#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΑρμθЮпЩψзμΦμГΗРΛ():
    value = 241986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgrhfXY02JpbaRWN33DCIRd/t1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уХпмиыЪХΛχ():
    if False and True:
        pass
        pass
    value = 354305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQHqPFM6+foWYimV30/EICYQ1zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪипΑБДΕμ():
    value = 402867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDrOVwdvpoEiIziL+kWJBjwp4ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9501 = 997
        pass
    return total

def _ЕιрДУуΧФдЦЭс():
    value = 487017
    text = __import__('base64').b64decode('TGZNalRnbGV1blBDMmtoVDBYcmk=').decode('utf-8')
    if len('') > 0:
        _dead_8695 = 559
        _dead_7855 = 328
    total = value + len(text)
    return total

def _κфоЛπσΒгныοщΘ():
    value = 771597
    text = __import__('base64').b64decode('Rnd2SVRzY0IwZmRjOFZqNHowaWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΡΞпΟΚρОышΓфτΟп():
    value = 324353
    text = __import__('base64').b64decode('YUpFdmJ6X0N2cFZlT3lPd3M5Yms=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛГΧЩΙΙюЪΨ():
    if len('') > 0:
        718
    value = 824427
    text = __import__('base64').b64decode('VGpXbXB0VE5NYUNncVVKem05X0c=').decode('utf-8')
    total = value + len(text)
    return total

def _СБЪδНυζηΜ():
    value = 59324
    if 29 * 35 < 0:
        pass
        _dead_2554 = 824
        _dead_2001 = 540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISvuRAAL5PwZCFfz3U6fEjEawFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 82 < 0:
        463
        _dead_2964 = 837
    total = value + len(text)
    return total

def _ЭφНтфчБΩЧ():
    value = 121888
    if len('') > 0:
        743
        201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQbvSUcf3J4INjqkw1KHbSwa5Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖЖΨдΛУбъЭκΕ():
    value = 439124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjvRV35tqPswKF2E2XSxFh8E3F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 31 < 0:
        _dead_9262 = 894
        339
    total = value + len(text)
    if len('') > 0:
        _dead_8911 = 832
    return total

def _енуюΝХΥΓДОЬΦΖЖΣ():
    value = 829365
    text = __import__('base64').b64decode('WGJDTWtFcVNjdHUzdVl0dkk3MHc=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6961 = 448
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _яЧγНΟгΑбЗшιкΔпр():
    value = 738551
    text = __import__('base64').b64decode('SklHc2xjNkIxbm5HZTVkMG9IZ0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΑлοΤзтικЗуΛλдМΘ():
    value = 198524
    text = __import__('base64').b64decode('RjI1dF9kTUJ4MEUwekM4ME5pbm4=').decode('utf-8')
    total = value + len(text)
    return total

def _РγГΕχπΚЦοдκ():
    value = 586780
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS23VEJt+IRRMj2FmEyBDhQ3sUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        835
        281
    total = value + len(text)
    return total

def _уτПτйЦЪРгΩΒзЩФ():
    value = 910274
    text = __import__('base64').b64decode('RGZVMHFOZjNsc1lCZzJKWUFmX2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩнБЪΞвФзΔШХΝωλ():
    value = 67727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgfbQFBp1p9QKQCvnETDAgYb8zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УХγпΔпьΨЮθ():
    value = 26890
    text = __import__('base64').b64decode('SG01VnN4VVlqd3RXMjQxNTd0Y2M=').decode('utf-8')
    total = value + len(text)
    if 81 * 56 < 0:
        _dead_5724 = 281
    return total

def _фφМююуξχΣмΑ():
    value = 381079
    text = __import__('base64').b64decode('SFJiVGlOOVBmVTVOMWVDUXA5dTI=').decode('utf-8')
    total = value + len(text)
    return total

def _бηнΕοчПьχэъИЕ():
    value = 521126
    text = __import__('base64').b64decode('UkEwTHJtUkZoZnNNRklMUkh1SUg=').decode('utf-8')
    total = value + len(text)
    return total

def _МЫνΤμбхΜψ():
    value = 732040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITbmTVks0qwSFTmR7AKjGT8g8Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыэωΗЬΑШΞН():
    value = 183504
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxXFUQURy4xXDxqU7VieMTwc4UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΕЖЧΖФсыкΠцΓζδ():
    value = 508968
    text = __import__('base64').b64decode('S1N3UDZyWF9ZR29jMjUxb3ZzZE0=').decode('utf-8')
    total = value + len(text)
    return total

def _юЫτЭαΨеλфλ():
    if len('') > 0:
        pass
    value = 887384
    text = __import__('base64').b64decode('cDVMVnVnTmk0aGRqdWxrN096SzQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ΖЪΘЕПгВΩΒЗяορ():
    value = 137194
    if 67 * 44 < 0:
        _dead_2932 = 296
        _dead_9539 = 900
        pass
    text = __import__('base64').b64decode('QXZhczFHSzVIajM0VUJFSUtFZkw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1686 = 373
        pass
        _dead_7330 = 634
    return total

def _ЦзЕψРлоЖьΥПЬС():
    value = 780308
    text = __import__('base64').b64decode('VW9QNW8wS25Lc1BWTEpKVWVvdVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _μθЬζπИΣХгфсубХ():
    value = 989670
    text = __import__('base64').b64decode('bURzd3hadTNWUHg3T1ZMWGhhX18=').decode('utf-8')
    total = value + len(text)
    return total

def _ζφηικчлΔшΝο():
    value = 783564
    text = __import__('base64').b64decode('TTloOEpQQll0VkJKaDVsZE9kdTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ОтйяЫξХнξаΠыΘΒψЩ():
    value = 145505
    text = __import__('base64').b64decode('aml6YjNaVjR4NVZTNVpoeUVUOGM=').decode('utf-8')
    if False and True:
        _dead_6540 = 627
        200
        166
    total = value + len(text)
    return total

def _ψΠΞНяζΣАУΟеомьλй():
    if 50 * 53 < 0:
        _dead_9394 = 88
        348
        239
    value = 683977
    text = __import__('base64').b64decode('RGFLYjd5dlE4ZnNTWUVmQU1wNWY=').decode('utf-8')
    total = value + len(text)
    return total

def _δλιΨΡпΜЮΒ():
    if False and True:
        pass
        474
    value = 493206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3u1P2Yp66IoPyn3w2OYHCop6jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        176
        _dead_2285 = 331
        258
    total = value + len(text)
    return total

def _ΗΞφΛрγзεУΣгЦτ():
    value = 940937
    text = __import__('base64').b64decode('ZFh3ZWRiS1hoU1dxSm9NMkRsQzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩψНцρЗлτД():
    if False and True:
        pass
        355
        pass
    value = 613080
    if False and True:
        pass
        _dead_6462 = 821
    text = __import__('base64').b64decode('Sk9MY2Zjb1RJT05WTXJGRldzXzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒθИЦЛФьΓчтΘξИш():
    value = 311113
    text = __import__('base64').b64decode('S2tpbWZHOWlSdWw5czlSUW9Wc1c=').decode('utf-8')
    total = value + len(text)
    if 8 * 59 < 0:
        pass
        _dead_8019 = 187
    return total

def _бπвЫЛСмъАРчвΖφ():
    if 7 * 26 < 0:
        523
    value = 86306
    if False and True:
        _dead_1873 = 499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjriXnY7q48oLjqp7gW8MAI8sEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 42 < 0:
        _dead_8186 = 443
        _dead_1840 = 807
        pass
    total = value + len(text)
    if 36 * 47 < 0:
        pass
        pass
        576
    return total

def _θΣσγфЦоΗЧςΙδэ():
    value = 792920
    text = __import__('base64').b64decode('QWlYRjRhbnhGZzNNX2c4aUx5QmM=').decode('utf-8')
    total = value + len(text)
    return total

def _УяΗдΟΤЩыιцЫςА():
    value = 436468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwfyZQM6zKM2ah+z73eCPS92tzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оЮΛшфГвХсыМΛи():
    value = 532491
    text = __import__('base64').b64decode('blZobElHVGh5RF9POV9Dd0VzY0s=').decode('utf-8')
    total = value + len(text)
    return total

def _οчпсΗЧЮСΠжΔΩψ():
    if len('') > 0:
        _dead_4845 = 804
        147
    value = 102503
    text = __import__('base64').b64decode('cV9yZDY1WVVVYUw2WkZjQmxsVVU=').decode('utf-8')
    total = value + len(text)
    return total

def _щщΣΖФжΑвЩЯЬθΒΓИЦ():
    value = 575678
    text = __import__('base64').b64decode('RnlaR1BTaHlTTEZvc2NCbHpfdVY=').decode('utf-8')
    if False and True:
        _dead_4294 = 855
        _dead_1006 = 458
    total = value + len(text)
    return total

def _еΤЙχΗΒΓцЧБ():
    value = 786042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCPLR3UIx7wrCQSlnn6YHwk4/HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚζΞАСξзξЗыяТюΦ():
    value = 47469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwOxPAQX7rJaNzr3/niDMTAD11c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠХВцλиЗЗРЧВЪρβщ():
    value = 563994
    text = __import__('base64').b64decode('WFl2QW5CNnRrRXFmMUM0TFFIc2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖβЕЛцΦЬпΩ():
    if False and True:
        pass
    value = 804302
    text = __import__('base64').b64decode('Tm9uWHhUc3c0UWdJa2VqQWRRWE0=').decode('utf-8')
    if len('') > 0:
        198
    total = value + len(text)
    return total

def _ΟъΩΥεηиη():
    value = 532136
    if False and True:
        _dead_8505 = 110
        408
        18
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn/+N0Jv94YoMjWw3mWqISwdym0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 34 < 0:
        pass
        pass
        _dead_6181 = 37
    total = value + len(text)
    return total

def _МΟлОΡνβЛМΘМЮοе():
    value = 241669
    text = __import__('base64').b64decode('UlF3Y0JiUFVOY2FYXzJtY0pYTVo=').decode('utf-8')
    total = value + len(text)
    return total

def _мΒВРυγбГ():
    value = 916688
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('U0txUlc0cWJrdlpHVWZtcDQ4Z0c=').decode('utf-8')
    total = value + len(text)
    return total

def _МАΤвЖεрΤцΟлШПтΩ():
    value = 946059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCjST2sq77wIajy02USzLXEowFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъθАΦпΤВξμ():
    if 62 * 92 < 0:
        987
        _dead_1541 = 176
        32
    value = 969398
    text = __import__('base64').b64decode('enpTaGpFN1VPRVRzQUkxcmxXOXU=').decode('utf-8')
    total = value + len(text)
    return total

def _юβрСΤΘςдνεБηКО():
    if False and True:
        _dead_4262 = 861
        pass
    value = 957069
    if 18 * 91 < 0:
        526
    text = __import__('base64').b64decode('VE1tcTR2WEp1YWVmZnFXMmJJYWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _βлνПХФШΛхπШΔиΤΛ():
    value = 592769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDjyfQkprvgGC1epyVuCZQQ6/Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        360
        _dead_9828 = 407
    return total

def _эъяВλхΗΟрХнΘΥьΖ():
    value = 417939
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBXtO2AM6LgIDxuU0U6xNzx/7WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νеΛкλОΔητ():
    value = 665004
    if 96 * 83 < 0:
        _dead_3416 = 684
        pass
        619
    text = __import__('base64').b64decode('VnhSbTZDbjBhR0J2U0lwajJreUQ=').decode('utf-8')
    total = value + len(text)
    if 72 * 97 < 0:
        _dead_9672 = 963
        _dead_5168 = 229
    return total

def _βВЫпбωλΤω():
    value = 204539
    if 58 * 36 < 0:
        685
        536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRfNXHwa0oMULj6N7Qe/ZQMLxlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ρоοЩΧШΡη():
    if len('') > 0:
        _dead_8312 = 503
    value = 531366
    if 11 * 15 < 0:
        pass
        940
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRzzPEQR+Lg6LgH7nWCXHyg4w0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥοζЦΙгΗГΘдр():
    value = 119256
    text = __import__('base64').b64decode('aFZFNWxaaE85d3lhaXJiWFNQckE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧДАГМΙπγфэЭ():
    if False and True:
        _dead_3016 = 581
        pass
        _dead_8007 = 998
    value = 209146
    text = __import__('base64').b64decode('UWNzT0xBVEZkc0lKMlZENHkyUF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΜιкεАсБΖДЮКκЮ():
    value = 888961
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAv3VnsP2Jw1Clak8Hy5HRM1tWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4350 = 994
        _dead_5423 = 190
        _dead_9792 = 137
    return total

def _ШνγЮрсθυμ():
    value = 690371
    text = __import__('base64').b64decode('bDRhSHVqVUxsQVdkN283TkZNZWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЪφАΑФИцΨБμНкτвО():
    value = 794646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESrvT0Qr0vspKzit30aRAB0/71E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2175 = 463
    return total

def _κХьΚγΚξЫжЧШПвΞ():
    value = 822222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyzDSlIt04omKAH3zGeiPHUC5n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 82 * 19 < 0:
        _dead_3099 = 596
        pass
        _dead_8125 = 347
    return total

def _ППΞКчдщβеΑΔеЮΠц():
    value = 633485
    text = __import__('base64').b64decode('U284aE5jTnZnRkFPNkg4M0RIdWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ςыσуГλъκκτ():
    value = 352870
    if False and True:
        _dead_9923 = 159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lw3zQUYh2oUQNiGK/VfEAnUNwlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_8557 = 966
    return total

def _ξаΨηсΚгЗ():
    value = 637596
    text = __import__('base64').b64decode('Tzg2aGtrOUVBSVBURnA5X0ZfQUE=').decode('utf-8')
    total = value + len(text)
    return total

def _υКзΚсιιЫ():
    value = 46335
    text = __import__('base64').b64decode('d2J0aU0yRTVpQWVmMVVzQW8zdVM=').decode('utf-8')
    total = value + len(text)
    return total

def _яΨΔЭΦΠйСюδ():
    value = 428767
    if 48 * 18 < 0:
        pass
    text = __import__('base64').b64decode('ZDFYUW5oSkVyUUduSXB4cE1rSUs=').decode('utf-8')
    if False and True:
        pass
        696
    total = value + len(text)
    return total

def _РюΞΟνэМУрътф():
    value = 911633
    if 67 * 88 < 0:
        pass
    text = __import__('base64').b64decode('VE5vOUE3TG15RlFyRW91a19PcEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЙΒбΒμиьУДхАΦеЪ():
    value = 625576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AADQeGEup4waPFa0zXyvHwcm0T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        369
    total = value + len(text)
    return total

def _αβБЕЧθэλοЗы():
    value = 435351
    if len('') > 0:
        _dead_3269 = 213
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgTPa0gWzKonDlyMzFWIPBcE0nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыψЩРχδЯЛэδЫрнт():
    value = 950927
    if len('') > 0:
        pass
        725
        _dead_5371 = 257
    text = __import__('base64').b64decode('WXNIQ3BfM1VzbzFPT25iSmVOZkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _σЪЕыΖШмПΨнтьΞΒ():
    value = 7875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IijQRUcU2b0ZMA61ywS8Pi57/mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        450
    total = value + len(text)
    return total

def _ψаΖνΛНΕрςΕΞШ():
    value = 512411
    if len('') > 0:
        881
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCfTTHpg/LkyLAqK90K6Jzw/4nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 39 < 0:
        516
        pass
    total = value + len(text)
    return total

def _ПΤЗΟбьΨзуχσоЗαΠΛ():
    value = 142575
    text = __import__('base64').b64decode('ZXpWUUNZQlZCdFpsV0xEV04wanI=').decode('utf-8')
    total = value + len(text)
    return total

def _ξхΞΓφМΣбуφΤМΕοφУ():
    value = 424481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQrueVZr9ocGEgqrxXKGBiJ5zzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΠλДζГйнлл():
    if len('') > 0:
        pass
    value = 948067
    if False and True:
        354
        _dead_1978 = 854
    text = __import__('base64').b64decode('ZzB1bGtzNlp4c1BTem1mRFJmZ3o=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΩΜДτщмηЩы():
    value = 340057
    if False and True:
        pass
        pass
        pass
    text = __import__('base64').b64decode('bWRvejI0Q0N5SlJXQmFRNnh0TE4=').decode('utf-8')
    total = value + len(text)
    return total

def _НοЭАьΟкРЙТКНы():
    if len('') > 0:
        _dead_9783 = 775
        _dead_6872 = 388
        261
    value = 900142
    text = __import__('base64').b64decode('RzFNYzlYNlBOeklTYzRHUDhKaTY=').decode('utf-8')
    total = value + len(text)
    return total

def _πψεфЕτОενхЧΟιΡ():
    value = 898497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQXLe39vqa8gFiqQ2weZMyF7z2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦУΔхψжμΗΓΝΑП():
    value = 84135
    text = __import__('base64').b64decode('bENVSm5xMDJZMThQYmJXeVpKcWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ξтнΖОБХБ():
    if 89 * 3 < 0:
        pass
    value = 222283
    if len('') > 0:
        _dead_1920 = 108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC30VHga5qEOGQax5F/GBDwK1E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_8742 = 8
    total = value + len(text)
    return total

def _уΔЛηДЫьηΗψыΨΩнТК():
    value = 551991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCLdSHAz6Z5XbxWy3UCqEXAttkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΦςΝФофЖ():
    value = 402292
    text = __import__('base64').b64decode('dTlVc3R5OHhEc3NZVGRKZElCb1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЬГЬДΣςЭГЩшЙο():
    value = 931362
    if len('') > 0:
        653
        _dead_7116 = 422
    text = __import__('base64').b64decode('QVJEVGJWS1E3dW5RaDFMS0p1TEo=').decode('utf-8')
    total = value + len(text)
    return total

def _αΜтЖКОκεЛΗрХ():
    value = 700229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3u2OHoz85k2MSqPn2nHOyEq9Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 61 < 0:
        157
        _dead_6543 = 6
    total = value + len(text)
    return total

def _ЦчЪβΞΜиΦμыМфαΩГΧ():
    value = 24544
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH/uOF41x6ExNgaM0QWRBXcfzUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_7919 = 909
    total = value + len(text)
    return total

def _ΚНДжΖцЦε():
    value = 119643
    text = __import__('base64').b64decode('WDFjWHQyZk5SMXAxNFJqOW9KdDM=').decode('utf-8')
    total = value + len(text)
    return total

def _жЫэьЯΠκхПхУ():
    value = 288777
    text = __import__('base64').b64decode('Vk1WTzdDZzdYeGREZ3o1djg3ZTk=').decode('utf-8')
    total = value + len(text)
    return total

def _кАΙЮДЙШΗРσ():
    value = 40539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxbhekI93KQ1Ayau8nzDHSAY3kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        690
    return total

def _ШИТνЛОвςВβΠъИхйД():
    value = 873210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwDbd3gtqoUWDSyZn1q7PhU//mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚзЛзНΠΓЧЗτ():
    value = 521914
    if 26 * 91 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ln/ifWltq7IFECyQ+FeaAQJ39mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6104 = 867
        102
    total = value + len(text)
    return total

def _ψьτшυΣΝμΝ():
    value = 282262
    text = __import__('base64').b64decode('YnRoTVkxVGZyd2ROaTh6YWdaVTA=').decode('utf-8')
    total = value + len(text)
    return total

def _мЪеδЪμХСΚРыνΝν():
    value = 656107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fzy8aWtp+akuCQmy/1K+JjcqsEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξлςЭнПяЧэιк():
    value = 110750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwXTT0Qp1vwnY1i77V3GPj0kzEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        323
        pass
    total = value + len(text)
    return total

def _МмшюΚЦΩφчψЦχαЬ():
    value = 736863
    text = __import__('base64').b64decode('dGVRR1ZUd0hNYTQxU3A5YkszSkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ТЮΦνΜΘЭкЩЪУтХУМ():
    value = 170889
    text = __import__('base64').b64decode('eWhOSFFiUUIyUUhyQ0FDNXJjRUc=').decode('utf-8')
    total = value + len(text)
    if 44 * 57 < 0:
        pass
        _dead_9967 = 416
    return total

def _ЯщРяпΡΟςцωэХτ():
    if 63 * 57 < 0:
        640
        138
        pass
    value = 978067
    text = __import__('base64').b64decode('Y01xdExVNnhQWGZiNElhOGQwOFg=').decode('utf-8')
    total = value + len(text)
    return total

def _чБρσЯдΝОФС():
    value = 167781
    text = __import__('base64').b64decode('Z1ZzTjQ4djZTZFdNR0wwWjlxM1I=').decode('utf-8')
    if 33 * 84 < 0:
        pass
        _dead_5200 = 973
        _dead_7391 = 671
    total = value + len(text)
    return total

def _μΙοΜюЕХζФ():
    value = 67868
    text = __import__('base64').b64decode('anFqanJ6eGhyUUZ1U2hyVkh0UWQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2753 = 935
    return total

def _ΞηГγэеУΚВ():
    value = 365906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESP+WghtrKAwHx2q4HiKFTArtnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        430
        196
    total = value + len(text)
    return total

def _щЕтАпΜЦЦЧШкюОхдЕ():
    value = 464075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB7uR1kqyKEMMCqQzWCRJHElx3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эЗΚγνοЩЗΡЦ():
    value = 289272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT3rV31vppo3Cx6mnm7JEwIYwnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΥΓРТЗΘЫпмΩ():
    value = 178660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IifefUsN7I8bDlqv6X2iFxAgxXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7907 = 117
        pass
        _dead_5594 = 552
    return total

def _нЕиБгЭькАКОрψщы():
    if len('') > 0:
        pass
        _dead_4028 = 813
    value = 950120
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTbxTwgf0KYGNRWi/me4MSwW13k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        822
        pass
        pass
    total = value + len(text)
    return total

def _χьДΙιХуΔηΓγзГΞИ():
    value = 325329
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lw3TYGkLyP8FMzaLnGaYMH0p938='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИЫТλБдЗЛИπпСЖ():
    if 64 * 14 < 0:
        _dead_2371 = 950
        _dead_4678 = 965
        _dead_1127 = 552
    value = 714421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHr0UQQu2bkGMDv0+gLEABIZ6F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЪΤθστЭъΘи():
    value = 977302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiLOemUb5pIwLSSb5weUFzIgzzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тзΙРйХΓΖΠпКьюъй():
    value = 295212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CD3SPlUrzb4lHliZ3gOzAR98/XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДдρБΞшНвΚωзΔξ():
    value = 315279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyG3Wnc9y4sQY1yr/HO+ZCoKsFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εεшγъЭкΙπξρΡуд():
    value = 605614
    if len('') > 0:
        _dead_5324 = 595
        pass
        459
    text = __import__('base64').b64decode('TlFYa0R3YjllZTBnNThfZmVkdl8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3111 = 352
        950
        558
    return total

def _хξЙδνΟεЕμЪΑ():
    value = 452969
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('RVFmNjg1SE5PVGlWQlFpbVpydE4=').decode('utf-8')
    total = value + len(text)
    return total

def _АΓлРμаГОжκкΗ():
    value = 544685
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSyyeV1t8JoJEgyc0GOUEyMmyGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 43 * 17 < 0:
        968
    return total

def _ъонжγЪΖйЙЕд():
    value = 109862
    text = __import__('base64').b64decode('aEtnNkxVS2V0UWFBTFNPYjVxY1o=').decode('utf-8')
    total = value + len(text)
    return total

def _θЖШШΔπАз():
    value = 791183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQnLPkFp3a00PVyG/EW+Nh0gymE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λДιεΨйτΡуюО():
    value = 712409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyW9SnNpyK4hFQCIy3LJbQ8G82g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙФФшЯчδйψΖχΩΨФ():
    value = 522280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LD/AXgUXyKsLIFbx2FPBYzALyWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СθцпКгНΤΡаыжйεм():
    value = 876045
    text = __import__('base64').b64decode('QlEzRkxLQ29YZFRCZkV3UzNTY3c=').decode('utf-8')
    total = value + len(text)
    return total

def _тΜДхψΩЧΕΘμъΩюбΡ():
    value = 124221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTfPeGko3fk3Ll2CkEeCBSo9zEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςпЖмЙЧъОΓоΩМ():
    value = 421624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyfbSwIV26shD1f2/1izCwka3kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 72 * 40 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _омΧЛαιЬυПΔСΥпАμ():
    value = 67917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pz3FT3ou6KU8CjuEzF2KECgc0EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωтзБΖКЫРжμΙ():
    value = 541505
    text = __import__('base64').b64decode('dVFLa010OXJ2RmFOb2l4ZVRmMFI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        716
        pass
        715
    return total

def _шΤΚТΥкНОТΕΚЬΟοю():
    value = 798928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IH/DPQUo9pITaSeW6VK0EC8gtGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЙθчΨзΧΤιΣЮλкСЯ():
    value = 746308
    text = __import__('base64').b64decode('dmdERTVSODZlTVFMQ2lSeDN1Q1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ροΨΚъΥоΘуаζС():
    value = 756115
    if False and True:
        _dead_3519 = 584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTa3Z1A38JwHAwf02wG+Ijd3tH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БПОИΕΦΧξасРΨμ():
    if False and True:
        _dead_7202 = 382
        pass
        pass
    value = 870703
    if False and True:
        pass
        pass
        763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz3PXAYOrYIMDQfwx26HPRI373o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 97 < 0:
        _dead_6545 = 12
        196
    return total

def _χХГзпαιчΓОнп():
    value = 49968
    text = __import__('base64').b64decode('RmdpdDZSdVlsNkVxQ1NwemxnUGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΓεΓИючρзЯσΥΖ():
    value = 541612
    text = __import__('base64').b64decode('QTFhYUo1Y19vbDFCc2J3Mzd0SEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _αНαЩВΕεΗСуξзгΨа():
    value = 551375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCrWbVYProEkLB2Q3GLJHwMVx1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        451
        pass
    return total

def _ВΕχЩщЭлхγтΡЛуμ():
    value = 276017
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAD3PVoz2L4pFlaMwUemHQ8cy3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 70 * 64 < 0:
        _dead_4044 = 674
        pass
        pass
    return total

def _сψцЩφгщЕБΜΚяаТΥ():
    value = 266901
    text = __import__('base64').b64decode('bThWN1ZGSmtHdlJBMkd0alJyUnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ζαатΛυοБ():
    value = 853867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQ7oW2Mgx/wtDCaqm36HZjUL4G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖЖЭτχλмΘΣψюЪΛ():
    value = 488727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQvDd30+86UrFl2FnlnIGxU48Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 2 < 0:
        589
    total = value + len(text)
    return total

def _ΞΨНΞςБγМоιΒЩβкхХ():
    if False and True:
        897
        pass
        pass
    value = 911349
    text = __import__('base64').b64decode('em95MEZmSUpsZDRVWkNfU29ZUEs=').decode('utf-8')
    if len('') > 0:
        15
        pass
    total = value + len(text)
    return total

def _ИАλОФжχОМюЦΙТΝы():
    value = 494422
    if 59 * 36 < 0:
        _dead_3764 = 274
        _dead_3253 = 520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhrWZl9o/LtTNwOn5XGcMnUC1lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        261
        _dead_6978 = 0
        _dead_8670 = 613
    total = value + len(text)
    if 19 * 59 < 0:
        152
        _dead_5677 = 621
    return total

def _ДτШЙШψДЙΑсжζ():
    value = 179414
    text = __import__('base64').b64decode('U1poR21UU2xSRVZnX0xlUGtfeTI=').decode('utf-8')
    total = value + len(text)
    return total

def _КЯхЖκлюΤωЖΓлΓλΙ():
    value = 691088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTbyTXwKybJbIz7x6gSXNggp62g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4555 = 619
        _dead_5387 = 465
    total = value + len(text)
    return total

def _ξуйяδνΕфеШКнфс():
    value = 586064
    text = __import__('base64').b64decode('bmdQWG00OG1QMHE1MHpCTVpzNTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ГξвШυдбГε():
    if 37 * 21 < 0:
        pass
    value = 549729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSbLRnYs84w7NQz7yXOkYAkpzjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_5262 = 908
    total = value + len(text)
    return total

def _НАМЛΔФΚВ():
    value = 376838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwLbf387r5ELLga2xQS6Hic3/Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηζρΜшψФΖЮΘ():
    value = 318153
    text = __import__('base64').b64decode('WWtrVl9LemZHREUwcTAwRlQ1NDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΗюдХφΜълфн():
    value = 841989
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQrpQ3Jpx/koFTaQ/gG+IgF53Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гЛГλΒγωЗωΣ():
    if 58 * 10 < 0:
        pass
    value = 70977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHbIQV0r2pEXNT3121yiEhon9TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НφнΠАγΓИυβЮч():
    value = 693562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXvCanxt1pE3MCul6mzFHyt5wjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЕΥЧуЧрбαгβДΚъΖΠы():
    value = 105189
    if False and True:
        _dead_8158 = 114
        pass
        951
    text = __import__('base64').b64decode('ejVBSzNyNFJmQXhIYklXdlhkR3U=').decode('utf-8')
    if False and True:
        _dead_9591 = 698
        449
        _dead_8839 = 136
    total = value + len(text)
    return total

def _ПθШЕХΤсйнψЗ():
    value = 746678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSTjZXcy1rI3LB+V+XWqLCohw2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αебψГзξζΥχвуβ():
    value = 464919
    text = __import__('base64').b64decode('Rl9Lb1BZRnh2Vk51UThpUTVlOFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _чВуνКуψгЕЖкчεЧб():
    value = 192165
    text = __import__('base64').b64decode('aGM0VGdLclhkN3ZSUTV1cHJRS20=').decode('utf-8')
    total = value + len(text)
    return total

def _ПοЫΤΓХэΔζаЛλ():
    value = 844580
    text = __import__('base64').b64decode('d0pmNnFYczhoN000aGxXWExRRW0=').decode('utf-8')
    if 46 * 100 < 0:
        pass
    total = value + len(text)
    return total

def _чωαпАЯШδπνОб():
    value = 817248
    if len('') > 0:
        _dead_3482 = 448
        _dead_4908 = 562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnjhZUgQqaAKOR6F/GCTYCYd510='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7319 = 240
    total = value + len(text)
    return total

def _УβЧΦэРΟΧδквЬ():
    value = 994496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBjgRnkD/bsSKhelwUWfGDIb8l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьοИΟцξΑχβЛоъВι():
    value = 768131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgqzPlsr7oc5N16k0FeRYnQ59UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УдςΦъТωЮ():
    value = 410021
    if False and True:
        _dead_2316 = 49
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRezY3UJ7/8GGSGU4lSJABM71XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_7474 = 956
        780
    total = value + len(text)
    if False and True:
        pass
        _dead_9158 = 746
        798
    return total

def _ΘΩчΩМσУΜпЬхγЯιтЫ():
    value = 305074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzzvWWA9x4UoMx6UkHTCDhQX/Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΨчДнлΝФРФΣΥΟΡ():
    value = 773953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXvqQGUerpA1LDeJ/2CKYwcX1lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮяХχОщЬТиЮμδИРΣЙ():
    value = 394611
    text = __import__('base64').b64decode('UF9HNm92cUROZmQ3bmsyWlJlT3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _υφБρςЩжβΥ():
    value = 459238
    text = __import__('base64').b64decode('T21ud3ZVanR1MFJyODNjVDB3NkQ=').decode('utf-8')
    total = value + len(text)
    if 59 * 52 < 0:
        480
        469
    return total

def _ДцρсΞιЖΞμγИ():
    value = 121386
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cwuze0ABz/AMKgSGzXLHHCwW4kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зαΒХАπОЗкτЩτфΨВб():
    if 35 * 51 < 0:
        pass
        781
    value = 108493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyTeX1ojr6Q6Izyw7UbAOgR94FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΘΛшΦМрдпςεΡ():
    value = 526479
    text = __import__('base64').b64decode('all5Z3FnNjNZemJGV1JYaUM5T1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΖдЙξΚйΖΦПдΣ():
    value = 561884
    text = __import__('base64').b64decode('cERFTjFBU3BPU2hNN29XTzZtTk0=').decode('utf-8')
    total = value + len(text)
    return total

def _тбψρθΔΑзШш():
    value = 811662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRnmPUQb9pcgHF+imlC7BCN703k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υФюΗЗοуυкλζβж():
    value = 48273
    text = __import__('base64').b64decode('VE1rWnJqd1hvMXFkYlBTZFdXMk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧзΞХЦННРяΧ():
    value = 676241
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD/NOlkB0/8wIDqk+Vu7OCQC9jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΟΛВξЮтξЦЮτΙΤΦ():
    value = 68076
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiH2e3Ns5L4iEiKq8VLJPX13zHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЛΡωΧρУнЫмм():
    if 86 * 62 < 0:
        849
        _dead_5660 = 565
    value = 351494
    if False and True:
        710
        pass
        _dead_3816 = 415
    text = __import__('base64').b64decode('ZW9aTGhYUE9WeEJBSllpTkd6OWQ=').decode('utf-8')
    if False and True:
        650
        766
    total = value + len(text)
    return total

def _ψУбΦΖчцющж():
    if False and True:
        _dead_4755 = 100
    value = 407578
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('Vl9HcllqRWd1TDdydGpwWTNkTEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦσпξСκцй():
    if len('') > 0:
        833
        521
    value = 699252
    if 34 * 40 < 0:
        _dead_4649 = 625
    text = __import__('base64').b64decode('Y2l6eE1yRXhvSUY1N1FYVDRYS0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨГЕуυΩвΜξΦψΕ():
    value = 76110
    text = __import__('base64').b64decode('RGJCVWFqMUtrc2RORjVPbTJ4TDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _щΧашыъцзъ():
    if False and True:
        _dead_6798 = 539
        _dead_9214 = 836
    value = 693406
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCrsRAUo2pglKx2vxnWyJw0/8WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 14 * 16 < 0:
        pass
        464
    return total

def _κЛοΑΩыКΡаеεΛСапЭ():
    value = 998547
    text = __import__('base64').b64decode('eE5aMUxIS0x6Q2o1NF9DTDMwRjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΛτΘАИИφ():
    if False and True:
        pass
    value = 239103
    if False and True:
        pass
        _dead_8066 = 262
        _dead_7316 = 981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgjTRXkD54kQb1f2x3OcAxcK5WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лυЛмыωθζ():
    if len('') > 0:
        pass
        pass
        pass
    value = 495774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3rFPWUW8KEyKD+b8V+zJnQu5mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лрγщΙιЦЫэСкБ():
    value = 107449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyzCOWVhpqcHGT+UznyqYyAetD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СбφтσУдЬΜγΟφ():
    if 90 * 35 < 0:
        pass
        pass
    value = 19053
    if 74 * 64 < 0:
        _dead_8430 = 286
        _dead_2733 = 788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Awbiel4Gx5IOFiW36QWlOBV40E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4532 = 114
    total = value + len(text)
    return total

def _ввЛΤЦюШΗеахЕк():
    if False and True:
        _dead_3703 = 955
        pass
    value = 296030
    if False and True:
        671
        439
    text = __import__('base64').b64decode('Uk9pQUZnakF4NlFPVDU2X2JlcjI=').decode('utf-8')
    total = value + len(text)
    if 80 * 15 < 0:
        pass
        314
        _dead_6718 = 469
    return total

def _ТΖθνГЭξЧнψ():
    value = 673128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MySyTGgSyb4FaSaO8maXDAc68EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЖΡЗΦюнАρУШρЙογ():
    value = 735682
    text = __import__('base64').b64decode('am1qUkRtX05QUEdXM05JWVlnaW8=').decode('utf-8')
    total = value + len(text)
    return total

def _щъХЦμзмиΛηλσйрю():
    value = 44433
    text = __import__('base64').b64decode('ZXlqVWNlT1BEcGJJa1RQM083REw=').decode('utf-8')
    total = value + len(text)
    return total

def _шТьαζχбΟбсП():
    if False and True:
        _dead_1662 = 97
        _dead_7302 = 634
    value = 696871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fn7XOHdvz/8iLQGx+U6dLggg0Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 15 * 38 < 0:
        _dead_7206 = 141
        _dead_1605 = 900
    return total

def _шΟζОнυιрТчξτΣАШ():
    value = 887071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxfiUUho1oRXYjCawU7DGgQl7X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΟЬиуτεээТ():
    value = 152796
    text = __import__('base64').b64decode('ZlZfbFU5b2tuTjAxVENTcVA1WlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑуνЬЭБЬξΗЧγрГΥш():
    value = 40404
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjXAS3k06ZA0NR3w6lSSAwYL9WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΣУЩυαУлυйЪЯ():
    value = 699461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCHwNmQQrvwWFQSinn/GHwZ791c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αеΨΟШρκЬПоΕХюхмВ():
    value = 943700
    text = __import__('base64').b64decode('SmR2cGZYcVJ3MHU5Sm0xZW02Yng=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_1604 = 200
    return total

def _πςХяψΜФОοσΗΣунΣЩ():
    value = 875326
    if len('') > 0:
        562
        _dead_2889 = 218
        58
    text = __import__('base64').b64decode('WldpOVIwVGM1MDBnelQyaHB2MUs=').decode('utf-8')
    total = value + len(text)
    return total

def _рΠΥЗГтΟχИЗΙπьцж():
    value = 855677
    text = __import__('base64').b64decode('VDFnZWFpR0hTcmxNbEttYTBvMjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ТТБлЭаΣΕ():
    value = 488902
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fy3GOHg+6pIZADW20WmgYwsJ9HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯЦхΑΞИыρИЫбδΞΙ():
    value = 185161
    text = __import__('base64').b64decode('WVlKTEVWQ2tCYVhBbUJOSDY4SkY=').decode('utf-8')
    total = value + len(text)
    if 48 * 78 < 0:
        618
        _dead_2151 = 909
        pass
    return total

def _ΜхВΗЧοδтгβΟΡ():
    value = 151193
    if 75 * 58 < 0:
        489
    text = __import__('base64').b64decode('SEUzdTRDQTFDMURmS1JVeDg1aEk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3739 = 32
    return total

def _ПАδλЧχыΟВΟжρ():
    value = 313509
    text = __import__('base64').b64decode('SkZ1WmJvOWZUbFdhYlFQNENJUUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗБъχαшΩνчууХΖ():
    value = 88053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQvXY0Jh6fonMBq0mXCiHXECtVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓНЙщφШКγьΩΥкб():
    if False and True:
        134
        pass
    value = 710329
    text = __import__('base64').b64decode('WjdDUVIzNzFBV1ZWc3JXRUFCdHo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        53
        pass
    return total

def _дθщМЫβΠлНηψ():
    value = 304211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3rRb3Yf6LhaEAmG0AalIy0b10A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦоΗμιфПхωψШГ():
    value = 240726
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX3XSgc1//s2Kwf7/W6bOnU3y08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щНжεΝяоΩьςΟшκΣ():
    value = 591349
    text = __import__('base64').b64decode('UVM4R0lORHdMZXhFa3FYSlc0S2U=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        535
    return total

def _ΟυыйчЖхΚΗΝъ():
    value = 127503
    text = __import__('base64').b64decode('QXBic0psYW9pTmpxUEdyWDBjSVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖСущЖЛΜК():
    if 71 * 24 < 0:
        79
        pass
        220
    value = 522391
    text = __import__('base64').b64decode('TlMwSXdMVVAxVWVMbHVCTTFUR2s=').decode('utf-8')
    if False and True:
        pass
        _dead_1962 = 894
        _dead_8201 = 538
    total = value + len(text)
    return total

def _χзПηЕхшΠ():
    value = 70261
    if False and True:
        pass
    text = __import__('base64').b64decode('Wk9DVVRUekdESjljaGdFaDdBME4=').decode('utf-8')
    if False and True:
        _dead_6879 = 783
        _dead_2015 = 392
        836
    total = value + len(text)
    return total

def _цβΜΙΞθОрΝ():
    value = 522981
    text = __import__('base64').b64decode('VzV0bzlVU1J1VU1IS3RIRmtfYVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('cg==').decode('utf-8'))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()