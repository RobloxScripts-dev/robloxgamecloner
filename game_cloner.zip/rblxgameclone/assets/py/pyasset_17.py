#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ωЫФщЬиΩЕрнДθ():
    value = 805352
    if 15 * 33 < 0:
        pass
        pass
        420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyDLS1Q39ockEAu7yUayZ3c+wkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИттЮлФшЙ():
    value = 754547
    text = __import__('base64').b64decode('WHpMZXNRcVZpQUVfcWtKRzZWRE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒЪχΗУжкωЪυΞЪиΛμ():
    value = 814416
    if 96 * 80 < 0:
        _dead_9991 = 613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx/Sf184zaMICyC1ynmJGRx3yFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5963 = 194
        _dead_2370 = 6
        pass
    return total

def _АЬΚθΤγξοьЮμ():
    value = 180434
    text = __import__('base64').b64decode('V1pkVDVHQ3haYWlhMFVRSjY3Szk=').decode('utf-8')
    total = value + len(text)
    return total

def _ШьΒΔБЧуρюшьΤцλар():
    value = 3554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR7ldnIdx4UgOwut4UOUGyEH4Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3519 = 513
    total = value + len(text)
    return total

def _ФΦΠΘСΚНΦЦЩ():
    value = 954952
    text = __import__('base64').b64decode('Z01QaGMyMzBoblI1eFZISFB0UFA=').decode('utf-8')
    total = value + len(text)
    if 42 * 6 < 0:
        pass
        57
        _dead_4703 = 29
    return total

def _рΗεЮСΒκΣ():
    value = 828658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgPTREFv9ocJKiap/3exBCwgxTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бψпηдεМЩуКУЙΞπ():
    value = 207364
    if False and True:
        842
    text = __import__('base64').b64decode('T3RMWk1udnFxN3Vjam1nVEZNS3c=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2648 = 675
        782
        pass
    return total

def _мξΨНКΡиχЭιоΦшЩ():
    value = 35527
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx+8QWAz0aI5EAmH/1vFHiYK0kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зβБΟКИЧАлλХΛΟв():
    value = 496834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjrBT1ca+bwJODW2/F3HHnIt8To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔеШИМеГЧΞЖμШςфДЖ():
    value = 317674
    text = __import__('base64').b64decode('VkpfNEVCOURmWmVPOEVnS1RsWnc=').decode('utf-8')
    total = value + len(text)
    return total

def _СγкЬРэГЙΧωасЦцξ():
    value = 249712
    if 29 * 39 < 0:
        _dead_7427 = 251
    text = __import__('base64').b64decode('aEUycll3N3VycVNLQ0ZtUmdTbDY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4923 = 336
        pass
        _dead_7154 = 921
    return total

def _ΕЫщςЙΣΤΥκΖСгΜЛς():
    value = 105892
    if 61 * 53 < 0:
        _dead_7918 = 225
        _dead_4635 = 385
        579
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ey7UfAQtyKsPa1mN3kSpPjN59jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ХгмЫνΩФЬФбΕвιЭао():
    value = 688140
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCHdW1cY8qYkIgKUkXWXHywc81s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 53 * 66 < 0:
        pass
        850
        _dead_5107 = 578
    return total

def _иψОμПэγСδΚкАτσπ():
    value = 613097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgewRUNv+P5QOA2FxX+gJwsIsjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИлАНΗЬΙλзΔΕΜ():
    value = 13104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhXlP14U5PAsPTqs63uUE3Ulzko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жчмνъξчΙΤοι():
    value = 372884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bwu1dgIQ3IYoHwCyy2aJMD8a7EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЮЧшяЗΠΚΟμЪХ():
    value = 603649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHntZUNg6PsUDxulzFPFIxMK7k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2500 = 683
        pass
    return total

def _μψбОЕцНξ():
    value = 421243
    text = __import__('base64').b64decode('ZUVVT0hteHRTWTdWbXhqeTlYN0w=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_6277 = 965
        _dead_1192 = 792
    return total

def _λКΚаΒΦаζЬμς():
    if 91 * 26 < 0:
        pass
        _dead_5386 = 125
        _dead_5926 = 813
    value = 267743
    text = __import__('base64').b64decode('bHdXOF9lTnhobXZVSGhLZmN6NnQ=').decode('utf-8')
    if False and True:
        pass
        880
        _dead_3376 = 48
    total = value + len(text)
    return total

def _ЯтΕΕУΟΕЫюψμБΡΩЭф():
    value = 944822
    text = __import__('base64').b64decode('bHJFTzliVFUxQ3dzVVJHaTROVkw=').decode('utf-8')
    total = value + len(text)
    return total

def _кεЖЭЬяφχжГоοΖшТ():
    value = 348643
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCfCTwEP85kmCwOMml2kJw85wGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 62 * 69 < 0:
        pass
        _dead_1792 = 157
        389
    total = value + len(text)
    return total

def _χаЖьΑсκξкβξ():
    if False and True:
        16
        pass
    value = 502283
    text = __import__('base64').b64decode('dWR3MkxPUXdrM08weTVwdUNWUFA=').decode('utf-8')
    total = value + len(text)
    if 24 * 88 < 0:
        _dead_5000 = 497
        pass
        pass
    return total

def _ЧΨЖΖАЛΡψНФДнБτ():
    value = 427305
    text = __import__('base64').b64decode('QlVvTUVKSDczS2E3WFhlQmlxUHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _УзΚуΣтСя():
    value = 63066
    text = __import__('base64').b64decode('RWVUbWVIN1VZYVc1Z2dMMjFGT1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ГνпцЪзАщΩКΩВ():
    value = 168327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz2ydFw2zIcsFlem0VCHFwQ7t34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΔεягВΞμюδδАю():
    value = 572365
    if len('') > 0:
        _dead_2285 = 949
    text = __import__('base64').b64decode('VFlzOGZOQlowaWw3X1d2ZzkzalE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7203 = 57
        _dead_8568 = 676
        942
    return total

def _ВΒαкπΙуцйЕθЗгВ():
    value = 163331
    if False and True:
        506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjfoXGsfyoM8YxaOylOBZTAa/Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ζξЧιъЯЬλы():
    value = 109095
    text = __import__('base64').b64decode('bE5Uc3BpUnVicXI3dlBYRXhERWg=').decode('utf-8')
    total = value + len(text)
    return total

def _зщΜИΘЦнΤοφЖη():
    value = 141377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyLWQ31p8qQsYg72xWyYGhMg4Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кηΟοΨМБлΞАφт():
    if len('') > 0:
        554
        _dead_5130 = 177
    value = 916507
    if False and True:
        346
        pass
    text = __import__('base64').b64decode('TEVhN3laWVdROUJXM204c0ZOS2k=').decode('utf-8')
    if len('') > 0:
        _dead_1954 = 835
    total = value + len(text)
    if 58 * 79 < 0:
        pass
        pass
    return total

def _жГωшσЛΞηГΥρЭЬепА():
    if 31 * 36 < 0:
        _dead_4515 = 184
    value = 983184
    if 96 * 24 < 0:
        _dead_1826 = 323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax/yRlcM/5AHMyKi526/BSk600k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АХΔЮυνΟЮρмΡлЧΡ():
    value = 244613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERrneXgVzr0tHDuzkUaSYjY6zns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_4481 = 957
    total = value + len(text)
    return total

def _рιηЭЮдΛηΧ():
    value = 692040
    if len('') > 0:
        _dead_1366 = 137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHrqPUkW6bgqLzmE60TIARAOtVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        470
        pass
    return total

def _σνΧтЖгΩΣиδΨТ():
    if False and True:
        127
        pass
        pass
    value = 948625
    if False and True:
        pass
        35
        _dead_4041 = 999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NADlOVYG16pabCmP4lyRJQ08tkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        666
        70
    return total

def _ψкоζεвΚΗ():
    value = 350673
    if False and True:
        pass
    text = __import__('base64').b64decode('cVlJUkZhcjJHbjNpd1J3WTlXeW4=').decode('utf-8')
    total = value + len(text)
    return total

def _νΚьЩβЩЙηπυТ():
    value = 53244
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxbUXlQxxooFF1nz3QSbOwR55nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΚАψХςΠΨζΦФфβз():
    value = 725664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lje2ekktrIATCQec5EHHDnUp5kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 6 < 0:
        759
        pass
        _dead_6815 = 277
    return total

def _ЖДПшηОСνщ():
    if len('') > 0:
        94
        pass
    value = 741727
    text = __import__('base64').b64decode('SnRWaG5OSEE1SWNEclUzTlpUSHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЬμаГеЛВэвгΒ():
    value = 641179
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRDjSEAw7KQOaCmW5AazZxY520M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        668
        568
    total = value + len(text)
    return total

def _ΤЕЯУьЬВЯςΖ():
    value = 712083
    if 96 * 3 < 0:
        pass
        792
    text = __import__('base64').b64decode('SFhyMkpkU1ExX0lEeXFIbXhFZXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞξκГЧΦмΧТβς():
    value = 494379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDWxQXsz35kpF1iPyVGjFiAA71k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПЩεежΑОΡΩСйςлЗУ():
    value = 964715
    text = __import__('base64').b64decode('ZjZLWmJlNGxoOTZybnVtcHJqSlU=').decode('utf-8')
    if len('') > 0:
        794
    total = value + len(text)
    if 61 * 38 < 0:
        _dead_9717 = 706
        pass
    return total

def _ЪΡυτσΘΨКГщ():
    value = 181529
    text = __import__('base64').b64decode('QWpzb3ZIZDFzVHB4bUtrYVRUWG8=').decode('utf-8')
    total = value + len(text)
    return total

def _пУЬΑзьщΛЕΝм():
    value = 521774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwzxOFk+qrstCyWp6V2yOxQ/3l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_7910 = 997
    total = value + len(text)
    if False and True:
        pass
        _dead_8478 = 648
    return total

def _тАιПΦИΩб():
    if 85 * 67 < 0:
        _dead_5943 = 286
        pass
    value = 163611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHrBSH8O9JkKIwCK7UaeJCEeyUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3541 = 221
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_9870 = 439
    return total

def _ΝξΨХюΖνбΛдΞТХνεг():
    value = 27306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj3dOWAA/L8MaBmZm1+2B3EXxn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΨпοЫаыдΑοφβδΨъм():
    if False and True:
        239
        pass
    value = 720772
    text = __import__('base64').b64decode('eVBoMkZEam5mTlVNR0szaVpWNmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΛγδτΜυΛυ():
    value = 115176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDbSbFgwp4UJDgGU6gO1JwEht0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЕΓтΘτΚОΥмФЫΤΝЫ():
    value = 971723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx7+YF8q8ZoLLAmOkGOAERUG9Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠчφΔΗУряешьΔЖР():
    value = 12844
    text = __import__('base64').b64decode('c0FrR2xSVjFDWktHZ181NDBweW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩеПλьжшιΕΡЛЕэ():
    if len('') > 0:
        61
        9
        _dead_5125 = 992
    value = 814816
    text = __import__('base64').b64decode('eTdrb2FtQ091VHZhWEpaSjZ0clE=').decode('utf-8')
    if 65 * 89 < 0:
        pass
    total = value + len(text)
    return total

def _ЯЕΙЭтΓЪнбДЮ():
    if len('') > 0:
        _dead_7782 = 636
        pass
        _dead_9352 = 541
    value = 44973
    text = __import__('base64').b64decode('TVk0UVpuR0x3ZmxudFRSbzhDaGY=').decode('utf-8')
    if 70 * 48 < 0:
        397
        391
    total = value + len(text)
    return total

def _фГУηхρуеηыχЬΠ():
    value = 914584
    text = __import__('base64').b64decode('ckNnbmhHZjhPVDd3eU9IVXV3Tks=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ωрΟУЭβλКξξβб():
    if 48 * 86 < 0:
        pass
        458
    value = 216528
    if len('') > 0:
        _dead_7869 = 425
        pass
    text = __import__('base64').b64decode('QUVFUTl3Z3M1dDhWVkN1SzNCQ3o=').decode('utf-8')
    total = value + len(text)
    return total

def _νХΨαЦαмευδь():
    value = 179160
    text = __import__('base64').b64decode('aXNaa05xNnFEX01sazJCZ0U2S1A=').decode('utf-8')
    total = value + len(text)
    return total

def _нσσщауΗйκΛαЩι():
    value = 942635
    text = __import__('base64').b64decode('UVY4V0RlTTRETUtZS1ZKc0lnM0s=').decode('utf-8')
    total = value + len(text)
    if False and True:
        397
        pass
    return total

def _шкэξАгΛΘ():
    value = 797779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAfrRAIO16kILQCp6Xi0BC4Z50E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕвГΖφΚΣΜЫиηХΞЮ():
    value = 511947
    text = __import__('base64').b64decode('STBJcktWQ0JqUUhyR0MxRGpPM18=').decode('utf-8')
    total = value + len(text)
    return total

def _бТθζШЗθхΛ():
    if False and True:
        pass
    value = 72473
    text = __import__('base64').b64decode('Q1VVVlhmamdnSGh1OFdDNnVxcE4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        59
    return total

def _ерДВΣОοыЩНΠЛюхγΧ():
    if False and True:
        _dead_1308 = 46
        _dead_3754 = 51
    value = 9835
    text = __import__('base64').b64decode('RXZBWEV1TVBjNV92NWhrSlhuOU4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1431 = 577
        77
        _dead_5564 = 102
    return total

def _τйЖιονυЯΥюνЩхЩΜ():
    value = 740172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LATUR1cMqoc6FRXz5wK1FwgfzGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГдΝюЗцπЛΖ():
    value = 903945
    text = __import__('base64').b64decode('aFBNOUU5NVE2Zk9jT3ZvaWVqcXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ТуΗУЩмУпΛΧλМ():
    value = 433412
    if 90 * 97 < 0:
        619
        pass
        578
    text = __import__('base64').b64decode('QnNyX0NDdkhxNWpSdG5uSFBLSUk=').decode('utf-8')
    total = value + len(text)
    return total

def _жБЫТиζΧωΠ():
    if len('') > 0:
        825
        _dead_2643 = 304
        _dead_4910 = 331
    value = 514824
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izf1ZwU+q6YCMAOk3nCDBz967T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эдТΕΗНΑВпπАωβбвυ():
    value = 873152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTi8RFMyyowgKgD3wHqgOC069zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 47 * 91 < 0:
        pass
        pass
        _dead_6601 = 653
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ЬжθЬЬΕКимΤфΜЫχ():
    if False and True:
        226
        _dead_8639 = 662
        _dead_1212 = 315
    value = 117058
    text = __import__('base64').b64decode('dFJNc01BcHNVcHVUMWVtSDJJRTM=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if 31 * 99 < 0:
        991
        73
        _dead_1170 = 53
    return total

def _ЗωЫЩЖТРΥΥ():
    value = 289295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3jeR3gW1ZIFLjq042SxM3wttD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РуНнцоΨЭθюλГус():
    value = 593884
    text = __import__('base64').b64decode('SnUzV1dYYzVYeUZpc0lEOERRaE0=').decode('utf-8')
    if False and True:
        _dead_4104 = 604
        pass
        _dead_7309 = 674
    total = value + len(text)
    if 52 * 55 < 0:
        pass
    return total

def _μйОσЧαлыоШΕπ():
    value = 507031
    text = __import__('base64').b64decode('bl9hZTJSNUU5VGZ6ZFJUUk9fTVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫДрЩоδΒщДеρΟκςго():
    if 26 * 83 < 0:
        744
    value = 180939
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh/xQ1YY87IIBSCP/GKaDgQrzV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9852 = 998
        pass
        pass
    total = value + len(text)
    return total

def _ΤфуЧγψДДб():
    value = 614876
    text = __import__('base64').b64decode('R05lakhhZDRhNjVfSklONzRKSEc=').decode('utf-8')
    total = value + len(text)
    return total

def _щгдΔшаΗΞЛ():
    if 5 * 98 < 0:
        _dead_5807 = 935
        pass
        715
    value = 117660
    if 36 * 55 < 0:
        _dead_3614 = 549
        490
        749
    text = __import__('base64').b64decode('QXJkc1JJYnNVRUJSYmliNUJKMmo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        705
    return total

def _ΨФюФηαэс():
    value = 295548
    if len('') > 0:
        pass
        611
    text = __import__('base64').b64decode('eDRzSlAyQ3l4SG1mc01SOV9xanE=').decode('utf-8')
    total = value + len(text)
    if 92 * 2 < 0:
        _dead_2412 = 866
    return total

def _ЛпъΛнюβΘ():
    value = 923522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQH1YEce0q0GHDuExUK2DSgVtUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 72 * 79 < 0:
        900
        159
    total = value + len(text)
    return total

def _ИУκдАΛЬВЫ():
    value = 848087
    text = __import__('base64').b64decode('eFJkazVXUU5GWnloOEdOQ0pienQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        44
        488
    return total

def _ΒΗШъνТзссΗпИГ():
    if 69 * 17 < 0:
        _dead_9826 = 582
    value = 772226
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACnCWFIJq7EvEj3z3WzDYRUCx0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЩкхИЧΧΖДОЭ():
    value = 926059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQTbZwBg3YIlEAuSkVWyFREi3Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψεЗчТгХУШщПЪЦи():
    value = 302252
    text = __import__('base64').b64decode('aU5rUTdqM2FDMFd4amlYNVdLYmY=').decode('utf-8')
    total = value + len(text)
    return total

def _хяΓΣυλψзНЬфыШйю():
    value = 351389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ixrdang8+ZgGND2Z4HSlCw081GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥЭИπψЛΩгπΤεο():
    value = 691758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDjXTVMr2a4rGwa10ljGPT0FsDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥШΑΨΘШνОξфуΞЧ():
    value = 866240
    text = __import__('base64').b64decode('bWR6ZmZkWHprelZhUzJDNXZHMXM=').decode('utf-8')
    if False and True:
        331
        pass
    total = value + len(text)
    return total

def _РКυзχυХфИξцГзκВ():
    value = 324506
    if 31 * 45 < 0:
        pass
        _dead_1280 = 755
    text = __import__('base64').b64decode('SlBvTGVRR3J2QXptZU1RWjF2NFE=').decode('utf-8')
    if 20 * 38 < 0:
        898
        873
    total = value + len(text)
    if False and True:
        15
        645
        pass
    return total

def _тяэпДжωρзΦ():
    value = 609946
    text = __import__('base64').b64decode('bGgzNFB4OFBCcGM5ZHBBSWVaRDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЛΡасλΨДПωдиЮоΚЩ():
    value = 478541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fwu9eHUe6vEMAAaSnVOVYh8t3VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЧфΑςНЛЯсоΒ():
    if 37 * 94 < 0:
        _dead_3574 = 687
        pass
    value = 313269
    text = __import__('base64').b64decode('ZVozSm50TmplZEFIREpUQ2hYbWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧβΓЩΒГЙЩΤΖαЕх():
    value = 234321
    text = __import__('base64').b64decode('SENjeUVnT1BzMzVkUExVNXFBbEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΦВЦЮоιдЪξе():
    value = 610557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyrKa38e9vkhPge3xluhJBMg82w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΩΣΡЮιεεэωВ():
    if False and True:
        857
        _dead_1108 = 823
        pass
    value = 56633
    if 15 * 68 < 0:
        pass
    text = __import__('base64').b64decode('aXYxSWNFUG4wSUxHQld6c1BUa1A=').decode('utf-8')
    total = value + len(text)
    if 6 * 18 < 0:
        pass
        pass
        pass
    return total

def _ζΠямКψШΜБ():
    value = 344615
    text = __import__('base64').b64decode('c0R5ZHVwOF93NERPZ3AzREI0WEc=').decode('utf-8')
    total = value + len(text)
    return total

def _γбυрΔεъярνШτβψэ():
    value = 668119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx3WeGAs/6dSIgi2kUe8DisY8ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _люцΜЪχДΥНκЩОЫ():
    value = 607371
    if False and True:
        _dead_5479 = 113
        pass
    text = __import__('base64').b64decode('cEJZeVYxNW5MSGtYT2pRenVqazI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5066 = 164
    return total

def _НщΙΦтАсΗεΙцΞжЖεъ():
    value = 892901
    text = __import__('base64').b64decode('RHdXTExWVGVZelRZNVFQMFU5b1k=').decode('utf-8')
    total = value + len(text)
    return total

def _πКЗдКНηΦнз():
    if False and True:
        pass
        _dead_5194 = 279
        _dead_3141 = 575
    value = 93388
    text = __import__('base64').b64decode('TEI5QnhhR2p2WDVBZFV0amg3VW8=').decode('utf-8')
    total = value + len(text)
    return total

def _εХлΨκЛЭΣΤδα():
    if False and True:
        _dead_7213 = 253
        pass
        40
    value = 335375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Awr1YlIN7po6IgrynkKeEjIL10o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζчЕψΔΞЯРΖεοЬэ():
    value = 928656
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAjGeH4q1qJSA1nyxmySFQMYy18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if 81 * 76 < 0:
        pass
        344
        _dead_4081 = 670
    return total

def _сΞΛРιζЮΞьΞЬу():
    value = 931461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyG1WHcf7K5bLxaZ3niEHXEH9EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡθГяУЬφΖοщΔС():
    value = 538933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx/BZ1kzqqk5OACkmHuzPXB5/Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙоκюЪпьЩшζфυΚл():
    value = 19030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXbbd1A65I4WFieE0AOyPnEl1k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        23
        243
    total = value + len(text)
    return total

def _λΞΣсЛΤΚπБуЖΖΨаι():
    value = 599704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwjqYkdu0p4gaV6EkQXAJQd/00g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΙΦмβδΤпК():
    if False and True:
        pass
    value = 333275
    text = __import__('base64').b64decode('RmpRUThXRnhWaXRhYkdleVI3Zks=').decode('utf-8')
    total = value + len(text)
    if 14 * 76 < 0:
        _dead_5822 = 865
        _dead_7863 = 344
        pass
    return total

def _лЩушΕщгγμтη():
    value = 762147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDfBfgEpyYYKFDaPy2G/N3EFvD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_7920 = 347
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if False and True:
        pass
        pass
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 27 * 56 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()