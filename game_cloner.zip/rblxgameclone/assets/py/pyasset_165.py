#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ЯροДΜΑЩпЬфШдιω():
    value = 563550
    text = __import__('base64').b64decode('YjVydUsyNWc3NmVVTUd1WWloOV8=').decode('utf-8')
    total = value + len(text)
    return total

def _бΔтηйЙσгЙΘэχаЫгй():
    value = 689662
    text = __import__('base64').b64decode('dHkwS3U3VmRoZFk3Sk9oNU50dUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧХСрςμοΤБ():
    value = 756214
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IH3yaGUQ5qkZHz712XDDBCs51j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нζυПеΡξмгКНоТ():
    value = 949996
    text = __import__('base64').b64decode('WExGdVNmVFZGWW50Q21QeHFPNzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫъХΥЗΥЭаΑщЭсР():
    value = 493472
    text = __import__('base64').b64decode('QXVHWTVzZ1JTNmtHbXZkUlVWcG8=').decode('utf-8')
    total = value + len(text)
    return total

def _яйЪΘΓХыΥш():
    value = 677760
    if False and True:
        814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix6xSUQ08JAOIB63ykW/Ihw44WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΩгΦδσаХДΔζепб():
    if 31 * 24 < 0:
        84
        pass
    value = 548116
    text = __import__('base64').b64decode('SU5yVnhScTBGQTVVR3hSd3FNNFg=').decode('utf-8')
    if 85 * 24 < 0:
        684
        _dead_7811 = 208
        pass
    total = value + len(text)
    if False and True:
        607
        _dead_7502 = 955
        pass
    return total

def _οЛдеΞцςЬЬνтφΛЙ():
    if 47 * 87 < 0:
        _dead_6724 = 110
        pass
        pass
    value = 699848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHzge3MJxoUTYw2L5UKiJwsKy1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4928 = 703
        _dead_7861 = 513
    total = value + len(text)
    return total

def _эЯрζΕвμαι():
    value = 583905
    text = __import__('base64').b64decode('T2NYUDBCRVVXempKbVlWSGN1S28=').decode('utf-8')
    total = value + len(text)
    return total

def _хуЕЛΔЯχσвлгβσлΥз():
    value = 655865
    text = __import__('base64').b64decode('QXplNlQ2cnRaM0Iyd1N0UlpIZ2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗοЭАФΡцнυЩМВрвЕт():
    value = 393394
    text = __import__('base64').b64decode('WGp2Rkt6cFZjZTZIaTg5ZFQ4NUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓсΔШРΧяζЧДЯωΨ():
    if len('') > 0:
        pass
        347
        pass
    value = 56645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pz/0ZFpr1f0MPBaWxQOKPy8m4Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 19 * 77 < 0:
        _dead_4746 = 266
        pass
        _dead_8332 = 943
    total = value + len(text)
    return total

def _ЕΟβИξφЙΤδбЫБп():
    value = 299660
    if False and True:
        pass
        pass
        pass
    text = __import__('base64').b64decode('VW4yOTVqd3FNYVlucjZuZ2s3QkU=').decode('utf-8')
    total = value + len(text)
    return total

def _жΕьμΑωМиэУτηЦ():
    if len('') > 0:
        187
    value = 531683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3zMWglu+r8CECuUn2fDETcqyT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _сАΓЭαшνΚыΝχξ():
    value = 540543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSbhSkIrxKEQOyTx8H2nHg451GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кКмΞМЖζеνβξΕЗβб():
    value = 490389
    text = __import__('base64').b64decode('VE9PWXIxQXFZbllLeTV6SmRhdks=').decode('utf-8')
    total = value + len(text)
    return total

def _пиηοШΩыц():
    if len('') > 0:
        782
        pass
        pass
    value = 980733
    text = __import__('base64').b64decode('ZXV3VTFDaXZabEpxNDlPaVE4Q3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝψΖаφΨΝρΞΙΩяΥσъэ():
    if len('') > 0:
        pass
        670
        pass
    value = 179840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwXPQwVs2akWDiunxVShPwc11EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΨАйγαпРκЯйця():
    value = 179714
    text = __import__('base64').b64decode('WjUyaEU1MzZKeXY2OXM1eGJCeGc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ςЭζνрΗЗΛиχвωж():
    if len('') > 0:
        pass
        127
    value = 484822
    text = __import__('base64').b64decode('VEpXZjRlQWdZQ0Fva2tuX0RWa2k=').decode('utf-8')
    total = value + len(text)
    return total

def _рДΨнЕфιεРХр():
    value = 161108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiLCRnIY6400AzaT3U+cYwEBxT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        347
        _dead_8406 = 683
    return total

def _λυйтКЯιρ():
    if False and True:
        pass
        661
    value = 423913
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgL2Rkso9bxRaRvx7EaaPDd9sGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7872 = 641
    total = value + len(text)
    return total

def _ХκЙСФдСТрОЙ():
    if 37 * 45 < 0:
        147
    value = 704504
    text = __import__('base64').b64decode('UW05a3pVaDRzTVVmaEhZdTNKaWI=').decode('utf-8')
    total = value + len(text)
    return total

def _эКШпГΝΠЙЧ():
    if False and True:
        pass
        _dead_7141 = 191
    value = 784395
    text = __import__('base64').b64decode('aTQzbjJmQXVIZU1ab2I1SHFMblk=').decode('utf-8')
    total = value + len(text)
    return total

def _χΓбьΖςБΧΦδОГгψЪЫ():
    value = 873171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICLlOWEt270XKjfz3Q6TbC866EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΖВΣЦБЪηυмгЗ():
    if False and True:
        945
        pass
        _dead_3417 = 709
    value = 84252
    text = __import__('base64').b64decode('dmY3UHc0Y2w2andBVjJaY1ZGekQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕσчИΠΗнυλЪνРРςΑс():
    value = 627084
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fii1YwQW7ZdVLCWR436aPjV78Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3395 = 586
        _dead_8145 = 257
        pass
    total = value + len(text)
    return total

def _цοсжРЪΦЙЛΓγХъ():
    if 69 * 64 < 0:
        _dead_2071 = 198
    value = 865591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSjAeWdq+58iMSOh3Xe9OQEa6j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 64 < 0:
        pass
        pass
    total = value + len(text)
    if 80 * 83 < 0:
        702
    return total

def _ΘбβЛΒпЯъщСΠΟПо():
    value = 655061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IynNTX07xqNaLSWizHeRJjwt8Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1443 = 27
    return total

def _ΟΠνЭцΖЗΗσεмРΩΩλ():
    value = 969782
    text = __import__('base64').b64decode('U3lHUVpxMkl2UzVJZmpWTW9aVGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ДЩοЗιаЬЕЙоЙяκνΛ():
    if len('') > 0:
        746
    value = 176062
    text = __import__('base64').b64decode('c3BsRmhfcm1EdmVKUGc2Tkp4XzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕНвШЩяΑλиς():
    value = 660043
    text = __import__('base64').b64decode('SnMzcDZYUFFPMHg2SjVWbGp1OHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣгЫмфВшъδΝйπμςщθ():
    if False and True:
        703
        118
    value = 382147
    text = __import__('base64').b64decode('Z3k5cFRDaWhPRk5uX1RjTUo2dm0=').decode('utf-8')
    total = value + len(text)
    return total

def _φВпЩΑβμнβъβ():
    value = 213003
    text = __import__('base64').b64decode('UzF0ajNEcWNwQUNMT0ljOUtON2U=').decode('utf-8')
    total = value + len(text)
    return total

def _χыρΝΕЮШоЫыЦλσЩДЖ():
    value = 675032
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bjv3fnAo14MmC1j25WCJHxwH10g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _СυнГιταцΕπлΠωжΜς():
    value = 354744
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDvsXGAS0Zw1CQKk/E+JZxED4Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΡΤжΔεОαΣΧ():
    value = 60442
    text = __import__('base64').b64decode('dlNaTmZYWFNTVnpkV2lWZk1oQ3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ψрзжяΩХδηАξιψя():
    value = 485821
    if False and True:
        774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwTHeWsqx4E1H1m68kO0Ey4fsXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θκСехΠОωКΩгнгеλΒ():
    if False and True:
        120
        pass
        pass
    value = 268117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxXHOGsP3LELPCqIx1ekBid/wk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6887 = 326
    total = value + len(text)
    return total

def _ъНωУНЧЫΘΦсНΣбηδД():
    value = 28999
    text = __import__('base64').b64decode('dFhuOFE3TFNJWmpCN202YlNfdmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩξнοсζфЬΩΓδфхСНμ():
    value = 457882
    text = __import__('base64').b64decode('alpVMWdMZzlzTjFyU2szRW9lYmE=').decode('utf-8')
    if len('') > 0:
        202
        pass
    total = value + len(text)
    return total

def _уςΛОЫХбршθФэЛ():
    if False and True:
        _dead_6101 = 768
        pass
    value = 92698
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn+1SnULwY8RLzr25F+fLh0KtFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЙΛЕЦМтΗζефЕ():
    value = 368017
    text = __import__('base64').b64decode('eThaYjRzZ2RpMkdGODBoZUZJX0o=').decode('utf-8')
    total = value + len(text)
    return total

def _шдΙъΤрюлΒγр():
    value = 753705
    if False and True:
        pass
        647
    text = __import__('base64').b64decode('eGxveDdaYUhlVXQ0d2cxQlRQQm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΥΒюωФтЦБΥм():
    value = 187179
    text = __import__('base64').b64decode('elVDRDhiOG4wVzluTXJSdDd4R08=').decode('utf-8')
    total = value + len(text)
    if False and True:
        71
    return total

def _ЕАρΘΞШтЦ():
    if 53 * 80 < 0:
        pass
        _dead_9356 = 910
    value = 847037
    if len('') > 0:
        475
    text = __import__('base64').b64decode('UFVLWko4OWdueVpRZzY2ZFpjUGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ТиΑУЮдΕЛΥыиε():
    value = 133037
    text = __import__('base64').b64decode('Rl9TN3ZteldodmdQRXRJRkJINzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΗпсΥяυюβμοИΥл():
    if len('') > 0:
        410
        530
        _dead_5532 = 91
    value = 123484
    if False and True:
        _dead_9463 = 630
        pass
    text = __import__('base64').b64decode('UXY5bnhLZE1waVVJZXNuMV9lT2g=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        906
        _dead_4617 = 845
    return total

def _ьπжμРИйζφГΛΖгΨσΧ():
    value = 904323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQLrP1krqJ4Jbxvy+W+bBz0c3FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВфРПψΥыΕЪΥ():
    if len('') > 0:
        _dead_8713 = 516
    value = 962219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgTFWkYr7K0qI1ua+3uIORd4tT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        599
        pass
    return total

def _аγшτΟфиШн():
    value = 918307
    text = __import__('base64').b64decode('YkVmWkIzOWZzOHA0VzZiVEtUWmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _εМхεЪНσΚццЗΩΝΗ():
    if 55 * 78 < 0:
        497
    value = 386244
    if False and True:
        _dead_3565 = 974
        457
    text = __import__('base64').b64decode('cTNVNWlyTXlRYXF3YWpLVXp6VEM=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _НИХнΞУЯΔту():
    value = 144419
    text = __import__('base64').b64decode('emFwUThUZFBrUE1QUFEwRFhlMTg=').decode('utf-8')
    if len('') > 0:
        _dead_6591 = 686
    total = value + len(text)
    if 52 * 28 < 0:
        885
        908
        pass
    return total

def _ξΔΞФЖМΥбρ():
    value = 92863
    if 15 * 74 < 0:
        432
        831
        665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiPnXVQd3LgIIjuS+0CqDXE9/GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЪЙфМоΡшТеяξэΓ():
    if 79 * 68 < 0:
        pass
        390
        37
    value = 694369
    if False and True:
        14
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAfLPwgtrPtTPh6a5n2jGy09w0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΖеъρсбаСЮονйεΨΡф():
    value = 74489
    text = __import__('base64').b64decode('S1k2ZkljOVZnUktXdFowa2RFNjg=').decode('utf-8')
    total = value + len(text)
    return total

def _сφρΓжлхνЧιбΦЧλЦ():
    if 15 * 85 < 0:
        pass
        _dead_4095 = 30
        pass
    value = 604826
    text = __import__('base64').b64decode('TnQ0RmtsemFvWUpiVHU4ZmlRdVI=').decode('utf-8')
    total = value + len(text)
    return total

def _βжΞмпΔДабШ():
    value = 921297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgjBXEIV6PwhORy1xEaBZjMK5ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΙчωΠЛΨяΤхР():
    value = 371979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESe1akA37oAqCAWvnUe7YxEEzDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΝнβΙпИεыηЪЧρ():
    value = 850494
    text = __import__('base64').b64decode('dXBWeEJKZTJiTWVYQm5xalFLN24=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _УПβКЮΝКΠит():
    value = 882166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw7DPXIPxI8zGDX6+UCfJDYesFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΔρτγЭΖД():
    value = 292334
    text = __import__('base64').b64decode('dU4zM0JJVGZnV3A3YXk2N1BsdWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ТιкчοщοβХЦιΩцкР():
    value = 559595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTvQekkjqvgWaC6L/3yBA3QVw0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψФВфПΞшзβ():
    value = 936223
    text = __import__('base64').b64decode('b3hGeFdPQ0ZHTWxMVld5MDhDdjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧηυДΗяεъ():
    value = 196819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwTKeUsW05wBaSiy6n69AiIMykM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЦχТЫΜыμгчΚυЕοы():
    if len('') > 0:
        _dead_9979 = 267
        pass
    value = 204418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzXXXlQc1IwMMRel2VqqC3QC1Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7541 = 465
        478
    return total

def _ЕЕуЪэσΠΡЧΞыП():
    if False and True:
        pass
    value = 619449
    if 9 * 93 < 0:
        649
    text = __import__('base64').b64decode('RkFLTm51N1VkcHg0S2ZxcUNKNm4=').decode('utf-8')
    total = value + len(text)
    return total

def _цΩдρЖНΞи():
    value = 630243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSnSeQgU3IoaHwyM2AO4ASwDwjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖζЩπТЗжμιХоюΓο():
    value = 31155
    text = __import__('base64').b64decode('WUhXNnhQMURlT28zblczOG9xVkk=').decode('utf-8')
    total = value + len(text)
    return total

def _фшσУΥΓΗХΣхЩНькЦГ():
    value = 70270
    text = __import__('base64').b64decode('bUdkdGk5bVJwM01JMjhkS2RISHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΣΤεПкρΝилΓыСχнЙ():
    if False and True:
        986
        _dead_1035 = 335
        931
    value = 849305
    text = __import__('base64').b64decode('cmtvc19wbzlrUVZhVXBlUk9OQjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒЦйΓθΓριΝζΝп():
    value = 935821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARrbWlsNzqATMRiL7W6YASoIsjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гπМщооηΖсτΠМ():
    value = 417677
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhjBOWEgp/ERIyetwgOjPhEt0jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЭΣаюβедыΚΓкрКΚзΓ():
    value = 92852
    text = __import__('base64').b64decode('eU1hVjFYdEpPNXN4SGV3Zl9IN0w=').decode('utf-8')
    total = value + len(text)
    return total

def _знШвσНΑЛαα():
    value = 926581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAXGNmg1/aVQHF7673CKMTMqtU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 66 < 0:
        384
        pass
    total = value + len(text)
    if 2 * 82 < 0:
        pass
        _dead_8227 = 566
    return total

def _ЩЙИΤΖвсХ():
    value = 531175
    text = __import__('base64').b64decode('YnVCaWJzTnhIY0xTaHNQWE9XTUg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _АДгΤЭυβςΕМΩψЮР():
    value = 779561
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATXFPFsI7Js6Dxm38WmnZA4ZsXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФσФбвΔЭγδωХ():
    value = 798090
    text = __import__('base64').b64decode('bzVjRmhiUXZ2aVB2amtGT3Y3a2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙςκсБсИςфΣκмρЙ():
    if 71 * 28 < 0:
        pass
        pass
    value = 134855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhjPWXYj6KkQLRiswg+REg0c3GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оашΕдчИЪ():
    if 99 * 1 < 0:
        361
        pass
    value = 722949
    text = __import__('base64').b64decode('d1lOeUg3bmRoM3J1YjZweFA2ZG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪψЪΗЫφπΒРъ():
    value = 776695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AirWR0EV77E7OQO162nFC3N4w0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        685
        _dead_9864 = 657
    return total

def _ΨχаυψΣяЖωΓЗФщ():
    value = 818978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nhf+ZUATr7oRHRr6/UWAZBEZzlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыаюγМЯьΛλитΥ():
    value = 982417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQy0V3IQ+aEaPB2u+HyXEA56/FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζЩμлΘзХΥПδфс():
    if False and True:
        775
        pass
        pass
    value = 655513
    if 33 * 33 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQH1aUg9zJw8EAz3wkK/EAcE9Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δМΧθЖюААτλтΣРΛ():
    value = 10035
    text = __import__('base64').b64decode('TnpkNWhGQWgxQzFyNzJYbFRwRWk=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ФвущμФиΒВπдΧΖЙΜ():
    if 55 * 10 < 0:
        _dead_6470 = 321
        766
    value = 420150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxDWeGM1ppsUYxWxz1WbGSx57FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 73 < 0:
        pass
        604
        608
    total = value + len(text)
    return total

def _ΣΠтρΨСДЦщбα():
    value = 247101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ixu8eXoy6LlXKTaRxVySOgsOzDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КρξЕΙыЦω():
    if False and True:
        226
    value = 571476
    text = __import__('base64').b64decode('UnFaaE0wQ0lNNEVUY0JUUU5hWTM=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _χρшеозΛълпЬΩрσЫ():
    value = 430779
    if 49 * 59 < 0:
        _dead_1369 = 704
        pass
        _dead_1658 = 325
    text = __import__('base64').b64decode('d0RVY1FwTnpPMEJKblRUbmVSclY=').decode('utf-8')
    if 77 * 94 < 0:
        _dead_9750 = 507
    total = value + len(text)
    return total

def _бАЛЮзИΑтЯλрλКБΞ():
    value = 94245
    text = __import__('base64').b64decode('VkhEVFBmOW5UakpwS2YzMDZoRV8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЫЙΓзънψЛξХρъТ():
    value = 56115
    text = __import__('base64').b64decode('bjlqV3p6MDNfRnNoQTZBQjJPTkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪПνλζЛΛΝΓкυЕ():
    value = 370735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjnAdn4h+5wCDhein2HDBA4V3Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 76 * 43 < 0:
        971
        _dead_6556 = 872
        pass
    return total

def _ЫяξΤУнМв():
    value = 507397
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzzxXnIA/acTACKlmFWGDCIKwF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пШΤΑχЫηлΖ():
    value = 855397
    text = __import__('base64').b64decode('VVBRVUZOOW5LU2ZaUGVhQnFvMks=').decode('utf-8')
    if len('') > 0:
        896
        331
    total = value + len(text)
    return total

def _ФΠχкиНνАО():
    if False and True:
        _dead_8278 = 419
    value = 511791
    text = __import__('base64').b64decode('YnhvN0V2Q01UYndjVVNXeGtuNUY=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4156 = 825
        368
    total = value + len(text)
    return total

def _РΓиΧςψινЪρζΝд():
    if 7 * 80 < 0:
        967
        pass
        pass
    value = 904477
    text = __import__('base64').b64decode('ZWN0WWN4RUN4a2d6eFNpbTB5Sm0=').decode('utf-8')
    total = value + len(text)
    return total

def _κбйПшръΖιжΞаХя():
    value = 662147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhvORHBs774gFTiJxmKfbA0e4zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΚБσιЖУБнμΔЖЯюλЩ():
    value = 741875
    text = __import__('base64').b64decode('SW1EdGxLSTFLZDNldnEwcWs2Vzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗБШεИэЬΧБΞηН():
    if 5 * 89 < 0:
        _dead_3970 = 776
        691
        704
    value = 875935
    text = __import__('base64').b64decode('SXNoUnVobHV5R0FXMUVzckx0VmU=').decode('utf-8')
    total = value + len(text)
    return total

def _δЙХЪоШλεюЕΔКЖρ():
    value = 834900
    text = __import__('base64').b64decode('eWx2TURvVllfbXdEZGVoWDZDMmQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        872
    return total

def _ΓβΩДβΝΚεЩфжКΥй():
    value = 702503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSTbQgIDr7ALLDuo4Hm3OwB5yXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψμρкΙζθδодДε():
    value = 428971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxf8PQIhyYskDwacnm+9LTB+t1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9039 = 375
        _dead_6628 = 117
        152
    total = value + len(text)
    return total

def _ЬиπЕнНЩщОδΨ():
    value = 440222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz7oSmZqrYEoKy617U+qbRMY03w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 85 < 0:
        382
    total = value + len(text)
    if False and True:
        840
        _dead_2105 = 755
        pass
    return total

def _эΚбмЯΛΧмКΝρ():
    value = 732668
    text = __import__('base64').b64decode('enZydjZoaUYycXZ5UEo5Nkp1TFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙγуΝжκчΤжцХЙщΟ():
    value = 275987
    text = __import__('base64').b64decode('TGJBZjdqa2R6WlVrWXVNYkppV0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖНЦΠΤМζκ():
    if len('') > 0:
        25
    value = 737073
    if False and True:
        pass
        308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTq9ZWIrrJwIOVqo+3qFOiR213w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6942 = 735
    total = value + len(text)
    return total

def _ΞυЧЙπХαАζъθУ():
    value = 430489
    text = __import__('base64').b64decode('d0d3anQwaFVUOVpGVTE1anFtVkI=').decode('utf-8')
    total = value + len(text)
    return total

def _λьΦКΨψοФΟξΒ():
    value = 352368
    text = __import__('base64').b64decode('bUE5Nnkxc2JYM3lfRnZfdG1uU0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩгяаλАЦвΧΙχμфω():
    value = 600937
    if 63 * 2 < 0:
        _dead_2054 = 863
        _dead_9142 = 750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LizhZ3ospqoBNiGv5nCcJCEt/lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦЮЮοΑΗβΜ():
    value = 635258
    text = __import__('base64').b64decode('UUU3Yk1LODBpYjhUQ2w0c1FadnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤδΗЭζХΟкМΞТО():
    value = 485801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX/VZWgX8f8lMT6p8E6qPXINx0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        709
    total = value + len(text)
    return total

def _ДвτмКтДπΤβРμ():
    value = 945650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRazRAA9qv9UAAua5HiSBg8t6k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥЬаОВΠРлЬЩЛжΧΗ():
    value = 180848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxCxWEEjp5oKCh2VmnCiLQF2vGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 42 * 41 < 0:
        481
        pass
        _dead_9270 = 160
    return total

def _ФуЦδйьΖΕе():
    value = 593020
    text = __import__('base64').b64decode('aGk2aWlDWm1fRG5BWlBiVUlTN0o=').decode('utf-8')
    if False and True:
        26
        pass
        249
    total = value + len(text)
    return total

def _σАζπмΧшηΜ():
    value = 193712
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kj/PeF5t7IdUGR+v4kWgGw4dzkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яЙΓВιьΡιАγ():
    if len('') > 0:
        pass
        856
    value = 530406
    if len('') > 0:
        _dead_6546 = 99
        _dead_2375 = 752
        _dead_1457 = 489
    text = __import__('base64').b64decode('VE5CUUY1cXloVU1rT2R5UTJZRWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚеИΓЬΠΧΝςΧΕЕШФц():
    value = 360960
    text = __import__('base64').b64decode('TE9fdWNxendmNEZvbmFDT3lIU08=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔТДΣъэςΠΨιΡγбΟ():
    value = 112516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQvGe3Vq/KotAi2vy3CKGzUi3Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_9348 = 359
    total = value + len(text)
    return total

def _иХνδΔΔφη():
    value = 364864
    text = __import__('base64').b64decode('R3NaWjZGZlhaM1pmWGFCWVI4TG0=').decode('utf-8')
    total = value + len(text)
    return total

def _кΝνлЦтΒΞΝщо():
    value = 76591
    text = __import__('base64').b64decode('S0paZXY1ZVV1Y3JVb2ZqVFNITHU=').decode('utf-8')
    total = value + len(text)
    return total

def _хшυуχрΩπБымΞεюъ():
    value = 992356
    text = __import__('base64').b64decode('RlIwc2VITkFxVjE4MDNSNXhWOVU=').decode('utf-8')
    total = value + len(text)
    return total

def _омыуЛЗчЧ():
    if 100 * 42 < 0:
        _dead_2928 = 931
        481
    value = 20732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCfNUX0W+5ctIheXwnqSFRx9/n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖαъΟЛτνЖΖЭнцΨК():
    value = 370477
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DB7UWHQrqZkXIi6W/lSYECl9tlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΖΟκЭЧЭΞДζΔВ():
    value = 373722
    text = __import__('base64').b64decode('ZUduaVBQbjFxMzAzUDdDaFRBbTc=').decode('utf-8')
    total = value + len(text)
    if 42 * 35 < 0:
        _dead_4331 = 144
        pass
        _dead_1083 = 319
    return total

def _ЬΣψдХγйθХ():
    if len('') > 0:
        _dead_3799 = 941
        578
    value = 494499
    if 21 * 67 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cha3QwcfyKInGzagwWSbLi0O80I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 15 * 90 < 0:
        pass
        _dead_6414 = 752
    total = value + len(text)
    if len('') > 0:
        718
        777
    return total

def _ЫВЛсэУънЖЗмЪΦΧ():
    value = 688087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz7XaHth24UNPwqix0eeZw4n4U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖдеΔΠΩθΝΘЦц():
    value = 88965
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwXhZlgP7pwHLz2pw3XBITYe/lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _омюбэГьХδΡЭгЙл():
    value = 765141
    text = __import__('base64').b64decode('SkVYdV9xN2g1UFRyRG8yZnExMGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΝΠГбфчЗΡ():
    if False and True:
        _dead_9033 = 188
    value = 943459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH3Fe3Bg8/kxDzCR/1u4Zx0HwGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3445 = 332
        804
    total = value + len(text)
    if len('') > 0:
        794
    return total

def _ЧηзΧТщьΤυω():
    value = 132777
    if len('') > 0:
        746
        _dead_3340 = 927
    text = __import__('base64').b64decode('SDhVemJORWxkVWo3dWJwb3ZrVEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗпТпθοННζтυЧ():
    value = 933184
    if 72 * 28 < 0:
        663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATj2Pl4KqII0Al3yzXuJB3Y96Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 28 * 52 < 0:
        pass
    total = value + len(text)
    return total

def _БШηЦυΨКΟ():
    value = 953439
    text = __import__('base64').b64decode('YWhCVzF4NXZNd3F6WlU5Mk1GcGw=').decode('utf-8')
    if 27 * 71 < 0:
        _dead_5399 = 170
    total = value + len(text)
    if len('') > 0:
        952
    return total

def _ΙεΤкЫИςЙΨжκ():
    if len('') > 0:
        pass
        456
        pass
    value = 819545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bgb1bUMc+58EPwD7mQKEHAwBt20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кЙΝμηΛεΔЮΣ():
    value = 62713
    text = __import__('base64').b64decode('RW9GOXhaMjlKZjRVN1NTSTFvN2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚаЕΘΩζнΥиΜΝ():
    value = 923085
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KATqbQQS0KcVETn78m/GODEM7Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σдΞэΓΥΘτΕщЙ():
    value = 654639
    text = __import__('base64').b64decode('cDhQY3Q5UG53NXpEOTFoMzVnN0M=').decode('utf-8')
    if False and True:
        532
        pass
        _dead_3567 = 132
    total = value + len(text)
    return total

def _ОΨνрπФЯщΑНυъνАΜ():
    value = 695201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAvgfAUJx6AHbzC6kHm0Jy888GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤАωбБΤьΖъоМΨвΥ():
    value = 160821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECfwa0kU6Z8VMgqEmGeGZxx+sEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΖΞбΚΩХΛСжςэ():
    value = 737757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCnIPVMNzLwnHhzw52OyLnw94n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 3 < 0:
        879
        485
        pass
    return total

def _ОлКΤюβОзМ():
    value = 264086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQy8aFMj959VLA2Jm1jHZxMA6TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηэανΦВжсшлЬьЭοПю():
    value = 569317
    text = __import__('base64').b64decode('SWtMTVBtS3p5Z1ZUNkxHdF91RUU=').decode('utf-8')
    total = value + len(text)
    return total

def _УИζΝΧЗιеэЪноΕλΒш():
    value = 390553
    if 59 * 49 < 0:
        _dead_3532 = 821
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnnyOWQM8ocLLzmO3FyoOTQ90WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        368
        pass
    return total

def _ΥΗΝЭЫнэΡΧяΟЩДФκ():
    if False and True:
        764
        _dead_5581 = 53
        98
    value = 409303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BB/APWA77YQPLB+O5m6DbQoEwWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яσΖлφφвΧ():
    if len('') > 0:
        636
    value = 607093
    text = __import__('base64').b64decode('WE9QNmNnQ1k5Q1NNSTljd3BkaXQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7106 = 741
    return total

def _ΔЯθИΙΝсьОΝхДο():
    value = 987481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSrHfkYsz78wLiT0mAG0LQod1Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙχэτЩцΩАΞчξпЮыГ():
    value = 71563
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhX1YgFs+LsrDi71ynSINgE93D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДеζфюнχАхссη():
    value = 572730
    text = __import__('base64').b64decode('bHdBZ2dWNzQwMEx1eHBGc0lrb0w=').decode('utf-8')
    if 49 * 13 < 0:
        _dead_2761 = 762
        pass
        pass
    total = value + len(text)
    return total

def _МАщΟςΣδυ():
    if len('') > 0:
        pass
        754
        43
    value = 791522
    if False and True:
        _dead_2093 = 491
        pass
    text = __import__('base64').b64decode('aU8yVVQxU3lRM0l4RkhzX3JCSlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ВниυоΙэбθхяЫЙ():
    value = 700758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxWwWwQg+o8tbjjw/QeIJjc31E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мοΔФцκОу():
    value = 860755
    text = __import__('base64').b64decode('SWZLRWJiVXUyRUxVMmpzMU56VlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛМйλΗγΦΣнΠлеΕЙ():
    if 33 * 17 < 0:
        _dead_9638 = 35
    value = 792220
    text = __import__('base64').b64decode('eEJwU0ppdHhBV2JaMzZMMlVicXY=').decode('utf-8')
    if len('') > 0:
        616
        632
        _dead_3174 = 129
    total = value + len(text)
    return total

def _ВσеγрБλЮКμΩΘЬνΧв():
    value = 237841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwjJT0lo7K4iMFma4FPAIC8tyEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝечшκκΙЬщ():
    value = 403346
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRfiSEs7zJcuDweG3VuHFyYE43o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯδчбχθЫыЪоηυδЧΕу():
    if len('') > 0:
        997
        59
        pass
    value = 254210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgzlfHBvx6UTNlyy4XumIwkM7Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЖζМΥвΠΩΞКδН():
    value = 978475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3/8OHwf9PAaLR7w7w6ENx0+y20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗфХхΙΥЖДТ():
    value = 333923
    text = __import__('base64').b64decode('WUNDejZ6cHFwZ1R4cllmSmFqRFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ДБΕазАДЩэΚμΞпДо():
    value = 397080
    if 69 * 95 < 0:
        177
        pass
        _dead_5562 = 816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky3SS24U0LAgDjWQ5VuYZTd9yFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΦιμδЗλЩЕлбсΤя():
    value = 72690
    text = __import__('base64').b64decode('clRoa2prVlRZQlFpOFByTDRqME4=').decode('utf-8')
    if len('') > 0:
        651
        pass
        pass
    total = value + len(text)
    return total

def _ξДЭвябКЫ():
    if False and True:
        _dead_8599 = 394
        44
        pass
    value = 20215
    text = __import__('base64').b64decode('WEFjRmE2YXJQbVJUUTRHSkxpRlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _кЬеοьαΗЦ():
    value = 760950
    text = __import__('base64').b64decode('QXF6ck41dFBBZ0xfdmFTRHdGQnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΕрΚЖОЖχуο():
    if len('') > 0:
        _dead_2189 = 698
        pass
        pass
    value = 226895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBXJXmsXzooIEBvw0Q/CAAsoxkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 60 * 100 < 0:
        12
        13
    return total

def _ЭηццКВΤυΦΡ():
    value = 881662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxriTVYU0bEiKg6r0HTDO3Yasl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 93 * 99 < 0:
        pass
        _dead_7618 = 642
        757
    total = value + len(text)
    return total

def _хпцаωДЬяμυ():
    if 79 * 21 < 0:
        513
        192
    value = 496928
    if False and True:
        _dead_2524 = 353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB3nXn0t0qcqOF/72AHJLiwBzV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΗΚΗиюΙΗΒДΞна():
    if 56 * 2 < 0:
        _dead_7493 = 482
        331
    value = 155988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAHBTQM8rKsHHwCizX2fEAx9vF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_2962 = 397
    total = value + len(text)
    return total

def _φΞыγыОГУκы():
    value = 562045
    text = __import__('base64').b64decode('ckZSU0J2ODNKeFN5ZGdWVkNUeG4=').decode('utf-8')
    total = value + len(text)
    return total

def _нРρСΔрАχщХЧРЪ():
    value = 164369
    text = __import__('base64').b64decode('WHlmUUV1U3VsUmE3WDVfTExQU0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟАΑενнАΘμЙЖ():
    if 16 * 75 < 0:
        pass
    value = 640602
    text = __import__('base64').b64decode('QmtsYzRxTU1pZzlONGpNS1dxNEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕγьвоθαцПЮπСИбΖЛ():
    value = 621662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EATrOQgUxKklKhWvmGSlByQu/G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        13
        pass
    return total

def _πПνКПОйЧγτБэЬα():
    value = 52776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh/oP0MBy5sVDQ736ni3PXQi7Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШγΗφτβπЫЧψ():
    value = 694599
    text = __import__('base64').b64decode('cjVMYkRLT01NWlk4QVJCWWpubzg=').decode('utf-8')
    total = value + len(text)
    return total

def _еЫъΟЬйбΣΔςЕ():
    value = 835544
    text = __import__('base64').b64decode('T2diNXc3MEZKNUhneWZHT1FFNWg=').decode('utf-8')
    if 97 * 80 < 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЫρЫχРЙУσ():
    value = 803022
    text = __import__('base64').b64decode('YXZwYTk3NFBXTXBmcnI4SFpvOWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧββУСПщΝνλЙлΜТп():
    value = 549209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQHSfEA78ocCFA6ZxnWcGC8lwXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1603 = 961
        pass
        _dead_8914 = 864
    total = value + len(text)
    return total

def _рпЮэβκЭуΛΤΨκοф():
    value = 965584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3vgSFQIq5EyNByJ7luhZDJ2wDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηψЪηιдЧμμζβЮЩО():
    value = 201809
    text = __import__('base64').b64decode('QWNCQzlaZzJBdDFEekR4RmJaWWY=').decode('utf-8')
    total = value + len(text)
    return total

def _жЬФвΥΣςκдξеΑθα():
    value = 750313
    text = __import__('base64').b64decode('RmJzWGlhZlhtVFFhQkJvSnkxVl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚσнЯЬαщшΣ():
    if len('') > 0:
        308
        pass
        pass
    value = 710009
    text = __import__('base64').b64decode('YTVJVVNvTlZpUDRPMUd4WnNPb0c=').decode('utf-8')
    total = value + len(text)
    return total

def _нФЮпΥλΣяΒГвνθВκκ():
    if 81 * 38 < 0:
        959
    value = 777349
    if False and True:
        _dead_9383 = 146
        262
    text = __import__('base64').b64decode('WmRwTkppYUdUM3ExbmNwRzU4REU=').decode('utf-8')
    total = value + len(text)
    return total

def _наΞЕφΥεрΡщЯμψ():
    if len('') > 0:
        857
        501
    value = 673666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHbPQAQ/7vtWCQSq8luvIyYuyVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        892
        736
    total = value + len(text)
    return total

def _ИлΥдΘΞςКзЪΑρΖЙКз():
    if 61 * 12 < 0:
        678
        _dead_1592 = 420
        _dead_1427 = 13
    value = 20657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXzTb0cO56E1CCW1yWSWIhQYvWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨςвΞχΒгшβио():
    value = 907777
    if 76 * 100 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDbWf3oq249UMiCE3V2RJiQj0j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηρЩэЯπЕЦзНЩ():
    if False and True:
        pass
        _dead_7825 = 112
    value = 656183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx3mSlJu96EsMgKLxGO6PgMDsUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9682 = 748
    total = value + len(text)
    if len('') > 0:
        975
        pass
    return total

def _йωΜкΡΜЮΛЭΓеΚΔ():
    if len('') > 0:
        _dead_8673 = 318
        878
    value = 205408
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnbBPGVo9KI2ETCK7l6ELAg1yjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕτкΣзιпχυξбе():
    value = 832267
    text = __import__('base64').b64decode('WVA3Z3luRDlhdXUzU0ZXcXZUQ1M=').decode('utf-8')
    total = value + len(text)
    return total

def _κПδΙяЪΚΥΩο():
    value = 968176
    text = __import__('base64').b64decode('YWl0RTRkYlZvOUZVNWlCaUsyMTA=').decode('utf-8')
    total = value + len(text)
    return total

def _уьнаκэпиωЮмфΓΛ():
    value = 516448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAjmXgI0rakgMSSRxgakPTAd8HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 20 * 58 < 0:
        pass
        44
        pass
    return total

def _цлΑЮωΙЫлБмηхиЙ():
    value = 113340
    text = __import__('base64').b64decode('SWRTbmViOG5lSk9MQWZabkdVcXQ=').decode('utf-8')
    if len('') > 0:
        397
        _dead_2744 = 824
    total = value + len(text)
    if False and True:
        _dead_6696 = 951
        319
    return total

def _ЕъиΚΥРκДβΨΜбнщ():
    value = 822356
    if False and True:
        _dead_4191 = 773
        _dead_4378 = 308
    text = __import__('base64').b64decode('RnZYdTlRT3FZcVk5RjhYVEs4emI=').decode('utf-8')
    total = value + len(text)
    if 69 * 72 < 0:
        973
    return total

def _РЪβΕЙтΚяΨсБэ():
    if len('') > 0:
        936
        pass
        pass
    value = 196584
    text = __import__('base64').b64decode('azhFMzdXZHVtNzB4M1A1ZXcxUHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚъСлΨΥχПтД():
    value = 575954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISLcNlI41qMaAA7y2G+yJBV4s2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜыЭЕцЭΝц():
    if False and True:
        101
    value = 909709
    text = __import__('base64').b64decode('Tm1UYUFTMHhDMndWUV9yX25ZYUo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        755
        _dead_7057 = 649
    return total

def _κκΧυТеΗУ():
    value = 131192
    text = __import__('base64').b64decode('UkdYVTh4YnZ4OUJnWENNa2hKdjU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7767 = 933
        495
    return total

def _πζςоγщΘиЛΗщ():
    if 91 * 54 < 0:
        15
        _dead_2300 = 797
        680
    value = 987848
    text = __import__('base64').b64decode('WHNZNU5sZU1KMUgzMmxUaG9PVTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ιоβФЙΟΠЕГК():
    if 30 * 52 < 0:
        846
        pass
        217
    value = 732003
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDXxa14c1ZwLBSO0/VuxZHwp8n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηпθΝЛЧзЕогхБοъ():
    if 12 * 52 < 0:
        _dead_7373 = 97
        959
    value = 17226
    if 27 * 54 < 0:
        _dead_3906 = 314
        636
    text = __import__('base64').b64decode('aXd0TnRXRlFTVkttMHFPOGttd1E=').decode('utf-8')
    if len('') > 0:
        pass
        137
        435
    total = value + len(text)
    if 1 * 73 < 0:
        pass
        949
    return total

def _ρΗθъвОΟΒф():
    value = 812989
    if len('') > 0:
        464
        pass
        799
    text = __import__('base64').b64decode('dUVoQnZzYUxGVU5rUlE4NWQzazk=').decode('utf-8')
    total = value + len(text)
    return total

def _щцΨΕФНЩпыНЕхЯΟЭΞ():
    value = 492937
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQnBOlAtrKFSIxyg61OnFyM84Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЫдИЕπξρру():
    if False and True:
        _dead_6342 = 329
        _dead_9377 = 443
        _dead_4242 = 887
    value = 576493
    text = __import__('base64').b64decode('ZlJJVk1Yc0Rrd0VUTFlIQ3FBbnY=').decode('utf-8')
    if False and True:
        _dead_5297 = 656
    total = value + len(text)
    return total

def _λαзТгΒГчй():
    value = 92336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3reWmBq0fFTFR2E4GaiIiA9yFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        707
    total = value + len(text)
    return total

def _шДΕΜЕЬбЧξΚΟуН():
    value = 579315
    text = __import__('base64').b64decode('eFdGUTZOYmgyNGpobmlrc1dXNG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('dA==').decode('utf-8'))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 75 * 68 < 0:
    _dead_5264 = 774