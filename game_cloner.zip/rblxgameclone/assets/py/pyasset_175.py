#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _χΦчσрΓжЩГωνΟΠ():
    value = 234184
    if len('') > 0:
        _dead_9433 = 576
        _dead_9133 = 28
    text = __import__('base64').b64decode('TTVkXzBrZ045UUNPcDh6ekJ4M1Y=').decode('utf-8')
    total = value + len(text)
    if 87 * 80 < 0:
        _dead_3572 = 694
    return total

def _ьБщЪυХлαΒйψн():
    value = 96089
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSe3QWAL9f8rHCKkzm6eB3J38Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮтΠζоЩκДйαмΑοвΟ():
    value = 190671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwzPXWtg6Z8lDx+C7G6nY3AcwTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΦΡυφчэЫбΘΖα():
    if False and True:
        805
    value = 237494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgzhbEs7pooQDCCx8WDHNhout0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 84 * 99 < 0:
        821
    total = value + len(text)
    if False and True:
        131
    return total

def _ΖьΚыгμΒοЖйЪХχλκΗ():
    value = 864487
    text = __import__('base64').b64decode('ZFkzMGVpTTFlMjFodjNLUWRlTzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΨцвчΦΚбΞоЩ():
    value = 834255
    text = __import__('base64').b64decode('U1RvbjhOTlFtV1RSWmZBaDBNSTc=').decode('utf-8')
    total = value + len(text)
    return total

def _υγюРЮЩιΒοΘХХΨ():
    value = 648856
    if False and True:
        100
        pass
        pass
    text = __import__('base64').b64decode('b215VUVaU3MzRVp5ZXZDRGp6MVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑТκΒΔАЬΚыЪΡγΜЭме():
    value = 124646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBizbEYs+YEvEDWO0XGDbSEs1Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5988 = 867
        _dead_4514 = 257
        pass
    total = value + len(text)
    if 89 * 99 < 0:
        _dead_5148 = 5
        pass
    return total

def _ДΜсνхшχεрΓΒ():
    value = 714373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgrvYncL76QkAAy6mXy0Inc63jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОБвκмЭмрбь():
    value = 173011
    text = __import__('base64').b64decode('WWl1YmRJQkNTbEEzSzBvT1B1VXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠγλсЕΘωШЮηс():
    value = 455019
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cx/cRWdr7KY2aCTz2mSjGiQ18UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ыпФГпψΞзθΒ():
    value = 989419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCnxPEZr+oQlDj6N8nqHYiQryXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υЪορΧЛοЖоχлЪν():
    value = 117533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXzJQFIB1ZoJKQai/lKDOwAozn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΓхΕΧЕυИЧ():
    value = 90973
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Diy2aGcJ+5EoEV3z/XCbYisgyFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИЦγевηΣΠйзΦΣζΣ():
    value = 696976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag7cbQQ+5rEIaB7y/XnDPQIC6EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 74 * 86 < 0:
        643
        _dead_4949 = 482
        713
    return total

def _ΠыГоЫδгВτΣν():
    value = 188240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjvHbX84//BSG16UnEXFJiwX6Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣеυХпйСТЪ():
    value = 741427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx3AYEUp7fFUCQSawmeJYgI6wz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κЦЦьыЩХфμμаτΟ():
    value = 390974
    text = __import__('base64').b64decode('emlNMXhYcko3T3lhdGpIRVFRYXU=').decode('utf-8')
    if False and True:
        971
        304
        859
    total = value + len(text)
    return total

def _χφΤУβЕΡА():
    value = 307670
    if 49 * 16 < 0:
        _dead_7980 = 426
    text = __import__('base64').b64decode('a3UzM04wa3FxRFlFcXVEc1Rrbl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ψъЗωνεтЦаνЪН():
    value = 571355
    text = __import__('base64').b64decode('aUJkM2ZYd1dqOURoMGJKZXRWWGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _МОЦσэхΟоиирцφпея():
    if 46 * 81 < 0:
        _dead_6869 = 276
        _dead_4161 = 854
        _dead_2634 = 226
    value = 196596
    text = __import__('base64').b64decode('VmhrRVhKODV5T2lkRmN6T3Rra1g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        901
        _dead_4497 = 15
    return total

def _ΘωяτΩЭΥтξΒсΦ():
    value = 108116
    text = __import__('base64').b64decode('bXhxSTAwRG5YdklfSGxWSGczQzA=').decode('utf-8')
    total = value + len(text)
    return total

def _гΑВΨХφНЖχρκΚΖЬ():
    value = 966481
    text = __import__('base64').b64decode('eDJ1Z3hDMW9MZV8wVHlNNEgzNGI=').decode('utf-8')
    total = value + len(text)
    return total

def _БвБВщΒΓρΦюЫа():
    value = 156428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTq2a14b2pIoNiT720GGY3c24z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Сεμбхъζβоць():
    if 86 * 74 < 0:
        548
        pass
    value = 95284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATvwWWsc95wwMi2q7WazBioty3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θеОУΛмυΣ():
    value = 442606
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAq3PlAzzLwsPB6Q6l+nESIB/VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δулΨйωЦИН():
    value = 243940
    if len('') > 0:
        pass
        273
    text = __import__('base64').b64decode('dnMydzBkNUoyQ1JJbE1JMHhwRm4=').decode('utf-8')
    if 34 * 66 < 0:
        _dead_7797 = 595
        530
    total = value + len(text)
    return total

def _еΠυешχымΔчцРФЧΒν():
    if False and True:
        _dead_9923 = 804
        _dead_1664 = 310
    value = 363526
    text = __import__('base64').b64decode('S1FEVEE5TGN5aDhUdVRwemhTVFQ=').decode('utf-8')
    if 39 * 25 < 0:
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _эПкъОΩДчΞ():
    value = 252172
    if 21 * 39 < 0:
        _dead_8315 = 228
        879
    text = __import__('base64').b64decode('VWNRenBZWjFkWmU4MnJHdWhEbzE=').decode('utf-8')
    if len('') > 0:
        _dead_4190 = 479
        _dead_5610 = 851
        _dead_4367 = 492
    total = value + len(text)
    if 49 * 59 < 0:
        pass
    return total

def _ΚζΩτБыΤΑΟцТΖΣИ():
    value = 85325
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzXleAY82KEQLAOLxQbGYRAXwTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мωЪΩΟйΡХКωΩЙоЮ():
    value = 372423
    if len('') > 0:
        560
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRrcSEYvxKQEHhag/VOAZyg9/T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 82 * 7 < 0:
        44
        pass
    total = value + len(text)
    return total

def _υиЧΙζμтыπΥИηςмε():
    value = 761172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQK1SV0cq4wwF1+6xViAOQgYz0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 1 * 4 < 0:
        pass
        _dead_6987 = 220
    total = value + len(text)
    return total

def _УΩхБрыВΒМЯεеъПи():
    if 9 * 55 < 0:
        _dead_7942 = 590
        pass
        pass
    value = 240566
    text = __import__('base64').b64decode('dFVkSkl4QndNTGhoc3UxNzVRZU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖρНΧсαРъМχΛчМ():
    value = 733837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQHyWQAz15giBQK55HinZRMMvTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΜΦФΙγσμР():
    value = 837268
    text = __import__('base64').b64decode('RFU3OUNzZFNVbjU2enpnbExyWjI=').decode('utf-8')
    total = value + len(text)
    return total

def _φХΝθлΣарчωψщА():
    value = 903994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgnVPnIO27koIzm3kX66PTUt0T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_2950 = 726
        pass
    return total

def _ЕжνΤшΔъΖЫхУЬ():
    value = 902905
    if 67 * 30 < 0:
        557
        357
        _dead_4725 = 995
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwXoPVQG9b4EYxWHylq4FTYJ7jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _знςΙΞαΕβ():
    value = 140341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQa8PQEa8L5VDQSHzH2CPi124Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓКΛпУξБЧΤνу():
    value = 496205
    text = __import__('base64').b64decode('VkoyRjFkcVhMdHZoc0dBTnl3R1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΦМнНδеω():
    value = 20031
    if False and True:
        489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA7LXGQu2pIRHFuF+HiiOnMj214='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        710
        464
    return total

def _гΖЗΕЙμυΧЭσ():
    value = 796410
    if 12 * 8 < 0:
        821
        _dead_3896 = 258
    text = __import__('base64').b64decode('WGgyVXNDRzFRWWd3SnFNdHdsQVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦθгυρηπσςАЮвР():
    if False and True:
        _dead_5040 = 826
        _dead_5197 = 538
    value = 725015
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAzBPwFp7oMGbAib0nmkDh0u4GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓωΥВΛΣΖСсжшЕΘя():
    if 23 * 11 < 0:
        _dead_3470 = 985
        375
    value = 165757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn/MY3QT8oUmbx7wnXC5Ew4ZyUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йшПгэвΝш():
    value = 967787
    text = __import__('base64').b64decode('dlZNMzd5QnZET1R1RmFkcEVETzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΙЫзттфЪГтЖμΜΝμο():
    value = 854114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgPIO2sh+4sPPSWX40KEBAN84mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡεШΧьГлψьЮЕπΝлюф():
    value = 610015
    if len('') > 0:
        _dead_7006 = 589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR/UQX8b/4sWNleg+nigGx0cw2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6307 = 292
        pass
        pass
    return total

def _ЛлΔψЕγβΡΟαξтςФ():
    value = 766797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASexfUcy16EJKji65nrCYiYH/n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФωΤТΘыΛωТоχфс():
    value = 36052
    text = __import__('base64').b64decode('dkYxSzN6VVdzVjRDTXk3WDFGTXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΑΩεяθΧМιБюπ():
    value = 5175
    text = __import__('base64').b64decode('UVBiejV4QUxFb1JjWEttTVFwckg=').decode('utf-8')
    total = value + len(text)
    if 78 * 29 < 0:
        _dead_8766 = 219
    return total

def _ρыЯθМψηФΩΦ():
    value = 462034
    text = __import__('base64').b64decode('ZUFBclVsNGFXV2tUZjFyZ1lMRXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ШτΤαощрВτь():
    if len('') > 0:
        pass
    value = 95728
    if 4 * 81 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn3GfnAoqrtTNB2Pwl7EEB1942w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        635
    total = value + len(text)
    return total

def _ξяуΝζжμЭЦМγξчжαК():
    value = 939159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fi3df1Y96rEtMgap8kfJERR+w2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лРЭпрЖλΔλΞΛс():
    value = 176965
    if len('') > 0:
        _dead_6596 = 665
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxXGRlkt5IMOGBWz+0LFPjQX4Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4948 = 550
        369
        _dead_8212 = 106
    return total

def _ПокЛφοмчиζШΜжЦ():
    value = 381839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EinxdgAB8Y0ZNh252mCEFS0/tG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Βщοхдωдк():
    value = 921446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCPteHs26rsnKQiX2wGiBzUc00M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΟΗιХωлΤ():
    value = 258301
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTzAP1QtrP01I1ecxXDEB3U+1H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΒΦЛψМΠΖЭи():
    value = 769331
    if 55 * 99 < 0:
        _dead_6927 = 960
        pass
    text = __import__('base64').b64decode('ZjZFUnQxYzJCdlpnZ1lSVXFmSmo=').decode('utf-8')
    total = value + len(text)
    return total

def _ФЖψВΨδΝξ():
    value = 549930
    text = __import__('base64').b64decode('TWIwOERqRmVJbVVNYXlpRTdOUmU=').decode('utf-8')
    total = value + len(text)
    return total

def _тΥУζςзοфθЙμшει():
    value = 403368
    text = __import__('base64').b64decode('YUVGTUEyTHl3Nk1OVDF0QUpXUkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ТЙΖтнΓдπχΗ():
    if 75 * 45 < 0:
        _dead_2113 = 794
        pass
    value = 51573
    if False and True:
        pass
    text = __import__('base64').b64decode('cE8yeXpRbG9NaVpXMVl0S0Z5RUY=').decode('utf-8')
    if 26 * 39 < 0:
        _dead_7548 = 848
        pass
        _dead_6300 = 691
    total = value + len(text)
    return total

def _еΡчΚθςгфΩω():
    value = 674349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fia0TFgAr6ZaCjWAmnu8AAEbtEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дфГбλΨЕХФλ():
    value = 492394
    text = __import__('base64').b64decode('QmRLRGdoTTV2YnpEcTVrSGtjVWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΡΡВылΩрКδΗЭξ():
    if False and True:
        pass
        637
    value = 406777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzbVQUgUwa4gYjmz+ELAIi8C0XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 71 * 19 < 0:
        _dead_3765 = 847
    return total

def _ДПЙΨЙРμΒφкьςλξ():
    if len('') > 0:
        pass
        _dead_3548 = 483
    value = 215668
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhD1dmEM9ocEagi63Xm1PjUp218='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        639
        _dead_4187 = 49
    total = value + len(text)
    return total

def _ывЙсΩЯоАХЖагΘιΒσ():
    value = 824068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSTUPHlg85oFaC30n3vCDjEtsk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖЦВθоЮЩζβμчГъ():
    if 84 * 41 < 0:
        966
        pass
    value = 611659
    if False and True:
        632
        839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCPRNwIJzJA2YhuAwGKzDAYJ4jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нърЙνσФΔвьσыСЙ():
    if 63 * 84 < 0:
        920
        67
    value = 939987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxvhQ2kK9Pk1AFeow3XCGhV760o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζзθρПΚяФэМ():
    value = 499129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwHFYmdg+IsFLjCnxU+nPiEV/F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ογГζΗОΙЛЩь():
    value = 597225
    text = __import__('base64').b64decode('U3RycUFoblg1dkw3WVZ3UDBYMFA=').decode('utf-8')
    total = value + len(text)
    return total

def _гяβосЗξБа():
    if 95 * 76 < 0:
        _dead_9986 = 48
        pass
        pass
    value = 261272
    if len('') > 0:
        _dead_7841 = 568
        _dead_1380 = 757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CD/SeFw37b0VDS2zwHGeLScp9Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФεΦЭтцОи():
    value = 266000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Any3egUO270PHyfywGSAIAkjsEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 31 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ОоΦΗΓхЗζНΦ():
    value = 847877
    text = __import__('base64').b64decode('ZENHZ3hNXzBYZWFPOXRKcTNwVUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔυΤτШυълιЦПξЯ():
    if False and True:
        _dead_3895 = 500
    value = 223240
    text = __import__('base64').b64decode('UWRRWVVMNVhuTkdMbmdjZ3RNd3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗБмΦюΞΗзУ():
    if 9 * 10 < 0:
        78
    value = 576307
    if 17 * 17 < 0:
        pass
        963
    text = __import__('base64').b64decode('ZkxRM2FQb0ZzeEZEVVJXOXhQbng=').decode('utf-8')
    if False and True:
        _dead_1533 = 312
        pass
    total = value + len(text)
    if False and True:
        357
        _dead_1843 = 319
        pass
    return total

def _ςфОДΕωΛΙщτъΚ():
    if len('') > 0:
        _dead_9691 = 850
    value = 969417
    if len('') > 0:
        _dead_7556 = 864
        503
    text = __import__('base64').b64decode('VHJrQUNJcTZOdFVBdlVEX1BnUk8=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _АΩαПБуСΨπэ():
    value = 130823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgrMPEA+0LBaKxv17UaiEQsExWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΜΝνΧЙΣфЛ():
    value = 389456
    text = __import__('base64').b64decode('Tklib1h1ZVJDS1dDbk5rZElhZVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ТψвфΤЧοΤΛЪавЭб():
    if False and True:
        813
    value = 541663
    if False and True:
        263
        _dead_6544 = 223
    text = __import__('base64').b64decode('TmQ1WXJjVGxmMFZCUU93ek90ME4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤъыΧξτютхΠойΤρ():
    value = 576657
    text = __import__('base64').b64decode('dEJ6M0RXQ3djaVlZZU1XSnZEckk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_6016 = 271
    return total

def _λШЬеаτпτдееΙШ():
    value = 790643
    text = __import__('base64').b64decode('R0xpSXJlRlVyNjF2MldiX2FFNTY=').decode('utf-8')
    total = value + len(text)
    return total

def _гЖΕЗФζΜСΛ():
    if 12 * 10 < 0:
        216
        505
        _dead_1060 = 187
    value = 19377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT7Hd1Q4+Iw6aia20lSxOw0d/UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΧεоотвэиΨр():
    value = 798264
    text = __import__('base64').b64decode('U21ZUVRtNU9TX214ZEp4dFMxclE=').decode('utf-8')
    total = value + len(text)
    return total

def _γΖйуΩοΦЕ():
    if len('') > 0:
        _dead_9731 = 895
        858
        _dead_2612 = 786
    value = 984103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Chi9dHUG94A1Khuy92fCEhYn8Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        478
        212
        329
    total = value + len(text)
    return total

def _οчШЕяΕΘяпкμШΓξλ():
    value = 376493
    text = __import__('base64').b64decode('dXJtcU81YWtUUFA1VE5qenB1MHg=').decode('utf-8')
    total = value + len(text)
    return total

def _νξюБγэΓΟΨ():
    value = 111037
    text = __import__('base64').b64decode('cDNyZGkwclFod3RfSDV0M2ZQQ1E=').decode('utf-8')
    total = value + len(text)
    return total

def _БСΡЬΩхΕβσа():
    value = 761981
    text = __import__('base64').b64decode('QkZpVGtzcHBWdjR1OE8zMEl4aHY=').decode('utf-8')
    total = value + len(text)
    return total

def _βИщБψεΝЗ():
    value = 964999
    text = __import__('base64').b64decode('RHg4WEFWY284WTBZcGJfRWVfTEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓШΑΗщΨБλψΣх():
    value = 714825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwayV2M/xrsAaReimWyqAiA63GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΒРЖцφμηΝΔηΛθНцР():
    value = 725526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhDtaXk90pwIPhuZ73+HAx05sEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЛрΑΓВοбЦΦ():
    value = 256264
    if len('') > 0:
        519
        pass
    text = __import__('base64').b64decode('TjROMVN4bV91ZWdxeDlqSm5WQWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕрιЙЯЗафОЮунηФФю():
    value = 38006
    if 99 * 38 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F361bWIPqYYLPg6y41+TIHANvEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 33 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _очтшчэοЮΗ():
    value = 463100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHjLZUMxrYACPgT05wObJhIMz2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΗΟςσΩЕХЙ():
    if False and True:
        _dead_7814 = 678
    value = 481571
    if 7 * 4 < 0:
        _dead_1735 = 516
        pass
        _dead_9821 = 451
    text = __import__('base64').b64decode('UnRXSlVwcXNBYVNLQ2x1OU00T0I=').decode('utf-8')
    if False and True:
        979
        _dead_3522 = 423
        321
    total = value + len(text)
    return total

def _ЖΩδΑπΘчнУ():
    value = 545517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Anj2dgcowYEkACCr3nWnNQsg8zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΠχЫРлχНγι():
    value = 762466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3fsawYU2rEvD1iL7X6/PjJ6wDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9723 = 362
    total = value + len(text)
    if False and True:
        _dead_9234 = 225
        pass
        955
    return total

def _αФБρЫяЪщ():
    value = 645193
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX3OPG5u9qM0CwmB+nimZQ88sG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        896
        pass
        142
    total = value + len(text)
    return total

def _ΘОμЮшμЪичтвХх():
    value = 31925
    text = __import__('base64').b64decode('SERYOU1TR0Zzbmg1V1pGUklOeUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦшъΝОэЩυΤ():
    value = 530054
    text = __import__('base64').b64decode('YjJTYThkbkNxb25UanB5eFlUVVA=').decode('utf-8')
    total = value + len(text)
    return total

def _зΤДилΕиЫаэСХХИ():
    if False and True:
        _dead_9414 = 839
    value = 327624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT7dOwIM7f0RLV2k2GbDAAYo/m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОεΙсеЪцΝινРΛεЪх():
    if len('') > 0:
        pass
        pass
        812
    value = 565915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxmyPUgr6aMJNBeMzwfAGHEmsEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 23 * 15 < 0:
        _dead_7083 = 572
        pass
    total = value + len(text)
    return total

def _мωΖэΜрмΟвэΛζ():
    value = 83801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ey20VkMh2KwFaluvnlmCZSkYtG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψθтюςγТч():
    value = 373785
    text = __import__('base64').b64decode('SXh0aHRpQ2tiSDBaRXpfajdock0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        70
    return total

def _υЗσΛсτДηΞРλα():
    value = 563603
    if len('') > 0:
        pass
        pass
        808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FB3OaWYc9PlTMwaQ0l2VHyka/VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δςΒТхИΟюКμΧΡЗΩФΞ():
    value = 962008
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzvxYHQGqIUZECWZ2FTCDT15z20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХыιЦУЬξΡО():
    value = 687514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCL+Y0MrrasaAgqKmlzCPR8Y7zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΜиΤΡЦЮКЗ():
    value = 84989
    if 54 * 48 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NynCPQc46pkQAl76/A6nGhIp5n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3598 = 950
    total = value + len(text)
    if len('') > 0:
        12
    return total

def _КυμДΤΣБЯоНΧυ():
    value = 126664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB7lZQEsyrtbaSal60CkEyAf8mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙВЪгοадыγСχγ():
    value = 778338
    text = __import__('base64').b64decode('WGU0cjdJQVl3RzRBMnhXUEZ6bFk=').decode('utf-8')
    total = value + len(text)
    return total

def _σΡМΠгΛδΝуΓΖΙт():
    if 33 * 86 < 0:
        _dead_1251 = 725
        567
    value = 26422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAPqY2Uy8qYoKBe5y1WSZzUL8kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юΦδΖщлσыщβπψΝь():
    value = 623341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCXLTV4f//gPMA2Ewlu/IBx86nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝγОяιμΕщб():
    if len('') > 0:
        971
    value = 210117
    text = __import__('base64').b64decode('TkVKQWpOQXNVVk5vX2l2ZktyeDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _НφΒθχΤщωπАζУЪОΖф():
    value = 888242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgzFXHQv+roiDzCF7H+gHD8gzVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        635
        _dead_4733 = 847
    return total

def _ΞΛцСуйρщДьДжщчъ():
    if len('') > 0:
        _dead_7795 = 339
        321
    value = 521763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CADbQUkMyaYQAwSq/WSaLQoh8lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _онМеηАвДυелЩ():
    value = 507384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHuxPmho3PA8Gz2L7nihHiEu9Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        640
    return total

def _уΣЮλиπгюцГьс():
    value = 267930
    text = __import__('base64').b64decode('ZTVKX2NIalRTelRNblZ1YnpFaDU=').decode('utf-8')
    total = value + len(text)
    return total

def _хαщЯЭλжωΝο():
    value = 130229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwqzaWEw/aQECD/7w3KJMiIh6D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЖρиОλΠζΩфбИψВΤ():
    value = 138110
    if False and True:
        pass
    text = __import__('base64').b64decode('aXI2dXpzYXoxQ3drV2RteXpxcjU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8418 = 40
    return total

def _еЙыΟΛЦзМ():
    value = 4828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnbLPXJs7LwoND61xWzENyp+0l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φЦКпαШΓΙбΔΨ():
    if 48 * 49 < 0:
        556
    value = 871161
    if 88 * 34 < 0:
        _dead_4209 = 795
        pass
        298
    text = __import__('base64').b64decode('eTYwaFkzZ2pTWDdZWmNGSkFJN3M=').decode('utf-8')
    total = value + len(text)
    return total

def _αЙЙφцВЖГдупьф():
    value = 160753
    if len('') > 0:
        922
        pass
        924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCi2SAUL9pdQA1ezy0+eZQgVzFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4741 = 24
    return total

def _ωЮщαΗЮДж():
    value = 140021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxvsRn03rvgiGSaswEG7JRQt/l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЗЙΥсωУШаΥ():
    value = 670772
    text = __import__('base64').b64decode('RXNkRzV2QXpNbEk4QWtGMlcyd1M=').decode('utf-8')
    if 17 * 9 < 0:
        137
    total = value + len(text)
    return total

def _ιηоЪБРζΔВфαПЮΗ():
    if 23 * 4 < 0:
        pass
        971
        _dead_9966 = 25
    value = 328775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyjoeFg+8K46NiSL61KCBiB+0zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4335 = 229
        333
    total = value + len(text)
    return total

def _ΒΖлуЭαяаσΕ():
    value = 791812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MifcfUY36Y4AOwycwHSqY3A5tF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψиΡэЪщкω():
    value = 954063
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ki7uWHIT+rtXADyvzWydGDIY/lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        884
        988
    return total

def _шъвфйЯРЪ():
    if 59 * 2 < 0:
        806
        _dead_1110 = 265
        pass
    value = 78859
    if 38 * 72 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnbqbQgu7/omOxiz7n64Nycn9Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΚΔγΥαΧЯιΨ():
    value = 866624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXjbT1Ua57IwOFqt5FyaMgo89mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЦЫγщπГχξыΧЛον():
    value = 184033
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDjHQ0Vs0b1Qahvw+3CqMAA46Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чυЧЫУΕкЪЮЫ():
    value = 622667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSHDOVZv9PwLKg3191vBMQ0p4kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γгеНθΑξШΑкХ():
    value = 433443
    if False and True:
        521
        119
    text = __import__('base64').b64decode('b0hHbksycGhoSEoyMlplWGExQWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЕАΞΖШΖωпщ():
    value = 100771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dw3gOQA8rPk7bjmh4l2cLiocwks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΥКмΒооΤэйюЗσ():
    value = 541571
    text = __import__('base64').b64decode('WnN2MW9WMkNuNzF6TTRaZUNHSFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΡМοЩΒμвΨЦЬШΔЛа():
    value = 316268
    if False and True:
        _dead_3469 = 607
    text = __import__('base64').b64decode('Wk5SZk1iaHFsbm0xQ1ptX09QcUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚХςΒμбщГиπДв():
    value = 561588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nxr8OVQ/zos2PAq6zneDF3wq5kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΕУрεЭνеЯСЩщ():
    if 19 * 99 < 0:
        211
        pass
        _dead_9245 = 714
    value = 360552
    if False and True:
        301
        555
        pass
    text = __import__('base64').b64decode('Uk0yNFNCaXoyMmtNMDlTZ0JPdzA=').decode('utf-8')
    total = value + len(text)
    return total

def _фзΥйΓдψИКз():
    value = 202932
    text = __import__('base64').b64decode('SUg3RmVIX2NXTVM1RG85MDNrUHU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5680 = 258
        635
        pass
    return total

def _шАХΕЬπαΟАΛ():
    value = 31267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjjHT0cWy6kUHw6U2w66Bgw18Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        432
        _dead_6769 = 925
    return total

def _αююνыλзΓЗΩфПт():
    value = 385607
    text = __import__('base64').b64decode('VzQzeUFFYkJFX09FWUxBcjJJSWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΖφΡЬЩЮΛдМ():
    value = 683071
    if len('') > 0:
        330
        _dead_6502 = 74
        851
    text = __import__('base64').b64decode('UEVXUlpOcThsWnEyUG5UQjhNeGc=').decode('utf-8')
    if False and True:
        _dead_1805 = 713
        pass
        pass
    total = value + len(text)
    return total

def _ΓСоφабшКЩλыΕ():
    value = 345068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnvHa2Q99L0FFAiA5H2JAwwf6jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕГЛоΥКξмΕХδθзХ():
    if len('') > 0:
        _dead_8154 = 510
        pass
    value = 144150
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('bG5pUHNGVmNjUVN3REdvcXFrdWw=').decode('utf-8')
    if 84 * 74 < 0:
        pass
        _dead_2314 = 569
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_5640 = 475
        _dead_8365 = 501
    return total

def _ΖЩшсХΒАПпХПюΕР():
    value = 855170
    text = __import__('base64').b64decode('STZESEN4QWFfUl90ZXpFcE56REM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣτАМΓЯΨЦσδωсα():
    value = 149268
    text = __import__('base64').b64decode('TzZjRjBXaVc5TUkzblZhQTY4T0g=').decode('utf-8')
    total = value + len(text)
    return total

def _йτжЧΝЖКЕΗξОы():
    value = 931840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PADSSQBs+7oTDQet+WKfZC12/Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БсτаМЯжаΣπцΥ():
    value = 932525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MifpfgMS+J9bDhyM0F60LXIp1H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        80
    total = value + len(text)
    return total

def _ИщбΡΒδΓУυΝн():
    value = 677015
    text = __import__('base64').b64decode('eU1VNUJuTmZFbXRkM3RUWk5uN0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚлоπЕΞΓОτеβЙ():
    value = 79275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyP0XkIK0oo8OQ6U/XWibSsm1n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚШчκβΜлжΛεБρ():
    value = 172180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwjnY3YtrIMOEw2u/mTIOz8HvGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лчθΣΝиХЧΕКоФЮВ():
    value = 170405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn7NWUls96oXKTe63FeDDC8q43Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΗαяδΚΕДщΒИщσ():
    value = 233163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3nQN2ER/4w0bia72VC0I3U352w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШБлЖЯБαШЦъς():
    value = 591959
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InqwfXIwzaMoawqa5X28YHUDzk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖсφьпΣбΝпν():
    value = 307969
    if 17 * 100 < 0:
        _dead_9820 = 395
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hzfub38Xp7oLMyS17Vu7DBIk0UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        602
        pass
        pass
    return total

def _шομСКОδхмΔ():
    if False and True:
        245
        692
        pass
    value = 927640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxXidngczb8sFij34FqGNXALtlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_6047 = 559
        398
    return total

def _ΟθАΙэСЙЪютУФγ():
    value = 150908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mzn3fVsQ8b8OaTy221mvLnZ6vGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΥχИМНΖεΔυζα():
    value = 633249
    if False and True:
        _dead_7981 = 406
    text = __import__('base64').b64decode('YmRPNjlBdXRNVFFYTGx4NXhwZ28=').decode('utf-8')
    if len('') > 0:
        417
        pass
        939
    total = value + len(text)
    return total

def _пΤαγэΔαКΜВ():
    value = 452769
    text = __import__('base64').b64decode('TWxZa2E3VEpYSHFIYWJSbmsydjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ρφЕбФσШκ():
    if False and True:
        214
    value = 263576
    if len('') > 0:
        22
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBnQOmRs/L9VaAaw2mSoACB3wEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        790
        _dead_2245 = 434
        _dead_7009 = 857
    total = value + len(text)
    return total

def _ΗζχИΒβнКЪКвθМτСй():
    value = 872667
    if False and True:
        _dead_2069 = 887
        _dead_8028 = 525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiHMaFos+5EXbFeo4n+AZTUnsjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 26 * 69 < 0:
        pass
        638
    total = value + len(text)
    return total

def _ШиехωгΠДДбз():
    value = 562623
    if 31 * 89 < 0:
        182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX3genYuqv5VLh6p4mCnNSgJyVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5652 = 335
    return total

def _хΨъоξμзвЪΛкεКеΧ():
    if 76 * 68 < 0:
        877
    value = 987448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ihr2RG4Lzq0zChew33ugMAE6xzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κеΜΩьяγΡЮ():
    if len('') > 0:
        180
        830
        131
    value = 474367
    if False and True:
        823
    text = __import__('base64').b64decode('WGV3ajRYQlJhRVhtQWFZR0xkcnA=').decode('utf-8')
    total = value + len(text)
    return total

def _кчлМБμцΤαΘО():
    value = 294690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHfqY0Ro9ZA1IAarxW+aMSQ+5jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΦΑшЭЛеΝреЮы():
    value = 924662
    text = __import__('base64').b64decode('akNxRXBwb09UUjF1dG5aQURRRWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ωуΚΠКТηтцμлзΟθμ():
    if 33 * 62 < 0:
        pass
        538
    value = 683514
    if 25 * 17 < 0:
        _dead_9866 = 540
        pass
        733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSu1PFgyyLkqDB6czmylYQwY8ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 65 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ЕξΦЗΙьψыιвΧяζГ():
    value = 670567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSHBdglhzaNaIwz12HKIOS0jyT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙйзΟΗΝζТКБТψΕоЪп():
    if len('') > 0:
        827
    value = 865097
    if len('') > 0:
        _dead_2263 = 53
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT7US0Aq2aQBDRr34kWIDCkgsEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        919
    total = value + len(text)
    return total

def _σЫΨΜыΠχЭРςΠ():
    value = 827868
    if 69 * 15 < 0:
        pass
        pass
    text = __import__('base64').b64decode('R1VOWEVJNTQ2RXlrbk5jNTBTTDY=').decode('utf-8')
    if 97 * 42 < 0:
        885
        pass
    total = value + len(text)
    if False and True:
        _dead_6621 = 10
        427
    return total

def _нхТεхэΔμτΜЖΡФжК():
    value = 94319
    if 47 * 96 < 0:
        247
        pass
        953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTjwWkgbxJEKEDeo63HEPAAf81g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 92 < 0:
        _dead_1963 = 623
        _dead_9519 = 142
    total = value + len(text)
    return total

def _аΧΝкΛьЬΤ():
    if 4 * 74 < 0:
        _dead_8682 = 377
        _dead_6376 = 921
    value = 300056
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR/hSmgayr8aGSqu3kW9MwcF9VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛФГοГΡψλъР():
    if False and True:
        718
        _dead_1922 = 215
        _dead_3363 = 155
    value = 112876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3vDSVgWp6wLPCqWy2WAYgsYsXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 49 * 42 < 0:
        _dead_2615 = 614
        _dead_5655 = 693
    return total

def _ыΔЭκдФΖЕДкΟ():
    value = 437594
    text = __import__('base64').b64decode('ZUN0bFVOMGZ3T0RvblRROVpub3E=').decode('utf-8')
    if 7 * 73 < 0:
        _dead_8342 = 363
    total = value + len(text)
    if 66 * 82 < 0:
        567
        _dead_5492 = 804
        _dead_7606 = 312
    return total

def _Гτвдαнбэ():
    value = 171209
    text = __import__('base64').b64decode('ejNfX09WXzNBWGx3VWJOcmVXckY=').decode('utf-8')
    total = value + len(text)
    return total

def _μНΧαдхБпρЛЦΨυΛж():
    value = 901626
    text = __import__('base64').b64decode('d0tob2psQTR4ZnEwUDVpOTZ0Zkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ωВΦыйшуλ():
    value = 938036
    text = __import__('base64').b64decode('SUFFWU1xQm1QaTI0c25xejdtNEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ψлβΦΠΔТиΥцΧУ():
    value = 645974
    text = __import__('base64').b64decode('ckV4TUpWdTRHX1VUYld1bGRZSUg=').decode('utf-8')
    total = value + len(text)
    return total

def _жпЦИУЧЦρ():
    value = 141525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT3AQmUcybIKHAGkmwLHOi08zX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пθаТηОцРХыηмμ():
    if 6 * 58 < 0:
        _dead_7291 = 315
        _dead_5736 = 65
    value = 390648
    text = __import__('base64').b64decode('SmJnYkN1ZDdWNzNjYV9EV3BCTGc=').decode('utf-8')
    total = value + len(text)
    return total

def _яυηвОφЕЭЭΛдъκΔО():
    value = 823964
    text = __import__('base64').b64decode('cXZsM2h1V3BKdXl4T1VlaVVudkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ПрΖЩьЛПτуφПγε():
    if len('') > 0:
        299
        _dead_1886 = 96
        pass
    value = 342071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCnGR3AWxLEmDlep31myLD0M1VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 23 * 48 < 0:
        pass
        _dead_8379 = 293
    total = value + len(text)
    return total

def _быдсБΚοйАιξтжуА():
    value = 364375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQHLSX4P/6IFLFysm1KFEho58EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λНΩςчΕξйРТΣоъэк():
    value = 254911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgDXe1Yc96EXaTX75XjDZBZ220c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αаκλаьπНТ():
    value = 659468
    text = __import__('base64').b64decode('QlJ2RzhaMUptVnQybFhwODdQOUQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7317 = 778
    return total

def _еойИтΚбф():
    value = 998195
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx3RSUgW8r5aDQSA6Q+JP3Ikwk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЛΒΒЛлΙΣΤοэ():
    value = 157666
    if len('') > 0:
        pass
        297
        _dead_4065 = 835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABXWZXgG2qwFb1+C93PCLXQfsmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1655 = 77
        135
        852
    total = value + len(text)
    if 70 * 83 < 0:
        _dead_9232 = 594
    return total

def _ΒЙнζуФеΚзξθаЖ():
    value = 775352
    text = __import__('base64').b64decode('dEdIejJIeWNmaTNlM0QzZl9fWGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚяλмюЭЙОРΩΝКРро():
    if len('') > 0:
        74
        pass
    value = 85491
    text = __import__('base64').b64decode('RDhZcDF2V0F1bTVTX0ZEaEtObzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _зьхΓыЛГΡЛШ():
    value = 310643
    text = __import__('base64').b64decode('bk9OMDZOaVJGc3JfS0hHc21ZSm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛкτΥВωдща():
    value = 606390
    text = __import__('base64').b64decode('eFVfTXdFTGdpZmRUNTRPWGlOcnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if 32 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()