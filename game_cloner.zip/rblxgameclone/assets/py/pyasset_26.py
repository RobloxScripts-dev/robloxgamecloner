#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _йрччещφεЖφ():
    if len('') > 0:
        _dead_2802 = 774
    value = 365271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCvQaggAq5gsCzmwmmSWGSYB/l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _εΟусΖΑУοеΩгχυ():
    value = 110933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDzNfgQ0rrECAgSx7mKAM3ID3mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5806 = 260
    total = value + len(text)
    return total

def _ζжΑУгςξκΜ():
    value = 867153
    text = __import__('base64').b64decode('Q3A2b3dOZUU0c05vcWNBdTJTdjY=').decode('utf-8')
    if 16 * 43 < 0:
        pass
        _dead_6214 = 693
    total = value + len(text)
    return total

def _ΡгфЧРΓиКИм():
    value = 310813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiHHa2c185JXIzu1/VPDC3A6s2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъВЩζюΕΠφγ():
    if len('') > 0:
        385
        _dead_6863 = 18
        _dead_2510 = 462
    value = 137657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgrVXXMtq4wzLT2qmVOII30G70o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςБбЩТζмъΝЯуВ():
    value = 52707
    text = __import__('base64').b64decode('S1JibWJ4QW45Wm13MFlVSUdOdEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖλЙРкэуъν():
    value = 318103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTfhQlANyZk2DVq1mnuKYQMG7Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5957 = 114
        _dead_5837 = 420
        _dead_8621 = 634
    total = value + len(text)
    return total

def _ΠяυЕЕψΨηЭ():
    value = 954066
    text = __import__('base64').b64decode('VXZrT2NhakNnZ1lZMUdXT1B6SmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΛΑЫΖшПЕΓ():
    value = 201490
    text = __import__('base64').b64decode('bk5SYmE5R2hwV1lBekgyZUF3Szk=').decode('utf-8')
    total = value + len(text)
    return total

def _θпΧΖЪрзВΔм():
    value = 107103
    text = __import__('base64').b64decode('ekNPQkRqazJFV2thWDVyV21nRk8=').decode('utf-8')
    total = value + len(text)
    return total

def _эχвγзкьЭδЛЯжκмЭ():
    if False and True:
        _dead_2234 = 585
        pass
        704
    value = 153488
    if 27 * 21 < 0:
        45
        388
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET7LZ0AQ2rIGM12q/liiZCEVzzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 40 * 9 < 0:
        pass
        _dead_8703 = 80
    return total

def _лэΡЗнЪйβИщшУττ():
    value = 735529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXnFeHwf0voxOBz14mecYTF8sWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΣБыυГжΚВнξχΟД():
    if 59 * 94 < 0:
        _dead_3555 = 549
    value = 775100
    text = __import__('base64').b64decode('UDlhc1J5MUVsXzNVQ3lSM3VNVVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘπΤЧЭТΖд():
    value = 994081
    text = __import__('base64').b64decode('Q0lYck5BUE4xZUpUNGU2RGZpdm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΚАФЙΖλЕдЛΑωыΔ():
    value = 845786
    if 43 * 18 < 0:
        _dead_6347 = 990
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LADRSkgqppA5FCr20k+gAwMj6Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уГвиЯλЭт():
    value = 747918
    text = __import__('base64').b64decode('SkM4RVlYbXk1NkdtV3hYMDRLYmo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜпзΟφαфСуцМЬνгЗ():
    value = 183473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTbLNlgdqPoCOTe6+nmTZQMH4zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΑεβαеоТмоΔΛ():
    value = 758592
    text = __import__('base64').b64decode('bXZwYlhJQ3B6bXlXMEUxY2p5Ymo=').decode('utf-8')
    total = value + len(text)
    return total

def _ыσΠКржιыΗ():
    value = 535352
    text = __import__('base64').b64decode('dUJxYUJxaXJwdWZjQVc0ZXRQVTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ХЬнΙФШФИςч():
    value = 132334
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHnsZ34xroASCieN4wTJEnI5t1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        484
    return total

def _ςбΝКзδРз():
    value = 305470
    text = __import__('base64').b64decode('RFg4ZEZjY0JTMml2dFdITjQ4Qk0=').decode('utf-8')
    if 25 * 51 < 0:
        894
        774
    total = value + len(text)
    return total

def _ΝцδΥσПЮΤΒЦ():
    value = 100245
    text = __import__('base64').b64decode('Y2RVN25HbFdWejV1ek9nWndFN2U=').decode('utf-8')
    total = value + len(text)
    return total

def _σхρЛжрПξΛψτЛНζ():
    value = 782536
    text = __import__('base64').b64decode('VmFlcjhZeHRsNEJEdFRwX2FGZ0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ехВЕΗπшЕ():
    value = 74458
    if False and True:
        _dead_1552 = 27
        928
        _dead_4386 = 373
    text = __import__('base64').b64decode('TTNyRk5fNWZHckhJVDZoZ3ZaUV8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9493 = 459
        pass
        pass
    return total

def _ЬΞχрПυλбГ():
    value = 54683
    if 82 * 70 < 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('UnNaUTZkMUtJUXdvTzgyaXFNTzc=').decode('utf-8')
    if len('') > 0:
        _dead_7900 = 450
        pass
    total = value + len(text)
    return total

def _япОΗΘьмο():
    value = 938234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HynUXQE265xVGVqVmHm7Ehx/tGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψεζкЖΝυБΟγγФΠΝ():
    value = 275305
    text = __import__('base64').b64decode('bzBPa25qTXliSWU4UERxbWx6Znc=').decode('utf-8')
    total = value + len(text)
    return total

def _мπΦЩχμКйСКбξγЙ():
    value = 874252
    text = __import__('base64').b64decode('TGdISW9EOFkyaWNhcENzOURFUHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΕΧΛΖΦρщеεθЖΡЯξВ():
    value = 271044
    text = __import__('base64').b64decode('RVRIUVVGdUZLTm5DYzk0NlQ4eXc=').decode('utf-8')
    total = value + len(text)
    return total

def _сеχлςъЭπшъΟ():
    value = 820779
    if 58 * 34 < 0:
        _dead_7376 = 259
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgP8PVwy864WHD3yyke8HBMpzXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΙуχδАЖοξΙйчθБХθ():
    value = 257087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IC3dbFYP9IsCAjiUwF28Znwn3T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σУоМюяΣЫΘохп():
    value = 241565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRjRNkBg3asaPDW230GRHxYi9Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΙыуПψЛуΖπыПωγФ():
    if len('') > 0:
        _dead_8042 = 545
        353
        722
    value = 161953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kg6xPH8Tq5sMKSK20g+7DAEt/mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щτзвЧΑщαз():
    value = 155400
    if False and True:
        pass
        _dead_1046 = 309
        _dead_5630 = 705
    text = __import__('base64').b64decode('WkZ1bE5JSlBrVnp1WnoyM1RqS2s=').decode('utf-8')
    if False and True:
        pass
        _dead_6978 = 572
        _dead_3777 = 170
    total = value + len(text)
    return total

def _ΨυсйΘдΨеФв():
    value = 165242
    text = __import__('base64').b64decode('UmFMMFZYWDVscm51RUI0WFVlWjI=').decode('utf-8')
    total = value + len(text)
    return total

def _цНУНЬπыбНюΠПшВσ():
    value = 198376
    text = __import__('base64').b64decode('SUliZlRLZTN4dWd3eE0wckY1bUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ХЪΗРΣжηА():
    value = 923734
    if 2 * 32 < 0:
        507
        pass
        598
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Li3IeAAe8qlVbxuH/3qpJC8AvFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρТЪивδΚТχаσΛΦщВ():
    value = 166413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD/NfUQz2IUTF1mmxHOTFyQ48lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БзаΦΧζΥΖΦтИιЬщΖл():
    value = 261586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjfIdEI23IBWIAShxgG2ZDU5yXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьЯМеΔΜЧκоЭЭεγΨΖз():
    if 38 * 78 < 0:
        _dead_9544 = 592
    value = 660258
    text = __import__('base64').b64decode('ck80SWxxdFNTVTZaOGFUdUJybHA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6421 = 63
        729
        38
    return total

def _ЩΤςтФсбсνΕψЭΣЫ():
    value = 153463
    text = __import__('base64').b64decode('cldsNFVXRmFDS0FacGtBUW1DcnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΜлΗчτХηδю():
    value = 188088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjjGN1Zo2psRKCuA8AKeMiIX220='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1431 = 295
    total = value + len(text)
    return total

def _АοЮЪδфодФΩΣе():
    value = 689512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgLLSUc2rZc6aj+2+UCCEwd38Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΡςΠΩεΛъΘЖс():
    value = 709707
    text = __import__('base64').b64decode('cHlhdHg5dDVMZXVKdHdMTlVBZHo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5305 = 452
    return total

def _юХЭοсΦоΨчωшΗй():
    if len('') > 0:
        pass
        489
        597
    value = 921158
    text = __import__('base64').b64decode('dDVPSTVBc2VYc2E3NjJ3MVhlN3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖМюσНцχΨпн():
    if False and True:
        pass
        pass
        942
    value = 948708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAz+amJg//8JLBmi/HLFIywu0Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 87 * 68 < 0:
        886
    total = value + len(text)
    if 49 * 42 < 0:
        _dead_3357 = 486
        _dead_2582 = 914
    return total

def _ЙРЦюдπλΨςПе():
    value = 875599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICzzZkAh15EoPiWM/X6xDDUbzDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _счФοωдупαлъΥЯιζα():
    value = 767130
    text = __import__('base64').b64decode('cWZMWW41dVFNbUgxcGpaTW00Ml8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6574 = 124
        _dead_7835 = 13
        _dead_7282 = 467
    return total

def _кщφвршВсбεξξ():
    value = 203683
    text = __import__('base64').b64decode('bmhiU3h6azRsRThmblVVRVd3T2w=').decode('utf-8')
    if False and True:
        _dead_2988 = 870
        _dead_9798 = 130
        860
    total = value + len(text)
    return total

def _ΛαξхэнФΗжТΧПмρоЙ():
    if False and True:
        125
    value = 401245
    if len('') > 0:
        pass
        _dead_5793 = 187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgC3UVYVy7okPgyJkFqZEy8W6VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΑΖдυибс():
    value = 59705
    text = __import__('base64').b64decode('RldyNG1vU2RLNjJBbWNibExvak0=').decode('utf-8')
    total = value + len(text)
    return total

def _θГяЭтЮЕЙηΓАМГпк():
    value = 949534
    if 85 * 13 < 0:
        73
        917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBC2XnQJ/akVFQy1w3nBJRAkwj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7295 = 998
        348
    return total

def _ШяΟμсΨαχ():
    value = 865435
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD7CO0gh7ooiPR25wmeRYzA/7XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вζЯСЙшВδτγΠ():
    value = 818454
    text = __import__('base64').b64decode('d1VGaXlCYV9nUk5IbTViNERJM1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЗΕΓδθБΑΚЯΛАоСχ():
    value = 497561
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxyxTVUx7INRLAv6wEyCIh8g8Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θδнжιюεζν():
    value = 655103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgewX1doy4wvLzuU3G+3DRIL2zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4942 = 367
        822
    return total

def _ФхΚчцςАСΔ():
    value = 295721
    text = __import__('base64').b64decode('dVFpdzI3dXNNc1RQNGJmYnU1VVA=').decode('utf-8')
    total = value + len(text)
    return total

def _цЯОЭγθηжρυΙσъΣ():
    value = 675967
    if len('') > 0:
        pass
        _dead_6817 = 816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQW2VAYr+5hXND+u4nOiEh8G8W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        939
        _dead_3535 = 886
    total = value + len(text)
    return total

def _ДБЗЪсΣΑЧТπНоω():
    value = 714156
    text = __import__('base64').b64decode('UUE0aEZ0dm50N1BCc0dVd011Y3g=').decode('utf-8')
    total = value + len(text)
    return total

def _вфИяζКΚΨξюхΒδτΙл():
    value = 272009
    text = __import__('base64').b64decode('aWp2bGpCeG1JME9KdHN0VGF5eGo=').decode('utf-8')
    if False and True:
        643
        _dead_1020 = 203
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_4643 = 776
    return total

def _иФбюεгΓМχцъе():
    value = 190446
    text = __import__('base64').b64decode('UWx3b0pVaUN4dXVmamhXZ2pMalg=').decode('utf-8')
    if False and True:
        389
    total = value + len(text)
    if 93 * 28 < 0:
        pass
    return total

def _ιтΟσΚЫяΚеδЙι():
    value = 658815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCzyWXQ4ro4aMzm1/WaUCyYnvDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖδЭбЮзφх():
    value = 927196
    if 64 * 59 < 0:
        _dead_2890 = 741
        pass
        pass
    text = __import__('base64').b64decode('U1pBUmFMd0tJbmNGSmE2OGRZTVc=').decode('utf-8')
    total = value + len(text)
    return total

def _νξΦхтРЮЭВябΓωЦАΨ():
    value = 135708
    text = __import__('base64').b64decode('elpBUk5PcVlYU21FYUhHT0ZNT2o=').decode('utf-8')
    total = value + len(text)
    return total

def _вΥΝрюΣЯдЩΔ():
    value = 57346
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej7BV2Uz+Kc6PSah+nOpFR99wFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φФΓλдЗйλ():
    if False and True:
        pass
        0
    value = 245573
    if False and True:
        pass
        _dead_7748 = 82
        pass
    text = __import__('base64').b64decode('clN2UGY5aDB2S1JTRjhYZlRUXzY=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        234
    total = value + len(text)
    if len('') > 0:
        490
        pass
        pass
    return total

def _ΔоАЭцβЩαιΑЬЪщΧм():
    value = 513772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR3eZXdt2ZAOLQeG3mLBEg4e4ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΒГЯрБηрПхфРΛчΚ():
    value = 455121
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAPbY2Qrwao3Lw6TxADHJhMA0nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КдχчΚтЭэΠΘБ():
    value = 70963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3z1fwAK6owoMRiP0lqcMgsD3mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        996
        pass
    total = value + len(text)
    return total

def _ЮηяхΨΑХмцВΤыНЖοП():
    if False and True:
        _dead_3331 = 311
        _dead_5180 = 364
    value = 546861
    if 33 * 24 < 0:
        _dead_3044 = 864
        pass
        pass
    text = __import__('base64').b64decode('eHo0R21va0o2OFN5amtpTlZYbW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯНряБЪРΦГН():
    value = 317343
    if False and True:
        678
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CS3uOngcqrIBGSOPnFupBSl+zns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦшВδШМΒρтΨрιЮОшΤ():
    value = 695148
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IS6zeW4z/Z9Saxap2Q+ALCIi1Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τеъμнуохλИξГς():
    value = 93478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTjCRUMt/Ls3PQms92+AMBF75Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5733 = 935
        pass
    return total

def _ещХΗеЯДфθЦГпшСΞю():
    value = 733206
    text = __import__('base64').b64decode('eHV1Q29nZl96OUV2cnFEakhtQ0c=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1234 = 72
        _dead_6902 = 881
    return total

def _бЛΘЮХхИγЪαΩпО():
    value = 741269
    text = __import__('base64').b64decode('TTRodk1RcFBNaUFNX1BtR0pOOW8=').decode('utf-8')
    if False and True:
        398
    total = value + len(text)
    if False and True:
        _dead_2576 = 314
        _dead_5138 = 294
    return total

def _ΠБκΣпΜЭΛиБη():
    if len('') > 0:
        307
    value = 53767
    if 73 * 78 < 0:
        64
    text = __import__('base64').b64decode('TW81TGhJbVo3b1F0SG5sVDVtRFI=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 38 * 91 < 0:
        179
        pass
    return total

def _ЧκδбΕμδΤЗпΓΗзςΦρ():
    value = 403501
    if False and True:
        _dead_7396 = 300
    text = __import__('base64').b64decode('aXdfaDZQYjhPTkxIdEd0dTJMM3Y=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        374
        232
    return total

def _аχρфλЯлΧΥΞΕц():
    value = 24026
    text = __import__('base64').b64decode('b3Z3ejhld2ZRRWxPeVVyR3ByVUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ИωКфЬаЛλуЗηβ():
    value = 191216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQbjX143ypIxbRiw33i+bRQbvF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЪНФдυУИςжд():
    if False and True:
        pass
        31
    value = 264655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTe1TwADxpoSIyOk2GS3GisgwEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗйφΗГρρлτЪΘжΞЙ():
    if len('') > 0:
        pass
        pass
    value = 552392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSztXgcs/PokAF62wnm7PCIe1G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оЫσΩΥκСшръΠщ():
    value = 593982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyXuX1Md8LErA1uv7F+UMTZ79G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЪλΧЕΞзΦΝ():
    value = 765704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAPiaGth5v9RClqI+WWyMwoc9Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4182 = 336
        pass
    total = value + len(text)
    return total

def _ΥεζВэξΞσβηБΛЪ():
    value = 255410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dz7ueVkr9YkHGT+txn3JBgot0Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        955
        pass
    total = value + len(text)
    return total

def _ΟбСяλИΠЙπзΛШоШγ():
    value = 425988
    if len('') > 0:
        _dead_5714 = 350
        852
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyfoYHcD5ooQawuS+k6ANQIO8Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 87 * 7 < 0:
        _dead_9931 = 504
        912
        _dead_5644 = 369
    return total

def _мОΒьΙЖυцΦΑξΑ():
    value = 317187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHrdQXcu8oorEgOQnWOYMHQuz1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΘγλгЙργδК():
    value = 615846
    text = __import__('base64').b64decode('V2sxanVGREJvZldxTmVWTHJMT1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЫЙцηψФЛЕΜПаΜЖЖ():
    value = 624094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR3KUWc3rY8CCQa38VmgOBo9yH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φηΣеΘΓзЛэБИλФмκ():
    if False and True:
        981
        pass
    value = 535515
    if len('') > 0:
        _dead_7000 = 46
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAL1Q2Q896snBVyC22G3BRB86Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЕДΒζΣкбνЩдΣюе():
    value = 180778
    if False and True:
        _dead_6244 = 860
    text = __import__('base64').b64decode('YWk4U2ltV0F4S2loQ3c4ZWFhRUo=').decode('utf-8')
    if len('') > 0:
        _dead_6527 = 473
        62
    total = value + len(text)
    return total

def _μΨСЮΩΥЗΘ():
    value = 320683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzvDWXsT34dVLgqMyUGZZDQ96Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШчсзΜйΥοеУαы():
    value = 596606
    if len('') > 0:
        pass
        36
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICjwRUIs0/8SHz7zy2aVJAEg7XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΗΚΓюЙьвСкΔН():
    value = 940354
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA7sWQQDz4ZWGDv7wH2cHTctxng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _наβΛЭТдаг():
    value = 636048
    text = __import__('base64').b64decode('ZGk5dDZKaGllSFRqVzhCaEdaWkc=').decode('utf-8')
    total = value + len(text)
    if 52 * 7 < 0:
        pass
    return total

def _аτБΡΔΥМъ():
    value = 682825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AX/tS2AAzqQbNBWs7nKaF3wLwmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΣъΦбЛΧэлΦжΝДшε():
    value = 544431
    text = __import__('base64').b64decode('b3FTejRTeGw0dmU5SldjbUsxamo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЪтΒСнγωχЙΡов():
    value = 612955
    if False and True:
        _dead_9469 = 687
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IirSYWM/56kqODey/mmlP3N8sXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙУиЬΖфюνΒΗинχШУх():
    value = 178436
    text = __import__('base64').b64decode('U3pMZEJINkpsclpQa0h0ZTI4TE4=').decode('utf-8')
    total = value + len(text)
    if 44 * 80 < 0:
        _dead_9541 = 457
        960
    return total

def _ьпΡБэλкЦγαрΗβлν():
    value = 700763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyneW35g1YM1AjXwnmOUA3wIxm8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НТσΠрφФΨЗβΞАя():
    value = 899722
    text = __import__('base64').b64decode('UkJJRVRBYzFwcElfYVRIN29rS2c=').decode('utf-8')
    if 37 * 1 < 0:
        pass
    total = value + len(text)
    return total

def _бΑЫфюΥуаβΘнθ():
    if len('') > 0:
        296
        _dead_5704 = 889
        pass
    value = 182067
    text = __import__('base64').b64decode('U2FoU2dGenZCd3pkYUdSSGhIanY=').decode('utf-8')
    total = value + len(text)
    return total

def _εЙЬΕΞξΨΔρЕТ():
    value = 515394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyXSO1UX15JTPj732FfAASgbzDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 17 * 63 < 0:
        643
        _dead_5727 = 491
    return total

def _ΒιФъЪПυзЯВπ():
    value = 388628
    text = __import__('base64').b64decode('T2U3dEVYRm5FN0k5YnA2cWpfcFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ГШψЩβЛлΜА():
    if False and True:
        _dead_3959 = 208
    value = 241135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABjodHo+9qMyNiaz2Xe1AA0Cy2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яОАβφΩχΣрдйШЫзο():
    value = 103225
    if len('') > 0:
        _dead_2857 = 175
    text = __import__('base64').b64decode('bTZ6T0xoejNZQW9VYW1fd0RBRVQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΤАΞΕяЙСЧ():
    if False and True:
        509
    value = 115835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTzCSXw21boQPSup/wenIS4O3Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чвνΤνаЪХγγ():
    value = 471207
    if len('') > 0:
        891
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwfHTXUB5r8BPzC6+mG+NzQC4lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧГЧоьэтщн():
    value = 399676
    text = __import__('base64').b64decode('bF9oQ0FEYTRqVmZyZ1Ezb2RseUg=').decode('utf-8')
    if 72 * 16 < 0:
        pass
    total = value + len(text)
    return total

def _ζνΟЫРρνЦ():
    value = 653364
    text = __import__('base64').b64decode('ZV9OandjemlUZXpHUXY4R3N1Ykw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥψпΘмфΔΚЙгφВπУХП():
    value = 920946
    if 28 * 20 < 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('ZEdFVGhjWW90QzZSTUk3TEdxSEY=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        812
    total = value + len(text)
    return total

def _ρΔлуЮκвФςηЫαс():
    value = 311701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHnMSUgUx55SMiCammKfNRQaxlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨчЖηΘκТυ():
    value = 595946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSbbW0Eor6wnBR7yxVGnHCl47kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бКюЛОιΜΖΜΒΒψΗΒЯ():
    value = 241195
    if 93 * 25 < 0:
        103
        714
        _dead_9934 = 916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3ewQ31s2qUmIC2FxHqpBiA89Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΥууΓψсФЯδ():
    value = 771505
    text = __import__('base64').b64decode('S3VZWmxza25VUmVPRUtTNzNVMXI=').decode('utf-8')
    total = value + len(text)
    if 39 * 82 < 0:
        682
    return total

def _ШΠΨязуηпЯРС():
    value = 159762
    if 94 * 62 < 0:
        124
        30
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NATlZnQR84EXNB+67l7IJiEe100='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2824 = 700
        pass
        128
    total = value + len(text)
    return total

def _ЫΧшΛПюΦнοлΒИр():
    if len('') > 0:
        _dead_2845 = 6
        _dead_1183 = 7
        pass
    value = 144594
    if len('') > 0:
        _dead_6790 = 878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICTzUQAXzb8pNB/x9w+yF3Uh6mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηАХΡФсζтΡνЧ():
    value = 643092
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bzfhe34G7roIKlqz6gaBAww+0V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΠμΛсЪЖιадΘЙωπ():
    value = 994047
    if False and True:
        _dead_5677 = 54
        pass
        _dead_4376 = 909
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDnIe2E/8qwVNCyT3F6ACygH1Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αеЙΟΔМРΠΠφНЬο():
    value = 82604
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyDjYVY8ybwGGBi65XKJAAQ/51Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рαагΦэхυθ():
    if 42 * 22 < 0:
        492
        756
        _dead_4168 = 661
    value = 227648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjbIWmcc/aMwaDi7nEDDGiA+t08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еьΞчΧьЙδщаОЭ():
    value = 553228
    text = __import__('base64').b64decode('VzJPcW1IcVJEM0pmZVQ5V2lJRko=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖУΟρδκΥσфБНМΣахО():
    if False and True:
        _dead_4563 = 844
        _dead_2594 = 567
    value = 794416
    if len('') > 0:
        361
        _dead_9525 = 122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXf3Nm4uwZAOLDWv4mnEbQYstHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _штЬПМяаΨρσ():
    value = 153934
    text = __import__('base64').b64decode('dEFPcE05V2RYS2pxMDZ4THlaeVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΛпεХжτЛλЧμΟΜλ():
    value = 180134
    text = __import__('base64').b64decode('bHNNVEZDVm5xZ0pTRHJadWMwSEE=').decode('utf-8')
    if len('') > 0:
        _dead_4985 = 689
        _dead_1724 = 419
    total = value + len(text)
    return total

def _λζГзЕжαсΝЛυпнмы():
    value = 988141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ln61S1k73LEyMV/2y3mpYBAjsE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υбДюΗБΤзФΣΥмΘυ():
    value = 383441
    if 46 * 76 < 0:
        pass
    text = __import__('base64').b64decode('cWZYbjd5QmE3X0NqM1N2TzZET0k=').decode('utf-8')
    total = value + len(text)
    return total

def _зйγжШлэτδшφ():
    value = 15114
    text = __import__('base64').b64decode('ZWRuQVN3aXdPTkw5U3A2RzFDQ0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗэερξьΩΧγСН():
    value = 218601
    text = __import__('base64').b64decode('djgzNlJMRzh1VjdMX1p4YkNIdnU=').decode('utf-8')
    total = value + len(text)
    return total

def _МμпгЗчΖтα():
    value = 713405
    text = __import__('base64').b64decode('WnNyRHNjc2lFSU9fejdFc09SQ1I=').decode('utf-8')
    if False and True:
        _dead_3250 = 408
        pass
        _dead_4365 = 93
    total = value + len(text)
    return total

def _йщЪЮнъчΚΜΡгΟ():
    value = 449577
    text = __import__('base64').b64decode('SXZLYV9lNUhDMmI1VVhmVFVGT1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ББΟшΒжХιРьΡ():
    value = 771207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAW8aHg4p4oAFRupmkfGNyQb118='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫγΥОκфνУпμ():
    if len('') > 0:
        254
        pass
    value = 394446
    text = __import__('base64').b64decode('VWN3Qmp1WFIxNnVZbDdEQ3BsX1o=').decode('utf-8')
    total = value + len(text)
    return total

def _οеЗйΒФДмφ():
    value = 403408
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXv1dFQg1JEzDQOw/We2PTwl8kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΑНυΩιиηГΟы():
    value = 627446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fya0W0ccqPFXEh2R90OvITQ26UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρДиΗΘЫЮж():
    value = 511629
    if len('') > 0:
        583
        405
        _dead_9588 = 824
    text = __import__('base64').b64decode('WlFMTzNCb3ZGZEE2bENWcko2bjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΨйθКсΚп():
    value = 126423
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz3oOUgD76EIDhv34EKFPBx+1FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζщΗПΧМиГΥГЪтδΧ():
    value = 746548
    text = __import__('base64').b64decode('c2Fsc2N3azZvZFFuYzZlVmNwcHQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5647 = 693
    return total

def _пЯсТετСГξΜЩλΔ():
    if False and True:
        _dead_8958 = 67
        _dead_1579 = 774
        926
    value = 172738
    text = __import__('base64').b64decode('a0xHYmlKcmlYdDAwVEMxWHNxQk0=').decode('utf-8')
    if False and True:
        _dead_7547 = 166
        _dead_9594 = 915
        926
    total = value + len(text)
    return total

def _ФчΩВЧςςаДγгнвτ():
    if 31 * 54 < 0:
        pass
    value = 78843
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDvLaktgyo0GCyucmlS6DAYG3T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РЦчщЩβШνьδчД():
    value = 37425
    if 98 * 27 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgLPZ0Qb7IwBMxym6nCcDCAZ3mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бСαзΨИχЬйκΡы():
    value = 886328
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fxz8fkYL1bgvChua2kLDGSka3Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РХзΗΛνΑАιΑ():
    if 44 * 80 < 0:
        633
        249
        pass
    value = 78897
    text = __import__('base64').b64decode('UkpJdkRqU3RTb3JpcVQxS05DdUs=').decode('utf-8')
    total = value + len(text)
    if 78 * 41 < 0:
        _dead_9199 = 574
        pass
        _dead_5972 = 167
    return total

def _фГчюφлζΕЛыГэμ():
    value = 987147
    text = __import__('base64').b64decode('VWhVczljcU54cHM3b0RRWjJDME0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΝζьяЮγэβиЙςБψφГ():
    value = 415251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR/LW1A8zqEsOzChmQOhESoE1Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΕЖНПлλΝРμεжρИМπη():
    value = 86334
    if 10 * 35 < 0:
        pass
        114
    text = __import__('base64').b64decode('WUZ2alhsVmlCQlliZlQ0a1ZiUkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ъСμΒяτεХ():
    value = 85913
    text = __import__('base64').b64decode('R0s5VjFPTHk2WVA1ejRoQV9JRHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜиъβΒπОмρωРυх():
    if False and True:
        pass
        547
    value = 863533
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('bUo5ZjljYnlwSldzMDEzVllPNmE=').decode('utf-8')
    if False and True:
        _dead_4633 = 595
        _dead_3965 = 946
    total = value + len(text)
    return total

def _ГξΝпняιре():
    if False and True:
        _dead_8370 = 255
        _dead_4521 = 139
        _dead_1641 = 788
    value = 289181
    if len('') > 0:
        326
        825
        pass
    text = __import__('base64').b64decode('SkJ0MmJ4OGpGOEdUSjJ2eWJSRFI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _жρЪфΔЛяхδΝγы():
    value = 644434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDW3eltq2b0uNAio4QSqAgsp7Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΟΤιιβЬΚγΖЕяЮΧ():
    value = 948607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HS3Ve1hp6ZEvLgSqxFOHOw0csGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 84 * 17 < 0:
        _dead_5729 = 725
        pass
        820
    return total

def _ΥΝХΩΞыцМзеηΞдчу():
    value = 950878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxvtXAED7poQFy2uyV+oECAA/Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пКЕжΦΑθΜоЭыα():
    value = 95576
    if 84 * 13 < 0:
        304
        _dead_6132 = 389
    text = __import__('base64').b64decode('bDBpZXlub1V6MFUyRzhVOVZBMUU=').decode('utf-8')
    if 64 * 78 < 0:
        _dead_4473 = 188
        pass
        34
    total = value + len(text)
    return total

def _ΘμοЧЯфκюΦъπБйΚ():
    value = 979846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwPHb2AY0qwxIDeAzHy/DncNsD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΘοьсΟТеяΜ():
    value = 635166
    if 33 * 94 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXbWZGAv5JI8Cg6Sn1LCLgs8t3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΓъТуЖЖΣГξеξ():
    value = 199313
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nyy1bQY9+YknEieCznKKFjUu/Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9220 = 415
        _dead_2492 = 884
    total = value + len(text)
    return total

def _ЙιΠπчΚФРΘЬ():
    value = 214130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBjqQ3Q35LknMymbnGSKZXwX/Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψШЦШДнЛΩЬ():
    value = 511073
    text = __import__('base64').b64decode('WUx5eExGTnZ2Zk93b3Q3UTB3d2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ηУиδФποцКаΠэ():
    if len('') > 0:
        _dead_2394 = 46
    value = 1551
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhDrW2Y+/aFaBRmUz2XEGy5+6FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΦхιоВΑΡμюкΞΔБК():
    value = 356310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxW0UVcu/JFQCDX342WIF3Y/0mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚφζβнΙъб():
    value = 171329
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAO9d0UA0/pSDB2c8k7DZwwd80o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΔХиСμЙΠκΑсφΛ():
    value = 486362
    text = __import__('base64').b64decode('eV9VOXZlV0lMMXlfMVAyQ3dZcGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if len('x') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()