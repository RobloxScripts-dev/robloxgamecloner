#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΩΣΞэзтτνΦрд():
    value = 778290
    if False and True:
        973
    text = __import__('base64').b64decode('ZFBYMFR5d3N0cERaNm9VU0szUHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣγλΟφσΑТяΑλгΑξδ():
    value = 938487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiHva1ATyvsRCx2p0GCKEywh7TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧэлНΦΔФУφ():
    value = 683030
    text = __import__('base64').b64decode('UnFINk43VjRGcGFnRnlfamlNUkc=').decode('utf-8')
    total = value + len(text)
    return total

def _μьЮчЫуτхЗСЭгΣ():
    value = 912571
    text = __import__('base64').b64decode('TWkzVXZlQVVJNHZPaGhSODNZeFQ=').decode('utf-8')
    if 11 * 10 < 0:
        _dead_5542 = 936
        pass
    total = value + len(text)
    return total

def _ХЮъуεψаГςΟΝьΙЛσ():
    value = 119198
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwTLSlsgqKY7DS6N/UCIASMhzjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ООζγХюΥЙщАф():
    value = 352234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCvwdkUh/KYCGQ2a22yaNwR9z0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖСψПОРЪχТ():
    value = 433265
    if 9 * 42 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDzGWVU897A8Oxe3yWGBDX0ptGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΒξфηачδаπΙς():
    value = 219114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgPTYkMD9qoXGRyZ3VjBO3IKx2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХВжЙψЦωаυвτ():
    value = 242289
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD/tYQcw65g7Mh61xVO9YzMl/WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оθΒЮχЯАЩЙо():
    value = 725344
    if False and True:
        pass
        _dead_1918 = 501
        844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgX3NlMz2ZwqMhua/W6FOj0Q0kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 82 < 0:
        pass
    total = value + len(text)
    return total

def _γΣЪвцосΣχ():
    if False and True:
        177
        pass
        pass
    value = 612344
    if len('') > 0:
        pass
        _dead_9674 = 810
    text = __import__('base64').b64decode('ZzFyV1lyUng0VXE0OHFpWUZZcVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΔфТнмцюΣЬуψиЦБХ():
    value = 759951
    text = __import__('base64').b64decode('WndyX0dfTFUyYncwVlNaa2lyOGQ=').decode('utf-8')
    total = value + len(text)
    if 29 * 55 < 0:
        pass
        _dead_5189 = 921
        pass
    return total

def _ΓδШЛалοΚΝПΟМшΞЭ():
    value = 30637
    if len('') > 0:
        594
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ei7+RX0Kx7sbDDmV7lqEBww49Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        842
        _dead_2263 = 394
    total = value + len(text)
    if len('') > 0:
        287
        pass
    return total

def _АрУПЮоΨζСςЦЭ():
    value = 777574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjvcSmsJ/5IqKwaGxwHEIjQH6Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦЯΥцρсΗьεδ():
    value = 913393
    if False and True:
        _dead_6425 = 165
    text = __import__('base64').b64decode('RHExWDlDeWx0Mm94bEJGYlhPYlE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        678
        pass
    return total

def _ЕПЮкΚЗΝχжρяΜЭΠ():
    if 55 * 50 < 0:
        879
    value = 656124
    if 20 * 65 < 0:
        69
        762
    text = __import__('base64').b64decode('Tlg1d2I4SnMxWmx5ekk1RktrbkQ=').decode('utf-8')
    if len('') > 0:
        22
        pass
        920
    total = value + len(text)
    return total

def _ΤρорЮМΖΜηУΧπΘ():
    value = 162683
    text = __import__('base64').b64decode('cU45X0hBU3VCSzh2U3hndndvVjA=').decode('utf-8')
    if False and True:
        _dead_1362 = 93
        263
        pass
    total = value + len(text)
    return total

def _ЩчююХΤΡΓΟΒйζ():
    value = 350774
    if 48 * 85 < 0:
        pass
        608
        335
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBrgSEM00/slDw735FCBIy0sw0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        170
        _dead_1985 = 823
    total = value + len(text)
    return total

def _РμХВЫгбοпΧχΥщαΡμ():
    if len('') > 0:
        pass
        _dead_9244 = 804
        pass
    value = 961257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzX2XFBo+fk6FC2cnGO0MC92/VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лυΝΒЕΦЬыΑ():
    value = 606405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhDbe0gL77gGFSi70Vi4NXwZyGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЕтЫΜоΚШσΨы():
    value = 677697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXuwSH4u6boPOwC72lXDFiEL6mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕСцосφгАΑνЙТХ():
    value = 716377
    if 54 * 28 < 0:
        pass
    text = __import__('base64').b64decode('ZmpsdFJMZUNEMEdoUkFwNFdtVFA=').decode('utf-8')
    total = value + len(text)
    return total

def _АърΞаπРпчОЧβΝξ():
    value = 138577
    text = __import__('base64').b64decode('R2cxTXRtcWhidlc4Y2hQZUZaRDg=').decode('utf-8')
    total = value + len(text)
    return total

def _δдΔΣсΗЫск():
    value = 230220
    text = __import__('base64').b64decode('cXVNbWJHOEhZS1lGWUZpcmI4V28=').decode('utf-8')
    total = value + len(text)
    return total

def _γΕνΣяυτκкΑΒпΑывУ():
    value = 764489
    text = __import__('base64').b64decode('VFRsbnhsS2NNcHlFYTEwUVozeUo=').decode('utf-8')
    total = value + len(text)
    return total

def _НДЧяБлΛФМ():
    value = 241948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADjXP2Ac8a5bCiCW33CeMjEc8V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΓхбОчЧΦχоΛэΝ():
    value = 354999
    if False and True:
        _dead_3175 = 611
        818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwbdVkVt+KAzCwbz0QKhAws/0EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_4973 = 247
    return total

def _ΜυγюΒСφσтπΠχРπΙВ():
    value = 937035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCL3TUQ43f4ZEDm2wlugA3UgvVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 16 < 0:
        pass
        _dead_1081 = 393
    total = value + len(text)
    if False and True:
        _dead_4692 = 701
        _dead_1111 = 325
        367
    return total

def _αЛЖЯЭЯΓПхΨδΖКцъК():
    if len('') > 0:
        562
        _dead_8294 = 896
    value = 432932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwLJPEYpx6UIGCr1ngeeFnQjvEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _χΣπΦΟгоλψΕΦЩЗ():
    if False and True:
        pass
    value = 841101
    text = __import__('base64').b64decode('eHF2RVg2Y1B4VTZQc0JhaHl5ekc=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΧкЧщωэЕГк():
    value = 540534
    text = __import__('base64').b64decode('aGtfd0p6M21GWnRhNUttc2xGd2k=').decode('utf-8')
    total = value + len(text)
    return total

def _χуτлСЖΕя():
    value = 13213
    text = __import__('base64').b64decode('SjlaYWRlUm5QMnpxamJaUl9vWlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮсιЬЕЮμТγЮхИп():
    value = 604780
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS7BaXM7rr9aFl/28GeCMQo+5UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯМΣфрцЯΜФΜг():
    value = 239987
    text = __import__('base64').b64decode('QlU5Q2pyTnFmWVd2d2xiSUp2dE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞцΙТкРΟΡБ():
    if False and True:
        134
        pass
    value = 235657
    text = __import__('base64').b64decode('UEtSa3RaRGI2X2VRWV9udmdGTEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖпхΧЯОАΟ():
    value = 898987
    if len('') > 0:
        _dead_2569 = 994
        217
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCjuQnw4/JxRPyf1+HqfAygAskQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 16 * 65 < 0:
        389
        pass
    total = value + len(text)
    return total

def _цΠαуΡИФΥкБσшЗ():
    value = 967217
    if False and True:
        265
    text = __import__('base64').b64decode('S0pmVjZzYzhxaTAzZV9hY2FLcTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _НοЕΟοюЬдЦφпи():
    if False and True:
        850
        _dead_1691 = 745
    value = 261085
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dhe8ZXpp0LElIz6Iw1+4JTQiwH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧμςпмсΝып():
    value = 45854
    text = __import__('base64').b64decode('b1B1b0RjZGRqTzJaQ09kTThsT18=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЫΤХдйυДΜмдζьφ():
    value = 531001
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhvPYAA2xp8pDliX5WCqZxYEyj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫэЩЙгМшПъЯЮΥΚч():
    if len('') > 0:
        pass
        _dead_6539 = 687
        pass
    value = 86637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR3pW30h0fwqbymq6U+AEycbwFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юЬΙΩвΕξИВΕ():
    value = 142332
    if len('') > 0:
        _dead_1846 = 529
        977
    text = __import__('base64').b64decode('bkRhNlZIenQ1WXhCaWh3aXYwQWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙεЕБΣфΚИэЛΞЖЗеэΦ():
    value = 685677
    text = __import__('base64').b64decode('VDI0SjRVWmd3VUdYVFVyWWNzVUc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        855
        pass
        _dead_1992 = 1
    return total

def _ЯЪЭςΕУякЧ():
    value = 227949
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiXQTAFgq6I7MDWqz3jCBAMA4mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_5983 = 418
        _dead_1784 = 291
    return total

def _ъГйжЗεΜчмщφ():
    value = 66306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECbOe1lv5ooVFiqNml2yMjR60UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΜСΤτπГΨЬΨΜΗΜΚ():
    value = 673711
    text = __import__('base64').b64decode('cXNHVHBDekl0Q1BucFRNM0NRSkE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        64
        _dead_8040 = 777
        429
    return total

def _пЛυдыδИΙрπоΕλ():
    value = 710469
    if 66 * 46 < 0:
        _dead_6008 = 499
        570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH3+PmUbyqQiHSKR6nXGPhct23Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        156
        595
        pass
    return total

def _ДБκаιыбпΙаΩΑмб():
    value = 28340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQvjXGgI7acuMQGrmHuIZik79Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΠюεаΨΕЭК():
    if 15 * 59 < 0:
        pass
        pass
    value = 675219
    text = __import__('base64').b64decode('b3VOZGQxektwSllZcUo3eWZEV28=').decode('utf-8')
    total = value + len(text)
    if 36 * 21 < 0:
        pass
    return total

def _дЛьЦЧΘяТыχωщ():
    if len('') > 0:
        pass
        983
        _dead_6201 = 589
    value = 87810
    text = __import__('base64').b64decode('dFNoZVBCWmpwMGVlNzEwVWZoUDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΦвΣЯЬЩЦΡБЦΦЫБ():
    value = 887617
    text = __import__('base64').b64decode('cHk3UWFXNEc3UWpXbWNjRHRWVUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖцДБΥСъПΠщю():
    value = 746807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj/obHIVroszHSf7m16/JQQs6Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΦРμыωυΣφθχЪпφ():
    if 32 * 100 < 0:
        pass
        pass
        pass
    value = 228988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh7AQls2q4EnPTu7nQK6MAYJz0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗеШμнΝΛЩг():
    value = 503848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnfoYmMK261aMR2WmlSxbCoW528='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗЙθЗАючфЗΙ():
    value = 999815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDX1eH8z2Z8xOTy7m3ijIS8V7ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝЕΣКрЭцΕФКЛμΟ():
    value = 901020
    text = __import__('base64').b64decode('b0FzZnQ3SmNIeEhmTDE4UTRBOHc=').decode('utf-8')
    total = value + len(text)
    return total

def _нчАЫυεκАОЧδжγуП():
    if 81 * 67 < 0:
        pass
    value = 759372
    text = __import__('base64').b64decode('a0JVQnF4V0tDX1FYZTIwMlZTbEY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9626 = 242
    return total

def _ΠУяΚтθУхΑм():
    value = 841515
    if len('') > 0:
        723
    text = __import__('base64').b64decode('RXlJSXNpRXNjTzdLaXlnUzVESFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ζπИРФςяКςХЭ():
    value = 582703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhbgV1cq9a8IICew92OmFyR5yzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χБΥыбргвςо():
    value = 131851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXvMb0luqfgZKQz15EG9FXd+xXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыЙЖчцΜεЭβε():
    value = 200994
    text = __import__('base64').b64decode('dEdaeEtobW1GQk9rUjBwanBFNlA=').decode('utf-8')
    if 83 * 14 < 0:
        432
        187
    total = value + len(text)
    return total

def _ΝрВηΝΛчπΞςγсезβΙ():
    value = 868103
    text = __import__('base64').b64decode('VTBYbHN5bzNLWkh4UFFncmpBVmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗяΟЭΩнРЛфΡБЦщ():
    value = 918046
    text = __import__('base64').b64decode('cGVHMFZfTE5STWxDQkFaNTMweks=').decode('utf-8')
    total = value + len(text)
    return total

def _ζоьπЙЙЦШαХΠы():
    value = 828291
    text = __import__('base64').b64decode('bTFzNUUwY3J6R2MxM19uV0JFN0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _сршхвЗЮАΜТΨКЖг():
    value = 53003
    text = __import__('base64').b64decode('dEVwcUVFckROZk1oUFJncmNyMmQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ЖκωхкнЗЮЕλьМεд():
    value = 289393
    text = __import__('base64').b64decode('QWJycXVBcHVxVXlVMEdBNVFuR1E=').decode('utf-8')
    total = value + len(text)
    if 43 * 44 < 0:
        _dead_5748 = 91
    return total

def _ΚМВΑΜδσФГΛζъЧ():
    value = 244498
    text = __import__('base64').b64decode('dk81alFwY3lsMzY3SGlKOTZnSXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦыПлЦэςЭЭκВрκЭωП():
    value = 51160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3zudwkW/5IqNiyi2keAZwN8sU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦгХБГнλНо():
    value = 665410
    text = __import__('base64').b64decode('SGtCT0VYbndTYVM3aktocjVmTWQ=').decode('utf-8')
    if 32 * 8 < 0:
        _dead_2649 = 997
        pass
    total = value + len(text)
    return total

def _δσλЕμηΤΝЩБιДЬБ():
    value = 11351
    text = __import__('base64').b64decode('SGNSMkFoZlpFQjVyNVBzREJQYUI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΗЙψЮλχНΔφβψ():
    value = 948332
    text = __import__('base64').b64decode('b2tTMk1KT0ZIYzA1TU92cENpXzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ОкνюπаяС():
    value = 304115
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyrKT38r5IFTEgmX42OgAAwc0Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        195
        pass
    return total

def _нΑλДюьЭοσихп():
    if 62 * 22 < 0:
        218
        448
        pass
    value = 317872
    if False and True:
        311
        pass
    text = __import__('base64').b64decode('eng0SjdJdnFKWmdYMGV2Wl9KeFY=').decode('utf-8')
    if len('') > 0:
        _dead_7844 = 130
        _dead_6542 = 628
    total = value + len(text)
    return total

def _ΒπαюеЫтΔΥГпщΚХΥλ():
    value = 947322
    text = __import__('base64').b64decode('cm05Z1RzVmg2ejVJMnpoRlhiMU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜЬЦБкοЪрСΦЕΑτ():
    value = 660538
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQnnTFcz/5AFCwe271enNy4O6Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΤШЕеηДЕргψσДдйψ():
    value = 734739
    text = __import__('base64').b64decode('WUdNY2Q1eHdXb2NCaFoydXJ2OEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ГРшψяοЯΗΞМ():
    value = 667066
    if False and True:
        _dead_6318 = 135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzzlNnsU174xPh/37gDCDncFylc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 62 * 65 < 0:
        pass
    total = value + len(text)
    return total

def _йЗιПСцРБΟΗыыζ():
    value = 625749
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCq2XwAP8PAyHl61xEaCPjciy20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 2 < 0:
        _dead_4864 = 860
        _dead_8272 = 357
        pass
    total = value + len(text)
    return total

def _пГЬλйЮэКκгψξΒ():
    value = 195351
    text = __import__('base64').b64decode('R2E2UFd1WnFoN2M1WlNaSUdiVlg=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΛЩΖзцЯΥ():
    if 25 * 73 < 0:
        _dead_5140 = 532
        _dead_6025 = 405
    value = 219718
    if 52 * 29 < 0:
        554
    text = __import__('base64').b64decode('YXBsenpHRmQxbVg0Q2RoSlNPUlo=').decode('utf-8')
    if False and True:
        _dead_8459 = 630
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_2622 = 85
        568
        _dead_3973 = 662
    return total

def _ΞГηукнлψтувΦΧИЭф():
    value = 699107
    text = __import__('base64').b64decode('TEwzY2xkWktlWTVHRFZQTkVCVWU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        711
        _dead_8293 = 163
    return total

def _ΙЯΨКγсЩΨуОχτАοЫ():
    value = 86633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxXmQAcBq44qbgmbxVmYOCEL0UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7036 = 362
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_8153 = 420
    return total

def _ЗЯЬлΝоЧΝЭПεСЧ():
    value = 852840
    text = __import__('base64').b64decode('VUhfdndRX09jMmdDWmN3SFBRYlE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫДЯАμΝзξяЯμΖχщΔ():
    value = 753473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyjBZwYSz4AtKDyown6kLC5272Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψχТшζΚψζΣΓ():
    value = 690432
    if len('') > 0:
        pass
        300
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzvJYXQ3zaMVMjWg6lq5IgQ10Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _πεςΥΣζΣШоοГΜЩСν():
    value = 874759
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EybdZUhgp7IFYxuh+W+UETMnzUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΦΜБфВβМθМр():
    value = 128457
    if 88 * 94 < 0:
        pass
        _dead_8507 = 327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnrwUWIa2aYPACORngWgDTQhwmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _сαπюзΣΝψДИ():
    value = 404770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyjSPgEy2YEPCSSoxnuvPCIY8Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МАбвжωΧνСЬΙютσ():
    value = 485559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBzuZlYt+5xSYhWs0HeTIg4c6Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΓщδДВтмцзр():
    value = 7310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTbCfnctz5E5GCKt312+JiM/62E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝπхιЬАΨωψь():
    if 39 * 100 < 0:
        _dead_9267 = 132
    value = 644038
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCT8dm5v+rsGHV6GwEeGMC597WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гφηλнтωБЦςИ():
    value = 256559
    text = __import__('base64').b64decode('Ynl0MWxrdkpPanhUNXdpVWlrdWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ГνιЛτпРπШеН():
    if False and True:
        _dead_3437 = 491
    value = 939987
    if False and True:
        pass
        789
        748
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACXQSltrxIoSaRm722O2YhQE63Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3652 = 732
        678
    total = value + len(text)
    return total

def _ξΕΤВряχу():
    value = 17026
    text = __import__('base64').b64decode('elhZS3ZXN3hvSzN2VzVmRlF1WEM=').decode('utf-8')
    total = value + len(text)
    return total

def _УγΦκиЧαεйдμπΔ():
    if len('') > 0:
        pass
        906
    value = 206793
    text = __import__('base64').b64decode('a0FjcWp5ajVBMmpRUkgwdFhaX3M=').decode('utf-8')
    total = value + len(text)
    return total

def _еΓωтСднМ():
    if len('') > 0:
        _dead_4269 = 808
    value = 817709
    if False and True:
        _dead_4988 = 721
        _dead_4000 = 743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQzqZlMA94ENCjqGnHGjbAYf63Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωиПоХБоаνЛЖхγАΦΣ():
    value = 80878
    text = __import__('base64').b64decode('dUdycDhXb2VpZXhvWDluTVZPZjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΣуйКΥΓΚШυβрюЙР():
    if False and True:
        _dead_7133 = 191
        851
    value = 930014
    if 56 * 30 < 0:
        _dead_7303 = 991
        _dead_3808 = 415
    text = __import__('base64').b64decode('Y1hjN2RDQWpoTjVGRzA2X2QzMzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ιгеπΑлЯЫхΩиθ():
    value = 113982
    text = __import__('base64').b64decode('U2NwcFZ1QUg0bUNkQXMwaTV4bVM=').decode('utf-8')
    if 85 * 82 < 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        223
        pass
    return total

def _ΨΟойЪГНΘζшπω():
    if 92 * 55 < 0:
        _dead_6023 = 798
        929
    value = 119316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHvmYV8+5psWaiOF2Vq0IgF53WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νДцСτюМЗТ():
    value = 426479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwHAQ0Icy4IxKAy1w16kFg0/yTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гюпΣΧΘЫрцμ():
    value = 970630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NC7taEIW654yNCSH0UORIB0Y22E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟХσΘчАκπЛЪкФμ():
    value = 956179
    if False and True:
        474
        396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PX38PHIz3KIvOyyAmXyjNzYG4UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 21 * 62 < 0:
        _dead_6734 = 511
        pass
        _dead_6777 = 231
    total = value + len(text)
    return total

def _ΧшψлЯςОВлΔυ():
    value = 365226
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTvbXQkg6J4uHVunnQ/FZBMO9j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьейВφЬиыЭιиЧβ():
    value = 60861
    if len('') > 0:
        pass
        768
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBbcQnUo3PkHKTaZ5HvHEBML9j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χЩδкΓшдэ():
    value = 773790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyjyTGluzYNSF1qa4nKXPigo41k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вШЪΜΦЮЖκыΖ():
    value = 126710
    text = __import__('base64').b64decode('Vk83T2ZRdXhoMFhkdWU5M2V5dzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚπбвШνπΖΝΡΖЗдπЯ():
    value = 758603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBe3OnU8wfsWbTam2UykDQAJ6mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 77 * 31 < 0:
        732
    total = value + len(text)
    if False and True:
        pass
        _dead_9692 = 44
        _dead_8390 = 594
    return total

def _κΦлξАμνт():
    if len('') > 0:
        120
    value = 838921
    if False and True:
        330
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3vDdAdtzP4CC16S/26WDXAusHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 86 * 79 < 0:
        215
    return total

def _φпσеΙΤФегс():
    if False and True:
        140
        _dead_8831 = 928
    value = 617799
    text = __import__('base64').b64decode('amtRcHhvM1hHaEpua2kxdFV4OEo=').decode('utf-8')
    total = value + len(text)
    return total

def _дσΣЕΖЧиΑЯωΚΧ():
    if 99 * 10 < 0:
        _dead_2363 = 700
        pass
        _dead_5529 = 715
    value = 248812
    text = __import__('base64').b64decode('VzY2azZ0SlUzV0c2RU5OdDJSYzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΑюΨδсьбйФΞ():
    value = 507689
    if 75 * 100 < 0:
        pass
        _dead_9629 = 92
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3/0W0Qsx7sbMzms/FKBP3w30U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩТПжПΓΣжЪяныЙ():
    value = 281576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDbIYlsh/645H1uRxEGFEg8k8Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓЛЛΩДвЕΙνρтΛΔυПφ():
    value = 958637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjvIX2YN554lPwCK+QeXI3B74UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хфλΧъДχуМεςΠδχ():
    value = 459656
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgL+aWUz6qkPMTCu7XimFjIWx0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьζиБЮЕΖтМжеЮυ():
    value = 296132
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwrxYgYP6bA1K1aN40e4OBF67nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪЗЛΖШчΟΗчχУТ():
    if len('') > 0:
        _dead_5133 = 412
    value = 878394
    text = __import__('base64').b64decode('R1ZkVl94dE5FUjVlYXJyeVN5NWw=').decode('utf-8')
    if False and True:
        _dead_8861 = 427
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        97
    return total

def _СθμжργΒНшмφΥлΨНВ():
    if len('') > 0:
        _dead_3643 = 793
    value = 245267
    if 23 * 1 < 0:
        382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jwy0d30r9q4hIDC10ECnBAoI414='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЪХеδθαηξ():
    value = 574734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P330dAYDzakWCz2L93XGDSEZwEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΑоОйФЗоМуρМфГδ():
    value = 290572
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwWySAQLyowLCQvxmGaADCQYsHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вюмΩδЗжОвΒэьκ():
    value = 515454
    if 86 * 59 < 0:
        137
        pass
    text = __import__('base64').b64decode('cVY0YUxaTUJfY3M4U0NybFphSEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗиωЬπχμЖΦКНδΨ():
    value = 766974
    text = __import__('base64').b64decode('SWNWS2xwNkVxcmk3ZFFfUVZvOF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΒуеШξМРФ():
    value = 436962
    if len('') > 0:
        118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LweyeXAuyIElHQGGzU++OX0oxlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7642 = 975
    total = value + len(text)
    if len('') > 0:
        pass
        251
        990
    return total

def _снξЯμЖфуЪЙΝИτ():
    value = 723293
    text = __import__('base64').b64decode('dWR4SkZEelp4NXRZcXUxRmxZSWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛнκρζХΓЯ():
    value = 374508
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FznPSgkJ9aYNH1j3z1uiBygXxVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 28 * 52 < 0:
        382
        pass
        388
    total = value + len(text)
    return total

def _ФηΟЬΕΨΕτжб():
    value = 72622
    if len('') > 0:
        36
        _dead_1532 = 323
    text = __import__('base64').b64decode('ZjlpeWVBOGR5Wmp6QWhVeVBVZUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠШΠрхιдΓмжВНοΣ():
    value = 9247
    text = __import__('base64').b64decode('UzNRYlNUU1AwQk05VlY2QXV4NEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝыΜЬπΧΓГΘγД():
    value = 465508
    text = __import__('base64').b64decode('WGpROGZtbW5QcFl3R216dHJFc04=').decode('utf-8')
    total = value + len(text)
    return total

def _бμΙрНюКΒЗΑщПэу():
    value = 918556
    text = __import__('base64').b64decode('cDVNQlpmeUNhSjdJWXhxSWhiNVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _СΖΘАТγыΗъДЕγш():
    if 51 * 28 < 0:
        123
        pass
        986
    value = 131467
    if False and True:
        _dead_3221 = 587
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSe0eW41z/o3NSKH0nSpPwY+3Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7110 = 382
        _dead_1107 = 88
        _dead_6689 = 567
    total = value + len(text)
    if False and True:
        _dead_5403 = 815
        pass
        639
    return total

def _ΓЭδΟΩαюοЫИωОБυвЗ():
    value = 716324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwX3RQMTq4QnPjq0/GmTbQEExUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΧГΣθβгΠεСлЛν():
    value = 556014
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzzXQQBry6oMPFe73wTDBzUOtmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _οЭвδхшХйМфΞф():
    value = 539577
    text = __import__('base64').b64decode('VnlHT0hxdG83enBPNmM4c2xLMHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ябνσвπκΒэПмιмлйЗ():
    value = 663037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAXBSGYq0KMaKFn75HSzDHEX22c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _опЫρΛψЭуΔζгСГΚψЗ():
    value = 688305
    if len('') > 0:
        pass
        437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDfbQkY95LtaG1u1w3myZggrwW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ЫЛΥЫΣозЫрЫТШΗΓ():
    value = 631803
    if 24 * 3 < 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('Tm0xSXN4R3pzQld0a1FHUEs3MmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧдΦχΠιΒуэгΧ():
    value = 457277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByD+eVIs0LA3Kle34FeyByEs0nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜνъзХΞуΒ():
    value = 299137
    text = __import__('base64').b64decode('bUtpbzE1ellYWU9CNlYyRUU3aEg=').decode('utf-8')
    total = value + len(text)
    return total

def _кψτПξТАхΙЛΙМЪο():
    value = 372840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgvLSnkOxLg0ECGc6VeBJHcJtVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6842 = 672
        390
    return total

def _сЕоыμΑПβΒΤЦгμιЧ():
    if len('') > 0:
        pass
        pass
        403
    value = 143363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3zMTVIIq4ImMVyB5ACJZQgt12Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΣΦαΧЦΧКН():
    value = 603814
    if False and True:
        731
        _dead_2878 = 461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRfbV2Aw0KVaAhXz4WWEETQk3XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 6 * 47 < 0:
        pass
        359
        pass
    return total

def _ВυщμфйСΠЗРЫ():
    value = 804703
    text = __import__('base64').b64decode('dk80bHpuZkk1Z1dpWHM2Y3BVWlE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        768
        558
        _dead_5805 = 454
    return total

def _ΜкзΤиЛΚπβоГΙпЪо():
    if len('') > 0:
        pass
    value = 810391
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETrtflA7rYcCYiyi2WfIEwR44zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОУфΑеΕкπΑλΛюΕшΔ():
    value = 276229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3/VbEQw1KYREQH18lmoATEj52w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МщАΡττжмΩхΠиωΠ():
    value = 883588
    text = __import__('base64').b64decode('UGhHY0phOExBcVBNOVc0a0ZTUEk=').decode('utf-8')
    if 78 * 63 < 0:
        _dead_5873 = 894
    total = value + len(text)
    return total

def _ΠлящзлγшОθщΚмΔ():
    if len('') > 0:
        168
        331
    value = 462338
    if False and True:
        pass
        690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgnBSwc8xqAABQq63lCUAiYs5Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΛыςΧиКζοιРмбΙ():
    if 80 * 99 < 0:
        _dead_6057 = 523
        pass
    value = 942675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhbuOWMu7acoMS6r5VKkNSk4710='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        683
        _dead_2854 = 333
    total = value + len(text)
    return total

def _ΟΧΟЫΨэрΒξЕσ():
    value = 777885
    text = __import__('base64').b64decode('QlhnTnlNUjJhWWFISkdSRHRDY3A=').decode('utf-8')
    total = value + len(text)
    return total

def _АьιгΘЪХΕн():
    value = 742512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgTcZHU9qItaHDqa3V2DYxIl7m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩАηЧαэζОЙьΗΦτ():
    value = 162520
    text = __import__('base64').b64decode('QllzanZvQ0hKdXp2WTNxQnZvcEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΞΘкгквБυьηнδРРг():
    value = 29094
    if 95 * 47 < 0:
        819
        907
        _dead_5232 = 181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnfvQEsb75EgIiK00Xq/BCM73EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1187 = 927
        _dead_4913 = 959
        839
    total = value + len(text)
    return total

def _ΒУΔЭЗΞеυчШлэ():
    value = 63932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LifLPEAW1qsFAiyEkF23EyQk/Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νфэоЮЬСЕпκЛ():
    value = 493000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAG2e2MV96EpEh6WzFSSIBEN8H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рдцЕωξеτ():
    value = 978302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyWwQ0Ig7ZArLyyOw3KIZhc6sjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чυωчвтчНΒт():
    value = 728047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx/AeUQq0aoREQy13WaXAhwG1Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1777 = 86
        pass
        984
    total = value + len(text)
    return total

def _МмотΣχΒΣ():
    value = 857736
    text = __import__('base64').b64decode('TWhVeUJqdndRcDdLS0h5VTJjbG4=').decode('utf-8')
    total = value + len(text)
    return total

def _дΟζуЭΒИСιΓИЕ():
    value = 889862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRrrZGga1bEgKBuy73CBNTQJ3nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ощттεиεΦΞτ():
    value = 254632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSL3aHxo/INWFwqP4FCUIzwa4UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣаХщΑΚит():
    if False and True:
        12
    value = 619429
    text = __import__('base64').b64decode('VGNwM1VoQTk0WVJMMzJtdUt4bFM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        722
        205
        pass
    return total

def _ΧКΗрьОщΝζЬγГЙР():
    value = 980963
    text = __import__('base64').b64decode('SFhKb1pOSjR5eGROdzl0TWp6Z3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _φΕФхьзСΕ():
    if len('') > 0:
        753
        _dead_4255 = 281
        pass
    value = 8779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxfWa0cv3JsFLTuKwmKmZ3Imt3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        452
        746
    return total

def _рОЫΑмвлΜЪюЛΗЯхΡп():
    value = 916993
    text = __import__('base64').b64decode('Vm16TmlDWlNzUmFuc2VreUxKRkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘГПивΒКΨЬΑсЧΘγ():
    value = 707590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3jTP3QgyqwHHD+z/A+hBAkuz2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΘαΖгДвДΙ():
    value = 175930
    text = __import__('base64').b64decode('VER2VHdsM2V3RUV6amJ4VXNsUG0=').decode('utf-8')
    if len('') > 0:
        pass
        740
        pass
    total = value + len(text)
    if False and True:
        _dead_6726 = 34
    return total

def _τλГЪΔАωδкΕ():
    if False and True:
        _dead_3424 = 226
        pass
        754
    value = 599249
    if False and True:
        328
    text = __import__('base64').b64decode('QUVjN19KX2dXbWtyWW41MG1SWXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ηмνрΟΨτнαγκ():
    if len('') > 0:
        245
        594
    value = 24721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ3gfQgwraBaKVao4EPIOAoJ/ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7922 = 606
        _dead_6851 = 924
    return total

def _τωΝаΝΠГψзΡжыΦФΔэ():
    value = 62432
    text = __import__('base64').b64decode('eVV5a21qQVpsV0JvMzBNQTVRejk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣχэΥшЕΚεΡыдв():
    value = 810279
    text = __import__('base64').b64decode('cE9pV1c5ZTF6cm1PbnVrVWRiN0k=').decode('utf-8')
    total = value + len(text)
    return total

def _οΠтЮЦκяβяУарΙЖ():
    value = 213013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyO2SXcG1ZgUaF264HW5F3AI3Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗТныΔЛЯμФΟΞΑЛгβЗ():
    value = 787446
    text = __import__('base64').b64decode('ZktDUFY5emZpVGxORXk5SjVYaWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ШξбνЬδΓИЖаД():
    if False and True:
        579
        pass
        _dead_5178 = 442
    value = 129435
    text = __import__('base64').b64decode('cDZERU1BOXE2dVA4YlFRMFR1V3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕчφтςНζчδБ():
    value = 528864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwnpPwIsrbsiMCKPwnXJFicc4j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 33 * 88 < 0:
        527
    total = value + len(text)
    if 43 * 4 < 0:
        pass
    return total

def _жτРоКхΞЦВЫэωβςΩ():
    value = 404462
    text = __import__('base64').b64decode('TTlkaVptcGdUVUlKUmxOR2xtOVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ωУΩДМΑуνσФМЮ():
    value = 282367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCbVXEUP/IxVPz2k0EW7DAo46XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΟьлЛыΘχеГνъхыΚλ():
    value = 600185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQX3QHo88ZIUMF6l+XnGJS4FtV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΞΧшιрВБР():
    if len('') > 0:
        _dead_2650 = 34
        458
        pass
    value = 268991
    text = __import__('base64').b64decode('VTQyNnBKTTg5MTd6UXQ3SU1kclU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΖлБΩгРΙЦзрнбΓ():
    value = 773532
    text = __import__('base64').b64decode('djNjSlZYR1pqWTJxQ2ZQc2tCbkY=').decode('utf-8')
    total = value + len(text)
    return total

def _еиγΤСсФΩΧтκаЛπ():
    value = 81942
    if 88 * 100 < 0:
        712
    text = __import__('base64').b64decode('WXJiRlFPdGg1MUhiTUM5ejJmbFM=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЮАкλΕкрХЬНевτΖ():
    value = 980580
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh7La2g/p7k7BRr3zHKiIBcfwVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДпрΝΧКΛΚОρщ():
    if len('') > 0:
        pass
        _dead_5203 = 330
    value = 11466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EivDNnAO8qkXHz30/FGZAwt51nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        25
        995
        _dead_3001 = 629
    total = value + len(text)
    return total

def _ΡαдΒСΡФэнΥтΑбΕΚх():
    value = 419312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXnwXlUpyrEyKV+T/F2lExU2520='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τЭεОрΜбЯδ():
    value = 464633
    text = __import__('base64').b64decode('blZ1TTZnNDFFU040bV9pZW9PQzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЮЖΤэчΜωΑΣянβμХ():
    value = 902286
    if 89 * 73 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSfFfAAMyfwFLS6o+V2XHAQrtWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ганοЗВБΜΙυΟξМο():
    value = 920919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTjrNwQ7qv4HHj+G2mOIbQMQ0mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4402 = 240
        pass
    total = value + len(text)
    return total

def _ЩсΡЖаΓΝыЕд():
    value = 92025
    if 78 * 49 < 0:
        _dead_4050 = 770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHjtfkEoy5E2IwGunVPHOjI19UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δгкВγГТяΟНщ():
    value = 828265
    if len('') > 0:
        196
        _dead_1497 = 845
        _dead_8960 = 9
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ay7yQkQj05oAbVus2UOTGCsW7Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 40 * 93 < 0:
        pass
    return total

def _λрдκδГфбςтыωеа():
    value = 592365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQHNf30Wx4YyPCyZzkWjPAYh90o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гЛγаГοЩχτЫвд():
    value = 334501
    if len('') > 0:
        222
        _dead_2598 = 183
    text = __import__('base64').b64decode('aEl1Sk5TemM4eDJtZ09qRWVvN08=').decode('utf-8')
    total = value + len(text)
    return total

def _фЖзэьЙмуΜζΓЙεпτ():
    value = 443163
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FD/Cf3IBrqchY17x3mO0F3EG8kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6729 = 549
        _dead_8775 = 886
        pass
    return total

def _РεоιοПχЛψνΘ():
    value = 963747
    if len('') > 0:
        pass
        897
    text = __import__('base64').b64decode('cVkxdEVQWGFOSFh4MlpfU3VWTVU=').decode('utf-8')
    if len('') > 0:
        0
        140
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if 44 * 36 < 0:
        736
        pass
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    _dead_2067 = 572
    794