#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΚνиЩшуыдФнАΩλ():
    value = 361840
    if False and True:
        33
        _dead_3537 = 334
        903
    text = __import__('base64').b64decode('c3Nram1WdkZtTkxmMzhQSGlhQ1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΦρфΗыьСψфжЮΛЗУ():
    value = 616565
    if len('') > 0:
        pass
        pass
        316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjnvWkgT95ooMQqp53qlLnZ94EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧαπяσδиΖъ():
    if 20 * 21 < 0:
        pass
    value = 364434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izz9WlIzqokmEgb6+2TJEg4I0G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЕγИГЛΧςпАПЯ():
    value = 805296
    text = __import__('base64').b64decode('U3ZGZUJaVTV4YThyVks5QUdwQ3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЦПιЩжτΘкхθдеβ():
    value = 301811
    if len('') > 0:
        _dead_2909 = 472
        542
        405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSb2fkYR6aISFSSCzGWvHAR2x10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4900 = 205
        8
        _dead_6850 = 514
    total = value + len(text)
    return total

def _εЮΣΥΣМСσ():
    value = 66310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSXDa2luzasWbALx3V+BYBQ96Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иηΓπЗфгαлЦух():
    value = 188932
    if 6 * 29 < 0:
        894
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQbqPV0dwbkpbFyv40WWZgF+t3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        871
        _dead_4443 = 277
        809
    total = value + len(text)
    return total

def _уЦтИьсЕрМΤηэαЩк():
    value = 187314
    if False and True:
        pass
        _dead_7559 = 990
    text = __import__('base64').b64decode('QUxWb0l3c0c1TGJ1NTNnMkRZejA=').decode('utf-8')
    if False and True:
        _dead_2794 = 827
        _dead_3513 = 373
    total = value + len(text)
    if False and True:
        922
        357
        147
    return total

def _ΛκйсΥςцζрчкрΔωΡЯ():
    value = 44806
    text = __import__('base64').b64decode('UFRIc2t2Zmx5Sl9fckxFUlBFVGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ξαшΞσнΚДКμкΘ():
    value = 774924
    text = __import__('base64').b64decode('TUtlQ1BuMDFxdzJRUmRKbDR4Nlo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        670
    return total

def _βαэψяЦΚеπСΙΡхΙΥп():
    value = 905500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiPWNkMg7K0SNS2x/GKeEjB54WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξκдΥчΕΕлрΖжυп():
    if len('') > 0:
        pass
        pass
    value = 512719
    text = __import__('base64').b64decode('SnRpa3JzMXphV2ZHa1ZKc2Yxc2k=').decode('utf-8')
    total = value + len(text)
    return total

def _НΓςЗΥСРЦЪУΩΞМ():
    if False and True:
        _dead_7777 = 916
    value = 262707
    if len('') > 0:
        496
        pass
        741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ER32TGQAqawoOAaCkFnJMSIftno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        167
    return total

def _χуУγΞЖβΙΗибБςмДρ():
    value = 320548
    text = __import__('base64').b64decode('dUVhTkF5MVQ2ZmFxaWVBaXhjVWo=').decode('utf-8')
    if len('') > 0:
        11
        pass
    total = value + len(text)
    if 97 * 92 < 0:
        _dead_1610 = 721
        _dead_9699 = 840
        243
    return total

def _ОΞμыΠчВПЖ():
    value = 157593
    text = __import__('base64').b64decode('aDI4TEdlV2kwNW5mNmU4YXBoZmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΦтοδЖИЦШхЗОА():
    value = 293233
    text = __import__('base64').b64decode('UUs3OEVUOG1GSVBwbjVra3k5OGI=').decode('utf-8')
    if len('') > 0:
        769
    total = value + len(text)
    return total

def _ХΥЖБуΠЩςΙΜΜфνЮэ():
    value = 35909
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCfNRQcxxLAqaCWOxl6DIT0o8ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 40 < 0:
        pass
    total = value + len(text)
    return total

def _ΓΗЕРρдЛЦ():
    value = 50312
    text = __import__('base64').b64decode('Z2FsTW5aUGhOejEyNVZDQUlQMnY=').decode('utf-8')
    total = value + len(text)
    return total

def _йВΝΛψλЦяΣчЕЭΕ():
    value = 318591
    text = __import__('base64').b64decode('bVdkUHlwVU5DS2o3Tkt6dklXYmE=').decode('utf-8')
    total = value + len(text)
    return total

def _еΡЧΖЧЩθΠβΦГОЖΕψτ():
    if len('') > 0:
        _dead_8541 = 327
        944
    value = 297215
    text = __import__('base64').b64decode('ZHpVNVFpNVdLSHdtV192ZFMxYV8=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΝлБеРλξеВωАХУА():
    value = 487457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRCzbW416KQoNC2h2VG1Pi8m60Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΡφμфхξЮЗэττ():
    value = 842415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSLwPl4jz5IVDx6M7XHAGwIK8j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        141
        159
    return total

def _ЖЫεеαимеΤΑЦгЛ():
    value = 641722
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjziZ0gW6JIoHyGJxkeBEHIFz30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩайζЬаФΑсБλΡК():
    value = 509953
    text = __import__('base64').b64decode('UXhfWEtUUGFqYVFkWTVxMm9WcDc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _θГυφΞюиυ():
    value = 351706
    text = __import__('base64').b64decode('VDdjU0ZiUjlIOTFNTW9SdHBKR2o=').decode('utf-8')
    total = value + len(text)
    return total

def _πφЮхζДДАυАΠБυЦΡ():
    value = 76170
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCfsf24brLk2bzWIxme9GQQQ1V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        163
    total = value + len(text)
    if 39 * 25 < 0:
        111
        891
    return total

def _ЮЭтРμψЙЩЯЩΚЙΨτΤ():
    value = 346014
    if len('') > 0:
        _dead_1271 = 618
        879
        _dead_2033 = 354
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQT9eFUq1pEGDzCp2wWHFjQH6EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        269
        pass
        _dead_1097 = 223
    return total

def _цНЩΤДьвьΩаπΠлАя():
    value = 753974
    text = __import__('base64').b64decode('RnhfbEhTWllkd096S2xYc2tEQWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬТЫχхЮЫФЧ():
    value = 471373
    if len('') > 0:
        882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCDURlYa7KEAbh2X7GmjNyQk118='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эςМфεряκчнξНХШΨ():
    value = 256440
    if 63 * 41 < 0:
        pass
    text = __import__('base64').b64decode('akVSZGpkaDh4X3FrZ0ZRNjFpWEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦИγΗτкЪΣЙНΨДоΔ():
    value = 880583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhDTd1A6+foiGRiW7mCJFTUh41Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗфеΦиζζγΙΦλιΨΛЪ():
    if len('') > 0:
        pass
        _dead_1193 = 75
        748
    value = 122179
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAPrV3I3+6oaNSXz9w+gPwEc6kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 34 < 0:
        _dead_2894 = 245
        387
    return total

def _лЗλШЮρΣπцηπьТ():
    value = 961858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjvceH0tprFabT2Iy36aOTcgtG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5694 = 660
        _dead_3449 = 991
    total = value + len(text)
    return total

def _θЬπвюйνрΕ():
    value = 521670
    text = __import__('base64').b64decode('ZXlJbXNfRUdwOUI0bWxmTUQyU0U=').decode('utf-8')
    total = value + len(text)
    return total

def _εВЗъбйΣΗλРΟηи():
    value = 776150
    if len('') > 0:
        _dead_4985 = 963
        _dead_1281 = 463
    text = __import__('base64').b64decode('VVFQZ2xWY2NNVExXRkk4OWhUbGc=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        430
        35
        _dead_4539 = 1000
    return total

def _жфЩЩΨУΡвВхЪпНωШλ():
    value = 609146
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB3jTH4LprgiLSG650SHGQYW7Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 27 < 0:
        _dead_1176 = 51
    total = value + len(text)
    return total

def _ΦΖшΩΧаЫжи():
    value = 162627
    text = __import__('base64').b64decode('aEY2bXo1b1llMlQ5Z0pMZ0xqTzU=').decode('utf-8')
    total = value + len(text)
    return total

def _λНΩыбΖΣх():
    value = 266602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERjyflA05qUrEBmp7mWeYAd5vU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рηΨσМцωξмохВШδ():
    value = 754757
    text = __import__('base64').b64decode('RVEwWURJdEVJY3JodVNyZ3p0b04=').decode('utf-8')
    total = value + len(text)
    return total

def _οЖβСΨХгΦΕλβюηЗ():
    value = 359157
    text = __import__('base64').b64decode('R2ZTcjRBV05XT3JWXzVOakhYUXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡУБИαЕуωΓг():
    if 21 * 1 < 0:
        pass
    value = 30786
    if False and True:
        333
        _dead_8719 = 106
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3/0PGIh+q8oNB+JyVi3Ph0bykA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 39 * 93 < 0:
        _dead_3206 = 530
    total = value + len(text)
    if 4 * 84 < 0:
        pass
    return total

def _ЭПδΚГУвεз():
    value = 378271
    if False and True:
        44
    text = __import__('base64').b64decode('YUZ6ZlRGNlhTZjBUZk5XU2xaSkg=').decode('utf-8')
    total = value + len(text)
    if 49 * 61 < 0:
        437
        733
    return total

def _ЧΔςнодфГНο():
    value = 82207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxjMY2Ycr4c3KwP3wkSCEi0Z6Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йШЕΩДυφшΦКэοАГΚξ():
    value = 391185
    if 37 * 94 < 0:
        _dead_7788 = 410
        716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzXAbX9vwboEEDyu7w+EC3Mqx3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        382
    total = value + len(text)
    if 84 * 59 < 0:
        115
    return total

def _МВэогхТрбЮβЛТΓ():
    value = 998440
    text = __import__('base64').b64decode('dkxWNWVnT2R2VXBzNDhPY2k1a2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑЙΠΘэκАοτΜ():
    value = 852296
    text = __import__('base64').b64decode('dlgzRXhyWFUyS0ZjYmNyZGlfNGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗФАЬШШπбζκΚэ():
    value = 175922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyPJOXkM76I2AwepzHeDYDck6kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 28 < 0:
        33
        478
    total = value + len(text)
    return total

def _βΖУзДΗЗиЦΣχ():
    value = 660255
    text = __import__('base64').b64decode('QzFIV3doeFBDX05vMG5yMmZsdmw=').decode('utf-8')
    total = value + len(text)
    return total

def _τεΤсΑюлноΙРфбΥ():
    value = 272677
    text = __import__('base64').b64decode('U2xfUGpfWHdFbmJqOFpGVFNlMlE=').decode('utf-8')
    if False and True:
        112
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        534
        _dead_9905 = 226
        pass
    return total

def _ΙωдкωаКцЧЫθχЗ():
    if len('') > 0:
        566
        860
    value = 954584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxexRmE6qp8pMSbw5w+iMj039jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7843 = 229
        pass
        _dead_7069 = 59
    return total

def _ТБΨτсπаΙЪ():
    value = 895975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQvlXGYgqYQANQWz7Uy+HXcfvEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9980 = 920
        pass
    total = value + len(text)
    if False and True:
        _dead_3828 = 153
    return total

def _νΤΠΥжΡПШаΚБδΠε():
    value = 174353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwDgPH0e971UHVa30ES2Fzwj7j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        936
        _dead_8788 = 342
    total = value + len(text)
    if 38 * 93 < 0:
        3
        869
    return total

def _ξβЦшεγΘЗюΤв():
    value = 224563
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ig3xO3sJ6pgHah60nGKyECEj730='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4574 = 236
    total = value + len(text)
    return total

def _τвгΛуσΦβκуцЬъΗЗ():
    if 31 * 55 < 0:
        pass
    value = 864528
    text = __import__('base64').b64decode('ZDVySWhjS0hiWG4wSTNQNTRNVFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟкΖБΑОКΠ():
    value = 668968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSe0SEsSzqsiFiuu4UCzGCQE02M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЯτщхРФΓЧ():
    value = 199541
    text = __import__('base64').b64decode('bHNxbHhoT0dFSUFzd0poVE93ZVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΤэРΓτΦХЫ():
    value = 653962
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3izXXg0rIkEahyx+gK1HXMi9nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΦйющюΩч():
    value = 394298
    text = __import__('base64').b64decode('REt4QlJBcXFaSmZZUFJfd2RwYVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞошμХиαξψюлφ():
    value = 864353
    text = __import__('base64').b64decode('TDBmd0tuaW03UzBFaGx6SmFoalA=').decode('utf-8')
    total = value + len(text)
    return total

def _КчДятГОдчΗНчЖГ():
    if 51 * 69 < 0:
        _dead_5450 = 756
    value = 633275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCLrbQcQx50TNFyo3WSFEwICs2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΖмьфеЫпτэυ():
    value = 442099
    text = __import__('base64').b64decode('WkFDbkpGSmtIMjFSdXZSRERiN24=').decode('utf-8')
    total = value + len(text)
    if 58 * 24 < 0:
        pass
        _dead_8838 = 789
        pass
    return total

def _ЩфтβДВαΥФ():
    value = 964667
    if 40 * 56 < 0:
        596
        pass
        446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxvcSH0tyo8Waxyc8G68DR8pvXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _πэЯФазЩгβΛжгЕ():
    if False and True:
        pass
        pass
    value = 983717
    text = __import__('base64').b64decode('ZVBhZ01Ia1Vwd2tRYVFyMGpzd3U=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8645 = 802
    return total

def _вωТзΦθЪσ():
    if 39 * 77 < 0:
        _dead_7948 = 202
        pass
    value = 914392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHrdf2Btwb0qFVeA5HydGQ8pw08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        408
        481
        803
    return total

def _ΒМφΗгЗΡБ():
    value = 538708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB/nYFYv54skMy2Q4FiiJh9422s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _мλцακΑκш():
    value = 134946
    text = __import__('base64').b64decode('aHJKVWZKODBsSVhpcU5lYzUyU04=').decode('utf-8')
    total = value + len(text)
    return total

def _жιΙЬцэЩЩлжьН():
    value = 553175
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRbNSGAwwZwNAyz351iBLRQ40V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХοкΜΑλΡЩαдХαωВлο():
    value = 409197
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBfVXEgK0IoOKyu0kH6oDHZ5xX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗτехяβιСΜΕх():
    value = 993882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwreUXU97IsiDAG2mHq+JS0bsWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7897 = 371
        pass
        pass
    return total

def _ЩΞασΧыВжффъеж():
    value = 101611
    text = __import__('base64').b64decode('azJ6cDZ6cWxGQXBKOWRVVndSU1E=').decode('utf-8')
    total = value + len(text)
    return total

def _АζΛкЗХмОФчΥΩ():
    if False and True:
        889
        878
    value = 55935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQreYQkN7acxKiim0nC1FXI5t1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пρчГНΕЖтн():
    if 83 * 12 < 0:
        961
    value = 48642
    if 97 * 77 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyjLXF5ty6wJMyOa3GK+I3Z34lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΜжΦθγκЙГ():
    if 13 * 76 < 0:
        _dead_8667 = 634
        _dead_1273 = 449
    value = 571325
    if 4 * 29 < 0:
        _dead_5198 = 126
        pass
    text = __import__('base64').b64decode('QUlPbXMyZjR3Y3AwSGFZaXhGcU0=').decode('utf-8')
    if len('') > 0:
        267
    total = value + len(text)
    return total

def _ΔпλΞυδоЕФКшμШЛбη():
    value = 524127
    text = __import__('base64').b64decode('Q3d0eklJMDI5cjVLOHdvZ1ExaEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪυЪФнΣθЪтμсεм():
    value = 870240
    if 83 * 79 < 0:
        _dead_6112 = 971
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az+yendt/fsZKT6Gxnm1Pyx+vG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2593 = 378
        732
    total = value + len(text)
    return total

def _ΡΘнтΠЛчΒяχЖ():
    value = 739961
    text = __import__('base64').b64decode('ZlNvTnJvWUxSTnRabDM1bEY3SEk=').decode('utf-8')
    total = value + len(text)
    return total

def _φмΓΔκΓфκ():
    value = 150279
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('Q3VwWGFBTVFJYVZuWDdWZkxzcFo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        634
        _dead_7467 = 440
        441
    return total

def _ЦэфΝМЬдφЗ():
    value = 290026
    if 3 * 56 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn3DWHhhqItUalyL/Ae2FQoe4no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΤшΘΑБΨлДрТЯЩ():
    value = 616405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHnKemlhrJEsIgKAnXeGNX0900Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вШΣЯЕвΣΨВπБχафσμ():
    value = 756368
    text = __import__('base64').b64decode('WnJFWUJNSjVmYnlBRWhrckpIN2c=').decode('utf-8')
    total = value + len(text)
    if 92 * 61 < 0:
        pass
        _dead_4245 = 663
    return total

def _οЗчЛСНГγΝзяπЛмε():
    value = 286093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwjHQX9v1p4xACKg/weBDhQq8GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 47 * 97 < 0:
        pass
        _dead_8622 = 713
    return total

def _ΔЮφωЩЧΕЬξτ():
    value = 982579
    if False and True:
        633
        267
        870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnjQdkI9xqk1Gxqx8nCiDQM28GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 79 * 41 < 0:
        649
        157
        pass
    total = value + len(text)
    return total

def _цΙΕΣΞλЬЛХχπмΣ():
    value = 932528
    text = __import__('base64').b64decode('Z2pqQWF6MmxfdV9nV0lRaVh5QXA=').decode('utf-8')
    if len('') > 0:
        254
        pass
        _dead_2146 = 981
    total = value + len(text)
    return total

def _збкιΓΒγС():
    if False and True:
        _dead_9264 = 206
    value = 662065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC3KXmsTzJEILA6G6VeeZQ0bx28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 73 < 0:
        _dead_4490 = 347
        _dead_2114 = 133
    total = value + len(text)
    return total

def _диΦαΘΘДФу():
    value = 695773
    text = __import__('base64').b64decode('VWNKeVZHdGdWVTV2eXl4UGtfaU8=').decode('utf-8')
    total = value + len(text)
    return total

def _АЫΜψДяНΥЩαΖΚΖΥ():
    value = 322629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSXMXUM624AMLge263G4ZHU2wko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΖΦΩχаιВбЩθЦшσ():
    value = 891717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kn7HTVdor44zPw735gG0CxcQx30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9165 = 205
    return total

def _хъΝСЛтхТЗ():
    value = 199215
    text = __import__('base64').b64decode('dEc4QU0xZHdoeUd4WWdfdlp2T1M=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6030 = 642
    return total

def _ηжςфюьеВθλυαРЫ():
    value = 992230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ni7xP1YM/4IpPRix51yfOTAI/Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 27 < 0:
        971
    total = value + len(text)
    return total

def _пнГЮЩУΘыΠχ():
    value = 463768
    if len('') > 0:
        _dead_7940 = 521
        _dead_9397 = 67
    text = __import__('base64').b64decode('dGlPS2ZqZnZwMjVaZER3WE5rZjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ХШЫΨиПφЛЙΛПЖС():
    value = 389190
    if False and True:
        _dead_9929 = 932
    text = __import__('base64').b64decode('czk5Q19DR3Z6djlUUzNaSDlPYUU=').decode('utf-8')
    if 57 * 27 < 0:
        _dead_7675 = 98
        41
    total = value + len(text)
    if len('') > 0:
        _dead_2906 = 523
    return total

def _μκψпрнЬУχζ():
    value = 881461
    text = __import__('base64').b64decode('VG1KU1Q1WFFqbHdNZ0h1SmRmQ3I=').decode('utf-8')
    total = value + len(text)
    return total

def _μχΕцτзыЦабβИ():
    value = 9601
    if False and True:
        225
        654
        395
    text = __import__('base64').b64decode('YklMenIzNEdDdEcwc3F0UlE4Z3A=').decode('utf-8')
    if 19 * 14 < 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_9370 = 226
    return total

def _μлЮсящρВσщ():
    value = 832233
    if 17 * 44 < 0:
        pass
    text = __import__('base64').b64decode('R1ZVSnNYek16QmV1VXRTN3hPZUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ОЫвмΕГОΦщмРΔΦБσ():
    value = 482198
    if 41 * 34 < 0:
        _dead_9870 = 245
    text = __import__('base64').b64decode('YmJ0ekZHUzdyajZvbFhkUUt6ZU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΜьЦсΖЖτΤ():
    if False and True:
        pass
    value = 858466
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('UVFkNzROY1pXZE1yRW9wbHc0eng=').decode('utf-8')
    if len('') > 0:
        _dead_1474 = 297
        983
        pass
    total = value + len(text)
    if len('') > 0:
        140
        pass
        _dead_3324 = 343
    return total

def _ηЖαгсйκЮ():
    value = 451765
    text = __import__('base64').b64decode('Z2tXRGU2dFFCR2FBME1EZHBMNXQ=').decode('utf-8')
    total = value + len(text)
    if 79 * 84 < 0:
        884
        157
    return total

def _ПεεэκΛыΛαэШлο():
    value = 867593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD7wQlst6acSLiqcz3O5Y3UsvWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛσψωПΗбИ():
    if 9 * 53 < 0:
        _dead_2001 = 773
        pass
    value = 177497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCPQYXs9q4sKLlvynWTHOhwW83w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 84 * 27 < 0:
        _dead_3243 = 865
        pass
        pass
    return total

def _ЩΞεЦΥγΜНйΟПю():
    value = 261452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQTzQwVrwYUAPlyt/UCmIwoYx2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΕΘΚρλбЛВз():
    value = 229568
    text = __import__('base64').b64decode('aGlpOEJ6eDlFRllTZWFQMjU2ZjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡεШсΠΗмΖтРΡЯΩР():
    value = 84876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3vidFY475gZDQqLmXu2NjMD3Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦщзсеРРНρЦνблμЛφ():
    value = 690442
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nn3leAU19KJTCja53FrDJXIn9Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΘоЦΚИеΔ():
    value = 398879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhnUP2gT26VQACeRmnjEDj8Gxzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 58 < 0:
        245
    total = value + len(text)
    if 64 * 25 < 0:
        _dead_4320 = 525
        pass
    return total

def _ЧΔяббЬζΕиοΑ():
    value = 63023
    if False and True:
        _dead_1370 = 42
        954
        pass
    text = __import__('base64').b64decode('RjVZVEdWbTZKTndndFYybkpOMUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞηΙΙδΔкρйΦ():
    value = 77681
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAjpZX816v8tYl6N/m+dDnQV8EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2468 = 316
        327
        _dead_3877 = 891
    total = value + len(text)
    if len('') > 0:
        _dead_1222 = 192
        _dead_2476 = 797
    return total

def _дΘЧξЭβЙεЬж():
    value = 750714
    text = __import__('base64').b64decode('UXQydTF4QWk2cDg0U0JqT1VfSTE=').decode('utf-8')
    if 91 * 16 < 0:
        _dead_3779 = 156
        788
        _dead_8349 = 789
    total = value + len(text)
    return total

def _ПΧФσχσΧВκЬТй():
    if False and True:
        _dead_4400 = 290
        897
        pass
    value = 898837
    if 76 * 88 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQLBXEAc+K47Eizw4nymZDYC6H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эфГмхЫВшВτЕтДθБε():
    if 44 * 40 < 0:
        pass
        332
    value = 13669
    if len('') > 0:
        pass
        221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwngdEMO8P4sPQqu0QaSLS5/xWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        275
        pass
    total = value + len(text)
    return total

def _ΤУΑКШвжνЬШΙЕΗ():
    value = 281850
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTm3X1Uox6QsaRqo5Uy+CwwNtng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сιЗОζΟяюлп():
    value = 456997
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDnCVnIop7IQOF2GxnCSYX06skY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΨцьεПЫδΘтЭХДЗЖΞ():
    value = 62623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCnNS2cK9KQALzaG7F+BMiQ2x0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υЪяΟΙΕμЧμдΒ():
    value = 796480
    text = __import__('base64').b64decode('UXhCSGlUYko3bnRSTFpVQkNKM24=').decode('utf-8')
    total = value + len(text)
    return total

def _φτУΥдΤΟГбГΤΕ():
    if False and True:
        pass
    value = 153495
    text = __import__('base64').b64decode('SGJ3RURWZU5GYWd6aXZzODFuZ08=').decode('utf-8')
    if len('') > 0:
        _dead_7113 = 830
        _dead_4338 = 866
        135
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_3286 = 710
    return total

def _ΔзиΝтьЦΟΖγ():
    value = 77649
    text = __import__('base64').b64decode('QVk5SWExMGpMUnVIb3Y0Y0lGOHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЯОжЯΥВбЧэХхПЙΙΑ():
    value = 841026
    text = __import__('base64').b64decode('VW9JQjQ3Rm9JejJsckF6RFdPNVI=').decode('utf-8')
    if 87 * 28 < 0:
        548
        838
        912
    total = value + len(text)
    return total

def _яПκΠсАЬΧЖнνДНδч():
    value = 997814
    text = __import__('base64').b64decode('TThrVl95UFJ1MEFJazBJSTAyU2M=').decode('utf-8')
    total = value + len(text)
    return total

def _пρφАчдНΧΩб():
    value = 380075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSPCW1k6p/BbPD+CnmODZz0G508='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οыЗξπлЪУУ():
    if False and True:
        447
        pass
        _dead_5213 = 648
    value = 19676
    text = __import__('base64').b64decode('emdiWnpkMTF1TjNObThreTAzMDM=').decode('utf-8')
    if 46 * 84 < 0:
        pass
        315
        748
    total = value + len(text)
    return total

def _ΕРΤΩΡΓΠΓ():
    value = 756233
    if len('') > 0:
        pass
        _dead_6185 = 940
        _dead_3956 = 50
    text = __import__('base64').b64decode('RlhfUEM3b0pzeE9wV1pDa2pLSUI=').decode('utf-8')
    total = value + len(text)
    if 59 * 9 < 0:
        _dead_7883 = 483
        _dead_3419 = 603
    return total

def _ΝУдσВБЦК():
    value = 681368
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HA3JZVs297wLKTiCwlrBZhA920U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΖЫХКАнШΤ():
    value = 644236
    text = __import__('base64').b64decode('eDMydFBkc1dDdjM4bDJxQkdQX3E=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        677
        721
        pass
    return total

def _ЭαФαΔНσжЛС():
    value = 163690
    text = __import__('base64').b64decode('YnZ4QkdKMjJ5YWhZWWpoZ0R1eXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЩЪЬΧмνΘψиЩ():
    value = 593487
    if 32 * 42 < 0:
        613
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AS7eRAQ1z5tXGQewyWepIBUFt0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7554 = 210
        3
        22
    return total

def _ΜИиэДХΛГΟШгж():
    value = 303094
    if 62 * 87 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyHGZnII3Ys5Gx6p5VKAGB81wUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 66 * 68 < 0:
        pass
        _dead_2228 = 395
    return total

def _γлЩЛЕъνδψΖμЦШЪВЬ():
    value = 820260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwnTQEcwzJhRKxWOyVy4BCA96Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НνθуΝηЫΤл():
    if 17 * 99 < 0:
        pass
        _dead_3301 = 100
        358
    value = 191961
    if 74 * 62 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzW1R1sN7f8VHVaS0G6aED0Y4jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 43 * 3 < 0:
        pass
        552
    total = value + len(text)
    return total

def _αкРыыΞθВПХЮΧΟ():
    value = 737285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA7tSlwz/P4QEDeKmA+kLh18yDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        154
    return total

def _ΟαΘλвνξзйξЛσЧρ():
    value = 796024
    text = __import__('base64').b64decode('Rk5aWVZQTE12bVBMRWhZNTFfcmY=').decode('utf-8')
    total = value + len(text)
    return total

def _лΕΑΛбРЖилΔΘФΣНΤ():
    if 88 * 7 < 0:
        _dead_8096 = 555
        pass
    value = 754894
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD6xXm5o9f8nCjCu/XiiGysV4j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_1850 = 7
        803
    total = value + len(text)
    return total

def _сωβМирВζМσΝцыιμη():
    value = 631642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyjAR0Jtr60UMDzyzFi1AhcJ3Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        421
        pass
    return total

def _ΓюксИαщТРγφΘБ():
    value = 699385
    text = __import__('base64').b64decode('cm91Q2pjYWFOY1Y2YWhsU2VKSGI=').decode('utf-8')
    total = value + len(text)
    return total

def _дНΤъΓтσрОоъИΒ():
    value = 608445
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAL2XwcU64AZawaWnnicNhB8yF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИЬΨцЦΧтΔΠЮςу():
    value = 424969
    if len('') > 0:
        _dead_3954 = 657
        _dead_1679 = 383
    text = __import__('base64').b64decode('cTA0S3hNMnI2NFk0NXU1YU9TNDQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        26
        248
    return total

def _χфрΚΖУθΓπОняΨ():
    value = 496862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ewm9bWc+7K0UEViX32HGBH0M12E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γшΕюцφΑπЬуΠиξО():
    value = 527665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQK1dGAo1Z01IzqwzAKSFj8LvHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        855
        _dead_7880 = 921
        _dead_9939 = 289
    return total

def _υфΝъςΜΧгΠΔ():
    value = 485069
    text = __import__('base64').b64decode('R21NUmtOZE5hSm1lSlAwem5pdVo=').decode('utf-8')
    if False and True:
        _dead_9116 = 657
        621
        pass
    total = value + len(text)
    return total

def _ΘεΣыτЫэΓьЕ():
    if 87 * 95 < 0:
        pass
        pass
        _dead_9820 = 146
    value = 851368
    if len('') > 0:
        pass
        68
        394
    text = __import__('base64').b64decode('dmRfZ1VHY1FOel9pT2t3a2E1d1M=').decode('utf-8')
    if len('') > 0:
        775
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
        451
        _dead_5685 = 388
    return total

def _ΦйъББΕАЫΚφ():
    value = 313065
    text = __import__('base64').b64decode('cEdVSDBCWW8yQ0xEVDFuTzNWS0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _еюйθΔχτуХταΦωХ():
    value = 414623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Agzod0Ub6oYzHQCTwgaGFy0j0To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 63 < 0:
        941
    total = value + len(text)
    return total

def _ξΤэКАиаβьЮδ():
    value = 246919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR3PWnoU1rgTCjaM7neWGQAi6mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьртяЦжхκбыψ():
    value = 974325
    text = __import__('base64').b64decode('RVhFVlFWM3Jnb2FqRkNBeXd4NmU=').decode('utf-8')
    total = value + len(text)
    return total

def _КκВΩХЭзρмуДπрэЗ():
    value = 202747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHvqRF4oppsQEh+g8g+BPR12/Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 6 * 99 < 0:
        pass
    return total

def _ЩГлмФЖσаэьοлЪΑЛк():
    value = 769658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjb8TGEUzqE1MiOb4G6hBnM/910='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оεЮδжаςжζΛ():
    if 75 * 86 < 0:
        pass
        704
    value = 708581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXzeOVJr+K1WADm54EG4Yxp8wFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _φчδбςΧοБζιЦΔι():
    value = 799601
    if len('') > 0:
        pass
        805
        _dead_9369 = 23
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjjnf3cg7IkBHyyr2XOJDAwItTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НκшямΞβгДΟл():
    value = 355385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRnRP2M82aNTOwyA7HueYnEA9lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΡЫθθΚтЛ():
    value = 538999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cgj2R1ATrYw0Ch+E3VKyLQIXtWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚзαХЩЮмΩΩΟΨΩчχ():
    if len('') > 0:
        _dead_3249 = 614
        pass
    value = 24969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn/JRAgT05cUMjaanUWADHIk4Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΑЕΝЙΘρτΣф():
    value = 779223
    if 49 * 39 < 0:
        _dead_1646 = 397
        _dead_2097 = 228
    text = __import__('base64').b64decode('eTJKeGdxSFBadWVoYjNFdmU1X3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΡμΠφОЕΨпΘКΖЗю():
    value = 598352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH3jZFkbwa4JHDaQkXKHFj815UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭδξЯжыΓτР():
    value = 534569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwW2Wglq6YYaCVqq+lCFYhp6sDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рκЩςцНΚМψюΤ():
    if len('') > 0:
        _dead_7692 = 485
        _dead_1569 = 539
    value = 433991
    if len('') > 0:
        _dead_7305 = 75
    text = __import__('base64').b64decode('Sk00WndPNGhUZXZTTFZnbVV2Y1c=').decode('utf-8')
    if False and True:
        pass
        _dead_4168 = 967
        pass
    total = value + len(text)
    return total

def _φИШбΚДμΑфаζ():
    if 94 * 42 < 0:
        973
    value = 956426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A37Ifmg41qc0P161+keaBT8p4ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗЗΣуΛнΑΧσйвΨΕ():
    value = 857438
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAC0Q3k2yvgMPV37zXqVIDN3vG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жδΛγНРζХεΓМПЮΣХХ():
    value = 730074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgrJPwIU+f4nOQWm6nGgFio45XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φРΔιτБεслдпфЯΑ():
    value = 209937
    text = __import__('base64').b64decode('STl2Rm1lRnUwcEtBMVhGOGcwVHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡпβРыχυΧтР():
    value = 467423
    text = __import__('base64').b64decode('YThOcEQ0UXpBcmFiY0dXNkdKcW8=').decode('utf-8')
    total = value + len(text)
    return total

def _СчγθвΓΜУ():
    value = 189996
    text = __import__('base64').b64decode('VTlOODRYVjJrRndPZHNLVU9PVUY=').decode('utf-8')
    total = value + len(text)
    return total

def _рмХРκροΡтψы():
    value = 852274
    text = __import__('base64').b64decode('b2NXQ0VPMllnOVRmR1BHTXp1M18=').decode('utf-8')
    if len('') > 0:
        pass
        213
        pass
    total = value + len(text)
    if 16 * 50 < 0:
        pass
        _dead_4831 = 147
    return total

def _щЙΕврюωеГхЫσЮ():
    value = 400791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NATgPXMc7a0CEyKHw3myGxINyEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λψΣΖαщэОΡЮμΤ():
    if len('') > 0:
        12
        877
    value = 475349
    text = __import__('base64').b64decode('dGJmUDh6a1JMclRtVkYzRU4ydDU=').decode('utf-8')
    total = value + len(text)
    return total

def _жКοΛΣТβθ():
    value = 11475
    text = __import__('base64').b64decode('UFd6UnpWUVprT3l1YWd5RVZNcms=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 8 * 79 < 0:
        _dead_3470 = 888
    return total

def _ФχуΑΑПпΛаζВХЫ():
    value = 272950
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCHLaEAt//8JNReCnG+yAwgZ/T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τМЪЪуЫэкσ():
    value = 439897
    if False and True:
        _dead_6374 = 756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXr1QQBpwa8aCz2cx1/EEykr5Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФρШщγψдзΗι():
    value = 330811
    text = __import__('base64').b64decode('UVB6S3NwRFh2em5zZlZuc2FrVVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔТΖΙтюσТхх():
    if len('') > 0:
        _dead_1291 = 227
        pass
    value = 739507
    text = __import__('base64').b64decode('b0ZRd1EwazV2R3ZQX1BTQ2JfODU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6531 = 661
    return total

def _ВΘЦωπΨΘЪЩΞц():
    value = 349312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzzzaEtv/ZAhKgqP8EPGLSo2vF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟХрпΚМφΒГ():
    value = 147414
    text = __import__('base64').b64decode('ek4zSWowOHJKSFVPMmpGVmJ5bjU=').decode('utf-8')
    total = value + len(text)
    return total

def _аамНйБУяА():
    value = 784414
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3+xbERh2Zg7ICubzWCyHBEQw1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЧаТπНνнΜνΦКЯεзζ():
    value = 918715
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyTPVmM97b4GGTmM+kCpYDEJzXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 48 < 0:
        pass
        _dead_9178 = 935
    total = value + len(text)
    return total

def _ΒШβфТшτВ():
    if 66 * 74 < 0:
        857
        pass
    value = 843893
    if len('') > 0:
        735
        938
        _dead_5030 = 987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NC3RZ1U876cWKzecmW6gOiQG/jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρУюψОθИπрΩξкΟφη():
    if 94 * 16 < 0:
        pass
        _dead_8376 = 609
    value = 587965
    if len('') > 0:
        726
        _dead_4128 = 612
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXnte2lo8LgiNjeZnF+nMnAnw1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХεмФуΨЮυζΜξоΥъ():
    value = 325005
    text = __import__('base64').b64decode('dzkyVEFpNk5YV2k2SE01anc5cko=').decode('utf-8')
    total = value + len(text)
    return total

def _эιЕлЭσποΦу():
    value = 732548
    text = __import__('base64').b64decode('T3JwZlRDbUc2MEFaWFVSYkVLRVk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        708
    return total

def _бΚτуЗΘжΑФЛыбИ():
    value = 342771
    text = __import__('base64').b64decode('bE9Ba3ZlR1lPcTM1MFNYVmdRY2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ФтμПЛΖςоРУθПлЧвς():
    value = 560149
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnvSTGM1z4oAPDe6w0GoGzwd4FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЖягηШТТχ():
    value = 231060
    if len('') > 0:
        pass
        535
        607
    text = __import__('base64').b64decode('ZENWbWhOSWVHTmtvN1VsVGVhcEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΔζиΛрΠоρъаΨмρн():
    if False and True:
        471
        _dead_7671 = 996
        _dead_1096 = 361
    value = 313989
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxzCP2QG0owAYh658WO1AhYit2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛяδНζΛΖШчшУ():
    value = 120232
    if 12 * 22 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQTUQGYp+Y0XHgL10kWAPjM2vFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        944
        pass
        pass
    total = value + len(text)
    return total

def _ХνωТΗлξΝТΔΜ():
    if len('') > 0:
        _dead_4708 = 75
        _dead_1223 = 209
    value = 925733
    if len('') > 0:
        476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAC1Wnsz9o87Mj2p4G+pPhc+8X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΚСЯПСтβДιЪ():
    value = 579169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX/XaG4x7bIVazyIwFqmLSw44H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОлхПΠφАΩγЫз():
    value = 921711
    text = __import__('base64').b64decode('ZVNPWVJyblRITFQzNVZUX1pGQ3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _вΚИяьГиνф():
    value = 317505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KC3eXEI897A7Hlyc+UyoFxIixks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝλэШΨЛΑΣН():
    value = 97886
    text = __import__('base64').b64decode('dDkydmVkNUVORkR4WW5uSjlWTVI=').decode('utf-8')
    if len('') > 0:
        246
    total = value + len(text)
    if 14 * 30 < 0:
        774
        _dead_5543 = 748
        558
    return total

def _ЛЮНИЛζнсуςоκЯжцΣ():
    if False and True:
        654
        _dead_3731 = 425
        387
    value = 185172
    if False and True:
        pass
        120
    text = __import__('base64').b64decode('cXJUNGtBNVZBVk9hcUlMcVJ0ZWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ωγωяξψξТκЮΑжДιО():
    if len('') > 0:
        _dead_7065 = 53
    value = 775096
    text = __import__('base64').b64decode('QWNDSXd2WExrXzRfS2J6RmJfWVU=').decode('utf-8')
    total = value + len(text)
    return total

def _жΩΒюλΨγр():
    value = 68441
    text = __import__('base64').b64decode('bW95aDZqS0tieGY4eEI0T2ZrbEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ηщтυΞαТΤ():
    value = 116390
    text = __import__('base64').b64decode('cGtOd2xpVkRjMFpucnptWVJ5bXA=').decode('utf-8')
    total = value + len(text)
    return total

def _щλжжυщΓпжфэСС():
    value = 245564
    if len('') > 0:
        _dead_6659 = 620
        163
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L372PUkIr74rKR2OxQSgIXAG4Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 26 * 57 < 0:
        _dead_2362 = 388
        pass
    total = value + len(text)
    return total

def _ΣЦЭэβξЭηΠωΑЧΙбΚΨ():
    if 91 * 16 < 0:
        pass
    value = 579779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lnf3d0hp+rEiHQKWzU+JOh93zmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 52 * 58 < 0:
        _dead_2465 = 612
        549
        pass
    total = value + len(text)
    return total

def _ГΓΦτζΚНΠτΕΒεзс():
    if len('') > 0:
        387
        _dead_8585 = 305
        472
    value = 878706
    if len('') > 0:
        582
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXb3Y3xh+KIZIASc+He/bXQ2wFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3369 = 875
        _dead_5393 = 948
    return total

def _йслЙφЫΤОпЪλгхыοэ():
    if 48 * 20 < 0:
        pass
        898
    value = 954863
    if 70 * 10 < 0:
        287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwPJTGkI7KA3FgK07ASqASsg6n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦσΦшξЧШΖеЮθяμ():
    value = 665312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHvHdFg9yaINbFaQ63OEM3c18Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('cg==').decode('utf-8'))
if 47 * 49 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()