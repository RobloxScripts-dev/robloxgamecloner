#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _νЪΝΖΔоΨцΝШτ():
    value = 751218
    text = __import__('base64').b64decode('bGgwOUVFc3IwQVJfcG5UZ2ZzZlI=').decode('utf-8')
    if 36 * 46 < 0:
        _dead_4250 = 33
        482
        _dead_3851 = 997
    total = value + len(text)
    return total

def _КФΠΓΥΘаΩУйβЖ():
    if False and True:
        pass
        pass
    value = 703680
    text = __import__('base64').b64decode('eWRmU3R2aTdNcDE0eUJqd1FLUUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦκξΠщЪαМπΜ():
    value = 598824
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxjhfQht+f8uNg2UwFS/Ng893mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξжеαЧНμнРΞЧΙпЫы():
    value = 180690
    text = __import__('base64').b64decode('WDJmeXkwVUFBTE9nTEIzVmFHR1o=').decode('utf-8')
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        625
        750
        pass
    return total

def _ЦωЦοХВЭΟД():
    value = 465292
    if 97 * 57 < 0:
        226
        285
        pass
    text = __import__('base64').b64decode('R1lnaUtDM2hSYm9kdG83cTdBY0Y=').decode('utf-8')
    if 30 * 95 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        718
    return total

def _дуТИБбПφкΝ():
    value = 833495
    text = __import__('base64').b64decode('ZmpqbWkzV0Y1bzh6Qml6Vmc3Y0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕЙΑυУθЩμΛαз():
    value = 733396
    text = __import__('base64').b64decode('ZTA2M1RxYmlpaVp1NFNDamV0Yms=').decode('utf-8')
    total = value + len(text)
    return total

def _ХδκχΒФπΩζбнд():
    value = 648878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3jTPHhtzbkKAlmt3UOgJ3UE8Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СдтΚЩΩгβΓΦн():
    value = 358821
    if False and True:
        pass
        _dead_5654 = 161
    text = __import__('base64').b64decode('SDNBVW83R1ZaU1pHT21FYk9ZNGg=').decode('utf-8')
    if 87 * 58 < 0:
        553
        181
        _dead_5867 = 129
    total = value + len(text)
    return total

def _ΑЖΧЬтπжατкМхСΣ():
    if len('') > 0:
        pass
        763
        _dead_6402 = 285
    value = 819290
    text = __import__('base64').b64decode('T2tVZ1p4bl85QTFBYVBWUGlZVEY=').decode('utf-8')
    total = value + len(text)
    return total

def _лсжшЧΛМτШБΕΤχ():
    value = 691579
    text = __import__('base64').b64decode('b2xuZnRIRzNQellFYmZHeXV5alk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕЬбГфγΓβА():
    value = 886943
    text = __import__('base64').b64decode('R2xES1l0OXJUSjhjbklmNVlYd0w=').decode('utf-8')
    if 31 * 23 < 0:
        _dead_9156 = 547
        pass
    total = value + len(text)
    if len('') > 0:
        560
        _dead_9551 = 877
    return total

def _РОмφясβЦνхсЖО():
    value = 303242
    text = __import__('base64').b64decode('cWlVRGFUS0lURkw0bWpURXFsOVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ηэΘηгеюξμбνςу():
    value = 207859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAvmbWsSxq4IPlrymAa3IQIW4Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5380 = 631
        _dead_2418 = 834
    total = value + len(text)
    return total

def _ЦюΞБДΕοΙσВως():
    value = 543622
    text = __import__('base64').b64decode('VmdRcDg5eUxLSEhVcWJLTHpjMmI=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΦМδОжцйлзΔРТβТ():
    value = 751840
    text = __import__('base64').b64decode('dTRqbEtBZFhfM1JPRHNjWDR5eEI=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЮζιКБкκГ():
    value = 818180
    if 46 * 78 < 0:
        _dead_5359 = 278
        763
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHfRZ3Q1+KwoaQ6HxALBJyYZ0Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЛΖгзΞйεОэФрρβο():
    value = 848296
    text = __import__('base64').b64decode('b2RmWkMyZ2xtMDh0Uk1HeXdTXzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΒСЬоощΝζΗэФАф():
    value = 685534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRnre0AL5II1DFyL92WJH3cQ218='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧОСГΕςΘγЗилΡб():
    value = 219958
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxjiXFYaqpkUAx6Gz2OcZiE10lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МкШэДюΗЙΦцΚ():
    value = 366111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgjvPwkfp6wpIC7y5U+HACI4sX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 94 < 0:
        pass
        _dead_4186 = 942
        _dead_2188 = 422
    total = value + len(text)
    if 21 * 94 < 0:
        _dead_3243 = 360
    return total

def _ЭМΦКзяДκΞ():
    if len('') > 0:
        149
        pass
        _dead_5351 = 327
    value = 149609
    if False and True:
        pass
        _dead_7308 = 532
        pass
    text = __import__('base64').b64decode('TE9UUGpBd01BcThhRUlodVJkN28=').decode('utf-8')
    if len('') > 0:
        724
        667
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЩΙЫλНκΧμЖЯΧ():
    value = 806434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwTSYWIYzLAxFCKWmGK4DBQF8UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чφΤАβρΦоψ():
    if False and True:
        527
    value = 780871
    if 84 * 38 < 0:
        _dead_1223 = 569
        125
        371
    text = __import__('base64').b64decode('SWZ5OWFLQzhHT09vRjhtdVJ6cUQ=').decode('utf-8')
    total = value + len(text)
    if 58 * 12 < 0:
        pass
    return total

def _ΚАτжПкωΠκЮυ():
    if len('') > 0:
        694
        pass
        _dead_1298 = 235
    value = 197042
    text = __import__('base64').b64decode('c184eUk1dW5QMGNUUF9vZXhad18=').decode('utf-8')
    total = value + len(text)
    return total

def _УЭΞΖдЬяΤ():
    value = 718437
    if len('') > 0:
        _dead_9813 = 643
    text = __import__('base64').b64decode('QnZhYVh0Mk9rdDhiNUpaT0wyQ2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _КχмωοΑΚТωΖ():
    if 87 * 55 < 0:
        129
    value = 950199
    text = __import__('base64').b64decode('Qm9oYm53eEI3UVVqVzIwYV9od3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΞуФшлιГΦ():
    if False and True:
        pass
        _dead_2718 = 335
        _dead_8799 = 447
    value = 226200
    text = __import__('base64').b64decode('bUZZUV9DWEhnMVRHOEVwem95eTM=').decode('utf-8')
    total = value + len(text)
    return total

def _лοΛΥлВΙбЧΟθ():
    value = 600680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHvySXVp6bovOBiT/EenDR190Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_2975 = 269
    total = value + len(text)
    return total

def _ЗККιНгСφΞту():
    value = 123918
    if 30 * 42 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh/bT1dq+JwGNDm3z3OlPBAMym0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТγςдтЯзαлυкц():
    value = 868187
    text = __import__('base64').b64decode('Z1gwbXZvMnhINDBLcmlCZ1JZWGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ДцοΕъΙЧКьхыйзюл():
    if 3 * 21 < 0:
        425
        _dead_2086 = 306
        pass
    value = 811784
    text = __import__('base64').b64decode('V0JhQTFWT3BRMnAzY18zeWVNU0E=').decode('utf-8')
    total = value + len(text)
    if 55 * 66 < 0:
        907
        _dead_6819 = 186
    return total

def _ИαжΨЛβΔЪШсУσцъ():
    if False and True:
        683
    value = 575858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT38fV1p0r5Xby72zWXFLD090Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 44 * 37 < 0:
        _dead_8175 = 902
        484
        447
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _οθчдХЬκκ():
    value = 874566
    text = __import__('base64').b64decode('WWllYWxEOXc1S2FsUFc3c25zWXo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_5311 = 973
        284
    return total

def _ΖТλЯВЧςΤΥТ():
    value = 568838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAXyamdr3ZwTEV3z8H3EMDQEyDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дАΤшββТфЙΞψх():
    value = 807311
    text = __import__('base64').b64decode('TWJyRDhRMFJVNFlCVGs4aHBKWXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЦιφσАβизΦ():
    value = 808909
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyDwOWdh3/AEF1iJ93GlAwIj51Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фРГδюΦρзοσшзΣ():
    value = 919170
    text = __import__('base64').b64decode('WU51MDBBTG02VWI4aklXVUZjWVE=').decode('utf-8')
    if 69 * 73 < 0:
        _dead_3108 = 458
        _dead_5252 = 449
    total = value + len(text)
    return total

def _ГЧωРшλЯΟещ():
    value = 921875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3vOWgcy1/wyEAaln2+zOwsF93g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дглиХχΕψζ():
    value = 868080
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('cVJ1VElydHdqaXFpeVNYN29kazQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ъΞΙιδΜξΞ():
    value = 410567
    text = __import__('base64').b64decode('Q3dUY3dwcWRFTGZUUVpHd2hjcEo=').decode('utf-8')
    total = value + len(text)
    if 33 * 91 < 0:
        _dead_9222 = 940
        552
        _dead_5092 = 232
    return total

def _ηлйΡΝФгаΞΚрΒъцΡ():
    value = 402521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyrvXnkw1JhRbz2t+167ZDYC8l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫςδмшοψйΦшгαπ():
    if 75 * 62 < 0:
        _dead_2132 = 406
        _dead_5479 = 925
        pass
    value = 54918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCbHQWls5IQtCzyCw16zbBYG1mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΔΝиОЪбΕ():
    value = 911528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSrsf1VtqfBSPy2v7FKvZSQ90z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νЧиаΔЫГΤ():
    value = 585526
    text = __import__('base64').b64decode('RWQ3cXRKaVVCZzhZb3R0dFUzd0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠνΛΟσΩμΗхЛЕΜЦχш():
    value = 82032
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQ3TSXoTy7sHHzq54FSXYB8bykw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιепДЖΗσМНлнКм():
    if False and True:
        pass
        632
        _dead_3208 = 112
    value = 312404
    if False and True:
        440
        _dead_3132 = 378
        _dead_1858 = 159
    text = __import__('base64').b64decode('YXpGd2pNbU9CZ3ZRMTBlUlFvT0M=').decode('utf-8')
    if 86 * 99 < 0:
        pass
    total = value + len(text)
    return total

def _ЯЮσЯΔпΨЕМ():
    value = 913853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD33YlY80bEGNTau+2KjJRQB1T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 12 * 39 < 0:
        pass
    return total

def _юΜлΕДЫΥξ():
    value = 369988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NX3+WF827PtbNwj3mEWcOgkl1Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΙαтΧОζК():
    if len('') > 0:
        _dead_1949 = 542
        _dead_4334 = 286
        _dead_3588 = 881
    value = 255357
    text = __import__('base64').b64decode('c3VZREpGdWRvQVdRejNqYWY5ZmY=').decode('utf-8')
    total = value + len(text)
    return total

def _γиΜгαφЗЕтЩΒοэΧьн():
    if False and True:
        pass
    value = 962078
    text = __import__('base64').b64decode('UEJpcEFGZFl1VkpycXpoMDdCcUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _еЧΦπΞЬЮр():
    if False and True:
        337
        _dead_8448 = 764
    value = 178264
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M33yRQlr74MCbDn7wXXHP3wDx18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЛпОΠΚθηАΠЬэσσ():
    value = 193777
    text = __import__('base64').b64decode('ZE0yRXdON3VkbUtLRExuNUpoSXo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        944
        _dead_5888 = 255
        _dead_7815 = 24
    return total

def _εцΧЦмπЭыщΧфΧΤΘ():
    value = 598066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHb8PWU7r74gbQC12nGEFzAZ920='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωζГЫλяЪΥΕШН():
    if len('') > 0:
        934
        pass
    value = 619769
    text = __import__('base64').b64decode('UFNzbnJUaXI0Mk40aERIUHpLeW8=').decode('utf-8')
    total = value + len(text)
    return total

def _юПΒрУАσэиτИЛэ():
    value = 315073
    if False and True:
        _dead_6993 = 836
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwWyY0MX2JoFAyeInwSBbBUp6X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΔΖлршПКВНчΩξΑШщ():
    value = 281282
    if False and True:
        pass
        pass
        739
    text = __import__('base64').b64decode('UXp5UHY5STM3T2JwQTJUTnh4dV8=').decode('utf-8')
    if 78 * 85 < 0:
        477
        _dead_5648 = 679
        982
    total = value + len(text)
    return total

def _хЫΗδχъωαΗаЧ():
    value = 177940
    if False and True:
        pass
        _dead_9114 = 854
        512
    text = __import__('base64').b64decode('YkhSTERoemNRaUhlQWVCSFE4Mm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒχГωчεщдДΓг():
    value = 939926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCnxbFRopr8TahuVwHDAGgt58n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        974
    return total

def _κρрРМωбφтз():
    value = 807068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3bXVlMS/L47LyOw+WKcYBQV6Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зтφκсЩецιЗ():
    value = 62520
    if len('') > 0:
        _dead_7249 = 265
        pass
        _dead_9866 = 790
    text = __import__('base64').b64decode('amZxbE5GdDZid3JyQmIzNWVSaXg=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΘΤСеШОνЦΒλИΤ():
    value = 785272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyHNOEcP7foCGzacmkCZMBAW3Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4538 = 186
        pass
        _dead_2248 = 121
    total = value + len(text)
    if len('') > 0:
        _dead_6566 = 79
        366
        501
    return total

def _ВьФΞвщμьΒОфОю():
    value = 835525
    text = __import__('base64').b64decode('RG5la3ViR1VpU0VWNDhpZ2w3ZHc=').decode('utf-8')
    total = value + len(text)
    return total

def _МсПΑЪтΦΙωьξχ():
    value = 315803
    if 8 * 97 < 0:
        140
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXvINmNq7KwzK1uw5UbIAT8M4Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΙЗРУеψГцρочΖ():
    value = 181048
    text = __import__('base64').b64decode('TFR0ZVJwUTNsVmhZSmhoVkFSeEo=').decode('utf-8')
    total = value + len(text)
    return total

def _τШΜШΟσΛΓвЮΛЫηтЙ():
    if False and True:
        775
        pass
    value = 310951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ey3POVVhzLAFDAmz5X6nM3V63Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        955
        _dead_1388 = 795
    total = value + len(text)
    return total

def _ρΘЧΤςγЗςωйБΑ():
    value = 237412
    text = __import__('base64').b64decode('amc2NFl6RHJnR01idzBiV0lsR3M=').decode('utf-8')
    total = value + len(text)
    if False and True:
        485
        _dead_3097 = 649
    return total

def _ψτайΣβьξ():
    value = 537058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECH9e0kjypAoHDCc21S/PysMyks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4785 = 565
        825
        998
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΣЯЗЗΥηκхΚП():
    value = 72160
    text = __import__('base64').b64decode('Tm1sZEppUjJxTVdjTVg4OGs0UXg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        822
    return total

def _αЪΑЪЙЫчΥБΔ():
    value = 27169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah22R0k0y70wLDj6zA+ePD94xnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        341
        _dead_9147 = 469
    return total

def _ΔйыЗЬИΛА():
    value = 946767
    text = __import__('base64').b64decode('ZU5BT3dfWGRuNlBzdmtHYUtnUkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЕΗНψЮЕΞαРЙ():
    value = 164366
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgLPPlUK/7EEbgyF+lykYAMO6X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нμλλдЙшпФΤШΕНδ():
    value = 806970
    text = __import__('base64').b64decode('d2g5bUxiaTZWVUJBMDdlanhOWjE=').decode('utf-8')
    if len('') > 0:
        _dead_2250 = 999
        _dead_1894 = 797
        473
    total = value + len(text)
    return total

def _гъюΚΛчλκδьυγщη():
    value = 989221
    text = __import__('base64').b64decode('cm5CajJVeHNPNWFNU2VLdXNtZ0I=').decode('utf-8')
    total = value + len(text)
    return total

def _МУλΡιэдХξ():
    if len('') > 0:
        _dead_9749 = 70
    value = 252864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnayZEFo24tXPjq1m2OVARwf128='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КаХйΠГλοФδыφεν():
    if False and True:
        431
    value = 940401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhbTbAU8r6UVHAGOzlC6IxB/40M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 63 * 70 < 0:
        275
        _dead_5011 = 175
        pass
    return total

def _ЕρАбЛСХхЦψъшΧ():
    value = 817958
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSnlN38vzrAOCB+R4nOgES4V90w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΟЦцашρΒγ():
    value = 487151
    if False and True:
        pass
        _dead_5035 = 251
        _dead_2958 = 207
    text = __import__('base64').b64decode('SUNXbVpaVzU1NDdTR2ZBZUV0bUo=').decode('utf-8')
    total = value + len(text)
    return total

def _фЛχАиШψδρ():
    value = 284935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AR/qT1k1qbINECmSmFuvDRU2vVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шοДΓΔЬφΓΠ():
    value = 954369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyXWeGAUxJ43K1ev8WCzEgk+yGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йυИθежΣΖНЕ():
    value = 603246
    if len('') > 0:
        114
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iw3cWns+5rwwCD2lmF6pOjchsTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρωψНοШюι():
    value = 26741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh7WYgcUx6coFxykx2DCBXUa6UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        452
    return total

def _НЛΤΖΧюΟΜлΠΥΘпυξ():
    value = 815979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzfXP3ohzqUOOF+0/1WXHTUh028='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛкυРеюζШΕγыπэΞξΚ():
    value = 20889
    text = __import__('base64').b64decode('Z1k2ZTg5YV9rSllOUG00dW5xeVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ичжсЧθωΩюПкνΖΤυ():
    if False and True:
        728
    value = 741523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DB2xRgkL/7tTFC662123DnM73Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8701 = 610
        pass
    total = value + len(text)
    return total

def _ηωιОМΘИφПэъωЫθΞ():
    value = 673528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDbxaHI636MiNjyN8FWFYhUJ52Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БαΔЕЭκопдЬИбт():
    value = 623521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISW1YXY6qIE6MB+l/QazN3Ai0WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДηнзζщЯπпΩЙ():
    value = 469617
    text = __import__('base64').b64decode('QmM2aU5lMGJyRk1FN29kWTA4eFI=').decode('utf-8')
    total = value + len(text)
    return total

def _тЪδξрпφЗъ():
    value = 269917
    text = __import__('base64').b64decode('em1aVmNXbUl2eDZFWmttandzQmw=').decode('utf-8')
    if 5 * 84 < 0:
        _dead_3796 = 474
        pass
    total = value + len(text)
    return total

def _еΠгπЗΘгмиχцЙΝιΚ():
    value = 486144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex/iRGkD5/4baCyHxGSGJTw21G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓшΖσμИлδДВΓ():
    value = 657346
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzzseAg90/wFPTaq/GOVEyF/y30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΑОЧΕюМШиψρς():
    value = 62431
    text = __import__('base64').b64decode('WkwzTE5RZnZfdm5NeHhhX2cyY00=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔЖмКОьςаζ():
    value = 649567
    if False and True:
        _dead_7953 = 118
        373
    text = __import__('base64').b64decode('ck1lYXBjclVsb1g1anhmSjdFTzA=').decode('utf-8')
    if False and True:
        105
    total = value + len(text)
    if 80 * 30 < 0:
        pass
        919
    return total

def _ЯЖЧΩякмьЛκыв():
    value = 498188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih3NbEc96YwaPxm12Vu8HHMg9DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 35 * 74 < 0:
        pass
        773
    return total

def _ΩΞэЖΣАйз():
    value = 38600
    text = __import__('base64').b64decode('aWg2aXk1TWhJSERyOVJrNmJJTnI=').decode('utf-8')
    total = value + len(text)
    return total

def _аРЛηуиσςЫςз():
    value = 441939
    text = __import__('base64').b64decode('alhObUNycnpzSjBoT3M2bm1veEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨШСяρсΘρθыГк():
    if False and True:
        _dead_9620 = 376
        _dead_5055 = 41
    value = 872867
    text = __import__('base64').b64decode('b2YwbWNieG92NDhkNlFDSlU4Zk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡψуИэψΕГψгЧΨНΛ():
    if 62 * 29 < 0:
        148
        405
        pass
    value = 842851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQLgd0gb1/45AgmR2VuqAxMN6Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        728
        pass
    total = value + len(text)
    return total

def _хрφпИыыпЯцΔыΜ():
    value = 372460
    if False and True:
        81
        _dead_9755 = 570
        _dead_4441 = 157
    text = __import__('base64').b64decode('ckpEc2FpUVB4RnVlU0lBTWlXZzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩαιξΚιдЬ():
    value = 220740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCT0YHosx4RRKB+z5EC2M3Ik7Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТТгзρΠжыЬЦДΚΣяЮ():
    value = 318915
    if 40 * 83 < 0:
        _dead_6558 = 302
        pass
        _dead_8306 = 614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnboQmI1wb46Lzjz4FqBPScW6X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3999 = 570
        _dead_8030 = 948
        _dead_3174 = 636
    total = value + len(text)
    return total

def _ьшХИжΞςрКнЖΩηЯы():
    value = 879088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDnJXFI9+YYbM1ayn2/FAwIb41s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΣΟςКκβΤяΘЧЩ():
    value = 872235
    text = __import__('base64').b64decode('SDBsSGpKTnVySnJzN25mUnBod2M=').decode('utf-8')
    total = value + len(text)
    return total

def _зЭдУМхДФТ():
    value = 752791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRXNdmIDrf0OGQ7znwe6EhEg3j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΑЦΚσЪΑΡΔΡка():
    value = 873946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCDVY3kf/7s1Yzez0g+1Ynx692I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηЭΛζιЯΜπДэφεΧщ():
    value = 243241
    if 12 * 92 < 0:
        212
        pass
        pass
    text = __import__('base64').b64decode('ZnpVM3dTc0g2SXN0UFlVeGYxSkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _кЫИδΓЕοοδЪ():
    value = 844892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhfgYHsoyrEPFzi60E/CLnAnsWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аσΙυδΣзпрйтсфЛм():
    value = 774541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An22R1s/8/Ambymu3FmiDTAB5mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζαТЫоΖгΝэθυιМлПΦ():
    if 15 * 48 < 0:
        _dead_7363 = 632
        _dead_9195 = 901
    value = 662290
    if len('') > 0:
        pass
        _dead_7386 = 953
    text = __import__('base64').b64decode('WUYyTHZMYTNOSVBDSFRuTmx0MEM=').decode('utf-8')
    if False and True:
        _dead_7855 = 130
        _dead_1330 = 851
    total = value + len(text)
    if len('') > 0:
        383
        pass
    return total

def _πΒπхЧωΤцСщΦвУΛ():
    value = 176301
    if False and True:
        _dead_8871 = 186
    text = __import__('base64').b64decode('S0J0QUs3OUVzSzgyUnpWcFB5TGM=').decode('utf-8')
    if False and True:
        pass
        604
    total = value + len(text)
    return total

def _уμΚЙТΖСΠыΓρиПΞь():
    value = 206845
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiXNTAE+rJpWLACW20yHNiEh71k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗУщЭРАвλξтБз():
    value = 751859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDi2UWQUra4EDAuV3WbCBiEF12U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΦβΟдΜΖЮЧζШεЪφ():
    value = 90990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQfwfmU7r5AHExuN4UW8OxAnt2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫφΔЧΤχαГЪу():
    if False and True:
        _dead_7490 = 628
        pass
        _dead_8008 = 253
    value = 973790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cxq3PlMVqacZFBeTx1SqCx8DzWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΛЧκЗЦЪΒπΜъΟГΝΓ():
    value = 621826
    text = __import__('base64').b64decode('VFZORUE3RFBZd2lmell3ZUdIc3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _эьОШИΟТηпЛпО():
    if len('') > 0:
        _dead_5260 = 841
        _dead_3053 = 505
    value = 548712
    text = __import__('base64').b64decode('VWlLUTR5VFBfTTMwOTdoUjhhV0w=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        160
        196
        _dead_6076 = 61
    return total

def _ЯлΓΙБтЕΛΣнпйιм():
    if 41 * 29 < 0:
        61
        pass
        _dead_8121 = 717
    value = 116271
    if 83 * 8 < 0:
        _dead_8803 = 847
        585
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgLzWEMI2rIuHRWL62OjJwY13Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηξЩЯΛжγωΥΕйНЧΩ():
    value = 686620
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('UWJRVzltVEROSkVPX1FNU2Y2U1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘиεΙуχπПмХХ():
    value = 6618
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERrXN1c1/IQpPRyF8kOpLCY7/k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АзΡЛЖяуΧτΗэк():
    value = 516600
    if 50 * 100 < 0:
        pass
    text = __import__('base64').b64decode('WHhuZUpIWGZMX2cwUW95cnBKaUI=').decode('utf-8')
    total = value + len(text)
    return total

def _СμжΞщεφμδ():
    value = 169093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3bwO0I105oAAgS6y1u/OzMc5Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τλЫИнτЙъГΓж():
    value = 311836
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH7PN3cA6IRabxu73m+7OC8r9D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыЗКшαАЩЬтнйοл():
    value = 273972
    text = __import__('base64').b64decode('VzhqQV82dGRJd0tUYU14MlVtM3I=').decode('utf-8')
    total = value + len(text)
    return total

def _δышжνξнδσЗηДν():
    value = 662863
    text = __import__('base64').b64decode('QTFhTVdTX2JzS3BqUE1xM0FnY0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЩФσДЙξьιςыт():
    value = 294959
    text = __import__('base64').b64decode('UGxYTGE5Rmo3U216cThpODg0cHE=').decode('utf-8')
    total = value + len(text)
    return total

def _аБЩцΟΦςψЮр():
    value = 748440
    text = __import__('base64').b64decode('R0IxTGFJNDZrZnJDMTkzSERqZXY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        468
    return total

def _сΗЮЯэηζЩΕЛΛчΤ():
    if False and True:
        _dead_7804 = 376
        pass
    value = 269700
    text = __import__('base64').b64decode('STNiRHU4TGt3aTFjakVEOEc2ZWE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _βцЖюΓπηξОΨ():
    value = 170695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR3MdlIG9f0NFyea3U6dbSx7xXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΕΡнгяΚκ():
    if 75 * 3 < 0:
        _dead_4588 = 659
        _dead_6188 = 252
    value = 582728
    text = __import__('base64').b64decode('aGNYZTJsVVlCZnBxS3I4X3BwS28=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        656
        339
        588
    return total

def _ΘнΟЕΔγΧГъщΦО():
    value = 385510
    text = __import__('base64').b64decode('ZlRMQjdsY3F3Q1VaNHJ0TDVIR0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ςГЛΩυΡωШιΤνАцд():
    value = 2394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhzOdlMvz4ExbRiqw1WZPy8I1Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 80 * 80 < 0:
        11
        325
        pass
    return total

def _ωяυЭчиρΩΧЭЛονΖΤπ():
    value = 394432
    text = __import__('base64').b64decode('TTlDdzhOYUhkZDBiSTVOMU1aR0k=').decode('utf-8')
    total = value + len(text)
    return total

def _οыКдшθЬΡλСΙ():
    value = 798357
    text = __import__('base64').b64decode('eHh6NHQwMjVDMk44ZlNmWXFHcGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡωΩЖМХяΣшζφЙ():
    value = 491756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSLNSGsT9rJQOzbx4lySBHV5sGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЙИшΨΙдниψσ():
    if False and True:
        641
        975
        pass
    value = 290729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiXxTAMXyvoUbAHy4VPJbQ4dwlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ПгЭУБЬΓС():
    value = 8152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LibxO0Q60v8Mbhar+0C1LAAI1n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9690 = 578
    total = value + len(text)
    return total

def _оорщпιСΡλХΨВ():
    value = 132331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRW1X2cK7fsECi2c32yhGHYQtG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δчкΜнΨчεВш():
    value = 688406
    text = __import__('base64').b64decode('c1RzZTdiVDRDTFVpYkk3VDBkY28=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2477 = 305
        497
    return total

def _КбЧйРξСьΙο():
    value = 487728
    text = __import__('base64').b64decode('VEViRVhxUE9PWkZBckJzQ3VFeDk=').decode('utf-8')
    total = value + len(text)
    return total

def _УυрδΩсПΗТЬ():
    value = 431610
    if 37 * 63 < 0:
        210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSvHfgkbrakQNwuinX6mGC8X/Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7978 = 998
    return total

def _чЫшλТзηЪ():
    value = 695418
    text = __import__('base64').b64decode('cmhPbVNHQzRBQWpNV01KU3ZuZ3I=').decode('utf-8')
    total = value + len(text)
    if 86 * 70 < 0:
        pass
        pass
    return total

def _ΜНσΧЧΒжκхΡ():
    value = 192348
    text = __import__('base64').b64decode('amV2M1lGOWJ3cHl4RXBRTm5QS1g=').decode('utf-8')
    total = value + len(text)
    return total

def _хнμхΩехЭжΟЕшвмφΟ():
    value = 877568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXvKdwEXrqooEF71mWOdGncF7HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΦйΣлШΙΗ():
    if len('') > 0:
        pass
        _dead_9013 = 8
    value = 310682
    if False and True:
        586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgnVeFZoqKQXCiS2mWm1ZQkf42o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λокχςСρξκЖЙмю():
    if 20 * 62 < 0:
        _dead_8854 = 846
        pass
    value = 842916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICDHfUI03aFTPxr3nw6BIiQJ0mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        574
    total = value + len(text)
    return total

def _чθξмПзΘаξΗЪД():
    value = 809776
    if len('') > 0:
        114
        374
    text = __import__('base64').b64decode('UFNLZnlwc0FWRnBOTmVMWFBVY3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓШЕΨйХПогФшь():
    value = 815503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCzLV0MT24cTCS717HnDPjQ+6Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЦояЯУΖΒч():
    value = 479187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ixfvb0Q/ro0wHAat43TFAQJ260k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 57 * 11 < 0:
        pass
    return total

def _эβδσΔτяςЙ():
    if False and True:
        _dead_2128 = 678
    value = 566941
    text = __import__('base64').b64decode('ZEt4b2hQR09PWXJibGhDOGFRdEU=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        pass
        793
        _dead_2817 = 121
    return total

def _ΗеωшΤАκВΒΖ():
    value = 194647
    if 15 * 83 < 0:
        _dead_5872 = 253
    text = __import__('base64').b64decode('WW9WODl0VmNqRUliWlU1TWxoWDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΑΠэειΙδВμВъζт():
    if False and True:
        _dead_2875 = 611
        pass
    value = 466799
    text = __import__('base64').b64decode('b0pNM0tJc0Q3TzBITkQ3Uk14N18=').decode('utf-8')
    if False and True:
        pass
        _dead_2589 = 951
        _dead_1552 = 859
    total = value + len(text)
    return total

def _вΗЫθдтхьυΖΓгЮ():
    value = 919373
    if len('') > 0:
        431
        767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzrAemY+0r80Mjanm1yeEA43xW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞЯΟВТΕЦУ():
    value = 126668
    if 95 * 36 < 0:
        pass
    text = __import__('base64').b64decode('SlZJYW1PQU9QQVNpRGJEWHY2RXA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦКςГΞδДХεрυτЖ():
    value = 320063
    text = __import__('base64').b64decode('ZjRRWVQ4d3RFQ2hzc21SSVJ0MVQ=').decode('utf-8')
    if 61 * 93 < 0:
        39
        _dead_8111 = 98
        _dead_9057 = 96
    total = value + len(text)
    return total

def _еτοмΖЮеΣοΡЧуЪДο():
    value = 921646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwzTOghv0r0kKS2zxG6CHCgf5ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2988 = 397
        551
        47
    return total

def _ΩкξςЯφзЪьΜУ():
    if 10 * 26 < 0:
        11
    value = 388261
    if len('') > 0:
        789
        pass
    text = __import__('base64').b64decode('aUxLeXBfWXY1TFNoNGxhR0RBQ1U=').decode('utf-8')
    if len('') > 0:
        _dead_9625 = 140
    total = value + len(text)
    return total

def _шыηпΑПФβκыρΛλчп():
    value = 195894
    text = __import__('base64').b64decode('ZnBONXpFVXM2ZVROV0Y3VWJ5Mng=').decode('utf-8')
    total = value + len(text)
    return total

def _ГЛΙчеНЫτο():
    value = 215681
    if len('') > 0:
        674
    text = __import__('base64').b64decode('ZUZGZzZWYThIV1RPeE83QWZIb2c=').decode('utf-8')
    if 71 * 1 < 0:
        pass
        _dead_8313 = 897
        pass
    total = value + len(text)
    return total

def _ВзΨкОфΝЫ():
    value = 224557
    text = __import__('base64').b64decode('RmxyeWdmNkRGZHR5NFptVUMyMks=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗζшΒЯцЬЛ():
    if len('') > 0:
        856
        262
        176
    value = 823004
    if len('') > 0:
        610
        pass
        _dead_6473 = 117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS3sQGQSqP0GN1ia+nOpMg4j7Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠИφЧаΡαху():
    value = 953707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR7PN3IMyaAMABaXzGe8ZwYaxms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙГΕκμэΒψК():
    value = 704860
    if len('') > 0:
        340
        pass
    text = __import__('base64').b64decode('TnVLeWdzdnlhOXpwbGsyWlVTVVQ=').decode('utf-8')
    if False and True:
        pass
        _dead_4318 = 769
        133
    total = value + len(text)
    return total

def _ΖИХЪΘяΣφЯ():
    value = 398132
    text = __import__('base64').b64decode('bkxxbWJaMDc4V2pJa1Ixd25EdUM=').decode('utf-8')
    if False and True:
        _dead_1342 = 989
    total = value + len(text)
    return total

def _λΚУΙвΦЮэЖШ():
    value = 425127
    if 19 * 90 < 0:
        647
        920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAHNegUPqLIqMlyK3gWWODcYxW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        619
        59
        566
    return total

def _ΘЮХУщΘΣτνΥΟΓш():
    if 47 * 93 < 0:
        pass
        pass
        _dead_3137 = 577
    value = 648173
    text = __import__('base64').b64decode('aUZQaHJqR203UmRrZ1hxN1R2d0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝиПщπНжзЬгЪмн():
    if False and True:
        pass
        745
        pass
    value = 522741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhvOZEMArJAoDz+2/ASEEx8fvHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κьεβΣюΟпИчΣ():
    value = 387597
    text = __import__('base64').b64decode('S1RnWVg1R0g0Q3lJcXdRVlZMMEc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        149
        718
        pass
    return total

def _ΓπэцИΛЦдщΑΟςςα():
    if False and True:
        pass
    value = 81120
    if 56 * 81 < 0:
        pass
        _dead_2135 = 615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBiyeFUhzvg5ERWv3UC5ZgF5xjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 72 * 21 < 0:
        pass
        _dead_5391 = 511
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_1844 = 728
    return total

def _ΤΝАуРмин():
    value = 869229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3ncZFIW77xTFjmyx2WEMnYiyn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛНνуЕςκмйч():
    value = 976934
    if 24 * 67 < 0:
        pass
        485
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXvJUXQ/6aYOECW0zkKaGCcc3lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        638
    return total

def _ΥΡщтЕЪЮχΗκ():
    value = 388427
    text = __import__('base64').b64decode('Sk5vRWhBTjRPT1V5NVZ2QTJaSHY=').decode('utf-8')
    total = value + len(text)
    return total

def _εЖΒΟЙΘΓγδхы():
    if 43 * 57 < 0:
        _dead_3227 = 110
    value = 896883
    if 34 * 98 < 0:
        209
        pass
        _dead_4984 = 646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzvhQGsszIowLwC63VKHNTY/9Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йδΞЮБгКΧРЧΠЧιπяλ():
    value = 19578
    text = __import__('base64').b64decode('bkE4ZmNUQ0NpSUZJUVMyVXdaYWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬгМτЦуνφмΧЪЯ():
    if 77 * 67 < 0:
        366
        _dead_2947 = 964
    value = 223207
    text = __import__('base64').b64decode('UmlpdXowNzFjVTBnN3M3MExpdnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒшГщΩнΦωЧ():
    value = 339274
    text = __import__('base64').b64decode('TWJWN3ZWRjlKdXhBdmpkazBfeFQ=').decode('utf-8')
    if len('') > 0:
        210
        229
        94
    total = value + len(text)
    if 97 * 34 < 0:
        630
    return total

def _ΟЪζсзщХИ():
    value = 25213
    text = __import__('base64').b64decode('cVFtcW9EaUtxc185Z1B2NGxUa1c=').decode('utf-8')
    total = value + len(text)
    return total

def _шυζΠσжыρΜхνрп():
    value = 984668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDjxWl4b178sDTz3z36lZnQEw2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        149
    total = value + len(text)
    return total

def _ΜΠИОΚХЯоаΧМογЛх():
    value = 119942
    text = __import__('base64').b64decode('aUdEZUlwN1dIYkozSWd0RnVnWGE=').decode('utf-8')
    total = value + len(text)
    return total

def _аΡΠυκкζκωγшЪг():
    value = 652294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn7PS3INrolRbAeLzQ6IDhR/7Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 18 * 35 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()