#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _гΘφκИИΦПТδΙэΥъаΨ():
    value = 780459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISnTO1No6rkaDjCTy3GXOyp850o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЪгλΧφλΦЬΡΝОШ():
    value = 717329
    text = __import__('base64').b64decode('SERROHZvTkVLTV9lXzVoWUVZZEI=').decode('utf-8')
    if 1 * 90 < 0:
        _dead_3244 = 290
    total = value + len(text)
    return total

def _БΟМБΙШνπтΘμехα():
    value = 285895
    text = __import__('base64').b64decode('Ym1ZN0lEOU83QVZUT01GRkc4aVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜсΓаΧβιΥβΤН():
    value = 256048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTjlN1ky6747DAq57m+7YQ15smc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨχэдсπτяγщмЭЬрр():
    value = 680727
    text = __import__('base64').b64decode('Vl9IXzJaRHhna3E2YWxKU3Y5bTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ДмΗИμЧΧТЬЗΧ():
    if 94 * 97 < 0:
        _dead_3873 = 177
        481
        pass
    value = 195540
    if len('') > 0:
        228
        931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ3NbEg6qvhVDCqJ40+aC3wayD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 33 * 19 < 0:
        _dead_6017 = 953
        115
        pass
    total = value + len(text)
    return total

def _ωТΩΔΞσВАз():
    if False and True:
        47
        pass
        _dead_9155 = 534
    value = 785868
    text = __import__('base64').b64decode('TUgzbmR6N3BVdDZYWWFzXzY2b3Y=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9810 = 372
        _dead_3847 = 862
    return total

def _чαΜмШюЧЛЕмΣΧβуИЦ():
    value = 474607
    text = __import__('base64').b64decode('SHE3NlFjQXVjeXExMXN2dE9fWkg=').decode('utf-8')
    total = value + len(text)
    if 25 * 13 < 0:
        _dead_7035 = 658
        pass
    return total

def _эζЯшцΗзχхшВοΗ():
    value = 815349
    text = __import__('base64').b64decode('UTl3ZUZXMUhFcUN2NGpqS3dFS3E=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1555 = 709
    return total

def _йιΠДεΘРлоГГ():
    value = 809203
    text = __import__('base64').b64decode('ekg2RXNEZFhzaXE3UE1OMGFNVzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ФбΒЫИЕκст():
    value = 5612
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA7rSUEX6bIIaBiz8GTAPzMXykg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_3122 = 90
        685
        pass
    return total

def _ΗтζΛжαффΗ():
    value = 483823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBvOWVkIr58lEzuBzVeHMj9+3X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζκΔрРαрнαЧмЙΜуκБ():
    value = 602092
    text = __import__('base64').b64decode('TGlXU0kyNDlDMXpPeGN6NDRzX0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ωТыδςλΠυд():
    value = 982522
    text = __import__('base64').b64decode('SVhLX21tOEFTXzJzNXRwQTRWOEE=').decode('utf-8')
    if len('') > 0:
        737
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_7309 = 798
    return total

def _ОΛγфνЛиχ():
    value = 504951
    text = __import__('base64').b64decode('QjU4ZDlZTHd6bnBSeHFhUWdiWU0=').decode('utf-8')
    total = value + len(text)
    return total

def _σφΧЮИйρЛκщэг():
    if False and True:
        pass
    value = 345486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRzdNkRp6IwBFyT7zXe8HXcfx2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        480
        pass
    total = value + len(text)
    return total

def _рЮВΥΓφгоΡ():
    value = 388950
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyrodAQu77ElPArz0EWpACoizWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΤΦШШςШζСтщожвВ():
    value = 942427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHfRW1Ij7vlTPge0wFHBARZ51jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уςИрвωЭХЗмД():
    value = 415010
    if 74 * 99 < 0:
        692
        _dead_1957 = 960
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AibFXlgw6vElGReCmUCiPRALz3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        414
        pass
    total = value + len(text)
    return total

def _вΘЫжАЬΦεσγПКφЕηа():
    value = 467177
    text = __import__('base64').b64decode('bENsb0hlelIyUnVYcnZLWjBDeVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _АΖГРΤЕеΣСЗЮΑΓлВ():
    value = 262387
    text = __import__('base64').b64decode('dmU1N0pfc21OZGwyb3ROT0hhMlU=').decode('utf-8')
    total = value + len(text)
    return total

def _λнЯΟДгτэиΓДξюЪХО():
    value = 425230
    if len('') > 0:
        683
        _dead_9444 = 832
        786
    text = __import__('base64').b64decode('YnNTUWNHOVJiTGM0SG1KMFhMdVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _γГЗмΡθΠФζΦ():
    value = 736490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTb8W14+77wFPBic7GSoMhAk0Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 30 * 59 < 0:
        _dead_6684 = 517
        _dead_4319 = 351
        pass
    return total

def _кЕжμуωПΠ():
    value = 798793
    if len('') > 0:
        991
        417
    text = __import__('base64').b64decode('ZUFydGRkTXZlWW45RFRYSDc3eUc=').decode('utf-8')
    total = value + len(text)
    if 69 * 5 < 0:
        pass
        _dead_3233 = 669
    return total

def _ыСчУκιЛцЦЮф():
    value = 115513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXnTRkgS2rIFYi2z/FiiOi96znw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПЙЛνЙнωυыяΧШВπΛг():
    if 90 * 12 < 0:
        435
    value = 671345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQPXemhhqboWNzqizGCAOgk5828='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мбτΩьПмЭЦξе():
    value = 7783
    if len('') > 0:
        856
        pass
        590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgnteXoG3YEVABeh8maVARoosk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эωмΞфΛЮуцкΟ():
    value = 835275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwjNZ2Y47pggHAOmkASWNy4O/Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3968 = 466
    return total

def _ψязςοНФаΘЦЪпФ():
    if len('') > 0:
        _dead_1465 = 800
        253
    value = 97674
    if len('') > 0:
        pass
        _dead_5299 = 959
        _dead_8199 = 328
    text = __import__('base64').b64decode('TkNmazRzV2dDN0h6WWNOYTI5dWs=').decode('utf-8')
    total = value + len(text)
    return total

def _еΕТσΓЛгАγ():
    value = 852362
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyvlbAIRq6BUbgqUzwO9FRwZ3lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΤУЙκзщйвΟ():
    if len('') > 0:
        _dead_5782 = 824
        262
    value = 475979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDm2VlQQqvoGLQOL+lSgHj0k1FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ААνρчЯΟЧ():
    value = 323231
    if len('') > 0:
        _dead_9894 = 194
        _dead_8705 = 486
        255
    text = __import__('base64').b64decode('S0h2WGZDYWJ5SlNzdXFUd2hKemM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠπΘΦЦβяИΠθβρφТы():
    value = 63259
    if len('') > 0:
        _dead_7805 = 425
        _dead_8164 = 607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pw31a3Q724QaKSCExlGKHjI73F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χФχпиβЬπ():
    if 57 * 20 < 0:
        _dead_9716 = 274
        _dead_6919 = 336
        pass
    value = 682329
    if len('') > 0:
        _dead_4929 = 368
        pass
        _dead_9273 = 579
    text = __import__('base64').b64decode('VWJmYUFna2RTZFg0WXhLNVJHZUE=').decode('utf-8')
    total = value + len(text)
    return total

def _МΝЬцРΨЬЦО():
    if False and True:
        240
    value = 769022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRXten0L16wkNl61+m+mPxQi62U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_8190 = 80
    return total

def _фΩηНςюΞм():
    value = 982517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxfbWFkd9qVWLl7ymne8AjAQ0GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_3603 = 238
        pass
    total = value + len(text)
    return total

def _ηиφζдГЫзИΡ():
    value = 50282
    if len('') > 0:
        469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCTLWFwe7bIgNB+m8kyYLjIFzzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 62 * 83 < 0:
        984
    total = value + len(text)
    return total

def _АгьрьδюК():
    if False and True:
        999
        343
    value = 436943
    text = __import__('base64').b64decode('ZXd5cjJ6R1dEUWU0S00yYzFuVXY=').decode('utf-8')
    if False and True:
        664
    total = value + len(text)
    return total

def _ΓδфЪяσбйЯΜοψф():
    value = 580245
    if 89 * 83 < 0:
        pass
        pass
        _dead_2553 = 754
    text = __import__('base64').b64decode('eGtlWlE0NDRhV0xMbFREcWcxOU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯюαЗпшаΜи():
    value = 46355
    text = __import__('base64').b64decode('RWgzdEdsWFhsSDZBWGppNkY4ajM=').decode('utf-8')
    if len('') > 0:
        _dead_7783 = 847
    total = value + len(text)
    return total

def _ρεΚОδпЩл():
    value = 838601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MA7NPUQL6qFXClylxHSpJyMh02U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘИΖυΑВΣУЙЬ():
    value = 691568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQzrZQcX+ZEODxi7+ATCNy459Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        360
        _dead_9130 = 205
        287
    return total

def _ВМПУεъεмФΙ():
    if False and True:
        pass
        354
    value = 632449
    text = __import__('base64').b64decode('RmpETjBqQkNEdEluRWJoV3VZR04=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_4439 = 412
        _dead_2987 = 166
    return total

def _КИбаΩМбΤοЖЬηЦΡТу():
    value = 154958
    if False and True:
        787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3nMOkY8r68JaiT2kWK2DDcQymM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗаЙкΡНГΦΣЧκρЭхЪВ():
    if False and True:
        _dead_3558 = 309
        _dead_7707 = 883
    value = 312592
    if 1 * 49 < 0:
        228
        _dead_9307 = 387
        326
    text = __import__('base64').b64decode('WjVoZ2FTcmR2QkRuVWRNXzRqRkk=').decode('utf-8')
    total = value + len(text)
    return total

def _СчъПШψКБΝв():
    value = 65481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxvWRHY38JslNSSqn3ubYnV481g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΔчΙγΚмγл():
    value = 97636
    text = __import__('base64').b64decode('elAzbkhNenEyeFE5RVhxM0gzTW8=').decode('utf-8')
    if 41 * 2 < 0:
        233
    total = value + len(text)
    if 81 * 94 < 0:
        pass
    return total

def _жΛЪРЧсφэθрωΝ():
    value = 699645
    text = __import__('base64').b64decode('TXYwa2lmZEdhdEJNdTRfcF9KV0s=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        987
    return total

def _ΛζШзΖГψЬ():
    value = 118450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQ3UTQUg1bA3EgWL0Ge6ESccsW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1771 = 284
        _dead_2767 = 727
        pass
    return total

def _ΣΑοсВβχφИ():
    value = 788823
    text = __import__('base64').b64decode('cmE5NTdTamN3ZDNNRUV5OUFpaUM=').decode('utf-8')
    total = value + len(text)
    return total

def _УаΝКУΡЭзмσоιХΦΤ():
    if 93 * 71 < 0:
        _dead_4794 = 368
    value = 281096
    if False and True:
        _dead_3299 = 927
        _dead_9250 = 370
        _dead_2242 = 369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HynPeV9o5PEBKyq1mQLGDgwk9Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦοАΟΝЪАЩω():
    value = 140043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LT23XGkDwaU3bySRykKeJjAtxlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φибвЯтмНфλφуΙЦВΣ():
    value = 112384
    if 35 * 16 < 0:
        _dead_3621 = 539
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSLee2QW6bIAazD74mPEYhcg4Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛбΤΦΡμНΜуζнСюЭε():
    value = 921904
    if len('') > 0:
        pass
        _dead_1233 = 455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LD7yZ3UM2oZXbgu3nn2IMTYW92E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 27 < 0:
        pass
        _dead_6030 = 437
        639
    total = value + len(text)
    if len('') > 0:
        709
    return total

def _АζпПφЮЕоΕπфΟΦндц():
    value = 568337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3nqX2cYqfxWK131mniAICou1UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΡЯэΙЙΞΣφι():
    value = 908586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAjwUX4y954OHSa66X3JLC4C3Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΗФкξЯдИσЗ():
    value = 837859
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('bzlZRDV3OEZDQ0RDRXl2TkhqYUM=').decode('utf-8')
    if 43 * 95 < 0:
        431
    total = value + len(text)
    return total

def _ςσфΤУЕшαыΤканьЮ():
    value = 831121
    text = __import__('base64').b64decode('UnY2Wk16blFobnB4T09NY1hsM2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ωЦЖПтзЛСλΨνЧИΔυΗ():
    value = 436440
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCTeOXs9yP1XEAf17li1GCx2/Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΩцРαяςΦиΤГЙΛΑЭ():
    value = 130331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CATMe0cR/7glIwCG5lOgIHEO8UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 28 * 5 < 0:
        pass
        pass
        _dead_1887 = 131
    return total

def _ΩωТЕнμАА():
    value = 547384
    if 3 * 49 < 0:
        _dead_4129 = 198
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EA70X30eq/wQOAOa+WSgJyF39D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5696 = 378
        _dead_7076 = 75
    total = value + len(text)
    return total

def _ЮΒΥΥИπХΟΘьц():
    value = 45157
    text = __import__('base64').b64decode('RENLY25Wal81aHRUeFZZV3pQWHA=').decode('utf-8')
    if False and True:
        334
    total = value + len(text)
    return total

def _шцΟΦδΝΙАΩΦЗА():
    value = 220827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjvmdHAjz7wmLB714UO9DC0uslo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъбΚΡзбωΚщγΤ():
    value = 633492
    text = __import__('base64').b64decode('bW9uanFpV3VJQlZ3MTF6SUtidnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ФОψФΕΙЭш():
    value = 708288
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('bFRIRlcyNTFmeVVrc0kwUngzU0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙκсυΡНΛшЪΘЗСЯ():
    value = 599530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQbKf2gPrIY8MFiK7F2bJnIk1kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щρЪζРтΞζЖΩγыЯ():
    value = 465855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eie1YUBpzoYbPVew6mO0HycW72Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЛζГЗσжяЮθεΚΟ():
    if False and True:
        _dead_4570 = 845
        152
    value = 860270
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzjXV2ksrJ0PCR+HwF68Awk7/mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓБЙйщЗΤΣΥЮΒΥч():
    value = 988565
    text = __import__('base64').b64decode('QWxzZ2V5QzQwOEM4U1RBODVFODg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        220
    return total

def _НΥЛаΘжСΛЦμλ():
    if 25 * 3 < 0:
        146
        pass
    value = 644177
    text = __import__('base64').b64decode('RERqT0hHdUNuVGs5Tk4yTm5Dbzg=').decode('utf-8')
    total = value + len(text)
    return total

def _τПнпΖфОκδДцψМоц():
    if 40 * 11 < 0:
        _dead_5613 = 96
        _dead_5478 = 613
    value = 322858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izfbe1QS9aVUKACmnGOfPxUu1To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЦΟΠΜΨшΒДΥзнЕαф():
    value = 848224
    text = __import__('base64').b64decode('ZURfZ2NUbkZ0dm4wQjNGZk1oYlk=').decode('utf-8')
    if False and True:
        _dead_8850 = 1000
        _dead_9416 = 673
    total = value + len(text)
    return total

def _нΖΣΟМΖЯУЛ():
    value = 282462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwnOVlUG048REF2kx3u5DjQesGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        615
        621
    total = value + len(text)
    if len('') > 0:
        _dead_1655 = 737
    return total

def _ζфκΜдКсωвΓ():
    value = 533827
    text = __import__('base64').b64decode('VEs4YW0wQkZQUnREZXJwa0FobXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞвιйΒЫЛΑο():
    value = 226301
    text = __import__('base64').b64decode('c0JNU2NsVVlGRTJlOTVoN3oyWEk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7222 = 875
        516
    return total

def _ΧΣшΝжмΔщΕхφΑΗнС():
    if False and True:
        _dead_8275 = 324
    value = 85744
    text = __import__('base64').b64decode('YTdtTUJucVRPY2RUeFF4WXlEa0g=').decode('utf-8')
    if False and True:
        _dead_4707 = 393
        pass
        pass
    total = value + len(text)
    return total

def _ьхΔьΤψδТшПфОс():
    value = 185154
    if 2 * 32 < 0:
        _dead_9530 = 818
        275
    text = __import__('base64').b64decode('dWJpNW9ualhEYXMybTBoTFZ1Wk8=').decode('utf-8')
    if False and True:
        628
        346
        333
    total = value + len(text)
    return total

def _ЯηНΩкσейΟπ():
    value = 528010
    text = __import__('base64').b64decode('YnZpaVR1SFFOVVUyZVp4QlF3eGc=').decode('utf-8')
    total = value + len(text)
    if 13 * 28 < 0:
        pass
        433
        _dead_4952 = 275
    return total

def _ΕβчοНчЮШодцЭωЩ():
    value = 566087
    if 6 * 66 < 0:
        56
        809
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSvIRlMw1rktPyim3VHIEyIE9Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εДвдЗгйкъЗβи():
    value = 128827
    if len('') > 0:
        _dead_8659 = 283
        458
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD7SWlsd3YtXCR2RwAWSEjcN41o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛθΥΘανΖΝЮΝъд():
    value = 865583
    text = __import__('base64').b64decode('VktHRUZueWZEQnJEVDZWaGJEa2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ьηΚпεΒПΞ():
    if False and True:
        177
    value = 277062
    text = __import__('base64').b64decode('am13TkV4UWtHVUd0NV91TEFMYnA=').decode('utf-8')
    total = value + len(text)
    return total

def _БыφΞщηыΑШ():
    value = 302105
    text = __import__('base64').b64decode('czNMM0hxRkxWR1NBWUpmVTA4OVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΝпдΕГΓРΦщηЫψξеΗ():
    if 86 * 16 < 0:
        pass
        _dead_6261 = 312
    value = 838573
    text = __import__('base64').b64decode('ZG1ZRTZORVNub3U5dHl4X3hmMnA=').decode('utf-8')
    total = value + len(text)
    return total

def _бωжωтλΖшяф():
    value = 574028
    text = __import__('base64').b64decode('QTBYQ1oxS0dBNUFDczVPRGtMMGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙТΥтΠΓΡщπу():
    if 73 * 24 < 0:
        pass
    value = 425077
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQ32Pnkp75ksIh6yzkCZJgo8/n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πЧαшκыШППΛΨнБЮ():
    value = 92778
    if len('') > 0:
        _dead_8750 = 56
        0
        208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx/AdFkOr59RK1612FiXYBIm5XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΕГВΥГγхΥЩνь():
    value = 65045
    text = __import__('base64').b64decode('cl90SU82Z2hDWHFNdXlQcTdpZVM=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        _dead_2967 = 609
    total = value + len(text)
    return total

def _зΠЙззФЩΝшЙЫ():
    value = 218443
    if len('') > 0:
        229
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ahazd3Vg9qc7LFbxmWm8bDE6/n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3754 = 142
    total = value + len(text)
    return total

def _дйьклΣБπΜРЛсπф():
    value = 458556
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('b1BERnF4eUdKRU9VeldMR20wUzU=').decode('utf-8')
    total = value + len(text)
    return total

def _πομтΩСξФДЖБΜσхм():
    value = 104506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An3BW2MzqYs6Hz+n5QahER0s9Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_2905 = 396
        893
    total = value + len(text)
    return total

def _жαЛΗΗоβВεм():
    if len('') > 0:
        pass
    value = 287639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjjuXVtv7/8mExqa2lm3GQwAsX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ВΨфчΘτρЧγРэЛ():
    value = 132207
    if False and True:
        pass
    text = __import__('base64').b64decode('eHJ0dTlieTNwbG1IN21xQkc3MTg=').decode('utf-8')
    if 55 * 96 < 0:
        186
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _υАΡАΟδяЖДВζΧяΝ():
    value = 127797
    text = __import__('base64').b64decode('ZW5NR1A3YmhDYWpzNlVqandVOHo=').decode('utf-8')
    if len('') > 0:
        433
        318
    total = value + len(text)
    return total

def _ΤτПΟζλΥОчαКаАΔΘ():
    value = 992709
    text = __import__('base64').b64decode('Y1FWUUxPV2UyaUs0eFM2SW43M1U=').decode('utf-8')
    if 38 * 17 < 0:
        _dead_4560 = 556
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        61
    return total

def _φΚЫЗηπξΞ():
    value = 269684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjXeagcQzakEKyy6w12xBT8a5mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξСЗЪинКφу():
    value = 56268
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITzJWF4N+vFWGzeF/Fy0GQEqyD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖπЬРзМζжΨШРМ():
    value = 314840
    text = __import__('base64').b64decode('WjhHczdxQVpuUFdFTzB5VDFhcUg=').decode('utf-8')
    total = value + len(text)
    if 40 * 89 < 0:
        880
        357
        _dead_1208 = 133
    return total

def _ζжΣФΛэЖγюПγΓуζαУ():
    value = 599559
    if 47 * 9 < 0:
        pass
        923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBneOFYd3aAUKTD620KHZTcZ0jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 30 * 12 < 0:
        _dead_6161 = 120
    return total

def _мΖκщчпьфйηхΛΙ():
    value = 703709
    if 86 * 87 < 0:
        _dead_9614 = 338
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQyyQXMY+ac5Hz6N5k6TNyYX/UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьτβВхΥчы():
    value = 589998
    if 19 * 59 < 0:
        _dead_8892 = 387
    text = __import__('base64').b64decode('d3ZZX2JTTkVScFVzbHRjVHFyRE8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9065 = 289
        _dead_7754 = 929
        _dead_6995 = 831
    return total

def _ΤлηΠАуОΛΔьг():
    value = 703138
    text = __import__('base64').b64decode('ZTdGbXV5dHFENjJKSHBLU3Rib2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _βδκΡΩΠйЛуΟαовз():
    if len('') > 0:
        pass
    value = 45378
    if False and True:
        _dead_6791 = 554
        _dead_5081 = 51
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FivJVn1gyo8TbQKKw1OSYXIbxmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9847 = 687
        pass
    total = value + len(text)
    return total

def _ωБчЦΞРеΞΨΦΥщЕЛΧ():
    value = 537846
    text = __import__('base64').b64decode('cFlqQklTczRsWDl5UWEzX3ZBRU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗνδχΦпωΦш():
    value = 851855
    if 29 * 73 < 0:
        971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQzvfEZpqYMqayzykXC+HCEjvFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пεаЖΔЗΩτΕ():
    value = 795048
    text = __import__('base64').b64decode('Q0I2SDdIOHRqREJ3WmNldGVQSHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮВΟхςДχΘЛΕэШЮ():
    value = 507022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHfKbUI13IE3G12q3XeYIjd2x3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СιβьЫψХΠ():
    if False and True:
        pass
        _dead_7354 = 156
    value = 668144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAT2PG440akzBSS1/36VMyQ96jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2944 = 65
        pass
        pass
    total = value + len(text)
    return total

def _εδΣΒΞΙГэжиχэЦ():
    value = 82240
    if 20 * 78 < 0:
        pass
        169
        pass
    text = __import__('base64').b64decode('SWJybElpc1k1QmlVY2lZQW9uZ0I=').decode('utf-8')
    total = value + len(text)
    return total

def _πλРΗθйтчΟК():
    value = 721723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxfNN2I176MxKjmr2HeHJQse3WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΝБвΖпйΙо():
    value = 374202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kw62QW4I14ozKAW592W9EnY51Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΦΨеяНщйуЮабюοеδ():
    value = 114479
    text = __import__('base64').b64decode('S2ZlZ2JjRGlfRUZZeWV3WXVUcHE=').decode('utf-8')
    total = value + len(text)
    return total

def _чΝЫрΡσЦεЮπВΒυΒДБ():
    value = 439215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cw3oTVgjrKoAKQ6x0neTDSwl8jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΨцФщδγТУΘοБ():
    value = 436419
    if len('') > 0:
        _dead_1568 = 192
        703
        _dead_7562 = 481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgTFegYg76dUFyzwmH/IE3UY63o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 70 < 0:
        _dead_2904 = 291
    total = value + len(text)
    return total

def _γюΨψρΩρЫА():
    value = 491166
    text = __import__('base64').b64decode('SW0wdDJZWUpHVnZJdkNDYmNUY2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ДτΧмСМыβκиыЪЫЙРΨ():
    value = 25400
    text = __import__('base64').b64decode('QW1GZ28yc1pFNjJ3SndBczF3ZHI=').decode('utf-8')
    total = value + len(text)
    if 72 * 95 < 0:
        pass
        pass
    return total

def _ΜΙςιΦоВΞОΘХ():
    value = 710072
    text = __import__('base64').b64decode('VEIxUVd5VE0xb1JPeWFsQWJwdTI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        118
        pass
        pass
    return total

def _ВδΘЬΩЭНпъАчΡЙν():
    value = 258892
    text = __import__('base64').b64decode('TWthdjNVc3VVcW1BQjZ2RThyVTE=').decode('utf-8')
    if False and True:
        486
        777
    total = value + len(text)
    if False and True:
        349
        _dead_4461 = 221
    return total

def _ЬьΟвσΕΧеνгвумΓМΝ():
    value = 870019
    text = __import__('base64').b64decode('ZXVyWDRNUWxHSUMzYUlMMzIxd2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΙΟδμэБΔъЪбгвωЩ():
    value = 559705
    if len('') > 0:
        _dead_6599 = 735
        _dead_7263 = 260
    text = __import__('base64').b64decode('WnNoQ1lobjhIZHZmWlhtNjNBM2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ККъСсΛрΦК():
    value = 647901
    if 14 * 65 < 0:
        _dead_7069 = 381
        _dead_1013 = 923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiCxNnIU075XaCWJ+wWDJiIl4kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        956
        _dead_4526 = 238
        _dead_7648 = 577
    total = value + len(text)
    return total

def _уИΧзуПΤжУюН():
    if len('') > 0:
        _dead_3335 = 757
        33
        pass
    value = 277303
    if len('') > 0:
        _dead_2825 = 249
    text = __import__('base64').b64decode('Z2tKQXVwVWVaS0g4RDFKNlhsM0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗаСкДΗзκΧ():
    if len('') > 0:
        pass
        723
    value = 29940
    if 63 * 78 < 0:
        _dead_1757 = 339
    text = __import__('base64').b64decode('eF9nZmdER1NQcWczUUpFSkRHcVM=').decode('utf-8')
    total = value + len(text)
    return total

def _яъХйшГКхσЦ():
    value = 409049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InvqW1M884QHOwGlkV2lBA8b9EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        31
    total = value + len(text)
    if 95 * 95 < 0:
        _dead_8138 = 990
        60
        pass
    return total

def _пЛΒиИбωζХΩνъψ():
    value = 146163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiPnZUQszY0KGTum2ny7Hgd/tUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7450 = 609
        _dead_3047 = 622
    total = value + len(text)
    return total

def _ЮΔвнχуВЫφхΤ():
    if 23 * 79 < 0:
        _dead_2621 = 105
    value = 130579
    text = __import__('base64').b64decode('T0VGeXFRc3V0S05mQzQxaUlteVg=').decode('utf-8')
    total = value + len(text)
    return total

def _νъΘγιТЮζΗΒцΑЕ():
    value = 994677
    if 71 * 4 < 0:
        _dead_7911 = 162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MX7rX3Jopo42Ylu5z2/ENgYI3X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 4 < 0:
        pass
    total = value + len(text)
    if 78 * 15 < 0:
        pass
    return total

def _умΕΙКВβειЬчΕяр():
    value = 640966
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT79egYPq7oHGAy6/mecBRoZ83c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЮΥΛεδΠΦяНΞΒ():
    value = 230158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAH+OXgvq7InMjWM+3GyZ3EM3Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΗθзЬКХХλЗςΙпδμω():
    value = 959312
    text = __import__('base64').b64decode('c0pKaVpfU214ekF0TGhGMGlzUGM=').decode('utf-8')
    total = value + len(text)
    return total

def _нΥВЫεЯеЫΒйхдπ():
    value = 119965
    text = __import__('base64').b64decode('c1BBRVgzQmRaSnVxQmhPV0F4V28=').decode('utf-8')
    total = value + len(text)
    if 10 * 72 < 0:
        739
    return total

def _ьπЬСΥУιΝι():
    value = 927281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiS1fERh3P4TAgS07XqzCxcJwUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _эЙΕЙρОФξЗяиΓ():
    value = 663936
    text = __import__('base64').b64decode('QmYzRW1CaWl0TWFKdTYyNXJsWU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭмЪСβЙХоηщБΑΤНъ():
    value = 527194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABDmdFcQy4o2Ewar2XuGDDUtsz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВыяΠГΧтΚ():
    value = 118464
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxy2WVAD7J4lYgyK5nLGIRE+vHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λοΥσМюНβрляΖ():
    value = 93809
    text = __import__('base64').b64decode('Um5lT011Vnc5V0J3VFpPQTY1cXY=').decode('utf-8')
    if False and True:
        104
    total = value + len(text)
    return total

def _жЗγюΘчΙΤр():
    value = 695945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXbgdHwupo4IEwib4lOmGn1/sWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зτγИуЫΥμФЦЗΘ():
    value = 51070
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQLVaV0R5J8pKg2g/kaFDhInyWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛЙΨГξβΠзтОЗщλкУ():
    if 57 * 55 < 0:
        pass
        _dead_8268 = 849
    value = 64196
    text = __import__('base64').b64decode('S043ZEk5X1E4enpzdE9BX25fbWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ШмнЭтЮκςρЖаХгΦξ():
    value = 485924
    text = __import__('base64').b64decode('TzZ0bkhRc1hsTnZxcll4MDVha00=').decode('utf-8')
    total = value + len(text)
    return total

def _вΓШВςιΥθ():
    value = 414482
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDXgdAQ17YwxMB2bxk7IGjF3sFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕρΩдАнкеθσ():
    value = 8453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwvTSUMGzLlRKzqrz1fGMiQ3sko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΗУфΚΡУавС():
    value = 93206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQvsPQdpzKwTIgSg90+cIDd46Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТιЦιцΠτΕр():
    if 96 * 54 < 0:
        30
    value = 527971
    text = __import__('base64').b64decode('cVVhSU81c1JDeVc2ZmJjTmNQVXk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _СΞкΒδΕΨБβДЮпсФхΟ():
    value = 343475
    if 15 * 49 < 0:
        468
    text = __import__('base64').b64decode('RVllRTVoUEFydzFmUTR5enZKOHU=').decode('utf-8')
    total = value + len(text)
    if 48 * 96 < 0:
        _dead_2704 = 358
        pass
        pass
    return total

def _РОРΜнжХΔΜйυЭΓ():
    value = 25012
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiK1ZgMAx5ooDgCw6WHJGzMuz2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟООυхыηЦйζ():
    value = 411300
    text = __import__('base64').b64decode('Q2h3WXdzRUdNWExoM0I5WkZOSFI=').decode('utf-8')
    total = value + len(text)
    return total

def _шСΑЕНТфЦΜ():
    value = 676950
    if len('') > 0:
        388
        _dead_8117 = 681
        pass
    text = __import__('base64').b64decode('UDJzc1NPUXJhMHhjTTRDR3RkWVU=').decode('utf-8')
    total = value + len(text)
    if 18 * 87 < 0:
        pass
        448
    return total

def _БαгρρΞΤОΚΡ():
    value = 190074
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTjzdkg8p643agby51O2FgQrwjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕкψΗБмеλτΑК():
    value = 236167
    if len('') > 0:
        _dead_8513 = 959
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lxiwf0YGx58zESe1/3qoYik921Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЖЭачΝСКюлΨш():
    value = 174151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzvzQwBs1acPbSWqwX2XJA8/w2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖхсжыΚэМгчНΧρ():
    if False and True:
        pass
        679
    value = 536859
    text = __import__('base64').b64decode('aEdvVkN0MVYzVndGdWdDV0h2N0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _УυХωΛтнγьТΒθЫ():
    value = 266703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyfJZloc04E0LS67mQ6WFTQFzzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3666 = 630
        _dead_8045 = 700
    total = value + len(text)
    return total

def _ДчεчбАкп():
    value = 531615
    text = __import__('base64').b64decode('QzdpTFpld0hIT2JDeklLU0JmMkI=').decode('utf-8')
    if 57 * 59 < 0:
        pass
    total = value + len(text)
    return total

def _ПΑΦΗбачΛ():
    value = 193697
    text = __import__('base64').b64decode('UGVmMnlhU3NjZmhaTWRlQ21yN1I=').decode('utf-8')
    total = value + len(text)
    return total

def _акЭчдРюбъДчяг():
    value = 911897
    text = __import__('base64').b64decode('SDR4THF5Z2xBVzc5MnZIeW5naDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧуБЛтΘкьκзΠаγю():
    value = 469610
    if len('') > 0:
        364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwTxRUI+zpBQbBy3yX+ZDRMr6HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_3537 = 431
    total = value + len(text)
    return total

def _ДΨοΦΤΗяЖ():
    if len('') > 0:
        732
        pass
    value = 912592
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgjtOmE96ZlRC16cnW6ENRYJxkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕхМвСΓтДНζΦэΛж():
    if len('') > 0:
        pass
        _dead_4264 = 281
    value = 776979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgDiPUgr0pwoGT2F4V6FAxI9tX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 85 * 86 < 0:
        pass
    return total

def _ΒВчОЪоΠв():
    value = 575114
    text = __import__('base64').b64decode('bnZlWG5JdTN5THp5UHNtVXphclU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩКлФГщΑеъЦмРпε():
    value = 819391
    text = __import__('base64').b64decode('ZkVFWnpxNjN6YlVxdWZMVjRySFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ВιВπзюоδНнЮαтнΞ():
    value = 145680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAHQawZh8q4PLl+gz2+bA3cWzkg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аχΡΚЭуЪΤ():
    value = 220495
    if len('') > 0:
        489
        862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHq2Sksv/IklNyu02XelLCAFtDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6539 = 854
    total = value + len(text)
    return total

def _αВΨυΝπμси():
    if len('') > 0:
        _dead_4019 = 45
        _dead_7181 = 646
    value = 130503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EizNTWNp+bIVPR6v+kHGIX01yEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮβΟГΦУЗεС():
    value = 384486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSrsY1kvwYEvIDit2kbCB3MlwUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _μьрИΔкНοΚ():
    value = 789344
    text = __import__('base64').b64decode('UnVZNEthRkZpbGF0MHVsWF93eG4=').decode('utf-8')
    total = value + len(text)
    return total

def _χЯЪвзИНхΙюλΖκиγЭ():
    value = 369508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnriYHw07pk0Yx+ZnluUbRd702w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙγΑζΤΡна():
    value = 33348
    text = __import__('base64').b64decode('dEhBcGJpeFJpSnFfV2hjNFpsa2w=').decode('utf-8')
    total = value + len(text)
    return total

def _θЛтτзГχξΧ():
    value = 950999
    if False and True:
        pass
        529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxmzaAgz1qIQGRun5m+xOXUB6zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жЬСгбМαΞз():
    value = 725311
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDq0UVQu1rI2YwKoynWfACMAxnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щТεжднξЯВ():
    value = 854765
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah7rTWQqr4QVF1j642fGJDIbsUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 83 < 0:
        730
    total = value + len(text)
    return total

def _ΘπΞюнηΗΗψμ():
    if 65 * 38 < 0:
        870
        _dead_4545 = 633
    value = 447783
    if len('') > 0:
        460
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSTnO3g98Y80Yg2R5V+zFy8283c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цяΓэшЦэгη():
    value = 889832
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhmybGIA5/AZCiD67FO8GgY3zlc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГоσΔРΒщнЬНθб():
    value = 136167
    text = __import__('base64').b64decode('cWpYeTE3RWNvMHRXUVFNRjJ3TGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ОЛΝυКчδиμχυ():
    if len('') > 0:
        pass
        927
    value = 208869
    if False and True:
        592
        200
        pass
    text = __import__('base64').b64decode('VkRzS3BWX3h0MTM5SGlmeE1YUnY=').decode('utf-8')
    total = value + len(text)
    if 94 * 52 < 0:
        pass
        pass
        201
    return total

def _тΩπяиЩτЗс():
    value = 809158
    text = __import__('base64').b64decode('Z3ZiUEMzSnBTUTFmdFBBSVFXWTQ=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_2184 = 37
        _dead_5908 = 91
    total = value + len(text)
    return total

def _чΜцкΚταцΑΦЛΩпИп():
    value = 875120
    if len('') > 0:
        469
        708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwXhPFJp+akCLAmn53rJAA8ntjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ВинγЫηцρΣζдС():
    value = 260871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AALjQgEOwYIPbxWKx0azADw3tlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        710
        _dead_5879 = 821
    total = value + len(text)
    return total

def _ЫρΧοэΗжЪ():
    value = 841653
    text = __import__('base64').b64decode('TTQ0TTNySk84cXVSRHBlaERqRXc=').decode('utf-8')
    total = value + len(text)
    if 45 * 94 < 0:
        355
        pass
    return total

def _ьωΜΦКΔТτΓ():
    value = 123511
    if False and True:
        290
        490
    text = __import__('base64').b64decode('VGVab3Y5NV9oTHd3SXVYTGNoWjI=').decode('utf-8')
    if False and True:
        _dead_2469 = 274
        _dead_4703 = 278
        _dead_5034 = 962
    total = value + len(text)
    return total

def _ШАгИХГΥчΟсжΚ():
    value = 7242
    text = __import__('base64').b64decode('UWdtSGhUMlQyQ2o0SEV3SUZtX3Y=').decode('utf-8')
    total = value + len(text)
    if 7 * 33 < 0:
        463
        pass
        _dead_7826 = 699
    return total

def _χΧЦψЫлъаΛοПдζЧ():
    if 25 * 80 < 0:
        _dead_8999 = 291
        pass
        _dead_4941 = 486
    value = 370495
    text = __import__('base64').b64decode('bFF2X0pCZzZfSGt4YTAyTFZzZFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔεδжρшΜεчΙ():
    value = 597566
    if 83 * 50 < 0:
        _dead_4011 = 453
        pass
        _dead_4267 = 511
    text = __import__('base64').b64decode('cEpoVGVtRDZXaXV3M0JrZmk0U0w=').decode('utf-8')
    if 59 * 83 < 0:
        pass
        207
    total = value + len(text)
    return total

def _КаДξШςтИхУΗχйΑοО():
    value = 796445
    text = __import__('base64').b64decode('UzhvbnhuZUVoUjc4a255djRKa2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠщπЯБΓБφζ():
    value = 510457
    text = __import__('base64').b64decode('bVJXWXd0QlRKRWpZT3g3THlOMkQ=').decode('utf-8')
    total = value + len(text)
    if 79 * 33 < 0:
        pass
    return total

def _ЗΛψυςЙОЬρ():
    value = 540823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MADKQGkN//46IziM71CZN3IatEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΥуμдкωΚυ():
    if False and True:
        674
        pass
    value = 324442
    text = __import__('base64').b64decode('RldBRTRaMjllalpDb0UyWHQ4MmI=').decode('utf-8')
    total = value + len(text)
    return total

def _κξφΩδЙνΣЕЭενΣ():
    if 33 * 52 < 0:
        372
        pass
    value = 826772
    text = __import__('base64').b64decode('bUZQREJtT0xXSjNUZUlwamJ2bno=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _НνοуиЧЦΙАΩΟ():
    if len('') > 0:
        _dead_3638 = 480
    value = 646351
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD3tbUM71qosHgWB90WqLjcB4GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θьУπλНΧЧДЫξσн():
    if 31 * 70 < 0:
        _dead_7295 = 121
    value = 682915
    if False and True:
        _dead_4755 = 983
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSDhYVAP+ZApDA2SyQK+AH0s5Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮхΖНΠОεδΠμф():
    value = 945336
    if len('') > 0:
        776
        pass
        458
    text = __import__('base64').b64decode('T3hpV245UjYwTXZGRFZlYUlqV2o=').decode('utf-8')
    total = value + len(text)
    return total

def _юХΝПцбΞяΗΜВЧ():
    value = 831226
    text = __import__('base64').b64decode('S1R5SlprVEFUYzMwd1F2anpIbl8=').decode('utf-8')
    total = value + len(text)
    return total

def _нγоΗБτкΕ():
    value = 529828
    if 29 * 82 < 0:
        374
        326
        567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiLAT3UY9PonFTqE50TGIw578lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1955 = 546
        _dead_1103 = 295
        715
    total = value + len(text)
    return total

def _КβΨΑΔОАψЭ():
    value = 190112
    text = __import__('base64').b64decode('Rlk3ZmN2eFVEdzJiTXgwX0NSSzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛρЯЖυЙЫЖш():
    value = 755405
    text = __import__('base64').b64decode('SmZQZGsxYUR3TVAyTW4weGRVcTk=').decode('utf-8')
    total = value + len(text)
    return total

def _λΞЖХДцπОΙЛэχΟЮ():
    value = 811989
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR7PY3ogq7sOCgKo8HmULikM7Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 82 < 0:
        _dead_8262 = 238
    total = value + len(text)
    if len('') > 0:
        _dead_7494 = 456
        _dead_5265 = 672
        pass
    return total

def _ΒпΜеΝΗΔτФВξΔ():
    value = 599481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dhy0b24D9aERbFqPyX2zLSd38E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 75 * 60 < 0:
        740
        171
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΔмγεοηБνΨΡос():
    if False and True:
        811
        pass
        216
    value = 9122
    text = __import__('base64').b64decode('b3o5UjZZOXhDTHNhZHNlckFURjI=').decode('utf-8')
    total = value + len(text)
    if 74 * 35 < 0:
        pass
        _dead_3022 = 979
        _dead_7371 = 479
    return total

def _ыΕлСΟТЯкΒнΟΔпΔжЕ():
    value = 250016
    if 71 * 70 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQflW3YIzfo5HQy7xQKUFX0By2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3323 = 315
        pass
        _dead_2167 = 137
    total = value + len(text)
    if 46 * 12 < 0:
        pass
        84
    return total

def _МΚΛςТτЭфРвзяθ():
    value = 3111
    text = __import__('base64').b64decode('QmRuNXExSXJaanE5SnhTRkk5OGQ=').decode('utf-8')
    if len('') > 0:
        _dead_6518 = 875
        _dead_4638 = 424
    total = value + len(text)
    return total

def _ДδκШσΥΧирΠдγ():
    value = 38859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQ3BSHkN95sKAlin7geiOhMG1kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜуΣЦжΙηйГФυΤЙβА():
    value = 484910
    text = __import__('base64').b64decode('YlVHTXBZVE1LX2NZbTZMY2F5V20=').decode('utf-8')
    total = value + len(text)
    return total

def _киθΑΨΒΟЪξηу():
    value = 949135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXzselctrKkqDgDyzwC1Hicl0UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηыГуэДюКтΜКвфАΠМ():
    value = 539952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg3pPgkXqqRbNjaky2CfBQwZtX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩпΩэСωΣΧйвλпНο():
    value = 602405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHvsbFMe+YQZLluc4X/FYwt62zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()