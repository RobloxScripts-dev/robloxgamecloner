#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΘΒηΑулВΔΟдΣ():
    value = 164127
    text = __import__('base64').b64decode('RFVZbGZER1YxbUYwN2hwdFR1U00=').decode('utf-8')
    total = value + len(text)
    return total

def _υлνЯΓкρОзΦζΝЙшφ():
    if False and True:
        _dead_2116 = 948
        pass
        _dead_3634 = 978
    value = 66370
    if 39 * 66 < 0:
        _dead_5366 = 866
        193
        _dead_2336 = 554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AST2N1wy/70RFRWSz1CyHgMm7l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 86 * 85 < 0:
        pass
    return total

def _жбЮхКΜЫφжмДΞ():
    value = 773795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzzQb1UpzZJabj26kXiXOwMA6kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΔτжγЧЗΥαюЕЙτψу():
    value = 943753
    if len('') > 0:
        _dead_3769 = 202
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRD1fmQK544rPSWN+EOFYAIt0Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2201 = 250
        _dead_8164 = 636
        pass
    total = value + len(text)
    return total

def _φΒηΕνκХΤтΤКеΞνδ():
    value = 352169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASXRXHlq2rwCbjCC6gTDNz8E3U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 95 * 73 < 0:
        _dead_1603 = 306
        268
        46
    return total

def _θκΤζιнΧΡΜξчΦйия():
    value = 426280
    if 56 * 98 < 0:
        _dead_8473 = 991
        577
    text = __import__('base64').b64decode('Z2lhM3hxVjZHb0hOZ290bEpySTk=').decode('utf-8')
    if False and True:
        839
        _dead_8763 = 830
        _dead_8071 = 742
    total = value + len(text)
    return total

def _аεфйΙΑпσзγΙСфθЗ():
    value = 332776
    text = __import__('base64').b64decode('VldtdVdxbXdHbnQxTTlPTUZyTlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _зЗψкфТсεΘ():
    value = 254947
    text = __import__('base64').b64decode('TURkanBJYjRDYXlnenFpYkd0TEE=').decode('utf-8')
    total = value + len(text)
    return total

def _еΙΥЮЬηΚΠБцЫъοИ():
    value = 587505
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('aWZOYW9vanVqOE5KbWVpZTNxc3c=').decode('utf-8')
    if False and True:
        _dead_4209 = 520
        pass
    total = value + len(text)
    return total

def _ЯΙδψЬЫΖьШ():
    value = 819517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnzsOAkvr6NbNASHxnCBIQI8x1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БяьηΩεΟЯΑΔЧ():
    value = 207065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSTvN1Ub9aMrPziQy2SfOAN3s3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХиΝвΠрЪΩ():
    if len('') > 0:
        _dead_1480 = 200
        pass
    value = 252432
    if False and True:
        664
        102
        _dead_8150 = 527
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dz/pNldqyKBWa1by6g+bMBEAvGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 39 * 68 < 0:
        367
        _dead_2943 = 592
        36
    total = value + len(text)
    if len('') > 0:
        836
    return total

def _ΜзΨнМФлκз():
    value = 552947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyH0PHYN740VLR+H5wO0ARE3z0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦкУэоΥΨΞсРЫΦсжΩΑ():
    value = 19034
    text = __import__('base64').b64decode('WFNNSXBDQ1hCSzRwdk9aRGYxQ08=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭςРсοΜΚЗхцΔБОπ():
    value = 465387
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('Q3RxbTFJVXdvZUxGdnRyS0RzZmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΔκйΟФαΘЪВМΞΛΒΘ():
    value = 962308
    text = __import__('base64').b64decode('TmJubUNLY2RCSFo2MVFJemQ4bkg=').decode('utf-8')
    if len('') > 0:
        _dead_3424 = 346
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ΤфΜЭΜыгηМΙьК():
    if len('') > 0:
        _dead_2030 = 938
        603
    value = 343640
    text = __import__('base64').b64decode('dW9rUHpfV1ZqT2dROWlZQU5Pd3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ТцБОюриΠТΖв():
    value = 861390
    text = __import__('base64').b64decode('S0hGZjV3dUFwbWZaX3RfQ01YVnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _фваνΖΟОМРсвФ():
    if 88 * 1 < 0:
        pass
    value = 41027
    text = __import__('base64').b64decode('WWNMNm45MEU5Z2xDVjN0MkZoZmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩδЦΜАЗжτΡвγнρδ():
    value = 439207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bib+TX4SqKMELgWlnni3PzIfx1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΑИΒЦзαРαЯдюλΜ():
    value = 728949
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bz22PWgr76EvYj3wkVizDiQm1FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΙοМВмКΗэЦПБмΓос():
    value = 274814
    text = __import__('base64').b64decode('ZWk4b1pBY3JqcEV0RGpSTEpieXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΩФΤΩэςθэωЪаδйГн():
    value = 468016
    text = __import__('base64').b64decode('dzFLR1RDQmNXeEV0MkJ2c1dqZFU=').decode('utf-8')
    if 28 * 14 < 0:
        pass
        _dead_7159 = 864
        _dead_3477 = 100
    total = value + len(text)
    return total

def _сΒОΩΞαаКБψвбφΚΨ():
    if False and True:
        pass
        pass
        pass
    value = 239789
    text = __import__('base64').b64decode('YTEzOU1ZWGR6RlprS09oWnhJVEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ρδΡθΟХБю():
    value = 267106
    text = __import__('base64').b64decode('QWNFTVJnOUdOclZ6akwzR0QyZEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΓйΝчСντЮЛКΝαьЩλ():
    value = 964568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERfbaGUwy44NMCyV+kKHHAoK12I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФкςτШЫЪМ():
    value = 617174
    text = __import__('base64').b64decode('Z0dDX2RWbkFUVzhfV0Fra3pNSEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠУхвеИЖЩΟуΑνЛΙ():
    value = 748084
    text = __import__('base64').b64decode('T2pOekhKNXlmTXpWb05yemliaEM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        1
    return total

def _ηοДЩЩОЖоυΛКΨΝΖ():
    value = 663255
    text = __import__('base64').b64decode('eFcxMm5BQTM5WFVRNXg0OWFQWE4=').decode('utf-8')
    if 2 * 15 < 0:
        pass
    total = value + len(text)
    if 50 * 96 < 0:
        pass
    return total

def _ψМмζΤιζςЗиРΑΙΔ():
    value = 342189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgHbaHIhxLFXYln00FSFMCkLsEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъмνшνξЩтИΚ():
    value = 784334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgDcfUVqzowBMg6G/nCqOnIr3nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςιШΟЭТмЖ():
    value = 167209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PznMZGgTq7oqFB2B4W+bMhd+/UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωпπиЩИΗκКсΛ():
    value = 95451
    text = __import__('base64').b64decode('UWVZV3JKbm93UlAxNk5CaHpVejA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦБΟΝрБηПъ():
    value = 93441
    text = __import__('base64').b64decode('RUNSTzNOcEp0TUlIWG1KRTVlR0g=').decode('utf-8')
    total = value + len(text)
    return total

def _чбθπцВЭТЧω():
    value = 17007
    text = __import__('base64').b64decode('aThpa3RQTXlmUE1yRjlLUHBhc04=').decode('utf-8')
    total = value + len(text)
    if 85 * 23 < 0:
        _dead_7138 = 906
        570
    return total

def _Вжρуυюгε():
    value = 458297
    text = __import__('base64').b64decode('WmQxbzlBWktLWXUxWGU4ZlVvSkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _МИПТДмГπУςМЛγпаΠ():
    value = 29152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXr+aVYq7vsyHi629363ECEs0no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮРрαΞхμЬи():
    value = 488454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dy7xfUVt3685PV2In1nCJh0CxmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑςйжбШМн():
    if False and True:
        _dead_2315 = 489
        pass
        pass
    value = 940630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCb8eWIcy7EoEwLz6VCBPh83w20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 16 * 94 < 0:
        pass
        _dead_4495 = 48
    return total

def _ΩЙΔГяΩξЧшΣ():
    value = 875060
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSPOPX4/qbxQOA2w8X6HZh8jsVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чюНΨπεБПБψΦ():
    value = 762463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kge8e2sV1rsKPF/32m64EA8h82w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηкэиюнΣωЬ():
    if 27 * 51 < 0:
        _dead_3918 = 751
        pass
        _dead_6956 = 177
    value = 76519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBf3dlAf6P0pMDX14HXBGBB2tT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 35 * 39 < 0:
        934
        _dead_7331 = 773
        829
    return total

def _ЦомΘηωдЛΠΣжηзюр():
    value = 630081
    text = __import__('base64').b64decode('cHBZT1BPYjdJWXBJWF9wNlRhMV8=').decode('utf-8')
    if 90 * 16 < 0:
        522
    total = value + len(text)
    return total

def _щГУяббжРεΓШНж():
    value = 556238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS7PVHkQ7ro0DVic/V+jLg0rxmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НνУπДЫΣΥκ():
    if False and True:
        pass
        pass
    value = 303766
    if len('') > 0:
        pass
        _dead_6715 = 302
    text = __import__('base64').b64decode('SFpBeUx0Y3I1TDlQRkpnTlB0ZTI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _АьοτδγΚщМВ():
    value = 607368
    text = __import__('base64').b64decode('VV9sNXFBRjB6bXMwZERyckVxU18=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_3564 = 890
        558
        _dead_5459 = 55
    return total

def _дГЛОхшДααΒЬΖιρΕ():
    value = 572254
    text = __import__('base64').b64decode('djZkZl9OTUhxRWxLc0FiYVRPQ0o=').decode('utf-8')
    total = value + len(text)
    return total

def _эΛЮАЕъλьυИ():
    value = 256118
    if len('') > 0:
        _dead_7760 = 955
        _dead_6920 = 271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB3gWVot5P42EwjzzWWqMC8EwXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пХмФζΨΥωΩьнγвЯбН():
    if 93 * 63 < 0:
        226
        310
    value = 37738
    if 3 * 76 < 0:
        _dead_3153 = 79
        _dead_8377 = 313
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgzeWWcVz4cKDDm04mmoOw8//mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡОχΗΙψЛГК():
    if len('') > 0:
        542
        pass
    value = 325153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCnJQ2E39YxWHC266UOcMCgOsDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АιнβτФΓююΞΠλф():
    value = 84766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzjQf0Y+7P4WNQuX+WOnZxR57WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПЪкзΕуюΥ():
    value = 95394
    text = __import__('base64').b64decode('SVRRT055X0Zkc3JVMHRfTEFGV3k=').decode('utf-8')
    if False and True:
        _dead_6101 = 395
    total = value + len(text)
    return total

def _ЮΓИΥΗΔАъΕМμс():
    value = 560609
    if 20 * 7 < 0:
        _dead_5914 = 509
        298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyH2OXYzrasRDgf6/VmGDCwI3Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4823 = 918
        _dead_4556 = 884
        53
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЙΔаШъВеΙш():
    if 2 * 86 < 0:
        pass
        87
    value = 239990
    text = __import__('base64').b64decode('YU84WGc0SkRFampiTVZLdVphdFc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        946
    return total

def _яλхятэδΟλΙ():
    value = 841349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjnbfmUz9ZcEPiOyzXOjOwI+w3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7121 = 583
        _dead_4955 = 414
        176
    return total

def _γΑвйьявЫ():
    value = 152392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Czm3UWtt2ZkEFFqR7Ua6Ynw9vTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        508
        pass
    total = value + len(text)
    return total

def _ЧзΔЭκгπΑΨиохΚоωй():
    value = 759764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AR60OgJt0KIXFViOxWeqBggF41k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 77 < 0:
        pass
        663
        953
    total = value + len(text)
    return total

def _ΙξОσЧψшхЩνЪщΩ():
    value = 334267
    text = __import__('base64').b64decode('amUyV2hadFQ2S0dOT0hMa0tWNXU=').decode('utf-8')
    if 80 * 96 < 0:
        386
    total = value + len(text)
    return total

def _ΗСΞЭςииΨμζαПЫЭГг():
    value = 260295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjzRYkgIybASFiCo7EOqNgcKyzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АυδЛΒΗΙлЦΞДнлχΩТ():
    value = 251863
    text = __import__('base64').b64decode('cDEyeElHT0h1eVB2OE5reTE5SGU=').decode('utf-8')
    total = value + len(text)
    return total

def _яΤпΘΗжИσΗОΙх():
    value = 971405
    text = __import__('base64').b64decode('cHB3UERvcVJ1a0tOb3NsMDNJd3c=').decode('utf-8')
    total = value + len(text)
    return total

def _иΣлюПπуПьщЖ():
    if len('') > 0:
        pass
        _dead_6612 = 150
        0
    value = 372694
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgjMf2ET36AubVaVyV3AJXEu/E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        963
        _dead_2193 = 325
        _dead_5747 = 609
    return total

def _ЭбсРεΕвΔ():
    if len('') > 0:
        pass
        pass
        pass
    value = 933197
    text = __import__('base64').b64decode('VzJ4Wng2UnhicHRiNFNZYTRrcGE=').decode('utf-8')
    total = value + len(text)
    return total

def _юΞкΤгπГтУ():
    value = 154267
    text = __import__('base64').b64decode('cWhFeE5WdmFpMGhNdWlCd29NeUo=').decode('utf-8')
    total = value + len(text)
    return total

def _сΞλУνфИΝвΛъααВ():
    value = 417397
    text = __import__('base64').b64decode('TTJYNW1GdVBPcFJBSnM5ckJVb28=').decode('utf-8')
    total = value + len(text)
    return total

def _ХρβхκΕтρΓеμΠ():
    value = 466264
    text = __import__('base64').b64decode('VFdPcDVnVzlZTVUxaFRSZlRnRHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗσшИδЕкνΩγкАΧΦжρ():
    value = 306586
    if len('') > 0:
        389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCOwPVoq870IPwKx/XKAC31/13s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΟсΡНνδукΥЯΦβц():
    value = 28867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzboWn0u2JkVCiCt72O9IDAg6HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЖεβΣΘЩдбЧ():
    value = 493696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX7oQ2hr2rFbYhb0wXKFDHN60mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φЬмЛпμνδςφИΛε():
    value = 500443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NALhVGAKrrgiMVj1+3XAJBU2xmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥθΥАΟИКж():
    value = 869330
    text = __import__('base64').b64decode('S3VXajZIa2tUbnNvRVdHTXRGZzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΨшΧОΝЫАЧхсΤ():
    value = 681568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NADJY2cr8vERKQ6wylSxOio47WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΛрЪькНΒНъΛюΦЧ():
    value = 268586
    text = __import__('base64').b64decode('bHd3V3BsRUFKd1dZU0pOTWhRc1g=').decode('utf-8')
    total = value + len(text)
    return total

def _итцХЯыχκфьμθПСЬΘ():
    value = 671585
    text = __import__('base64').b64decode('dXdrQUpZOUM1UFVabXB0YWkxazU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣЗсВвνΚΙщ():
    value = 467217
    if 3 * 53 < 0:
        _dead_2285 = 683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjzLTFRo6KchbiOL91y8JCAn9Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7822 = 87
        _dead_6553 = 2
    return total

def _μφЫЧНβОΥΥρΦ():
    if False and True:
        pass
        _dead_9916 = 658
    value = 3165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRnLZVsGxvEUbAms5WyfM3wd714='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εавΝνъкΞδбλУгмο():
    value = 974600
    if 87 * 79 < 0:
        662
    text = __import__('base64').b64decode('Y2RfNl9QTE9pRmZtSkhBQkxkZEw=').decode('utf-8')
    total = value + len(text)
    if 24 * 92 < 0:
        102
        899
    return total

def _лχКоΝνЕλъΡΧИφξ():
    value = 502135
    text = __import__('base64').b64decode('R1NDUzdkZG5Tb1pDbWdBSGE0YUU=').decode('utf-8')
    total = value + len(text)
    return total

def _φчΗлФПνДξХΗпчΟλ():
    value = 609718
    if False and True:
        440
        _dead_6702 = 282
        213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnbddFwOpq4LIBmt3keVMyx35Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΕΒΣτтмΝКбИУЛуΙλ():
    value = 280918
    text = __import__('base64').b64decode('S1FuSFQ1Wm9nOEgwNk02QWFjWGY=').decode('utf-8')
    total = value + len(text)
    return total

def _АХΚЮΒбЩч():
    value = 917325
    if len('') > 0:
        534
        436
    text = __import__('base64').b64decode('TWNubUkxZFdlbFZURnF5T25hRUU=').decode('utf-8')
    if len('') > 0:
        pass
        430
        pass
    total = value + len(text)
    return total

def _ПχΠΣвТйбьМΤγΘЫ():
    value = 718919
    text = __import__('base64').b64decode('QnZjYWkxUzJmR09WOWxSTFBqdzg=').decode('utf-8')
    if 99 * 3 < 0:
        638
        139
        _dead_3875 = 56
    total = value + len(text)
    if 39 * 31 < 0:
        810
        pass
        725
    return total

def _КЖьЮΓхяΞχε():
    if False and True:
        pass
        205
        pass
    value = 239407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwjrX1Uz1JgwMjWR5lCGMz17zUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        167
        _dead_1297 = 615
    total = value + len(text)
    if False and True:
        _dead_3154 = 651
        pass
        _dead_4822 = 285
    return total

def _ΒЫΣУΗБδу():
    value = 135556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCjePEAy6Y1SMiWTxVWgbBYn7no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χоχξвΒЪЖчШ():
    value = 78717
    text = __import__('base64').b64decode('Wm1aYXNZZFd2dHBMbVJCZjdyN0s=').decode('utf-8')
    if False and True:
        pass
        _dead_7839 = 798
        pass
    total = value + len(text)
    return total

def _θΘΒЪЯдΕΕкυХ():
    value = 149084
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBy8WngA9IosGFmq+H/HGzU58l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 87 * 45 < 0:
        _dead_4937 = 495
        pass
    total = value + len(text)
    if False and True:
        183
        pass
    return total

def _ιДΑпяΞАκЩшδ():
    value = 883774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTbKXlJup6EOMzuN2FyaGCl8820='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3019 = 181
    return total

def _ЙΡъХЕуξУъΓΨΑЕΞ():
    value = 414936
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjXLRnRs3L4LIlnwz3SKZg0o3nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дψУΚДосХΕъРхΚ():
    value = 502445
    if False and True:
        556
        784
        pass
    text = __import__('base64').b64decode('aGg1bzVCam44RkdOR0pKaVZJWW8=').decode('utf-8')
    if len('') > 0:
        _dead_9339 = 985
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        747
    return total

def _ЕηςιщξьΝβОπ():
    value = 266680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bgq0WmUTyJ4PNwWz6l+TLgkg/UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φτΓАξуΩΕуфΥХ():
    value = 674176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABjTQUgo+6oSaB2i6keSOjYB7kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΛЦВΖаЭДРг():
    if 54 * 64 < 0:
        577
        _dead_6718 = 711
        282
    value = 596512
    if 81 * 79 < 0:
        pass
    text = __import__('base64').b64decode('bnlWQkpBeEtiRHJNRXZ6MjJtREo=').decode('utf-8')
    total = value + len(text)
    if 32 * 69 < 0:
        _dead_2146 = 508
        864
    return total

def _жЕЗΦΟЯΙВмεЩΩαъЭΙ():
    value = 150238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhrNf3QQyI48aAil3g6ZYH0f/lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιΧρυлРσξΚψ():
    if False and True:
        624
        297
        216
    value = 803969
    if len('') > 0:
        400
        _dead_1976 = 311
    text = __import__('base64').b64decode('eWRpRTRRWTlpRVpaMEdUVFo5TUw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9329 = 720
        429
        pass
    return total

def _ЫΘμΡшЫЪМΛЫчфРмЮ():
    value = 661262
    text = __import__('base64').b64decode('cklHaGhGTjhEaXM0THUyb0hEeW8=').decode('utf-8')
    total = value + len(text)
    return total

def _жθыщΧычрзцΗ():
    value = 337951
    text = __import__('base64').b64decode('VWFyZVkxY3pKd1ZndHo5WGxoOVI=').decode('utf-8')
    total = value + len(text)
    return total

def _θжνςМΨцЧΩ():
    value = 983757
    if 60 * 94 < 0:
        514
        916
        _dead_6290 = 273
    text = __import__('base64').b64decode('WXR4R3M4N2NLTXo1UjZnVmFzV0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕэбчыΜяЧжΟеуБфθ():
    value = 446775
    text = __import__('base64').b64decode('TnV4STY0UHdYa3kxTTdBclpzWlc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2390 = 725
        pass
    return total

def _ГψсΙΖΦκцχаЬЯБκΑЮ():
    value = 851157
    text = __import__('base64').b64decode('ZlhJcF80ZHM5d2dtcG9ORENoQTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _щцΧβαξψэБοδ():
    value = 604119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwDMX0Q+1Lk1OQCN5l6hHhU5sW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΜσσβвΚξ():
    value = 548320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxDVO1ts7Ic1bCyvmUCUBzwG3lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Орβсιхγчщр():
    value = 208662
    text = __import__('base64').b64decode('eHFiWTg0bDNGek4xRUFWdzk0d0c=').decode('utf-8')
    total = value + len(text)
    return total

def _фкλоДΞШТαГ():
    value = 6663
    text = __import__('base64').b64decode('TjJjMHRYNUNPTmdrODl0MTl6dkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛМежкΦсюИАΘςЩΕыЖ():
    value = 306161
    text = __import__('base64').b64decode('cWxuOGU4SlZGenlRZGtqWU9iZmo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΞлююγΚХΓΧΑΚΚεΧΖ():
    value = 746419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhvMPlAa6YItCzyl/nXDMjwC5nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        453
        462
    total = value + len(text)
    return total

def _ΖΘаΒγЬΔнΟΖ():
    if len('') > 0:
        527
        169
        836
    value = 353261
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('bzQ0NlNRajFCRmNzYldlb2VuUnk=').decode('utf-8')
    if 96 * 31 < 0:
        990
    total = value + len(text)
    return total

def _РуιΑΑΣцРшпΨΤюА():
    value = 522052
    text = __import__('base64').b64decode('TkNUYXltUVJjSXJEX01MUE5lekI=').decode('utf-8')
    total = value + len(text)
    return total

def _ОЩΛШΕθΝЫΠξПЯИΖαТ():
    value = 322553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IivJWnco+4A1bziXkVObPXF3tlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩНяΔγЦиХοцн():
    value = 765501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgXMYH096KwrHiSU3FuDFzwi4j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щъИзСщΞεΩτ():
    value = 43228
    text = __import__('base64').b64decode('eTc2cV83MGkxY0I5aWlsZXJPdVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠБЫΛГЫгК():
    value = 248548
    if False and True:
        _dead_1182 = 508
        371
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3/dd1MYqIUmaCmL2mPIFhI4t1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 93 * 42 < 0:
        pass
        _dead_8180 = 84
    return total

def _нφбΟХчЯТΘВχμ():
    value = 888374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAHzawA8qJIpCyyB8UWoGyo50ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚаΤμΚΦпдздявфν():
    value = 839597
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('YV9uVWFldWxqbXpmUWkxaGhIVVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙщΧχχэνэΔЗθΒЛΣк():
    if False and True:
        141
        pass
    value = 246719
    text = __import__('base64').b64decode('TDZjS3dGVzVpdXlXYTJZTkxweWg=').decode('utf-8')
    total = value + len(text)
    return total

def _АуЩαφΞΞΕεцΣ():
    value = 24050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwrRWGsUwaspaTD6y2PGOgAtsmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧηΙξъοΕЬНγ():
    value = 747555
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSb0XwYB04IoL1ny8gHEHDMexWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИбОШоНΔгСфЫσюΠр():
    value = 446637
    if 23 * 18 < 0:
        172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA62RQIAz748Hxmxy3yRZzIBtmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        281
    return total

def _яяГЭлΒΒΖрτя():
    value = 569463
    text = __import__('base64').b64decode('YmRpcXk3b1l1c2wzV240c3lDZDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _УАΝЛΚνΘЫΗвΒпнГωю():
    value = 203912
    text = __import__('base64').b64decode('dm1LUjNxTW92b3hlTDlJaGFHTl8=').decode('utf-8')
    if False and True:
        497
        23
        525
    total = value + len(text)
    if 33 * 77 < 0:
        pass
    return total

def _йМэьΤФρφБ():
    if len('') > 0:
        _dead_3449 = 648
    value = 215540
    if 19 * 86 < 0:
        pass
        809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw79bGkT9fFQNjbzmGaHBnU+tU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        946
        168
    total = value + len(text)
    return total

def _ЖμθАΜуДмъРФш():
    value = 657489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz3Sf0A07oIIDxammGGBFycs1k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шышΠЪγσшОФι():
    value = 426062
    text = __import__('base64').b64decode('U0xUTG9RT0pNR05naHNReXNiWDI=').decode('utf-8')
    if False and True:
        _dead_9536 = 732
        470
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΚЯыКзыΔαСΖРпЪжТ():
    value = 415387
    text = __import__('base64').b64decode('R0NhVEo0U2tuZExiamY2STdudUk=').decode('utf-8')
    total = value + len(text)
    return total

def _σΜαИτэНνАйρГ():
    if len('') > 0:
        622
    value = 317988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQCxfgkBr6YhHAm1mVyDDjUX3mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6092 = 990
    total = value + len(text)
    return total

def _ХΩΤОЪφηΙн():
    value = 867976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyTMfEcL7qMOLSKH+EWpbAAXtTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιХЫΥОУЪвщайЭРяΩр():
    value = 721520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjWyfEgJ+IwKbliBwHnJJHUO/Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЮΡЕхэЫнЩΜζая():
    value = 561721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwHDVHQ16p5TECaJ+gadMHE9zl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζαйЫΗЫΑП():
    if 34 * 26 < 0:
        251
        pass
    value = 234827
    if len('') > 0:
        pass
        771
    text = __import__('base64').b64decode('VlB5VllmS2lEYndJNFg4dE5zVDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖДωыιШОιΠППαΚкЪξ():
    value = 190482
    if False and True:
        _dead_5148 = 618
        _dead_2256 = 389
    text = __import__('base64').b64decode('eXduVjU1cWtTQVdjN3g3RER6RGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _АйμЧтδΥΤΠкяуΚЯВК():
    if len('') > 0:
        272
        _dead_9338 = 112
    value = 546446
    text = __import__('base64').b64decode('ang5eUoyNGdUdTJmaFhnUjJON08=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_2515 = 370
    return total

def _ЖштюрδζДТФ():
    value = 292324
    if 75 * 64 < 0:
        946
        _dead_7984 = 22
        _dead_9177 = 434
    text = __import__('base64').b64decode('T2g5UjNCcloya0JHeEx5V3FWWG8=').decode('utf-8')
    if False and True:
        _dead_9037 = 669
    total = value + len(text)
    return total

def _фΖпБτсзεο():
    value = 626521
    text = __import__('base64').b64decode('WkFkX3NvUHFGbDlOQ19RaXNzTHc=').decode('utf-8')
    if False and True:
        856
        440
        _dead_2141 = 172
    total = value + len(text)
    return total

def _ъЕмУΨΞЮνЙзцΔΧЫΞπ():
    value = 171818
    if False and True:
        68
        pass
    text = __import__('base64').b64decode('TlphSUpIUHJaR2Q5MGFzdkZLU2E=').decode('utf-8')
    if 8 * 39 < 0:
        387
        54
    total = value + len(text)
    return total

def _ЦγоΤВОψηл():
    value = 225157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED21dGE4rIYZMjiZzV6TAh8F0G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7179 = 80
        pass
    total = value + len(text)
    return total

def _еьχЕтχгГКΩеБΛЯ():
    value = 705447
    text = __import__('base64').b64decode('cEkzOExaY3Zyel9zYTFvc0J6V2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ГПΛθΓСьσКθ():
    value = 396398
    text = __import__('base64').b64decode('ZU1YaXJxVHRzQTE3NV9KOE1PdWo=').decode('utf-8')
    total = value + len(text)
    return total

def _УОЖЧΙΔаМЧμτЗЕ():
    value = 323758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDvyfVNs2YUAOCeA7k66IAt412w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чццДΨΗЙЗчςбПУαе():
    value = 948875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CibbSgYt8Kc1Kxqb+EyCEyMKtmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 29 * 1 < 0:
        _dead_4786 = 871
        _dead_1421 = 325
    return total

def _ихЛмчФеζΩπлΥΡΑыω():
    value = 705891
    text = __import__('base64').b64decode('cVd6WW96cFhaT1hqZ09CWm5hN00=').decode('utf-8')
    total = value + len(text)
    return total

def _РφΤΝΑОΒζыК():
    value = 951090
    text = __import__('base64').b64decode('RDQyc2FrbG92OWtoaGNLVGJZUTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _кшИΦцпЙΟ():
    value = 120641
    text = __import__('base64').b64decode('UVFtT3ZQZzV6UzBFa0x3d3FZUXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥКПΤыΖΟΞ():
    value = 557635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3zHNkYN9vwICwWk0HfDDnIb4lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξНΛвЯюΙНΡЗЬςΩ():
    if False and True:
        283
        _dead_9494 = 41
    value = 875189
    text = __import__('base64').b64decode('TTJCTGdqTl81MFJ6OGJPcndjRGE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЦηдΞκαΣωСъς():
    value = 37356
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PX/sYQks0a85aiK76mepZgw11H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξюуМΩнъζΖЭΥТмЕч():
    value = 775960
    if 38 * 88 < 0:
        pass
        pass
        743
    text = __import__('base64').b64decode('SFdDQVMyMndxUXhCOEx3Tl9Scng=').decode('utf-8')
    if 66 * 52 < 0:
        pass
        _dead_1061 = 303
    total = value + len(text)
    if len('') > 0:
        pass
        654
        pass
    return total

def _ΟюЫΕωЖΩКΦГЦИеΒ():
    value = 116485
    text = __import__('base64').b64decode('WWFWaVVhX2lOM1lWU2pITW11MHg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2117 = 418
        17
        pass
    return total

def _нδАНβμоΣψΒ():
    value = 708877
    text = __import__('base64').b64decode('Z29OVVJ3S2d3MF95MXV3c01oYXI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        997
    return total

def _ЬηΞςЖЭΖиЖοΦ():
    value = 976989
    if 76 * 52 < 0:
        _dead_8011 = 123
    text = __import__('base64').b64decode('bEVxR2Fpcm9SblJRNXNic2lqckU=').decode('utf-8')
    total = value + len(text)
    return total

def _ДЖΘАСусμмΙИцζΩ():
    value = 133232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CD/hW1Zp2KwbORu6m2+/MS4B9mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 96 * 76 < 0:
        _dead_9711 = 24
    total = value + len(text)
    return total

def _ΣБПЫΙшПλщΥЕйΖХ():
    value = 2552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bzz8f3Uqqrs8Pz7xkVuJIAk5zFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙГΦУциРгΥκдеξ():
    value = 235775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRnMXAc9zrkzYyTzmUOSPSoLw34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_3297 = 842
        _dead_7236 = 163
    return total

def _ΛβυкянστКкКЧνеР():
    value = 571480
    text = __import__('base64').b64decode('ZEtYb0NnbXNPRk1iTFlPQXdfTlI=').decode('utf-8')
    if len('') > 0:
        281
        pass
        pass
    total = value + len(text)
    return total

def _ргγγнΦипεл():
    if False and True:
        818
    value = 540212
    if len('') > 0:
        _dead_1208 = 559
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxzeT2Aw5vpabCaM0Vy6FRos6ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 80 * 100 < 0:
        610
    return total

def _идЦιЛΟγИΘа():
    value = 667869
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lg3lf2k3zJ8bFxea/XSDC3U19Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эνьПЖΣβЖРγАВЙα():
    if False and True:
        pass
    value = 589006
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KizDS0Q/074KbyaV+WOhAyIa22c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗауФψΠщεΟБΓЕС():
    value = 254739
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATndQ3MezYkoPDa2+WyabXU63Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6749 = 151
    total = value + len(text)
    return total

def _ДΥυКькξЙБВ():
    value = 696657
    text = __import__('base64').b64decode('akFOUldLblpiZVVjR05HV1BqVnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔχЧЩОςеΩРΓ():
    value = 354934
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn/uekAR85ghbCeo32WTLCotyXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _агШοφΒрЬяЪЩъπЩγ():
    value = 191966
    text = __import__('base64').b64decode('eDF6R19XVmIxX3lQS1k1QTN1SVk=').decode('utf-8')
    total = value + len(text)
    return total

def _βьЫψΕЛΡΘΗФзΨЙωΓ():
    value = 797624
    text = __import__('base64').b64decode('bzFXcWk3Nml2OUtsb3Bfck1JY2U=').decode('utf-8')
    total = value + len(text)
    return total

def _зАУВαпшπКΡйна():
    value = 157929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiTjQ14e2aYVPDmSmV+AZhE21W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9148 = 801
    total = value + len(text)
    return total

def _ψυοьршΘΓТρНЛο():
    value = 47540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxjCUUdtyo07a1et+l2YZTd462E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 67 * 45 < 0:
        974
        pass
    return total

def _ДаЬрψхΣцΝХлρωУЧЬ():
    value = 950092
    text = __import__('base64').b64decode('Z0F5UDhEYkFlWkViUVJEUFFKOVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _цνльΜΔΑΜлРУЗΖ():
    value = 858919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JivJaAJv254iKSn7/2aGMzUGyjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пьйазумσжψΝσ():
    if 51 * 79 < 0:
        _dead_6504 = 980
        _dead_7540 = 265
    value = 910388
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExziQGUJq5c5bSCi63iyOS4d1Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        630
        pass
        pass
    total = value + len(text)
    return total

def _зрΜФψЙΒГшуΩКЗβ():
    if 48 * 12 < 0:
        pass
        pass
        pass
    value = 549668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh/qOUAgyfgPDiCQ7m+DGQEC7nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬЪνΚοчΥΧпШюВЯеИК():
    value = 393680
    text = __import__('base64').b64decode('YVNYREg4S3dYN0NXdlZtR0dhd08=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜεшбΜзλЪзМЙЫсΙцζ():
    value = 661699
    if False and True:
        _dead_8499 = 238
        _dead_3379 = 758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H37+WEEL96svMCyI326SJ3N/3Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ЪκΦаςЮφщмο():
    value = 786096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByHGN0sJ2LoNH13121WmAik79mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βыМГЕсДХΨουИψφ():
    value = 536332
    if len('') > 0:
        485
        852
        _dead_4062 = 962
    text = __import__('base64').b64decode('aWVkcDZNUDhZaWR5SkF4ajh3Z1M=').decode('utf-8')
    if 84 * 25 < 0:
        289
    total = value + len(text)
    if False and True:
        154
        733
        _dead_2206 = 785
    return total

def _φφΧΖΓρсΞэεнΕ():
    value = 768587
    text = __import__('base64').b64decode('b0FBNzdIRlNLVmhnenBLOEZubVE=').decode('utf-8')
    total = value + len(text)
    return total

def _χЦЭΘьМТΗарΠЖяэго():
    if 54 * 91 < 0:
        858
        106
    value = 691540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCOzW3NqrYctLC3z2nW2OyIQ/nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6169 = 31
    total = value + len(text)
    return total

def _яΔфьΠδωιαМЭЗκМРψ():
    if len('') > 0:
        167
    value = 32966
    if len('') > 0:
        3
        _dead_2109 = 312
        pass
    text = __import__('base64').b64decode('cnhxTFJkTXlxRmQ2MWVWZWtXakU=').decode('utf-8')
    total = value + len(text)
    return total

def _υΟξхЛтГιΨθΤЯщ():
    value = 42402
    text = __import__('base64').b64decode('b2ZRSGdvbWxNcDdfQW9OZGpJUjg=').decode('utf-8')
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ъпφцσщРЖ():
    value = 337827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAzNflkd3J0vBRqq6XiRYTF/7Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дωΘЖφжΩТ():
    value = 337010
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgiwPlhh7YwOajr0x2+BHRYdvHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞоρНдтΨяИщμ():
    value = 669738
    text = __import__('base64').b64decode('VVFSUzVwNXRfX1MwZXBYZlk3alA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΘФъГВκк():
    if 17 * 94 < 0:
        _dead_5254 = 495
    value = 93148
    if len('') > 0:
        305
        533
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAjbfkdv0aYvDz6a2QaTOhYl3mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑжЕюθЕυωΧ():
    value = 830213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx+1fmAq9oAEGwSo31GaAHwOzEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        617
    total = value + len(text)
    if 13 * 65 < 0:
        pass
    return total

def _χΗьΧтцЬΤдОΣ():
    value = 977585
    if False and True:
        _dead_4542 = 342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD7SRmk32bE5Ai2w73qcHjV292c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5130 = 257
    total = value + len(text)
    return total

def _ΣΤеΧщΜИЧΓθω():
    value = 348976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3/Sa1QV8/AEChi1nkCHMyt34X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ьρъΥКΓΤэΡηΗοΓδκ():
    if len('') > 0:
        424
        _dead_6155 = 830
        962
    value = 753063
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHfgeQYKx48BFjuW4lKxHRB56WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 57 < 0:
        _dead_1495 = 174
        _dead_9580 = 387
    total = value + len(text)
    return total

def _ЖыγгкκсЙζΒμζγθЦ():
    value = 145164
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IS78dAEv3JsXEjv672+GGRoL0T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΝкЛΟΟГщ():
    value = 420872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBCya3Q776oUaluQ3QKBYT81sUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΕΒκΜΒςб():
    value = 738760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQjlOloxwY81Hy62zkGjOTc84EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧоЬРэΗкΔщш():
    value = 378038
    if len('') > 0:
        _dead_1765 = 168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAHtWn8x+ZwFOVj150eVBBcW1X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6417 = 680
    return total

def _БУΒΨПΗυΖяΙπсБЦΜц():
    value = 166530
    text = __import__('base64').b64decode('SkJLb2NxTTJCOTZ3NTFreVB0Wmo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝЮωСВΛзФрВжΒ():
    value = 872188
    if 31 * 57 < 0:
        _dead_1644 = 317
    text = __import__('base64').b64decode('RlVfWE5wNjg1N0tzT1hUV05ST1E=').decode('utf-8')
    if False and True:
        _dead_7204 = 257
        pass
    total = value + len(text)
    return total

def _МнНΔыτΛφНГВеъΓ():
    value = 106393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnjqZAIW9oEEAFi08liGPCEn8m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨξθррЪЦпЯЛρψйν():
    value = 164076
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQPiWQEyy6wzAj6KmwCSYhUd4Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПчмЬЬЛмΠоεЕйφТпц():
    value = 624979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSbMSWUfy60zAiGTxgbCETI+/j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΑюйΙОδΗтЗНЭ():
    value = 188287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERr0Rng8x4MgOD/y72GVMggWwXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 85 < 0:
        156
    total = value + len(text)
    return total

def _ΨΞиуУΖаΛ():
    value = 730222
    text = __import__('base64').b64decode('ZXgzZnBhWFFIV1NaY05YMDBvd3I=').decode('utf-8')
    total = value + len(text)
    return total

def _μζРЛшχΒΝΗнх():
    value = 557752
    text = __import__('base64').b64decode('aHdSeXJuM1BJSFRkUlVjY3h2YTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΠНЮεГττΤΝбυψ():
    value = 114018
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('YVYzb2NYNzdTYXYyNlZFN1JMUk0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_6273 = 565
        982
    return total

def _ТΧоωХЭЧλΜыЬф():
    value = 572583
    text = __import__('base64').b64decode('b0JmazNyQlY0d1MycTNJOU16d2g=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        500
    total = value + len(text)
    return total

def _ГКХτзψμЫΥюблЯςΛε():
    if 66 * 89 < 0:
        653
        pass
    value = 453912
    if False and True:
        861
        pass
        pass
    text = __import__('base64').b64decode('TFpIeHlDRG1GSkpMbTBtUl9BTF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ьυΞΙσлΖπяβΖЙиυЮа():
    value = 653660
    text = __import__('base64').b64decode('ellaTzJSelk2MFA0QVdEVW5VdHY=').decode('utf-8')
    total = value + len(text)
    return total

def _хСΡΔψλфλραΘГрЩ():
    value = 275818
    text = __import__('base64').b64decode('dDZOcndxZFNRRXhtblVwZ09oTnc=').decode('utf-8')
    if False and True:
        pass
        _dead_1223 = 210
        190
    total = value + len(text)
    return total

def _ΞДЭПхΠРСррΜΦоΟгЧ():
    value = 541163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxjbREkG8PoiMj7wy0OAIh8W9UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥУимШтυйъ():
    value = 8122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR+xZ1c2/4dbHTz651O2Yz8kwFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 85 * 57 < 0:
        pass
    return total

def _βЬζСБЖяоΣяВΜρΝσ():
    value = 597873
    text = __import__('base64').b64decode('QVZfZlRNRUdmZTBMN3NnTGU1cXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ζсшсНюЖЫΦΑη():
    value = 222292
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRrhZQUI7o8XAiul7UG7DAICxjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕκЧъЫΨхЙεγιΙюК():
    value = 18124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS3pRHQ67IEXaFuz+VLJbRQIxUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _эΛжμУШλЖЯжШΛ():
    value = 352396
    if 97 * 99 < 0:
        _dead_9639 = 80
    text = __import__('base64').b64decode('cDBUckRQdG5DeUF5YVhkZlpKbzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЮОФндφфЖΜΤΖΦЕ():
    value = 17337
    text = __import__('base64').b64decode('RlFNaUw5cEpkc0VnbllnUmFhNkE=').decode('utf-8')
    total = value + len(text)
    return total

def _γζХоΙΛЙΓЬРΨн():
    value = 566021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXrmOWsX04cnMgmg5lXAPiE/skE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΝУΗЙЖэжβзч():
    value = 768175
    text = __import__('base64').b64decode('SHVSX1lDNWZkbWhXakpldDhPMEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('IA==').decode('utf-8'))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()