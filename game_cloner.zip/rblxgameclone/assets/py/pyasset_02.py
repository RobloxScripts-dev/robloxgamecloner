#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _зфзΤАΒκчλ():
    value = 416141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBCyfwgc0JgzPTmx3E6oLiYd0kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вπСνюйяЩФг():
    value = 251292
    if len('') > 0:
        pass
        _dead_6828 = 547
        _dead_9315 = 635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH3vO1Mj9/ArCByJ91+EExcEslg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2646 = 423
        pass
    return total

def _ЯфΒлбКмхεТΦρоК():
    value = 590840
    text = __import__('base64').b64decode('TWZ1QXBoU3NJbFYxSHdyb1FuQlU=').decode('utf-8')
    if len('') > 0:
        199
        pass
        pass
    total = value + len(text)
    return total

def _ашΘΦΗеЯкъΝОΙэю():
    if False and True:
        pass
        _dead_8458 = 68
        271
    value = 204805
    text = __import__('base64').b64decode('ZU1FemdVbVhMMmdOUWliVVJDQVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΖЩψΩяЯИΥΖ():
    value = 482425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSvmanhpq68APhm00mCVZig+6ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΕΜюρмЫГαφΤΑиςθ():
    value = 237764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXvFY1wT2L0VEzaLngG9GSYm6Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟχκлШΔπрΒЕΠпΘЖΑЫ():
    if 48 * 43 < 0:
        346
        _dead_7169 = 279
    value = 678131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRXGV3oUzfo7bFaR7mO1ExQCt3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΟЭьДщщуТжЪ():
    if False and True:
        _dead_6433 = 613
    value = 975763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxrwQmsI3IwBIiyE32HGNRE61Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГζνΠРзοкТОΩΠΖΦγт():
    if False and True:
        923
        pass
    value = 850021
    if False and True:
        618
        pass
    text = __import__('base64').b64decode('a0pvRFZmcXhqdTlRdlF5eTJWemM=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        430
    total = value + len(text)
    return total

def _τηκКλОσρψл():
    if False and True:
        671
        pass
    value = 180464
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EinuXlgaybIFKwybmweRCycEs0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 54 * 54 < 0:
        _dead_2280 = 300
    return total

def _сэпАΒΙΜΖωΠУцσ():
    value = 940383
    text = __import__('base64').b64decode('YjlfeGtzQ2JnYU5xb0VfaGpZbnA=').decode('utf-8')
    if False and True:
        _dead_6826 = 438
        _dead_5064 = 159
        pass
    total = value + len(text)
    return total

def _ыΨαиφбтЙΛЯΓЪοΒα():
    value = 247458
    if False and True:
        167
        403
    text = __import__('base64').b64decode('YkFnZzZjcmJkTmNKNHpYb09saDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦшωПЕГΑмньОΖк():
    value = 278469
    if len('') > 0:
        pass
        801
        pass
    text = __import__('base64').b64decode('WjREcFMyZXE3amFZdGh4c1hXSXA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΔΧβΑсыДыЩνДоδЫТ():
    if 63 * 76 < 0:
        713
        _dead_4975 = 692
        318
    value = 752153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERvLPXI4yJJQD1a1wm+EYTM2z0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РСθΑΝЖςν():
    value = 975413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRDofgEd6o0QI1qX/1mpbHJ7910='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΗхсκυΜЬишΠο():
    value = 979405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nwf1XG4V24EbaSyp4VGAMQl41zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ДγξμЭьΞПб():
    value = 643848
    if 28 * 85 < 0:
        _dead_3279 = 309
        164
        pass
    text = __import__('base64').b64decode('VTVBVkFMeVZMV3JDdlpxcUNkNHI=').decode('utf-8')
    if len('') > 0:
        575
        _dead_9352 = 588
    total = value + len(text)
    return total

def _ЦУйΗдьнςЫΧХΝΜσЛ():
    value = 867165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Myy0O1MyzYY5FB+G43KbG3UVsG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _επΜχржЧХζΕСΖЖ():
    if False and True:
        pass
        pass
        _dead_3271 = 568
    value = 724838
    text = __import__('base64').b64decode('aTBCRXpwYkg5V09fMUl5dWFTUlA=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_7075 = 132
    return total

def _ОАΦГрΑтютл():
    value = 334173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCDRe1Mb7pdbLT664A+eIxAcyD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦβΧρЖΨγелΟν():
    value = 824904
    text = __import__('base64').b64decode('V1l5MlhZblJXdUs2OHZ5Y1A1dmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛФВщешΘЖΘΘΞρХ():
    value = 16682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3fya0gy9ZgiMBmu0nigMDQ7/FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 26 * 90 < 0:
        83
        548
    return total

def _нцмγЮΘгΘ():
    value = 335397
    text = __import__('base64').b64decode('VlJFaTJqQXdmVV84TEtPMDN1cHc=').decode('utf-8')
    if False and True:
        _dead_8931 = 665
        pass
        418
    total = value + len(text)
    return total

def _φΞиΞгΔъΟНΞиβ():
    if len('') > 0:
        pass
        pass
        677
    value = 552773
    if 57 * 16 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBXlQFdspqlSKxeO41eIHBp3sW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3776 = 277
        pass
        _dead_7958 = 488
    return total

def _юпΘοыοΝЪ():
    if 40 * 73 < 0:
        550
        643
        pass
    value = 323907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDXhdEYWz7wSbB+inHKyGnws0X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 26 * 13 < 0:
        pass
        _dead_9270 = 674
        _dead_8737 = 201
    return total

def _нΖЙξиηΙοшЫχС():
    value = 69796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCPCdHY3qKUrAhas+0adbXY49mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВδОЭТθЬЯИЪК():
    value = 511718
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jwjrb0koxropMQq26V2vbSEe/l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛфвжιаΡΓμяΖо():
    value = 900050
    text = __import__('base64').b64decode('dFhTQXNlZ2lwdVRWVTV4TmRHelA=').decode('utf-8')
    total = value + len(text)
    return total

def _дνЕГМтРУ():
    value = 110560
    text = __import__('base64').b64decode('YUVBdTNoOUN3MTVpX25lMXRMdUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ςФдпΔδΘЙβγλΑнΑ():
    value = 79455
    text = __import__('base64').b64decode('Y2I1SGM2SWl5aUM2YXJzaDUyNDY=').decode('utf-8')
    if False and True:
        209
        680
    total = value + len(text)
    return total

def _ΡТЕБΚДСьбπаηΛмН():
    value = 52904
    if 21 * 50 < 0:
        197
        _dead_6437 = 753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jhr3QQQfp4kiMAOK3XSGOgM921Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6182 = 810
        872
        pass
    return total

def _ЙκιΚαсУЯ():
    value = 101309
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzvzRFkw5PAgLASgxge2ISIn6Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бЛΒγбРЧξЙ():
    if False and True:
        pass
        pass
    value = 45577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ6zYQUf77wkKzb76U+kGw0Y620='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОκоζΖпЩЗЖбЧы():
    value = 869820
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXzNamRg0b9UEBqN40+lJQ8ByGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЖΩφЦкУτЪΧΧХΔ():
    value = 724976
    text = __import__('base64').b64decode('WXBMOHBER0NzaDJuN0dJMUJIdEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩτнΓдδТУктя():
    value = 23698
    text = __import__('base64').b64decode('R1Z2VDA2ZTVrQ1VfaFBtSXNkUlQ=').decode('utf-8')
    if 39 * 83 < 0:
        892
        _dead_7217 = 517
    total = value + len(text)
    return total

def _ιЖεыЕηψЙ():
    value = 886750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRrtflAR1KI3HAaUnGa0LHEH6kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        430
    total = value + len(text)
    return total

def _аЛТснσΨю():
    value = 196630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgfDX18xqYA7IByV7lK4AnMA3kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΘуψУдсΦЖЕуθΡ():
    value = 535208
    text = __import__('base64').b64decode('b0tnZWNxSHNCaGpORUpqWlFqVUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡοыоаυΕЫΨЛсЕШφ():
    value = 914094
    text = __import__('base64').b64decode('eEl1WjNQUlprbDZWaFJIWDJVZFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ГфΥэнвΡЯзЗц():
    value = 174832
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAf+QFYBq6ANBRaH8H7AZh81yUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нτζςαоЖЙюσф():
    value = 588056
    if 80 * 8 < 0:
        _dead_8478 = 336
        791
        _dead_7329 = 72
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR3JZnk7rf4zFjiwxU6XI3M19z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 7 * 34 < 0:
        _dead_2987 = 407
    return total

def _φСЫΨНЮЗωВыρк():
    value = 463199
    if False and True:
        _dead_5557 = 366
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhjRdggV0ftQK12W+WaGOBY8xUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6082 = 389
        779
        722
    return total

def _ΜчρгПτУΚа():
    value = 999497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCzbSWA684w3NTiV7QOSDBB2sj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пщлυχчξΤ():
    value = 711885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgTVb38tyIIkOCC1wWOFHgMEzH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΥΥчΦСДΛφ():
    value = 274270
    text = __import__('base64').b64decode('S3BncmdiaHpxTkFuQlphYk9LR1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΗЖрΚΙЫЭЫΙςЙψЪ():
    value = 36730
    text = __import__('base64').b64decode('ZGRlVHpSclJNQWlVTU1JNlVJQjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦзЕПξОΒМЭкЫН():
    value = 315960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnfbOmg6+5cXDCaFy3+jEzA+s2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οПХκДδсф():
    value = 400272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnfobXso2rgKKT6CwQGcJxd/4XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        996
        pass
        _dead_6069 = 84
    return total

def _чЗВΩЩаΞυ():
    if len('') > 0:
        pass
        pass
        _dead_5947 = 91
    value = 230813
    if False and True:
        _dead_1963 = 500
    text = __import__('base64').b64decode('bUtfNDZWSXhWcXVUOV82Q2xqV3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЙрΔшЕщСБрЩΙπΦ():
    if len('') > 0:
        pass
        pass
    value = 623890
    text = __import__('base64').b64decode('S1lQX1Vic2FuTTNfY1E1MndINTA=').decode('utf-8')
    if False and True:
        _dead_3083 = 123
        472
    total = value + len(text)
    return total

def _ЯьСиХιΤЦГΦρσΘЩ():
    value = 782113
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyLrWXk78J85KVyA3ES2ZgIIvX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝГεыυΘθФсмКδδΦ():
    if False and True:
        403
        pass
        pass
    value = 113243
    text = __import__('base64').b64decode('ZTgyUWdPMlFnREd3bjRQOGVEeWw=').decode('utf-8')
    if False and True:
        _dead_6491 = 704
        pass
    total = value + len(text)
    if 47 * 55 < 0:
        pass
    return total

def _ЦшРΘъаωΚ():
    value = 283258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnzIeWcvq50aaC6kynikOAI75l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 77 * 83 < 0:
        922
        996
    return total

def _ΣеΤΗΥδКлЙыЙКйΡοχ():
    value = 504563
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCbeZkY+qfEEEBv03wG5bXMu4Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΗЮоЗаΑΧοδ():
    if 97 * 43 < 0:
        _dead_7982 = 919
    value = 597629
    text = __import__('base64').b64decode('TkRGd0ZTdUxyTnIzeWNMYjg0a20=').decode('utf-8')
    total = value + len(text)
    if 31 * 98 < 0:
        _dead_7036 = 135
        pass
        318
    return total

def _ИиЙбАнчαιЖΤθЪρ():
    value = 901116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LniwX2k7xopTHwyw52y3ICE402I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 41 < 0:
        178
        475
        12
    total = value + len(text)
    if False and True:
        pass
    return total

def _МΠзЕΛΩΘяЖгΦ():
    value = 364729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg70RUMo+KsxDzi7xl+VJXYl4EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οφСωшЙлΣЦС():
    value = 14473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH/qOUcWyPAnIDW3/VWbNnYY0Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 23 * 41 < 0:
        pass
    return total

def _ΘсчΥХΩΕτдЭζД():
    value = 233717
    if len('') > 0:
        617
    text = __import__('base64').b64decode('SmI3Q2VsYmVBZWZvMVkzdkNod2U=').decode('utf-8')
    total = value + len(text)
    return total

def _щΦфкΤΘΖзьШЕЪЫ():
    value = 151055
    if 76 * 73 < 0:
        pass
        _dead_7773 = 655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cie8RWUPrqMPDgO23WK5Zj8Dtmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        679
    total = value + len(text)
    return total

def _ΝΥФΖЗΠισд():
    value = 775615
    if False and True:
        _dead_3103 = 731
        42
        696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQvhYm4O3Y8aKjmkmVWCZTc3tXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НдОρΔгпЙχ():
    value = 815116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQfJO2cxqqAhOAWS+GDBYAQZs10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        854
        274
    return total

def _ΕСΘλюβэσюλΨФпι():
    value = 409142
    text = __import__('base64').b64decode('Sl9RbDNIR25FUTRtdXJGRXNxQ0Y=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        231
        _dead_3073 = 774
    return total

def _тизυΦСЕоБπζ():
    if 2 * 81 < 0:
        131
        pass
        pass
    value = 705547
    if len('') > 0:
        908
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCLXW30U8vALNAX2zwO3Nggm718='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞαΣβЛΒЯΦЧ():
    if 50 * 46 < 0:
        350
        590
    value = 425098
    text = __import__('base64').b64decode('UE9MOHkxekFlNlFFZUhWdnJjWEw=').decode('utf-8')
    total = value + len(text)
    if 29 * 14 < 0:
        pass
        pass
    return total

def _ΚьκфщЩЯβЬΔкωЗвΦΕ():
    value = 305646
    text = __import__('base64').b64decode('WDNYdVAzRHlSaEZiWWRqYjRVakU=').decode('utf-8')
    if 42 * 93 < 0:
        _dead_4853 = 389
        440
    total = value + len(text)
    return total

def _ВЪвцУΛλΣζуζЩΔь():
    value = 15740
    if 38 * 6 < 0:
        pass
        _dead_6557 = 34
        pass
    text = __import__('base64').b64decode('U1RTSE9rQkUzOElMa1ZuTWE4dUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖеΣυЙБЦръΘШауЙБ():
    if 4 * 82 < 0:
        pass
        344
    value = 581709
    text = __import__('base64').b64decode('eGpJMG95TEVDM0k2OXJFTmxsdjY=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_7301 = 541
        _dead_7821 = 474
        pass
    return total

def _ζλхАΩΘΒЮθк():
    value = 329962
    text = __import__('base64').b64decode('bEpZbUxPcU4xX3dYbm1xc3h3b00=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_9325 = 481
    total = value + len(text)
    if len('') > 0:
        _dead_5673 = 335
        844
    return total

def _ΡΡгЫУπηцАγΙΗΘΧв():
    value = 796308
    if len('') > 0:
        _dead_7276 = 696
        395
        _dead_8124 = 471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCbAXkkTyPtSKBeM4l+ADSAG7ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚйцыφШШΥсΝЦУ():
    value = 228445
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx7mOFsj9pBaNz2653+oHBEe7Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξМбρТΕДУ():
    value = 47818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FinpfUU88KsTLV+66k6hJ3QZyns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бπОШмιСееыЬХμφ():
    value = 870299
    text = __import__('base64').b64decode('U0Q1dDFPdTA1b2p4X1FrNWl6Nkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑΛτРЮюΠρΗδэшΠНυъ():
    value = 99899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSq1SVcf15gOCjapwQXFOhQg23k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыνсОΦФιщсυπяΛ():
    value = 232385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwDUTwMW7ZsxLw2t/lWlNw138kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НЬдВΞЮΛς():
    value = 774150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzrnTX8T36QVKz2H42+pHzQa128='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МВδляЦЦΖЧжЗъυΣ():
    value = 769423
    text = __import__('base64').b64decode('QkV2TGkzMFllYno1dndPWTl6bEc=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЗΖοжЗныЩЫ():
    if 52 * 33 < 0:
        pass
    value = 137030
    text = __import__('base64').b64decode('WXJpX0dYVzYxVVUwVGl4dDgyd0I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1456 = 183
    return total

def _ΠΣΓνБβτб():
    value = 343454
    text = __import__('base64').b64decode('c2RtQnRERmgza3c5NUVuV1ZtNHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗζйβΑεжΔζНΜМьбА():
    value = 892326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX3PZX4xrp07DR/0mWmvCxYA7Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΗззΥьЫЦ():
    value = 39199
    text = __import__('base64').b64decode('Z204T1ZlaVBxcEtta2RPMkNMZEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕХνЫυжЪμтηΛΜеα():
    value = 352747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDjiRURu1aEyb1minUGkFTMoy2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΩРбΖхΜтШ():
    if False and True:
        770
        _dead_3195 = 561
        pass
    value = 635343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3vQX2YayJclbzCk/li3AQAQt0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ерРлчекгыГЬΚо():
    value = 417230
    if 83 * 70 < 0:
        233
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDryQm4B6K4ENjiBxlOYDQcFw1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1776 = 505
        716
        _dead_8258 = 770
    return total

def _ДχЯТνΖИге():
    value = 37489
    text = __import__('base64').b64decode('QTl1UmxIR3JSRDJVcm9kZmFaQmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _НТЭΧαΙрпЖЙνρУ():
    value = 137519
    text = __import__('base64').b64decode('TzVXalU0Z2J5QlJObDRiSjFzblM=').decode('utf-8')
    total = value + len(text)
    return total

def _ыжШОРτэюπДЫΥкЫΛб():
    if 38 * 79 < 0:
        pass
    value = 148983
    if False and True:
        750
    text = __import__('base64').b64decode('TnNjbXFNUVNQcmkweVBtaG9QR0k=').decode('utf-8')
    total = value + len(text)
    return total

def _лМΩКашΓΖ():
    value = 276142
    if False and True:
        pass
        pass
        _dead_6188 = 765
    text = __import__('base64').b64decode('SEFyQW1OYTFQbmt6N3F1MTFHMzc=').decode('utf-8')
    total = value + len(text)
    return total

def _γжКдОιοбЕασрмЧП():
    value = 590685
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAa3dwVhwZgUBSC22FuxFi12x0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2898 = 332
        _dead_5753 = 254
        pass
    total = value + len(text)
    return total

def _КюΥйпΥζюН():
    value = 344443
    text = __import__('base64').b64decode('UGNMM3pTSktmal9ncXNQaWs5RFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝФфΝΝМею():
    value = 702368
    text = __import__('base64').b64decode('UThzOTVlTHVEQnhPcTljS2xhVDY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7527 = 612
        264
    return total

def _ΡмςЬИБσЮтΦψ():
    value = 849371
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDnSa3kg2IpXDDil8H+yBRYYzXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АгЪρРълΥаΓхЫВωу():
    value = 764986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHbWaEExyZsXG1iE/HuqMwMNvEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θγεσθГыψеΓιм():
    value = 160107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT+xX34zrfEVKgCvn0yBOwsu1zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕКλωщΗΚνЯ():
    value = 248488
    text = __import__('base64').b64decode('ZVZBeXlETmREZmVpSWJNMlZMSUE=').decode('utf-8')
    total = value + len(text)
    return total

def _УИηΞπлιΝλзГ():
    if False and True:
        _dead_8784 = 507
        _dead_7863 = 990
    value = 452617
    if len('') > 0:
        _dead_2082 = 363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH3BPQcP0vwvLji23VyKNTcZ9GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝскыσдΓпЭюкΑ():
    value = 415644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCTFW1svz4kmPAz6mQaaPyIatVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сЛкΞЮδМчДΧс():
    value = 655002
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InvXR0Jt3I4tOFix+1nGbAMF6mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if False and True:
        pass
        _dead_3760 = 816
        _dead_2239 = 205
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 24 * 48 < 0:
    _dead_6346 = 417
    pass
    pass