#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΤАψТукйωΥъЧЩзΜ():
    value = 366025
    if len('') > 0:
        _dead_2123 = 834
        _dead_5127 = 440
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgjHWX4Y9f5aGRan50W6OHYN9UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓЯзΓэоΓиΦΗРкζΓκЙ():
    value = 807106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwjAZF8hqaEJAjqx+Xq5MXc2wGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аαРочТΞΗИΝΘЦΧ():
    if False and True:
        677
        _dead_6425 = 940
        pass
    value = 224847
    if False and True:
        pass
    text = __import__('base64').b64decode('VG5qd2xQdkdLQ05Cenc3SUdSTVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ТЦцяΘηАξ():
    if 65 * 93 < 0:
        pass
        477
    value = 184350
    text = __import__('base64').b64decode('b1hGMHNrMWtGa3dCQ0ZUdnJqT1g=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        171
    return total

def _яΦМЮΖοΒДнΙ():
    value = 755449
    text = __import__('base64').b64decode('VUFZcEgwd1lCRlliOXBuaTRUNjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜτΑжγζмЯЧεъЧрг():
    value = 935475
    if len('') > 0:
        724
        794
        _dead_2487 = 446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ER3SeUttz7gUYz2O3VLJAj0k8zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 67 < 0:
        pass
        213
    return total

def _ШуΟОдΟΥцΙВδΨА():
    if False and True:
        _dead_9781 = 781
        852
    value = 631282
    if len('') > 0:
        155
        824
    text = __import__('base64').b64decode('WG5HRXRidzV3bll3VFZpWU1POG0=').decode('utf-8')
    if 1 * 84 < 0:
        _dead_6938 = 467
    total = value + len(text)
    return total

def _ОяЛьοΖλωΩωЩУ():
    if False and True:
        _dead_6574 = 794
        _dead_2890 = 150
    value = 303735
    text = __import__('base64').b64decode('S2w4YVBuN2U5aERfWmlBeGppcGQ=').decode('utf-8')
    total = value + len(text)
    if 95 * 28 < 0:
        849
    return total

def _ΞωЪаЩТπΜШΦЫТτ():
    value = 91021
    if False and True:
        505
        _dead_3989 = 399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyDddkshxvglEQ7xxk+8IXYms1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йфφфστΧΟЖхε():
    if False and True:
        965
        pass
    value = 51781
    if 13 * 49 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyPcOVsa3IsMAiuI+WOhLgR/3EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тбНΑзεΜыΣПнИМмиπ():
    value = 694028
    text = __import__('base64').b64decode('WFZ1YVZiTExIck1YQmdkT3pTazc=').decode('utf-8')
    total = value + len(text)
    return total

def _егμППЪюΘеиюУОР():
    if 26 * 43 < 0:
        _dead_5636 = 850
        _dead_1560 = 933
    value = 403750
    text = __import__('base64').b64decode('Rzh5QmhsamtqWXRmTjlfRHdweks=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪОΕзвςφλпι():
    value = 452589
    text = __import__('base64').b64decode('S2I5dTg3M0RLYmx0QWtsMkdiZmQ=').decode('utf-8')
    if False and True:
        995
    total = value + len(text)
    return total

def _тφτкΩэΛρδрγн():
    value = 387030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kzm3f1AR77gQKCqw7mydIxIO4Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣгзУαψоРСиБЕΠКЫв():
    value = 216203
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FibHNgA49/kBYguI4Wa0LXQZwEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        969
        pass
        629
    total = value + len(text)
    return total

def _ЯхΛфФξМяΩОгΚ():
    if 52 * 77 < 0:
        pass
        pass
        _dead_5056 = 130
    value = 698325
    text = __import__('base64').b64decode('RVdWTUx6dGw3aHlnZVNMdDRJazg=').decode('utf-8')
    total = value + len(text)
    return total

def _еπБτшЮюΡψαУъψΟЬσ():
    value = 198449
    text = __import__('base64').b64decode('RWhPTl9HbzBTQUdab3FtU1FjOEI=').decode('utf-8')
    total = value + len(text)
    return total

def _САмΒРηщΧцъяκВпЬМ():
    if False and True:
        pass
        _dead_6285 = 250
        289
    value = 71605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDa1f3QB94AmECv1m12qECEGz0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бζπΡЮЧΝδАαЖИ():
    value = 980478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISPpWHAQqL5XbyWi2lHFHzw443w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒРθωΔеΦФЫГдзκ():
    value = 657128
    text = __import__('base64').b64decode('bnFlWXpDOWx3alVCRzNuQW10c1U=').decode('utf-8')
    total = value + len(text)
    return total

def _υчΒГΟитιгШВцб():
    if len('') > 0:
        173
        pass
    value = 464690
    text = __import__('base64').b64decode('Wktzd1VWT28zclJMU0VXa2xpN0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧыυгеНΒГ():
    value = 105656
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnfiR3cTx65UFxX253XGB3cY7l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫοеΞсЮьθ():
    value = 834301
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTnmYwMy55cPNQ2mzUeRFy4/sTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΦυαРгнεЮчцλщ():
    value = 86634
    if 58 * 51 < 0:
        pass
        _dead_5571 = 809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DADQal4e0olQIgiA+wK6LDF3wEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        107
    return total

def _уπрΖБΞОιρсκО():
    value = 46857
    if len('') > 0:
        636
        712
    text = __import__('base64').b64decode('TlVIVXh4bDh1NWpxcDdKSV9PRlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖюмΕУыэΞМ():
    value = 530146
    if len('') > 0:
        _dead_2875 = 637
    text = __import__('base64').b64decode('d3ZOUW91NWlPQjRlcGFENlZzT24=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΨΖхОΞΧυΛ():
    value = 902617
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERbCZF1v/ZkHOzia5niYMC0V/jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТξКЬСдЬΥоДνт():
    value = 547565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyzXb0Mw3JFUCQCn0U+DEAAbwF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΞюдΟВΠч():
    value = 5082
    if len('') > 0:
        226
        _dead_5349 = 790
        666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCCxd3xq/JcsG167+gWqE3UB/UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыяφдлΕбАΔшΖчъΥК():
    value = 623273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DA3yd2cS9aslKyaux1WKJQMozmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДдтоиΠΖЕчыφЕзςΖ():
    value = 33834
    text = __import__('base64').b64decode('UjNiUGFtWGZOckswWVd2d3JXaFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ШζФцΞΔΗнРζΘεФμ():
    value = 115760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTjRd1wA36BUAyizzlHEFXcM0lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κЛζфвφлуξб():
    value = 26450
    text = __import__('base64').b64decode('R2ZVZVlYUG5nejhCRUlYZ0xxMnQ=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _УζμиЬιЮΗιЭγωλЯШш():
    value = 384213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCfKfUY7zr5TPQCLxFylFRYNsl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _жλЫφфμΛфθΚн():
    value = 169513
    text = __import__('base64').b64decode('RUZicmZjUGlSWnZEZ2M5cTlBTXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮуЙЬГωпΞθввю():
    value = 171054
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiXeRGALzf1aIAW5xWm+PXMJ1Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лУομΒσУЭπъζМх():
    value = 802456
    if 98 * 8 < 0:
        pass
        286
    text = __import__('base64').b64decode('djUzb0lIVXg5WGVnRzM5MktjOHU=').decode('utf-8')
    total = value + len(text)
    return total

def _дрбзяЗдШдВсЬΚΞъ():
    value = 33315
    if False and True:
        377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQPhWGMOqYw5Cz6PmmKiOXN55lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        351
        pass
        _dead_9389 = 599
    return total

def _цУΕΧθυХΝюар():
    value = 328325
    text = __import__('base64').b64decode('VElSa0V2VkpsUXRCQTZVYzVJekg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЮΦТχЪбςсЭμз():
    value = 379389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTX9NwQL3PEACyD2xgGvLiwd928='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СцΖΠρΟΘслдЭπяψΔ():
    value = 646624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnztYF8IxLspbhqRxnGSGzMpyGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _χшΞэЫъΦρ():
    value = 320771
    text = __import__('base64').b64decode('QjFlMEJkZmpjS3JKNU10dlh1THA=').decode('utf-8')
    total = value + len(text)
    return total

def _ВηΧΩЬИжУИΓщΥΕΔГ():
    if len('') > 0:
        pass
        _dead_4533 = 411
        _dead_7416 = 56
    value = 884037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iyn9alsdqP8VIymvn1O9DHA8t28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЬτψЙЬΡжΘφЦжνщЯ():
    value = 71690
    if len('') > 0:
        pass
        _dead_3639 = 693
        371
    text = __import__('base64').b64decode('UzdPcXN6dnB2aFJXVU9nc2Rac1I=').decode('utf-8')
    total = value + len(text)
    if False and True:
        596
        729
        376
    return total

def _μΣΚΦΘюЛНλбЪΧЭ():
    value = 890779
    text = __import__('base64').b64decode('WHkwdU9Gd3YxYUJKdkh3dHJFS28=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧξлЗκιЮшκΘΣз():
    value = 677530
    if len('') > 0:
        141
        578
        524
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDb8bGJr2v8xYi6L+V+iHw8MzHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗХчъΠхνВπ():
    if len('') > 0:
        _dead_3759 = 728
    value = 275195
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCy0f2MI+5wLPjuwwGSSGj8WyF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гбСοΛУфпЦγ():
    if False and True:
        _dead_9776 = 589
    value = 38272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCbgRUQRqfowEiyn8QfIGios0no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ХΠАλΗьйΚ():
    value = 945058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX3cfwEQ74AXNCq0kWPIBj8MyEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΕΣχΦΩБТψСя():
    value = 987854
    text = __import__('base64').b64decode('Wk5RbnBkT3V0WG1ncWhzTWZCYWM=').decode('utf-8')
    total = value + len(text)
    return total

def _πГξТΙГΧсГΔχ():
    if 100 * 58 < 0:
        48
        658
        pass
    value = 352676
    if False and True:
        151
        778
        328
    text = __import__('base64').b64decode('RUdrZzNzS2tsRHhFMzFJTVp0Vmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥюψшУюЖΨЪ():
    value = 546978
    text = __import__('base64').b64decode('VEJxdUlEcHliMUpZWkZfN2xHR2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮжчЬσΔЦо():
    value = 583988
    if len('') > 0:
        772
        pass
        _dead_8410 = 34
    text = __import__('base64').b64decode('WkdDektveXdXVHVJeFNZYnVtelM=').decode('utf-8')
    total = value + len(text)
    return total

def _рйъчΥВπιчηъТяЯЖщ():
    value = 961181
    text = __import__('base64').b64decode('a1pOTHBXUDJ2dlN0WFhJS2pybnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΝиαΗЗаыσжΨБп():
    if False and True:
        _dead_2347 = 36
    value = 279125
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjazPXQg3P00HiG15UTHCxQm93k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯкςЧΟδБτ():
    value = 550162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTnOZQgL8boAMTiwnFKGYCI97z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςЦВЛшЫСцΩАцλ():
    value = 260421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQ6xZUcu/74ELTaJylWeDi8f/kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 84 * 39 < 0:
        pass
        877
    total = value + len(text)
    return total

def _РжЬщЬЛОЛЬрΓμ():
    value = 528221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EifOXlU7y6MRaiytm1GKDiYF9zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 40 < 0:
        423
        pass
        374
    total = value + len(text)
    return total

def _ЬуΗРхНгЛдУξЩЩД():
    value = 902570
    text = __import__('base64').b64decode('Rl8wMzVvWXdkZlFKekhZa0dxR08=').decode('utf-8')
    total = value + len(text)
    return total

def _φПЖζτОωуЬЧвЗхмлΔ():
    if False and True:
        pass
        _dead_1752 = 301
        pass
    value = 637696
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQfCX2Eb9qoRO1qEnlSSOicb1GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 83 < 0:
        449
    total = value + len(text)
    return total

def _ιεωΙПΩбжЛΒЧкς():
    value = 869703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBewQ0IyqpIpbziCmkagFwwpyEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жИΖрШжЖσΗΙдГΟГ():
    if len('') > 0:
        372
        102
    value = 917390
    text = __import__('base64').b64decode('azAxWkxFdW5ZRVFEUVB2bDVKaUc=').decode('utf-8')
    if False and True:
        341
        _dead_3514 = 418
    total = value + len(text)
    return total

def _γχРυЮУФωЬуЩМΦЕш():
    if 47 * 72 < 0:
        _dead_6313 = 706
        342
        _dead_7245 = 556
    value = 604755
    if 86 * 100 < 0:
        _dead_8752 = 313
    text = __import__('base64').b64decode('aDh1cTJKVVlUaGlyQXlCbFFWQ2U=').decode('utf-8')
    total = value + len(text)
    return total

def _θПцОЬΧΥИДρъ():
    value = 417758
    if len('') > 0:
        _dead_9244 = 125
        6
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQnmd35t9fs6aF3ykA61Ai0+3Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕρОΥЛΧИΥς():
    value = 250829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQzuOwYdyfgyIgCh51iaGDUQ6kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _блИΟзφЯнΦΠПπфбΡ():
    value = 829271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTbSNldv2YtaEl+p7VeRHC126UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ивμζαΩдЦЕ():
    value = 329595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjvTQlAD9LkmNzmp0nOVEHch6VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бьЩшчρяИψ():
    value = 964404
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhnAW0ATrqAaEhm20F+vY3J77kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λНκφоУщтХΑЗΡΔΤЖ():
    value = 76725
    text = __import__('base64').b64decode('YVJzdlhIR2Y4bjA4VGFndV95M04=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΣДΥαΙχУэω():
    value = 890955
    if 25 * 58 < 0:
        752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITrJagJg2voVEDeFnnypMxIey3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ξУДуςρмХЭΖ():
    value = 339794
    text = __import__('base64').b64decode('aVdab204VDJPWE81cFRaMTA0U2M=').decode('utf-8')
    if False and True:
        919
        _dead_8420 = 550
        pass
    total = value + len(text)
    return total

def _ЗяΥФйнκЫп():
    value = 921323
    text = __import__('base64').b64decode('eUM4QUtrVE9JV1FCV0hPdHh1UDc=').decode('utf-8')
    total = value + len(text)
    return total

def _μНρμηΟЬδгΝτ():
    value = 170282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRXHNwE497FaFTqV0WSUYjI7vHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΖΟИяΨВШΦЕ():
    if len('') > 0:
        584
        _dead_4197 = 534
    value = 578342
    if 40 * 85 < 0:
        _dead_8826 = 772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwazXXQG+6s5NTip7gGILTAY1ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5309 = 843
    total = value + len(text)
    if False and True:
        449
    return total

def _ΘΘλщΖΤжяшΠЬуопУб():
    value = 85213
    text = __import__('base64').b64decode('V05jUVpkeDBmU2t3eWZMd0hhUzU=').decode('utf-8')
    total = value + len(text)
    return total

def _βГΦлСВЯχΤцжсνУΑ():
    value = 879750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwKwSURprJAQDQ6PwmKoGB855Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛВдКйсκΑζн():
    value = 571588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH3IOnxgxJInbBq54XWiHjMs1kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 56 * 52 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3111 = 486
        _dead_6451 = 689
    return total

def _ΧэςΗμΕКФБК():
    value = 6675
    text = __import__('base64').b64decode('SVlIZzh3VjJXSFN4a1hyYnRRSTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЭйκфΛШНзΒтЙΤггΚ():
    value = 456602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxzgYVsM6KQvKSyM/3OEFwY2yWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΣчΧаΙВβМыО():
    value = 473766
    text = __import__('base64').b64decode('QU9LaVhaRVZuZDhZaG1ZRDFodHU=').decode('utf-8')
    total = value + len(text)
    return total

def _гρρЮΜЕэιыъκ():
    value = 746915
    if False and True:
        636
        494
        _dead_3563 = 918
    text = __import__('base64').b64decode('Y2hRTEFyb1VFUW9HV2hJWUtsR2I=').decode('utf-8')
    total = value + len(text)
    if 90 * 52 < 0:
        841
        _dead_1757 = 671
        _dead_3024 = 82
    return total

def _пОмΚΒГΨьμДДΠκ():
    value = 752005
    text = __import__('base64').b64decode('SHRNaGZrNTNSZlBROW9tN21YZU4=').decode('utf-8')
    total = value + len(text)
    return total

def _λЫПμξРΗХа():
    if len('') > 0:
        565
        626
    value = 274297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Chb3anY8+JEuLzawwEWkbA4I7nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λчТюЮЩЛп():
    value = 785542
    text = __import__('base64').b64decode('VnF1c1IxRlZlbTc0bjZvTGl4UHo=').decode('utf-8')
    if len('') > 0:
        _dead_3305 = 36
    total = value + len(text)
    return total

def _дычОΔρюΣАзτНΓЩ():
    value = 672281
    text = __import__('base64').b64decode('dHFOb0xVWXY2UTNodnRQSDFRNng=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛξνЯщОшΗИшκ():
    value = 22754
    text = __import__('base64').b64decode('RVRsR3dCOHhQWWNqRXVLTks3UnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣЩωχЮЗΩΔТте():
    value = 222881
    text = __import__('base64').b64decode('cFFsNUt3N1dKbU1PRVhrSUhpclU=').decode('utf-8')
    total = value + len(text)
    if 96 * 16 < 0:
        pass
    return total

def _ζуаπДРфΨМσηЬИюву():
    if 51 * 41 < 0:
        _dead_6344 = 726
        _dead_4645 = 61
        _dead_9327 = 536
    value = 4823
    text = __import__('base64').b64decode('Z05vM09IdkZIN0Q0T1ZLNE84S2k=').decode('utf-8')
    total = value + len(text)
    if False and True:
        713
        604
        220
    return total

def _ТшЧμιΞΠнΠЩЪ():
    value = 389449
    if False and True:
        _dead_3220 = 492
        809
    text = __import__('base64').b64decode('cFN1dDZTbV9NY3hxaWhvdEl0OWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠρΛΩηЯИМΨрΗлΒ():
    value = 965996
    text = __import__('base64').b64decode('UnhwUTlwbVFOQUZrWGxoNlFMYWQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΨκчΛКхТδиг():
    value = 579144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBX8SVouq5A2Awv35GSXYzV4ymU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥγΨУуыΗΔТκШΗψτ():
    value = 483321
    text = __import__('base64').b64decode('YUY1c2pOWkx4SDdobjJuX2RBcHM=').decode('utf-8')
    if 26 * 52 < 0:
        pass
    total = value + len(text)
    return total

def _офΜЧДσξΟмМЮ():
    if len('') > 0:
        _dead_5141 = 192
    value = 93384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwPDTQIL6KBWPyW15kKxYRIL0m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЛφомΔθΤΣэ():
    if 27 * 2 < 0:
        _dead_7067 = 582
    value = 240613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQ39QXwPxq4IBS21mXWiBAYo4Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 69 * 88 < 0:
        _dead_9464 = 147
    total = value + len(text)
    if False and True:
        _dead_2897 = 322
        _dead_7338 = 975
    return total

def _ЗΖиπщыЗΤ():
    if len('') > 0:
        pass
        _dead_5853 = 364
    value = 73748
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDX9P1QD9YosAiaE8GfEOwk3zX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        991
    return total

def _хρШХаъЧωдНЗЩХ():
    value = 655840
    text = __import__('base64').b64decode('Z0g2Rm13ZXdWMFBjcW1JSlU5NEw=').decode('utf-8')
    total = value + len(text)
    return total

def _шгΔЫΧЗАκ():
    value = 300217
    text = __import__('base64').b64decode('UFlpMjg5dEtzTGJvMDhjQXV0cUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮσоЧΞГцΘ():
    value = 149657
    text = __import__('base64').b64decode('cFp5X2hSTnBjUHdpcmZpQ3FvZzM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6312 = 514
    return total

def _αЙΨмхХχЫφΝΕБЧΙΡ():
    value = 11216
    if len('') > 0:
        pass
        228
        73
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRCzSwMpz6E7CgH2y26eGQkDsV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пВζΝФΦΨю():
    value = 591488
    text = __import__('base64').b64decode('R3RMU0hMS2dYbTBVRnNHSVB5Z3o=').decode('utf-8')
    total = value + len(text)
    return total

def _οАушΝоςΦхбСαЦи():
    value = 697068
    text = __import__('base64').b64decode('TEg5dHpDVlVjR214cnowWl9CSWU=').decode('utf-8')
    total = value + len(text)
    return total

def _иΝκρбτбЪι():
    value = 223674
    text = __import__('base64').b64decode('YW1jcHNJb3dQNU02TENGVDUxdkc=').decode('utf-8')
    total = value + len(text)
    return total

def _τсЕщжΣЫΞе():
    value = 170570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASXLb1Iu078ULVax3Qe4YnAF9lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юшρφΚцдΞβЯИбФ():
    value = 509465
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JymyVlthyIc7Fyug2m/BDid7sGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3174 = 646
    return total

def _ЕΡΛωЫЕτΡэχЧХяРΩп():
    value = 102005
    text = __import__('base64').b64decode('S0FPdFJSMjdTVlVpQktWT21XWl8=').decode('utf-8')
    total = value + len(text)
    return total

def _лЧчИβйАЦΟбυВСя():
    if len('') > 0:
        _dead_5902 = 356
    value = 505314
    text = __import__('base64').b64decode('S0dHbkhCdm9CamtqdVhNdjQycnM=').decode('utf-8')
    total = value + len(text)
    if 70 * 50 < 0:
        _dead_8274 = 721
        133
        pass
    return total

def _ГζΒΠΩиνΙ():
    if 44 * 68 < 0:
        789
    value = 910832
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgrwbXwu9o8zFFux4FC8AhQgtls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бчΛЮφОЕα():
    value = 228622
    text = __import__('base64').b64decode('eVhmUE5rellDSzNTR25zeG5GUEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΔРфЫНρяжГЭΚ():
    value = 511106
    if False and True:
        _dead_7450 = 810
        908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASTsbEVrypsLKw7x3n+cMgcM/Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕЭнЦνσвяΘ():
    value = 746809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCLbb0gX5/0gESCs6kW9BxEGsTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 91 < 0:
        513
        _dead_9031 = 843
    return total

def _ΜΖЗσНпΕψΥΥΙМΡмюй():
    if False and True:
        726
        _dead_9351 = 94
    value = 110432
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgnBTQYjqaAhKjbw3nqhIBN90lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λερβПψиςφΙΞж():
    value = 930598
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC60UX0+q/8lBS2W6VqUHioZt3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΡΛМЫΘдэлЯΝПηΩ():
    value = 417665
    if False and True:
        _dead_4730 = 675
        pass
        320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng3PXgEQ1IMuEyTzml+RIw0Qtjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ГΑЫΚΥτΠΓТхρλΠВч():
    value = 887931
    if False and True:
        _dead_2222 = 720
        pass
    text = __import__('base64').b64decode('UEpzQ0hWVXR3T2ZRS1FwQW80Y1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮщжмςΨεΘе():
    value = 575257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cia9fncSq65WHiug/WnEOxQl8Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 82 < 0:
        _dead_6819 = 72
        _dead_2205 = 987
    total = value + len(text)
    return total

def _ΖЫΙΥщпηБЭяοПО():
    value = 619674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eje8N2gbyoIHCxqq+F+1NhI88Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        194
    total = value + len(text)
    if 89 * 21 < 0:
        381
        pass
    return total

def _ΝΚσψЫятΣδκЙ():
    value = 632537
    if 21 * 41 < 0:
        _dead_4157 = 184
        pass
        823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DALtO3oc6pk6A1+cn1SmZQ8nwjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        633
    total = value + len(text)
    if 83 * 73 < 0:
        pass
        pass
    return total

def _ΕβΔφβтΒзь():
    value = 749685
    if len('') > 0:
        638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjvwQ1oa/Y48HC370GWlC3QV7Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кжΥыацΨппэβТικο():
    value = 757008
    if False and True:
        _dead_1901 = 963
    text = __import__('base64').b64decode('bHVpd201WEJHajA3T0lIMXdMZFE=').decode('utf-8')
    if 93 * 81 < 0:
        141
        _dead_3177 = 759
    total = value + len(text)
    if len('') > 0:
        _dead_2548 = 139
        550
    return total

def _ρиχОδтΧнΔгШвΩИЧ():
    value = 886185
    text = __import__('base64').b64decode('Z1kyOGtES1Q1b0RPRDBSSTVFckk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΜФΨΓΣΕЧΩοА():
    value = 639147
    text = __import__('base64').b64decode('U2NBV3k2YU5xRFZYTExXaF9Ld0U=').decode('utf-8')
    if 73 * 19 < 0:
        911
        _dead_6347 = 544
        _dead_2822 = 427
    total = value + len(text)
    return total

def _γЩюхкΜтнеΓ():
    value = 669512
    text = __import__('base64').b64decode('YWhIenhUQzdUOWZXakxrMXNIUUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓсΜΓбοΠΕДΡαи():
    value = 153560
    text = __import__('base64').b64decode('Z0FpVVhRckp4SmFFM1FTaEYwaE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩЫγωδмЬΟωΘйШδЬ():
    if len('') > 0:
        _dead_2343 = 676
        _dead_3583 = 185
    value = 947107
    text = __import__('base64').b64decode('Q1FVNzVUbzFWdFJpbGdyd3FMN1U=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _зΠЯΥΖЩιψΒσΩтΩЭ():
    value = 556774
    if False and True:
        pass
        _dead_6361 = 598
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LijceVht+4sXbxWi7UybGDIutH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сδΜЧИйгσΝΧΨδΛΛγВ():
    value = 985397
    text = __import__('base64').b64decode('WlpkX21Wdk90VnptekN0T1NrNVM=').decode('utf-8')
    total = value + len(text)
    return total

def _мЖПШψΩФе():
    if len('') > 0:
        pass
        838
    value = 767642
    text = __import__('base64').b64decode('a0xfeHNmSUZrSmRTQU15bmVZeDk=').decode('utf-8')
    if 90 * 32 < 0:
        pass
        9
        648
    total = value + len(text)
    return total

def _ъьμσыΤДцРωφψж():
    value = 561406
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhnmN0cf8bxXDhf0kQOAPRca61w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΥМΣЗвЫфЧяΟψ():
    value = 106138
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBrpVH8u7vssaAD7n0KcEAEA3WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αЪιΗьпςФдωВэΑБ():
    value = 941271
    text = __import__('base64').b64decode('ZEFKSlc4Z1dEUWdmNXVoc2ozNVc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5167 = 986
    return total

def _беЮΤиЕΡЖ():
    if 51 * 97 < 0:
        _dead_4539 = 638
    value = 32432
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCnPakM//as2DCbwzlqyOxMF9n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юαИъЦыςИΖлρЫξσ():
    value = 945724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzrrYFYy+78sA1iZwXCkDjUE/kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 26 * 97 < 0:
        395
        _dead_8876 = 476
    total = value + len(text)
    return total

def _μΝЦνΣηρьτзЛΒςб():
    value = 27527
    text = __import__('base64').b64decode('cVkzTlg3Q0tJYjRZS3dwcUJXbzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _χШΡΓЕСξфγбуΨЗН():
    value = 917290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyDrRQg3/YkrHRau2EKHZS4O214='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _χιБъЯаεΝΜΜΧО():
    value = 776131
    if len('') > 0:
        _dead_9629 = 180
        _dead_2383 = 86
    text = __import__('base64').b64decode('d2lyTEhMUEhDSk1zdWpPWVljRFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ГВγΞЙуαЪ():
    if 86 * 29 < 0:
        pass
        112
    value = 772977
    text = __import__('base64').b64decode('aUhNS090ckprYWg4eFRjSGRVbUE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        658
        pass
    return total

def _ΖΔςПйΧкξьеСнсчщ():
    value = 357972
    text = __import__('base64').b64decode('ZlpYZWZ2TUJkWWNWNFhSV0RxSFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡвφГιйΖсуθκшВ():
    value = 667370
    text = __import__('base64').b64decode('bVhmYnRSQVpST1VhMTRpVDJPanY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫВрΤодГчψжηъΕ():
    value = 416740
    text = __import__('base64').b64decode('cEY0QkFfVlhoODd0Y0xPa01zR20=').decode('utf-8')
    total = value + len(text)
    return total

def _йΝЕьиЯцηЗΜεΧτ():
    value = 604700
    text = __import__('base64').b64decode('cUNYNU1rM0V4TlU2UXBBMnptaE8=').decode('utf-8')
    if len('') > 0:
        949
        pass
        _dead_1000 = 751
    total = value + len(text)
    if len('') > 0:
        154
        pass
    return total

def _НдιШтιΝИ():
    value = 574956
    text = __import__('base64').b64decode('ZXA4S1dhMEJEYXZnV1pyNEZpNlg=').decode('utf-8')
    if len('') > 0:
        _dead_8448 = 980
        pass
    total = value + len(text)
    return total

def _οнЦγкЖαЭφτлЦβςЖ():
    value = 436331
    text = __import__('base64').b64decode('dlYzOHpmNXFTa0Zqb2pqV3ZFN3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ТμτОпоЬпеΞψτЪ():
    value = 430739
    if 80 * 17 < 0:
        197
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA7AXG44qYwwH1qozFe5OgwDwGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        587
        pass
        _dead_1463 = 739
    total = value + len(text)
    return total

def _мЕжэКщЧςдрζ():
    value = 2982
    text = __import__('base64').b64decode('dzJsTnl0ODFTOXUyS2U3XzBXdGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙКиδΡψΒΝΩттЦΩчч():
    value = 170542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChzMQWMy9b8CHw6p7lGoARUh90w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩФЛβЛхюзΛЭяГЧθАΑ():
    value = 648164
    text = __import__('base64').b64decode('SHlOeld6VlJKTGpIc0t6V1JtTzk=').decode('utf-8')
    total = value + len(text)
    if 53 * 53 < 0:
        536
        _dead_2602 = 494
        867
    return total

def _фνΠΕЯкιФΚмЛКДШΧψ():
    if len('') > 0:
        pass
        76
    value = 418269
    text = __import__('base64').b64decode('UkJEc0NGZU5ENU1kdElXc3pwVFY=').decode('utf-8')
    if 28 * 47 < 0:
        _dead_1762 = 758
    total = value + len(text)
    return total

def _ьЭΣθщрРΖωЪнъСΛЛγ():
    value = 694011
    text = __import__('base64').b64decode('TFA5RmNsNl9lRzVaMFVJVkJaTDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝςψγсЮтςΟυΝТц():
    if False and True:
        817
    value = 151471
    text = __import__('base64').b64decode('Yk9JakFGUk9BeHdxWG5MQzFuMkw=').decode('utf-8')
    if 29 * 32 < 0:
        _dead_5839 = 88
    total = value + len(text)
    return total

def _εпшЭΑπηЩξЧεГξΒс():
    value = 264927
    text = __import__('base64').b64decode('blBLejNYSUR4QXIzN0loc1Bnd1k=').decode('utf-8')
    total = value + len(text)
    return total

def _МΠΝХΑΜдФγПурЖτ():
    value = 967437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyTvVgRr+JEULFuFmWSBBhMg7X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫгΩΨпрСжφΕΧа():
    value = 935240
    text = __import__('base64').b64decode('amRGb1VyallqZzZMV205WF9Pbmw=').decode('utf-8')
    total = value + len(text)
    return total

def _мЩЖдЮπОн():
    value = 806734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiflTAQs2o8hOzD1mGmlYjUovEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПдМΜεуКΤ():
    if len('') > 0:
        _dead_4087 = 361
        296
    value = 660813
    if False and True:
        _dead_1383 = 197
        _dead_2204 = 415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAncTWQ9/7ghFlatwUanHiI88Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧшдχвдыдРυжβЫ():
    value = 801061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRzgNlYh0ZsAbyWu4meWGHcu3mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΦψυΨΕИΧ():
    value = 491539
    if False and True:
        943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQbxVFwp9okHH1qkkHOIPXIVwDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        298
    total = value + len(text)
    return total

def _ζΓΘΗСэΠУΒ():
    value = 243775
    text = __import__('base64').b64decode('RVd4amV5T2g4TWhneF9leHd5dnM=').decode('utf-8')
    if 38 * 54 < 0:
        pass
        697
    total = value + len(text)
    return total

def _цыТЩвтЭАЛΥθΑзζΙ():
    if 30 * 39 < 0:
        pass
        871
    value = 574103
    if False and True:
        pass
        _dead_6244 = 241
        _dead_1140 = 367
    text = __import__('base64').b64decode('ZkFCMXBYMGlxNlpGbkxOcmN6VVE=').decode('utf-8')
    total = value + len(text)
    return total

def _οΠΤΚΝΘΨρюΓςХ():
    value = 14751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhjjQ2AJ3LxaNieZ7lGqJAEF7EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыГοЦБМЪл():
    value = 332905
    text = __import__('base64').b64decode('dTFCcXd4RFJBMVhRd2ZsTGNuZmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ТмψΥψΘΧΡΤЭмΛдпΥΦ():
    value = 10669
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAjORgkVzYw7MS2u2A6bDBR51GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζδωиΟΘАнФъπΛΚСи():
    value = 811778
    text = __import__('base64').b64decode('YmNqYld1emRWQmFOa3BvVHdsN3c=').decode('utf-8')
    total = value + len(text)
    if False and True:
        75
        pass
        pass
    return total

def _УσКνлщЙЭЦдФΨщ():
    value = 274604
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lg7wfVsO6IUNbjuWm3OdEAQbyGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        9
    total = value + len(text)
    return total

def _ЗщΓИςΖλдрмЕэρμмл():
    value = 103378
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EH7LNmcu05wEPwSPxXy9OyoH70M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вχыпσкБΔ():
    if len('') > 0:
        102
        _dead_8443 = 748
    value = 78688
    text = __import__('base64').b64decode('eHN4QkVwMXpSRWxwSXBjRlVkUHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ςыπωΥшβнЪφ():
    value = 4341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I360PgYI8YJQax675XeKYzEp8js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зςηΝυыΗАж():
    value = 524475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgrcewEP5qUzKBmLz3iXZT0I1Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΠьцУбщнрЖΧЬъ():
    value = 407411
    text = __import__('base64').b64decode('Q3R3M1owZV9nQVFfcnlBSEVvSkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛпэμоойнЗЙΓщ():
    value = 665858
    if 81 * 11 < 0:
        977
        pass
    text = __import__('base64').b64decode('d3phMVRkUG15ZHMxN1E5eHlFSlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ьлξщΖЪВΜΧвΣЕ():
    value = 601908
    text = __import__('base64').b64decode('YVRfVEFqMld4YzVuSWNSYWlyaXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣζРБчЬщΓΖζ():
    if len('') > 0:
        pass
        pass
        111
    value = 371118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR/tO2gp26I0EiGbnlCEHih37WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χпкЫξΗМΘΝ():
    value = 724354
    text = __import__('base64').b64decode('WGtSZlVSTjlacDVFVnZmR1BQdWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨЯψΨАуюпΙξХΒш():
    if False and True:
        pass
        117
    value = 589191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX3zfG4A6LhTFgqs7l+ROxd/0Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1862 = 180
        _dead_3514 = 429
    total = value + len(text)
    return total

def _ιкцΧлЗΞыжΚдАЩ():
    value = 562965
    text = __import__('base64').b64decode('YjYxbXVKOHFvZU1zQWxUOG1ueW8=').decode('utf-8')
    total = value + len(text)
    return total

def _εθКΙЕΟЭμτΖγΓцю():
    value = 687110
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDXnTEsIr7wxHD+JxQSvGhEW93g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кыЖюΝвьυРЩφксРО():
    value = 87043
    text = __import__('base64').b64decode('am5ibUc1cW15Zk9xQzlRWmJCSks=').decode('utf-8')
    if 88 * 85 < 0:
        _dead_1922 = 307
    total = value + len(text)
    return total

def _ЯзτЯЛщБьяАЫмгυ():
    value = 646393
    text = __import__('base64').b64decode('RXd0aEd6NGJxb0VZZU1GSklOZ0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΨαцлыаπЯΝкнπб():
    value = 293664
    if len('') > 0:
        292
    text = __import__('base64').b64decode('WkgxT3BxVzNGc0I0Z2N1MHdYcjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЖΔуэЙЧπУΗ():
    if 17 * 77 < 0:
        879
        _dead_5524 = 485
    value = 531477
    text = __import__('base64').b64decode('eGZIZWhINTNGSDBLOExRRkIzYUY=').decode('utf-8')
    total = value + len(text)
    if 1 * 78 < 0:
        49
        pass
    return total

def _ЬиОфΑРΩχΥηςμздЮξ():
    value = 109972
    text = __import__('base64').b64decode('WEhnUnJQdkd6WUlvd0RXSTdLUG0=').decode('utf-8')
    total = value + len(text)
    return total

def _фУξхПдβГΑЬμъΕ():
    value = 345912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jgn1aX8z3L4ZNSr6+kLGZSIX0H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сцЬожзλХ():
    value = 245133
    if 72 * 26 < 0:
        932
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KibnSXlqxIkAESuKnWC+HRUs0EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫнΒьйзЖщΙкКиь():
    value = 978727
    text = __import__('base64').b64decode('Z3dOVnVURVB2UUp6Z1RsZ2NxMlY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5280 = 524
        pass
    return total

def _ТхЧυЯЮшЧ():
    if False and True:
        pass
        866
        pass
    value = 808266
    text = __import__('base64').b64decode('YkU0dkZVVmtwNGRRdlhuZ2d6UDU=').decode('utf-8')
    if len('') > 0:
        _dead_3114 = 255
    total = value + len(text)
    return total

def _бЭχыγяνρГ():
    value = 380563
    text = __import__('base64').b64decode('dnJ5THV0cDhlOXBMeG1sRnhjdkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝηтЕЬНοдмЧΘ():
    value = 869036
    if False and True:
        998
        _dead_7779 = 720
        509
    text = __import__('base64').b64decode('eHgwYk9ET3dxdk5lMHBJYkczMzg=').decode('utf-8')
    if False and True:
        pass
        213
    total = value + len(text)
    if False and True:
        pass
        pass
        0
    return total

def _кВχλЗйьΕΦςыцов():
    value = 547218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxrnQWAG8LBWAwCFwVfBOiF8sEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χшΔУΑπξрКзатЬς():
    if len('') > 0:
        352
        620
        pass
    value = 239855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LS7hT2dr270gKzDz2GG4LS8szUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОТЖйХМыбхυА():
    if False and True:
        _dead_9853 = 288
        _dead_4179 = 968
    value = 551136
    if False and True:
        585
        638
    text = __import__('base64').b64decode('RDJGOGs5Vmh4T192WE11QWxJVlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ъцΓЛСΜюпζЖбθ():
    if len('') > 0:
        830
    value = 776892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQrUPlIo9ZEVHDCH6wezMDct1X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        186
        _dead_6696 = 974
    total = value + len(text)
    return total

def _ЬСоΔМьшЛχшξЛЪυэЛ():
    value = 463328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISXJTVAw544UAAKi6UCmFSp/0D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пдΑшЭнцψωλЫЪфЗБ():
    value = 81567
    text = __import__('base64').b64decode('c0xNeWk3aGJJMGFwM2xyRThkN2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЬΡЬЬРαΓМ():
    if len('') > 0:
        pass
        pass
    value = 587811
    if len('') > 0:
        3
        pass
        pass
    text = __import__('base64').b64decode('bDFlbms4R2d1SGMwVGFNNlluWVo=').decode('utf-8')
    total = value + len(text)
    return total

def _щмΩОЙξБеьУπИ():
    value = 839055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mgrhb0I0yYwtCl2rz2CqMCA900M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЫГИШЙφМУСθЭτЯτ():
    value = 687636
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCvsbWA78f1WaSiz6QeGZHI/yXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДκΜДфχФΗЙГФяΘпωО():
    if len('') > 0:
        pass
        570
        _dead_8604 = 472
    value = 679876
    text = __import__('base64').b64decode('Vm1vcFNkZzZZQks0MkdPTWlRV0o=').decode('utf-8')
    if False and True:
        _dead_5844 = 373
        _dead_5172 = 786
    total = value + len(text)
    return total

def _αΜРЙЧγВСΙα():
    value = 965850
    if 86 * 82 < 0:
        181
    text = __import__('base64').b64decode('UTR0NnhKTmprS2d6cU1VcjMwN1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖэξрαгшрλΤ():
    if len('') > 0:
        _dead_4435 = 343
        256
        pass
    value = 736559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXjBN34fqa4PaA7y8lyqGBMC634='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        533
        _dead_6619 = 373
        pass
    total = value + len(text)
    return total

def _ЖэшпσЯΤЕсТ():
    value = 81786
    text = __import__('base64').b64decode('S3ZMOWIyTTNScGJQczFwSW1rYW4=').decode('utf-8')
    total = value + len(text)
    return total

def _АмΓбащΓπъ():
    value = 272736
    text = __import__('base64').b64decode('QWJhajQxa2R1eEZXSUVtZHNaaWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЫαюζΛρΜъψ():
    value = 790005
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgblY0kzrqEtPwai93KbIDIV8DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СхΓΘΛчβШНиω():
    value = 717239
    text = __import__('base64').b64decode('Z3NfVENKamJxNmFmOXFGMVB6SUc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        412
    return total

def _ЪЬВβПЙτδ():
    if 8 * 1 < 0:
        225
        _dead_7430 = 646
    value = 537356
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiLlN0AO0IwKFhma5VW9By4NsDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηЛрБРηЖЮΜФΤНзΖЯΧ():
    if False and True:
        698
    value = 445758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izv3Zgkh+6olbVqOzw+xDgF6yXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЖЧΗЦЛΨсωΘЬюЖОця():
    value = 727858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCDPfllt+flXGD6U7GCaDhoGymI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шзЩΖκхΑНЮб():
    value = 660288
    text = __import__('base64').b64decode('b09HYXY2dzN6cDk4eWtIVVhGNXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _РΗΡτмнЗоЬ():
    value = 512659
    if len('') > 0:
        pass
        _dead_6875 = 3
    text = __import__('base64').b64decode('TEkxS0RfYmtnTjJpcVE3QXB1Tm8=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_9667 = 906
    return total

def _ωПЫΑъρЕЬаΚщаξж():
    value = 13710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAPGUUcQ9v8ZHluK/0+TDhUpsz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДяψМдηНχУОЭЯТ():
    if len('') > 0:
        pass
        643
    value = 604153
    text = __import__('base64').b64decode('WU5lTVJ3WTdHUHYwRm44OHU5RTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if 2 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    _dead_5413 = 921
    557
    pass