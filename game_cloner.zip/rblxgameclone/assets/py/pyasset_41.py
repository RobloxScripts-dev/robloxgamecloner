#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΩаБоЫЦγτыЖмΜτΘ():
    if len('') > 0:
        443
        22
        _dead_6103 = 390
    value = 121820
    text = __import__('base64').b64decode('VGwyOHhZNXo3bzNUTW5RMWdXQ08=').decode('utf-8')
    if False and True:
        pass
        281
    total = value + len(text)
    if len('') > 0:
        _dead_8004 = 513
    return total

def _ЛΟΣγэыΦфцГвΒ():
    value = 418034
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDnrPFg+7oIkIyTznHK5Jwh642A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιΨЬκфОюИчЮйρаьБЩ():
    value = 527780
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTveZVlq8PoQFzWn/AO5EBB90Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑτΞδБеЩΓАЯмΡΓ():
    value = 621342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhnRYl83+bosOSOQ+UWRGjU66UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πεЫοЭФεΤкЛм():
    value = 723031
    text = __import__('base64').b64decode('THBKYVVvT0tmWnRFSzJYTGVlSUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ШКκоЖλΣВюлИДδс():
    value = 215857
    text = __import__('base64').b64decode('bFRoVElmS2xENXg5V3plTV9YckE=').decode('utf-8')
    total = value + len(text)
    return total

def _ξнΥνΩуβРрΙΓЛ():
    value = 143489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCXoeFI424UBEzaM3mW8PgB99To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗπХЦυСγΨиНЩ():
    value = 226972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR3yal0G76RUFyiF3kGoNhMN0kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хνьΨτтюςΖΗщΝш():
    value = 916018
    if 10 * 63 < 0:
        _dead_6000 = 821
    text = __import__('base64').b64decode('bTdfM1hYeWVPeHNTS1lCX201QmY=').decode('utf-8')
    total = value + len(text)
    return total

def _йнτφВΛΣΚΚαв():
    if False and True:
        pass
        pass
        pass
    value = 341760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz71N2Jg9KFaAD+N7we/MCkktUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χВЪщэξжЬБΘЩΞβ():
    if False and True:
        210
    value = 964998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgjMVGgvqqAxNASWxk6pAAsr9GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        141
    return total

def _ΛНРμуηЯПТеτДрЯсД():
    value = 890533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3nbZGg3ypoOCje6nmSCJB8dsmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тбэзΑΑτку():
    value = 440978
    text = __import__('base64').b64decode('RzUwdVJLQjBPQmxtX0pVX2FJT2U=').decode('utf-8')
    if len('') > 0:
        392
        532
    total = value + len(text)
    return total

def _ььΦρВΔгΣγζ():
    value = 716939
    text = __import__('base64').b64decode('T2MwM3h0dUdfOGJhTFo1akd1WW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙбЙψΛЗтЕ():
    value = 687734
    text = __import__('base64').b64decode('aHZQRkg2TFlUcW96bVRhNFF5NWg=').decode('utf-8')
    if len('') > 0:
        _dead_4510 = 209
    total = value + len(text)
    return total

def _θРπΞдΓВΓцΡκТβАЖО():
    if len('') > 0:
        154
        898
        _dead_2946 = 109
    value = 459475
    if False and True:
        665
        pass
        pass
    text = __import__('base64').b64decode('WWY4eFI1VlNFUVdEX2JpemdHVWE=').decode('utf-8')
    total = value + len(text)
    return total

def _κυФАιΔгωΒЕШЧ():
    value = 124015
    if False and True:
        pass
        _dead_5797 = 704
    text = __import__('base64').b64decode('WWplOGJhZ0ZDemNDVkd2MlhOMEU=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        256
    total = value + len(text)
    return total

def _ОΧωГлΓβнцγг():
    value = 48629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQTuZH4c97lRPVqR6wKTFn0q3H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 56 * 6 < 0:
        pass
        _dead_3498 = 25
        _dead_5216 = 612
    total = value + len(text)
    return total

def _иσОΝЩУтΓΜ():
    value = 972316
    text = __import__('base64').b64decode('TndmRFE3RlY1WHlNY2p4UWFDTEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚГξΦΡΑТЪшΓЪ():
    value = 216309
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyX9OGcO77tRYieA/E69PzYtsmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _йτЫчΒξшΓσТΚрХЗ():
    if 66 * 84 < 0:
        pass
    value = 971182
    text = __import__('base64').b64decode('bHptVk9hSFVHQmQ4WkVZZk5xdUM=').decode('utf-8')
    if 36 * 46 < 0:
        pass
        pass
        674
    total = value + len(text)
    if False and True:
        _dead_1182 = 422
        _dead_1411 = 713
    return total

def _μцвьЭьΝμΧу():
    if 53 * 75 < 0:
        _dead_4834 = 438
        818
    value = 946128
    if False and True:
        pass
        _dead_8764 = 486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3jURgcOqY46DhqSxQe/Di4N0Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚгНγПпΤθЮΛ():
    value = 434821
    text = __import__('base64').b64decode('aDlxVnB2c3B2QWpiY1pZUl9NNnY=').decode('utf-8')
    if len('') > 0:
        771
        pass
        pass
    total = value + len(text)
    if 83 * 38 < 0:
        _dead_6375 = 41
        679
    return total

def _ΡΕВгыаΜΒЛСщрΙω():
    if False and True:
        pass
    value = 557984
    text = __import__('base64').b64decode('amgxbnRhajJ1aVN0N1hwRl9RX18=').decode('utf-8')
    total = value + len(text)
    return total

def _ауДпъΩχПΙЭ():
    value = 679260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxbSaEcD56kWbgms71OlbCcpxmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЫΝКРψНзυΒψнЖ():
    if False and True:
        pass
        pass
        pass
    value = 444120
    text = __import__('base64').b64decode('ZFo5SHBGaDlCMWdmemVZdVdSMFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _дыδГЕчиςьЭЛΖΝοкХ():
    value = 19060
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAzlOlIGprA5IwCpwU6nAhx5/WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жИХзΠΤΝЪиυд():
    value = 22529
    text = __import__('base64').b64decode('YV9qMk1TSlh3RGxnSVdOZXZ4NVE=').decode('utf-8')
    total = value + len(text)
    return total

def _υлОσззЫнБΥЭμ():
    value = 938506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axjne1APr54qEwC3m1DELA4+3Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΟυээрДА():
    value = 932877
    text = __import__('base64').b64decode('c0RPaTFWbW5CTUp5QmRfSTRidEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖαиЫиηΖвΛΧБЦзδ():
    value = 184441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fzf9QkEJrYtQCyKOnlOlYik46Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        259
    return total

def _χγНΩШХцгσЩмщтζЩ():
    value = 511165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECHLPAUQ9qA8IDaXkAe1OCk+yDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТвβуцПχфξχоεЗαΣ():
    value = 100836
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3f+YmkRr6oSDTyS4keULBEX5WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΤНιυδЧЫПИкгсе():
    value = 831475
    if False and True:
        546
        255
    text = __import__('base64').b64decode('SXNtUUc1bWsxVkI4Y3RTbVdJc0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ПКλБΗпйΚ():
    if False and True:
        _dead_6777 = 81
        pass
    value = 533895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhDeTAgS9Lg2EB2VzkG1bXcGsV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        732
        _dead_1697 = 944
    total = value + len(text)
    if len('') > 0:
        pass
        943
        _dead_5251 = 874
    return total

def _еИъΘΜЦэЫсТ():
    value = 209603
    text = __import__('base64').b64decode('VFNQME94U2NrQUlvNVpOalV4NW0=').decode('utf-8')
    total = value + len(text)
    return total

def _тЖаΩБЛрκΜββπОУ():
    if 74 * 9 < 0:
        629
    value = 394328
    text = __import__('base64').b64decode('RHN4bzZaTXd1b2V1bUlDUndZV3c=').decode('utf-8')
    total = value + len(text)
    if 82 * 29 < 0:
        694
    return total

def _кшБУΟΘΒπα():
    value = 873840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ajb3TWUR0PE0KV+18HKoHQcN5zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΚΨОдλπζφраИЮ():
    if len('') > 0:
        267
    value = 838446
    if len('') > 0:
        _dead_4177 = 576
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDbdV2kQybIQbCK533mRDgEJxmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘйхйвЩΝΤчтκ():
    value = 903774
    if 10 * 91 < 0:
        pass
        _dead_1573 = 645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgTJQ3UK6KwLLDj33U6HY3wO4mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 64 * 21 < 0:
        _dead_1699 = 182
        pass
    total = value + len(text)
    return total

def _бΚβυСаΙкνΥΧжα():
    value = 308820
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAnve0Ucr4lWbjer20yIH3EY7Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΘфЦχзГΛЪΜвЛΨ():
    value = 937114
    text = __import__('base64').b64decode('ZHJmZDFneVN3WUZqOThQdjdlZm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦБΘΘζРуШЖ():
    value = 912761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnzRPFcO8oMBaAur/VChAT025Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΕΙΩУзΒфсΙеЭ():
    if len('') > 0:
        pass
        _dead_1628 = 999
        793
    value = 487591
    if False and True:
        _dead_4356 = 784
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JibTT14T2Y8yYimCnneWYzJ3zWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рεδτЦΝТьйγ():
    value = 26024
    text = __import__('base64').b64decode('UkZnOGRYMVV5SVBuOGc1dGFFN3g=').decode('utf-8')
    total = value + len(text)
    return total

def _лςоЭΕπтРΣ():
    value = 757591
    text = __import__('base64').b64decode('bHhJc2VxY2NDVmhyRkQ1ajJ0SjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘОδШφиМсχΧхΛ():
    if False and True:
        _dead_8051 = 756
        41
    value = 355434
    if len('') > 0:
        pass
        pass
        7
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cyezf3YD6K8uCA2p336EGyE7x0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        16
        _dead_4142 = 477
    total = value + len(text)
    return total

def _нЪЫЙтЪΤυΥΑиЗΠ():
    if len('') > 0:
        pass
        pass
        _dead_6734 = 303
    value = 63402
    text = __import__('base64').b64decode('dFpTSGJEaVMzV2dtNEs3c1hrS0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦМНШΜΞТΛФМд():
    if False and True:
        pass
        _dead_5996 = 178
        676
    value = 212548
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHnWa2Af274CHhaoyUWlZjcD/UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 68 * 44 < 0:
        pass
    return total

def _φμъΤτеЪйΘ():
    value = 313540
    if 46 * 3 < 0:
        pass
        779
        453
    text = __import__('base64').b64decode('YzZ3MVVUY0xIdG5RWlQxYjg2Ymw=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _απбРМлРщρλЬФΨеμΜ():
    value = 710747
    text = __import__('base64').b64decode('UDcxRnpfVzZxV05OUm5fOXV2MU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗкЦξθэοΚυЛ():
    value = 674301
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiTSRHcap/pXEiiqy1qJJCF43kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΓΝΔΚнξшХΙ():
    if False and True:
        pass
        pass
        _dead_4603 = 101
    value = 674920
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('akVvT3FBeVhKY3VWUGtYZnJOZFI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        272
        pass
    return total

def _шкρλЫФωвη():
    value = 276229
    text = __import__('base64').b64decode('cTNwRV9Sdk9rRlEzUDQ3Z2szT3A=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4001 = 44
        212
    return total

def _трОΦХψΤШй():
    value = 991111
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('TlRuNXZYaGNodEpmbEVrSzlENzI=').decode('utf-8')
    total = value + len(text)
    return total

def _фλκЩНжЪφбо():
    value = 367815
    text = __import__('base64').b64decode('WERhc01nY3VmaDJrN2pqb1lmZGU=').decode('utf-8')
    total = value + len(text)
    return total

def _χпλΛΚМΤдзΖчА():
    if False and True:
        778
    value = 613889
    text = __import__('base64').b64decode('ZTliT3cwZUdkUVE3ZHlzX1h2SEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ОЪМВМηΙиσμζ():
    value = 491488
    text = __import__('base64').b64decode('STBadnBtMWRjcV9kbVBGMUNibkw=').decode('utf-8')
    total = value + len(text)
    if 62 * 97 < 0:
        89
        59
        pass
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()