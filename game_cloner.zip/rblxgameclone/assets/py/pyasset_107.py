#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΒСгМΕωыΒлςΤΑбЫ():
    value = 734462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzfBOFhh54sAFhuk6neEZip+/Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4538 = 93
        929
        914
    total = value + len(text)
    if len('') > 0:
        194
        963
    return total

def _нΔзδβЯЗЮευΝμхшшΓ():
    value = 401860
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3bKQXMJzYIKHT33nE6lNysnsDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΘлЩВΖμЭж():
    if False and True:
        _dead_9300 = 199
        _dead_8437 = 802
    value = 134262
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAC9QUUL9JI0Kymu7EeAEyofylY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πтжьрΕΝеР():
    value = 903350
    text = __import__('base64').b64decode('UUtSVFppM1pTRjUwRlp0QmxIQjI=').decode('utf-8')
    total = value + len(text)
    return total

def _РψъΘыβуЗф():
    if 52 * 63 < 0:
        _dead_3234 = 520
    value = 852457
    text = __import__('base64').b64decode('TWdQOFBlazJ4TjBSbklLZ2l3ZFY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        444
        320
        824
    return total

def _ОМΕЬРξюаμкψСПэΥЭ():
    if 99 * 16 < 0:
        521
    value = 470210
    text = __import__('base64').b64decode('R3ZQZ3FGMUwwUDR5ZFhaN3d1c3A=').decode('utf-8')
    if len('') > 0:
        60
    total = value + len(text)
    return total

def _βΑВГысфНиξΡсΓ():
    if False and True:
        pass
    value = 89709
    if 42 * 1 < 0:
        pass
        pass
    text = __import__('base64').b64decode('akRISEVpcWNHVzRSV09MSk81QmE=').decode('utf-8')
    if 70 * 76 < 0:
        _dead_6245 = 992
        pass
        909
    total = value + len(text)
    return total

def _зоΣΨфΕффъμΝБπСΕτ():
    value = 231091
    text = __import__('base64').b64decode('STU5bVJQSXB4aTluYjJuV08wRzE=').decode('utf-8')
    total = value + len(text)
    return total

def _АлΥΣΙΩНςЗЛδοНвρ():
    if len('') > 0:
        pass
        _dead_4067 = 471
    value = 796655
    if False and True:
        _dead_8791 = 160
        653
        _dead_9411 = 283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgPwXAEyqpBaFwST8nqfIiYYwj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟευОпЙаОЖΘσГг():
    value = 54655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3q1eEVu0ZosEg2w+1mbYxR8wEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЮτπцеΖγΞП():
    value = 154778
    text = __import__('base64').b64decode('dzR1c0g0dTE4WnBfVHFDZlBuTjc=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        _dead_2985 = 980
    total = value + len(text)
    return total

def _еЮΚИуΝарржрьощ():
    value = 345913
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRzzZVkar7wQGQytwnqDOgoHxnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 43 * 72 < 0:
        pass
    return total

def _ΠсυπзυΔЭвхΛФΙхμ():
    value = 386280
    text = __import__('base64').b64decode('WEg1YktoWm1FVGRkRHRUcENobE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕЪзГρЦзοαжΦ():
    value = 552169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAbvZndo5p4HFVuZ+wHJHi4h6GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡъТРΤИΨъщзФЖЛ():
    value = 536355
    text = __import__('base64').b64decode('aHE5bWRDdzB6eTVDN0I2RThIN2k=').decode('utf-8')
    total = value + len(text)
    return total

def _имΠβνЛΡΜжп():
    value = 641338
    text = __import__('base64').b64decode('a1dNcVJNX25RN09JTnJwSGZ4RkI=').decode('utf-8')
    total = value + len(text)
    if 41 * 28 < 0:
        _dead_4128 = 650
    return total

def _рхψΜЪоψΦцΦГΘΖУв():
    value = 624784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhmwfXA3yqUwESmp5FKRBwQG1n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 26 * 51 < 0:
        281
    return total

def _ЭхПАςΖΚрй():
    value = 686987
    text = __import__('base64').b64decode('U1A1djR3UmxiTzBlSXhzQnJLR3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗζШиΠзСςеμьЧψτ():
    value = 417272
    if False and True:
        688
        _dead_3710 = 173
        pass
    text = __import__('base64').b64decode('SGFaaFZJWHBRb1FobGlOalFtMTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ыШΑσгхэЗΨцΓΥЦΑ():
    value = 107099
    text = __import__('base64').b64decode('TnFGelZfc3VGbXFoUUFOZnR0TWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓцβУΕДЦнМΖМЬ():
    if False and True:
        127
    value = 91323
    if 25 * 84 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICH1SmsPzrEHACOW+GGEJSYJyl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬЖдлαяХΙжεчφпζΝΝ():
    value = 525863
    text = __import__('base64').b64decode('bDRLWnRQdE9hV2lvRE8wb3dxUl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ШяχЪЩπΨнι():
    if 81 * 43 < 0:
        pass
    value = 355594
    text = __import__('base64').b64decode('ZmFmYVY0TlJRdFdreEtNWmV1NHk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        268
        pass
        pass
    return total

def _лηМЧоΤΞфχСцаЗчκη():
    value = 454067
    text = __import__('base64').b64decode('VEdvR2JhR0MwbVkxbWNtcUk4VlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ХйшωйнψНθЕεЪИ():
    value = 906066
    text = __import__('base64').b64decode('Wk9SWWllM1QzNWdsUEVheXZzOVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ьжЫдγωхжΗ():
    value = 217955
    if 55 * 98 < 0:
        _dead_6095 = 463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByLnaVcq1qxWbT/22EbBHxIN3F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λδεЪΥЗяуюЩσуС():
    value = 846180
    text = __import__('base64').b64decode('bE41UjFWekdIaXFwT2ExZUoxY28=').decode('utf-8')
    total = value + len(text)
    return total

def _ыОвΠψИкΤ():
    value = 255034
    text = __import__('base64').b64decode('WGhrR2ZJQkE5U3UzdV9zMmYyN2c=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΠОιΒеΤρФ():
    value = 597449
    if 59 * 81 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ez7GX0cIwa81NDq6nX/BPXQi12I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 64 * 77 < 0:
        _dead_3929 = 699
        92
    return total

def _μЩАлβΡмв():
    value = 215776
    text = __import__('base64').b64decode('SjFXeTdtVnlPYUh2bTFBakNzWHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ДэΧΟΝзяИν():
    value = 661641
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAriS2Y1rI8oEySxnn+YJnwd6Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чЪЗзуμгαгΦкΩК():
    if 50 * 97 < 0:
        87
        _dead_4721 = 438
        _dead_5550 = 929
    value = 979248
    text = __import__('base64').b64decode('QTJTcmZoRWFzckI5NDhTVHQ4Q1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬяαΣζеΗцωъПτЕΤνй():
    value = 833164
    text = __import__('base64').b64decode('UGVSdTRrRmNNUlcyNjdqNldXeFE=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_8889 = 704
    total = value + len(text)
    if False and True:
        39
        pass
    return total

def _ΙЖрЬМЩπΜθоΥЩΨς():
    value = 437457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQfId0IUxJ4RERuW21qROCE/sF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜцФУйхωчω():
    value = 182207
    if 66 * 23 < 0:
        271
    text = __import__('base64').b64decode('WWY0SUxGM0gyZGM5TXkwZW9YZXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜкΑξЛεяθΒτвеΨ():
    value = 481971
    text = __import__('base64').b64decode('elFWSTQySEg1UG8wc0xBUUZQU3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _фТΛΗΝнцт():
    value = 849839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHnIYXsD+qdRHzC3/X6HZjEu3VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иьυЭОвΟβΖВψΝΚΤΖ():
    value = 720755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eg7xe1ga8/8UGwalwma0YisazDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟαвΡεПБРтΤГГ():
    value = 89916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR7me3Zowf8KHwGQ3FGTFhoQy0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟкπУАδшοαЖσкцЦб():
    value = 365505
    text = __import__('base64').b64decode('YzY1U0hCOTZQQVdMTDJQR0xnOEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛВΕМΓвΔοчΛфψ():
    if False and True:
        _dead_5632 = 914
        pass
    value = 886772
    if False and True:
        _dead_5793 = 394
        577
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyPdT2A/2Ys2Nlr34GGVAwML1T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖХЬΕЖччΟμΜы():
    if 31 * 37 < 0:
        pass
    value = 58151
    if False and True:
        91
        _dead_4687 = 692
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDrRbAUV+qxaGDum+HiYIywhvV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7464 = 94
        405
        _dead_8579 = 169
    total = value + len(text)
    if 2 * 40 < 0:
        611
    return total

def _УΕΙжреΠЙκζэιτβ():
    value = 99064
    if len('') > 0:
        pass
        _dead_9607 = 332
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET/lPkI8z4kHaymgngPEFSp3xkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВякΤηДμтΣЙтΩχЩФф():
    if False and True:
        pass
        400
    value = 557162
    text = __import__('base64').b64decode('UGNieTVMUUNYT3ZQSEtVMlFTa3o=').decode('utf-8')
    total = value + len(text)
    if 78 * 46 < 0:
        _dead_7344 = 339
    return total

def _ΛжчΧτТЬυЬγяб():
    value = 758357
    if len('') > 0:
        823
        927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQPJaEsS940BA1+O+nSXDRoK0Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘРЮΦΩΧΒΠОВрВΤеп():
    if False and True:
        331
        861
        pass
    value = 606166
    text = __import__('base64').b64decode('eEdUcDhvOWlvYjBZUlNLSjBINVo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        327
        165
        47
    return total

def _еΔΥΞЦΡЫЙоляο():
    value = 679184
    text = __import__('base64').b64decode('YWozaFlVSm1KSHhtcVJ5Z3dXVzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ГЕщρсТθкωпМФν():
    if len('') > 0:
        _dead_1775 = 525
        773
        pass
    value = 676561
    if 18 * 54 < 0:
        _dead_5191 = 570
        71
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwfuVAcAzJJVDV+n2X2fOy58w08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        407
        _dead_6928 = 555
    total = value + len(text)
    return total

def _тЙπλДэцшΩГыψЭ():
    value = 109817
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD/VZQUD+v9UP1ya92C2CwF6z34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        593
    return total

def _ΖфΤЧгЮΔПпКΟЮфΕР():
    value = 259480
    text = __import__('base64').b64decode('bjhlYzlEOTBvaHU2a0dkMVE3N0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ощУиЙκляПЪΩГГ():
    value = 87801
    text = __import__('base64').b64decode('ZGtVRzhsdEVCcThiS2VOUnBpNUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΨЕЯдΦΛкσΣБПΝ():
    if False and True:
        249
    value = 668073
    text = __import__('base64').b64decode('cmlQb096SFlCdXBJb3kzZHBZZDc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ςψζЬтшДΠΗΕΝξ():
    value = 732061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESneXkg3z4MnFDqTyWSqGDwY9Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨοцφΟΨЖΩψ():
    value = 238421
    text = __import__('base64').b64decode('ZW9YUjFKV2lPbXhjVW1fbVZ3eTU=').decode('utf-8')
    total = value + len(text)
    return total

def _цдйжСЩφΛЬкъρиιυλ():
    value = 129059
    text = __import__('base64').b64decode('SFBDNXdZd0JDWWhWSFV2RDJuNzM=').decode('utf-8')
    if False and True:
        pass
        924
        pass
    total = value + len(text)
    return total

def _ρЦЪΝзиχΛΞЬφ():
    value = 186068
    text = __import__('base64').b64decode('R1R5and5OWl4Smc2a0s5N1Y4UjI=').decode('utf-8')
    if False and True:
        828
    total = value + len(text)
    return total

def _гвКЕзΒΑεЙ():
    if 83 * 92 < 0:
        _dead_4884 = 893
    value = 897259
    text = __import__('base64').b64decode('dHhteWxqRVFJbTNyTnJ0ODNxcU4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _κδΨςЛЛтΤнГЮРК():
    if 87 * 48 < 0:
        pass
        _dead_4207 = 502
    value = 20028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXzVYHAs1KJXNSnyxVuSHQQJsmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΛυГВЗΝЭннδюЧеШΕ():
    value = 227965
    text = __import__('base64').b64decode('T1E2VnZRZUVYNTB4TFU1bjZxOVA=').decode('utf-8')
    total = value + len(text)
    return total

def _юςДтЙйсΡβпоλΡшω():
    value = 154234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXfVWkEz0I1WLSX6xHm3Yi0+0Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КОσΩСЯΣЮοЮΑΘ():
    if len('') > 0:
        _dead_6132 = 789
        _dead_8397 = 570
        _dead_7277 = 906
    value = 301516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MynjVHVgy7oHAzqtzXWcbCMr9m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΣфшЧμΠς():
    value = 335208
    text = __import__('base64').b64decode('U0JzSTFpdE5YZWFBUjdKbmlGZTI=').decode('utf-8')
    total = value + len(text)
    return total

def _шΒΨВуΒδζуЮЭβ():
    if 51 * 39 < 0:
        573
        24
        pass
    value = 930965
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXfhXwkdrawHHCmlxFOyHnMnwEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        784
        340
    return total

def _ЖλсγОΓΦΣДμя():
    value = 759670
    if False and True:
        _dead_6099 = 69
        _dead_1197 = 278
    text = __import__('base64').b64decode('aFZZYVpDbzVIdUQ3V240cU5BRlI=').decode('utf-8')
    total = value + len(text)
    if 17 * 82 < 0:
        pass
        769
    return total

def _ΕнΗзΛНιλςт():
    value = 981579
    text = __import__('base64').b64decode('RXgwWloxUjh5eHdsY0tOeTVySFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΦМЕΙζТνяΧвβαИ():
    value = 93649
    text = __import__('base64').b64decode('cTBDT0VxOVJCb09QZ05ZQThtc2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛХГвηЮбλНщХζЙжΕ():
    value = 282578
    if 92 * 88 < 0:
        363
    text = __import__('base64').b64decode('d3pfM0VsSU1YX2FvSVpFdDdoNmg=').decode('utf-8')
    total = value + len(text)
    return total

def _μчжмψηунДιЫШΨυ():
    value = 781231
    text = __import__('base64').b64decode('ZkVMQjNTUXBFQVNVb0tVbFBfM1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _υысХΩΝЧξωшΟЬжБ():
    value = 358887
    text = __import__('base64').b64decode('enhqOTI3NUI2TFI1Rm10clFMRTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖрΤьнΤΜвλюаШηθв():
    value = 302173
    text = __import__('base64').b64decode('b2psaENEbV9ZaDc3d2k1RThsUWE=').decode('utf-8')
    total = value + len(text)
    return total

def _εъЧγΠΩЬπ():
    if len('') > 0:
        pass
        _dead_2351 = 618
    value = 915336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cia3W1oDzo0lLhWu7Qa+DHx4zzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АαМююбоνъхчΦзуЬΒ():
    value = 974201
    text = __import__('base64').b64decode('UmRhY1RLSHozV1Voc0JaQV9SVGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΡНтбηНЕΓщуАδ():
    value = 295094
    if False and True:
        _dead_7516 = 366
        129
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQi1f2UOyLACLAmA3GOTB3I18mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9950 = 504
        _dead_9919 = 267
    total = value + len(text)
    return total

def _ΝαрΩдсФйΗДэцΙεζз():
    if len('') > 0:
        pass
        _dead_8724 = 256
    value = 44471
    if len('') > 0:
        _dead_1991 = 926
        477
    text = __import__('base64').b64decode('VVdWNkFySjdTWlhoeVFLZk5jMlo=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        261
    return total

def _СкАμςВЭМЙΛтХλЬς():
    if 42 * 91 < 0:
        77
        pass
        421
    value = 358619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz3obW4O+PAsPSCU50bILnx9/Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗζΕсЬΘеπιζμ():
    value = 520511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mzz9VnI8+fgWAASB0UegBT0g9j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эукΑβсПцЪΟΩ():
    value = 704065
    text = __import__('base64').b64decode('Y1VHNGpTb0UyR1RIS1NDR2I2ZU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔЩЙЕιжйΛ():
    if len('') > 0:
        pass
        pass
        pass
    value = 295577
    if False and True:
        _dead_9503 = 637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB7QfnsG1vFTEyny4XO0GAgVynQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _кτΔΩхВυβУ():
    value = 264059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXvJd3IB2I4hOQe6/2aXPnMOskk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_5644 = 423
    total = value + len(text)
    return total

def _χУбаΑηХчτφζвΩь():
    value = 818510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwDpbVU45KklaFyG5WTBZggH0UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 5 < 0:
        pass
        _dead_4059 = 625
    total = value + len(text)
    if len('') > 0:
        pass
        856
        _dead_8214 = 767
    return total

def _ιЬΡπюςбыаШйлχ():
    value = 160705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRruZ3AA2adWDyvz/2CYZw8B0jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φДДζЕТчΔοςзГщыбЬ():
    value = 498317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDXHa10b2ZwrLQqCxkCpIw4Xx3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЮΚΡъσЪσησфлчО():
    if 43 * 16 < 0:
        pass
    value = 567684
    text = __import__('base64').b64decode('cWRvd1QweE1yUjB4U2xoYncwYkI=').decode('utf-8')
    total = value + len(text)
    return total

def _υПЖююπсΨИГСЩСЧчУ():
    value = 48960
    text = __import__('base64').b64decode('Z0lRT3BPenQwbW1jY1h3bDlrdGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _БшζЛЫлСΟЯЮсьΣА():
    value = 53258
    text = __import__('base64').b64decode('aHd6VzJZX25TTVpMY0lRZFc1OXk=').decode('utf-8')
    total = value + len(text)
    return total

def _юθΦсПщпМЗЪш():
    value = 497018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyvuTUka3PAFEFua31mTCyx28Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΣΗЫцшгПΘψσй():
    value = 935663
    text = __import__('base64').b64decode('bXBpWktlbENzQVRROGYySVRmbGY=').decode('utf-8')
    total = value + len(text)
    if 60 * 55 < 0:
        _dead_9391 = 589
        pass
        _dead_4079 = 636
    return total

def _щΞПοяδсΙιнφИЭНΔИ():
    value = 334083
    text = __import__('base64').b64decode('UXQxVmhUVVpkbk9NT2VOMWM0aWE=').decode('utf-8')
    if 59 * 29 < 0:
        601
        528
    total = value + len(text)
    return total

def _ыεЮΡΦУΩηΚыΩщЮЦβ():
    value = 428192
    text = __import__('base64').b64decode('TmJlUl9SbFJmVEhzSnc0SjZabFI=').decode('utf-8')
    total = value + len(text)
    return total

def _АΩοКуηИЙГΤЦАκΨΒЗ():
    value = 978538
    if 74 * 59 < 0:
        459
        pass
    text = __import__('base64').b64decode('SFV1QlJhNXpKMThNNDZrR0QxYVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ηЖκшΘρиςФΟΡшΜ():
    value = 294893
    text = __import__('base64').b64decode('WlZRUDhOU0dpTkduaGRrZFk4WFU=').decode('utf-8')
    total = value + len(text)
    if 87 * 97 < 0:
        17
        pass
    return total

def _ЙюаРФьИχлγ():
    value = 988438
    if len('') > 0:
        _dead_6705 = 894
        _dead_8544 = 962
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CS7bdGIh1LwiBQyO0l2GMwgZx34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НьшιлшаЖяυΖδ():
    if 17 * 85 < 0:
        _dead_7013 = 200
        pass
    value = 925689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQvTZ0gsqaEWAlmw2mCaLiJ+3XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙξεΖФςЬэΜИхызφщΧ():
    value = 376418
    if 9 * 74 < 0:
        _dead_6374 = 1
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3zwVlovwa5TEg2B23OpIjMbwFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΛлыРуеК():
    value = 983765
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCi8XwZup4E1aleV3my2YSx/700='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФξΡЬχъΖΚπΑкΛВτЦρ():
    value = 422910
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHfxdnkP9q0tOzWs+g6IPicDs0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        588
    total = value + len(text)
    return total

def _υАκρУвцΜЬΞьΡБ():
    if 95 * 65 < 0:
        pass
        _dead_3007 = 698
        _dead_4225 = 329
    value = 412838
    text = __import__('base64').b64decode('UmZjVmpESXdpbkpYV1VUTjZuNEc=').decode('utf-8')
    total = value + len(text)
    return total

def _СтΙΛрЧлщыфΨЬгΑωО():
    value = 126537
    text = __import__('base64').b64decode('TmhRVkREbTdEWE9nX0VNc3J2Ylk=').decode('utf-8')
    total = value + len(text)
    return total

def _λЦЕτМиαΞ():
    value = 687984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjvLfmRt0Z87HxmU2gWoEigu1kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φоКνжяξΡΦМΨдЭθ():
    if len('') > 0:
        pass
        pass
        99
    value = 380858
    text = __import__('base64').b64decode('TXREckd3Q2tGaHAwRlBUOHdLWTk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЕΘСДΔΥЪπя():
    value = 904069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChXqfFwv35smLwW54GWcGgEN1To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨПЪФЦЯяЙЧΤξШяЛ():
    value = 155128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah+0e1A254w2Nhery1SaPi4l7E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛчтйЩоφж():
    value = 411098
    text = __import__('base64').b64decode('djZoblV4NDVJUWZTZXFxbnZlTkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙуддхιхШрΧπтцлШ():
    value = 302861
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSXtYlBoqb8PCiah8kG2YAof6Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        365
        _dead_8011 = 741
    return total

def _ижЮРИΟбЙэЪШт():
    value = 742548
    text = __import__('base64').b64decode('RUtRN045Rl9qNDZUZVh6alduS3k=').decode('utf-8')
    total = value + len(text)
    return total

def _сЮГκХтηνЫςΠыЪъτУ():
    value = 171174
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQCzPmg12q8WGFmQ40y8AzQYzmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮШФуНЫκыСθΘη():
    value = 532897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXfbeEYp07oINAj133qFF3wAtW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тэыЙνбфΒ():
    value = 997446
    if 27 * 31 < 0:
        pass
        pass
    text = __import__('base64').b64decode('WUZGVUs5THpmTlNkdFZaQlFIVGI=').decode('utf-8')
    total = value + len(text)
    return total

def _еюνОйβхХυЪчυΣ():
    value = 970034
    text = __import__('base64').b64decode('YkpueEZtRE5IOWpVMTJtRmZac1g=').decode('utf-8')
    total = value + len(text)
    return total

def _крζΚςνοЪ():
    value = 125067
    text = __import__('base64').b64decode('ZGdlYldidVI4M1JUVTJabmFSZGU=').decode('utf-8')
    total = value + len(text)
    return total

def _пцтнйθзΝХЙН():
    if 18 * 25 < 0:
        pass
        pass
        _dead_4018 = 258
    value = 297250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACjVRQA3qaUhDCen3myoGAo8wFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 55 * 64 < 0:
        pass
        pass
    return total

def _твъψнтПбТпЛщσ():
    value = 706014
    text = __import__('base64').b64decode('b3lHZUE0VmlmbElDYTJQVm9ndUI=').decode('utf-8')
    total = value + len(text)
    return total

def _роςКΘςаΦВиГςБзо():
    value = 402961
    text = __import__('base64').b64decode('QlExR1pTbEhsNGFSekdhQlRDbTg=').decode('utf-8')
    total = value + len(text)
    return total

def _οхλΛжЫξΓл():
    value = 696570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADXiY1Q4/K5XOz32xk+KBwJ21mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сЕηΘБзыГйυΘφн():
    value = 252523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISfDdkIhqKwQNzWkm0CzAhQGw2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΔΖΑλцЮηιА():
    if 14 * 47 < 0:
        pass
        139
        _dead_2234 = 228
    value = 457842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQb2fUES/Zk6Py3wxHGUCw4H3Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йδеΠЯСξЫвνЭΧщυ():
    if False and True:
        _dead_4764 = 894
    value = 267625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3f+QUk/0YMXCTnz3WOXYXMD7Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΩгχршΙмФБ():
    value = 32750
    text = __import__('base64').b64decode('YlJOWTQ2dlEzSGN5aWN0U3F2bzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛГΠЖδЙЙμΒхЫΞшлв():
    value = 134745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTrUR1M27Jo7bl/170ekEj8Z420='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΖГΡΞюЦхΛУДΧЫуь():
    if 32 * 65 < 0:
        pass
        _dead_1929 = 357
        477
    value = 140969
    if len('') > 0:
        pass
        pass
        392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhbJXmYz7qtXIi2WnVO3OQcXsEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 84 * 50 < 0:
        pass
    return total

def _ΤΥЭжсиΧЬε():
    value = 924495
    if len('') > 0:
        564
        761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3rFeWko8/xSCDCqmAOmZg0q7Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8014 = 255
    total = value + len(text)
    return total

def _чτхπзбπΩΝЪ():
    if len('') > 0:
        _dead_4541 = 770
    value = 92950
    if 13 * 26 < 0:
        _dead_4388 = 700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyvURGky6b4UFzmM4U+6Bw4c/Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        289
    total = value + len(text)
    return total

def _ИΚωΖΑΡЖЫΨ():
    if 23 * 68 < 0:
        _dead_5666 = 796
        _dead_5052 = 10
    value = 178983
    text = __import__('base64').b64decode('TU9Xa2FiaFVKWEZjTHhYcU5UeVc=').decode('utf-8')
    if 34 * 7 < 0:
        pass
        511
    total = value + len(text)
    if 42 * 85 < 0:
        95
        _dead_7903 = 305
    return total

def _шьфΤГαψзДщлωКу():
    value = 681398
    if len('') > 0:
        761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiPxRH8h2b4KHzubxHWSFTABsmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΡαюΕъΤΖОσФМН():
    if False and True:
        _dead_4382 = 161
        664
    value = 702881
    if len('') > 0:
        644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgeyWGU9z6ctExXxm3OXIDMisnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗКψнληΛЩьωцдОΜ():
    value = 911318
    text = __import__('base64').b64decode('SEl6b0l4dTZmSDhoQWQ1MkptckM=').decode('utf-8')
    total = value + len(text)
    if 40 * 21 < 0:
        pass
    return total

def _ЯлΦжΘυΨАδхφΘ():
    value = 441356
    text = __import__('base64').b64decode('RkRtaGp2VnJNTXQ3MjhNOEJOS00=').decode('utf-8')
    total = value + len(text)
    return total

def _НЗвΚΙΕεВΣ():
    value = 967050
    text = __import__('base64').b64decode('bzR5azBrYmZJWlJRaUNJRDJtWU0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4963 = 77
    return total

def _θζНяιЪПΝАΨЪΩШιθ():
    if 60 * 58 < 0:
        41
    value = 218761
    if 9 * 36 < 0:
        730
    text = __import__('base64').b64decode('ZFBYRDV6Sm9BN1VYcV9VeU1lY2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ъТΣΥлзλудлЧΗ():
    value = 879922
    if 56 * 77 < 0:
        _dead_9259 = 234
        pass
    text = __import__('base64').b64decode('eFpYR1pqTVpNNWpxWnBTYnVBNlo=').decode('utf-8')
    if 23 * 57 < 0:
        756
        178
    total = value + len(text)
    return total

def _ΡМψορчЗдвхР():
    value = 131745
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('eXJIc3BpT2swODY4NGVreHZGYmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ДвбΠλкγιиП():
    value = 243641
    if False and True:
        _dead_7194 = 691
        _dead_3459 = 845
    text = __import__('base64').b64decode('dHpMM2NoUmZ4aVFoOUs0TDVidXM=').decode('utf-8')
    if len('') > 0:
        973
        pass
        _dead_5809 = 561
    total = value + len(text)
    return total

def _ЗιюξдфъΓоцαаΙΗΨΗ():
    value = 708015
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Azbvf3A06IYmDQOmwl/FATcZzn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣδΗςцΤΤЮΑΥ():
    if len('') > 0:
        _dead_7637 = 495
    value = 575345
    text = __import__('base64').b64decode('ZjhmZDdSUnROb1JQS1p0NDY4R3M=').decode('utf-8')
    total = value + len(text)
    return total

def _МζМΦАпБХщЪш():
    value = 389544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQTxQwdprv0oNTmJ736gLXcW1GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иλκНΨъдδянθЯъы():
    value = 818921
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCvuSARtxoIlNFaV6QS/LXI43Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        325
        742
    total = value + len(text)
    return total

def _ЛΑочЗпνβеАΖτцΗ():
    value = 382898
    text = __import__('base64').b64decode('YWdnWWRzR2UzdmdtRVBiSXA3OV8=').decode('utf-8')
    if len('') > 0:
        _dead_3326 = 520
        _dead_3942 = 113
        _dead_1157 = 610
    total = value + len(text)
    if False and True:
        pass
    return total

def _λпРνΚЪξщ():
    if False and True:
        237
        333
        _dead_1923 = 615
    value = 159737
    text = __import__('base64').b64decode('YWtBOFBHTk92SzY3NjVqRUhjT0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗεЧЦφзδИв():
    if len('') > 0:
        pass
        pass
    value = 518607
    if 37 * 87 < 0:
        pass
        _dead_5430 = 78
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA3IYEcM77wWMCKczlO9Hn0K9Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 76 < 0:
        _dead_4255 = 953
    total = value + len(text)
    return total

def _УьκβопξоΚЛаλцуУπ():
    value = 128469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhqyaX4rrv4KYx2v3w/FYgp+ykg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гШΖшиιДмтπиЫη():
    value = 301736
    if len('') > 0:
        507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDbWRngpq7oUbAv263qpYS4jz2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        29
    total = value + len(text)
    return total

def _ыоцьηОΚΦΞ():
    value = 965155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQu8QgcIpqs0KAKA30GqMBIh7VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μψαуςВΧщΥιЖα():
    value = 344905
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH/vSWg6xrhTFwvw+l2RIT0O6V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κπдЦЖΙшЭΘοЛмδвГ():
    if False and True:
        _dead_6070 = 551
        pass
        437
    value = 939330
    if len('') > 0:
        _dead_9428 = 131
    text = __import__('base64').b64decode('clZVTl9SeV9JekpIVlpsM2p2MGI=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_5110 = 960
    total = value + len(text)
    return total

def _члЧшкλгχгнΖЛχ():
    value = 573059
    text = __import__('base64').b64decode('eV9XSDdadUpCY2c3bGNKZE5KUkk=').decode('utf-8')
    total = value + len(text)
    return total

def _реЗуЙЩЙςаι():
    value = 977512
    if len('') > 0:
        354
        931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjzAXAduy5cLMgiAzWnDFwENtGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        218
    return total

def _ΦабЗμчЯΚΜжοяР():
    if len('') > 0:
        pass
        _dead_7951 = 384
        _dead_6618 = 813
    value = 827284
    text = __import__('base64').b64decode('RnlMUVMyV3BEb3pKVndYV01nNl8=').decode('utf-8')
    if 97 * 57 < 0:
        974
        pass
        870
    total = value + len(text)
    if len('') > 0:
        _dead_3850 = 532
        pass
    return total

def _пэЫУιеπΝλΨΚГ():
    value = 16653
    if False and True:
        411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiTIdAFv06QIKBiEn17BJxwjsVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8474 = 767
        614
    total = value + len(text)
    return total

def _СГθъГбшдфжХЖйч():
    value = 606727
    if len('') > 0:
        _dead_4985 = 556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAnCVncr6LkmAxWQ5U6mYxMi9VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1382 = 777
        _dead_5170 = 201
        264
    total = value + len(text)
    return total

def _ФМΨеЗаЗФыρГЛ():
    value = 315782
    text = __import__('base64').b64decode('ajBrOXp2NDJ4QkZvNmlpUTcwdUo=').decode('utf-8')
    if 65 * 39 < 0:
        pass
        313
        pass
    total = value + len(text)
    if 69 * 84 < 0:
        _dead_5454 = 369
    return total

def _ПςеЩПζиΤцεл():
    value = 925276
    if len('') > 0:
        pass
        _dead_7464 = 988
        868
    text = __import__('base64').b64decode('QUczQ3hVVVUxOHN0Ym84bVFLa3E=').decode('utf-8')
    total = value + len(text)
    return total

def _уςуΖЪАΦШтХМΦξ():
    value = 213425
    if 46 * 68 < 0:
        453
        616
    text = __import__('base64').b64decode('VjVodFJHT1hvQlU0ZTlTOWlwMUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩеувΜНδΦΦухβδфΖШ():
    if len('') > 0:
        _dead_9904 = 250
        421
    value = 676407
    text = __import__('base64').b64decode('YTBYblRXUV9ZVDdmX0dENjZqdkI=').decode('utf-8')
    total = value + len(text)
    return total

def _οХΑψΛбπШ():
    value = 309226
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDXDTXVvzLkZNVqH2XmnLhp6s0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _съРχиΖэЩτЦ():
    value = 189203
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N37HPHww1P83Hzqcw1CaMhd6zls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 77 * 24 < 0:
        pass
    return total

def _ςΞбςфФДзРχυГΤфыΣ():
    value = 124939
    text = __import__('base64').b64decode('Q0lJOXlheTg5TEl4aXcxbUhRS0k=').decode('utf-8')
    total = value + len(text)
    return total

def _πнаОеыλΓдΜд():
    value = 400890
    text = __import__('base64').b64decode('VWJrSlhaYnhFRUU3bDhjWFdWMmg=').decode('utf-8')
    if 9 * 90 < 0:
        847
        722
        876
    total = value + len(text)
    return total

def _эздшΨπСмигΒСΖяФ():
    value = 91138
    text = __import__('base64').b64decode('aG1CcHltSDIzek1nQ2RQUlE5Qlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖшГхχуфΝΝΥ():
    value = 724096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxznakA76pBXaCyc62XEDhYk6Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΦВοАоЩОэγцЮφТΓЫ():
    value = 395702
    if False and True:
        pass
    text = __import__('base64').b64decode('SXFGSFNtdEZ6UWZUampBRXdmRkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ьςеКЫтыξλσЬЦп():
    value = 786189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwvuQmE41ZEQPl2w+nCvBCQlsmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ЖδΥЦкЯΩОΕКС():
    value = 832976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3jJNgBozZ4OMxar712vOiQk23g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λВПσЭΣΚЕ():
    value = 723261
    if 18 * 25 < 0:
        pass
        637
    text = __import__('base64').b64decode('UGt6M2FXUEozX3FhdmpnbVJDOXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΡйаэΔМψзζФδщЯ():
    if len('') > 0:
        885
    value = 256732
    if len('') > 0:
        pass
        359
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXn3OwJq6/8aFD314EKxGwQl/no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓοгнΔЗσЗ():
    value = 584196
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lyy2fgQM1b4ZDT6P5FG0YA979Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νОггΤлюΡю():
    if 33 * 15 < 0:
        _dead_3496 = 479
    value = 918464
    text = __import__('base64').b64decode('WVlDUGtUT3lzNHIwYTR5dGxjQjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ρσолДΚЧΓ():
    value = 363216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQDQO38QqZIPbzuc61u7DDQf3Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φкИНΒΙмкΔЪЖτΧчπ():
    value = 292035
    text = __import__('base64').b64decode('UEJRMEc5RWEyU0VNNVM1TzdKN0k=').decode('utf-8')
    total = value + len(text)
    return total

def _νξκφьХωЖуΣγ():
    if len('') > 0:
        pass
    value = 998307
    text = __import__('base64').b64decode('ZEQzM2NhNldZRmtCMGlpRmtTMUU=').decode('utf-8')
    total = value + len(text)
    return total

def _рсΜΑдνъШеяβГэχ():
    value = 726157
    if 97 * 31 < 0:
        948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATf0RX9u1oMHNirx+n+qGXMk20Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 49 * 25 < 0:
        485
        674
    total = value + len(text)
    return total

def _МОΙдΒжОеΗо():
    value = 936601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXfXVHsw9JgxAhuU91m3E3cDtHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΓюЧуςэπКбоΑтψ():
    value = 701234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjjddHcz6qkkCTmp93SjZA0mx2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝюЪЬΓвΤМνΜΘВЫсТΗ():
    value = 511815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSbQPgAAzI9WYiSG2EKkZBoL7mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΚοΞТαдοмρВХИЕ():
    value = 589882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzvQYVYf8YAzCxe163C2LjEo3Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _φφОЭюшΔδЕσуЗОуΦΕ():
    value = 347621
    text = __import__('base64').b64decode('dkNiaWY5S0xXMXdSdTQ0bTYyVXg=').decode('utf-8')
    total = value + len(text)
    return total

def _иФΦРЯψωПзΣЧοΖψ():
    if 55 * 89 < 0:
        477
        _dead_5261 = 726
        204
    value = 128555
    if len('') > 0:
        _dead_2295 = 398
        pass
    text = __import__('base64').b64decode('RDBkWHcyNXplX0dEV3h4alJvem8=').decode('utf-8')
    total = value + len(text)
    return total

def _УΕΥПмЬτΟ():
    if len('') > 0:
        _dead_7793 = 529
    value = 167093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSSwfFY/zv4QFCKW61qWDXIe4UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЗТьδδΣλ():
    value = 582529
    if False and True:
        _dead_7931 = 449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSDPTHof7fA3Px2M2HS1EQoc7E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кКчКЛКАαΞеНΓСΕ():
    value = 78340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISrOa0U9y61bPgaN8AHGAgoOx1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υСЯбЗТЛοπх():
    value = 913198
    text = __import__('base64').b64decode('dFd2czFBMXR5U0Q1cVJsY0xZbWI=').decode('utf-8')
    total = value + len(text)
    return total

def _μуьМВМΞθНВт():
    value = 846107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IS3UW2M79Ps0PSu54UGpBR8fxWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОьмЪюεКмλπд():
    value = 655188
    text = __import__('base64').b64decode('WFRPWVc3NVczY0NPbkhBMHBnQUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ьγοмОЫзЧаВэОσЛμ():
    value = 216398
    text = __import__('base64').b64decode('cE5oaXlBTTdSbHI2WWZNal9rSGI=').decode('utf-8')
    total = value + len(text)
    return total

def _πЩΤЩΜОоеφчьχаФΡ():
    value = 404223
    text = __import__('base64').b64decode('WjY1TUxuckNqek1yR2JJbHhqOTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxxx') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 40 * 26 < 0:
    pass
    pass
    473