#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _υОьγθГЬβЪμ():
    if 24 * 89 < 0:
        pass
    value = 938053
    if 42 * 57 < 0:
        _dead_1128 = 390
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InnJeHUI+/sraSiG+ge4NjcI0nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 93 * 28 < 0:
        pass
    total = value + len(text)
    if False and True:
        650
        pass
        pass
    return total

def _φωьгммжнηНξ():
    value = 921047
    if 8 * 36 < 0:
        _dead_8215 = 123
    text = __import__('base64').b64decode('TVlDNWpQVk44bktjOExja2R0OGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬшΙХΣЮьνλкεΘ():
    value = 619930
    text = __import__('base64').b64decode('cFAzM3hZR1cxVElqWU1JckIwVTU=').decode('utf-8')
    total = value + len(text)
    return total

def _γЧΚтΦζφχΟο():
    value = 370397
    if False and True:
        756
        _dead_3894 = 997
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgG9OFw8zKBUMC2QkWC4GhQstX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        487
        774
    total = value + len(text)
    return total

def _ЗмωσТГΝЮς():
    value = 752652
    if 79 * 29 < 0:
        32
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwHNZkA/34YvGCusn0+aASkMz0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 96 * 59 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _зγхУШΑχПскΝЮ():
    if 14 * 90 < 0:
        _dead_2511 = 910
    value = 939627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXvIbXAg1Y4FACaK/3mCZwQk82M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5942 = 78
    return total

def _ЙЧЗΕΨБυМΩ():
    value = 293730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSPyemcDx4QBAwuT33CYBzII60A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩюьйЪпηΓШВΞНэε():
    value = 526562
    text = __import__('base64').b64decode('QnRsN2dwN0E0OVdfNVNiMkJqNUw=').decode('utf-8')
    if False and True:
        pass
        891
        814
    total = value + len(text)
    return total

def _ΧψΡπНΝМΝιНпΨбХыб():
    value = 374180
    text = __import__('base64').b64decode('TWhmYk4zM3Q2X1RFVlhvdFMwN1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ИЛΒμчτΗч():
    if 21 * 21 < 0:
        963
        _dead_9203 = 478
        pass
    value = 739475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDziflpg2JxWHC62wWafbTcF3F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 58 * 88 < 0:
        931
    return total

def _ΘониΕΧβЧ():
    value = 860803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRjsUV0D7IAbayuk3neiNzAX9Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьμεΗчχκнΟσσЧ():
    value = 480708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAvTPEMGxoEhNiiw4161FSI6yXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘЯФΚщυψαΠнГΥП():
    value = 756345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCzDSX4y9vszMjb290ObIj0ty0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йАЩЖξδΘЗ():
    value = 198985
    text = __import__('base64').b64decode('ZlJWNnR5RkhHYXg5bzNuQUNNNFY=').decode('utf-8')
    total = value + len(text)
    return total

def _кНЯШΨΣΨΥМΟЪωа():
    value = 638729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jw3NaAYUxPkpaQON0geAAzIq0mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЮΔΧЗνςυΛΛΙπΙЩςΨΩ():
    value = 589514
    if False and True:
        _dead_3669 = 510
        868
    text = __import__('base64').b64decode('WU5pMWRoUl81eFZqZlpxM3RSQzc=').decode('utf-8')
    if len('') > 0:
        _dead_2822 = 251
        _dead_5497 = 525
        891
    total = value + len(text)
    return total

def _отбкδЩЧπΞуΠΑП():
    if len('') > 0:
        404
        _dead_6383 = 678
        660
    value = 175333
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3nzZUJh65s0GSGV6wOvHBMq7m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦМьщНЦлфсЬ():
    value = 691079
    text = __import__('base64').b64decode('VGdpTEFfODZOQ05XTWY4aVRCVHk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        194
    return total

def _ΜυκцκЩмσΘ():
    value = 667020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSPCOGUS//BaNFaWzn2AJAkk/Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_5534 = 740
    total = value + len(text)
    return total

def _ΑЪΜхюЧйИПΠДтθ():
    value = 178169
    if 43 * 28 < 0:
        _dead_9298 = 617
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3nldFsG3PBRCBuG6WfFZQMMzz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΠИζσΝΜФΗЗ():
    value = 719399
    text = __import__('base64').b64decode('cmFVVkMyMGRJaUxpZXhPR1RSYVY=').decode('utf-8')
    if len('') > 0:
        _dead_2951 = 256
        _dead_5661 = 160
    total = value + len(text)
    if len('') > 0:
        323
        _dead_1302 = 198
    return total

def _мЛшдЛΤмΝθνρ():
    value = 633284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwL0R2I2zI4kKBf70n+pOwwWsWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аδСбЪЪчГτОψ():
    value = 551569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID7FN3AfrYwsESeh33eqGy8D1F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φлΑεмщΚΠтΠαюτφ():
    value = 72326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhvFaH0g2KAMLCm72AKVETEE/mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        459
        _dead_1301 = 963
        pass
    return total

def _ЗΨσЙπΟжВМчсшхИ():
    value = 494815
    text = __import__('base64').b64decode('cl90QVZPbVAwQjBsQWdmem5ITU0=').decode('utf-8')
    if len('') > 0:
        _dead_7057 = 29
        _dead_2634 = 233
    total = value + len(text)
    return total

def _ρГюроПеΑЩΙЭιРщΖΟ():
    if 90 * 4 < 0:
        pass
        pass
        pass
    value = 663635
    if False and True:
        189
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAfWVEUd/J8NNVaCzU+cAScD/WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭиЮησСδТμЪΦмΟжΔу():
    value = 24770
    if False and True:
        pass
        _dead_6159 = 780
    text = __import__('base64').b64decode('VXdJZFdOMG9uaFZMakFqOG5KeWo=').decode('utf-8')
    total = value + len(text)
    return total

def _УЙΨСρЩлρΥЪ():
    value = 735321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EASxTGJu+JIRBSSkymaTGHB66Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сУΕΧеδБЭц():
    value = 87423
    text = __import__('base64').b64decode('ZGlXNFZYaXpoN251MUc3VlFicFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜНΙЦЕвафЪφι():
    value = 218953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCzxQAIT85cKDRmG0lCbDDMoy1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψФЮΧюΕΟγΗ():
    value = 48846
    text = __import__('base64').b64decode('QjVWVF95Q3JSQVBBRkpiNHMwTlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝςΥΞФУΒц():
    value = 166265
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQbga1UK8642AFmnkQ6JYQEss0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡαγΕбшΞΟмνΣεбУΘЗ():
    value = 59082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBzpbXkJzLJSORzy5wGfYwgDzjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤмбχΦвЧψЮ():
    value = 564166
    text = __import__('base64').b64decode('WFNSQXZUUERrOXdCUElrZ0RRNEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡэИбСбγМПьЙнυνЦ():
    if 97 * 62 < 0:
        _dead_6097 = 705
        _dead_8185 = 191
        pass
    value = 948845
    text = __import__('base64').b64decode('Q2c2UHJ4X1pseHdXZkxlbUJHbWM=').decode('utf-8')
    total = value + len(text)
    return total

def _υРЕшрφοюТΠχМΣΞηв():
    value = 487489
    text = __import__('base64').b64decode('bkdtQnJrMVRLOW9SelZBUHRHcGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒЧжωДΨΨλζΗуПξ():
    value = 434631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fyu3fEsNr5gIFw6M5EKVAit60Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΑмσГΚнбМΙбΜЙЮЩ():
    if len('') > 0:
        pass
    value = 316901
    text = __import__('base64').b64decode('Uzl2dWFrc1hhOUhYQ1EwWlBxUks=').decode('utf-8')
    total = value + len(text)
    return total

def _ХГПЕуЧΧллуЙЮΜπг():
    value = 956040
    if False and True:
        679
        pass
    text = __import__('base64').b64decode('bnFZYlV6eUE3eVRIWVY1V0p2SjI=').decode('utf-8')
    total = value + len(text)
    if 75 * 45 < 0:
        835
        666
    return total

def _цюърХΖъΜτипКτ():
    if 100 * 56 < 0:
        513
    value = 261447
    text = __import__('base64').b64decode('UEVtcWJ3cUExc0dRbUZhVV9aa2s=').decode('utf-8')
    total = value + len(text)
    return total

def _кЕαΩыМЯХПσюΥΧ():
    if 9 * 8 < 0:
        897
        _dead_8335 = 149
    value = 365120
    text = __import__('base64').b64decode('TGJEeFJERHp5cDYzeXhhVHdORVk=').decode('utf-8')
    total = value + len(text)
    return total

def _НΑмρλζрΞЬβΑ():
    value = 603754
    if 89 * 11 < 0:
        928
        pass
    text = __import__('base64').b64decode('Rlc3Z254QllEd3pidWtVTTdIdXY=').decode('utf-8')
    total = value + len(text)
    return total

def _МДβЖьОМΗфТгЬ():
    value = 986637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HznFeXouroEhAwuP92KjOAkt0zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΕпΛεзвХγфλδΦ():
    if False and True:
        _dead_4025 = 790
    value = 530487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnjyfVQA2aAFCiup/WXBGxU/xmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лцшРНфМЙαΒЙо():
    value = 249489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDbcNn4XxJ4PPCCL2GecG3wY7Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3301 = 469
        _dead_9060 = 639
        pass
    return total

def _ФνΟΗМΟщаьтεяи():
    value = 920715
    text = __import__('base64').b64decode('Ym53M2ZYU3RkVDBoTTg2Mm5WTE4=').decode('utf-8')
    if False and True:
        278
        _dead_9707 = 541
        _dead_6744 = 206
    total = value + len(text)
    if False and True:
        _dead_2382 = 440
        _dead_4800 = 443
        36
    return total

def _οтΙвъЦАУУκΞХлЦ():
    value = 904875
    text = __import__('base64').b64decode('eV9uUW4yaTRFV0xJQ3lMR0Jzd3M=').decode('utf-8')
    total = value + len(text)
    return total

def _κΜθιΟХλσХ():
    value = 249815
    if len('') > 0:
        _dead_7545 = 90
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwXcekEq/7EHAxeV0HW4DTAL5mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        61
        _dead_2143 = 151
    total = value + len(text)
    return total

def _ΡΑиΙΑПΘРОя():
    if False and True:
        153
        66
    value = 140058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAzvT3Bt0r0nbiGOmgWzPyMNtGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙьшαηиоЬΩΘωДτЫъь():
    value = 565029
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTXAR1AR6KBRCiCo2l6BOic+yXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1465 = 595
    return total

def _πТДКζГпΕцМОАт():
    value = 807588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXvDSF01xLsZECaonlCBECgQ0Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юхНПπйуМЦ():
    value = 660571
    text = __import__('base64').b64decode('YzJ3cmR2SHJ4MU9KWmhQS2pnV2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _βНеЗυенЫцЦζφм():
    if False and True:
        _dead_5166 = 32
    value = 617945
    if len('') > 0:
        _dead_8164 = 275
        _dead_7533 = 697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx/FY0dsrrsLYjyKnQajACZ70Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сκγτφφΦЪъ():
    value = 704842
    if len('') > 0:
        16
        _dead_1036 = 206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgX9ZQADp4ESEwS6nwGcPiQCyEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        230
        pass
    total = value + len(text)
    if 55 * 84 < 0:
        _dead_7012 = 112
        750
        427
    return total

def _ощкΔРЕЕγЦΔ():
    value = 403300
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dw2wP0cQ/aE2CCSJ8ACpNgo2tVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8453 = 418
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_8049 = 641
        pass
    return total

def _λΕВПСдыΜЯΥΙγЧ():
    value = 752127
    text = __import__('base64').b64decode('S2NKQ0d4YW9aeGJPYktTTzZkSk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙРоΓΡгΥΥжьмфЪ():
    value = 374995
    text = __import__('base64').b64decode('VngwNXlKcDNhX1N1YlZrTWJMdWM=').decode('utf-8')
    total = value + len(text)
    if 49 * 71 < 0:
        _dead_5709 = 855
    return total

def _ПФрκγιЦТχζпХΙаΕα():
    value = 84064
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTzWbF0p1ZksP1iF33/GNxB4z3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭПΩГΕпнγΖЗ():
    if False and True:
        534
        903
    value = 60484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzzzV3gswYANGV2Q+WaeAQgEvTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 20 * 8 < 0:
        pass
    return total

def _юСΛννДЯΝ():
    value = 542725
    text = __import__('base64').b64decode('Z1RRelZBdlVQOWM3blVmUXZMUTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΥυюνВεΦЬΙр():
    value = 258294
    if len('') > 0:
        859
        _dead_4041 = 146
    text = __import__('base64').b64decode('WGE2TmwyQXFwelpPcDZkalVkMmI=').decode('utf-8')
    total = value + len(text)
    return total

def _мεΓЭчлβζ():
    value = 951729
    text = __import__('base64').b64decode('REJnSDJTakZQYVd3dzlVZmhzM0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ХψыЙЮφцψφ():
    value = 39832
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx3yeFsr054ELQiRymKeABUD3k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        123
    return total

def _ςйΜτζΡЩЭΖκд():
    value = 542891
    text = __import__('base64').b64decode('TnJLZlFOdzNvRjVQeHhrOFo3cWo=').decode('utf-8')
    total = value + len(text)
    return total

def _гГςРΦФΚАшаК():
    if False and True:
        672
        207
    value = 936181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn/9fVgG16BaKhzz3EWkIRwHvVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 90 < 0:
        668
    total = value + len(text)
    return total

def _гЗΣЬοοЕЫЖКиоΝΑμб():
    if len('') > 0:
        _dead_6772 = 101
    value = 671627
    if 12 * 34 < 0:
        886
        _dead_9557 = 120
    text = __import__('base64').b64decode('SkVoenlBQ0pwT1JwQVo4bGdwTUw=').decode('utf-8')
    total = value + len(text)
    return total

def _жΧуβγоййΠиχж():
    if False and True:
        pass
        _dead_5172 = 800
        pass
    value = 139703
    if False and True:
        844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz3qP1s1040aDiCz/1iaBRw120U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 20 * 73 < 0:
        pass
        pass
    return total

def _ΒχΝеΦоΩФ():
    value = 835656
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQrvP3QMxvklNSqay0K4OnZ24UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦμГσЩпнлЮЙλЧяΨЮ():
    value = 463339
    if len('') > 0:
        858
        _dead_1234 = 729
        _dead_9703 = 166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDfMaXhq8acEKS2S3lCgYTc37T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΘгτΞΚΤфтΡсПιΡΣο():
    value = 429868
    text = __import__('base64').b64decode('ZkVvd1R1dWhnVTY1NVIxNXMzWkM=').decode('utf-8')
    if False and True:
        _dead_7796 = 141
    total = value + len(text)
    return total

def _КпΦснεпКфсОδФΠ():
    value = 340584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxXTZlks254lHiiN0EK6ZgEo9Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 89 < 0:
        435
        648
    total = value + len(text)
    if len('') > 0:
        _dead_2156 = 596
        pass
        784
    return total

def _ЯчΖΩζγшыД():
    value = 455696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mw71dFw296kKHgOGkH6KNRY/xT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8006 = 120
        _dead_5790 = 854
        pass
    total = value + len(text)
    return total

def _ΜβωеΧжМжΚМκ():
    if 84 * 16 < 0:
        _dead_5120 = 747
    value = 535883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESHlXUlg+qQgPCa7wWnAOzN8vFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АдИБсБыψτВмз():
    if 40 * 37 < 0:
        _dead_4560 = 375
    value = 71048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgTIOEgR+ow5OT+s8lC3FicrtHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 56 * 75 < 0:
        _dead_1216 = 373
    return total

def _ЬγСρЩуφΦжчΔΚБνΩΣ():
    value = 316642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwTcPEEv0vo0EVf64lS3GBI27zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1888 = 132
        pass
    return total

def _РΛммСПΟςКТρьΑθ():
    value = 888672
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('d3NOclBLa2gyZU1xUGxYMzdtbVY=').decode('utf-8')
    if len('') > 0:
        _dead_9233 = 552
        _dead_3262 = 150
        8
    total = value + len(text)
    return total

def _щвЧоГкаеоΑφБАуηК():
    value = 967209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnfoPWMS5L4ZIjqa32aBZx8hsEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПУοшσяэΛψн():
    value = 559715
    if len('') > 0:
        874
    text = __import__('base64').b64decode('ck5JUmVzN3JFYzNEbGxMd3E4TUI=').decode('utf-8')
    if len('') > 0:
        _dead_3429 = 697
    total = value + len(text)
    return total

def _ЦЮшΦςλВАРФвΠΟΩШт():
    if len('') > 0:
        pass
        pass
    value = 486823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA7APX492LEhAB6F/ADAE3F61D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бοрΩСωСηшУБЮΥ():
    if 93 * 73 < 0:
        pass
        _dead_3716 = 802
        _dead_9236 = 32
    value = 550721
    text = __import__('base64').b64decode('VXNFYzdwZUplSkVqNHJUTnBwajE=').decode('utf-8')
    if 91 * 91 < 0:
        pass
        pass
        pass
    total = value + len(text)
    if 48 * 4 < 0:
        765
        _dead_1962 = 199
        _dead_6672 = 658
    return total

def _ШΘηνвкΧАσдкνπ():
    value = 280065
    if False and True:
        _dead_3210 = 570
        227
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxvuSVYpxqwqEimsxFeTGhJ+5nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘθбДйΧςΙΛЪПθν():
    if 36 * 22 < 0:
        480
        _dead_3797 = 665
        pass
    value = 538456
    text = __import__('base64').b64decode('VzdQZFpxUmpGc3pHVUhraDl4QTc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3151 = 943
    return total

def _еСΗЖΟσξΘА():
    if len('') > 0:
        _dead_2838 = 388
    value = 635739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXzsf1M+76I5PgKQzX6ENgR/40I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 94 < 0:
        _dead_9215 = 393
        18
        _dead_3011 = 152
    total = value + len(text)
    return total

def _ωΤхцυйιмщ():
    value = 349212
    text = __import__('base64').b64decode('QUhRZEpsdTFlRTFXRWdmUFVIOFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙГфЗдЕюжцγ():
    value = 20393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj7MYXUP5qIHMBeMnwGWMRUJ8Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 95 < 0:
        458
    total = value + len(text)
    return total

def _юуЛΤзγюГН():
    value = 381256
    text = __import__('base64').b64decode('UmNrSUFsS3RLRVI3dmRqWFpJY1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖВчЖфвцλргξΥЙлΝ():
    value = 684714
    if 78 * 21 < 0:
        pass
        40
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw78T0YUrPAnPTeLkFjFGyYMwmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        818
        _dead_6207 = 764
    total = value + len(text)
    return total

def _ΗμьЮОРШЩ():
    value = 32269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HA7VWF5tzrIPP1m050ekbQE4xm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙДТдηАЙМΙЫςΤΨΜЩυ():
    value = 423019
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSPpO0QNyL0aYwan+WOFBjIt6lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σιППДΜΜйχДΑΕΑ():
    value = 100243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwC8ewdpy/lVMFv2+XCoNyAM0Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦЦУΕЛюиоΨπ():
    if 96 * 85 < 0:
        _dead_5807 = 414
        pass
    value = 831127
    if 60 * 41 < 0:
        pass
        _dead_3103 = 696
        _dead_4612 = 396
    text = __import__('base64').b64decode('Y0ZtZzJ4X2JWUVB0WEFkeUJqOXI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        171
    return total

def _ОшрιбГφтο():
    value = 352877
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHfJOFUp+IssCyCP/UOFPAJ3x14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        465
    return total

def _хΒЛвлБчВЗиО():
    value = 193790
    text = __import__('base64').b64decode('eW4yWWpvTk1TTUZrd2ZoRnFnb04=').decode('utf-8')
    total = value + len(text)
    return total

def _РΦΓιηэУεиЗ():
    value = 548209
    text = __import__('base64').b64decode('QThlWnR5WjJPNkZGRDVMdG9oa0s=').decode('utf-8')
    total = value + len(text)
    return total

def _емдχΝцΗХФρШЭσТЙ():
    value = 629032
    text = __import__('base64').b64decode('UGhfWjVTZERraUNaOUJHNk5aOUU=').decode('utf-8')
    total = value + len(text)
    if 85 * 76 < 0:
        pass
        _dead_6120 = 413
    return total

def _ВΞΧΒцНΚЩДгγΞθЗ():
    value = 102201
    text = __import__('base64').b64decode('U1d2T1R6b0JENUVQT3B5T2JXenI=').decode('utf-8')
    total = value + len(text)
    return total

def _негТНΨББзО():
    if len('') > 0:
        _dead_5183 = 718
        _dead_3462 = 705
        43
    value = 337774
    if 41 * 79 < 0:
        pass
        _dead_2950 = 477
    text = __import__('base64').b64decode('RXNwMFpVQ1IxazhXdmNYdzhEOWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛρнжбΥзбΛΒ():
    value = 41367
    text = __import__('base64').b64decode('Zzh1Q0o1cEtwbHBJU0tGVEJheU4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _бщучерЧЩыФ():
    value = 417963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx3tREIUro0lFQ2G63eBBQgtsFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζОφΧοРλΕΣΚ():
    value = 78743
    text = __import__('base64').b64decode('VnNmUkFtWXFVb2MzNzNQY2hBVEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ПОвΥнΩπНΕшкЫеЛыК():
    value = 512799
    text = __import__('base64').b64decode('YTRPV0JfRGtvVnh4UjJYckt5OVU=').decode('utf-8')
    if len('') > 0:
        _dead_8922 = 421
    total = value + len(text)
    return total

def _БξуЕьхИЬлктнψ():
    value = 471159
    text = __import__('base64').b64decode('V0xUQUxyWjdoS3hFelo2X2w0WUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΑπΜЮппорΞЖЮюΘΒ():
    value = 824345
    text = __import__('base64').b64decode('U3E0b0c2eGtsQndHa0h6MEluc3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΕΠюйΜΘБ():
    value = 5510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyvOWXMqwa5SD1m1+UWcZnUC9Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХВΟνΛλδΒйЮЗСд():
    value = 325668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhbRNwZqzPAnEh3x2W+qYRcd4mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯМΧςωеяЛ():
    if len('') > 0:
        _dead_7823 = 595
    value = 916182
    if 4 * 11 < 0:
        443
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChvARUFh1q0EMgGP6X+ZMCsM1E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΨъΚфчεΗ():
    value = 544919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHj8V3gg56cqIhy3wn/EMSo3tzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΧЙуΘωяНΝνеΟΡ():
    value = 814399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBnoTUYdy6QEaiv0/QKkEwwfxWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шαвюΖхτЦ():
    value = 433052
    text = __import__('base64').b64decode('enh5OWI4RXZQY1RCOUc1a0tXX0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯЫιπшнζДωябВ():
    value = 694267
    if len('') > 0:
        pass
        390
        pass
    text = __import__('base64').b64decode('UktpaVZ6OTVWUzl6UWVBdnlpVGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ψДГΞФΛЭΦΙ():
    value = 972644
    if 28 * 98 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD3+eHVt+I8LbjqS432FIxEC6mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 23 * 8 < 0:
        pass
        pass
        966
    total = value + len(text)
    return total

def _ΑΦШЪХкπτΠУβΡ():
    if 69 * 14 < 0:
        _dead_2577 = 973
        _dead_6792 = 445
    value = 869808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjvyfGkRwZ5TGVmky0OgZAw4t3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        791
    total = value + len(text)
    if len('') > 0:
        884
        930
    return total

def _жαйφЮχьэлΩζПИуыб():
    value = 600363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBXhbEkz9KQma1mBxFekERElsUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5145 = 962
        pass
        pass
    return total

def _ИΞЫνФжΒΜγБΖБ():
    if len('') > 0:
        _dead_8926 = 364
        pass
        _dead_8003 = 728
    value = 699994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3u1fm4Y2qUpHDmpwGmIMw5+vDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧςΜщчтЛЕеΖф():
    value = 951480
    if len('') > 0:
        pass
        pass
        _dead_7863 = 727
    text = __import__('base64').b64decode('WGpnb0F1b1BnZVdnVGpibmp5dWM=').decode('utf-8')
    total = value + len(text)
    return total

def _Υщйοκтажэьме():
    value = 739566
    if False and True:
        309
        222
    text = __import__('base64').b64decode('WGF6aFJrUzNGRGEwUVFlMnd4MWo=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if 93 * 7 < 0:
        789
        _dead_3173 = 136
        _dead_6520 = 423
    return total

def _НПШхЧΖГΟЗквΔζх():
    if False and True:
        pass
        _dead_7706 = 909
        pass
    value = 671270
    text = __import__('base64').b64decode('a19TT0NBVTV5amtjTjlLSmZRTUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΧДГΖГэьΛщЖш():
    value = 942044
    text = __import__('base64').b64decode('Z25VUFRjSHBNYXIxZXp2RDRsZ0Q=').decode('utf-8')
    if False and True:
        pass
        _dead_5621 = 955
        _dead_6649 = 835
    total = value + len(text)
    return total

def _аΨСЧцМзδδχКΟумча():
    if False and True:
        296
        pass
    value = 374703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyTIXVIQ7Jw0FRf091qqHRwntGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 7 * 17 < 0:
        _dead_3782 = 941
    return total

def _ЧΞтψрЯмзюψΕРТяΟΓ():
    value = 892281
    text = __import__('base64').b64decode('dk5ld1Rlc19FM0hIekdaV21keDI=').decode('utf-8')
    total = value + len(text)
    return total

def _цЗΛΟфΜСлЪДνΑπьКШ():
    if False and True:
        pass
        _dead_6695 = 37
    value = 446399
    if False and True:
        _dead_1357 = 83
    text = __import__('base64').b64decode('RHUya2xjbzFtTGs1bXRvNmdTUVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ОЙдεΕΞрдΡР():
    value = 133644
    text = __import__('base64').b64decode('WHZwa3RRb252eTJRZFhTUmhpU0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕЖфпЙКωУξΙ():
    if len('') > 0:
        pass
        516
        380
    value = 86177
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('eHdwWDV0bFg1eTRzT0RfcG5WWUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _уχСγяψДгυъйчΔщМρ():
    value = 613983
    text = __import__('base64').b64decode('b2RlYTRreGhPNkZDRzNpUGlUcE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤνπгΥПЩРзлЫВ():
    value = 966478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDn2fHhu8bAzPxb37HvCFSQ25no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6520 = 693
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_8122 = 92
        pass
    return total

def _ΓξЕΗъЫΕξЪ():
    value = 561031
    text = __import__('base64').b64decode('RjFyR1J0UjFLMUZYN1Q4cFUwUGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨУэοрΚΠσ():
    value = 63171
    text = __import__('base64').b64decode('VXBhdUJ5djBUMHBWX21VTnpIWGM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        991
    return total

def _λнΒΗΩΡшψЖшоψЯчψ():
    value = 643035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cxz9WlY1664zLS2J7QLJBzw+3W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠкβθушφΧЗ():
    value = 463447
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzzjbUUx0a0XDA6o2F3JHwck8mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жрΞГΟιΝφΑЕ():
    value = 627554
    if 96 * 41 < 0:
        _dead_3173 = 417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgDyf0FqprAKNVaC5EbGPSB3010='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШιАζсΛζКмНъΓβж():
    value = 961737
    if len('') > 0:
        825
        _dead_4853 = 190
        pass
    text = __import__('base64').b64decode('Zk1iaUJScW1mSjhwSTVycG0yOE4=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 49 * 58 < 0:
        288
        _dead_6388 = 270
    return total

def _хжЬГςΗζБΜгЬу():
    value = 981367
    text = __import__('base64').b64decode('TFR4eTJaX3k0cHdFaENtQmltQ3Q=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _юСЪжΔΥΚΘг():
    value = 152942
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw30V3AQ7YQOCCz19323O3Ua/GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νаМяΚиγα():
    value = 433455
    text = __import__('base64').b64decode('Y2w3cll0cnpWUU9tdUdmYWdER0M=').decode('utf-8')
    total = value + len(text)
    return total

def _аΨЬРΙФцςлОиЕкΨ():
    value = 758010
    text = __import__('base64').b64decode('cTlxZzFUc3Y2bkljNHF2REdmZ3E=').decode('utf-8')
    if len('') > 0:
        pass
        784
        _dead_5437 = 308
    total = value + len(text)
    return total

def _жоδММрπκΞЛιывШι():
    if len('') > 0:
        pass
        _dead_7743 = 435
        _dead_3305 = 435
    value = 259463
    if False and True:
        443
        175
    text = __import__('base64').b64decode('YWlRY2dYNG90Q3ZMeDhzOHNTNlk=').decode('utf-8')
    total = value + len(text)
    return total

def _вкΩΨΦΡκДйΨΚ():
    value = 831572
    if len('') > 0:
        21
    text = __import__('base64').b64decode('Z2QzdVdKbWlCV3ZpTWJJM2lGQXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨλЦпΛμеΕБУцКΥ():
    value = 516894
    if 81 * 98 < 0:
        900
        355
        161
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiLcfVY3pp4ZOD2T7We8EBI66GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 31 < 0:
        pass
        pass
        _dead_9825 = 294
    total = value + len(text)
    return total

def _ΓэδнΙγφωзф():
    value = 21294
    text = __import__('base64').b64decode('WnpGSGwxTkJ4WjBFWUhrMnBMMWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ηчаЧΨΘυАяяΥγΝ():
    value = 299536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBrje3xrz6MEYwab3Wm/AzYc61c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΖσЦςχВςχэфцοПΤ():
    value = 448811
    if 54 * 60 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH3WPmYzpv01Izeh62C8PHAY3jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΘзиΝΧыΓуУσψЫж():
    value = 633387
    text = __import__('base64').b64decode('Rjl5MDNCOGZvRmFDMGFJRU9fY2k=').decode('utf-8')
    if 47 * 52 < 0:
        _dead_2467 = 858
        194
    total = value + len(text)
    return total

def _ΠΡмяжщГачυуЖ():
    value = 35293
    text = __import__('base64').b64decode('SXZDMWl0RnJaNXhXTnk0SldXeDM=').decode('utf-8')
    if 27 * 55 < 0:
        _dead_7353 = 119
        _dead_2366 = 27
    total = value + len(text)
    if len('') > 0:
        _dead_2649 = 409
    return total

def _αИуσщхЯТт():
    value = 241963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxnRflA+3/43Nzzx7ECpICE+tnY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6247 = 399
        pass
    return total

def _ΙТκΠΔоΒуΞДЩзх():
    value = 432041
    text = __import__('base64').b64decode('T3oxUG1EWHRVY08yVG93MDVPbDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΔфΖьχЫκЫО():
    value = 550466
    text = __import__('base64').b64decode('WHdOX3cxX3VpR0hxNEF4WjBxc1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЧσЮФКТθьыζр():
    if 68 * 56 < 0:
        pass
        460
    value = 311336
    text = __import__('base64').b64decode('c05XTTRnbmRJTWI0RlEzOGZldGM=').decode('utf-8')
    if False and True:
        _dead_6445 = 298
    total = value + len(text)
    return total

def _чΣъШЧφиμ():
    if 49 * 11 < 0:
        _dead_6064 = 173
    value = 675411
    text = __import__('base64').b64decode('cEZqX19PclRWWkQ5ZVZpYUQwZmM=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_2123 = 755
    total = value + len(text)
    return total

def _РкγЪουνξ():
    value = 654970
    text = __import__('base64').b64decode('RGNYcFpsQVprSmhuYnNsekJYb0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚфΜΗΚζμκЯκзΕβΡ():
    if len('') > 0:
        _dead_6404 = 310
    value = 370706
    text = __import__('base64').b64decode('Q0VTczRnRFBMdjZVX21PY0hvbzc=').decode('utf-8')
    total = value + len(text)
    return total

def _рυЫЗрПψζуθτФΝ():
    value = 152557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwXrOVpt74waM1q78A+6ICon5Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6797 = 817
    return total

def _φЭКγуαΥΑЛИ():
    value = 774156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyPndnw35vERYwqWyV25YQQV3lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1065 = 266
    total = value + len(text)
    return total

def _γκоζнЕгΔжО():
    if 80 * 44 < 0:
        pass
    value = 710526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBDXRl4Wx74CDAC2yni1FnM4t3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧмкбχяЙдЗЬγГХгЭ():
    value = 339440
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSC9f2k/9/EiKjul2He8GiMOw0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑьЕχЭЭΕψΒрЙΦ():
    value = 686282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fjm9R1I9qIosHwS1y2ChC3wHtXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧЧвщρΔгзуζΓ():
    value = 291212
    text = __import__('base64').b64decode('WFFqeFlKcGYxVE90QkZtYVJkdzY=').decode('utf-8')
    total = value + len(text)
    return total

def _λБηгΨΣΞзРзγΘ():
    value = 466059
    if 49 * 71 < 0:
        _dead_5282 = 337
        pass
        871
    text = __import__('base64').b64decode('YWZfRGdfQTcxMG9wUGRPMmpiQl8=').decode('utf-8')
    if 59 * 6 < 0:
        _dead_2441 = 303
        _dead_5337 = 534
        pass
    total = value + len(text)
    if 36 * 28 < 0:
        556
        799
    return total

def _ПбЬδЪтяядρгшξ():
    if len('') > 0:
        268
    value = 462886
    text = __import__('base64').b64decode('a0VZakxhSmpyalJoNnRjZTZPRjI=').decode('utf-8')
    if len('') > 0:
        680
        _dead_2313 = 136
    total = value + len(text)
    return total

def _щЯμЪЕΗΙΒρΜДе():
    value = 821748
    text = __import__('base64').b64decode('SnZTaGNtSWdhUWFNd3I4RUdKcDc=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_3592 = 658
        pass
        _dead_7914 = 13
    return total

def _фμЩθйΖνΠнбΧЦΘΦ():
    if False and True:
        _dead_7691 = 81
        _dead_2968 = 827
        pass
    value = 408346
    text = __import__('base64').b64decode('ZzZaV3Uya2JveVBoSUYzNW5keTE=').decode('utf-8')
    total = value + len(text)
    return total

def _φОΚβΙсΕХΗΩΥ():
    value = 920791
    text = __import__('base64').b64decode('VUVIQjVYQ1N6UmZfZFhKUE1aeGw=').decode('utf-8')
    total = value + len(text)
    return total

def _θλωЫСТΓМω():
    if False and True:
        _dead_2698 = 16
        450
    value = 599191
    if False and True:
        _dead_1610 = 243
        pass
    text = __import__('base64').b64decode('a3lfcFAzTzl6aUp3c3ZZVUtuRDU=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΣЪвΠЪΔΚЫдхНΜпщй():
    value = 812616
    text = __import__('base64').b64decode('RXZjT1RfS1lpSFlaQVlkTXd1eUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧИуΛжЙСохΝΕаΘΟΜΧ():
    value = 606852
    text = __import__('base64').b64decode('T2ZXZEt2bmlCd0dzeUE4NUNXVWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞПμеφηЯцΜ():
    value = 989763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSrpXGcu7q5aIB6CnE6HDhIMw1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩишβджωЦσΠВ():
    value = 272791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR7cN3sh3YNXaAyE6VSBHjYhtEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 76 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _αЩтиΥЫκшΤ():
    value = 466597
    text = __import__('base64').b64decode('eEN2QklYS2xlR3FkNTR0TmdFQms=').decode('utf-8')
    total = value + len(text)
    return total

def _съхρтφηЫ():
    value = 115354
    if len('') > 0:
        _dead_3959 = 410
        _dead_8583 = 850
        _dead_5572 = 278
    text = __import__('base64').b64decode('VEhxakpLblpnV1M0WFJxdG1JTDk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5307 = 82
        365
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if 83 * 78 < 0:
        981
        30
        pass
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()