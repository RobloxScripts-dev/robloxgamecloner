#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ЫЬЮаъΙιхДзьлχΤψν():
    value = 95443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXrAW1co1Zo3A1aB2WaWFSh/xn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΘсΩξΦψψΧАоνхОΕ():
    value = 540196
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgnJdEUxx4IEPQ6czXqaBTEH9X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τвдФщщйХ():
    value = 50049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICfvdFgPp4YhMTC0+FyEARwGtmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5230 = 32
    return total

def _ЦΞэФКСпОмΤ():
    if False and True:
        pass
    value = 317452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTjSQVg/yrElDSC3wHKKZDwMyWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        346
    return total

def _АΓэыΡΧΣяιрδНЬ():
    if False and True:
        362
        pass
        pass
    value = 510129
    text = __import__('base64').b64decode('Ylp2bUd2M2xidXJLYmM3bElGbXM=').decode('utf-8')
    if False and True:
        _dead_5347 = 141
        939
    total = value + len(text)
    return total

def _вшΔμΚВτсюгΩ():
    value = 205264
    if len('') > 0:
        _dead_6163 = 664
        697
        _dead_6792 = 886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADn1VFsW9Pg8ah67xVGHNn0g8j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        122
        484
    return total

def _жяЩβшаВсΓΔАΛΚ():
    if len('') > 0:
        _dead_8223 = 189
    value = 472721
    text = __import__('base64').b64decode('SUo4ZVBnc0JObDlITmwwRHFwNmw=').decode('utf-8')
    total = value + len(text)
    return total

def _αеΙщΒηΟргШ():
    value = 598491
    if 71 * 43 < 0:
        460
        _dead_6958 = 53
        _dead_6248 = 281
    text = __import__('base64').b64decode('c3hxc1Q0X09nVXlDOFdmdzVHWlk=').decode('utf-8')
    total = value + len(text)
    return total

def _убιкΚчνσГчΦΛ():
    value = 922419
    text = __import__('base64').b64decode('VElxdGJ3ZmV4RlVJd0U3RTdiYXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΙΦаτНкГΥεфΖхΗлι():
    if len('') > 0:
        _dead_7563 = 472
        142
        _dead_4851 = 943
    value = 471119
    if 21 * 30 < 0:
        813
        _dead_5328 = 254
        251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AR3We1wK7PkIbyaMxlCcCyckvUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΝцλεδΗдΘ():
    value = 658093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQ72aGMJ7KVXAyG28AXJbAA39lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘφЮзЦТчολРМΕε():
    value = 843767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Azr3OVcQ75AbMTqc6nW2YxYt3X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОгζιыблЫΧАЧЧΞН():
    value = 391204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA31ZmMb6aUCExqw0EGaPwgc1Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΠξОтΓзγ():
    value = 9741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3jIaVwY6qAbaiSB8HrHNQZ/42A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠκφхЪηОΨχшωЯЪτ():
    value = 94340
    if 71 * 91 < 0:
        590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NH3qVkI3q70mPCCU5E6aFxUdzVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓЫΝччοЖъδЙЖЛ():
    value = 6217
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HS7mN10T6YElHVaon1G6LQ4oxz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        446
        pass
    return total

def _лωξщюΔСθФЩйнΡΓ():
    value = 429288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx7RZHgO8PovKCG3n32iIgYo61E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗюлεЫΤХеΞГξкΙ():
    value = 520917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3rnZmkU26YRCgOr61OKO3Es9l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αкΦΕΙЬψФΠЦεчΕΞΥЙ():
    value = 943729
    text = __import__('base64').b64decode('c0FlWFoxODYyN0xMZnZQdUFScG8=').decode('utf-8')
    total = value + len(text)
    return total

def _βашлЛЪυНЗмдψэРкΤ():
    if False and True:
        476
    value = 662402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERzDTAg0+b4rGBWNym/CYSc3zFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 5 * 17 < 0:
        _dead_1656 = 195
        pass
        _dead_1624 = 534
    total = value + len(text)
    return total

def _υХждΔβΓτ():
    value = 732937
    if 3 * 65 < 0:
        _dead_8688 = 510
        _dead_3834 = 282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyzTeFdg0IkrF1yizFyJDiF7sFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 45 * 74 < 0:
        140
    total = value + len(text)
    if 64 * 31 < 0:
        pass
        pass
        110
    return total

def _εαвτзфοΚΙКΘΩч():
    if False and True:
        _dead_5687 = 263
    value = 258116
    if 41 * 34 < 0:
        _dead_7738 = 845
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDfJOAc/yPkGIluTxVqVMnc492U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 18 * 13 < 0:
        446
        pass
    total = value + len(text)
    return total

def _ОШΒфδыЙзсθΑЛ():
    if 77 * 2 < 0:
        pass
    value = 371718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDjnTEYzx640DSOBnX+cMj89sno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 95 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_2997 = 922
    return total

def _ρυЗсВψуИφД():
    value = 823220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQu8W2YJ968TMDiSxXCoIDEg7Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψэЩΛмэΦΨфιςЫ():
    value = 836077
    text = __import__('base64').b64decode('aG9UVnljdHJrNFU2VlVmTE54YlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЬиРКлКΡ():
    value = 819609
    text = __import__('base64').b64decode('S01fRVl0STIxcWM2cWh1WGd5VU8=').decode('utf-8')
    if len('') > 0:
        pass
        84
    total = value + len(text)
    return total

def _яуθаХΘЕΝыЙыΨδΘО():
    value = 797230
    text = __import__('base64').b64decode('ZVF2WkVfaUhDNGpTbm9VeXdpWm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞкРζОτКΘβΖь():
    value = 561334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAL1dH8o/KURPgLx7gSmGHwMy1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΟΕΓΖмОюΧаиςИφТΡ():
    value = 61920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH7GdwZs+rIbODWa+kSIOggk5kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩРΖθЭЗгцТΥШ():
    value = 770305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTfFWHAA7vwQPCTy0nDHZj8f3EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЖЬЪпοΞшνρβκοξΜη():
    value = 189273
    if False and True:
        _dead_6977 = 10
        105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHexQAc2qLw7PgyxxGShOSMu9Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξьπΛфаыυΖЖщΡΕνИ():
    value = 889630
    if False and True:
        581
        692
    text = __import__('base64').b64decode('bjJLbXl5SjB5SGd4cXFFSTJ1cmI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        280
    return total

def _ΟτΝΙщГΝΟНСикщм():
    if 46 * 40 < 0:
        pass
        _dead_4955 = 442
    value = 587033
    if False and True:
        _dead_9066 = 569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRq0PkUs6L8EMA3wnGaaHBY682Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъЖΔШλХχΞТпъТΛЙ():
    if False and True:
        _dead_8218 = 508
        pass
    value = 580355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT7CP0ER3b0XH12byWG+OnV9wGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8094 = 1
        pass
    total = value + len(text)
    return total

def _иММзъдлфРπбОΧБ():
    value = 511756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBrVPFVpyL5QIxip73G9ES4jw2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κχЭсΔснΞΦФΓΜαБΣк():
    value = 48417
    text = __import__('base64').b64decode('aE9icmZGQWMzODNBd3NHQUNLVVI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _υσфρεΚЫхΚΤынΔδζв():
    value = 441871
    text = __import__('base64').b64decode('ZkZ0ZWNKcVJiMTdDRWVOam5kUlE=').decode('utf-8')
    total = value + len(text)
    return total

def _σΓфъΣУрй():
    value = 320494
    text = __import__('base64').b64decode('RWR1aGZHbXZOOXpBdzRrWm92REY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6378 = 500
    return total

def _λπγХуΟαρΨъΠ():
    if False and True:
        _dead_3435 = 690
        pass
    value = 127602
    text = __import__('base64').b64decode('djh5OElka0RIbzR5ekp4WWU2Wjg=').decode('utf-8')
    total = value + len(text)
    return total

def _пуВΣявЙЪтнΟАΘы():
    value = 794843
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTuwfWYcxJEPIgeB4ECmCw8exXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φэдшвТжеЗюηТе():
    value = 460476
    text = __import__('base64').b64decode('RkZseW9JcjZvZUx6YXRKMGFBaHk=').decode('utf-8')
    total = value + len(text)
    return total

def _λФКХТФρТΨЦλЖ():
    value = 788090
    text = __import__('base64').b64decode('dG1LM21BbHloWTVneW5sWUVlcVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΔΑυуβЬФΘЧΔΗШъΘΗ():
    value = 662453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxbgZnk0zZ0bPwag8n+nAzd6tn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        520
        _dead_3675 = 105
    return total

def _умштлоΝюυеУфΥηзс():
    value = 884705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCfmdGcv8JgKHyqKxGyDInQ981Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψнцЗΘяШΑИФ():
    value = 165947
    if len('') > 0:
        _dead_8599 = 730
        pass
        _dead_6833 = 621
    text = __import__('base64').b64decode('VmxsWEI5T2dRN1RNODhyY3lOWnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨυЬΑйсгωιΨΜβГШ():
    value = 241157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhzpO2QKz6ctCxiL/GnJGQEnsFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8007 = 691
    total = value + len(text)
    return total

def _ПДГЙДκΠξЪΑб():
    value = 104732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mi3vNlow7IELY1mk+wOiNgEH7HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 47 * 37 < 0:
        880
        pass
        pass
    total = value + len(text)
    return total

def _зΔУλνΜДэΕκц():
    value = 213101
    text = __import__('base64').b64decode('TGN1c09iYWVmT3QyOEEwMlNTQ1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _σРψъТΟюφθГΥгЫАκΤ():
    value = 251631
    text = __import__('base64').b64decode('aUI3amEzcDE5N1ZqNzVZTkNFRmU=').decode('utf-8')
    total = value + len(text)
    return total

def _οЬτцхЕιε():
    value = 785227
    text = __import__('base64').b64decode('SGs5YV93eG0xXzJWMTR3bkhoVXQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        90
        _dead_6112 = 707
        528
    return total

def _ΘτΘΛΠνΒтяЮΘс():
    if 23 * 89 < 0:
        pass
        556
        pass
    value = 288280
    text = __import__('base64').b64decode('WDVUTGIxVndLQVNabjBWSjNGWFU=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_8989 = 989
    total = value + len(text)
    if False and True:
        639
    return total

def _ΝΖΝυтВΔшφΛь():
    if False and True:
        724
        _dead_4556 = 307
        377
    value = 410939
    text = __import__('base64').b64decode('Q2RsVE03WFhhazZtenppYjdKa0c=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        378
        425
        _dead_5051 = 14
    return total

def _ΦΘВБюшНцШ():
    value = 992477
    if False and True:
        pass
        _dead_5456 = 125
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwD+O3ocyLIFKzyk/324F3YhvVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6259 = 619
        468
    total = value + len(text)
    if 68 * 79 < 0:
        _dead_7243 = 587
    return total

def _кЗΦЕлуρЪπЬΧбеβ():
    value = 402334
    if False and True:
        _dead_3286 = 5
        _dead_6041 = 619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAjSYGBqzv8UaRWrw2fBZCA460E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΦЛВщьтЗμу():
    value = 403273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3znS3wWyZoEHQWi0lyHFw4J80A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еτΕΓΔеρзζζΧΝЫод():
    if False and True:
        _dead_9439 = 487
        549
        pass
    value = 813035
    if 18 * 52 < 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('cTJ4RFpTOFJXNXIwa0M4aEEzOEg=').decode('utf-8')
    if len('') > 0:
        _dead_7166 = 67
        pass
        _dead_4932 = 251
    total = value + len(text)
    if False and True:
        _dead_4478 = 959
        955
    return total

def _ЙИцИагбрΚΩедР():
    if 52 * 82 < 0:
        pass
        594
    value = 184203
    if len('') > 0:
        pass
        963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnfvY31vzpc6Pwf28myCAAko6V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ихКйζΟОхЫη():
    value = 107964
    text = __import__('base64').b64decode('RkpGWFBZYXdGd0dkbHBOWDZvWmY=').decode('utf-8')
    total = value + len(text)
    return total

def _εκξθΔγΨΕ():
    value = 607682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I339SHMI6bIiBQWHyVipBjct1Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯιцсэοьΘθζА():
    value = 700728
    text = __import__('base64').b64decode('cXBrTjZsdHFuQ1JvaFBROHpVOU8=').decode('utf-8')
    total = value + len(text)
    return total

def _шΑШλсиωωΙФζХιРΘ():
    value = 634526
    if 23 * 13 < 0:
        pass
        608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3i8VgAD9IItMgSP616SbCE46Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 24 < 0:
        _dead_8933 = 837
        _dead_6933 = 996
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_1496 = 920
        _dead_1055 = 138
    return total

def _ΟйЧщМηΒπВъэΝ():
    value = 107053
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyXNbXQt3axRAgqA8XiiFj930Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гзЙнхЗΓбГИψвΛ():
    value = 963662
    text = __import__('base64').b64decode('eHdqV1B5SEVtUWZpSFZuZmxGRFM=').decode('utf-8')
    total = value + len(text)
    return total

def _πзΙψΖжщзКцл():
    value = 99991
    text = __import__('base64').b64decode('Q3QzMWRBaEJvYjlIWjBES09VdzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩКэπБуρΙмжΥЮΟ():
    value = 185527
    text = __import__('base64').b64decode('cng5VVI2aE5mMWJLRjRXMWF2eFM=').decode('utf-8')
    total = value + len(text)
    return total

def _уЗэυΗйΓгГвΠэтС():
    if False and True:
        _dead_8206 = 600
        pass
    value = 56191
    text = __import__('base64').b64decode('ejlZb3VBdTUyQTE4Z3hCTWNxb2I=').decode('utf-8')
    total = value + len(text)
    return total

def _σρСМщМЬγ():
    value = 256977
    text = __import__('base64').b64decode('T2xXbnF5cFhicDI5VkJBY1ZQWDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _съΨаЧΩΜκзΨτз():
    value = 516423
    text = __import__('base64').b64decode('Z212QW82NllRV3ZZXzVLWjhodlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫвФΞКсрТξфихН():
    if len('') > 0:
        _dead_4770 = 113
        259
    value = 999053
    text = __import__('base64').b64decode('UHBYUXVZZFMwM0JZbGJSOEE1V1U=').decode('utf-8')
    total = value + len(text)
    return total

def _всЫιΨХΧνΜНВΙх():
    if False and True:
        pass
        pass
        _dead_5403 = 353
    value = 608256
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQPHQlQz244JGAmhwQ6yYA4W8nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5374 = 274
        _dead_7473 = 608
    return total

def _йМυэЦγΩшδЩε():
    value = 656728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH7mVFRvzb1aHwb2mHi0JCF+4j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УτχΕсвбΔ():
    value = 994700
    text = __import__('base64').b64decode('V1FSM1I1TVdUc1FiNjRDRW9BRlQ=').decode('utf-8')
    total = value + len(text)
    if 34 * 39 < 0:
        715
        pass
    return total

def _ДшλжσКфπЯΑеВΡъ():
    value = 803911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSD0V0Vg66kJCgGU/F3JFXE+0lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФςбсρυлЗЖдσрВ():
    value = 256222
    text = __import__('base64').b64decode('ZmhKSVZKU3dkeWNjRGtBMG5hYnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЩΨλхкхсОтГ():
    if False and True:
        pass
        pass
    value = 554914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAHpPmFp8roTPz6C9wemIi016Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 11 * 82 < 0:
        283
        828
        _dead_3613 = 146
    total = value + len(text)
    return total

def _ЯΔФваκчιθγХΟФЦх():
    value = 350815
    text = __import__('base64').b64decode('ZHZaV3JHOElybHVnalljTktxM2Q=').decode('utf-8')
    if 49 * 94 < 0:
        830
        295
    total = value + len(text)
    return total

def _φьбΤΨΤΛΨюΦ():
    value = 800782
    text = __import__('base64').b64decode('dkRjMWVYWWVJdG9zYUYxNk1kdW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ДйπэлБГсιшЧьЫиИа():
    value = 105355
    if False and True:
        _dead_6367 = 577
        761
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXf+QWkQ94BaNz+C7FfBEQwK82c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _τζΠΩςφХКπЧЖЖιΤυБ():
    value = 567526
    text = __import__('base64').b64decode('WENTeW1sSTBuUVFEaUVKckxFaTY=').decode('utf-8')
    total = value + len(text)
    return total

def _эНπΝυΩСαΣοΨΡΖЪθ():
    value = 987754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwjsOWE//YIWaSX2mACFBHMo4nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 97 < 0:
        pass
        _dead_3417 = 121
    total = value + len(text)
    return total

def _ЗЖлТдфАΜпшыΛΤчεЬ():
    if len('') > 0:
        _dead_5741 = 546
    value = 816113
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lgf2eFkxzLFRNAqQ5EDHMj17834='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮЗчеΗяУΕМхνΙΝ():
    if len('') > 0:
        pass
    value = 645584
    if False and True:
        _dead_8437 = 467
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCT8V1807PkkAF+Z+QKJCyJ85U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПШаЙМθνБ():
    value = 409011
    text = __import__('base64').b64decode('VFdHaHpBMncwRXlZbmhveHhwNk8=').decode('utf-8')
    if len('') > 0:
        _dead_9724 = 255
    total = value + len(text)
    if False and True:
        _dead_1964 = 702
        478
        pass
    return total

def _ΡфψΚΥξΙаЫλΟОΩ():
    value = 231186
    if 76 * 68 < 0:
        140
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzfTelxvy/AaHhqJmA+vAHd+s2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        940
        _dead_5912 = 844
    total = value + len(text)
    if False and True:
        501
        _dead_6142 = 513
        600
    return total

def _ΥεфлрΖηφ():
    value = 935885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBfdTWMa5rEPNA2E3kGoOAgH1Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        799
    total = value + len(text)
    return total

def _εСъшмυΞРЫчΤа():
    value = 443944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjrCbFYI67wgayWr5XqHLRINvUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВкфцЖЛΡγХБ():
    value = 333000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACn8QF8L/KAyal6z/WzBIRp99kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΚΝλεχЙΜтπЦбΞПв():
    value = 158522
    text = __import__('base64').b64decode('alY3ZnRNYmFCRDlKemJIRGR4Z3E=').decode('utf-8')
    total = value + len(text)
    if 56 * 50 < 0:
        pass
        pass
        pass
    return total

def _ΕωиЖУбХпс():
    value = 250235
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fj+3SAEOqY4OAjy1ng6eLhw+4kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηπЩЛфлЬу():
    if 33 * 23 < 0:
        pass
        206
    value = 220398
    text = __import__('base64').b64decode('UmtYZU9DckJaT2pEMHJEY0o3dGo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        696
        _dead_1695 = 123
    return total

def _ΛΠοГиΤОТэЧРψ():
    value = 382991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjbzW1AAy4IXDQGyn3XHAS8u52A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΧΡкСΣΝГΥΓεН():
    value = 673137
    text = __import__('base64').b64decode('dzBTU19DOUtSZ2YzUzdWbk54RWw=').decode('utf-8')
    if len('') > 0:
        646
        990
    total = value + len(text)
    if len('') > 0:
        _dead_7882 = 932
        pass
        pass
    return total

def _ИΚΧΛωΡΡяяηΓ():
    if False and True:
        _dead_7383 = 980
        pass
    value = 760954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCXbOVo084AiESWTmUyZPQN+4H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΟερεΔМюсξΑΠ():
    value = 112787
    text = __import__('base64').b64decode('cExuZkh4SXNOOE1idHE5bGlidGg=').decode('utf-8')
    total = value + len(text)
    return total

def _орНЖΜРЪΑЧх():
    value = 34204
    text = __import__('base64').b64decode('RmxBbDJrTTlRbWNpNWxMamRiZ2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _сζолΠвχΞАПΟБ():
    if 80 * 24 < 0:
        pass
    value = 522328
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ7SOEYg0vkBIAqrz3y3AXcV51Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 30 * 78 < 0:
        pass
        375
        _dead_9588 = 218
    return total

def _щаσζнАχΣШΩβΙΛаΨ():
    value = 156541
    text = __import__('base64').b64decode('ZTFRNmxzZXBDd193cERHaDJzcHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧАξΕПжяЪЛΒξаΙσ():
    value = 997700
    text = __import__('base64').b64decode('TGdtdmxVcHRnOGt6bHpLU3k3UkY=').decode('utf-8')
    total = value + len(text)
    return total

def _дгχЯъдоςЮКΚДЫψьΙ():
    value = 931164
    if len('') > 0:
        pass
        _dead_7426 = 773
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dzr8OUA/055TEACg3EWWDhMg4H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8977 = 578
        pass
    return total

def _υΛдВэΓОеЧЖζ():
    value = 963090
    if len('') > 0:
        _dead_3645 = 499
        _dead_7453 = 73
        pass
    text = __import__('base64').b64decode('TTQzTW1DMzlFS3BObkUxblFRaW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΦΡуюПΝεфтыУоа():
    value = 567146
    text = __import__('base64').b64decode('ZGFBY1JJZFFzVEFFQmpmbjJCbEU=').decode('utf-8')
    total = value + len(text)
    return total

def _црЯФХЗаьЧзναОеφ():
    value = 566342
    text = __import__('base64').b64decode('U3JnZHVPWjIxUmNhWnJfQl9EN3Y=').decode('utf-8')
    if len('') > 0:
        482
        pass
    total = value + len(text)
    return total

def _цФυБзΧНχΣαьЖСАΥЕ():
    value = 834066
    text = __import__('base64').b64decode('eVJOR0lLTU9yZFBXaloyREtERVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧяΚνЮЯΑъУн():
    value = 803670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQDDSmUU9YVWPluKmkWyMwYO93o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΧβЙЗуΝαПΞЦΗ():
    if False and True:
        _dead_5119 = 973
    value = 477934
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAvmeXVr0qEKMhmM2FWdOCMjzzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        906
        402
        _dead_6772 = 486
    return total

def _ΧЯдΑΦцΑΥ():
    value = 93637
    text = __import__('base64').b64decode('bXlYQzZmNUJ0Nk1BbTZRQU1SQjg=').decode('utf-8')
    total = value + len(text)
    return total

def _γωгЯлЧΨБ():
    if len('') > 0:
        _dead_1541 = 448
        _dead_4333 = 89
    value = 78730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pyz0fUgL3YMgCCmV21W0BQYCy38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 33 * 75 < 0:
        _dead_9047 = 393
    total = value + len(text)
    return total

def _МШтюΨΑΜФиЙδпΗω():
    if len('') > 0:
        _dead_4892 = 577
    value = 550374
    if 18 * 2 < 0:
        pass
        pass
        _dead_4947 = 635
    text = __import__('base64').b64decode('RzBJd3VXMVdzSkhvN0VfSVlaRUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _НкΗбθΡЯЬоЖβьμηζ():
    value = 806893
    text = __import__('base64').b64decode('R05FSmxkOFFSR1I2UDlRZmkxeWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ОьЪИΚΩВМБ():
    if len('') > 0:
        99
    value = 119355
    text = __import__('base64').b64decode('ckFCd0hMWER5YUgwOG9TX1g2QnU=').decode('utf-8')
    if False and True:
        894
    total = value + len(text)
    if False and True:
        _dead_9868 = 509
        _dead_2905 = 168
        57
    return total

def _ΛζЮеЬΓΜдλОЙвще():
    value = 648197
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxDgPmUyq4lXAgqC20CxNiR93H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эπлΧгΙΟζзмБ():
    value = 178141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQLWVAQS65smbybw2HK3Pxon0ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        179
        321
        pass
    total = value + len(text)
    return total

def _ьΛхкψЪτХтфΡρ():
    value = 833928
    if 94 * 26 < 0:
        _dead_1982 = 201
        798
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXzBaV4r2q0yLwaX4FWAOx06tkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΩЙцΝЦΨчЯс():
    value = 319317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzrvbHBo2pwXNB6cnWKnZhIXtFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1097 = 788
        _dead_7150 = 214
    return total

def _ФξеМΘκΩηΨкоΙ():
    value = 388183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQ7dXgFsyL4ZKje62maAHi8M7F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 12 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _υХзΖуьРς():
    value = 399558
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH3mXmYq164CaDmQ2HKVPhM53n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3638 = 670
        _dead_9454 = 646
    total = value + len(text)
    if 31 * 97 < 0:
        _dead_9807 = 717
    return total

def _ккβгЬАьΘΩВσуБ():
    value = 480606
    text = __import__('base64').b64decode('RkJnZmNHMDVMZzU4aVhhTlNNWTA=').decode('utf-8')
    if 100 * 15 < 0:
        _dead_1073 = 632
        pass
        pass
    total = value + len(text)
    return total

def _ЕΞЩНпоΗЬЗΖ():
    value = 52105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DS6zX1cO8oQ8GRuZn06ePCc83Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οзПδΑпΗΣδЫдЦ():
    value = 492625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LA3hOFAc1/AgADDxwnOlBiE9s0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νПэГиπψχгЪЖ():
    value = 728144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3zmVHdp+YorLVes8HWkYAw41nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЗΘТвΠΖуΓевφТ():
    if 66 * 40 < 0:
        pass
        21
    value = 763259
    text = __import__('base64').b64decode('d2xNVHYyS21Ja0lTSnBhaUZBYlM=').decode('utf-8')
    if False and True:
        _dead_3393 = 6
    total = value + len(text)
    return total

def _онβАζыГπΞмυψ():
    if False and True:
        780
        _dead_5518 = 744
        _dead_9036 = 993
    value = 582085
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyTeY2MW0qIxPTqCzGKcCxd49Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2659 = 39
        pass
    return total

def _ЕτДсУНξпбкч():
    value = 998448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDzcfQlrprkBaCO2226nHQM9vHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣΔЪΠХЪОкφθ():
    value = 333696
    if 50 * 65 < 0:
        909
    text = __import__('base64').b64decode('VWZLVnl0NG9rb3F0TEFpYlNjdUU=').decode('utf-8')
    total = value + len(text)
    return total

def _дЙЙΠЛоэд():
    value = 872379
    text = __import__('base64').b64decode('bElpeDZKN3RwUERFUU90Zk14cHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖкβЩмАΑЗзцеΙΝзСь():
    value = 105388
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgfcZFUY3JAXD1i3kWnBODc93E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΤчнкΥΑйьЪΑдΠΥМИ():
    value = 447791
    text = __import__('base64').b64decode('cGtUcE11c2FfbnNPWEV2SDJqU2I=').decode('utf-8')
    if len('') > 0:
        602
    total = value + len(text)
    if 89 * 66 < 0:
        _dead_7231 = 204
    return total

def _αКΙλСζъΝМξζОκмν():
    value = 886839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nze8OHox3bISDSyIyViiEzMA11c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зеЖβжЛЖψΣЕΗλΤεХ():
    value = 129734
    text = __import__('base64').b64decode('ZzlqdnBiZElRTlIydjN6YWxCUDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΩΩяΙРсгсоζОЛΞсЬ():
    value = 298595
    if len('') > 0:
        _dead_9307 = 138
        pass
    text = __import__('base64').b64decode('YlExMnVLQklDSXRCTkswaXU4OWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _шПΕΚπсυт():
    value = 450212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTfHY1oA/4I0Ihi25lKnOBo8/Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if 37 * 33 < 0:
        _dead_4804 = 738
        607
    return total

def _ηΡЪΑβБοΩМπ():
    if False and True:
        _dead_3794 = 52
        pass
    value = 684755
    text = __import__('base64').b64decode('dERXdGo3ZFFXdEY2TVhMRjdpcE0=').decode('utf-8')
    total = value + len(text)
    return total

def _λфЖоьПΣпΩСΤΖТΩγ():
    if False and True:
        _dead_9916 = 78
        867
        _dead_7050 = 893
    value = 973809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD3USFUe6PAsYga7wGagJwAZ/H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 5 * 18 < 0:
        _dead_8136 = 85
        459
    total = value + len(text)
    return total

def _ΓοΓМЧРσΙПЕУΡ():
    value = 787368
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSr8elkKrJAML1uwm1KEEAkH5U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗχьПЪΩЧЖ():
    value = 572116
    text = __import__('base64').b64decode('U0htM3VlMndTOEhuZ2RZUmRYX2E=').decode('utf-8')
    total = value + len(text)
    return total

def _бΟΓИсщΩΘыъЦэЪΛ():
    if False and True:
        792
        261
        pass
    value = 293763
    if 11 * 68 < 0:
        pass
        232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pze8b3k1yIoqGSWG+QTBE3Q26Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮрЭэΖЬДω():
    value = 74785
    if 54 * 66 < 0:
        pass
        pass
        89
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy7tSn1gxJEtLRz3z3DHYBoJ6Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 84 * 67 < 0:
        _dead_2760 = 264
    return total

def _ЗлιΞлαаΛЩН():
    value = 243101
    if 12 * 93 < 0:
        pass
        58
    text = __import__('base64').b64decode('V01CdFJwTG5uamFvSGVTcXdfRE8=').decode('utf-8')
    total = value + len(text)
    return total

def _влГφФΘНΨεΞΙЯЮ():
    value = 936951
    if 90 * 78 < 0:
        _dead_1945 = 623
        _dead_6971 = 15
    text = __import__('base64').b64decode('RFlEcHg4b084S2F5ckVxUVp6UzY=').decode('utf-8')
    total = value + len(text)
    if 99 * 77 < 0:
        651
    return total

def _рδΓЯσκТоМΜ():
    if False and True:
        438
    value = 74854
    if len('') > 0:
        _dead_1769 = 48
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwTKf3cO6oc2bhmNkUW7DXEqyDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξмУЧСХжЯΗОзЧп():
    value = 304882
    text = __import__('base64').b64decode('eHp1Z3dVd2xoRWZPcmVwR0xieE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖπНцкΟяΣуΓΠ():
    value = 411368
    text = __import__('base64').b64decode('RUxpenc1MDZ1d0dDejB3bmdhNUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ξНЪяаωТφцΘνιΘλб():
    if len('') > 0:
        300
        111
    value = 401666
    if 85 * 78 < 0:
        575
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwvoVmY9row1Owyg6n2pNxMAtjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыьжξΔсыЯΗΘЩεйЮб():
    value = 541648
    if len('') > 0:
        _dead_3270 = 364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EH7IW1gpq4wsOBiz+A6KHBQH108='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜщΝσζЦωЛШΞΥι():
    value = 586955
    text = __import__('base64').b64decode('SFdGYmFvaHRGQ2FxVkNTbTJXZ0w=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ЭфςΨМХγЦьτшξЗ():
    value = 756523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITvUZVdr2ZAqbDah+1eCbS093VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΦιсбЮФЮичΨяПηΨ():
    value = 77598
    text = __import__('base64').b64decode('U1lZY3pCMXBVWFhBazdUeDNWSHA=').decode('utf-8')
    if 35 * 3 < 0:
        _dead_5908 = 440
        pass
        415
    total = value + len(text)
    return total

def _чθУГмΡЙΗ():
    value = 777418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDzPO34e75kpCAmU+UzHZnc26U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _βяΡжζсΠξр():
    value = 936410
    text = __import__('base64').b64decode('RVZEQzZHNE9uZE1xZnJQQ0F6NWM=').decode('utf-8')
    total = value + len(text)
    if 97 * 38 < 0:
        577
        _dead_7315 = 389
    return total

def _ьЪхΩЬΞΥιмΞσυτΙаθ():
    value = 74833
    text = __import__('base64').b64decode('QU5sZl90U3hOejlpd3J0dUY3MGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮηкгеъШЕλ():
    if False and True:
        pass
        136
    value = 949718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzXwWUMGqrkJEzzw4FDEJDI892U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚЬΦйАπДΕ():
    value = 865318
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzvePH47qaIOGQKU93SFPCcJwGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МγбшшμκωΕкΒД():
    if 70 * 60 < 0:
        pass
    value = 813644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzXmV2M754oNBTmy7EO5IHd88Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 65 * 20 < 0:
        pass
        pass
        _dead_3701 = 334
    total = value + len(text)
    return total

def _σεьЖяуег():
    value = 251114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT68PFYI9awaYhex4X2AbA12zFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΗРωИЯоΟΡк():
    value = 818709
    text = __import__('base64').b64decode('dFF6Q2ZHcTNvRF9yMVlaME5BcE0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        765
        pass
    return total

def _фАβНГεъН():
    value = 504900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjzMVnIf6rI2GTuz5QWbAQQL7UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ргΓτДΞСсΜρφЕς():
    if 44 * 37 < 0:
        pass
    value = 594505
    text = __import__('base64').b64decode('dG91QjdNS2gxYmloTVQ4Sm5TOW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЗкψЗνосСν():
    value = 37810
    text = __import__('base64').b64decode('U0ZiX3M1MzhJWXBYaE5tcjZFNU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓσωЖьψву():
    value = 685108
    text = __import__('base64').b64decode('aW5scVZWOEhPU205ajVYaEw0aHg=').decode('utf-8')
    total = value + len(text)
    return total

def _оЕζθтςЫθΞьСУ():
    if 36 * 100 < 0:
        177
        857
        _dead_4925 = 133
    value = 331287
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('SmZualBXeVI5Z2tkQmFCb2Z2QVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜдεδβтΒДэΝИΑз():
    value = 795683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISncNnA+5qUhLzmk53nAGRx5tDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΣυъΜΝъшЖюш():
    if False and True:
        pass
        939
    value = 830119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxfIXnAp5vAvOFekwnC+ZxAQymY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 4 < 0:
        161
    total = value + len(text)
    if 12 * 72 < 0:
        pass
        pass
    return total

def _АнЯяЦγщΜБχρл():
    value = 350518
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDnNWERt2JctMxWUkGmHJgJ41F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΒЬуΚеЫΔКΙ():
    value = 289729
    if len('') > 0:
        528
    text = __import__('base64').b64decode('azVXR09aTzZYb0VyaHYxU1BEMEg=').decode('utf-8')
    if len('') > 0:
        521
        714
        _dead_4421 = 490
    total = value + len(text)
    return total

def _иВΤчИшΠЪζ():
    value = 887087
    if False and True:
        pass
        _dead_3894 = 410
    text = __import__('base64').b64decode('V2VmTFY0T05WaTlwRHo3N0xDQng=').decode('utf-8')
    if 13 * 12 < 0:
        401
        639
    total = value + len(text)
    if False and True:
        _dead_4618 = 313
    return total

def _вЧЙДЖтУшиωοЧ():
    value = 663337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXnHXXAX5JkgIyOnn12THhZ/8n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьωΘПБЛтΑΦяτцГиλ():
    value = 361299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3z0N2QvzrgQPxal93TEHh866kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ВАУΔыоρжийΒ():
    value = 199075
    text = __import__('base64').b64decode('TGhnQ0s3eURCOHZkM0FTSERoQk4=').decode('utf-8')
    if False and True:
        353
        _dead_4254 = 266
    total = value + len(text)
    if len('') > 0:
        _dead_9050 = 607
    return total

def _рШоΜгЙΚдПвЕ():
    value = 389028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FinrXnch56IqMCe7z0/JLXx3s3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛαыΓΛΔΛβ():
    value = 289992
    text = __import__('base64').b64decode('QVplc1R1M0pnRHAxdE51UkE3TjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪХΧаЛрЮдπеΙ():
    value = 275801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAPbSlUD7o9XbiKXkVC4OxUt8mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 41 < 0:
        600
    return total

def _οψηΛζЕВμл():
    value = 168337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHfsf18Qqo0CMwqN5luaPXJ290s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫκмжуΡΨαμ():
    if 56 * 27 < 0:
        290
        pass
        277
    value = 28660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAnoSQY/p4M0GAK64mLDIQ8Bt0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_9071 = 488
    return total

def _брвσСЭШΟАГ():
    value = 245503
    if 88 * 92 < 0:
        335
        _dead_6273 = 49
    text = __import__('base64').b64decode('dEszeDk1ckNqaWVlc3VPR2lLclY=').decode('utf-8')
    if len('') > 0:
        _dead_7315 = 77
        776
    total = value + len(text)
    return total

def _вΛΒНЪВРΡцΜ():
    value = 673845
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCrcd3Bp8ospES664FexO3I54nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 81 < 0:
        _dead_7258 = 270
        _dead_4990 = 869
        _dead_2089 = 870
    total = value + len(text)
    return total

def _ΘοΙΩПΛΦβ():
    value = 82754
    if 27 * 67 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxjsY0g624UzEAmHmluiDTIm6z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΒпЭωэГъΕΙι():
    value = 427276
    if 62 * 19 < 0:
        257
        923
    text = __import__('base64').b64decode('c3RVV1lRNUFLb0txZlpFVUZRenI=').decode('utf-8')
    total = value + len(text)
    return total

def _ФφГχρλнΝПΤα():
    value = 414091
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kyu9dwYL3KIPLh+ow3q9bAh7x2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЯОЦΑючυЛΒыΠτΕУ():
    value = 34111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwHsREIIp508HVqz6wS/Ynx9z3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 45 * 91 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()