#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _вνξωНηГз():
    value = 898992
    text = __import__('base64').b64decode('VGtRZ0xNWnV6cndvUjBERUJaTXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ддЩиΜΗГΨБΖθζΡюβ():
    value = 212352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj/bVGQU/KM1MiqIwUzAOQF6438='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фМςюЛЯДрдт():
    if False and True:
        220
        _dead_6938 = 878
        pass
    value = 315928
    text = __import__('base64').b64decode('eDNIWUNCeGtGc25LSGNqQnE4aW4=').decode('utf-8')
    total = value + len(text)
    if 81 * 38 < 0:
        pass
        _dead_6200 = 352
        _dead_9086 = 491
    return total

def _ρЧчηэАЫΞ():
    if 56 * 74 < 0:
        791
        _dead_9258 = 807
        pass
    value = 979006
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InazNgQS3adSah2Q8kPFOXEiwnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еεЫεцΓΒΦθΟΥНЪΗ():
    value = 69911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTzudHYa0IwmDT6pm3efBDwYz0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘчЧυЫΩаΚ():
    value = 887127
    text = __import__('base64').b64decode('QVliQzlnVkFJaU5PNV95Y1ZDZ0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЗΥΦσБНГМ():
    if False and True:
        309
        _dead_6175 = 693
    value = 228707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwbHN1A8q/kMIxmg8lOpYhMDszY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑψΦЪηΩъδνΓЬ():
    value = 451974
    text = __import__('base64').b64decode('TlllckJyaXNzalFKcHA0aGg1RGk=').decode('utf-8')
    total = value + len(text)
    return total

def _жΦΑΞЫΛΣдкЖ():
    value = 899227
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lzb1dH4d2p5UMVmnx3S1IDID52Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эАΧεяΡЕΗИζΒЬΔз():
    value = 880167
    text = __import__('base64').b64decode('dWhNcnFCZFdfSzBqaHBKdnQwdmI=').decode('utf-8')
    total = value + len(text)
    return total

def _ψъΨΑреЧΩβΞΧй():
    value = 150503
    text = __import__('base64').b64decode('SFpSUjJ2X2U1S2h5MVBkc1ZrVEY=').decode('utf-8')
    if False and True:
        pass
        296
        _dead_8276 = 66
    total = value + len(text)
    return total

def _βρчΙοКγγ():
    if False and True:
        506
        pass
        _dead_4000 = 261
    value = 509412
    if False and True:
        _dead_6699 = 623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwPiRUgbxJgFKDaF+3qlHnMrzj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΛнωЫαεΛνЯψС():
    value = 123613
    text = __import__('base64').b64decode('V3ZVMUFOZHk3ZEw4bmF5dWhrSGU=').decode('utf-8')
    total = value + len(text)
    return total

def _δГгЧЮΣфиφ():
    value = 846966
    if 4 * 74 < 0:
        246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3z0eFhgx4AGKTuR/EfFIDEj4n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 47 * 98 < 0:
        pass
        pass
        _dead_9596 = 853
    total = value + len(text)
    return total

def _ЯъОτЛшжПεΥΒМπ():
    if 11 * 95 < 0:
        _dead_8044 = 826
    value = 239816
    if False and True:
        pass
    text = __import__('base64').b64decode('UnZ1azdiTmJHaFFMMmZBOGtncWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΧκСΞβΓΖΛψωРЮ():
    value = 143759
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NynOSFoa2aEIGT7w7kTAGhct4l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔлορλГεУЗΔΒσз():
    if False and True:
        pass
    value = 834305
    text = __import__('base64').b64decode('THNYMHF0b3lqb2dTQkNRV0djYjM=').decode('utf-8')
    if 8 * 85 < 0:
        274
    total = value + len(text)
    return total

def _ЭΣЯΤъЩΔясйαΞ():
    value = 332055
    text = __import__('base64').b64decode('bFJPVkNTTnM1eGNMS2NwcGRxa1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЕАΛпьпξωБщэ():
    value = 577603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSDDQVYNpoYyLR6Z4nSYIHUJ4UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 87 < 0:
        pass
        _dead_4128 = 796
    total = value + len(text)
    if len('') > 0:
        831
    return total

def _ЧΝΣгЫЯЛЫЯзπмςн():
    value = 699331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHfeWEYfyo9TDwe15W+4Hx1+wz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        619
        pass
    total = value + len(text)
    return total

def _бхПβяЧЩνН():
    if 93 * 70 < 0:
        pass
        555
    value = 374962
    text = __import__('base64').b64decode('b2xmMDFxdHFoQU9fMHZQUjNIODA=').decode('utf-8')
    total = value + len(text)
    return total

def _ВвςΣжψщхТΣδ():
    value = 897634
    text = __import__('base64').b64decode('dUFHdXdTZ0tQMWo5bGJnUURQejc=').decode('utf-8')
    total = value + len(text)
    return total

def _πиюΦУΩΤгудθэΤ():
    value = 998787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx/HRwUex/oZLCKw8Wm9AHJ74mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φчΚЕΚχэЛυΡρСΨ():
    value = 51408
    text = __import__('base64').b64decode('SEtiSHBXNzh3WUozQVRlazVyY24=').decode('utf-8')
    total = value + len(text)
    return total

def _πвγυакξБψС():
    value = 421834
    text = __import__('base64').b64decode('eFdvaUFLMF95dGZ5SWRkbmE5OVU=').decode('utf-8')
    if 65 * 14 < 0:
        _dead_8460 = 588
    total = value + len(text)
    if len('') > 0:
        _dead_7615 = 292
        pass
        _dead_3259 = 767
    return total

def _μΟЖПбюιьΓΩ():
    value = 675212
    text = __import__('base64').b64decode('RjNOd0xSbkp6QWxEaFk0aVAwUkw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        899
    return total

def _ГΝΟгеΚθξΡμщ():
    value = 960157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MC3qe0I37Jc7MgaMxEGkJ30l/Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κКΜОΠНУБЙНΠΔЕЛ():
    value = 205122
    text = __import__('base64').b64decode('U1JzMTI3QUZXWnRqYXUySTRIUjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ρЕУΜωλЫЩВυч():
    value = 349156
    text = __import__('base64').b64decode('aXNWMWhVdnFJYjVGUm5LV29JMks=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8446 = 113
        _dead_1621 = 972
        _dead_4758 = 900
    return total

def _ТШрΤκΧШΥΒΡχыдοю():
    value = 462458
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CizldnQG6KkOAiWc+meHLQAYzkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2280 = 596
    total = value + len(text)
    if len('') > 0:
        934
        pass
    return total

def _πтиРψяββΛ():
    value = 529544
    text = __import__('base64').b64decode('WjVkTzU4WjgwRVRIUnVvYkYxXzg=').decode('utf-8')
    if False and True:
        823
        _dead_6891 = 478
    total = value + len(text)
    return total

def _ЗυЖювХчсЦ():
    value = 143711
    text = __import__('base64').b64decode('bTEwNGJWZ0NwMWNyMUx3VThKYks=').decode('utf-8')
    total = value + len(text)
    return total

def _мΝΙχΘγвБΗГΩ():
    value = 176644
    text = __import__('base64').b64decode('ZFhHMGhhZ2tGRlBUMENGWUFMR3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗφМЧΤзюШΦа():
    if 36 * 96 < 0:
        pass
    value = 67435
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Egy2ZkUYyoQbHTmynWKaGBc53lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 44 * 83 < 0:
        53
        283
        _dead_9698 = 178
    return total

def _μΗУΥξвПЩΙβЮТЗσβД():
    value = 902126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzfVYGEw35JXDz+y8FSDOgZ38Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХйφъцΛъПλΖ():
    value = 465641
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LivAXgQsrIIPMiSozlKdIwx5tUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 54 * 79 < 0:
        _dead_8417 = 345
        _dead_6916 = 320
        _dead_5653 = 990
    return total

def _ЬвΕгКЗвβЦЦЪξч():
    if len('') > 0:
        pass
        pass
    value = 460353
    text = __import__('base64').b64decode('dlJ3MGNlU2g3enU1ZjNvUXMzRF8=').decode('utf-8')
    if len('') > 0:
        _dead_5942 = 819
    total = value + len(text)
    if False and True:
        354
    return total

def _ЛиЛΚΕШУьЕХβт():
    value = 891250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRfzQnIc27wKYh6FwmalbQodxzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рКεлΦмΡДВΜОυщςт():
    if False and True:
        _dead_3079 = 264
    value = 346257
    if len('') > 0:
        _dead_7265 = 231
    text = __import__('base64').b64decode('eXlFdWJiQnQ5cUNKNkl4YjY5TnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ТдЗφНцфςТυтба():
    value = 215556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAWyPWEM8Y0BKVqMmUyzJC4iskw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πрμΣπμХЧΚад():
    value = 94223
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzjeQV1t3bwPGCSS32/INjYl/Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        244
        pass
    return total

def _иΦΓδΦгоШΑМп():
    value = 518038
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESOwYnIS7/k5ChWo7UW2GRE4x0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΙцΞΙΣτΟπ():
    value = 342779
    text = __import__('base64').b64decode('ckRTcnFmcDE1MW1nd1RWaXNlMU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ШИΛшΞΓΥцΣηιζ():
    value = 246175
    if 37 * 17 < 0:
        502
        _dead_8888 = 318
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjnbSQAyyJxSFBmVy3KWNQQV42Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕσяТрЦАфΘПИгзЧЧ():
    value = 299215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQ61YV0zwbgqEgO50g6RIyF81X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣοβХбγыУΒσΘтΡ():
    value = 889380
    if False and True:
        pass
        _dead_9702 = 845
        _dead_4930 = 463
    text = __import__('base64').b64decode('bFNlaUp6MmgyZEk1TjNSVm9nZjM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        372
        111
    return total

def _сβтχΠлбΔΖΧωφχ():
    value = 69775
    if 11 * 12 < 0:
        694
    text = __import__('base64').b64decode('TjFVVkxLV3Z4ZE1nekI3MlZaVnI=').decode('utf-8')
    total = value + len(text)
    return total

def _эΕвГцκНλпбθрХГ():
    value = 962490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDzGO2Uu6Lw0IC2u4WnCGXEk010='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦЮНπΞщПΣΙαΜМНксУ():
    if len('') > 0:
        _dead_1101 = 260
        524
    value = 14250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxXKRVs70oAgEjaCkWSvMCQu6n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςγЯπΡкΑпЭωВц():
    value = 328182
    text = __import__('base64').b64decode('RGRscG5vazBLS3ZsTWNjYVF6VXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЙΘψЙДЩΥρйΗГφξЮ():
    value = 251961
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDXKRUcX1aw7HTmX20+eYHUqy2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 40 < 0:
        pass
        _dead_6513 = 175
    total = value + len(text)
    return total

def _ςυμЦЭдφнλζΟςмУ():
    value = 260863
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDbRPns174EWKR+W6UK4EAp77j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τβЪщАбυγ():
    value = 469562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiDrbH5v+J8nPyuvzGmZYHQA8D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        36
        pass
    return total

def _ЩиФΑποВψщЮюЪс():
    value = 611668
    text = __import__('base64').b64decode('dGxnelJaVUhTa2VBS2hVcVBIT1E=').decode('utf-8')
    total = value + len(text)
    return total

def _щсθЩюγβГχ():
    value = 936520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyDlXX9r5LgpCVirw3zICxMk5no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыθΜУτЛΘХ():
    value = 85983
    text = __import__('base64').b64decode('VnlhQVhVdU1rM0NDNUQ5SE14QVY=').decode('utf-8')
    total = value + len(text)
    if 55 * 50 < 0:
        pass
    return total

def _гςΓψЩφЦΖХБΑЧχЮ():
    if False and True:
        _dead_4218 = 537
    value = 614710
    text = __import__('base64').b64decode('bWRyOVZKRHZ5Qm5NQm5yNEZYV2M=').decode('utf-8')
    total = value + len(text)
    return total

def _нαφяχчШКκΖЙВМΒК():
    if len('') > 0:
        pass
        pass
        pass
    value = 719677
    text = __import__('base64').b64decode('T3ZOQnNZTUhJQjE0RzR3NnVBYXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ζэщяКщΥΨВ():
    value = 281243
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('QzIwUzAxRHBwRzdCaVJVZGloZXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜеνСжакψЮΓШΟΖмсЦ():
    value = 894891
    if 41 * 86 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FADWV3UoyLw0aDy5/X+XJTIE5mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7161 = 808
    total = value + len(text)
    if False and True:
        pass
    return total

def _сΒΨΨЙчЫΟηΑШэεζцМ():
    value = 578672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwT3fX9ry4s1MyKcm1KaZCcJ/kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψξшΚΝΩбОзωβаГλΝ():
    value = 410236
    if len('') > 0:
        _dead_5469 = 298
        pass
    text = __import__('base64').b64decode('WTA0bmxNX3BBaDR0VWJ4Tk5NWko=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦχτΜЭΙαЮεαФьЭεш():
    value = 959433
    text = __import__('base64').b64decode('RFVyUERTdW1wemw3VHNRcDhzbDI=').decode('utf-8')
    total = value + len(text)
    return total

def _АΑφМоδшДωξУμйΕ():
    value = 211543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX3OOH4BqpFSKyynkHWjYQ0/xkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 97 < 0:
        118
    total = value + len(text)
    if len('') > 0:
        259
    return total

def _ХэΛЮыЫОюΖМСψ():
    if False and True:
        pass
        pass
    value = 200165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgLUZFMs6rI5IBq13Ua+GRcQ82s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИλцΙЬхЙμΧ():
    value = 437299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgfhYHkw0IIUEyCI63+DBgceyUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВмτПЬхοсГЛςЯкΔЕ():
    value = 579373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiTiVAARzYAUEySO/WS5NjB8s0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρжхЭМгЙΗΥЙКьΛыэΗ():
    value = 231123
    if False and True:
        pass
        pass
        44
    text = __import__('base64').b64decode('ZklWaEwyVlloenR3OUZpS3EzQWo=').decode('utf-8')
    if len('') > 0:
        _dead_7623 = 716
    total = value + len(text)
    return total

def _ЩчЩАеΨвΗлΧлЩνΕαш():
    value = 461250
    if False and True:
        244
        _dead_7387 = 817
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By7FVlU8768MPimh+WSRPTAk/kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 30 * 21 < 0:
        _dead_4297 = 421
        pass
    return total

def _ТТπтβςαыъ():
    value = 108142
    text = __import__('base64').b64decode('dFZYaUk2SVY4Y2J6SDcwN0lkQ3g=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _кΥнΛβοαΗλкСД():
    if len('') > 0:
        _dead_8283 = 573
    value = 867763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQrTYUAu9plUKzqQwU/ABxQV7UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        567
        879
        770
    total = value + len(text)
    return total

def _λфБκΛΝкγλМпΒРθ():
    value = 582926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgDXX3kdxPwFLjyE91WcJSYH700='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зζνжгхсДθКθ():
    value = 579078
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBnmPQEc2708ICmEwVS5bSodzzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θМΠчБΚηΨщШЩТΞд():
    value = 803592
    if len('') > 0:
        556
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IT/hP3cQ7aBRC1qpkWzAJ3Aj1Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        405
        _dead_9656 = 834
    total = value + len(text)
    return total

def _ΞЗθЗΖοдξоδρυЮ():
    if False and True:
        286
        pass
    value = 749211
    text = __import__('base64').b64decode('bVdGdzZMQVNaa29YZUhia2dqaVM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        525
    return total

def _зΔλΩψΒЕАфшΔрЕрГЫ():
    if False and True:
        pass
    value = 608303
    text = __import__('base64').b64decode('bG1rbFh5Smg4dUZqWFk5X2JCQm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬъЖΘξυτιΘΒЪшБ():
    value = 536450
    text = __import__('base64').b64decode('Wk1Oa0FuMDFiMU1UMU13Q0pKSHc=').decode('utf-8')
    total = value + len(text)
    return total

def _енΧюЕмЮХЮкΕИμС():
    value = 519083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyfiSksh5KQBbRWlyUbIFRcH2zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λпΒΝдσΡСλΦйζΒ():
    value = 73802
    if False and True:
        pass
    text = __import__('base64').b64decode('UTdHX0xZbENXRnQ5REFxWXNSVUU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7387 = 713
        pass
        489
    return total

def _ΨοφωυυцЬρТЕ():
    value = 915552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzbOQmsar4YJKQeT2ly8Gnc5wUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΥМδРЩωρВ():
    value = 643853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3+yRkA2xK42IAWa+l2fLCYK1Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЛЭτΛηιΟ():
    value = 6898
    if False and True:
        _dead_2911 = 802
    text = __import__('base64').b64decode('Rk9hZGVwQWZ2RE93Y1Q5emZZUEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪЩΚφνЖшЭЖцΛЧдЮΤ():
    value = 155375
    if len('') > 0:
        92
        _dead_2011 = 315
        pass
    text = __import__('base64').b64decode('WHBYbGkxR01hbG05cjlqSWx6WlU=').decode('utf-8')
    total = value + len(text)
    return total

def _уэγφЛшъш():
    value = 14037
    text = __import__('base64').b64decode('YUpIaEZlWWRpdk9seW1sRXFJVjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧθюЯΜпΩΖΘκКхшМ():
    value = 396327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHbPOmcX+5kXPx+x73+IAxIp6U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жαξςнЮюςξΤ():
    value = 165997
    text = __import__('base64').b64decode('c2c4NFQ2NW5ObGNsb0VMX3Rmclk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧадΦКκГμ():
    value = 788941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhzbV3Ms5KknAiCUnUOvYQsm13k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БъБΨμκкΔОΟΨΖоцчЪ():
    value = 936764
    if False and True:
        685
    text = __import__('base64').b64decode('YkQzSWJWUkZXV19pUVFSQVZnWHA=').decode('utf-8')
    total = value + len(text)
    return total

def _δыμυпκμЕАλДΙΕβ():
    value = 292062
    if len('') > 0:
        pass
        pass
        542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyDJQ2UYzrwpHCym53LEPgsb5Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7430 = 616
        173
        _dead_7229 = 6
    total = value + len(text)
    return total

def _фΔτлΙвАюРДφжππτа():
    value = 549337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjnhUWgD9/kaNAKU8ESDIgR590A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗьΡрγμΠΡφгυрΝуз():
    value = 840962
    text = __import__('base64').b64decode('T2ZFWHNRYXZLSG9hVVJJakZjUlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ιЦыνΠЦχдΥюэгφΞУР():
    value = 531176
    if 75 * 17 < 0:
        922
        677
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ij7zZH8h+4lUAguQ+U6hBB0oyVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1953 = 166
    return total

def _ΥμСθεМшΒюОνΩ():
    if False and True:
        _dead_1911 = 229
        35
        901
    value = 570467
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQu8eUgW+YACBQyC7liaJzwo6lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟπΑыΨШОЬ():
    if len('') > 0:
        pass
        pass
    value = 487328
    text = __import__('base64').b64decode('a3lUem1nWXQ5WkRBdTlrbV9nUmM=').decode('utf-8')
    if 9 * 31 < 0:
        473
    total = value + len(text)
    return total

def _нοйКВУγф():
    value = 593330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C33sVAQ/0pIpHBaL62OGOiwuxkg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕйдχΗеγоР():
    value = 116570
    text = __import__('base64').b64decode('WExvR0RXWnFMdmhfaEgzcnBCQlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΟэγцТЪβИВФицп():
    value = 696838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXb+Qkkqy/45AF6PmEeYBwEO8nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦКЫПвйρΛФгΚнΒЮ():
    value = 684875
    text = __import__('base64').b64decode('YlhoaDY1S3BhZjlLdEJjQmJtaG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨηηДςΗОчΜ():
    if len('') > 0:
        _dead_5676 = 743
        pass
        _dead_4527 = 209
    value = 160455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aneyawc4qP1WbyGomXOFJSgu914='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _νσОКεΣΜтΔΨι():
    value = 144449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRnzYUQKwbw5NV6c7Xi+Zy8p1Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        293
    total = value + len(text)
    return total

def _ЩρпΘЬШчΒхΦοΣΒшЭи():
    value = 734747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExbNd2IN24sPPzir8FmKJAArtGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗчьАдαΕσ():
    value = 791094
    if False and True:
        473
        _dead_8164 = 361
    text = __import__('base64').b64decode('WEp0djV5R0tzWEpQekNsd2V2Qlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΗяεФУτηνхΧξΡηфП():
    if 57 * 73 < 0:
        _dead_4995 = 951
    value = 529517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cne1SWRh2qUyIB2p2nybHCB681c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НЮЭΕНΡВПЩЫθО():
    value = 754202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzW1elVs6PgmbjigxH+6GSw1/Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рьвкьоЫΚДΟοЫςЖ():
    value = 927308
    text = __import__('base64').b64decode('eGp1T1RUUm80MEZCM2JtX040ZGI=').decode('utf-8')
    if 20 * 95 < 0:
        626
        pass
    total = value + len(text)
    if 9 * 77 < 0:
        _dead_7073 = 238
    return total

def _ΗБДЬЦΜΩΑΒΧЯзΔ():
    value = 903176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHrnNlwT3IwUNAeH5wWTMRd81Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΒЪЩκРВΦβд():
    if False and True:
        pass
    value = 368476
    if 26 * 98 < 0:
        pass
        _dead_8061 = 767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHmyTAk79ooOCzqV6QCyPC4d8V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΟЫДцΓςД():
    value = 173114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECLKbHcU6/1TED365k+RLC867lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 56 * 23 < 0:
        pass
    return total

def _ПяγоЛλοсΑ():
    value = 608524
    if False and True:
        _dead_3304 = 213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT7LQ0Ztqq0TGDW6mVi0Eiofz0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βыМЙддЬγαΝжйо():
    if len('') > 0:
        _dead_7263 = 828
    value = 760948
    text = __import__('base64').b64decode('YU50a3U5Z3NBbW9oZ1lNM2RUOFI=').decode('utf-8')
    if len('') > 0:
        983
        pass
    total = value + len(text)
    return total

def _эхΨЧВНбДФγ():
    value = 177369
    if False and True:
        _dead_2635 = 573
    text = __import__('base64').b64decode('ZVg5ZldoWTBRbGxBSzV4YlN4b28=').decode('utf-8')
    if 4 * 84 < 0:
        pass
        _dead_8355 = 109
    total = value + len(text)
    if len('') > 0:
        _dead_2275 = 523
        _dead_2955 = 393
    return total

def _мΘσγсСДЕмΡеρΥβО():
    if False and True:
        pass
        pass
        274
    value = 883431
    text = __import__('base64').b64decode('RkxDSWFCVWdJZ3R3dEN2Z1JrT2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЛЗικКυИεБ():
    value = 936730
    text = __import__('base64').b64decode('WEVmbWhSS1lvQjdMWV9aak52TW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ГтκцдТχСкπзММ():
    value = 605070
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M33dR2AO9/8vPSmL7H2HEX0HvUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фКσЪъΥΠБ():
    value = 156159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQPBN3Ma8L86Llu1+FCeJRo18jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цНИШвЧΤζдЪХпγКп():
    value = 646822
    if 47 * 86 < 0:
        _dead_7414 = 615
        297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH3VdEQO9/oILB+z+ESePRo5x2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦкЫεЮЭдЛΓЭ():
    value = 8274
    text = __import__('base64').b64decode('TFlsOUxWQlp3MTZ5Y3NyWkdaMUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓЫΕКμОΧντзν():
    value = 3375
    text = __import__('base64').b64decode('U3RNM21qaFpRNGxtVlpUZmZ5YlY=').decode('utf-8')
    total = value + len(text)
    if 90 * 31 < 0:
        pass
    return total

def _ρАуλЙОЧο():
    if len('') > 0:
        pass
        pass
        514
    value = 356457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiLcQggs7L0UPwOr7WS2IC4i3Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 18 * 1 < 0:
        _dead_4455 = 113
        pass
    total = value + len(text)
    return total

def _ЮΠэδеХЧцЯΔЕφ():
    value = 702192
    text = __import__('base64').b64decode('UUZUVW1oN0lXMDJiSGw0VXo2ekU=').decode('utf-8')
    total = value + len(text)
    if 47 * 64 < 0:
        _dead_6374 = 370
    return total

def _РιпДиΔФΙΧ():
    value = 679568
    if len('') > 0:
        901
        620
        838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiWzYkMSqo0mbw2022HHPAR+tlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 86 * 10 < 0:
        _dead_9801 = 889
        pass
        pass
    return total

def _ВΚщιεεпТη():
    value = 30032
    text = __import__('base64').b64decode('SGY2aUJPRWRaMUhJeldIdVBrM1M=').decode('utf-8')
    total = value + len(text)
    return total

def _υΙкΘызЧισθхмς():
    value = 651923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQXXe24OyokAKj37ywOBOhwus1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωηрωδмαЕдЦςκρυ():
    value = 705075
    text = __import__('base64').b64decode('dllJRmVGaF9sRVB2SWxFeHhyTzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛВТμΘдλлКс():
    value = 191873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTb+bVAM1Y03MBem+3SWJh0gwG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъсвΧЕψУсТμФρυο():
    value = 683111
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('dncweGpTNnR6bkJhNW9WUWZ5cXg=').decode('utf-8')
    if len('') > 0:
        146
        32
        _dead_9306 = 401
    total = value + len(text)
    return total

def _ΦьеЬщπУξοЙτХδВ():
    value = 272439
    if False and True:
        pass
        _dead_6825 = 334
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3f1O38J96NXHg2Q8lqfOhUn1Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШАмρцθΘвжэМчЬан():
    value = 637637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwTKdEINp5hWCVaXnGe1bRwn9To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        404
    total = value + len(text)
    return total

def _ΙшηрмцπцοЩΓΧл():
    value = 214478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSzrPWJg0b5UMD+0nlCXInIox14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΒσЛΚЩдК():
    value = 708054
    text = __import__('base64').b64decode('Qk90cG9Ydno4UlljazZXZXFfbnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨβνцКΦεТкιрИρЧЧц():
    value = 719185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwHXOwVvwbEAAB+W0GKyYRN+6D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дνθрΡςκσςМ():
    value = 156893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DznyRXRq6PpTaAaB50/CBzAD00A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 68 * 20 < 0:
        663
        _dead_9849 = 78
    return total

def _утοШдκУΛΒцЕΣдΒЫБ():
    if False and True:
        704
        218
        _dead_9458 = 825
    value = 706935
    if 86 * 42 < 0:
        pass
    text = __import__('base64').b64decode('aDFnTG1QTGtoRGtxU2pUam5PcFk=').decode('utf-8')
    if len('') > 0:
        292
    total = value + len(text)
    if False and True:
        pass
        785
        _dead_9990 = 727
    return total

def _мΟяηΘгрχσ():
    value = 692811
    if 55 * 43 < 0:
        399
        _dead_8504 = 897
        990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBXxfHZvyrggCAivmVKaYXEGz1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙЖВэШхΤцьф():
    value = 577358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwrbP1s/85gNFDCvwAfFNyE+3W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΜΓΡΣηСΑЯЫΙςКд():
    if False and True:
        _dead_7983 = 319
    value = 404651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwfhNmga2Ys2IBaQ92aeEnE/7EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕБьπхйЕκп():
    value = 511557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSfTOkIv/LslFSGA5FqRJSI4/Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψχβτφβθΚμШшωЮΧτ():
    value = 114238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgvteAQhx6o7N1yL42XBEhwn7zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΔορЖΡмΘСЕ():
    if 75 * 6 < 0:
        898
        pass
    value = 947711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dz/oeVYuzbxWHBaQ4n2RGQJ24k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΡюСвΔψуδЛГП():
    if 56 * 90 < 0:
        199
        _dead_4006 = 413
    value = 989720
    if False and True:
        pass
        _dead_6569 = 620
    text = __import__('base64').b64decode('WkRtdUt3cmljTjBRVkpXQmdueWk=').decode('utf-8')
    if 39 * 24 < 0:
        476
        479
    total = value + len(text)
    return total

def _ЧЗΣшбςξωЙУ():
    value = 871045
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDrATHkO8Z0THieg506EDjB4/Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΕммΧΧхЬчηюжФ():
    value = 84384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhXqYXw0+qY6Oxmm/2mEYgAB71Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _соГяелфТηТзНЪтΤ():
    value = 386313
    text = __import__('base64').b64decode('SktHYlVZZFk4SFd6ekJjcXdxVWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _еЖхНΗЩфй():
    value = 895266
    text = __import__('base64').b64decode('YU55TXpYYnRzQTA2dmlnR0lENmo=').decode('utf-8')
    total = value + len(text)
    return total

def _τЦМΜыΝФΧρΞЖЗζцтΟ():
    value = 48074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACzxfgMP67hXCgutn32TMBAE0Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АВГЮЭЫΛПΞД():
    if 36 * 4 < 0:
        pass
    value = 960481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhzyNkQN7/oMHzyG2VGlDC0W91k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 11 * 5 < 0:
        _dead_5268 = 598
    total = value + len(text)
    if 69 * 62 < 0:
        pass
    return total

def _МθшОиСоЫеЮБΘнз():
    if False and True:
        _dead_2922 = 378
        558
    value = 563980
    text = __import__('base64').b64decode('SEVoNDhHNk9pYWdDTzA1WVhqdjM=').decode('utf-8')
    total = value + len(text)
    if 27 * 55 < 0:
        pass
        _dead_5645 = 320
        _dead_4908 = 209
    return total

def _ЪΟΜнВΘηΗЮЙц():
    if len('') > 0:
        _dead_3071 = 0
    value = 715557
    if 35 * 85 < 0:
        _dead_1789 = 541
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSvPPFkXz/sWDy2i3nS1InR2vEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        438
        _dead_1525 = 40
    return total

def _ΠΟЛΝнлоοя():
    value = 566677
    if len('') > 0:
        pass
        827
        _dead_9529 = 675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwLCdEcQp/klKzqJ53iCPQY97nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πхΣΜыЪεц():
    if False and True:
        pass
        pass
        pass
    value = 671696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT/XZ2E49Z9bEgeE7nyRZTR+/jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кяοιщИωБЯа():
    value = 519250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn+0T1Ug2vsULCHx+A+GMjwAwlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИфΟΘοςξωВК():
    if False and True:
        184
        51
        pass
    value = 621737
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('bGY2Y3BaRHNtd2xreFI1SzNGcFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ОМжχСхчδакЫιСкΟ():
    value = 287313
    if 90 * 90 < 0:
        _dead_1622 = 397
    text = __import__('base64').b64decode('dXdsaW5SRFBGVUZScWlIN3l5YWI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7364 = 149
    return total

def _пσαοкыιφησΟ():
    value = 228294
    text = __import__('base64').b64decode('cTU3UnlqWEV0QTVWbFhoclc3VEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬОΧСУβΡЗВУΘ():
    value = 430190
    text = __import__('base64').b64decode('alJzUVJBYWxGRTd1d2xsZkdqenM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΦТΓИωкΘмθ():
    if len('') > 0:
        pass
    value = 672872
    text = __import__('base64').b64decode('cnVFMkVVRWE4NFZYM1ZhMGxESUI=').decode('utf-8')
    total = value + len(text)
    return total

def _дαчλλшпИщю():
    value = 513604
    text = __import__('base64').b64decode('SG9ZZGhadEw2ekFOVk1qcjc5NDM=').decode('utf-8')
    if len('') > 0:
        _dead_2249 = 733
    total = value + len(text)
    if len('') > 0:
        _dead_4155 = 251
    return total

def _ЪАδРпуσΚщπ():
    value = 486368
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQm0aAcyqaYlAAa5n3u0EnQL02Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЯиЩАшЭаψρЭндй():
    value = 903710
    text = __import__('base64').b64decode('VVNfMWUzQk5IRXpreFZlQ0k0dWM=').decode('utf-8')
    total = value + len(text)
    return total

def _еσωыЭААΥΤЗСЯ():
    if 40 * 53 < 0:
        _dead_2726 = 240
    value = 86101
    text = __import__('base64').b64decode('c3RpMUdiSkZiVW1NUWVnOTFhUmE=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_5021 = 785
    total = value + len(text)
    return total

def _НзМΞωΑЗυφцМ():
    value = 157393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBrBRnsjqpImax274Fq8YXQ39H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЧαиθъεΞСдφшП():
    value = 118801
    text = __import__('base64').b64decode('czNYRkZmMWZucWs4RXdYQWxfTFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ηэХПтωςΔлКНкβ():
    value = 991645
    text = __import__('base64').b64decode('SmJzckxNbHdwVFE1SzlWc1cwNTM=').decode('utf-8')
    total = value + len(text)
    return total

def _БЭΩτнιμЦ():
    value = 552568
    text = __import__('base64').b64decode('QVQzRG1QYk5BZkU2QkNOd1Qwa0s=').decode('utf-8')
    total = value + len(text)
    if False and True:
        508
        pass
        448
    return total

def _ΨρψДΨΨΕΕОπΟφ():
    value = 423379
    if len('') > 0:
        pass
        67
        345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MibsamEb844rDQuB+3+nHQMh0Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯВцыеγΓЕΩЯРЗуΣ():
    value = 548813
    text = __import__('base64').b64decode('VGpWcHZjejFkUVhZRVN5SmV6UTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥХЗРЬПчУξыΥКζс():
    if len('') > 0:
        936
    value = 136804
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyjpWwJv8PoLEwKPygKTZgoWskw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΕоΚХЦαΓγΤΡЗ():
    value = 386071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3z9OFQT1qcrayTw8W+/PgQG614='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 11 * 27 < 0:
        pass
        _dead_7889 = 792
        282
    return total

def _УτЬоξΓοχашЩαсα():
    value = 416266
    text = __import__('base64').b64decode('TkllQjV2eGVXRV9sY1NUODlNMzA=').decode('utf-8')
    total = value + len(text)
    return total

def _юψεβдИЪΖς():
    value = 642793
    text = __import__('base64').b64decode('djRQelRUMm1nYlcyektSQjZ3UTg=').decode('utf-8')
    total = value + len(text)
    return total

def _эяθЯмеΑΟф():
    if False and True:
        451
        573
    value = 798344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ihn0P3M78aooNya7m2HCbX1+sDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яφШыиΨςΞΔиВΤφЛτ():
    value = 665260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT29OWVp/KIxGQm6+FOBNiE64ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШБкδЛνзΔβςςмρςЬ():
    value = 779996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgjVd2gOqZonAx23+UybYAgMsEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σцюФЦпΘВивρЛЬ():
    if False and True:
        pass
        _dead_7321 = 318
    value = 602660
    text = __import__('base64').b64decode('R0Mxc0xXWENZaV9zQXVKV1JKbTY=').decode('utf-8')
    if False and True:
        904
    total = value + len(text)
    return total

def _гьΒЬыачΗРРκΥ():
    if False and True:
        _dead_8152 = 573
    value = 131884
    text = __import__('base64').b64decode('d09ENG5LbVlfM1lYazdQMTFYRXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓуйеаεсМРКμφтСςш():
    if len('') > 0:
        740
        pass
    value = 403977
    if 10 * 56 < 0:
        343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NA3lZl4rzZgpLTiB2lmBNh0h4jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СψпзмДдВ():
    value = 421399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSa2S3QezZIHHxmx3mOiBDIZt2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖАЫπшпΔНПΠУνЬВш():
    value = 178621
    text = __import__('base64').b64decode('RVFfUV9HSkVmNTBfSnZrNTk0Nzk=').decode('utf-8')
    total = value + len(text)
    return total

def _θцФλΛγчВθ():
    value = 454827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxbTVAAr5LsAaBm38G+gAwcls1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘъΠΩΙьоΘЗьΦυς():
    value = 882077
    text = __import__('base64').b64decode('R2tHSElnWmswa2lPOFhSbXBtR3o=').decode('utf-8')
    total = value + len(text)
    return total

def _йΘЩμξМШαпГΝΑΤ():
    value = 992170
    if 94 * 12 < 0:
        pass
    text = __import__('base64').b64decode('bzBEcHF5d25pcFB3b1BmZERqT0s=').decode('utf-8')
    if False and True:
        925
    total = value + len(text)
    return total

def _ζоШζАжАкТΘЕэΚюХπ():
    value = 582156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzryfEcRyq4ZCgbyykHHJyoO6EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 38 * 84 < 0:
        20
        784
    total = value + len(text)
    return total

def _τΞΥЧΒЬщнгйΗЛзΥψЬ():
    value = 776393
    text = __import__('base64').b64decode('dHBCYkxPaW80MzFydWZnWEhiY1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩШЮЙΚεпмΔС():
    value = 847963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAPsRXJv0YEoGyiqxAeUMgI4wlc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤшφВΑЮйыρΤЧРЯοФ():
    value = 197887
    if len('') > 0:
        pass
        _dead_7485 = 556
        327
    text = __import__('base64').b64decode('aG9sQzU3QjVOV0NPZ29wSUhsN2U=').decode('utf-8')
    total = value + len(text)
    if 59 * 17 < 0:
        _dead_9361 = 466
        41
        pass
    return total

def _ЗξξζяМГМЙνОΞ():
    value = 255603
    text = __import__('base64').b64decode('VUJOMWFUUXlzSHh0SEhCOUJLWlI=').decode('utf-8')
    total = value + len(text)
    return total

def _βζΔκУлРδюςЫфμйС():
    value = 367247
    if len('') > 0:
        _dead_2850 = 50
        943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EArgZ2EBp4c1Dwiwx3jDIwAk434='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фнфщбΤνΤсЦСΖκаЗ():
    value = 589345
    if False and True:
        87
        _dead_9747 = 865
        668
    text = __import__('base64').b64decode('WUFLZ3lIR2hrSTVOVGlJZE80d2g=').decode('utf-8')
    total = value + len(text)
    return total

def _бΕηЙΗБДχ():
    value = 186367
    text = __import__('base64').b64decode('cVNEZDI4V3Q0djZmOFJVcVVodk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΜэΟΙΧКХΩΨιИ():
    value = 226798
    text = __import__('base64').b64decode('U2tzVTN0QXZhVGxFakZlN2tJT0M=').decode('utf-8')
    total = value + len(text)
    return total

def _θЫзЦΖδюЩьθсΘκ():
    if False and True:
        pass
        pass
    value = 455371
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERXTaUMs5o45NSma31jBEB8pwTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8929 = 380
        pass
        561
    total = value + len(text)
    if len('') > 0:
        _dead_4125 = 325
        48
        _dead_7755 = 493
    return total

def _ЫПσΘΨЯМЛΣЩ():
    value = 810314
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAvGPlQr6YAUNSGa5V+FNhEJ5Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 48 * 78 < 0:
        _dead_1512 = 282
        229
        _dead_2191 = 663
    return total

def _ΜЯПЕДΠζΟΟЬΛ():
    value = 733226
    text = __import__('base64').b64decode('QkZvaDhFNGVEUmFZZGVFX0VEVHo=').decode('utf-8')
    total = value + len(text)
    return total

def _βΠτΧгκХΗΛтхдрМ():
    if False and True:
        pass
    value = 482099
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACn2ZUUX35goO1qr/AaAbHAe8Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ЕкΩЩφτйΚфъν():
    value = 18256
    text = __import__('base64').b64decode('bnkzNlZzblhHSVVZV2xmNGppT1I=').decode('utf-8')
    total = value + len(text)
    return total

def _МΤЗαкφЮТιш():
    value = 854068
    text = __import__('base64').b64decode('V2tUZmtLX21FNGl2WDFuX1REc2M=').decode('utf-8')
    if False and True:
        _dead_5348 = 637
        314
        462
    total = value + len(text)
    return total

def _ЧαЦПТЬΑхНЬ():
    value = 220728
    text = __import__('base64').b64decode('bUJzTVZDclp0XzhWWXN0SHh1bnc=').decode('utf-8')
    total = value + len(text)
    return total

def _βΖкπζзιΠΩΚПηλлсΛ():
    if False and True:
        754
        259
    value = 191883
    text = __import__('base64').b64decode('eE9KRkg4WU9uaHFIdWU1VTNpOUs=').decode('utf-8')
    if 90 * 60 < 0:
        _dead_4421 = 738
    total = value + len(text)
    return total

def _εАηяХΥЭμЫ():
    value = 827044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Knbya1gGqJsULleOymazIAAZtj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЦΞсΒτΕГν():
    value = 671385
    if len('') > 0:
        pass
        872
    text = __import__('base64').b64decode('ZFp4S2NTY3BEOGdrMF81X3NsSWY=').decode('utf-8')
    total = value + len(text)
    return total

def _шαΤνΤЩβчЩмΘЭЫυ():
    value = 258082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABjMN39tz7IlHAeEwQOUOCksymc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔИαΓШΣζΤЬАЦЫυш():
    value = 603975
    text = __import__('base64').b64decode('RVhkMXBXZGVGbE5BZDhfSzR6RXo=').decode('utf-8')
    total = value + len(text)
    return total

def _щΑМΝΟΚςжαΕΥъДυв():
    value = 908513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mjz1PGdg6oA0PlyMmkK7ABI8w0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΛилФοяаСДиИшΤ():
    value = 896085
    text = __import__('base64').b64decode('S3c5blR4Rkl5UW9HSWpqWHhoT0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ПωνчЙοеΘлα():
    value = 278156
    text = __import__('base64').b64decode('ZHllZlNRczdHSUdqVXlXNGtsakU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛзΙЗΑтВЦлΩμЫΞΜ():
    value = 405232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB7sVm4q8/gGMgG6kW6IEwAh7zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 40 < 0:
        661
        993
    total = value + len(text)
    return total

def _оЧρыΓχΟχк():
    value = 157516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzngTAAX6pAmOSSl3QLFLRM74jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()