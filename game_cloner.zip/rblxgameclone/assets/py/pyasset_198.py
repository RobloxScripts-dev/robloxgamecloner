#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ЮЩЗσΡлнфΟНЪыιТ():
    value = 642936
    text = __import__('base64').b64decode('dXk3RUpSTEVNY3EzMmI3eWxOOGo=').decode('utf-8')
    total = value + len(text)
    return total

def _чвμΥЬЕТΖεРЧξлл():
    value = 667086
    text = __import__('base64').b64decode('amtzSEw5T3lfNUNLSmlnYXhZYUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΔνπΛχзτΕ():
    value = 916043
    text = __import__('base64').b64decode('ZWY2bUpQN1RUaFVCdXlVTHQwbnA=').decode('utf-8')
    if False and True:
        pass
        214
    total = value + len(text)
    return total

def _ΓХФΞσхσУν():
    value = 655883
    text = __import__('base64').b64decode('WVFIeVhacUVWbGZ2b251N0tzazk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧШДДцθзХщ():
    value = 348714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwTRXXUt+7sxGBiQ4HzIE3Am0Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΕΝЮЪЗμаΖ():
    value = 141131
    text = __import__('base64').b64decode('Wk92Z2dQdHJ6T1J0WlBOWTByRVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ςыоОΑηЦчКμΧηнИП():
    value = 985945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kg7SVggh048MHxeowwSZEzN7/nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жХЖсвВΑЙчщвκС():
    value = 673388
    text = __import__('base64').b64decode('eG5NTEhzUnJ4S1pKcm1TYXdEb2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝРΑпΩРьБγФз():
    value = 202581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDrtRmAjypIlDw6H7F+BDXQBz20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧцζМсЮχДъцΝЛκД():
    value = 314123
    if False and True:
        _dead_2975 = 488
        _dead_3329 = 280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg7MOlBg/LJVOQTzy1GANTIex18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    if 71 * 36 < 0:
        626
        pass
        116
    return total

def _ΗЧЗбБйыψЗУ():
    value = 950792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwX0aUch+6YJGRexwAe2LSM/9Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        195
    return total

def _тΦоΞЖфοЩшЭςγЫ():
    value = 194818
    text = __import__('base64').b64decode('SHZ2R1NIUUtkblpEVGZwOVFOTG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩтНςφпκρЮч():
    value = 647756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwbgRwcgr5FUDSj00U6zCxUI3mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рРδυбΗωγжΥ():
    if len('') > 0:
        _dead_5417 = 808
    value = 813499
    text = __import__('base64').b64decode('RVBieEFFSDdhNncxQm5BTXU2M2I=').decode('utf-8')
    if 1 * 27 < 0:
        _dead_8925 = 964
        942
        _dead_6409 = 568
    total = value + len(text)
    if False and True:
        _dead_3903 = 581
    return total

def _ПзοχУЕхζΖ():
    value = 103339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH6yQXgv3IMuAg6CnU+RDg0sszw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωФдΤАυΚчΗЬ():
    value = 561371
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS6zdHwp150pKQyhzGelPgMY8l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 95 < 0:
        pass
        _dead_2692 = 117
        pass
    total = value + len(text)
    return total

def _жπΦрπλъΖΓχфы():
    value = 655071
    text = __import__('base64').b64decode('V2U5NU9uVTB1WEwzMnhhVTNqaG8=').decode('utf-8')
    total = value + len(text)
    return total

def _χΑζκΕξФйИσΛλψУΓ():
    value = 354195
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX3hbGg68IQwaV6X40WTPC0f6Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кψξдВιДβщΡΦ():
    if 67 * 47 < 0:
        pass
    value = 397117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH7JNkRg3fsANw6oxkHDYgEd6Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛчеμБΠЗЯЗυьМпчεй():
    if False and True:
        712
    value = 872993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzrXeWkb24IBLx6m71PAEXcJ8js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йхОСφуςΝ():
    if len('') > 0:
        912
    value = 515765
    text = __import__('base64').b64decode('dTRZQ3JEQUt1Q05TalNXeWY5UVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ηБЮЛθоψΨуБΚ():
    value = 756584
    text = __import__('base64').b64decode('Y1J6TUpudzY5Mkh4WEduRkRQVE0=').decode('utf-8')
    total = value + len(text)
    return total

def _яятκГЙЮлεУ():
    if 72 * 93 < 0:
        _dead_8601 = 688
        152
    value = 612329
    if len('') > 0:
        964
        299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHiyS2Zv3JwiYg2skGWfGB8s9Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΙΨΝНэЬΦΜцΣЬ():
    if 100 * 50 < 0:
        42
        pass
        _dead_4553 = 990
    value = 606731
    text = __import__('base64').b64decode('V0lCeUZiSUh3eDhhUXpCeWFlWjA=').decode('utf-8')
    if 58 * 54 < 0:
        495
        50
        _dead_7789 = 879
    total = value + len(text)
    return total

def _чмΟλфΟηΟШΨμΩП():
    value = 153646
    if 82 * 25 < 0:
        875
        _dead_4499 = 757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQHJRnUs0IkEFlqNmUS9H3Al5mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оАΙΥχλзζцжΩλ():
    if 74 * 12 < 0:
        859
        _dead_9531 = 97
        pass
    value = 551815
    if len('') > 0:
        pass
        884
    text = __import__('base64').b64decode('ZGVYY0ZXcUtRMU90ZzBTd1J6M0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟАΕνΘгфΒАтЙХΛΓρ():
    value = 938045
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICvMd1ARzPlbAhqV73WSGwYB7kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АядыЕдЗπΥ():
    value = 671872
    text = __import__('base64').b64decode('cmdhR05wbjl3bjRFb0J4N3d5dnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΜΓЙηΜξМιεΗςоь():
    value = 825316
    text = __import__('base64').b64decode('c1NTU1NvSWE4RUZxS0pydXpzNTY=').decode('utf-8')
    total = value + len(text)
    return total

def _κЧЪБσаыΟεуΓ():
    value = 291419
    text = __import__('base64').b64decode('ZWQ3eWo1bGlKYmdMMF9Ld0loWVk=').decode('utf-8')
    if False and True:
        920
    total = value + len(text)
    return total

def _βЩЮσуЭНδАΙΩτЪх():
    value = 493340
    text = __import__('base64').b64decode('bDROQUZacGdqdVptZ0o3NWZKMVU=').decode('utf-8')
    total = value + len(text)
    return total

def _юмΕΤΤλΝрЪ():
    if 31 * 58 < 0:
        _dead_6744 = 763
        301
    value = 375462
    text = __import__('base64').b64decode('RUtmTjV1VXF2Nmw4VnJyQVBPWlg=').decode('utf-8')
    if 77 * 99 < 0:
        _dead_7530 = 125
        pass
        _dead_4517 = 335
    total = value + len(text)
    return total

def _ЭΧМγФΟУηЬЧΙλρΘν():
    if 92 * 77 < 0:
        479
    value = 99423
    if 99 * 43 < 0:
        _dead_9891 = 494
        3
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTW8TUg9xKc6Izyh3GWcOzN96G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 5 * 2 < 0:
        _dead_6249 = 724
    return total

def _УΦЫЫЦΓзΦЫ():
    value = 554912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dgy3f25o+P4tHliu0nKoODUG/Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ερХиπЯяюΟΙαтΜМй():
    if False and True:
        _dead_1200 = 899
        112
    value = 84860
    text = __import__('base64').b64decode('aUNnd1dBZUd1WlVSSlkzU09OcEg=').decode('utf-8')
    total = value + len(text)
    return total

def _чΠыτφЪΜΙмΙΓ():
    if False and True:
        _dead_9253 = 778
    value = 693204
    text = __import__('base64').b64decode('dHpGZll3cVdOZTVLVzRmOGVHUHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭЗфйТφхеΓ():
    value = 204595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXnjRUkx8awwFV2i7HqcJnEr7Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 47 < 0:
        701
    total = value + len(text)
    return total

def _бЯФИθδкы():
    value = 620652
    text = __import__('base64').b64decode('c0o3UHIyeDBhbjk2YTJYSzdsZGY=').decode('utf-8')
    total = value + len(text)
    return total

def _φχυυФиСАИБмοшсΧι():
    value = 964030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH/1OHg7xps6HAShxU++bSkO4ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΗχεоιΟυаΩ():
    value = 512961
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTngZHMS/K8sPjqN2G6EZiQo20I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 51 < 0:
        951
        pass
        800
    total = value + len(text)
    return total

def _ΔΗГиДыЖрψχΞЙгИ():
    value = 380439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDqzVmEL6q9VbDCsmVHCEgQj/lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 54 * 15 < 0:
        198
        pass
        _dead_7122 = 415
    total = value + len(text)
    return total

def _тжμтоЦεОυΖзΘΒШГ():
    value = 810344
    if len('') > 0:
        177
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxvRZkkT1KcNbh27mkOaDjwF6z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7104 = 559
        _dead_3780 = 47
        _dead_2867 = 65
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3954 = 271
        80
    return total

def _ЛηЯΦяδшμЭйμζς():
    value = 616504
    text = __import__('base64').b64decode('WW1pSDRWSkkyYlh2d2phSElqNG0=').decode('utf-8')
    if False and True:
        _dead_8021 = 853
        662
    total = value + len(text)
    return total

def _цЫЛСЩπΖКχΙ():
    if len('') > 0:
        85
    value = 821675
    if 91 * 92 < 0:
        605
        _dead_7858 = 167
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXfFQ14OqIoMMyOtkQacJXEQ0j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АιъИΕхΟιоΜеоΒГ():
    if 49 * 72 < 0:
        101
        pass
    value = 512961
    text = __import__('base64').b64decode('aGYzNjlVbnlUUW1nM1BXbEY2WjI=').decode('utf-8')
    total = value + len(text)
    return total

def _хгΦΜзΗμЗЖШюф():
    if 14 * 42 < 0:
        pass
    value = 358105
    text = __import__('base64').b64decode('SmtvaVNnZDFzcTNUcWlPOFhfN0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЩжοплНΡзЛДПеФ():
    value = 379859
    text = __import__('base64').b64decode('Y19vekpIOUd5aG9HR0lZdmxyQ3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓβΜΖτΧмОΝζΟСкЧЕъ():
    value = 931833
    text = __import__('base64').b64decode('ckpoQTBZT1FGNmd2enc1VFpIY1g=').decode('utf-8')
    if len('') > 0:
        508
        _dead_9934 = 621
        pass
    total = value + len(text)
    if False and True:
        611
    return total

def _ΦψΝςΖΠЮхщσΧχ():
    value = 927990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An/GQgA7/aQ5Exu5znKoBBAd90E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЮОБыБφОβαΚсшАω():
    value = 695341
    if False and True:
        pass
        _dead_9809 = 913
        pass
    text = __import__('base64').b64decode('UjBYUGVLbWc5UHhpTVQ2MDBoR1I=').decode('utf-8')
    if False and True:
        pass
        681
        pass
    total = value + len(text)
    return total

def _μчΩЭΨцЮШОэИ():
    value = 255927
    text = __import__('base64').b64decode('T0VLVVY2eTdHNWUyc2FJNV9xQ2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ДкЬδиВαьСη():
    value = 889602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyjSPHc8y78mBSKp+k+hOgI21kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮЧпχΞКΖβСЭηεпеЖ():
    value = 205418
    text = __import__('base64').b64decode('Sk9fRWtJQ1lKYUdham8wUlFPQ0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΗзбтπφΤЗДΛμа():
    if False and True:
        160
        _dead_9285 = 829
    value = 947344
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyPhTWQg2rA8Axf7+V+/FXcE1GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 59 < 0:
        pass
        _dead_8305 = 879
        pass
    total = value + len(text)
    return total

def _ъσГκЩΧчζлОΒΨ():
    value = 69899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQvHSWMs9KITKS602mSvLgI9/T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 15 * 13 < 0:
        290
        384
    total = value + len(text)
    if False and True:
        _dead_6359 = 578
    return total

def _ΖΝσЬжнЭЦωЯΛь():
    value = 810168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3vHV2gBzJsTPgqW4lyHBAMnzzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2254 = 331
    return total

def _жВЬψξЧФЮБγЯббВΗ():
    value = 215674
    if 100 * 86 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyDpRGkW67AIYi21xWmFYS0ryW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηмΑЭΖΠΡзЩΩΔ():
    value = 503974
    text = __import__('base64').b64decode('RzJZc3o3ODN0d1RsRUdpa1I4QXA=').decode('utf-8')
    if 36 * 18 < 0:
        pass
    total = value + len(text)
    return total

def _ΨηπьπшйпНЧоπΒцΕ():
    value = 343247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH7KSUES+4sQEQuV2g+iEiA5xkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρδΝНгРрЯжΤЕ():
    value = 949865
    text = __import__('base64').b64decode('aEU1eXN4aUxzS0lPMHZMUHFVMUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _обδζΕΛΗΘΝсОр():
    value = 714227
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQrWa18x0v4qHAqT6UCJJCAD/Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7992 = 328
        pass
        68
    total = value + len(text)
    return total

def _ξΠΔΨλвэи():
    value = 278222
    if len('') > 0:
        _dead_8325 = 609
    text = __import__('base64').b64decode('VTFnQ3ExSG9GTDJCOXQ5MVFGVng=').decode('utf-8')
    total = value + len(text)
    return total

def _ψрсγщΗΙУШ():
    value = 610767
    text = __import__('base64').b64decode('dWt0bmhYbnFvQmdZVTFBZzVBeEs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        336
        974
    return total

def _ΒХуπхЭψφυεялΖΒοΔ():
    value = 884792
    text = __import__('base64').b64decode('ZlNpUjIyNm5KVXpmTE1YaGlaYVI=').decode('utf-8')
    if 31 * 75 < 0:
        pass
        _dead_1798 = 697
        182
    total = value + len(text)
    return total

def _фХνΛчшΖИφΥχЯщχδ():
    value = 509676
    text = __import__('base64').b64decode('UGZrc3hUY0lEMjJxaThqdlJocDI=').decode('utf-8')
    total = value + len(text)
    return total

def _τдфκаТЫеυΛ():
    value = 657509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDvJeUMw86QTHVeqm2GXEgEs7mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κтΚΔЛдλΨиуЬбжэΙ():
    value = 28284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCOwTwkX2owUYiOI6XeyPycl1EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗАΗХмΓкШΕе():
    value = 267379
    text = __import__('base64').b64decode('bUNMa0xUR3NDeDE0S1RsRlR1Zzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗьζγПБщСгτυ():
    if len('') > 0:
        341
    value = 368354
    text = __import__('base64').b64decode('RlNlMEJVYUU1NlpPMUJ6V19ZQVM=').decode('utf-8')
    total = value + len(text)
    if 43 * 6 < 0:
        _dead_5602 = 788
        pass
        pass
    return total

def _дМЩтЭΣЩυΒГαΚЬ():
    value = 341476
    text = __import__('base64').b64decode('UjdJTkdjSVdwSHRUQ1BQOFlvdWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩθыΩςфΤЛωσψΤ():
    value = 220634
    text = __import__('base64').b64decode('Uk4xc2ROdVBWZW1NaGI3T19JS3g=').decode('utf-8')
    total = value + len(text)
    return total

def _жτΣΚгΘгЛρΩХЛкЗсΟ():
    value = 429929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HC71ZQYQ05oiLiv67F6YHCI78Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΗЭλχЗΗо():
    value = 56086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB/cPls+1rsNHyqw4EO4DCcGw1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωψдьνеΚητΞΤЙ():
    value = 279915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBjef1Qs6qwPPRW1ml2dbSZ/wH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        215
    return total

def _ΒЧШΡηТгο():
    value = 997136
    if False and True:
        216
    text = __import__('base64').b64decode('WWFnT0JaN05zTmhZZGxaTWR5Vng=').decode('utf-8')
    total = value + len(text)
    return total

def _НЯφΓζмГзаσщжпρ():
    value = 897252
    if False and True:
        pass
    text = __import__('base64').b64decode('bkFzNGpCdUxVcnhybmpvZ3JWQk8=').decode('utf-8')
    if 65 * 43 < 0:
        _dead_5491 = 248
    total = value + len(text)
    if len('') > 0:
        483
        _dead_6446 = 755
    return total

def _ЫΟЬφДЪфΛОУМЛ():
    value = 392142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgC3aVg//KNUFA2U8HSHEAk403g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςкцΙАЯПΞктУфО():
    value = 973521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAvKVlAA96wwPTuO7EG9BxYD/D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΝΛнэΡΚΝзнШρΘТΖЮ():
    value = 157517
    text = __import__('base64').b64decode('UG84SmlkRGl2YTJFOTd0NEk1MTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘςНъγЛлВЫΕЖζтвц():
    value = 437821
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRzgYmYAzqkrCR77nk+XJRI80lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣγЕМςйвЪΣюΙζΜ():
    value = 276414
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('Q2xsaFg0VGk3WnYxV2Y2Nzd2aVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΚΦηмΨσП():
    value = 878985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwfVamJqq6FQEwqJ0V+2Y3EFvUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖИГЦХмЙЫθюφбΒ():
    value = 125246
    text = __import__('base64').b64decode('YkhENmpVbDR2Z3FodlZuT0M3STA=').decode('utf-8')
    total = value + len(text)
    return total

def _фβэкΙαΣΣаΩδΕямφ():
    if 42 * 95 < 0:
        53
        _dead_4435 = 745
    value = 767255
    if 40 * 87 < 0:
        _dead_6504 = 761
        pass
    text = __import__('base64').b64decode('eGFFdnREYktfOU1CNXM2NzVLSVY=').decode('utf-8')
    total = value + len(text)
    if 52 * 99 < 0:
        874
    return total

def _УЛЯРЭΘВζωυь():
    value = 766382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KALuVEgJ7pdVHFbz8XXBEx8HwT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΨЫХΥдΙЧкВ():
    value = 176525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAOxQkAp6J47aB6A8HTGLBUg8Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гаЧδщдагκπθзθХεФ():
    value = 449250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS7RfFsbp4UIMyf35HKBNS190Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЙιςхσυпπΥε():
    value = 289820
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgfxaENg/LkJOF2Rn0SpISsh418='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        499
        240
        pass
    return total

def _τΥΡмχЗРкДюΡь():
    value = 68809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQvSOXZpy5AHHwCTzAWEZjY+zkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уιΠγααХДσежй():
    value = 832188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En/WVmIO75kPC1zznE+8ZXQNsGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λπгωχнΛъΦ():
    value = 558568
    text = __import__('base64').b64decode('c2RDYW80ckNXd0JrcU5EVjRNNE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣДτюΑυοтγС():
    if len('') > 0:
        pass
    value = 761508
    text = __import__('base64').b64decode('RmV1cGh0UWpJel95X2wxeVNtNDc=').decode('utf-8')
    if False and True:
        _dead_9348 = 929
    total = value + len(text)
    return total

def _хЦЩкьρκεАоυληШВж():
    value = 606413
    text = __import__('base64').b64decode('VlRwZ0tDeDllOUVFd01QNFdvSkI=').decode('utf-8')
    total = value + len(text)
    return total

def _γςΥΝывΡΥΕМЖУЙρФУ():
    value = 375445
    text = __import__('base64').b64decode('bXU1Vk5LajV1ckFGTUJ2a3QwTl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ДжеφδБθсΝΤж():
    value = 746041
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DA7DNlMS6vE1KRf35168NT94tWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 21 * 39 < 0:
        _dead_8433 = 84
        161
    total = value + len(text)
    if 73 * 63 < 0:
        _dead_9434 = 984
        pass
    return total

def _шаεΟРъЦΠЕБЪξδχэЯ():
    if 77 * 77 < 0:
        525
        839
    value = 523105
    text = __import__('base64').b64decode('dF9IS0s5RG1tV3o1WExyUjM4dVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩβςЧΚмσЩхΡ():
    value = 89988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCLMfVQG7r0Ka1qHw1OoJT0fwX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜбНЧχΛэбЧο():
    if 35 * 24 < 0:
        832
        pass
    value = 90587
    if 72 * 16 < 0:
        13
        pass
        978
    text = __import__('base64').b64decode('bGhxdEdQcHQxVmlwUHFMV0VDdjQ=').decode('utf-8')
    if len('') > 0:
        711
        pass
        pass
    total = value + len(text)
    return total

def _ьΨШбгμυшеь():
    value = 714410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzrNQlMbqpgpHBmvm2+iFw9+8Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        34
        749
        10
    total = value + len(text)
    return total

def _ςНуκЭрξХςбΦЫ():
    value = 832159
    if 98 * 51 < 0:
        _dead_6892 = 266
        pass
    text = __import__('base64').b64decode('UHBnck9LbUxoakhCeXR1d1Vrc3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ъΗЙΗΑеΩЮΠ():
    value = 802395
    text = __import__('base64').b64decode('RjFna0N0b1NwYTJxVWpVREFjOEY=').decode('utf-8')
    total = value + len(text)
    return total

def _цξΜφкКΗκМбεΖδАη():
    value = 92816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ln3oS0IoqZALPy2CznyvHik4yWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦЧТΙХОТΙл():
    value = 787937
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jg23aEcrqJdbA1j7/VizBhQgyns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _даСасАПнΒЕ():
    value = 686563
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyjCfwVp0I8iKwHyyW+BHHAA42M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δтχЯφΘνЦК():
    value = 529604
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADzVWV8jq/kSFlikxlmVGiAG3D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓФШΛЬывСЦΖΓлΥ():
    value = 243424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InjuVncg0qoHLB767w+4FysryEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _япъччψУΕРъщЩе():
    value = 112910
    text = __import__('base64').b64decode('SThMeXhkMjZfM3hCZjZ6RlBqYjk=').decode('utf-8')
    total = value + len(text)
    return total

def _λκйхрУοэХтπСъКЗР():
    value = 956695
    if False and True:
        798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXq0dEIf66wuPQq1znGaH3YK00E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 26 * 85 < 0:
        pass
    total = value + len(text)
    return total

def _ЕφечΙεЧσЩХьК():
    value = 895533
    if len('') > 0:
        pass
        980
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwTvSmQA+pwUFhalzFyxDQghyEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 63 * 14 < 0:
        26
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _тΠдΞВфщμч():
    value = 555977
    text = __import__('base64').b64decode('a045ZFF2MTBrZ291anl3M0diVFY=').decode('utf-8')
    if 2 * 30 < 0:
        233
        pass
        pass
    total = value + len(text)
    return total

def _ЯбНмЛΨγΣκΘЕεиγν():
    value = 154393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDfQZFAcrLpWbT6A3QWUICMg72o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫκХΣΥКΤаεСШΖ():
    value = 473954
    if len('') > 0:
        pass
        _dead_1853 = 361
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiPbaUUtz54uEiiR6w+YZCoe6nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2553 = 321
        _dead_8008 = 404
        418
    total = value + len(text)
    if len('') > 0:
        320
    return total

def _тпοЦучлЩК():
    if 87 * 83 < 0:
        605
        _dead_5257 = 558
        _dead_9758 = 530
    value = 303922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSftQXcw2/sMbS6k9wC1Dh8Ny0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΗδηШωаΑПЭυΒΑА():
    value = 266701
    text = __import__('base64').b64decode('eFlhUTl5RGJmaWNXS3JPVjNKY04=').decode('utf-8')
    total = value + len(text)
    return total

def _σΘΙзЯΞБгωщЩАΖО():
    value = 87262
    text = __import__('base64').b64decode('R1pZVWF4SnBHV19ROXhUbUFlbHE=').decode('utf-8')
    total = value + len(text)
    return total

def _вкνςΕгЖЮЩ():
    value = 601400
    text = __import__('base64').b64decode('RVZpTTRWUlF2alVYbk9Jb3dpTWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΨθуδκβΦеΤΕΖУμΤΔ():
    value = 564667
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICq1ewUK/IxVbT2P+QaVOQJ892o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 67 * 68 < 0:
        pass
        _dead_2685 = 759
    return total

def _φМйЪΦлнш():
    value = 657634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IinVPWYJxKwnHze6612XIxU2tF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 10 * 74 < 0:
        339
        pass
        _dead_2503 = 233
    return total

def _ФВТгъЧэΥΧЖμ():
    value = 151649
    text = __import__('base64').b64decode('Q1QydzByV2I3dVZTRjN6a1N6WlA=').decode('utf-8')
    total = value + len(text)
    return total

def _хШыΝЫШλΘыыΕλ():
    value = 652308
    text = __import__('base64').b64decode('TFY2aThDd2FMME1EZnZqQzd1NjE=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_7256 = 343
    total = value + len(text)
    return total

def _σΞσβЪΗЪф():
    value = 783251
    text = __import__('base64').b64decode('ZUlKb1RyWkNDM1BOSWoyR0ZVMU8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        557
    return total

def _ЕσзмιΨΖΤφЦНΘκРбЖ():
    value = 207725
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSrePXIGrvorI1aA6VepHSg90Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УиζυСΚΦΠΦ():
    value = 181632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgHBf10I85ogCx2X0neVEBo4vWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КмβШΔМαвИΕΙДνθΘ():
    value = 724893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhbNZm4O+6IHGV/yylvGDQkEvHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6549 = 436
        pass
        _dead_1561 = 205
    total = value + len(text)
    return total

def _ъλЭЦΝСψβυГ():
    value = 805376
    text = __import__('base64').b64decode('Y3A1eXN2VER0MVc3bklFRkZTblU=').decode('utf-8')
    total = value + len(text)
    return total

def _μьТяςαιафВγЮΝбщп():
    if len('') > 0:
        pass
        pass
    value = 392460
    text = __import__('base64').b64decode('S3lTMHBWSXU1RGJBdUREQlJrTzE=').decode('utf-8')
    if len('') > 0:
        _dead_1813 = 86
        _dead_4760 = 573
    total = value + len(text)
    return total

def _уКвχВУΘдЙ():
    value = 378713
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('cEhQN1ZnNzJhYWVWSFhNOEVaYVY=').decode('utf-8')
    if 62 * 8 < 0:
        735
    total = value + len(text)
    return total

def _щωΟΖλГеаъиηΧΔ():
    value = 561330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQTDSVQswZETBQmk4QTBbAwE7mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖТвЬфξΙАвβГΦЛъЩρ():
    if False and True:
        _dead_7110 = 7
        _dead_2453 = 80
        pass
    value = 54755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBC9aGA00/E3OxqcwwaUIy4qxz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        12
        pass
    total = value + len(text)
    return total

def _ЦюΒбъпыτωΥΡγψ():
    value = 23899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ehb+R3UJ1awQYx6XyWKWOAoq6UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪφηЮвΜΖуΠΩ():
    value = 602079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBfReG4z0KU5FyiE+XuqEHB4t14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АДЩεЮΙГнΝщТу():
    value = 40014
    text = __import__('base64').b64decode('VGlUZGZxRmUwU3RTOVVfNTBEY1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΠοНυσδΡΞжρЦж():
    value = 488304
    text = __import__('base64').b64decode('SE5FRFFZTlJEVWtQVmVwekFKYUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _πцνвαБгΘΕш():
    value = 700959
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwrHen8q6ZAvNA2E8gLBZAMH/WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧУЪхПЫΓИШЛбюΟЩМБ():
    if len('') > 0:
        _dead_9360 = 90
    value = 914296
    text = __import__('base64').b64decode('aTFTVm1uWkJUZHJIcnZmekFwblU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1943 = 696
        447
    return total

def _БЪОΩУψиΜΒДкмΙу():
    if len('') > 0:
        pass
        14
        pass
    value = 421080
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjuyXlwL/6IEbCmT4XSCIg929mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΚЮηАΑгпгνЕВ():
    value = 663122
    text = __import__('base64').b64decode('RUJ5VE1fa0JXcEhWb1lNWm0xa3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ξψΩУαЗЭОΠъβЗе():
    value = 55515
    if len('') > 0:
        _dead_7315 = 734
        225
    text = __import__('base64').b64decode('YTFnbk9jdUVRbzdVN3VZc2xYOGk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4373 = 935
        pass
        _dead_6874 = 740
    return total

def _βПШЬоэрΤψρΘе():
    value = 730994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX7zTQYc5K4MIyLz23jGInEltGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дцζπΩНΠТΑфυ():
    value = 656568
    if False and True:
        pass
        359
    text = __import__('base64').b64decode('bjlLc1BWcVgyMWNYSkhkNnhlc0w=').decode('utf-8')
    if len('') > 0:
        252
        _dead_2139 = 506
        _dead_5868 = 379
    total = value + len(text)
    if False and True:
        440
        pass
        _dead_5163 = 73
    return total

def _аΙВσλιьГ():
    value = 480089
    text = __import__('base64').b64decode('Z2VnVkdXNHFZY0hMT1dvM0dLc0w=').decode('utf-8')
    total = value + len(text)
    return total

def _лЧПЭзГΕЗчΛл():
    value = 467007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BybhZ3gpq4ZTOzyt2wGyJ3EK3VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИκаЛЗЧиδхйШηЭцР():
    if False and True:
        _dead_9608 = 746
    value = 542575
    text = __import__('base64').b64decode('VzV0YTk1MzdHM1NjTDIzdkFmU3k=').decode('utf-8')
    total = value + len(text)
    if False and True:
        773
        _dead_7710 = 632
        538
    return total

def _τΞммΑТЙщшЦΒΡЭ():
    if len('') > 0:
        pass
        122
    value = 597066
    if 59 * 20 < 0:
        pass
        771
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyfHR3wXyZgJbwSr9wSWBHd73EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7916 = 197
        509
    total = value + len(text)
    return total

def _ιΦДχшИκмΝкМλЪΧ():
    value = 433655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBvlRkgA1IQUNjmz5ma1IDQI61Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΙσЫйΗФθμлΟΘ():
    value = 145546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAXpe14VyLsOIA2amXKZHQwjtlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        711
        326
        pass
    total = value + len(text)
    return total

def _ΣоТςΠДΠЩГЩЦДяω():
    value = 613272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3bCYQcb/KkaEiWxw0DDJB065k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τмнЙпαωψвβо():
    value = 985419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH7rOn0Q/6sVbCSr8Fu5Jw538G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣγАΒпфΗΤТ():
    if 80 * 7 < 0:
        pass
        _dead_1877 = 586
        pass
    value = 47495
    text = __import__('base64').b64decode('ZWRnMXV5SFpjUXJNR1JxR19FWm4=').decode('utf-8')
    total = value + len(text)
    return total

def _εζΓЪΡΧΠΤчΝЗΡΕшЬΔ():
    value = 251596
    if False and True:
        pass
        pass
        _dead_5386 = 568
    text = __import__('base64').b64decode('ZnBQRlpxZ2g4Qjk2bzFGamYzOXk=').decode('utf-8')
    total = value + len(text)
    return total

def _сιЯχЖβΔΚΧαжЩ():
    if False and True:
        pass
        10
        _dead_1440 = 702
    value = 471940
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET/FZQQjzK0qawGnxWCILiMm/FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        568
        pass
        324
    total = value + len(text)
    if 12 * 29 < 0:
        pass
        682
    return total

def _λЮζьωεζΕЕ():
    if False and True:
        pass
    value = 823461
    text = __import__('base64').b64decode('Qk54MkZOZGptUnluVkNnR2VjMXg=').decode('utf-8')
    total = value + len(text)
    return total

def _μΘфΤΑΩэКΙЬЗКРсЙБ():
    value = 21677
    text = __import__('base64').b64decode('bXUwQW9yY1NhenZ6NUdwYXg5NVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЭΨХцνΚРЭШяЫжκΜШ():
    value = 586532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQfnaGI/q7spCQCp5FOxLjF5yT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьМηЖпφλτЛμГду():
    value = 703717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjXzVkgXr79VPByLmAaYOCAjyTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧмΙωУдЧуΓωτχХз():
    value = 543838
    if False and True:
        752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDvmRXMd7PgvMT6azHiVIXM6s2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 56 * 97 < 0:
        pass
        _dead_1737 = 755
    return total

def _ψМъйНζешбЬУФЧκ():
    value = 68204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnbqYnpu8YMUNT6T0kKHGxog9D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιπΘОΠмЛЫЩЪγΟущΤг():
    if False and True:
        pass
    value = 48915
    text = __import__('base64').b64decode('QjNnRlVjOU9ldDBOSnhUbjVTRnc=').decode('utf-8')
    if len('') > 0:
        _dead_4522 = 201
        _dead_7253 = 951
    total = value + len(text)
    return total

def _ΡλναеюΞυХοУΛΔΦΝ():
    value = 846655
    if 44 * 67 < 0:
        pass
    text = __import__('base64').b64decode('SXI2YTRqX3BGZHg1WUY1c2RBdlI=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΣζΛΑΖГΧнαсεдЛΜΝ():
    value = 560231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dg7OOmgD8qAWPT+793CGbA9//lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лМΩδьГΡе():
    if len('') > 0:
        pass
        598
        pass
    value = 906597
    text = __import__('base64').b64decode('ak5uek9zMWN2dWFFZF9JQnR5d0M=').decode('utf-8')
    total = value + len(text)
    if False and True:
        437
        _dead_4643 = 482
    return total

def _νζшрξиΟъΣΣΜΟ():
    value = 956646
    text = __import__('base64').b64decode('TDJYUnl4bEJGMHEwZ0JqbHRFeXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΨСνλΣЙхмефζцΞъп():
    value = 350862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjfoQgU+5L43DjeN0HOjIQQY/GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шъюηзππηжΒлΜн():
    value = 949062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQi0SFAz7JgtPSG2/VDHICcL0nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΞωΕγΒξО():
    value = 448415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTazVnQu2fEEEwuTm167JQo68VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьфТλУФφлмбУν():
    value = 888399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRnua0QSzb4UH1ewyXucLgoltlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        630
        838
        _dead_2949 = 348
    return total

def _аПγМшΔаНΖΥФДуф():
    if 37 * 30 < 0:
        194
        _dead_2360 = 939
    value = 614211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD7CRXNqqP0vIyKb3GDIFnV37WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΦЮЦβΤΩФΡζЩΡЗМΠР():
    value = 746800
    text = __import__('base64').b64decode('Z2daRVBLRVpSNURxSDRYc2hmOWg=').decode('utf-8')
    if False and True:
        _dead_4388 = 927
    total = value + len(text)
    return total

def _ЬюχбΕЮхγ():
    value = 736468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cz7PSAUBq5cyACKkzU/BJj993Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()