#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _лβжСДΕЙхгΣΡн():
    value = 471720
    text = __import__('base64').b64decode('QTJSNjA0UnZVazFWc09zMUxoVTc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7389 = 613
    return total

def _ПкДБэцфмя():
    value = 319545
    if 33 * 47 < 0:
        673
    text = __import__('base64').b64decode('bGZiYmE3ajI5TzNtbEVSUzcwSkQ=').decode('utf-8')
    if 76 * 77 < 0:
        _dead_7691 = 278
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9717 = 308
    return total

def _КфαΚγνмΒ():
    value = 907631
    text = __import__('base64').b64decode('a0hIZ1NHXzRXd1RGYkpUbVNXbzA=').decode('utf-8')
    total = value + len(text)
    if 76 * 63 < 0:
        pass
    return total

def _оΚДвтΩиПΜοГδ():
    value = 796750
    text = __import__('base64').b64decode('SEVRTkV3cmxlVzJJMzVxRVJCZmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ШтγЫΛЭьМА():
    if len('') > 0:
        212
    value = 580272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwPHe0VqzK00bVqaxHCBGwwA0Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΜκνХеΩйΛρУΑ():
    value = 596178
    text = __import__('base64').b64decode('YmNCMDZ0OUQyeWtLQVNEZ3FGamc=').decode('utf-8')
    total = value + len(text)
    return total

def _уεэЪзΓΚо():
    if False and True:
        589
        pass
        _dead_3347 = 327
    value = 440740
    if 92 * 78 < 0:
        531
    text = __import__('base64').b64decode('VVpnR2pqeG41eG9lWjdrTGJSdms=').decode('utf-8')
    if 8 * 71 < 0:
        16
        479
    total = value + len(text)
    return total

def _ψΛмπψХτЧшсБπΘΒμ():
    value = 848933
    if False and True:
        730
        381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz3hRAcS7qwqKwOw4EOCIHE6sms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρХωмЭегфнΑςПχм():
    value = 744045
    text = __import__('base64').b64decode('eVdIUXQwV2JYTURoQVMxZ2ZrN0o=').decode('utf-8')
    total = value + len(text)
    return total

def _аРРΛδсЩтуЬ():
    value = 466649
    text = __import__('base64').b64decode('ZWxTbnZKUVZsS0pTODNDODM3eXg=').decode('utf-8')
    if False and True:
        pass
        _dead_9974 = 576
    total = value + len(text)
    return total

def _мИΚБсЬΓΞξвΗШπ():
    value = 326674
    text = __import__('base64').b64decode('T3lLQ2p4bXo5RFh4WVdfTlZvX0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔοΡвΩΙΑτДЖΝг():
    value = 91662
    if False and True:
        25
    text = __import__('base64').b64decode('THN6bmUxVTdDZHk1SHBBZk02MTg=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if 69 * 35 < 0:
        724
    return total

def _ΠΞБдЭζДКВζбья():
    value = 27368
    if False and True:
        947
        _dead_8608 = 140
    text = __import__('base64').b64decode('bEVEa3l0YmpoTGxfYTlkQWR1Nng=').decode('utf-8')
    total = value + len(text)
    return total

def _οΥэΥΜПзΠК():
    if False and True:
        pass
        496
    value = 320508
    text = __import__('base64').b64decode('VTBDUWhmZGpRbnFMcnBVWVFKY2I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4343 = 921
    return total

def _РыАξλφйΙγеωаΥ():
    value = 100695
    text = __import__('base64').b64decode('d01Pc3psTFBPZlJXVXduQmFmc18=').decode('utf-8')
    total = value + len(text)
    return total

def _цхΧЕσΕΤκπΔДФйЩлф():
    if 65 * 44 < 0:
        pass
        _dead_2548 = 797
        pass
    value = 875799
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxjUaWgOx7FbE1+5zE+3OisA02s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КНХβЖЫΤεсЙΕηсИτ():
    value = 93405
    text = __import__('base64').b64decode('VTZyRDZJbHJQT1RiQ1VIZ05tOWU=').decode('utf-8')
    total = value + len(text)
    return total

def _РΕΕЧТаΜХНτΟΓТΨΤ():
    value = 556673
    if len('') > 0:
        pass
        pass
        97
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiTyVFRs7YUhNQ6032K2HXc803Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΨΚςЬσхтζυ():
    value = 464254
    text = __import__('base64').b64decode('RDRrak95eTRmUUZqZDlTdXFNTTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ДзФсΤψачοжμΟΜЫъ():
    value = 678676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAG8ZHgJ7KYJDwiN8Q6UYhEoxn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        664
        _dead_5296 = 235
        _dead_8206 = 869
    total = value + len(text)
    if 84 * 63 < 0:
        pass
    return total

def _Μψбыδмаигοπя():
    value = 193527
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ai3cR2A+y6EsMCaNmX67ER8c43c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξзтλμчЭκβΗзмРεЧ():
    value = 841925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQLhWGRgxIAyFC2XyWWzGDMMwkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨхδαИлσЙΘЦтΞ():
    value = 468718
    text = __import__('base64').b64decode('TGgyZ3g0QWQzc0JVZmdBSmhER1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΚжγЮΧаα():
    value = 964681
    text = __import__('base64').b64decode('bURMbE96T3ZCb2VYT0MwUkEzak4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗЕЗУΛдНсшΗнФа():
    if len('') > 0:
        _dead_1562 = 817
    value = 250083
    text = __import__('base64').b64decode('c3lhSDY5WWNSMTVzcDJic2ZHaUM=').decode('utf-8')
    if False and True:
        _dead_3582 = 410
        934
    total = value + len(text)
    return total

def _рΡΘСΗςДοЧαюУхωй():
    value = 81469
    if len('') > 0:
        826
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT7mR2E18YMPKgyt20/HYjwA7WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рπηтФЕΓоλтΣ():
    value = 930468
    if 34 * 91 < 0:
        206
        43
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzjubAkKrvgmNyCbzGO4AgJ+w0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ювМщδгκζвгΤк():
    value = 201265
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAfyeVcox6QZOVeO7FWEEBId9UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζΨВΒэοЦлδΛρДк():
    value = 985066
    if len('') > 0:
        _dead_5388 = 212
        pass
    text = __import__('base64').b64decode('QW1iYzJFaGMwVUVObnVKclhFd3Q=').decode('utf-8')
    if 58 * 40 < 0:
        _dead_3526 = 614
        405
        _dead_6188 = 444
    total = value + len(text)
    if False and True:
        pass
        pass
        470
    return total

def _ВΠΨΒиЦеΝлθЦДρбМΟ():
    value = 420099
    text = __import__('base64').b64decode('RWkwdEhTbDlyTFZfaG9VdE9pRE4=').decode('utf-8')
    total = value + len(text)
    return total

def _щлъξчΣΝΡэΧщΞьэЦп():
    value = 34875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhDiWHMuqbsTPhqhkUCvYXIF4Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КθΚΑλхмЪΧкναсгν():
    value = 718413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dg3MS0ss//45GTD0wHO8Gigd8mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 70 * 40 < 0:
        pass
        _dead_6469 = 80
        489
    return total

def _ΩыШδАМГΟΔсжι():
    value = 881317
    text = __import__('base64').b64decode('cU8yc3U0SW5kd25aanAxNkx3YUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦψΙπЯоЛъЖбСъЛЖв():
    if len('') > 0:
        pass
        pass
    value = 822835
    if len('') > 0:
        _dead_3039 = 918
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBnoVEUJ5JEyKw2xwVCgYzAVtXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8106 = 702
        _dead_6555 = 531
    total = value + len(text)
    return total

def _χΧяοцьγжδγΩРЧΣкθ():
    if 69 * 15 < 0:
        pass
    value = 593323
    if len('') > 0:
        349
        pass
        pass
    text = __import__('base64').b64decode('cDNCbXBQa3hZVDZveDJzaUZvR0g=').decode('utf-8')
    if len('') > 0:
        866
        390
        _dead_3078 = 945
    total = value + len(text)
    return total

def _ΣГУПθгΝΑя():
    if 18 * 73 < 0:
        pass
    value = 492785
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBb+OEQe1f0tLBWzyk6DDiwZ/mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΓЪШкНθчшΣУΜξμΕ():
    value = 408827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSDIfHk0y61aEySm2H+aFg8t/lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΘШΓΗцξЩγРЕаТйΓ():
    value = 14040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB/xZUcK/7EiPQCFmky5EBIJ/lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξςωΙЯαжμьзΠσχ():
    value = 436169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHe8PVgz56YbKQKOwFeDHSEiz3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓхвΘΣλЫыοкλУг():
    value = 769314
    if len('') > 0:
        _dead_3322 = 955
        643
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBnhbHMt5oAbFR+E51G4MzUX41w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 99 < 0:
        635
    total = value + len(text)
    if 67 * 23 < 0:
        pass
        585
    return total

def _ΟΧвпМΓΛτφΤΛηЫξΛ():
    value = 220610
    text = __import__('base64').b64decode('SEdFb29Ra2FEdHVVNjMyeFB1Yl8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _шюμБкζυц():
    if len('') > 0:
        _dead_2742 = 337
    value = 387161
    if False and True:
        pass
    text = __import__('base64').b64decode('RURoTU1uUDFiblBsbU5IYTBLc0E=').decode('utf-8')
    total = value + len(text)
    return total

def _σρθξφΠыΘγ():
    value = 285914
    text = __import__('base64').b64decode('VFFZV1I0NGx1RGQ3X2ZOaXpDWWE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4717 = 367
        _dead_1953 = 18
        _dead_7719 = 153
    return total

def _τпыэСχэνИΠΡΗчμчЛ():
    value = 357787
    text = __import__('base64').b64decode('dGEzNUx5dm40OXBiNl91WmN3c3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥРΟйшчΦπяΔηфωΟΥ():
    value = 835763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fiu9ekAj8qQHAjz3zmTBYh98zmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςРηВжπКРСьν():
    value = 394431
    text = __import__('base64').b64decode('Wk9LNGZmZnJrdl9OWWdMOVBJdDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ιаКνβтЯиЙ():
    value = 327118
    text = __import__('base64').b64decode('RHN0d3B5WEg0R1loRlBMQ0VjTFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦАыΡΝъоιПаКШХ():
    value = 569877
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD/NTGNv0IM0Lyz33HLEYB93y0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _φπМЩωЯЮιзд():
    if 61 * 29 < 0:
        pass
        58
        _dead_3008 = 818
    value = 352172
    text = __import__('base64').b64decode('UHR6WHVnblRvckxFdVVyNko1Rm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣкЦΣεЦрЧζВз():
    value = 783441
    text = __import__('base64').b64decode('Qk80aTc5MDNVVnVOUjAxNEtrR0k=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5098 = 15
        pass
        113
    return total

def _ГРΤΖκЮηсΡ():
    value = 931335
    text = __import__('base64').b64decode('ZVJ0MFE0c29vdDNaVDdKR3Q5UVk=').decode('utf-8')
    total = value + len(text)
    return total

def _аΒДГОσТяБуΞΗ():
    value = 526559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQrxYHMbyLwXbCG5+gWfPgsZtEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψхφйДЫΔΑβΔцяφЙЖ():
    value = 150229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DinNf0UD+P0VCRep7FyHOHF6618='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 87 * 29 < 0:
        pass
    total = value + len(text)
    return total

def _юМζЮнΩοихь():
    value = 947497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBXxWVI+04ksCzmZ7WKhACsfszc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨЧλулЧΡγФτηОцμ():
    value = 904038
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nxq8XlZh6/0Bbg6nnlizbR0t7Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΕхηΤςοрφаΥоΖУ():
    value = 398006
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwPIakQDyKcgLV2pzVKUES8fwT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мηФιЫццΜВюа():
    value = 564444
    if False and True:
        984
        408
        709
    text = __import__('base64').b64decode('STg2dlhucHVma3ZNRmF2d3ZkeTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ъцЪРвуОЙфНδζ():
    value = 865165
    text = __import__('base64').b64decode('TVl6dlg3X3dSNVlxbzUxQWhpc1I=').decode('utf-8')
    total = value + len(text)
    return total

def _λэыЛβθрЭο():
    value = 153081
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTnPT0EWqKFVGAGi6wGjLH03t2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щνΧШояуΓαМ():
    if 26 * 57 < 0:
        _dead_8103 = 817
        pass
    value = 868915
    text = __import__('base64').b64decode('R21IM1d5UXllNmVKMUhMZzRPS3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦфСЩΓБУξСΛЮЛΑО():
    value = 8675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InzoSAkW5/8oFz6vn1TEHC5520c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΟιΤырιξΠб():
    value = 11666
    if False and True:
        pass
    text = __import__('base64').b64decode('WXNMdElTUFNBRTFIMEJ5REc2Znk=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _цυοχζьтС():
    value = 872378
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CS38PHkvy4IsFzeBwWyZBCop6zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чдΧΜεневщζпЭбν():
    value = 921128
    if False and True:
        pass
        pass
        623
    text = __import__('base64').b64decode('UTRzS2pQUTQxbzQzY2htenZEVW0=').decode('utf-8')
    if False and True:
        833
    total = value + len(text)
    return total

def _ΟзΕлбΠΣζДФΗХΡ():
    value = 17725
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnzQZkAy+YtSLDyHzGKVLSQG42Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        275
        468
    return total

def _ΞуЕдδωμΞΒЛеχΦПλ():
    value = 251034
    text = __import__('base64').b64decode('aHhlRVNpekNQYjM2WjRVMTJzanY=').decode('utf-8')
    total = value + len(text)
    return total

def _кДωΟβΧΙΔпфΜ():
    value = 688677
    text = __import__('base64').b64decode('YlJZWkFfU3F6MUZSZDNxbDJ6R1A=').decode('utf-8')
    total = value + len(text)
    return total

def _σЬВМΑγаБΛд():
    value = 29217
    if 20 * 17 < 0:
        411
    text = __import__('base64').b64decode('UlF4aWU5NWlaWXppZkduZFdrbHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯЙЙΚΕыЦΓИΒ():
    value = 121842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAnxbXwszpAkCQ2ay3rDJnYsszo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        372
    return total

def _θЗуΟОΗΛΘΛпΛ():
    value = 962914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR7yeWI78aowFAmPzUKzARY5tT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηРΓωΔвЯЮΦмΜΚΕρςΜ():
    value = 109055
    text = __import__('base64').b64decode('eW5MbWduNTNLdVU5VWhHU0ZtaHA=').decode('utf-8')
    total = value + len(text)
    return total

def _маΖждΜГВзΔ():
    value = 508030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnnlZVIV75tVIzyawFGkGxJ56jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рηЖΠπΡσеτЮЩΔΞΡς():
    value = 452535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3fQRQFgxqERNwiM0WaEIzQtzD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьйοШЯеОймξνЪ():
    value = 771540
    text = __import__('base64').b64decode('TldkeFpFcklsTE5aWmF5VUpsVFk=').decode('utf-8')
    total = value + len(text)
    return total

def _еΓλжЗГΗΜ():
    value = 976853
    text = __import__('base64').b64decode('TDltNDZ2WHVkNkRVeTk0NTNidFk=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _фЦиΝдивυдЯΠαΥςЬъ():
    value = 874144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3+yaHs82r0MDl+b3ALJAyh7zGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        402
    total = value + len(text)
    return total

def _ΝбσμШΤюΕμςПйЗ():
    value = 444571
    text = __import__('base64').b64decode('SE04c2xIdHNoZjNTYWo2Q2E3Wm4=').decode('utf-8')
    total = value + len(text)
    if 33 * 66 < 0:
        pass
    return total

def _μЫμφжΨΞЮ():
    value = 602467
    if False and True:
        426
        pass
        _dead_9924 = 61
    text = __import__('base64').b64decode('VXh6WFFnSmdGMkE5YUZQeDdjU1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ХАηбШТΥНВρ():
    if False and True:
        pass
        746
    value = 191756
    if len('') > 0:
        pass
        _dead_9124 = 332
        _dead_3672 = 525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3rMZwUs9YUwMAW02XCdEyoZ/Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТπΖΝωΩΤΝ():
    value = 542794
    text = __import__('base64').b64decode('alZKbWJfWExfSWNYdW9haUs4ak0=').decode('utf-8')
    if len('') > 0:
        540
        _dead_5459 = 388
    total = value + len(text)
    if False and True:
        pass
        385
        _dead_7429 = 311
    return total

def _оΚОμΔΣдщ():
    value = 474437
    text = __import__('base64').b64decode('U2hLNzNLbGJCVDBVR1RzWHZEejM=').decode('utf-8')
    if 44 * 36 < 0:
        _dead_4336 = 657
        _dead_9830 = 720
    total = value + len(text)
    return total

def _цШπРψνьλΩпεХК():
    value = 440462
    text = __import__('base64').b64decode('dEhtN0hnWU5ObEdHckE3bGNya0s=').decode('utf-8')
    total = value + len(text)
    return total

def _πηχАЯДфΚЮ():
    value = 292804
    if False and True:
        963
    text = __import__('base64').b64decode('WkR6ZnFEZDlvY2R0MjczWjB0aEk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8054 = 27
        49
    return total

def _ΑбςоЛπыЭ():
    value = 508345
    if len('') > 0:
        pass
        pass
        _dead_4214 = 105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAjAN0E3y6orEzyGzF+9FgQWx10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΨИκΛλΩΦ():
    value = 429067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bzi1ZgRh0aITDxqxmUC/OS8o5mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лКΛγоεΠЦжЮ():
    value = 808075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MR/TOl0c74sFHA6K+wS0BhQp5ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘвΞгνΚΘНшЙЫыНΓ():
    value = 942251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSjKW0ts96QPAi67zmSYP3AL4Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΕζюЮОБψ():
    value = 824601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwW9WGkj55wRbiCnwweUHHM/zn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯаΦФьχΩΤΓфЦξй():
    value = 314959
    if False and True:
        426
        _dead_2772 = 588
        pass
    text = __import__('base64').b64decode('SFdoNWJKYVRTQmZ0WXNJQm1oTG8=').decode('utf-8')
    total = value + len(text)
    return total

def _κфЖыСДρфУиβэОЮъ():
    value = 434727
    if 19 * 49 < 0:
        97
        563
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ6xR1Y1yqYpbwGGmlSUI3MFxXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 41 * 34 < 0:
        _dead_4909 = 462
        _dead_9501 = 564
        _dead_3167 = 888
    total = value + len(text)
    return total

def _зфщΖΖΧцλΓ():
    value = 369547
    text = __import__('base64').b64decode('c19kcGY1dUVTRzhnelM4dTNTb2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ыПкΛξвъоВΛξЬ():
    value = 891206
    if False and True:
        397
        175
        295
    text = __import__('base64').b64decode('UENNdDZsQ3p5S05ESmpIS0dFdTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΣЕχΞΡωрЭςΟυΖе():
    value = 198206
    text = __import__('base64').b64decode('c0hwbV85dHZMWTZ3MGRiU0JBRm0=').decode('utf-8')
    total = value + len(text)
    return total

def _еРНΗшСλΔуΧιλΛю():
    value = 549302
    text = __import__('base64').b64decode('b3lJeEVsSndXX0ZCVFpuQUt4WkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣОаЩНДоуХХΓэЦФΚΤ():
    value = 221518
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ND3GdwIb6asgMhixkF+cGBQk/Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тфЕλПγзЮΝΗщΨЫч():
    value = 121151
    text = __import__('base64').b64decode('YjVkMEJvcTFBQnc4NVhuTllVWGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩβΨЯΜчΧΩХΕ():
    value = 432547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyqxegBt16U3axuUzU6DEAoa0FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыςλΣеζΚΟЪθΥаκβ():
    value = 688950
    if False and True:
        _dead_6941 = 23
        791
    text = __import__('base64').b64decode('U1h4eGRhWUNpRXkzeXprdXdZaXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥяЫЗДζΠр():
    value = 486772
    text = __import__('base64').b64decode('RDZfaWZjd2FreTVicG9WX2VoUmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΜΙχΤЖΖТн():
    value = 932959
    text = __import__('base64').b64decode('aFV2TW1GNDFSUVpiT1NwN2ZCUFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΨΚЭΞπзаМмКμъЬЯ():
    value = 993570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnnNQUscrpIaLx6R6n2kLDIa7WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фАДκЗЮпяξμ():
    value = 238972
    if len('') > 0:
        67
        pass
    text = __import__('base64').b64decode('cXZOUWV4WmtIb3J1bXpFY3g4ZW0=').decode('utf-8')
    if 97 * 55 < 0:
        _dead_1748 = 965
        952
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _яШΥуδеЯШЖθгΞлΟ():
    value = 420533
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT3pZF8Y6ZwBMQWO+3iXHhossTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ауЩФαмкΧ():
    value = 378080
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwDJQl8Q54EtFh+XxEW4EBwB12g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4881 = 840
    total = value + len(text)
    return total

def _чжγеιбκψОюИвЕЕα():
    if 49 * 61 < 0:
        383
        pass
    value = 578592
    text = __import__('base64').b64decode('bVp4SmFPRkZpNkdIME1PcmVTSWE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_7607 = 405
    return total

def _ρеνΟЪхМХΟфУμ():
    value = 917381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwnxdFZo9acVay3w7lDFLjUHyUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РπхсαфΜσυχΘеννΣ():
    value = 604733
    if False and True:
        _dead_9659 = 241
        _dead_5379 = 153
        459
    text = __import__('base64').b64decode('WDdsaFdwNFJNOFVZNFFNUWZkYlM=').decode('utf-8')
    if len('') > 0:
        _dead_2275 = 814
    total = value + len(text)
    return total

def _ΣшσμΝηξΒГξεАΛИ():
    value = 606295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyL1R2sy56srHVuE91LDFRwXwnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БяλДЫщЦВцчшф():
    if False and True:
        _dead_8970 = 110
        pass
        _dead_2418 = 873
    value = 787199
    text = __import__('base64').b64decode('d1lzRXl1Sm05UVpqdFlMZGtxRm4=').decode('utf-8')
    total = value + len(text)
    if 75 * 12 < 0:
        _dead_2857 = 538
        _dead_1695 = 381
    return total

def _ΧΞψθЪСдРθФЧ():
    value = 698525
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn3DeFc11bonIBua5mmqP3M1/FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖηХЗчΑσСΝηВΛИΠТ():
    if False and True:
        pass
        pass
    value = 443059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JibNZl8q1ZAvDFnwnmavGwkEz1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψлщЛУзКςЯβΩηγТъР():
    value = 939677
    text = __import__('base64').b64decode('U280MTZnak1VMDBhVFFwemxZdHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣмМЧФРΣлъε():
    value = 657433
    text = __import__('base64').b64decode('UXN0amVWeG1hYWQwT2NUaHBPeFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ХлЮЦЦьгВыфиΓЮΚ():
    value = 57250
    text = __import__('base64').b64decode('cUFBZVhGZWdKTHBxbHk0NDNNUmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _τшЧωЛбφыζΦТсπ():
    value = 877876
    text = __import__('base64').b64decode('S3BwUjI0Q1ZadUpaZWIxRm9JMlU=').decode('utf-8')
    total = value + len(text)
    return total

def _гъΣΝΥΕΛοΕо():
    value = 732033
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTbWZUcvzr02M1uA+VqUHyEmzm8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДЧΦτъЯЪмЩэΘ():
    value = 548037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnzWYXUf05sZO1upw3O3LDUu918='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УнΦκРΓвβιуΞ():
    if 31 * 88 < 0:
        pass
        973
    value = 488539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BD/ON25vzI07MhWE6WyqADAly3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΓωЧжяшШΨАΨμь():
    value = 823147
    text = __import__('base64').b64decode('UGNvNlFiM29IS04xMjU4VkM4eU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜЩνΣγμЦσΘзνл():
    value = 815986
    text = __import__('base64').b64decode('S2txNVlYUDRXV09yTVg0Y3J0YnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ТмхμЩΣсγΞοЩρВ():
    value = 780542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSi3R3xqx4QzLAyc8Q6DEQIJ/nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        684
    return total

def _шΓΓΒГΣφЯЩρΗржδз():
    value = 392761
    text = __import__('base64').b64decode('SXhGSGRvM3hMS0NSaTBtQ29ETWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ыηΒНЩΔωνЩьγ():
    if 67 * 10 < 0:
        _dead_6212 = 718
        pass
        _dead_9175 = 967
    value = 871971
    text = __import__('base64').b64decode('UlQ2RzZjSUU4WlM4TnI2NGZaWDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ХэΓΨюΕЛО():
    if 61 * 10 < 0:
        pass
        678
        311
    value = 890591
    text = __import__('base64').b64decode('UGNGRFFaTEtiZHduc21MN1AwMng=').decode('utf-8')
    if 1 * 13 < 0:
        _dead_4855 = 1
        pass
        _dead_4595 = 868
    total = value + len(text)
    return total

def _ΠδюЩщδΙς():
    value = 964209
    text = __import__('base64').b64decode('RjhxeFNzNGNyckhkRzh3RnVLNFE=').decode('utf-8')
    total = value + len(text)
    return total

def _κтκκωГΞпΘμτзΨЦα():
    value = 441844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSP8Rwcf/60vCjaQ/VCxIAQI4W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЕнмΦгзΕАνти():
    value = 755750
    text = __import__('base64').b64decode('Z3lmV1dTajdXTTd0OU1yZ01WblQ=').decode('utf-8')
    total = value + len(text)
    return total

def _μУΡθтΗψЦгБДК():
    value = 835358
    text = __import__('base64').b64decode('eVpsVjRWT3J5ZmNwdmF2ajN6OUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬТζСΟπЧΡФ():
    value = 768555
    text = __import__('base64').b64decode('UjBsb2xPT3c5OE1NanR6dVJaZXk=').decode('utf-8')
    total = value + len(text)
    if 91 * 85 < 0:
        pass
        _dead_1456 = 193
        pass
    return total

def _ΓΓДικмΧНτдΙпΚ():
    value = 916926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzfJemgBp5EzYjX2mWSZNiY5wFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πсΥТыΦмΤθΘβь():
    if len('') > 0:
        _dead_6161 = 217
        _dead_6383 = 788
        _dead_6420 = 158
    value = 633236
    text = __import__('base64').b64decode('TXBvbEVPYUxyclliUmZjRXF3QUQ=').decode('utf-8')
    if False and True:
        764
        807
    total = value + len(text)
    if len('') > 0:
        675
    return total

def _ТψВИЗЛεκγщπчΡΛТ():
    value = 62327
    text = __import__('base64').b64decode('WHFLZXhxUVZ5ZW1WYWJCZUJiZjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΛэъКУтΜз():
    value = 283769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC7cfX043Y0lCDeQ+3ekHSocx34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гэΩРюТБΥоΨЦСΛаΠЗ():
    value = 523850
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EArUVG5p16tabQOi+H+WFwE5wX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        37
        _dead_5309 = 980
    return total

def _ЦИкПηЯΗΑеΤзеЕь():
    if len('') > 0:
        558
        _dead_8472 = 778
    value = 673677
    if len('') > 0:
        694
    text = __import__('base64').b64decode('ZGFMa3JhbjJkZFU2MTRXbmVvUE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘνЭΘРΨнАΚΡΩлΣОΣц():
    value = 866322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSjOSgQqzbwzEwiO/nKSGi8+3n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _афЯαулЦΜΝьξиО():
    value = 891732
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('RVdobTFzRlNIeDFtY0xlRUJCcGE=').decode('utf-8')
    total = value + len(text)
    return total

def _πψФэМεΒτξаαβА():
    value = 554064
    if False and True:
        291
    text = __import__('base64').b64decode('bzh3Sng5a2QyVDViUks1eDBBSDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦтбщЛιжШТνЯас():
    value = 961122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiPJOH866qUlG1q16n7BIgo17ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БХОΣюΞΓНχεУοш():
    value = 99890
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHznQEsD9KwICzam3FGZPTYo3Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΜνηψАйЩхαΕσσΗΨ():
    value = 606843
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgK1enUO3bhTFSaNykGZbDA96XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛПТвΟΞТМЫΘЖνοχΨ():
    value = 803715
    text = __import__('base64').b64decode('QlJESzhYSWVuTGxsTnpRSHJ3TlI=').decode('utf-8')
    total = value + len(text)
    return total

def _дзЕЩεЖΦхпныΓχΩ():
    value = 768590
    text = __import__('base64').b64decode('ak85TTBWOFVZNWQ1SUhITHQ0a3M=').decode('utf-8')
    total = value + len(text)
    if 68 * 45 < 0:
        pass
    return total

def _ПчΜпнЭΓАИЙΨ():
    if 88 * 58 < 0:
        pass
    value = 702356
    text = __import__('base64').b64decode('QWZxT3paTE9LWVo2UlBCT0I2T2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ψКОφμψщЭΣЪΓг():
    value = 803480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kw69Ym5gyP4FHy6T7l/AHgsJ7kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οэοхЬывыелщΗιж():
    if 20 * 73 < 0:
        pass
    value = 124594
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSPyZgEO8b86IBqwy3XAJT8m6U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘУвΩΟбэГбьФΗу():
    value = 865162
    if False and True:
        897
        5
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITniZWFv7K8GAlaGxGPFOSAd8Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цьЮтζΞЖρФТνεД():
    value = 316725
    text = __import__('base64').b64decode('dm5CVUUxcXZMWVJVekJRTnllelA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤπЩτщИАαЬψβτ():
    value = 695682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn6yVFVg3IA1CTu25WO9ZxYhs2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        727
    return total

def _ХЬзΖГυвзхТΔ():
    if False and True:
        415
        pass
        55
    value = 577109
    if 95 * 66 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXbiPkEq5IEPODum40edYxUW/mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1744 = 627
    return total

def _яМПбΣΟχхφΒΩнщнν():
    value = 820279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACTOVF8S/aYXbzaN2UW4Oy0qyHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7606 = 926
        377
        pass
    total = value + len(text)
    return total

def _ЭЯΙыΝЪобкЗьοМЙЦ():
    value = 516317
    text = __import__('base64').b64decode('S0M1X19tMHdIYmw3Y3R6MnFxYUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑнξлсΚЛΚуМф():
    if False and True:
        _dead_3042 = 500
        _dead_3269 = 817
    value = 299811
    if 70 * 39 < 0:
        pass
        264
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhXxeEc+rqNQMl3xmV2FZB8/5kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9409 = 320
    total = value + len(text)
    return total

def _нмеωъжμьБ():
    value = 860053
    text = __import__('base64').b64decode('UWlNUk50T2ZXVzJCS0QwbHg0cjY=').decode('utf-8')
    total = value + len(text)
    return total

def _γτΟЬнуΛьО():
    value = 736637
    if 6 * 39 < 0:
        378
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAvyTAkyy5gENDmV7Xi+Oy0m7mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 43 < 0:
        _dead_4210 = 954
        268
    total = value + len(text)
    if False and True:
        pass
    return total

def _аЖΗигЭΛΗтРβпщψ():
    if len('') > 0:
        _dead_7858 = 540
        pass
        pass
    value = 638587
    text = __import__('base64').b64decode('TnBGaFR0djd5UEZ4SXR4QjVFd0I=').decode('utf-8')
    if len('') > 0:
        _dead_5435 = 445
    total = value + len(text)
    if False and True:
        pass
        _dead_5358 = 404
        _dead_7607 = 650
    return total

def _ЪЭΚВрΜΙηхνоσв():
    value = 802667
    text = __import__('base64').b64decode('QXpjS2FTblNJeXA0R1RNbGp2MjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟκΧαΣяτοоΥφδЮεХ():
    if len('') > 0:
        pass
        _dead_6075 = 842
    value = 969083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3uyeFIJ+4QyFiah5ky6YyR5wz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δαШΔξΑЭΙБΦ():
    value = 81342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC3Df3YMzIUqEyaO3USiOnMh3H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нχыΖжЗРΨ():
    value = 202046
    text = __import__('base64').b64decode('RUhsR01KTjhSTlM3czM5NDZBZGI=').decode('utf-8')
    total = value + len(text)
    return total

def _фΨЗΖЕАЮЗдμ():
    value = 632733
    text = __import__('base64').b64decode('VVA5aENsTjBhTDN6ZHU4UElDYUE=').decode('utf-8')
    if False and True:
        pass
        413
        64
    total = value + len(text)
    if 14 * 14 < 0:
        _dead_2751 = 478
    return total

def _гθлФИИτΚсНФπ():
    value = 873671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxzAV1UJ3Ik3EwOUmXieNQMW0Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_2595 = 585
        426
    total = value + len(text)
    return total

def _ΔΓσФτЫΞкσε():
    if len('') > 0:
        _dead_4361 = 675
        pass
    value = 458628
    text = __import__('base64').b64decode('Wkp2VGhTRW1qTHJPOTJBRXI4UUc=').decode('utf-8')
    total = value + len(text)
    return total

def _φОжσГΥхЫζКж():
    value = 897369
    text = __import__('base64').b64decode('Qm51MkFKaWhYXzJ3QXdxTHF2czI=').decode('utf-8')
    total = value + len(text)
    return total

def _σεГЫεГΚФ():
    value = 611595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mhjofn846JJXCVayzlimGSkk5kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔлΨШШошνИЮП():
    value = 341843
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IC73b2M28pwmPCSLmgTEYRI5wTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΖΥЕυΒξβДКΘΕт():
    value = 798343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQfNTHU/6Ks6CjuFwACzZREO6Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТьХЦфииυζΙζсΙς():
    value = 141178
    text = __import__('base64').b64decode('Y0ROZm1JT0gzc00xeW1KQ21ud1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ψπМюΗыτΩГхιцρА():
    value = 21769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mgr0Y0RhwaBWPAnw2m6nIRwpwV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЛЦиΥжφΑЗУΠΝСΠ():
    if 100 * 52 < 0:
        _dead_3859 = 961
        _dead_8449 = 758
    value = 859983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh/gR2Ju2osvHRe5yX2vIzABxWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΗРшΩЫешЭφεИ():
    value = 769145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTu0dngs0q4mMAax3mOaBgl9/U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еЙШтЯЮθЩκпζαК():
    if False and True:
        _dead_4786 = 672
        pass
        _dead_6028 = 780
    value = 173684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETree1I/74MRKQr0/lXIPisn7lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 19 < 0:
        468
        _dead_2801 = 329
        576
    total = value + len(text)
    return total

def _зЮУοΞУнайπтЕиил():
    value = 962260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACrCTQI6qrkPPQqb/1PJZil8w00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φХφιбΙΩΙжЙпξШΔ():
    if len('') > 0:
        _dead_2674 = 108
    value = 333777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT60e0Fg2bBUDi733260Z3A2yWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        617
    return total

def _ΓΝθΙухφВщ():
    value = 972912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSG0Wmk83bw6HRaImVyKZXF3y0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чσοхεШψοΞйγвЗ():
    value = 918985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiXKd2cz6v85aAGLmX2eDSYr6EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        286
    return total

def _ΕЛоΟΡЭιΒкρзВ():
    value = 382067
    text = __import__('base64').b64decode('QnZ1dFl0SUlIZEN6STF6SGtaTTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ыβαβσМшлκ():
    value = 452069
    text = __import__('base64').b64decode('YmRQR0VaYU04cE83aVMzS2hPNmI=').decode('utf-8')
    total = value + len(text)
    return total

def _НУςюτЯΙιП():
    value = 741756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EirOf2UV8aMtAlmXmUadZHA11Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1091 = 710
        pass
    total = value + len(text)
    return total

def _ьлГтβξπЖΖθΥηРЪ():
    if 47 * 20 < 0:
        785
        562
        _dead_1211 = 845
    value = 396001
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXzxYF818r4XYhui0Q6+GAsNtUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лыΦΣΤιςοНйφΕΕСЕ():
    value = 341383
    text = __import__('base64').b64decode('ZW1MOElRc1JnYjUxcmVOelhrTEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨшςМтΘрпВЛфЭоΝЖ():
    if len('') > 0:
        pass
        pass
        934
    value = 46741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KibjeEZu+4laLAeb7HKEZX0JwEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РеΞУΥнАθΦςх():
    value = 648697
    text = __import__('base64').b64decode('VElFRE9QV2dBbGV0MUh0MlI5V1U=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        729
    return total

def _ΓДмйСЮИЧΛΘ():
    if len('') > 0:
        pass
    value = 533849
    text = __import__('base64').b64decode('VmpDSUx2bGZHSEJSRDJkMkFsZjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΞЛяΛΖςЯβ():
    if 67 * 30 < 0:
        499
    value = 960376
    if len('') > 0:
        _dead_9721 = 663
        805
    text = __import__('base64').b64decode('T3BWX0Uzdk8wYmZ0dk9oMl9NbDQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        90
        44
    return total

def _γΨλθЙПЫσρ():
    value = 292863
    text = __import__('base64').b64decode('VFFnMHp2a2tyM2wyendLVjU0bjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ληтδΨπСσаρыεЪ():
    if False and True:
        _dead_8714 = 452
        585
    value = 272523
    if len('') > 0:
        833
        _dead_7692 = 323
        _dead_6585 = 47
    text = __import__('base64').b64decode('cW16Y2ZGbFp5cFdVUDdHMTRZNm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑΔкХжςЕФРοΔдγΑΨ():
    value = 838779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3rUXlQh94UMAl+My3mEOyQ1ymU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οдБРКοЯЬψτ():
    value = 940272
    text = __import__('base64').b64decode('dGQyc3NHYzZDUHpJRkw3TVhhR2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ςλΒътйомΘ():
    value = 563842
    text = __import__('base64').b64decode('aEhVOEQyZTNXeDliT3VJV0t2Q1g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8820 = 324
        pass
        pass
    return total

def _ΡΡΔРΛνМςТе():
    value = 507782
    if 38 * 38 < 0:
        39
        _dead_4252 = 897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR3cTVYD3b1XbgqAzVGDBwMVwUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        22
        pass
        390
    return total

def _ΜчЯьохЦмИΗμΘ():
    if len('') > 0:
        pass
        974
    value = 956472
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ni7+SggX0PEsYj+mw0WSJRR93kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2976 = 731
        pass
        194
    total = value + len(text)
    return total

def _ςьЙйΦςпщΙтМнЗНЦ():
    value = 578315
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCX3UXcDzrstBQaP2nuAGBEC4Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 5 * 38 < 0:
        62
        pass
        _dead_4454 = 265
    total = value + len(text)
    return total

def _АΒβκδЫτюфЩ():
    value = 220596
    text = __import__('base64').b64decode('T05TRVZEQ1VNSTA4TUF2SWRTc24=').decode('utf-8')
    total = value + len(text)
    return total

def _ытΧφлсЖκΧзж():
    value = 329150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDrnXFsW874kNSyymGmFHHM4yj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 68 < 0:
        _dead_1894 = 45
        _dead_1309 = 959
    total = value + len(text)
    if 13 * 48 < 0:
        _dead_7649 = 289
    return total

def _жХДοΞωζπΚ():
    if 81 * 25 < 0:
        _dead_8351 = 85
        _dead_1648 = 553
        _dead_1167 = 389
    value = 494278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRW2RwRg56EJaDqryQeeDAMc93s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кззЫχχмδвмн():
    value = 250240
    text = __import__('base64').b64decode('bmZQUUZQR1hxd0tCWklIZnVzeUc=').decode('utf-8')
    if False and True:
        196
        256
    total = value + len(text)
    return total

def _ФЖЪΣЕСΓιиЖтτυβ():
    value = 915543
    text = __import__('base64').b64decode('cUxhWkZNSEFNazZQbUU5ZlF6aE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭоУЯΥэКьСи():
    value = 290647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AS7Qdnsp5Kcqaz6UkWSaZAI11WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хςЧдЧθдЮЬЦ():
    value = 7364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwjXSFIdrKMEGS6Hw0/CAhotx18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _СμυξΓρйД():
    value = 349936
    if 34 * 62 < 0:
        73
    text = __import__('base64').b64decode('b2Z5Qm1xTVRhVGRoS1N0bjFSZjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()