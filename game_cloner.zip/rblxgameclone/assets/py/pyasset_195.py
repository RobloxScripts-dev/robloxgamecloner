#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _хθηΟмΔйВа():
    value = 746241
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARfVd3AGz6EXEVaO3nW/AAod0V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5146 = 261
        pass
        68
    total = value + len(text)
    return total

def _εСчδГЛρМΓ():
    value = 149070
    text = __import__('base64').b64decode('enA0RV9fTnhCU3RucXBxdENXMnQ=').decode('utf-8')
    total = value + len(text)
    if 90 * 15 < 0:
        _dead_2734 = 129
        534
        26
    return total

def _ЗЮνЭНЬνьГΥ():
    value = 360650
    text = __import__('base64').b64decode('ckNFd2ZIazBhVmRXbVZkREdITTU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        991
    return total

def _ΠОйΛВВεδО():
    if False and True:
        pass
    value = 812903
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgXFfkQdrP8FEyeomHGmITYLwz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        932
        _dead_9298 = 55
        57
    return total

def _ΜДΦУδДлЪЯГ():
    value = 74272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECjBbXQLyYdRaCut8k6lZCx58EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΓλмНАΦψтевЦжΙΩ():
    value = 715306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQbnaVwbqosKEV+77Q7DGxcZxkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДЕοηΔрΡΒържχΞчж():
    value = 548214
    if len('') > 0:
        237
        _dead_9967 = 817
        907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hwv+ZlYw3aohAiSL4Xm+DXMN9Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9527 = 138
        111
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_9584 = 388
    return total

def _ΩЗЙНфЭРΝьΦИЭыонЯ():
    value = 215038
    text = __import__('base64').b64decode('bzdYTnhqOHZQOXFSd1U5eWZ0OVU=').decode('utf-8')
    total = value + len(text)
    return total

def _εМЮЖЖГеαθΤДσШыΡ():
    value = 42869
    text = __import__('base64').b64decode('U2JpS0c0VWFzZWJ2UkM5d1ZFb3o=').decode('utf-8')
    total = value + len(text)
    if 62 * 96 < 0:
        473
        pass
    return total

def _βщΖοЭηΕфкοЭςГ():
    value = 667583
    text = __import__('base64').b64decode('TWhfVUlzNURkdW05dl9vaWVqSlI=').decode('utf-8')
    total = value + len(text)
    return total

def _тъβнЭЯζζχЮ():
    value = 367869
    if len('') > 0:
        _dead_9034 = 837
        284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXbTaW4r6Z4LOx+VzkLCYQ8q634='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВκπΟφхрΣа():
    value = 9327
    if False and True:
        _dead_8548 = 374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDixf3Qy841SDTv60Q/CZSYr9l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΠξΛШЬΦρΧΟгΞ():
    value = 655165
    text = __import__('base64').b64decode('VjBvVWdMbGF1UnR1Nzl2Z3lwVzM=').decode('utf-8')
    if 8 * 20 < 0:
        _dead_6500 = 822
        pass
        644
    total = value + len(text)
    return total

def _ЗηΙЯΔБТзΗтК():
    value = 130215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjzGfwho1KsQagr0nni1Cy4EyWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5516 = 882
    return total

def _нμψΞЪфμЕπιεОфαΕΛ():
    value = 263603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BizHaFgb0I0ENx7xzgWGNgAAzFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΝοВνΨΩяЖрΤδΡМЕ():
    if 84 * 73 < 0:
        _dead_1699 = 721
        _dead_8122 = 90
    value = 833922
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBrHZgFq5qAvDlytzHyJG3Y9528='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7441 = 447
        pass
        437
    total = value + len(text)
    return total

def _ΤΥЙνРΞЯРриЦПДнπ():
    value = 559679
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn7QPXwx+as0Al6gw3qJFxZ63Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫρРцТΤтфςыниιΒφ():
    value = 764203
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhfbOVkjq6RaFTeCmgOJHjw3vD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νчбΔΒΩАгаРΡЛжЧΦт():
    value = 843755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwbuawgrzaokaV+S+FG7LHQm8F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        732
    return total

def _ΡЩзФΤατлзτЬ():
    value = 536637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxXhT1IxyYIGYx+b532+Pg4Xyn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 59 * 88 < 0:
        _dead_7705 = 432
        pass
        _dead_9227 = 415
    total = value + len(text)
    return total

def _ΖЫзцΓοЬΡяЮΕьЗор():
    value = 890549
    text = __import__('base64').b64decode('bV8xNVBCNHl0ekxueVJNT016aVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΦлεжзΥεγтλаи():
    if len('') > 0:
        pass
        pass
        _dead_9290 = 316
    value = 721797
    if len('') > 0:
        276
        180
        _dead_7392 = 714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Py68fFUM2K4FaQeLwVG3PzIh9ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κБτеΙФПгрИγс():
    value = 665100
    if False and True:
        _dead_3380 = 827
    text = __import__('base64').b64decode('RFZhVVU3S0VNVDhhdjBlSkIydlE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖαχΛΜхкςЬгΟЪ():
    value = 443989
    text = __import__('base64').b64decode('b29UYWFld1BHMkRyV2FmSV9VYWg=').decode('utf-8')
    total = value + len(text)
    if 8 * 69 < 0:
        _dead_7994 = 148
        pass
    return total

def _эЩМκΑыРΧъΒЖдц():
    value = 645128
    text = __import__('base64').b64decode('Y2FBV2U5U0FYRzgzMG40OW9rUzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΩχеСΜьжαсΝЦюκэЭ():
    value = 537469
    if False and True:
        _dead_3529 = 948
        _dead_5134 = 349
        _dead_6163 = 501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In/pZAZqr6olC125mlSAZjE70kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 22 < 0:
        _dead_6519 = 367
        719
    total = value + len(text)
    return total

def _ΠпβΡЪΣЫЗ():
    value = 903131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz21QUQj9JwHCj675l2VIxcNxVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΚπψбΔТПΦΤРЯςΗг():
    value = 291522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kyn0RVct2/4uMAOKnm6UIxQc614='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЬЩФΓЙАлτμΡяН():
    value = 330908
    if False and True:
        _dead_6240 = 902
        pass
        _dead_6931 = 436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyzxQ1xpzqJTAAL1+Q/HZScG92M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6394 = 905
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ДδУЩюЙΙΜ():
    if False and True:
        pass
        pass
        _dead_8490 = 216
    value = 138081
    text = __import__('base64').b64decode('V01RRkxEdmR3dEl3UGZJeEJueW0=').decode('utf-8')
    if 89 * 56 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7152 = 952
        _dead_9957 = 474
    return total

def _ΨФαΡчβΦШШШΨΛΔ():
    value = 888835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fxq8XUkzq/w8FiyB+1eIORAh1Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΟЩеεДцΦ():
    value = 304135
    text = __import__('base64').b64decode('UFFZZFpBNlI1YzlWV2ZxYmVCaDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _язΧΨСжОφлМфσεωηл():
    if len('') > 0:
        602
        pass
    value = 722463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQHnYHA01f4lLA6s3lHAGxw3yzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΙпΖПΠЭВЪт():
    value = 982508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESDGQnQQy7IiOw6B42GCMwYj4Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κηЙΗηЪцмйИΦнγе():
    value = 908933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhnIOAcT6oQZKDiJ2WLEZgopzVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δМИδτфΨτЮΞ():
    value = 922282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBmxZV0h/f8BES6byk65HggN4mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηωйАΚξфЩС():
    value = 52949
    text = __import__('base64').b64decode('eFRsd0x4SGpQZlI3cThQZlA5ZUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦХВЦнФдκт():
    if False and True:
        pass
        821
        pass
    value = 603245
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MifHe3ptzZorYl2G53KXNx0V0lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3336 = 618
    total = value + len(text)
    if False and True:
        pass
    return total

def _сΤΑγяЕρπхΡ():
    value = 181309
    if 35 * 66 < 0:
        _dead_9152 = 778
        _dead_8442 = 956
        159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgbeaQY90IIWGC2T3X+FPRQm714='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        296
    total = value + len(text)
    return total

def _ΧιПЖПΖжЮξ():
    if False and True:
        891
    value = 231617
    if False and True:
        pass
    text = __import__('base64').b64decode('QjF0VnRTRVdTWUt4UGZzbjNwZGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧшξΙμКοЫъдй():
    value = 35741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ68f2kw7/gGGAen3g/AYSkBylg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сτТΧΗρуФΝ():
    value = 724571
    text = __import__('base64').b64decode('UHVYRVl6RWdWWDhBa1hDd0E0Ulc=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЦηбζПпЗα():
    if 24 * 100 < 0:
        _dead_5208 = 188
    value = 64383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSiwOlJsr5wyMh26+gCANhEo73o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вξзεЪНΔюχχШΗъΩΞЗ():
    value = 473174
    if len('') > 0:
        501
        _dead_5013 = 699
        _dead_2309 = 965
    text = __import__('base64').b64decode('S0MzRUtxaUQ4Zk5YZV9FaFE1Z1E=').decode('utf-8')
    total = value + len(text)
    if 39 * 91 < 0:
        _dead_8037 = 433
    return total

def _αсχрЕрЯпЧЧидйΤ():
    value = 825007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pwv8fVgz1KoJOSiQ736lHAAfz0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μωНКЬГΑρΕъ():
    value = 840706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az+xdHtprZsKBST00Fq1FgsL5mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФэкΡΜΥЪСЩКБ():
    value = 99101
    text = __import__('base64').b64decode('c1dEenhWck10ZEtmUUNHeGJyRDc=').decode('utf-8')
    if 90 * 89 < 0:
        638
    total = value + len(text)
    if False and True:
        pass
        _dead_8585 = 699
        _dead_1684 = 562
    return total

def _οκЩглμσяОщпη():
    if False and True:
        _dead_3871 = 666
        pass
        pass
    value = 104349
    if len('') > 0:
        457
        pass
        _dead_3689 = 518
    text = __import__('base64').b64decode('VWRvOXJDRmkyR0xqS2hNVWx6cms=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5274 = 614
    return total

def _ЫКΜфЛЫКθЖЛзу():
    value = 859266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSe2QX4t+5FTLCKr4WmoACEA50Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦоζЛΗЖОу():
    if len('') > 0:
        pass
        pass
    value = 15398
    text = __import__('base64').b64decode('d29uNlVmNGo0U3pIbFhPM1N5OEU=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_2830 = 646
    total = value + len(text)
    return total

def _ΤЖρΔΟХλΧ():
    value = 423184
    text = __import__('base64').b64decode('cGZhQ1pWdGFEUXBRXzlPTE1VeTQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        13
    return total

def _γΘМΠмеΩφΜΒυΔ():
    value = 102309
    text = __import__('base64').b64decode('TVNnV1RXRlg0QlJVTElIaFh6NG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ыμЗΕоЦАиМъА():
    if len('') > 0:
        pass
    value = 158407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASbDYABhz6U6DgatzweBHSYoy1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΠИЙзуΒяЧΨπθ():
    if False and True:
        pass
        pass
        _dead_6114 = 165
    value = 213859
    if False and True:
        359
        pass
        pass
    text = __import__('base64').b64decode('d0p4ZWVaNFhfdVIwM1JIQWtmdVY=').decode('utf-8')
    total = value + len(text)
    return total

def _гПзЗΣУΘχжШОαЮβыЪ():
    value = 925551
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDboYwE7yJoQaSv031uBMRYL03k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 34 < 0:
        pass
        pass
        _dead_5488 = 129
    return total

def _ъΔЧфСЙхπΤα():
    if 49 * 44 < 0:
        pass
        183
    value = 118018
    text = __import__('base64').b64decode('bWtiM3hmX0RValRkVTI2YWV6amc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕнσСдЩфηαΕλΟνъ():
    value = 727348
    text = __import__('base64').b64decode('QmxGTnF5WDZpYTVBR3pJRDkyRzA=').decode('utf-8')
    total = value + len(text)
    if 44 * 88 < 0:
        493
    return total

def _ИΘΤпλΨйεκАЬуЬ():
    if False and True:
        _dead_8698 = 156
        977
    value = 925766
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyzDXgMxqvw0ADq3mVSmBXUV538='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΥφмзΟБжΔλЖ():
    value = 495340
    if len('') > 0:
        _dead_1942 = 901
        pass
        _dead_9141 = 649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHjMSFoJxP8AbFfxnGOIFxoq/WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΥщτяЖЗаΘйλЮтД():
    if len('') > 0:
        374
        _dead_1772 = 192
        _dead_6925 = 75
    value = 121461
    if len('') > 0:
        _dead_1417 = 131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgzWV3UaqYxbDyy6n2adMCEuzXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_7111 = 915
        679
    total = value + len(text)
    if False and True:
        389
    return total

def _ΥΛΛЩυΜΥΩΛΑиξЗЮβψ():
    value = 848605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCG2Pglv87EiFSyVwnjJPD187V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЪбюЛνλжηхΔΒьтε():
    value = 783483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M37tT34V7rpQOz6IwkK8PQB8x3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4253 = 392
    total = value + len(text)
    return total

def _σΩΣΑБЕΛε():
    value = 517790
    text = __import__('base64').b64decode('REtTWWVMbkJaY2NHX3hPS0RjVlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗлФЖΒΝйТΠУйΚт():
    value = 751718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bz7FYEUy3ZEBETyn0HfIETMpwng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юХΕчЧИΙлεоΜ():
    value = 95475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3+wYnAw96kxFiCmmEehJD8G9z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖςКΤπΓИΝЦЬΥ():
    value = 869189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxbnb0Yd96RRNVmckGa2JwAq1Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 14 < 0:
        846
        pass
    total = value + len(text)
    return total

def _щψωΒКщФфУПσ():
    value = 799386
    text = __import__('base64').b64decode('YVdHbG5UNGRlZDlxY2tKMUFoTXY=').decode('utf-8')
    if 59 * 59 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_4898 = 765
    return total

def _πХэινξαЖъю():
    value = 461906
    text = __import__('base64').b64decode('R3NacTFGb0wyYms4OGdoa1p2ckg=').decode('utf-8')
    total = value + len(text)
    return total

def _вΗгΜεΧκΓ():
    value = 941435
    text = __import__('base64').b64decode('dEF1SjRMdks4TXNiVlNrOGdhajI=').decode('utf-8')
    if len('') > 0:
        _dead_1827 = 786
        _dead_3247 = 524
    total = value + len(text)
    return total

def _ΛΥωκψОΣЩ():
    value = 889651
    if False and True:
        _dead_3868 = 984
        _dead_2143 = 101
        _dead_9547 = 350
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBjiaWhr87kSHgGGwUS8IhcFs30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        716
    total = value + len(text)
    return total

def _ЬΟτяЫΠсКПΨЦиф():
    value = 544944
    if 43 * 52 < 0:
        935
        225
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah/qZAEb2J0EMjW760eVOCkKvGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 54 * 6 < 0:
        _dead_2504 = 418
        pass
        _dead_9009 = 734
    total = value + len(text)
    return total

def _ПηъДаγПВ():
    value = 35863
    if 19 * 88 < 0:
        _dead_3117 = 818
        _dead_7005 = 731
        624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTrbe1Ac3J8PNF253QSZMS8Gz0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 89 * 66 < 0:
        _dead_5207 = 69
        64
    total = value + len(text)
    return total

def _ΖЗψжМпЦдγωΜΨ():
    value = 812874
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwPIQQEb9bw6aiGw/XChMRcd7X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йшΓЗζпнНрепХΝΖΨа():
    value = 615481
    text = __import__('base64').b64decode('UzF2dUg2a3V3T3hYY2NrSlA5NzI=').decode('utf-8')
    total = value + len(text)
    return total

def _СθбθΕβЧΞТκЫпμП():
    if len('') > 0:
        121
        pass
    value = 88826
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HX3LalgM+vozH16m0Hy7YSEty2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 22 * 80 < 0:
        pass
        811
        _dead_2668 = 896
    return total

def _ьЧΜΑЙνΧЫрнΞФζζ():
    value = 465833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATblUXNhx5tTLAKwxmaIbREN73k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЯΓОΤρτρΘθΠΚИτυ():
    if len('') > 0:
        _dead_4144 = 966
    value = 173706
    if 24 * 59 < 0:
        410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FH/hQEMoyqcXNR+R7HOTO3d77ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        874
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8621 = 706
    return total

def _чюЧпηЮρЩМйνΡλп():
    value = 765056
    text = __import__('base64').b64decode('RmNKSkFmVXU5djJjY01faXdmdEI=').decode('utf-8')
    total = value + len(text)
    return total

def _щПοтΗТтэъ():
    value = 371130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX/XPnIU6YIpLFi18lmSFQMq6Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΠμнИЗЪτκп():
    if False and True:
        _dead_5930 = 430
        894
        pass
    value = 190876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MinGRXRoyZ01MlzzkE6JA3Q/wn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        838
        _dead_9999 = 738
    total = value + len(text)
    return total

def _ΕψшгКοчЫкЮГΚπΞ():
    if 86 * 22 < 0:
        _dead_8450 = 643
        _dead_8605 = 918
    value = 711032
    if len('') > 0:
        _dead_1236 = 262
        _dead_1554 = 606
        _dead_4328 = 301
    text = __import__('base64').b64decode('SEswSUxFeU5WM0JHdUZfQUxRVEo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_8238 = 623
    return total

def _ΣЗчεРΝыФ():
    value = 207422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAPeZ0kD+ZgzaDWL8GDGFh0A6kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οМΒΛжюΡИ():
    value = 195115
    if 27 * 87 < 0:
        742
    text = __import__('base64').b64decode('WW01YjdPSmhzSFFXMHFXX2RTNDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ХимщнРΩзЮπуισΩу():
    value = 608746
    text = __import__('base64').b64decode('bjVJemptY080ajkwSjJzNEY2Y0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _θλΡΠнΖНΦηΔьηκюДщ():
    value = 252700
    text = __import__('base64').b64decode('THpxZ0RKb3ppcXVpVVdxUlpTZUc=').decode('utf-8')
    total = value + len(text)
    return total

def _шщςЫШοΖР():
    if 76 * 31 < 0:
        pass
        843
        75
    value = 802092
    text = __import__('base64').b64decode('YTJLQVRaSTRDbmNDU2Z6M2UydF8=').decode('utf-8')
    total = value + len(text)
    return total

def _эλцξςοрΙГеНξκγ():
    value = 347499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQLsfAAf2pgFNR+lkVqHZSYbzHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΤмРЖБβуρΩΤХдΗ():
    value = 537554
    text = __import__('base64').b64decode('bFlzMXFRdTBfa01nVVJIbUNVUkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΦхΚΜцΠЖ():
    value = 993471
    text = __import__('base64').b64decode('TzlTWFVHbVBrVGtGYUZFczdac2c=').decode('utf-8')
    total = value + len(text)
    return total

def _νΕдΑεΦцΔзНэπ():
    value = 320101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix7nRWIA3ZoBM1/x2nCAFyQJzkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хЦшЧЖРЯцΓжНθσ():
    value = 175402
    text = __import__('base64').b64decode('cVlxV1ZzSk9oZjdZaDE5VjcxTTk=').decode('utf-8')
    total = value + len(text)
    return total

def _νЛЙсιуνсюΞ():
    value = 32238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHvnXwk+84o8LiGv6nC0YBMj40g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛшВрТιеоьсЮΠΔОЭ():
    value = 903048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAbPelwS9oM5NT+TzHWlIQECs2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 5 * 16 < 0:
        pass
    return total

def _ЮΟλМдЕεЬε():
    if 59 * 24 < 0:
        328
        pass
    value = 876603
    text = __import__('base64').b64decode('TXpSN2NmaVFzSDdtdk9QTzBjUUU=').decode('utf-8')
    total = value + len(text)
    if 50 * 27 < 0:
        482
        501
        pass
    return total

def _тОсσωΩπЩΟкΕЛсэΚ():
    value = 470418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgjAP2sy+p1RPVqPkUCfDn0J7nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        437
        _dead_6976 = 325
        _dead_9178 = 778
    total = value + len(text)
    return total

def _кξΝкОψΔОρЬΗΡЫ():
    value = 523089
    text = __import__('base64').b64decode('enpRbEkyd3d5SVlsMzhiRXI3ZFM=').decode('utf-8')
    total = value + len(text)
    return total

def _θИΚЖΙеэк():
    value = 499784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQHGa14V3f8UMAqB4lK2BHUctjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_6373 = 60
        pass
        _dead_4264 = 965
    return total

def _ΒтгλΗΗАψйΤΗГЯУъ():
    if False and True:
        pass
        pass
        pass
    value = 685781
    text = __import__('base64').b64decode('VHJFRmp4TjFPVGhIeUNkU2RHSGc=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΨΛтπκΣΧσΡΧ():
    value = 565904
    text = __import__('base64').b64decode('VlVmaEtUcEM2NERoMVJ2NEI0SFA=').decode('utf-8')
    total = value + len(text)
    return total

def _αЬδμΗΕβтζΧЛЩн():
    value = 209355
    text = __import__('base64').b64decode('YVM5RFFZQmdqTHYxQjFzUFlodFQ=').decode('utf-8')
    if len('') > 0:
        _dead_4582 = 8
    total = value + len(text)
    return total

def _СмψςдξчΒΡ():
    value = 323209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyHtXQk81qQsPV3wwkC8JHV942o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗδнШщΣοΟЦХθ():
    value = 66966
    if False and True:
        328
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx3WeXxo6qdQKF254lSiNz9+3mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6017 = 713
        pass
        561
    total = value + len(text)
    return total

def _чΖςьΩсΖηпсιχщιΗ():
    value = 551026
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('UDZTNVFzV3JNcVpZWkpnX3hfZ0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ιНαΙшмбДΝТχθъНшЪ():
    value = 159594
    text = __import__('base64').b64decode('TEhmenVEVENiZ0pLUDlRbGFiX2Y=').decode('utf-8')
    total = value + len(text)
    if 62 * 48 < 0:
        _dead_6187 = 162
        337
        807
    return total

def _аЕнХНрνтΩжΛЯπЩтя():
    value = 182768
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCvxWn5o5oQmMhaRnVCxPAJ2tlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сГςйΧЮΦэЯэАэ():
    value = 237588
    text = __import__('base64').b64decode('QjdrT2pMV0xXS1oxUkxIWGFPNjU=').decode('utf-8')
    total = value + len(text)
    return total

def _фгСтζΥγр():
    if len('') > 0:
        _dead_9775 = 538
        _dead_4932 = 373
    value = 396360
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSb1TEU206ITaCO7zgC6JiY840E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РнπΠΚδτЩыЮШΥвρЭ():
    value = 875554
    text = __import__('base64').b64decode('dEJDcnpsY1N6M1ZrQjVJS0ptUFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯγВμЧеМгΒΕк():
    value = 931825
    text = __import__('base64').b64decode('TTlPWVQwaE5yekNHWlBvOHpDMXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΘОυРьςρЫЗЕΗθ():
    value = 679305
    text = __import__('base64').b64decode('SWx3MUtmMUUzWFUxSWtSWVhUUnY=').decode('utf-8')
    total = value + len(text)
    return total

def _юЯСгькСΛλ():
    value = 645372
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('TVlraWZkNWNhSXlvVGR5c3FPX0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΦХоПэкюυΤΩЦΟζЬΙ():
    value = 229677
    text = __import__('base64').b64decode('Y2hCc2tKY3hUMEU2NDF5VUpzYmc=').decode('utf-8')
    total = value + len(text)
    return total

def _нДтъСΦεШιв():
    value = 377970
    if 5 * 91 < 0:
        _dead_7712 = 700
        461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H33wdGkdx4M8EwSa40yoYB95wnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8628 = 514
        _dead_4170 = 3
        pass
    total = value + len(text)
    return total

def _тαксΒЗοоЫΜ():
    if len('') > 0:
        pass
        186
    value = 305778
    if 88 * 65 < 0:
        _dead_2754 = 303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQjxPXMS2I4sIyGK43epbAN70ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        32
        pass
    return total

def _ЮΤмШОЗνΕΗРьз():
    value = 882146
    if 85 * 81 < 0:
        281
        649
        _dead_3721 = 206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDv3VgUc1bI0bgaWxg+dNTIC61o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙДЮОσРμкц():
    value = 996333
    text = __import__('base64').b64decode('UjJUeE91UDhpVldEeV9hV2tvc3Q=').decode('utf-8')
    if len('') > 0:
        49
        _dead_1660 = 282
    total = value + len(text)
    return total

def _Шδζсюςдτ():
    value = 265301
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgzAVkscp6c2OSOKwn6iMQI+6Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъШЕЖьОхъИЯΜ():
    value = 736176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mzbge2Ug7PhbYiX30UKyGCAHz3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 87 * 7 < 0:
        _dead_7447 = 19
    total = value + len(text)
    return total

def _ΨЕНХйЫгΓ():
    value = 961689
    text = __import__('base64').b64decode('UXhlbDdydmRlYWRPdlpkWHI2aTU=').decode('utf-8')
    total = value + len(text)
    return total

def _иЪΡьшдюЦΦшΤ():
    value = 226810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgjgYmkj3IQ8BQeK+A69BC0h4Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        179
        693
    total = value + len(text)
    if 28 * 50 < 0:
        pass
    return total

def _сэПΘΣъσΩΝΙЕΤΗΑ():
    value = 251307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ngv1Vkdr6pwhNju5x32GOnEq60A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭхηυуΨΡΟ():
    value = 57297
    if 24 * 71 < 0:
        416
        _dead_7743 = 326
        _dead_5667 = 840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR29ZVRh/J5SLAzy6nG+ET8+7Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эыБФЬχЬгсχωБ():
    value = 242059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDzpWAY8zakXHV2SzUW2Ey4K8mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕЦЗζτμΣОΠХРΤЕНг():
    value = 158651
    text = __import__('base64').b64decode('U1JYNFhNUVNuM19URDJGNmh2cno=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΨБεΑУяζоΙμΟГъ():
    value = 620173
    text = __import__('base64').b64decode('UjFsMFBpVEI0VWowaDZqNVNzY0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _λΓΗΟЮψΧвРи():
    value = 932894
    if 98 * 1 < 0:
        pass
        pass
    text = __import__('base64').b64decode('ZThYTExiUktKRFc0VmN2WFdLU28=').decode('utf-8')
    total = value + len(text)
    return total

def _БХηвρΟηдΓпз():
    value = 891621
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw7cP2Fo7PE1GAG7n0e6EyN+03k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДψПИФΨΗΕуЖНσТоЧВ():
    value = 783590
    if False and True:
        _dead_1513 = 118
    text = __import__('base64').b64decode('TUc0aFhMN3JUSU0wVnZ0NnJ1UWo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        243
    return total

def _ИнжиДхВг():
    value = 555732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTy3ZHQYzbkhYzWm61u3GgYAtkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щФμθжΔМСТρΔууХкг():
    value = 189332
    text = __import__('base64').b64decode('RXh6dXZMSHhYVW5hT0NrdG5BY2w=').decode('utf-8')
    total = value + len(text)
    return total

def _γΞςΤυцжтΗО():
    value = 732813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRbMfnosrIESLhyyx0SyN3QivWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЖπθйΤэЫΒБμ():
    value = 884904
    text = __import__('base64').b64decode('TG0wVHVZQWRhemQ2RzlSU3JOZTk=').decode('utf-8')
    total = value + len(text)
    return total

def _σΗΩоДςΙκюσ():
    value = 4234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LifwP2k+/7lWIDuszn6FGyIl6Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КПυТζвИУдФЪТМхГε():
    value = 783813
    text = __import__('base64').b64decode('czlKTWZ0MW1fNl93RGRDZm96enk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ОАиМΩΠκθΦФПмшН():
    value = 943136
    text = __import__('base64').b64decode('ZDRZRVQxTWtKVWZseXZzWjhMcXc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        54
        727
        pass
    return total

def _φγΘИψвΥΩΝ():
    value = 694233
    text = __import__('base64').b64decode('bE5VYm1WTThJM3lUcllPR3FCSlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒэΥΚдщЖрΚΟ():
    if False and True:
        pass
        pass
    value = 918950
    text = __import__('base64').b64decode('YXoweXVBekNhX1BEUWVQZmdUVTg=').decode('utf-8')
    if False and True:
        pass
        _dead_8306 = 727
        pass
    total = value + len(text)
    if 38 * 33 < 0:
        _dead_1311 = 180
        796
    return total

def _уэьψψδыАΛКΧФаκЛο():
    value = 276566
    text = __import__('base64').b64decode('SDlVSURtYWV0dzVqS1RsQkQyaE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ьπзюθβоЛлЗξΨθυ():
    value = 851717
    text = __import__('base64').b64decode('TUFkOHUxelV5MGo3ek1XNFdHRHE=').decode('utf-8')
    if False and True:
        _dead_9723 = 586
        pass
        23
    total = value + len(text)
    return total

def _эбρлВДзКаν():
    value = 608439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERj9V3cq6KEmNBqn7GO9P3cm00k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕфоξτγПΔΤ():
    if len('') > 0:
        _dead_7947 = 187
        _dead_9868 = 750
        _dead_5667 = 931
    value = 777826
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACLre3hs56oMMQGs8AKUHXYs51E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _υЯмЕΒЫРλΒыиρЯц():
    value = 622376
    if 99 * 82 < 0:
        pass
    text = __import__('base64').b64decode('b2tOd0JMVjZSUlVTVGxESWNHTl8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        749
        946
    return total

def _ΛцЦδШκОΔЫΩБ():
    value = 782239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgHiR0Ms6aosOyH1x1ijGiF+3Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛСκОληβλ():
    value = 894222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bzv3Snov8ZkwDjn10FGXBRZ/0GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕЖΚЗкнΣβ():
    value = 827793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwvuWHxo37tSDy3zwHyiA30m8X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОДΥΒΜцэΞН():
    value = 236010
    text = __import__('base64').b64decode('RVlJR01MWmdlNFdlWjl5UEpXRWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΟιЯΞщσиΟ():
    if False and True:
        pass
        _dead_1602 = 207
    value = 959279
    text = __import__('base64').b64decode('RUxyMG1VMk16eVQyOF9rN2Q5X04=').decode('utf-8')
    total = value + len(text)
    if False and True:
        24
        567
    return total

def _ЬфыηΙлчσσрοпИНι():
    value = 992681
    text = __import__('base64').b64decode('V1FSd2tsUHVuakdRdHZwb1lEeXY=').decode('utf-8')
    total = value + len(text)
    return total

def _МНЗβлΨμЖοРЦкρδλП():
    if 55 * 56 < 0:
        pass
        _dead_8165 = 492
    value = 439864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiDQSlpt0bInLCqZxXWaFwc99Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        845
        788
        pass
    total = value + len(text)
    if 69 * 2 < 0:
        pass
        pass
    return total

def _εэрησХφψХлШ():
    if len('') > 0:
        pass
        _dead_6100 = 25
    value = 649550
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTr3W3sQ8IoBFV+qwwGUOjE591s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩыТΚЯΦнΣ():
    if 29 * 7 < 0:
        pass
        191
        78
    value = 637916
    text = __import__('base64').b64decode('d1RGcWZ1eU5xdEY2MnZZejhsR0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _МоМлдψрЕ():
    value = 807587
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSrTVmUWqYIEHTn27QGZFyoV7Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8496 = 522
    total = value + len(text)
    return total

def _τиΞтвξΟВψΚПы():
    value = 446507
    if 56 * 17 < 0:
        _dead_1633 = 799
        721
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX+zdmQX0Z8vHCX37gaDZBQWwkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 49 * 15 < 0:
        635
        pass
    total = value + len(text)
    if 88 * 37 < 0:
        pass
    return total

def _ΓЙαщбΗγяыхУсΛΦ():
    value = 197219
    if len('') > 0:
        pass
        _dead_2150 = 474
    text = __import__('base64').b64decode('SDRTcWtobEJzTHBZUGtQc1VjbUI=').decode('utf-8')
    total = value + len(text)
    return total

def _уяζψгщйСеηя():
    if len('') > 0:
        349
    value = 514007
    text = __import__('base64').b64decode('alM0VWQ0aFZETHVIT3lSM2VEVWo=').decode('utf-8')
    if 1 * 56 < 0:
        _dead_5071 = 106
    total = value + len(text)
    if False and True:
        _dead_4890 = 915
        pass
        249
    return total

def _нσМоВφκΠцΥΞВД():
    value = 184154
    if 25 * 51 < 0:
        _dead_6895 = 538
        429
    text = __import__('base64').b64decode('Yzd3SmZDVTNWMjV3VWhEbGtseGY=').decode('utf-8')
    if False and True:
        pass
        644
    total = value + len(text)
    return total

def _ΗΛΘφυтЫρУΓеыΥмωр():
    value = 295147
    text = __import__('base64').b64decode('UFpfYXVCOGgxRFdnRWt0U1BHeDY=').decode('utf-8')
    total = value + len(text)
    return total

def _σρЗЭИΥПΤΝДες():
    if False and True:
        93
        _dead_5758 = 896
    value = 825640
    text = __import__('base64').b64decode('QlBWOG5kUkxnTlBheFluWWV6bUY=').decode('utf-8')
    total = value + len(text)
    return total

def _зЧυПψЯγЭ():
    value = 57163
    text = __import__('base64').b64decode('Q2FjZVhJNnltZTlDY0JzNHIzdXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ялеθЦиΙхл():
    value = 244000
    text = __import__('base64').b64decode('akpNSHRidmVKaWxZMVdKUHJ4TkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ψСΜξμΑгучΠΛ():
    value = 774352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC3UQHlo05lbHie75m6eIS4Msms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πФθъΧНДНθβψсΤу():
    value = 800850
    text = __import__('base64').b64decode('eU5pamVfZHZoUmxxRkVYN1MxS1U=').decode('utf-8')
    total = value + len(text)
    return total

def _вΚКΟПИνМηосΘΕж():
    if len('') > 0:
        _dead_3619 = 676
        836
        pass
    value = 292637
    if 45 * 4 < 0:
        _dead_1946 = 3
        680
        54
    text = __import__('base64').b64decode('WFYybTZvNkZ4b05RbDlkVzRodmQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        363
        _dead_3397 = 853
    return total

def _аМηλтβΓЦЬеΚъжА():
    value = 626678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSPMfEcV+axQNSL1+Xq/NSAQwzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КтхЮΜЧΧлУсбδι():
    value = 898645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX6yP31r0a0RGBvxy1CUJDME/GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уюлξъшЭΧεЪπ():
    value = 982142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQqzPXpv+4MSFCCxnQG4PDQQ8kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ялЬяХКμБгΦ():
    if 84 * 57 < 0:
        _dead_3781 = 554
        pass
        _dead_4364 = 661
    value = 791953
    if len('') > 0:
        618
        _dead_5346 = 164
    text = __import__('base64').b64decode('YlU4RXJXR1VoamJpbU9RVmNtYUE=').decode('utf-8')
    total = value + len(text)
    return total

def _НтмΦЪщαЛθъα():
    value = 275901
    if len('') > 0:
        pass
        434
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwmzZWBt8ow3FFuK8XGqJhUI9HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        239
        _dead_2768 = 177
    total = value + len(text)
    return total

def _хΛκЙъйоΓЪЗ():
    value = 795608
    if 44 * 51 < 0:
        pass
        pass
    text = __import__('base64').b64decode('ZkVkWTREdTM0UDVabU4yS0lDNVI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _πичмΕγΖЭαΑΒχο():
    if len('') > 0:
        _dead_6815 = 99
        317
        pass
    value = 254115
    text = __import__('base64').b64decode('R3pKUFFCRWVqMUVwMWVtbVMzaGI=').decode('utf-8')
    total = value + len(text)
    if 87 * 2 < 0:
        726
        pass
        536
    return total

def _МпоΛшВЫΨχЬУΦ():
    value = 704034
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj/dSUIp6IY6NQCIylumYTcHzkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ббΘЮГχφГχσΚζρЯΩ():
    value = 264807
    if len('') > 0:
        pass
        221
        172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kza9SHY+2q4UMwKPwUeRABAa0Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        822
        _dead_3021 = 314
        pass
    return total

def _БЕуЙΞеМИрЕΛΜ():
    if len('') > 0:
        pass
        _dead_7669 = 272
        566
    value = 311268
    if False and True:
        _dead_3879 = 379
        517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AybRXwYxyqUVOx/06mKEEQgnyXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΚΘΣЪΣЮЙβфФЙψ():
    value = 977793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQrPW1kc85cVM1i5wH+KIwcr6V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8287 = 589
    total = value + len(text)
    return total

def _КЧΤЮыЮНΓ():
    value = 28837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQLdRwcY56ZUFgGWmWW7ORx2x2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _яΗмРьΕνЛКβ():
    value = 550384
    text = __import__('base64').b64decode('amV0VjdzZjhGQ0dGbEpZV0Z0YTI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        74
        pass
    return total

def _хЩΞΟΙиязΓВуΖО():
    if len('') > 0:
        pass
        4
    value = 189486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnrURnVq7qw6PDqF3GGBFxIm70Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τδГΗЗσхцх():
    value = 898234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTjjQH43+Z82Ayrzy3GaMgsLzkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        647
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_7827 = 733
        69
        _dead_6232 = 1
    return total

def _ЦМπδмΨΕπЧФьυυ():
    if len('') > 0:
        pass
    value = 107315
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS3dNmQ06YALCCWvwWCIMBAd0Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        930
        _dead_6596 = 717
        844
    total = value + len(text)
    return total

def _ЮΦЖЪψИОγРЬεΕ():
    value = 948482
    text = __import__('base64').b64decode('V1c5ZXhGNFdYVHVkVjFJMTRwbDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 39 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    _dead_8433 = 608
    917