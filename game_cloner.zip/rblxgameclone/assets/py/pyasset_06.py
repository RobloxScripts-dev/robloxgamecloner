#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _μгжσФωΒШσ():
    value = 871369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3b0XVNu6boCPiiO31XCNjwYsWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωуψιξΦхυ():
    value = 361890
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('Yl8yT3FfWWEyYkNvVVBvTjRFM0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЛηЭВπςωρψиγДД():
    value = 164747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQD8floMyf9SYzuNnEKfDgABzUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        707
        pass
        506
    total = value + len(text)
    return total

def _СзρΥΣζΕЫзЗζЩы():
    value = 50480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECa3OGs397wLHyOL3WeBZxw95T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        999
    total = value + len(text)
    if len('') > 0:
        _dead_4440 = 59
        pass
        _dead_9908 = 336
    return total

def _зЯΒΟаГясфиЬь():
    value = 937770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxroVmcI36MyNAGMwnCibAMo4Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 58 * 92 < 0:
        _dead_6291 = 440
        _dead_6217 = 105
    return total

def _ПΩдфΤγκκγлзΛ():
    value = 758421
    if len('') > 0:
        pass
        164
        941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXvqYHc4pqMMPDv7kF2CPgF4vFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИβщвШΕоЖοа():
    value = 30837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhbrQ1Zq3/tbDiy24g7AIXJ2y38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓрЦΗςθΖдΥΞхδΞЫκ():
    value = 944488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwXPWlA0y58gEyCs8FC2JTws9jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΨΣЖБΩθВ():
    if len('') > 0:
        506
        741
    value = 627506
    if len('') > 0:
        _dead_6121 = 613
    text = __import__('base64').b64decode('cGlITFpBR3NudEFPb2NPSlNmUHc=').decode('utf-8')
    total = value + len(text)
    return total

def _πЫΣΝυΝзгΗΜΡΙПф():
    value = 646834
    text = __import__('base64').b64decode('Y0trbG1VQWRZYWRrdHFTMVB3MzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪеемРЬТθΛМЬ():
    value = 816321
    if len('') > 0:
        866
        _dead_6440 = 472
    text = __import__('base64').b64decode('bzJ2c3FpWnpLN0RVUldZN01aUkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ОβЯАξПаВгΗЛрΑХЫ():
    value = 81382
    text = __import__('base64').b64decode('TVhpZWVhdE1YUTdhVzJuR1ZnTjI=').decode('utf-8')
    total = value + len(text)
    return total

def _βпΨъгЫЙЛмИыζйттГ():
    value = 910751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhvDVHkbqIdRDiv2/XmpLScF5V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΒцζежρхщυшПχв():
    value = 797071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgzKWHI6744ADzeTkVzJZ3wI7mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πφΑзΒпβнШιЖΨτ():
    value = 621756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3rNNgUj0KosCwCJ6lOHMj0Iwz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        339
    total = value + len(text)
    return total

def _ζοθСΘΩьЛщ():
    value = 148411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgLAaG4orJwoAAyZ4AaYHBIY0FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩНЭΝТφτθЮнгцщ():
    value = 578939
    text = __import__('base64').b64decode('dDc4N3Ntc3N4UGE1U2EzZGR6aXI=').decode('utf-8')
    total = value + len(text)
    return total

def _рζεστολсбГа():
    value = 137469
    if len('') > 0:
        _dead_2916 = 252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Di7nPVI9wf8HMyat/Gy2GTMM4Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_8324 = 556
        _dead_7832 = 73
    total = value + len(text)
    return total

def _БμσγФΜНТΤшδΓΟМΔ():
    value = 693650
    text = __import__('base64').b64decode('V0FQUmtsY3hoV0xZYXdQbERTME0=').decode('utf-8')
    total = value + len(text)
    return total

def _пεРСюйдюφЖ():
    value = 249046
    text = __import__('base64').b64decode('Z0xmZmJWekNmRERYeVFHM3oyVEk=').decode('utf-8')
    total = value + len(text)
    return total

def _χΣЦνЯκγэЭδАΓдлΚΠ():
    value = 838743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHi8YEE2qJEkbDiA8WOGDDAHzW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 88 * 34 < 0:
        _dead_1660 = 891
        pass
    total = value + len(text)
    if False and True:
        _dead_3968 = 860
        _dead_1502 = 706
        pass
    return total

def _ЕПΜГЭвΛΝСКгДΒ():
    value = 810435
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXqwV0Mxy/AIaFqbnmK5FiEuwVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΙбЭЪчνΜФ():
    value = 790342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB23akYpzfo2YzuW+HqAIho71mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΩΦщЩрЮμΘΔжδ():
    value = 327545
    text = __import__('base64').b64decode('T2JmYzJwQUZuZ0owYnJpZ3NDTlY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮшνпεηсαйγЭ():
    value = 752076
    text = __import__('base64').b64decode('bnJSTVBBZFpvMmRjNk5kWER2TGw=').decode('utf-8')
    total = value + len(text)
    return total

def _гтеККЕюηТρаιπλчΡ():
    value = 182805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjvpbXcXzoRSMDCckQW/HSkF9lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οζΛБеэнΨиФΜρРоюы():
    if 24 * 84 < 0:
        _dead_7413 = 661
    value = 612972
    if len('') > 0:
        _dead_5458 = 640
    text = __import__('base64').b64decode('bjA0eExGeHBNZ3FDczJ5VVRMbmY=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ОкιηМΕЧωЕеΙξМЯСε():
    value = 562944
    text = __import__('base64').b64decode('d0IzTVdaUjgySFBpbU9ibGdHN2g=').decode('utf-8')
    total = value + len(text)
    return total

def _АΒэπХГκλΥмШ():
    value = 283532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQDie0cr9J4AAlmk/n+3ACY44m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΥΖГΚпΩбΣЖΘσХМφ():
    value = 724550
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ijj+YQEO56tXKzzy0V+fZx92yXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νуЗΘКΦЦΛΩЦКДД():
    value = 529771
    if False and True:
        67
        pass
    text = __import__('base64').b64decode('WjRSWlJ1TGljenpuUFlsRjJjdDE=').decode('utf-8')
    if 47 * 32 < 0:
        _dead_3790 = 344
        _dead_4376 = 461
    total = value + len(text)
    if len('') > 0:
        _dead_8396 = 280
    return total

def _ΙХгθΟйΚΜ():
    value = 389204
    if False and True:
        971
        _dead_2379 = 762
    text = __import__('base64').b64decode('QnpvOHBEQW5XdXpkYXF5VEFNWTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗМξυψЦТОδΤΞΗЪссΕ():
    value = 523705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxW2eFc+z4UobRqc7HWcMAY66ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κзщβηθΒЛпЛфиЙ():
    value = 767523
    text = __import__('base64').b64decode('ZERWNTZTUHlocnRkSlNMYzNQU2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙчιРВιецμф():
    value = 661413
    text = __import__('base64').b64decode('allFN0ZrSE1UNzJ1b0ZLYjdVR0k=').decode('utf-8')
    total = value + len(text)
    return total

def _φυερдВНа():
    value = 880236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITXceUJs+bEuIlmQ2X7GNyogzUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШьольРШВΚΘλ():
    value = 624293
    text = __import__('base64').b64decode('YUxONU5FNnZYb0xiaFdfa0VxUTI=').decode('utf-8')
    total = value + len(text)
    return total

def _КсθгеьъΥτЫΔиωра():
    if len('') > 0:
        _dead_1117 = 750
        pass
        954
    value = 526359
    if False and True:
        _dead_2327 = 20
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3rXawMpyp42aFe03UPBJy888X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦаюшЕХωΥ():
    value = 721098
    text = __import__('base64').b64decode('TkNOTm5kcko1MUNYak1rbnZKa2E=').decode('utf-8')
    total = value + len(text)
    return total

def _αхъюЪЕщιθм():
    value = 148068
    text = __import__('base64').b64decode('dF9HT2lfcU5CbEFwRlFYWXNtZWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЪенЛκΞφγъ():
    value = 889610
    if 87 * 66 < 0:
        _dead_5099 = 819
        121
        _dead_1401 = 855
    text = __import__('base64').b64decode('ZFl1RjVhcXFNV3VkVlVpYmJJNk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ωоΑЙσнΡИΥКщ():
    value = 828577
    text = __import__('base64').b64decode('YWlHSUw5NUF5SDVscnN3R3NCenk=').decode('utf-8')
    total = value + len(text)
    return total

def _ωМυαяθлЮΧЖчП():
    value = 589821
    text = __import__('base64').b64decode('bktWc3NKZkVWWGpNdURoaGc4bDg=').decode('utf-8')
    total = value + len(text)
    return total

def _иЛΦШΗрρХΕРЖ():
    value = 852771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBnTYUE6q5EKHTeI/H+aIDR+wkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΓдЖΧνμθЭ():
    value = 330868
    text = __import__('base64').b64decode('aFN1VEVzamh4cmFwTlRHbktCdzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜэνмЩЖБэЪиъμιл():
    value = 302007
    text = __import__('base64').b64decode('dnlxSmpQdHhKRTJrZTBzQ21vc3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЦУъЙКχιΔ():
    value = 825967
    if False and True:
        220
        _dead_6143 = 932
        pass
    text = __import__('base64').b64decode('Rlk5ZGVFcVg0VGRDYW1wZ3NhVXk=').decode('utf-8')
    total = value + len(text)
    return total

def _χЫΙρКξТмιΒд():
    value = 278652
    if 69 * 84 < 0:
        _dead_3956 = 778
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3zQZGAr7bARNxr1+H+4Zg8Ctj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΟяСΠЩГΒ():
    value = 658606
    if False and True:
        _dead_3207 = 180
    text = __import__('base64').b64decode('blFPc2JVVmZpYmVYSEVoM2JuZjg=').decode('utf-8')
    total = value + len(text)
    return total

def _κЧφθφЙэαβ():
    value = 218414
    text = __import__('base64').b64decode('SnE3S2VqN1hLbFNsdkZRd3UxNTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ρсΚУЕыЫЛЩΜΑΟз():
    value = 933584
    text = __import__('base64').b64decode('VzdGQXlTNFc5UDN2U040UU1ybXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΑΟςямВяγ():
    if len('') > 0:
        _dead_7139 = 111
        pass
        _dead_8861 = 104
    value = 494560
    text = __import__('base64').b64decode('UTFpQzRIWVBZeWJjaE9fRFNEM2Q=').decode('utf-8')
    total = value + len(text)
    if 39 * 48 < 0:
        880
        pass
        _dead_5710 = 597
    return total

def _ΥЗΖЫиΕΣъфιΞχщΥΟ():
    if 50 * 80 < 0:
        pass
        970
        _dead_2704 = 107
    value = 821903
    if len('') > 0:
        453
        _dead_2368 = 358
        pass
    text = __import__('base64').b64decode('ZWpNUzlJTHNnQWhDQlRJdWk1QVE=').decode('utf-8')
    total = value + len(text)
    return total

def _рцΨоρъξξПгг():
    value = 720978
    if 94 * 4 < 0:
        pass
        _dead_7220 = 239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyrCd2UYz78pYlz77HylHnAM928='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        43
        pass
    total = value + len(text)
    return total

def _ЭуΕоΣьΞфςЩ():
    value = 551179
    if False and True:
        pass
        pass
        pass
    text = __import__('base64').b64decode('ZGV5YWxHODlBTjN2MVFSal9rX2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓλиΟΥюйζкюΕ():
    value = 488557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR/SOloo8K1bFQyJyg7FIi8dyXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        982
        _dead_2960 = 276
    return total

def _ыκВКфεΙяТΣ():
    value = 620707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Exj1TAAW14AFPAyIwQHFbC0j1nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_8543 = 504
    total = value + len(text)
    if False and True:
        pass
        370
    return total

def _θтФНυыςсыЕ():
    value = 768448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kzr2SQc9+o4iCFyz7kCHFjA951E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣиПрЕΥΚИды():
    value = 545552
    if False and True:
        pass
        987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwPdPkNvx6k8MjW77X2qbBM770k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        912
        _dead_8327 = 332
        pass
    total = value + len(text)
    return total

def _ЭРицπЕΛэФСэцыПК():
    value = 65462
    text = __import__('base64').b64decode('V2dscmJoSXdVNVhHTGZuTGFQWjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΙЬъωеΒΜς():
    value = 12525
    text = __import__('base64').b64decode('bXk5ekVsOXFFODUwOUwyMlhKcWs=').decode('utf-8')
    total = value + len(text)
    return total

def _МΤРαзнρσЦзЯ():
    if False and True:
        pass
        367
        286
    value = 166790
    if False and True:
        509
        383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgDLYEQ3158oFiSiz2fBOjEXw2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρτйьηΩςωΥЕρΦΧШΟΓ():
    value = 459363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA7uZGA+x4MIHCqxwGe/ZjwC51g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ишφΤЩызςΧχКЯшф():
    value = 289474
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh/rUWQY850FEzak/Xm2NXYq1TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΝцΧЯυΒЭΓΦν():
    value = 590321
    if False and True:
        _dead_3859 = 82
        _dead_7426 = 47
        _dead_7909 = 799
    text = __import__('base64').b64decode('YzZ0RzBTVFJPZU9OcGxVVFFQUkQ=').decode('utf-8')
    total = value + len(text)
    if 86 * 60 < 0:
        pass
    return total

def _ЛμЮΧВΙММγΨΡпвΡ():
    value = 647356
    if 99 * 23 < 0:
        _dead_9959 = 215
    text = __import__('base64').b64decode('THZPbFNPQmJhQWE4eGhYSUpDMXI=').decode('utf-8')
    if False and True:
        747
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()