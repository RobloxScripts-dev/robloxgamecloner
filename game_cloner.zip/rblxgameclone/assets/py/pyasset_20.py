#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _оοαруШВηеВн():
    value = 911530
    text = __import__('base64').b64decode('am5ZWlVQaGNhREtDUDJwSXNqMUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ουΨΑΙжЦлΑχφΗ():
    value = 703294
    if 17 * 87 < 0:
        425
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSPuagdg9b5VKgH7zk+WZiZ+9ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΟСШυНЕамЖШу():
    value = 821142
    if len('') > 0:
        _dead_9140 = 785
        pass
        _dead_6831 = 172
    text = __import__('base64').b64decode('VEYwdHF4bjV2R040UG1lZm9NVEw=').decode('utf-8')
    total = value + len(text)
    return total

def _РΤΑтΡЛχлδζΠρ():
    value = 584322
    text = __import__('base64').b64decode('bDN4ek1mNVFxeUtseGJxSTNYd24=').decode('utf-8')
    if len('') > 0:
        163
        pass
        _dead_4823 = 396
    total = value + len(text)
    return total

def _ΙшЫρΞфЧΓχλα():
    if 84 * 85 < 0:
        pass
    value = 285193
    text = __import__('base64').b64decode('UktLaFhsM3lLWmFXZlVnT3Q2dmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖИБеКνЙъξоБ():
    value = 423728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESHIO3wazv06CAmhwHWzYHwi408='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        876
        _dead_5162 = 525
    total = value + len(text)
    return total

def _углЬцΕηζТΓΥκΙЩ():
    value = 347241
    text = __import__('base64').b64decode('em9uRWZBakNNS1d3TUZEZUwxU0o=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7913 = 478
    return total

def _ЯΓχЦΓлυξБСθ():
    value = 324478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDm9Q2Yoq5IPPlqm+QeBPhAfzmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОθυАμБнчΟφπъЪ():
    value = 796574
    text = __import__('base64').b64decode('TmI1NDR0TlFBVDBtQ1Rlb2JTbl8=').decode('utf-8')
    total = value + len(text)
    return total

def _κΖывЦιΒПΙρо():
    value = 3795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAy8N3g40b4vYzCs2UeiLSsN/G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖЮΒυЖЩлδγр():
    if 60 * 9 < 0:
        pass
        pass
    value = 932436
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KADSRWYGrYQiAiz7mVOxDR8Xtkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кЭςмтΤΞфΘьλζЧ():
    if 94 * 26 < 0:
        387
        204
        pass
    value = 52647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjfzaQgpzJ5WIFmo52GgZXAV4D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦЬЗЗРЫΝΩ():
    if len('') > 0:
        pass
        _dead_9471 = 198
        _dead_5928 = 41
    value = 152227
    text = __import__('base64').b64decode('QmRGZENqWWJpR3pXeVE3RDZkVXo=').decode('utf-8')
    total = value + len(text)
    if 100 * 79 < 0:
        517
        493
        990
    return total

def _βξεюΚеΜЙφзДΖкЫλ():
    if 12 * 83 < 0:
        _dead_8960 = 542
    value = 860115
    text = __import__('base64').b64decode('cm9iRWhnU0pJRGZaX2Jna2h6QlM=').decode('utf-8')
    if len('') > 0:
        _dead_2565 = 805
        _dead_9054 = 22
        pass
    total = value + len(text)
    return total

def _вфшУΙΓЗБΛу():
    value = 531615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3jgaQke8/8aaCz32UeUDCYsslg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕТШρμПκДΩпДημγх():
    value = 741174
    text = __import__('base64').b64decode('RkdRSzVpZEFJZUJHODA3dHVVVEY=').decode('utf-8')
    total = value + len(text)
    return total

def _цΟηΖεжιЭξΗмΨ():
    value = 771447
    text = __import__('base64').b64decode('VHpSUERvdm43YTFmZUNZX1VvV0w=').decode('utf-8')
    total = value + len(text)
    if False and True:
        938
        pass
    return total

def _нλмΨκшРΑЬΜΒωРЛΑΗ():
    if 90 * 72 < 0:
        pass
    value = 815094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwrGZ3sR1ZwiABv1zlSdZSsW5WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4131 = 845
        pass
    return total

def _ΤтνΒукΗтНпΞооψΣ():
    value = 586319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh7IbF4B3IQzKwKNykWgEQMg9jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηζΗЪУΦΚДГьςΟΑРЫ():
    value = 739944
    text = __import__('base64').b64decode('bF84ek5FXzlrMGVIWW5JM0dNMkw=').decode('utf-8')
    total = value + len(text)
    return total

def _вΘьπΡРТμ():
    if 38 * 86 < 0:
        _dead_6638 = 110
        _dead_3686 = 481
    value = 235553
    text = __import__('base64').b64decode('RDZEQ2FWRnRrcE8zV0NxbEp3QVA=').decode('utf-8')
    total = value + len(text)
    return total

def _юнτмΝψпиηЭΧЭмΙ():
    value = 584244
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAy1QWNv0J0IPQqw8HqvBT8svFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯβΔЪИкЯεγбυЛПбщ():
    value = 187537
    text = __import__('base64').b64decode('VE9FQ3F5eHdhN0ZrdW1hUGJLMTU=').decode('utf-8')
    total = value + len(text)
    return total

def _йАрьΥЦκЭЮ():
    value = 384350
    text = __import__('base64').b64decode('S09Md1FYMXhNM3Q2dTY4WEkxamM=').decode('utf-8')
    total = value + len(text)
    return total

def _ъхΧдδΜψτЕΥЛΥВЗ():
    value = 513919
    text = __import__('base64').b64decode('YjdsTmFJZEp5YzI5a1dacENESjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒбΟтΣбΑπ():
    value = 906637
    text = __import__('base64').b64decode('VHl6T0Y5TWw2RnRQVnljTWwwNVk=').decode('utf-8')
    total = value + len(text)
    return total

def _зθμПБНςπхК():
    value = 860593
    text = __import__('base64').b64decode('VmlCeVlmT3VQTVNabmllazhVaHE=').decode('utf-8')
    total = value + len(text)
    return total

def _θжνГπфЫЩΓνЮεтΣΧΤ():
    value = 986028
    text = __import__('base64').b64decode('S2x1NjMwTGpxYko5THphc0ljUnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЖЦЙΩΞрЭΥ():
    value = 16457
    text = __import__('base64').b64decode('Vm0xSTFVYVMyMmxyRGVVaTZmQXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ягРТРΒмэ():
    value = 577388
    if False and True:
        521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQHjRAct14cmABey4FGUOhQ4z0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        36
    total = value + len(text)
    return total

def _ТШζгтзАΛРСдΘн():
    value = 47601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQawSEYK9a8HMxa191ehLnY2vEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΞОνΚЮГйБРЫС():
    value = 774890
    if len('') > 0:
        336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSayfVYyqI4OIzu00QOiDj19/Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 78 * 75 < 0:
        pass
        912
    total = value + len(text)
    return total

def _ТρΘΘУΤакδУ():
    value = 584632
    if 73 * 12 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih7Vb1o176QlKS7xxnvBGgYh3lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЧξΡπЯΔМг():
    value = 598199
    text = __import__('base64').b64decode('UHZodDZnSjMwdEtDZnpJTHFjSDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜχΔншрьяЙΗαΩлΡΗц():
    value = 122588
    text = __import__('base64').b64decode('QTFwWVRiZlNKQ01WU2VOOHFqZ2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΨΨзΤЧфк():
    value = 130224
    text = __import__('base64').b64decode('cVRsYnZsVlNJWjQ2Y1ZXNHoyeTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡеГРαδяСущΥвΗλед():
    if len('') > 0:
        538
    value = 348847
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwvHOGA4r/wNDgGk8ny/NSII20Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 69 < 0:
        317
        328
        pass
    total = value + len(text)
    return total

def _чАβхΟчЫμЯΜΡ():
    value = 422100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3fxWkkp64wSAiiL+3SYMAMetWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЧиСЩГуταΧщ():
    value = 618515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzrKTHsxqYA7HDCW/EGWIHAQ6UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХчαьТКХηюζЙΩХ():
    value = 491516
    text = __import__('base64').b64decode('a0dnZnhsTklRaTN0cjNQYWhPNHk=').decode('utf-8')
    total = value + len(text)
    return total

def _οУΠΙΙΨΖΣрСШ():
    if len('') > 0:
        889
        _dead_5776 = 41
    value = 97381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LS7rWAUOwf0NCRzxmFK6Exokwlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 55 * 59 < 0:
        _dead_7860 = 374
        83
    return total

def _иЮηБВσεЪщΡю():
    value = 60111
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('blF0VzJUeGxGcnkzU3VCZm9UNUU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _οωЪГъъиΣЮДзхυλ():
    value = 43618
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxbifmkA36ABHQya5UOKGQ8C22U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞмГΡхиЦΙΕяЛЗклγ():
    value = 61046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDnWWVA7qoxXIxiSx3mUFhJ473Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΔΥсφДярдРοЩцкмю():
    value = 363487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LD+xVEMo2PsEEyWN/0+RJRYIsG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬθψяФПУкρшЦΔлУΟ():
    value = 333105
    if False and True:
        _dead_4389 = 540
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSfVQn8sxq0Fageux32VGD97tUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μШЩбΘΞΤЪб():
    value = 421332
    text = __import__('base64').b64decode('UWhiSGFHeWRiaDJaNUloNThxSVM=').decode('utf-8')
    if 71 * 58 < 0:
        _dead_3553 = 615
        pass
    total = value + len(text)
    if False and True:
        156
        _dead_8928 = 376
        _dead_9734 = 86
    return total

def _вЯЮΓъЛσγ():
    value = 112782
    text = __import__('base64').b64decode('Rnh2dFZRejhPU283emx3bEl3TzI=').decode('utf-8')
    total = value + len(text)
    return total

def _чыΝΔцгεЫΒгΞАγ():
    if 21 * 96 < 0:
        _dead_7943 = 610
    value = 285910
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwjOal0ezJ9XFg6KnUGzGAEk1l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8887 = 323
        _dead_8040 = 462
        pass
    return total

def _лΔςОθЬЪвκΕβΣ():
    value = 845712
    text = __import__('base64').b64decode('WmE5ZXV5REJZUjFuOWFOa3VVWWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ρЬрЕФЩйΛμυπаΒфЯр():
    value = 501706
    text = __import__('base64').b64decode('emQ4UnZXSzhGRlU3MVpxQTJFbUc=').decode('utf-8')
    total = value + len(text)
    return total

def _фхΞεнΝΣХдЫΓΚνΖθ():
    if False and True:
        _dead_5074 = 324
        pass
    value = 3261
    text = __import__('base64').b64decode('Uk1PbE45WWdRYk92eHdfcUhVT3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΔУйвΤСΑΣΔΩвψ():
    if len('') > 0:
        _dead_3849 = 971
    value = 518035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyXyf0Iv0Jc2FV+O5XefJnIK/V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7023 = 206
        _dead_7065 = 979
        _dead_4698 = 202
    return total

def _чЖΙеΓμЩрЩΑэλсМ():
    value = 111077
    if False and True:
        pass
    text = __import__('base64').b64decode('Z0dRcjY2Z3FzblZoT0YyeEJWeWI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if 6 * 93 < 0:
        579
    return total

def _еΑΧςфЖХσ():
    value = 763817
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bi7TUWsxqqAPCQeS3W6+HC0a9Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕуΧнΗεΔΨ():
    value = 123296
    text = __import__('base64').b64decode('QlY2VjN4dHRIQ3dJT095ZGdXWUc=').decode('utf-8')
    total = value + len(text)
    return total

def _дчмлгеξξζяεУЫΚЩю():
    if len('') > 0:
        pass
        _dead_9677 = 835
    value = 570854
    if len('') > 0:
        331
        126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTn9fmgV2/xbNR6Fw12JYiQ38Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фсψΚйχВαΨУβЛ():
    value = 775015
    text = __import__('base64').b64decode('bkZKR3FvN0FxaVA4UUpYSHFxTWg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9803 = 878
        _dead_5291 = 510
    return total

def _цюфινΒаΚмюцЫΕяΣд():
    value = 679269
    text = __import__('base64').b64decode('RmxNQml6RWpINEJ0YkhuaXJ5NEM=').decode('utf-8')
    if False and True:
        _dead_9412 = 47
        pass
    total = value + len(text)
    return total

def _ΓρЭЫΠΧАкΦЭИшХКК():
    value = 800381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg63Z0g1qL02HgyG32/AJAgk4Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓфΣФОБШГяГЗъΞπβΟ():
    if 15 * 98 < 0:
        pass
        927
    value = 329549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHfUWAMJ/5skaB2p2HeSDRZ/sDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        116
        pass
    total = value + len(text)
    return total

def _мΨκΔνчСςΦΖО():
    value = 215180
    text = __import__('base64').b64decode('Y3BybHA4T2VQaTVyQTVPbUZQZWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЪкΤСτФдΝ():
    if False and True:
        pass
        493
    value = 332638
    if False and True:
        168
    text = __import__('base64').b64decode('dUhaY1B3RVN0MHdIR3dJU0VkaUI=').decode('utf-8')
    if 22 * 66 < 0:
        _dead_9984 = 787
        pass
        879
    total = value + len(text)
    if 20 * 95 < 0:
        908
        pass
    return total

def _λмψефρΓлСΠСΛЬэ():
    if len('') > 0:
        _dead_3330 = 994
        pass
    value = 425076
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwnLfwIM+fhWDRaKmgC5EjAn0TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        205
    total = value + len(text)
    return total

def _εсΣυΖЕΑσдμХθ():
    value = 125889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgfzZkMarIA3PDiyxFPDOysHyDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5041 = 624
        pass
    total = value + len(text)
    return total

def _ьββМδШъψγю():
    value = 18130
    if len('') > 0:
        pass
        70
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgXXS2M60acSHwL26V+WYQF47WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 28 < 0:
        390
        pass
        _dead_8326 = 503
    total = value + len(text)
    return total

def _ΟφРыξψТΠЫБ():
    value = 730664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FADORV4L3P0gMAic6wa6Jw4s1GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ювψνΡνЗΦфИγв():
    value = 709142
    text = __import__('base64').b64decode('TVVEYnE3ZFVhdm5lalpDQ1NiSnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _σΤаΤщуΞΩоъ():
    value = 436848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3i9THYy05k5GRuG/WO3NzUg3mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФщΛΓχκхЗвКΟ():
    value = 364603
    if False and True:
        963
        pass
    text = __import__('base64').b64decode('cWc1SXlvSW16b2pLYkFwY3duS24=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8224 = 346
        _dead_7876 = 190
        pass
    return total

def _ΠРΡΣСПРΑр():
    if False and True:
        719
        279
        _dead_9924 = 504
    value = 815031
    if 16 * 46 < 0:
        _dead_5779 = 524
        _dead_9271 = 885
    text = __import__('base64').b64decode('eVYxV3RHMG9TRHk1MVd0aFU0eXg=').decode('utf-8')
    if False and True:
        _dead_7167 = 219
        pass
        _dead_7156 = 886
    total = value + len(text)
    return total

def _γЫθуыΩзε():
    value = 950727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH7SYVML0fkwbBio/wXEPwt2sD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯугνЫЫΙЪИцΤФ():
    value = 532948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej7le18U0aosbB6i3G7DGgB9zTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΤχХΝΒΣιЮкΕмψΛ():
    value = 950517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnfgOwABrvAoHjqU+ELGMTMD6D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨмБσзξαΨхУЪОυШ():
    value = 280405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBXUXkk69qIKCAPwzA6qJXMYtl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 88 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    235
    _dead_6756 = 22