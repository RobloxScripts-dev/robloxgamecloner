#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ιΨыфцφцЬ():
    value = 76624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACTNfVww2/obOwL261+eC3cMyFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        933
        _dead_2299 = 860
        _dead_8456 = 512
    total = value + len(text)
    return total

def _εξыΔьΕУм():
    value = 674410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiOwf3sb9aEGbhzx2gS3DAk2tDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вχаэВрεΘСЯΖ():
    if 93 * 9 < 0:
        905
    value = 842623
    if len('') > 0:
        259
    text = __import__('base64').b64decode('anphZHRjNGk0bFdGZXZmMVNaTVM=').decode('utf-8')
    if len('') > 0:
        _dead_9920 = 443
        _dead_9075 = 856
    total = value + len(text)
    return total

def _яЩζΞтΠхшΚфУ():
    if len('') > 0:
        471
    value = 134137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzzeX1oc7YxXPzaA23eZLA4K81c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        622
    total = value + len(text)
    return total

def _ΧΝйьΩΛыэΠΞΚθб():
    value = 474469
    text = __import__('base64').b64decode('dVdxZVlxenlja04wWUdaQVBQU1Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        949
    return total

def _эωξΤТξчΛ():
    value = 296473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBX0VgM27YkoYyj25QHFBDQc8Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИъФлΞПЛχюΞυυ():
    value = 947710
    text = __import__('base64').b64decode('aExPTnVtTlZEVUVoNkNFSXk5MVM=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_5304 = 918
        pass
    return total

def _γΜыеьεкеτ():
    value = 972056
    text = __import__('base64').b64decode('UzA4blEyQWpmZFZZR09PaFVSSWM=').decode('utf-8')
    total = value + len(text)
    return total

def _νλΞСιΗнχХ():
    value = 787477
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nie8SHpp64pSPCiRmm6iMR8t5m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΒτβΡΘИЙλΤΠφВΒ():
    if 6 * 3 < 0:
        _dead_8621 = 122
    value = 398213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBrCekIKqYcVHT3z31CyESoEyjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        394
        pass
        pass
    return total

def _кмΨΥЕЗЪшΦНйЮЬж():
    value = 281980
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgHUTFsurqAOFgy0zneHFSgn3Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        357
    return total

def _щΛЯΕΓфΩΓΥΠЩемр():
    if False and True:
        _dead_7151 = 68
    value = 342538
    text = __import__('base64').b64decode('SG5UU0N2NXFTeWV2TWlGa1pOOWg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7018 = 554
        pass
    return total

def _ΧασΦςΗΒΗπш():
    value = 787547
    text = __import__('base64').b64decode('V0JwWkcxSWhTdlJzck5XRTlIaHM=').decode('utf-8')
    total = value + len(text)
    return total

def _οχПξщΓοуξйΨ():
    value = 400703
    text = __import__('base64').b64decode('dkVBUTJlcjhxYmN4RFoyb0U0NVA=').decode('utf-8')
    if 96 * 85 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _δФυХΤПΕΞμΓЩΩυΓ():
    value = 10902
    text = __import__('base64').b64decode('bklobVZCR2QwR0hWMTNCX2FMNm0=').decode('utf-8')
    total = value + len(text)
    return total

def _яΜаМТвΗγхдхБЭ():
    value = 342530
    text = __import__('base64').b64decode('ZEhCZjVhUXBhNTBURlJ1ejQ1Nmg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_2060 = 326
        205
    return total

def _щΕЭХрΛэЮ():
    value = 504112
    text = __import__('base64').b64decode('Tzg3QzZxQ2RzcHFQTFJ0bGxadHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜσЧγУРΘΤСХЖνюΜЫ():
    value = 507310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDzPWwcA8Zo6IFr260C6AxU183s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3831 = 539
    total = value + len(text)
    return total

def _ΒСаΛζψμючСм():
    value = 388006
    text = __import__('base64').b64decode('cjRlNjJKTm1lRHN6T3hDOXlKV1g=').decode('utf-8')
    if 6 * 38 < 0:
        pass
        _dead_3809 = 267
        _dead_4758 = 65
    total = value + len(text)
    return total

def _ΧЮКιпльχтΕчМ():
    value = 63552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyCxaQUg3JpVEjqomlyYBC0asD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4539 = 539
    return total

def _ЪμΛчцжСвηЗσрКψ():
    value = 838948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTfUPwRq05kJaguEnlSUDT0Yxzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юТшЬΓПХδ():
    if len('') > 0:
        962
        438
    value = 899713
    if len('') > 0:
        5
    text = __import__('base64').b64decode('c0lTNWE2bUpDTUJrUTNiUWFjT1k=').decode('utf-8')
    total = value + len(text)
    if 16 * 4 < 0:
        _dead_7005 = 217
        pass
    return total

def _ρюςьиЧνωЕуχдΗх():
    value = 88191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ2yZmkQ1oU1Fgmw/1qHERQdzm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_2509 = 615
    total = value + len(text)
    return total

def _τΠЦШΩБГиψι():
    value = 241238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjrARAgt0KQxDF2X7VG2DiAjtDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤξГфЬПпρШАтδв():
    value = 19908
    text = __import__('base64').b64decode('WnB5Z0Y3NDZBZHEwcGZEM0JEREo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        720
        430
        522
    return total

def _НΝρΧгРΣμВХωРι():
    value = 771305
    text = __import__('base64').b64decode('STJvSHhkaEZGTElFRUl4Z2JGaWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛЛΦЬМЯАРυй():
    if len('') > 0:
        _dead_3588 = 454
    value = 695865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyPmRlsP5qEZGSGE4USjIQIF62o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пμηΕгЖΡЩΕнσΨюσЪу():
    if False and True:
        _dead_4529 = 474
        _dead_7806 = 295
        _dead_9588 = 44
    value = 28074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxXyZ30Vy7xQNxW17G6qLBcIslQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_5752 = 853
        951
    return total

def _шбΜρьИχθ():
    if False and True:
        pass
        _dead_7117 = 267
    value = 435579
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRndSgMK8bwFGSmVwV6/YnMuzGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АοжЗΔυΓМнНЗΟΤР():
    value = 637077
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nyj9TWc4yqEJCgeRzlSqNzJ/vWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кМΖΝΦАЩЬехΡ():
    value = 333405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAzFPFQfqqc8DF6o5gCyGRU61UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чыАкβПВаθРΚюΤβ():
    value = 168163
    if len('') > 0:
        664
        pass
    text = __import__('base64').b64decode('Z19SUmxMa2o0UnFJSjhOMXJKUlM=').decode('utf-8')
    total = value + len(text)
    if 27 * 25 < 0:
        403
        _dead_7397 = 766
    return total

def _рЕαйширжΒβУефΠ():
    value = 399728
    text = __import__('base64').b64decode('WXUzM0F5QmZZS0w0OUZwZ01FZTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛρиτИкκω():
    value = 949674
    text = __import__('base64').b64decode('ck5FVUtHVUF2OG1FSGNhbE5DUk8=').decode('utf-8')
    total = value + len(text)
    return total

def _вΥПэΑοχζЪΜЦΔм():
    value = 941248
    text = __import__('base64').b64decode('c2VpNDgzeHRRU1BNQ2NWN1B2Q0o=').decode('utf-8')
    total = value + len(text)
    return total

def _νΒΡξκЮΞН():
    value = 928275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah7RUWs8+6QTCD6VwVmhIQsGzT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бейДфδΡЧ():
    value = 300965
    text = __import__('base64').b64decode('dF82dmJ4S3F6T2pITnd6VjRBbUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _бНςΝцъНηкА():
    value = 864317
    if len('') > 0:
        _dead_4968 = 163
        pass
    text = __import__('base64').b64decode('UEtyWlpGWnBIZ3FweGNvM2ZXV00=').decode('utf-8')
    total = value + len(text)
    if False and True:
        447
        _dead_3197 = 238
    return total

def _ΑьнмЗψУяμΚ():
    value = 801674
    text = __import__('base64').b64decode('QThRVkpSUVFKQ2RnOXRUQUdQeFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΩπΖΘЩЗФВмΞр():
    value = 839300
    text = __import__('base64').b64decode('UXJVUjBJSWRrd0YzSVV0cU9fTEI=').decode('utf-8')
    if len('') > 0:
        824
        728
        _dead_5073 = 314
    total = value + len(text)
    if len('') > 0:
        _dead_1714 = 464
        _dead_8539 = 942
        _dead_6244 = 124
    return total

def _нчθΕоθΦΥВςΖΓЪФλ():
    value = 89974
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxjMRH8zr5FbLTz3xQTEFgIVsV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΩИξЛΗωрчмЦοнεЭ():
    value = 820024
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjXAW2EQ2rwuCFmP8GaaLRUA/Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗаънтμБβχдаЦλΒ():
    value = 972546
    text = __import__('base64').b64decode('TFJfT0tTWHR5NHdsZHdfU1RXUlg=').decode('utf-8')
    total = value + len(text)
    return total

def _НИАηΕЛДюЛ():
    value = 985343
    text = __import__('base64').b64decode('WWk3QzJWSlJpTTFDNm4zMUJKV1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _χαβчАΣΤΟПσζАВηБф():
    value = 262252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyPrQUM9rP8vaT6AnX6YYQd4z00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζιςМзιеАЪюЖнЗκлИ():
    value = 594150
    text = __import__('base64').b64decode('d25JaWxBcVM2MGViZVZySTQ5S3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛιφБИΕΗм():
    value = 311106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSm8YVU19okSHjCCm3TCFXA701s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 47 * 74 < 0:
        _dead_8491 = 584
        pass
    return total

def _ΣΠωХΥикЬ():
    value = 307381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mgm8eWUa+7o0CyaK2F2/J3wh4lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΑоΕπδДзςΩАγгчно():
    if False and True:
        434
        498
    value = 519461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyXRSnYQzpxQaQ6k4lueHhEr9k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 96 * 89 < 0:
        369
        _dead_3303 = 269
        pass
    return total

def _МъРςЗвПΜхыΜΕ():
    if 47 * 69 < 0:
        pass
        344
    value = 247599
    if len('') > 0:
        585
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzfGR0s36p83HAWG/kDEIQ1/tTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛгΗрεΑΦЧДνМΑ():
    value = 203757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxvbfwYrqL42M1aJx2OZbXce0Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иυяфщφрюДКΔр():
    value = 700180
    text = __import__('base64').b64decode('QUJ3dm1weHdJcDllUjU0NVQ0SWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΨюΡвΑкфζщΦнЗ():
    value = 198807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT7efUFq0aciDzyU0lCbICgQ9Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μщΙГΨΛχХиι():
    if 79 * 15 < 0:
        pass
        _dead_4757 = 875
        _dead_4062 = 94
    value = 969741
    if 85 * 14 < 0:
        952
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hyy1eHZs+YwNNh+ImGPAZw4qwXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 65 * 61 < 0:
        722
        pass
        _dead_1410 = 201
    return total

def _ΚΤζЯΦднсяΚΔрαΩвΘ():
    if 44 * 24 < 0:
        _dead_9154 = 772
        356
    value = 973647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxDpeV1sqYQ3DyaRxQeYLgYXzH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙмТБЛЧξιξозΡеωΕΛ():
    if False and True:
        _dead_5115 = 284
        pass
        pass
    value = 389633
    if len('') > 0:
        663
        _dead_4719 = 706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwO2eGYw9aJWGVu3x2exIT8i3EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        862
        pass
        pass
    total = value + len(text)
    return total

def _рыТηнβЫφς():
    value = 451255
    if len('') > 0:
        599
        888
        _dead_3237 = 968
    text = __import__('base64').b64decode('a2prMVVEdk9TMVhrOEZvamxLUF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ρвχДΙЬхΜυ():
    value = 612646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX7bd2gRprExDV6c7UO+HCEn7nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        581
        _dead_4696 = 424
    total = value + len(text)
    return total

def _σирГαπΖμφЛНлЮ():
    value = 550934
    text = __import__('base64').b64decode('ZGl0OVdoTzk2M3FSUzRNNFNiNWs=').decode('utf-8')
    total = value + len(text)
    return total

def _λйЙШΠΓςЦМбΛΚγυГш():
    if 26 * 30 < 0:
        _dead_7679 = 965
        _dead_3877 = 436
        284
    value = 421359
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXywYAEt7f1UMl/22Fy4EA4A4EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        847
    total = value + len(text)
    if len('') > 0:
        _dead_6052 = 260
        782
    return total

def _йбБрΓΧτУЛВ():
    value = 850442
    text = __import__('base64').b64decode('bFdHR0F6VFVaS2s2TGZqZnZZM2c=').decode('utf-8')
    total = value + len(text)
    return total

def _κζθцЖйШДπΤХ():
    value = 254768
    text = __import__('base64').b64decode('V0pISjVfc243UFlCWlJqeWdxUW8=').decode('utf-8')
    if 28 * 17 < 0:
        _dead_1863 = 206
        pass
        pass
    total = value + len(text)
    return total

def _гΩξπΟтΛьΤШа():
    value = 98649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHfJV3gL2JsqA16o5HCnGX121UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γНмπεχμСσцΚГΦВ():
    value = 190025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgK1ewMS7bobMCrw7XWnIgI5zT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ακоΞЗωгЗхС():
    value = 552130
    text = __import__('base64').b64decode('Z09ZaVN1cUV4MmozZTBDWUprMWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _αцΩМЮνφкΜ():
    value = 682537
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTzQXVkQqv8yCiT0kHO8FT0gtUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЪХνΘνОхΩΩРΠΧуый():
    value = 461406
    text = __import__('base64').b64decode('d19sVUlid29xMl9vRlhVYm5FVXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΔΤЦИВчεΠЯΞμΞΡ():
    value = 212304
    if len('') > 0:
        _dead_4130 = 627
        pass
        82
    text = __import__('base64').b64decode('SUVyTm5LZWxUMFIwc24wWkpQNzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _вοΑЯЫЗУΨ():
    value = 308697
    text = __import__('base64').b64decode('RW5TOTRSdmFPWmFtdjdFeVBwV0s=').decode('utf-8')
    total = value + len(text)
    return total

def _νШсЩυΘσΨДюБ():
    value = 446653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHfBS1Us1ZJTLlin+luKIzIL1Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΦλШАзΙΜΜρΡαФ():
    value = 44854
    text = __import__('base64').b64decode('VXZfZm9RUUtmVjlvRkJkWTZZQk4=').decode('utf-8')
    total = value + len(text)
    if 24 * 9 < 0:
        pass
    return total

def _еьψσнолνεк():
    value = 279437
    text = __import__('base64').b64decode('bEpGUnY1WGRzRmhaSHJ5MkNpcXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ζсшΝθζшσο():
    value = 933247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NH3GdGk79YQAGQ2rm1SeHyws9GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κЯИЧБЙμκШςΝ():
    value = 216692
    text = __import__('base64').b64decode('cDlScmZFd2xIS0lWUnQ2X0NCS3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙιиыюΓζЙασъ():
    value = 788747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jw31b1o8yLwoEQ32znWIYDR3tmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _изчлцщςωЭΦИκ():
    if False and True:
        51
    value = 554042
    text = __import__('base64').b64decode('bkFDeHlKa3dQeFhtbWVDMTJmYW4=').decode('utf-8')
    total = value + len(text)
    return total

def _оЩБΥΑΣΩεΟΒЧΣΩ():
    value = 641905
    text = __import__('base64').b64decode('SWNJYmdVVEZQQXA3Y2hVQmdyMHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ВИλбρθГσ():
    if len('') > 0:
        pass
        pass
        466
    value = 697567
    if 13 * 54 < 0:
        149
    text = __import__('base64').b64decode('RHFQNW5ER3BmU01HY0Vnb0EwSTE=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _роЙЧΕКыχХРΣАтΩьγ():
    value = 62880
    if len('') > 0:
        _dead_3386 = 386
    text = __import__('base64').b64decode('TGJiOVM1T1JIWnNNM3Q0Vl9zUjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ζыψзВтχΔΨΗξ():
    value = 352781
    if False and True:
        232
        _dead_4269 = 279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARX+bVcyrYQWGyOwkVHABj844Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        234
        _dead_4137 = 922
    total = value + len(text)
    return total

def _шЦгΔКπПсМж():
    if False and True:
        pass
        243
        pass
    value = 953869
    text = __import__('base64').b64decode('ejNBZ0MyU0lHZkwwZG1sWWdUeVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕяцЪэмбъМЗыφπ():
    value = 525674
    text = __import__('base64').b64decode('Y1FKWEpGY3plTElzdkdWc3ZoazE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΤβωοΖΤсШох():
    value = 404502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExzPPWYo25o2AiSS+QKkNQQoyEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜТΡИЗΛсΛсЛРχ():
    value = 207829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHjjW24MzZcAHleuzAScZSYI9lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λНсξψΘΖЗе():
    if False and True:
        351
    value = 877496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AinqYwk/rbg0awGhnWyHNSJ772A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_2714 = 259
    total = value + len(text)
    if False and True:
        714
        47
        _dead_9331 = 875
    return total

def _αΡωъфпъΧВ():
    value = 746741
    text = __import__('base64').b64decode('WElvaXZGaFhjd24wWVBNbjFHV20=').decode('utf-8')
    total = value + len(text)
    return total

def _ГаΧцДжΡЕивэρωΣ():
    value = 17396
    text = __import__('base64').b64decode('TzRObFlDNkxxWk5SS2d0dkdTV2E=').decode('utf-8')
    total = value + len(text)
    if 54 * 58 < 0:
        592
        _dead_4284 = 160
    return total

def _юПфйЙτЭΧя():
    value = 310339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyfPSFQ6/KRRHFaT6USyZjd/3VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΣфΤшΞθΛ():
    value = 935523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn3+SQZu2vsbYgCiznyJOyMt0Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΝΜνрСуъЮБею():
    value = 479679
    if len('') > 0:
        pass
        53
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjvAakUJ2YsaKje18E/JNhoHw38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9812 = 794
        pass
    total = value + len(text)
    return total

def _ζΙЦЩтΓИр():
    value = 732717
    text = __import__('base64').b64decode('eHBIUzk2aDlqb2tKMWcyVDRwSm0=').decode('utf-8')
    if len('') > 0:
        57
    total = value + len(text)
    return total

def _ЧГжОмсζфщЦΖ():
    value = 114581
    if 26 * 93 < 0:
        _dead_2142 = 230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETfdQ1IG5ooLGSW673zBNgsf1VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦνсαψЪУпъРΦкЙ():
    value = 93853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyCweVsA/6swGD735gOfGhYb5Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        28
        pass
    total = value + len(text)
    return total

def _βЛтΘΥРΣДαЫ():
    value = 646675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRyxQgBg55cIPwWqmw7CFQMZzzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жκΦГФФвΟь():
    value = 213071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgbgOWY6+JcpOB/7yXecBTA10zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вυАиЙЗνΜΚбΠИβΔΟ():
    value = 67449
    text = __import__('base64').b64decode('RHh5RjM3dWNnRjF2bkxLTVJ6eWg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        76
    return total

def _рΧЬлФΩυЬП():
    value = 898048
    text = __import__('base64').b64decode('TU1TY1NjZWphbGRkZnplb2drdXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭτаюыαεЗйгαвГσ():
    if len('') > 0:
        pass
        pass
        _dead_1465 = 767
    value = 275057
    text = __import__('base64').b64decode('U09mU0hTUGNtZVJCYmRocTJoU0U=').decode('utf-8')
    if 21 * 9 < 0:
        810
        _dead_7487 = 694
    total = value + len(text)
    return total

def _λβУЛЗκΔбцК():
    value = 890551
    text = __import__('base64').b64decode('Z0x6NERIZEhBcHpwSWxBZm41d2o=').decode('utf-8')
    total = value + len(text)
    return total

def _θδжητаЮР():
    if False and True:
        38
    value = 174721
    if 30 * 58 < 0:
        _dead_4456 = 895
        pass
        _dead_2502 = 312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiroSEtu//8NGAm7+GWvCzch7l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔПрИЭΗлΒΔЬξ():
    value = 971776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwO1TH0XzY8ZA1yz+3mxFSsQwzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РУΝЪдмбμηαФ():
    value = 656740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh+yP3c0yYELOT2Ex06aBz8o0Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        119
        _dead_9866 = 605
    total = value + len(text)
    return total

def _ЖΥШщдεЗмОσДЛьрΑИ():
    value = 137298
    if len('') > 0:
        pass
        945
        _dead_8592 = 650
    text = __import__('base64').b64decode('RDczRWp6UUZ4aEVUU0JNdkt2ZWU=').decode('utf-8')
    if False and True:
        pass
        _dead_3141 = 80
    total = value + len(text)
    if False and True:
        pass
    return total

def _АЙυТρΔвΔ():
    value = 881686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSHdQEIr/IcNPDmlzAKVHiIgzTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 62 * 34 < 0:
        pass
    return total

def _оЯКοεδγШΦъкψ():
    value = 747909
    text = __import__('base64').b64decode('R0lLVGhqcFFfU2duNFRLYmdiel8=').decode('utf-8')
    total = value + len(text)
    return total

def _гщМЯЩΦЭλδИφχХ():
    if False and True:
        pass
        _dead_9934 = 622
        pass
    value = 115977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRnLXHw6yrBTFDWi2FGjYzALs0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 38 * 36 < 0:
        _dead_6589 = 302
        723
        _dead_2403 = 127
    return total

def _вΑжΟЮБнсμΘЙ():
    value = 238295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NinPO0Q1pqYBbCmA6keKGS0o4Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 45 < 0:
        _dead_2199 = 571
    total = value + len(text)
    return total

def _γφφЬЛлЪΤΔз():
    if len('') > 0:
        _dead_9631 = 593
        pass
        273
    value = 671639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAHmP1sa5L0nCDmJwl6ZARYCwz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬμЧЩсΨεрΣЯχш():
    if len('') > 0:
        _dead_5727 = 287
        pass
    value = 376795
    if len('') > 0:
        pass
        _dead_7923 = 502
    text = __import__('base64').b64decode('T0J0ZHFuZjRZUGNrMkhjR19UZjM=').decode('utf-8')
    if False and True:
        525
        815
        _dead_4199 = 738
    total = value + len(text)
    return total

def _ζвГОюГΥтΦаОα():
    value = 518740
    text = __import__('base64').b64decode('aDhZODI3eXlIYU5jTVg5bldBNUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΠЪψωБΟХЦΓЛчι():
    if False and True:
        _dead_8418 = 816
        pass
    value = 200344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnviQABgqJFUbwiBwGW7LnIi7kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шьΔшъиКфЦΑΔфΤщю():
    value = 626387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXzIVnMY+/AFOAz6/nevLBoZ72A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        272
        _dead_8512 = 457
    total = value + len(text)
    return total

def _πЗеЫθЭτβлΘΒзωΜЪ():
    value = 870875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiDKQHQSrLINLzeAmHybJip78j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        919
        511
        _dead_6781 = 591
    return total

def _АЯКЦлτЛυМΟΟ():
    if 43 * 53 < 0:
        pass
        _dead_5777 = 652
        300
    value = 989257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCXzS38B3IYJMzmQ2G+9FhAY6kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        892
        _dead_7245 = 241
        _dead_9362 = 447
    return total

def _λΦдχΒоχЫУΣ():
    value = 363687
    text = __import__('base64').b64decode('WXJ5dktrX2JwZU5HSFFNSTRndTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _κΒХδεΡДΚюΞйωЦ():
    value = 8658
    text = __import__('base64').b64decode('WDc4TlFMXzJvTWM4bEU1UWR1dmo=').decode('utf-8')
    total = value + len(text)
    return total

def _вйΙΨδΘяьмжπиζщмЪ():
    value = 953212
    text = __import__('base64').b64decode('RXBtdExjTmFRWjlBcm10NVFFeEw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        137
    return total

def _ρДγаДЗиР():
    value = 418026
    if 83 * 88 < 0:
        9
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwfjWUVh6ZEnLluE6kCTNgYBtlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βθйОΨΚηш():
    value = 825776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bj6zQ3sOrPFVNTWNm1WbNyJ78Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΡΨωМΤвьЖбцлΘУ():
    value = 90176
    if False and True:
        _dead_8320 = 703
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih/NX1or5qVUPxyLnmKEFQA/8EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        878
    return total

def _ПУфТкΓΥАΥΠ():
    value = 826852
    text = __import__('base64').b64decode('YW56RFFkTHJxSm5fNk9MSFRyYmI=').decode('utf-8')
    total = value + len(text)
    return total

def _яυбБФЦпΘ():
    value = 552019
    text = __import__('base64').b64decode('QnVvaDg5VG5qNm9XU1N5WmUzWWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝζЬνΞЗжΝ():
    value = 484821
    text = __import__('base64').b64decode('ZTNiTXd3X1NobnpjSDJxTHZWbjE=').decode('utf-8')
    total = value + len(text)
    return total

def _τΓρΧъвиуЛθΩ():
    value = 708907
    text = __import__('base64').b64decode('VlFqbWlLU0laVFhtd2FWUTJlT1E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        449
        _dead_9642 = 21
    return total

def _γΥΠΞЬφΘгуыΜΡ():
    value = 366630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjnAfQMu8qAXDQC122WWGwZ89lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_3811 = 192
        pass
    return total

def _ΔκιωεаΘяЯТБΩй():
    value = 994260
    text = __import__('base64').b64decode('dExBcWRqVVRHUU43Z3JwOHJkSE0=').decode('utf-8')
    total = value + len(text)
    return total

def _σлχЗэΤΖюΙ():
    if 49 * 30 < 0:
        91
        _dead_8568 = 684
    value = 301687
    text = __import__('base64').b64decode('aTVwYVVNeXl2VHFoYzllRWZlcVI=').decode('utf-8')
    total = value + len(text)
    return total

def _НКψХΘΩаΩъе():
    value = 709330
    if 59 * 72 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChyyYnkDq6M6Oybx3EfJN3we70I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨуΖΟИφΧсЕэΨА():
    value = 268655
    text = __import__('base64').b64decode('aUViZnltZEtkX0ZGUTd1TE5XR00=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _αΙΒъЗκВъЧΩθБ():
    value = 227504
    text = __import__('base64').b64decode('Zk1QbnJtNjZiMmh0S2hFcmdYUl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ВшЖΩсοмΒεьΘЫоδΣ():
    value = 936666
    text = __import__('base64').b64decode('a3JOd19sc0VRQnI4WXRZMlBpYmI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖδъАКζраЫО():
    value = 390787
    if 42 * 5 < 0:
        _dead_1743 = 394
    text = __import__('base64').b64decode('TVEzQnpFZ25NS1lyeGIxdGZIMlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ςэЬцΡΚэпψφοβ():
    value = 830104
    text = __import__('base64').b64decode('STk1WkVRRHlteWxFMkhOSmxRbEI=').decode('utf-8')
    total = value + len(text)
    return total

def _уΞΙЦрйтΔσы():
    value = 3488
    if 99 * 44 < 0:
        _dead_4082 = 484
        _dead_3607 = 414
        596
    text = __import__('base64').b64decode('UWxvYjZwU3A1ak1KQlpYbnJYYUY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        689
        242
    return total

def _ЫПРσΒΝШч():
    if 31 * 7 < 0:
        731
    value = 784018
    text = __import__('base64').b64decode('bVNSWTVWcnpzbVJMZms4YmFleHk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        761
    return total

def _РЫςшАфρΗйφ():
    value = 268427
    text = __import__('base64').b64decode('bVV3MHp3ZHE1R3BLOVhvdm05ZWk=').decode('utf-8')
    total = value + len(text)
    return total

def _δьδцξхйΦИωпэΕшж():
    if 16 * 99 < 0:
        _dead_6501 = 356
    value = 50805
    text = __import__('base64').b64decode('QXdZNFhrSEhmNTV0UzdXS2tVX2g=').decode('utf-8')
    if False and True:
        288
        _dead_8899 = 492
    total = value + len(text)
    return total

def _οмфΘфхΠВΞБς():
    value = 122622
    if 31 * 61 < 0:
        pass
        710
        743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ki3vbVQNx4UgNQT2kXi5ZCso0ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦЪяΦΦΖдо():
    if 95 * 34 < 0:
        _dead_8163 = 813
        _dead_8654 = 682
    value = 468378
    text = __import__('base64').b64decode('dlR1THdVRXVxODgwallHMWFVU0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨιοΛΔТΓΩЮκΠС():
    value = 74883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnvVX3QMrflQAiHy/nyGDRQlzE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζМлшЦлΒьЩ():
    if False and True:
        55
    value = 489845
    text = __import__('base64').b64decode('clo5SmRBU2lfUm9wSFB4Mm9PRm8=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        _dead_7626 = 281
    total = value + len(text)
    return total

def _чвΦμЦπΣеЧГΟЫип():
    value = 165859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQnVXkAVqb8pIyS5nlTFYnIG8HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩКиΔЫИПИ():
    value = 411978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgPta0Edz6JXHVeuywKkZQwH3Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шθχГχΥжΣеПο():
    value = 340960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCP+eAkLyIIBOCOVzG6GOXwD43g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΜЯВλΣИРπΣлФΡ():
    value = 625729
    if len('') > 0:
        920
    text = __import__('base64').b64decode('WFF5VmhwSHpVemF6ZWtUajNDdjM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЯЬγчχΧГτ():
    value = 434093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSyyX2UR1/xQMCD78UKHFXErz2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΒХρθЦлДРθдδυУЮ():
    value = 513777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQ3SZ1ca9ZcnPw6GngWeZCk4w1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йЗюμфуοнИЗКЩΞо():
    if 67 * 39 < 0:
        pass
        114
    value = 164752
    text = __import__('base64').b64decode('cTdTTmtTZmR1d0h2ajJPbHZiWHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯЬуΘЯψПηЦМΥΦκвΝ():
    value = 825093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjvPPUY62rsQCV6c5l2bP30a3kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        532
        pass
    total = value + len(text)
    return total

def _ρТΛΒпЩщдΗъτ():
    value = 730617
    text = __import__('base64').b64decode('cEQ0U3dHOWI2cG82aDU1RFZmUlQ=').decode('utf-8')
    if 84 * 87 < 0:
        pass
        _dead_1937 = 324
    total = value + len(text)
    return total

def _χΞхβЛРρΦ():
    if 48 * 30 < 0:
        550
    value = 379335
    if False and True:
        369
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXngVkso96EqEVaBylXAPA8+vGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςЪвαяΚКΖвΣоцбфФ():
    if len('') > 0:
        pass
        946
        _dead_1973 = 856
    value = 736684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwTCVgQA/44OPh+l2UHBYyIg9Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μяΒвΤδбТгОз():
    value = 359711
    if 95 * 40 < 0:
        732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyDCa2EwxPknMVrw4X6AGxw61HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7311 = 853
    return total

def _щпЙΦеХеγшощλΚе():
    value = 519410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTXuV0UW/aUBEifw8kWGBAl79Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НδΜλξΑИГ():
    if 25 * 71 < 0:
        _dead_8916 = 725
    value = 38294
    if len('') > 0:
        _dead_5874 = 463
        _dead_6857 = 541
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lnv+aWAI37oRBQq3kGeEGTEF6Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4417 = 617
        143
    return total

def _УзΤΨжΚъэЪьлм():
    value = 313878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyXwd2Y6/ac3al+VwVO/PCl5/Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЫКщПНкΛ():
    if len('') > 0:
        70
        pass
    value = 422714
    text = __import__('base64').b64decode('U0ZUZEdtTzhBZlNjSE9XZlNveEw=').decode('utf-8')
    if 53 * 73 < 0:
        952
        _dead_9979 = 120
        828
    total = value + len(text)
    return total

def _νЫΑπВыΓхЙ():
    value = 522124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSXmYV9r8aUVFyml5lmRJQd44EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΨэδУЧшмАκэ():
    value = 23850
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQDHPFps1YtVOwSv3luELhR31Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙяИбΓДμБΧЮР():
    value = 12083
    text = __import__('base64').b64decode('RGhMMWtZMmVXTHBsVWR6MTVacHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣοжэЙкωэЬξφйυФ():
    value = 799931
    text = __import__('base64').b64decode('UXlTUDVzZ0hIZF9HbG9RSFRkalg=').decode('utf-8')
    total = value + len(text)
    return total

def _лΓКПνдΧΜωψΝм():
    value = 410576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgvuTVQO1Z8nHR6t/1K5Pwt+1Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖπξβςОлЫункΑψИк():
    value = 18555
    text = __import__('base64').b64decode('WlRCM3Y4TTBNWko4VGZRRk1TWUs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7376 = 671
        _dead_5392 = 527
        _dead_9571 = 816
    return total

def _хеъбГЪвд():
    if len('') > 0:
        _dead_6895 = 544
        pass
    value = 706864
    text = __import__('base64').b64decode('bmRlWGkyeG1BRGVubWpDWkF3VHM=').decode('utf-8')
    total = value + len(text)
    return total

def _вεЩΒЪмςωΠΣΠ():
    value = 870492
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXflRlo0wZIgalanyly0PRcD1WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХэθЦбζψУхфЮξРΞ():
    if 27 * 26 < 0:
        296
    value = 113890
    text = __import__('base64').b64decode('Q0dTUFNROElkS1p6UUd2OFltX20=').decode('utf-8')
    if len('') > 0:
        pass
        495
        pass
    total = value + len(text)
    return total

def _ΓνλчξЗЦХ():
    value = 69496
    text = __import__('base64').b64decode('Z0dYeHhXMjV6VEY0aXBMRHBMZG8=').decode('utf-8')
    total = value + len(text)
    return total

def _σΙχΡυζΒΠпερП():
    value = 627040
    if 24 * 71 < 0:
        pass
    text = __import__('base64').b64decode('S3drUzBCaXNpZmNLQl9zcTdxS2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЧэΧОээχВьЬзЗΨΑ():
    value = 4866
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgnWR0g2yLJXKS2b0HqHYi850Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 97 * 25 < 0:
        _dead_1611 = 862
        52
        814
    return total

def _ΗβΝюяхйЫЙФγκУΨД():
    value = 86239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NST9OEkAyp9VEiuP6l/IHhcXwlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖоНτщΞΚПΦгΦВрОΝ():
    value = 952953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KADhXUADz58KLFuQnwaCNzIGs0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФЧЙщщΓдΓЭНΩьИα():
    if 87 * 54 < 0:
        951
        _dead_9292 = 397
        pass
    value = 686297
    if len('') > 0:
        197
        pass
    text = __import__('base64').b64decode('blNoVXFxNmIxd3h0bDJwZXI0d1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _йτκεрΗπМΒеЯρЦз():
    if len('') > 0:
        _dead_9818 = 257
        pass
    value = 320805
    text = __import__('base64').b64decode('RTJjR2Z1SW0yeV9HZXk1YTBpckY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        489
        pass
    return total

def _вфοэψЧЧσοηЭяаВФ():
    if len('') > 0:
        pass
        _dead_2836 = 686
        239
    value = 180582
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT/JQnRrxI0pKyGt2HC1OBwX3j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 51 < 0:
        207
        238
        160
    total = value + len(text)
    return total

def _δьμχдΩЦΛоЮΔ():
    if len('') > 0:
        125
        _dead_1483 = 839
    value = 104707
    if 68 * 9 < 0:
        215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCDPNwJrrooGD1+pxWGKBgQBtz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΣΞЖфРПΗΤлЫβΖпΞω():
    if 10 * 72 < 0:
        _dead_4674 = 706
        pass
    value = 795786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwjlS2Uw16wULwaF4WCDHnB/62c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 93 < 0:
        pass
    total = value + len(text)
    return total

def _здиРрРтΕφХςПΑГ():
    value = 742781
    text = __import__('base64').b64decode('eTB6SEIyc0QwY2xGYkphM1dzY2w=').decode('utf-8')
    total = value + len(text)
    return total

def _слЧЙΑйφКΝкЕФγХπΔ():
    value = 376442
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH7yTwE03bIHDT2TmmafPw9+/mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        805
    return total

def _ξιωЗβфΡΙр():
    value = 519479
    text = __import__('base64').b64decode('Qkl6MEZDZFRqcUdLSUk2enVDeUc=').decode('utf-8')
    total = value + len(text)
    return total

def _южкψβусιОЫИααс():
    if 43 * 62 < 0:
        pass
        pass
        _dead_3021 = 181
    value = 47394
    text = __import__('base64').b64decode('U1gxOFJQVldRWklLNnBtaWtRYzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _чЗαчызрзтκяВ():
    value = 307577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETjHa3U1+KAgND2E8QSkFyg28F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МзюкΔΘыΧремЩг():
    value = 8785
    text = __import__('base64').b64decode('Z2J3MThxdlZ3aXZtMXE4dEowcVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ечΝβЮΞοбм():
    if 33 * 27 < 0:
        981
        _dead_9924 = 735
    value = 901569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCGyTXQKrakJHyWomEO6HiMm4zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΚлΛιыНοχЦУЧηΘяμ():
    if False and True:
        280
        _dead_2677 = 582
    value = 366491
    text = __import__('base64').b64decode('WmNKeVRDQWdzUm5WM3Z5TU5GV00=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒншооГΙρΣφκьВУ():
    if False and True:
        pass
        pass
    value = 775861
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXzMZ3A8zr4mEByPnXO0Ox8G/mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4495 = 213
    total = value + len(text)
    if 36 * 46 < 0:
        _dead_4317 = 692
        _dead_4654 = 405
    return total

def _ρЪασчπГАαЕкΓσв():
    value = 108637
    if False and True:
        pass
    text = __import__('base64').b64decode('QUI0ZFNvTlFXRkRJZXpfdmFsWXo=').decode('utf-8')
    total = value + len(text)
    return total

def _сΝзШχсЙСλμР():
    value = 669725
    text = __import__('base64').b64decode('WVpBNk5iRkNheHFIcmhLUjlFWl8=').decode('utf-8')
    if 36 * 56 < 0:
        _dead_9285 = 596
    total = value + len(text)
    return total

def _νфτЕαΚτты():
    if False and True:
        _dead_3289 = 582
        851
        _dead_5314 = 260
    value = 715000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyTreEVt3f5WAlua7weELBAdwEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 45 * 54 < 0:
        _dead_8394 = 167
        _dead_6397 = 459
        pass
    return total

def _длθΡЭШсЦЯζπфπωеР():
    if False and True:
        931
        pass
    value = 565041
    text = __import__('base64').b64decode('ZmV0d2RYc1Zma0xVN1RrZFo4YW0=').decode('utf-8')
    total = value + len(text)
    return total

def _йЩоκОЕЦЙЖИΚ():
    if False and True:
        523
    value = 33691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwrtegcGzPkZOwe2x0ymAiEX534='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НМφφΠеιγ():
    value = 673887
    if False and True:
        _dead_6326 = 71
        953
        116
    text = __import__('base64').b64decode('a1Boc2dPcmFrc2lKZVZfQXBUaXk=').decode('utf-8')
    if False and True:
        pass
        _dead_1096 = 421
    total = value + len(text)
    if 78 * 99 < 0:
        pass
        835
        pass
    return total

def _щэυψΛжУЭЩпΧζбШРц():
    if len('') > 0:
        383
        _dead_2098 = 24
    value = 15923
    text = __import__('base64').b64decode('VjluUHFFUVBpVkdNem9KRWNUZG8=').decode('utf-8')
    if 14 * 62 < 0:
        _dead_9061 = 335
    total = value + len(text)
    return total

def _ьзκмьДДΣΝЬζК():
    value = 596230
    if 15 * 50 < 0:
        _dead_4717 = 483
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwrOd3hrrI4uMV225QW+HyZ7/Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЕΟхπΧΟпоБрΙКкг():
    value = 184115
    text = __import__('base64').b64decode('YW9pa1ZFQlVqaWM0eFdycWhhXzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЦФΟжβхэωяΓ():
    value = 183328
    text = __import__('base64').b64decode('YkNqOXNQaEs5V1phc3lPWTF5ajQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭПшπеРЭЭКΥЛИΧλ():
    value = 60942
    text = __import__('base64').b64decode('R3FjaGZEenV4MmFxM29iZlB1MHg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9786 = 130
        pass
    return total

def _υΧШуфсΣМжтСεψ():
    value = 477464
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExfUa0IazrwLAwWA/FKKHQoExl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΩψΑзБγΝжγБβ():
    if False and True:
        _dead_3572 = 448
        737
    value = 285344
    if len('') > 0:
        pass
        590
        105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KC3JdEgc3JwmYlq67lKkNQIO6kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗЛηеηЛжζШΝч():
    value = 819500
    text = __import__('base64').b64decode('bXhHRDd3aF92c2RrQjJkYlhtdUs=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2785 = 495
        _dead_4244 = 464
    return total

def _ГψΧφρφИтχ():
    value = 188738
    if len('') > 0:
        731
        pass
    text = __import__('base64').b64decode('VmtaeEJqMGZrNFlhRkVlUVo2bGY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΑιΩпсΥОНуъΕΚΘтПЦ():
    value = 735626
    text = __import__('base64').b64decode('TmJxaVJYTFlOYTZEeDdoR1hyaV8=').decode('utf-8')
    total = value + len(text)
    return total

def _МцНΓфλΔΞьОпКογγο():
    value = 663181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgbOflMT6rI6azXy7V+GJSAozzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДζчΞηоΟФχκλГсШΞ():
    value = 777473
    text = __import__('base64').b64decode('SUdjcWRMa1E3c1hTd2xqY1VwbEw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        324
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 99 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    _dead_3904 = 748