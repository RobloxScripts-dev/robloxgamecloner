#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _фУЩхЧщΖЕσωЖжБγн():
    value = 718168
    if False and True:
        _dead_7729 = 855
        470
        _dead_3239 = 290
    text = __import__('base64').b64decode('bUFoSVF5cmVvUExWbjdmRFYxdW0=').decode('utf-8')
    total = value + len(text)
    return total

def _πΓΒйКξΦДογΔ():
    value = 538693
    if len('') > 0:
        pass
        pass
        27
    text = __import__('base64').b64decode('dkV0N3FaekV5UkdPeXZTRmNsZ24=').decode('utf-8')
    total = value + len(text)
    return total

def _ыωЗАТхИдЖΜнМф():
    value = 899665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITvCe1NvxLoVCxqvxGaXO3U1smY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИГλфИКΓδνςД():
    value = 160662
    text = __import__('base64').b64decode('YmhEZF95WGoxM0cxSDJsWDZmM3I=').decode('utf-8')
    if len('') > 0:
        _dead_7991 = 347
        93
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_2632 = 694
    return total

def _дοчЯζνРфхψВζлςΥС():
    value = 415436
    if False and True:
        pass
        148
        948
    text = __import__('base64').b64decode('U1AwOVpid1JHbXN5WE9HamxjeVA=').decode('utf-8')
    if len('') > 0:
        _dead_1066 = 679
        840
        182
    total = value + len(text)
    return total

def _ΛЫΟЮμъванп():
    value = 82665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCjTOQQ2+45RIAD6y3OnBQ0a1EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юНΣМΕчΜτΣаεΝΗδ():
    value = 809544
    text = __import__('base64').b64decode('bTVqeTRDUnVPSzQwcVZBb0lpN1k=').decode('utf-8')
    total = value + len(text)
    return total

def _тбνΧοεлσΦдΥζЬ():
    value = 22568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQG2OUMUq6wqCw259wfHPnYHx1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιμΞБΔΩдХЯβνΙδдДθ():
    value = 869578
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCq3fAY62Jg8HCOAkUeBLDAY/jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χУΥиΡΞπΧΝΚ():
    if False and True:
        pass
    value = 358681
    text = __import__('base64').b64decode('aFhiU0w4RmhNT2VqQXlVSnpLaHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ФыВпЖщюЩΦКЮлЩυχΦ():
    value = 155711
    if False and True:
        _dead_8309 = 855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3f1O1IcqpIhES3z6w+cJQt810k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХыλлоДЭΞ():
    value = 233696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAe8W18X7asEESOC3A+4PCsj1UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        534
        _dead_3384 = 998
    return total

def _кдξαсрщГψТГΛ():
    value = 32312
    text = __import__('base64').b64decode('dUx5aTl1c1Uyclk3Y2NCU01Ybzg=').decode('utf-8')
    total = value + len(text)
    return total

def _νгфжДШЭΡаХΟЙΘΛ():
    value = 400545
    text = __import__('base64').b64decode('VmI1ZmhlMGY4Ullid3lXSG5NSlo=').decode('utf-8')
    total = value + len(text)
    if 58 * 1 < 0:
        pass
    return total

def _фбЙΧАΠКΧουю():
    value = 65635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jyb3d1pspr0sLCG6+H+BAw487jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        344
        _dead_3744 = 828
    return total

def _ΝбΒАЬЩчρВ():
    if len('') > 0:
        495
        _dead_8247 = 959
        pass
    value = 290909
    text = __import__('base64').b64decode('RmFIamk3WlNMbDhvQ1BBNTdhVm8=').decode('utf-8')
    total = value + len(text)
    if 79 * 53 < 0:
        _dead_9597 = 90
        _dead_6103 = 300
    return total

def _уиРνΜЮдТнΤΚТρΔ():
    value = 953985
    text = __import__('base64').b64decode('ZjgyOXJGQU1zd2NxdnFWaE51TnQ=').decode('utf-8')
    if False and True:
        _dead_5547 = 274
        31
    total = value + len(text)
    return total

def _АαЪЦρΛΜτυуымПвкο():
    if 93 * 12 < 0:
        _dead_6872 = 500
        pass
        577
    value = 477243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBC3RlcszpwSDDyczW6XMAgZ0mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝпЖδρйξС():
    value = 689074
    if 38 * 39 < 0:
        713
        pass
    text = __import__('base64').b64decode('QlRzV1JqcGx6elBVWms0eTU3dW4=').decode('utf-8')
    total = value + len(text)
    return total

def _пюэкхΕЪΞтαБсКВΟн():
    value = 269666
    text = __import__('base64').b64decode('cVVQQ014ZHhjYXZmMGVsU09mZ2o=').decode('utf-8')
    total = value + len(text)
    if 82 * 91 < 0:
        _dead_7676 = 984
    return total

def _ΩΖΡОπЙлП():
    value = 814278
    text = __import__('base64').b64decode('UTFfWlhacGxBaGpsWlQ2NkN1ajc=').decode('utf-8')
    if len('') > 0:
        pass
        656
    total = value + len(text)
    return total

def _хСэсеθнУΚйЖγχК():
    value = 951901
    text = __import__('base64').b64decode('S1pUT1YxT3NkWklDOW1mdGg1OVE=').decode('utf-8')
    if 24 * 64 < 0:
        654
        _dead_1460 = 865
        _dead_2787 = 421
    total = value + len(text)
    return total

def _ЖΧιЮлΣеκΛнЬф():
    value = 219291
    text = __import__('base64').b64decode('dFlTWXlqbTViZ0JiSVlNUWwwZ04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΞнΖгЪσШнЕσΘ():
    value = 892719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhaza1sGqfFWKwP7/G+SGSEtvDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πтΤФФФутЪφΧηΧР():
    value = 175317
    text = __import__('base64').b64decode('TEZoajd3ZExHcmUzQ3NIXzBsaXM=').decode('utf-8')
    total = value + len(text)
    return total

def _НэΣΖηфχιьшн():
    value = 748653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBroXwJs16EICymmmXKbBx089Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πЭгСДταЫεΛБω():
    value = 647625
    text = __import__('base64').b64decode('czZ4eXM1ZXJWT0t6MVpGZldydWI=').decode('utf-8')
    if 54 * 87 < 0:
        pass
    total = value + len(text)
    return total

def _χРпΜΙьΑλΓРΡμпН():
    if 23 * 40 < 0:
        pass
    value = 219516
    text = __import__('base64').b64decode('TDI4bkNBRXZ6cXdZeklCV2hiQWY=').decode('utf-8')
    total = value + len(text)
    return total

def _δЦΞΚиΞλфζτдЬΨ():
    if 55 * 67 < 0:
        pass
    value = 445536
    text = __import__('base64').b64decode('ajJMSmZVY29EaEplbk4wTkRiYlE=').decode('utf-8')
    if False and True:
        pass
        pass
        418
    total = value + len(text)
    return total

def _ΘЪΖЛωСρΜщРЗРθμ():
    value = 492378
    text = __import__('base64').b64decode('bXZtYUpkZVdFTzlHcVlqZEVXaWI=').decode('utf-8')
    total = value + len(text)
    return total

def _νЬяΦπΧαиλκюΙшΕлА():
    value = 108395
    text = __import__('base64').b64decode('WHNidFlhMGJVMEpmQXNRUUtacXg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        480
    return total

def _ГиЪΓΤТιДиПъИьο():
    if False and True:
        535
        566
    value = 893418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axn3f0cU0apQCTWE4kySFjEcy3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯхъΧбщФСе():
    value = 856525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eyrtb3s/36cgPTunwGGFYB0m7lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЭΞъνЗщφγг():
    if len('') > 0:
        pass
        175
    value = 304831
    if 60 * 54 < 0:
        _dead_4271 = 874
    text = __import__('base64').b64decode('RmE1X09KU0RTakJTWHZYMEVTdXc=').decode('utf-8')
    if len('') > 0:
        905
        pass
    total = value + len(text)
    return total

def _кГеεыψгъΔΒ():
    value = 536392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRjcZlYL1qA2CTmh7wLGBhUd43k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_8635 = 279
        _dead_6548 = 531
    total = value + len(text)
    if len('') > 0:
        _dead_4110 = 191
        pass
    return total

def _νφηονЭдбО():
    value = 632147
    text = __import__('base64').b64decode('bFhDOV96X2pvYXYxTExUdXhBeWg=').decode('utf-8')
    if False and True:
        274
        _dead_6189 = 539
    total = value + len(text)
    return total

def _ЗκпыТΖΝφΟПδЪΝ():
    if len('') > 0:
        pass
        646
    value = 682009
    text = __import__('base64').b64decode('RlFPb0NEbUxpS09ONGdvR0JKQVc=').decode('utf-8')
    total = value + len(text)
    if 66 * 89 < 0:
        970
        250
    return total

def _ЫβχαΦГФЬΝжЫЕсАδл():
    if 74 * 31 < 0:
        pass
        pass
        704
    value = 801665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzaySwYrypkENA6xnHq8HXc2xWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ωЖКеяяιТ():
    value = 152859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxXcbwAx064KNF6H5UDAA3Z7zUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _щзШΡΛтΙφ():
    value = 778097
    text = __import__('base64').b64decode('ZlRCOVU0R0pxTno2VE5hYkgydTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _зγγиςΡΟΤХЮгЯΘ():
    if 58 * 30 < 0:
        _dead_5131 = 418
        _dead_2866 = 645
    value = 459151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3mwXV5uq6NVD1am+060OQN4y0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5637 = 386
        630
        pass
    total = value + len(text)
    return total

def _υЛδЧвИЫсθ():
    value = 669672
    text = __import__('base64').b64decode('SV9zSnNNcnVzNTRUVTJHbF9MWEc=').decode('utf-8')
    if len('') > 0:
        _dead_5298 = 955
    total = value + len(text)
    return total

def _яγОΟΩКαшο():
    value = 534122
    text = __import__('base64').b64decode('ZUlmTzV2SjE1ckxpT0ZBcHB2bXo=').decode('utf-8')
    total = value + len(text)
    return total

def _υМКΒТΑнзΡаПтЪ():
    value = 336671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCnFRXoD9YIZOSC02geJGw0g8GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХεςКЛягΨΒ():
    value = 928273
    text = __import__('base64').b64decode('dUJnUm83Sm5aN2ZTMHRNcGQyRkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ψУвцχъпΠчШТΒЪЩ():
    value = 977980
    if 27 * 61 < 0:
        pass
        128
        _dead_5513 = 725
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAfoVAE/8LgnDQ6h8HC+IjE9zTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мФΙτЯνΦοсηТЮб():
    value = 73792
    text = __import__('base64').b64decode('YmE4Z0hidVZDV3pnM3Bsel9oVmw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8423 = 637
        _dead_1136 = 377
    return total

def _βЙхΟυΨΙΧιЛΒИοйдς():
    if False and True:
        _dead_5292 = 296
        _dead_6237 = 804
    value = 705582
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAfieEADp/BSIh2C/QGcBCwMs1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠбτцПЩШΡοчκ():
    value = 741474
    text = __import__('base64').b64decode('djZfWng1Ml9fUHNyaVVmQU1FeXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ПзΟАκФХьЙ():
    value = 574727
    if len('') > 0:
        _dead_5172 = 104
    text = __import__('base64').b64decode('UFk2TGdBa2FRSzlFeXNldl9iNHk=').decode('utf-8')
    if len('') > 0:
        643
        _dead_9464 = 316
    total = value + len(text)
    return total

def _ъτЖβαΙЯзΘнДψюΞΒ():
    value = 236771
    text = __import__('base64').b64decode('Y2YzaTJMeFlNWjVBSklBb3B2ZkI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        308
    return total

def _θΗΖαгУфε():
    value = 458511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAfQUXwOxIkACzunzli6Mwgs9E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βЫюкЮωΜκκрОШψяАο():
    value = 300306
    text = __import__('base64').b64decode('cGtCNHE5MDI1S3RJc2NxWkdxcEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛзфυгβυюςыΙςЪ():
    value = 861758
    if False and True:
        972
        _dead_2209 = 493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnnWZVMjr7s2IyWl62mlJgMstXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΕКΓкЭНнЛΥπяу():
    value = 778398
    text = __import__('base64').b64decode('QVlmb1FFVjFmS0U2S09uZHNieTI=').decode('utf-8')
    total = value + len(text)
    return total

def _МъЯΡьЯФеψЩλΩБχ():
    value = 39880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnrTQ1kW/aEUKQD7nHSfGjMXt2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гЙΑЯЮГСьιОΣВ():
    value = 739898
    text = __import__('base64').b64decode('TV9neExZWk91bllxSlhrN3hISXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖБΠгνИΣθΒΤζθЗυΑ():
    value = 671861
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRXmPmIw/bgxalahn2eZPCgKzkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦкЬКηΤьсЯЬЙψμЭч():
    value = 406659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQe2YmMprYo7KQuO61yHEHR/81Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        40
        _dead_2517 = 168
    total = value + len(text)
    return total

def _ауЗчμВчχρΓдΧК():
    if 61 * 29 < 0:
        544
        pass
    value = 364662
    if len('') > 0:
        480
        226
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyLQXlptrJkEDiDz+3SJGwsKx2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΨнМДςБЗШβλш():
    value = 660670
    text = __import__('base64').b64decode('RlUyaENtQ3VfX1h2TGJ0SWVyU2w=').decode('utf-8')
    total = value + len(text)
    if False and True:
        325
        _dead_1688 = 783
    return total

def _ΗΥαγХΘЗΗхξΖБ():
    value = 506393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji3dSgAQ+qRXDgXy3ECbNyADtU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШШюЯъЪэΖλσπΗΨо():
    value = 876834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3n2b1ot97gVOCSb33ycJiwr63o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚюКΚΔБАпθСБУλ():
    value = 892065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih+xYXRr1L9aCimH20O4MTQ44WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΠШшμψΩγΘг():
    value = 70326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRzPf1Y3068qKSO64Gm8EnwL/Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        635
        325
    total = value + len(text)
    return total

def _ЮццαПζΡбЫ():
    value = 740903
    text = __import__('base64').b64decode('R3NBUHZqaG9XR243NXNNSDlUczY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩлχеЬΗЭΦЗрΝпυΚ():
    if False and True:
        _dead_5685 = 895
    value = 372383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Di6yQ3029qApAwKK3UKbHwIq3kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 25 < 0:
        pass
        972
        _dead_9591 = 817
    total = value + len(text)
    return total

def _цГρмУцЯхФ():
    value = 356855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBvnQG4QzvAZYymy0G6dGwcNzDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЙИΥΩΘσе():
    value = 47235
    text = __import__('base64').b64decode('bWlfQ1hsV2p6VjY3M3pGRFhGT1c=').decode('utf-8')
    total = value + len(text)
    return total

def _гМеΧδцΒС():
    value = 734261
    text = __import__('base64').b64decode('d2FvaEk1M3pBWWtWcG1YdWZzb1g=').decode('utf-8')
    if len('') > 0:
        _dead_9573 = 115
    total = value + len(text)
    return total

def _δθИпκпγΤδмЬΡ():
    value = 177601
    text = __import__('base64').b64decode('dlJ4aEhvdDhsUTZDOE1mT0NuNGs=').decode('utf-8')
    total = value + len(text)
    return total

def _эЬЯΚΠΖΡξЮг():
    value = 420451
    text = __import__('base64').b64decode('RlpXdHlxMXdTTjVIWkFlVVNQTFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΝСΠьбгяθεЖ():
    value = 234616
    if 74 * 27 < 0:
        pass
        _dead_2079 = 313
        329
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHvhZAI9ybooEC2h7Fy9GSokxjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖЯαΙΓΝφЕω():
    value = 654248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQDefkEd/7EZEQCu3lXAMCAL1GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΧΕпΝΗмИьеΩЬ():
    value = 523693
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh+9UXIx64YLAAap93S4BTU1tGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 49 * 26 < 0:
        818
        pass
    return total

def _лБΗιΜрΣΨЯиМзЙс():
    value = 920351
    text = __import__('base64').b64decode('b25mVVBtaENUMXZzVFAycmxQcXg=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if 59 * 50 < 0:
        _dead_2895 = 193
        773
    return total

def _οΓЙχЧРнввΥдбΖб():
    value = 532610
    text = __import__('base64').b64decode('TWpPdmNTUm54ZUhYQVo0Q1dEM0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔОλмΤΝвЗнθчΦля():
    if 31 * 2 < 0:
        pass
    value = 246316
    text = __import__('base64').b64decode('UExVcG1hWDdFb3laRGt1UWdIMW4=').decode('utf-8')
    total = value + len(text)
    return total

def _КθζгэωхС():
    value = 490194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDq2fAUBqq8JNga571mkHwcJ6Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΕЭΛеютΨΡΗ():
    value = 150870
    text = __import__('base64').b64decode('czZrSE9wR2tjd3Q2OUtpOXFudzY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8140 = 984
    return total

def _ЦзξГялαΨЕ():
    if False and True:
        169
        pass
    value = 134002
    if 33 * 48 < 0:
        _dead_9226 = 900
        436
        _dead_2212 = 552
    text = __import__('base64').b64decode('Q1hIWVc3Q2VQaERGN2k2TW5SM2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪыЩэЭξΞτΠЦοκΔΖйυ():
    if False and True:
        372
    value = 595412
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nn69SgQry55SPT2ywUSdZQt621c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠθΓХдοУξйτЦЛμу():
    if 18 * 65 < 0:
        pass
        pass
        966
    value = 504810
    if 67 * 48 < 0:
        337
        pass
        12
    text = __import__('base64').b64decode('YkNGSWZuSWthWXBFQnh3UXhDaVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗлΚπкμΧКηΨΙэγ():
    value = 418966
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSnzbHpt054xKSCXwmWSHgsZ910='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яМΠΗлШΡΕΩУ():
    value = 256388
    text = __import__('base64').b64decode('WVVCR1dDdW04ZTRtNlQ4TVhGdVI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        855
        450
    return total

def _θχуδυχΨΚПЭμΗЕЦΟ():
    value = 622506
    if 99 * 62 < 0:
        827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSrlYmcq2YolNAzx0WS9PDMXz0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚкдΟЗяшЖΝтвеТΣω():
    value = 730934
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQvWZncR7vExIA6w+mKAYAIVyTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПчкΑКЪΒУУФΧ():
    value = 28846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTuwamID2oAFLV7732WvH3Ep9Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρьДΡΓосΙΙХΦΓΙΨ():
    value = 540958
    text = __import__('base64').b64decode('WjBtUDdra2VHN1FDaEphbVFndmo=').decode('utf-8')
    if len('') > 0:
        57
    total = value + len(text)
    return total

def _ЖПкЗΤрΤшЬ():
    value = 99562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS7nY2MgqKJWbiaJ6mWkEwEa60I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖШΛЬΑМΣВжОЫЧΘкыρ():
    value = 884361
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChzcZ0MpwaAlbx+W/3PDERwg8zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЩдЮшДУеΞυΑλθЬГΕ():
    value = 481120
    text = __import__('base64').b64decode('dzFqQjM1SEtwdUFDaVEwWGhDV0k=').decode('utf-8')
    total = value + len(text)
    return total

def _αНψЮФΨςαО():
    if 100 * 26 < 0:
        123
        _dead_7539 = 295
        pass
    value = 717548
    if len('') > 0:
        855
        215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jzi8Pltr9aMJPleE932+Nikc9Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        48
        _dead_7241 = 745
    return total

def _яшОηтΧΦЮΛ():
    value = 599614
    if len('') > 0:
        705
        _dead_4700 = 765
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwHea0Mb+40ZP1+i5gevHR035W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1365 = 883
        240
    return total

def _ΞΚАηοχΩЛж():
    value = 960528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ljm2N3VprfsFbln6yX+8Ix8B0lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _АЪθИωτзΖфРο():
    value = 273359
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3bLaEIf2JIZPViV7AaGYD8QyGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕЭοдφлθΡηжЪ():
    value = 147493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECrsZGE+qaBbD1a13k6dAi0m72s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σψΟДвΚгσцпЫАен():
    value = 281679
    text = __import__('base64').b64decode('aEZDYlRXMEhEUExoWE1CUnh0UTY=').decode('utf-8')
    total = value + len(text)
    return total

def _вαΧбзэФоΜΔфИвЯχ():
    value = 280744
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgzlR3YIrooMGRXy/2meJQMbxjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чμыОΗμЕЭΤΥЖ():
    value = 668666
    text = __import__('base64').b64decode('VW5acEFqYXlEZU1WaGpGTXRkU0M=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΤΗΜΟЬЙыЮ():
    if len('') > 0:
        592
        pass
        _dead_7439 = 244
    value = 855488
    if len('') > 0:
        pass
        _dead_7556 = 643
    text = __import__('base64').b64decode('S3JtQlNFUFY0MUtZeVc1OENTamU=').decode('utf-8')
    if False and True:
        _dead_2016 = 246
    total = value + len(text)
    return total

def _эгΙΒпσЧчιЛΞΙЖо():
    value = 917482
    text = __import__('base64').b64decode('Vzh2V2FUaTYzSDNiR2Q4Yk51NVk=').decode('utf-8')
    total = value + len(text)
    return total

def _οξзΨОμЛИйεщ():
    value = 884670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQrPOV1v3aZVCBz3306dDRUI0T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эζΨзψжПξΡЗαТΙП():
    value = 303107
    text = __import__('base64').b64decode('dE9QQzc2dVhJbW4yYTdGNlRoWWo=').decode('utf-8')
    total = value + len(text)
    return total

def _нчζсБФНΧюоΑ():
    value = 451738
    if len('') > 0:
        908
        _dead_6790 = 155
    text = __import__('base64').b64decode('dW1rWjREMEVRNTgwRVNUejk2X0s=').decode('utf-8')
    total = value + len(text)
    return total

def _рЙχхηνНΝΩФ():
    value = 854186
    text = __import__('base64').b64decode('WG11Y0Zlc2V5RkdfajBMazdoS0I=').decode('utf-8')
    if len('') > 0:
        866
    total = value + len(text)
    return total

def _тйгνθνцчАΠ():
    value = 73087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXzWVHUpwaEOMA6O8W6TNhU6zWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яОΚΞСЖяЬΡЬеΡΦ():
    value = 18032
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSDpOXMh3IINNh2T/W6yJAg6sUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΚσшΧдψгеД():
    value = 336583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTrBP2QJqLAWYjWw7H6ZHTMMvUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8405 = 233
        pass
        pass
    return total

def _ьДтιαюΥаЪΤθйР():
    value = 585213
    text = __import__('base64').b64decode('cFJvb3ZOV3doTTM5bDFaX3draVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡНΝΖθфγюΩсΤЯлΨ():
    value = 33700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ihq3bAQc9YMLLy21+ESkOx8C/F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓТПъФлюβчΒАΧ():
    value = 321532
    if 64 * 95 < 0:
        _dead_4713 = 618
    text = __import__('base64').b64decode('dXRLcHZyN1gxTXZHSFJSTDJMNDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙкαсйенΓγΕλ():
    if False and True:
        94
        _dead_3025 = 579
    value = 229050
    if len('') > 0:
        _dead_4036 = 153
    text = __import__('base64').b64decode('REtyRUtWbFZVV0JvTDRuMmdkZ2w=').decode('utf-8')
    total = value + len(text)
    return total

def _нηФшΧгЧρтιΗЛоР():
    value = 614521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACzlNgEh35IPABms6wWcMyh9zGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьЙκτзМξΔυθм():
    value = 825049
    text = __import__('base64').b64decode('YjhodHZvenJZQkxSODU3anlBcWg=').decode('utf-8')
    total = value + len(text)
    return total

def _фуΚΝιυπЛ():
    value = 502493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3ryb1c2364LBSSrw06nYzELt20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΚНХАВΜΓожЪ():
    if 44 * 7 < 0:
        365
    value = 300439
    text = __import__('base64').b64decode('Tm05MXhmVzFFMFZXSVB0ZTQ3OFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ьγъμЯСκХФОρлλγΨν():
    value = 936595
    text = __import__('base64').b64decode('Yl9HRm5DcXRXRWt1ak5DcmE0Y3o=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3284 = 892
        pass
        _dead_8639 = 743
    return total

def _ΑжЩоΟМхъЦ():
    value = 839803
    text = __import__('base64').b64decode('dE1LbFdWbjY4alpMaDFyOWhKcGQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8891 = 683
    return total

def _μМшШИюΝГ():
    value = 284821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQrefkAfxpgpCTvz6nu7IA0W1z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΕβйабχпЪяγЗ():
    value = 710364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyTeOX4ezpBWDzaIwnmlJ3N87To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βоχξΗΧУυыз():
    value = 577008
    text = __import__('base64').b64decode('UE1uZE00amNOVkVqd0d1bzlRd2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ХβИьтБхУУэ():
    if len('') > 0:
        385
        pass
    value = 392835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHq1PXwdxJwNDSmswGebHnQA50s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 51 * 73 < 0:
        pass
    return total

def _ΒЬДΙЩХмΚ():
    if False and True:
        215
    value = 873096
    text = __import__('base64').b64decode('R1BWVlk5ckI1V0JqeUlUNVZUQmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΕцЩоΦКЙЖЭ():
    value = 863402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXr1emgSy7hbbR6m4FCaBgM971o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞРйΣιЖλЦЗфИДиρθр():
    value = 263262
    text = __import__('base64').b64decode('QUpEQU81dVdjZlRaamNQaGsxbHk=').decode('utf-8')
    total = value + len(text)
    return total

def _οЗΣвΑЗГсЪ():
    value = 464595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgfOd3Yj/6MbHCuLyVeSAAR27mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цщэыΑмβъφюБ():
    value = 784846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fza2QUsr0ZAGDDag5mXCAnB8zV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        349
    return total

def _ЪНыЪМсхΘъТ():
    value = 600378
    text = __import__('base64').b64decode('d01JSWV0TE9zWVBsZUdGaXpreFY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5737 = 948
        pass
    return total

def _ξчпьβЕκυΣΡΨΩΝΞГπ():
    if 7 * 79 < 0:
        898
        pass
    value = 607723
    if 97 * 36 < 0:
        135
    text = __import__('base64').b64decode('YjJoUG9nT3lFZEtIU3pfY1JKcU4=').decode('utf-8')
    if False and True:
        640
        _dead_9998 = 936
    total = value + len(text)
    return total

def _кσΡРЩδНмρНЗНджрε():
    value = 506009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mxv9OgEc77k7NAuL3WWkEQYusE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝЮоΥкьвЦΖэБ():
    value = 946128
    if 56 * 43 < 0:
        _dead_4153 = 226
        _dead_6540 = 416
        462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aw3SeUtu2fgyKlmBxX6YOAkG1Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        6
    return total

def _ЛЕΓωгΛлМΩоаЬРхЬΡ():
    value = 985401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwPrSXQf37AGEDq0+1eZYTMG9EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1386 = 726
        pass
    return total

def _ΕυТдМкψРХ():
    value = 276708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ3yd1kh8IYAPiKGww60OwN5y0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эγЙΑпβΦθ():
    value = 479799
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyHDbWE+x4ZXEC2G6kOIGBU5sV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        247
    total = value + len(text)
    if len('') > 0:
        338
    return total

def _ΚτΝфΑтжпЗщωф():
    value = 239722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHiwTFdu7fEgbiD08FHHEzYnt2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КαтЭЧлυЙΙΓφУяХω():
    value = 828138
    if len('') > 0:
        pass
        58
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRvGagls+ZooOSyRzUKJGAR/4ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЭΚбКнврΖяΠ():
    if len('') > 0:
        _dead_5034 = 290
        pass
    value = 351308
    text = __import__('base64').b64decode('Y3p2WWJnRDRqYWp4ZUk5SHNvOW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥИагδιЖЧπ():
    value = 385431
    if 91 * 86 < 0:
        pass
        pass
        291
    text = __import__('base64').b64decode('VUVTeElzYXZPU0pCU0hhTmFqT1k=').decode('utf-8')
    if 47 * 20 < 0:
        103
        pass
    total = value + len(text)
    if 88 * 5 < 0:
        _dead_6418 = 370
        505
    return total

def _гШξЫэлКσБСЪΩюцпΦ():
    value = 898909
    text = __import__('base64').b64decode('SFpibXN2NHp1RjRUUlJoVzVnbzE=').decode('utf-8')
    if len('') > 0:
        272
        pass
        pass
    total = value + len(text)
    return total

def _ЩΓΛШмВчцΖΦш():
    value = 907590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCTnWFkg8KwXPgiT/gDGECl4s3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДВТΦОРДμτАξ():
    value = 676243
    if len('') > 0:
        790
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dy7BY0c+wb0oIyOJ7kPFOS4Zt2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4590 = 777
        _dead_5955 = 515
        633
    total = value + len(text)
    return total

def _ΦыБЮЪΦШιыЦ():
    value = 60310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ES3CPlcIqolQHiKR+GGXM3Mh7T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 16 * 10 < 0:
        273
    total = value + len(text)
    return total

def _πΞПХΝЧθяечеЙхωλо():
    value = 919757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRXcfVsp1Y5XKBepxwOFPxAG1Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΚОвИθШЬοЦЩоνАТо():
    if False and True:
        932
        pass
        131
    value = 530029
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAnwW14b0popCQG2y2WZbBMWvEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аВΒφЩЬзЬЯΝАчУεц():
    value = 829695
    text = __import__('base64').b64decode('VWxjQUQxbGZqVnpGTzdlS1VUTng=').decode('utf-8')
    total = value + len(text)
    return total

def _ρъξфΒЭеМж():
    value = 796961
    text = __import__('base64').b64decode('b2ZzQjFXWXVnRF9oNGFpZUhmS3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣДГсЖбΦрУДЗиЩΠЩ():
    value = 740304
    text = __import__('base64').b64decode('UTFhRmxjdXo1YzJsZm5KNWc5R2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΒбκυПΔЕγЙεЦЕ():
    value = 153539
    text = __import__('base64').b64decode('bThkRUJvSHhxdHY5ZlpmeUZwU0E=').decode('utf-8')
    total = value + len(text)
    return total

def _тОσιнφиюυξД():
    value = 501024
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lif9WEcy8YcvaCT6n1W5ASx+/Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мЙюзэЪйСΤφпчζщηх():
    if len('') > 0:
        435
        _dead_8813 = 617
    value = 97422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXi8SkJrx4EWHiz7/lm4IQM20EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςИЮЭηδНЬΟΧбЮЯνр():
    if len('') > 0:
        764
        727
    value = 889291
    if 49 * 5 < 0:
        pass
        _dead_6487 = 601
        210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwjDWUsG+IANED27nl+TIRo58mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΘΕμХκдтκахα():
    value = 384706
    text = __import__('base64').b64decode('Um1nYlNUU3NPOHBCSWU2d2tzUGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝСЖвлГΤгφцГруТы():
    if False and True:
        655
        873
        102
    value = 839242
    text = __import__('base64').b64decode('THgwaGVweWY2VVRwSzRMOWF0ZTA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        80
    return total

def _рщоъπвЯΘь():
    value = 655493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiHgWUEj0rwzY16h7XeACz8+zks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хущЯβжΣεЛяи():
    value = 882623
    text = __import__('base64').b64decode('aVNtbm9CREtLWHJOTkFDMVBqVGc=').decode('utf-8')
    total = value + len(text)
    return total

def _жξСΨШДГΦΚмЧАд():
    value = 856143
    if len('') > 0:
        pass
        _dead_6245 = 982
    text = __import__('base64').b64decode('Tk5YZ05uX0FRQlRTa21Eak9VakI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΗИηСψНвйщЯъ():
    if len('') > 0:
        460
        778
    value = 672585
    text = __import__('base64').b64decode('QWdNQ3hKT0FBVVFITE9JSHFrRGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮяСτοзХΓΛъΞΛАуТ():
    value = 400723
    if False and True:
        11
        _dead_6162 = 101
        784
    text = __import__('base64').b64decode('Y0QyNjQyM0RHU2RkdUFXd29aSTc=').decode('utf-8')
    total = value + len(text)
    return total

def _еθЯΟΗΕфχεАЮПкφβВ():
    value = 357100
    text = __import__('base64').b64decode('bjk4bjRHT29wUkpQRG5ybnhaZnQ=').decode('utf-8')
    if False and True:
        _dead_1365 = 915
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        255
    return total

def _ХХχγΛΗыΖИцΗкνβЧ():
    value = 358119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXzFaF4IqJgFFxqp3XyvbAAgyVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дДщдΔЛιεΝ():
    value = 306057
    text = __import__('base64').b64decode('bVZLMUdsSWRUaEIxX3QzRFJUVlE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        593
        _dead_9177 = 265
    return total

def _ьΟкΛМΚγυωξςБъКМУ():
    value = 417608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgnSQ14/qrkhCR2H8m+0Fj167lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йщзΘЫЦЦЬπЯл():
    if len('') > 0:
        _dead_7817 = 321
        _dead_2697 = 206
    value = 914433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An/baFMX76kpAAq02AKyHXQp20g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΔиΧбμМФΡаЬРΟИЦ():
    if False and True:
        pass
        pass
        486
    value = 672798
    text = __import__('base64').b64decode('eUo2bDhCc1I0eTUzM1ZBV0tGclQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫωΕφλЦъеш():
    value = 517764
    text = __import__('base64').b64decode('UHVmbWZQQzdKWWVtT3NTVzJvQnA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4558 = 698
        pass
        _dead_2408 = 376
    return total

def _σШясцγчσыцΡС():
    value = 133563
    if 74 * 21 < 0:
        323
        967
    text = __import__('base64').b64decode('WUIzNE5FcFRRTmJwTHBMdTlWOW0=').decode('utf-8')
    if False and True:
        _dead_4124 = 84
        _dead_5585 = 829
    total = value + len(text)
    return total

def _АъΟТЭьβУяαяωю():
    value = 504832
    text = __import__('base64').b64decode('akFBUGt0WUJjczdLbGszRExtSHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΦΤζдеΓПФ():
    value = 658401
    if 41 * 95 < 0:
        pass
    text = __import__('base64').b64decode('cGpkcUp5Y2NCb1NfWDRCeHB0a0M=').decode('utf-8')
    if 46 * 66 < 0:
        pass
        _dead_5630 = 985
    total = value + len(text)
    return total

def _оЗдЯγыМГχкПБОчМη():
    value = 644725
    if 16 * 14 < 0:
        _dead_9567 = 870
    text = __import__('base64').b64decode('WGJobzllQjRBT1NsMXFoQ0E2RF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΩΞЫрΞΓЭкΒμ():
    if False and True:
        _dead_4532 = 90
    value = 839584
    if False and True:
        _dead_3835 = 543
        pass
    text = __import__('base64').b64decode('eEdHUUtvazRTOVpINmJOYWRaMzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _аГъΦΤйΔΖ():
    value = 84738
    text = __import__('base64').b64decode('RGRDRzJoRzNhTm5VeXdKel9oR1o=').decode('utf-8')
    total = value + len(text)
    return total

def _жчЗЩχΡЗщИυШ():
    value = 160638
    text = __import__('base64').b64decode('YlR3RDVJaXF5MjlyTFQzdlh2Ym4=').decode('utf-8')
    total = value + len(text)
    return total

def _θвтθВЛщеΜΦьφчв():
    value = 978278
    if False and True:
        pass
        903
        242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCXMRQQQq/suHy2Py1KmIgsb92w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΗмξеΤТБьщю():
    value = 642899
    text = __import__('base64').b64decode('SkxGWUpWUzVHdV83aVo3ckt6NVI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΧξЫЗлНЫБΙΗзτνУΝщ():
    value = 279063
    text = __import__('base64').b64decode('UXdKb2VUWFp2TkQ2V0lmb082bzc=').decode('utf-8')
    total = value + len(text)
    return total

def _θχΝγфΞПиθθФвμτД():
    value = 919567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwHcN1kayYBWGAur32WEFgEi8ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΔчЫφуΔΩ():
    value = 752946
    text = __import__('base64').b64decode('a01ETE8xckdLcEUwc1dic1FPSFA=').decode('utf-8')
    total = value + len(text)
    return total

def _АЮΕнψΗΙΠнρΙэτιΓ():
    if len('') > 0:
        712
        _dead_1432 = 354
    value = 822898
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('R1B3TnBvZ3ZCczI4aU90Tmt1RzA=').decode('utf-8')
    if len('') > 0:
        pass
        617
        _dead_1635 = 261
    total = value + len(text)
    return total

def _ΝоΒφфцВэφИΠМμΟκη():
    if len('') > 0:
        pass
        552
        _dead_8396 = 860
    value = 796740
    if False and True:
        pass
        pass
        921
    text = __import__('base64').b64decode('d1dESnRDUkxkbUtldUNwcjV0Q3I=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _θΣΧШΓЩэм():
    value = 542190
    text = __import__('base64').b64decode('Rm1yWE80X0g5SHNqUmlzb2lmdDE=').decode('utf-8')
    total = value + len(text)
    return total

def _αшΞΣРихνРгшοРшШυ():
    value = 435553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBjOXHYc+7g8Yi2W+gSeOgciz34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уδйΧИлΧΨеЭлоλВщ():
    value = 960227
    text = __import__('base64').b64decode('Q0VuYndqT2pQc29FazFEREpCbkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ФαУнЦзΦΒУΤвм():
    value = 879028
    text = __import__('base64').b64decode('clRsQ0VtYzBZYm14bkJNbUUyWEE=').decode('utf-8')
    if len('') > 0:
        977
        _dead_4889 = 757
        _dead_7336 = 920
    total = value + len(text)
    return total

def _ЭθеΟфΜυь():
    value = 139502
    text = __import__('base64').b64decode('TndrNXBsOGE0Wml3NHkzZWpQdzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ШПкБлβζКх():
    if 81 * 7 < 0:
        _dead_5045 = 677
        336
        _dead_6807 = 26
    value = 778350
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQbSQlxhqZkkKBv1/FmHZygN4EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 1 * 31 < 0:
        pass
        _dead_1313 = 612
    total = value + len(text)
    return total

def _ЗрОяτθζШИ():
    value = 961616
    text = __import__('base64').b64decode('Q2xLZ3dHZVp4bWdZcjAzaV8xVTk=').decode('utf-8')
    if len('') > 0:
        _dead_3852 = 582
        pass
        pass
    total = value + len(text)
    return total

def _РβγТЪτΑαЮУЩΤуφЙ():
    value = 290230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXrcXVAR3aESMRmFnAKoOiMC6Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3093 = 376
    return total

def _ΙДΗΞπъГΕΑГашюД():
    value = 349345
    text = __import__('base64').b64decode('cVdpQ1gwR0JHMmgzQ0tRTkhaR2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ςчшΝΟηΔкΟЮ():
    if False and True:
        pass
    value = 161915
    text = __import__('base64').b64decode('REEzY1NIaDlBVVA2cFpIOVZkVjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗГΟκμΠабρτκХκθΨΑ():
    value = 828907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxfSe0Fs8YElAjqIy1iDZiQj6ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧдПΑГКЯδьс():
    if False and True:
        412
        835
    value = 230912
    if 46 * 94 < 0:
        _dead_4134 = 669
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRz9O2VtpqomPSibkXmBJzAAxj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7598 = 93
        pass
        pass
    total = value + len(text)
    return total

def _ЬЫрςνΦтΗЭСЮдΤκт():
    value = 796039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ahr+PQcPq5EUECyk/nGAAXMbzF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СξγЖчаΛЙЦζнθΖ():
    value = 579072
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQPwN3oJ6fEaOSKs8HnFBBQA9lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЯηФйьЮПπэП():
    value = 213842
    if 25 * 73 < 0:
        422
        304
        238
    text = __import__('base64').b64decode('aDVib1E4UG50dXFlTVdUNU5WRGg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1900 = 791
        512
        pass
    return total

def _ЦφΡΚюχωЯЬωΜЕЗЧюπ():
    if len('') > 0:
        _dead_8526 = 487
        61
        pass
    value = 872906
    if False and True:
        _dead_3953 = 483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnzGWGEa9ZcpGASw23yxPhQW1Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЮШрξδΩобгдбЬΙΦъ():
    value = 516787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BALpQFBr2YILIyygm2+VNiAf01k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4894 = 570
        252
        _dead_1802 = 649
    return total

def _κΤВΖΑΕкγΩΔζШЙьЧ():
    if 34 * 81 < 0:
        pass
        _dead_5727 = 567
        pass
    value = 655542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiPLdlVsy5g5DCKC516cNRB8xlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮЧσВξэчеΙ():
    value = 585358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHvoPH8/rokvIC2033S2J3Et/V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3136 = 867
        pass
    total = value + len(text)
    return total

def _ηξдνΒэцοяπ():
    if len('') > 0:
        425
        72
        _dead_2761 = 449
    value = 615627
    if False and True:
        185
        _dead_8639 = 844
    text = __import__('base64').b64decode('U21CRDlVZWFJMEwzUXo5a29ZNEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΣХмСпШРΞ():
    value = 284655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjnlWQQz5ok5OSeH7UaZJD8I4jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖБЬХωΚδεвΩВγякКκ():
    value = 704339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3fhT1UDwfs3Hxq1ywavBHM87zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 58 * 48 < 0:
        pass
        _dead_8160 = 105
        _dead_5600 = 450
    return total

def _ΕωЭιПЙΧЮ():
    value = 5135
    text = __import__('base64').b64decode('d0k5c3NrRHdfaWoyTll6YXF1eHM=').decode('utf-8')
    total = value + len(text)
    return total

def _χεвιЛΞΡДаξΒнвнρт():
    value = 404758
    if len('') > 0:
        pass
        880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ij+wZ2dp36MIHhqp4FSqZBQI0WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фИζЭсяЭΜЬЕц():
    value = 965013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3jLSHo/34MOFBmI/EfAMHAHsHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИаГрзγэΛξзчЦВ():
    value = 3448
    text = __import__('base64').b64decode('dkZuRnp5dnJibjdlbG9McVJqbEM=').decode('utf-8')
    total = value + len(text)
    return total

def _яΜΚСσεпЭθЭαЫЦ():
    value = 371801
    if False and True:
        792
    text = __import__('base64').b64decode('SWJVaFVDdmlRT2pBYkRWZlk4SmM=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if 78 * 19 < 0:
        836
        pass
        _dead_8807 = 156
    return total

def _ΖьбРυЧВЬν():
    value = 760838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB69d3sv3ZsMCT317ViZDiF401k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6842 = 686
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        699
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()