#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _юФΩКсОΓЫТ():
    value = 924393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHfSUVse9fBTCgry4m6obAwn8zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _льжЮεΦφкМъЕΦУηБ():
    value = 634362
    text = __import__('base64').b64decode('YmRudU5PblV2bzh2b0RyNTM3aVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘςωфΨьΧХЛБρβМ():
    value = 159426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCDoO2Zpp5AHPV/7mHiKBw4f8XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 86 < 0:
        pass
    total = value + len(text)
    return total

def _ηкЦΓЖюКхЭτРЪ():
    value = 487326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyjIZQE477sqCRuE2GSRMiIly14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧгκцψηЬэς():
    if 80 * 96 < 0:
        pass
        pass
    value = 606709
    if len('') > 0:
        pass
        _dead_3840 = 593
        71
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhC0a1kc5PgENQmZzAGiPXwex1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_5848 = 527
    total = value + len(text)
    return total

def _УШУФΡΥвςТБ():
    value = 911752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh63TF0D3J8HK1iB3EWZH3Miz2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 21 * 50 < 0:
        pass
        pass
        947
    return total

def _ОХхЛΘтбσпΕФβ():
    value = 927484
    text = __import__('base64').b64decode('ekU5WEE3WFJzTk1OSVVpb2RGUk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑμЬВпЩκΚ():
    value = 836775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDfWV3kj0KcLMSyrzAK2AzcqzHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΝоΡдтЫψτфияВσσβ():
    value = 891667
    if False and True:
        752
        498
        _dead_6530 = 78
    text = __import__('base64').b64decode('bGs1T09Hc05jbzNlWG40b3dDTTM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2492 = 596
        pass
        773
    return total

def _хАΤζΗΑЖХпΗΟξн():
    value = 364382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxrPewge+LETbyaSx2aEIiQa81s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9060 = 453
        _dead_9966 = 782
    total = value + len(text)
    return total

def _ВНЧσшχΥВьΞΟРРБМΑ():
    value = 99323
    if 43 * 60 < 0:
        165
        pass
        _dead_1709 = 17
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Knnoa2Y/zZcXDSyJxgabAHB+zXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ноГьшЮΚκ():
    value = 96650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB3rXHMB2PsQP12K42CKYAEDvEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΜбмΖШУяЭηφιШиТ():
    value = 502556
    text = __import__('base64').b64decode('S0dtTllIOVduZThKcUFzd2hsaVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЯмЩОпПюМσесΕΚя():
    value = 866996
    if len('') > 0:
        320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KArwfHQR/YE6C1+vnke+NxEi80I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пδЪОοЫΩЩЧμ():
    value = 587752
    text = __import__('base64').b64decode('TmtXTnVzckYyRmxjakxYWDB5TEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧдΨГγΝкхΜΑΝхВВχЫ():
    value = 145709
    text = __import__('base64').b64decode('dG10cmpfSGJ3a1dQSE1GS0t2Wlg=').decode('utf-8')
    total = value + len(text)
    return total

def _РыσΥХЬκгРЮ():
    value = 720055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCnIVFprrvshah6Q2VOhZHd5tHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _осдцХПοΟ():
    value = 726110
    text = __import__('base64').b64decode('dVBtUDVxTWJlS1VMZFpPYW9fTHE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5875 = 537
        _dead_3294 = 590
    return total

def _πнΛзЧвΝμсΦΝ():
    value = 310558
    text = __import__('base64').b64decode('VDlrMm9fYldWRHpDNGlORDBZejk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЦΟΟзΚεЪшξчюяυз():
    value = 60280
    if 89 * 37 < 0:
        pass
    text = __import__('base64').b64decode('REwzY3Z3YW9keEtTb0tiTzlubzU=').decode('utf-8')
    total = value + len(text)
    return total

def _υАΔэЪЕΜяΡжЩΓκΕЛε():
    if False and True:
        _dead_5593 = 160
        _dead_4706 = 699
        _dead_7097 = 197
    value = 719767
    text = __import__('base64').b64decode('TF9DTEJpYUVmMGZHbkFuOUlRRWY=').decode('utf-8')
    total = value + len(text)
    if 41 * 48 < 0:
        _dead_6396 = 932
    return total

def _ΥчъτхццКΤМ():
    value = 677538
    if False and True:
        pass
        522
        pass
    text = __import__('base64').b64decode('Y2NYTk1HQjBsMVJnQ3BCbXdyUjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤХыьХОжГбΞУГε():
    value = 785769
    if False and True:
        930
        _dead_1976 = 137
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IijRQQIx07IHbCea6321bBwMsT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жпвξЩχνФюБφУЛΙΩ():
    value = 163879
    text = __import__('base64').b64decode('WmlYd0J2NE1xYndxT3pzVm5MdHA=').decode('utf-8')
    total = value + len(text)
    return total

def _βсАШιοΝПнη():
    value = 24200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH/MZ3A19qIzOyum6kKmOXUZ3WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 71 < 0:
        970
    total = value + len(text)
    return total

def _ψξΞνΘΡюЬд():
    value = 942191
    if 32 * 25 < 0:
        _dead_3936 = 500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBXCdG493YciDiKc4HWvIjY1y1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АиμτпцМЬфτхеВΨУ():
    if False and True:
        430
        427
    value = 363792
    text = __import__('base64').b64decode('bVF3NDMzbDVoUXJ0ZGhPbjFndWU=').decode('utf-8')
    total = value + len(text)
    return total

def _κтЯΞИРмсожКΟυ():
    if 37 * 14 < 0:
        pass
        776
    value = 717592
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwLpeXRs9P1XPgeUmULIOnEQ70w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔυΞЖΝιπωδΔΩНтαΕЫ():
    value = 27752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAHnfwMS9ZIIK1aT5gClN3Is4WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РЕФТКΟχфРфΧΕΘΗδμ():
    value = 49760
    text = __import__('base64').b64decode('a0RvTll3VVNRcVVvRV8wT0hnTGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮδοвτайτΚЕΖЧсξН():
    value = 530082
    text = __import__('base64').b64decode('V3BuOGk1dnZGUlpDbVR6dVlJOTE=').decode('utf-8')
    if len('') > 0:
        pass
        699
        _dead_9647 = 814
    total = value + len(text)
    return total

def _зУЙΘΘεΚЪзоΗαПΣЬ():
    value = 245862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRjvPQMp0v4FaTmcy1nGPQsH238='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4894 = 984
        pass
        147
    total = value + len(text)
    return total

def _ΣιχщцСΔыдШФηЪсΞ():
    value = 588808
    if len('') > 0:
        _dead_6590 = 6
        pass
    text = __import__('base64').b64decode('Q1dneVpLcTFmVFFOaWVMTUFqVno=').decode('utf-8')
    if False and True:
        191
        202
        pass
    total = value + len(text)
    return total

def _фБтВΥфьБ():
    value = 810341
    text = __import__('base64').b64decode('ZHFWTU54dmpIcVFteDNXc2J2TkY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        232
        pass
        183
    return total

def _сЗиЪГλпчЛчΙχТнΚΙ():
    value = 64591
    text = __import__('base64').b64decode('V0J2SWJOY3hmNnJIQlpxWnlvclM=').decode('utf-8')
    total = value + len(text)
    return total

def _иЪГБΤЦΨОр():
    if False and True:
        19
    value = 143786
    text = __import__('base64').b64decode('azdMQ2JMaTJzVjRlYWNrMHp3eEI=').decode('utf-8')
    total = value + len(text)
    return total

def _РМУЫюδΝгЮ():
    value = 158769
    if 95 * 78 < 0:
        33
        40
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDu3PEUsq7kuEx/x5VyWOyQ7ynw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚκНвΩΙΝΜπΟкΨΝ():
    value = 361242
    text = __import__('base64').b64decode('SUVsY0k2RkxSNnRVdmc2eFhiQ2M=').decode('utf-8')
    total = value + len(text)
    return total

def _λЗιμхрΨЙΥπιтς():
    value = 161245
    if len('') > 0:
        898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgPXRF0+qIkFO1aM0HOdFyogwDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        228
        _dead_4532 = 61
    return total

def _ЯчяУЯΜцςμоΨξц():
    value = 996833
    if False and True:
        577
        _dead_4356 = 902
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3f1f3gO0v4CFlaZmX2jPnwM60A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μкιαЕΧЯЮНзИ():
    value = 680679
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiS9aQUX/6ooGSCu8FW7GB0jtXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑбαГφΠлΠвН():
    value = 430008
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DibATVgu85goPyzzzWeJDHcNwGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τμΕςрΥΘиШτкΔΦ():
    value = 492709
    if False and True:
        915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQjNV3ADz6ANNl31+lGiAg8k8zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _йηθхсιпΞчξΙПщНбк():
    value = 126518
    text = __import__('base64').b64decode('RGlmdlNPX2xaYXdETDZpWUlGTU8=').decode('utf-8')
    total = value + len(text)
    return total

def _хЕλЗΝЭербψШ():
    value = 499603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiDAeXMQz7hWCAOaymy9AREpyUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪыйΙΤВαщφρΑ():
    value = 444623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgfiZGkp0oU3DxnyxGCoHiQHwUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧНюθПкγбщα():
    value = 761190
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj7tPno13f00GQG1+EKeNhx/5Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_5417 = 380
        300
    total = value + len(text)
    return total

def _ςУυΥθыГρг():
    value = 925917
    text = __import__('base64').b64decode('UlVTOWs2N2JLUzlLaVdoQmRWSUo=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_8032 = 998
    total = value + len(text)
    if 20 * 9 < 0:
        733
    return total

def _ιΡГвζтьΨΑΧлдсΝΨУ():
    value = 560953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDXUY2gz/5cgPi2SwnuzDnR3tkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηχνЬсΖΥфγ():
    value = 214136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3rUTUA80KAaPAGq4QW5ESZ3tXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙрщЛЯωΘγ():
    value = 28734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH/JUVYUxPpaNzqG+wKTOBINsWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        830
        838
    total = value + len(text)
    return total

def _ТτгψΠьτжцΓ():
    value = 387514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiXvOUEj3Z1VGAmanXjIZBUcy0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5985 = 654
    return total

def _μуΒЦΞψкзтζВПαуО():
    value = 325072
    if False and True:
        274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBveSwgN0rogbCmP606GOyMfskA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5047 = 876
    total = value + len(text)
    return total

def _ρΛΕКюετκДекρλδκЙ():
    if len('') > 0:
        788
        pass
    value = 790795
    if False and True:
        _dead_5909 = 771
        _dead_7981 = 570
    text = __import__('base64').b64decode('Y0RXd1pKaW5DZDZBcXFTbVo3c24=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΘъΞμιкаγЛъчыαшΔ():
    value = 18380
    text = __import__('base64').b64decode('VGJrS1RXdmpJUHRrX1JYano5Tmo=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 25 * 32 < 0:
        751
    return total

def _иоЖςифηвθЗ():
    value = 137610
    text = __import__('base64').b64decode('c0RqZmxFcmhPb29VOUM4R2VfWkU=').decode('utf-8')
    if len('') > 0:
        874
    total = value + len(text)
    if len('') > 0:
        70
        769
    return total

def _γΗγЮцфΠнοΦΣΥЕв():
    value = 443376
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS3meFdo1rICDR6R3k+aLQIG4m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        608
        _dead_1899 = 439
        501
    total = value + len(text)
    return total

def _λΦосεςщТгΨЕκш():
    value = 842785
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABDsVGdu8aQZGBvz3UWlO30mzz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЗΔξοαгΓжшλ():
    value = 94680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgazV3Ab7ZtUKDym6lGaDil31m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕωςДмаΕЮ():
    if False and True:
        _dead_8508 = 703
        pass
    value = 984097
    text = __import__('base64').b64decode('ZkR1b1VIWG9yOGhIVVByX1pOTDU=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΑιдωНΣΜθΕαпΨЖΥ():
    if len('') > 0:
        _dead_3051 = 45
        900
    value = 373963
    if len('') > 0:
        705
    text = __import__('base64').b64decode('cXBDUThKbWdMb2ZEd1JkeFUzek8=').decode('utf-8')
    total = value + len(text)
    return total

def _ζпцеЮΡпьЛПεНТ():
    value = 660037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn/AOXQX57wvNx32wXeiHRZ+s30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9162 = 382
        _dead_1416 = 105
        _dead_8370 = 64
    return total

def _ξχСλцЮΩЖ():
    value = 844305
    if len('') > 0:
        _dead_3526 = 259
        pass
        414
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwLXemIhzZcxAi2JkXiiDh0JtUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_3532 = 344
    return total

def _ΣγчоΙεАбςПЧи():
    value = 993452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwjgQ3dp8Y0SPjes7FSWZxwM1lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вСрЪлλБъςθψρэπЫη():
    value = 128685
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhXmPQAtyLI2Cxf1+2G0OAkL7jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БГхъдЪτЭп():
    value = 163754
    if len('') > 0:
        264
    text = __import__('base64').b64decode('TU85TWFoTms1eDA2YzBKYlhoNHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ыμиНλДАЖΙВ():
    if False and True:
        pass
        _dead_8581 = 265
        792
    value = 247297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCbDPgMPx4AbOzqF6k6XPBR87ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дУΨΡΞнιуАνТΖ():
    if len('') > 0:
        _dead_8296 = 746
        172
        963
    value = 80103
    text = __import__('base64').b64decode('U041NkxjMjRYR1lMZEt5SXZxV1M=').decode('utf-8')
    if 99 * 25 < 0:
        _dead_2853 = 791
        _dead_1968 = 383
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _θБηЗζСщΣэАШУжм():
    if False and True:
        _dead_3418 = 631
        _dead_6855 = 684
        pass
    value = 65308
    text = __import__('base64').b64decode('c0g3RmFoTnZmb2JFeFQxYnExRVU=').decode('utf-8')
    total = value + len(text)
    return total

def _РоΞЙЬЦЗΦПвеЫΝ():
    value = 300444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCbPUV5rposQblfx8V2JHTMmtzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        877
    total = value + len(text)
    return total

def _ГмιОΘΖШβΩгζцлΗкн():
    if 55 * 86 < 0:
        pass
    value = 972310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In7SYnYf8pEPMSqR0nKGHXIbs0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 73 < 0:
        pass
    total = value + len(text)
    if 1 * 39 < 0:
        _dead_4661 = 712
        262
    return total

def _σТэΩφΨЖФЮΛπрΒиΨО():
    value = 175717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjX+PEI3+bsxCiDx3ga+Zg0gs3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩζЩсЖπΤУЫΠωχΗρя():
    value = 524866
    text = __import__('base64').b64decode('aDJHY3d2T0ZWczMzU25waFJwMmY=').decode('utf-8')
    total = value + len(text)
    return total

def _пОΦΟψΧаΠγщΘЗρφХп():
    value = 639874
    text = __import__('base64').b64decode('cklPcmpPcGtBTnY5THAzeEJZT3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠнОΑэΞΡЩ():
    value = 907384
    text = __import__('base64').b64decode('V0k1alg1WTNJb3MxbW9RbjZrSTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ιлПГςСшпз():
    value = 88674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDXdOwMx574sIleawlyGHBUi5jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нρЩУΑЗуηЫп():
    value = 173153
    text = __import__('base64').b64decode('Ull6VjVzcnRFMWwxRHRyWFRzMWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘуχςсНДцяЩк():
    if 7 * 8 < 0:
        pass
        _dead_5453 = 797
    value = 185322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nwf+f1Zt9rsOFj/2zUXIMjAn8H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        764
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _чВψΟоьТαΝЭНнЖ():
    value = 435288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgW9VGIM7/wgEByN7neHBiAA6Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 33 * 62 < 0:
        pass
        316
    return total

def _ЩΓГΡυеγИμЦКΤ():
    value = 424872
    if False and True:
        pass
        680
        _dead_8079 = 933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag7pZkkuqqQEC1f14HyUISci9GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 89 * 87 < 0:
        107
        pass
        _dead_9030 = 738
    total = value + len(text)
    return total

def _НщюьуЯУυХь():
    value = 777396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej/rW1AJ+Y4iNl6RnQa6JCMC7XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨκμнУΜΚΕσнΨНТЭΑ():
    value = 248772
    if len('') > 0:
        555
        pass
        545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAntdgAg14smbQ2w62KBOxZ9tTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑДολСЛιΤТΘ():
    value = 415091
    text = __import__('base64').b64decode('WXFyM3ZZN25BWTFDaDlfUXd4ZXM=').decode('utf-8')
    total = value + len(text)
    return total

def _гЦцξИвеζωοшπΙиσγ():
    value = 285765
    if False and True:
        600
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jzz3PAMN2LxSNyer2F3ENRI+tE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 86 < 0:
        _dead_6936 = 287
    total = value + len(text)
    if False and True:
        848
        _dead_6410 = 736
    return total

def _ΚФΜцдΘюΦθэюо():
    value = 692237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAm9SlIXqK0gGAGg/wCXInB56Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΠοτщДЫъуψπг():
    value = 17975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASbCbFUO9J1TCAmPkF+VJnMftWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΟЮТΚЕхΝφ():
    value = 832185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwzbP1Mgqbk5BVaJ0gWdMTcN6HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘщαиχЧΒКзЬЦν():
    value = 913092
    text = __import__('base64').b64decode('Q3RET1NhbHpZblZsSDg2YllyaEs=').decode('utf-8')
    total = value + len(text)
    return total

def _цωЕЧγЖΦξΕэΟοп():
    if 97 * 28 < 0:
        923
        pass
    value = 708016
    text = __import__('base64').b64decode('TmdrdDBtQnQ0V2o4YjNCRUhfekk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΟНЧШεΥΖζεЦчλτ():
    value = 255237
    text = __import__('base64').b64decode('a3dKMGlJdGY0dXhKVTc3ZW9vd0s=').decode('utf-8')
    if len('') > 0:
        285
        pass
        785
    total = value + len(text)
    return total

def _οхОЛпЙδΗЪ():
    value = 628283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHq3PkUY+/8HNxey20CXFhoJ8WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηуθΦФЗпЫΑνΨυбртθ():
    if 97 * 22 < 0:
        pass
        _dead_2976 = 533
        _dead_7367 = 44
    value = 34625
    text = __import__('base64').b64decode('Q3UzRjZyb1FzbEh2Z2pmemlQeUM=').decode('utf-8')
    total = value + len(text)
    return total

def _НΡΜнчЪΚГЫχшс():
    value = 648638
    text = __import__('base64').b64decode('S2R4czd2SUh0UWdJcV95Y2NQVDk=').decode('utf-8')
    total = value + len(text)
    return total

def _χнцΕЬАρцХаκм():
    value = 872448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhnebEFo9bkRDRa0yme3FXQ8wmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηхΡВъδΑΛЬИпЙΟΔ():
    if False and True:
        pass
    value = 379699
    if len('') > 0:
        _dead_4103 = 760
        _dead_4190 = 375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACniVAMa56AQNBay2mGjIxc3sUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 62 * 36 < 0:
        pass
    return total

def _ΡРИχΤПъДЭδΩΣ():
    value = 960105
    text = __import__('base64').b64decode('WnpBWEZZTF9WTkw5cmYwc3JPUEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤτлЯУΓςιγЧ():
    value = 242328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgzHNgQD/IwxKh/3zl2XMCon3H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥωλОчжХлоРк():
    value = 713962
    text = __import__('base64').b64decode('QXR0eUhKbEJxTEtxN3NZcm1HUXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ттАсγЫдБйБ():
    value = 266070
    text = __import__('base64').b64decode('VUVtZWZySVNyYWZ1amM1cHE5SGg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1065 = 376
        pass
    return total

def _ЕΤΘΦζеДМДжΤ():
    if 33 * 76 < 0:
        pass
        _dead_3262 = 782
    value = 764251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dgmzf3YeqKwXaymk8XOnLH0psUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        901
    total = value + len(text)
    return total

def _ΩпмΝтЪοЖеМЬгΖ():
    value = 576592
    text = __import__('base64').b64decode('bGZ4RDBVSXJTVms1MU02TjVuaks=').decode('utf-8')
    total = value + len(text)
    if False and True:
        268
        757
        pass
    return total

def _йνΚηОχςΞΘΘΒИЛρзЦ():
    value = 613122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXnmS3Mg8oMIHFyoz13COyAN9Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _иЗБΗЧλеΥζηΤΠ():
    if False and True:
        352
        pass
    value = 889609
    if 43 * 53 < 0:
        846
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JynlamEG+KUIYwyq5Q+5JxUA22c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 18 < 0:
        _dead_6419 = 636
        566
    return total

def _хПβΓОΧΓкΟмοКуΘь():
    value = 843589
    if 41 * 20 < 0:
        pass
        798
        _dead_7449 = 904
    text = __import__('base64').b64decode('dlpWRHMzVk5LalFyR1VvYXhWVVA=').decode('utf-8')
    if False and True:
        189
        _dead_5511 = 660
    total = value + len(text)
    return total

def _ΙΑйδγНΠк():
    if 75 * 40 < 0:
        _dead_8878 = 381
        332
    value = 9209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXncSl8r9qRQIw274GKpAhc642Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 10 < 0:
        _dead_5353 = 943
    total = value + len(text)
    return total

def _νθщБΧδюЗΣΩπыр():
    value = 171259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDznTAMRy/s1NRe6+w+4Myx74mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 38 < 0:
        _dead_8814 = 264
        pass
        _dead_6107 = 74
    total = value + len(text)
    return total

def _νБьβъмΣνΘ():
    value = 590804
    text = __import__('base64').b64decode('eUZta2t0dFhvRTBzR1BBZThFUDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЙПЭзКъςνнΘ():
    if 74 * 11 < 0:
        68
    value = 151502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FizTfnUy/78sYluXzn2zIAA+8EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗχαΙфΝщφЛлофх():
    if False and True:
        _dead_3626 = 93
        _dead_7856 = 96
    value = 249690
    text = __import__('base64').b64decode('bG1TcGlXTV9rTEExVjdMMkxGQ1k=').decode('utf-8')
    total = value + len(text)
    return total

def _γκΨμΘыπХζκΛфВ():
    value = 865291
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATvuPlQd0P8RCg6BxHWcJwkevGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΙΔγχЮΑΛλЮэепηр():
    value = 111676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L32xO1QG3KtSKjemxGO1DnF5xkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛайЮБВЫΚьбσи():
    value = 971855
    text = __import__('base64').b64decode('Z3VVSVlaWU9wQ3RzODk1ejFBSEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΠТΨΦэЛэи():
    value = 173677
    if 20 * 19 < 0:
        31
        _dead_9890 = 756
    text = __import__('base64').b64decode('VExOQ0RuNDBOb1h6WE5MaEg1WFc=').decode('utf-8')
    if 42 * 61 < 0:
        37
    total = value + len(text)
    if False and True:
        848
        480
    return total

def _ЬчгФΛΥЯРыг():
    value = 233402
    if 77 * 41 < 0:
        _dead_9321 = 976
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhDqaUQuy/08aSGF/lCELCALwHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΡШиНхЩТκэΟΘΔсЦΓ():
    if 76 * 55 < 0:
        409
        _dead_3349 = 740
    value = 962604
    text = __import__('base64').b64decode('S2VkdVRxakhhdDVyRFBqYlZ1VEU=').decode('utf-8')
    total = value + len(text)
    return total

def _СмΥьρуЩссйΗΕч():
    if False and True:
        _dead_3137 = 93
        pass
    value = 227879
    text = __import__('base64').b64decode('ZUxQMnZpdzltUHZDTW1XWl9wUUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΙЛΛЯзЗξмКβπл():
    value = 899412
    text = __import__('base64').b64decode('dnlqQUZueDJveWF0MF9uT2JibVI=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ВЖЙΛΥΗРΓЫΓ():
    if False and True:
        _dead_9004 = 163
        337
    value = 787445
    if len('') > 0:
        792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhvMPwA0raRTCi2EkUHAJC0WsnY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΔΓоУΠвЫ():
    value = 349576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAe1WAQdqJcBPjen62e9HHQDt20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2572 = 688
        pass
        51
    return total

def _δΩςшЧЧчъоκаΝэЕΑψ():
    value = 129346
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSPsPnoe1vE6az6u4lecPj0qvGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_8825 = 747
    return total

def _ΖΠсМФЯуфδХяЫΝЫю():
    if 27 * 88 < 0:
        _dead_7588 = 370
        pass
        _dead_4241 = 338
    value = 408741
    text = __import__('base64').b64decode('ZWJvNHJVRkJKZkNwcTgzakZfQXk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _яκμЭЦРπИκФ():
    value = 381773
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTrrTF0o0J4IGwS6zHSRFyEWxWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦиΒПрЭЫчΚОгξο():
    if False and True:
        706
        pass
    value = 613586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzjgdFcT+ZsONiew5WWmBygF4k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 44 < 0:
        807
        _dead_1144 = 317
    total = value + len(text)
    return total

def _юмхШδЭБμ():
    value = 297207
    if False and True:
        pass
        761
        969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAnmPWdhyZAtMAyvxVihbQg9wXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 27 * 31 < 0:
        316
        pass
    return total

def _кгΛДыБξсъοеΤрОВΙ():
    value = 309416
    text = __import__('base64').b64decode('eG9odG5TUU5fOXVWWlp3R2JyOXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΖΣщФДΚпζΚΤνЫΘΛκ():
    value = 796213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzX9QEIG9IkLHDWp73vHNyl49Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зхΜΔвГиэм():
    value = 504157
    text = __import__('base64').b64decode('eWM2VmhJR3dXZlkzUGRTMWxXbmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨлΙЗьПоσλνМЩяξлι():
    if False and True:
        740
        _dead_3352 = 107
        _dead_6980 = 972
    value = 190235
    text = __import__('base64').b64decode('QlVsNWpOczNZbENQWVdDTUo5b2w=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΔσβфъРмВλΖ():
    if False and True:
        pass
        _dead_7244 = 396
    value = 863735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQz1YVsw9KIQbRi2ng+bJxcazV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_4530 = 580
    total = value + len(text)
    return total

def _αЗχΩЙФъκψСЛеΜΗΠЧ():
    value = 284003
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwjFdmYw0Zo2Hgu5/GG5YgwEwUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щШςдΛпΥС():
    value = 838967
    if 59 * 77 < 0:
        pass
        pass
        994
    text = __import__('base64').b64decode('VkZaOERac0E2eFRZRVdvS0dfVk4=').decode('utf-8')
    total = value + len(text)
    if 66 * 69 < 0:
        _dead_1417 = 624
        807
        _dead_3044 = 653
    return total

def _ΝтΜцργкфиΚтπ():
    value = 775046
    if len('') > 0:
        _dead_9695 = 451
        732
        _dead_8182 = 248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDzRRHke0qMnKg6t7Hi1HQ96/GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if 53 * 99 < 0:
        0
        _dead_7255 = 975
        _dead_5291 = 877
    print(__import__('base64').b64decode('cg==').decode('utf-8'))
if len('xxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 79 * 34 < 0:
    _dead_1003 = 885
    _dead_8252 = 485
    _dead_5888 = 460