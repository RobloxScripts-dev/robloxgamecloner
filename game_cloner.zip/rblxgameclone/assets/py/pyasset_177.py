#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ςХπΩΠνшэΡ():
    value = 346017
    text = __import__('base64').b64decode('RUlmOUJlOVoyUEJtRTl6NXJQUE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛυюбуыьΓПΙΑдψЕΑС():
    value = 91090
    if len('') > 0:
        _dead_8308 = 931
        pass
    text = __import__('base64').b64decode('TW5JcXVhUlRqaU40Q2lybVRCNmM=').decode('utf-8')
    total = value + len(text)
    if 42 * 85 < 0:
        _dead_8774 = 922
    return total

def _СчлцПгАΡ():
    value = 354002
    if 49 * 98 < 0:
        _dead_6303 = 975
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyrvbHAc6K8uEgS16QOxNXV+4mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦЩΑΞлЮвΞρПЕψэΨ():
    value = 638757
    if 18 * 48 < 0:
        _dead_2364 = 422
        _dead_3799 = 431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwDIOUBp15oHYzuUn3umJywe408='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡσιΔртЙΨκдΑτгξΑ():
    value = 516691
    if len('') > 0:
        pass
        844
    text = __import__('base64').b64decode('R2xaZFJHTl9lVE9oSEhzeE1zanQ=').decode('utf-8')
    total = value + len(text)
    return total

def _αйρЮθьжКΕба():
    value = 644454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQrDP3Ybrq0SCSuG4kOSYCcB7Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΕтсΚОζπΒР():
    value = 446398
    text = __import__('base64').b64decode('dHZ4cXI0azNrX3RndEdRRXdrMWk=').decode('utf-8')
    total = value + len(text)
    return total

def _бщπωчφΛιдоДЛшо():
    value = 65828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSHDWHws+YcyMBaEwUCqET8j6GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_8054 = 541
        pass
    return total

def _лΜΒмЧΕЦДΞЧνΩΠρι():
    value = 681823
    text = __import__('base64').b64decode('UGhydjI3ZGdFZ0FSRnU0TlJadFE=').decode('utf-8')
    total = value + len(text)
    return total

def _РЦлЧэкьθμ():
    value = 645593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC3TfVpo760abSOF7HW6IwoO9Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΠТΨЯλхЙΗ():
    if False and True:
        _dead_5176 = 779
    value = 923159
    text = __import__('base64').b64decode('UGNoQkJJUzEyOFZJdlZrREVFeEw=').decode('utf-8')
    total = value + len(text)
    if 61 * 28 < 0:
        pass
        pass
        _dead_7936 = 881
    return total

def _ΤΡоΠΖκΜъυΓΓρщщ():
    value = 438627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR62e0EJ2Z4gBTaF53yCGxIq23Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фθοεоЫбыЦς():
    value = 999589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQvhVwUcp4Q6MwuG20eUJT991Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖοεрсμВβъωПЙ():
    value = 547440
    text = __import__('base64').b64decode('RzNSRlFLYkVCMm00YXlpcVZoek0=').decode('utf-8')
    if 24 * 43 < 0:
        _dead_3666 = 258
        986
    total = value + len(text)
    if False and True:
        597
        pass
        pass
    return total

def _ЫоΦΣμиκВΘτΗэЪ():
    value = 718453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBfwOwIq54lWOFqr0HSDHhZ41W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΝХглΟГо():
    value = 522251
    if False and True:
        442
        pass
        _dead_3990 = 194
    text = __import__('base64').b64decode('VjVLa3I5b01VeGF4X2JMUmNhbWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩиεАЬσГчшКДΠТΑ():
    value = 843149
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCj8eFVvzaUHFBb13F2kNwABy2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 98 * 71 < 0:
        _dead_8319 = 848
        pass
        pass
    return total

def _ΤэΙЛαΚΡВКεАΓы():
    if 95 * 27 < 0:
        pass
        pass
        861
    value = 597883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iy3xSENs7p07GSn2ymGyJzIO6lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4888 = 276
        227
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_3147 = 199
    return total

def _ιПТΦкδШλ():
    value = 113258
    if False and True:
        _dead_3258 = 0
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQbqN38oxKUzPluL0UaBGHMDs3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΘаΚΠЧяιхУьΠЮЮ():
    value = 120519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwHFUVAu85gwL1yxnQXCYid9zUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 34 * 45 < 0:
        _dead_1981 = 909
        pass
    return total

def _сνСзΗШΙΕαРФδζт():
    value = 923296
    text = __import__('base64').b64decode('TzNNVFNXUVJwaVEwUTcyVkRxQU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ИЩφΥьΑуц():
    value = 564361
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAX8QlwA3K4OaCj043OfFzcbx1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖψΗЧЛΓЖРЛЮΝ():
    if False and True:
        244
        pass
        pass
    value = 815481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz39TWUI9r8pYjWu8GOnEBQa1zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘξСΝпΜΥу():
    if len('') > 0:
        950
        _dead_9678 = 541
        pass
    value = 111460
    if len('') > 0:
        _dead_8820 = 973
    text = __import__('base64').b64decode('S0daTDJqUzRfSmlmaEN6UEN0bEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟТяΠодКψуΝМСедъφ():
    value = 689044
    if 31 * 55 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhXTd1cUyoA8Nj2V+E69ISsosTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        193
        _dead_3538 = 969
    return total

def _ыМσЬНеτгфΩΑ():
    value = 869441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ch62XVAJ655THhum6WGRYjM87EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 70 * 71 < 0:
        _dead_3780 = 652
        pass
        pass
    return total

def _ллфчΟлфпЫΦэъм():
    value = 599014
    if False and True:
        896
    text = __import__('base64').b64decode('SmZUSUZ0d3IwbkN6MHFOQ0ZOc0U=').decode('utf-8')
    total = value + len(text)
    if 49 * 55 < 0:
        304
        850
        272
    return total

def _ЗыьμеΟжСНХΙЯτΑмη():
    value = 310173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBbJS1oM3Y02agSi3mmxYiQ1xX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        445
        pass
        pass
    total = value + len(text)
    return total

def _пВвДЧмьΜΧОφΛ():
    value = 64765
    if len('') > 0:
        733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AX7xTWE79L5XC1mBz2mxBnAF6Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωραιγΓСфДТК():
    value = 262607
    if False and True:
        pass
        _dead_8059 = 891
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgbyN3UTrZxWHBagxF+9EXQg0jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7251 = 684
    total = value + len(text)
    if 54 * 97 < 0:
        pass
        _dead_9865 = 802
    return total

def _ιэФууяцυΥрПξ():
    value = 812559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyTLWlo92v4kKwCWzFKKExU58E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ршяθеМияОΦΣζЬ():
    if 55 * 69 < 0:
        197
        219
        pass
    value = 614869
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDnlWgE9rbhSICaB+W+7LTQ58Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΥИсΛςЬΜАГйΚЯ():
    value = 148770
    text = __import__('base64').b64decode('d3RKelBZeEVUNmFjUWp0cnRRcHE=').decode('utf-8')
    total = value + len(text)
    return total

def _нπΛΠщцςвФ():
    if 74 * 65 < 0:
        354
        pass
    value = 282590
    text = __import__('base64').b64decode('ZkVaQ0lQVURrQl81dzczcG5DRjk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2326 = 545
        pass
        pass
    return total

def _ΟЦбξΦρаγу():
    value = 245364
    if len('') > 0:
        _dead_7400 = 662
        _dead_5440 = 434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQvRXlwArqIRCD6P7lOqIBQi9FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5253 = 832
        470
    total = value + len(text)
    return total

def _ςмПрВЫηΟΟΗξβπьо():
    value = 560413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgzLfHMvr68VF1q6zHvJMw8s9k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΥεвзШΗΞжэНΔЙβγ():
    value = 561316
    text = __import__('base64').b64decode('VW1CT3NfTmx1V3ZvZzZzaUpSS28=').decode('utf-8')
    total = value + len(text)
    return total

def _бъΧΥъвΩЪЯψйβ():
    if len('') > 0:
        pass
    value = 687146
    if 5 * 94 < 0:
        383
        979
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD7UNlMb2Y1bb1en5EavAjwmsHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7337 = 161
        pass
    total = value + len(text)
    return total

def _ЮцΘсΕΑнβЖУΘюΜ():
    if 36 * 42 < 0:
        _dead_1458 = 187
        _dead_8787 = 385
        436
    value = 184999
    text = __import__('base64').b64decode('RzE4bVlQMHhLSFB1d3JMVHZSY0E=').decode('utf-8')
    total = value + len(text)
    if 76 * 78 < 0:
        566
        983
    return total

def _ъγинчΘГжσχ():
    if False and True:
        789
    value = 129828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dw3hTwlsyqk1BSKv73+fOX0r6zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2729 = 478
        pass
        929
    return total

def _РΔλЦΠΑНЛΖΕδ():
    if 34 * 95 < 0:
        pass
        _dead_4312 = 506
    value = 732406
    if len('') > 0:
        pass
        _dead_5666 = 707
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgrpPFwh3aQ3AyKu+QCIYxMV3TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 32 * 32 < 0:
        pass
    return total

def _ΒγГΝοеκМЮσпМ():
    value = 469531
    text = __import__('base64').b64decode('SjFLTHBFTElPdVhsU1NvNUdBaDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ζкчτФΧУсгНМεжКΡ():
    if len('') > 0:
        pass
    value = 81313
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDvyN1Uv1aISFBmkygbBMQl61Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηζсΒΧЦΤеΨЙшΛςВЧΓ():
    value = 642993
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRjKNlwW6JcgOBeF+328FQorsTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΗσсΚΘΓУ():
    value = 452924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRvpRkETr7kyCQby/EXEMww7zmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τЩУωФυБМΨΓ():
    if False and True:
        _dead_8808 = 291
        pass
        _dead_3048 = 554
    value = 458207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCn0fmNtqP8zESmV6VTDOH0m5kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТТЩУяаχΓФ():
    value = 567019
    if 27 * 52 < 0:
        _dead_6343 = 301
        51
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3v3Ql4h9IZQGDep/3zBLA8dsH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йуμжБΦЭЙΝΩЖΙ():
    value = 309402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izv2P1As+axWIirx52agHzI941c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 90 * 54 < 0:
        _dead_9341 = 457
        205
        _dead_2366 = 466
    total = value + len(text)
    return total

def _ΜзαтΛкФКФρЫφΥ():
    value = 851709
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwHwOmI06qEaAw2J8XuiBjMu6F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жяΤюψψΖшКбψыΘ():
    if False and True:
        _dead_9007 = 118
        787
    value = 417308
    text = __import__('base64').b64decode('ZkNuVlF5TmZ2MWFwcXVydURhN1Y=').decode('utf-8')
    if 43 * 60 < 0:
        _dead_6556 = 309
        _dead_1241 = 667
        359
    total = value + len(text)
    return total

def _ъςψΒлςΗю():
    value = 900842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAbFNn880JcpbSCJ4l+vJD0ryzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬσΠΣΔЭщШΖэιиПЬχ():
    value = 243431
    text = __import__('base64').b64decode('R0NHaXNpTUFCNDZlWUtWRUdsU1g=').decode('utf-8')
    total = value + len(text)
    return total

def _εшчяεпΟХΨΖкΜΧЩ():
    value = 782571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgfRRwYB6Y0CPjqEw2C+Cyx2wHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧйЕМГйξВΓьЦдΧВΟΒ():
    value = 363749
    if False and True:
        _dead_3180 = 827
        _dead_8623 = 316
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3rIfVoeq5cNPAyI4l6kNQYOsTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 36 < 0:
        _dead_9331 = 45
        _dead_6416 = 279
        pass
    total = value + len(text)
    if 72 * 97 < 0:
        917
        297
    return total

def _БРЧΨОВэσАЫτγβΟ():
    value = 368482
    text = __import__('base64').b64decode('d0NGQ1Z2RnI4b0NiN3EyX28zaXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΞΘыГζйΠ():
    value = 922047
    text = __import__('base64').b64decode('b2o5aWgyRmFLRTczUmJST05pYTI=').decode('utf-8')
    total = value + len(text)
    return total

def _иφΒζΧеΑνВЛνхηш():
    if 54 * 28 < 0:
        _dead_8996 = 786
        _dead_7308 = 184
        899
    value = 735400
    if False and True:
        _dead_9758 = 921
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgLdbFQP1aUGFRekkFuVF3QVwEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΥοЧПфκэАеψ():
    value = 680083
    text = __import__('base64').b64decode('RVVsWjJUcVlCQjROcEgwaUIzZFo=').decode('utf-8')
    total = value + len(text)
    return total

def _βЩюзΟΙКсОΗΓκ():
    value = 465382
    text = __import__('base64').b64decode('dXl3cllZcDFTVDN5cWExeF9NVUc=').decode('utf-8')
    total = value + len(text)
    return total

def _мФαЯΛЪНЪψβв():
    value = 47821
    text = __import__('base64').b64decode('RHZpbHJPUk1CZkZWUVl6XzZZaWo=').decode('utf-8')
    total = value + len(text)
    if 70 * 15 < 0:
        582
        133
        796
    return total

def _нΗςчжСУθХ():
    value = 103710
    if len('') > 0:
        _dead_9868 = 251
        _dead_1679 = 684
        pass
    text = __import__('base64').b64decode('SngzODR0SHU2b3ZFMXFwdXIycWY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1583 = 430
        869
    return total

def _ΣχγμτΦЩμЧРтΟ():
    value = 359496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABrNe0Mc1v8WMQPx3maRPncJ6kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        957
        _dead_3845 = 716
    return total

def _εиЛυλянуΘдΨ():
    value = 46631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bz7dWVQ334cxMF6X7lCKZRYH8j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        641
        pass
    return total

def _ДΨяцлξχΘпδьЧ():
    value = 521165
    text = __import__('base64').b64decode('dDhiZlVvbGpqUEFrNUJIOXNHUk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟβδΛμΣСкαЦΚб():
    value = 90153
    if len('') > 0:
        99
        pass
    text = __import__('base64').b64decode('bGUzSW44d1ZMTnFGT1p1WEQzNTI=').decode('utf-8')
    if False and True:
        550
        pass
        829
    total = value + len(text)
    return total

def _сПоεΨΧсΧς():
    value = 88783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC3ee0YD9oUXEiT10l6AIywB4GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔньщЦΞнαρй():
    value = 154247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCzsf3oK//EhbV+XnlK8ABIMt30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΙΦМЕЭНщ():
    value = 536736
    if 59 * 24 < 0:
        pass
        986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB3CPwIvxIBQGw639wKyBAEJ/lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 7 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЭпТъюΗβΦΦжз():
    value = 67907
    text = __import__('base64').b64decode('Z043ZmRNbGhHMnk4dmlSSUJJOWo=').decode('utf-8')
    if False and True:
        _dead_9413 = 617
        _dead_7591 = 412
        pass
    total = value + len(text)
    return total

def _ΛΓрΙГЭбЖνАюбеЙσ():
    value = 571976
    text = __import__('base64').b64decode('emhkWVRmRWt1QU9WNm1vdmFRdEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ШσНΔнΗΑБυщ():
    value = 323237
    if False and True:
        pass
        _dead_9061 = 929
        pass
    text = __import__('base64').b64decode('eVl0Umszb3RQQmVxT3dYbFFWYkg=').decode('utf-8')
    if 13 * 21 < 0:
        _dead_9535 = 779
        pass
        pass
    total = value + len(text)
    return total

def _ΛчиПΡЬΩΤцКшЪК():
    value = 803548
    text = __import__('base64').b64decode('dXpmTTVUcTVkQ1BLcW15bzdpVFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ФлΙχГζχОЛΞ():
    value = 24058
    text = __import__('base64').b64decode('ZV9YMWNodGxvTFJfajVyTGsxMDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖσиРмζЧпτΗψч():
    if False and True:
        pass
    value = 426275
    if False and True:
        _dead_9996 = 604
        pass
        940
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHvnVGMNq45aNgq50lqENio67X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αжβρηλΞВи():
    value = 164967
    text = __import__('base64').b64decode('TzFIOGdHTHVUYnM0NkVhNkZWV1M=').decode('utf-8')
    if False and True:
        _dead_9523 = 689
    total = value + len(text)
    return total

def _ООФчΛγЙξωЫΣΜ():
    value = 962826
    text = __import__('base64').b64decode('Wkk0SFBRQmIybHJaZUpTS0xkV1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩБмАЕΓЯОЙΤΖЙЩБПΦ():
    value = 68558
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px7GREIIzqEIEFma2ne4PCp75jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыНλЙΜΦΠΙСрщ():
    if False and True:
        527
    value = 568598
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3z3bUds2KkrLT2o8nuKLhAO3lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8875 = 938
        _dead_2611 = 455
        999
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ЕеМκЩΒΔЭЗжа():
    value = 790841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSnGXXsq3/8Sb1el4mK1ZAwY53k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩρΠαСЦнФδс():
    value = 863818
    if len('') > 0:
        _dead_7515 = 356
        713
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTb3X3o4/f5aKgez3mKkFTIGsUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьфРζрдφВВΝω():
    if 87 * 12 < 0:
        345
        60
    value = 311966
    if False and True:
        pass
    text = __import__('base64').b64decode('cVprOGFiVThXXzJ1Rl9yM1RfdDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΚψΡИςрαсцΓсω():
    value = 951743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB/Qf2MV775SbQqOm12xDRUO8VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4404 = 599
        _dead_7302 = 544
    total = value + len(text)
    return total

def _ЭКПряΛЖΟ():
    if False and True:
        _dead_6092 = 358
        _dead_1894 = 342
        pass
    value = 383200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3jTWHUPxK4VaCySmGXGZRd+5ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2487 = 271
        _dead_2700 = 641
        _dead_8135 = 587
    return total

def _АЙЗуЯкωψЩуВλЛ():
    value = 425220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwntQGYuxqNSNDu07HyhEhwDvDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        383
        495
    total = value + len(text)
    return total

def _ξуцхιΚеыΩбЦθш():
    value = 421408
    text = __import__('base64').b64decode('YU40TnFXZkNrSGU2SEdIUHR1eEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΧЗΗΗΥωΝςΘΒЧУЦН():
    value = 65250
    text = __import__('base64').b64decode('TVdHWUc3dHU4Ml9UenpMdFRGQkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΓЕΡκвΙгρΘйζбυκς():
    value = 157005
    if 19 * 9 < 0:
        _dead_9786 = 976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyHtVG4zwZg6MCupy0KqYj0f21k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εяРΙхφьЦМΓιψ():
    value = 863847
    text = __import__('base64').b64decode('ck9fVVIzZkxnZ1lhY2tUeEtOMlE=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_8906 = 274
        703
    total = value + len(text)
    if 56 * 55 < 0:
        _dead_3377 = 118
    return total

def _РШΠЫюσЮΗУыи():
    value = 885698
    text = __import__('base64').b64decode('UGJvSkE3MHlIT2M5OHd0RzRKV1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧθвΝΤыцНΩаψΦς():
    value = 970137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXbeeHcBroVRDASH7k+nHRZ27Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΝΩЮδДЯихη():
    value = 294990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjewfF0Wx6EtKTyE0l+FA3193kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟСγКжχМΛяШфМйФΩщ():
    value = 46417
    text = __import__('base64').b64decode('ZDluSW95a3F3WWZxNndVY2NSdVk=').decode('utf-8')
    if False and True:
        787
    total = value + len(text)
    if False and True:
        _dead_1975 = 968
        682
    return total

def _фыъηЖдΦзξфш():
    value = 13931
    if False and True:
        923
    text = __import__('base64').b64decode('Y013TnFRbnFIRklOeDhwb19lRlU=').decode('utf-8')
    if False and True:
        276
        321
        82
    total = value + len(text)
    return total

def _μχпΘΕызтΗкΟ():
    value = 40488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jj7mZmg4xLszCVuC/mCHHCgNzFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αхЖюλЗЖж():
    value = 39581
    text = __import__('base64').b64decode('cWo5cjZVWGozaUlpOWVsUXR6aFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΕЫΛΧΛχоьлуФЗв():
    if 45 * 72 < 0:
        pass
        pass
        144
    value = 27544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyzwQlkY05kwPAL25UGYAhJ36GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΕЮδΟгкΟц():
    value = 373025
    if len('') > 0:
        _dead_4526 = 395
    text = __import__('base64').b64decode('S1JqV0NndEh6MUpWNE9ySVA5Tkg=').decode('utf-8')
    total = value + len(text)
    return total

def _сяαфΡЯЦрεЮ():
    value = 587377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX7eR2AsyJ4yAlj092KKJwsrtUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οХΡФγЮΨлτνΔζ():
    value = 330364
    text = __import__('base64').b64decode('cDg5VVlQdXlCdGZRMGxtN3JlejI=').decode('utf-8')
    total = value + len(text)
    return total

def _ψюТαΚДаъχχ():
    value = 15463
    if 35 * 70 < 0:
        _dead_5570 = 821
        _dead_3541 = 795
    text = __import__('base64').b64decode('alloYVlvdEwxWmtITTM4dkVOTFo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΤЕυяСЯьвБξЪυ():
    value = 202088
    if 57 * 15 < 0:
        132
        171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBX1Z2Ad6robIA22mmDCDQ0lxjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юФжнεЦлβвΛιЙ():
    if 4 * 72 < 0:
        _dead_1049 = 366
        _dead_3913 = 782
    value = 654399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzncQ2Aq1qEQETCTmGKGIB0/8X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 39 < 0:
        _dead_5146 = 88
        150
        pass
    total = value + len(text)
    return total

def _υжΤбςΥЩκЮъ():
    value = 355025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHftan4G165VHyPwnmSGICo701s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        219
    total = value + len(text)
    if len('') > 0:
        103
        385
        pass
    return total

def _НЖδтЦшСКйтρΕн():
    value = 172410
    text = __import__('base64').b64decode('UWxWU0dYVWhWMVN5ZFVVN1dvVTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛМςцМьοΗθΒАтι():
    value = 389688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IS23P18L1YYHOCCwmEKRJBML4lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χКΔдΛуχДтγЫя():
    value = 762485
    text = __import__('base64').b64decode('bGdabllMWk15ZW8wRW9HeWlib3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘыΦьЭτйрЧСЛВβУью():
    value = 380911
    text = __import__('base64').b64decode('cVg0dU1iWnZlTG5Zd1RmblN4VHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝцΩъШυθк():
    value = 234374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgvRUXYb5opbbFiFwG+BJAIe4Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        915
        769
        978
    total = value + len(text)
    return total

def _БχИΘзацΒгαΦБ():
    value = 284299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgnUf0ka8Js7Nyz1yVKnPjEcxW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛцσжΨЧχкРςαаΑцη():
    value = 774468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQrsbVgG/41WFwWV0ADGFygE4nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПЙтΚюδЯЩЗлйРА():
    value = 395376
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3fOWUgdzbkQFFqA/3mgDRZ+0ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 45 < 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_9964 = 371
        935
    return total

def _КХБШГеκпАЗ():
    value = 905521
    if False and True:
        pass
        156
        495
    text = __import__('base64').b64decode('aVFtbUZaekwxZ2pxY1hiTUpzdTU=').decode('utf-8')
    if False and True:
        712
        _dead_1816 = 100
    total = value + len(text)
    if 5 * 25 < 0:
        _dead_2207 = 548
        pass
    return total

def _ЮδХρЪдМйанυ():
    value = 637139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRnQTFccyqEFCgqynkKaYw93y1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        283
        _dead_1273 = 273
    return total

def _ЫΡΖбехρУНпчЛГρλ():
    value = 839285
    text = __import__('base64').b64decode('VHVfM3lWZnAzQ1F0S3VQVUhfSUQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ζΗΑвмιφΥФΜКΔбрЪм():
    value = 222945
    if False and True:
        787
        pass
    text = __import__('base64').b64decode('b1dZclkxYW9GYTlhVHJpTlkzUl8=').decode('utf-8')
    if False and True:
        501
        pass
    total = value + len(text)
    if False and True:
        _dead_6207 = 923
        pass
        _dead_5536 = 363
    return total

def _λΒξΒζΕшмΩφΖДЗ():
    value = 33906
    if False and True:
        277
        32
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KATeYnYd258mbiyC7FGWMyIhwX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        949
        _dead_8131 = 293
    return total

def _СитφλΔΘΧχЩЯсγаΙЭ():
    value = 255566
    text = __import__('base64').b64decode('bk1yR3pLUndiRzlpVENGZjgweE8=').decode('utf-8')
    total = value + len(text)
    return total

def _χСцнВоψΠаςΞФ():
    value = 224682
    text = __import__('base64').b64decode('elJseHZQbVcwU0lKQnRzNFZnazI=').decode('utf-8')
    if 39 * 47 < 0:
        977
        725
    total = value + len(text)
    return total

def _ΗηςфαЖΞШΔЛрσ():
    value = 813629
    if 98 * 36 < 0:
        _dead_9036 = 913
    text = __import__('base64').b64decode('aVFMc21zV1VHVnk5Y29WQ21fX0w=').decode('utf-8')
    total = value + len(text)
    return total

def _хνΥзπкτΜЩ():
    value = 192219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnnDa31v37EzMTCkynyUOn0g6mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φρμяΚτεшКэΔ():
    value = 109775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jnvmfksu+LwmKweWkHG+Yz8ct3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        422
    total = value + len(text)
    return total

def _ЦмТъОψйγзУΒиσοΘ():
    value = 666889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz/xO1862pIFMFuS62DIHiQr8l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αюЧзяΘδВъ():
    value = 594619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PB/2eWEw+ZAaYgOM4XqoGjM56Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΞакθъπΒрΤ():
    value = 516912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjW8OnAvz4MBIFeoxw+cIR8qvGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜιэЩЯδЫьЛιΤеьΠηβ():
    value = 917936
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASPPeUtg+PotOzik0HW5Gw0ZyF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛйлЛшИяЗаΤζцι():
    if False and True:
        _dead_5333 = 928
        427
        143
    value = 31750
    if False and True:
        347
        594
    text = __import__('base64').b64decode('eWNJVURnUTlHTHNEcXg5OF9wX1M=').decode('utf-8')
    if False and True:
        pass
        _dead_1580 = 553
        _dead_8328 = 852
    total = value + len(text)
    return total

def _хоμπшЦдпκμбΣκλξθ():
    if 60 * 51 < 0:
        pass
        pass
    value = 252608
    text = __import__('base64').b64decode('eHluWWdNRG52SVFzZ2RIZUdsOFE=').decode('utf-8')
    if False and True:
        pass
        183
        pass
    total = value + len(text)
    return total

def _еэМγαОЛнΣρΚэП():
    value = 375349
    text = __import__('base64').b64decode('ck9EdG5RU1NQd3htQWZQZjBBMWE=').decode('utf-8')
    total = value + len(text)
    return total

def _дΡЧΨпПΛι():
    value = 152969
    if False and True:
        pass
        pass
        pass
    text = __import__('base64').b64decode('QjVoOVVLbE5rY2c4dld6VWpaem4=').decode('utf-8')
    if 20 * 82 < 0:
        pass
        _dead_6012 = 992
    total = value + len(text)
    return total

def _гωЭδщΖΔВ():
    value = 106189
    text = __import__('base64').b64decode('azFHcnNhSFRYeWNMZXJUWklXSmQ=').decode('utf-8')
    if 26 * 11 < 0:
        544
        pass
    total = value + len(text)
    return total

def _ЗζКЯгИΓΗτΨхΥ():
    value = 584735
    text = __import__('base64').b64decode('Qk0zMG52YTA3Q01NRXhIZVJ1NWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _хОρОеΨуО():
    value = 477693
    text = __import__('base64').b64decode('SlFxNHk5T3NIZURibVhCWXI0eUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΟшЕОЦХιАгΥξпС():
    value = 552995
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCjWPQQoqo8aDV+P5Ey5ZCN4zXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔГЫЗχзωζЬРΠπЮ():
    if False and True:
        pass
        pass
    value = 399270
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgXyfAIp5/whBSb6nWK0PiJ3znY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        797
        pass
    total = value + len(text)
    return total

def _ΥЭеыЬΡЭУЭьшΧΣ():
    value = 163846
    text = __import__('base64').b64decode('bEVPdmZiVmlDVHM4N1lvdVp1TTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ρИαшΨΣШХаιγΛεч():
    value = 434722
    if len('') > 0:
        363
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbwaFk9zqolHQiCz0eKOCx56Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛγρτдσРЕз():
    value = 271105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA20fGgrzoAtHA260ATJOCgu938='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 36 * 9 < 0:
        _dead_3132 = 42
        _dead_1425 = 593
    total = value + len(text)
    return total

def _ЬВЫζпхКЬ():
    value = 262792
    text = __import__('base64').b64decode('ZXJzaHBlWHBxY183R2JPTGtGZkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘαЕΛΝзЪθΓΕ():
    value = 67895
    if len('') > 0:
        523
        pass
        _dead_7073 = 913
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB30eHcBrK0aaDuQ7EWKNho1wjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 69 * 22 < 0:
        110
        135
    total = value + len(text)
    return total

def _ΗаΕгξπСеИЯ():
    if len('') > 0:
        pass
        598
    value = 604259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTzDfkJuzoJWDQe5wHuoMg8c8l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_7108 = 838
        _dead_2365 = 776
        891
    return total

def _ЛЕψЗΩτΣЭΖэл():
    value = 887650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LA3LaXc87K4uOSH6n2K/HRwi410='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юКщμιЩРЩ():
    value = 947363
    text = __import__('base64').b64decode('dnhGRnM1QW9kTUtlUzl2RFEyeng=').decode('utf-8')
    total = value + len(text)
    return total

def _ωлηОβбйкЬ():
    value = 556462
    text = __import__('base64').b64decode('Q0tZS1dKZ3hqTVlxelhNUURueXQ=').decode('utf-8')
    total = value + len(text)
    if 43 * 7 < 0:
        pass
    return total

def _юψΨивβζΚ():
    value = 465909
    if 17 * 77 < 0:
        pass
        pass
        28
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDi1dFwc0aAuagmAzW6WNnx/5Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9067 = 779
    total = value + len(text)
    return total

def _ΤΙαЮяЯΓφцΙЪγΚСм():
    value = 264999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCfIQGdh9bkMCwC2w2K2bRUlznc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6935 = 857
        996
        _dead_7063 = 606
    total = value + len(text)
    return total

def _ΓиΨжЩιЬйцр():
    value = 76407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LST2X0MvzKoBCRmQzASnZwcrs2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝУψΘыΙФЕωΛбЪйΚΤΟ():
    value = 96732
    text = __import__('base64').b64decode('cDNCcGVlUE04TVNIX28wOHlGaHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙрΜωЕΕОЫχжВЛпй():
    value = 549216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3yxXV4SyvgSbgus5E+BZCF39mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪкоΩЛддρхг():
    value = 754498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MijpQXUay4QNBQKN/VynZgop7Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒςηВФΨмГЙτсТАйлδ():
    value = 209581
    text = __import__('base64').b64decode('U3VsVmNyUG12TVpUekJHMVl3S0o=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        334
        _dead_1196 = 529
    return total

def _ЦАκгаАρЙ():
    value = 515436
    text = __import__('base64').b64decode('SkxjOTRKTmp6VHpQNzQ4X3BUZTU=').decode('utf-8')
    if len('') > 0:
        _dead_3352 = 79
        73
        528
    total = value + len(text)
    return total

def _МювЪИΚΙИΩΙФ():
    value = 357153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRDIZlAB1YUTHR+MxFymNXI290w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζΦτΡθΡаΧв():
    value = 121491
    if 18 * 75 < 0:
        pass
        _dead_9338 = 152
    text = __import__('base64').b64decode('bVlVbmFvSzEwUmo5OTJ5S3RLQVY=').decode('utf-8')
    total = value + len(text)
    return total

def _дσΣΞъχΦΩЪΟΦЖш():
    if len('') > 0:
        pass
        _dead_5914 = 29
    value = 428735
    text = __import__('base64').b64decode('TW9hNEs1YV81SWxoZ3ZOMU5saDg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8047 = 826
    return total

def _Фφυνяитосω():
    value = 668883
    text = __import__('base64').b64decode('VHZicGNHc2ZtaHNybEFsNlRsU2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖζνтξЙΝΤгχхцНΤδ():
    value = 799491
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhzIR0Fty6sPMjmFn3DCCw8mzns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡςяшЬъθдΑо():
    if len('') > 0:
        _dead_1298 = 819
    value = 476186
    text = __import__('base64').b64decode('YzRTYTlsTGhoUjFnU21WcmNaNXU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        482
        930
    return total

def _ФдΠθтΙщνκσΙψйтΩ():
    value = 473540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwTqdkEVrIcxHx+gygHCZiQH1Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒзψαηоБΧ():
    value = 957466
    text = __import__('base64').b64decode('bzVxdm9rZ05URkJwS0pGaDlxVmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩоИγкЖэТЩΓА():
    value = 79306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3bdbEUY1I4Lbyr6/lvBZAgI82Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΗЛωДψθΔхшΗ():
    value = 699711
    if False and True:
        138
        62
        766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgjWeW4g+rEuKD608kWqYigNzDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖВгθохνЪУ():
    value = 380455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAD2VkQb8/sEHFux7mG1DHd3tl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5884 = 507
        _dead_6539 = 60
    return total

def _ФΛВΠΒЙχπшФъοЩлН():
    value = 366239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ehb2fH0Y7oRQaiv6w3uZZzw+4U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙВΙΣυъщγКЯН():
    value = 970043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M36zTENoz547KTj2zEzHIwF33XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3348 = 962
        473
        _dead_4909 = 505
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5376 = 855
        _dead_1977 = 492
    return total

def _ЖГЯКъθэУЛМωуъш():
    value = 208317
    text = __import__('base64').b64decode('cnVkQVptNnJwdkppSG91N3FFZks=').decode('utf-8')
    if 49 * 58 < 0:
        pass
    total = value + len(text)
    return total

def _ψμςрЫтσлР():
    value = 236962
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAO8OX843JguawP68QC+AyMC/ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЪΩΨдаΩсКΝΘДβр():
    value = 180854
    if 48 * 12 < 0:
        _dead_3421 = 318
        pass
        _dead_8237 = 438
    text = __import__('base64').b64decode('ZVpGdjlRWEZDQ2k2WmduYVl0WmQ=').decode('utf-8')
    total = value + len(text)
    if 90 * 71 < 0:
        pass
        _dead_6308 = 144
    return total

def _РμсΚΡΗμевэτрЛпА():
    value = 814255
    text = __import__('base64').b64decode('akRqUDYxXzNDalJHTEV2bXVuRGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩНαхШЙΣЩЧнκεΥб():
    value = 286206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRDqUX80rIInOS66nFSBOAs36WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ътяЪηрЬцξъ():
    value = 399443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn7hd0kh07AhKBuTykS9LQI27E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ουлжΑыХμьпЗβоΚ():
    value = 467485
    text = __import__('base64').b64decode('eW81d1htVnQ2bEFPVm1VYTl3S1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ГαεрΓψЕЭШηы():
    if 10 * 44 < 0:
        437
    value = 372472
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('c0FQdGdKdE16T2prZlNQRVJZZUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭωμΠσЛЬυ():
    value = 627085
    text = __import__('base64').b64decode('bG5RVVBXaU4zT1Z1SEZYZXREZ2k=').decode('utf-8')
    total = value + len(text)
    return total

def _κσΣИΠЕУΟнуσκШζСς():
    value = 865018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh28PgZhq5cBLR6Unle/ZSA/40s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υПЙГξπΗЙθ():
    value = 318567
    text = __import__('base64').b64decode('Rm14T0xtRDVucm9mRG95Uk1MdjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _МωβΘЙνΦтπИСΖЩо():
    value = 825315
    text = __import__('base64').b64decode('UzA1NFhDeTJqaVV5QWxqSHFGb3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ПъМшьБΖпЧ():
    value = 808068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBrsbAIuqIIHOCON3HO8OAp3/Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8828 = 246
    return total

def _УφтψςЙχщ():
    value = 467348
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQ7mZEFpyP5bEyub2F2zMTN/0Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΡмрЩЫПмЬЗОЯι():
    value = 310091
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz79aUk35oMaExeL+WKFHioI5Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΔλΧгλКιςλΛэ():
    if 8 * 11 < 0:
        pass
        _dead_3004 = 534
        pass
    value = 258646
    text = __import__('base64').b64decode('a2Jld2VDaVJvSlJBRkVKTTJTWjY=').decode('utf-8')
    if len('') > 0:
        _dead_5563 = 445
    total = value + len(text)
    return total

def _фАψуЬΔДТ():
    value = 168206
    text = __import__('base64').b64decode('ZlNLQTNhNVhPQ3dud0R0U3BxMFA=').decode('utf-8')
    total = value + len(text)
    return total

def _εσфΙΥмШΞБбΠеξ():
    value = 270748
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChvWO11p9L0gHQL0kVebECF8sGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 59 * 33 < 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _γΣΒΜΒыЖЕзЭЗлИπКж():
    value = 775061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DynuQ2Ue+bA1HAaWkVKALCgQ6ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λιидΘοЛψ():
    if len('') > 0:
        _dead_2843 = 923
    value = 719122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eg71TXAf1J0GFzWr/VqgZRIW0m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 36 < 0:
        pass
        pass
        39
    total = value + len(text)
    if 21 * 46 < 0:
        pass
    return total

def _аΕΓεζвТρОМ():
    if 81 * 15 < 0:
        pass
    value = 255401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgrnfHsYrqYTEl272lHJEDQZtHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9589 = 953
        307
        516
    return total

def _ΞшΜдяРΙЭЯРνΩбΑ():
    value = 745269
    text = __import__('base64').b64decode('Wm5sR1RXUkw3cTlvRjNIRDhtU3o=').decode('utf-8')
    if 62 * 21 < 0:
        _dead_9810 = 595
        _dead_8112 = 827
        pass
    total = value + len(text)
    if 81 * 83 < 0:
        _dead_1462 = 215
    return total

def _тβμЭШΓчБбИГДа():
    value = 573639
    text = __import__('base64').b64decode('YjkxalpKYTRsRGI4RjFuTTlGUXA=').decode('utf-8')
    total = value + len(text)
    return total

def _ыИеεσОΙΩςπΔΡЯРЧП():
    value = 251570
    if False and True:
        pass
        48
        _dead_1993 = 854
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyT0RngLrP0VaAmzmAKcZSY4sFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 84 < 0:
        pass
        _dead_6672 = 548
        pass
    total = value + len(text)
    if 60 * 15 < 0:
        _dead_7066 = 589
        266
        pass
    return total

def _θШΤττУЛЕГПСщбъΕ():
    if False and True:
        pass
    value = 634652
    text = __import__('base64').b64decode('ZWJoYUpnUTlyOHJYNmJzcXBtWE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ХЯΙЗωΥщкξщгοΡрЕ():
    value = 905980
    text = __import__('base64').b64decode('Y3Q3dVp1VGdRQkhsNnFhVFI5c3Y=').decode('utf-8')
    if 66 * 33 < 0:
        _dead_6652 = 999
        402
    total = value + len(text)
    return total

def _ΡбδУшаФΠαςбλ():
    value = 980184
    text = __import__('base64').b64decode('SENzSmlIeERnWXJSTkZCVWdlVjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ГВТΡЪъΧПοεδРοЩн():
    value = 123065
    text = __import__('base64').b64decode('aXE0UE5JdWdpM0xKb3JsZkU2bW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩχФдΧУыГσЫΕΛгφ():
    value = 132545
    if 32 * 1 < 0:
        _dead_5179 = 582
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwzjZ144ypItMQGv0Q6FBTwA72Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 41 * 43 < 0:
        _dead_2618 = 643
    return total

def _ΘεЙБβрРЛОс():
    value = 665048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgLAX34y2Z9aKCqy73SfNXMl4jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΑηдΙΞРσ():
    if 85 * 47 < 0:
        _dead_1192 = 731
    value = 975486
    if len('') > 0:
        pass
        485
    text = __import__('base64').b64decode('RjZab0M1UnpzbWxqZTBkRTNVQkw=').decode('utf-8')
    total = value + len(text)
    if 98 * 68 < 0:
        pass
        _dead_2901 = 937
    return total

def _ΒтЦвΗΥсΟνυГ():
    value = 111692
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAewYFkzwaAXHlmr7Fq/bC8Eyj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('cg==').decode('utf-8'))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()