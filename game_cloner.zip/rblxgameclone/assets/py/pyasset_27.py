#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _гщЗΟθЭΓБЫЗйΔрТБ():
    value = 326436
    if len('') > 0:
        355
        298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ehm3ZH44q/kALRv20kSnIB0X1VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εоΩφзЬюсы():
    if 56 * 8 < 0:
        pass
    value = 603376
    text = __import__('base64').b64decode('dXlRZnViSDNzWUNvMkRzNzR6UlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚРρΖЯАЯнυ():
    if False and True:
        164
        pass
        pass
    value = 657558
    if False and True:
        pass
    text = __import__('base64').b64decode('VDl2eV84UjMzRnRwY0JrWjd3bE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЬЦτЭφДпΣфΩθΞΞι():
    value = 440285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDfuXV8D1YUsMR6O5GWWHgwJ0lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕλζфλΦТλабЕ():
    value = 142003
    text = __import__('base64').b64decode('YkROZVFxaVpuMzVfR1YzNjU5Y2Y=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9236 = 604
        _dead_5752 = 722
        732
    return total

def _ъητЭλзйВΨτχы():
    value = 670028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQXxOQEVzq02aSG1zQK+JDImw0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιйАαяпшъλю():
    value = 209795
    text = __import__('base64').b64decode('QXRpcDcwQ2Y3TGhVVEV3bjBFTVI=').decode('utf-8')
    total = value + len(text)
    return total

def _юφΤюνЭρεΑбΠЦ():
    value = 426766
    if len('') > 0:
        912
        _dead_9456 = 372
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRWwYlNp96ovDjik+36WBjR+23c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8482 = 518
        146
    total = value + len(text)
    if 15 * 24 < 0:
        pass
        332
    return total

def _хООμцГХШΦΛл():
    if False and True:
        pass
    value = 632324
    text = __import__('base64').b64decode('azlfTktnRWJ1TEhoQVJBcV84a2o=').decode('utf-8')
    if len('') > 0:
        _dead_7365 = 102
        pass
    total = value + len(text)
    return total

def _ΙШНыгсцОщцнΝи():
    value = 328601
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDXMWXZozoxRHyGCwGGyMykQ0Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6785 = 407
        pass
    total = value + len(text)
    return total

def _тшΜХтЕОПкДκΗС():
    if False and True:
        _dead_4979 = 261
    value = 944016
    if False and True:
        _dead_7286 = 991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EijRRmtr1akWKz6C0VOAJiMi7E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζτрΜιхГЩτчЯΑΣ():
    if False and True:
        449
        _dead_8524 = 953
        pass
    value = 601493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDu1T0gw3KFSAhWQm3HIAhIe1Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        507
        pass
    total = value + len(text)
    return total

def _ПСχΞВфюЧАλАФΩως():
    value = 888894
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgfnS0kJ35c6Lify/WGlDgcZsn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        180
        pass
        pass
    total = value + len(text)
    return total

def _ρФйЪΑъδЭΝБЛАα():
    value = 944684
    text = __import__('base64').b64decode('QkNfQkdmNHlaRUZ6VFIyWU9mXzI=').decode('utf-8')
    total = value + len(text)
    return total

def _рκЖЙтΔυзЗΟруГκ():
    value = 900860
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwO0ekEW0fEuYxrxkA6jMSwV1mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ψωрщΣГΝТпЯсъθт():
    if 71 * 98 < 0:
        pass
    value = 364810
    text = __import__('base64').b64decode('cGNpSGg1REhTQXZzM2hjcXNtQnU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2071 = 122
        _dead_1746 = 854
        81
    return total

def _зЧДЩΦыВаЫρσаррΔВ():
    value = 891752
    text = __import__('base64').b64decode('S2pJbGdid3dISGh4YjlkRkdkelo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛбМЗΞяАЯΙΣ():
    value = 807124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3buQn821vAOICSzzEe2P3J+9zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        773
        _dead_2244 = 24
        292
    return total

def _мΞуεцμЙθИЦьχтЩм():
    value = 990625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX/gPmEG3LAJIiiowXC6NRo3tmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иνНθяорЛЛγЭЗ():
    value = 467817
    text = __import__('base64').b64decode('RFM0UFZ1Q2R5aVZ1cm1lQkF4enA=').decode('utf-8')
    total = value + len(text)
    return total

def _эйΘЯΒФμζΟшςЮΧ():
    value = 667248
    text = __import__('base64').b64decode('SzdISXlFQkZxdmo0WDk3RUUxelE=').decode('utf-8')
    total = value + len(text)
    return total

def _оχΚΝСЕφΛΟΝζЧΠλчА():
    value = 31106
    text = __import__('base64').b64decode('djV5NjBmTkNnWG81VGJ2OEJyZWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ОШΙТХКПмпЭφл():
    value = 672586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej7PdFMX+fozNjiQ2HOiJHI+t3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЗгρΤПЛзζτΑБяΘлР():
    value = 534047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSnQdlVs941QDh+m/A/CDHweyjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΗЗыΖзΕαυЩγοэЗΡуГ():
    value = 573812
    text = __import__('base64').b64decode('Vk9wVWx2VGR4OXFMZnJlYkpkWFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _кΨШηЭЫъψЦЭЕ():
    value = 403212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxDdTGQG7oQSYlqmxHmoYjc48lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мφгИνКΠйΨνΟο():
    value = 138820
    if 89 * 30 < 0:
        pass
        pass
        _dead_7678 = 645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCOyS38J2INbGx270leaJjc7/X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХСфщΛАнБлЛзЦΥхвω():
    value = 733739
    text = __import__('base64').b64decode('QlBPZ1l3eDRSZFpkUFJPS21NR1U=').decode('utf-8')
    total = value + len(text)
    return total

def _РСΛψθЖλΗЧс():
    value = 342348
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HALbbV8JrYoNIiS2x2OHLiccwXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШθЖΗψВхяыδЮЦЩζчδ():
    value = 154977
    text = __import__('base64').b64decode('Z3NDaHJZcERrdmQwRndJQjhqOGE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        603
    return total

def _ЖХпЖУβДпФЭЮжя():
    value = 27416
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXvMUUYB6bsRLjya8XXCOR0Ws14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟσШшъЦвг():
    value = 649005
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzbQR0BqzqMoGQuG0GKXJXIF7Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κιΗьγηЫц():
    value = 578192
    text = __import__('base64').b64decode('T0dFNlIybEZIRVFZVWZvWE9YOWk=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _μεоЖТМьМψящ():
    if 39 * 52 < 0:
        277
        pass
    value = 630590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASjcSWcQy/0tNz70wlyCZXQ1vVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ηЬЛνвτхΛθДХУкψΦТ():
    value = 408296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERa2YkQt0vEUCyfwmG7HZzAb8lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟηΔоьΨЮΕιΗχλщ():
    if len('') > 0:
        661
        pass
        pass
    value = 64206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCXDXlMs+pkkawC0n3C7NTQ6yEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4080 = 154
        816
    total = value + len(text)
    return total

def _сΘΘВкБЬγЭβΧЖнЕ():
    if 88 * 19 < 0:
        _dead_3366 = 866
        949
        pass
    value = 71012
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj/HfAEs2qYWEh6z/FmvHiM4wjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 47 * 59 < 0:
        pass
        pass
    return total

def _ΧИςткνБΔ():
    value = 910545
    text = __import__('base64').b64decode('R1VGTGtmS19sQmxLazBScm5PQm0=').decode('utf-8')
    total = value + len(text)
    if 47 * 37 < 0:
        pass
    return total

def _τЖыХλХγгΔтπαΝЖТ():
    if 92 * 77 < 0:
        pass
        _dead_1642 = 182
    value = 898484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBftOlseq40BCBqy+EyqEx8esDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙаροнδεИоА():
    value = 715499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSLeSkgA5ooXPyaa+kK3HAsr/Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 98 * 90 < 0:
        _dead_1015 = 488
        290
        830
    return total

def _ψφъФΛαιФыΝ():
    value = 102094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSLyfGspqpoWaD2nzFe/PSEc20k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хβπδФДцюКЫЪ():
    value = 331598
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jw3nfnIAya5bEl6i4lmbOBos1Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИъΑЗХςЛА():
    value = 96830
    if 77 * 65 < 0:
        pass
    text = __import__('base64').b64decode('Ukh2MVRqVGtCQlNRRVU3dmhubWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠλπыАτξЫсЧЯβБш():
    value = 384463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT/XQ0ItwYcaagmw5Hq4IA8t0z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡгεγΠжИЫΓο():
    value = 379536
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('YVBlUHdJT1FKMWltTTFqc1gzdUo=').decode('utf-8')
    total = value + len(text)
    return total

def _дΝΗπиΔεПщΛΜΙκΡУ():
    if False and True:
        _dead_8655 = 138
    value = 890000
    text = __import__('base64').b64decode('R1RacmwzMk93dXdNMmswdmVZeEw=').decode('utf-8')
    if 18 * 76 < 0:
        460
        42
        pass
    total = value + len(text)
    if False and True:
        587
        595
    return total

def _шббЗвΣъеΨнх():
    if 57 * 64 < 0:
        722
    value = 590273
    text = __import__('base64').b64decode('eU9UelBwU1dOWkFjYTRjd05oTEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝДЛвοрοΩпюφ():
    value = 373249
    if False and True:
        276
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fwb8ZHgO67pSEVmh0lOFPTAL4kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 99 < 0:
        _dead_5446 = 558
        709
        171
    return total

def _аэΖнΥΠЩф():
    value = 421741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MibzbWc8zpoVaxiznkaUM3J422Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟцμГСΠлхΨ():
    value = 952062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgjQRFIB06QAaBmR/w+JJR0q90E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 11 * 49 < 0:
        _dead_3024 = 136
    total = value + len(text)
    if False and True:
        _dead_1661 = 722
        pass
    return total

def _СарΥνзбрщь():
    value = 676324
    text = __import__('base64').b64decode('TjRVVFRFczZnN1FPYUhReFI0WXA=').decode('utf-8')
    total = value + len(text)
    return total

def _ОςσыИЫлςΒаπЧы():
    value = 317816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz7uWAMG7rxSDxq52GmjJAAC1n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _утАνЙьοΞУИЩ():
    value = 400634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSvbOQg/3K8hIAGG3FixPnYr83o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УШюлΞΘоАА():
    value = 991030
    text = __import__('base64').b64decode('TzZhb24xU05rSVUwZjE5d2ZwdGo=').decode('utf-8')
    total = value + len(text)
    return total

def _еЙРΖςΨяеΔεΟ():
    value = 422036
    text = __import__('base64').b64decode('b1Z2RzdBQWJqRkhwUWg0Z3NucDg=').decode('utf-8')
    total = value + len(text)
    return total

def _рЦкςγгΖШГц():
    value = 483216
    text = __import__('base64').b64decode('cmwyOVo3TkRrN2FXTkRIV3RXZjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ПπηшдвπрΓЙςфπЗЬЛ():
    value = 654554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzjhQV80p78kAyuK8maKFycZvDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΑЙΦΗыТЬνо():
    value = 592031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAHLfgQjyJ4uFhfw8F+yMw170ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZA==').decode('utf-8'))
if 98 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    _dead_7592 = 83
    858
    _dead_3053 = 48