#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _μАцАΤдЛΠΒАΟΟς():
    value = 931818
    if len('') > 0:
        _dead_7824 = 386
        _dead_5996 = 385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCDIOUQp0qUVFD6Tm1fEOCoBvTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 73 * 80 < 0:
        pass
        490
    return total

def _сιСРынκΗΖТΞиΙ():
    value = 13613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx7eXQcbq74PK1v163WAFwB2520='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УжΜΙξφЛТсЭРΒиа():
    value = 574008
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnbeZl0zz69RbQ667HW7OBMqtHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΠзшеПρоΑдтΜбΔβШ():
    value = 688513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eyn+SnM9q55aPy6N9wGjDhYM3HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТσГМлМлСхНкЦ():
    if 62 * 76 < 0:
        pass
        pass
    value = 167611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzvRbG5t36c8PSiU73C3Mz096lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮрΙчζχтБгУЗπσИФ():
    value = 375629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAPyW2Uj9poIbS3x/HmSMRA4xl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εкдφкоБΙΟ():
    value = 461915
    text = __import__('base64').b64decode('Q1ZaU1pYRXZHNm4zUUdoUW42cWs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2436 = 939
        _dead_3889 = 871
    return total

def _ΡшΥЙрэчΥэжΚ():
    value = 902102
    text = __import__('base64').b64decode('R0dUVXBNaWdzNXJKRVVBRHliUmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖвΑΓюЦτΕΙБΠΟμр():
    value = 49240
    if False and True:
        _dead_5995 = 10
        _dead_9393 = 506
        867
    text = __import__('base64').b64decode('UzhYMENSNjM3Wm9IRnRSUUNqQzM=').decode('utf-8')
    total = value + len(text)
    return total

def _λρωиЮβщμуζ():
    value = 620316
    text = __import__('base64').b64decode('dm1oRWo2S05lZUZMUWRYazNkRU0=').decode('utf-8')
    if 93 * 86 < 0:
        pass
    total = value + len(text)
    return total

def _ЧАбЬπЕВК():
    value = 767426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCjGQWkg1IwMExuSwmKAMS965kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЛУμτЧζзрΜγηА():
    if len('') > 0:
        pass
    value = 234886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECmyQmhh/IErDiKo/Q+bGQ4FvUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5898 = 13
        _dead_7745 = 774
    total = value + len(text)
    return total

def _μΘЧпУсβΤзεχ():
    value = 833419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnbMXlwh1aFXD1yNy06DMC4Y1H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝαДΔуРЦШρВ():
    value = 151410
    if False and True:
        _dead_9597 = 963
        480
        580
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICneSwE0+LskaD/wn1ubGzwh1FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 65 * 71 < 0:
        pass
        pass
    return total

def _ХЖХδσРΞЙ():
    value = 93815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bji2X1oJ8b8Abz/x3GyRJAsttjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟЖЕΩяΕωШяΥчζαьи():
    value = 737255
    text = __import__('base64').b64decode('b05SZjc1aDJlaGoxTnRacU1ROUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛωИχпбВλΦКиΙбШ():
    value = 625448
    text = __import__('base64').b64decode('UHFBdmFHU3dUaVBISG04Qm5GRGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΤΣБΝЛЩΣгΨС():
    if len('') > 0:
        _dead_3280 = 190
        583
    value = 909655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F373Wlc68qYaMAOqwGbJIhUQy38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΡЫκΒμНσΥм():
    if 5 * 87 < 0:
        _dead_1506 = 556
        722
    value = 351427
    text = __import__('base64').b64decode('a0Y5UUtOSXVPUjA4OGJFbFNQYVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚδРжΥУЖΞδΒεЫсмОΥ():
    if 85 * 6 < 0:
        387
        _dead_8858 = 172
    value = 511600
    text = __import__('base64').b64decode('Tl85RjlBWXppUzdxUUV6eXI0MTE=').decode('utf-8')
    total = value + len(text)
    return total

def _βιρюХΓфТюψЖЪξРПΖ():
    value = 480393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwXTQXof8r42HzW7nl+CGT8d9lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 74 < 0:
        238
        975
        _dead_4670 = 888
    total = value + len(text)
    if len('') > 0:
        75
        pass
        _dead_7090 = 163
    return total

def _ШДΓοПιΡю():
    value = 538538
    text = __import__('base64').b64decode('Q3RLVndDQW1Wa3RudDI2SnZ1MVk=').decode('utf-8')
    total = value + len(text)
    return total

def _срКШКмЙш():
    value = 952445
    if False and True:
        _dead_8438 = 487
        687
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FB6ydgUDyKYILz2Q0WLAOSAH92s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юФтКЗΦΨрδχτфЗΦ():
    value = 4215
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('STUydnN3QXB6NXBHRWRuQ1hQWlA=').decode('utf-8')
    if len('') > 0:
        545
    total = value + len(text)
    return total

def _РышмрιЩγЛςэЪ():
    value = 285820
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwTdaAQy3JEwNgO0mE66FRR3930='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _КЕΟРοβФацς():
    value = 584538
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3+yVwQ32/4WbAytmn6zYAAV53c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        762
        _dead_2764 = 929
    return total

def _ыΥΧцгΠΣрйσνΥπΣжζ():
    value = 447950
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('RlozbmlzT3ZVM1NfbjREbHdsdmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΨЮЬΜΖωОТщΦХН():
    value = 921062
    text = __import__('base64').b64decode('RzUyT215OGJSd1R5RERWWktadm4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        393
    return total

def _НΙΓνΗοЪЪГ():
    value = 695492
    text = __import__('base64').b64decode('VUhoS1VKcjVCbmtXTmxBVDBndFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _θΞΑΙжБоББΟρСв():
    if 67 * 88 < 0:
        _dead_6804 = 889
        0
    value = 652742
    text = __import__('base64').b64decode('dHFIVkgxWWM3YXBzUGt4Q1YzUDY=').decode('utf-8')
    if False and True:
        379
        pass
    total = value + len(text)
    return total

def _дзаЮМфΔсьъ():
    if 3 * 2 < 0:
        _dead_7666 = 994
    value = 415836
    if 59 * 19 < 0:
        _dead_2941 = 678
        _dead_5577 = 788
    text = __import__('base64').b64decode('YzN2YXZ0RHVUem9xa01DWG1INkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚрЬεцХщЦБОξΗиУΑ():
    value = 556500
    text = __import__('base64').b64decode('R18zdHJodFJJbjk2dTNaOUUyX2Q=').decode('utf-8')
    if False and True:
        _dead_3436 = 588
        pass
    total = value + len(text)
    return total

def _ΟхΞОзοШчΔεП():
    if 33 * 50 < 0:
        pass
        71
    value = 321938
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DS3zd2BrzLoZFFuV+VyqEBB7zW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΚβτΥшВИφхΡιΧδΕΠγ():
    value = 539617
    text = __import__('base64').b64decode('SFppelJldHJFMnNzR2pZWWRpd0s=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_1736 = 216
    total = value + len(text)
    return total

def _σψфждθзΠηΡЮржβя():
    value = 207341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mjr9OmYUzIURFy6InWGgBjEX0ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        134
        pass
    total = value + len(text)
    return total

def _ΔΧБαфхщМЗаυпвц():
    if len('') > 0:
        235
    value = 154505
    text = __import__('base64').b64decode('RFZVMjBCZm1pSmZuS3ZlZ3Z1UWQ=').decode('utf-8')
    total = value + len(text)
    if 100 * 31 < 0:
        pass
        pass
    return total

def _ИΩОφΕΙΤмНΙйи():
    value = 145830
    text = __import__('base64').b64decode('YlRFWGJaRTRjY0RWZWhJMjY0NHI=').decode('utf-8')
    total = value + len(text)
    return total

def _нЫРчоσуΟΣСΛъθК():
    if False and True:
        pass
    value = 154661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQPyPGs19PxXHy2A3W6COnJ9yFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2914 = 892
        _dead_9531 = 217
    total = value + len(text)
    if len('') > 0:
        420
        715
        271
    return total

def _υФςπъОξпκ():
    value = 929019
    text = __import__('base64').b64decode('czFYNXpjR0J5YzFMSHJ5eHZRMzg=').decode('utf-8')
    if False and True:
        _dead_4630 = 904
        850
        75
    total = value + len(text)
    return total

def _ФотоНΝМЧκχΤотрът():
    value = 808291
    text = __import__('base64').b64decode('RUR0bU1JWHkyY0M3dzh5QmsyNlE=').decode('utf-8')
    total = value + len(text)
    return total

def _εНяθυΓξфОЭЦχχΒΜй():
    value = 106509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgfDSGQu8bkAGVqF5lqDO3E9vEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΓаМкΤЫю():
    value = 472172
    if 66 * 86 < 0:
        797
        301
    text = __import__('base64').b64decode('VndWRHEzY0VXTlZyckNUUTVKdGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΟνΨиΥгЗкυЖиЧф():
    value = 189832
    if 31 * 75 < 0:
        _dead_6472 = 846
        _dead_1691 = 694
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERbvV3Vt3PghKg73+0STZgEG82c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫλжηХиΤйтАЧΓрε():
    value = 984243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR32fmQ19oZXCiGWmWe8Cy8+7zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝιηΧцΖΞжαчνι():
    value = 129166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX3OamAX/4UhIha3n3WIDnEl5no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4510 = 206
        534
        _dead_5102 = 751
    return total

def _ΧЬΞφΖэгэμИй():
    value = 704276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cwm3WV4bqIM0Hx6y7nW8MxV+4T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        630
        _dead_8610 = 98
    return total

def _ΥкρУτюЩη():
    value = 453783
    text = __import__('base64').b64decode('QnJpT2pPQzVnV2lweVpKT3ZJb28=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧКφЗЩаΝμ():
    if len('') > 0:
        270
        pass
        _dead_6215 = 717
    value = 566522
    if False and True:
        _dead_2318 = 139
    text = __import__('base64').b64decode('Wmg3bWxUYWxsNm5sNEhaX1hBMWE=').decode('utf-8')
    if False and True:
        514
        _dead_3052 = 495
    total = value + len(text)
    return total

def _пξΒΣбаъыπЛаш():
    value = 457625
    text = __import__('base64').b64decode('R1U4NVBKZjVXMWhZZ1F4U2hrTlg=').decode('utf-8')
    total = value + len(text)
    return total

def _цΔЮХЛυΓΩΤйяк():
    value = 653001
    if False and True:
        452
    text = __import__('base64').b64decode('TFk0d0ozeFFkcHBXQ1R3eEh4VkI=').decode('utf-8')
    if len('') > 0:
        265
        _dead_1406 = 626
    total = value + len(text)
    if 30 * 86 < 0:
        425
        pass
    return total

def _ΨμЫцλеΦкΑΘКгψφ():
    value = 928514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRu2WFsNyKwWHjir40eIbQF6x0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΟПλΔюφΒГΗЙЕрΠзШ():
    value = 232731
    if len('') > 0:
        _dead_1663 = 965
        _dead_4884 = 1
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgzISlUd070JFCC36nuhOHc67mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΗеΧТнДФτчΙφ():
    if len('') > 0:
        _dead_1291 = 660
    value = 675603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR21a3gR/bAbEDXx33ehGwF6wnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2417 = 925
        pass
        285
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _эΚИψΣшΗΓЦЯδТ():
    if 89 * 74 < 0:
        986
        886
    value = 107663
    text = __import__('base64').b64decode('dkZ5eTJUcmNZRTRGanRGS09Ma04=').decode('utf-8')
    total = value + len(text)
    if 12 * 76 < 0:
        _dead_7103 = 964
        786
    return total

def _ГгжЖтζΣфьщ():
    value = 983237
    text = __import__('base64').b64decode('Q1FpOTF4eE9iMjZJMWhjcWl3VmM=').decode('utf-8')
    total = value + len(text)
    return total

def _йЗΣрЬсыχЖδкΟ():
    value = 649070
    text = __import__('base64').b64decode('WlljVWRzMXRxb2dNOXdfc196Q1E=').decode('utf-8')
    total = value + len(text)
    return total

def _κИЕνθΞΕх():
    value = 148972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgDDOGkp1f4LHgG76kOyNjZ56kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υδЬкΓхΠЯжНКОк():
    value = 669126
    text = __import__('base64').b64decode('dzhLNWpESlkwR1dBQ2s5UkRDc0I=').decode('utf-8')
    total = value + len(text)
    return total

def _βΦνчςцЛς():
    if False and True:
        _dead_3932 = 10
    value = 328919
    if False and True:
        _dead_5155 = 604
        pass
        _dead_3244 = 652
    text = __import__('base64').b64decode('aXhCNHRvOGJVa1pjcFoxYTVZWGg=').decode('utf-8')
    total = value + len(text)
    return total

def _λгвФКПΘбЖКШН():
    value = 497353
    text = __import__('base64').b64decode('dnlsT1czQTBrU3BUWk5fbTN1TGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΔфкЯΤУЛЪ():
    value = 326144
    text = __import__('base64').b64decode('dDh6b2Y0WTVPTGVDUnVNbF81Qkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ςςΤЮшъΞВэАψ():
    value = 910976
    text = __import__('base64').b64decode('U1Q2endIVzJLTmZxcW5pWGhmRGo=').decode('utf-8')
    if len('') > 0:
        793
        pass
        518
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΓΡλЧμΕнεтΗδκχΜжй():
    value = 417015
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MA7FSkUKra4zPzag6QWfOzx/7Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3214 = 988
    return total

def _ЗЫζлмШυфв():
    value = 915280
    text = __import__('base64').b64decode('Tk1Qb3hGNDE5eWlWS1g1NndlX1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮεΔΝЭηбюαυЯΤ():
    if 84 * 33 < 0:
        _dead_5934 = 987
        176
    value = 812581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQvOT1IM7YoOPhqN8XeeZDcL6l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χГτБΨцсτφгρтЧξът():
    value = 930001
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh3nYGAIrLkmHDWK/FvJHxAK7VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣζΝтρΛΟΚγΙзНυε():
    value = 823621
    text = __import__('base64').b64decode('ZnpyMTM3WTVLeUJIbmd1d252X3g=').decode('utf-8')
    if len('') > 0:
        _dead_9796 = 225
        183
    total = value + len(text)
    if 58 * 60 < 0:
        198
        pass
    return total

def _ΑНλθπφЯх():
    if False and True:
        727
    value = 459307
    text = __import__('base64').b64decode('V2daTU9YVGNUNGZ0Y2pLeWZhbVI=').decode('utf-8')
    if False and True:
        67
        pass
        pass
    total = value + len(text)
    return total

def _ИлЗβνурΙРπЭ():
    value = 234342
    text = __import__('base64').b64decode('V3lXZTZwMkpObnhsQmlLalZMckg=').decode('utf-8')
    total = value + len(text)
    return total

def _ζλДяΖΗκоюΤΝЙШзсЬ():
    if 19 * 65 < 0:
        pass
        pass
    value = 620962
    text = __import__('base64').b64decode('clZyRFNjNjZyT2F1YndYcXEzR2Y=').decode('utf-8')
    if 44 * 21 < 0:
        _dead_6566 = 933
    total = value + len(text)
    return total

def _ШΝпоныМбАκг():
    value = 556027
    text = __import__('base64').b64decode('bFE3WXd0Q0I5bHVOUVU3MFBLY24=').decode('utf-8')
    total = value + len(text)
    return total

def _бтθρДγЗГθ():
    if len('') > 0:
        _dead_4684 = 12
    value = 133486
    text = __import__('base64').b64decode('ZmVzYUJPVlg0Z1lPOFhSOHF3WlE=').decode('utf-8')
    if 92 * 49 < 0:
        264
        pass
    total = value + len(text)
    return total

def _ФэиМΞЩΗξ():
    if False and True:
        pass
        321
    value = 867960
    text = __import__('base64').b64decode('cHk1WXFzRG5SSkNUSGNrVEo1XzQ=').decode('utf-8')
    if len('') > 0:
        _dead_4565 = 250
        _dead_2551 = 697
        pass
    total = value + len(text)
    return total

def _ΦпАуΨρыΩτгΖЪЗοаи():
    value = 447545
    if len('') > 0:
        658
        _dead_2854 = 110
        _dead_8882 = 913
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHbROXc25KAnCyb37X+vGBcN93Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΧъбПφэоΦвΣчΧΑμБΞ():
    value = 445160
    text = __import__('base64').b64decode('ZUtJaGxUeE56MG9LWTFTZ3JmTXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _йСΜеΜΥθςЦйεВτκЪя():
    value = 144796
    text = __import__('base64').b64decode('UGxMM0x0dWF3YzM5TjU2M0JPWm0=').decode('utf-8')
    total = value + len(text)
    return total

def _еΑБζυсΙαυΩ():
    value = 387189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRzifHIb9aUPYleS2X+9MgAHyks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УОегФшΤςΖЩФСΑΛ():
    value = 198216
    if len('') > 0:
        286
        403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQTdeHUe6oAOFReu3G6aADcc1FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГυЦΚΧΙΙΗыю():
    value = 664131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dgj3WVAa+bwoDz2v7XedACgW0Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛйΟОМЩΑΕ():
    value = 822111
    text = __import__('base64').b64decode('SFN1SEtyNGR6bm1zNmRjVFdoS3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΧξЯДωαЪжыΙа():
    value = 168516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSbob0YM+vEUDSX32XCgBR0m/Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 62 < 0:
        696
        pass
    total = value + len(text)
    return total

def _ΦμяШМьмБηλкоΔεы():
    value = 473861
    text = __import__('base64').b64decode('RmZRV3BPX1dPY0Y2NkFPaE5zNGU=').decode('utf-8')
    total = value + len(text)
    return total

def _οфЯδкξэβΘХ():
    value = 104289
    if 11 * 29 < 0:
        pass
        _dead_6259 = 290
        _dead_9921 = 126
    text = __import__('base64').b64decode('cWYwbDNiOFNOSHpJN01XbWlidFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣГεЕчγНцηЦъгЯ():
    value = 559967
    text = __import__('base64').b64decode('ZXEyVlZ1ZG9wSEhfMVJ3TFdHa0g=').decode('utf-8')
    total = value + len(text)
    return total

def _РФФЙΓРЯЧμψШ():
    value = 94257
    if False and True:
        _dead_8672 = 733
        356
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSDUPnhq04A3Dx+b7kTAPTMa/ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьХУОλъοτΤ():
    value = 952300
    if False and True:
        _dead_1902 = 122
    text = __import__('base64').b64decode('bk1IQTNVa0JnRlFKOENVUTdZZU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪъοςвЕΝΨГгШЛζ():
    value = 991792
    if False and True:
        _dead_6770 = 85
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXbPb1Qy15FUAzuz3lSWPx8N3Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уОыτЗρыΘлХУсЧЯπ():
    value = 674836
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjnKfkQt8opUGB6U5mDGHzYM4Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩωыеβςЗУЛЙ():
    value = 948617
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjveXUAT86IsAl+TylmvMXcrw34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τοЩΤοьκСИНοС():
    value = 92441
    text = __import__('base64').b64decode('b3pSUU9vYmJ6RTk1OHhBdmJQRjc=').decode('utf-8')
    total = value + len(text)
    if 14 * 48 < 0:
        pass
        _dead_3617 = 185
        pass
    return total

def _сесριЭЪρЙ():
    if 60 * 6 < 0:
        912
        186
        199
    value = 609498
    text = __import__('base64').b64decode('d21ibEl2QXFHbEI0c0twQnMyRkQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        312
        pass
        pass
    return total

def _КщьзШЗЦΧВΚгαбΝ():
    value = 86158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxbjWn06p5woMiSuxGbEHjB302Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΩсΞΥδζЪΖДЯйшΥ():
    if 65 * 24 < 0:
        _dead_2912 = 796
    value = 574619
    if 75 * 44 < 0:
        36
        _dead_8917 = 986
    text = __import__('base64').b64decode('SnpVYnhzeHNZbk53WWt4SXBZUVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ωτхзφэпйοοπηйτ():
    value = 937291
    text = __import__('base64').b64decode('UVloOEZCUVl4dXZ4YUNLOE9pTEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ИЮΩЗχЖЕΟΑя():
    value = 922779
    text = __import__('base64').b64decode('SkRDN3lpUHRmMDhaMU5SMl9Mckw=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΘιиκΩΓЮЧТ():
    if False and True:
        _dead_2412 = 112
        _dead_9754 = 383
        pass
    value = 526277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBfUeEgc874NDCjy61OaPywK9UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩχЗъψеΝΗ():
    value = 168893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhXOXwdv9IktLgKux3ulHikXxUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _афрЬУпΞеλβВμνНФд():
    value = 779935
    text = __import__('base64').b64decode('dlkyUFhIRVdoZU1OY09hWUNSSzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡζΩОлΠтО():
    value = 595623
    text = __import__('base64').b64decode('Q05zR3hlbnZUZ3VRcFM0ZDJ3Y3U=').decode('utf-8')
    total = value + len(text)
    return total

def _СфынеΞλФЬЙЦхΡΩοд():
    value = 654727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh3iWXcJ6aMzaiScxGzEY3Yr63s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πθЮФоΑΥοΤезЭсэΛю():
    value = 349260
    if len('') > 0:
        _dead_9377 = 956
        293
    text = __import__('base64').b64decode('TFdKbFhUaFpnSlIzUU5fcHNTZW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛεξαьЬεЛψэ():
    value = 297143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSHBeAgS358sIwiBy0KEGxB312w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жφСцΣβΩзЯУξсоюч():
    value = 850896
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwnHT0sqrqkMbQSZ3mKgMhos0UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πλййΤьвзΜΚμΗωТын():
    value = 36584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCzPdkYPyaw7OF2Qww6kAncq5WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        74
        880
    total = value + len(text)
    return total

def _НурЩбλΖсщ():
    value = 778776
    text = __import__('base64').b64decode('VnI5TlFBM0JYUXhNU3RRUWdQdHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΗИЫτЗчЕпιКнЮ():
    if False and True:
        _dead_9878 = 645
        658
    value = 42961
    if False and True:
        _dead_1930 = 323
        790
        629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyCxaVAt1bwrFAyo71jDLBwOzEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _θЭΦЫΩЯΩэДлθЕ():
    value = 335512
    if False and True:
        927
        pass
    text = __import__('base64').b64decode('ZTAwMTNMd0JiWGtSc3NVVkFTUWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ГзЯЯΕМЪκ():
    if False and True:
        288
        3
    value = 470718
    if False and True:
        208
        656
        818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESnealwu0/FWMCiJ32e2NgMlvWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        941
        932
    total = value + len(text)
    return total

def _пσλяυАМΨΣи():
    if False and True:
        _dead_7540 = 735
    value = 947374
    text = __import__('base64').b64decode('aTJtNDN6MkU3QkJRUEw4ckViMko=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЮыθЧПмΒзЦТ():
    if len('') > 0:
        _dead_7463 = 313
        _dead_8067 = 401
    value = 750727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX7Ge0Ax3ZgmHBiWnHyYHyQsxks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6201 = 576
    total = value + len(text)
    return total

def _дХъΔΙЕЧОκСΔν():
    value = 580567
    if len('') > 0:
        _dead_8206 = 135
        627
        667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAnIT1cv+pwmNFis4XqHBwgs918='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зγΛпρйπеηмХо():
    value = 214834
    if len('') > 0:
        _dead_3246 = 164
    text = __import__('base64').b64decode('TnljbkdFTkZYWE9pMEs5VmpIUHA=').decode('utf-8')
    if 9 * 40 < 0:
        506
    total = value + len(text)
    return total

def _оΟλьκкпцоΑε():
    value = 616871
    text = __import__('base64').b64decode('QmpWb0EwcDhJcUdRaXlsV1c5Zkk=').decode('utf-8')
    if 50 * 74 < 0:
        _dead_8384 = 944
        437
    total = value + len(text)
    return total

def _ΙυΞИΝЬлζнЫω():
    value = 413988
    if False and True:
        254
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kzj2algq7rwHMzakxm+7MyIIy2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нЬμеЖδΤχ():
    value = 328210
    text = __import__('base64').b64decode('TVRWQUM5V3dUM18xdVBQTGpxdmE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4816 = 140
    return total

def _ΖСςΑΒςΡΨуш():
    value = 283100
    if len('') > 0:
        _dead_2254 = 27
    text = __import__('base64').b64decode('eUdiX2NaZGV2VW5zZEVUa3p1aGo=').decode('utf-8')
    if False and True:
        _dead_5898 = 273
    total = value + len(text)
    return total

def _ПргςнзψТχжοςλФ():
    if len('') > 0:
        54
        939
    value = 356741
    if 83 * 45 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwHzaVovqfkaDT+b5weJYnQ810g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΩшГδрΕηгρКΖг():
    value = 58244
    if False and True:
        _dead_4345 = 114
        _dead_3221 = 840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgHMa1UNyaQ0K16G2HCvEh0Xt2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠАΒεльЯХНУЭцЮ():
    value = 970345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCvgeVtq9rgiIjWT6U6TGQAh6Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 21 < 0:
        _dead_2280 = 654
        868
        854
    total = value + len(text)
    if 97 * 70 < 0:
        _dead_9090 = 55
        646
    return total

def _БΜφΛбсфжκнЬ():
    value = 567896
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSvhNmBs85wqKR+owAaCGjUe/U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рУΗЫывпι():
    value = 657602
    text = __import__('base64').b64decode('dlVLenNtVEltblUwSDlidUo3Z0E=').decode('utf-8')
    total = value + len(text)
    return total

def _εакχμΑνΤ():
    value = 621344
    if len('') > 0:
        _dead_1147 = 379
        pass
        pass
    text = __import__('base64').b64decode('cVBZTTZqV0h5MDBuZ3hmMEVtZV8=').decode('utf-8')
    if len('') > 0:
        490
    total = value + len(text)
    if len('') > 0:
        268
        pass
    return total

def _ςшξщяςСНψмφъЭо():
    value = 227929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyX3PFApwfEBHQGw2l+pBHMBzj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тщρΣВАαЗΤ():
    if False and True:
        _dead_5394 = 821
        _dead_5077 = 799
    value = 751108
    if False and True:
        918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnvLPVAJ/J8lbAKnz1rJBzQj3Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 38 * 80 < 0:
        _dead_2579 = 175
        pass
    total = value + len(text)
    return total

def _ЛЛхιΝщΟЗΩйΛЧсООх():
    value = 943415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxC0RXsM2IUOGDyC5H66ZjMA7FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮληΥχБΞаЦΓεΠΟτ():
    value = 673659
    text = __import__('base64').b64decode('d2k1TUpLejlVUnNHcVJGaDh6d28=').decode('utf-8')
    if False and True:
        162
        804
    total = value + len(text)
    return total

def _МΜОверРЩ():
    value = 61087
    text = __import__('base64').b64decode('V2hzRXVBY2RmSXNTSFhBcHBYc2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚаДξΒχшС():
    value = 74072
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAr0OkUD9bomH1ma8FHCCwx8x3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЕξвЦΤЕЩЭэΙл():
    if len('') > 0:
        627
        pass
        pass
    value = 757075
    if len('') > 0:
        _dead_7694 = 856
        351
        187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTm8UVQsyIRRNwa561OZOAcQ7jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠТииΨψзУЬΑ():
    value = 967549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiXcQHMUzP4vYymx2EW1AQZ9/Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЩФЖΡкркЕПпΨьЛМА():
    value = 825304
    text = __import__('base64').b64decode('cDZGYUd0dUZaWVFsYjBsb0FqVHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ясОиξΦπЩиξ():
    value = 268858
    if False and True:
        pass
        _dead_5712 = 586
        _dead_6686 = 353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTX8b2Qz5J87bTWanAOWZBwOw10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧοΟЦιЦюцФΕОж():
    value = 732513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR7tTVRr5K0MDFmBn0STLnMAwDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _дШАНбЙНфРкΟΔЙδ():
    value = 482750
    if len('') > 0:
        pass
        _dead_6788 = 539
    text = __import__('base64').b64decode('cGRPTXlQRFRyTmphcmhVODRJSWk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        894
    return total

def _ЖгЩЕуежФМШчзыβΩ():
    if False and True:
        _dead_8708 = 629
    value = 65650
    if len('') > 0:
        446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FH3PN30475oWKyj60XzFHHcZ7X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΑАΦсρЧФиζφО():
    value = 382035
    if len('') > 0:
        599
        _dead_5402 = 336
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgPVaFYfqY8pACO15FGnEgd55z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧуЧΧλГЪζЯяξфАЛЛ():
    value = 848959
    text = __import__('base64').b64decode('ajBBZWlvNEhBUkd5RF9qT25PUDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯСεΓАЙнЭΑκЙζ():
    value = 752063
    text = __import__('base64').b64decode('YmVwb25uSVJMQ2dFb0lnbTRqSjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ИУΠКΞИΑИ():
    value = 130349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAneOXYx2qdbahyMmkSqFwE6tzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠτхΝζΒμЗОЭΤ():
    value = 16349
    if False and True:
        253
        _dead_9900 = 155
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTWzZgIbq4oHLiON716CYnIK1zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _φщκΕΚΗζмχбγЛзТц():
    value = 507554
    if len('') > 0:
        _dead_7337 = 499
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn7GWgFuqLA1CAu5kV2nZxAI81o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 47 * 46 < 0:
        296
        281
        602
    total = value + len(text)
    return total

def _СЗΩызЪпыэубЗδйψ():
    value = 182559
    if len('') > 0:
        pass
        _dead_2315 = 487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRvJWks49po6CS6I8lOaYwAo8j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дφсВηоЬν():
    if 1 * 18 < 0:
        pass
        pass
        pass
    value = 558479
    text = __import__('base64').b64decode('RTBIQlNMdWd1WUZXOWdNU2pCN2s=').decode('utf-8')
    if False and True:
        70
        pass
        393
    total = value + len(text)
    return total

def _ъκκоμμЩΡΛдξжфΠ():
    value = 179945
    if False and True:
        _dead_1940 = 725
        284
        484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxDvSGQM+ItUNCmrn2y+GCx/xng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ωПβШЖлндζχБп():
    if False and True:
        857
        _dead_1711 = 731
    value = 592125
    if False and True:
        pass
        864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAPmRG4X+7E1I1yRnkeaGgwM73g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΘлифБупМ():
    value = 984854
    text = __import__('base64').b64decode('THVscEN3VUkzaVVvSUh6OURpTUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ФббιγЕэПЦΚ():
    value = 955658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQ61ZFoy+IMlPTWF6U/IbA0/7lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δвжлΔМвτуИ():
    value = 882126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX7KNmkLpo9RNyGL7EWEBRQsyTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _обΠщγфЕцСΨЕ():
    value = 790920
    text = __import__('base64').b64decode('UEYxRHVOYk9DZ3E5QXY5c2VNSGY=').decode('utf-8')
    total = value + len(text)
    return total

def _кРКЯγЬΥθοΛбх():
    value = 522528
    text = __import__('base64').b64decode('UXFJYm5PZTVIaTdiYWRrSHIxc24=').decode('utf-8')
    if 4 * 70 < 0:
        _dead_8633 = 893
        963
        324
    total = value + len(text)
    if len('') > 0:
        _dead_8303 = 132
    return total

def _ΗεФπЯщьщЗГВΒ():
    value = 918555
    text = __import__('base64').b64decode('TmtUc2ZwT2tSM2FiNXE2WU9zV2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _υΚКшΡΕПηоΜр():
    value = 822766
    if False and True:
        462
    text = __import__('base64').b64decode('TWs3cDZsYW1zUG5nWU1mVWVmUG4=').decode('utf-8')
    total = value + len(text)
    if 50 * 80 < 0:
        pass
    return total

def _ыЙХОевцк():
    if 33 * 27 < 0:
        pass
        pass
        pass
    value = 317151
    text = __import__('base64').b64decode('QWtPeWg0ZldsYmhGc2FQcUtQb1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΞΠσΓПσлφЭдШы():
    value = 931102
    text = __import__('base64').b64decode('Rl9YcThfZnMxUERlQ3J2RmptV2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΘσΚψΠщсΜ():
    if 24 * 14 < 0:
        pass
        pass
    value = 329999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgXKWF4G/JdTKxWtkHm/ACYN4mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΕγхчЬΩЛАξζЭРФγ():
    if len('') > 0:
        435
        pass
    value = 672509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAn9XEYO55IpFCiX/0ekBS4nx2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8809 = 875
    total = value + len(text)
    if False and True:
        _dead_3094 = 144
    return total

def _ЭЦΩψαЛΕЙ():
    if 17 * 42 < 0:
        pass
        259
        598
    value = 144639
    if len('') > 0:
        723
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCPKOlMa9qUnMQi391CRJyh3wG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΡЦяфαаЖтк():
    if 3 * 41 < 0:
        pass
        _dead_6685 = 429
        pass
    value = 154710
    text = __import__('base64').b64decode('VUlFd1NWS3RJVHdvRlR2cGpXXzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ъδΖΤщииСΑяфηХИ():
    if False and True:
        749
        899
        _dead_1146 = 134
    value = 553456
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS7Ra1tsqv4OFzec4lSTEyAo/U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩγЦςτζΟη():
    value = 631591
    text = __import__('base64').b64decode('aEVDeVlKSnhBbHRuZ2JUUkxsSEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΧОчτМξδΟ():
    if False and True:
        39
        pass
        _dead_6877 = 239
    value = 750037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jynjd1sDrKYvHjyB2XmaMS4j60s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 67 * 19 < 0:
        _dead_1285 = 967
    return total

def _ЪэτΕβЧβΜчНκжъдλ():
    value = 520509
    text = __import__('base64').b64decode('d2xXRHBaenRLS0Y1czJCTk9QYlE=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΨΓцδχξΙЭвЯρΟВ():
    value = 212136
    if False and True:
        150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICa0R2Q9/PkXAzmqmgO3Jy4q8Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        788
    total = value + len(text)
    return total

def _ΔФΤΞιъΖдФσрσφФΔ():
    value = 500853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX7LdnVt6KYTEVi631u2PwgovWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        143
        _dead_8525 = 271
        258
    total = value + len(text)
    return total

def _пчΞεНдОЮ():
    if 100 * 35 < 0:
        911
        _dead_1042 = 671
    value = 912368
    if 57 * 1 < 0:
        797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwH8dkIj+4AREhvx7F6aJDcmxlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χжЧЙρЧΣΓБвюРвο():
    value = 425150
    text = __import__('base64').b64decode('dGZ4MlU3WXY1ckt3TkpaczMzWUs=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6652 = 344
    return total

def _ΑыΞОъυπΓСσПЖΘм():
    value = 795399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dw7TY1lopp4ODVyq/n+gBS4V8Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζΓΧЭХΡгсНгЫащЯыΨ():
    if 100 * 43 < 0:
        723
    value = 609360
    text = __import__('base64').b64decode('RVduR045RzhIU2xGMTh4blduZG8=').decode('utf-8')
    if False and True:
        _dead_5461 = 47
    total = value + len(text)
    return total

def _ЬРзЭΔЛνЯψ():
    value = 141693
    text = __import__('base64').b64decode('bkJyY21xV2FCQ0I2MkpyMjFEV0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕвЯΕΒКΣлΑθΚЮКц():
    value = 9124
    text = __import__('base64').b64decode('WkRrMmhtSGh5clU1WG9kb21RaHk=').decode('utf-8')
    total = value + len(text)
    return total

def _πЭРЕпςсταΚЧДКшΜΔ():
    if len('') > 0:
        807
        285
        _dead_4223 = 18
    value = 756940
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCX1bEkz2Y0AYyD26Q6BNS05zGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        310
        pass
    total = value + len(text)
    return total

def _фсыΚΨσЖθΡШ():
    if 10 * 51 < 0:
        _dead_4228 = 127
        pass
    value = 948864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxyzX30crYpTAh+E7GaaFy1+x0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οιУζΝМΚпргиΕωηΛΖ():
    value = 743898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHqxQgQV6KxUIjC0mQHCEDAavGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оьГМЖбдвΑоНΦοеЦЗ():
    if len('') > 0:
        pass
        pass
        pass
    value = 635733
    text = __import__('base64').b64decode('VUVhZ2FmcURVNDFmWU1DYmZteEk=').decode('utf-8')
    if len('') > 0:
        859
        pass
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('dA==').decode('utf-8'))
if len('xxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 41 * 40 < 0:
    358
    pass
    15