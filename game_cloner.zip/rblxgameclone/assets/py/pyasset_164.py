#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ρИыρэΣΦдΖΖΙЛПΡ():
    value = 888987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCDVRnMq+fFbEyum6QGgFgM3wz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЖπΤΙИγΠБβтΖΡбψΦ():
    if 36 * 48 < 0:
        pass
    value = 801660
    if len('') > 0:
        892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwG2T3wBrIUENSqs/06cGj8V7T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚТЕтЪΨΡαдЬοМ():
    value = 792716
    text = __import__('base64').b64decode('TktYWnY4bmM3R3duUEpBNlhIQmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _МυξΓιщζОукΕαяξЮ():
    value = 391506
    if len('') > 0:
        pass
        pass
        639
    text = __import__('base64').b64decode('emFiRUJndmltcTZGZk9mRE1ibHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧФНΔгεΡпΞЮьΧΕμο():
    value = 153242
    text = __import__('base64').b64decode('ekNaaEpleWtlcXFRZzE3MVVzY3o=').decode('utf-8')
    if False and True:
        pass
        _dead_9891 = 346
        _dead_3356 = 182
    total = value + len(text)
    return total

def _уσнэфЖВνъиРΧЭгΙ():
    value = 923644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3ywOwcb0fwFKCuF4FLHISl/0HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηЮΖЪΨгфБ():
    value = 708469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASbrdFgv24c2Dx67/X+WZzR5228='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уиχςγτАσЦСеяτξ():
    value = 565889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In/BV0Yo7JkzFF2x6Xm4PxcH0Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иμцэεазρАλςф():
    value = 984367
    text = __import__('base64').b64decode('V2NaZ3BQczRZNUYxUDE5NFg5cHg=').decode('utf-8')
    total = value + len(text)
    if 84 * 98 < 0:
        _dead_6400 = 912
    return total

def _ΜΦΕЦШψΨФгАХΧΚ():
    value = 760557
    text = __import__('base64').b64decode('TGJwY1FjZEM5NkZNVk5zUVZadmU=').decode('utf-8')
    if 3 * 78 < 0:
        _dead_5324 = 593
    total = value + len(text)
    if False and True:
        667
        pass
    return total

def _ЬζкЙΧχπсΠ():
    value = 279232
    text = __import__('base64').b64decode('U1A4VlBhb2w1UDdUS3pYdm5fSDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛοяЖΩВωднμЗэКηжγ():
    if 41 * 22 < 0:
        pass
        _dead_5165 = 649
        _dead_3707 = 961
    value = 501761
    if 19 * 35 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSnBfUdh8oA3NgWGnEWXBnwlx2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζεАЛФюГыМςΗΙР():
    value = 992791
    text = __import__('base64').b64decode('ZkU3bm9lbzN4NWV6Qk41MFplcnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔБΝСЗСΟσθΒ():
    value = 570063
    text = __import__('base64').b64decode('TkZJY2t6SEVUbXZPckJZUFB3S18=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧщцЛСыБЦΜъ():
    if len('') > 0:
        pass
        pass
    value = 672533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByP3a1gxwalTCg6tkHjIbTU24Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιεМγвгΕΩиЪэяαУ():
    value = 934683
    text = __import__('base64').b64decode('UllxMTZNQk5KRzZZQkxwUENTTHQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        902
        pass
        pass
    return total

def _иχбрДьяψλЧьшБо():
    value = 878721
    if 69 * 99 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDrDXnoX6qAXLwGRxlOoJjN+0Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фСХφГΡψНдΜδΖΚαго():
    value = 353532
    text = __import__('base64').b64decode('QjQ2UDd3dzQyaWhNTjlEZHNuanA=').decode('utf-8')
    total = value + len(text)
    return total

def _НΧыщфΩμν():
    value = 263718
    if 70 * 41 < 0:
        pass
    text = __import__('base64').b64decode('aThhNk9XS2NfaEN6RFVyWjJidXM=').decode('utf-8')
    total = value + len(text)
    return total

def _яςшυмЮйηДΞФσТ():
    value = 472301
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxbnOmch245RODmm7FKRZXYYzTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хяфнсΑдθτАЮЫΜк():
    value = 939316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3nzbEkI7YAxCxun4nHJMQ0rymw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        849
    return total

def _мνφлЬАсΖИΣΒγ():
    if 63 * 69 < 0:
        pass
    value = 417977
    if False and True:
        _dead_5185 = 508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBzLRUYM2pkMKSqz4liHJxB742E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        55
    total = value + len(text)
    return total

def _ВρзΥΞΖΝΤтъхγоψПЖ():
    value = 458712
    if False and True:
        _dead_1534 = 849
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAHCSmkx1bgOa1f1916xZXwV3GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4800 = 105
    return total

def _юЦФηπΨЙΔΛ():
    if len('') > 0:
        pass
        _dead_4588 = 831
    value = 316593
    if len('') > 0:
        _dead_4411 = 714
        355
    text = __import__('base64').b64decode('UVlsN2lOVzkyS2xpYWhYVFNwaXE=').decode('utf-8')
    if 76 * 7 < 0:
        231
        _dead_3777 = 370
        pass
    total = value + len(text)
    if len('') > 0:
        89
        _dead_9860 = 679
    return total

def _ΦξξгηυωзтШΥρ():
    value = 754860
    text = __import__('base64').b64decode('emJyZlNQMXlnRVhmWkJrcGhYYzU=').decode('utf-8')
    total = value + len(text)
    return total

def _шΩСцйГσНαΟУΦοφУ():
    value = 938255
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwjxPltoz/0Hb1yx2WG6DCQ3738='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΕνΣηЕπγЙЮН():
    if False and True:
        409
    value = 29330
    text = __import__('base64').b64decode('YzRSZkx6V1Q1Y2doNGFFa0VBV2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦδΠΣφнЭΣΔκθ():
    value = 122084
    text = __import__('base64').b64decode('UDAzUDZnMExQUnRmMW9pN0dPXzI=').decode('utf-8')
    if 61 * 3 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ΑΖРГφЫэζ():
    value = 784021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXryOlw8qaIWFQqqkFO+LHwd2z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΒφХнтАЙЮΣ():
    value = 314402
    text = __import__('base64').b64decode('VjhpZVUyMDAybE13SUFndGZEZ2E=').decode('utf-8')
    if False and True:
        pass
        _dead_5162 = 797
        _dead_2057 = 0
    total = value + len(text)
    return total

def _ктдκвЬРЯИвΤЦЗзч():
    value = 346607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCD3dwBtwaoUHwKq5F2zDiJ+ynk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эоаяЭТТΕлцΔΝΤγУъ():
    value = 588710
    text = __import__('base64').b64decode('U21HRVBLaFJlMG44VHkzdVJKV2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯчΓЪуРΨτΧβζΒсΦΖζ():
    if len('') > 0:
        949
        pass
        pass
    value = 416490
    text = __import__('base64').b64decode('aVNvQkpWOFRLMTZZQXhxTUw1ckI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΑоχΓЗΙИ():
    value = 162559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT2xXQks9/wwagmQ0VypOS0rxmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮЪΦКмкЖΠЩвΡуютыУ():
    value = 702172
    text = __import__('base64').b64decode('bWxUM283ejY0RkxkMzBmMkpHcno=').decode('utf-8')
    if False and True:
        113
        pass
    total = value + len(text)
    return total

def _ψйПщТΧΜСтΖПфα():
    value = 476334
    text = __import__('base64').b64decode('TVd2a3lyTnl1YW0wUFIwR25lOTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮШжрЮΝюΜБэуТ():
    if len('') > 0:
        _dead_6290 = 949
        _dead_9213 = 366
        pass
    value = 903196
    if False and True:
        _dead_4200 = 578
        584
    text = __import__('base64').b64decode('am9jNkNrMkJnbF9peDZRM1FoR0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ПУЗЯхЭζиΖНдζОбМ():
    value = 742106
    text = __import__('base64').b64decode('SERsdEZPbjNjZlBlZWlkblN0aEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦзечΞЦΡзРяухЕФан():
    value = 466522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADbgVFIgq7gUbC217Ga0MAgYzmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΨгΨΥаφоΟпψФвбλ():
    value = 83381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgTpOmcb7IctLB77nQCdJn0Iy3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦχΠсужыΨ():
    value = 952330
    text = __import__('base64').b64decode('eTJIVnRyMm52TUJhOUFvUFkydk0=').decode('utf-8')
    total = value + len(text)
    return total

def _БΕυζΜчαСΕя():
    if 39 * 44 < 0:
        _dead_2880 = 69
        pass
    value = 259258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQzIa1wD8Z0UMyWP5gG0YSo/5Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙпψгωюИд():
    if 12 * 86 < 0:
        pass
        110
    value = 131596
    text = __import__('base64').b64decode('TVhmTWZZWkZ5elFTa1RfWlVDOTA=').decode('utf-8')
    total = value + len(text)
    if 46 * 99 < 0:
        _dead_1273 = 653
        129
        _dead_6814 = 78
    return total

def _кСЭтИдебЭиΡΙ():
    value = 243739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj7KaEcD9atQDA2n/EOGCwJ6w10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЯφκМηκЫρ():
    value = 723562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSr+TUcR5JI1Ih2x4VmZJS8J9zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΨΦаςдсБυσΒ():
    value = 185431
    if False and True:
        pass
        905
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lwjid3YPzZxRHyui50OmAC4c5Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йκъвнΝВооσЭΜγς():
    value = 497221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSzhVmQj+Pk0KV+T0Q6AExItyUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΔΙцΞЛЯΕШяЛпш():
    value = 434634
    text = __import__('base64').b64decode('UTJsd29hR2FYRFhrUDUybDlSNUw=').decode('utf-8')
    if len('') > 0:
        217
        516
    total = value + len(text)
    if False and True:
        473
        527
        _dead_5731 = 600
    return total

def _δеςЙхчбЙХΜΝЖγ():
    value = 140133
    text = __import__('base64').b64decode('ZUU2eXlaMHZlTENRaDdDajNJSnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙоΡпμИЙι():
    if len('') > 0:
        471
        _dead_6861 = 580
    value = 318066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAPpRFxv/b8KLT/zz2C7YAkmw10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6600 = 379
        _dead_2326 = 291
    total = value + len(text)
    return total

def _ыЬХωиΧΕБФзЖΜЫσЪО():
    value = 482402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cha2PWQT06IgbFqs+A65MjQ73Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΨоΣШΛэКΗΨйΖи():
    if 68 * 14 < 0:
        89
        157
        867
    value = 255270
    if len('') > 0:
        653
        736
        pass
    text = __import__('base64').b64decode('ck9Md0QyQTIwb29vWUtHT0tmeXc=').decode('utf-8')
    total = value + len(text)
    return total

def _βΠХъЯЙМηсБЬΚφΤΕ():
    value = 4521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBjKZWMBpq0gaQP7yX2pOTQswFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡфМЙГкщЖЛ():
    if False and True:
        _dead_6648 = 334
        286
    value = 49331
    if len('') > 0:
        110
        _dead_4629 = 13
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQf8OWAU7oQEMy6V7nyDYD8G4Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        652
        _dead_1550 = 696
        567
    return total

def _ωЛΠΥιηрνЕЙ():
    value = 229665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgfxTVIP5KAWMgut2XuSNXY80Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ροΗеσВξПΚΒФιτΕ():
    if 53 * 37 < 0:
        183
        _dead_8039 = 690
        pass
    value = 337699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kz7sV2Ucy4BRPwGn7lm9LhM4sD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬбЧЕМтΔОΕьΨБИГ():
    if 44 * 3 < 0:
        _dead_1052 = 839
        pass
    value = 909580
    text = __import__('base64').b64decode('TXlGMk1HeklIejVVZHkzcWZHY2g=').decode('utf-8')
    total = value + len(text)
    return total

def _МΧΤζαΕЭψ():
    value = 550485
    if 1 * 23 < 0:
        _dead_8875 = 963
        774
        pass
    text = __import__('base64').b64decode('Q3pkODdFeEd6cndmU05PbjVKaGE=').decode('utf-8')
    if False and True:
        _dead_3449 = 782
        420
        75
    total = value + len(text)
    return total

def _κэиЖчбтψγσъРЙΤ():
    value = 506702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fn29P35h34MHPTCP/w+JZjY/tm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣуθЮεпΒРНΞауЗΤкш():
    value = 969477
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwznWwY1wbAaFguz3F2gAHMI4Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЧΙъцЧЛςпэ():
    value = 436480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXnSalUuypo7D1yVwgGpBBoh12M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щНхУААΔрмъО():
    value = 915284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BALTO1Qzp/w7agar4GObbTwK3Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εγЙПЯуьγωе():
    value = 755701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy3geGkyyIUMMS2Jx3mmYjQI8Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аПЛПψαΤУВΕ():
    value = 194447
    text = __import__('base64').b64decode('cXhna1FDTkdFeWlIVU9mX0ZhSFo=').decode('utf-8')
    if False and True:
        _dead_6014 = 24
        719
        483
    total = value + len(text)
    return total

def _ΔЪΝСΑЧхХ():
    if False and True:
        pass
    value = 519506
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('eGNvQ2FNbTNmQnhGRWZTSGd5ajc=').decode('utf-8')
    if False and True:
        _dead_8660 = 706
        625
        pass
    total = value + len(text)
    return total

def _ΞψбОνФΣΙΗΚтбΒ():
    value = 470752
    if 33 * 71 < 0:
        133
        pass
        _dead_4711 = 736
    text = __import__('base64').b64decode('VDdRMENaSlpBejM4R2QwTG0yWnc=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6644 = 709
        pass
    total = value + len(text)
    return total

def _РеςЭгΣХиУωшΜг():
    value = 111944
    if 7 * 79 < 0:
        _dead_8317 = 1
    text = __import__('base64').b64decode('TVZZbUxRcWgzVVIyajVENWdvQkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚНаΚνМЬγСшДЖъΝ():
    if 50 * 55 < 0:
        pass
        _dead_3838 = 68
        _dead_4963 = 452
    value = 326252
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('QVMzaUpudk5heGxBWWU0VHJ6S1A=').decode('utf-8')
    if False and True:
        231
        _dead_1667 = 685
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ΡΩαЪφщΣΝЫΡуλЛ():
    value = 10853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRjhQXU/5JoVAyGI+nCdYhUmyV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 96 * 96 < 0:
        997
        56
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ΚЮψΩΩявиΡ():
    value = 794029
    text = __import__('base64').b64decode('YkZmUEx3eHBIV0pveXdxNHVuV3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒОΒЩАυГеоиΜωФ():
    value = 88860
    if len('') > 0:
        _dead_2201 = 339
        385
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DC7SYHgyxPFQaQXw8WelGC8q7Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уΕπГФΤкκфхωбЖΕтЯ():
    value = 306773
    text = __import__('base64').b64decode('bGpOME92WFQ1djdaVTlQQUxaWng=').decode('utf-8')
    total = value + len(text)
    if 77 * 3 < 0:
        pass
        _dead_6159 = 638
    return total

def _МΚдкΣΡгВдσΚПдц():
    value = 179058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARjGaV8g05cuFlag0XqpGygi1lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΞΦМΙπвρмШхΦН():
    if False and True:
        pass
    value = 482517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQbAeAg82a1VbV6M/GG8LgEf6Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6298 = 962
    total = value + len(text)
    return total

def _ЪХЯтжΝшΞхЭς():
    value = 538457
    text = __import__('base64').b64decode('dzdkTWk0MVFSWnFOQ21WWVdyUGc=').decode('utf-8')
    total = value + len(text)
    if 79 * 55 < 0:
        961
        559
        992
    return total

def _ХχВбΛмСЬЩΤαжΠб():
    value = 454971
    if False and True:
        783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwTGRgUhx40ELVulkW6WBAIGyGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫθЦΞβΥлτЧМΜАο():
    if len('') > 0:
        36
        pass
        pass
    value = 653893
    text = __import__('base64').b64decode('WTljb3hMc29CUFdPUUt0ZlRqRms=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦрηΔЫΡУΩΔЗсγ():
    value = 627702
    text = __import__('base64').b64decode('YW9pVzN6UVNYMlFHdEl3amUwT2E=').decode('utf-8')
    total = value + len(text)
    return total

def _кΩуνΦΖδζχь():
    value = 368848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC63OXQg6b8MIjaOmA/EAB123EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 69 * 100 < 0:
        819
    total = value + len(text)
    return total

def _ШβОУПцлэΣ():
    value = 729425
    if False and True:
        _dead_2776 = 803
        _dead_6836 = 180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBbySFZh9ok5bQOs20yaGTEIxUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΑъТУΑΞяξдЮцб():
    value = 640254
    text = __import__('base64').b64decode('Y0VJUk01X3BMZXZsTDBqNmlFSEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗХфцΝАЫжΟΧРмΜсШд():
    if False and True:
        _dead_8904 = 316
        _dead_1237 = 853
    value = 331449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzzAQnUo87EiCiGuwneECyMWvUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7250 = 515
        pass
        557
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _этδδюзьх():
    value = 187749
    text = __import__('base64').b64decode('SWpvNlpPdklnbjFPeHNhb0NMdGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝγмβЫфЧеПЛецКπ():
    value = 937203
    text = __import__('base64').b64decode('ZTZxN0V4bXJuSkw4a1pQeVl3clE=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЪЫЙΙэЙцпМАωЬ():
    if 13 * 68 < 0:
        _dead_9829 = 81
    value = 705025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED7QRn01550ZLziiwHGhDhEu7H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗДπДΤвхΗΜτьЛΜξ():
    if len('') > 0:
        _dead_3998 = 925
    value = 68649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Any9O1dorIk5bjyS5neBIh8B3Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 72 * 31 < 0:
        pass
    return total

def _ΓшΧРχГПΠЩДΒδ():
    value = 401206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiT9WFk35J4PazuZxGKCPQMEvTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 77 * 61 < 0:
        pass
        _dead_8624 = 776
    total = value + len(text)
    return total

def _ВжщПуεΞЮΙтΟуΑςлε():
    if len('') > 0:
        _dead_5542 = 598
    value = 936124
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3fLWUkx3KcXYi7z8H+vAREd91E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΦΣЖхСуЩЪманΟΧ():
    value = 632151
    text = __import__('base64').b64decode('WEIxWklEeURJQTQzeGs5eEZxUFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ωеαсΚΟЭΨояΧιι():
    value = 78737
    if False and True:
        756
        _dead_7737 = 293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAG9Zmcd570hbjmN3kW2ZDYIyXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 1 < 0:
        pass
    total = value + len(text)
    return total

def _РцИλъκйТλ():
    value = 144330
    if False and True:
        _dead_7582 = 709
        143
        pass
    text = __import__('base64').b64decode('YWJpUlg3MUtJVGZyaldVeGlpV3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΘЯуΩδωΦΟ():
    if False and True:
        pass
        _dead_4271 = 821
        pass
    value = 751045
    text = __import__('base64').b64decode('RFFpU0pLQkljclBUQ2Z4ZDVzSEg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        222
        919
        pass
    return total

def _ΘгфмНΑΣРΡЕΥΓсже():
    value = 850119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhnRencA6oI8a1eb7lHBNQwp8To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пхдщΙФЛЯГ():
    value = 507207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jx7xen0p07EqFyqa2QPHJjcJ4ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηкгЩйοеЧдррИЬщШβ():
    value = 443813
    text = __import__('base64').b64decode('VWFjVVZMMDR0Z0g0MDdWOGdjWnI=').decode('utf-8')
    total = value + len(text)
    return total

def _φКЭΒЮΘχюЙ():
    value = 41579
    if len('') > 0:
        _dead_2392 = 911
        pass
        _dead_9981 = 632
    text = __import__('base64').b64decode('eUR4b3NCU2RRbm1VckZlNmY1Q0I=').decode('utf-8')
    total = value + len(text)
    return total

def _вΨЪКБΗСзωηи():
    value = 400251
    if len('') > 0:
        _dead_8174 = 654
        _dead_9565 = 521
    text = __import__('base64').b64decode('bHdhRzJTdUVSaExhSHQ0d1pqQkc=').decode('utf-8')
    if False and True:
        807
        pass
        995
    total = value + len(text)
    return total

def _ωФΡВЯфяλιуλπ():
    if 3 * 48 < 0:
        _dead_4979 = 494
        766
        _dead_4283 = 725
    value = 867454
    text = __import__('base64').b64decode('d3NNZmhRekxKNGZDdUdXMEZ4MFE=').decode('utf-8')
    if 14 * 27 < 0:
        12
        376
    total = value + len(text)
    if 69 * 42 < 0:
        _dead_4023 = 198
    return total

def _ΞЭЪУчцΩθ():
    if 61 * 24 < 0:
        pass
        398
        556
    value = 13910
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTmyREI78bwPCAuF/QObJCEa72E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΝβЯадχвМтωτιЕкδ():
    value = 298717
    text = __import__('base64').b64decode('Uk41OFNtX294aG9KOThCRUh5Nms=').decode('utf-8')
    if False and True:
        pass
        328
    total = value + len(text)
    return total

def _жЯΓЗлАΒЫиЪжсрфа():
    value = 87046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHviYmhtzJsVagKbnnGxEAAB3HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3537 = 936
        _dead_7143 = 867
        pass
    total = value + len(text)
    if len('') > 0:
        723
        _dead_9048 = 147
        pass
    return total

def _ЯξΤβУιΘψВΚюИЦЯωК():
    if False and True:
        pass
    value = 818929
    if 29 * 59 < 0:
        pass
        _dead_2224 = 91
    text = __import__('base64').b64decode('dHAwclgwVDB1eXpib3RDMl9IZ0c=').decode('utf-8')
    total = value + len(text)
    if False and True:
        728
    return total

def _ννфЙνЖΔазΝсΓТΔ():
    value = 298271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCzcOGIo1qZQMRaHzV+YDXEe/Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПРвЭЫιχЖΒΒΩф():
    value = 199170
    text = __import__('base64').b64decode('bXlhRXREbUR1SU00aTFuTzJKVmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛзЖςщΛНκг():
    value = 694831
    text = __import__('base64').b64decode('VkwySTJYWWkyVmhKcGhtNnQ1ME8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩЖБιΜхΟΝфξκσο():
    if 32 * 98 < 0:
        _dead_2596 = 314
    value = 646539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgW9WWkV6IVaBTqw52GgGRN98UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        490
        _dead_9588 = 468
    return total

def _цшΘяькмЦЖЕгЗАы():
    if False and True:
        pass
        639
    value = 369541
    if False and True:
        pass
        990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBjbbGIa15wpN1iwygWcN3cqx2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 47 < 0:
        _dead_4056 = 452
    total = value + len(text)
    if False and True:
        411
        _dead_2586 = 614
    return total

def _ЮЭфПΕΧιИЯМЩΥг():
    value = 648096
    text = __import__('base64').b64decode('TUw2VndrNWRTWmlJM1d5QW1KbWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΝβОюъВΨОГъ():
    value = 105109
    if False and True:
        185
        _dead_3368 = 636
    text = __import__('base64').b64decode('VTJ4eUo0SFgxUUFWbWFWNlpoa3c=').decode('utf-8')
    if False and True:
        122
    total = value + len(text)
    if False and True:
        657
    return total

def _ЙΝлΖНΒΦΙмпΑхρΓ():
    value = 406276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSr9SW5o8KEwNAqN0VyVASQ4yTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _МюШцΙжΔЛЙιЮУИ():
    value = 833518
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCnJbFAu7LAlEiyS73y4PQYE4l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩАοБψδюφ():
    value = 90023
    text = __import__('base64').b64decode('dkVNMUo0YmtrT05ibFJaY3ZDbHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛгХΝфψτчппьΥсЧМξ():
    value = 13638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDbLV3YYp/wvaj2A/V6lOQIK6ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъсЙωаΚорμρξщцЧ():
    value = 203299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCnwa0MTyJ8NOAC5/lKmOxMXyj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΦбЮъДфОμЯрС():
    value = 925037
    if False and True:
        933
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JziwWgYRz6M3AAbyxESRZxIj3nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        815
    total = value + len(text)
    return total

def _ЪэЩΗξбХрм():
    value = 752638
    text = __import__('base64').b64decode('SnduQlIxdmNVcWtVQWtMaXFWR28=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΓГгниΣНзοζЩБ():
    value = 950569
    if len('') > 0:
        _dead_5003 = 864
        _dead_7088 = 511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj69RQNr+PgOCQqHwnjEB3If41g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пυΚυвφЦОхΚю():
    value = 655080
    text = __import__('base64').b64decode('ZXBqZjJyODNOT1p6M2FuVUxvTnc=').decode('utf-8')
    total = value + len(text)
    return total

def _гбЮεПΥСзβаз():
    if False and True:
        _dead_7952 = 393
        pass
    value = 700272
    if False and True:
        366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRW3R302z48HMi2W8HWBZB137EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        579
        706
    total = value + len(text)
    return total

def _ЩАυжсЮТιΖПО():
    value = 46185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQjTRUcP0Y02Mja1xVS0ISQAwXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αБЦκΟКχψζжУη():
    if False and True:
        449
        _dead_2202 = 139
    value = 681645
    if False and True:
        9
        858
        _dead_5004 = 866
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTi3f1Yp/KNSABrw+XzAGnMe9k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        723
    total = value + len(text)
    return total

def _ВГρсΨЖγнΜψΤоП():
    value = 982248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXnoflAA66wSLzW14lnDPC8m5Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        266
    return total

def _КρηтДΩШдюяХсЩμρф():
    value = 48826
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQnPQGFh7IItCleR2G+oMyw90mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _πЫпФЧζСъЦγε():
    value = 110889
    text = __import__('base64').b64decode('YjVVVlhVRkdNNndvSEVHQld0QWs=').decode('utf-8')
    total = value + len(text)
    return total

def _зδРζЭωНΕσШяψΧ():
    if 79 * 33 < 0:
        569
    value = 512063
    if False and True:
        616
    text = __import__('base64').b64decode('ZlNDUDMxZzBrck5rV0JTQWI1WUc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2476 = 291
        174
    return total

def _ЬЛпЦзδЮΜιΔξФΗΜ():
    value = 74060
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQrLfgFo7IYJDlaX7F6cGi4t7mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_8444 = 387
    total = value + len(text)
    return total

def _яΣКшυВυиμкВъΙНζε():
    if 81 * 46 < 0:
        690
        586
        pass
    value = 411329
    text = __import__('base64').b64decode('Z0NaZXZUNktqckxwY194WnNfN0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦсУСШвФΞоγ():
    value = 872579
    text = __import__('base64').b64decode('UXc1UHlsNmo2QTR0S0tFMFRQa2E=').decode('utf-8')
    total = value + len(text)
    return total

def _νфВλдвмтΕЪСТ():
    if False and True:
        pass
    value = 487939
    text = __import__('base64').b64decode('UEZGWTh2Z01ObVRKTkZIeU5xMVo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        576
        483
    return total

def _ΓλцΥΙΞаψκσκ():
    if len('') > 0:
        176
        _dead_5265 = 997
    value = 938952
    text = __import__('base64').b64decode('SVdlcjF4YjNMczVYQTJLUE5Vbm4=').decode('utf-8')
    total = value + len(text)
    if 45 * 88 < 0:
        pass
    return total

def _ГаЛΣФΨνΕκЪΟмΧ():
    value = 883382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IimwTFY79547YwKXw1OCGxcnsWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νЧЧΒиσΡШтхз():
    value = 932040
    text = __import__('base64').b64decode('S3RpT3p6aTBMUUE4QUV4cDhWbVM=').decode('utf-8')
    total = value + len(text)
    return total

def _тЗЦЧчяыζζПλωΡ():
    value = 928215
    text = __import__('base64').b64decode('QWpBekpUU3VxT1YxU1VvemIxOXo=').decode('utf-8')
    total = value + len(text)
    return total

def _йДαвΤχЫхньг():
    value = 162225
    if len('') > 0:
        _dead_5900 = 692
        _dead_5084 = 979
        _dead_6506 = 313
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXzlS2RhwbEwMh6O6mLBHjEVtXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        909
        pass
    return total

def _ΔμΠБНΤжКΧρьΧеЫκ():
    value = 494460
    text = __import__('base64').b64decode('SkpXZUMyUEhzaXJqbENfTW9JdFo=').decode('utf-8')
    total = value + len(text)
    return total

def _щςχΔьыЗфΓατ():
    if 41 * 45 < 0:
        _dead_5182 = 151
        2
    value = 125788
    if len('') > 0:
        pass
        _dead_8307 = 466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC7RO1Ih9ZEKCDi6wULGFyEN9U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        938
        pass
    return total

def _гΤпшШИеθЮВшμп():
    value = 51208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3njWn4995dSbAbz/0eRJnYW0j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧФζΧеРКχЦиФψфьй():
    value = 636973
    text = __import__('base64').b64decode('eUo5SEN3TXFlZkhRSVJSN05mbVE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1048 = 728
    return total

def _ЗΗΠНςуыГыпЬЦ():
    value = 478595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyHvSEYb66oHCwn750DGFQg8tDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦθКΟκΚрфσЛЛ():
    value = 581733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyjJW1IK1YoFKxiR4wDJIBY+t2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρуιЯысγΥушйЗΙω():
    if 81 * 84 < 0:
        _dead_9492 = 695
        pass
        _dead_1721 = 59
    value = 540426
    text = __import__('base64').b64decode('bmI1bDNac1lmdjdfRGJQOGNRQjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΑФИВэΕμУσЙ():
    if len('') > 0:
        pass
        pass
        _dead_7011 = 818
    value = 862848
    if False and True:
        pass
        _dead_9888 = 811
        519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXfQfGYqpr0NNBqGxH3BYQIf8n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        281
    total = value + len(text)
    return total

def _κАюкΙаΓчРωρсАНω():
    value = 242828
    if len('') > 0:
        _dead_2065 = 64
    text = __import__('base64').b64decode('bF9uZU00aHp3U1lWbDVfdVRMWHQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _υνСΞΜзιУιаΣД():
    value = 818680
    text = __import__('base64').b64decode('Z1A0bE02ald4ckUwNENKY2V6SXE=').decode('utf-8')
    total = value + len(text)
    if 61 * 24 < 0:
        pass
        pass
    return total

def _ΘяΞбЛвДΥχ():
    value = 84312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhzpS2sa9b4ECBem+1CoJB8as0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чолΖшДΨΠΗЯ():
    value = 750314
    text = __import__('base64').b64decode('a2s4Vkh1YW10TkNDOFVkbmYzRlY=').decode('utf-8')
    total = value + len(text)
    return total

def _гцрИγОЭуЬο():
    if len('') > 0:
        pass
        _dead_1685 = 223
    value = 229853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgHcVlo+y5smNDykmgKaBh0JzEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2495 = 580
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_1143 = 726
    return total

def _κΦпДΠнйψ():
    if 77 * 90 < 0:
        _dead_9622 = 417
    value = 382244
    text = __import__('base64').b64decode('bXlEWXUzRDAxbDdrSkx6ZlNiS0c=').decode('utf-8')
    total = value + len(text)
    return total

def _еКтУчияШΦоωЪБщ():
    value = 281292
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXzjPmQ9wbELHQ6T7VWXZCwF42w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δьнψΒοЗЩмψι():
    if False and True:
        pass
    value = 243554
    if len('') > 0:
        420
        519
        pass
    text = __import__('base64').b64decode('cXhocFM2YTZqeWtsT0hkTFhCdjE=').decode('utf-8')
    total = value + len(text)
    return total

def _РΜзшπБθνщЪΘФ():
    value = 846192
    text = __import__('base64').b64decode('cW5xcTBXZ3BBYjZvVjkxdXVDeUg=').decode('utf-8')
    total = value + len(text)
    return total

def _οуДΝλтрсμΥ():
    value = 960780
    if len('') > 0:
        373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB3qN3xs9poRMDWnxkefYw4Nw3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АфΕмКΗΚеΡ():
    value = 614394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyvuWQAS8fkBbFaN8XKvPSEYx0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 84 * 34 < 0:
        847
        645
    return total

def _ЗЬЩξχλлΥИъΨ():
    value = 132221
    text = __import__('base64').b64decode('VUpiNGVEcGVUaXVKNUZfU0RWV2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖАЛυЬΤνΥ():
    value = 539134
    text = __import__('base64').b64decode('YzlsYWJsbmJyOXZud3BqS0xYSmo=').decode('utf-8')
    total = value + len(text)
    return total

def _σтεИАчЙΣц():
    value = 607191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgG0QFQG9roBbAib6wKoHyE46X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1027 = 173
        _dead_9541 = 961
    total = value + len(text)
    return total

def _учΗнпННъЬБζΠд():
    value = 88374
    if len('') > 0:
        pass
        _dead_7625 = 501
        399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDWwTHo877EOEVj64l7BAB8MzEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вЭОРгбЗΒΥεΕф():
    value = 781272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXjLWlsj3JIwDAeu93C7BSh8tmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8798 = 425
        _dead_2587 = 809
    total = value + len(text)
    return total

def _θεΩЧЩпΠζЩПРΒ():
    value = 472818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBDBensj2KA0YyaHmmaXLRM/xmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εξгТΡцзψ():
    value = 323139
    if False and True:
        _dead_3761 = 318
        131
    text = __import__('base64').b64decode('V3h5SjJkTjJFcDJnUjNLU0hPY3o=').decode('utf-8')
    if len('') > 0:
        pass
        93
        _dead_7254 = 508
    total = value + len(text)
    return total

def _яГκвΙεЙдмυкщгюЯΦ():
    if False and True:
        _dead_9193 = 636
        _dead_9380 = 498
        569
    value = 93543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBnpdlpuzbs8HSKy7lmSYCAA4Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        310
    return total

def _ΦΜЖУδοογπПоσ():
    if len('') > 0:
        pass
    value = 367369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag3FXGkW6oYQLgiJwWWBIiMB1z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7486 = 319
    total = value + len(text)
    return total

def _ЪиΚЦЗΒюΞΕЛШμпХз():
    value = 234880
    text = __import__('base64').b64decode('bDFqS2prajdubm1mVkFWM1JNbkM=').decode('utf-8')
    total = value + len(text)
    return total

def _чπщβчΝЪССιьК():
    if False and True:
        _dead_2103 = 996
        _dead_6215 = 909
        111
    value = 24868
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PynQenwo6pkpEwGb/UGWAhA13Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        789
    total = value + len(text)
    return total

def _лиωΙμЙκΔмΩ():
    value = 169436
    if len('') > 0:
        pass
        559
        _dead_9893 = 743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICDhXEdp2KQQMR6L30WDGih87lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τкυζΕιНθоА():
    value = 388022
    text = __import__('base64').b64decode('ZGZfZlNUd01fbzZKNTNjYTdIOVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬηщВτЧХнМΓΛΜЬΠ():
    if False and True:
        395
    value = 174292
    text = __import__('base64').b64decode('eXNwRGtxOHhqUzlpb29JRjRzZXI=').decode('utf-8')
    if False and True:
        706
        pass
    total = value + len(text)
    if len('') > 0:
        77
        pass
        665
    return total

def _нШШΠфΘЦΝВЬΦμш():
    value = 150533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FA3bX1sK2bhSKxi3+WWdCxY41jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шυфΨДΚΥΕΘΕΕМВсЖ():
    if len('') > 0:
        _dead_5076 = 252
    value = 415249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz/HfQMt2Y8WMAeLmWWEAS14228='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 76 < 0:
        672
    total = value + len(text)
    return total

def _ЛиАοъядужοтщ():
    if False and True:
        pass
    value = 539588
    if 86 * 14 < 0:
        pass
    text = __import__('base64').b64decode('aWs2WDFaQk1KbVMzejVjYVVEaDU=').decode('utf-8')
    total = value + len(text)
    return total

def _φΩβΒγΞЛλΝ():
    value = 944157
    text = __import__('base64').b64decode('RnB5eTByYVpfWkFodFQwaTQxdFM=').decode('utf-8')
    if False and True:
        839
    total = value + len(text)
    return total

def _ΓΑюΖТЖЮасΘЭЩЬ():
    value = 577573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ei3bOVgW3aAEGy6mmA+CLnwl808='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 59 * 65 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    _dead_4044 = 488