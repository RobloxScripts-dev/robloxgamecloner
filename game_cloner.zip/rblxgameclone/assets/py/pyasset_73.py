#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ιбвИРнΜЫЮШсτцφ():
    value = 322577
    if 14 * 31 < 0:
        491
        pass
    text = __import__('base64').b64decode('SWs1S2hpa0tqbk92Uzl6cElFT1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _вСбАРαиηьΞцАЕнΖь():
    value = 820252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bxb2WkQg/aQ8EA6W/WWWJXx5xUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΛУЦφбЬл():
    value = 132351
    text = __import__('base64').b64decode('T1YwSXk4Q3Ezazc5ZzhHNTBTZVo=').decode('utf-8')
    total = value + len(text)
    return total

def _δРкЯслБТЯнЫ():
    value = 266424
    text = __import__('base64').b64decode('eVVFWlpUczM1M21ZZUtHSFpUbno=').decode('utf-8')
    total = value + len(text)
    return total

def _хрεХШоλκ():
    value = 877074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HX62Y3RvrIIREyWIkEGXPhcq9ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧКΟΓΟУψΗЪΩΒ():
    if 19 * 50 < 0:
        719
        214
    value = 869845
    if 90 * 83 < 0:
        116
    text = __import__('base64').b64decode('VVVnUjd4MEs0dHNwZ1Bkck1JbVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΔθЖυчβςт():
    value = 552049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxnIOHJr7IQUGFjynV26MRF41Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 91 * 3 < 0:
        _dead_1602 = 557
        _dead_5954 = 861
    return total

def _чТΦΘΞйуψκрЗ():
    value = 11872
    if False and True:
        pass
        589
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxvqdFMA5JFaMSOBzkOTOQwpslc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αаωθВεωтτАκ():
    if False and True:
        pass
        760
    value = 139202
    if False and True:
        318
    text = __import__('base64').b64decode('VVk0dk1TYTFKX0dCYlJQNGhqdkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗбФГЯμςЦУ():
    value = 431434
    text = __import__('base64').b64decode('d1VWa0dUb2cwT2c5ZE1ZSEFwaGs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        655
        106
        pass
    return total

def _εΖχλΜтмΑυΤЦΗ():
    value = 570502
    text = __import__('base64').b64decode('S2dESGZSckFva0pjbk9ybTQ2YnA=').decode('utf-8')
    if len('') > 0:
        _dead_6732 = 212
        pass
    total = value + len(text)
    return total

def _цЯнΒэыωχφьКξЛ():
    value = 683009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MA7DaXsc+4AFIw2kkU6pNzQe5mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 89 * 73 < 0:
        pass
    return total

def _ПεΗБλΚποодт():
    if False and True:
        272
        pass
        _dead_1380 = 1000
    value = 261687
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiLrQWZr+580bT+V21SWMyMf42w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κЙΗΑощдμτЛКижΘξ():
    value = 439415
    text = __import__('base64').b64decode('RzZvb2dzQ1NOd3pKbzZRM1JrMXg=').decode('utf-8')
    total = value + len(text)
    return total

def _чмΥбЬзтз():
    value = 596171
    text = __import__('base64').b64decode('R0tOenVxN0YzeG5fSGc0THJvajU=').decode('utf-8')
    total = value + len(text)
    return total

def _сεЗПλМΓζУΙяАΠИиΦ():
    if len('') > 0:
        _dead_3267 = 451
    value = 407171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxfHN0Fs0oAZDgWk/l+nEAAnt34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8245 = 176
        _dead_1913 = 822
        pass
    total = value + len(text)
    if False and True:
        882
        577
        pass
    return total

def _шΝвфСδуФ():
    value = 939097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDW0QV8arLkANT+r4gDCYygs6G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΕΧΓЦςцЕ():
    value = 848431
    text = __import__('base64').b64decode('eXdSTUVXdHlCMFByYTRtM040bU8=').decode('utf-8')
    total = value + len(text)
    return total

def _цЕбЛТΞΤОеΑΡ():
    value = 980966
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HADMT2UY+a41NyCB93y2DiMM7WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩУΜθΩРщтЗΤхыЙъЭ():
    value = 956509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRu2b1dtqYcHMjmomXKxNSQa12Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΔρηηЧАΓйЪДςοс():
    value = 493593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwnSVwkuy6Y5MBqlzmS1FzIg5Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩХСΣТδΣΑк():
    if len('') > 0:
        240
    value = 742249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgKwO0cj6vkoNQWhylqIFTAF/mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БоεαжАЧμЪЙιКп():
    value = 543872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K33KSHMS1PgMDV360mm0YCAn7ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝЙРдЭνХмΔЬΤλ():
    value = 946671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH/2dGc396UoPTi36gOxDCgLvEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        527
    return total

def _ПαяыγζφяЬεЫзДθΒ():
    value = 882959
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADXDRn0W36MQPiKT2EKqLicp/jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        827
    return total

def _λΓΝУяχγΨΝЕΘыМ():
    if 23 * 73 < 0:
        pass
    value = 729401
    text = __import__('base64').b64decode('RGNrSGFFZGdOMnppMkRiUGZDUlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ωДσжΑъЛыЗЛпΖ():
    value = 686542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB3Sf0Iuyrg0IwWL73mSFgcX9Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧвζΣкΨДцρΛυΞ():
    if False and True:
        pass
        pass
    value = 498293
    if False and True:
        pass
        _dead_6942 = 57
        229
    text = __import__('base64').b64decode('SFkwTk5NMEoyaWFlVldCOE1MS3c=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _исΛЧэАме():
    value = 739816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAW1ZXIr3I8mDV+A+GnFNigttUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕяяΚпληЩφΨжЦэΝ():
    if len('') > 0:
        _dead_1404 = 308
    value = 778384
    text = __import__('base64').b64decode('RHdjYmlJNEkwQlVMYndMOGZJdmU=').decode('utf-8')
    if False and True:
        _dead_4207 = 4
    total = value + len(text)
    return total

def _ъθОбеибЦЯчΘбΜηΠх():
    value = 235415
    if 38 * 85 < 0:
        445
    text = __import__('base64').b64decode('UjI5Wnh4Wnk3akYyeTJnREd3SmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΥйЗαиΙЪпΑΕχΗΗ():
    if False and True:
        pass
    value = 273856
    if 34 * 52 < 0:
        pass
    text = __import__('base64').b64decode('TFBXODNPNUZhSXBOeUhSREdmZjM=').decode('utf-8')
    total = value + len(text)
    return total

def _хЩШБθддΥО():
    value = 836455
    text = __import__('base64').b64decode('eTMxcTVGOVhzd2hBS2xxNXpRdmY=').decode('utf-8')
    total = value + len(text)
    return total

def _γΥξекТвΣЮАЩТсπШ():
    if 17 * 33 < 0:
        pass
    value = 573207
    text = __import__('base64').b64decode('Rjk1MUUxY1pVWW96RDFpd0Nsdmk=').decode('utf-8')
    total = value + len(text)
    return total

def _УΡΓсюгΞфΡζ():
    value = 755248
    text = __import__('base64').b64decode('Sk1BZzlOMnNvWmFxNHlGMHVVRVc=').decode('utf-8')
    total = value + len(text)
    return total

def _чВтΡШкАΕбωн():
    if len('') > 0:
        _dead_8650 = 420
    value = 192150
    if 75 * 12 < 0:
        pass
        _dead_8188 = 276
        _dead_6156 = 764
    text = __import__('base64').b64decode('WkhGRFJnbDBUenJvRXk4RmxPaTk=').decode('utf-8')
    total = value + len(text)
    return total

def _τκΒфьВαшγηοЫП():
    value = 232273
    if 13 * 77 < 0:
        358
        pass
        _dead_4653 = 364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzzWelMK0ZI2Hl6TwgeWIAkq3T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_4443 = 845
        pass
    total = value + len(text)
    return total

def _кЭРЙΤχΖνΖцΙδ():
    value = 602989
    text = __import__('base64').b64decode('WUZScFM0SzJoZVJna1l6RGRxQ3A=').decode('utf-8')
    total = value + len(text)
    return total

def _еσΡΩПΔσρдχΑКφЛΠ():
    value = 807274
    if len('') > 0:
        82
        pass
        832
    text = __import__('base64').b64decode('YkZCd1JCS2JCU0REaF9sdFQ4VTc=').decode('utf-8')
    total = value + len(text)
    if 36 * 44 < 0:
        pass
        152
        180
    return total

def _ФРΤШМТεфуМЗ():
    value = 732140
    text = __import__('base64').b64decode('eFBzVmFxaUpsZ09KaVlNQ2VnQ2s=').decode('utf-8')
    total = value + len(text)
    return total

def _рвζдЮυМьΓ():
    value = 18786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET3qQWtqy4QmFF/64FOIPnwk9Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δнхЪНσШЦЛРΟВΟч():
    if 72 * 47 < 0:
        pass
        _dead_6722 = 216
    value = 199072
    text = __import__('base64').b64decode('bGxFOFc5RWMzelkwc0ZLamdEUlY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        32
    return total

def _МЦαΛχδйЦΟΥ():
    value = 562085
    text = __import__('base64').b64decode('QTlUSXdYZTRfbXYzOTcxeHA1bkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧοдαАСЫж():
    if False and True:
        195
        pass
        pass
    value = 155269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhrAR2Bp9aEkEgH38nmIIzMW5zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕυубδΥιШομНюиΣκ():
    if False and True:
        681
        _dead_5808 = 730
    value = 336956
    text = __import__('base64').b64decode('cWFxUW9scVRabTJucDR0YlpreWI=').decode('utf-8')
    total = value + len(text)
    return total

def _νΛВΟБЖετ():
    value = 986154
    text = __import__('base64').b64decode('SVRiaGc5MWVfc0M1SlAxQndRWFA=').decode('utf-8')
    total = value + len(text)
    return total

def _κЕАшΩЪΔтУФΓзο():
    value = 484642
    if len('') > 0:
        _dead_6944 = 733
        _dead_5530 = 612
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzazfVYb84wmYg2M93ijEzQ+yjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_4629 = 297
        pass
    return total

def _еНТКилЛЛδιΚГΛΨу():
    value = 576517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn/rQkgKr4RbLAv1232qNikqyTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιτΨБГнЩΞνэσΛю():
    value = 154899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQPhbFQ/970aFTX14EfHIiR5sFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υжΕБЙЫсΤД():
    value = 942431
    if False and True:
        982
        pass
        pass
    text = __import__('base64').b64decode('dnlMWDIzaHQycFBXSlB1ZnNXUlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _БрШΗυθСΦчЩЪεюηςσ():
    if False and True:
        438
        _dead_2230 = 254
    value = 743672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARfXQl5g55wMAiTyxU6eLiEa8HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 7 < 0:
        631
        _dead_8151 = 847
        pass
    total = value + len(text)
    return total

def _ыθΤτξДЗΑυΧΠβ():
    if len('') > 0:
        _dead_4264 = 390
    value = 959746
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHv3YEEUy78sMTCm/F3BBS4E1GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТδзχλБцкИε():
    if len('') > 0:
        546
    value = 87380
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBDqbGBpq7ICGTmx53TBCyYry2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4060 = 686
        pass
    return total

def _хжмДПКщИ():
    value = 656115
    if 94 * 1 < 0:
        _dead_6910 = 588
        _dead_1307 = 675
        925
    text = __import__('base64').b64decode('VDJ1cWt4ZEpRd01RZE5NeFc3a3E=').decode('utf-8')
    if len('') > 0:
        332
    total = value + len(text)
    if 74 * 12 < 0:
        pass
        _dead_4673 = 345
    return total

def _щГΔξСΝΞйΞыχΛыШ():
    if False and True:
        pass
        _dead_8390 = 80
    value = 876981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgbWN0gcy5cJLAeZnETIZBwX00U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЭσΗΧΥηдНВυ():
    value = 784497
    text = __import__('base64').b64decode('Ulp1b09MSTFqeXpfYTdwRGZSVGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ξВπΧΟΧюкΥИЯμΑзСΣ():
    value = 954783
    if 42 * 45 < 0:
        _dead_3524 = 504
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxXQXGFop4FaMwL75HTFGB0k4Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 39 < 0:
        53
        _dead_6736 = 408
        pass
    total = value + len(text)
    return total

def _йδноδяΓщΘюΨЬЬбХσ():
    value = 39909
    text = __import__('base64').b64decode('dm5BYzEyZlNHWWZkVU1NTXpScDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕэιΠшРμЦБθщσйδ():
    value = 715395
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTa3ZGgtzKM3HV+k7HScZiQB5jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωТΨπαΠтш():
    if 21 * 79 < 0:
        710
        486
        _dead_5780 = 447
    value = 677633
    text = __import__('base64').b64decode('aGRSb2hPRTJvWmRBdmtZRUV1VXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥИРфΟΠвэао():
    value = 793692
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz/3W18D6/ETFhak5FuTDHcd/F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыεΠзηωлДΝ():
    value = 651296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB/RXEsM3bAMEVmV2nG7Iw83wFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эЧмВΧЬηчшШчПА():
    value = 474153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXjiYFMwqK06CCusnkHFPCkKz2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΖΦдрμГΛбΨяφЮΨΠ():
    value = 411375
    text = __import__('base64').b64decode('WVE1VFhXZXVsTjdGZmt3WHBhbFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ГоειαмΤΖ():
    if 18 * 95 < 0:
        _dead_5399 = 981
        _dead_6862 = 659
        663
    value = 203424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBXlbG4t7IMxGS2N60WaAxR5wlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΒσягкΝαΙШΑ():
    value = 935034
    text = __import__('base64').b64decode('YlcyaGNOaGVTZmp3ODhoSFpsaDE=').decode('utf-8')
    total = value + len(text)
    return total

def _уγβЯХщΣΜΚ():
    value = 527429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAb1O1opy7khC1et3gW5GjQX12Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        513
        _dead_4789 = 411
    total = value + len(text)
    return total

def _ЦΝФΡВБЦΨлΑАхЗ():
    value = 635810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgTyWnc+rY0iEQai+XmBEXYo42s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФψΘДШξΟнАχθчБЭаΧ():
    value = 89879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhrjaHkJ7pwFEhyxzHqXACIN8X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яжЗеβКНψεеэъэмй():
    value = 966610
    if False and True:
        _dead_6877 = 770
        pass
    text = __import__('base64').b64decode('VmFxWTgyQTYwbFZIYWp3YTdBQ2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΒСКξЙΔγКзΧвеεа():
    value = 155745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjzXNkc+2aEiHBqayUaqAA157k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΨВрπεηЧΓ():
    if len('') > 0:
        pass
        96
        pass
    value = 91010
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiHNO0UWqoElFD2C0m+XZSYJ72k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 8 * 13 < 0:
        pass
        pass
    return total

def _эΝυγЕΖЫУΞΝхЯЯ():
    if False and True:
        pass
    value = 706381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCbtXwg006BVPimXnW6mMC56t0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚчфΧхελЬщΝηКΑУф():
    value = 104805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiTqYFIYr6AMMl312lC1bTAJwG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΩдΙВΞολ():
    value = 438346
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwC8XXsr3P0sFx/6/FmUACN+114='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АбΠВΠξХπаЫЪАΨцС():
    value = 484551
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhDybFw6wZ82GAybnWS6YgMCync='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДмχВуПКοиθшΡю():
    if 14 * 79 < 0:
        _dead_9521 = 914
        129
    value = 678024
    if len('') > 0:
        pass
        _dead_1466 = 811
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn3memUGqakgPhihy1uaMwt802c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤπζΩΦЮчΓθΧщ():
    value = 271591
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjXTRVNr5LlXHwOW+QGqAiwGw14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ДхфЯкЮЫНАφЧΘ():
    value = 84900
    text = __import__('base64').b64decode('VkZCS2liOUdQWTRuS0ZOR3UyTm8=').decode('utf-8')
    if 56 * 82 < 0:
        _dead_6972 = 694
        194
    total = value + len(text)
    return total

def _пеБШйχлТЖюъюДй():
    value = 653439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyvHSkk4rK0pOweg43rCZTAL7Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3907 = 592
        _dead_3700 = 734
        236
    total = value + len(text)
    if len('') > 0:
        297
        _dead_3606 = 107
    return total

def _ΜйЬГΗδэΚфΟ():
    value = 818475
    text = __import__('base64').b64decode('WEZ0WnRNS1J5WTFrSzExNzVzNjg=').decode('utf-8')
    total = value + len(text)
    return total

def _бЕУδψуΦЫ():
    value = 895004
    text = __import__('base64').b64decode('cTFacXNfSXFwNHdCcHJGd2J6MDM=').decode('utf-8')
    total = value + len(text)
    return total

def _йΡЦΛЪμмХЫυ():
    value = 174279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IC63SQIG8vg6AzqL+UG8HxR900U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯεΕТЕΔαЮ():
    if False and True:
        144
    value = 52197
    if 38 * 86 < 0:
        _dead_3418 = 286
    text = __import__('base64').b64decode('ZWZORHE0MElTZ3BYRUN5Q1hBYWw=').decode('utf-8')
    if False and True:
        _dead_2363 = 891
        pass
        _dead_8370 = 725
    total = value + len(text)
    if False and True:
        780
        861
    return total

def _шτХцψВЮлΠМΤпςАи():
    if False and True:
        pass
        _dead_1077 = 700
    value = 961561
    text = __import__('base64').b64decode('YkhYcXN4cWZrenpsQnZxN2tsMjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _θγΩнЮиοэЧеьΔоЦ():
    value = 145322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxnMV24x+Z43Hz6o2V++Gg0M1Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒээьζхьХΖТмΗΧΚф():
    value = 918039
    text = __import__('base64').b64decode('UEF6VXp4a2xaS25rbzFWSWlqV2o=').decode('utf-8')
    total = value + len(text)
    return total

def _сςλхвФβШрАΙθЦ():
    if len('') > 0:
        653
        _dead_8588 = 616
        871
    value = 142331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXzVRnMv8q0nH1+N7VyGEBEFzUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫяΣΨуЪдАфбτ():
    value = 783447
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISi2N10WrqcQblyswV6nHyE/0mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦяΑгΙФПьи():
    value = 581130
    text = __import__('base64').b64decode('ZFZDMm10Z0dQN3ZyUU5aaWNPVFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦящАεкδт():
    value = 490705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHjceHgd9aMRDQqu5UyHAjI+tmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _уφКнρыΟшΩЮΣςδо():
    value = 580083
    text = __import__('base64').b64decode('TFl0ZmJzWmR5SEgxRFRNaG5rOVg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΛзθЖφτΝи():
    value = 295842
    if 44 * 63 < 0:
        _dead_4883 = 614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lnu3WV0v6awIFl37ynufBDJ790M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4101 = 809
        _dead_7129 = 855
        pass
    total = value + len(text)
    return total

def _θрτЙΝтρνПБЬζοъσ():
    value = 289526
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRntYGk3/bgSDAC12FOEP3UuwFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8802 = 75
        _dead_1902 = 74
        523
    return total

def _μчпΣеХЪЫймжЫАоМχ():
    value = 86809
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDWxZ3wSpqYRKRfy+E+HJCd5z2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡоιΜиЩЗζярмдΓ():
    value = 954435
    text = __import__('base64').b64decode('a0gyZ3paWW9odE9UaHIzZ01wTmM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        17
        pass
        _dead_3413 = 818
    return total

def _ΒΝуНηЕМΟΧеδфбςчВ():
    if False and True:
        pass
        pass
        pass
    value = 584582
    text = __import__('base64').b64decode('ZWdKNlh5OEdUQXBIbnltb3p6X08=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_7740 = 998
    total = value + len(text)
    return total

def _κΜφЯοжиγμщνЯςНδ():
    if 89 * 72 < 0:
        pass
        _dead_1642 = 969
    value = 374872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxrqYUkB/IEXCzeQ2FzBGhQn12U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιсσπпιΩρ():
    value = 551784
    text = __import__('base64').b64decode('YUVoSG5oc1YzRVBqSkQ1YWVBQks=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕшψйτМΤбрΕηЮ():
    value = 419407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgHcWXMJrYAUPSGN7X6SIHAm7V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΓкΩящШр():
    if 5 * 89 < 0:
        pass
        255
        37
    value = 825122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh7qal5r064QAyy2+36mGRB+w0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΡπΦφΗμЦηВγΨЧΞЙ():
    value = 215529
    text = __import__('base64').b64decode('SVJORUdKRDlMdHNWVnRDYXlqRFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΜλъωЗΛΘΡЯВоК():
    value = 95234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Djr+e1ogybwgaBm50QGbBgl7zFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΓЛιПΗπΥΧλэψой():
    value = 608462
    text = __import__('base64').b64decode('VWhmR2NMcEFwYW5hWVpKZWJVcWs=').decode('utf-8')
    total = value + len(text)
    return total

def _СКШλБеоУ():
    value = 47018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn61ZQgYyKQ0EDicz2OebCQo1lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 45 < 0:
        _dead_9409 = 176
        _dead_2222 = 882
    total = value + len(text)
    return total

def _СгЮαЫПчеκΖФπ():
    value = 167284
    text = __import__('base64').b64decode('WTdQMHBTT2Q3WVF2bHBBNTRKTDU=').decode('utf-8')
    total = value + len(text)
    return total

def _яΓςшνхΧАЧжλ():
    value = 102113
    text = __import__('base64').b64decode('RXZhRDNKMlVZZHBvSUgxU0VMaUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _УωцЙуξцч():
    value = 672076
    if False and True:
        617
        341
        360
    text = __import__('base64').b64decode('T2tzNjJGZzYySXdLMUpsa01MaWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ОτοЫГΕБυИяΚΔδΟχο():
    value = 403174
    if len('') > 0:
        pass
        232
        373
    text = __import__('base64').b64decode('dlNVQzc5ZmtQNHVDdXhMNkhfMUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕψЮγКΥΖφЩ():
    value = 858996
    if False and True:
        827
        _dead_5254 = 534
        _dead_3348 = 946
    text = __import__('base64').b64decode('bWUyX3g4SkY1NzB0UlVVV09qYWo=').decode('utf-8')
    if 44 * 30 < 0:
        _dead_7085 = 347
    total = value + len(text)
    return total

def _йιαдШргсАТкэеЕ():
    value = 574369
    text = __import__('base64').b64decode('bDUxOTZRYVFNUE00UFFEY1V4QUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦьЪΜυЙΥнЛбъШξΑ():
    value = 133153
    if len('') > 0:
        pass
        489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB29bEI/qaonEFym0lDBJXcdxns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КксЙЫФΩфωζЦМζ():
    value = 831904
    if 46 * 14 < 0:
        _dead_3948 = 991
        13
    text = __import__('base64').b64decode('Y2UwYXdDeHZndDZRTld2WmVDSXk=').decode('utf-8')
    if 17 * 22 < 0:
        pass
        pass
        pass
    total = value + len(text)
    if False and True:
        779
        574
        495
    return total

def _ЪвТЗΜГΛΣηщЗХΘ():
    value = 871643
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3nIeWsex74CPhn67GCzMB8GtEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρоΙШΟзбη():
    value = 382206
    text = __import__('base64').b64decode('UkZueTBWTWE2aTlGVU9KNjFDcmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΑжзьЖΗТ():
    if False and True:
        506
        454
        668
    value = 473571
    text = __import__('base64').b64decode('aW5wMjlyTk5lY1RycHp2cl9UMU4=').decode('utf-8')
    if False and True:
        _dead_4060 = 144
        pass
        _dead_4209 = 680
    total = value + len(text)
    if False and True:
        _dead_8195 = 674
        _dead_6840 = 138
    return total

def _ъЛςςΠВЧсΝΩ():
    if 71 * 72 < 0:
        pass
    value = 804693
    text = __import__('base64').b64decode('bVVTckVJUEFwUEhLNTdTMHprQVE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        141
        _dead_4889 = 316
    return total

def _аΟчΚТлЧιΧΕπΤ():
    if 44 * 8 < 0:
        416
        11
    value = 518591
    if len('') > 0:
        123
    text = __import__('base64').b64decode('UV9TXzdXUkhZMHBUM1dBak1Ua1M=').decode('utf-8')
    total = value + len(text)
    if False and True:
        467
        _dead_1671 = 436
    return total

def _гΔжΟΤοзкδУЧЭсДв():
    value = 572220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BD7cQ0Ya3aUHMQ6MmUXBPQ8a8Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΝλейюЕБэГΚщСЬκ():
    value = 883106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3+xWGgz6oMkCTmq2FelG30rs08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨορσоОχЩЪ():
    value = 387229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BB79X0Zs3fo7EymT+mWBADN39n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΑγΙβΧыΑЙΥεЭ():
    if False and True:
        _dead_4316 = 601
        788
    value = 152508
    text = __import__('base64').b64decode('WDFrZ3RVWUcxUEJzTlp3eFVHWXc=').decode('utf-8')
    if 76 * 82 < 0:
        _dead_3865 = 32
        _dead_1588 = 456
        931
    total = value + len(text)
    if False and True:
        pass
        pass
        172
    return total

def _ЧξΥΩВοξΔΒхЙο():
    value = 481498
    text = __import__('base64').b64decode('SmZYVlFMRVVjazZqVGU4VW5WMms=').decode('utf-8')
    if 78 * 37 < 0:
        606
    total = value + len(text)
    return total

def _пэψАЗΡПθЛЕцНмЭГ():
    value = 317856
    text = __import__('base64').b64decode('VDA4Qk9QZ3JobFlOTnVJTlBTMlo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        876
        _dead_7655 = 815
    return total

def _ЮНτφЕηζфΤоЗТбюΙχ():
    value = 840574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxXCX2kgx7goEwib/X6fDA0m50E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑИΩΧОΜΝСΠГ():
    value = 668532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR29QXc2+78WEl2unWWxFT8D9GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΜΞΕчУοΚφοмхΣОρЙ():
    value = 765469
    text = __import__('base64').b64decode('ZmdYWlJLd2tkcm95bkJFVDg2ZU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦζШΗЫОτΑΘΥΧ():
    value = 303375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgbFT1xr7b05OSm7mkSVGjEe/Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        935
        pass
        _dead_9859 = 492
    return total

def _ιХшЦΚιЙжβμθΗιΚ():
    value = 629870
    text = __import__('base64').b64decode('SmVMdnpyWmR4dFZpa3ZYb2w4aDU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛλрκРСЗВо():
    if 48 * 38 < 0:
        pass
        222
    value = 528744
    text = __import__('base64').b64decode('RFBURXFYVWRHOGtfNEs5STRCazY=').decode('utf-8')
    if len('') > 0:
        663
        _dead_2459 = 415
    total = value + len(text)
    if False and True:
        _dead_4794 = 799
    return total

def _йГщΙБζямΝхэιΝ():
    value = 418631
    if 37 * 31 < 0:
        pass
        257
        _dead_5112 = 194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXn+UWIqyf00BS6cy1S3bAkXw2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖрΩΟςЙЛφлЙ():
    value = 50728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRfNO2I685IMbwmv5m6iInUas2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΖнθНтεЯЮ():
    if 21 * 69 < 0:
        pass
    value = 245491
    text = __import__('base64').b64decode('ZzdiVDUydnNFeHBOazM3bDN3bDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ДжβтПλеζΠιлΗеУВю():
    value = 235795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB3iYGgd26Q0Lxyvz1KmGzAf7nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕιБΘдЖПΟМшаБ():
    value = 216552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy79PWQ2zPoPDwDwywWZIzEHt20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЭηΥяЕЧЦю():
    if 70 * 87 < 0:
        pass
        997
    value = 399913
    text = __import__('base64').b64decode('cUFiSEw1emwwdXB4U3MxRjNFcTM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЕуеθκςβУзЖвЗю():
    value = 428370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgDQYG4dyI8KGyD02FikOSR97mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςбЭЧΩηΝоΡ():
    value = 815854
    if False and True:
        531
        _dead_3806 = 811
    text = __import__('base64').b64decode('elRMWWJOb2VFWERfbHZPTjgxUmk=').decode('utf-8')
    if False and True:
        _dead_1078 = 339
        pass
        pass
    total = value + len(text)
    return total

def _ΦПЬξОШεфчζБУΡкρь():
    value = 329114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAayOEc/9rkHGT+7x2CjLjYftH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οыыχΙηθРΚγХИε():
    if False and True:
        pass
        _dead_9505 = 478
    value = 292657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AC3SW2Aw5KobIjqPnw6YFgoi1Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        814
        pass
    total = value + len(text)
    return total

def _θЩΤΩΞΑοЙδе():
    value = 453423
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nhv0bGs3z6MvHRu3wE+dHSMry3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7108 = 100
        pass
        459
    return total

def _дΧБяαφπЪΙЮ():
    if len('') > 0:
        433
        632
        _dead_8091 = 700
    value = 72240
    if len('') > 0:
        271
        949
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHjKTV8L9PwmGAGX2HipBxR2yFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _χΗΒяΨуυкτКь():
    value = 812893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTXjPksQ9rE3ORyr3nWXPQo14Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        917
        pass
    total = value + len(text)
    return total

def _οΟτцЬЦцйς():
    value = 111803
    text = __import__('base64').b64decode('Wl9Rb1hhQThzaTFaTXBMSngyXzY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        399
        _dead_4207 = 166
        pass
    return total

def _ЫΑЪχΞЧГΟАσανКд():
    value = 869745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyP3XAEIxvw2PiCqnWWIITYXxUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        528
    total = value + len(text)
    return total

def _ξюΜщΣнхыΒξВνд():
    value = 984268
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAvcOUkA/6dUGFulxAWJbD0k9kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςςΙиπηкЙΚЙΤиЬΞы():
    value = 428367
    text = __import__('base64').b64decode('eWt3cDd0NkZIRENKbkxvY0JQZGI=').decode('utf-8')
    if False and True:
        _dead_7804 = 579
    total = value + len(text)
    if False and True:
        995
    return total

def _κЖΡСЮκАцΘЗС():
    value = 658009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQzUYgQTr6oFPAG3yX2YNy0Z3EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θБηΤΚνПβгПрβ():
    value = 994534
    text = __import__('base64').b64decode('QU5JNXZ0cnFPek1pelpINjhTRkw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        567
    return total

def _εΑъνияЩοДυδБрЛЪ():
    value = 764381
    if len('') > 0:
        _dead_9182 = 790
        _dead_9322 = 798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH3oSAIp8J0wGSKH2mW0DAd450M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еζφйХочцΟωσшζ():
    if 23 * 71 < 0:
        783
        pass
        _dead_5789 = 301
    value = 465787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD3xWlhr6rtVDS6A2k+VAwoCxm8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κъЦХтΤΝЫς():
    if False and True:
        pass
        227
    value = 492194
    text = __import__('base64').b64decode('eTE5dWJqdzlhRE1ucUxDZFJsU2E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ВНΤηψоΣсЯδΨп():
    value = 650243
    text = __import__('base64').b64decode('ZlJwTkhtelFneUczbldwUkpJcEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒВχΡаЧюьыαшфυςЛ():
    value = 540031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChXeVkYz8IU3GS2m22mJMyIs8H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΓБΨЯΒДΡ():
    value = 3011
    if 5 * 28 < 0:
        800
    text = __import__('base64').b64decode('cGVsRnpCMW1ZanBVcmRGN0lEMlA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        966
        pass
        525
    return total

def _θИμеΑνςаяξЗ():
    if len('') > 0:
        721
    value = 435565
    text = __import__('base64').b64decode('ZjV3VVdyaDFXUl9ScENuX3BGNE8=').decode('utf-8')
    if 91 * 77 < 0:
        _dead_7581 = 108
    total = value + len(text)
    if False and True:
        _dead_7246 = 770
    return total

def _οгюоΞβФшοβΑпИы():
    value = 109012
    if False and True:
        _dead_5894 = 139
        82
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSr8eH8V36AyNBi33VW2PTwZ0Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        776
        318
    return total

def _чджΙΘΟπЛФΖΦцΠуР():
    if 42 * 43 < 0:
        pass
        _dead_9272 = 791
    value = 841882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXjlQ3QSyJozGxymn1WeJzIj92Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οУνОЫΗСσБ():
    if len('') > 0:
        205
    value = 769476
    text = __import__('base64').b64decode('WjJtUTJva1ZmMEROTWVyeTRNdl8=').decode('utf-8')
    total = value + len(text)
    return total

def _щЭλцЗξзп():
    if 90 * 33 < 0:
        400
    value = 27978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAizfn4Ky6k2Ajau6WejHiM+wD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νХΣφХеЫξУкэЩО():
    value = 929202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzrlNwg76LwhNBav5gHAZCM87Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РЛКБοοОΓЗΘаМЮЛъ():
    value = 283936
    text = __import__('base64').b64decode('VnRkT2dNVWNaUURocW9WeGd5Ulo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔωБρΨйΒБ():
    value = 369754
    text = __import__('base64').b64decode('dGNqRGd0Y1VQWER6TGVvNXBvcm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤМлцЖЮжЛοЕрхэΔ():
    value = 83288
    if False and True:
        786
        284
    text = __import__('base64').b64decode('STVLTWcyOHhKaG9XQnhEZFA2anE=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 81 * 18 < 0:
        _dead_1799 = 265
        815
    return total

def _ΓκΚкаθηΩС():
    if len('') > 0:
        81
        _dead_5573 = 621
    value = 869415
    text = __import__('base64').b64decode('SF9kQ0dSTzF4UzVQZTNKd2kzWUc=').decode('utf-8')
    if False and True:
        _dead_2136 = 548
    total = value + len(text)
    return total

def _уτЫφχвΤδΩΙъГεΗψл():
    value = 883026
    if 80 * 64 < 0:
        134
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AD3QWGAIyfsEBVmO+FGmHi0rxmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 28 * 32 < 0:
        _dead_3666 = 344
        _dead_5040 = 249
        pass
    total = value + len(text)
    if 27 * 4 < 0:
        pass
        pass
        592
    return total

def _εαΛуκапЩ():
    if False and True:
        408
        337
    value = 566778
    text = __import__('base64').b64decode('VVdCWVJYNUE5b0c2bEZQdFY2NTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ВймΜеБЕИΔτОн():
    value = 500207
    text = __import__('base64').b64decode('TU5ROHdhNzJEa3d4cVFQOHVVRUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΑЬρΑσΕζЬшΒЮσΨβ():
    value = 833379
    if len('') > 0:
        190
        pass
    text = __import__('base64').b64decode('V2x1Z21wTkw5ekNZYzNFc3JDUEk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        79
    return total

def _ΙуДщаΕΖйтαУЛοεЙ():
    if False and True:
        _dead_1171 = 300
        pass
    value = 526994
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjzxWAMO6Z8XHF6rmmWaFgcn4mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜдΒПТиΔсЖхΝ():
    value = 766414
    text = __import__('base64').b64decode('aUE2RnR5U3JjQUVMRGhSVFdHS0M=').decode('utf-8')
    total = value + len(text)
    return total

def _нκаМΨиΡФ():
    value = 445186
    text = __import__('base64').b64decode('RUZjODBtd3J5MDdocnJ6OFNId1M=').decode('utf-8')
    if 54 * 7 < 0:
        _dead_8770 = 953
    total = value + len(text)
    return total

def _ΜΔКйвγМВр():
    value = 135459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBvLT2Eq5oEwbzyP+n2+Axce12w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΑΩκΔООзΨΦт():
    if len('') > 0:
        275
        _dead_3302 = 305
    value = 996375
    text = __import__('base64').b64decode('c0M5UUtGeEZ5aTVLMndQVmIwYWw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _мζγыйЙΖςνчΟΖНΦЩ():
    if 60 * 39 < 0:
        pass
    value = 858301
    if 1 * 66 < 0:
        _dead_3693 = 173
        _dead_9292 = 517
    text = __import__('base64').b64decode('b0tHRl9Nb192YlZ1RUZNVGR1c28=').decode('utf-8')
    total = value + len(text)
    return total

def _ъпьЛχΟζΓьМΓ():
    value = 830494
    text = __import__('base64').b64decode('UlhfR3JOcWU2X2VfSVhBem1YWDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЦкгЭпИвГХКΖхЫΗе():
    value = 468465
    text = __import__('base64').b64decode('bE1tTGR5b0dVUXlDSFBQZ1pRUFY=').decode('utf-8')
    total = value + len(text)
    return total

def _чбЩΦσφйυΚ():
    value = 941668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwD9PEBs1Ls8Hg33/Q6zDhMG4nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒоеыИΚΕшКφΞ():
    value = 718958
    text = __import__('base64').b64decode('a2w3VnJ5elFmeEp5UGdQMm5YWEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮπγφδоωшσЬμаЩ():
    value = 493309
    if False and True:
        _dead_2794 = 161
    text = __import__('base64').b64decode('d1ZxX1RVdENJbjFDNlhqR2ZSWDI=').decode('utf-8')
    total = value + len(text)
    return total

def _уΥЫΠЦΣΑηλγ():
    value = 365624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hxzqb1Qg+/E0Fl2ykAe2NhYj110='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΧπцΡΨохБωДГШйΖф():
    value = 664269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiLhaHYz6foKYhb13wabPQJ8z3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ппфυхМЭРωΦпЬБРρР():
    value = 637756
    text = __import__('base64').b64decode('cmxLTEhHQmJwUEJBNzRqbWM2MVk=').decode('utf-8')
    total = value + len(text)
    return total

def _φтяΣТкΧМτлХΝπЫ():
    if False and True:
        396
        pass
        _dead_4122 = 481
    value = 634080
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fwv2fmYh0YEaO1v1z2KbC3d/vVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мβζΞΤЖлΘηеΡΒаςК():
    value = 963024
    if False and True:
        330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CC3WfUI7z6UUFyOw61uHIiQn4VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 20 < 0:
        _dead_8021 = 402
    total = value + len(text)
    return total

def _бΩХГΠгэМΞαΞЖЛЮб():
    if 6 * 50 < 0:
        618
        193
        pass
    value = 157220
    text = __import__('base64').b64decode('V3BiWTRIZFZzb09QcWxEN3QxbDM=').decode('utf-8')
    total = value + len(text)
    return total

def _мЩэЗтщΦфΓεБЕа():
    if len('') > 0:
        pass
        806
        pass
    value = 267128
    if len('') > 0:
        235
        pass
        730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kwi3S2MY8qpaayCK4mzHOCYGtXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7428 = 345
        _dead_7023 = 463
    return total

def _шЯπζйАδΑ():
    value = 863935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAL1QF8X7qcnLgSx2FygDA0s6V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭТσδХЗΦЮшρьС():
    value = 876562
    if False and True:
        _dead_3650 = 440
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxXeTHI86oxQCV2S3FqIF3YD/UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 66 * 73 < 0:
        _dead_2512 = 48
        _dead_3476 = 900
        287
    total = value + len(text)
    return total

def _ъАэьφПАмцχνШΠД():
    if False and True:
        pass
        _dead_9968 = 689
    value = 143934
    if 52 * 99 < 0:
        pass
        _dead_3701 = 147
        346
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DALcQ1Bv+aINH1aTnnOZOSR+wn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юΙЛиНγКЬщПЦКОχяш():
    value = 291612
    text = __import__('base64').b64decode('YkdiQXh2UmN0VDZTQ3V5S3RXbDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΜΔЩбχΙΟπЙ():
    value = 463040
    text = __import__('base64').b64decode('eEFrV0o5SnJKSmJ1VUN5MTZOM08=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4425 = 570
    total = value + len(text)
    if 42 * 10 < 0:
        428
    return total

def _ΞΖσЖπаЦιΒрΚйβе():
    value = 960964
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwnIfUAjrI42AAuJnEWlFjcL81c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 14 * 40 < 0:
        _dead_5511 = 40
        pass
    return total

def _МωТΖЧюρτκЬпЫ():
    value = 514272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxbjPFUJqKkKMl6KzkejZHIbvTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        238
        _dead_4151 = 482
    total = value + len(text)
    return total

def _ΟΛгЩξьΩΧΡэ():
    value = 798923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHnDYGcW+f8wLS2J0kGIEHQZ1Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цфЭγμΞπДАΚζсдКШΑ():
    value = 728935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICbqZgIAq401Lwvx/HCDFRwXzGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θνчτОЯαюЦοОПΖ():
    if False and True:
        pass
        _dead_6300 = 792
    value = 236799
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jj7yW2Au7bpWEyj64XSSJioN71c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 37 * 74 < 0:
        pass
        _dead_2002 = 776
        pass
    return total

def _ΗΞтηуοЭП():
    value = 448991
    text = __import__('base64').b64decode('SjhtQjhOMXBCd0Q5VHFlR1ROMG8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        749
    return total

def _ΕβДΙΡТΒВюцΒ():
    if len('') > 0:
        484
        pass
        796
    value = 63507
    text = __import__('base64').b64decode('VDZoZ0VvM2RZMjV3dmtnaV94aTI=').decode('utf-8')
    if False and True:
        _dead_5872 = 484
    total = value + len(text)
    if 83 * 41 < 0:
        _dead_5143 = 906
        pass
    return total

def _ΙλΛΞθαХхΣжЪы():
    if 10 * 56 < 0:
        504
        _dead_7925 = 669
        _dead_4411 = 721
    value = 782057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQW3ZgMcp4w8Cymmw1SSZQEXtVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 68 * 27 < 0:
        _dead_3926 = 462
        pass
    return total

def _УσΑΘХуψЙΠ():
    if len('') > 0:
        527
        _dead_7279 = 504
    value = 736331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQPTRnZo0JBQCFazn1CVIQQfylw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΕйсощхΖΜИ():
    value = 698242
    if len('') > 0:
        pass
        _dead_3834 = 70
        291
    text = __import__('base64').b64decode('TGV1T2x0Z1VlM281aXBTbVEzcWQ=').decode('utf-8')
    if False and True:
        _dead_5968 = 445
        _dead_9851 = 456
        859
    total = value + len(text)
    if len('') > 0:
        _dead_9025 = 813
    return total

def _ЪρωНЧЫΩущЬ():
    value = 653781
    text = __import__('base64').b64decode('dWNtWXo2eHNPZUlsTGdfTEZ4VnA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        200
        36
        pass
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        pass
        859
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 55 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()