#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΖщοеΞйΗмТοдΚБΥфД():
    value = 492180
    if False and True:
        pass
        pass
        522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXbnd30u8asrGyj22V+UHxJ5xUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        842
        111
        691
    return total

def _ΧξЗΚфСνΕоπЖХμт():
    if len('') > 0:
        pass
    value = 592265
    text = __import__('base64').b64decode('ekducmxibVBablY3d3hfYlI2YmU=').decode('utf-8')
    total = value + len(text)
    return total

def _фЗЗκΡЧЖК():
    value = 341691
    text = __import__('base64').b64decode('UEtqT3EwVWpXM2dLb3k5TnNaNTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΠΖкθφдςπСξεУ():
    value = 344503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX6yRmduqvkpNT+wmW+6BjQV7V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΨцщПллиаκРιпΤе():
    if False and True:
        _dead_1577 = 691
        _dead_8817 = 821
        pass
    value = 497022
    text = __import__('base64').b64decode('UFpEYUhhZmtCaU5YVmhCbUZ0T2w=').decode('utf-8')
    if len('') > 0:
        379
        _dead_7396 = 403
    total = value + len(text)
    if 20 * 24 < 0:
        413
        pass
        _dead_8487 = 206
    return total

def _ЬТΨδтυюмХΤΝ():
    if 7 * 77 < 0:
        pass
        162
        pass
    value = 511807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kj/3e18s5K9bFyD7kGK3HnJ57ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9181 = 604
        pass
    total = value + len(text)
    return total

def _ЮльσНЙιΓΥэΚАЙ():
    value = 696647
    if False and True:
        _dead_3859 = 32
        pass
    text = __import__('base64').b64decode('TnBRbkFOZXdWNWo4ZW00WFAyTGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ррπμηгλьд():
    value = 419176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXa1WV4P1K4xIgr38F+hESMc8z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣюЩεяЦЫΑЩςνμЫΙΗ():
    value = 997872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MifhOmMYzYRVO1/2m3ScDgk56EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        740
        61
    return total

def _ιъБζОЫЫΡΥБηп():
    value = 931863
    if len('') > 0:
        737
        pass
        pass
    text = __import__('base64').b64decode('UHA2d2JYdTB2M0N0TWhtRkZIQmU=').decode('utf-8')
    if False and True:
        pass
        _dead_6936 = 4
    total = value + len(text)
    if False and True:
        pass
    return total

def _рΣПΓПαγеαриСττВх():
    value = 235470
    if 95 * 19 < 0:
        _dead_7842 = 278
        _dead_4382 = 321
        _dead_9332 = 407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABfcR3cc8vs3EymL43uWOiIb/EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛаΟхΚЛжрППφΓеΕТ():
    if False and True:
        _dead_6151 = 545
        737
        _dead_2963 = 634
    value = 668083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwLuV0ErxvssLle7zWaKYn0/zX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 19 * 46 < 0:
        pass
        761
    return total

def _οднКфЙΡюςяζе():
    if False and True:
        _dead_7477 = 301
        pass
        pass
    value = 877360
    text = __import__('base64').b64decode('QWdUYlFBYlAzQ09LbW5MWWo5Zmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗлмЙΥшΩнВЙ():
    value = 338353
    if False and True:
        _dead_9552 = 422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR3VaXUu/YAlCSeuxGKHMSMCy2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 87 < 0:
        _dead_4608 = 721
    total = value + len(text)
    return total

def _λЙЩΚΕνмеТΗΞΙЭ():
    value = 670357
    if False and True:
        254
    text = __import__('base64').b64decode('T2ZGZUJRSDdVUGhvOFM3M2RacEk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8478 = 795
    return total

def _ЯОЖΚиΝГρθφγцΖ():
    value = 796228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CT3XfAhg5pw6DDax3ViGPgkQ72g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξьΙνШΑγψЩ():
    value = 97259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBfxXVg307g6LgKswk+hDjIl10o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9199 = 282
        _dead_7294 = 869
    total = value + len(text)
    return total

def _γΒωпьτΑЭ():
    value = 715939
    text = __import__('base64').b64decode('SDZQblR5eEJHWjRmSWc5RGRDTDY=').decode('utf-8')
    if len('') > 0:
        942
        pass
    total = value + len(text)
    return total

def _зОΜйеМъАηΕвфθсλъ():
    if False and True:
        _dead_8730 = 173
    value = 402479
    if 39 * 86 < 0:
        812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAvKTXQ/raU1DgKX2HqIMH14w3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑвΟΟЕυвχбЗжηαПη():
    value = 338732
    text = __import__('base64').b64decode('SVNFdDJiTnpNX3RmS0V2dlJNMFY=').decode('utf-8')
    total = value + len(text)
    return total

def _НΡΚТихΩρвιыΣ():
    value = 308291
    text = __import__('base64').b64decode('b2NpWDJZX3JGbVZ3dVZFN1pOclE=').decode('utf-8')
    total = value + len(text)
    return total

def _еучтμЕпФюλЗ():
    if False and True:
        pass
        _dead_3157 = 30
        pass
    value = 802711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FifONmEsrblSAzWA0G7ENiQ9zX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 15 * 79 < 0:
        _dead_4991 = 252
        _dead_7074 = 392
    total = value + len(text)
    return total

def _эΕшТмйλъφλξεЛςΒ():
    if 44 * 53 < 0:
        _dead_4271 = 208
        _dead_9950 = 216
    value = 614177
    text = __import__('base64').b64decode('T2UwYnBMbW1YRDlUSl9KbEhvUVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪεйοьΕнЖηцщι():
    value = 570940
    text = __import__('base64').b64decode('VVo1R1BTanF0dFpIWVB4U0t5eVY=').decode('utf-8')
    total = value + len(text)
    return total

def _цшэζδΡнДтбΘυДпдΓ():
    value = 859904
    if False and True:
        pass
        739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyOzWwIK0/gzO1un4kS1DBN+43Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЬΦЦκнАΙР():
    value = 702906
    text = __import__('base64').b64decode('R1hJaTRXN0pLRFdsb3ZHNXU3ZXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡАπιюУΛΩΣэξπ():
    if len('') > 0:
        0
        pass
    value = 842734
    text = __import__('base64').b64decode('TmQzaWxxOEFuNENwdmRvUVQ3YW0=').decode('utf-8')
    total = value + len(text)
    return total

def _шωбΟУΧЫαν():
    value = 677072
    if len('') > 0:
        pass
        pass
        _dead_6492 = 174
    text = __import__('base64').b64decode('TlcxbUl2UXY0UmYzcW9JODQ5SEY=').decode('utf-8')
    if len('') > 0:
        917
        _dead_4918 = 759
        _dead_8380 = 236
    total = value + len(text)
    return total

def _ΒΓеАЬиыЗеγΓиο():
    if len('') > 0:
        pass
        _dead_2180 = 855
    value = 203556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B37RdgEv6PooOySS3F++HQYo9UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9686 = 298
        393
        pass
    return total

def _йχΛΨΧнФαΚжй():
    value = 894338
    if len('') > 0:
        _dead_2055 = 112
    text = __import__('base64').b64decode('cGtVaGdGbVZDTUpVMEloMUt3MWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝτΜрЕΣьΘыΡлЗъ():
    value = 821399
    text = __import__('base64').b64decode('SzY0STZhSXFrRXNBZGpvcl9sSWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΕκЯВеУдМβзΧξлШ():
    value = 525525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD/UbVos049SYlmv/mmbYwAl6ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нЮЬΙлτδЪΤ():
    value = 15375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyG2a0FuyLJTKSKA3kGcGn0X1W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВПЕШπБΙКуυв():
    value = 394277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSHxaAEoyf0OLAaE0Xu7Ny0c53Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЖςЗΤьТЖЫЫΧ():
    value = 617088
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnboVmghzZE7Dyuy6W6FMCR+20k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1277 = 228
        _dead_5502 = 454
        _dead_6573 = 321
    total = value + len(text)
    return total

def _ψСОΟρχπЛбцДБЕх():
    value = 443380
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx79O24V068BGzig+WXGJjYc8Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        347
        pass
    total = value + len(text)
    return total

def _λвНХфКΧыгщΚгФзЧЩ():
    value = 826434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyW1XXg17Lk3DS2v7lepYBYbyDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒцΣЭνΚΝХОΧСыηξ():
    value = 949162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCbDPFwpqrkaBRr75X2VJgYoyXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7295 = 117
    return total

def _ЦΨΖχисхтΔρкйпι():
    value = 862603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCLQXwcq6KYtajzy22C8PHIgwUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΕонЖьΑУ():
    if False and True:
        973
        pass
        646
    value = 801111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB3CVEE+yf0EaQiIzmm3Bio84Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 73 < 0:
        pass
    total = value + len(text)
    return total

def _ЗΒαдыοζΡСЪΖΩэСдУ():
    if 43 * 62 < 0:
        495
        pass
        _dead_8314 = 127
    value = 669581
    text = __import__('base64').b64decode('Z0R6bkVmTFdwYnkzbDFDT3hfZ3Q=').decode('utf-8')
    if 56 * 12 < 0:
        pass
        190
    total = value + len(text)
    return total

def _ξЮΤюςαχΓψΗ():
    value = 705791
    if False and True:
        _dead_6035 = 808
        _dead_8966 = 59
        288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fjm9dl4WqqQCPgX34gWpOhMV03o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςμНςуяψΖПХЬкΠрΗн():
    value = 261137
    text = __import__('base64').b64decode('YjJKWVRVU1VOY01iZDd1MUNORzA=').decode('utf-8')
    total = value + len(text)
    return total

def _счэснЛБшΙγЕδχ():
    value = 819228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxjvOV0G9fowAlaz22+cbDcj3Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΘвωСΡуЭаφΑхσЦсм():
    if False and True:
        _dead_2660 = 435
        pass
    value = 401739
    text = __import__('base64').b64decode('Tjk0YlFybk5JMGxIaWUxVEt4S2s=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3420 = 286
    return total

def _χεЯЯΖβъΟяГν():
    value = 420061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhfRYEg+6Y8IDDWExkOBJSwK/m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖГиИΚΕЙνМτиФ():
    if len('') > 0:
        pass
        pass
    value = 91259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxiwNggp8rw0aCOcm0ORJgwMzEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 31 < 0:
        367
        _dead_3478 = 838
        806
    total = value + len(text)
    return total

def _нХжЕЭΞЫгбж():
    value = 916768
    text = __import__('base64').b64decode('Y0FHOUV5MmdQbkVRYnpOdG9NY3A=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        788
    return total

def _ЛЗλΙиБΗжйьΑΙΧΧΟХ():
    value = 220614
    text = __import__('base64').b64decode('TTcyc0VPRXRRTDcyMG8zMk5JX1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛбсВЖυБΡГ():
    value = 224913
    text = __import__('base64').b64decode('S013cGVBeHNmeXJhUkNYMndXMmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ιРзγΙΘΡШΧΛШЧдгД():
    value = 648616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyzAewVrwftXFQKa3weDDSsFsD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _уУЙнΖΜГГωкΗΔφ():
    value = 755874
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnzKaGUUzK4MD1q0kVmIHQ46wmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιОΠуАΜнРΗΝЗЗιГЛ():
    value = 257546
    if len('') > 0:
        _dead_5578 = 499
        pass
        pass
    text = __import__('base64').b64decode('bzA4YUlTSXpMQklfM3prXzFBT0I=').decode('utf-8')
    if len('') > 0:
        778
        _dead_9983 = 274
    total = value + len(text)
    return total

def _КГζРСйжП():
    if 41 * 75 < 0:
        719
    value = 891787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhjwWFI98pJXFyGJ2g+XDAkY238='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        761
        899
    total = value + len(text)
    return total

def _ΓθΙΜЕйъТЙоДΧЪЮιЖ():
    value = 752960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dz6zT1NhyLw8DyyFm2bGHwk3tzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γРбщцкεξγЦΔУДΚщξ():
    value = 882015
    text = __import__('base64').b64decode('TEtVY3BmaEY1Q3BZaUV1TUY3YWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ьМЪсЫΖЮдзΡτχοй():
    value = 2129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh3AXngN1fkvAwGTzFqENw4btEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хВСбвЩρГчШ():
    value = 289382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERWyWXUh1o86FQu1znnCDnIj3WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΤЩДаΧЬР():
    value = 422438
    if False and True:
        pass
    text = __import__('base64').b64decode('dU1kX3IzTU5pbVNtMlcwSE5zelE=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ΟншЬΜВЭΠ():
    value = 676405
    text = __import__('base64').b64decode('SG56T3FTYmxmdVA1TDhhU0N5OTA=').decode('utf-8')
    if False and True:
        873
        pass
        650
    total = value + len(text)
    return total

def _υΘпσλтяуΗΩЧ():
    value = 671348
    if len('') > 0:
        _dead_6156 = 648
        _dead_4435 = 664
        14
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzboSng+0YxbHDCGwHunBXQcw0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 48 * 70 < 0:
        196
    total = value + len(text)
    return total

def _йφΥΨΚУΒШνхφуша():
    value = 286121
    text = __import__('base64').b64decode('SUZrUnFHU3NpVjRDMXdYaERQR3g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7402 = 5
        pass
    return total

def _чΜоψждяΓЦкλы():
    value = 30525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj69eHg+7rEOPxab7UPBOx8j1X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЕбΥмχиЯΖξГ():
    value = 69461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ina8bWI77oYZaAO521yzBnYo5Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тπЬνξψχЮ():
    value = 278375
    text = __import__('base64').b64decode('eFJLOGJTWVkza1Q1YWxSYURzWHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΒХМΞУрΝδЛ():
    value = 30473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnqxTHYMp61VCQCT6gbCM3U381k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςНτΗРШγΥθΑ():
    if False and True:
        _dead_2463 = 761
        239
        pass
    value = 681730
    if len('') > 0:
        _dead_8746 = 565
        pass
        769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQPzPVcQ/a8JLxu1/ALHOTEV1Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΨЪΞАΩфχКнΖД():
    value = 985619
    text = __import__('base64').b64decode('SE5tcmxMTTlDTFRnS0ZFYktxYng=').decode('utf-8')
    total = value + len(text)
    if 83 * 72 < 0:
        623
        _dead_7230 = 188
    return total

def _πΛαщшΝχЫΥак():
    value = 886295
    text = __import__('base64').b64decode('aEMwWnFvb2ZUcDhWdDFXaVgxZkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧБуужкПΨеωТСцИΕГ():
    value = 676149
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQHNW3g+3Y4FOQL2x3uiYA4QsEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НаΖоΒσеΘХγΚ():
    value = 404022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDnRQFQN5L8FHRin+3m0M3V74Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _γрРψςЙΜк():
    value = 808416
    text = __import__('base64').b64decode('Y2p5cUswWW1pSVpzSDd1ZkJNTEs=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _βМиΘΚΡμΡяσвπΚКше():
    value = 608206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ7cPkcQx7oUHjW6nEa4ZQYk81k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        748
    total = value + len(text)
    if False and True:
        _dead_4087 = 505
        _dead_8658 = 913
    return total

def _ΝΒикφеэдяБЕфкЗ():
    value = 784103
    text = __import__('base64').b64decode('bklwNjJ1M1dRWFNhSXFCTlFFZkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓацгΦΠШьаτуμΗ():
    value = 36523
    text = __import__('base64').b64decode('cm94dTBiVElyTElwVkNNT2tnZDA=').decode('utf-8')
    total = value + len(text)
    return total

def _лЛδξТηνКЫ():
    if False and True:
        42
        pass
    value = 540697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAPRRlJq8PEKajv142ORIRQF9mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        146
    total = value + len(text)
    return total

def _пΞννсъΨΘΗеσ():
    value = 266791
    text = __import__('base64').b64decode('RU1EamJGSkNadkxRSFBYU3FMbDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ыηЯбЪΠМЭιЙшΣыг():
    value = 531129
    text = __import__('base64').b64decode('cjBCbkZtWTJPUElPbVJYTk10ZXo=').decode('utf-8')
    total = value + len(text)
    return total

def _НΩПεΖяыюΓесη():
    value = 525920
    text = __import__('base64').b64decode('eXpRTVcwSk1NM3Q0VEFPN04wZFA=').decode('utf-8')
    if 91 * 15 < 0:
        _dead_3583 = 389
        496
    total = value + len(text)
    return total

def _ЫаУΗЛЭъсИае():
    if 48 * 100 < 0:
        pass
        _dead_4106 = 159
        835
    value = 684611
    if 96 * 92 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSHvTEI80rgFMQX6mkOWLiEn3Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΑωψμъΣΛУΧгΙ():
    value = 407881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnjceUko8rgCGFeLykS1EzALtEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪдУΚъОκИαЪзιюΙΘΗ():
    value = 122581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3nGbGY81KsuMSL78H+XNQA45zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σбПΑЛЫизПαР():
    value = 556525
    text = __import__('base64').b64decode('TXlzSGxwMnc0TVZReWo0M0FjcDU=').decode('utf-8')
    total = value + len(text)
    return total

def _ВфζΙцΑπН():
    value = 360626
    text = __import__('base64').b64decode('d19FVTMyU09xbk92VEQzSW9PMlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙφПΥНΙЭЕЙΝΖьΛаν():
    value = 721250
    text = __import__('base64').b64decode('eGJENEVKeUt2NzBmQnRRZE1NS0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙηлΑЙЦΗλзУВΧφΑι():
    value = 22266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyXuPEQY0f4pPDmU7wKiCwEl8Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЭνхГГгхЕыυц():
    value = 117736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh/LVAEK0vkbbAKo/1zJPScD8ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АРЫЛΗΛαнλЩь():
    value = 609272
    if len('') > 0:
        _dead_7251 = 181
        _dead_3360 = 43
    text = __import__('base64').b64decode('R3g1WDNOU1BYdmRlbHY3M2NKNGU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4448 = 181
        762
    return total

def _ИЛиΥΡγРΚΨзΧПд():
    value = 371725
    text = __import__('base64').b64decode('THhISnlJYjRWNjU5b2RKdTZKRUE=').decode('utf-8')
    if 28 * 66 < 0:
        188
        pass
        pass
    total = value + len(text)
    return total

def _КтΓСыυφεΝЛθсΠΓμп():
    value = 63200
    text = __import__('base64').b64decode('VWY2RXJXdEFOaUtJYk8yOTc5NVE=').decode('utf-8')
    if 30 * 11 < 0:
        73
        462
    total = value + len(text)
    return total

def _ΛнЩгзθЖΨцее():
    if len('') > 0:
        pass
    value = 771568
    text = __import__('base64').b64decode('VXRnNnVZSTRta3cyTEJBdU1Fd0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛРμыΠчжВФЕνμдмт():
    value = 851733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBjGRXct2PwJERuO+AejPgMA6UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пфμςЮЬξξκЦЯχцХ():
    if 97 * 91 < 0:
        763
    value = 247029
    text = __import__('base64').b64decode('ZnFXaGV5S1ZXWUVOYnIxc29yRkY=').decode('utf-8')
    total = value + len(text)
    return total

def _θяδГωΔСοфΚΞΝχΑπ():
    value = 556274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyCzOnUM54MzFCyH8kajPAsa0zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тФΝсуЗеРλγшДЪ():
    if 63 * 93 < 0:
        pass
        pass
        pass
    value = 848848
    if 41 * 41 < 0:
        688
        _dead_4289 = 718
    text = __import__('base64').b64decode('STlDcVRYSG05ZlMyT2VXSWlFVlk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        20
        152
    return total

def _ΘЩОΝзξЙжεЫШζΤЫ():
    value = 205402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz3qTEcDx6owOyyZznmbDA4EzUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΠΩЕτξкК():
    value = 242396
    if len('') > 0:
        pass
        116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhnuaHIr0YIybly25HiTAT8XsGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 7 < 0:
        27
        211
        pass
    total = value + len(text)
    return total

def _νьхυлРЙθΞдρ():
    value = 724872
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('WndyemkybE9QMmhHNnU4WlhJcmI=').decode('utf-8')
    total = value + len(text)
    return total

def _зцРςεΡεНфΟδЛН():
    value = 35907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxjrSlws8IBWbwb68mW7Ew0/8T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЕνаΕΦиТЬЕы():
    value = 584479
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCb0YVpo07opbSiQm3uXPjUEsVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δδцЭРъзΡьΚψΠФηш():
    value = 729855
    if len('') > 0:
        814
    text = __import__('base64').b64decode('ckdiYXlsT2t6X2kxN2M0dUVaODQ=').decode('utf-8')
    total = value + len(text)
    return total

def _юзζТДβζκмпОΧ():
    value = 590085
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDnqO3Zp94YmCB+B2Q+5GRJ2wn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΝЩцмΙаΧ():
    value = 197401
    text = __import__('base64').b64decode('TFY4WHNSazF1YWhSek5YWl85R3U=').decode('utf-8')
    total = value + len(text)
    return total

def _кэФρΖЮЦΡэлГШзи():
    value = 987462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByvqNlML/aIzLhmgxE+lGhAKwG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΙсΗсОΒθβ():
    value = 897481
    if 93 * 39 < 0:
        pass
        140
    text = __import__('base64').b64decode('UFRmZXFmOEdkcHNqRzRSN3Q1V1U=').decode('utf-8')
    if 49 * 30 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        260
        _dead_2465 = 43
    return total

def _ΟзΨЕωДфТХЩ():
    value = 459703
    text = __import__('base64').b64decode('RU93TVBEWnJONXpkNUFpRGZmX3c=').decode('utf-8')
    total = value + len(text)
    return total

def _еΨМКΦьΟЙЛ():
    value = 945488
    text = __import__('base64').b64decode('YmFqZTZCQTVlOFhDXzlFc2VjQnU=').decode('utf-8')
    total = value + len(text)
    return total

def _иΞΡΛΑОеλψ():
    value = 971430
    text = __import__('base64').b64decode('WFBZZnV6eWJaS184SFpjdmdmVWg=').decode('utf-8')
    total = value + len(text)
    return total

def _θЕΙΔДЦЯΞцшΑМδж():
    value = 339661
    text = __import__('base64').b64decode('V0ZuQUxEWnB2NzY0bmUwTnBzbk0=').decode('utf-8')
    if len('') > 0:
        _dead_7451 = 438
        _dead_3157 = 783
        _dead_2265 = 117
    total = value + len(text)
    if len('') > 0:
        70
    return total

def _ΟуπХЕуωεУιивТчΕл():
    value = 242483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSbIaXkuyZsBGCynzUKVZys5tHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        600
        _dead_4010 = 84
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4786 = 213
        pass
    return total

def _ΞΦπСНЮгЮΩрΥщηΠ():
    value = 78876
    if False and True:
        _dead_7260 = 224
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyDLVEE/94MBbQuC2UKRATQ47Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΜжΖСПнмΙКм():
    value = 534987
    if False and True:
        _dead_5132 = 941
        683
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBewfEEK+pALCxeQzFGzYDx25WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αИμΓκЗДκΩаЧМт():
    value = 312740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXr1bGga3I0HEVac/HyWJzYsxnQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        409
        _dead_1565 = 715
    total = value + len(text)
    return total

def _ΚνςБдНωωКПρБΟΕτΝ():
    value = 964788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgfCTX0w97g2IiOkmnqiCzQO6EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦдΠэΙъиιхСψκЗф():
    value = 150867
    if len('') > 0:
        561
        _dead_6638 = 933
    text = __import__('base64').b64decode('Zkt6TmNxVDBYVUNWQUEzM3RrYW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЩΖрΤχσСцδЖχГ():
    value = 419876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3m3SH0DxrtaDB6l0WSRBxwNzDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΦэДκΘшζαΡуΕαНλ():
    value = 174903
    text = __import__('base64').b64decode('WkRPSkJCYWdpUzFOMU5aTWlJd1U=').decode('utf-8')
    total = value + len(text)
    return total

def _еΚΙΓэЗЙпΚΩΚΔψвИω():
    value = 405059
    text = __import__('base64').b64decode('ck5nQWtZdGdrTHJ2cVZ3ZVRyNEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΛνЬψΞшσУюЩЙβаС():
    value = 248812
    if False and True:
        _dead_4616 = 703
        549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AD3BeFhsq486EDmynFTCbCE2tEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЗБιΜкЮΒΚιТΣυр():
    if len('') > 0:
        599
        _dead_6126 = 473
        190
    value = 812904
    text = __import__('base64').b64decode('RjN0a0VzQmFIZndZM1FCREM3eUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ДБеχущΛцΧнΡпчΧγ():
    if len('') > 0:
        pass
    value = 809303
    if len('') > 0:
        _dead_1969 = 780
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSDLQX4+9IUnbzyU3lKJLTEM1zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 28 * 98 < 0:
        _dead_5218 = 559
        24
    return total

def _аЬжДбЕОΩТ():
    value = 217201
    text = __import__('base64').b64decode('UmlWQTBrd1RaTm5aRXZXN3h4TnA=').decode('utf-8')
    if 43 * 43 < 0:
        260
        885
    total = value + len(text)
    if len('') > 0:
        414
        586
    return total

def _ΣхЙΤκюмЬТУβАБ():
    value = 469206
    text = __import__('base64').b64decode('b0twMUxHSnhuX0xqd2Rnc1dxSng=').decode('utf-8')
    total = value + len(text)
    return total

def _РЮтΠбμАбυ():
    value = 981842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC7RV1du2KZQGAaI33/HGHJ8/Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΠОцТыΝЭВуЖИСз():
    value = 636736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSbVaGc/pokkNxu08nmpOXQ59zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΝШжΝΗβХΨЧАПЯ():
    value = 94607
    text = __import__('base64').b64decode('UE8wMjRhdXY0MEtPQmV2bnBqZTc=').decode('utf-8')
    if 84 * 24 < 0:
        670
        _dead_4356 = 672
    total = value + len(text)
    return total

def _υΗμυρЮΦА():
    value = 273924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDv9PkNt2b4NI1ag0gDJFQAKy18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВрпξςτАГΛηΖОηЖюх():
    value = 851323
    text = __import__('base64').b64decode('aUxTc2ZFSEVpbE1JVFgzY3UzVmo=').decode('utf-8')
    if False and True:
        787
    total = value + len(text)
    if False and True:
        pass
        _dead_9292 = 924
    return total

def _РьРΖРюЕΛΛК():
    value = 507843
    text = __import__('base64').b64decode('Tno3eUw2YW1ERVBaSzBlN0hZZ2M=').decode('utf-8')
    total = value + len(text)
    return total

def _мЙПΚΖаξхΠКΝТΜьΜ():
    value = 380103
    text = __import__('base64').b64decode('dVVCTDZpMGxLcTFvSUlzaFpKc2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒИрерπΧΒЖТ():
    if len('') > 0:
        994
    value = 646788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwPtUXUO2/kPPCyqmGKqIDwH4Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞпφΜδЖЭббМξΗ():
    value = 327328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXexa1Nu9Y4bN1mHxm+fHRF4x2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙκΨУПιЫяыуο():
    if 21 * 58 < 0:
        773
        _dead_3444 = 638
    value = 718330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITjWagJszfAbFiKEwG+HGR0W6F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РнτЭБФюΓΖ():
    value = 37218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBn3dnUqpvEgAAeAxFiZLgMK5T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        563
    total = value + len(text)
    return total

def _ЙшεДРΖрιΣр():
    value = 673896
    text = __import__('base64').b64decode('djBtNkxsSDlNQ21rUDZxRDFDdnU=').decode('utf-8')
    total = value + len(text)
    return total

def _вмЖΙΠХЙЕвЪМΖИР():
    value = 480633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISboYmBo3Y8TKgKUwGe5DQElwjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΞбψΓΠЕШοθуΖπφ():
    value = 536379
    if len('') > 0:
        _dead_4608 = 591
        _dead_9175 = 372
        _dead_6381 = 415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB/VSVc3yak7aDz3+0DGGjUszTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 64 * 16 < 0:
        728
    total = value + len(text)
    return total

def _υЩГαμКωκΘΕЮЙФπВу():
    value = 923367
    if False and True:
        pass
    text = __import__('base64').b64decode('WnV3YXo2OW1oS3dHMFVuU1F1cDk=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _УфИЖхХаΓр():
    value = 769867
    text = __import__('base64').b64decode('Rk9LeHpWNWFpSXdoZk9vc00yOW0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        68
    return total

def _ρрЭГЪНпЙЙ():
    value = 268285
    text = __import__('base64').b64decode('Vkg0UHNESjVlM2lvQTNaanNyZ3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΟηΨΞΚрЦьεзтеИГе():
    value = 947898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw7LOmUpx788Liez0GCDNQEZ70E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        98
        pass
        699
    total = value + len(text)
    if False and True:
        74
        pass
    return total

def _χЕΛХгΟХΖΚЛΝΗцβ():
    value = 538296
    text = __import__('base64').b64decode('WTlVbmpFbXNVNlVvYUd3YTBEa3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ВнξΓНθπУоΙ():
    if len('') > 0:
        pass
    value = 927958
    text = __import__('base64').b64decode('ZXB0TlRoSjloam5yOEsxUU5vSlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΓВДΖηЮΛуε():
    if False and True:
        355
        pass
        _dead_4687 = 822
    value = 463627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ei7oemBg+vBbayGZ5VGbGQ8q8Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΒΣΛΔοΥяβУыη():
    value = 910932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETfyUVM6xvkJBV2rwASmGH0K1HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωгйЯДШгЕМвσΓ():
    value = 474452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT3XQ3Yt5KQ1Lzf3kAXJYHM/6n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЕцΗΧбЖАккхλΩβ():
    value = 669930
    if len('') > 0:
        726
        _dead_3387 = 21
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DA7yawUQ36lWaQer4265HxUY9j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6386 = 173
    total = value + len(text)
    if False and True:
        _dead_5291 = 425
        pass
    return total

def _ОпσФηешЖШчщгрκΘ():
    value = 86169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT7RWmlt2JkpNCyU+HeJJA4e5lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΧыМПТμХРηд():
    value = 121673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kg3dZ3kK7Plbax+Z4wOaPDI69j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        777
        pass
        899
    total = value + len(text)
    return total

def _ΝηллцχΡΤэЦψЬч():
    value = 497973
    text = __import__('base64').b64decode('TWhoUUxlR2duWDkyUGRnSGg0MEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ρеΝЫδΦυщбδъфιМΘ():
    value = 947820
    text = __import__('base64').b64decode('eng1Y1Fjd3c0eHJEY2psMjZHbTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΟξхτπΙαКфюЬΟ():
    value = 677590
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx7Jd1g876YKIwmckA+RPw8MwHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9023 = 44
    total = value + len(text)
    if 82 * 34 < 0:
        864
        pass
    return total

def _ριΙΓкИΖЬχвк():
    value = 338254
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MC33akNh6P8UD136zW6CPTwgxmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щбΨλκшВρλЗ():
    value = 729449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah7AfwYP5JE8IBa75GaTGi8s8Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬюομвυвδΨΞψЧчΗ():
    if False and True:
        _dead_1586 = 703
        pass
        pass
    value = 129305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih/+YUg97LoFGAW5w0KpBxp97j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 87 * 63 < 0:
        127
        pass
    total = value + len(text)
    return total

def _ьШвοЪЧЦлошяЪνМΦ():
    value = 565544
    text = __import__('base64').b64decode('V2lzQkpuVXhtUjZ3cWRveTFqQ1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝОЩЛМΛЭыПЪч():
    value = 810394
    text = __import__('base64').b64decode('d0RJbk41V3QwQ1FObkdhUHR1blo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗжЩшхΜУζ():
    value = 159919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQbuYUtrx5gsNFy3xlqWERd40Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СпΟτаЙЗЦΡиνιхнΥ():
    value = 288168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px28SgkYyf8wPSuU/We3MSAuwFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5842 = 195
        _dead_7413 = 571
        276
    total = value + len(text)
    return total

def _ΕωКςΠЬюЖДц():
    value = 956566
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCjIYXs2+JkGPyGm61qHG3UCtj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еЬтюκΔΧξ():
    if len('') > 0:
        pass
    value = 330932
    if 43 * 40 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHnbZ38U5/gSNj6o8Qe1MCoK6V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чШΖξΗщАοЬΧЖИνщΞО():
    if 51 * 48 < 0:
        496
        410
    value = 593999
    text = __import__('base64').b64decode('QngwM0hycEYyTk1tcDl1N0NmenY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        426
    return total

def _ΔΖУεыΒшοθцрιк():
    value = 420131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh/hUV841pgbNDqq42SkMBcr/UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖпыБыΞЪд():
    value = 479041
    text = __import__('base64').b64decode('d1R4QkFDQ1BETExyb29jaHM3aWU=').decode('utf-8')
    total = value + len(text)
    return total

def _шΒξΓδΤхе():
    if 26 * 63 < 0:
        _dead_3302 = 600
    value = 210565
    text = __import__('base64').b64decode('WWl1MjVVTkNHaTdjRTJRUG9ycjY=').decode('utf-8')
    total = value + len(text)
    return total

def _χЧιΛαЬнδэясЙчΠх():
    value = 534579
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyXdS1hu5KUgIgaT3QO/DjQ7/kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2419 = 40
        _dead_8739 = 863
        pass
    return total

def _УгΠчχΡиΗслΟпЩиΚщ():
    if 2 * 36 < 0:
        pass
        _dead_8593 = 194
        357
    value = 720641
    if False and True:
        _dead_2831 = 33
    text = __import__('base64').b64decode('a3lRMW16Mm5lYjF2UUpLMzNYTjk=').decode('utf-8')
    if len('') > 0:
        644
        pass
        585
    total = value + len(text)
    return total

def _ΓτΥΚЖЧПωЩЭЮΨПπα():
    value = 640689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARfjRkEIx6sSHDyiw26FJCA6xXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВβТцмвπЦδεЗЗ():
    value = 503862
    if 79 * 10 < 0:
        812
        pass
    text = __import__('base64').b64decode('aGZjdGdNMXZ6Ymkyc2w3SHJDTk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('IA==').decode('utf-8'))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()