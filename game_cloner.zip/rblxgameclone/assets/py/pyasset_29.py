#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _зъкФχылУЛΠэЩν():
    value = 695591
    if False and True:
        _dead_7987 = 122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCLxRkAP35AUC1+G8GymOCx7tmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        599
        782
        _dead_9064 = 687
    return total

def _κΕΝМΡЬςнΒаηΗшИУ():
    value = 277850
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRDFRHo19oBVCF/x42K3PgkO4Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χЙчйЭВΤγμΒэΕψй():
    value = 156737
    if False and True:
        656
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzvAekNs7ooQDQyJkWKqHww6/EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        870
        _dead_4396 = 969
    total = value + len(text)
    return total

def _ΠАНΨтΓЛшБсΤρυθΡг():
    if 77 * 4 < 0:
        pass
        _dead_2655 = 439
    value = 316206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCbte0gu/Y42DF2b5leYOxYu12g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 18 * 10 < 0:
        _dead_3355 = 378
        604
    total = value + len(text)
    return total

def _мφφΡеζюφ():
    value = 914540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCHlUQcw5IYgPlj7nUa5ATIo6Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 41 < 0:
        979
        _dead_7065 = 305
        _dead_2982 = 169
    total = value + len(text)
    return total

def _ЬпΚΕмχςоПΞХ():
    value = 711606
    text = __import__('base64').b64decode('Q1pJeVdzU2t0SHVvSkdMODZjdDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚπХдδЪвΓΒпХчвБЕΡ():
    value = 684872
    text = __import__('base64').b64decode('RlViX2FVczdBVTJidVZma1FXRXo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3430 = 489
        _dead_8643 = 263
        497
    return total

def _ЮηЗпЭююЫΞХЮ():
    if len('') > 0:
        pass
        _dead_3682 = 243
    value = 475612
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXzxO3Ap7IEsLlb0ngS3ZQoq9ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΒщмςΓφнЧвΩЛДδ():
    if False and True:
        _dead_1277 = 949
        _dead_3586 = 784
        _dead_4413 = 806
    value = 898230
    text = __import__('base64').b64decode('WTlKeGE1NnQ2cFc1VjNGSmFjeWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫнШгωЫэжДыЧДΟП():
    value = 32997
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy7eZVA60PoiPiD15weUDDAcwDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΦТЛПΟСРцΘΙйГйР():
    value = 39134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCzhd0Mzwa8lAy2s8GaAIwgft2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 39 * 100 < 0:
        pass
        pass
        _dead_8017 = 796
    return total

def _ЦкζδΜЖьВ():
    value = 92185
    text = __import__('base64').b64decode('SXEzNHFJTFBwc19xMzdsU3dGSTc=').decode('utf-8')
    total = value + len(text)
    return total

def _СюκκЪюИУп():
    value = 899361
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3j9Q3Y8qv45LRyI/k60HTw1s3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βΟΝξмЩηΞΔЖ():
    value = 242772
    text = __import__('base64').b64decode('T1B0MHFaNVB3Y0ZxaDNkNXIwNGE=').decode('utf-8')
    if False and True:
        802
        _dead_7076 = 423
        pass
    total = value + len(text)
    return total

def _кЧΗβЖЫыΡчяПΩгИ():
    value = 537411
    if len('') > 0:
        _dead_2985 = 885
    text = __import__('base64').b64decode('eVN3MTZrRkhuV0I2UmQ2cDNCdU0=').decode('utf-8')
    total = value + len(text)
    return total

def _θφβУЙЭеΔΣ():
    value = 846859
    text = __import__('base64').b64decode('b3k1S1dKZXZ2elNJdVF1b0hiN1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΧηΤΔΥЖπ():
    value = 857124
    text = __import__('base64').b64decode('R3pPdWtPZ2U3SVJJVXNmZVFxM24=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙθΛРдСщΓЗЖ():
    value = 961123
    text = __import__('base64').b64decode('Z1VSbktIWE9Zck1KRjl0eVhqSk0=').decode('utf-8')
    total = value + len(text)
    if 1 * 5 < 0:
        342
    return total

def _ξЪуТбκЙωσ():
    value = 565696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSfsfXwI1Js1CSqbzV6cAjAn018='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        945
    total = value + len(text)
    return total

def _ΤЙψΑяΖфЭзПиХЫм():
    if len('') > 0:
        pass
    value = 778379
    if False and True:
        418
        417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzX9W1sX6vgQK1y07VSaNnx9yWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 53 * 6 < 0:
        pass
    total = value + len(text)
    if 14 * 65 < 0:
        _dead_4450 = 335
        733
    return total

def _ηЗςвЯфПЬЮБоОгχгш():
    value = 499558
    if len('') > 0:
        771
        63
    text = __import__('base64').b64decode('YjJzc1RvWkxta1MwZTVscU9XdF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ХаМбеνλзυиμεΚй():
    value = 607064
    text = __import__('base64').b64decode('TnBNT3RDdU41djVUQTFRRmp6SG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ХкХυУГιΣ():
    value = 629950
    text = __import__('base64').b64decode('dkhla2loMjJuZFo4cEJhazIyM0I=').decode('utf-8')
    total = value + len(text)
    return total

def _γΥУвккШδΕ():
    value = 991592
    if 44 * 68 < 0:
        752
        _dead_5205 = 673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH/DWgUG0PAaOS2cz2mFJDwVsk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒчιйцΧΟεωНХΖОТΤы():
    if False and True:
        _dead_3946 = 125
    value = 248739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXrmWn1u0KsrHBuC+FfFFi8Hy1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сПЯιΤСΠХХоУ():
    if len('') > 0:
        _dead_9217 = 919
        pass
        496
    value = 893812
    text = __import__('base64').b64decode('bzZwTUlrazNCOFI3ZHhiTUQ1dFo=').decode('utf-8')
    total = value + len(text)
    return total

def _υЗЬδвΙЩΔГш():
    value = 626969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bjv3SUk+qf0QaB+p7HeFDRYp8j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыβецθЦДσжыЯиъ():
    value = 60212
    text = __import__('base64').b64decode('dXBQNXAyZ1dxS0VON3R0UzF5d1U=').decode('utf-8')
    total = value + len(text)
    return total

def _тЕъЮΦЭЩΚσ():
    value = 335320
    text = __import__('base64').b64decode('ZXhHV3lFQ2ZQQmJsZm5uZlM1MWI=').decode('utf-8')
    total = value + len(text)
    return total

def _φΑΓРИеХβθΩвηЖЛΘ():
    value = 141691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDzARUY6/awkLBiN52WqAjMo4nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩβЕχСыгЧЦзЙщжс():
    if 53 * 100 < 0:
        325
        _dead_3892 = 64
        pass
    value = 205623
    if False and True:
        950
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQbyPF1up5whLSWn8FuqGTELvHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ιΚρΩΙΣΧД():
    value = 336747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiDFWgkh/JkGbQe3n1SVZQ466kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦωУТЦφфΨΨφа():
    value = 872550
    text = __import__('base64').b64decode('U2F5S19nTzJfY0YwS3hSbGY1b28=').decode('utf-8')
    total = value + len(text)
    if 25 * 43 < 0:
        319
        pass
        853
    return total

def _ςψΒОΝδеыδпыχгγЧ():
    value = 510543
    text = __import__('base64').b64decode('WUN2OE8xcEoyN0FMSERYMlFYTE8=').decode('utf-8')
    if False and True:
        699
        678
        _dead_7954 = 6
    total = value + len(text)
    return total

def _ψдΣΤъσΧФΨШПйλη():
    value = 452296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyOwVFkU54EOCyKMnXCnLiwr5ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МхΞмгэМγΔыюλкλВ():
    value = 382661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwLISGEqqYorGBXynnebMXAq8Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟчЧνРΦλκПо():
    if 29 * 20 < 0:
        pass
    value = 237123
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCreQXc/xL8rIAKC/X6yECo5zWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 88 * 78 < 0:
        _dead_4602 = 347
        _dead_9027 = 204
        pass
    return total

def _ОχюцΠκЛьσЖνΔлфФΙ():
    value = 673725
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSXnQ3AQzqBUGR2kn1qgEwcMsEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аИГОβΑΓЧ():
    value = 449397
    text = __import__('base64').b64decode('dXl3ajVSUVRsZkFPdWhfTG00WUU=').decode('utf-8')
    total = value + len(text)
    if 54 * 39 < 0:
        128
    return total

def _υΟмυпνΙΝ():
    value = 84303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwvmN0YV+vAEbzag4mCEJTYe1F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 72 < 0:
        470
        pass
    total = value + len(text)
    return total

def _συςΑиКεОюΘ():
    value = 61089
    text = __import__('base64').b64decode('T01QcGdUMkF4YXRNR2NWbzAyWm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ИχΟЬбОαΑкΤЬРΙс():
    value = 914914
    text = __import__('base64').b64decode('YzVtSnFvNUxldzEwWWRUa3ZlYUY=').decode('utf-8')
    total = value + len(text)
    return total

def _йьЮычйхΘМвσςЫрΜ():
    value = 494473
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg63bF0cypwBDymA+w6fHj0uwj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3833 = 669
    total = value + len(text)
    return total

def _ВΧΝωдЕКβΡмωΠЫκн():
    value = 785073
    if len('') > 0:
        _dead_8222 = 25
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQzPTQQR/4oXEzm5/F+8YAcl42o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        308
        312
    return total

def _МΡγЙΧКΠЭюΠу():
    if False and True:
        pass
        pass
        _dead_2605 = 50
    value = 765386
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjjBRgI98fknFQOC7mCcLQ8X9mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1299 = 474
        _dead_3888 = 647
    total = value + len(text)
    return total

def _ьαμЭΙЬОτ():
    if False and True:
        _dead_6742 = 305
        _dead_9115 = 938
    value = 329261
    if len('') > 0:
        pass
        874
        326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHzUal0b87kWMzyQ+26COiIb6jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хαсЩтПйφпλμΒН():
    value = 100487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSjOVlNv5IMxKVyQ5A6mYiIBvHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υςуМφнΧΓ():
    value = 985747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhzpNgYz7KoQLVay6l24PjUh/kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4904 = 101
    return total

def _БхиΙУЧΕΦНΚрфЗ():
    value = 147094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERz3WX4K5vFXK1in3VWiZCJ36lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жηЮЙΜСфуυι():
    value = 676904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgDiYGcK5ppUPimiw06KMCY6t0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        766
    return total

def _оыΨοЛЗЭщΕΔуЭг():
    value = 337339
    text = __import__('base64').b64decode('Y3dJVVVERU96bzlCQVVUX3pmTUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ςβυτЛэχМ():
    value = 315363
    text = __import__('base64').b64decode('TE1vVkdUSXltWUhXTzR1a0ppVzI=').decode('utf-8')
    total = value + len(text)
    return total

def _кЩдλΘзЛчΒο():
    if 63 * 18 < 0:
        pass
    value = 178483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3rif3ss2PsqEQWb4kzGGyI60lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4959 = 760
        555
        _dead_2098 = 700
    total = value + len(text)
    return total

def _ΠхЙΑρХОΠвОΞеШΗф():
    value = 454648
    text = __import__('base64').b64decode('ek5MeU9rUnE0aXNnbURPaE5PTk4=').decode('utf-8')
    if 41 * 98 < 0:
        91
        129
    total = value + len(text)
    return total

def _υЪГСΠΨмκШЯφЦ():
    value = 21377
    if 78 * 56 < 0:
        48
        _dead_7824 = 894
    text = __import__('base64').b64decode('YTZLTE9ZbW5waHlEWHFKcm56VWU=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_5847 = 722
    total = value + len(text)
    return total

def _ΤсΚγыξвθфГεКщςΕβ():
    if False and True:
        _dead_2921 = 454
    value = 811497
    if False and True:
        444
        963
        955
    text = __import__('base64').b64decode('RTJxMkRwNnBfZVBSTDZjbFV1Y1k=').decode('utf-8')
    if len('') > 0:
        623
        22
        _dead_1294 = 640
    total = value + len(text)
    return total

def _ΓцЭкΩГМэЭНЩХοЖ():
    value = 762877
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQDRXHQ79akpKzyl+1eJFTEVwko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2513 = 254
        945
    return total

def _ЭкшΝччθляΒεдςΗТ():
    value = 607787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHjVY1s82r8TABv24nOBOi4+6j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦЙΔдсθЕςςοОИ():
    value = 599439
    if len('') > 0:
        _dead_9017 = 273
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dw3oTAU2/6EXEx6p6lOeIBAaw20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΚυκδАщЬΞ():
    value = 218728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACbAfFw757hWH1iq3FeyHg4kyDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕеΗΒζκιчδб():
    value = 624298
    text = __import__('base64').b64decode('ZzJkZHB6dHdoVWQxNVRrRmx1RjY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        397
        _dead_8181 = 639
        889
    return total

def _НуфуιъГЕК():
    value = 946080
    if 40 * 67 < 0:
        281
        649
        437
    text = __import__('base64').b64decode('bmJPZlp1Zjd2TnZQeEE4a1FiWFo=').decode('utf-8')
    if 59 * 62 < 0:
        958
        _dead_6823 = 756
        549
    total = value + len(text)
    if len('') > 0:
        984
        pass
    return total

def _πсΜОγЮХбω():
    value = 490307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSXJbGUU/6IiKyexnFWROzMkyFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πчΘΛΡΑЮПВ():
    value = 349104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C37pbHcN5LhVazy733WgBRA643w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_2535 = 456
        _dead_8863 = 499
    return total

def _ΣхΕЕЭΒПΦыιΧθ():
    value = 833784
    text = __import__('base64').b64decode('TEdOcURIM1JScmdYQ2NFQUxUYXM=').decode('utf-8')
    if len('') > 0:
        _dead_4632 = 864
    total = value + len(text)
    return total

def _ρΥххцΠΩЙ():
    value = 758934
    if False and True:
        _dead_7932 = 481
        389
        110
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj/KbEc+86MBDC6V70zJYzYIxVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЕαЫЧхЙЫ():
    value = 171726
    if 71 * 78 < 0:
        _dead_7697 = 510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jya9ekNsrYAiExmX21GnJQAMt1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4278 = 42
        pass
    return total

def _сСъΚХзЙΤнкМжу():
    value = 773447
    text = __import__('base64').b64decode('VXcxWWRiMzczcVNLajhwN3VNeFI=').decode('utf-8')
    total = value + len(text)
    return total

def _γЪψιЗΟφдΛ():
    if len('') > 0:
        935
        _dead_4385 = 834
        _dead_2222 = 732
    value = 920193
    if False and True:
        431
        pass
    text = __import__('base64').b64decode('SHByZFNRSGtrSzg3dzFpUlV2SjM=').decode('utf-8')
    total = value + len(text)
    return total

def _φчΙφΟσΜлиЖОΠπпфЦ():
    if 84 * 50 < 0:
        _dead_3948 = 278
    value = 189238
    if 65 * 10 < 0:
        pass
        pass
        _dead_4938 = 729
    text = __import__('base64').b64decode('VUdrNWJfbmRNTlRnUUhta09VbmM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        749
    return total

def _ΜΠТξλвΗыш():
    value = 975210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgjnTEke1boAMR2EwAG1NzQhwUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        20
        _dead_7589 = 424
        603
    total = value + len(text)
    return total

def _ωпоκФξЭвбцШуиж():
    value = 357603
    text = __import__('base64').b64decode('bnZ3ZmFNcWdmTlhxdVhPRE9BSUQ=').decode('utf-8')
    if False and True:
        159
    total = value + len(text)
    return total

def _υцξАзΘШИΕλζΔχЭШΒ():
    value = 415073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQXwZloPq5csCCCB436aBw8twDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠЙшьйьЬИγΖхΠΥюΧ():
    value = 753007
    text = __import__('base64').b64decode('YkFGNlpteEZtRUEwUUlncUVET2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨКοФГπχЭΟ():
    value = 648876
    if 44 * 71 < 0:
        _dead_6069 = 697
        pass
    text = __import__('base64').b64decode('c2R1R3lGOUtZcU1ZVTBUNG1xYnk=').decode('utf-8')
    total = value + len(text)
    return total

def _οЭккτгΞμχ():
    value = 521976
    if 84 * 98 < 0:
        585
        _dead_9556 = 650
    text = __import__('base64').b64decode('dFVsN292cFFPN09GSUdCUGI5UVU=').decode('utf-8')
    total = value + len(text)
    return total

def _νгυΧицΦЬλНлСЙ():
    if False and True:
        496
        _dead_2623 = 206
    value = 23255
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dja0TWU7zf4BDiqMnWzFOg129Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_8699 = 714
        _dead_7493 = 745
    return total

def _ТАΒαΗЯΒΑμИйμΗУрζ():
    value = 971542
    text = __import__('base64').b64decode('Z2o5aWpNNG5JejBQVmpsSmRLQXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩγЖΕЕβБμЖфЩπыΑсΥ():
    if len('') > 0:
        pass
    value = 772102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRXoSwg02pkNbCKTwW6zBxJ+t1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΛвъяπΞа():
    value = 483765
    text = __import__('base64').b64decode('RkhXaTNoSjBFUmFUMnlXR2N4NzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪЪεтξИтсΧΛ():
    value = 34880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhXPXXMRzIMHaQ2qxFW0YgY7/nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χсвюЮТШфюэКΛЪ():
    value = 335862
    text = __import__('base64').b64decode('d1RBRDJqdl93VmVBQWlWVDAxcFU=').decode('utf-8')
    total = value + len(text)
    if 20 * 80 < 0:
        656
        31
        8
    return total

def _фςδщФΟЩζβЛзЙжА():
    value = 456457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAPtaGI21YswEwXw7EeRLAo58Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        134
        pass
        595
    return total

def _δεАзкλρьеΓрЧΟΣ():
    value = 191419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxDFT3wNrZIvHFfx7WW4PS0Z0Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _иΜТцλδΧξΨχΒ():
    value = 614421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQ7cW0Qy+aUCIzqi23iDYnw1ymQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗуэκΙΜνΥфΟΣтГЩΔи():
    value = 854567
    text = __import__('base64').b64decode('VGJyX1NWaUFYZnVZNDJSSHJWc0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝУЕЕЩяУЮьц():
    value = 82663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAvge1oq8r4NaD6Q/1XFbSwBy1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧЬΦΦβТζΞηΛΔπαЩνε():
    value = 18957
    text = __import__('base64').b64decode('ZDBPWFJCcEZTQzJwMDh4dkdZQlI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7926 = 758
        565
    return total

def _СТяΟЪμдьЛЩеэΠρжΚ():
    value = 541663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzniYEID5qYhLxWPx0aHIyIm9j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΡлаЖНБκ():
    if False and True:
        205
        pass
    value = 22295
    if 81 * 91 < 0:
        331
        690
        _dead_4413 = 750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgLjXnoN36BWPwWr0GbJFwx6vGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 94 < 0:
        130
        658
        _dead_8108 = 345
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _чаΡБΓΡгОЭΕКДΞ():
    value = 537769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH7HTQBsrYEoDSai2lyJEnwlsXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηоочЫЦρβΑΑМζ():
    if False and True:
        435
        pass
    value = 967451
    text = __import__('base64').b64decode('S0FiZVQxR1RoOE1HV0RDSUdkTUU=').decode('utf-8')
    total = value + len(text)
    return total

def _οΧЦТДПΩααнΗΚΥΓв():
    value = 719462
    if False and True:
        529
        _dead_2542 = 657
        pass
    text = __import__('base64').b64decode('WjRMb0g5ejhiRWhSSTE1dDk3Vlo=').decode('utf-8')
    total = value + len(text)
    if 92 * 28 < 0:
        716
        pass
    return total

def _ΔςъЫξюЬЮ():
    value = 189856
    text = __import__('base64').b64decode('VEtCRHB2amxxOENrOTRLV1ZJVjg=').decode('utf-8')
    total = value + len(text)
    if 58 * 78 < 0:
        869
    return total

def _ΜЦсЧΑΚΩу():
    if 10 * 7 < 0:
        pass
    value = 333314
    if False and True:
        721
        _dead_4790 = 35
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRvbPnwJqLkoMwWtxgCcBHYr0Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_4788 = 758
        pass
    return total

def _ψςςФσеИСыУЯдШ():
    value = 531483
    text = __import__('base64').b64decode('ZmF5YXpremlYZzhSenFnQ09jRWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _гыυςжЩςΩаΓτΣЪ():
    value = 905279
    text = __import__('base64').b64decode('bjVuS1lTUXpUR2kwbElZMEJsTlU=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ωуΥдоьЧШΒпφб():
    value = 542041
    if 82 * 64 < 0:
        _dead_2403 = 315
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR+2RVIMp/wAPD6qzgPCPywV1Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4548 = 184
        949
    total = value + len(text)
    return total

def _АпбцΑоеСИςщпξ():
    value = 40974
    text = __import__('base64').b64decode('QXRDUnBOTnM1NGhLb1VwRjVaV18=').decode('utf-8')
    if 56 * 44 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЬМΒЧΗΚΥЗΟмΒΨтΨ():
    if len('') > 0:
        _dead_6927 = 338
        pass
    value = 282637
    if len('') > 0:
        679
        pass
        727
    text = __import__('base64').b64decode('SEZMd1NRRFhRYVFUVFVJRDVCRGI=').decode('utf-8')
    if False and True:
        _dead_2791 = 862
        _dead_6883 = 669
    total = value + len(text)
    if 25 * 1 < 0:
        pass
    return total

def _иеΤмтчΠκЙфαΓ():
    value = 70535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgnbbX8Kz/8MEQeingCpYxE54Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 40 * 14 < 0:
        _dead_8415 = 531
        pass
        556
    return total

def _ΣΤЛрΣЛЗбΝЩь():
    value = 836881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAnGf2sIzYkoLgmQ/Xi1MXUEskE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΟЗЬДщСХΥωеь():
    if False and True:
        pass
        621
        pass
    value = 623344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRnpW0Qxy60MLRf26liiGBUYsjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВδщηИОΘΠζ():
    value = 224206
    text = __import__('base64').b64decode('Uk12Q1FFelhGRF82M3RkdzlETzQ=').decode('utf-8')
    total = value + len(text)
    if 52 * 85 < 0:
        776
        _dead_8017 = 698
    return total

def _ДълИΙНКκскВждя():
    value = 930533
    text = __import__('base64').b64decode('TzZrQ0JMSlBfa005MzNKWkxySmU=').decode('utf-8')
    total = value + len(text)
    return total

def _δτνθΝβΓΞ():
    if len('') > 0:
        _dead_6432 = 256
    value = 219635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAPMf2Uuzq0ZGz62y3uhZDEBt1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΔХкжΤсΗΙиΧΤ():
    value = 628157
    text = __import__('base64').b64decode('QXU4dlFEVVd0NEZPZDdNMlBrdjg=').decode('utf-8')
    total = value + len(text)
    return total

def _СуЦВЦоδнуГЧ():
    value = 503458
    text = __import__('base64').b64decode('RVc3RE9mTEN2WG45MVBCMzBEWF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ζЖΞФбφЮлРсдξτ():
    value = 449176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBD1SVYJyPA7MQKZ0kKmZi0q4jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фчвιвУιоФЫкФΨ():
    if False and True:
        _dead_3921 = 153
    value = 687713
    if len('') > 0:
        813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwexNl0RzKoiIC6N7wa7Nyd/7zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6866 = 777
    total = value + len(text)
    if 49 * 81 < 0:
        369
        666
    return total

def _υыуЖУξиаΣΨоΡΩ():
    value = 762664
    text = __import__('base64').b64decode('SFFVSnliOUJaZk9vbUVVT3lFMEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΚЗТДιΕЕюπφВШзжΝ():
    value = 545068
    text = __import__('base64').b64decode('aDc2WWVIYUgzNHBGWFR2WENlVDE=').decode('utf-8')
    total = value + len(text)
    return total

def _βДГωБχъщ():
    value = 300435
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAfMPgIKyJs1PxWv7HCfBRI8zXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧСюξзХζчЧβΠ():
    value = 898303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBq3XmILzoVQDiyl8AenZ3Ij8kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мωцАЯρГъ():
    value = 703207
    if 74 * 45 < 0:
        _dead_1856 = 133
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg3QQFYayaw6BST76kK7IRotyjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νИтμηΛОЫхΨЗ():
    if len('') > 0:
        155
        pass
    value = 171140
    if len('') > 0:
        _dead_1832 = 443
        _dead_9997 = 871
    text = __import__('base64').b64decode('UXZuRU41d0ZCNUhJNlpDX0M3NnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЯдАпъΑηЯ():
    value = 622440
    if False and True:
        pass
        pass
        _dead_6269 = 8
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiSwNn0O97guOyKCwwe6GDMfwmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΤΠпМΛччэ():
    value = 443312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID/BaWMrxJcrMheW7FCcPxQt9Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зεξСтεΓНЪЯηыΓ():
    value = 110462
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACzte1A47oQhCwuvx3WDDi573GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 90 < 0:
        pass
    total = value + len(text)
    return total

def _ЦΩОςЫΔдΦΩγУпрςΠй():
    value = 101167
    text = __import__('base64').b64decode('cTFtS3JkaGlNUTFYeFA2X2duTFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΟκЙъыΨелλБЬΦ():
    value = 999270
    text = __import__('base64').b64decode('RG91WUxUSk9XVjR1b01COHNzRGg=').decode('utf-8')
    if False and True:
        577
    total = value + len(text)
    return total

def _ХэΛΖЗχЦΖйχПΠμ():
    value = 155197
    text = __import__('base64').b64decode('d0dhSWdWeVpNbDhEc2F6R09QTlI=').decode('utf-8')
    total = value + len(text)
    return total

def _КеξуρκδασщΥΦщ():
    value = 410315
    text = __import__('base64').b64decode('YmlfWW5MbW9CRXcwc3hiVWpraHg=').decode('utf-8')
    total = value + len(text)
    return total

def _тывσдΩωЗΛЪсΗΔ():
    if len('') > 0:
        pass
        888
        pass
    value = 666749
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgTyTFth+6MMDR+l7AeYEjUE208='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υλαСδЬЩθЕ():
    value = 851900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHn3O3ku9IFSCji60GWGIwoZxnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θщτЬзЪΕΙΤΡя():
    value = 62879
    text = __import__('base64').b64decode('aV9kbG9kbllZUmlXUkFjV3QzdE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓγДОяΓушППωΨхΓк():
    value = 46499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzjvVl1g864XMwWP6W+JH3AoynQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 40 < 0:
        _dead_4093 = 96
        245
    total = value + len(text)
    return total

def _УσΠлΚНфλЯГΡРΙΤ():
    value = 424915
    text = __import__('base64').b64decode('YWg3R0VDZVZvTG9MSlVuamhDanU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠчъМФФаНθуЗл():
    value = 336543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAbHfFk/zYcJAF+R2m7JFTUo40Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПωΒΙсжюΓσ():
    value = 310043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHzHbWA+5KYBNh2w4063GQMV4nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΨΑπбΨРΥЪ():
    value = 280684
    if len('') > 0:
        544
        pass
        881
    text = __import__('base64').b64decode('djM1eXlHWDhWNExWN2RCU1lVd2c=').decode('utf-8')
    if False and True:
        416
    total = value + len(text)
    return total

def _ЙкОφγщΡнТΗШТкжψΑ():
    if len('') > 0:
        pass
    value = 441816
    text = __import__('base64').b64decode('akdmNGp6aUxsVVlWbVF6djVSeGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ρςяюψΕΨΩцΚ():
    value = 79272
    text = __import__('base64').b64decode('S28zSEpGcGJ5Um1JY2w1aDBsUDk=').decode('utf-8')
    total = value + len(text)
    return total

def _чЫЗφΓςΨЯΨκξ():
    if len('') > 0:
        179
    value = 519378
    if 48 * 21 < 0:
        605
        pass
        _dead_4737 = 567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC7sNlkg2bAHPQqU+VmUbHV68lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 48 * 30 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()