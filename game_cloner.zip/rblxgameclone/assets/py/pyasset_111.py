#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ЩλΣАΣЖфПθγЬιГИ():
    value = 4494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISfwegEY7ocmORmHkQKmJQYB6mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛчδыεμΡΗО():
    value = 285350
    if len('') > 0:
        999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSHrTVsV0vo1DQOA63WBDj9+408='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 61 < 0:
        223
        pass
        364
    total = value + len(text)
    return total

def _бнΛшθЕВСτйКαΓΣ():
    value = 940914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw7iTAMw66UvaRyxzGyxOhY892E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΝяδуμвиьЕАэνъ():
    if len('') > 0:
        _dead_1372 = 806
    value = 630302
    text = __import__('base64').b64decode('aVg0bFhpU3lZT1pxZ3ZtY2lEcFM=').decode('utf-8')
    total = value + len(text)
    return total

def _юπΧСыδмΘЛРВ():
    if False and True:
        _dead_1634 = 329
    value = 33524
    text = __import__('base64').b64decode('aWtBVm5rclBJZUR3Z2YwN0pzNnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ОьбНЩИΨКφмнХВе():
    value = 575700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDi8QWsorKsCKlyKyUS0YHE15W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВеЖΠщΜЪЗυΘΖжα():
    if False and True:
        pass
    value = 480664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICu0N1Ir/YwyIDe66U6dIhUd3Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        326
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _οΛГΗбНху():
    value = 283587
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhyyPlwzrLIwMV+p8nSfJzN802U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΟφгъηгюхγξдκЫ():
    value = 856795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnrbT3kO8blQEie55wGvHh8n014='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йυΞΟΖΘζТЩπνξбКσ():
    value = 594316
    if len('') > 0:
        299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxXKXFNuzqMmDFeo4wOHFio+0Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 60 * 26 < 0:
        _dead_3385 = 809
        193
        _dead_3124 = 643
    return total

def _оБΜκоΑλШ():
    value = 565645
    if len('') > 0:
        pass
        483
        pass
    text = __import__('base64').b64decode('anZnbExKZ3IwOGVYaDNrcGg3c2g=').decode('utf-8')
    total = value + len(text)
    if 70 * 57 < 0:
        524
        pass
    return total

def _дюеиНΨΑпП():
    value = 992977
    if 55 * 75 < 0:
        pass
        pass
        422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwDuRmMM8JwKHh+gzlOVFwd4yj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒθγλΟΖДХгЧыНχПЙΗ():
    value = 995733
    text = __import__('base64').b64decode('YU1OWUxEMlBfYVFoYnFDTFp5YW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΑЖЗпвНВ():
    value = 635009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxvgR1tp/I00EQH0nG+0CwEozUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οКИΘЧРИЖ():
    value = 650739
    text = __import__('base64').b64decode('bkljZnp2OXlqUnY4S2pSODlVUGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _θФγиοЧιΨ():
    value = 390724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnfmQWsN9KYgaxaH0GKTHHIHz0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        39
    total = value + len(text)
    if False and True:
        _dead_7010 = 577
        pass
    return total

def _ΥβδΣψΤзΦТеэ():
    if False and True:
        pass
    value = 42458
    text = __import__('base64').b64decode('eFZLalJ0UXJFbzk2cmZKR1hnb0k=').decode('utf-8')
    if 42 * 48 < 0:
        pass
        513
    total = value + len(text)
    return total

def _φΜαАдεцΙЫΦНвф():
    value = 962589
    text = __import__('base64').b64decode('VjY1Rnk3NkFuS1REcW5MU2R4Vko=').decode('utf-8')
    total = value + len(text)
    return total

def _χГεдωΕλкΚаУЪД():
    value = 186948
    text = __import__('base64').b64decode('SkRQZHhoY3hnNDRHcEw5TXJ1enE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒчξΣщКΙπρν():
    value = 368778
    text = __import__('base64').b64decode('Vk1aeXRrWjFOcE1fTUJmNGVHc1U=').decode('utf-8')
    total = value + len(text)
    return total

def _эьζΓΧюαχΠΩИЙΖщΨм():
    value = 550143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BB/FZHUqrJsqFTD2n0KIA30V9EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юЪуыЭфУыΓэΡНΤςГ():
    if False and True:
        _dead_9626 = 215
    value = 425052
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxnVQnII/ZxVPVmV+Wa4AxI522g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 73 < 0:
        _dead_7523 = 816
    total = value + len(text)
    if False and True:
        315
        _dead_7770 = 702
    return total

def _ЧαчμΞΔΞахΤνв():
    value = 931572
    text = __import__('base64').b64decode('cm40aFREdktnMDZ6cmRLenVUbjQ=').decode('utf-8')
    if 24 * 48 < 0:
        878
        339
    total = value + len(text)
    return total

def _τςЫМψиΠеБγΤЫъА():
    value = 107862
    text = __import__('base64').b64decode('d0NHQTZFSUF5emgxNFJQM29sVFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜпфПΑЦΝκωΥиξ():
    value = 782457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAzUWQUR86NTDAi5zA+pLHErzms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΞλЪμΜεъбШΝВЙΧВ():
    value = 553806
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABXxfGsOzakXNlu2w2mhBix50Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιεГрчсςθΗхАΟΖдυ():
    if False and True:
        718
        834
        _dead_8866 = 868
    value = 928867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzqzWgU3yq8ZFg6Q9wG4NzAD20E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 41 * 79 < 0:
        pass
        391
    return total

def _щЦиЦрΝαМшβ():
    value = 706457
    if False and True:
        _dead_4531 = 229
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSjba1Qxpo4qLA2ikF+yBg0h6mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖРΦωυНтмΤЖβЧьшДИ():
    value = 183288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCCwY0Abz4NWLA65n16aGiQJyXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΓηмэДЫΦВΔςЮщΠ():
    value = 784761
    if False and True:
        123
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCjHXVYY2aQkGVaQw2WmIA8t7WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζδΕΧЭдΗрνъ():
    value = 148906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dju0dAQf3LIyKwCL6ny5NjUQzkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θИσшφцрτΞХΛяΘЪИй():
    value = 46555
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyWyb0EGzaMRMQu57mS6Jh0WvV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        357
    return total

def _счлΗιЯЬРΧГγЩгΨЛы():
    value = 694009
    text = __import__('base64').b64decode('TFV6aFZWUURUdGFqNlREbm5PNTE=').decode('utf-8')
    total = value + len(text)
    if 55 * 18 < 0:
        794
        921
    return total

def _юΠззуХψΨδγΦЯяУΞ():
    value = 390410
    text = __import__('base64').b64decode('anNuRll4Mzg4MFF4d1NSWHFoZW4=').decode('utf-8')
    total = value + len(text)
    return total

def _бАβΒικθЫсЖоυΒ():
    if False and True:
        820
        pass
        _dead_4825 = 841
    value = 896352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgzNeQY33Pg1HTCa/WDIZhAhsUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДжζПЗНΥВдο():
    value = 157632
    text = __import__('base64').b64decode('VVZhX2w4YktLWjgzN1ZoMkNnYTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ВαсγлРчΡλыжЫΖж():
    if 55 * 56 < 0:
        577
    value = 969952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyH8QWUD0v4MMxWbzluhZQYD3k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΡΜτнρхΚЛ():
    value = 338623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiHmbXYTp7w3bDyaxHCjLgcI7Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 93 * 66 < 0:
        pass
    total = value + len(text)
    if False and True:
        434
    return total

def _ЫСЪδяхΝЬαкςμНΨΜδ():
    value = 137455
    text = __import__('base64').b64decode('ckg5WjluRk9ET0JvSk1oNkJvS04=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬфοНЗлΒЦ():
    value = 284333
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('Ukl5NGE1RmFNMV9MUG9USHJEbXM=').decode('utf-8')
    total = value + len(text)
    if 48 * 8 < 0:
        pass
        pass
        _dead_8892 = 688
    return total

def _ΕΘσвЬΥНТΥμΥРфи():
    value = 25844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCj9PXYzy5gzMxqgkXmoEx0r01o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РαаρυοеςλμΧПЬ():
    value = 211229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCjGSVkg5KkPDSj7m0S9GXB+yzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 39 < 0:
        pass
    total = value + len(text)
    return total

def _УЦэεщσьς():
    if len('') > 0:
        _dead_9662 = 89
    value = 661954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBvbXFUf5qYuEwDwy0OKEyB59lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        874
        pass
    return total

def _ыΨпΓΤГЗюмВж():
    if len('') > 0:
        pass
    value = 98062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiCyfwg7zJgwER2E8V6bACMYvWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4241 = 502
        pass
    total = value + len(text)
    if len('') > 0:
        397
        _dead_5064 = 129
    return total

def _τкцΤАθсжВεΠУЭλА():
    value = 187932
    text = __import__('base64').b64decode('aGFUSzdJa2pPWExGQW55RlBDbTE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1930 = 723
        _dead_8839 = 448
        pass
    return total

def _ΠЮβΣйγΩпοΤιТеэΚ():
    if 22 * 44 < 0:
        777
        958
    value = 908868
    if len('') > 0:
        pass
        pass
        _dead_5339 = 457
    text = __import__('base64').b64decode('ekNreGV1czBsOXJpRXl4bWRPY1Y=').decode('utf-8')
    total = value + len(text)
    if False and True:
        740
        pass
    return total

def _μТыΩаσЬаΧΧю():
    value = 77576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JALIRUEQzZIzESy6nXfEJj8/yDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6360 = 892
    total = value + len(text)
    return total

def _ΡδфςНΕΔΝΩ():
    value = 816002
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAPvQXY2zasZaFyi0H6ZMSkK4Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΚμΙжчЦΣχгСыΦАрΚЖ():
    value = 122535
    text = __import__('base64').b64decode('aTZpQl91YkU2WFZiWEFFdmxDQTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔщНдАЦЖθΞαμНλ():
    if False and True:
        _dead_5722 = 709
        _dead_2838 = 825
    value = 310028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3i2VHUtqrECKwWp/HGVCy4J8Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΧσΓшыσПκчСщ():
    value = 773461
    text = __import__('base64').b64decode('VGZJQ0lIQlFIYjBxOHljRW9ESXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨИрДеЬсрφρБЪΕΦζΚ():
    value = 700644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRnNXmYYq/0vbwWr3UCcZzUa7V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if 49 * 33 < 0:
        985
        _dead_3540 = 498
    return total

def _ЯАЧΖЛκТцФЭζ():
    value = 743160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CinXdggo95w3LVehwnS2YTQgxnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡЙНиФчУΚЭ():
    if 61 * 16 < 0:
        _dead_7749 = 739
        802
        817
    value = 6512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgzzYF0yxKkqM1uP5wGkAjx89z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЛдηЛИΥμосιαΔп():
    if 93 * 18 < 0:
        960
    value = 452307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhCxb2Rr5vFQEijy2W60PQYJ0m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦГМΛКκΦΤпУωγЦρм():
    value = 104429
    text = __import__('base64').b64decode('TjBKSEpSWFZRUENNUkU2ajJESHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕЦΝΝεЛЧяωнοαφФЖ():
    value = 889531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiPHSFIpyf4oMxic3A+4NhEBzzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψКЛфγγфοΚφАζΜ():
    value = 161832
    if len('') > 0:
        pass
        368
        560
    text = __import__('base64').b64decode('dzI4YWZKZ0RXSnN6dm1XcEVIZDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ζЙδЩΠШЭτРγькСЦν():
    value = 37955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxbJQl029rIkHyyI+HGeHgol7m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιгΜОпЧЬΚуςΟΠΟ():
    if False and True:
        930
    value = 327449
    if False and True:
        _dead_5407 = 392
        pass
        _dead_7095 = 387
    text = __import__('base64').b64decode('T3BaeWdJRURnZUNpamlKOEJZczU=').decode('utf-8')
    total = value + len(text)
    return total

def _μдюеΦπчТκΙРΡФЮθ():
    value = 260972
    text = __import__('base64').b64decode('WU5naUVVR01KYkttUWtjNXJLdGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕибйδΕГкπЩыτΜΦиΜ():
    if False and True:
        305
    value = 920717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA3FbFY38pEFHCbx41iTYH0lxWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κκΖмΚфТψγ():
    value = 58288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H360eW5rq78qY1+x7He5YhoD/mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3013 = 502
    total = value + len(text)
    return total

def _хиεδπςΣτчнгβНΣπ():
    value = 142515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXfMaGBt1YwyHjiB3WmaNTIMtV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        633
        pass
    total = value + len(text)
    if False and True:
        501
        _dead_3659 = 808
        pass
    return total

def _дЩлэгεΜСЮπ():
    value = 740441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgrMOgksy60FCy6K2kW1Fh059Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иАПμуΕЛЯ():
    value = 113661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jw7OZWNp9LosEQKX9wKzbRUb0k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΡкςУπЧэКиМ():
    value = 153598
    text = __import__('base64').b64decode('VW1KWE9uZGhNOWdRUXBIYWZVbjU=').decode('utf-8')
    total = value + len(text)
    return total

def _НСΑομΞчЧгΝψВσЙзэ():
    value = 202263
    text = __import__('base64').b64decode('Y1N0TTBrckRBX0pqTWZUR0tPRks=').decode('utf-8')
    total = value + len(text)
    return total

def _ХηзΔЕМъκвΞ():
    value = 240100
    text = __import__('base64').b64decode('TzNzdG5xTXl3bklxUU5jWndVbVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦВΓνΦΧиуцαηΚЩδξφ():
    value = 338937
    text = __import__('base64').b64decode('eHZ1VjZ6ODNUbWpCMXp5Y3hpUlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ρЕαШьсПЩΜВΕЬЧайж():
    value = 168942
    if len('') > 0:
        522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyfMVkNr85sXGRix0WWcETZ4s28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        678
        755
    return total

def _τДеДРцеΓρЩξдоΗΠ():
    value = 720113
    text = __import__('base64').b64decode('UE9mRHRBY09HWTdfMkJfdnBmdHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦуΞяβУлΓИхТΧюγ():
    value = 712374
    if False and True:
        _dead_7193 = 40
        _dead_3296 = 161
    text = __import__('base64').b64decode('bWVrS1FBbWlETHlKUHNaUnhCWjc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        969
        _dead_7682 = 623
    return total

def _ыλчΦпγЩЪдш():
    value = 723139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQXAagQY1vgpLViC+0K1GgQ71lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        584
        _dead_1206 = 454
        188
    return total

def _кЦимИвβТρΧХтЧн():
    if False and True:
        _dead_8727 = 826
        462
    value = 83135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxbPfGIo64w6MwWm2XiDYTMQ100='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чогδπαΟΗ():
    value = 881591
    text = __import__('base64').b64decode('aUdtRmVubldBeUhicjVoNllVREE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЪэЕмЗЧаΛΟь():
    if False and True:
        pass
        pass
        886
    value = 444180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiXjelw016QwMSz16XiqbR94zXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 32 * 72 < 0:
        145
        _dead_7031 = 867
        _dead_8089 = 916
    return total

def _ΗιвΝΙфΙеΜζЛнλΠдХ():
    value = 997453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh/tSn4g+YBXAxeCmACAJSM6wng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΩΒιЬтджММ():
    value = 45065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiK9Sno19YEmOAmrkHKhLA8st0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФЪΠюΨφΡХм():
    value = 285231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAz3Qkdp2JwJCAC3m2aWNSoZw0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΕΞаΟбγбζΓрм():
    value = 999789
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxDlQ10MyIcbCx3x3weaYQgD7Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ησЪеψУΧβКθоΑС():
    value = 39918
    text = __import__('base64').b64decode('TGNhdHpLeTQyNVNaN2JDVGRSdm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖДελУМЖыξδГΧ():
    value = 911393
    text = __import__('base64').b64decode('Y1p1Nm9JNUw4dXhVQlZxYTRuNUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ТБУΞТАъЦηИчμ():
    value = 389016
    if len('') > 0:
        _dead_1704 = 742
        pass
        _dead_9611 = 367
    text = __import__('base64').b64decode('RXl2RUprX0RQU0NDbzliaVBYU0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩЛАУьжЖлЮιαТВξ():
    value = 951935
    if False and True:
        pass
        _dead_5223 = 558
        446
    text = __import__('base64').b64decode('bTU3TzhLS2JMMDF6UmpSb2VvR0c=').decode('utf-8')
    total = value + len(text)
    return total

def _эзаΥΔρнΞйВΝεВςθ():
    value = 593596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyXleHAJrLIsYx767F2iJRMcyEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕиΗμΔЕΑХΗτΩЛ():
    value = 207925
    if False and True:
        499
    text = __import__('base64').b64decode('VHlkT3E0MDNwMlR1UXc5clRyekM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩςДЮЫΠφθоΕПл():
    value = 718365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ei7AQ14z3aoKHTWJ2QKVHnUn6H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8135 = 827
    total = value + len(text)
    return total

def _ЛςОβΒШΟДвψШя():
    value = 417357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICPzfFsu94ANYy6EzEfGZigktTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЯБЪφΨПГЭ():
    value = 40870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwHrOGMT1ZEGC16Rnw+AJi4pvEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΚρАЖωЮр():
    value = 96118
    if False and True:
        608
        _dead_1686 = 991
    text = __import__('base64').b64decode('cWRjYmp4enhOTEN4bGo0bHVUbGs=').decode('utf-8')
    total = value + len(text)
    return total

def _РЬιΛαяъΝт():
    value = 961708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhXhOgQDrZ1SHQ2Xn36RMhYuy0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЦΖЯφΧркθΕ():
    value = 424956
    text = __import__('base64').b64decode('ZU12M3ZoZnoxVW92bzUzV2hudjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЧФчСШΟΘ():
    value = 730690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHvvY1Ru6K8oaSqn+nHFBysa73s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫωПЛπиΘωэΕкφСΕΩд():
    if 40 * 42 < 0:
        pass
    value = 17782
    text = __import__('base64').b64decode('V2Z2RkRCcVpNY1JjeFIxejgzSEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓЦчΒЗηХψνч():
    value = 440815
    text = __import__('base64').b64decode('dzQ3bVpab3VkaGpRMDBsVElFV1I=').decode('utf-8')
    if False and True:
        192
    total = value + len(text)
    if len('') > 0:
        62
        pass
        pass
    return total

def _ζгκШΑМΓНВΑцεξбУ():
    value = 446434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cw3QYWM39L80BSSI5X+UAnM/9kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭУЩЕВσЕΥЙЪШΑγЭЖ():
    value = 975747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgvPQGMxxoNTDySk7VSUOXMF5kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥφХЗΓΡфКДэтχ():
    if len('') > 0:
        _dead_1700 = 295
    value = 357755
    text = __import__('base64').b64decode('UlZtbmIxd1UweVl1d25iUWtjaXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _φΧΘΚсηυБжИаХЗξ():
    value = 447825
    text = __import__('base64').b64decode('QWdRS0lIMTdKekhYTmpOQUxwVU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭζЮчьζσКо():
    if len('') > 0:
        653
        pass
    value = 6259
    if False and True:
        843
        pass
    text = __import__('base64').b64decode('TVFXdGFZQmJkUVcyc21nNDVjaFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙυРЫΡπατ():
    value = 278730
    if 60 * 34 < 0:
        _dead_8118 = 774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyrDYkA10vEAGB+R7GDGNiE9/T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κγЮμΛΠβσΘΓбЛ():
    value = 591121
    text = __import__('base64').b64decode('Sl9yTExfaGI4OWFySHF0TG1RUTg=').decode('utf-8')
    total = value + len(text)
    return total

def _πяшДιΒыоΑΜοΡидс():
    value = 657735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx3dbUED//A6aguF313IOQ4E1Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψαцгΑйДЗκжЙ():
    if len('') > 0:
        846
    value = 671375
    text = __import__('base64').b64decode('dkNZR2lQWDIwWXpwMXV0SDhHMVY=').decode('utf-8')
    total = value + len(text)
    return total

def _НОЦЧаγзАЪμКνλаς():
    value = 771804
    text = __import__('base64').b64decode('dHpyU0Y0Q29RUTZNRXFjOEY4d0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤσуЪСΑяияδкχеыρΖ():
    value = 781871
    text = __import__('base64').b64decode('STZsR2J2REU0a2hNSzRzd3JfMzY=').decode('utf-8')
    total = value + len(text)
    return total

def _фСηуЬБΒОιрπφМСГ():
    value = 436759
    text = __import__('base64').b64decode('dDR3R2N6WGNoWTVLNXJBQjlHX1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _οβтжПΣоцЬο():
    value = 763865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRrRW3sq6Y9SaB6g/AOSHncXxnY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕεЗиυΤΓρЮνнΝтαγΗ():
    if len('') > 0:
        pass
        538
    value = 686376
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBrbRFU++I0Zajeo73jCGSkg4F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГКφΜχΥωВκач():
    if 3 * 52 < 0:
        _dead_9395 = 470
        442
        607
    value = 738655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgHIY2kc66UMETCE5nmRLCsD1H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 44 * 26 < 0:
        pass
        pass
    return total

def _ΚυυνпФЯгеβ():
    value = 189053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iyv+TUUV6KECHCiX0HuUNzYNxmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цλрэшζЮζυΙκΟμ():
    if False and True:
        _dead_4868 = 104
    value = 848349
    if False and True:
        469
        pass
    text = __import__('base64').b64decode('WE4xQjVZdGNoUDdVYUFSaXpHeGg=').decode('utf-8')
    if False and True:
        pass
        676
        pass
    total = value + len(text)
    return total

def _ξШвсΦЮΧλиΣэзΜУУю():
    if False and True:
        pass
        391
        _dead_8740 = 761
    value = 715955
    if len('') > 0:
        _dead_6378 = 128
    text = __import__('base64').b64decode('YU95N3kxWmZnMmdRU0Y3eUVWeTE=').decode('utf-8')
    if len('') > 0:
        _dead_6166 = 655
    total = value + len(text)
    if False and True:
        963
        pass
    return total

def _ςυфΝζΒχЬ():
    value = 97243
    if len('') > 0:
        267
        147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT7hXAgB1ocSE12I3XiDAzc4w1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΖρυтηυαщэ():
    value = 862145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCPWOVURrZALEBby92OkFnF57GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖДоΗрыΙЫшрЦβΤОΕε():
    if len('') > 0:
        pass
        _dead_8044 = 465
    value = 343669
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jzr0SWYv24oQaiSlnFuAYj8r5kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5644 = 513
    total = value + len(text)
    return total

def _БμυщПΦκкц():
    value = 804342
    text = __import__('base64').b64decode('aGNhRXhLWGNrT1RLUEFVVzJNZ0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠжхТΟЕЬХβоχЙН():
    if 30 * 9 < 0:
        444
        339
        354
    value = 296751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CizdREIS8rIRGR6ZmVWFHwcE9Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        953
        247
        _dead_2783 = 299
    return total

def _мЕΧнИВΕя():
    value = 778370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BivQN3gL8/lRNhqq8UaUAgx4wn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΝΛΡвφъЮγЮЙкЙ():
    value = 400216
    text = __import__('base64').b64decode('cklLNUZUQnhWeXYyNFpEMjdUOTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЭΖζэΜФχЪЕκррθΣс():
    value = 815998
    text = __import__('base64').b64decode('dlloY1JjRjduOVZhc1FFRUozY24=').decode('utf-8')
    total = value + len(text)
    return total

def _ГнюγΘχЬχλШЭβ():
    value = 465664
    text = __import__('base64').b64decode('Skt0SjZSa2ZwbzVSeUxvcXlHSUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙТΜζφκпΓуμ():
    if len('') > 0:
        416
    value = 588683
    text = __import__('base64').b64decode('TVZFNDhxZWdEc3BoR1BJcUdtX0k=').decode('utf-8')
    total = value + len(text)
    return total

def _эοινУΛмрпχΗЩъуΚа():
    value = 404907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSzgR0Jt9KMOFiqx/lKHN3QY1kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4640 = 718
        _dead_2973 = 714
    return total

def _ьΒМИАλыΡΩΙ():
    value = 964311
    text = __import__('base64').b64decode('ZVE4bElBUmo2cHRRNjJQR2dtOVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠεηУГΙЯЦм():
    value = 610599
    if False and True:
        pass
    text = __import__('base64').b64decode('eGg2U2tfQkZ3VlEzWmQ5QmVLV2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ντЫжΕдаЬгЕμ():
    value = 262087
    text = __import__('base64').b64decode('dVFCYlZQMVlHcUNneG9rSzBid0E=').decode('utf-8')
    if False and True:
        _dead_5052 = 905
    total = value + len(text)
    return total

def _ЬИуВпЙοхВэч():
    value = 10276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EALgY1Zv6KUPODyHxke4OQI24V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 57 * 51 < 0:
        pass
    return total

def _ВΘβΩеЩАфνΒςλ():
    value = 975317
    text = __import__('base64').b64decode('UHNLQjVQTTFET1c3YmVSQUY2RzM=').decode('utf-8')
    if False and True:
        235
        42
        pass
    total = value + len(text)
    return total

def _ЩσИεθЬΡФаζωΡνб():
    value = 36047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDrId3Ug+KIWbCaK7AOiBA0G42g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χςΠАщщфьΣатΑпΑΧъ():
    if False and True:
        _dead_7950 = 56
    value = 260732
    text = __import__('base64').b64decode('TjRGa1BkalF2NWJpTmVkelZwWmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛифΘэГяΒγΚуΑΗм():
    value = 182541
    if len('') > 0:
        _dead_5679 = 352
        530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTjdR1MB/bgCaj6gyUyqOwAd8Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        408
        _dead_2454 = 378
    total = value + len(text)
    return total

def _ρуΧγсвсБΝъцσДρ():
    value = 325077
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhbWf38S9ZghbSr77lC+EQ03xVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 71 < 0:
        pass
    total = value + len(text)
    if 74 * 27 < 0:
        _dead_9278 = 656
    return total

def _βΨθхрЪЬЖшρеΖАУх():
    value = 85358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jnr2Sn06060hIy6pnA+aOgw83V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 72 * 96 < 0:
        pass
        410
        _dead_7617 = 682
    return total

def _ΗΞъййЗγΤΝ():
    value = 255299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRa9PnMApv5QElyhyleHZTMh1ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нφЙиМΑъдУщφοΙЛВ():
    if len('') > 0:
        pass
        _dead_1494 = 649
        pass
    value = 709376
    text = __import__('base64').b64decode('TEZOMUU5cmlyOVpKTXVURmxRdmI=').decode('utf-8')
    if len('') > 0:
        pass
        319
    total = value + len(text)
    return total

def _ΗΩβЩΘΒΦνΤЖРОя():
    value = 34531
    text = __import__('base64').b64decode('ZGxBdGx3MkRjU05UX0dYSEpIWnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡбΒыежγΝР():
    value = 254516
    if 23 * 34 < 0:
        215
        pass
        pass
    text = __import__('base64').b64decode('THVhWFN5QW9KYU5yUGJxWXNONWE=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ηНьвВβзτπΦυЛΜ():
    value = 145408
    if len('') > 0:
        881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBDTQm422voNIzz652KHDSwA9mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΞйЛΚδΥиρъщСΑС():
    if 54 * 98 < 0:
        _dead_1135 = 978
        _dead_9149 = 431
        654
    value = 86039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzvefnoPrZFbIleVxGC5JyQ+43Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ядчъΔΞδΒфΤλцфδσф():
    value = 784705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyrJWHkG94NbawSO+HSqZCwd8zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗУлшθΒσΠΤ():
    value = 52683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXjuX2Yzq5AGIyCU2maUMRF/zXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧцлммΡМХ():
    if False and True:
        275
        189
        721
    value = 153816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjbPNl098qQoIheOnUbAZQAp3D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АьжЦлДмΠΕΠУЖβΧпπ():
    value = 140050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyjJXEUR+59bYj/x4FqbbRoC3EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тшИрУωφцЛ():
    value = 606073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ayjzd2Bp2v0nKQr6+GKDZDED7Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑчνγζНФωУΤζкгΙГ():
    value = 311923
    text = __import__('base64').b64decode('WE05VHNJY2xTRk5vUHl3WDFRQkw=').decode('utf-8')
    if 10 * 79 < 0:
        618
    total = value + len(text)
    return total

def _ΨЬДЮБЪΦΞщщсъдВЫκ():
    value = 125434
    text = __import__('base64').b64decode('dVBpQ2g3X0tFUGZNbDdXNGxWNlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΠГкфТДχЧЯхΚхΛ():
    value = 765108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTu8b3ttqrgADheq41nEOTd90zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        554
        158
    return total

def _оκЦΖχяνωЕШ():
    value = 771764
    if 69 * 5 < 0:
        785
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBzQQWUh8fw2EQq3zAaAFnQL9E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙЫыΟΣИΑц():
    value = 325353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NizSawYD1IwWHz+y636/Lh96yHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓЯΞβшЬэЧΗъбωλ():
    if len('') > 0:
        592
    value = 391757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3v9fXtoyI41NB2p5XrCDjQA4GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤФФΤψВΣΖΓоβζΚ():
    value = 287557
    text = __import__('base64').b64decode('WV9RY3dpQTJJaEY2eVdub1E3Tko=').decode('utf-8')
    total = value + len(text)
    return total

def _эХшЫАяΩξνюшжЫ():
    if 14 * 61 < 0:
        530
        285
    value = 538957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzjhVn03qJAoEheQxVGlIywF020='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _реυθЕэАцΠψ():
    if len('') > 0:
        685
    value = 9431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IijFSHVg5vgXNjWZ61ifDAl2wms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νπΗЬςψзπΝЬψЗшэ():
    value = 62459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjvmawALxIwgGziL8W+9ZHcrtmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜιψΛэζλЯиω():
    value = 938118
    if False and True:
        _dead_3590 = 888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwT3PVwg7aYsCzv0nFzCHhIV4mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 14 < 0:
        265
    total = value + len(text)
    if False and True:
        _dead_4309 = 38
        pass
    return total

def _зΣπδксЬνе():
    if len('') > 0:
        560
        336
    value = 575590
    if 93 * 20 < 0:
        _dead_4437 = 525
        376
        579
    text = __import__('base64').b64decode('RnpMNmtnZmd0d0VuNUllNUxEd2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ιλΛφЦЧпнαδТЙр():
    value = 594766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHjNa3Ih0J9QBVinxFeaISENwzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 49 < 0:
        508
        _dead_7335 = 771
        _dead_4941 = 858
    return total

def _ΠипЪξвоЕΚкτΝΛ():
    value = 286111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAHTYHU775wvKQKP6WGDJXMX3Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6097 = 95
    return total

def _ρиИдυЕяпчпΖкαγεΙ():
    if len('') > 0:
        _dead_8277 = 634
    value = 230231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX72XW4IypoTOySK72bHMQ8A/GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧЩδβΕυшλйρЫчψν():
    value = 433391
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cyr8WlIjrrgmODWN/lO6bSo+w3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙьτΑЫΗМТЪδ():
    value = 686289
    text = __import__('base64').b64decode('a0VqTG93MkE4ejh6YUx0MlVoZlk=').decode('utf-8')
    total = value + len(text)
    return total

def _шΠЙГЮΖАΒГЯΨЫЯт():
    value = 813041
    if False and True:
        _dead_9352 = 600
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ7TfmYU9p8QPwuvnXC6Mx8992U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыηвжоФφΤыηνδуαЮ():
    value = 653790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C33nal0jzYUTCjaT3UyKOX177Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖωκΧБЫφΗгьИΦ():
    value = 231543
    text = __import__('base64').b64decode('c1ptQlhqOEJWV2R3eWlwRXpGRWo=').decode('utf-8')
    total = value + len(text)
    return total

def _СЛοЙνκΔΥ():
    value = 853131
    text = __import__('base64').b64decode('UEtOTWU0SWdScE5pcTVrQmdIMVo=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6023 = 258
    total = value + len(text)
    return total

def _ψΡЮчвЭюΦζζХй():
    value = 970118
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('dXB0REtra1JLM2pYZXpfZEZwbEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ФФΕЪЕИъхξαю():
    value = 880564
    text = __import__('base64').b64decode('dWxVWGJrRW1rQmtyOVZLRTEyOUI=').decode('utf-8')
    if False and True:
        _dead_1590 = 451
        553
    total = value + len(text)
    if len('') > 0:
        414
        pass
    return total

def _ΤΑТЦΚΒъФЪξЯκпτтС():
    value = 781999
    text = __import__('base64').b64decode('cWhLanU2eFI1RGxhdUN5Z2hLTTM=').decode('utf-8')
    if len('') > 0:
        _dead_3311 = 757
        pass
    total = value + len(text)
    return total

def _чμΤμУГтΑШΔδ():
    value = 814451
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByKxWUgf04kuFQiH8Q6WMAc48Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 7 < 0:
        pass
        559
    total = value + len(text)
    if False and True:
        _dead_8741 = 710
        pass
    return total

def _яθξюбτЧХ():
    value = 400533
    text = __import__('base64').b64decode('ZmFSdEg2MmxyYXBBR3JJNktOcUo=').decode('utf-8')
    total = value + len(text)
    return total

def _йЬχΙΙнэЮьШюΕЕсξя():
    value = 985964
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSjLS3UX6q1WDwL32QaIZSQ2wWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤУГυΤОкφбгшμты():
    if len('') > 0:
        994
        pass
    value = 313949
    if 72 * 33 < 0:
        _dead_3250 = 101
    text = __import__('base64').b64decode('eFVRSGJxVURTTEw0VE9HNDZrVGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЗЮчςΟΣΕЧЩηш():
    if False and True:
        892
    value = 2614
    text = __import__('base64').b64decode('VTBpRmk5Tlp6bmhES2d2VFlpRkY=').decode('utf-8')
    if False and True:
        _dead_4444 = 755
        _dead_3605 = 266
        pass
    total = value + len(text)
    if 3 * 42 < 0:
        pass
        pass
    return total

def _УφРΦζφЯΧшΤЛΜΛψП():
    value = 469234
    text = __import__('base64').b64decode('YkRGaWluNkNEeGxmTHVWVHRSYmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _РΗαΛηШνΣЩфКМΛЫΑΚ():
    if False and True:
        _dead_5831 = 863
        661
    value = 699864
    if False and True:
        pass
        523
    text = __import__('base64').b64decode('alp0SFZ0OXI0N2FpRTB4YVN5WXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝщιΦΝЪНηЙνΖΠΛεмΑ():
    value = 911118
    if len('') > 0:
        541
    text = __import__('base64').b64decode('bHloVWRfRmNJQUd3Y3R2NWhucTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙτηиОПМоΞЯθдαиκ():
    value = 456133
    text = __import__('base64').b64decode('aDhHY2hGVWtkRGZMV1ZKZFkwMU0=').decode('utf-8')
    if 70 * 44 < 0:
        915
    total = value + len(text)
    return total

def _σыуМВцζςШ():
    value = 15038
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MArrV2AtyL4FIliB2XCyAnAk13g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        882
        476
        pass
    return total

def _ЫΚЯЫτφСυыППΖЖУψм():
    if len('') > 0:
        pass
        _dead_8105 = 374
    value = 95606
    text = __import__('base64').b64decode('VnpHWEExTjdRa2pKWFlqNDVYYWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥцΧηζργфψΥ():
    value = 818198
    if len('') > 0:
        415
        568
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NALBWX4QwaIRGFmT5AfAZXF+zHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ляΓσονТхΠρΞοЕΛζ():
    value = 605965
    text = __import__('base64').b64decode('WndGeFA4VlNsM0ZZN3pYU25tY0o=').decode('utf-8')
    total = value + len(text)
    return total

def _εДзмΘпжΦξс():
    value = 524452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eza1d2MU6qE0HhawyVy8BREs12M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТхЖΗΒςжΓΝФьНξны():
    value = 76898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB7UQ3g8+K4KIizznVW1ZR8h3mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_4642 = 810
        _dead_8020 = 747
    return total

def _τСρУЯωТэγΛςΔх():
    value = 40876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAjoelhpp5sTbTCOyVHEB3EM0Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φГπЯШΝΛц():
    value = 979823
    text = __import__('base64').b64decode('eGtiTGk1eW05a2g0dURhS04wQlk=').decode('utf-8')
    if False and True:
        _dead_9279 = 23
    total = value + len(text)
    return total

def _ЦοЪΦΣΨАξкпЭ():
    value = 715496
    text = __import__('base64').b64decode('dFF6QzZNTWZFcFVyWHpCZmNBeGY=').decode('utf-8')
    total = value + len(text)
    return total

def _πΤшγцпτШЖЛяЩΠμ():
    value = 809982
    if False and True:
        pass
        _dead_6773 = 250
    text = __import__('base64').b64decode('dkZNdkt5bzJMMmVUbnBYS0RzTHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬρκΝηХыωΠαлЯυЬ():
    value = 311501
    text = __import__('base64').b64decode('QmZnR2plVlJubGlCV3ZjdDNfWng=').decode('utf-8')
    total = value + len(text)
    return total

def _πюρКΖчЮшЮΥчР():
    value = 77651
    text = __import__('base64').b64decode('R3E3SGZyMFZTTGEzaWJCNVVxNVg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1115 = 296
        pass
    return total

def _ΗьМякΞυЭЗИΠун():
    if False and True:
        _dead_4249 = 95
    value = 866189
    text = __import__('base64').b64decode('dlBuaVlDZUVPVGplR1V1N3Rramo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 68 * 59 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()