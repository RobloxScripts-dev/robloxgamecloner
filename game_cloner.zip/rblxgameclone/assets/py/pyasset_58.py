#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΗтЭПяΘΗцвШЧ():
    value = 948377
    if False and True:
        559
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhbFSmEP+awkEj+CmVW9JDI29WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        481
    total = value + len(text)
    return total

def _РЬЗхΞЮψТя():
    value = 262960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mze0d38+6aNUMR+BzlqVAzQN8mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΛςΠЕΩСπΙ():
    value = 734269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhXbdlcoqvATEQ7x+HW7EA991Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωщЪйНЗСЭχпВΖКυЙ():
    if len('') > 0:
        _dead_1777 = 960
    value = 141589
    if 51 * 67 < 0:
        675
    text = __import__('base64').b64decode('QkpFSmx2d3luSTVMVFlKR3JtdjI=').decode('utf-8')
    total = value + len(text)
    return total

def _оаШИХЦιмΨ():
    value = 797055
    text = __import__('base64').b64decode('S0RISnNqYXVlRXhUT3RFU25QZDY=').decode('utf-8')
    if False and True:
        pass
        191
    total = value + len(text)
    return total

def _ъЪиЩΔβКζТεчщГ():
    value = 553200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwreSkRsxIxVKhiBwWSzHCEj0kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪπΒпЫΩЗΗΦρТУ():
    value = 563729
    if 89 * 34 < 0:
        _dead_7842 = 668
        37
    text = __import__('base64').b64decode('aDdVTnhTOHE0c3QxWGJKSFdFMWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΨεκяΖчОитγ():
    value = 858927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHjdQVQay/4sbV6PzH+HGA4Z70g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гλхТЕЛщЭΨЭβ():
    value = 415181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCPdVwQp6ZEtFBuq5XWxbC8k4mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чЦюΟκФрЫπ():
    value = 48040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyrGRnsj2pEPaAuymVnAEzU+3Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бςщγЯЗъТьομЛΛШ():
    value = 790890
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3v0ZlwbrIAoAzbymFucCwEgzE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΤΧΦЦΔТДажКΝΖюзХ():
    value = 174800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjfqY0s20a8PYym50mGEODB4vU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εлйхГΜрυΥθи():
    value = 831708
    text = __import__('base64').b64decode('VTFQUU91WDBzT0JpUEIyczFIMHY=').decode('utf-8')
    total = value + len(text)
    return total

def _θσЗσυЛΑсааξρ():
    value = 875365
    text = __import__('base64').b64decode('UGxHem1EUFJMcEdnOWdJcjFkSnc=').decode('utf-8')
    total = value + len(text)
    return total

def _мэΛсшЭйчζлмх():
    value = 212748
    text = __import__('base64').b64decode('Q2dKOTVzeXJnYU95ZW5naUUwVHI=').decode('utf-8')
    if False and True:
        _dead_8904 = 885
        pass
        _dead_5221 = 514
    total = value + len(text)
    if 60 * 29 < 0:
        _dead_8687 = 146
    return total

def _эбΒЦμыЯлθΦ():
    value = 269211
    if len('') > 0:
        pass
        467
        261
    text = __import__('base64').b64decode('dm4zWjgxRmczQnRYVlVoTm0yQ0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡМОΜιЖΙфαОЦЩыΣпΛ():
    value = 363226
    text = __import__('base64').b64decode('SlRicVI2RUdpS1poc210c3RuR20=').decode('utf-8')
    total = value + len(text)
    return total

def _хЦσбφъСЗ():
    value = 375025
    if len('') > 0:
        _dead_9673 = 356
        _dead_3691 = 630
    text = __import__('base64').b64decode('eTh3eTF6Ym1xX3JGNENtTVJXQXU=').decode('utf-8')
    total = value + len(text)
    return total

def _СδКРΙδμэСΠρМю():
    value = 121389
    text = __import__('base64').b64decode('UlpTdGdlYzhmZ2tTNWh1NFhPRVE=').decode('utf-8')
    if False and True:
        _dead_1496 = 976
    total = value + len(text)
    return total

def _яйηΓΒЧЭΘщФуΘΒΓо():
    value = 286993
    text = __import__('base64').b64decode('T2lkOGlRaEY3RDllRTBfOW5DM3M=').decode('utf-8')
    total = value + len(text)
    return total

def _СвсЮΡЗςЩеЮρиΞ():
    value = 215400
    if 77 * 10 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3rrT0QypqE8Dy2Kw3uGZSc55nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 100 < 0:
        _dead_9298 = 636
    total = value + len(text)
    return total

def _лЛЖΟξζРмΓИευ():
    value = 974973
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EArxWEID2YZUOC2C/lCRIDcI60s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΙβΤЮоςτψΣΔ():
    value = 252678
    text = __import__('base64').b64decode('a2g5ZG42NXk0QnVXYWhVNlhiUGY=').decode('utf-8')
    total = value + len(text)
    return total

def _νюъСΩΙΘхбШфКνΑ():
    if len('') > 0:
        _dead_7510 = 157
        _dead_5264 = 395
    value = 673742
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('WFo0UzhvY0JyZkNENUM4XzlYUnQ=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4588 = 566
    total = value + len(text)
    return total

def _ДЪзΙкГВαΠэтпВо():
    value = 75474
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzXBRWcryfEsExqb5nmbAycByWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 81 * 50 < 0:
        327
        _dead_6223 = 757
        pass
    return total

def _ΡтАΤУЛιОП():
    value = 985318
    text = __import__('base64').b64decode('dUc0cTBvNUdRUXhJaFpfbHVlN0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΧТЮΙЫоΕь():
    value = 441124
    text = __import__('base64').b64decode('aVBic0pIRnc0QU9qUDdFc29DT2E=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΛΥдХтωящ():
    value = 684226
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgfbSFcRxrwgEl2R/UOJEnJ5xXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΥБчЗЫΟСПΝйЭ():
    value = 566297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3fhWUYSp48RLBj1n3unZjEGsjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΧлнТЮЙΤα():
    value = 943350
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRa2QGMP9bwmGwOH3kKVIwwM62o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        497
        _dead_3944 = 766
        pass
    return total

def _ωжτЩιΖУξЕтμЦэ():
    value = 929481
    if False and True:
        254
    text = __import__('base64').b64decode('UzVZRmlOWW5aWEVDWWp1UkNsWmg=').decode('utf-8')
    total = value + len(text)
    return total

def _цυэОΣΑρΚΟфСΗφэ():
    if 74 * 36 < 0:
        pass
        864
    value = 197739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQS8R3spyJEybxaO2A6XGRE83m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪтΛυфπиζεЩчν():
    value = 334725
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ihm2Wlos+bglGF6ymlPAPhoW02A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МСΠζςΦτцяζ():
    value = 4438
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lgq9YWQN9aokKCS7mUaoGB0Mxkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _убβМΦεзΥΣ():
    value = 488230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InjNR3AtzoIaDFeg4Wy3JSg1zWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬющМτιζЛшзу():
    value = 205503
    text = __import__('base64').b64decode('dFNPSXRNalpidWcybVlPVGtvckE=').decode('utf-8')
    total = value + len(text)
    return total

def _ШψЕцτρЬЩΤΔЭЬЦΝ():
    value = 979342
    text = __import__('base64').b64decode('UEJoNmM4ZVZjd2FlU05xMHh4N2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΑзЬжρΨИЦ():
    if 48 * 27 < 0:
        174
    value = 979537
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChjQN3Ng170PCjaywASUDRQ41mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗχПОοВПΨΗфβλφлЕж():
    if False and True:
        42
        420
    value = 520432
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3/eYFUB/Y81AzWU3FS5OTA483w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 86 * 29 < 0:
        675
        688
    return total

def _κЯъχιΞгЪвшэ():
    if False and True:
        11
        pass
    value = 354494
    if len('') > 0:
        46
        _dead_7754 = 868
    text = __import__('base64').b64decode('T1QxOG5rSUdKU003ZlZNM1k4Q1U=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2243 = 110
        866
        pass
    return total

def _ЯΠπВвуэМΑФΡ():
    value = 361144
    text = __import__('base64').b64decode('ZWJha1k1MkVfNUNQZnRpYXJab2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗοАοщЗζργζΘ():
    value = 287345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx2wP3kI+IQXFBu3yQW5OyA8038='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψВтπФщщΩуЩИЗΕγ():
    value = 715785
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3y9Plxs2b9VKySszVG+PiQYxWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чДсΝΤοпБΦллТДσ():
    value = 932672
    text = __import__('base64').b64decode('V3RTVGpXYUR6NjlWS3UySGxYdzU=').decode('utf-8')
    total = value + len(text)
    return total

def _кМΖИωВвкЧэмΜ():
    value = 25248
    text = __import__('base64').b64decode('aG5LMjJabjkxc2UyYnYyckU3cnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ζКЛνБЬлЩκдγ():
    value = 102487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nzq0WElq/bgWPRyg6VKZO3w9zzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еχΖЪωлаΣГобλЩбΤз():
    value = 340450
    if False and True:
        _dead_2016 = 456
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQbqXgY7qIokHz2r7XqlZ3d5/nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        58
        pass
        pass
    return total

def _ИΧΝοЪφрΒκВУΓж():
    value = 150332
    text = __import__('base64').b64decode('SHVDdGNlU3ZVMWF2RG0wamd2R04=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΧаюиЫζгэζЛБ():
    if False and True:
        723
        _dead_1165 = 107
    value = 931472
    if 38 * 37 < 0:
        pass
        268
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CibGO3hs9I8lEgyi/Hi7Pn19900='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒйПпΚЭДΒΠ():
    value = 706791
    text = __import__('base64').b64decode('Wkd2R05DUUdlUWNPMTRZcFd3V1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ХρΟΒфчΧМш():
    value = 48202
    text = __import__('base64').b64decode('RGR2ZjZWZGpGNVF5YmF5Q2duQ3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ζμγΨηХШΔиκηηχОδε():
    value = 716159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXy8PnUz8acvKQKw3nOYZz0MvEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΜξгРЖЫλЕυЫ():
    if False and True:
        pass
        347
        708
    value = 37775
    text = __import__('base64').b64decode('WjJVMkNFc2Iwd3B4OEE4cktWNDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖшяβэШΟΑкΒΡФ():
    value = 321760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxzqSEgW1KYbEV6z4lOfbAAV3no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΚГфΙЩЗшνΗΣЪ():
    value = 851340
    text = __import__('base64').b64decode('Z0FBTmtvbzYxUEk0UHhCZm1pSXk=').decode('utf-8')
    total = value + len(text)
    return total

def _бτьСОуЯлξρΜωЭς():
    if False and True:
        _dead_2500 = 968
    value = 975128
    if 64 * 45 < 0:
        346
        pass
    text = __import__('base64').b64decode('a1lmS0Z1S2tRVzBzZEJOM3hraHU=').decode('utf-8')
    total = value + len(text)
    return total

def _κВβЯщΞΣЛцΦР():
    value = 616750
    text = __import__('base64').b64decode('UHd4M1RkamN6aVZUMFRKX3k3OHY=').decode('utf-8')
    total = value + len(text)
    if 16 * 76 < 0:
        321
        _dead_7060 = 983
    return total

def _υγЫтУΠПР():
    value = 684130
    if len('') > 0:
        _dead_9330 = 961
        875
        pass
    text = __import__('base64').b64decode('bjJiOGo5ajZmSExEM3hEeENJcVU=').decode('utf-8')
    total = value + len(text)
    return total

def _мΞΞλхηХыХзцЧιЖЕр():
    value = 381423
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MznpNnAA67EnHCON0gCBJSct5kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йκΘХзггμЖчσΘ():
    value = 205927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ljq1N3Ij54MTAwOS4XO5Hxo63l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пвκРПыΠлУΥдТвИГ():
    value = 973780
    text = __import__('base64').b64decode('VDFDSmpqanRWSVFLcWkxWFZvaTI=').decode('utf-8')
    total = value + len(text)
    return total

def _πЩΞχеδΠрΟсЩпФλД():
    value = 216510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXq1b1k6y/0yNQKu4lPDYRE+/X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лъСΠΒΝсЯλΒмΑхφΥ():
    value = 165771
    if 28 * 19 < 0:
        _dead_9224 = 12
        113
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dwe8RmEbxpA7YguQm2ySJTM91VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1332 = 98
    return total

def _ЭςФГдΨΞЕΩЦКΜ():
    value = 121364
    text = __import__('base64').b64decode('d0psT2JnVmhuVXBabjR5T25TMnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ψКЙфСнυУЬВτНЕХ():
    if False and True:
        pass
    value = 586210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXbWV3Bp3aEZLimV33OjCxYV6HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 28 * 40 < 0:
        pass
    return total

def _φΕφππΑδωЫ():
    if 71 * 81 < 0:
        712
    value = 856034
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSm3O10+z4EzNB2ZmlCkAyIn1D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_3409 = 69
    total = value + len(text)
    return total

def _αРРτΖЮоΒчΧεΧЩψ():
    value = 37185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnrWV18Y87kmEVai8QWAZjY94Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЙЩμйвηΖснП():
    value = 743659
    if len('') > 0:
        544
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHvHa1c73YtXMFqJ2lijLD0l6G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иρηαДжьБдфΔша():
    value = 936847
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCrTO3RqzYwaCgiLn1ebGy4e90g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΜпЭэдГΦΚЦρх():
    value = 511307
    text = __import__('base64').b64decode('TmtDWVVaTWJidEtwMlpQWXVXTUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛяСΝшвчъТГ():
    value = 699915
    text = __import__('base64').b64decode('V0pRQTV5SlhCSDBMOTNyNEc0Z0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΤюΛυЕжОΗйΟПУза():
    if False and True:
        pass
        694
    value = 587542
    text = __import__('base64').b64decode('WVZCVWs1Y21UWFZxWkhUZWlCWkQ=').decode('utf-8')
    if len('') > 0:
        _dead_1092 = 357
        136
    total = value + len(text)
    return total

def _вΞнΨяΑπΒХАΨπыΛ():
    if False and True:
        _dead_8407 = 781
        _dead_6006 = 926
        _dead_8604 = 974
    value = 311667
    text = __import__('base64').b64decode('eWtKdnFHUTE4dDNzc3RIM3Btbk4=').decode('utf-8')
    total = value + len(text)
    return total

def _φЧРпΠεфΥτβ():
    if False and True:
        _dead_3725 = 143
        pass
    value = 969547
    text = __import__('base64').b64decode('bFNfWmZEOTZNY0VyQ3VrczJNOTg=').decode('utf-8')
    if 49 * 84 < 0:
        24
        pass
    total = value + len(text)
    return total

def _аνщПιτтΩρГМЦР():
    value = 716876
    text = __import__('base64').b64decode('azFSR0h2cmRheV9fTUtHRlFEZXk=').decode('utf-8')
    total = value + len(text)
    return total

def _нПζЭΕюсЬъфгαΙЭκЙ():
    value = 778751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgbvTEY0xPwqbjymw2WiHCwN7nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        740
        pass
    return total

def _εΟΖрΖшΣΝИηνЭΧХЙ():
    if False and True:
        _dead_5302 = 93
    value = 133127
    text = __import__('base64').b64decode('aW80cmxCTGM4Z24yanZmT0ZTeFM=').decode('utf-8')
    if 23 * 13 < 0:
        650
        _dead_3873 = 570
        299
    total = value + len(text)
    return total

def _ЮθςλТΙΜΓЙъЬΙюΕ():
    if 33 * 5 < 0:
        629
    value = 897696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3y9YUQ376YCPw2y2HGjOzMI6kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΓφРКЛκЪОΕμσмЖο():
    if len('') > 0:
        749
    value = 80253
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lgq2SXYUyLIyMCyw6V6BMBUp7DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чьΔкХΨΤюπΓюνЛСσ():
    value = 301825
    if len('') > 0:
        _dead_8877 = 140
    text = __import__('base64').b64decode('RkJ3bGNmS0RiM0hfbFZXd1FSV3I=').decode('utf-8')
    total = value + len(text)
    return total

def _НΤшζΗΙяυΑ():
    value = 255331
    if False and True:
        569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX7AeW5v8IAIFjqc5VO5AXd+1mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΜЙЖрΩгΑΚсΜΚυяйЪ():
    value = 606781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhfoN0AU9pFUAyCN6XqIOg8W/k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юИβУьЮчцΠлГτУ():
    if False and True:
        671
        _dead_5055 = 307
    value = 458881
    text = __import__('base64').b64decode('Tnk4ZjBTNkxJSjN2em05YnRqZXA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4390 = 898
        pass
        _dead_7917 = 404
    return total

def _чβΒλЩΖСнρгΑр():
    value = 764787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB3ralhgxKQKEymS6UeeHy1+xj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧνШйиНиΕЙЖкзκвθσ():
    if len('') > 0:
        _dead_8318 = 330
        _dead_7510 = 173
    value = 766737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSDbeVodr4ITGy6n5UzIPCkf7EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζБъΣеΤвяфбΕθρΖиЪ():
    value = 793834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fwb3ZG4T+71UaTyW0GO6ISQZz28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 51 < 0:
        764
    total = value + len(text)
    if False and True:
        _dead_6934 = 583
    return total

def _ΓιшΖωΣКΧιъν():
    value = 224577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTvHPnMq8vxaPyCa7lSlJCQg6Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9998 = 897
        _dead_4218 = 495
    total = value + len(text)
    if False and True:
        pass
        878
        pass
    return total

def _χОςщМψыι():
    value = 709801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyzNRlQ437srMxWF+l+8HSIIymE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΠЖуοвЛυΩΤΑΛγЩР():
    if len('') > 0:
        pass
    value = 54525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH/qX2htyfwSD1b141ukHz02520='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠЩЧЗΞоΖЛδЬοΨщΓ():
    value = 452816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz7bPmZq05oJKD+Hy2KSJAs59Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        679
    total = value + len(text)
    if 72 * 62 < 0:
        322
    return total

def _ЫЪμЪбрПтЬВАу():
    value = 948916
    if 43 * 95 < 0:
        592
        813
        pass
    text = __import__('base64').b64decode('TW9qaFFGVFNIc1YzNWdsdGdLNV8=').decode('utf-8')
    total = value + len(text)
    if 51 * 49 < 0:
        pass
        _dead_2509 = 446
    return total

def _ЙяςΘΗЗУтνнΦΩωΕГΨ():
    value = 529049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwfwYn8gx5knKleG/1+/IAsW6W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЙЖшэффΩШБнДψ():
    value = 319922
    text = __import__('base64').b64decode('R2xCT1AxUzVYY2lwRTFuMnRqNDU=').decode('utf-8')
    total = value + len(text)
    return total

def _ρρЙφОЦЛХьЮ():
    value = 318962
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAu8dHUu8fBXKRmW7GyyJSt/yl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7975 = 374
    return total

def _эκφЕζγБЖ():
    value = 74056
    text = __import__('base64').b64decode('dE1SUVlsbTlSblAyVmtyX1VydDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ψюЪΣзЪΜςψ():
    value = 253030
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('bXpyUV9OcW5IbnhMb0JtTG5TNmo=').decode('utf-8')
    if False and True:
        _dead_7364 = 859
    total = value + len(text)
    return total

def _βΩψипΨвЗΝК():
    value = 502360
    text = __import__('base64').b64decode('S2QxUmdVSnZSb1VFQkNZeW9BbWU=').decode('utf-8')
    total = value + len(text)
    return total

def _РдЪЩзυМНςεЪЯοбЬ():
    value = 465907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh3rXGUx7fkqNyew4ma7NTEQw0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _имМυЖΛъБΥЗоЦОо():
    value = 833186
    if len('') > 0:
        _dead_1452 = 393
    text = __import__('base64').b64decode('d3NjdlNuQlg5dFFvNXdKSkJSR0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘПГπΠръΑςΥк():
    if len('') > 0:
        _dead_3560 = 633
        97
        930
    value = 359471
    text = __import__('base64').b64decode('Zk4wdFB1YWlwUlpQck1talVobkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ιДΧНσЯьЕЛ():
    value = 785377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTzCRUU/qKknEgLxzmKYFSs2vEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оНоζψиΕΑωψЕ():
    value = 360784
    text = __import__('base64').b64decode('blVsc3RKTXBxdjJkc1Ywb01kX3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛунРяΕЙЩОΟЫРΒΤζ():
    value = 15812
    if 81 * 22 < 0:
        509
        3
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiTCaWsv7q4RLhX6yU+YPSgl9FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 4 * 15 < 0:
        650
    total = value + len(text)
    return total

def _СιΨЖЫΜсМу():
    value = 288228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nwu1P2UV1aUaPFuhkEGmPiAY9m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шνΜИЧΣлРЖ():
    value = 641042
    text = __import__('base64').b64decode('SUNzWUJDTFZWU01HYkNrV0pnS24=').decode('utf-8')
    total = value + len(text)
    return total

def _εРкρТЦΠЪΟΠπβθ():
    if 93 * 12 < 0:
        pass
        _dead_3459 = 427
        pass
    value = 493205
    if 8 * 63 < 0:
        771
    text = __import__('base64').b64decode('Slc4RVRfX2ZVdFhZM0plUmZ5REU=').decode('utf-8')
    total = value + len(text)
    return total

def _фΘХΜмξΙΟФПДбУШωГ():
    value = 368821
    if 74 * 42 < 0:
        _dead_3544 = 646
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwfKYwA62KIlCBe72w+jLTAA52s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        677
    return total

def _КозугθζК():
    value = 860015
    if False and True:
        _dead_4459 = 365
        104
        _dead_6450 = 752
    text = __import__('base64').b64decode('UGZpS0xPZ1JFOU5SNW9IdlpqNnc=').decode('utf-8')
    total = value + len(text)
    if 43 * 54 < 0:
        _dead_6676 = 509
    return total

def _КыΗЭπγЗяζШЪУЖΜяП():
    value = 263279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgHSb1442a07Hi6Pm36+ZAkhtXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮБΚюцΞЛвνρЗρβΡΣЫ():
    value = 482344
    text = __import__('base64').b64decode('UmNueGRTZXVCX1p0NU9oekcxUTM=').decode('utf-8')
    if False and True:
        pass
        pass
        404
    total = value + len(text)
    return total

def _χхΑЮИГγй():
    value = 505639
    text = __import__('base64').b64decode('SFZVTVJ5UkRhX0FkeUtDSl9mOHU=').decode('utf-8')
    if len('') > 0:
        _dead_1227 = 158
        210
        471
    total = value + len(text)
    return total

def _МрМΓαЭВφΔΦΟ():
    if 35 * 23 < 0:
        656
        _dead_9164 = 427
        _dead_7040 = 203
    value = 552116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQvwRXYf/69bGF2Ry2SUPHQX6js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 36 * 89 < 0:
        82
        _dead_9169 = 163
    total = value + len(text)
    return total

def _ΖЪΖаюТУΛΞΗ():
    value = 41810
    text = __import__('base64').b64decode('RUJpc3pObkRZc2lmWXZTYk5Cdm4=').decode('utf-8')
    total = value + len(text)
    return total

def _сυАемκаяηккδ():
    if 3 * 87 < 0:
        420
        96
    value = 695185
    text = __import__('base64').b64decode('SkxRbXNMSTdobkFMeldWODFCYzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗπкΟεпςτРтγТв():
    value = 708288
    text = __import__('base64').b64decode('cmg0a1VGbmJqa1RqanRMNWQ5Vk8=').decode('utf-8')
    total = value + len(text)
    return total

def _κωИηΖжТЧΔвθΒοМь():
    value = 140867
    if False and True:
        697
    text = __import__('base64').b64decode('Y3Y4dVRFcEtxNFF5QnZWNlRIeVU=').decode('utf-8')
    if False and True:
        _dead_6626 = 156
        94
        _dead_6361 = 551
    total = value + len(text)
    return total

def _ЦπΣΦδЭωρПсΘκЛоΜο():
    value = 444385
    text = __import__('base64').b64decode('TDJZc2pMMkdOY3hmVmdwSGowaHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΥИΗΡМУΤФ():
    value = 403683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dg7XO1Ij7IRUCRz050eRBg44skk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧоВхψΟξЙо():
    if False and True:
        663
    value = 755637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnzsaEs0qpwWHV77n2KZMAAF7HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        975
    total = value + len(text)
    return total

def _дснσГфТКйШФчи():
    if 88 * 76 < 0:
        _dead_3725 = 646
        pass
        703
    value = 505133
    text = __import__('base64').b64decode('WUQ4SGpNMnNYRkZ5SHVheE03UHI=').decode('utf-8')
    total = value + len(text)
    return total

def _цΗВΧщМΡΓΦШΖ():
    value = 603529
    text = __import__('base64').b64decode('VUZLXzhIUVcxYVJMM1ROVVI1YlI=').decode('utf-8')
    total = value + len(text)
    return total

def _ШφΥнЫΓКρАΝδγηЮ():
    if False and True:
        _dead_5872 = 900
        pass
    value = 489822
    text = __import__('base64').b64decode('bkVJYUpVZm5YZDJZclFFSUJjYkQ=').decode('utf-8')
    if 19 * 91 < 0:
        _dead_4534 = 695
    total = value + len(text)
    if False and True:
        pass
        pass
        248
    return total

def _чХΛыεчХцΜθОЛдкУф():
    if 10 * 41 < 0:
        pass
        _dead_6549 = 86
        pass
    value = 781337
    if False and True:
        pass
        53
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjzTRn9h6rsSCymoz1G2OA47sGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3207 = 49
    return total

def _БοАΖбабьλχ():
    value = 841770
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jnv2N1Q+7f8XGBbwy3CXGSsKvFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_4301 = 225
        946
    return total

def _ΠрΟΤЗημлпс():
    value = 483007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAr0XUE0+fk2bQakmlOGLSsG/X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗухθЩΜОнТИнΔ():
    value = 878251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETbvRQMa2b5QKj2OwFGKJ3cmxXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щЬκкΝГУψАΟ():
    if len('') > 0:
        648
        pass
        69
    value = 167738
    if 87 * 19 < 0:
        525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADb+fUUGqvgzAC6x+nOdOz8E1Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        808
    total = value + len(text)
    return total

def _эНщЦББξФ():
    value = 951727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCfIOGgj9b1SGD6qn2+qESwc8Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9079 = 646
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_1636 = 837
        pass
        _dead_6972 = 819
    return total

def _ТφьиЦφмΙ():
    value = 388235
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3/1XUIj7fo6FCWR42e0MAN71kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κоУвЙШЫνΕφВЕα():
    value = 452554
    text = __import__('base64').b64decode('bWM3RGZVY1FEV1Bia0tESG1SUE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖОщμФфςАθΧЦπ():
    value = 463031
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDbFXWk1qYU2OzeC91ycJ3Qk7zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςВЕжψеЙαХДξ():
    value = 157134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA68X2k8y4w3Alayxw++AhI1yEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬВЩδЛпбЙиЪшвШ():
    value = 353205
    text = __import__('base64').b64decode('UDlLVlpkNm95TlM1ZXQ5TzY2TFA=').decode('utf-8')
    if 86 * 37 < 0:
        pass
        72
    total = value + len(text)
    return total

def _τШΓЛуЗΞеπОΞΑ():
    value = 781812
    if False and True:
        _dead_9883 = 510
        _dead_8312 = 334
    text = __import__('base64').b64decode('aW15UGg0TDJqcEZDcjhKUzJXeXc=').decode('utf-8')
    total = value + len(text)
    return total

def _бΚЮбьГнУфΝΗ():
    value = 361437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAWxXVQayIEELyOm8WCGIgoj6VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цщСΓκΙбЧдВВЬΗβчФ():
    if 36 * 97 < 0:
        pass
    value = 73177
    if False and True:
        _dead_7053 = 994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRzGX0Iw3aEsA1e27060ZyAG1zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЬФгвΜСИлβМΨ():
    value = 313674
    text = __import__('base64').b64decode('b3JyeDNRQk8zbHE1Mkp0OHZ1WXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕκдЬτυΩБАΙа():
    value = 188916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fyn+UXgGr6xXCiC14nGGEhEKsVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыИπΡИлπβРΜΡ():
    if False and True:
        723
        _dead_7120 = 617
    value = 622612
    text = __import__('base64').b64decode('RldZQmJmbHRWY1NHQ1ZpeUxfSmY=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        pass
        490
        663
    return total

def _ΓДΤψΛΛκλετ():
    value = 318324
    text = __import__('base64').b64decode('dk5XbEFXcHlfd3B3WUllQ3d2SHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦδΑηηяююжτлτ():
    value = 736971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHn2e3Ij1JcGKRau0AOcZREF/GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юΒΦПнНЭЖЦр():
    value = 707518
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx6xalBsyIMIFSmBw0WfJSl71mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΠΑнкΩΣеЪζ():
    if len('') > 0:
        216
    value = 156754
    if False and True:
        _dead_8903 = 136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Inn0Wlc9yrAxOCyGzm6FAwMo9nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9572 = 606
        351
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8471 = 575
        _dead_2255 = 623
    return total

def _ЯΤωьΛμТжЮШΡβσ():
    value = 96564
    if False and True:
        _dead_9202 = 966
        pass
        pass
    text = __import__('base64').b64decode('S1ZmZlFhanUwWWFtR1RUR1hfSXE=').decode('utf-8')
    total = value + len(text)
    return total

def _κЕПркжзЛ():
    if len('') > 0:
        pass
    value = 516473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR7hXFo47fsbIF2B/HGUGD0B7W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КνйυМыЛηπΩΩкΔмε():
    value = 151020
    if len('') > 0:
        pass
        767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAz9PAMpz4s5aQaw7FuhATI70EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1782 = 594
    total = value + len(text)
    if 49 * 68 < 0:
        pass
        pass
    return total

def _ΞаЖХШшφжψуΘиъδОх():
    value = 393220
    text = __import__('base64').b64decode('ckxCa3lJd0l3aWl6MTA4VHRXRk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩзΡΠδбИΝрμМмΣε():
    value = 462943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAPOf2spx4kRFQeF2XPFPnYY5l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        627
        _dead_8877 = 649
        pass
    total = value + len(text)
    if False and True:
        pass
        549
    return total

def _ФшлΦωΙДкХ():
    value = 980440
    text = __import__('base64').b64decode('WTFNWmljakhJN1VrUlJfaGJwMWc=').decode('utf-8')
    total = value + len(text)
    return total

def _θηЪПфЗΖшΤнЫοыΧΤ():
    value = 104952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwuwPX44rvhVICupxny5O30B1n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сЪыΕфЙдΛ():
    value = 751889
    if len('') > 0:
        _dead_3680 = 698
    text = __import__('base64').b64decode('cHRvVmtVN1liWXRNSG9BNXZTMjA=').decode('utf-8')
    total = value + len(text)
    return total

def _лΩЩСЬсΒЦΣΗвХ():
    value = 328752
    text = __import__('base64').b64decode('WVR3c2dZOG5LNmYzdFhjVVp0b2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ВсαψΜΕГхεнυΞыоσГ():
    value = 690325
    text = __import__('base64').b64decode('dkhpZ1NJYUV6bDFwaUllNFBIYjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _νπЙΕщрφш():
    value = 69153
    if 91 * 69 < 0:
        _dead_8689 = 705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnzIR2sQyoVXPRi66X+yOXUWsz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ψцлμлюЮпЗЙΠП():
    value = 671421
    text = __import__('base64').b64decode('S0hJdHFSVUhxWTZLODdGOVBjUjE=').decode('utf-8')
    total = value + len(text)
    return total

def _мΓηГПΟЙмж():
    value = 779871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyzGNwMB/aouMiOr72aJJSwh4X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓσδщхфμчС():
    value = 387842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCPpUVkD6I8lFSa341SpYw0Y41k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωнμψΨκдсРд():
    if False and True:
        6
        _dead_3628 = 786
    value = 559825
    text = __import__('base64').b64decode('dGFJYVhueU1OYzdtTUFuTmtRU1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦчтЮΛζηШЦοхц():
    value = 433471
    if False and True:
        _dead_6771 = 321
        629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQe1Xn4f5pgSHiCNkEa1OT8791c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΔΟэЪΠПЫе():
    value = 281310
    text = __import__('base64').b64decode('QlllYWpHQW9SQU9zU2JtcUp6cmg=').decode('utf-8')
    total = value + len(text)
    return total

def _υοωъΡыςμΞψПΖъД():
    value = 467475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxzzUUEg7Pw3Ow26z0HEPHMX4lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΒХτДЗΧЭцФ():
    if len('') > 0:
        765
        129
        _dead_4324 = 5
    value = 482320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjW1ZEdty5hWPiu3+XGlBSQKxnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИμшАΟхшυМРΖыТξцΒ():
    value = 346119
    text = __import__('base64').b64decode('bjhPVWphNkpiOEdmNTE2Slc3Nkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ъашйыЗΖψοьИЗκ():
    if 91 * 62 < 0:
        pass
    value = 193139
    if False and True:
        664
    text = __import__('base64').b64decode('WTRYTVI2cDV6eTdBcUNWbmVEZ3o=').decode('utf-8')
    if len('') > 0:
        _dead_6925 = 84
        _dead_8223 = 374
        249
    total = value + len(text)
    return total

def _ЫΛςШΒДЩскΧя():
    value = 841803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSS0ZEYP+4sQPgCmnFGcIHU30EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΦνнЭеяЛсΩкχХΩПρ():
    value = 820090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISq0aAUe8/wkDRuW0mWhEiEasjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЖЫупοЗωσΥБ():
    value = 954232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3r+fn0f+LIJAl+x5gWyDA17s1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΝйДΩщсνе():
    value = 926547
    text = __import__('base64').b64decode('ZXZJdWxjaXJZSFdXM3lhQU02NFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘБΞХЭηЛΠαяеε():
    value = 176041
    text = __import__('base64').b64decode('ZUJhTEhvNEZ3Y3RPV2g5dmxiSkY=').decode('utf-8')
    total = value + len(text)
    return total

def _μРсδБСΓλеГюΩО():
    value = 365222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3vpeGcB77gNDhWW4ASUNhos50c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 45 < 0:
        807
    total = value + len(text)
    return total

def _ΕζзΨвξΗЗСУΧ():
    value = 604420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCDnOnUr97gqCj+y0lWjORIMsVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 38 < 0:
        pass
        pass
        212
    total = value + len(text)
    return total

def _ΤеюКΥδΡπьΜςлπΖЗ():
    value = 637502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjrpQ2Y8/LAJPC30w1OdLBc5tn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 72 * 99 < 0:
        pass
        pass
        _dead_5005 = 858
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 2 * 76 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    _dead_4705 = 984
    543
    147