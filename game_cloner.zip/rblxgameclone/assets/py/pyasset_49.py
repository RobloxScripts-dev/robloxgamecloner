#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _УЗЦλшηЛОтКβаΩ():
    value = 73710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCrlNngf07IBIj+J2VeiAxUG8GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙШεуΚΣнκьΙβцΨη():
    value = 872465
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwLISFYpqaMHLVr3yk6AEjUH4X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρчΗйΓхχяСкх():
    value = 781575
    text = __import__('base64').b64decode('WmpHem1GZzJnVlo5NVdLU3Bab20=').decode('utf-8')
    if len('') > 0:
        992
    total = value + len(text)
    return total

def _ΧечЩщΚхя():
    value = 254681
    text = __import__('base64').b64decode('aVhmUlNGeEw5aTRHb1NUR3lkWnQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if 62 * 85 < 0:
        _dead_2068 = 515
        _dead_6239 = 937
        174
    return total

def _ЫЬЮπОКκΔщ():
    value = 905779
    if len('') > 0:
        66
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCL0Pno8qoM2GF2IxkyRGQwByT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЮФΖФГщъдΡюυτη():
    value = 455613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQfVR1gf67EbMS30+m61PSY793o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΘЮητщΓΒ():
    value = 456055
    text = __import__('base64').b64decode('Q1BicmdGSnR6cnlkdzh6YmJqX28=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЗАРЛпλЗС():
    if len('') > 0:
        827
    value = 766041
    if len('') > 0:
        _dead_1896 = 368
        _dead_8301 = 936
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgaydEMW6pkSNQTx5lOTZAE713Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тμьжлщΖΡКПжэЖоЬт():
    value = 868557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTzqUWQS9PgqFD6GnXGnPgsQvD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФυЭжЬΚσй():
    value = 311126
    if len('') > 0:
        120
    text = __import__('base64').b64decode('Z0lRVDAyVUpjSEk0TlNCczdZZnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ДУъвΝиφЮΦя():
    value = 746248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fgy9XQcy255XHBav5FHDPTIs/kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βςΥιйυщΔхыЛНг():
    value = 806520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg78OAYe+o4lbT678UCDAH0f4z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _βεптщΘΩФεςβВΦчΟщ():
    value = 53857
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCbIWUcJwbJTP1mmnFC4FTUowWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηЙοЩсЙΩωЙ():
    value = 949166
    text = __import__('base64').b64decode('b1BOTEllc1B2VDJBRWExcW5DdmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _καЩГЗΠΖοаигЯР():
    value = 266182
    text = __import__('base64').b64decode('dDN2TkV4aTdkSjloQVEwZndMQzM=').decode('utf-8')
    if len('') > 0:
        _dead_3457 = 695
    total = value + len(text)
    return total

def _νζБФГГйНшЖЧΗ():
    value = 686395
    text = __import__('base64').b64decode('UExfbWp6VUZMWUtTd0U2Rlo1Mkg=').decode('utf-8')
    total = value + len(text)
    return total

def _υЕпσΒλвτΙΜЕщ():
    value = 439027
    text = __import__('base64').b64decode('WUZTaFVaTWNXVEpxV1RHeGtWb20=').decode('utf-8')
    total = value + len(text)
    return total

def _СХΒсШνЕелжыι():
    if False and True:
        pass
    value = 671121
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EirRelUo+/smMiOJ0GGgLi9312g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШЫΗЗмгΔТбρΨΤ():
    value = 39699
    if len('') > 0:
        673
        pass
        pass
    text = __import__('base64').b64decode('WmdpRFQ3OWk5T3FuQjRGVFd0VHU=').decode('utf-8')
    if 32 * 53 < 0:
        pass
    total = value + len(text)
    return total

def _МЯЖγΝеЬκеи():
    value = 932057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyXUTH8+q5EvLSeQkGa5ZRcs1WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΘоЧмоΗщΔп():
    value = 387044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgbNeUZv8pcXKF2U+QLDJ3EZzl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛСцΒΡЪχТΝΤО():
    value = 87683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iy3ha3wQ/bsOCBr2kQWFJzMn5V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 48 * 26 < 0:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_9156 = 172
        pass
    return total

def _βжРΒыБИй():
    value = 656434
    text = __import__('base64').b64decode('VlIzQTg4OGhGREQ1dTZPMXBtcVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _хьεΙΖΜДБнΖΟΙЪВη():
    value = 538496
    text = __import__('base64').b64decode('WGhnN3BsZzQwbVNFaE1UcjUyTGs=').decode('utf-8')
    total = value + len(text)
    if 68 * 6 < 0:
        pass
        _dead_4954 = 270
    return total

def _чΠДβΝΘТЩιλδВЗΡκч():
    if False and True:
        pass
        pass
    value = 824771
    if len('') > 0:
        783
        _dead_8421 = 512
    text = __import__('base64').b64decode('elN3VjZVczgzeGVqazNRVm5OU0c=').decode('utf-8')
    if False and True:
        120
        _dead_7867 = 997
    total = value + len(text)
    if len('') > 0:
        458
        _dead_7348 = 742
    return total

def _юυЙвтιΓЪας():
    value = 708692
    if len('') > 0:
        674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAG3fEg42JhVDiac51nHAzQJ1Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αБыСьфИΠ():
    value = 335296
    text = __import__('base64').b64decode('dFFhc2dfYUZjcWdQZFQ5aVpvcWo=').decode('utf-8')
    total = value + len(text)
    return total

def _МЖйзчРπБψЖΠΚв():
    value = 702011
    text = __import__('base64').b64decode('UUZsMF9abzdxamFTYnU5R3dVYXo=').decode('utf-8')
    total = value + len(text)
    return total

def _МвыκΞБΟγ():
    value = 819534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiPFfUU426JSFhmuyWC/Yx92xUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓШЕЙясψАυ():
    value = 212129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXrxRQgr85syGQGi3lzHBxYkvD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_5644 = 876
    total = value + len(text)
    return total

def _ЦΒозνУцЖκТ():
    if False and True:
        596
        _dead_6514 = 313
        _dead_4364 = 863
    value = 179128
    text = __import__('base64').b64decode('UXRoQ1I3SE5ucFNCZmJrVkFpeEQ=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΘΧΥКΧпωШ():
    value = 978357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KibFRmMq9YwENwWl0HHBOHw40zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЛυΓΗцΘМХм():
    value = 163997
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn7xP3Uu6b0CCiuxz2edPnUD4mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςнΘКСΧоВгΘ():
    if 64 * 66 < 0:
        _dead_5289 = 723
        pass
        pass
    value = 517231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx7TYEAu36UhAwKy8nSBBionyVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙыΑεОДΒеΒω():
    value = 255129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQXhWGspyoFTEQL78FLGFy0ZvUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΠθβФξДЧрΝΗω():
    value = 955047
    text = __import__('base64').b64decode('Y0hUeG5NQ1IzZTBHQTZhVHdfTXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ТХъЬδЛβЧλ():
    value = 102736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCbiOXMXpo9aMQKvwA++JjJ8wUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цуΟяазеηρ():
    value = 863630
    text = __import__('base64').b64decode('QllHQVJxUk1rbGtMUE15eFozdVI=').decode('utf-8')
    if False and True:
        616
    total = value + len(text)
    if False and True:
        _dead_8221 = 834
    return total

def _ΕШЖΖАμЧЫшΕσΜηЧΖ():
    value = 764097
    text = __import__('base64').b64decode('S2hHcVRwbzlMYkI3aGJoZW1KY08=').decode('utf-8')
    total = value + len(text)
    return total

def _лщσБУγΣУ():
    value = 621929
    text = __import__('base64').b64decode('dXVNSVVadkszSmxIWWdsSlZXX2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЭАБыФАΘЮжνэ():
    value = 196901
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzW3NggN0aMIKwu37G+ZHwYKylo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭαягΧТФФбΟ():
    value = 882290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR3DbVUvqo4wCSDx62m+Lj8A/Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒсфыкοφΖΡЙвнκι():
    value = 984197
    text = __import__('base64').b64decode('SmZFXzNKRk1ueUhDZWhjQzRubXQ=').decode('utf-8')
    if len('') > 0:
        _dead_8862 = 1
        112
        _dead_1158 = 828
    total = value + len(text)
    if len('') > 0:
        835
        pass
        pass
    return total

def _жγАСДырэт():
    value = 351681
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDfAPUEL7qsiODeOnkygOg43yWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яРТэТЖψфЫъ():
    value = 38874
    if 66 * 73 < 0:
        960
    text = __import__('base64').b64decode('WDRSZkJXaWpIcWhtZnp6bldwWWc=').decode('utf-8')
    total = value + len(text)
    return total

def _рυФΘУθΥΘρГυΨ():
    if 30 * 28 < 0:
        pass
    value = 517971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwrgR0kt54EiKimv/AScFgkm0WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фмΣΖΤοФεοη():
    value = 925491
    text = __import__('base64').b64decode('TENTaXB2NmZscW9Rc3BEa0NpWE8=').decode('utf-8')
    if False and True:
        _dead_3016 = 711
        364
        18
    total = value + len(text)
    return total

def _ισыυНХргξυ():
    if 17 * 54 < 0:
        966
    value = 335938
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyTiSQEe1ZwJYy6iwQK+Lg0nxTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥХШщЬБТΞΑΘΑкЮ():
    if 75 * 8 < 0:
        228
        _dead_6680 = 34
        _dead_2834 = 690
    value = 817095
    if 24 * 59 < 0:
        856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSTrYVQO7Z0aYwq12WSUOwclymA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        545
        pass
        _dead_6339 = 269
    return total

def _ΑΚхγЪξιВζтШФωυΝ():
    if 75 * 71 < 0:
        pass
        _dead_3832 = 180
        _dead_2416 = 58
    value = 439035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBjtWn0Y9vwnEyT36QKILS8c3lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        982
    total = value + len(text)
    return total

def _ΧЕрхδФχшцβΓβΘδΗя():
    value = 611302
    text = __import__('base64').b64decode('SUl3MUMzMmN0UGZzMVZjVnk4azU=').decode('utf-8')
    if 10 * 96 < 0:
        _dead_4780 = 540
        _dead_1696 = 591
        pass
    total = value + len(text)
    if 13 * 46 < 0:
        835
        _dead_1218 = 853
    return total

def _дθпΗгεвНЯσΧдФ():
    value = 739249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lne1eHoxyosMMzq63X2/IwEE0TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΕКщзфРВчΦπΟ():
    value = 804664
    text = __import__('base64').b64decode('VXBtMDhkS1hVQk1FY3ROR0FtUTE=').decode('utf-8')
    total = value + len(text)
    return total

def _оφФκэяΗυφ():
    value = 337830
    text = __import__('base64').b64decode('dnNiRm1WM3VqQ2xFdUtMdUJVTDY=').decode('utf-8')
    total = value + len(text)
    if 96 * 50 < 0:
        pass
    return total

def _σЗДΑΝЪяΜкЦΖΔшΝ():
    value = 610984
    if len('') > 0:
        _dead_4010 = 816
        _dead_1822 = 47
    text = __import__('base64').b64decode('czhCdGRacjlYQlBtTU1vVHRLZXc=').decode('utf-8')
    if len('') > 0:
        _dead_3896 = 266
    total = value + len(text)
    if 3 * 73 < 0:
        140
        701
        pass
    return total

def _ΛЧРЦУЯτЦимχФΨчЫ():
    value = 657169
    if 57 * 76 < 0:
        238
        225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCrKQHwBp40nEz+U8lmkASgA0lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_8129 = 508
        _dead_5770 = 620
    total = value + len(text)
    return total

def _кΔЫΖЛРεΥψпр():
    value = 665663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw78YWNo1v8VbCiO6wKvZC8fwTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤзЩцннэзδЛΥЮψπрз():
    if False and True:
        _dead_9847 = 733
    value = 546178
    if 23 * 73 < 0:
        174
        pass
    text = __import__('base64').b64decode('R0M3Tm9ZQkdpdjFSd0MxdmRROFU=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_9937 = 531
    return total

def _ΙΚЯЩΛΑγОчΠхЮъΨфΣ():
    value = 426179
    text = __import__('base64').b64decode('RTlkOE8xcEZUakJzZkxvUVRIbWE=').decode('utf-8')
    total = value + len(text)
    return total

def _лЕΓАιхыЪηζэ():
    value = 894011
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzvJeVg7y65WKCj1xXmdYg1+6ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 13 < 0:
        _dead_4545 = 196
    total = value + len(text)
    if len('') > 0:
        _dead_6873 = 941
        pass
        535
    return total

def _ьЮΥБццКΙΞ():
    value = 89081
    text = __import__('base64').b64decode('amVNNUw5R29SNkkzbDdTb3V2UFM=').decode('utf-8')
    total = value + len(text)
    if 34 * 45 < 0:
        pass
        _dead_1872 = 964
        _dead_4305 = 524
    return total

def _СδзСлЕΛжΟφН():
    value = 576143
    text = __import__('base64').b64decode('RjR1TG9IUWFPcXhtMjRzd2h1Tmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦιЬγХвКфТΤΤτшн():
    if len('') > 0:
        pass
        pass
        pass
    value = 884866
    text = __import__('base64').b64decode('VlZ4cWh6bTg2TUgxRFlaUEpJTHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪкКΙεюΟΖσ():
    value = 500258
    if 52 * 75 < 0:
        410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABW9anIG+LA5EgGk7H28LXIk62g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        442
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        599
    return total

def _ШхэΘςΜΔΛЫτган():
    value = 983822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj3vPWMc17IXFQmA0F+aISg/6z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜξвυЬιλНМГ():
    if 64 * 67 < 0:
        233
        pass
    value = 479449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwDlQFgAyqAFHV+05GnEIQkAyEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГВξξδυЬчΥσъεрбΒ():
    value = 722189
    text = __import__('base64').b64decode('RW51Z3Q2azRXU2dmSDk5bmttbXE=').decode('utf-8')
    if len('') > 0:
        _dead_4493 = 825
    total = value + len(text)
    return total

def _еНоЮТЧЭОξΥαйЧΕ():
    value = 564698
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCeyfXsu64wQDziP21STFREcsEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кфДСщаыаξвКζЦ():
    value = 757559
    if 35 * 68 < 0:
        pass
        pass
    text = __import__('base64').b64decode('WDRHTTNhZFF0RXczQjdvanA3aWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡВΒЙЬЭλλТηΣбΓ():
    value = 425316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSq9Xn8f8IIsEwCb/1y2ESEgskY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иОΓΩхБШОЕ():
    if 90 * 50 < 0:
        _dead_8318 = 961
        pass
    value = 194435
    text = __import__('base64').b64decode('WmtMek4wWGpjRzh3Y1FfSUVpR00=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΧуАрдкιрйτΙ():
    value = 917268
    text = __import__('base64').b64decode('ajU2MWhsblhWS2NvZzRFdVNETWI=').decode('utf-8')
    if 89 * 43 < 0:
        313
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        846
        pass
    return total

def _ξяАΗΝЧψχФΠУЖеςап():
    value = 181894
    text = __import__('base64').b64decode('cXpJanhDbWVySVNrMGtNaHF4Z1o=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        398
    return total

def _σЕΩУицδΕижΨ():
    value = 964557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhbnZXoj8K8gEh2c0QOSbR0qsVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕЛУφНΝуЦфП():
    value = 212844
    if len('') > 0:
        29
        _dead_8717 = 76
        _dead_4898 = 847
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCnnbX48+vgKbiuk6X2gISd55VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6549 = 581
    total = value + len(text)
    if len('') > 0:
        _dead_7043 = 136
        _dead_2689 = 66
        pass
    return total

def _ΚβЗщмДСΗΓζ():
    value = 851048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAT8aHod2LEBMCWa0ACDGSM46WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΨЙΔθμяКЭρюкрΕЙ():
    if False and True:
        pass
        pass
        _dead_9106 = 433
    value = 712135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESbeNncg+opTaByNxUa4P3wH8zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _имЕАαТΩъУΡтΧиτ():
    value = 955874
    text = __import__('base64').b64decode('WHVzVEh5aWxGRTBRWDFYSlg3ZEs=').decode('utf-8')
    if 92 * 99 < 0:
        _dead_9797 = 242
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        929
    return total

def _уυπТрΒыхсΨ():
    value = 860272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR28VFMA/INTEjiM+3m4OCN+zmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        571
        pass
    total = value + len(text)
    if 61 * 30 < 0:
        612
        _dead_6101 = 488
        _dead_2466 = 916
    return total

def _нЯдБэγФщб():
    value = 548674
    if False and True:
        954
        _dead_5620 = 51
        258
    text = __import__('base64').b64decode('Y0loZDFORTFrcW1YODVPcTFRcE8=').decode('utf-8')
    total = value + len(text)
    return total

def _υйΖμйнцρΛЫф():
    value = 150139
    text = __import__('base64').b64decode('Tmt5aXJrRnpnMWNhQkN5cDRndVA=').decode('utf-8')
    if 47 * 85 < 0:
        _dead_7299 = 227
        pass
        549
    total = value + len(text)
    if 2 * 100 < 0:
        686
    return total

def _юЙзцСΚэσξЪητДХβ():
    if 7 * 100 < 0:
        _dead_5897 = 451
        _dead_8851 = 652
    value = 675806
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICLqZFwr5pIsaAz6kQSVGg8lsmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        315
    return total

def _ΗμΥγЯΖхоΞ():
    value = 215323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQTVZHoX374IMR6B5H+YC3A+y1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γсВрεβэЙΖГй():
    value = 786062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQy1T2Yw66UrHyqUwmS2O3UH6ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖωТΘΩддМωμΤπΕБУΔ():
    value = 964338
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDrdX2UK0IIlGz6T2gOKJgoj5mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        402
        122
    return total

def _ΗаюλνυΛβЯτЕн():
    value = 314018
    text = __import__('base64').b64decode('TFF2UUM5WEVhczR3X0M2UkdJdzA=').decode('utf-8')
    if 92 * 48 < 0:
        968
        509
        _dead_2135 = 230
    total = value + len(text)
    return total

def _ΡЩυКΓξЧΟоγοδч():
    value = 195594
    text = __import__('base64').b64decode('UWN5T0ZRTTVlWEZ2OXZzQk53QjM=').decode('utf-8')
    total = value + len(text)
    return total

def _щκмΕτδнθΔ():
    value = 594342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRDOQ3A7+4YsHhmmymW3GHAuwjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЯНΦЯΧΙπЯσИωλΛЖ():
    value = 365757
    if len('') > 0:
        _dead_4159 = 780
        _dead_4491 = 275
        333
    text = __import__('base64').b64decode('c0tpNXFCc29VZWFrS1BiNzJVVHk=').decode('utf-8')
    total = value + len(text)
    return total

def _νпΒуβЩφφ():
    value = 396289
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR7UN3Uqy4MwDFuh4E6iHBx8wmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пιРΝΥрΧХ():
    value = 80564
    text = __import__('base64').b64decode('RF85ZGVsZUU4bzBaVnI5VXFQUkk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7033 = 176
        _dead_2621 = 738
        698
    return total

def _пцЪΘτВΜИρΨЭШ():
    value = 101108
    text = __import__('base64').b64decode('R3Z1SkhwcldjVEw1NUxqM3lKa0w=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3060 = 993
    return total

def _ншΜЭεΦδрМв():
    value = 864822
    if 88 * 17 < 0:
        _dead_6301 = 171
    text = __import__('base64').b64decode('anhRdkw2anFJeGkzZ0tWZmJLRjA=').decode('utf-8')
    if False and True:
        _dead_1816 = 333
        362
    total = value + len(text)
    return total

def _ЗπΒкΨЪЧΨеΔσΡЧ():
    if len('') > 0:
        _dead_3688 = 724
        _dead_8950 = 331
        611
    value = 628706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgzCPgVh7/wzbyuX5FOhMz8J/Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦθΙхБΖцЧЪбηм():
    value = 586611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LS3nR30bzbFTGTWN+nC5HTU14T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        89
    return total

def _чЗνУТКδχаΡЬбιСС():
    value = 684191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3fIS24A+qkCbyT62QWEHwAe6Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УтоюБιбМ():
    value = 887822
    text = __import__('base64').b64decode('QnkxYzdOSTBmWkVKZ0pvWEkzTHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ωСαΔВфЖсЛПβшжψс():
    value = 37720
    if False and True:
        870
    text = __import__('base64').b64decode('bkxVMnBMTTJEMHVMZDBtd0ZKU0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪЮБΖШΤНσХхэζΒЭγ():
    value = 517810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExXcfkkqq4dbEgaZ4l+WYQca4EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 30 * 4 < 0:
        _dead_5414 = 922
        95
        pass
    return total

def _ΑтρΛЛЬЮΧδχ():
    value = 153953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M37DXGE02LooNwKXxlG+PAN2/G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИχΑχТξТΒ():
    if False and True:
        537
    value = 656278
    text = __import__('base64').b64decode('RXVMOUE0R2RxUWNtTmdCUkNfWXA=').decode('utf-8')
    if len('') > 0:
        _dead_4332 = 606
        pass
    total = value + len(text)
    if 74 * 91 < 0:
        pass
        _dead_2604 = 531
    return total

def _ΟαΖЦиΙοαч():
    value = 246510
    text = __import__('base64').b64decode('ZWZScjhIM3BzQ2J3MlNPTWsyRnk=').decode('utf-8')
    if 32 * 41 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('cg==').decode('utf-8'))
if 67 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()