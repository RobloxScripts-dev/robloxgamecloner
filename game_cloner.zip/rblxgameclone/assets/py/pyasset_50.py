#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _зЯΛΤΩхъыχдпσ():
    value = 109155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bzr8RUcWraU5HFqqwFykGRI4w0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гЙчНΟйЩΨЫЧЬп():
    value = 300833
    text = __import__('base64').b64decode('ZWJPcEowUG1xMnRXekJqTTgxM3E=').decode('utf-8')
    total = value + len(text)
    return total

def _цПЮηдππдΠЦΒ():
    value = 857270
    text = __import__('base64').b64decode('a2pBN0NnWHVjT2t4ZG1YQjV0Wko=').decode('utf-8')
    total = value + len(text)
    return total

def _йΣхиХηΩЯΧЪО():
    value = 118745
    text = __import__('base64').b64decode('dHFhNUZCYzVuZzlwT254bnVBUWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓфκрΜλΝЦιЭч():
    value = 476471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kn6yXUQ457oAOF+Kyl2EHHANxVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НФχχКιпЙЛю():
    value = 140360
    text = __import__('base64').b64decode('TDZneXE2VHhjTV9NQl9xN1hZOVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ААΞξГШΤΖкфΔΔΒКΤ():
    if len('') > 0:
        34
    value = 990414
    if len('') > 0:
        406
    text = __import__('base64').b64decode('YUR2Z1RWMnZTT0REN1NleTZaY1Y=').decode('utf-8')
    total = value + len(text)
    if False and True:
        528
        _dead_8286 = 684
        pass
    return total

def _ГΨПеγΕщΥΣЗб():
    value = 754785
    text = __import__('base64').b64decode('Q0N0YlhrQlRzUDBqZHdJM0NWNGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑфэКΙУЪρΤЯСδξД():
    if len('') > 0:
        767
    value = 40415
    text = __import__('base64').b64decode('cWg5T1BYNGZoSGtlS1pkRTdOX0g=').decode('utf-8')
    total = value + len(text)
    return total

def _хрСκςμоγΨщ():
    value = 764907
    text = __import__('base64').b64decode('SkRQa0VJT1lKc21nWm5FVEo1NEE=').decode('utf-8')
    if 5 * 3 < 0:
        pass
        165
    total = value + len(text)
    if len('') > 0:
        _dead_9334 = 621
        pass
    return total

def _ΑЫШдйΖЛШМйЪпΔΘΨ():
    value = 405526
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CT/LSXxqz6tSNz/32n/FZAAq7zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡшУэЖΨЭСКшιΥчΙЩ():
    value = 366737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwCzRlM43a4uDyH00Q+1bD0W7Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4180 = 237
        231
        228
    total = value + len(text)
    return total

def _ИΩУпябЪраЖζЙθжсП():
    if len('') > 0:
        pass
        pass
    value = 723207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwLiPlQ21oARAwCSxHfFB3I63WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βШнпΜΞЧжЦΠЖФΝΣк():
    value = 600673
    text = __import__('base64').b64decode('bWFfQ1NxZkUwRTVSbDVOTWgxcEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ОεΥДШХРΚ():
    value = 542884
    text = __import__('base64').b64decode('VjJuT3FpRGFtc0Y5TFdvTWIzbEM=').decode('utf-8')
    total = value + len(text)
    return total

def _онΟьктяΓΧηΕ():
    value = 883975
    text = __import__('base64').b64decode('eGxGMDdsVHN5ekRBT05sNTRfVnY=').decode('utf-8')
    total = value + len(text)
    if 72 * 78 < 0:
        pass
    return total

def _УΠЙσПυоΞяΥГ():
    value = 252706
    if 17 * 90 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET7GfUBs8K8FDwun8G6gLSIh02k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        247
        813
    total = value + len(text)
    return total

def _юХСЬдτеАΒΧιНο():
    value = 4996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQrWXXUs+vs6OAS7nHSaEBwF10k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖσоекψКвΗФ():
    value = 26446
    text = __import__('base64').b64decode('ZlFYYlhmaEhGekxvUGZseDhyelM=').decode('utf-8')
    total = value + len(text)
    return total

def _кРДФΤζζь():
    if 88 * 93 < 0:
        pass
    value = 687751
    if 1 * 43 < 0:
        575
        _dead_7712 = 96
        _dead_9327 = 788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw3WalA8pv0lKx6NkGm6PhAVt2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уΓЕΑзДаδХтβПшТГ():
    if 83 * 73 < 0:
        _dead_5939 = 485
        _dead_9451 = 438
    value = 912425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Liy8QAE7/KkLHCSx4ny3EwQk8lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        929
        pass
    total = value + len(text)
    return total

def _ЬиδоμΡСΓф():
    value = 706892
    text = __import__('base64').b64decode('Y21DWkltWlROTGRzVWJGcXpmWlA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3117 = 108
        549
    return total

def _υмФруοЩэΒ():
    if len('') > 0:
        _dead_3251 = 704
        140
        _dead_6121 = 16
    value = 351488
    text = __import__('base64').b64decode('SlN1UGM2YXM5Rjc0Tmtlajk3c1Y=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8750 = 792
    return total

def _ΣΧЗςТШшΣφθРъΒχζс():
    if False and True:
        _dead_1217 = 517
        _dead_7358 = 147
        809
    value = 998005
    text = __import__('base64').b64decode('eUsyVk1WckdVWmFPbUp0UjZ1Umg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        388
        6
        594
    return total

def _ΝЫДфПΛΦηυНεσ():
    if len('') > 0:
        pass
        370
    value = 514126
    text = __import__('base64').b64decode('SFA0a0I3ZVhFYnI2SGc1eklqemM=').decode('utf-8')
    if 57 * 34 < 0:
        pass
    total = value + len(text)
    return total

def _ХτυξυккοВΑ():
    value = 606878
    if False and True:
        204
        994
        _dead_1098 = 843
    text = __import__('base64').b64decode('VGVrV0JRMkx2aVZ4NV9BWVY4blg=').decode('utf-8')
    total = value + len(text)
    return total

def _фьнТЗуЗЬы():
    if False and True:
        pass
        pass
    value = 630473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz7xVAEA2aZSHwq33XzCJi8evEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3356 = 930
        537
        _dead_3635 = 997
    total = value + len(text)
    return total

def _ΡфφσΦΙнΟ():
    value = 184661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy3pPEZh0703OCSV0nGnOxMt1nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _тХЗИкИЛщθУФфκАο():
    if False and True:
        pass
    value = 944101
    if len('') > 0:
        183
    text = __import__('base64').b64decode('b181ZFVtOWc5UlFVN1hnTWFpR0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΣνШΤΗгΣЩаγйηξъщ():
    value = 294063
    text = __import__('base64').b64decode('UTBrT08xa3ZOSUVTd1JOS1F0Yms=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖюЛМаΜйηКЕвπх():
    if False and True:
        _dead_9682 = 850
        817
        973
    value = 682873
    text = __import__('base64').b64decode('a0pjcWxVQnJ3WHJMc2JoRnhlYTA=').decode('utf-8')
    if False and True:
        pass
        _dead_9325 = 392
    total = value + len(text)
    return total

def _ЯкηУяΨоΞцΙλ():
    value = 237186
    if len('') > 0:
        _dead_9236 = 1
        pass
    text = __import__('base64').b64decode('b3ZQTlhGMVBBWEI0UE1zM1dDZTA=').decode('utf-8')
    total = value + len(text)
    return total

def _еШοМЯйЦΑЪωТΝωБιΖ():
    if False and True:
        _dead_3761 = 364
        987
    value = 441021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgTTPEI09ZgoH1iHx0PAHSQA8jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪЖЖΙДΗχΞУλρτΠщьд():
    value = 48572
    text = __import__('base64').b64decode('RFdYeWNraE1LZUNkeEJacHpXbzk=').decode('utf-8')
    total = value + len(text)
    return total

def _фмξΨΒГНτΥΟЫΟβШЦ():
    value = 926459
    text = __import__('base64').b64decode('TnlON19VaU91UGdubVpLaUl3RUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЪнΣΠβнΟΩ():
    value = 39899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bz/ROnAPrrgQDSm76VHGNz0/wE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓУΗΣъΓνлθкΦμшГЧ():
    value = 336729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQzsenot7/gEEwin4EaGJREB03w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΗοЕωΕесσΟΞт():
    value = 455414
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXvSXUM86IMOGyWi3XCiPxUI0Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЯβЖОТγλЩЬэЫΕИΣ():
    value = 736101
    text = __import__('base64').b64decode('UDFBR3c3QUx4OTdCaHNyZXRGMV8=').decode('utf-8')
    total = value + len(text)
    return total

def _трЗΜгрΣωИ():
    value = 885238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CibeT0ko94oCDlmS2mGpF3YJ8mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟτюρШтγлΘ():
    if len('') > 0:
        34
    value = 799894
    if 92 * 90 < 0:
        _dead_6923 = 540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh7uPmcx7IkIYh2tnGypAwwawnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ахνрБφΕΜВкΒΨ():
    value = 763221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jgy8aEY++YQgbFiHmEeyBHEEymY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гζδαοΖчъΝСΠюΑΟΧΥ():
    value = 559885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K37SVlIxqZ0FGQWL0QWVHzcIzWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σξЭефшфψйΣΔЦΗЕсЧ():
    if len('') > 0:
        _dead_4570 = 375
        _dead_2000 = 949
    value = 271311
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In3yVFcU26MWYwu25GaCAS927nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 33 * 88 < 0:
        _dead_1681 = 944
        _dead_5235 = 280
        _dead_5558 = 365
    return total

def _ςЯΒВыυΤЦδΤΥбЯЮ():
    value = 910496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxbTagU85vguCVyb8nu+bT8m/Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1317 = 498
        _dead_1386 = 571
    return total

def _зРΛδσгПχкы():
    if False and True:
        274
        pass
    value = 909864
    if 49 * 14 < 0:
        pass
        pass
        _dead_2936 = 172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhD2T1Zv6bBVHTWT8UyFHgB+zGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 60 * 68 < 0:
        143
        pass
    return total

def _ΒΒΙЛξцфΜю():
    if len('') > 0:
        214
        774
        801
    value = 640972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCS3TXwS7/E2MwqA3GGdZjZ/zFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩугчΧкВκ():
    value = 645191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M320SEQd75AyOxq38kSvPDB/snc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _СХГρьяλПш():
    value = 427573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwzhQUUqxJkaA1arwVyjMxQD7Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΚΙλЙψСОЫуΘМ():
    value = 864288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dwq2Y1og7a4HYz+22Hq5NT0310I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΝчКΥуΗлΒ():
    if 65 * 71 < 0:
        _dead_7289 = 447
        _dead_8773 = 656
    value = 474134
    if 97 * 55 < 0:
        _dead_1941 = 737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KArye10/0PE8Fze0yUeFZTEZ21Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΤГΜвτцаТВ():
    value = 640858
    text = __import__('base64').b64decode('bzlZUmhWXzBtYkhIaEJRNzlEdTA=').decode('utf-8')
    if 3 * 83 < 0:
        _dead_2134 = 642
        _dead_1181 = 413
    total = value + len(text)
    return total

def _ЙΝιЩИοпνχ():
    value = 109764
    text = __import__('base64').b64decode('Slh5SjFCZV9rY1Exam9LSFEyTnk=').decode('utf-8')
    total = value + len(text)
    return total

def _δυЛΝкμωыШαСе():
    value = 720865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MX7zZn0s3YQ2FgKa7gKAMHAttWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хЖΜъЬςюрμ():
    value = 604379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTbUXgAu84YZEz2pyQ+0AXMW3EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΨεфλЩПкЫщκр():
    value = 822743
    text = __import__('base64').b64decode('UmhFeHVCVjh2M2s4cWFLWVBjbU4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΖРζρΝушашЦМщщЦΗЭ():
    value = 912171
    if 95 * 61 < 0:
        _dead_1387 = 549
        _dead_5688 = 944
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDXhfnJq+IAUDBqh5nfCZwcgvXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 93 * 35 < 0:
        pass
        467
        _dead_4260 = 748
    total = value + len(text)
    return total

def _ЕдΑГШοιЙκΨΔгΝ():
    if len('') > 0:
        _dead_1457 = 540
        _dead_9750 = 882
        pass
    value = 530139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyTFOlI/qo4KAieu61SePTMh7Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6196 = 261
        _dead_3723 = 294
        81
    total = value + len(text)
    return total

def _ΛΓЖдШοЪсΧΘκχЮэ():
    if len('') > 0:
        pass
    value = 863488
    text = __import__('base64').b64decode('WXEzNHlfQUw3OVBnaG56eDZqVEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЮРΘЙηуΚσΟЕкН():
    value = 895188
    text = __import__('base64').b64decode('V1VuZHZpMmVOcUNnOUJaaThZQjg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        25
    return total

def _δЪЪАЕτАχζΣбΤ():
    value = 616309
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3bONwcQ86dSbV+G/gCGNyN/zl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7837 = 93
        100
    return total

def _ΥцςшςУЮΧΦТλΦτΙБз():
    if False and True:
        pass
        920
    value = 119121
    if False and True:
        pass
    text = __import__('base64').b64decode('dzZhYkhoRGJvb05uUkc1Ums1Q2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦдщшγΨεЬДθкц():
    value = 483626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRi3fnlg350TABqpkFyIIQ034V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гВжуΞЕπЙБпЬ():
    value = 450455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISHpREkJqp4EPz2A0VXJOQsd900='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гщдΛΨλγμпναя():
    if 32 * 45 < 0:
        79
        pass
        pass
    value = 827565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDfoXWdtrPwHNj6J+UODDgEZ8nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΒЬйКтΗЭтиΑЖКΞ():
    value = 379962
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQ7qQkNv76wsHDfwnXmlZRotsT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΩЯΡдλΕΕСωЪшоΑ():
    value = 912642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQmzOmYX+5cBKheX8GS2JzJ/4Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΚΕТΓЭЛφΨСээсыνα():
    if len('') > 0:
        85
    value = 260260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxDuPHUt06JWFBrzwVXHOyMF41Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_8249 = 841
    return total

def _ΦзЛΛΖΠΗΖχч():
    value = 169616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDzTPn1r/J40PCuLnECqOiQD/l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нЛсψЮΩφщζΣΓЩ():
    value = 187977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AR3tWEUG1LpbbBmJ4wLDERU152o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1823 = 362
        17
        _dead_8674 = 955
    total = value + len(text)
    return total

def _ΤωБЩСηиυъ():
    value = 572431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCHKTHkY9J0nPwqykWHCGSoX0U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъεыνмΩнΔСНь():
    value = 315196
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgnjUVNo0/kTYl2SxH60Yg54y38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΤХβПурюнх():
    value = 216825
    text = __import__('base64').b64decode('cV93dE9tUmZsV0N4T0FiVXY3aHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭвΣАюхΓбτДσ():
    value = 925515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxjnTF0Ypv8pBTWz0n68bT0hx00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тСжЮнУμπХφдд():
    value = 469782
    text = __import__('base64').b64decode('b0hnMEVzUFlvbFZfX04zV2RqXzI=').decode('utf-8')
    total = value + len(text)
    return total

def _νΕдΕπхвВμ():
    value = 293377
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAbrZmYByo0nFSv24nuDM3IJzTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΙтХьΠμлЖΓфХШ():
    value = 402719
    if 4 * 45 < 0:
        890
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxW0bVkO2aJbbifw7AC9YSp35kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_3661 = 484
    return total

def _νφΥэβвΛЭъ():
    value = 741149
    text = __import__('base64').b64decode('bE9uZENVMDFZM0pja2VobkR3alM=').decode('utf-8')
    total = value + len(text)
    return total

def _οЧζмЮкδМпζУпλКχз():
    value = 83144
    if False and True:
        _dead_6141 = 799
        235
        283
    text = __import__('base64').b64decode('ZGhYMjJCNGlnUkNITGs1dDhhNEI=').decode('utf-8')
    total = value + len(text)
    return total

def _еΨΝМЧчΛηуωф():
    if len('') > 0:
        _dead_7409 = 727
        pass
    value = 518090
    text = __import__('base64').b64decode('TnZCT1dDVU9oRnJpa01BUzFsQnU=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
        326
        pass
    return total

def _бΥΩАИКЗпвьагт():
    value = 850866
    if len('') > 0:
        84
        _dead_3518 = 602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ND/wPEQO1q0CaASI0ESfNyl31nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΡσΒΠещКοъаαρТβ():
    value = 299011
    if 43 * 93 < 0:
        _dead_9907 = 615
        _dead_2537 = 496
        490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgDWQGA48oQvKgSE0XyhEA484UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩЗΛζжхЯХЙННй():
    if 94 * 55 < 0:
        _dead_6414 = 865
        687
        pass
    value = 168587
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NizjW3gG+voMYwyI4Fy/YBoh10Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΟЧмφеиМ():
    value = 927460
    if 31 * 79 < 0:
        _dead_4682 = 584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgC0aGgD0o0XLhm37XPAZA56wWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮζοπыюΣΟлΧΥ():
    value = 625756
    text = __import__('base64').b64decode('REJVSUN1Y3hFNWtmbGY5Q21qN0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒθлшВΖщΖЩΙ():
    value = 877184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXvuOl8zzLotHyG36gagCw011Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟЗγлπГζΟУρ():
    value = 253809
    text = __import__('base64').b64decode('VEVQZzlraTFvamdZcE9TSlhvN1c=').decode('utf-8')
    if len('') > 0:
        _dead_2263 = 704
        932
        836
    total = value + len(text)
    return total

def _λНΜτиэськГьτит():
    value = 960369
    text = __import__('base64').b64decode('ZkxVUkRHM0p4VVpFUnFvY2dDbzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧФФγΞиЗКξλΠυ():
    value = 505012
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxrdSkQ65K4TPSWE4medHCcc9jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ааςБбщΜЯлБЩΒ():
    value = 309007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCTcXngO3KM5YwOz73DDGRIWx1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5326 = 310
    total = value + len(text)
    if 71 * 100 < 0:
        pass
        pass
        _dead_5457 = 325
    return total

def _ъΦτρяΡΑτЙΥэ():
    value = 92717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz+zQQIP6aAyHgeryW/IbAA78Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦвЙδчЯаξГЦа():
    value = 644617
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDj8WGQJq6EgKSWS6lyFM3MNyU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΖТЩвΨτдШъвФΔУШ():
    value = 317419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCn0aQI12oYNOD+n5gKFFjEJ72k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πЕцθνКΖΝОШΧμфυ():
    value = 153429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EC3wT2ky25lRP16TnmekDgIiyEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьЧпΣηнюφΩσΒе():
    value = 525581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBnrfQYV04UGGAyOmVqzGTIh0Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        98
        _dead_6159 = 607
        61
    total = value + len(text)
    return total

def _ЙгΒОЬтΚηΥζЕцАη():
    value = 711306
    if len('') > 0:
        _dead_9646 = 263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ER7Cb3Ro5pcUKjC50FeaGAo1vVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕНπрΕγγο():
    value = 408441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3rhbWQtz/sCbCelzXynPRoQzVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 21 < 0:
        pass
        _dead_1368 = 312
    total = value + len(text)
    if False and True:
        _dead_5214 = 393
        _dead_7699 = 984
        pass
    return total

def _оХкνэлчТΠМэзВΤшв():
    value = 466840
    text = __import__('base64').b64decode('eFhYaGpNb1Rwa2trUU1BbVpWYkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥгЪΘЫξΩξΞзΩΓыΘΣπ():
    value = 325741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3exSgAX6aMzGwOznmKmHSp26Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЫЩЭδξоМωγОШсВу():
    value = 117445
    text = __import__('base64').b64decode('cDhxOXR2cnhGdUlKaTF1X09DVTI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        1
        _dead_9704 = 110
    return total

def _ΤΩЧΓΜЧыМВΑЬΤΨωΦ():
    value = 436605
    text = __import__('base64').b64decode('czBjVmV4cm9tN25kd3l5QWNPQ3I=').decode('utf-8')
    if len('') > 0:
        247
    total = value + len(text)
    return total

def _οθнЛкυδΚΜηΤы():
    value = 872511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQveY2lr0fgUMTiw4HubMwIV9Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИОσΛНφγΨжμΔБΘа():
    if False and True:
        _dead_2656 = 514
        354
        pass
    value = 898984
    if False and True:
        109
        pass
    text = __import__('base64').b64decode('Tm9MOVpQMmx2SXpUbzh0UDFlY1M=').decode('utf-8')
    if 47 * 5 < 0:
        166
    total = value + len(text)
    return total

def _νΞΒОΓΙΙтэшХκΗυм():
    value = 818668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhXOTVwx951VLRuU/mO6LBwmtlc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2530 = 824
        _dead_7686 = 18
        _dead_8121 = 741
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()