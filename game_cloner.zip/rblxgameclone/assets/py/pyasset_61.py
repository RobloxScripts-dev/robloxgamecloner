#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _λЩγжтΥйβ():
    value = 107502
    if len('') > 0:
        674
        930
        552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyDqagQ22bFTFTyvxUavJwl2y2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4483 = 228
        pass
        _dead_1177 = 571
    total = value + len(text)
    return total

def _ыЩИξбюςСяρЩоοЪЧ():
    if len('') > 0:
        _dead_3422 = 45
        pass
        pass
    value = 80253
    if len('') > 0:
        999
        717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQHdSFIg6Pgibzq5/3/AEAwKtT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нщЯйγяΙцЛνРππγε():
    value = 481835
    if False and True:
        _dead_5820 = 890
        434
        _dead_3264 = 221
    text = __import__('base64').b64decode('YlpVQ1BGb2ExekxlWDRLY2FCYWo=').decode('utf-8')
    total = value + len(text)
    return total

def _цЕΔеΗΠιΦΥчΒГарΑэ():
    value = 912570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCfxOmUT/5gBNiWt+gWhBTwjymU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7395 = 900
        284
        pass
    return total

def _ωΗψТФВьЪσφωΡхТ():
    value = 991000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDnHZGQx0IE7KCeO/3nELCA3tzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧЗукΗЙьΗ():
    value = 681041
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCDXPWM1yYslMSqU6Q+HGAEKvXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЙΖφΚγКЖяюПΚщьТ():
    value = 571246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBa9PHpo9fESEBq76wSxCwd9yn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩαΛягωΨРПΜО():
    value = 468191
    text = __import__('base64').b64decode('ek54d2FkQklzYXM1YTU2UTNkWUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ρνοΑТеУρдΥηΔХ():
    value = 84727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnboSXAX0Y0ABTuq+Q7CFh0A9lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 65 < 0:
        _dead_3162 = 108
        _dead_2966 = 202
    total = value + len(text)
    return total

def _ΥюяВШрЧжШощ():
    value = 606658
    text = __import__('base64').b64decode('bFVKTDNNNnprTThSRnFNR3NqQWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΓβτРЩΡπνЮхй():
    value = 624334
    text = __import__('base64').b64decode('RnNPam5XME9uMTlsNzRBN1E0VHc=').decode('utf-8')
    if 15 * 79 < 0:
        _dead_6154 = 808
    total = value + len(text)
    return total

def _жΕСΤΗβВΒΒСΗψВДδД():
    value = 227853
    text = __import__('base64').b64decode('ZE93alVMYjE1eExDeTlsU0dQaFU=').decode('utf-8')
    total = value + len(text)
    return total

def _жкСβλОчЫλωοлчеΓ():
    if False and True:
        560
        pass
        991
    value = 326177
    text = __import__('base64').b64decode('TFVsM2NtSE9JbEpEWHljZWdRUW4=').decode('utf-8')
    if 13 * 62 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ЕΤΟχΖягрэЖГοБйЙ():
    value = 624865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyG3QnI/xKUNGRyPnAG7JQJ51GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _овΒλθΩδΤκЫξοъ():
    value = 240433
    if False and True:
        581
        222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiXreVgb7YYhAw2C3EazYg53s0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μδпΙоΖΓИэμГκοОε():
    value = 159582
    text = __import__('base64').b64decode('YzJybE1NcE9VYkUwSk5RNllncUQ=').decode('utf-8')
    if len('') > 0:
        _dead_9759 = 674
    total = value + len(text)
    return total

def _ςγЪфςψйда():
    value = 585159
    text = __import__('base64').b64decode('azR3TXhaSkxoZmJjWE1rVl9nRVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _πυйАРΙхΕ():
    value = 868802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRb+d1Yr1KEVMCyZ3EKzF3U20Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уРΠтθΔρμΒΓ():
    value = 116459
    text = __import__('base64').b64decode('bjhKUmhsczM1aEZJNmZTX3FSVWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤφΥмЕцπΖр():
    if 91 * 44 < 0:
        _dead_8908 = 738
        584
        _dead_8324 = 748
    value = 918804
    text = __import__('base64').b64decode('cDVrd29Zb3FYdnZIUWo5a3lpakg=').decode('utf-8')
    if 63 * 79 < 0:
        pass
        211
        828
    total = value + len(text)
    if False and True:
        197
        641
        pass
    return total

def _ΞяьςρΧХλφ():
    value = 325331
    if False and True:
        575
        pass
        _dead_8464 = 625
    text = __import__('base64').b64decode('Rmw1YmJkSWw5QlBsc2FmZWVmYzM=').decode('utf-8')
    total = value + len(text)
    return total

def _δЗΕΒεЬгоХΓυбХκЛЖ():
    value = 777454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChizNnMx144FaTW0xQOiHzQW/Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬЮЫςαΔνκΘ():
    value = 167647
    text = __import__('base64').b64decode('dGxCWl9iRG50U213MXM5ZE03Zk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠэрιЕъЫμΔоъ():
    value = 374032
    text = __import__('base64').b64decode('ZjJxUlFQdEdJY3pvb3dmNm9OTFU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _бСШЮшΜФοΖТφυ():
    value = 716957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAjFWkgd1YELAgyh4nq3IwYK1jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 90 * 20 < 0:
        pass
        525
    total = value + len(text)
    return total

def _ΙΩωГжΘСιΡтТΡЖЕδ():
    value = 466576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQTLS2Zg7bkLBV6W40aECyt460w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σУΖЩπяΥМτйγъ():
    value = 870194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgbqSUEL1r4rEgK24F/GODwl6kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 71 < 0:
        pass
    total = value + len(text)
    return total

def _μΤцЫσСяСэыкΣцоΗ():
    value = 953401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyriW2MS9bFSCRihmESfHnQA4Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΠэυШМΓΒВΞФΚхУ():
    value = 1573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwrFVHIJ34dTCS2on3ueMDQgs38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩШКΟдγюΔμΝΤχвЭаΩ():
    if len('') > 0:
        _dead_3580 = 291
    value = 316251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBv1XQQx6owwMQGzywCUBAMhzDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΟΠεкбΔοΛйΖИΙμ():
    value = 323997
    text = __import__('base64').b64decode('WHhjOE5VaTJfY3F6WGhXWkdrdFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ыаΕςоΓцР():
    value = 219880
    if len('') > 0:
        288
    text = __import__('base64').b64decode('ZTBJOWx0b000UU1ENUtldW9IUUU=').decode('utf-8')
    total = value + len(text)
    return total

def _СДхθЪВΕУХ():
    if 27 * 95 < 0:
        pass
        _dead_1096 = 999
    value = 550924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bj/cWnY42J0HLwKp0HuqNnIdxWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эπчнюΗбЩп():
    value = 652382
    text = __import__('base64').b64decode('VERfVlRQY0ZvODFHRXZvSG9VNTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΥВπρЭщЛΓЫоЦ():
    value = 849704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQLPY1YdqKUzHgus4UzDJQod/FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧяεДЖяРΘςΒξХβΦ():
    value = 597610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiXAQnQAz/kBCR6T7UWVPww+s3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΟυуЮФиЯωΧ():
    if False and True:
        93
        pass
    value = 421914
    text = __import__('base64').b64decode('emZSQ094VXRXWE1vVWxEdXlPN2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ελбГιεΥΡμЕΡγωМ():
    value = 953000
    text = __import__('base64').b64decode('VWpGbGxxV2U4b01BODVDNUhqQ3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΙфВЙрγΗЗψΖзлωι():
    value = 509593
    text = __import__('base64').b64decode('VUp5T0Z3WVI5aHNHeGxuUjlFMWk=').decode('utf-8')
    total = value + len(text)
    return total

def _θюωкИΚφΒшжΖ():
    value = 977062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSLofkcvyq9SD1qS/VmiOyYOt2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 93 * 83 < 0:
        pass
    return total

def _ИВνсзДЯΘжΓ():
    value = 12534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCfmf1IY+64MOx+O7W6yZyp31EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жδЗθЧТΤζюΠпΩχ():
    value = 369670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCzKeWMR/5cUFwmtzG+FFSoc9n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΓτΠвφΩлх():
    value = 2650
    text = __import__('base64').b64decode('bFhQV0ltS2JUak1QX3g1M0tSTnE=').decode('utf-8')
    if 71 * 71 < 0:
        pass
    total = value + len(text)
    return total

def _щξЬолРыфΥС():
    value = 255423
    text = __import__('base64').b64decode('T3hlV1RnQ3pFd3J5UE1KaXdqTTA=').decode('utf-8')
    total = value + len(text)
    return total

def _йппЕЧйицλЭΞ():
    if 2 * 45 < 0:
        pass
        867
        pass
    value = 762244
    text = __import__('base64').b64decode('a3cyU3pBbk5xN1ZSNGVzY1RCWGU=').decode('utf-8')
    total = value + len(text)
    return total

def _РΓаЗжΚΤθНςрωЗШя():
    value = 384475
    text = __import__('base64').b64decode('alVFR0xCaklmeWJxaHBXOGN2azU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЫΜΨчрΖчΨνМυΡм():
    value = 414669
    text = __import__('base64').b64decode('U1F2Mk9UNHdZN0FPR1N6WmF5Ykg=').decode('utf-8')
    total = value + len(text)
    return total

def _бΑΡφΘиΦυ():
    if 3 * 12 < 0:
        _dead_1145 = 687
    value = 769472
    if 15 * 77 < 0:
        61
        pass
        _dead_5589 = 814
    text = __import__('base64').b64decode('ZjltUlRRdlN6aWlJR0pYcXpva2U=').decode('utf-8')
    if 23 * 70 < 0:
        868
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_1379 = 797
    return total

def _АСюЛнΩςΩΗψуΓВ():
    value = 969024
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax2xagAMzvhbYluzzUWYHXcX81o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΑбЖΠΦαцУнς():
    value = 101965
    text = __import__('base64').b64decode('clNIYmZ1c2pNRFhURmdQcl82Y1E=').decode('utf-8')
    total = value + len(text)
    return total

def _яΠιВθΙТюыхΑβ():
    value = 917328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A33LdGZqwZoqDT2ykUyeEScCtWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эдЪмДИλρθЭΡЮэ():
    value = 527290
    if len('') > 0:
        pass
        553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSK2SwA39PlTHQqGxEy4IzQBtm8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ЮπДЬοΕПкΩгксΝφζа():
    value = 586650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBm3bGAK+aM5b1aF4lyXNjR81E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иЭΔзьЗΥВα():
    value = 334889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eja9YXQY0YtbKweZ+QXEYjEj11Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зНΔПВσΞБ():
    value = 691931
    text = __import__('base64').b64decode('clJjNTlwOHNuRmpHWmpvZWZaVnE=').decode('utf-8')
    if 37 * 49 < 0:
        pass
    total = value + len(text)
    return total

def _кΩзчоΠахПАφЬ():
    value = 642536
    text = __import__('base64').b64decode('R1ZWNFpCZFZweHVpY0pCRElrRGc=').decode('utf-8')
    total = value + len(text)
    return total

def _дяΥкщфξξ():
    if 14 * 72 < 0:
        pass
        pass
    value = 43856
    text = __import__('base64').b64decode('eFVTbHZRQmowZW54NzVMZG9aZFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ψρΝΤЪЧшωшрφ():
    value = 437187
    text = __import__('base64').b64decode('S3V2ZnJ1azFUeXVEY2NsTFp3X0Y=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_6326 = 253
    return total

def _ъπоφяτГш():
    value = 678393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnrGSHsrqJcrHSCV2leCFhwQw3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        476
    return total

def _чмΡΣУΘζωЛшЯλλ():
    value = 807402
    text = __import__('base64').b64decode('bFF6cEtHMnczbTNxM1pkemE0STA=').decode('utf-8')
    total = value + len(text)
    return total

def _юОЗψфЙТθΜйсщП():
    value = 562754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSXPQWFu37ooDg2Gn3THBywjsmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηрΓЖвΚэξπхλшьЙнб():
    value = 780070
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXjoN0EN8KcHFCab52TDJRYH11Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яШеΟИЮθыяРΔЖТнс():
    value = 364844
    text = __import__('base64').b64decode('bFdqaENwZnFEaGVLQjFsaDBmQ28=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙθμφРюЙρ():
    value = 553595
    text = __import__('base64').b64decode('R2pWNHQwcDBkZFd2bFpYQ08yUVk=').decode('utf-8')
    total = value + len(text)
    return total

def _πππЦοСлμ():
    if 4 * 78 < 0:
        _dead_4208 = 472
        90
    value = 264199
    if len('') > 0:
        291
        856
        _dead_3574 = 531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQ7gPmUGwa0yNyP24lzGEAcetGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 45 * 10 < 0:
        pass
    return total

def _ТщΧζФПЫςфγъшφзйь():
    value = 707476
    if 48 * 73 < 0:
        _dead_6561 = 633
        _dead_4919 = 726
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyXWWUQLxIUAGTuu+HHGBDcs1GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4093 = 81
    total = value + len(text)
    if len('') > 0:
        265
        pass
        _dead_4232 = 414
    return total

def _ТηфШρψζюлμκα():
    value = 633290
    text = __import__('base64').b64decode('cmxhbXVrU1NOZnRzZXBwNU00cGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘдНΨибФκБАΖ():
    value = 426023
    text = __import__('base64').b64decode('QnpyM043Wmh1RktwQnpMcTdZNXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ωэСИцЖЯщпйιу():
    if len('') > 0:
        _dead_2352 = 401
        _dead_5173 = 895
        342
    value = 612454
    text = __import__('base64').b64decode('TFhOZFJqQzd3VmVYNEZrVkViTVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΛоΕΖКмЬомЯ():
    if 44 * 95 < 0:
        pass
        415
        633
    value = 544881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCvjTGMf+5IaPBmBxVmgOSME9jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2895 = 872
        481
        pass
    return total

def _εъхχыυХΩ():
    value = 675476
    text = __import__('base64').b64decode('Z192MlVTdThqRkFVZ3ZGaGtub0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _юЪяхШсууγАУςρΛ():
    if False and True:
        _dead_3861 = 924
        _dead_1301 = 722
        _dead_7500 = 762
    value = 151957
    if len('') > 0:
        pass
        _dead_4184 = 917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh7FTUkG/Z41DTmv206DZDcq0DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПсηΕОφΛββΞХшГ():
    value = 611022
    text = __import__('base64').b64decode('RnoxaHN6WjNVQkoxRWxFT1B1bmo=').decode('utf-8')
    if 12 * 32 < 0:
        _dead_8083 = 406
    total = value + len(text)
    return total

def _ФсБкΞЬΘΓΘΖСΑ():
    value = 632598
    if 8 * 80 < 0:
        561
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AivsVAk81aQZNTuV0ESJAXwY0Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        743
        813
        _dead_9605 = 670
    return total

def _МяΨςΨОιΓБννе():
    value = 119464
    text = __import__('base64').b64decode('bW44aGd6bzVNOUNTTTNfQlowYWE=').decode('utf-8')
    if False and True:
        351
    total = value + len(text)
    return total

def _ЯюиςφωΝо():
    if len('') > 0:
        114
        98
    value = 951539
    text = __import__('base64').b64decode('bGNTNXlJV1FWNE4xb3Ywc0MxYzU=').decode('utf-8')
    total = value + len(text)
    if 88 * 76 < 0:
        687
        pass
    return total

def _ЯЛюьσЭвΕийЖΨ():
    value = 58120
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgLcdlo20JtWYxeEnVe5IXUswGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХФξЙЗЬРΨу():
    value = 668224
    if len('') > 0:
        _dead_9850 = 215
        41
        pass
    text = __import__('base64').b64decode('WmNvczVOX1RpRWFTeGVWNkVRTmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ζИЯйΞЯЕχψτтΜ():
    value = 814500
    text = __import__('base64').b64decode('WjRtSDB3dUJHNXo4eVJOVmpFQkY=').decode('utf-8')
    total = value + len(text)
    return total

def _хΝюСτНРιθЖйπ():
    value = 585091
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAHeYmMq6JEAE1im0GmBEA4W1mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΘЕΦΒΨМосрщ():
    value = 884704
    text = __import__('base64').b64decode('ZHhzNmRGN3RBN0RPYUhJOW1DVW0=').decode('utf-8')
    total = value + len(text)
    return total

def _вШзМшαисыЪ():
    value = 80137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhzwOggv+vAPCjiK6VSBbRUd6X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓЪЮΥγрГκеσιΓы():
    if len('') > 0:
        704
    value = 500643
    if 52 * 36 < 0:
        _dead_4489 = 815
        118
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3qzZQQQ/PxUNTqG/XuoF3M1/ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΦТэΔΖνР():
    value = 414392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB3eV1kLyYIVBQW1/XyEHykYsXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧпзСΓПΟΓΙЪ():
    if False and True:
        pass
        468
        pass
    value = 48601
    if False and True:
        495
    text = __import__('base64').b64decode('UDZTdktvT1JNXzdaME0xOEVQU3I=').decode('utf-8')
    total = value + len(text)
    return total

def _θвκАμмйνгдΛЖτРР():
    if False and True:
        pass
        pass
        105
    value = 938191
    if 96 * 93 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyjMYggByP48bSWu3GSvLDZ82zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 38 < 0:
        _dead_8620 = 813
    total = value + len(text)
    return total

def _люНязЖΙДΥРΞψμЗη():
    value = 520496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITXIbG4A2YoFND+N51+IBB944j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κРΧλτββΨεЮ():
    if len('') > 0:
        996
        739
        _dead_3844 = 772
    value = 561976
    text = __import__('base64').b64decode('c1N1akllYkVfMG5PYVlmcDE5WTQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5541 = 726
        643
        451
    return total

def _ΗОΟΔЗΨЕΠθηοφΙζн():
    value = 351749
    text = __import__('base64').b64decode('QzZlRktiQ05icHIzZkRnTThYYV8=').decode('utf-8')
    total = value + len(text)
    return total

def _РбΛунИъчκΡЭЭ():
    if 37 * 20 < 0:
        336
        _dead_5662 = 688
        56
    value = 814920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCjcPWs3yoUyDQj65HGcPisGy0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙщхνдЪπλ():
    value = 660131
    if len('') > 0:
        109
        _dead_6431 = 412
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3qyV3Nq64QuKgaunEa7OxMb6Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΤβκεΠюΨπΛθС():
    if 13 * 54 < 0:
        _dead_4196 = 938
        _dead_7709 = 373
        pass
    value = 496772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB7sYEgfypctLiaG+1GJNysG3WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        292
        325
    total = value + len(text)
    return total

def _щΧУьФЛЙСΗηζъуЛЦя():
    if 40 * 37 < 0:
        pass
        pass
        _dead_1101 = 150
    value = 147906
    text = __import__('base64').b64decode('UWhLSmxRSXRSbG9NZHQ3NlRlR1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ьмκцжЕюΜЪкжю():
    value = 799375
    text = __import__('base64').b64decode('dUpMN1hLd1N6OUJDUVJiN2EzZkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑΣλΖЦБΒΘ():
    if len('') > 0:
        _dead_3402 = 702
        pass
    value = 78263
    if len('') > 0:
        _dead_5313 = 87
        961
        441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgzXTwkK8fEBMFa17Xm2Hg18t2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 100 < 0:
        _dead_5891 = 130
        pass
        203
    return total

def _ΛηщрρПцциφ():
    value = 762251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhnuWAAsqKQJIDaTzQ+0YHcm63g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖяСШξйсшЯЦмЕρδЖ():
    value = 398489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSXtSWE2740XLSOJ5WGDHXcd9Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗнитуцЮЦФХтΩтаМЮ():
    value = 562279
    text = __import__('base64').b64decode('b2F6cGF0SjFoUEpfcTRXSDVCdGQ=').decode('utf-8')
    if False and True:
        pass
        pass
        28
    total = value + len(text)
    return total

def _ψжΚШφωΕоΔ():
    if False and True:
        _dead_6933 = 314
    value = 155356
    text = __import__('base64').b64decode('T2c4QkJGeDJCSk9lU3dJWTJoWXg=').decode('utf-8')
    total = value + len(text)
    return total

def _πтэХщйβξωгδβиω():
    value = 6874
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx/GOlML0JBVMFyan0fFDgZ4sTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗιΓβΠХφΧПШςгткД():
    value = 503064
    text = __import__('base64').b64decode('dzlreFZlQnJvdzFSRjY2NUZxMGc=').decode('utf-8')
    total = value + len(text)
    return total

def _СщяΠβуοЗш():
    if len('') > 0:
        _dead_7839 = 944
    value = 565860
    text = __import__('base64').b64decode('aUxmRlA4Rm40Q1V4V0dLeERyZDc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        635
        _dead_9661 = 60
    return total

def _νХΠоЛχγлИПАшлИΑω():
    value = 743823
    text = __import__('base64').b64decode('aEFvMHBMUzBkX09kYndEb1NoMGk=').decode('utf-8')
    total = value + len(text)
    return total

def _фПгΓвφчМκγКИΓηв():
    value = 873050
    if len('') > 0:
        517
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NS68Z0k0zpJTKV+S/VyXBwEF8zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξμΓιΕДΓτ():
    value = 515899
    text = __import__('base64').b64decode('Wnpja2IxSXlYNkRXUzVNOXAxZEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ДчΨΨΔШшеИАк():
    value = 629669
    if len('') > 0:
        _dead_3405 = 884
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgXHa0gxqoUSIxX3x3PJBnUW0Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        675
        186
    return total

def _УΚΞΒσВУΟ():
    value = 125259
    text = __import__('base64').b64decode('bXJaVWtvSFFPbGU0WjZLTnkzQXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ТлЪвВνπρΟ():
    value = 965557
    text = __import__('base64').b64decode('SG15THlHb0MwX3NTWTB0Q1h5YXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝМяιЩоεюΘκаΘΖπνβ():
    value = 333123
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3rhXlQ4/YdabVeVwma9JDQ56Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 34 * 18 < 0:
        408
        244
        pass
    return total

def _ΤφпζъХΡдЬΤβМЭ():
    value = 727518
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxzlT34Rz/kUPSWQ3Fi5Bip7yW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        38
        _dead_8692 = 219
        _dead_1402 = 132
    return total

def _ЩсКгωΔοжυь():
    value = 949755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgHVWmMG37g0ah2CkX64PHUs8jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЮξсПΘЫътοΑφ():
    value = 127821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChrTR14U8p0PPiGu/kKJPDwesGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вйъπЫΠμπ():
    value = 363184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ3zRFM7zpIPLiu57V7JFyQb70E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        26
        _dead_7742 = 889
        561
    total = value + len(text)
    return total

def _ΗояΧξΓЦφЕийче():
    value = 859387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jne3ZVBs3IVWNV61xkybNhcdsUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3916 = 66
        _dead_9574 = 711
        _dead_9334 = 889
    return total

def _ыуЯςΨΥρЩσΩ():
    value = 415783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bja0Z2sb9qAFOCauzGyCLgsq5kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΘΥΙЙЯГНΡТуΧΖДхΘ():
    value = 827861
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iyq9WWAu7KcRLwDw2HKJB3I66l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 22 * 32 < 0:
        _dead_5907 = 938
        902
    total = value + len(text)
    if False and True:
        pass
    return total

def _φщρкκСυχлеЗФπΨβ():
    value = 572255
    text = __import__('base64').b64decode('dTVUX2FmQVA2VVFNc3FGNnkybGY=').decode('utf-8')
    total = value + len(text)
    return total

def _γЯΧΗΩΣЕμ():
    value = 872992
    if 88 * 1 < 0:
        49
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAXKWkcsrL87A1j6yX6ZMQ8Xtzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 21 * 76 < 0:
        pass
    return total

def _ξπгщξΓПмЫАФ():
    value = 43871
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCbTOFUrrrhXbjqFnGyZEwwLsG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 77 * 66 < 0:
        577
        _dead_3361 = 600
    return total

def _ХνлΥωГБэьδЮφΖЭη():
    if 17 * 27 < 0:
        _dead_1075 = 726
        pass
    value = 689398
    if len('') > 0:
        pass
        458
        _dead_6385 = 939
    text = __import__('base64').b64decode('UzZwUUFrWlFjQWl5bEtpam5FbGc=').decode('utf-8')
    total = value + len(text)
    return total

def _КЛΘσΘПЮшШЧθу():
    value = 602240
    text = __import__('base64').b64decode('QWlqMTgxR3Z2UGE3RWdrQ01ScTM=').decode('utf-8')
    if len('') > 0:
        999
    total = value + len(text)
    return total

def _οьйИгςФйОδуζ():
    value = 969395
    text = __import__('base64').b64decode('TmxiTU1mUGg0czhTTVlUMHE3V0o=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _оκΣπйЯαФЧяΞТ():
    value = 85112
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jjvlfgcu9I42Gxr7zli+ZxQ/5nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        60
        401
        pass
    total = value + len(text)
    return total

def _ΡКшЫηхΙХΛЩНΛЩΞ():
    value = 790498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj/lXUUq1Pg2ES6P+EOpLBA3x0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙπпΧΩΝΔΠ():
    value = 939422
    text = __import__('base64').b64decode('dVRJWnlIV05oVVpxOUFzVkVnYng=').decode('utf-8')
    if 76 * 57 < 0:
        889
        185
    total = value + len(text)
    return total

def _хЦΚпΧНкιЗψΜεΩεΦ():
    value = 297691
    if False and True:
        pass
        368
        _dead_4727 = 172
    text = __import__('base64').b64decode('TzQ0WXppM2JaVzBWMlEyQjBkc0c=').decode('utf-8')
    total = value + len(text)
    return total

def _τКσэαΙζσрТΗ():
    value = 762439
    text = __import__('base64').b64decode('cmRtY3BpUzR0SjUzOHVubFRnX0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _пΑινпуΠУμΘΑВ():
    value = 336230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjbsX2Yy5oApNVaW71zABR8etGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 100 * 4 < 0:
        808
    total = value + len(text)
    return total

def _ШаξрЧΚжα():
    value = 804107
    text = __import__('base64').b64decode('bDdXdjBRZGtCUm94ZGhxVXEyZ3Q=').decode('utf-8')
    if False and True:
        pass
        _dead_5019 = 307
    total = value + len(text)
    return total

def _ΦЕΑЮфχΙГΨατГρшζ():
    if len('') > 0:
        _dead_1520 = 471
        6
        _dead_6867 = 959
    value = 211314
    text = __import__('base64').b64decode('ZklGT0VscVpkczVjYklZVGM4ek4=').decode('utf-8')
    if len('') > 0:
        _dead_6487 = 854
        745
    total = value + len(text)
    return total

def _фБюυЩπШДΗζτжЮИ():
    value = 882784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FATVRVcx9asJPgS35Fe+IjA+vGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        551
        pass
        pass
    return total

def _йπΦЯИчΖΣбБЭтΙΛж():
    value = 104409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyXyfWQh55oILwr6606yOB99yUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 97 * 39 < 0:
        103
        942
        968
    return total

def _ыιγΘКмКΦ():
    value = 133611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHrSYlcU2LkwMSOJ42WzZR0B3kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 60 * 88 < 0:
        370
    return total

def _ΤЫсΗшιψпК():
    value = 80593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzfvaX0d9ZwAKBaNzVyKLhoq408='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ИηΑвβπпИψщνд():
    value = 834690
    text = __import__('base64').b64decode('TjFJWGdWMG9QMGgyR045OUhSOUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ζζЦЙЩπЮлУбΚ():
    if 40 * 45 < 0:
        494
    value = 175837
    text = __import__('base64').b64decode('UmZ0TnlWNU03NjhFQjBLZVdfa0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓαкЖΙψсйИИШΕΛ():
    value = 649236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxXwXl8N1vkXADyU632+LRA63Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γωьβйАвΟΦзп():
    value = 577136
    if 65 * 71 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E37UaGk+0IQFDVmqy2S0ZgglwVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 74 * 44 < 0:
        _dead_5696 = 420
        570
    return total

def _ДθьщΩΕЦΡ():
    value = 880731
    text = __import__('base64').b64decode('UldSdjlUWUs5NEdZNlRSSFlMdnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _АббΡΕцμВиБΥΩ():
    value = 281267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cg7LeXs27acADV+V+HmkC3ccymo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κмТΙлονЪМκνбктЦ():
    value = 445867
    text = __import__('base64').b64decode('R2JRUFJWZDhQQ1lkOG1VZTYyREM=').decode('utf-8')
    total = value + len(text)
    return total

def _πМиБεΟιρХоΗι():
    if len('') > 0:
        pass
        287
        pass
    value = 892139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISjpeW48zJ0CDRqy23LIBCgE4zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΙЙоτχγΨΕΕΑ():
    value = 704538
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxzUZ24ewaQobgyizHO7AjYdw2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΡσлΙшψрΓ():
    value = 454961
    text = __import__('base64').b64decode('eHJ4d19RNHZpZHk2UFZPQlJ1QXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΩыГекΦфъ():
    if False and True:
        pass
        _dead_5636 = 360
        _dead_7630 = 783
    value = 917115
    text = __import__('base64').b64decode('TFREZDdBUEYydTFkdVhGbjlGbXQ=').decode('utf-8')
    total = value + len(text)
    if 47 * 74 < 0:
        235
    return total

def _ЧДэнНШоЮΥΖγюμ():
    value = 296232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HALrfWkP15sxagiF0ASgYg4FzGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_4678 = 509
    return total

def _ГΚсьхКΜΖλμдЗНΛ():
    value = 491104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXzlOHQU2/sVGySV63KUIwok70g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦсωэθАρХГψαЪ():
    value = 53487
    if False and True:
        pass
        475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjbSYAYPyf45Ngqw4QKoIgd40X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔыДеНΧдφфΣΚεцε():
    value = 849837
    text = __import__('base64').b64decode('al92ek9HZFZROWdEOG9mUFo2bEE=').decode('utf-8')
    total = value + len(text)
    return total

def _цгΘфЮвРΟВΟФηθ():
    value = 677862
    text = __import__('base64').b64decode('cVRaR3hxRkF5TlE0OFB4MWFiOG4=').decode('utf-8')
    total = value + len(text)
    return total

def _эπЬйΚΤкУьХΔЗСЕ():
    value = 440639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgPXfmkh6I5QKgKU/ka/FnY60Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        563
    return total

def _ΠΟΡвЧЙщδ():
    if len('') > 0:
        pass
        756
        532
    value = 764970
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQzjfgMh264sPQfx4wOcGwR5wEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        138
    total = value + len(text)
    return total

def _тТУСЙвοФυΡтЙωΗБж():
    value = 457633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwXQaVAq6oAnPQ6X2GyTZXIMw0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТφПнИПΑЪ():
    value = 444191
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjmzQFYsraMtPVuX+VKBDjAW0kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 49 * 14 < 0:
        _dead_7874 = 899
    return total

def _ΩΘΒИбγΒΜрσ():
    if len('') > 0:
        pass
    value = 575564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgHXOF8e5681KyCF8Q+XOyd30Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        970
    total = value + len(text)
    if len('') > 0:
        _dead_2298 = 998
        320
        _dead_3398 = 824
    return total

def _γΒαрιΠΑъΨеЮζА():
    value = 369511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB/cb1UP8KUtACOT8lueGDUC51c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 26 < 0:
        355
        _dead_1624 = 391
    total = value + len(text)
    return total

def _ιΠΖЯВΗкБΕιЧπк():
    value = 113928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MR/eSGBt0ZBRAwb3/EKiMSF9y1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΩНЙнЛαΡПлχηΕ():
    value = 511722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS7ndFU6qJ8BGCrx+FG1AyApsDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςφшΟΕρπσВКХЗ():
    value = 813747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An/lX19g7vkbGwXw8mygYCQi82Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дьчсΦΑγя():
    value = 989127
    if len('') > 0:
        pass
        _dead_7164 = 650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTbiXnkAz6khFh2UzHi9EnUmsEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2476 = 779
    total = value + len(text)
    return total

def _ΛκКΚΝλВАΝЮξгΞΑлΗ():
    value = 143851
    if 79 * 17 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnzjZEYeyqoQFy222luxESI43WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΖΥηюβЮХΡнГ():
    value = 601231
    text = __import__('base64').b64decode('b2ZteFNxeWlFbk40VFJsZFNiZDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _φгцγСМцκρ():
    value = 338906
    text = __import__('base64').b64decode('ejI2TFI1bkxoTXJhN2E2eXJyTDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ъΣπηКсυФ():
    value = 349532
    if len('') > 0:
        _dead_5106 = 939
        713
    text = __import__('base64').b64decode('c05RT0FYTk5WTEtwdFhYQmRSSmg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        977
    return total

def _лСгπлπУΠΖВΕ():
    value = 120682
    text = __import__('base64').b64decode('b0hUVWVvUzA3bDRHTTJSQlBEd1k=').decode('utf-8')
    total = value + len(text)
    return total

def _φЮΘЮЮΕφΚΜЮδц():
    if len('') > 0:
        pass
        _dead_7451 = 665
    value = 697509
    if 56 * 45 < 0:
        _dead_6471 = 827
        pass
        pass
    text = __import__('base64').b64decode('RWdBZmRnM29BdHp0TXA1anZiSU4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        521
    return total

def _бρζЙляиьβα():
    value = 139727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzzJZGk2rJ8COAaXn3WxIxIC9ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОжΥНΥцΜЫар():
    value = 843647
    if False and True:
        32
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgrJPUA45KcyLgmCkVjIDRx9yFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ихитτАινьΓДМΞро():
    value = 668411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCjAY0dp3ZI5FQfz71LGZQIGt18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2888 = 111
    total = value + len(text)
    return total

def _ΘИпдωΥША():
    if len('') > 0:
        59
    value = 696505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDjTa2k+3IUMGCj64WOfbQEK8Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛяΣхΖνЛΠΥξВςфеΕ():
    if 48 * 44 < 0:
        _dead_3294 = 787
        pass
        250
    value = 816725
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXjJQkIJzKVTFRm25m+HARIM0GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑРрнПμуΠиΥШψю():
    if False and True:
        120
        353
    value = 645391
    text = __import__('base64').b64decode('UUJXeWQwTHJHQVBnSmo0cjhVUnE=').decode('utf-8')
    if 19 * 25 < 0:
        pass
    total = value + len(text)
    return total

def _эΠκхΜЭУсЖ():
    value = 136453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARbsSQIK1Yk1LQ2M+UKXMgQhzlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БηκБεбΩщт():
    value = 97462
    if False and True:
        _dead_8209 = 841
        _dead_4071 = 370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgHQdGU9rLAQDyG10GG8GXw5yjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΡшΗυлиιςцвЬΒщ():
    value = 537087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCziW1oo7PgXHx6OmFOFPSQN3FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5825 = 334
        pass
        _dead_2784 = 379
    return total

def _ΛΔЬХЩгеΥф():
    value = 108556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCXtX3MM74VQGQuszGyVOCMH0UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ункаДπμеΛЪ():
    value = 761860
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAPzRUAWxJtQAC2NynSvAggo42Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        640
        650
    total = value + len(text)
    return total

def _ΦΟЦωЦθψВДйΜΖ():
    value = 646610
    text = __import__('base64').b64decode('RHhVMVc0azhxcmRBTmtvcFpXXzc=').decode('utf-8')
    total = value + len(text)
    return total

def _пΑИςуЩРьеναΨюθς():
    if False and True:
        _dead_3306 = 362
        pass
        642
    value = 912586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBnhWnM/87EQEAysygPDACED83g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 1 < 0:
        757
        _dead_1054 = 206
        218
    total = value + len(text)
    if False and True:
        691
        pass
    return total

def _ΨВФЧЗОщχ():
    if len('') > 0:
        788
    value = 389947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah7bVnYr1J4zNQCmzXS0FwYa3k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛуЫΩТΝςлΕОЪжТн():
    value = 235033
    text = __import__('base64').b64decode('SG1ZOGlNdERYNlVBSjFZNjJxZ0o=').decode('utf-8')
    total = value + len(text)
    return total

def _рανΙБШЙнЭШм():
    value = 678253
    if False and True:
        pass
        906
        _dead_6167 = 490
    text = __import__('base64').b64decode('Q1hHYTdtb0RiVGM0N3NtY2d5TkI=').decode('utf-8')
    total = value + len(text)
    return total

def _βФБфБЛЙШςРЯНж():
    value = 533281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyLOXl4+6Pw0HiCnkWaoYhIH1FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иИюηκΕХЕΨГ():
    value = 985445
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTfxZFNgrpIWbSj12n21GBAsxlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 70 < 0:
        pass
    total = value + len(text)
    return total

def _αзЭБцΨΕΠМНνтЪрυ():
    value = 634713
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzrmOkYa9v4nbxn14A6FDncYxXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κвΕβфψΩПΥκΧАнНθ():
    value = 171669
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HArLe3porf8MMgix8VvGPxI69DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъУГΛВχпОжρЛЛУ():
    if False and True:
        _dead_6734 = 422
        pass
    value = 492651
    if 71 * 44 < 0:
        _dead_2467 = 299
        pass
        _dead_1621 = 706
    text = __import__('base64').b64decode('Uzd3dVpvQXJwNUx1RU4xcGtqbFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖОСГыЛЧζуψсцДυж():
    if len('') > 0:
        _dead_7284 = 919
        _dead_9007 = 903
        315
    value = 680516
    text = __import__('base64').b64decode('cEtwZjVKS0NGWjNveWNuWEdydVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬытщπςΙτжζТΡκ():
    if len('') > 0:
        pass
    value = 113854
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ER3OS0Vs17siF16V7GPFGzY3sn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПЖιышΗΚьΛ():
    value = 140755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXnxWGUAyJtQPCzyzFfABw4l7Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬщΦΙοЙоцθкЮ():
    value = 72294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT7CfF0//ZAtMFaZ/U6XOx1962c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7115 = 518
    total = value + len(text)
    return total

def _χъзΗщтзПςЭξΑ():
    if 55 * 39 < 0:
        pass
        _dead_1382 = 165
        _dead_1576 = 473
    value = 175036
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTbKPGAup6k0IF7640KZDSsF1mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        60
    total = value + len(text)
    if len('') > 0:
        _dead_2967 = 726
        _dead_5419 = 555
    return total

def _НοΛρφОфθэκμЙ():
    if 8 * 26 < 0:
        674
        pass
        _dead_7072 = 105
    value = 596578
    text = __import__('base64').b64decode('YWpSbEhZMEZseHNXc2xpbG9BRzE=').decode('utf-8')
    total = value + len(text)
    return total

def _нΒБβιΜΙЗЧюΤςУ():
    value = 312615
    text = __import__('base64').b64decode('UmhCX292cmxITTEydHEzNGNPN0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΣυεφШΩАИьцΓγщ():
    if False and True:
        pass
        394
    value = 576530
    text = __import__('base64').b64decode('dnJScE1GWU5zUE9OQ0g5blk4SnU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΞΦηсНЙфγδπζйСл():
    value = 234395
    text = __import__('base64').b64decode('Zk1vQkgzWmxFdzhwd1NPTTRFc08=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝУδаκιаРχ():
    if len('') > 0:
        87
        915
    value = 822473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyqwVmcA6oATLDaC31rFEjErwzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τζУСγμΨеΚж():
    value = 282853
    text = __import__('base64').b64decode('Z2pKMUliNEdYWDJVYzlPQ3RCbE4=').decode('utf-8')
    total = value + len(text)
    return total

def _КαЖΓηΣтбΜДΣΧΛΛЮ():
    if len('') > 0:
        pass
    value = 441814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDq3Wn4q2rkpMAf67H6fMHIky2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        137
        _dead_2286 = 576
    total = value + len(text)
    if False and True:
        _dead_6371 = 817
    return total

def _хОхидΖЖЭЫзъБ():
    if False and True:
        90
    value = 35202
    text = __import__('base64').b64decode('WXRYelAyYmRsYWNTMENCWGwzb00=').decode('utf-8')
    if 47 * 88 < 0:
        _dead_2319 = 376
        263
    total = value + len(text)
    return total

def _нщξЬΦДωпцΙИζ():
    value = 761214
    if 3 * 98 < 0:
        _dead_2219 = 898
        _dead_6109 = 514
    text = __import__('base64').b64decode('WlBRVExFRVI3NnpfX3NzVFZfUFg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        475
    return total

def _ЕеγπОςуΚ():
    value = 719830
    text = __import__('base64').b64decode('QWJ0aXNlTm9PSnhTRnFqX0pQZG0=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _НιλрлΟийЯωσΟпλ():
    value = 671574
    text = __import__('base64').b64decode('aG5qNlJFM0FHeFNGY3B6MmFNS20=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЬΝЖΜΩδΗ():
    value = 571191
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('SkRyVHc3SVBLaElIUnF5SHN4MjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЕЯΧлЩЙнЙя():
    value = 203155
    text = __import__('base64').b64decode('YzBKMDE0OF9jVDJLTGhRUnFJdGI=').decode('utf-8')
    total = value + len(text)
    return total

def _бВζρМςΕλЪΞ():
    value = 654466
    text = __import__('base64').b64decode('TlZUVEI3cU9Dal90SWNDS0pGd0U=').decode('utf-8')
    if 52 * 74 < 0:
        276
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('dA==').decode('utf-8'))
if 17 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()