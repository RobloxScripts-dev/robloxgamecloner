#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ЧрΦχЖοζЙ():
    value = 431925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAn3fFw954kFYjeJmH2SbXE4/WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1626 = 585
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _βЮυσРΗΗΦΙМоМΡшΒж():
    value = 64446
    text = __import__('base64').b64decode('b1ViQkh1ZWNsdDJpUUU5aW9yYjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪтΗвЛβιц():
    value = 306446
    if False and True:
        872
    text = __import__('base64').b64decode('RndJUGFFVHlCWDgwdDFhQUdKQUY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        685
    return total

def _ΔРΤфδΖΨАЮρРъ():
    value = 907966
    if len('') > 0:
        643
        _dead_2123 = 206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX7OX0M496UIPACg8GS7IT0ZzUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОρДΧηнПУэςΚУ():
    value = 134410
    text = __import__('base64').b64decode('ZmFMUzBiankzVFVPS3Z1UW1CTWQ=').decode('utf-8')
    if 41 * 36 < 0:
        _dead_2315 = 276
        453
    total = value + len(text)
    return total

def _явπщЗλЧΤψкпυИгЗ():
    value = 326349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjfHPlkszq88Hl2P4w+VOwI35lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 45 * 37 < 0:
        _dead_7113 = 896
        pass
        pass
    total = value + len(text)
    return total

def _ΥωуЯχιΝсАηВТУ():
    value = 177102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiXqOwE/x/gbKlaxzGTIOAoe63k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΓчВйТтΩБ():
    if len('') > 0:
        pass
        _dead_4386 = 542
    value = 861050
    if len('') > 0:
        pass
        154
        _dead_4681 = 44
    text = __import__('base64').b64decode('UUliZ2dHbk9wQkZkMXR3NXB6Rmk=').decode('utf-8')
    if False and True:
        pass
        _dead_4657 = 159
    total = value + len(text)
    return total

def _ΔΚωΟΡмхΘΖ():
    value = 189260
    if 21 * 17 < 0:
        _dead_6052 = 975
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh6xS1AYwZIVaxWawleAOnAVtX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΞМфωзшьСιΨп():
    value = 454310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRXqRmId04ALPFb2w1SBZi8Yyzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΨоμЙйШΤ():
    if False and True:
        pass
        901
    value = 596705
    if 71 * 54 < 0:
        pass
    text = __import__('base64').b64decode('YXhjZnFLNUVHTkRpaVNGY0k3WXU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7634 = 922
    return total

def _υЕΥвфυЬγΗγцЛгΩй():
    value = 624977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjizR0Q89p9bPia5n3i0BxQEwWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙьξаηпСπъ():
    value = 569081
    text = __import__('base64').b64decode('SVMzTW16ZW1oX0tEampmT2N5UkY=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _νΒЦΗСФυχΜрбатνыν():
    value = 386255
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgayamNqqLonYgCZwVi/IxAH0lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оБПщИΜζχ():
    value = 66847
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3vmalIWzacNEz6wxWWWOi0A7Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _νΠидтΚθκдВЛИψ():
    value = 429602
    text = __import__('base64').b64decode('R2daSjd2enpKWEcyeTZSWXpYaDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΥкβςφЮΛΙιν():
    value = 787639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAO9XAUh94IaFSbx7nPHbXcQxVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΞмΜλΧЗфщеПΟ():
    value = 223056
    text = __import__('base64').b64decode('aEZGM2ZsX1VkZnplSDh3aTJ3TFU=').decode('utf-8')
    total = value + len(text)
    return total

def _УφζРЩΚфΟ():
    if len('') > 0:
        _dead_8326 = 909
    value = 52643
    text = __import__('base64').b64decode('SUI5X0ZRSTJ4b1E1SVdGZl9QSzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _σУЕЗАσЧπθςεЧυΞ():
    value = 637483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix3mOVc7y/AINlu64AWeGgl21EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΨЕΑщлαыдξλъ():
    if False and True:
        525
        pass
        _dead_5834 = 891
    value = 795280
    if 83 * 7 < 0:
        _dead_1024 = 659
        _dead_2989 = 323
        73
    text = __import__('base64').b64decode('ZFZZdTRLYXQ2ZkhfdWJUUURmT1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫШΜхРзжЫхя():
    if len('') > 0:
        pass
        925
    value = 444410
    if False and True:
        _dead_8886 = 287
    text = __import__('base64').b64decode('aUxneHkxQW44aW5fSUROT3hNWTg=').decode('utf-8')
    if False and True:
        _dead_3437 = 598
        _dead_5527 = 132
    total = value + len(text)
    return total

def _ЮвαΦΥξХпезΕΚФМλ():
    value = 650805
    if False and True:
        pass
    text = __import__('base64').b64decode('cllYc2RzajQyWDZKYzlLaUhwVUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΒмЮЧΖφьΦГЛЛЖПК():
    value = 910287
    text = __import__('base64').b64decode('dWdlb2xmdUpnOUpYajJFMUhnVEY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        284
    return total

def _χИΥБΘЩЛбудς():
    value = 977539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyXeZmQI6ZlSIAyZ+3jJEzwp3Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓТхэΑиУбЛыЗДмυΙь():
    value = 298084
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCrAZ2RspolUagKN21yzYhEu5js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΛΤΔΞнοΞΒνεκχ():
    value = 762823
    if False and True:
        _dead_7320 = 271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjjrOkMc+pkHFQeQm3zGEjcpzEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 55 * 95 < 0:
        pass
    total = value + len(text)
    return total

def _ЛрΚЯачλΘОτИψ():
    if False and True:
        351
        750
    value = 726562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR/WZmEf8osHHVeW4Hq1OQ9+xkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        153
        _dead_7861 = 654
    return total

def _нОΖδЭМηζθьщβяτδΨ():
    if 57 * 31 < 0:
        914
    value = 960311
    if len('') > 0:
        pass
        830
    text = __import__('base64').b64decode('ek5rQkpqbzlnNGFwWVpaMXlSdnk=').decode('utf-8')
    total = value + len(text)
    return total

def _оРεдιωρцнЮ():
    value = 633695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSLSNno/8aApaVmL5E+8PjYfzHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΤщδтωΜэшВΤэхШЗ():
    value = 698308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hxfva2Q21qs3NQmpmlujEwB87j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 5 * 15 < 0:
        _dead_6012 = 878
        pass
    return total

def _ЬкБШчдЮΨΓΒ():
    value = 552467
    if 100 * 63 < 0:
        pass
    text = __import__('base64').b64decode('VFNIMHh0RXZtemJYMXhQY0JfdW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ααИБйΨцщψНеТμηηπ():
    if len('') > 0:
        630
        _dead_6862 = 158
        _dead_8085 = 239
    value = 916870
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRi2S18J04AVPz62yVOoF3038mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΔφοМшζчαюρНοн():
    value = 356015
    text = __import__('base64').b64decode('aEF1RDJhMlhjRWRobGo3c1hTN0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓψΛЦВдхβэχпюκ():
    value = 979262
    text = __import__('base64').b64decode('dWFLUklnYUt3aUlLZXZZdGR3aWY=').decode('utf-8')
    total = value + len(text)
    return total

def _пσδΞΒΦςидМЧЪΦ():
    value = 337629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3boeEsbyK1XNSyUkXuqCyQJwUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лОНЮеΒЫΥДΔοЗ():
    if 84 * 29 < 0:
        _dead_3061 = 688
        590
        pass
    value = 538945
    text = __import__('base64').b64decode('Y3VtcU1pbjZIdkxOQ3NrVXp4R1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖПοоКДИЯΦΕΞю():
    value = 47058
    text = __import__('base64').b64decode('UGdrTWROTWFTdW5ZWmhIRTl6aFA=').decode('utf-8')
    total = value + len(text)
    return total

def _КИφбΕФωтЯАеЩ():
    value = 415308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzbqXV8o5oQrGAKx+wa/NnQNxz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 9 * 87 < 0:
        pass
        _dead_7546 = 387
    total = value + len(text)
    if len('') > 0:
        483
        _dead_1143 = 542
        _dead_1383 = 713
    return total

def _ХΚрψРаΛЛΟ():
    value = 463981
    text = __import__('base64').b64decode('T2Fib1dhX25FMl9nSlpoZ2JoWHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨЖκιЮЦцНκκб():
    value = 149557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cz6xX3sW94wLFhWk+w6+EDd+9mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1755 = 403
        pass
        _dead_2586 = 140
    return total

def _ΣЛуΦВΨочκψД():
    value = 398093
    if False and True:
        _dead_4728 = 591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQrnYUsb2K43FACL5VSbN3Q89Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΛΑЯЖеОιюΕΕΡ():
    if 24 * 49 < 0:
        829
        24
        _dead_4751 = 954
    value = 706077
    text = __import__('base64').b64decode('U0pIcWo5SVo0TTlqOVFvVjhhYjE=').decode('utf-8')
    total = value + len(text)
    return total

def _оΖЫдллтбЛΧΨεНАи():
    value = 329035
    text = __import__('base64').b64decode('RUpjMk55M1VoVVpjZHBGNXAya3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡчΧъУεΡь():
    value = 465914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSHrXXgXxLJQbSWTnVypHwYcyUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шШφБцεΣΒСΙлβ():
    value = 147989
    text = __import__('base64').b64decode('elVrMlZWSEozc3VJa2hHQkhKMFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ζгΖΘσзОЬΩк():
    value = 654016
    if False and True:
        829
        _dead_8114 = 179
    text = __import__('base64').b64decode('TUhLRmplUjF5SjBPUnRlb0tocDU=').decode('utf-8')
    total = value + len(text)
    return total

def _РСсινЕЧЕΟЭгζъо():
    value = 726477
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTyzTWQj1PkgGBWVwlKEGiwu52o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΨмΓЯυцαэηш():
    value = 471005
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAndalUwrZosHyn0/3mDYyM3s18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωУьψТцΡΣзвыψΔ():
    value = 200995
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByTJQ1YQ9pspIiSvygXDYR0kz0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2066 = 702
        _dead_3459 = 823
        pass
    return total

def _ъРοΣρΖядтъοч():
    value = 776523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kj/GXkswp4EAGRWQwU+jEwYn0XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦшδмчγΦΚшЬчУΧιΣ():
    value = 87076
    text = __import__('base64').b64decode('TkdxaWc1NUtoX2pLRmJFZ002Y24=').decode('utf-8')
    if False and True:
        835
        pass
        _dead_8672 = 920
    total = value + len(text)
    return total

def _πЗπβИоНЫζКнСлΠУΨ():
    value = 455271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB3jfngJwZAibg6a53mIIAd34U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξШιρξвδН():
    value = 825730
    if False and True:
        613
        _dead_1541 = 804
    text = __import__('base64').b64decode('U3QyMHVzaVU5WlVzWHFUVHBiQ0c=').decode('utf-8')
    if False and True:
        473
    total = value + len(text)
    return total

def _χψэЛьйκлζВЖΠ():
    value = 182761
    if len('') > 0:
        _dead_8129 = 395
        pass
        881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fiz1eFUx+psaDzuxzk66YXIB6ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СмэηΙυТЬсκАβцх():
    value = 798428
    text = __import__('base64').b64decode('SGRFTk15akpHTTlJeEhYUFZkN2s=').decode('utf-8')
    total = value + len(text)
    return total

def _КσЪеςсЭωдς():
    value = 345995
    text = __import__('base64').b64decode('WEM4ZUViMFRHRWFudGExaVAwTDk=').decode('utf-8')
    total = value + len(text)
    return total

def _одσОАλΛθъσΚαС():
    if False and True:
        494
        pass
        801
    value = 890478
    if False and True:
        37
        111
    text = __import__('base64').b64decode('aDN6eWxYQU5iN1ZBTTJGdm5lNW8=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        498
        pass
    return total

def _ΠθСγΒзξщею():
    value = 574088
    if False and True:
        _dead_8150 = 18
        pass
    text = __import__('base64').b64decode('QjlTdWNwcUVjUGJiaHgxVFFZV3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ыцωщхсЭБьοРψ():
    value = 324214
    text = __import__('base64').b64decode('aGpvbDVEeWUxSWMwWm8zZGVkVTk=').decode('utf-8')
    total = value + len(text)
    return total

def _йΟзωЦшηдςр():
    value = 980766
    text = __import__('base64').b64decode('V25pSEVIdDQwN1QxR2QyMnBhU3E=').decode('utf-8')
    total = value + len(text)
    return total

def _жЕρΩпЗсΗБДщ():
    value = 152611
    text = __import__('base64').b64decode('S0xtNUduM2tFTTNLYnFSOUdpQWs=').decode('utf-8')
    total = value + len(text)
    return total

def _кфιрΦНлЮЭ():
    value = 585732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQ3nYUUB3Z0mPTyM/GeDJxcqvEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΞΩΓоаыЖπПоΤΥ():
    value = 431958
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dgv9ewgN1ZwlMzW521KiZRA7wV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭТюΔΗфαб():
    value = 221600
    text = __import__('base64').b64decode('elljV3hBRW5tUTN5blpxUHdoNDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ηОьΦКρЧпΒτЪψЮОΚ():
    if 56 * 20 < 0:
        427
        _dead_8039 = 542
        _dead_2910 = 289
    value = 45475
    text = __import__('base64').b64decode('T1hnTjRyVG5Rb2ljNE1TYW1zWWg=').decode('utf-8')
    total = value + len(text)
    return total

def _тλΣвβΔцЭΙγЬΣκгт():
    value = 480029
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ni33QEEz94EELyim2Ve0Py940G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еξыυΞвυφчЦуΙбΧ():
    if False and True:
        _dead_1330 = 188
        pass
    value = 678527
    text = __import__('base64').b64decode('U2lJaWlUblJRdGh5UnhKNFF4MVQ=').decode('utf-8')
    total = value + len(text)
    if 66 * 30 < 0:
        _dead_2562 = 761
    return total

def _αεхЛΑщтξя():
    value = 615634
    if 54 * 84 < 0:
        _dead_2422 = 374
    text = __import__('base64').b64decode('bERjSVgwNGloWGZ6TE5XY21fc1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ТцНлΒтнЦζξ():
    value = 75277
    if 38 * 82 < 0:
        25
        _dead_7802 = 146
        pass
    text = __import__('base64').b64decode('bTRLYVdKTFhnQThDRXdoMEtLbGU=').decode('utf-8')
    if False and True:
        pass
        _dead_8988 = 67
    total = value + len(text)
    return total

def _βЭΘыЮΝγБчзΨрκ():
    if len('') > 0:
        _dead_1461 = 474
        410
    value = 548677
    if 47 * 46 < 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('cVZXcXpUYlA5YVVnSjVXX3NMcWM=').decode('utf-8')
    total = value + len(text)
    if 58 * 27 < 0:
        481
        _dead_6120 = 712
        pass
    return total

def _ОкΕΤЪρЪиΖюЮΥβ():
    value = 142394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXfjYXcw87whMyehwGOeHXcM0E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШИВянεЭВσщшЭ():
    if False and True:
        _dead_9693 = 942
    value = 761652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAX8eEE0zpEPFxes3gWpLSJ84UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 11 < 0:
        11
    return total

def _ΜυσвΒнВДΤΓΚ():
    value = 162626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXveZAYt9JkUBSam7ES6ZQAD4WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8323 = 291
        623
        pass
    total = value + len(text)
    return total

def _дйρрилРыΛыΦТгц():
    value = 933137
    text = __import__('base64').b64decode('dkx2ZGdQVlViTldCQVZMTThHS1I=').decode('utf-8')
    total = value + len(text)
    return total

def _εКσйГσвфЩΞщθПЙЫ():
    value = 74825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwnVamE0z5IGIxqn6VuHJB0CyVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τХайЯШΔэГФμЬ():
    value = 591377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQrtYHgD1Zs8ADr26WKqHi8Ez3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭХЬΩΜЧυΚςыΞΙРыЪу():
    value = 240900
    text = __import__('base64').b64decode('Yl9tazNIVjJ4dzZnZF80aG91Z3o=').decode('utf-8')
    total = value + len(text)
    return total

def _рμъΡГцχНχΣЧр():
    value = 254688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQqxZ0tv7bsUCD+lzkK8HAED/n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜЯгΦΘθЖχΦъд():
    value = 735074
    text = __import__('base64').b64decode('d1d3TmJaU3laWVpMYmJVbkRqWjg=').decode('utf-8')
    total = value + len(text)
    return total

def _пяоοЙЧΠφкНМΩхγ():
    value = 940916
    text = __import__('base64').b64decode('UTJ2VzREOXNSR084UFBfNVllZGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΘьхцЭИНьΓЧСя():
    value = 210428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnrGeVtoyb8FN1vy23ijNgIK4WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЗлеТзфρΩΗΣψрВыЧ():
    value = 323377
    if len('') > 0:
        _dead_3346 = 255
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiS2XFM4qIAmKAuR4GmlGwp23X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σЫππτΤягΠУΘ():
    value = 509924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxjmWgQzzo8GLATzxle8PAog9Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2642 = 11
    return total

def _еΕφзЪТУυуππΟ():
    value = 202397
    text = __import__('base64').b64decode('eVo1RUdVWExnTnFIT3JEUWlHb2M=').decode('utf-8')
    total = value + len(text)
    return total

def _КτΣΕΙфΔΔщξΛНУ():
    if 66 * 34 < 0:
        500
        pass
        _dead_2522 = 829
    value = 172686
    if len('') > 0:
        _dead_5454 = 221
        _dead_4323 = 560
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRzlS24d0L8VIyeBmFu7LXUXzXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5045 = 804
        _dead_8478 = 654
        544
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΚЙυяцπфТΥΥхгъЙш():
    value = 546700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICTJf0MewbI3IyqHzwazEyR6/T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аβΟθγЧςгЬвЯг():
    value = 988643
    text = __import__('base64').b64decode('RFFKM3JUeWd6QU55U0pfazRsZzI=').decode('utf-8')
    total = value + len(text)
    return total

def _КЭмκΨοΞδΥπΚмСэ():
    value = 588811
    if False and True:
        _dead_6334 = 116
        354
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FB/MOVgN5/4GCzX66lC/GyIV8Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лПуИΒЧΒΘαУяФ():
    value = 490184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzfLTXgR2ponMjWc91TANis20GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вКфΧгЕХλЛωξδσэ():
    if False and True:
        638
    value = 906772
    text = __import__('base64').b64decode('U1NQNnh2Zk16QTVlUHVVNXZINWI=').decode('utf-8')
    total = value + len(text)
    return total

def _СθМКшαеγУъчдИв():
    if False and True:
        382
        pass
    value = 107696
    text = __import__('base64').b64decode('TDVPeHZQR3duNDRZY0lLOTNwdk4=').decode('utf-8')
    if False and True:
        856
        _dead_5666 = 130
        927
    total = value + len(text)
    if 63 * 38 < 0:
        489
        _dead_8154 = 366
        _dead_6994 = 624
    return total

def _ЧЧшΒшΞтχб():
    value = 15629
    text = __import__('base64').b64decode('dnAwMjRfS2Z3UFhVX3JkeHFfZnc=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        148
        pass
        pass
    return total

def _ρРΛНмЩОК():
    if 35 * 66 < 0:
        pass
        185
        pass
    value = 975645
    if 28 * 29 < 0:
        283
        193
    text = __import__('base64').b64decode('R3B2REFzd1RSWWc4YTZnaUZ4dlg=').decode('utf-8')
    total = value + len(text)
    return total

def _οωЗкжΞэРсИГАюМеЪ():
    value = 175252
    text = __import__('base64').b64decode('cEdqUVVLTncwNl9MeXJEcUhpdjk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_8255 = 122
    return total

def _яθЦпооνθнрнΡ():
    value = 574426
    if False and True:
        _dead_1165 = 229
    text = __import__('base64').b64decode('VTlPOU5MYUJ3UXdxR0xSaGpmM08=').decode('utf-8')
    total = value + len(text)
    return total

def _Ууъρэснгτσзтης():
    if 83 * 54 < 0:
        735
        pass
        _dead_8094 = 366
    value = 917896
    text = __import__('base64').b64decode('S0o4aWcyXzFFRTREaUNUdUgyWGs=').decode('utf-8')
    if 44 * 49 < 0:
        _dead_5337 = 847
        521
        _dead_1915 = 630
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4859 = 742
    return total

def _ЕΩЛΡσΞРΔЮλ():
    value = 37165
    text = __import__('base64').b64decode('Q0trQTRqc004bnhrWTV1c19RM1k=').decode('utf-8')
    if 43 * 77 < 0:
        _dead_9299 = 449
        477
    total = value + len(text)
    return total

def _ψжψмΖЭДθхΣφвЙЭ():
    value = 9746
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXjMP1ctyZAQAi235w64OjE+xkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βδвωρИЮРАыПζяΣы():
    value = 352104
    text = __import__('base64').b64decode('T1dJa0VMVUdxdVJ0MEZzZEpuTmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦσтсКΒйщЩΒрζцЙАπ():
    value = 893863
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBDQbEAo6owMbhayznS0Iy8WvDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦγнфЗГγθБΦ():
    value = 17951
    text = __import__('base64').b64decode('bG1XZGZCQXI2QnZXTnZ2djdWS24=').decode('utf-8')
    total = value + len(text)
    return total

def _чΥЬΠфΤкξЭΒ():
    value = 328380
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHvKW2Ug9YoxNRn6nQOhYBo8wns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3179 = 213
        _dead_4369 = 694
    total = value + len(text)
    return total

def _ΘИτУчοПЪПΟРχοЪЛ():
    value = 387793
    text = __import__('base64').b64decode('ZGJ1X29LZVd0cHdLd3Z2WFBDTWo=').decode('utf-8')
    total = value + len(text)
    return total

def _υЦТΘлЬЮωбЗкмψυ():
    value = 802988
    if 67 * 37 < 0:
        483
        _dead_8862 = 568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXfGSmYfqJEVAzih3FWCIgo+wks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΖΝυДΒρеΥ():
    if len('') > 0:
        629
    value = 592220
    if len('') > 0:
        pass
        914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kgv+dFozqKwbaxmE61O6DTB6tn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 4 * 7 < 0:
        315
        pass
    total = value + len(text)
    return total

def _φщαΙςπфыροАλЬъЪΕ():
    value = 136873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BB7PQnM/ppgJNBqCw0CgDhIbvGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        332
        573
        652
    total = value + len(text)
    return total

def _УσыИΣЬΒΤИФηУП():
    value = 316632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDnlfFsD959VKjaE2keHYAE50Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЧЭКСΣвκъфънъьθ():
    if 88 * 69 < 0:
        62
        _dead_1036 = 903
    value = 207325
    text = __import__('base64').b64decode('SmxEVDBMUmU1SWc0dlNxZVBoOTM=').decode('utf-8')
    if len('') > 0:
        _dead_1152 = 193
        851
        552
    total = value + len(text)
    return total

def _γКδшκΤфωПЗ():
    value = 333310
    if 15 * 20 < 0:
        _dead_4337 = 457
        _dead_5172 = 269
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiDgfnw+zJsBFxqI4ky0ZTU6sGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΠодиОшАТυУρω():
    value = 874720
    if 96 * 80 < 0:
        _dead_3700 = 498
        979
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxfiWFUb24NbCAv75VTDNnM8tXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 9 * 35 < 0:
        _dead_5005 = 175
        pass
        _dead_2008 = 558
    total = value + len(text)
    return total

def _πμδьΝВБщЖмЛыЛΡуО():
    value = 584122
    text = __import__('base64').b64decode('d254STI3YzFBSnFDeEp6Sno2S3M=').decode('utf-8')
    total = value + len(text)
    return total

def _фςнДΙйкςРχ():
    if False and True:
        pass
        _dead_5622 = 305
        _dead_7598 = 209
    value = 634952
    if False and True:
        _dead_4538 = 220
        971
    text = __import__('base64').b64decode('S2t6ZWE4ZTZFd3lGUkVkeUZ1ZXM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2083 = 606
        _dead_1386 = 944
        _dead_5423 = 150
    return total

def _ИуκηяЦшжЧИП():
    value = 898529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwbiV3suzf8PLgmm8lS7GhU37WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖсЧΨЖΞШυзЮк():
    if len('') > 0:
        733
        847
        _dead_6769 = 631
    value = 554090
    text = __import__('base64').b64decode('c3ZYWVdyOWdLY1RlVmNZc2szVkc=').decode('utf-8')
    if 80 * 4 < 0:
        pass
        240
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        995
        _dead_7089 = 300
    return total

def _ЗЫьыηχЭж():
    value = 782357
    text = __import__('base64').b64decode('ejdsMFg2dng3VWpDTnlwbVA1X0E=').decode('utf-8')
    if len('') > 0:
        246
        309
        _dead_4546 = 244
    total = value + len(text)
    return total

def _уζΚХГлРОдФЧΘфщу():
    if False and True:
        106
        pass
    value = 829217
    text = __import__('base64').b64decode('U2FzR21FeHdteUdHTDhHV0NId1k=').decode('utf-8')
    if len('') > 0:
        789
        880
    total = value + len(text)
    return total

def _ъПΦЬπΤкЬ():
    if False and True:
        909
    value = 743081
    if 67 * 36 < 0:
        _dead_3516 = 249
        _dead_8803 = 304
        149
    text = __import__('base64').b64decode('cmlIdGlUUEhHckxMT1cxZjhaU0k=').decode('utf-8')
    if 41 * 41 < 0:
        _dead_1884 = 295
    total = value + len(text)
    if False and True:
        113
        _dead_4524 = 648
        728
    return total

def _РΒЛΠχφРΓддπεΑсН():
    if 23 * 86 < 0:
        _dead_8689 = 14
        _dead_4374 = 534
        _dead_6535 = 684
    value = 397557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDnJVHgK76IaDBy6nnuvGR8X3jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оεΛЩцΝхΓфщΘ():
    value = 218354
    text = __import__('base64').b64decode('eW9QbWNwMUpGbXIxUDB1aUNDTGY=').decode('utf-8')
    total = value + len(text)
    return total

def _уψЫЩΖлδХξΡрА():
    value = 488673
    if len('') > 0:
        _dead_6004 = 647
        499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwK1QXUq6Kw2bV+v7QSDOgsY82I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 11 < 0:
        361
        _dead_1774 = 789
    total = value + len(text)
    return total

def _ОзΘΦЪТХΒιсΟЕιη():
    value = 15714
    if False and True:
        pass
        546
    text = __import__('base64').b64decode('VFpwNklnN0UyZHZMQ1E1b2N1Vkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬαπЗωσЦηξτζΤΩυщΛ():
    if False and True:
        _dead_1038 = 637
        _dead_9237 = 651
        pass
    value = 391766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSbzalAV6JkuODu56lmfOwAEyWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5686 = 344
        pass
    total = value + len(text)
    return total

def _νθΝΣиσΦекΟε():
    value = 705382
    text = __import__('base64').b64decode('Zkx3RFlNalR6VzZKbXRJZHpBa3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _аωνζωРΒАФαζЕ():
    if False and True:
        _dead_4666 = 880
        pass
        185
    value = 499401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PByzSVg+2vlVBSuV9wKzJQA/71Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_3233 = 211
    return total

def _ΙЙмΛЙрРσьΜφ():
    if False and True:
        _dead_1750 = 762
    value = 51673
    if 68 * 55 < 0:
        507
        pass
        _dead_5730 = 220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCv2Nwc02q8PHVn13mCcIAx/xUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩνЧаЖжμЬφмх():
    if 63 * 9 < 0:
        pass
        pass
        pass
    value = 303810
    text = __import__('base64').b64decode('dW1rVW55RzdycFFSeFFuRklhSjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ПβНΔжςХжχησΨХтΝК():
    if 77 * 8 < 0:
        pass
        _dead_9765 = 668
    value = 664885
    if False and True:
        pass
        _dead_3232 = 576
        _dead_6084 = 453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHnObQQx1r8iD12Xm26VLggdwUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζДΩΟΠМξξβию():
    value = 785628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzjcZkEg06kHFDmN2m6nLj8hzz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬУΣДΑЫАρ():
    value = 131899
    if len('') > 0:
        pass
        pass
        902
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kwyya2Nr8aovAjWVzGCkPg0p9UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9821 = 482
        pass
        _dead_6302 = 269
    return total

def _ΥсПΟбЙΘКояηг():
    value = 561525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDzVX2AA16QGDwaQ7QLAZHIgxW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыιγИΜОρЛВГюΘ():
    value = 962684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCfuP3Qz7YZSGyKT+Q6YNggL4m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞнЕУсΣФΛ():
    if False and True:
        _dead_7930 = 190
    value = 21145
    text = __import__('base64').b64decode('c25VRkJ4bTQ2dkdVZmVMNF9zS2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜнШдЧΚЬвΒ():
    value = 826950
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh72VEEw2oohPgSU8myKOzZ+8jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠмфμвуΜηξρκрГ():
    value = 973477
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzneWFcvrYlTFy2320fGJysC5n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜλΝГДУИΚЪΛ():
    value = 442035
    text = __import__('base64').b64decode('eHFRT2cyZ3lLWVJqNUJZSzQydlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ъθΙνΒЙζΠЮК():
    value = 319374
    text = __import__('base64').b64decode('bkV5Z0FtajcwRXhlMGhjeEsyM1Y=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5973 = 154
        654
    return total

def _ЫαдБξсъРΥоΦ():
    value = 45831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzX3RV8b8LAJHT+s/UCxbTR/9Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΔщσОηχМκξ():
    value = 504801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiLHXwEGyaQ2LAy00g+DI3QutUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фйζΔνмИχΓπ():
    value = 46928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jge2awhp6JlUGTj6mXCCEgZ303Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РψΟуЫтξЪπАΟΗвαΔ():
    value = 784035
    text = __import__('base64').b64decode('RDJvMXF0MGVRaENKcktHN1ZpOTA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3100 = 624
    return total

def _пйЭμηьКуЦжБУΩΘ():
    value = 958993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh/da38y26Y3KDCzzly9DAoV6GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 34 * 91 < 0:
        _dead_9285 = 73
        368
    return total

def _ψыДжΩБИГ():
    value = 447630
    text = __import__('base64').b64decode('bVBHNEd5N1d6S05oMjVaczZRaV8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        281
    return total

def _ЮΤαγΠΕΨщΕΘьЩΑΟ():
    value = 234184
    text = __import__('base64').b64decode('ZHhQUmRZbnJKenluOTFnaWliZTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _УΝлηлΤеβуШКΧ():
    value = 195188
    text = __import__('base64').b64decode('SXlaM0QwZ29IOGRRNVFodldLaWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗηрτЗАьζЕΖξзсЧ():
    if False and True:
        662
        pass
    value = 938634
    if 17 * 99 < 0:
        _dead_4978 = 572
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHjwQFoqqoUuEySE933FYnwDxXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒэЫБΣπИΖαоσШ():
    value = 996454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cza8ZHo776UobF+o3HvJBBMKvDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 67 < 0:
        517
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЯРγАЭгцр():
    value = 12447
    text = __import__('base64').b64decode('UmRsaUdublYwbVAyTTAwank1bWs=').decode('utf-8')
    if False and True:
        450
    total = value + len(text)
    return total

def _ΡввАбпχβΜПσТ():
    value = 516447
    if len('') > 0:
        822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQzBR3luqoAqLBm33V6gAyF31Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4371 = 304
        _dead_8358 = 731
    return total

def _юΖсΘψиΠΛ():
    value = 289299
    text = __import__('base64').b64decode('dXBGem12dW05dU1hZTJwb1RhUXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕЗωΥвСοИз():
    if len('') > 0:
        615
        361
    value = 65726
    text = __import__('base64').b64decode('a002N29PUzFEWlA0SGRVME5qNTc=').decode('utf-8')
    total = value + len(text)
    return total

def _йБОεыДыФοпΧω():
    value = 784788
    text = __import__('base64').b64decode('RF9kVkdqUkNZaUhNeFRMMVNJcFY=').decode('utf-8')
    total = value + len(text)
    if 89 * 98 < 0:
        876
        _dead_1312 = 966
        373
    return total

def _ιЧτоюГбЬуХτс():
    value = 781753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRfiaEA39/kKHRum4VuKEyp+41g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3978 = 698
    return total

def _οΠоАΨωΕКζΚьщΤ():
    value = 52449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxq1R0Id6voKGVuS3F+/GTUnyVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΟθτνэЙунпЙОИαΘ():
    value = 624607
    if len('') > 0:
        _dead_6585 = 528
        502
        68
    text = __import__('base64').b64decode('Ql9NQTFMYWl6SjlmbklVX3lzVjg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7758 = 165
    return total

def _γΚИΒΥΝоταε():
    value = 865500
    text = __import__('base64').b64decode('ZTVCT0hPTVhoc3c3VWNnbHF3bEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪψηКΖΕФч():
    value = 88388
    if len('') > 0:
        pass
        _dead_2172 = 37
        _dead_4878 = 471
    text = __import__('base64').b64decode('YmlxMGc4dE9kOFozbVNkb29BVWQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8277 = 134
    return total

def _μγвиμΤβЕΘву():
    value = 577713
    if 75 * 58 < 0:
        pass
        _dead_8731 = 684
        _dead_4487 = 854
    text = __import__('base64').b64decode('d1QzRDR3Z05rZXN3eDdMV2NUeUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛχΜПЕНэνгЫΜΙфРыг():
    value = 969260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyTXSVsp7PEvKi6Qzn/GGQ847zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сЬдсσэоДΥ():
    value = 392688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwvFem4h85JXKFn2+UGGBQd7zUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΕвЪСУЪЭЛэΦΔ():
    value = 988538
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JibiUQQI2qwsC1inmAOxORAd6z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩБΚΤΘζηпЮЫш():
    if len('') > 0:
        _dead_3779 = 754
    value = 866096
    if 7 * 20 < 0:
        59
    text = __import__('base64').b64decode('SFdzVVVEUWlMRkc0R1VYY3ltdmg=').decode('utf-8')
    total = value + len(text)
    return total

def _тКтВЖЦЪДωΜУК():
    value = 223111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAHqbUIIyPpROFuS+0KVMS0NzXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥХωΔЧвΘΧТЦςйΤ():
    value = 458233
    if len('') > 0:
        870
        _dead_3106 = 780
        _dead_9744 = 216
    text = __import__('base64').b64decode('VFFVV0J6UUk5SXZjNW5VOERuaXY=').decode('utf-8')
    total = value + len(text)
    return total

def _лεκςъЩРЗνμУР():
    value = 257656
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiTOdFcG2YwVMViBwAG6BXA9yWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯчоЪруΦяюαΩοкЬ():
    value = 748506
    text = __import__('base64').b64decode('UmZlQTNrVl9yYVhjamU3blFCaU0=').decode('utf-8')
    total = value + len(text)
    return total

def _КζЧЪΚжΔЪΝЭΘτ():
    value = 614964
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiPhZkgp66oVAgOAx0+mAzMCykU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηξТсζΧψΑςψεМжЬΣ():
    value = 160274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgrealADrq4mDAuC3wSkZBJ9wGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        215
        604
        pass
    return total

def _ξьΙΚЯнкФξΚγи():
    value = 773955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnnodnMd2J8majn043yXECIB9HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЙΕЩνлшШЫ():
    if False and True:
        _dead_6945 = 587
        _dead_3654 = 294
    value = 72365
    if len('') > 0:
        815
        _dead_3470 = 292
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LT3DbAcWqJ8rLSOqxn+mYAEbvEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1962 = 991
        7
        6
    total = value + len(text)
    return total

def _ъΟЗμΝъЙΩХфКСЩД():
    value = 538385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwHJSnwT+/orFF2F/QCYHhYOyjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5705 = 499
    total = value + len(text)
    return total

def _ЧЖгχткШВδФΙЦηкВщ():
    value = 302025
    text = __import__('base64').b64decode('SVlTUlV4M1hJSnozcDRGOGRaOEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ШфСτΜжΖβ():
    value = 207763
    text = __import__('base64').b64decode('d0J4cXlTenpTcENnRVBEWkJtdTk=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ШγЪМΒМαЪмΦ():
    value = 742524
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dir8TGEQzL4CMS313HupMwl88WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΙМыойτЛρВ():
    value = 196469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix3tTFYr6phXKBmr/2fEOC0ez00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙЮктнκΦιЧцςεΑън():
    value = 358619
    text = __import__('base64').b64decode('VzhGWTNfcEpoWXVjTFhWUUVxX2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧшδпТЭгςвйΤηыЬЩр():
    value = 109509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDvtenk+0JhSKD2b0Hq3ZCsf0Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΛлФбхνυнЮшФΞПυ():
    value = 889416
    if False and True:
        _dead_3930 = 550
        899
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3bnPVsI/aYkIF2SxW/JGQ88w08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7291 = 553
        _dead_3783 = 876
    total = value + len(text)
    return total

def _ВЦдтΓψΠП():
    value = 458534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCzLeUYuqLI0KCyNnAalG3Ml4EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭКБЭχрςбЗΚОΨδ():
    if len('') > 0:
        pass
        _dead_9687 = 553
        926
    value = 724470
    text = __import__('base64').b64decode('b3kwdElWbDM5VWVPaFdka3dDQ3I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2003 = 991
        pass
        pass
    return total

def _ΘλювΧэьΔУ():
    value = 301041
    if False and True:
        297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAKwZXdq1osEa16nnUeaZA4nzzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 8 * 80 < 0:
        pass
        _dead_7886 = 125
        502
    return total

def _хΗδФΞΛχФхСФ():
    value = 824050
    text = __import__('base64').b64decode('WTJ1WmUzdDZ0Yl9aYWgyWXQ0enY=').decode('utf-8')
    total = value + len(text)
    return total

def _αЧΛυРрФЙωΖΞьэ():
    if False and True:
        pass
    value = 656984
    if len('') > 0:
        _dead_4198 = 757
        85
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhjraEky6Y0FYjf2ww66OhZ98Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 36 * 76 < 0:
        _dead_9965 = 42
    total = value + len(text)
    return total

def _οΠЕαΚЖΕΒ():
    value = 987296
    text = __import__('base64').b64decode('eFE0M0owMkd1QUFSb3RNV0U4UXM=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 19 * 52 < 0:
        _dead_7521 = 61
    return total

def _βэΤωЦЯχγ():
    value = 193039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgW2VHsy7pkwKif0kHiHAQQcs14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 22 * 57 < 0:
        pass
        _dead_1841 = 148
    total = value + len(text)
    return total

def _ΒсеΨддλэлΟРАηψЬ():
    if False and True:
        385
    value = 727877
    if len('') > 0:
        _dead_9122 = 219
        _dead_8286 = 938
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXjFYAcq9qASIAWA2WmRDSEotUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('bQ==').decode('utf-8'))
if 35 * 47 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()