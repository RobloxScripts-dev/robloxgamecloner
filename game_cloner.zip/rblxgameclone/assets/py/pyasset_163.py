#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ЮнЬтβлиκхнИп():
    value = 245520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAPXWH4Jx6QbNVuy/V/DPwsctUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щδΦΗμирФ():
    value = 21234
    if len('') > 0:
        pass
        320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz+zaUIt3akbHxiw0XupDXAX4mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        561
        312
    return total

def _αнбСΙжБЛπΑςЮΒ():
    value = 33821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EynSSnozqPE7ah6yxFC4GScnzkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩГЮχφщиδЮΣТСВεю():
    value = 25262
    if False and True:
        pass
        289
    text = __import__('base64').b64decode('b1htSXNrVFhyZzZMT0xFR1BPOUw=').decode('utf-8')
    if False and True:
        pass
        _dead_8519 = 65
    total = value + len(text)
    if len('') > 0:
        pass
        507
        81
    return total

def _φΙτШпΓЖбНбИΘ():
    value = 620524
    if 35 * 4 < 0:
        _dead_2172 = 103
        947
    text = __import__('base64').b64decode('VWtIN1I3ekhkMmFtdVRZSVM0Q1M=').decode('utf-8')
    total = value + len(text)
    if False and True:
        518
    return total

def _ЖЬΦΤсСθПЬ():
    value = 870828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhzDPEE6+YAADRqq+UycZTYf42c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЛΕкΕьШПТДсπ():
    value = 794227
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCC0WVUP06YVMR2FyUaFAhIh01s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΚзΧЦвЫαж():
    value = 897171
    text = __import__('base64').b64decode('QVppUGpmWWRSSXhXQ19XNUN0ckc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓЕРлюσРΨ():
    value = 588003
    text = __import__('base64').b64decode('a083ZXNJRFdvMWNNVW9wOGdNcGo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΧЩοЬнΠΜΑ():
    value = 690523
    text = __import__('base64').b64decode('dWFrVU1QeW5DSjZZSll4MHpEUE4=').decode('utf-8')
    total = value + len(text)
    return total

def _бΧξИТДЕφКΛρδΒμЫ():
    if 19 * 62 < 0:
        pass
        pass
        531
    value = 383498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRzKREIz9awWKCmgkFGqFSkK3GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МШпАΖΒЩяΧДУ():
    value = 533927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQLhZnZh8P0ONz2a+GKyBA45sjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛДХΕтαнφΔΦХБг():
    value = 638108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAPrRHVs6YxbMQny6W6xJCN55z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠВИΖχςΨΣ():
    value = 641136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwH9bGY1qqtVEin15WO0ZzE1wEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΒτКШΧуχ():
    if False and True:
        _dead_4983 = 249
        699
        _dead_7610 = 713
    value = 831669
    text = __import__('base64').b64decode('TGNiQlA5a1A4YTNfYUJjcWpLdzY=').decode('utf-8')
    total = value + len(text)
    return total

def _цВшКяβΨгΡ():
    value = 297488
    if False and True:
        pass
        _dead_2986 = 365
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In7mXkYxp/sUOCeE7FiDGnAn3G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 61 < 0:
        pass
        729
        _dead_2605 = 648
    return total

def _бЬМаАφЪψγЦхИк():
    if len('') > 0:
        _dead_4839 = 511
        pass
        pass
    value = 278178
    text = __import__('base64').b64decode('U0pZeFVhYXlnT24weU9IcVRrVXY=').decode('utf-8')
    total = value + len(text)
    if 97 * 46 < 0:
        41
        pass
    return total

def _ЫГβЯΘКЖφЦВβΕ():
    value = 318008
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSHxTAIYqqcwLxmvzAaKFiF260g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УРСΝНгЭοБ():
    value = 782261
    text = __import__('base64').b64decode('bkY5NktyZG9rNTQ2dU45QXNUM04=').decode('utf-8')
    total = value + len(text)
    return total

def _ьμЮοУйоΝεшωρΣЭй():
    value = 382016
    text = __import__('base64').b64decode('c3JMdlV5TTFqN1RaTVdOaVVDX0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ωцЙлΕЛцЬΧφЯЬршЭ():
    value = 786865
    text = __import__('base64').b64decode('bkV1VGl2am55aVVUSWdHSm9CMDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЧлοηТΕΨ():
    value = 727010
    if 95 * 56 < 0:
        85
        900
    text = __import__('base64').b64decode('bjhXWm1GdDBwZGJPdXF2bGlpX18=').decode('utf-8')
    total = value + len(text)
    if 21 * 75 < 0:
        _dead_6317 = 961
        503
    return total

def _УОγЧЧΤΠвθ():
    value = 658188
    text = __import__('base64').b64decode('ekZ2YXFRQ2dXSkJBYmJXWll0Skc=').decode('utf-8')
    total = value + len(text)
    return total

def _ηραΛЪыПАΔЖΙΠκ():
    value = 800366
    text = __import__('base64').b64decode('TG5OTm5VRHFid3lYTUJIMnZDN2o=').decode('utf-8')
    if False and True:
        pass
        161
        _dead_2822 = 861
    total = value + len(text)
    if len('') > 0:
        _dead_4784 = 470
        _dead_5489 = 884
    return total

def _ижεκЙеσξΞФЬлРΠяΘ():
    value = 986669
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn+xXwI3+7EQHwCG52C7JgEksWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟыьБщьΠσлЮλ():
    if False and True:
        pass
    value = 551116
    if 82 * 14 < 0:
        978
        pass
        437
    text = __import__('base64').b64decode('ck5xN3kzYjVIeHpheHY2ZWd0bnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ОλИωσΦсВΞОЯШ():
    value = 272075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDfFT0Vp3aMOCD+KykXHIDcAy1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        16
        17
        945
    total = value + len(text)
    return total

def _чΗΗКΖμχщρПАУΞоБя():
    value = 527511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyS3dwYJrL8OCQL0nUC2ZgEVzFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮоΒΨеЙΖΔЯπΘФжиΑЧ():
    value = 680633
    text = __import__('base64').b64decode('QkFNeTRiclBvXzAyajZkTkF1dlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ьχяπуγΚΟФη():
    value = 416009
    text = __import__('base64').b64decode('dEE2WktJWlJBaUlUWDBMZzJ1aWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΩгонжЩΞφ():
    value = 73599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgHATWYrzplVLQuL92O+GAMXsW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _еЯеαХШλитΩНЗВЙЙ():
    if len('') > 0:
        pass
        _dead_4751 = 562
        _dead_6368 = 210
    value = 677580
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz3QfkMr1posLCfyngOjBjAe/Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъЗΙθлБЮΚΓΔπуΑναи():
    value = 780343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyXOPVYQp5wLCRi0nlCfGx041Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΕумΖАзЧгЛьζ():
    value = 947436
    if 26 * 48 < 0:
        _dead_5695 = 450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgnpbGJs6J4NNwz07V2JBncsvVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШхсΥΩЙЯНΕОΜ():
    value = 795622
    if 6 * 15 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IirMQnw226kPNiGXnkacGXAr6WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щЙъυцЗΒΘ():
    value = 44113
    text = __import__('base64').b64decode('S0FhWTZKTmlsdFd5Vl9WS3l1eXY=').decode('utf-8')
    total = value + len(text)
    return total

def _хιЭβЦеТХОυэοБуЦ():
    value = 509747
    text = __import__('base64').b64decode('WEFVS0VCbVNYcDg0Tm5hOGh6ZG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧтатΖшцιГГюаПтαк():
    value = 331620
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHbFSVo4roUHIyHx3GOIBi48vE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8756 = 205
        pass
        621
    total = value + len(text)
    return total

def _ΔэЭΑΠдъхλγ():
    value = 844968
    text = __import__('base64').b64decode('QW9KZDhCMHRHOUk3SU52REtyc0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬкэδРыЧτΓЛЮок():
    value = 291442
    text = __import__('base64').b64decode('djRWWGFwa1ptekVNRXoyUUhMM3o=').decode('utf-8')
    total = value + len(text)
    return total

def _МсκΡαΚЛηИοπη():
    value = 227954
    text = __import__('base64').b64decode('V21xUHViTFJaUklHQ0VhaXNMZTc=').decode('utf-8')
    if len('') > 0:
        _dead_8892 = 238
        457
        _dead_8035 = 127
    total = value + len(text)
    return total

def _ιАοеЯцоΜыСκйюаХ():
    value = 971984
    if 53 * 30 < 0:
        pass
        566
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBnmOWA876xRGQyy8nyEIisatzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΓπоАзИяхΕкфЛπμ():
    value = 111947
    text = __import__('base64').b64decode('T0VYbHRiMzNlaEFkYTU3SWw5Mkk=').decode('utf-8')
    total = value + len(text)
    return total

def _μεМΤррЯФ():
    value = 314463
    text = __import__('base64').b64decode('Y1BWYm1xbXJZU0pYRVZkU3FoTXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩоЭБφАνЩθПжΧ():
    value = 819067
    text = __import__('base64').b64decode('Z0hTb3NaX0M0MVc5UmFUQkhiZ2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫТιьйπρЖΙΞΓй():
    value = 943129
    text = __import__('base64').b64decode('eUtBcDdRVXlxOWh2a2lZYkNXeEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΡпΜφОΚСХГ():
    value = 585539
    text = __import__('base64').b64decode('Rkg0M29aekhXUmo2QmJsQU5iVnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕσΒЪчΘΠΚТπбьиνΟЛ():
    value = 864290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCDlO3Qqz6MrMwaRwGWgP3A7zEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νМΝΝСХъΟΖ():
    value = 507958
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwW0QFJgrYJQNV+SwWCgExYlw3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κДΩΦБαξЛцбЕΑщυдТ():
    value = 597775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRv2PHg26KMuYlyGwEO5E3MX3T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥаΦΔΑьНюηСΕΗГαχΡ():
    if False and True:
        pass
    value = 274932
    text = __import__('base64').b64decode('cURqNDI5UVlaWkVENUxPaUJVZTg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_4903 = 405
        pass
    return total

def _ДИσМιΞсДμйВявβα():
    value = 176591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgzQaVshy/lRKjqMyWWEMDU83GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 61 * 72 < 0:
        _dead_2934 = 186
    return total

def _νЛΧПМδΚХΞΥПйδ():
    value = 526352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzXmfmRtzaM8GC2C4AWpDBQO6Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΔΠщΠжκОΛбοΚΞγШФ():
    value = 628550
    text = __import__('base64').b64decode('RzJ4aGIwWXJjRU9CelZTVnlfTlE=').decode('utf-8')
    total = value + len(text)
    return total

def _пУхЧжχцσв():
    value = 188794
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ai3LYkABq5saPxeC62O4FTUA9Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЦМνγРМъ():
    value = 164670
    text = __import__('base64').b64decode('bEF6VElLZjdYWXJFRXpDbG5lSjY=').decode('utf-8')
    if 40 * 98 < 0:
        _dead_5575 = 272
        _dead_2855 = 459
    total = value + len(text)
    return total

def _пΜЙεΕскГяЯΝΖ():
    value = 976669
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnjpWggSwaZVKh6B0nyXZCQW9k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1075 = 127
        pass
    total = value + len(text)
    if len('') > 0:
        296
        544
        158
    return total

def _ОнΛВρЪвоЧЭрκй():
    value = 84505
    if len('') > 0:
        172
        671
    text = __import__('base64').b64decode('eTNqV2lQWVBXSk1PaUVnVmNzRHc=').decode('utf-8')
    total = value + len(text)
    return total

def _βэΞВΝлДЩΔκχμБ():
    value = 852353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BADDXgM206kIIAWy7EPBPjEd0mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _вςМИΕчэфъγΑЯ():
    value = 468499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDbtNndu765XORipn1SBJQQHy2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΜжнΠЙФσςцΦ():
    value = 64626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AC3NP2ExqIwTHBir9w+bFismx2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψшиЪΓАΑЩР():
    if 61 * 45 < 0:
        _dead_6407 = 316
    value = 76969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MADQP0Ehy5gTPh6k5wWTNQgct3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 21 * 65 < 0:
        _dead_2950 = 573
    return total

def _кςΕмПЙψγβуНЫΨгРЗ():
    value = 462293
    if False and True:
        953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K33Ke3Yazq4zAliHkEaJHzcXvTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        697
        pass
    total = value + len(text)
    return total

def _ЭΥЭыаБκΗъс():
    value = 402507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dwu2QGZq54A8EQma7Qa3GTI79UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вσΙЯщхЙдеАк():
    value = 164584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axzba1xprL8zBSK1xGm3N3IF5j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 92 * 63 < 0:
        pass
        pass
    return total

def _ЬЕщΕПлОΡБэьΥ():
    value = 69171
    if 4 * 64 < 0:
        805
    text = __import__('base64').b64decode('aVd1a2sxbkd3RThZTGRNcHF5VGg=').decode('utf-8')
    if len('') > 0:
        76
        876
        738
    total = value + len(text)
    return total

def _τωΓΣАζиρΞчГΧмμγГ():
    value = 704184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fi29Slts84wrKCWV2H+/Anwqz1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 17 * 97 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        214
    return total

def _ЪыФЯΑЖИΦχθωβωΣгг():
    if False and True:
        _dead_2509 = 299
        pass
    value = 452807
    text = __import__('base64').b64decode('enJHTGRpWmgwUGt3eUhVZFBnN3g=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4160 = 693
        pass
    return total

def _ЗΝΕВбцТГΦη():
    value = 161606
    text = __import__('base64').b64decode('TnNlOVhqc1NZeWwzVXpkWUVSdUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ПТЧζκИΒлВБЪΘЧ():
    value = 342723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxayQlxo24ElGRiZwAaZYXcDx0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 88 * 91 < 0:
        88
        122
        _dead_1662 = 608
    return total

def _оΜφиНνмЦъΖщж():
    value = 377174
    text = __import__('base64').b64decode('bDRGVlMzSWVlQVdKS25oYVBaak8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦдубωυжωЮ():
    value = 453599
    text = __import__('base64').b64decode('WFJORWVTNmtORmNuUWFnemo1SnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΤοъβЛΗГχαΗшяβΕГ():
    value = 400645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyTTa3Aa+6U5BTzyz12KHRA8sVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηξфнЗбИΤΣЮцοΡΤЭΓ():
    value = 55130
    text = __import__('base64').b64decode('THVSUTNRQXNrbktVTFFOcndjWG4=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_8330 = 861
    total = value + len(text)
    if 33 * 50 < 0:
        _dead_9270 = 977
    return total

def _йκξΨχεΡУфΝτФΦφя():
    value = 903814
    text = __import__('base64').b64decode('T0d0aDB6d3Y0am94eEsyQUVsbWo=').decode('utf-8')
    total = value + len(text)
    return total

def _γζμγΡγχνЧдЙΣΞ():
    value = 668615
    if len('') > 0:
        _dead_9767 = 951
    text = __import__('base64').b64decode('S3BMZWc3SXRoVkttTXY0cDdGcUI=').decode('utf-8')
    if False and True:
        609
        pass
    total = value + len(text)
    return total

def _ΡΜЖβΛКуЩΠςсжЯБев():
    value = 943684
    text = __import__('base64').b64decode('SHpQVGY4RUZLaGxEUkdzcURfejQ=').decode('utf-8')
    total = value + len(text)
    return total

def _κыΛбιΕцζθεΙυ():
    value = 318896
    text = __import__('base64').b64decode('YWdLXzk0dElIN3FqMW55MWxiOFE=').decode('utf-8')
    if 51 * 89 < 0:
        pass
        969
        _dead_2549 = 217
    total = value + len(text)
    return total

def _ЗЮГΗИчΥΣζЦЖΘ():
    value = 63444
    text = __import__('base64').b64decode('dkxRbzhrSjBVQkpUY1JERWc2aVU=').decode('utf-8')
    total = value + len(text)
    return total

def _νΞоΣνойКже():
    value = 697303
    text = __import__('base64').b64decode('WGRhVnQ5MVZvWTRvSFpVaVBHdmw=').decode('utf-8')
    total = value + len(text)
    return total

def _цхμэЯκЬρТΗΒαΥΑБ():
    value = 807606
    text = __import__('base64').b64decode('TXJtQ2FKcmJqaU9NdnpFeGQwaEM=').decode('utf-8')
    total = value + len(text)
    return total

def _щзжЫЮЖчδРЦθΩт():
    if False and True:
        _dead_7991 = 834
    value = 811917
    if 93 * 53 < 0:
        pass
        _dead_8783 = 325
        pass
    text = __import__('base64').b64decode('UDVxWE1BZ0xReTZYM0FXU0VkNWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙωВνлмАе():
    value = 192593
    if 66 * 21 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBDuWkE7q6YKIBeL0k6WZDE+8UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΝςсцюЙъ():
    if 52 * 66 < 0:
        673
        433
    value = 736901
    text = __import__('base64').b64decode('YjlKbUQwVUhXbTl6eExhSU1jTFc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        741
        386
    return total

def _ЯςЧΥΥйθαС():
    value = 831288
    if False and True:
        _dead_2114 = 626
        693
        pass
    text = __import__('base64').b64decode('R29tSkdOTGhsR0l6X1dfeXFqRHM=').decode('utf-8')
    if len('') > 0:
        _dead_6412 = 61
        288
    total = value + len(text)
    return total

def _цсВЪЖΧяЪς():
    value = 366662
    text = __import__('base64').b64decode('T203NmNjelUyVVFrU0tSMFhvQVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЙςΕРεΑΦЬκзЩοИт():
    value = 77076
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS3yWl8zxqQPPyK05n7IC3IO1GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БοΘъгξюΕ():
    value = 137201
    if 48 * 26 < 0:
        _dead_1540 = 555
        _dead_6394 = 395
        168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjuxXGJpyIMgOy2W3GWDJA8O01Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦщχЬΚΠζеНСΟТэгшΩ():
    if len('') > 0:
        pass
    value = 515936
    if len('') > 0:
        pass
        pass
        _dead_1952 = 976
    text = __import__('base64').b64decode('R3ExelR6YW5XWmxNNWNIaDlXeW8=').decode('utf-8')
    if 65 * 57 < 0:
        pass
        _dead_2601 = 588
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_5574 = 551
        pass
    return total

def _еωнЦЫВюДлзвνоиΖ():
    value = 680769
    text = __import__('base64').b64decode('T1lEU2M4cGJLQzM2ekNOQVBQdnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕαЯЖШξпЙΟΓς():
    value = 100817
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISPbYkUOrIQRbF2M8g+pIwgJ0j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _евсχμгПΩулЧх():
    value = 439783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjjRaEMMya4mLiWk0gTHAS4h1ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_3435 = 534
    return total

def _ΒΑГЧрхСиαУлне():
    value = 53553
    if 7 * 8 < 0:
        pass
        482
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjjHPkA7+osHLBWu0EHFEQMMwGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КрλГЫΔρМθπ():
    value = 937678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXi9PXZuqKY1bSWu5V+xJg4YtTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙρХΑНРмКьΡΣыγ():
    value = 650155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRnDZAAV/fspMj2ww0SAIDY56UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ПеСφТщλΦНΒаψрС():
    value = 211646
    text = __import__('base64').b64decode('bElPUlVaNHE5aUJCSlBlX1dPSHE=').decode('utf-8')
    if 91 * 95 < 0:
        _dead_2205 = 430
    total = value + len(text)
    return total

def _иΔμюНμхζЬΝрκмτΤб():
    if False and True:
        _dead_8467 = 733
        pass
        _dead_2845 = 734
    value = 287033
    text = __import__('base64').b64decode('czM4R3c3UUxUUTZ1SXBqREc5NnY=').decode('utf-8')
    total = value + len(text)
    if 5 * 12 < 0:
        _dead_4188 = 42
        206
        839
    return total

def _ЕйΞφЛШЫΞ():
    value = 707055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQy1RENv05FTOQeZ42TABzc/yFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξψμиνξЖΘ():
    value = 644632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTjOOmIa76EaPl+K2ETHJikh/Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΛρχЯΩΑПττ():
    if len('') > 0:
        842
        45
    value = 116138
    text = __import__('base64').b64decode('RkxpUWN0bjdLNEtucVZjQllLd0s=').decode('utf-8')
    if len('') > 0:
        _dead_9047 = 608
        _dead_3228 = 291
    total = value + len(text)
    return total

def _фΗνβΚтΩΜнцΧ():
    if 86 * 97 < 0:
        pass
        pass
        694
    value = 937679
    if len('') > 0:
        _dead_1996 = 749
        405
    text = __import__('base64').b64decode('QnJGRDB1bjRhekVXNHdiZzZKT0o=').decode('utf-8')
    total = value + len(text)
    return total

def _фΔλэηΔκΞΑΧ():
    value = 393212
    text = __import__('base64').b64decode('Q3RQektqSGtVUk5CRnkxMXJUNWU=').decode('utf-8')
    total = value + len(text)
    return total

def _νКдΘуΒЩШ():
    value = 95396
    text = __import__('base64').b64decode('c2hmT3BVTDRtdU1BYzNfVW8zZ3E=').decode('utf-8')
    total = value + len(text)
    return total

def _αιМЭОтБТШИгр():
    if False and True:
        19
    value = 958263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiLCfXxo+aswNiGa93qSE30+42k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МβΛθΚЪПЫΖδθнΒΥ():
    value = 261885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAjMVEIL7aESNAqh0VKiPgop/j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠЖбΥЧуЕΦДрψЙ():
    value = 269401
    text = __import__('base64').b64decode('cnBSVXFpc0Y1TDRpNWdDM0c1UUE=').decode('utf-8')
    total = value + len(text)
    return total

def _жΣцδΦщзΥΨΣЯ():
    value = 560565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhrSdFQqr443bQyv+wa5IxIE8E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΟнΟнΠИПΔЙΓекΛΓМ():
    value = 889828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiKzY1Yg1asmLjaqyn+TNxYN4ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сзХАьЫτд():
    if False and True:
        _dead_4569 = 658
    value = 58802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxviRlUpyoc8PzyK21q+Zh8msH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5159 = 716
        pass
        pass
    return total

def _ВΑпττдБΩιОбΥ():
    value = 399115
    if False and True:
        pass
        929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mgm2b1oQ840WDAq7ynTGZCF+zH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5910 = 778
        _dead_7182 = 231
        pass
    return total

def _ξэΜΓπдЕаЗι():
    value = 264273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgbDS0I/7vATKl/zwWnEHnZ5z0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙςКΞγΗοСКррЗЖΡφΚ():
    if 39 * 61 < 0:
        _dead_3057 = 149
        pass
    value = 296312
    text = __import__('base64').b64decode('akRmTEZ2WEFYZ2JrV3FCX19rd3I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9599 = 892
    return total

def _АкеАЕСтЖ():
    if len('') > 0:
        pass
        649
    value = 349188
    text = __import__('base64').b64decode('YmJrSU5JbFpuaWkyRXRJZmx0NG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛТδАКΨхсСМ():
    value = 760802
    text = __import__('base64').b64decode('bE92bHFVbTRRZ2lRQTFuTnZWWmk=').decode('utf-8')
    if len('') > 0:
        _dead_7671 = 854
        _dead_7435 = 363
    total = value + len(text)
    if False and True:
        897
    return total

def _ЛΖшрπΤБеυακю():
    if len('') > 0:
        335
    value = 530916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MADWOVkT5IcnIwmt0XjIbAwo5ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПВβШъШψнΝиГΜХ():
    value = 57846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx7nb10T25wENVuG8EbDNnYb1Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4868 = 559
        _dead_3480 = 993
    total = value + len(text)
    return total

def _гНΔгЙБΕНвΑЬж():
    value = 391809
    if 77 * 88 < 0:
        825
        _dead_6334 = 956
        pass
    text = __import__('base64').b64decode('TW9YYVBaT1RlTUlBRElmaUl5RGc=').decode('utf-8')
    if 11 * 11 < 0:
        955
        397
    total = value + len(text)
    return total

def _ΣιΥрςЛΛШкΟюΝЦ():
    value = 423085
    text = __import__('base64').b64decode('aUdKQ0V2OE5PTmJ5b0NmQ1ZXUjE=').decode('utf-8')
    total = value + len(text)
    return total

def _коχКΩμЪΠ():
    value = 676620
    if len('') > 0:
        253
        330
        835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ch/WQFoDqJIaPTuokFXEO3Y810M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΖΟΚψчΧιнΔЫХНφГ():
    value = 375695
    if len('') > 0:
        _dead_4840 = 622
        pass
        _dead_8670 = 334
    text = __import__('base64').b64decode('eElpQnQ2X0tJczBYdV96VFpKcE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΘΥΦжΗшΗΘηЛΤΣсΥ():
    value = 562077
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByTQQGc634EBaQTy2VuiP3UZ0jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΗлκМмρΥцρΥ():
    value = 933324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBXMV24R+KITAzuP8gSpbAAY/T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 82 * 55 < 0:
        pass
        637
        274
    return total

def _γΦГΣΣЮγнЕЧРуоΒΘФ():
    value = 6153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DB3ePV86+blXFyyA7EWYCw038Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωрΓГмпαТЙΘΩ():
    value = 262822
    text = __import__('base64').b64decode('U0phV0tWVEVBeDNBN3NTb213dm0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        74
    return total

def _веИгмςшлинκ():
    value = 329327
    text = __import__('base64').b64decode('WDd2YXptSGtibEM4b1ZRMnNpM1Q=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_3445 = 70
        _dead_7680 = 191
    total = value + len(text)
    return total

def _φΥЭЮυЗуΟЕВ():
    value = 684995
    text = __import__('base64').b64decode('R3h5STJ0YlZIeGVHUkhIUlZzdVc=').decode('utf-8')
    total = value + len(text)
    return total

def _δδΜАΗтπεΠξЧЗхΟΟЭ():
    value = 601596
    text = __import__('base64').b64decode('WUl6MTlCTWFrR0p5Q1ZkWjBSeXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣνуьΤЫаПрΧЩ():
    value = 961127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBbqZWRr7ppTIx/z8ESBJhwp41w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤРΦΨЦрЙЕЖР():
    value = 230107
    if len('') > 0:
        954
        642
    text = __import__('base64').b64decode('cFQxcjljTUpZXzFWRGo1TFNlZ0g=').decode('utf-8')
    if 36 * 73 < 0:
        pass
        _dead_3577 = 381
        pass
    total = value + len(text)
    if False and True:
        70
        pass
    return total

def _уИъπэωεОъЪПΓΩΗЯξ():
    value = 168532
    text = __import__('base64').b64decode('Zk9zXzhHRnh0eWNOckYwTm05Skk=').decode('utf-8')
    if 31 * 93 < 0:
        pass
        _dead_4438 = 149
    total = value + len(text)
    if len('') > 0:
        _dead_5297 = 852
    return total

def _ΨТΥΦΡεрΠΠΖ():
    value = 13549
    if False and True:
        939
        _dead_2831 = 408
        _dead_5048 = 914
    text = __import__('base64').b64decode('UlZvSnZ5T1VDaUtnUmMxazh3YzI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ШЕСцОρЕα():
    value = 641549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTnoZGMP558qPTmc/A/BBBA/50w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 16 * 61 < 0:
        pass
        pass
        _dead_2418 = 246
    return total

def _ЖЭнХΙΕйчΑΜτηф():
    value = 163635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bin9QEIf8pIqLVuh/268BxYAxVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эηоЮъшΦδ():
    value = 279662
    text = __import__('base64').b64decode('cGxBX2VoVTZmb1JFeFZyVWpPaTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗрΥσуΔЛЧяЗφ():
    value = 385836
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('eEl2MnIweWVzZUR2TDlfeUc5bzg=').decode('utf-8')
    total = value + len(text)
    if 41 * 65 < 0:
        _dead_9753 = 269
    return total

def _йЛυвйΦζБкΩΚΩΕБΚ():
    value = 314347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHvQeQQgy4s1Dlykyw+DCzwitTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΣвΕбаыЫΩλΕκΟ():
    value = 177321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhCxalIp2IIBKwq392GpJBct1UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8199 = 93
        723
        550
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЬηЮНοрвкΛЭйККο():
    value = 326128
    text = __import__('base64').b64decode('U1hzTzgyT3RsUkVoWU10d05kbEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞνСΖГЩЬΓμЛξО():
    value = 727331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiTXeUcu6qIvYz7wzke9FwA91jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 75 * 27 < 0:
        947
    total = value + len(text)
    return total

def _ЧΞΝйφδδоьΠζΩ():
    value = 534086
    if len('') > 0:
        pass
        96
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTfwY3g80LIRAAK7xAC1Zgl/0Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 15 * 2 < 0:
        pass
        801
        _dead_4108 = 429
    return total

def _йπгΟζпμΕαч():
    value = 643619
    text = __import__('base64').b64decode('cVcybnNGSno1STRHNWxqbDhBU2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΦυДσωБπЬмзΣ():
    value = 910003
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRa2WV4W9KsCNVikwQSkbBJ721s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧМγΙМЧΜсВНюбьа():
    value = 739605
    if 32 * 15 < 0:
        871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBfOYlUf5qUKAFeb+WKlASEK50M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        775
        279
        _dead_5281 = 408
    return total

def _ΑρσтΗδКΘ():
    if len('') > 0:
        _dead_3037 = 262
        850
    value = 187514
    if 12 * 80 < 0:
        _dead_3564 = 490
    text = __import__('base64').b64decode('djRVMHJaenJYQ3Fwc2t1cXJvdUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑΦпΗФтшχЭΘяяΜуΩ():
    value = 586131
    text = __import__('base64').b64decode('djlfN2RNMnJlcVM2SHJvaV9mN1o=').decode('utf-8')
    total = value + len(text)
    return total

def _РΡьяьЪУΚΚΞЛЛΛρΠ():
    value = 239204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bz3va10p56UHEQPz93ygPg8q9z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑПМεЪςлωАθΗΕΗз():
    value = 244146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhjWdAc/6J8SOAih5GGWMiwk0Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΠРπЪΣшСοχцшг():
    value = 120931
    text = __import__('base64').b64decode('aXBXRW9KRVpZcnhfaHk0OVR1RTA=').decode('utf-8')
    if len('') > 0:
        _dead_2847 = 353
    total = value + len(text)
    return total

def _ЩφΨЗКРρυБφюх():
    value = 585188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAjjOF4v7rwIYxWM/UW8P3d+408='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        175
        pass
    total = value + len(text)
    return total

def _ΒЭиежΚπψшеφεΥσγо():
    value = 390439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhjPR1Iqwb8UExub/36+Eywkwkk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        45
        _dead_6359 = 603
        pass
    total = value + len(text)
    return total

def _ЭЫщυЦΜψЕ():
    if len('') > 0:
        _dead_3448 = 825
        38
    value = 642006
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxX9YAgU16wMCwiy23fBEgYQ8Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΓлιμΡσЗΙваΤщ():
    value = 601246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3vQR0YQ758rMQCOyVKSBS4Gwmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛТЕαΣΡΧψψΦСЪвσэ():
    if False and True:
        _dead_3354 = 664
        _dead_3089 = 830
    value = 117612
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzztYH449KohBSeQkFy2PCAOwmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИγэΝфηΥРΨшБσЖХΜτ():
    value = 543367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBb+Xm42xK1RNTuAkHKWIDwN6H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5703 = 820
    return total

def _ЛΜгИдУШμЩΝ():
    value = 721263
    text = __import__('base64').b64decode('a0JYUThMWERhYTZ1WnFWYmNvb1E=').decode('utf-8')
    total = value + len(text)
    return total

def _χασУЙУβДμУξЧЦι():
    value = 643327
    text = __import__('base64').b64decode('TFlONmhPNmZJcDlTUFJpc1FRRms=').decode('utf-8')
    if False and True:
        _dead_7840 = 356
        pass
    total = value + len(text)
    return total

def _ΑηξεНШζμйΡб():
    value = 385741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BizlX3YK/YpWNQWi0XupZCo+x38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8719 = 344
        536
        _dead_7144 = 337
    total = value + len(text)
    if 94 * 27 < 0:
        pass
    return total

def _ψΛμαζτΧЛΥμк():
    value = 531203
    text = __import__('base64').b64decode('TGRaUk9tY0RLcUxvakpsRkhNcVg=').decode('utf-8')
    total = value + len(text)
    return total

def _лγΑщеΘУΡπбРу():
    value = 199661
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiTdYnw+yv0yNwiR0HeINTMk62c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψεΧйеατΓПкй():
    value = 447173
    if False and True:
        810
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyCwPgkYprEabD2o/WGfFhoLyUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лЩкСДξцПΖж():
    value = 595837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDXNOkYq1vA2Dh+bwljCYDEt8H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9558 = 603
        _dead_9082 = 358
    total = value + len(text)
    if len('') > 0:
        383
        202
    return total

def _дΘφЯсЮяξΔ():
    if len('') > 0:
        pass
        172
    value = 931012
    text = __import__('base64').b64decode('SWRwaDAwUWxGRUxjd1k5V1NKOWE=').decode('utf-8')
    total = value + len(text)
    return total

def _жТΞηИДчυяΡю():
    if 3 * 49 < 0:
        _dead_8008 = 321
    value = 350980
    if 53 * 57 < 0:
        247
        pass
        _dead_3483 = 493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgDQRlg9yKQtCxuxwnijZiEj/V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΛсЯЪζХИΘ():
    if len('') > 0:
        _dead_7665 = 148
        pass
    value = 898375
    text = __import__('base64').b64decode('WU9SdFRGSjFHdTY4M2NFeTRWSlo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _θλМфИФπОουΚΜ():
    if 31 * 57 < 0:
        _dead_2681 = 541
        pass
    value = 612170
    if False and True:
        970
    text = __import__('base64').b64decode('UXN0ZWFmcVN0UWxfMW0zWHJPMk4=').decode('utf-8')
    if 24 * 93 < 0:
        _dead_5577 = 686
        pass
        406
    total = value + len(text)
    return total

def _лЪΚягжΓРΒУЗуеше():
    value = 424483
    text = __import__('base64').b64decode('TnpwdHBpRDVEcVA0UFRKSlAwYnU=').decode('utf-8')
    total = value + len(text)
    return total

def _шюПΑРЩΚΕЮσΥКщ():
    value = 9370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BinGSlU02ZoEHV+0+HC5ExcQzWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВσЛллρΑи():
    value = 255406
    if False and True:
        923
        143
    text = __import__('base64').b64decode('RHptZzhhVXRkOUwzeGRfNXJoa0c=').decode('utf-8')
    if len('') > 0:
        445
        _dead_2989 = 406
    total = value + len(text)
    return total

def _ХвγςЧσЭΣФФ():
    value = 217288
    text = __import__('base64').b64decode('dDlkSWRLZFRra0xkTjliNXc2R2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧнβЫψпΚοтΟυΓ():
    value = 696645
    text = __import__('base64').b64decode('WUtZb09Gc3Q5RUluZzlzaURrb3I=').decode('utf-8')
    total = value + len(text)
    return total

def _жнСπкОсΕΟμУΗ():
    value = 985308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQvbe1YAppkZFxqi3n+WEC8Xw0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        95
        _dead_7254 = 375
        134
    return total

def _ΙςΗжЧζЦЯаЪ():
    if 78 * 38 < 0:
        pass
    value = 404116
    if False and True:
        _dead_9236 = 253
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IADPa3dp/aYKCgWs7wXGGyMu4G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъЙμΟжфОεγηиы():
    value = 907114
    text = __import__('base64').b64decode('UXJxenhLYm82dWlkdVF2VHp1dFc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2142 = 298
        pass
    return total

def _ΗЖХΘСζгχιωещΥТξ():
    value = 488036
    if False and True:
        999
        199
        618
    text = __import__('base64').b64decode('S2l5dFg1dnI0YXhQdXQ4aXFUZFk=').decode('utf-8')
    if 42 * 90 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _АΩБΖδпЪш():
    value = 89801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHfIZ2Q4xoAlHTCcxgOEBCQ+6zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 15 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ΕцρΩВЖаκΖΜΝ():
    value = 822639
    text = __import__('base64').b64decode('RW5qYWRUNEpzRm10ODFxSDhiX0I=').decode('utf-8')
    total = value + len(text)
    return total

def _σλξТЙΧΝКБнхцΜУЮπ():
    value = 809131
    text = __import__('base64').b64decode('Qmo3aVByQnF4NHdUSjhEYlozM2E=').decode('utf-8')
    total = value + len(text)
    return total

def _фпεкчТАΕкΧУРСыΔы():
    if 17 * 47 < 0:
        _dead_4534 = 671
        _dead_4425 = 511
    value = 105225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ij3+e34By60mOz6bxl6kJQQ93VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УАбЫЫιΟηВ():
    value = 452580
    text = __import__('base64').b64decode('b2FOQUEwOEUzVVVLa1JQZmtuM20=').decode('utf-8')
    if 20 * 14 < 0:
        _dead_2349 = 770
    total = value + len(text)
    if False and True:
        pass
        _dead_2875 = 674
        _dead_4285 = 774
    return total

def _ηнΧАньЙшЩФЖЕζδ():
    value = 891439
    text = __import__('base64').b64decode('TUM3SkxTc0hhWjA0SDBtZ2ZROHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()