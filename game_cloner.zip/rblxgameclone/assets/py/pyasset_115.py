#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΚςпΤσΦСзΚшΤ():
    value = 679022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAy0Y0A76YEIGwCpxQGSZQR+sFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εεΧЕρдΓς():
    value = 550000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTvvN1kN9IcJC1uu33q5JBMqxXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΠηоНЛπдЧΘЮжжМΙ():
    value = 413911
    if False and True:
        pass
    text = __import__('base64').b64decode('U0NUMWxzT1FYWFg0OV9adm84U3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ηеДЦМбБφ():
    if len('') > 0:
        _dead_3667 = 237
        pass
    value = 344346
    if len('') > 0:
        16
        _dead_2522 = 513
    text = __import__('base64').b64decode('TUt5VU9WcDN6eUFzeVdPY1YzbEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙκФηЮθСσΞΕаΚбι():
    if 66 * 84 < 0:
        _dead_5275 = 536
    value = 511212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwrQZVVs36IhMzeNw1q1PBQs11c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жчИΗεВρдЗюн():
    value = 891178
    if False and True:
        pass
        _dead_7351 = 130
        105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnzvRHJr56ozYz2uwHTHBx0iw0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        311
        _dead_5301 = 767
        _dead_7432 = 506
    return total

def _υКЦμжэΩАНпХΣпη():
    value = 254159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT/wN10xyqUyOzb7zVikIRYBtHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъβяПфтυчЮржΒΛУ():
    value = 373661
    text = __import__('base64').b64decode('bmVkdFhhcDAzMWNnb1pxMHlxMHg=').decode('utf-8')
    total = value + len(text)
    return total

def _фΔЪδΝΝΔыМΛФыνшΨ():
    value = 327081
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn/lWEg06IEbDjqh7nO4Myk7w2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЬгσαθсςΣΦ():
    value = 655451
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCvcaXdgrIs3Nxvx23uKISQY4Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МοыЯваИшДχρΖχН():
    value = 738269
    text = __import__('base64').b64decode('UVdrTVB6a1phaTJoY2YweUhibV8=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _нШΣτЧШиК():
    value = 352402
    text = __import__('base64').b64decode('clQ2V0VmZlltMXU3Sjl2RUZnVzg=').decode('utf-8')
    if 20 * 12 < 0:
        _dead_4528 = 244
    total = value + len(text)
    return total

def _юρδΝжπЙаσ():
    value = 188758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSiyelMw/7I5KBer4kLJHBoG92E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩςЦναШнδу():
    value = 890879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H37gQwEb/40OLxqT3Gy4YDwLzF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        113
        899
        pass
    return total

def _зеЬΗμъΕПциΖβХ():
    value = 284123
    text = __import__('base64').b64decode('QnBDSVBDaFk3ZTEwZFFRa3hidVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ПηκΘΡμαθалαωи():
    if False and True:
        pass
    value = 820631
    if 55 * 84 < 0:
        _dead_3259 = 334
        pass
    text = __import__('base64').b64decode('Q09tSkZtcWNhMzlROTIyUHBPSFI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        745
    return total

def _УαхΑιΩΟπиэκзσч():
    if len('') > 0:
        pass
        pass
        pass
    value = 359352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhu1e1Ro0P4JMDnzwUCGJBE+5lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 95 * 60 < 0:
        _dead_4072 = 11
        960
        pass
    total = value + len(text)
    return total

def _ГМмШΓзТЗΖУ():
    value = 606736
    text = __import__('base64').b64decode('djhhdzA4NV9pOHRJQjV6Y3ZJbkg=').decode('utf-8')
    total = value + len(text)
    return total

def _γвЙбРυСр():
    value = 648314
    text = __import__('base64').b64decode('cDBnY19BdXBCN1N6R0FWM0NWYVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠТγЧчΔςΙΠ():
    value = 494158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ii7yaWso5J5SAl2lmES9BBIm728='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚыЛςΙωΖЯУ():
    value = 654161
    text = __import__('base64').b64decode('QkF5M1RkdWNTV05tT1h4bUZDZGw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2510 = 542
        pass
    return total

def _ВтОбΝФйВКΡЛΠ():
    value = 831308
    text = __import__('base64').b64decode('Q25BbHQzRWdidHUyUmI4VmNoMWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _АΔδцбтιζГЭзЛ():
    if 44 * 27 < 0:
        _dead_5008 = 436
        _dead_5354 = 620
        _dead_2408 = 2
    value = 268485
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCPpbGJvxrBUbz6C5A6HPys9/l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1665 = 172
        _dead_6746 = 366
        664
    total = value + len(text)
    return total

def _УΓжρΜηЦЬδπВψБΟ():
    value = 245727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgHiNmUV+oMMKhqu0QPBPSd/1X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лИΒШΩσΘУУυИμ():
    value = 710729
    text = __import__('base64').b64decode('VlYwcnRhcklHYnRJeGZSejk4SzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЮлгсЖЙгσчиШγνхρ():
    value = 351488
    text = __import__('base64').b64decode('dFF1cmM5OENkRjFUR01PZndRdlc=').decode('utf-8')
    if False and True:
        pass
        248
        _dead_7052 = 82
    total = value + len(text)
    return total

def _ГЩγвθρΕΚмМЖ():
    value = 133772
    text = __import__('base64').b64decode('TmhnVnFSQVR4WlhfTTB6bWtEOHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ζамЙΔΔыεΔΙΣЙЖΤδ():
    value = 449535
    text = __import__('base64').b64decode('SHg2WFN5TloxaWQ2SGhlUWxaX3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΘцбιИцπΩЭΒЭА():
    value = 22970
    text = __import__('base64').b64decode('VlNmUE14ZF8yeTZZM3pCOFJ6a2M=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        405
        412
    return total

def _ΖМτΣЦвЙεЬΨδ():
    value = 572853
    text = __import__('base64').b64decode('UFJRMnZRTER2eVNJczFpN3dqNnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑБΚρуΧюэβωвΚΣя():
    value = 339124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgbpVEg6qIMvMDiqwgGVOj0h4lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яιРдтΕοΛВΓкы():
    if len('') > 0:
        164
    value = 895055
    text = __import__('base64').b64decode('c0JLNlZMd1FoazhFX2VmNXp6MHg=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        320
    total = value + len(text)
    return total

def _рςοΦΤοУΘζЖм():
    value = 183312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBjtPlkQ+aQIAhqR+EG9Nnd7vX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 43 * 9 < 0:
        _dead_4206 = 728
        pass
        618
    total = value + len(text)
    return total

def _рдβνЕиηβЛλπНвлΠν():
    value = 583593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASnHbUgV64ACAzqmn1uvNSQesGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьνΣэμЯКΓΛΤΤα():
    if False and True:
        939
    value = 244482
    text = __import__('base64').b64decode('U191Ym51ZnRSSHY3MWFUOEJvQUQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΓоΑЫΙЛцηзπдΦбβ():
    value = 316402
    text = __import__('base64').b64decode('Y0lqYW1tTmNSbTRpUE14QkNvMUU=').decode('utf-8')
    total = value + len(text)
    return total

def _НγζΩПУбФΚσ():
    value = 764694
    if 43 * 98 < 0:
        _dead_3790 = 595
        pass
        pass
    text = __import__('base64').b64decode('RFZWTU9PS2RnTmJqNFFqUzZjWnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΔзΘΘЖДаΑШω():
    value = 471646
    text = __import__('base64').b64decode('TzN1QkFiYnM1QkFlSHF3TkFWSjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨνтъяШьЭуМ():
    value = 83834
    text = __import__('base64').b64decode('T2dubGF2NTBqZGxyVkNOMnZ2RXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥзφЗымδΙλз():
    value = 316456
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kyz+T2Md5royaFeS6w6bFXJ4t2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6793 = 828
        362
    return total

def _иДΠΓюΦΑΒΠ():
    value = 563816
    if False and True:
        pass
        _dead_6216 = 363
        81
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAXhVkIzq5JTKwaUxXqXJhU9yHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щэтπбΚχЪЖэедΦ():
    value = 457514
    text = __import__('base64').b64decode('WFJyWEpsZUxVZE9zSXhNU2ptZVY=').decode('utf-8')
    total = value + len(text)
    return total

def _сτбμυИΔМмΧИ():
    value = 455168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3e3dmE91vs2NyOUyWOaOBYV3lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εТХοΒвξυθΤнГηΓΖ():
    value = 41224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwPPO3wVqq9Wbj+a6w6XMSAG1Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НХηТΥВмЯшЬъ():
    value = 852014
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bgv2ZlMe0JgbGB+q53+jAyAJ53Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΙГгΞъΝмцЛαЕцф():
    value = 58137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATa9eWMf/4YpPxz6zl+DMxB49Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬяΜγρжπцΔ():
    value = 685790
    if False and True:
        _dead_2641 = 795
    text = __import__('base64').b64decode('WG9pQWNyYkh4S3lLSFBKbUt6VmY=').decode('utf-8')
    if False and True:
        _dead_5054 = 774
        537
        _dead_8385 = 13
    total = value + len(text)
    return total

def _μХπΖαюхЬχ():
    if False and True:
        pass
        680
        _dead_8317 = 520
    value = 475221
    text = __import__('base64').b64decode('REJsWnd5OWF0WFZpYkFOU2N5dFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧжЮвΔВШХτΓωυδ():
    value = 809855
    if len('') > 0:
        _dead_4309 = 733
        _dead_1165 = 83
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRXcXXgq154QOy6X33CYHzIc8mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ААσηΓΟЮрФСЛсΟпдь():
    value = 155590
    text = __import__('base64').b64decode('VjhHUEttcXBBZEZySHJmOVVPWmg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        397
    return total

def _гИбЦйГοъЫнэУ():
    if False and True:
        _dead_2598 = 653
        122
        pass
    value = 251470
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxblQQIDyZAXHSby33ujHHI5xzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΑыΙДяσμщρаьАЪР():
    value = 983676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyyzPn812b0gCQj032mXJXc16Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нЙСБΗуωδΓьιΓДοмб():
    value = 606231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARjUUWZp96Y3DCSXmXGkJw92tks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        988
        pass
        pass
    total = value + len(text)
    return total

def _ЛςБΘвъΙдЗГВЯчН():
    value = 669200
    text = __import__('base64').b64decode('TXlKVEgyd0drZXR5SGFGSnBma3E=').decode('utf-8')
    total = value + len(text)
    return total

def _яРУДγωУΛ():
    value = 81895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDfwa3AU6v9aIA30z3vGOXB9z0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жнτСεΕλΧГЛΡοΥЮЬЭ():
    value = 575994
    text = __import__('base64').b64decode('cHVycVFCR2dFbDFVbERTWU0zaXg=').decode('utf-8')
    total = value + len(text)
    return total

def _щгωдйЬΧЪιвΜУПηВΓ():
    value = 237039
    text = __import__('base64').b64decode('azZWb0dZUlRhZnRpTnZTc0p2dng=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖψйиЙоХчΑΖ():
    value = 30523
    if 77 * 18 < 0:
        746
        _dead_4791 = 325
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnvlVG4v5r0QCiqT8ASiPgsH1Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 56 * 20 < 0:
        _dead_1770 = 93
        625
        _dead_3316 = 739
    total = value + len(text)
    return total

def _ΩΜςнΜΖςю():
    value = 66062
    text = __import__('base64').b64decode('a0RwbTE0dFJ0aFE4a2g1ekZIMVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ωЕгλыФПΥтвЖЪяы():
    value = 564876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACT9Q3kO0psEKyCgzGWWMzQjvVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7744 = 483
        _dead_5110 = 929
    return total

def _ълСхрΖεсИομб():
    if 92 * 85 < 0:
        pass
        pass
        478
    value = 753555
    text = __import__('base64').b64decode('WmFDRUIwbHJ0djA4TUlKemxhYlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _εοРнΚЛртδΠ():
    value = 458424
    text = __import__('base64').b64decode('V3J0WFpuQUU5QTBpejJzN2JQZWY=').decode('utf-8')
    total = value + len(text)
    return total

def _НτЩПуфЧшШСгΟηг():
    value = 386716
    text = __import__('base64').b64decode('ZDJxVHd5WkJyTVU5ME9jTHNITEU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7081 = 393
    return total

def _жσΜьΚηΚЖдймΔЩМΓк():
    value = 227784
    text = __import__('base64').b64decode('bDd2SGtnN3lHVkNZeTBiSU5OQU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΔΑчΖЫκΤоеσЫшΨВΨ():
    value = 307646
    text = __import__('base64').b64decode('TlY4dTBJNW1uUTczTm1vTDRNdlc=').decode('utf-8')
    total = value + len(text)
    return total

def _иΜεюθЮбη():
    value = 649136
    text = __import__('base64').b64decode('T29YOHJCX1BJSFBOWjhsZHVVbU4=').decode('utf-8')
    if len('') > 0:
        317
        _dead_1217 = 691
        _dead_1217 = 269
    total = value + len(text)
    if len('') > 0:
        308
    return total

def _ςрμьλХΩΙΥГ():
    if False and True:
        _dead_1309 = 78
        586
    value = 144833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyazRmFt7LwaMw2w/2amH30gxTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        648
        832
        _dead_9063 = 829
    return total

def _μΒΝτΓнζμБ():
    value = 682090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn+wPWBs3/4ZbQqtmHGBCy8MxkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΜσсоЛсхбуэ():
    value = 707500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxjbQWsLxvEVP12vzUPIPDYoz2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АКСКеιЬБεΜ():
    value = 454100
    text = __import__('base64').b64decode('blhBM0VjR2dDb3VDV0w0YXMyWHQ=').decode('utf-8')
    if 65 * 28 < 0:
        _dead_5984 = 895
        pass
        186
    total = value + len(text)
    if len('') > 0:
        _dead_8494 = 653
        _dead_1806 = 760
        _dead_5557 = 523
    return total

def _ЧеιФμΑΛгчеΨΟΦ():
    value = 291180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwfNQGsRwYkAaTj6kHvGATwn62g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κмξЗΟΩκΒщАΜыρ():
    value = 454045
    if 46 * 19 < 0:
        pass
        pass
        625
    text = __import__('base64').b64decode('Yzl3bEpJbGdlTEpmQTNtRnJIZmU=').decode('utf-8')
    if 5 * 51 < 0:
        513
    total = value + len(text)
    return total

def _ыАсоμΤШςОΞщΖΦШ():
    value = 972907
    text = __import__('base64').b64decode('dVpXWkpDUHd0N1ZGd1pEUTlhOEE=').decode('utf-8')
    total = value + len(text)
    return total

def _яΑΞзЗУиХΜφ():
    if False and True:
        256
        pass
    value = 130438
    text = __import__('base64').b64decode('cXNZQ0hQb29HTFY5YWwzSGJUalA=').decode('utf-8')
    if 87 * 95 < 0:
        pass
    total = value + len(text)
    return total

def _σηΥηаМЛСйьβшЙ():
    value = 828660
    text = __import__('base64').b64decode('VU1felA4anFoc0NSN2dNQkdiQ2U=').decode('utf-8')
    total = value + len(text)
    return total

def _τГγяпмπгхΗτμ():
    if False and True:
        146
        _dead_5706 = 350
    value = 145028
    text = __import__('base64').b64decode('bnB1T0xaNU1XTHpvbWQ1bkNEc2I=').decode('utf-8')
    if False and True:
        862
        _dead_9346 = 887
        564
    total = value + len(text)
    return total

def _фΞВАШюκШРВηЛУтчμ():
    value = 804822
    text = __import__('base64').b64decode('aHR5Yk90cnBQbHZOaGpFX1VjaDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΤΥцЧЛняΣΣПφπγя():
    if 96 * 71 < 0:
        727
    value = 447304
    if False and True:
        pass
        _dead_5155 = 527
    text = __import__('base64').b64decode('VmphTndxVHd4TTdIOVZxdU5BRDc=').decode('utf-8')
    if len('') > 0:
        316
        pass
        369
    total = value + len(text)
    return total

def _ΡшвсОΣΘω():
    if False and True:
        _dead_8350 = 255
    value = 464703
    text = __import__('base64').b64decode('UE51bnRVNWJwMHVpMWZBU1lNMkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ωДγДωфΡΕОμсЫсττχ():
    value = 433334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERzsSQcKzfkFAAqlnn7BBDIe4XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩτξэввνμπΚ():
    value = 526504
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgXzXWMPyPszD16Pxg6aBDQDtEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мχφЩВфψфДэкв():
    value = 129070
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In7FfFwG8qMPEQaLm2W1JH193kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠσζξμТЫθΒΙψъβН():
    value = 734906
    if len('') > 0:
        321
        _dead_5732 = 783
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCuyOgBv2IMPY16J3Q/JMgkl50A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГФςЮΟΚΦЙи():
    value = 435243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAf8X1U63KNUBTet8gaYEQsK9Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΒЗυьЕЮЬеψ():
    value = 118021
    text = __import__('base64').b64decode('T2VyYVhRNXAxOWp5ZmlRblR4NXo=').decode('utf-8')
    total = value + len(text)
    return total

def _БэАΧΚСαЬ():
    value = 505653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHrdUQIg7pwgMx+X4QS6CxcNxWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΓηЫйθΖМвΥΗ():
    value = 458178
    text = __import__('base64').b64decode('dGtZVTJBVmVBb2hyMTB4cUptbkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ωЗШкеΤΚдκΛО():
    value = 969615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ijzrel8+7qkAPhi5kGagDHwhwlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДЩκτΛцΨОσЪηюЖυ():
    value = 598018
    text = __import__('base64').b64decode('V09kVlNaTVdLMTVwQ0xGSXYycXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΧΠЗЩсЙΔΗНςυυ():
    value = 644040
    if 94 * 97 < 0:
        559
        _dead_2873 = 955
        _dead_2265 = 605
    text = __import__('base64').b64decode('cHBpUElZT3lQYjF4UVY5MnN1eUg=').decode('utf-8')
    if False and True:
        pass
        _dead_5695 = 62
        _dead_9884 = 528
    total = value + len(text)
    if len('') > 0:
        698
        488
        pass
    return total

def _γДΖцΗρКчΔψ():
    if 67 * 31 < 0:
        _dead_7404 = 343
        _dead_5123 = 45
        pass
    value = 308011
    text = __import__('base64').b64decode('VGpIbVJRVlpGajNQNEpadnhuZXA=').decode('utf-8')
    total = value + len(text)
    return total

def _фМφΠΕЦΟθуχ():
    value = 44016
    text = __import__('base64').b64decode('RGdGUjNkNTgxV212Q0ozVHBTZTk=').decode('utf-8')
    total = value + len(text)
    return total

def _АωυΨΦμΔτΖχηПΒрωБ():
    value = 791239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXrCSXsVqYw8KleUywe+Fn040n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _λζψжыСΔκтЫВД():
    value = 530806
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyrdZAAGzL0ZCQam4XTFLnY+3V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВМщΑЫΑНΡхΖξпаЬНθ():
    value = 361793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSvcWloX56EJNCOczFGYNQ9+w28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 80 * 100 < 0:
        pass
        pass
        pass
    return total

def _βιГкΒΕПБ():
    value = 769480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cizea2UI0JgHaQqF8XuzZAwn8jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яМεЮΧжΒΘΜμдΞΟΧжτ():
    value = 451892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAXASV8A1aYPPSmL90GGAjQNx0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОнхΜПБλыχ():
    value = 96844
    text = __import__('base64').b64decode('QXVpZmFraGI0czhWdkJIY1ZnQk8=').decode('utf-8')
    total = value + len(text)
    return total

def _МЬЬβψΕΥяХящπ():
    value = 904302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgazPnthxvlTKQWqzFq9Hn0Q9GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_1953 = 1
    return total

def _ΓΦжςеΛβаς():
    value = 365054
    text = __import__('base64').b64decode('ZHY5T3NTWnZSSVUxUHBJS0xWSnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ИГПЯМΦаυщπΥОъ():
    value = 371104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXvIOmBs/bImKQenkHmeOA8Yymw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΡΞυЛθЦνиРЯсΚ():
    if 50 * 90 < 0:
        pass
    value = 633923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCi0NmlgrLEKPB71mUKCAwgfzUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΑрсДвусκжДΦΩδΛб():
    value = 367622
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRy9Ym442q5TaRaH2lehPBI58ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 19 * 7 < 0:
        555
        _dead_8845 = 816
    return total

def _ΛЕййδШэьμΒмΨеκΤ():
    if len('') > 0:
        66
        39
        _dead_8167 = 388
    value = 328216
    if 26 * 77 < 0:
        _dead_3927 = 830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3vgXGgS+qIzMD2y7EeUIgkJ1UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 87 * 46 < 0:
        pass
    return total

def _ИΙΕКтРκГРΦο():
    value = 922737
    text = __import__('base64').b64decode('ZUhkOWdrWDV3aU1qdzhUaHQxa0M=').decode('utf-8')
    if 56 * 16 < 0:
        pass
        759
    total = value + len(text)
    if 27 * 37 < 0:
        818
        _dead_9253 = 420
        _dead_3461 = 516
    return total

def _ЦЖΑΥщРюΛΒж():
    value = 386521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzbzYHourbgXIFeBzQ+JEhAn3lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        999
    return total

def _НлωΥΗРЖЯыВβгПΝΒЮ():
    value = 530689
    if False and True:
        pass
        _dead_1143 = 961
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQvVSQNh9KElaBeS3kLAMnYQ9kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1835 = 133
    total = value + len(text)
    return total

def _згΤгЮΨνЬЕξиΛЛЮ():
    value = 752271
    text = __import__('base64').b64decode('RGQ1WTZuSDBaVlBZRFdwcUpBVVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓмΚжкиЩΒфλωы():
    value = 975922
    if 62 * 93 < 0:
        _dead_9527 = 409
        808
    text = __import__('base64').b64decode('WDRIdnBOT1dMNzgyaUhUSk5NVzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ТςαΧΕъχΡзщчχΙΒб():
    value = 169287
    if 43 * 56 < 0:
        pass
        _dead_7263 = 78
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzaxdlYJ/fhTOVvz7Gy2DjUJzXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡτЙΖιЖЩΕ():
    value = 994403
    text = __import__('base64').b64decode('dlhoWTdpcW1XdnJoWURpelR4TXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΒΑмΝΖκιΓΠзΚйэξ():
    value = 166986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhziaX5u968SHx2Hz2aSHz0ZsUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηУΖакЫαЧρ():
    value = 83217
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxXJN1cV8fAGOQyTkHm7LisZ408='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чθГкΑσвΒщγуσβ():
    if False and True:
        pass
        _dead_3161 = 380
    value = 380933
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw3rPFYj/KwNGCa76ViiHSAKxn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΗняюλгρτΣΖ():
    value = 702765
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzfzTGsRx4EQPzf13n/EB30B4nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3537 = 653
    return total

def _юσЛЖυэΖΙ():
    if 9 * 86 < 0:
        pass
    value = 124757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnbuS3ou16wsCTen0V7DOycitUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρзтΤбδЩγΠбб():
    value = 488045
    if len('') > 0:
        pass
        284
    text = __import__('base64').b64decode('QVFjNmR5TGl0QjVfNUthNUJKTVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ШоΣМЕΙспΨмΔΟОΞуя():
    value = 801752
    if False and True:
        547
        pass
        _dead_9568 = 789
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwDNW30u055VKSmlyXKyYSAm7Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τпθεκЦВхεцΣЪδ():
    if 44 * 90 < 0:
        pass
    value = 779694
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBf1f2M7/ZxUABqk5FSlPHQkvXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΙсАχοΤлλПπкБ():
    if len('') > 0:
        _dead_8793 = 944
        pass
    value = 848502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxnUdglqyKYyGRmyy1WzAz0l710='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΟЧοбΟДтмΑНς():
    value = 179787
    text = __import__('base64').b64decode('ZDVZWFV5MGVhQTg3N3VzRlBJZDE=').decode('utf-8')
    total = value + len(text)
    return total

def _εлΣΜеОγиΩΨιщπΣК():
    value = 425527
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQDIWwUrzvszMQPywX2UCzwfxWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θоТЕΘΑΑЧВζΛхδЩ():
    value = 928197
    text = __import__('base64').b64decode('QThjazB1YzBsZXIxODcySGo3enQ=').decode('utf-8')
    total = value + len(text)
    return total

def _νяυЖψцΧцπлδк():
    value = 636083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3jiOG4gyf8gP1zw/0a6EiEq4lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3547 = 407
        _dead_8824 = 326
        pass
    total = value + len(text)
    return total

def _ΓαΜοΨъШюВΣ():
    if False and True:
        pass
    value = 872863
    text = __import__('base64').b64decode('V1BkeVhFdXRCN1h4XzhaZ3BQQ0M=').decode('utf-8')
    if False and True:
        229
        pass
        pass
    total = value + len(text)
    if 89 * 26 < 0:
        591
    return total

def _иГςδжτяΛΜ():
    if 13 * 9 < 0:
        pass
    value = 331026
    text = __import__('base64').b64decode('dGN5cENVRDc3X2FsNEVSNjJqdWM=').decode('utf-8')
    total = value + len(text)
    return total

def _бГΤзХтςЧэвЙνгΨΡΘ():
    value = 364328
    text = __import__('base64').b64decode('YlZBUVdLSm1EWDc1dllqeW5oRUU=').decode('utf-8')
    total = value + len(text)
    if 88 * 37 < 0:
        pass
        _dead_5526 = 127
        _dead_3194 = 932
    return total

def _βефжγАШнЭяΒдъΒΕЙ():
    if False and True:
        272
        pass
    value = 796163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjvDWWQf36ICEza03nSlPAR9zXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩзОνΧпΙΞыАΔоВΜ():
    value = 408588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAz3QGNh+J07K1662g6vFS4H0nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОοсэςΚЛоΔСЧГд():
    value = 916069
    if len('') > 0:
        _dead_2528 = 285
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzzsdFsw96srGyP15QCqHxUgwGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΜρЖΞюАМрйыΙγж():
    value = 736216
    text = __import__('base64').b64decode('S3BBd1VRRV9FUHZyRnVpM0tUc2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤφЛυζΑаНτе():
    if 46 * 10 < 0:
        26
    value = 372940
    if False and True:
        pass
        _dead_2173 = 172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCrrSEBq6Zc7OB2mmmW8PhB7w0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТрξпРЧεвоΒΞβΑΙΩ():
    value = 427413
    if 20 * 19 < 0:
        _dead_5361 = 148
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISDzXHc10Z5QbTqx3F65Diou6Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        719
        pass
    total = value + len(text)
    return total

def _рΓΠзкΔΜΖЕаТыг():
    value = 977320
    text = __import__('base64').b64decode('Q29JWjR6N2pfN0owMzgxWE1QclM=').decode('utf-8')
    total = value + len(text)
    return total

def _ψэъΛγаЭΥδΥ():
    if len('') > 0:
        pass
    value = 997340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz3Ub3AI15sFKDm063m1Bw4Y0mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 10 * 69 < 0:
        269
        772
    return total

def _ΜΒσΣтюИΓМτюуЗбζВ():
    value = 956660
    text = __import__('base64').b64decode('WlZOX3VTWTJ2NDRGSFpERERRZGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ДξТНсаЭμМΖΓφ():
    value = 487244
    text = __import__('base64').b64decode('Y0dOYnlUd2FpMEF6RDJHbVlFbzk=').decode('utf-8')
    total = value + len(text)
    return total

def _еуЛЖнΕΑНβдЮбчФХ():
    value = 599695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hxiwemgrr/oFCgCH62PBbSo6zDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЙдЦиВчэδПΤθΧΜц():
    value = 356674
    if 66 * 38 < 0:
        550
        928
    text = __import__('base64').b64decode('UktpNVl4SXEwQTZHR1g4WlBVaEs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        625
    return total

def _ЫθΙИГрΚТ():
    value = 116971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERfvOHsj/IAGYy2t7nybFSIW/Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эЪλСЖΨсΟΖΧКЪое():
    value = 543566
    text = __import__('base64').b64decode('QkNzY2p5dFJnS3ppTWV4MGlFSUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΦδΩωЭξрбХЛВΚμα():
    value = 111163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCHnX3MLxqULHw2H2m+9JAQrzkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ФθΤзФΡΞЕУУщΥ():
    value = 193957
    if False and True:
        348
    text = __import__('base64').b64decode('RHdsOXpWNUZxRFU0X205OTVya2o=').decode('utf-8')
    total = value + len(text)
    return total

def _θщРВλΗшндΤмθΡ():
    value = 91565
    if len('') > 0:
        _dead_4172 = 870
        _dead_9519 = 887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An+1bW4LxqUxBVyUx3OqHhwX520='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АТφЕФξНЮЩΔоЭэИкб():
    value = 591096
    text = __import__('base64').b64decode('aW9VZUUwQzBpVVBrYjYybFYxV3g=').decode('utf-8')
    if 52 * 10 < 0:
        534
        563
    total = value + len(text)
    return total

def _УΩΗДрУОΚЫР():
    if 25 * 78 < 0:
        412
    value = 820580
    text = __import__('base64').b64decode('dFFycE1fMG91dW9iNWEzQzQ2dXM=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_1957 = 687
    return total

def _ΒкЪеλзяЕΧοЯγв():
    value = 271959
    if 38 * 70 < 0:
        _dead_9585 = 552
        _dead_1776 = 98
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQe0UUQAy/w2MzahylCSIQN611o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥрмпАχТξΙπТ():
    value = 746152
    text = __import__('base64').b64decode('czRkTDdfWnBDMVRkVWM2TFFZQ0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΤгюЭδΑвΙсθуγп():
    if 5 * 29 < 0:
        349
        102
        949
    value = 346819
    if False and True:
        998
        pass
        746
    text = __import__('base64').b64decode('ZVFzMkFFYWY3bXlBZ085M2VYVHM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        72
    return total

def _тΔπпαЦΒоязХ():
    value = 744262
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXnBQH5t+qwODCz14EeRNw8W4mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΦΛУмΖζζ():
    value = 431547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExfHWFUR/4JVaByH9wCYMj8bzkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔψΛкΝβЗνэУМНЕ():
    value = 353369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DA7HT0QW0fwqNjyb90CKGgYuyXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЭΑυΗτЭджτκΘд():
    value = 99510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh7dOV8hrKIaCjqCmgSgBwt85W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЖλοιρАжρΩψ():
    value = 24993
    text = __import__('base64').b64decode('QldEVmVRYUgyRmZySUhQREwwOGU=').decode('utf-8')
    if 9 * 28 < 0:
        pass
        _dead_4625 = 72
    total = value + len(text)
    return total

def _εχбΕΘκФοбωΙδЮζЮТ():
    value = 516428
    text = __import__('base64').b64decode('U1FYNjd5MUhZdWZFd20xN1pOZ2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩфРΣΖΖжЭΜ():
    value = 198573
    text = __import__('base64').b64decode('TFdwMF80UFFvUGtEMzE5WW5qSmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ъФдтрюμыиГΓΦ():
    value = 805517
    if len('') > 0:
        380
        _dead_2453 = 422
        382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRfSQQQyyIwVbzac+l6hYjZ+8V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тцУсюцчδжчПДρш():
    value = 315031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHniZ1Qb5KEREBmz3VmAHHADz30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΕлпΥΞВτΤοχπЗеωЯ():
    value = 581196
    text = __import__('base64').b64decode('akVzZkxnVElKbzBUZDVydGR0Mnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ψкγЭγιБхсдσЛб():
    value = 727829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX/rQXQS9rwoHwyp/mOxYyc64Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТРΗашддИЫЯΜИЕНЦ():
    value = 563761
    text = __import__('base64').b64decode('WGtiY2NLNjFGOEJROW5ETlNoaVc=').decode('utf-8')
    total = value + len(text)
    return total

def _юнБΩΕЫчвАП():
    value = 424143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXrOb1Bu7pcBNAK6xnSYFwIMsX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НЛСтцφВΚΛь():
    value = 381496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgXMbUsM0bk0LVa2nXfHFRMK5Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΟΒоΖΞеξμ():
    if 84 * 58 < 0:
        _dead_7111 = 269
    value = 206411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyzVdHUe+JoraS6Qwk+pbXA3/Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΦΡЙХЫЛп():
    value = 188356
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTXdZ2Mf35c0KV+Q53+IOAEG4V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙγПХЫЪсуΣЬΛюψ():
    value = 818121
    if False and True:
        598
        pass
        349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PASybUY78IJRLDyv0VnIJRF+3Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яэζΥшηИкΣдЯθΑб():
    value = 573561
    text = __import__('base64').b64decode('UlB4OHpRZHQzbHJaUGdONzZ6VGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑχрΟзоΚΨ():
    value = 29898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX+xYHMy95ssIiL251+7HzcfyHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 39 * 69 < 0:
        pass
    return total

def _лΥΜЛОБτΣΥИπМΨдЪ():
    value = 891326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyDMamg1/YxTPguS+FDILTU/wVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5984 = 476
        290
        pass
    return total

def _ХΣΝыюψΜчпсΙдА():
    value = 52972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDvGYmUQy4dSNCiq2HTHZH199Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щюΒεБоъИбτδδАΞпШ():
    if 87 * 34 < 0:
        pass
        _dead_3817 = 168
        pass
    value = 172900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwXMSwMM54BaEyiSy3yoOCJ3wko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        316
    total = value + len(text)
    return total

def _сИыγθсюн():
    value = 194963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh3vOnYhy5AuDSbz2XGyATwex1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЯΣСФχγзνΠ():
    value = 521940
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgewTG4G7/45Hh+zmWybZTd34UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кσΚΡβшτе():
    value = 37239
    if 44 * 76 < 0:
        440
        _dead_7684 = 291
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kgz9ZAIfpq8xM12S0AfGDg8292U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΠνμЬСΞчЮΦ():
    value = 746519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnfzXnc0zItVOA2a0Xq1IXUr7l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6802 = 457
        pass
    total = value + len(text)
    return total

def _уωιИΗеэβ():
    value = 161450
    text = __import__('base64').b64decode('bW12TnZOcGRIaG11S1hFbWFNbjU=').decode('utf-8')
    total = value + len(text)
    return total

def _βшфХΛиΔЪωΖ():
    if False and True:
        _dead_5315 = 591
        _dead_9821 = 960
        _dead_6232 = 563
    value = 501165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTzdUQEU6fw2CB2N91qHABYWw0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 42 * 9 < 0:
        pass
        306
        962
    total = value + len(text)
    return total

def _σωцμДАмДШЦщδσЖы():
    value = 162245
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgHsa1AbwaswOAynmkTBMyEn0lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜλУДфςюεΚЛьΔ():
    if False and True:
        _dead_5314 = 229
    value = 395181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECfwPkEs6pg7Mjq6yXGZHAk9tkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9462 = 261
        pass
    return total

def _цλцГυκΓМΥμζ():
    value = 939658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDXPbVtq+qcBHV670mbIZQoA1X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЦтσΨИΥыπΡН():
    if len('') > 0:
        pass
        _dead_9538 = 487
        pass
    value = 329357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3yybHM484pVNAmnzWKYBw4rtWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        628
        551
    return total

def _ιбΧфъНιгληТςν():
    if 2 * 15 < 0:
        pass
        379
    value = 500675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyzlOlsPzq82DCCm0H2BPHYEtHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9772 = 469
        571
        203
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZA==').decode('utf-8'))
if len('xxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    pass
    824
    _dead_1073 = 406