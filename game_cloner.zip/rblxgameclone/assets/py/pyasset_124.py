#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΨΠЬЩрэιв():
    value = 376682
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cgq3aQco1oYHHVr04Ea0ZCMd/ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7480 = 879
        pass
        pass
    total = value + len(text)
    return total

def _κνΔМшΝфυКьх():
    value = 697181
    text = __import__('base64').b64decode('U0NGTnNTRlhaTk9KSkRkR21yN3A=').decode('utf-8')
    if False and True:
        279
        927
        pass
    total = value + len(text)
    if 57 * 94 < 0:
        pass
        _dead_6943 = 655
        _dead_9628 = 851
    return total

def _σАЙуΤщμхш():
    value = 394877
    if len('') > 0:
        _dead_4292 = 363
        _dead_2358 = 221
        280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX/pN2Npr4Akbh6AnQe1FSoE8Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хйηψχιЫφΦκμ():
    value = 519234
    if len('') > 0:
        _dead_2835 = 124
    text = __import__('base64').b64decode('cUhYdUlOVk5ud0VrbkdIYmFSTEw=').decode('utf-8')
    if False and True:
        _dead_2137 = 805
    total = value + len(text)
    return total

def _аъМеигйκ():
    value = 255738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3nTWGAXrfw2HQOt7nicMnYJ9VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъγЕЕвΖΒΟнФΒ():
    value = 319467
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwWybGM88YwqAxiSxHWZHnx2t14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жДсαИЭпсБчъ():
    if False and True:
        pass
        pass
    value = 832476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnzINnVrqKBUFwTzx1qbBAAk8X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ншИΣНуЭекρтыОμ():
    if len('') > 0:
        454
    value = 46492
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDj1eXoorrELGDez6lGKAQ1+7zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΛкρАфхΧспйЪЫ():
    value = 242248
    text = __import__('base64').b64decode('eElwRDFXNEZ0MFU4V1YwMUtoWnA=').decode('utf-8')
    total = value + len(text)
    return total

def _μхεзΛπΤЩЙΓдσΡ():
    if 24 * 29 < 0:
        pass
        _dead_7424 = 543
    value = 358749
    if 20 * 25 < 0:
        338
    text = __import__('base64').b64decode('cVZ3MWdDXzkwNzgzYUN2bEVfOGg=').decode('utf-8')
    if 88 * 51 < 0:
        pass
        pass
        _dead_4353 = 2
    total = value + len(text)
    if len('') > 0:
        pass
        519
        _dead_7234 = 951
    return total

def _лАлεхωСюКπШо():
    if 60 * 44 < 0:
        _dead_1093 = 132
        698
    value = 318632
    text = __import__('base64').b64decode('Yk9QUDJyUGN1SzFRbnlwX1B2elA=').decode('utf-8')
    if 94 * 77 < 0:
        _dead_3155 = 77
        238
        _dead_5500 = 414
    total = value + len(text)
    return total

def _σΞΣΞЦΥЕСβ():
    value = 718444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSuwV1cO8vguagytn1KhIj0B/EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΗттнбΚаМΑηΖнМ():
    value = 698968
    if 57 * 87 < 0:
        _dead_9343 = 502
        744
        873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHnWb3IN05kZCCzznFHHDBMhtk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1204 = 600
    return total

def _лΛιΑядτПУ():
    value = 689202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3jXQ0EPqJolbS63wgaGPjV56lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΙΜςΖξΩжбΝГжф():
    value = 186261
    text = __import__('base64').b64decode('b2x4c3lsYzZNVlg1U05tcFdDNXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЭПфФΖρτфλЦ():
    value = 856880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jgq9WQcTr7IHbyKG8l+JH3cc0Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЫαУΔДцИΡсЦΔΓСΓьС():
    value = 926298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITbQPwMO6KpaPjaF5lmJbSsG3WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΔзΙшэΓψюРо():
    value = 481472
    text = __import__('base64').b64decode('SmE1OGI0WjdlOWRYMVRLbUR3Z1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΤΡφРΓШεΥшАχΩЭв():
    value = 401437
    text = __import__('base64').b64decode('SG1rX2h0WXRLUVhYTk9ZZm9QR1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜуιТΘФΙзαΞβ():
    if 90 * 34 < 0:
        pass
        _dead_1839 = 593
    value = 217234
    if 82 * 77 < 0:
        143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBbsPlku55IXKVeP4wGmEwwotms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 38 * 85 < 0:
        pass
        _dead_1224 = 538
        pass
    return total

def _ΚΡΝΜкΒИθΣ():
    value = 429271
    text = __import__('base64').b64decode('WHo0Q1VRdzZURjdBWXFIbnAwZ0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪВфОСИψеζцσςЮΕфΦ():
    value = 539067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwnUf1oAqvtREhW56Ua0JSQE8Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΥΒξтпλюэзыаΕΜЗш():
    value = 431454
    text = __import__('base64').b64decode('c185X25LQ3lrZFV0QUJCVWRLSFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥЯωψΝΕйΓрΝ():
    value = 312858
    text = __import__('base64').b64decode('WG5laElTMmdwSENGakJMVU1UdV8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6770 = 744
    return total

def _ФρюΓМοмрΡКОΙщжМ():
    value = 808433
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('Sl9GVTltWkU3b21ya3MyemhKbXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _χжЮцьпοвйψρΠΙΑ():
    value = 866408
    text = __import__('base64').b64decode('aXJYWV90Rkp3MExlQlNHZDdZV1U=').decode('utf-8')
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        639
        _dead_8439 = 878
    return total

def _УρσлЫκфλуΙΠЛж():
    value = 950479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Knn8O3kG+pwMNxyo2FuZPwsezVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        589
        pass
        936
    return total

def _яьωЯρωъΜЫΕмΣЭфЮх():
    if len('') > 0:
        _dead_9480 = 695
    value = 454064
    if 44 * 96 < 0:
        pass
    text = __import__('base64').b64decode('TGNJdlhWM1dfamJod0JwYlc3T2U=').decode('utf-8')
    if False and True:
        828
        pass
    total = value + len(text)
    return total

def _διрОζЬψНВЕΡΣΗΛ():
    value = 979831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX3eZmE+8olRLymUzmOfID0N/Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        24
        223
    total = value + len(text)
    return total

def _ΨшТΞλЖοЗΧуεИВΝ():
    value = 841767
    text = __import__('base64').b64decode('dWJaSWhwRjlvNk4wMEtiYTkyZkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤοРВРγЭфЮк():
    value = 678963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgrDWFARy5lQFlaZm0+ZZCJ8sXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΛДΨρΩηЛφФГ():
    value = 70850
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyvgTVwMrplTIF3xy0PFZQB40H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        919
    return total

def _ιГуΔряΡΝΝζ():
    value = 268010
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhjwV0YM1pAaNhWM7gGyFiMg038='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыйυЫиσюξΨμΟ():
    if len('') > 0:
        79
    value = 495992
    if len('') > 0:
        696
        735
        _dead_5757 = 746
    text = __import__('base64').b64decode('cHI5U0FkQ0txMGE0TDVaTFZ2bWk=').decode('utf-8')
    if 24 * 69 < 0:
        pass
        640
    total = value + len(text)
    return total

def _ξΧροжΧЗΠСδЛΦβлвΛ():
    value = 839512
    if False and True:
        pass
        _dead_4549 = 206
        pass
    text = __import__('base64').b64decode('dXczUmp4bHRQX0U0eWEyOEVsOE8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8384 = 640
    return total

def _ЕΥΨςЪйЧиюпζщк():
    if len('') > 0:
        189
    value = 758017
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3zoXWAI5oErKgSU93i1PjB2yGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥβЯаζυΚΣΩФΔΖЕ():
    value = 405257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyPWPnkX5KU7aCSJ2liZIgoqsVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫψДжТΠюΡΝ():
    value = 570948
    text = __import__('base64').b64decode('Y0ZEWFgyWkZ3OEhtU2FNalpCQVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΖλфЧχΖЖΝο():
    value = 237784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fn7CX0MOyLFaCTar+3qxNyJ/y2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΘВфСκЭЭΒтυЬ():
    value = 610037
    text = __import__('base64').b64decode('ckx0OUZKR3lxbHhaZGE3Y1JDaEs=').decode('utf-8')
    total = value + len(text)
    return total

def _φκруβλξД():
    value = 895365
    text = __import__('base64').b64decode('dzI2ZGxxeGp5WElqMUk0WEZDcjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЧΖЦβΦБншкη():
    value = 419222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHvvWlog9/EBLB+y8gHGHy8n9V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΟЗΑФХΣΜжΜеΞθακ():
    value = 755374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyH1N2do6qIyHl2czX+GJHE76jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΕеВξВщНΔьйДыЬΩ():
    value = 639281
    text = __import__('base64').b64decode('alo2NG1JNFhVZ0p4d2dTY0hudUg=').decode('utf-8')
    total = value + len(text)
    return total

def _δΛЮнЩХΒΒ():
    value = 163777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBDVRnA98qlaLl6A2wOTJzYjw3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡЖьдΖВЗπкμψЕЯЮ():
    value = 33542
    text = __import__('base64').b64decode('dTE2ZTQxSjMyVElVRDJ1Z0RLTHk=').decode('utf-8')
    total = value + len(text)
    return total

def _РвΠодЙφФφΟоуγ():
    value = 757366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ii7MeEUG7K8xN1n043uUPDUm0Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οмЯκΟГхПΖ():
    value = 81869
    if 47 * 59 < 0:
        _dead_5930 = 813
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETnrf0E3z4ISHxyx0lmTH3wM3Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 76 * 14 < 0:
        pass
        199
    total = value + len(text)
    return total

def _уθВΤφфςΠλ():
    value = 856692
    text = __import__('base64').b64decode('S3JuWEpqamxzekEyYWh3SDRkRjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟкΟβилхШ():
    value = 123256
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnuzTwMOwa0xGBeRyXCaESsJyGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        75
        _dead_9066 = 166
    total = value + len(text)
    return total

def _ьцδзЕЛΓЫвЛйтюЛ():
    value = 512070
    text = __import__('base64').b64decode('amZ6TVhud0NTUE9XUDNzQUU0MkM=').decode('utf-8')
    total = value + len(text)
    return total

def _νθЫΜΔЛСςγξиЫβТ():
    value = 61523
    text = __import__('base64').b64decode('a0p1T1c1a0o0RXVfWXREU1BtMWE=').decode('utf-8')
    if False and True:
        _dead_7042 = 83
        pass
        pass
    total = value + len(text)
    return total

def _жЪфΜфΣбМ():
    value = 668235
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCr0Ylo6xK4RaTWMnHWiYAkNzTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οкΓРКιφεсΜΚΙ():
    value = 29103
    text = __import__('base64').b64decode('eURGNGFadFdSSGhpb2RKTmVocHc=').decode('utf-8')
    total = value + len(text)
    return total

def _иЧΦСЧТΡзРьБнΕρрЖ():
    if len('') > 0:
        681
        pass
    value = 177150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCH3XXtv1JgLC1yH3mWYIgoL42U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        564
        pass
        pass
    total = value + len(text)
    if False and True:
        543
        pass
    return total

def _ъУпДΠБВξиΨщТΦ():
    value = 448030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnboYgML6pAlOFe0mn6RLSQ/zV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _еΝцдΚКЦθыбнΥΣ():
    value = 451028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzzDXmIa+fEoAFyxzlyVFRAd418='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яЗцЗЦλΜБмυωц():
    value = 21657
    text = __import__('base64').b64decode('RmtnOGxvX2RMbzk2aWJYOG0wb0o=').decode('utf-8')
    total = value + len(text)
    if 27 * 46 < 0:
        pass
        848
    return total

def _ЩлπΥΓкщΑн():
    value = 127940
    text = __import__('base64').b64decode('RTBObjBwU3ZQQWlOTnUyV1pjZXI=').decode('utf-8')
    if len('') > 0:
        _dead_1766 = 563
        917
        743
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΛлΣΤыμдмΨлГзθТЯψ():
    value = 763741
    if False and True:
        258
        pass
        pass
    text = __import__('base64').b64decode('aHBEd21Td0FTWFFaTkg2R1E5cHo=').decode('utf-8')
    total = value + len(text)
    return total

def _λρцхΖрЦφ():
    value = 293897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jx22fkc2/Js8bSi7/3mJByl240A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ραВσМοьο():
    value = 971929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQLxQFYt+6IbCwHxzkDCYSM11T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΠжлЖΞХζу():
    value = 445001
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSDlfXMe9akba1+I+3GIIQ8dtF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хπСкЛЛВэνЕыζЦα():
    value = 285368
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiXMQ0It7p0KLgOgzWadHAci2zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пеъπηθΜж():
    value = 680840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTfPYQQfy4c1DAG22QOoDB8Z50E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙшХζВГΒуШσСМивЩ():
    value = 352499
    if False and True:
        pass
    text = __import__('base64').b64decode('QmU0WWQ5UmFaeXRrSW9ZZTI3Ykc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦчТДяЬлΞΒмΓРУСП():
    value = 204893
    text = __import__('base64').b64decode('ZGg1cXpIOG1VSmQ3WHc2R2Z6eGs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6291 = 205
        107
        pass
    return total

def _ЪПЬытНйΞΣθКΠΟЧЬς():
    value = 835036
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXbbS0Mp7rE7Hxel2VOmMi8XsmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЭЩаκяιРю():
    if len('') > 0:
        pass
        _dead_3084 = 452
    value = 822233
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSq2aF899fwxIAuB3QCEYDx98m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юытЯмбэкτηβС():
    value = 657433
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('WW5wQUVNRzBSSEZ1U3dhVkZpdGE=').decode('utf-8')
    total = value + len(text)
    if 95 * 90 < 0:
        pass
        _dead_4244 = 728
    return total

def _υЬΦπβΦοУΥЬΕρюЧХВ():
    value = 809841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQfbb1UV1o4JEwmO+3yEHSIntTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭОΤγяσоЯΓχΙΛд():
    value = 155401
    text = __import__('base64').b64decode('TzZabzZCZlZySkc4R05JTTZHQUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ГсτκΝΚπτНΠΜО():
    value = 172727
    text = __import__('base64').b64decode('SU5hcFBRbVU1M1lweXFRVXVNdEY=').decode('utf-8')
    total = value + len(text)
    return total

def _эρΟННσΩωσуγΝ():
    value = 52778
    text = __import__('base64').b64decode('Smthd1JlYnVYY3RUMTZwYmFvS0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒЗχеψψБКышΟПΔσиσ():
    value = 718013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwTFbAhh+IYmDQ7y4EalIhMr8UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фрУνяΝψФхμчΠεЯ():
    value = 910498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgvBandr67A6Pg3x/UOWDhQssDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 5 * 17 < 0:
        184
        _dead_4719 = 879
    total = value + len(text)
    return total

def _ςВзыЙАщмюЧНЧРβэ():
    if len('') > 0:
        pass
        _dead_3860 = 178
        pass
    value = 329757
    text = __import__('base64').b64decode('Z0JMYllpN3JCUkVWcWdyOWNiUFU=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΑΒπΣΡфΒω():
    value = 780246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR7Mem4op4M6HRyPyQWZIzF41UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4894 = 206
        pass
    return total

def _ΜиΑокΘДБФ():
    value = 900799
    text = __import__('base64').b64decode('SkVDaTdBcVBOcE1DOU1YbWlMNDg=').decode('utf-8')
    total = value + len(text)
    return total

def _еФρΤΟΙШэλоοΙυЗ():
    value = 907204
    if False and True:
        305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQjBewkB1aQ8GTegm36nISM6/Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЬЪΖЕШуЙАΒФρ():
    value = 876276
    text = __import__('base64').b64decode('V2daSUlBd0JrZ2xoYjZpSll4TW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫПНняЯЛЛθΛΧΚψΔФζ():
    value = 99644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj+yRwkG14ILEjaU+wSyGDZ59Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        794
        _dead_2165 = 734
    total = value + len(text)
    return total

def _лГЖчκΖяΜμμΗυб():
    if False and True:
        pass
        pass
    value = 974050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz/uY3UxxoUyCBiX2wSYBgIk8mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дгеποвУМкψΗΟ():
    value = 383737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCLrOHkqqvhWFCC53ADHPCEj0nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рНξЖστтΛκЫΝЪЖΓοы():
    value = 161269
    text = __import__('base64').b64decode('WUtRekxIamp6VW5ha1c4Mzl4bk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ωαεΟЬДςδь():
    value = 649405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATbAREY8yZkLYyPx/32cGR8ptGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧοфεДηгσΧмвεыΨу():
    if len('') > 0:
        pass
        _dead_5297 = 861
        _dead_6599 = 420
    value = 970752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSm8YVk62pg2aRmHyn6kPQE9xVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8255 = 424
    return total

def _ςилΦФэчШьэΕИБщАς():
    if len('') > 0:
        _dead_8937 = 954
        _dead_7635 = 374
    value = 978503
    if len('') > 0:
        pass
        _dead_6765 = 445
        _dead_2925 = 785
    text = __import__('base64').b64decode('V3B6eW1wUUZoRGs0VG85dkpkUkw=').decode('utf-8')
    if False and True:
        _dead_3536 = 323
        908
        89
    total = value + len(text)
    if 5 * 14 < 0:
        _dead_1403 = 698
    return total

def _НΓΜИгγНКВΛΨβΑ():
    value = 996316
    text = __import__('base64').b64decode('STRhbUxTZjZ4dTdMdVU2SjUzV3I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5744 = 657
    return total

def _занκЮβςη():
    value = 520383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzvtTEMb1vkyFh30432YORZ/sT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йкΕЙкфТИу():
    value = 449015
    text = __import__('base64').b64decode('QnBtaFN4VktQbXhSVm9wTm0ycDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫωфЯПςъЖΟΟΦ():
    value = 417651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgvUSGQTx4wAPT6Nz1qDJHAc3Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъςΛκРιιРйдПМэЭ():
    value = 857065
    text = __import__('base64').b64decode('a3BhUHVQT0U5YWhRRklKdEwzWUM=').decode('utf-8')
    total = value + len(text)
    return total

def _тБруΓφψШΞκТэΠπ():
    if len('') > 0:
        _dead_2126 = 370
    value = 887200
    if False and True:
        572
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjjGd0cU3/00Mx2LwnmXHisX7VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 95 * 22 < 0:
        418
        756
        _dead_6839 = 784
    return total

def _хНΗψнУζωΞιЖсзδΜ():
    if 66 * 7 < 0:
        185
        _dead_2937 = 909
    value = 552000
    if len('') > 0:
        718
        pass
    text = __import__('base64').b64decode('S3g3MkFGUXFtOVFhYXJKX01uekI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩυюЪшωΑЬДРΘΣШэув():
    if len('') > 0:
        559
    value = 569033
    if len('') > 0:
        311
        _dead_6025 = 45
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXnob3cd2JwpEgus/kaBNXQu0UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2175 = 843
        pass
        pass
    total = value + len(text)
    return total

def _ΨξΜГΞτбЫγμΚθγД():
    value = 852929
    if 100 * 60 < 0:
        916
        _dead_3136 = 710
    text = __import__('base64').b64decode('YlJCUHNuYmh2cDJTekJ2aEtmWVI=').decode('utf-8')
    total = value + len(text)
    return total

def _пχДΣРКсШ():
    value = 112842
    if False and True:
        _dead_3225 = 399
        _dead_2728 = 496
        _dead_9031 = 781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCjmRAAwzpo8NljxzWSFHX0e7Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6565 = 340
    return total

def _уКЧтκЗζВАνИкКΧ():
    value = 405830
    text = __import__('base64').b64decode('T2p4REpKUDhtelFHMmh2OVdKRTg=').decode('utf-8')
    total = value + len(text)
    return total

def _шЩΛЪОДдΝΞЗЮΟЦш():
    value = 974612
    if False and True:
        _dead_7603 = 912
        883
        831
    text = __import__('base64').b64decode('b1paejNDZmNfX2VlWV9UeXNmOGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ξλгξΨЩЕκБЗиΑ():
    value = 675320
    text = __import__('base64').b64decode('T1JSZ2xzdXgyTEhzVU8xeDd1WUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯЦЧЖχъΙφыКεΓΝН():
    value = 641920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDjhRVoz8aRWPyCgnH3JZTEkvGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нκβхЕнεδΡπТРляχ():
    value = 800076
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQf8P3xp7ocJaCazy1K3HwkM4k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗбТΑэγΨЛυИ():
    if 19 * 52 < 0:
        pass
        _dead_7063 = 93
    value = 615954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDfJYVY6qf0tOzmmxnfFOzc55Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еθΝξИΧПУПИψГ():
    value = 271698
    text = __import__('base64').b64decode('WDJ2YnNkcmNSWm4zM0FRTFk3MTI=').decode('utf-8')
    total = value + len(text)
    return total

def _гρΚνωОрЩЙθбΒжх():
    value = 777019
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj/1UXAYyZ83LQaFx1egBD0Q5Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δθуюξКΧγΛμ():
    value = 908158
    text = __import__('base64').b64decode('QTZlWmlwaFQwRDBDNzNTRWIwc1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΙЗΞЛΡΡΧбщОδεюρ():
    value = 398998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDrSQkZg8qUwMxuS5nC6FhM80js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δζβЩШЮЪэΥκΦ():
    value = 640045
    text = __import__('base64').b64decode('U3hHdTZkWHVvZTdPOTk2V3Q3Szg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЦдЧιΙВΔЛиηШΡш():
    if len('') > 0:
        921
    value = 335146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgXLYEMdzLwVPwyk+kzDOnJ4zF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        893
        pass
    return total

def _ЪτъаΓбЦιШЩНч():
    value = 863119
    text = __import__('base64').b64decode('WjBPUG04ZFZIQVlxVHJEUFBxOGQ=').decode('utf-8')
    if False and True:
        _dead_7882 = 648
    total = value + len(text)
    return total

def _γΘΟиσЗОбαΝ():
    value = 699882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxbMNkEe8/ouMC2rmXyZIxx+5Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЭХЮМНψеΒΞΞΓφЧΧΥ():
    value = 613398
    text = __import__('base64').b64decode('bHpGczVYeGxnM0ZvT3RaOURPbFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭНВυγНμΤдγЗУΠпφψ():
    if 24 * 31 < 0:
        _dead_1327 = 281
        pass
    value = 909929
    text = __import__('base64').b64decode('eFF3R01DOVdhTHlQeUhXQmxWX20=').decode('utf-8')
    total = value + len(text)
    if False and True:
        502
    return total

def _ΚαОυΕОХΚΩЧΠЕеτи():
    value = 319566
    if 48 * 5 < 0:
        _dead_9893 = 574
        pass
    text = __import__('base64').b64decode('SlZRUjNXNGNfTFBzbDJEWU1oUUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥγИютЛξΨ():
    value = 306344
    text = __import__('base64').b64decode('UGxZc0Z6U0MyQ194V0NVMWtqOUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΞβЩТθбЛ():
    value = 18752
    if 21 * 82 < 0:
        472
        _dead_3871 = 755
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDjePQk8+/8kIl7wxgajHTQA6T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7762 = 470
    total = value + len(text)
    return total

def _ГЕкуЯМОφК():
    value = 955603
    if False and True:
        _dead_1140 = 454
    text = __import__('base64').b64decode('ZjFnMERweExROUU4UDFocnAzMjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ατЪщэХГΧφЛ():
    value = 497098
    text = __import__('base64').b64decode('SmlXbzlJTGFmdGxrZ1U1OW9QZWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ρТиГρоθΖοΡ():
    value = 881431
    text = __import__('base64').b64decode('aXZUNFVsM0VSVm0wbFVFOHpPY3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ОηΝΖПФпрШжЩ():
    value = 234153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiuxZ1Ij1qwIYhqy+26IYj0r3GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δЮъΚΚлЮЩДчΞΓпΥУ():
    value = 75490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICDMZX413IkuAz6b0HmFYCM1yHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζξЪцмШМΦ():
    value = 201495
    text = __import__('base64').b64decode('Y3FpeERsU2JpM0xsTzBPcGE5UEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩнАуνюιзЧИРп():
    value = 528851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej7POFgr/ZoqLCuRz3qxZyg33Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭιоМεАμшυΟг():
    if len('') > 0:
        _dead_7311 = 783
        209
        _dead_7008 = 697
    value = 29119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX71QUst14lQFir03mCSBw4E5WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βсγςΝВЯйλи():
    value = 973515
    text = __import__('base64').b64decode('UFl6V0l2cGhKREJEekluaFhVOEk=').decode('utf-8')
    total = value + len(text)
    return total

def _υЛΓИДЫΔЙйкΧъИЬз():
    value = 244241
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQnCYlkvqoAyCAKCwmbEIj8Q50I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κМхиεаЗЫУκбΩэ():
    if 28 * 6 < 0:
        998
        872
        pass
    value = 368708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAP3OQE/9YcZEljz+mC/YisVzUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωТОεЦκαЪйЦ():
    value = 410382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAKxZH8cr7IrYxe62gGxLSd3zlc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИУλΘΙБΝηВκзаГασο():
    value = 745454
    text = __import__('base64').b64decode('UTFGSktIVlcyTGtlRFZHXzNQQnY=').decode('utf-8')
    total = value + len(text)
    return total

def _баΥΛюυΜВЙΣφАдРт():
    value = 895465
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAO1VnQP96YSFx6W+gOSGiwHs38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΥХξШЫΣЧφЛПЖ():
    value = 652970
    text = __import__('base64').b64decode('S1F6Z1cyN3ZwcVZBeF9qNmU4MEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΜγΖоОΞΡιαΘРΕЯМщ():
    value = 98217
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQzceFUt1ZwUA1iImly5FicsyjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юфЯΗУηсΡ():
    value = 697422
    if len('') > 0:
        640
        686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxWzSUBg5osqFAay4lG/Zy44tlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 15 * 27 < 0:
        225
        pass
        497
    total = value + len(text)
    return total

def _ΟЕΡΗΙЦαПдГαΛ():
    if False and True:
        _dead_4476 = 417
        pass
        pass
    value = 697172
    if 44 * 85 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IS7qSmZt97kGIF+hzg+iPxIY5Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2152 = 842
    return total

def _вюΕЦΤЬΘτγЮη():
    value = 288769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR+2W3IjqoZTOyGi+HOIbQg/slg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        430
        795
    return total

def _ΒςΚγαэЙΚβΞ():
    if 66 * 12 < 0:
        pass
    value = 459483
    text = __import__('base64').b64decode('czRhc3JkbDFWMjhZUm5URjhzSTI=').decode('utf-8')
    if len('') > 0:
        _dead_3559 = 363
        _dead_9183 = 578
    total = value + len(text)
    if len('') > 0:
        _dead_6904 = 811
    return total

def _θшξηΚΜΧлΓΩгΑ():
    value = 709456
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jj7QWwcGz5gWGyOS52abGyga0GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςзΗтЦЦДГХйЛω():
    value = 389859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NX7Fe3ot+6cUAjCQ6QGdExod1Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жθΓΘΝТΦъйγμΒςβμο():
    if 16 * 27 < 0:
        pass
    value = 107812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyjLOFcAzLoUbSz6kWezGxY51Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭссΡИмФбЕαωю():
    value = 495348
    text = __import__('base64').b64decode('a2NzamRlNENBelBTRFRyT2VDdlQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9703 = 254
    return total

def _яЖΕβνυцαьУмр():
    value = 803264
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCDLTQUzrJpXaFy25Wm0NRQL420='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΠδжЯнΒЪЗ():
    value = 935423
    text = __import__('base64').b64decode('SFB1VEtXSTd4MGNZMGZtTTFob2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΡΧРτяУΘюφЧΙΜΜΘ():
    value = 60529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSO3akg+77snKQSpkHSpORwr3jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣΠΠΖξЪΘΔ():
    value = 931307
    text = __import__('base64').b64decode('Y0t6M2d0dkNCZzhTN1AzVUl6Ymo=').decode('utf-8')
    total = value + len(text)
    return total

def _ψφщэяδςνщ():
    if 70 * 87 < 0:
        _dead_2454 = 932
    value = 785214
    if 18 * 15 < 0:
        pass
    text = __import__('base64').b64decode('ZVBQeDJsaXRHc05DQWRHSUt2ank=').decode('utf-8')
    total = value + len(text)
    return total

def _οεБαεБйхРβо():
    value = 756868
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyvKd1Io+fwaYiChynuAPQo+/mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κβнчξКфεюΘЧ():
    if len('') > 0:
        _dead_2028 = 584
        545
        pass
    value = 912325
    text = __import__('base64').b64decode('Sk5ZVWx6M21JSzJhTU1LUGVDcFI=').decode('utf-8')
    if False and True:
        pass
        542
        pass
    total = value + len(text)
    return total

def _МСЬΑΛΜиιМЭЗрр():
    value = 317552
    text = __import__('base64').b64decode('SEp6VFM5cHh2TlNCTDBqdzRqelo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4155 = 299
        pass
    return total

def _ТЭΩМθюбТΚ():
    value = 10777
    if len('') > 0:
        pass
        _dead_6233 = 620
        pass
    text = __import__('base64').b64decode('R2dFUUViNFRUSDF6YnNjS016OEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ТСФЭЕИΤο():
    if len('') > 0:
        _dead_9402 = 463
        _dead_1379 = 398
        _dead_8724 = 678
    value = 508012
    text = __import__('base64').b64decode('TnNHMDcwSGtHRksxUzZvaHVtQVU=').decode('utf-8')
    if 44 * 82 < 0:
        523
        pass
        pass
    total = value + len(text)
    if 46 * 90 < 0:
        pass
    return total

def _ΓψΒФΣрыθДЩЮИθ():
    if 93 * 7 < 0:
        pass
    value = 276545
    if len('') > 0:
        _dead_7024 = 76
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTXrPQgQzpo5ECP3xGe0BBom1Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΦвЕΣΡщφσΘХθюθΟ():
    value = 705048
    if len('') > 0:
        142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH/zT0Yz1IMALCKSxWy3B3E2yXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 39 * 52 < 0:
        120
    total = value + len(text)
    return total

def _ГПякΒΞΕγюνЫХИ():
    value = 949490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx28VmVhqKMPOz2VmUaTYD8dtTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 94 * 36 < 0:
        612
        pass
    return total

def _βОсУКАфЧ():
    value = 35575
    if 87 * 45 < 0:
        pass
        _dead_2146 = 9
        489
    text = __import__('base64').b64decode('RlFQMmRfY0szWmp5TTA5QXUwOHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ШдΗρεПΒβпХНμНвКу():
    value = 799217
    if False and True:
        928
        251
        639
    text = __import__('base64').b64decode('TzdYWTdyN053TjNqYWVTMUNaUlY=').decode('utf-8')
    total = value + len(text)
    if 1 * 99 < 0:
        pass
        pass
    return total

def _ФцεΡдζКπΛчРΝ():
    value = 354191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HArVS1YMy5IBMAOV8gKBMiQp4E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟРыЬЫщхцη():
    value = 221526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jg69Z3Jq1p0yEgrz7FSXGTwnsko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΟΜΩЯμщД():
    value = 127252
    text = __import__('base64').b64decode('Y0gyZzhWdm91TVBoRWlHMUQ5eUs=').decode('utf-8')
    total = value + len(text)
    return total

def _цВΙξΦβφГβгдΕ():
    if 32 * 20 < 0:
        262
        pass
        pass
    value = 695540
    text = __import__('base64').b64decode('dzRsR3FQMWVIa2JlSndMR3ZqN0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ьлаШЦоУПΕΜφ():
    if False and True:
        961
        163
    value = 402117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESTxXHAK6/kXOwaFngCXLBw4/Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КдщШΕфΔβΗδΧСвеВ():
    value = 209225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCvIXHM+3KIUGC6FxF+yGCwF7Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ψΣБγΚΩηΡшдτдЩп():
    value = 244722
    text = __import__('base64').b64decode('Z19WR1FyaE5PbW5GcVdxMm1VYTY=').decode('utf-8')
    total = value + len(text)
    return total

def _щШξрсьвНязяпΩΜ():
    value = 327022
    if 84 * 22 < 0:
        _dead_5027 = 470
    text = __import__('base64').b64decode('R1lqV21DREdSNW5mOHF0eG0xaEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛиэйΧФМБССтΦЖМ():
    if False and True:
        186
        pass
        pass
    value = 643925
    text = __import__('base64').b64decode('UTRQOEw5aER5R2s1ZnVpU0dSYkk=').decode('utf-8')
    total = value + len(text)
    return total

def _эОЦЦбЮΖйΥщЛЩ():
    value = 215707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBfSeQMU56oRNVnykF3AMiAZ8Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЛΦйвОкπа():
    value = 2518
    if False and True:
        351
        pass
        361
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTnzeXRuxKUyCSC6kXu9HhUu/Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        35
    return total

def _ЕξМΗЕВНХΓΛЯ():
    value = 644079
    if len('') > 0:
        884
        _dead_3697 = 158
    text = __import__('base64').b64decode('a3FZRDFaYzdFQVQwS0M1WWFaS28=').decode('utf-8')
    if len('') > 0:
        _dead_2115 = 865
    total = value + len(text)
    if len('') > 0:
        pass
        812
    return total

def _гЪечΝΙΕъРщΞκσαа():
    value = 565501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgbpVwENrrIZOQm55kSWZi0nx2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_5278 = 229
        663
    return total

def _κрщζφεΗΤ():
    if 79 * 90 < 0:
        pass
        905
    value = 287444
    text = __import__('base64').b64decode('bnNtODdVaWtlSGg0R1BUdjlCdzM=').decode('utf-8')
    if False and True:
        _dead_5891 = 411
    total = value + len(text)
    return total

def _ТΜΛЛΖνжЫКωπЕπШ():
    value = 213269
    if 1 * 100 < 0:
        pass
        465
        pass
    text = __import__('base64').b64decode('cUlyMWZlX0NCSTFHUXg3YThxS0c=').decode('utf-8')
    if False and True:
        pass
        558
        pass
    total = value + len(text)
    return total

def _ΣмХΜэΙΩК():
    value = 530748
    text = __import__('base64').b64decode('SXNzeWJ0Q3FjUWJua2hzckthSW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ХаьγΥΑДэцЫюКΙБс():
    if False and True:
        _dead_4654 = 560
        _dead_6706 = 640
        420
    value = 813928
    text = __import__('base64').b64decode('VVl6cWJBSVlaYThXMFRqaU1wQ3g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        841
        933
        pass
    return total

def _ξЯγξκАЪΡгΩυΦ():
    value = 761447
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxfvYwk33K8CIgSOynSzGCgOy1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιФМШРзРГΞΔβЮΔ():
    value = 776301
    text = __import__('base64').b64decode('ZVRIQXRBdFRWT09aWWNFczBJYzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩлЯбСζХЦΩθ():
    value = 858400
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwCwYmMLpvsBKwWT5nuiHDV4wEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚШхЖχπатιТΨмψ():
    value = 372266
    text = __import__('base64').b64decode('UjhJcXh0R2x4dU1yTFkwYThHcDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΑАΧАαζпеЮжЕЫφо():
    value = 980339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQXxakA9zpo3Dj6Uw2SjAi1+40k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΟдσΗНюаэЖξΙХХ():
    value = 985064
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQDIQnwM2KkrDiua3GG9ZCILt1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 37 < 0:
        _dead_6734 = 84
    total = value + len(text)
    return total

def _ЩΞюБЫиΟφΝΝΠАыаьΑ():
    value = 695906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxvzZUcQ1P0HHyKr21KeGHZ95ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УδоэλфаοЙΖбэ():
    if len('') > 0:
        pass
        982
    value = 714750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHvGOHwx9ooEPD/yzUe5bRYk3Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 10 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()