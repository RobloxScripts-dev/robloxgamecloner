#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ОмΤАБЫωЪγγкΑкΘ():
    value = 439376
    if 61 * 95 < 0:
        806
        _dead_5052 = 605
        229
    text = __import__('base64').b64decode('dFE2a0szUU8wclNJaEJCTG1Ha20=').decode('utf-8')
    total = value + len(text)
    return total

def _φΕΗсчЗиαΦΗωА():
    value = 598512
    text = __import__('base64').b64decode('dGhndWxkOUFHT2RIWjNFNTN5SUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ρЫЬιХэЫп():
    if len('') > 0:
        _dead_7345 = 584
    value = 637095
    text = __import__('base64').b64decode('TERHNWE3MkR0Z1FJSHJ0SzJwTnE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        261
    return total

def _ачЗаоΣτъυц():
    value = 579926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDm9Ol1tx70NNFrw63LDBz0d5jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 42 * 11 < 0:
        345
        pass
    return total

def _ЭЦыΔЫэУхжьхяАЦ():
    if False and True:
        650
    value = 731867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT3+aQhgza0aESuI+0SYIDcJxz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7642 = 673
        442
    return total

def _йΙΒΩююΞτΘцΖ():
    value = 743894
    if 75 * 24 < 0:
        _dead_7441 = 236
    text = __import__('base64').b64decode('SzA5SkJoWW01V0NtOXdiY3E5d1c=').decode('utf-8')
    if len('') > 0:
        599
        316
    total = value + len(text)
    return total

def _ΓЛВΤхΤЖЖαηвВ():
    if len('') > 0:
        _dead_4177 = 395
        218
    value = 891428
    if 34 * 95 < 0:
        pass
        pass
        122
    text = __import__('base64').b64decode('amoxUnFIeUk5N1hfQUxUYmNEMEw=').decode('utf-8')
    total = value + len(text)
    return total

def _оБΔτΨΒτжъЛЙЩβДУε():
    value = 124493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EA7jRgg/8a4GbQuhmG+mIiQpzUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛлСЬΒЖФЫ():
    value = 260904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXqyVwMK5Js5Iyu58EC+YiIO1WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НрΡэΝНЖΝиΞИ():
    value = 560353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXrqfXM/+Y0rLQO05kWaLTMd9ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕфΜΓгкΜсπМ():
    if False and True:
        233
        _dead_2983 = 231
        687
    value = 442104
    text = __import__('base64').b64decode('bWdfREdJVVBIWXdwQnRlYmNhbzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘРβэитИοΚλεψμЧ():
    value = 929434
    text = __import__('base64').b64decode('S0NWZUZ5VVc1a3Q2aHNoTGE5OGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜОζΧΓΤхЭ():
    value = 737136
    text = __import__('base64').b64decode('R3I3OUFKQTlCclo0Q081a0Qxelg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΟчΣЯхΣЬυф():
    if len('') > 0:
        _dead_5418 = 263
        _dead_3006 = 530
        674
    value = 713539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3/0V1UNzqMQLye0xHOdOT9/7lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΙыΗΒΝΡоУΝ():
    if 62 * 2 < 0:
        920
    value = 784683
    text = __import__('base64').b64decode('bEZ6bWdWU3F1Ql9iSDA4Z2k1NXM=').decode('utf-8')
    total = value + len(text)
    return total

def _чрφнТмΩςючгΥΒσ():
    if 32 * 85 < 0:
        pass
    value = 214860
    text = __import__('base64').b64decode('amZjeDRsM2FEc290MlNETVhyVWI=').decode('utf-8')
    total = value + len(text)
    return total

def _фςυИоτПλΧПЩБρМтΩ():
    value = 471475
    text = __import__('base64').b64decode('ekNGWkluQkhWMWVVenJaRkRIc0M=').decode('utf-8')
    total = value + len(text)
    return total

def _инАвТТКэ():
    value = 649820
    if len('') > 0:
        _dead_9078 = 891
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBu1a1kh0JEvPgGr3HGSECg1wmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧνэωЙΨΦВД():
    value = 160849
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhbsZHYO+PBUajCo7XPFZXUuyXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 73 < 0:
        pass
        _dead_5357 = 584
        _dead_9847 = 436
    total = value + len(text)
    return total

def _ЪΙюφζηλΒΖД():
    value = 671769
    text = __import__('base64').b64decode('aTRKVmlWMGEwWXowOEdRNzFPUG4=').decode('utf-8')
    total = value + len(text)
    return total

def _РΧшрБЛпΠуΡЩΒбИ():
    value = 22907
    text = __import__('base64').b64decode('UDRqODI4a3NHd0VrU21aZlE4T2w=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _шχзуЫЖαЖΠθσ():
    if 90 * 28 < 0:
        181
        672
        771
    value = 96060
    if len('') > 0:
        pass
        57
        15
    text = __import__('base64').b64decode('eGc5ODV4S3cwb1V2VjNLWGR6VFU=').decode('utf-8')
    total = value + len(text)
    return total

def _рψбтнВГΙΟЬЕΑНюС():
    if 80 * 81 < 0:
        pass
        pass
    value = 720664
    if False and True:
        _dead_7938 = 916
        _dead_2405 = 270
    text = __import__('base64').b64decode('enhsYnd5djY3OUF4cHN5ZWVOMW8=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        409
        pass
    return total

def _УПαчСЙРΔдθΠξЙй():
    value = 183215
    text = __import__('base64').b64decode('WVNkdlM4YXlMZFFlWUJVc3RXM0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡлΤУцЦΥф():
    value = 61265
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSrpWQZo25EqACT74GG5LXY/yz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣζФЭΝοМΠΕк():
    value = 140025
    text = __import__('base64').b64decode('VU1mYk0zaHdDdTBSdDFCRVdqT0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЙκσБЮйΝЪкхЧΣκς():
    value = 497848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQzpSXJu540VGCiw/kSIMnYM0Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪеЩЫцξшΨЫΑΓσχ():
    value = 398285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBf0PlsY6vs3CwmXwA6FPRM1zWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        905
        710
        821
    total = value + len(text)
    if len('') > 0:
        711
    return total

def _ВеАъяΑЧшφх():
    value = 160977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHfqN2gKr5cba16SwlGyMQAY82c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤкыхЮπβвΨηй():
    value = 666074
    text = __import__('base64').b64decode('d1ZyZjBWWHUzWWFMOFNaNE9IRWo=').decode('utf-8')
    total = value + len(text)
    return total

def _φЖЮШлГЦдгМЛψΩΦр():
    value = 998685
    if 21 * 2 < 0:
        690
        716
    text = __import__('base64').b64decode('QmhaaGlVRjlybmR2Y1Q1XzEwbUk=').decode('utf-8')
    total = value + len(text)
    return total

def _тЫЙεγЪблΟТеУхγО():
    value = 192753
    text = __import__('base64').b64decode('cDdveXk2NVFRVnk2bGZnTnNZVjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓЕжφΚЙфΧ():
    value = 107021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwrrWn8XqrICMT2g6QKIYTcB9GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2987 = 490
        633
        _dead_5430 = 958
    return total

def _фднΔοДсРλНъА():
    value = 502479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj79V0YG0YFTCwK0xleqLX0rxW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωКαЬιЭιοУ():
    value = 447855
    text = __import__('base64').b64decode('V3V1bjZTbFBJejRZWEJNSG1ZWWg=').decode('utf-8')
    if False and True:
        759
    total = value + len(text)
    if 87 * 7 < 0:
        498
        855
    return total

def _нЫιфυτπτζЩОΒх():
    value = 64154
    text = __import__('base64').b64decode('Y0FiSnRpZDlLemFJSnVzRzRfeUg=').decode('utf-8')
    total = value + len(text)
    return total

def _шЖΠοпχгθЗ():
    value = 908960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3nPVksM/JcqNDqu/luzNRp590o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γвθΓдМςξ():
    if False and True:
        905
        pass
    value = 296024
    text = __import__('base64').b64decode('SUdCbFBFMHJiZlBNRlFPWVpZMF8=').decode('utf-8')
    total = value + len(text)
    if 70 * 73 < 0:
        _dead_9291 = 770
        345
    return total

def _ΝΠΩлσИιУъΘЯчфаς():
    value = 304416
    if len('') > 0:
        _dead_8842 = 9
    text = __import__('base64').b64decode('RTRiN1Nna25wd0FJN2R4c2wwQko=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3350 = 279
        439
    return total

def _ЙиВэзрΖπβπнЦαΞч():
    value = 449623
    text = __import__('base64').b64decode('SG9sOFNGdm9EZ1JLZXlOdkZwaFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙМΤδрЬЕщαδΝЮΣ():
    value = 725594
    text = __import__('base64').b64decode('cFV4cURNVUxSS0lQYkpWc2FqeGg=').decode('utf-8')
    total = value + len(text)
    return total

def _κЙКЭωйΕΦΡЫγЧ():
    value = 940988
    text = __import__('base64').b64decode('YXN2ZGF6M0tUdTVxd1hyNF85T0k=').decode('utf-8')
    total = value + len(text)
    return total

def _РчЭΣΤΚЭαюΕΦωурψ():
    value = 897947
    if 55 * 79 < 0:
        pass
        995
    text = __import__('base64').b64decode('ZEdSNWgwRmdEdk93VUNSRFQ4eHA=').decode('utf-8')
    if 1 * 74 < 0:
        pass
        _dead_4608 = 753
        534
    total = value + len(text)
    return total

def _ИКГкβьΨААЙΔΘΟбс():
    if False and True:
        pass
        _dead_9817 = 206
    value = 722373
    text = __import__('base64').b64decode('Q2RCdlphVThFY01rWWdtc0hnRU0=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _δβХφхТΘΨгΥЮ():
    if len('') > 0:
        _dead_5082 = 49
        pass
        _dead_1873 = 313
    value = 32406
    text = __import__('base64').b64decode('TkFjT1FCM1A5d3pLbkZqTTRWMUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ψρΓЕμυэΨΚΦΟв():
    value = 347805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy7xamMD1roTb1uS41vGFR0H41E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τζΚΑΦЕНЕЗοΖΥРАН():
    value = 99544
    text = __import__('base64').b64decode('a0djZHA2dV85NllMazdhbkRweXQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        227
        pass
    return total

def _ΕРККδаΚыргх():
    value = 914633
    text = __import__('base64').b64decode('eXpGX2g2QVBGSHN2eV9FdWVHY1c=').decode('utf-8')
    total = value + len(text)
    return total

def _цχχεΘΖτΤγΥνКпб():
    if len('') > 0:
        134
    value = 432273
    if 75 * 52 < 0:
        pass
        969
    text = __import__('base64').b64decode('QkdET0t5X1IwNFY4TnA3SjJLalY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        810
        pass
    return total

def _δдлωκωЙЪΠЗσТВкΝ():
    value = 23894
    if len('') > 0:
        339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBfVYAMw6rkFHjWV306KIjZ7vXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4428 = 340
    return total

def _нΣιпФъЦООξиασТоУ():
    value = 604812
    text = __import__('base64').b64decode('ZmsxQlJWRTJPWmNqQzdYSmxZWVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΑАКБιΕьаδ():
    value = 578888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC60awgazvsgKySh+F2WGCw11FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓпГρΖцХъыΟΤ():
    value = 20803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAW0VwAQ+JIWLgXw+G+SLCN2/GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οаΤЗАΚΚгΨЧАбТΣ():
    value = 556072
    text = __import__('base64').b64decode('Q2JJNTB4SmVQU3RiclVGel9sRng=').decode('utf-8')
    if len('') > 0:
        56
        _dead_7672 = 584
        921
    total = value + len(text)
    if False and True:
        _dead_8416 = 636
        pass
        pass
    return total

def _БΖэЧгχγχιауψЗΓδ():
    value = 591363
    text = __import__('base64').b64decode('WHdEOWo5blZqel9wR2JXcERFd04=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΓщНъΣχчЛЪΟдα():
    value = 733417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnjHanw/2qlUYh+x5QK5ZAw451Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣТзчΤИЙяζ():
    value = 601835
    text = __import__('base64').b64decode('YWhSUElsam5RaUVRUXFLYTVlNWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠокюкЩЭα():
    value = 166925
    if False and True:
        _dead_7971 = 961
        pass
    text = __import__('base64').b64decode('dERQWFd6Y2pQbnUyN0ZJMzlJaEQ=').decode('utf-8')
    if False and True:
        pass
        _dead_5215 = 124
    total = value + len(text)
    return total

def _иыωωЯйσβ():
    value = 97391
    text = __import__('base64').b64decode('TFdxN2xUX1ZtZ1JLN21oZFNveFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦяТкеΔΒЙΧезψ():
    value = 525485
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjWySUE1ypIPai2K5Q+pOgYCyjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςщпΦЦδЯαΟ():
    value = 551180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FA7od0M6rKEUaheR3kCFYQQB9jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йελМЩΡαУЭΡΙΓνψюη():
    value = 397583
    text = __import__('base64').b64decode('cVJzd2xtMkxyMlVuYXl1TjhYNjk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        878
    return total

def _ъНοΑΤΕΟцБ():
    value = 331682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB/PRXAzp64FaCGSmgOEMX0+zWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БНΟξОιαГΓвαΕοИше():
    value = 763354
    text = __import__('base64').b64decode('WHVuTWNCQkRJVVBQWk8xVmxJdW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΙиКгНλσГνГκ():
    value = 752589
    text = __import__('base64').b64decode('RHRpSDRVRm1BTnRvRl82TUE4c3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ПιΩεгвΚчцМЫ():
    value = 651247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bj/UYEMxzYMKNFa2mXSnYwM4zFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пГЬΜЛΜИΥК():
    if 92 * 3 < 0:
        _dead_9764 = 61
    value = 405453
    if len('') > 0:
        pass
        pass
        875
    text = __import__('base64').b64decode('VFFvSnFxMGtrZGxPdEwyZ1haTTA=').decode('utf-8')
    total = value + len(text)
    return total

def _βДγαЯиΔЫσСКуα():
    value = 960300
    if len('') > 0:
        _dead_8346 = 371
        pass
        562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz3tengI34wZNFyFxkKAJBUOz2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        987
        _dead_1104 = 880
    return total

def _ΠУрыЯЧυηъЪГΚ():
    if False and True:
        pass
    value = 115462
    if 18 * 30 < 0:
        _dead_9180 = 133
        _dead_9356 = 397
        pass
    text = __import__('base64').b64decode('cE40U1JpSlpXTV9KeV8xbGQ0RWg=').decode('utf-8')
    total = value + len(text)
    return total

def _пτЩυдγЪоφΕ():
    value = 672077
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhnKVFsc8KYZAhyZ31eqLn02sj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΦОЯПФгЯ():
    if 46 * 62 < 0:
        _dead_1596 = 802
        _dead_4122 = 927
    value = 302310
    if len('') > 0:
        pass
        130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh3LaUYQ5JIGDguc8USKIXYN1n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 37 * 57 < 0:
        _dead_9556 = 104
        _dead_6987 = 869
        482
    return total

def _жΤЮЧπχЪχПΞ():
    value = 373942
    text = __import__('base64').b64decode('ZjI4Uld1OG1GWUZPWllMZk1oeXc=').decode('utf-8')
    if False and True:
        610
        pass
        pass
    total = value + len(text)
    return total

def _ΙχдУωΜхΔεΧавхθр():
    value = 88481
    text = __import__('base64').b64decode('b3I3MnF3Skd1Y3kzYTRpWnBybkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡМЦШБЙШΒьι():
    value = 590740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHzXdFUc+J5TaSn67luFFhQY00Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сξΡПΩΚЫχιΞοхШνΑΜ():
    value = 48447
    text = __import__('base64').b64decode('TlRXbXpYYV9xN0RKZUdJeENPb0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΝЖΨЮъЪТΙ():
    value = 725844
    text = __import__('base64').b64decode('Z212bDNPNnhNdW01cFhZbjRiUVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΦфжщτыАоузβД():
    value = 267754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQbzaFkT1fwAIgew4VG0Fxd96mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьπΣΦθΠΙДΘЛШхΨΞмα():
    value = 46797
    text = __import__('base64').b64decode('UGNoNDdaU2lLS2JGUmZYeUlleHc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _рЗэΓеφωП():
    value = 778477
    text = __import__('base64').b64decode('QjhwWV8xZmR3Vm9qNkk3d01nNG0=').decode('utf-8')
    total = value + len(text)
    return total

def _КΝνθгφΗΦЩ():
    value = 773450
    text = __import__('base64').b64decode('WEVIRWREd0FSVGRXSTA0XzdKa3o=').decode('utf-8')
    total = value + len(text)
    return total

def _еялаδвτΨδ():
    value = 927394
    if 15 * 92 < 0:
        662
        pass
        pass
    text = __import__('base64').b64decode('VDRPMk9iODI2U2JaWjF2RzFpdlY=').decode('utf-8')
    total = value + len(text)
    return total

def _еСтНДФΖΠγΜτ():
    value = 778141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3jmQkIj/60XPSqG5XW0Jyg78m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _βРλψГКррωбΨ():
    value = 8302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lji9XUNhyq4tGB2wwF+BHyt86GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νгИШδΜπкσПЧЬ():
    value = 144648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCfTfwZorvlULF2p6kCfYQ0Y4Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΚвтоЙЦн():
    value = 563596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lyr3T1Mqp68SaAL18WWfGSoY13w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эвъΚΟυвχГ():
    value = 872908
    if len('') > 0:
        pass
        _dead_2050 = 89
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX78N0Us6KkZMiuz3GaKMS8V1lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЪοбλμоЭ():
    value = 515979
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('eHdmeWNzWXY3ZkNuNU1GbGRtbmw=').decode('utf-8')
    total = value + len(text)
    if 42 * 33 < 0:
        pass
        811
    return total

def _нЛъΨИΨΠΧтλЦБПВЙ():
    if 50 * 80 < 0:
        625
    value = 824194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRyyN2Bu6vEADTmN2AShLCQH62k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λХΑΟΜъъоΨтζпΤρΒт():
    value = 276171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3bcYXdh3a0ECyT390+oEiR2y2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΥрνδΖΝшэΡсьπЯ():
    value = 237953
    text = __import__('base64').b64decode('djRZNVpVeFFLVDJYWTI5T0tBdGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒтςУαЖЬΞΚλвХ():
    value = 31762
    text = __import__('base64').b64decode('Rjc0cUZ3NnI4MnhGWUEwZXRqRXM=').decode('utf-8')
    total = value + len(text)
    return total

def _зТΤЭТοфψΡэωЬ():
    value = 630657
    text = __import__('base64').b64decode('ZEQ0TTNPMXhxcnBPOWMwSzg3ZGg=').decode('utf-8')
    total = value + len(text)
    return total

def _μФэκΧЕйπГχХДо():
    value = 438492
    text = __import__('base64').b64decode('QlZTOTVWYUZsMnpvQjV4ZjFhWHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒЪпγτЯмΖзц():
    if False and True:
        152
        pass
    value = 515275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDrzSUAr/7oMNTeh20LGZDE72zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 85 * 82 < 0:
        pass
        pass
        161
    return total

def _ψпμχеаШπуЗψωдЦЖШ():
    value = 205297
    text = __import__('base64').b64decode('QVc1TU5zaGd1VnJGVmYxdEl0U0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ьАпЦΛБГΧООξ():
    if False and True:
        _dead_3842 = 575
    value = 604822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQjMUXYyr/wvAj2r+lCaBAQG8W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УνΚΡΤЪхιЪ():
    value = 717805
    text = __import__('base64').b64decode('dVJQcHRVVVRzZTRBQnJnRGpjYTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΛωЙΟωνΙφПθуЧΖЕ():
    value = 335986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgjMREMu1r0JER2Z62zGEDM4sU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςξηсммЭЗпДЖΟ():
    value = 760264
    text = __import__('base64').b64decode('Z3lxVUpUM19BSmx2SE1hT3ptalI=').decode('utf-8')
    total = value + len(text)
    return total

def _ςНΓдБΖαΘДΦγμЯΜл():
    value = 303128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ki71PgE7+pIyAwXyymXHGjMI6Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ювΓΩμνщχΞΗΗМИΛ():
    value = 936217
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DifXS3Yu76sLNBi25WTEDBYmt20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΧЪЙΕθсΜΟΙИΒЗУΚ():
    value = 418592
    text = __import__('base64').b64decode('dDlJcGYyUkN5SUl6Q055WWlVcGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜуγяψНУπшЫθω():
    value = 432670
    text = __import__('base64').b64decode('eWpNR3R2eFJuTldQeEZHM0hrZzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΑΓχьМКЙвζРьш():
    value = 37213
    text = __import__('base64').b64decode('cjJiSjdNYlh6R3dtaGl1TUZHNzU=').decode('utf-8')
    if len('') > 0:
        pass
        83
    total = value + len(text)
    return total

def _ЮоНлэρδкχοв():
    value = 976486
    text = __import__('base64').b64decode('RUFoeU01U2ZTTjd0UFRGMkZNQ3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΧΡΕΚэбщδВΧαЪ():
    if 23 * 72 < 0:
        pass
        pass
    value = 612518
    if 85 * 52 < 0:
        _dead_7172 = 913
        _dead_3468 = 716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgXVWAg68oUOH1mS2VubOykQ6mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΣНчδЖНЛ():
    value = 520443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw7sWncu6KYSO1uw6nqiPxIK9kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡрДтмαΙиςХвЗ():
    value = 161070
    text = __import__('base64').b64decode('aDFzbDdFZGFjN21BUVdhMktZd2M=').decode('utf-8')
    total = value + len(text)
    return total

def _τμнΕΤКΑωБγлΖΖаκ():
    value = 573568
    text = __import__('base64').b64decode('cFNBaVdPVXo4cHM0eFVFam51eHM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_1442 = 437
        288
    return total

def _ΖшКψλЫАЩПΡъ():
    value = 35452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwzPTV823P82NTu33g+TER07xTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΜашΧифΞФЮ():
    value = 739398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXfLbHU/2IwCNxeL4lPAAAEG40g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΜΔΙλΗΛχэΓц():
    if 30 * 49 < 0:
        _dead_5261 = 633
    value = 815258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTrKSGBowfwgHSGh/gPFIgYfxms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        645
    total = value + len(text)
    return total

def _βфЙΥвЗПηΨΟЬΡгΥ():
    value = 21015
    text = __import__('base64').b64decode('SnZ2TG0wRGhSTWlZOFVTVWpFTUk=').decode('utf-8')
    total = value + len(text)
    return total

def _μπйРфΙГЧБВΣкγμт():
    value = 205207
    text = __import__('base64').b64decode('d1pleFkzY19hUHdfMVNjU0F6ZW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ВЫЩΩΙэωυЫФΓζСв():
    if False and True:
        _dead_8930 = 488
    value = 781639
    text = __import__('base64').b64decode('SW5UWFJpT0l6VmZlX1hfTlg5X2E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6095 = 787
    return total

def _аЗεμзηЧфεИЗГчЭ():
    value = 991423
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBroekQAyrgbMSD22myVBXcF70o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 72 < 0:
        _dead_4389 = 761
    total = value + len(text)
    if 45 * 56 < 0:
        pass
        778
    return total

def _ХКΑЙзλзЬΧшжΤΥХо():
    value = 559507
    text = __import__('base64').b64decode('YnB1OUdQZmFPbUFtaXVZb09lbXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ВξΣΚщаЧМД():
    if 72 * 86 < 0:
        941
    value = 95370
    if 85 * 5 < 0:
        _dead_9608 = 219
    text = __import__('base64').b64decode('YWMwUXZpUWpmMjFCQnVXTGxCVUY=').decode('utf-8')
    total = value + len(text)
    if 16 * 57 < 0:
        909
        223
        549
    return total

def _ΡЫτοЛаΜА():
    value = 356460
    text = __import__('base64').b64decode('RlFyYVI3VHBocEs2WDE4OFBQQnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙσχМсγЗΤΦΗе():
    value = 351694
    text = __import__('base64').b64decode('dVFGSlpaVFBMUUd1ZXJ3ZUtoYlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ιУκδψΝЗκρ():
    if len('') > 0:
        _dead_3316 = 73
        _dead_5879 = 374
        _dead_1658 = 721
    value = 248313
    text = __import__('base64').b64decode('bG5iaXNEWG80OVowS0pjaE9KbTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ιГβМκЦΘЯοεе():
    value = 716345
    if False and True:
        _dead_9240 = 341
        356
    text = __import__('base64').b64decode('TVNrQms1U1hvelgxUjRFYmhBT1Y=').decode('utf-8')
    if 87 * 14 < 0:
        pass
        919
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΗШТжΦΖΥъшц():
    value = 681979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiLQRF0I/aktAy6Z8AKeODJ4zE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΘЭρψΙσчυΒнвαΓ():
    value = 696923
    if 48 * 41 < 0:
        675
    text = __import__('base64').b64decode('SDNvcFNUT29EQ1lOeE1SMlVJYWY=').decode('utf-8')
    total = value + len(text)
    return total

def _еэειЦюЦφю():
    value = 187598
    text = __import__('base64').b64decode('THhMNldPU1RPZ3B0X3A3QzQyWXE=').decode('utf-8')
    total = value + len(text)
    return total

def _пΒШΔТΦНргЩРйΔШζ():
    value = 341584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQjhfXtqzP0LLi6szU+EEjE47mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιцмΗАцОΠ():
    value = 82400
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CT/tXF4wroQwDybw2G+9Fho9zGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3950 = 785
        pass
    total = value + len(text)
    return total

def _оЯΤФδΖЦйШ():
    value = 387896
    text = __import__('base64').b64decode('UVVDTFVSMVk4dkJ2TXAxNUgwTEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ηХюЙоВхбξщх():
    value = 60309
    if 7 * 26 < 0:
        357
        _dead_2048 = 904
        218
    text = __import__('base64').b64decode('QU1FR3BiZU1Va0FrdGg5VGVRRTc=').decode('utf-8')
    if 7 * 90 < 0:
        816
    total = value + len(text)
    if len('') > 0:
        _dead_4845 = 3
        _dead_2161 = 781
    return total

def _ΟоЗИΞжуЛРсΜууЩу():
    if len('') > 0:
        _dead_9346 = 847
        pass
    value = 937095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAvWa1MB1qonMyOkzFGxMCZ/4zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2014 = 596
        _dead_9687 = 994
        pass
    return total

def _ЭμаνδБАС():
    value = 553634
    if 73 * 28 < 0:
        _dead_4742 = 488
    text = __import__('base64').b64decode('bjVNS1NBOTdyM2RGaW9TU2V1OXg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        211
    return total

def _ЩειНйСоуЖΣц():
    value = 12249
    if 50 * 7 < 0:
        _dead_6914 = 753
        410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxXhWWUV9aRSKSeo8EejFRM553g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _χКЕνжярθеγση():
    if len('') > 0:
        957
    value = 231272
    if len('') > 0:
        pass
        _dead_6247 = 461
        pass
    text = __import__('base64').b64decode('Yzdlc003WTdnU0c4M1c0ZVN3Skw=').decode('utf-8')
    total = value + len(text)
    return total

def _гЖьыпΡцаДпдСЛ():
    value = 706944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzvtYGMb8YRSaiC07A6yEBEO/lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΙлОЕθυГшЭЧН():
    value = 109539
    text = __import__('base64').b64decode('dUZiN3daWVpoZ3lKYkhsc1VuSXc=').decode('utf-8')
    if len('') > 0:
        606
        _dead_1581 = 642
        pass
    total = value + len(text)
    return total

def _ΗбктДоΒэЗЧтα():
    value = 978610
    if 96 * 78 < 0:
        _dead_7215 = 448
        _dead_2112 = 616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXu3Nm4LyLEWMw770XqAITcl6z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6042 = 792
    return total

def _лчηпящзЦрЪФЙΕрК():
    if False and True:
        _dead_1253 = 955
    value = 847360
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E33iaUg9yfsACVaS3FXFJAF682E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΗλτЯΚοеаΑг():
    value = 802593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz/FRnBpx5EIFh+Emw+aPAF8/Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 88 * 28 < 0:
        622
    total = value + len(text)
    return total

def _уКψфъΘτΨκΕΖЭв():
    value = 554434
    text = __import__('base64').b64decode('WVVlM2EwODdFalZ6eWc3YnlnaEM=').decode('utf-8')
    total = value + len(text)
    return total

def _νлквяЪυзχрυ():
    value = 25642
    text = __import__('base64').b64decode('VFQ1RUNxUTVXdVJTcFFuQ2I0b3Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        826
        pass
    return total

def _ЭвгюБθςσЛьЬΣΓβχВ():
    if 31 * 40 < 0:
        pass
        802
        pass
    value = 510933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHv8PGkB870kEgi043SxNXEl9UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        4
    total = value + len(text)
    if 10 * 56 < 0:
        pass
        _dead_8927 = 961
        pass
    return total

def _лИЯышοъΓ():
    value = 562941
    text = __import__('base64').b64decode('dDBpdXp0YjNCZm1iNlEyMXVBd1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _εεΛЯψΜЩΘαцНСΦ():
    value = 70752
    text = __import__('base64').b64decode('ZERLV3dfNDhQMzlQQ01tc3pZbDI=').decode('utf-8')
    total = value + len(text)
    return total

def _МфМΟОКΓξ():
    value = 853658
    if 4 * 48 < 0:
        _dead_6401 = 320
    text = __import__('base64').b64decode('SWk2UGpWQnFRTEpudTA5NFE0eko=').decode('utf-8')
    total = value + len(text)
    return total

def _μΡГτтχΘΔΗ():
    if len('') > 0:
        _dead_2747 = 79
        pass
    value = 90629
    text = __import__('base64').b64decode('Z1JyUzZ2T3hWc1dSZ2Y1N0lsVlI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЧΞξΨзщΥ():
    value = 628069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzrMXXQD1JI3NwmX/GW/ABV49Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑНПιγЧΖГΧδπЙΛе():
    value = 752563
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ejn8ZmczqpcAYznwnQC1Bh144Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 22 * 30 < 0:
        pass
    return total

def _ΥαФцпЛμΑС():
    if False and True:
        pass
    value = 520495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRfoZkk8rLkzYgqh5WydBjMuwEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5694 = 768
    return total

def _ЛыΛХμибЧΓκБΧ():
    value = 779647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRrteXAa16UzHDuI8l68MAAl4nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        365
        pass
    total = value + len(text)
    return total

def _ΣбчΠησЛЗяЪТЭ():
    if 83 * 35 < 0:
        pass
        pass
    value = 723172
    text = __import__('base64').b64decode('TkZKOXlGbDY4X3g1SHp2RTdxR3E=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЕЪΨωΔχьδяΚΩκ():
    value = 331893
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('VmJXQVJGXzJWY3RMdkl1N1NjMXY=').decode('utf-8')
    if False and True:
        _dead_2733 = 57
        pass
    total = value + len(text)
    return total

def _чръσΠГΡяφ():
    if 95 * 38 < 0:
        _dead_3370 = 709
        42
        _dead_4794 = 452
    value = 440319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiDvPXM+7q5XKF+n4nGFFnQW/kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9595 = 549
    return total

def _хнуоθЖАРβφ():
    value = 740034
    text = __import__('base64').b64decode('dU04Q0hxTFlIS2diU3hWMFJOSzc=').decode('utf-8')
    if len('') > 0:
        376
        527
    total = value + len(text)
    return total

def _ηУΤΨЗГΞΟ():
    value = 810705
    text = __import__('base64').b64decode('VENBbzhHNDJpT1RPSTMzZGpRYzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ОψΚΔΙοЗΧапвμ():
    value = 78596
    if 81 * 73 < 0:
        34
        _dead_7116 = 771
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyXtVksD/J5WKxyt+Uy1Ex8O7GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НрχσΧΣΧπΤψяЖЩд():
    value = 499028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAbwaXkI8/4QPBm2zVuGYhYjvGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χкΧьтОθδςчйφК():
    if False and True:
        _dead_3552 = 802
        _dead_8826 = 744
        662
    value = 784800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTfSRGA9q/gBAFqzmEKbZAoL0Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δъАЫЖрξιэαψкυξρφ():
    if len('') > 0:
        _dead_8975 = 340
        pass
        _dead_2329 = 694
    value = 690730
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnfsRmRr+oFSNT2B/GKZBxQ452U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕщοяκщΣЮХМΚ():
    value = 37313
    text = __import__('base64').b64decode('TWZqSDdUVG56RUNUSlJoY3Z2a0g=').decode('utf-8')
    if False and True:
        686
        _dead_8194 = 923
        _dead_1192 = 827
    total = value + len(text)
    return total

def _ДΛэφГСαηъΒκΞн():
    value = 465365
    if 15 * 56 < 0:
        _dead_1350 = 251
        pass
        _dead_6961 = 903
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDn9YEEp3bEuOR2LzWWKIRUCykA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4407 = 37
        pass
        858
    total = value + len(text)
    if False and True:
        710
        86
        264
    return total

def _ьξХОδοБЙυрЙΠ():
    value = 299375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwzNQnk+9KBWKh+2yWGCMncI0z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 100 * 65 < 0:
        461
        pass
        pass
    return total

def _чΕφννэυΒΛВνЩ():
    if False and True:
        _dead_9110 = 613
        _dead_5325 = 730
        pass
    value = 865942
    text = __import__('base64').b64decode('ZWNjWGtHTUFZUDF4a0Vfc2FoUE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЮΝπεбΒВЩ():
    if False and True:
        510
        pass
        477
    value = 338945
    if 4 * 72 < 0:
        _dead_9752 = 595
        pass
        pass
    text = __import__('base64').b64decode('dEZOYjFVd25YQlk0dWNtWWhGbzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΚΘрШΒИхτ():
    value = 580978
    if False and True:
        _dead_2522 = 173
        408
    text = __import__('base64').b64decode('WmFpUWNhY2RGTVcxVVVEYnBnNko=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙГлολэχΤхПψПΕΥ():
    value = 1943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ihb0XlUK3ZkMCViLnG6YYTAMsXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъкτЫτγΛΠΨ():
    if len('') > 0:
        329
    value = 982102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwLybGRr7IEvCyf2m1u9GnN+xkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΕсΟπιоЫШΓМκΕ():
    value = 392298
    text = __import__('base64').b64decode('dWRNelBfdk1iUW13U29uSmxib3A=').decode('utf-8')
    if 63 * 49 < 0:
        134
        pass
    total = value + len(text)
    return total

def _ΧΦЕοГтψΒ():
    value = 108570
    text = __import__('base64').b64decode('UVFNblF6OWhRTjFCNnF3M3kxU1U=').decode('utf-8')
    if 5 * 50 < 0:
        _dead_3162 = 361
    total = value + len(text)
    return total

def _ШιжςθНПзч():
    value = 422674
    text = __import__('base64').b64decode('RnBZSmY2RmNFQUhkdzRyVEZodXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜμэйΩещγЮφνф():
    if False and True:
        pass
        pass
    value = 652224
    text = __import__('base64').b64decode('aTVnVU9OUnVuQmJYS05UNVdPWGk=').decode('utf-8')
    total = value + len(text)
    if 67 * 29 < 0:
        _dead_1675 = 885
    return total

def _еγпΧбΩачб():
    value = 392013
    text = __import__('base64').b64decode('dmlpUmx5MVJvczVpNmpWdTJXZ3k=').decode('utf-8')
    if False and True:
        974
    total = value + len(text)
    return total

def _вμчΘΝΓцжЫЦМЕΧзЕ():
    if 67 * 29 < 0:
        _dead_3412 = 457
    value = 98396
    text = __import__('base64').b64decode('TUJTT3hwMTJZbEpIWDZBZVFJMUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ШПлЫηΛЩκ():
    value = 470238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiDUemgQ1IAgGwOCz0OcPg0esjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛлыюρЪлΦΨД():
    if 32 * 4 < 0:
        pass
        _dead_2738 = 125
    value = 974492
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwizV2MDxLEqHSmv40bFGhx+yUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒγμмЕΓаΙМюΑΘγЧΩ():
    value = 428416
    text = __import__('base64').b64decode('VnZjZ0pveFZ0Zm9Odk1BNjJfd1g=').decode('utf-8')
    total = value + len(text)
    return total

def _аЬςωΟУοЧхψы():
    if False and True:
        128
        _dead_3408 = 137
    value = 579587
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjbNQncsq4QiBSOuxgGeDBAQ5Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъМΕηαΚлоΨкыγρ():
    if False and True:
        pass
        556
    value = 253891
    if 60 * 22 < 0:
        pass
    text = __import__('base64').b64decode('cDY4VkM5QzRZMWtITjZXVEhOWlU=').decode('utf-8')
    total = value + len(text)
    return total

def _АЗачΖΓαΒЮрАПБ():
    value = 470710
    text = __import__('base64').b64decode('bF9iVmNsYUFobU1QZ3VIX0lRWE8=').decode('utf-8')
    total = value + len(text)
    return total

def _йУаςмαбифΠκр():
    if 54 * 4 < 0:
        pass
    value = 516622
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS3ubX4U/fkGHCPz/XOeHj8FsHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _δЧΚμΔшυβΠΧЩПхθλо():
    value = 225804
    text = __import__('base64').b64decode('cGhpQjdFb2tzY2dPb0ZfZjdsSVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠογΡΡЖΑαюρ():
    value = 794867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzXeQgdoz5oLNFr2m1uaFT8A9WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГτΙυЙΞζχФωχΛЯ():
    value = 394211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3fXdwUd2bBSYySqw2CqDhwbzWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_7412 = 141
    total = value + len(text)
    if len('') > 0:
        _dead_5919 = 57
        877
        _dead_1442 = 477
    return total

def _хΘΖЫΖνЩψ():
    value = 545665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHfnaVRq5pFXPyCN+WWhGBwM/lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 70 < 0:
        pass
    total = value + len(text)
    return total

def _χВΦфгμβЗηфЦсωκΖн():
    if False and True:
        pass
        _dead_6660 = 395
    value = 788368
    text = __import__('base64').b64decode('b1hJS1N0QUMxalpCNFdZbnA1eUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ВЫτНЮφκГ():
    value = 539710
    if len('') > 0:
        134
        155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCnmYmsqwZgEbDCI5GbHJCEl6lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щсГцЩМφΨΠнКпξΛ():
    value = 768699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQXRa3oKqIxVMhvx4Gy0ESwI8Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9527 = 101
        _dead_4029 = 611
    return total

def _ИπΑЫΒΚаБГΑвбλ():
    value = 413455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCj9XX02zfwCKwqp4USBBB1+6jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        325
    total = value + len(text)
    if False and True:
        701
        pass
    return total

def _ГюτкςщιЧШфεА():
    value = 42213
    text = __import__('base64').b64decode('dGZvSDM1Vm4zOW1mZjlMYV9weHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _РМυΚΙΩЪξΟц():
    if 20 * 78 < 0:
        _dead_7870 = 921
        _dead_6332 = 182
        _dead_3527 = 276
    value = 672885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjeyZXwS+/sMHiS64macByl7yEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 2 < 0:
        pass
    total = value + len(text)
    return total

def _λЧΛΧΩαΡйμκОгЩ():
    value = 743896
    text = __import__('base64').b64decode('UGNvTzRmWklfel9wUVU5a3hCQ1o=').decode('utf-8')
    total = value + len(text)
    return total

def _УΦчЗξоΜΡТω():
    value = 304090
    text = __import__('base64').b64decode('cmtnSEJubGttQTZ4OHdVdlQxOE8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6565 = 259
        _dead_6991 = 795
        _dead_4992 = 859
    return total

def _ЮυБΣΔγολοшуЖяшβм():
    value = 582545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHzTfF0t/PwwYwC5mUGkDnEtsWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟОЗУУННпαЪзΒГ():
    if 42 * 87 < 0:
        889
        pass
    value = 731116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxvmfXkqqrkaGD7y31fCEhc+/Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΥμΗαпйяΖΑдМς():
    value = 209470
    text = __import__('base64').b64decode('TDZVOGdKcFNrS25xWTgxdmtlV0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΥγΦШсΦи():
    value = 497493
    text = __import__('base64').b64decode('SHZwSUVfZkFIV0M3U01OQnFhV1U=').decode('utf-8')
    total = value + len(text)
    if 5 * 92 < 0:
        547
    return total

def _ЙъαοПрйΙРУλφыгπх():
    value = 139257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3zWQFpu/L0zPlauw0e+HTIM5UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 99 * 72 < 0:
        pass
        1000
        pass
    total = value + len(text)
    return total

def _ЯнΠεЗηβΒНΔΥУλΓлτ():
    value = 154212
    text = __import__('base64').b64decode('YWVNR0VzejlfZHBfVUZtUTRIS0U=').decode('utf-8')
    total = value + len(text)
    if 77 * 75 < 0:
        513
        pass
    return total

def _ΖюМΧДΔΕξЗ():
    if False and True:
        _dead_3807 = 633
        _dead_6053 = 214
        _dead_4792 = 544
    value = 227063
    if len('') > 0:
        pass
        827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nn72TGUh6KYTaiqs2GSiYC0Fw1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βъεσПъμχΗшζΡγ():
    value = 283988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CC3KYXgc06QKBVqO0UGWCxYW3Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('dA==').decode('utf-8'))
if len('xx') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()