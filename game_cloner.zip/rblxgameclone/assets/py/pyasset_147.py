#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _μΒшПСαъЬΧЗю():
    value = 901819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In3bOHkh1ZcrGRyP7VzFOCsd/ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВοωφШМВО():
    value = 475299
    if len('') > 0:
        564
        pass
        _dead_1886 = 605
    text = __import__('base64').b64decode('WWF3RlA3UU9pNFU0aEo4WmtNZzY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4508 = 690
        _dead_3461 = 177
        11
    return total

def _УΑШиκΡкδΔ():
    value = 759771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBfmbHY23Ic2bjqPwE+5PBV6/Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρφδЕюΤюΗсα():
    if len('') > 0:
        _dead_6398 = 929
        _dead_9770 = 829
        265
    value = 888787
    text = __import__('base64').b64decode('dEdPNkRIWElEQ21udmFtTUdnU1A=').decode('utf-8')
    if 7 * 30 < 0:
        424
    total = value + len(text)
    return total

def _ЕЙРΧКΥνЕ():
    value = 652117
    text = __import__('base64').b64decode('U0R2S3psYk5RY3VfOTVnd1p1azg=').decode('utf-8')
    total = value + len(text)
    return total

def _БЭаГΞмξτЩиЕ():
    value = 551802
    if len('') > 0:
        pass
        _dead_3893 = 416
        844
    text = __import__('base64').b64decode('cHlRT3Nwc3BDWGRnTkN3b1BCNGw=').decode('utf-8')
    total = value + len(text)
    return total

def _кпйХΘΟНЪыπΛКснХΠ():
    value = 277006
    if len('') > 0:
        96
        868
    text = __import__('base64').b64decode('QVVhMXRoMXdYaGQ5ZG9PVUt3ZVY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7219 = 94
    return total

def _ρЖЮηтНачЫ():
    value = 791196
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3fqS2svxoBVbjah/mChAwd8/Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧιсςАπЖΑМχΒΩ():
    value = 747986
    text = __import__('base64').b64decode('QUI1bUoyM2NtMWxsNktCV05BN1Q=').decode('utf-8')
    total = value + len(text)
    if 15 * 7 < 0:
        400
    return total

def _ΣпхлΓΦЯРзЯеζ():
    value = 153363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EA3BaFVs/IIrHVyH6kPDbSAK70E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _рЩρЛкΩΩчО():
    if len('') > 0:
        _dead_4113 = 563
        473
        56
    value = 960564
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy71R34e3KIRbgy1yXOHZCsp1X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        505
    return total

def _дςэвУΜθдψРΘΝ():
    value = 298192
    if False and True:
        323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSfwalcbzr8FMSy59wS0OT8H4jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬВωΒоΥПΥИял():
    value = 45438
    text = __import__('base64').b64decode('bk5iNXhXUVRDUEJUMGxxZG1ybDM=').decode('utf-8')
    total = value + len(text)
    return total

def _цμΖοмφЫΩΝΖИСоυс():
    if len('') > 0:
        720
    value = 201657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSLBRHsq67E6A1a5wgSFGhce0jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _τυφнтЖνςщζйЗγМТ():
    if False and True:
        pass
        pass
        _dead_5270 = 712
    value = 293423
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgvQZXsG9v1VLSaJm3KxBnAHxWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΖΠΙξГΞшН():
    if 39 * 87 < 0:
        676
        _dead_1527 = 853
    value = 32570
    if False and True:
        _dead_8996 = 198
    text = __import__('base64').b64decode('T0tzN09zdlF1ZExWcnlDOFBwSXM=').decode('utf-8')
    total = value + len(text)
    return total

def _υετохΥШЯЩΘхС():
    if len('') > 0:
        26
    value = 435163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NS3ePkce95xUCQSa4Vq9MAsOsl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХВоξιβТХ():
    value = 245021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwXXWQUjrZ4uHSuO4HrCCyp64FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 46 * 70 < 0:
        _dead_3013 = 591
        520
    total = value + len(text)
    if len('') > 0:
        _dead_8440 = 606
        152
        _dead_6967 = 974
    return total

def _ЭΡιкΝВЬШ():
    value = 190562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Agm9S3Ia7poFFTaGzAO6ED0kyjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 13 < 0:
        _dead_2637 = 778
        _dead_7709 = 566
        966
    return total

def _ΥΗУΡΩзχуГВπЙλΑчΩ():
    value = 138165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB7tPFBt+/sCMTqz93rCYSAW4X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΤйΝΕπβιФιьπ():
    if False and True:
        761
        pass
    value = 939999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESv9XmErwfFTHT+E0mC+FQR/9zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εшВСизьа():
    value = 218386
    text = __import__('base64').b64decode('TEQwd0g5cldlY2xrUnVrckkzdm8=').decode('utf-8')
    total = value + len(text)
    return total

def _юΒъΔΤΞΦλц():
    value = 804631
    text = __import__('base64').b64decode('ZmdNZnF6d2JIMEFCckdMMjdobWQ=').decode('utf-8')
    if 98 * 17 < 0:
        _dead_9656 = 130
        797
    total = value + len(text)
    return total

def _υФлмοοαчаαΟ():
    value = 154773
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExvARHg/3Z8KbSSN5kPCLRAu0n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αрγαЦЫФψТ():
    value = 157352
    if False and True:
        pass
        _dead_5116 = 783
        154
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dz/rV2Qd5Jg6KD+ExX6IIS0bzV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        744
        983
    total = value + len(text)
    return total

def _ЗοцσВыξΣΚн():
    if False and True:
        654
    value = 689451
    text = __import__('base64').b64decode('YWphbFYzbDFSOWNqendoNUdZcTU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        243
    return total

def _ΓΕΚΚКκяρяоμФщΞрΖ():
    value = 748594
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQz0T18y1Y9TFRqMkQaHLnAL7Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γЛььХβЗЕзεζβοвФΩ():
    value = 912751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EijNfHMa0Pg5Ili5kEXHJHIh8WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝУКШЯТψМгСййН():
    value = 741514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyPCQ1sY57EgLxiT0VvGJzwetWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εщτфФСΧзЕΤχьαо():
    if 65 * 12 < 0:
        pass
        333
    value = 996493
    text = __import__('base64').b64decode('UElvTFBCT3g3a25HelgwS0NQSUU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        449
    return total

def _ΠТкμМФιΦΥΑОа():
    value = 892818
    if len('') > 0:
        _dead_2561 = 13
    text = __import__('base64').b64decode('QlBRbHh2QU0zMlNkSUdfdzc0X3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΕγхΛяσоΚ():
    value = 849393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHfJb3AM8Z0CFRic7nKFASAM4Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТххПГΖΘΔЫДДτ():
    value = 508599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyfVfXRszro0LRagm1+0BBJ57DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        289
        _dead_5559 = 84
    return total

def _οпсСсБИδлвΔθθΣхΘ():
    value = 593973
    text = __import__('base64').b64decode('UllQSjh1VHFGbXpNRmNncWlRblg=').decode('utf-8')
    total = value + len(text)
    return total

def _вδщνРКЮЯΩΞψσΔχΣ():
    value = 103764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRnQZ14g8v4KCSCh3X65IT8nsUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖСΓΒλПНΠΕΡ():
    value = 171679
    if 26 * 38 < 0:
        164
        109
    text = __import__('base64').b64decode('SUlsSGhGVlNMRHRjdm0zYnlfYW4=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ВБоΨЯПУХΛ():
    value = 200043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kyu1NmggyJlVGQOU4Vu+FXUI/lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λυЮштΧГвжЕн():
    if 79 * 91 < 0:
        pass
        _dead_5245 = 937
        _dead_1815 = 660
    value = 352322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQjpSGUYybs7CgGVyVS0BSQM4zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1623 = 979
        496
    return total

def _РХыЧОяшπвωΠ():
    value = 771718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn3rZn8I2f08LwuHw3qcYDQIwk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 85 < 0:
        pass
        196
    total = value + len(text)
    if False and True:
        pass
        935
        pass
    return total

def _кФыПнντπЮхТМцЗρц():
    value = 278790
    text = __import__('base64').b64decode('WTJJVTF2cUc4S3lYZFJWR0lPYnA=').decode('utf-8')
    if len('') > 0:
        pass
        472
        pass
    total = value + len(text)
    return total

def _аΖЯωθЕοНψ():
    if 55 * 56 < 0:
        pass
        _dead_8622 = 160
    value = 430638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDbMbFYR2qpWMSH0xmSXHA8l42A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΚΔбΧлПΩΜгΩжΝ():
    value = 37679
    text = __import__('base64').b64decode('ZFpUZVhWVXdVdVM1eVhNMXgxMW0=').decode('utf-8')
    if len('') > 0:
        674
    total = value + len(text)
    return total

def _ΦбяЯζΚρδгΠκψЖζ():
    value = 503250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyPBeQQbzv07b1m2+wODGy8X3Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΡЯΩыДΥι():
    value = 432034
    text = __import__('base64').b64decode('bjNLSVpnaXdQMnZFTFlPYVpnWk0=').decode('utf-8')
    total = value + len(text)
    return total

def _йυΦγфяλЖхшФαЦдΝХ():
    value = 765248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('My3pN3cJqp4XLyWbm1fCNiAcyUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩμюνΓЩдλЭУ():
    value = 195733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRW9TWgh7Z07alup5GTBOzUi9H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВбАпαΣΚи():
    value = 96128
    text = __import__('base64').b64decode('QW5xZ2Q5UFlvV3JtbXRTTTJFdWw=').decode('utf-8')
    total = value + len(text)
    if 79 * 24 < 0:
        408
        _dead_5829 = 52
    return total

def _ЦεеΘтζηβφДчЮΜТ():
    value = 162654
    text = __import__('base64').b64decode('bnBaRWpUcHFIXzNxbERGb2w0Z2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ωтбΜβВςмфΓтЖцПуУ():
    value = 84666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRjRTEUdp5IxACOiwwG2MAg/yV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЦδОμΗΨъФЬЕПΩΘ():
    value = 262303
    if len('') > 0:
        _dead_3075 = 157
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRu1bV0S37AwCQKvnHi8YDws0GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 55 * 67 < 0:
        415
    total = value + len(text)
    return total

def _ρπТгЦρηΦЬ():
    value = 964793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAPyVloRraIlCDaA+3+5JgwtzFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιтΒωψШММ():
    if 91 * 30 < 0:
        pass
    value = 357749
    if False and True:
        pass
    text = __import__('base64').b64decode('RDJZcHF1ZVZYUlRtYkl4UGlUTlA=').decode('utf-8')
    total = value + len(text)
    if 6 * 97 < 0:
        _dead_1796 = 636
    return total

def _ΓΦжοгΒДЬσφмΚοюλτ():
    value = 471465
    text = __import__('base64').b64decode('cWlqZ1VOODAydlc0a2IxNEtyTmk=').decode('utf-8')
    total = value + len(text)
    return total

def _фэЕшсΦαРΗΥΨш():
    value = 540934
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnbPa2AS5q88DCqSn0CXBRZ/4V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьθΞκΧхСлИШγпМЧ():
    value = 414918
    if False and True:
        248
        _dead_5820 = 343
        pass
    text = __import__('base64').b64decode('R1djeVhKbE1YekxZX0x6WklxMGs=').decode('utf-8')
    total = value + len(text)
    return total

def _еебЯДпКЧ():
    value = 5609
    text = __import__('base64').b64decode('VnhpUVZSUVNESnUzMDJuMjVHSGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙегВΘЩЬорτΓц():
    if len('') > 0:
        pass
    value = 668380
    text = __import__('base64').b64decode('QTdqWm1VZVlRN3JBblFnR2tYTGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ιфХПуπχвб():
    value = 385761
    if 28 * 8 < 0:
        94
        445
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy7pXlpsrf8vPjWozwPGZQ0H3Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΒπΡрхυελЕоγ():
    value = 682418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECjBOlYUq6wgIBz7wEXHFjcHtWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦйψБяАыςюАдυТ():
    value = 955420
    text = __import__('base64').b64decode('dHBoVHU4RGpWNjFldW4zcW9qb04=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        302
    return total

def _АςθΑΣЖвθΟ():
    if False and True:
        _dead_5180 = 157
        pass
        pass
    value = 571885
    text = __import__('base64').b64decode('UGpoVGdNdUcyMWxGNWFwQmlVZ0w=').decode('utf-8')
    if False and True:
        _dead_6585 = 995
        _dead_8276 = 449
        537
    total = value + len(text)
    if len('') > 0:
        pass
        799
    return total

def _ΓζΛΛЩЛОλщ():
    value = 93051
    text = __import__('base64').b64decode('eG1aMGxYaURwMlJGNXUzamtvTFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΥЪοгЮмоΜψξОФоΔ():
    value = 790938
    if 83 * 47 < 0:
        624
        _dead_2342 = 892
        _dead_7139 = 879
    text = __import__('base64').b64decode('b3RUNkhtS2hicnpQdDIzWWhjTFE=').decode('utf-8')
    total = value + len(text)
    return total

def _λΟкЪπОΤДьЭ():
    value = 28150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ai31e2QL+6lXCjby23qJMhUNsn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςЙΩЗТΞоЫλЩΨΜΙ():
    if len('') > 0:
        561
        _dead_2927 = 659
    value = 708877
    if False and True:
        pass
        pass
        _dead_7574 = 922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAqwelYt7qcELw6AnECiMi0Y9lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γКйθкαйуρνъЕΝЪ():
    value = 31192
    text = __import__('base64').b64decode('ZHM3TkJYMG1WOGRuSDcwc1NZTjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ςμψςхУΠαсЗЩД():
    value = 17908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACHUSUcp3/kHOQ2F/w6WbCwh0m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φИЭιαЧщБ():
    value = 501683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiXNP18WxqIiIC2m21yEOA173Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιйΨμрнχаρЦЕ():
    value = 751306
    text = __import__('base64').b64decode('SWp6M0RacmEzdmRmWVZ6UWZxZnc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4448 = 275
        241
    return total

def _ФЖэΙΛΒЫтАНχФΙЭαξ():
    if 11 * 30 < 0:
        600
        147
    value = 35402
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jgz2bGYW+I8kETizz1K+PCQH6zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        141
        _dead_6808 = 33
    total = value + len(text)
    return total

def _йΗΩАΒΨъχ():
    if 20 * 57 < 0:
        711
        183
        _dead_8073 = 216
    value = 731017
    text = __import__('base64').b64decode('QTZpYmlmbVNSN0ppYVFOUjc1SXM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        236
        pass
    return total

def _пиПФьлЯе():
    if 36 * 32 < 0:
        pass
        531
    value = 658977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy3WaHAdrLgCDB6GygayYxErzEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9195 = 366
        306
        _dead_1548 = 177
    return total

def _ρΟЧΑОΠΞБсУПшδΟ():
    value = 407355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSLbaXMB3J0uGBWxnH2AMBwG4Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΩЭτйЖΑΖΒНТЩвМгч():
    value = 29791
    text = __import__('base64').b64decode('aFZNN01NVWtYeENQeThvc2VZbUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫТВьβйгпζэγГκαТΝ():
    value = 672656
    if len('') > 0:
        417
        _dead_5807 = 4
        90
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lwa8NkM8rK5RKhmMyky2BTwivHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5925 = 215
    return total

def _ЙлκΟΥцяυРπΤяяΨ():
    if False and True:
        979
    value = 380473
    text = __import__('base64').b64decode('dEk3bEZEMVFVYTBDd2VaclVzTHo=').decode('utf-8')
    total = value + len(text)
    return total

def _бхΡцОЯΝТγ():
    value = 742170
    text = __import__('base64').b64decode('azBiNEZSVFJ5c0hoQTA4V2k3cUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦТтвχτЖδθЮтοЕΥ():
    value = 235875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRXyPVsU7PEzFByt5GK2ISIK3X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чТзρλΝЪжΧΚюмΙψП():
    value = 719684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyHCR3ABzrtQbiSt2WS0LD0kvF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лМдξНСЮХΞ():
    value = 98114
    text = __import__('base64').b64decode('S1oyVEhTc2ZTMHA4U3FRVHR6MDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠВτςДсζδ():
    value = 786328
    text = __import__('base64').b64decode('ZGZEZ3JNZ2t5VjJjc2JVdFdqVlo=').decode('utf-8')
    total = value + len(text)
    return total

def _δОиΝωъцЪннΥхРΜЛГ():
    value = 917437
    text = __import__('base64').b64decode('VmFvOUh6Zkh4RkhBbUJVVVhCWHY=').decode('utf-8')
    total = value + len(text)
    return total

def _жЮфяρнΜΔгαжИМΙε():
    value = 836615
    if 7 * 91 < 0:
        896
    text = __import__('base64').b64decode('ZHVSRENicmJTM0VfYzlIb3VpT00=').decode('utf-8')
    total = value + len(text)
    return total

def _щвΑΖЮΝСкπэΘΩяγκ():
    value = 750224
    if False and True:
        636
        609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jg20Y3kX+/orDwas4mfEGzUN52c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хШщбЦзЙтΥνФб():
    value = 548070
    text = __import__('base64').b64decode('R0FwbExwRjN1Tm5uMFhmYnBqang=').decode('utf-8')
    total = value + len(text)
    return total

def _эΦйКζЗηз():
    value = 71400
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cjq1XAQe9Jg0LliA7FKXASEL/jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βνЕλыЪужеΣ():
    value = 81284
    text = __import__('base64').b64decode('Rk5xMW1JYXVPM1REU3BTR2trYl8=').decode('utf-8')
    total = value + len(text)
    if 44 * 23 < 0:
        _dead_5955 = 742
    return total

def _ЯиαΣИτκωпТФΑΔΨх():
    value = 390550
    text = __import__('base64').b64decode('dXR1OFJEWE5mNURjYjNtWTFyanQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЩΟВщЫΓиЮΨгвСР():
    value = 739323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADfbXEcDx60JbDyy53OaARd4w1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥМЯйыцьф():
    value = 14804
    text = __import__('base64').b64decode('S0JQaVNFbXlKWUpGTUZTbzlkOGU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6780 = 822
        pass
    return total

def _РΙЫзΜρВυНδэ():
    value = 101794
    if len('') > 0:
        _dead_2943 = 12
    text = __import__('base64').b64decode('dWo5blpSZjJUR3FFM2VLNTl4NnI=').decode('utf-8')
    total = value + len(text)
    return total

def _фχвЦЮжшεУБГеЧ():
    value = 747234
    text = __import__('base64').b64decode('Slo0YnIweG90enBMQnY5UllzUVg=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6164 = 34
        290
    total = value + len(text)
    return total

def _АΚικОнфдГ():
    value = 649521
    text = __import__('base64').b64decode('b21aX1RVVXZpT0ZxV3MzQzJYb0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _БΣωδφΘΠΑчВΜЬъН():
    value = 786142
    text = __import__('base64').b64decode('R0pSYmpENDNBcmZCWXltZHZfZkg=').decode('utf-8')
    total = value + len(text)
    return total

def _хГэσсВИшδЩχο():
    value = 901620
    text = __import__('base64').b64decode('a0dSSXpPWFNDVmtNUkJ6OVVCRDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ξЖΙΓггЕьΡΘУЮЧΗ():
    if 51 * 1 < 0:
        pass
    value = 659740
    text = __import__('base64').b64decode('dU5XaGhYQVN5NWRtR3ZOVUN4b0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗσΡξσьВμΞЖБПβψΚ():
    if 16 * 46 < 0:
        _dead_7987 = 126
        887
        _dead_1111 = 49
    value = 857030
    text = __import__('base64').b64decode('cEtPcG9xbkVUY09ENG9vdEtFTGc=').decode('utf-8')
    total = value + len(text)
    return total

def _φΡρмЯмΡДΕμъΣτ():
    if False and True:
        364
        825
        362
    value = 543900
    if len('') > 0:
        pass
        _dead_9269 = 555
        _dead_3034 = 19
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRiyfGEz8YcxHB6P/2W5NXwj828='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        230
    total = value + len(text)
    return total

def _ьЧΡйτνΗχδЮδР():
    value = 851304
    if 86 * 38 < 0:
        pass
    text = __import__('base64').b64decode('c2hKd05JbE9DaFA0b18wU3VqV1Q=').decode('utf-8')
    if False and True:
        _dead_3993 = 396
        pass
        247
    total = value + len(text)
    if len('') > 0:
        _dead_3012 = 598
        pass
        582
    return total

def _νκЦЮζЮБаΙКΤЗ():
    value = 729772
    if len('') > 0:
        pass
        867
        299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHj0Vmgs1/oCFyOW+mXCIScg7Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        167
        _dead_8777 = 286
        pass
    return total

def _ΣИΠЖψκΤΔВΚΔПЧзΥв():
    value = 572785
    text = __import__('base64').b64decode('S2UwZUM3SmwxQmlFcGFaY3A1N1o=').decode('utf-8')
    if len('') > 0:
        199
        542
    total = value + len(text)
    if False and True:
        pass
    return total

def _МνЭΔШЩОλιл():
    if False and True:
        244
        _dead_2311 = 385
    value = 902613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cw3wRXMry6MvCj+AnWmDZSAf40M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςςфΚЬЦοΝπΙЯЮ():
    value = 354745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTzrPGEu7JwWFRr7mFG8AAx3wGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΛνΜΨЕεЯхυжЛиη():
    value = 129075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXzRbUsO2r47F1n6ymmqEQQEy0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ььχАрγмΗιуεως():
    if 53 * 72 < 0:
        _dead_7848 = 786
        _dead_5502 = 899
        pass
    value = 983372
    text = __import__('base64').b64decode('Z1Q1Tk53TVRjNW56NlVUNk80WWw=').decode('utf-8')
    if 35 * 49 < 0:
        _dead_1834 = 674
    total = value + len(text)
    return total

def _ΥжлρОχЫыΡΧ():
    value = 80325
    text = __import__('base64').b64decode('ek1nUG84OGJrR1NVOGZLbEQzZkU=').decode('utf-8')
    total = value + len(text)
    return total

def _νζВρΔэжδ():
    value = 948758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSLcXXYy7P5aMxeA2VGUEQ4BvDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨςмДДΞюФГΦЗινЦξΨ():
    value = 214631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgzrVwdqy7kTIxyT+AS6Ogl99Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фκβιТАрСΘпγЕυъЩ():
    value = 247517
    text = __import__('base64').b64decode('eXlRQ3JvcUMyOTNmYTZhdlNERWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦπэЛхЖηΜΖЭкА():
    value = 696102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjrMT34R1o0gLV7wznWbI3Qj91k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цЛоЗЦΘτяЫЖΒАэ():
    value = 575234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyT8emg864MwE1ao8GLGYRp68no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΖяΩινВΝКЯΩΗ():
    value = 818865
    text = __import__('base64').b64decode('cTEwWVBIWG0xb1lrQ3hKeHpMS2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕπεХΡλΣЧοχКαΑюК():
    if 5 * 97 < 0:
        pass
    value = 816249
    if 79 * 4 < 0:
        118
        505
        904
    text = __import__('base64').b64decode('aHloOXBkRVZZUkJ5cl9GbXpnd3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΒеуεΗΠРΧуΓШΠуОй():
    if len('') > 0:
        pass
        pass
        _dead_7877 = 480
    value = 680083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz29T1Yf/aFQAw72+GKDJjQC70s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιαγРАЖлΙπρ():
    value = 304210
    text = __import__('base64').b64decode('SFJ0QmhUNFhjRW1RNEdKc0dIN3M=').decode('utf-8')
    if 2 * 33 < 0:
        259
    total = value + len(text)
    return total

def _λΞЧяаΛΥΒΦрГиоЖ():
    value = 922152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRr8WHw716ITIB6p+QexOCQn0W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝАДаЗБΩмЙяЛцИУ():
    value = 724614
    text = __import__('base64').b64decode('WDdZYllBSDB1MW9lY1Z3SnN0bEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ηβηядιхАЕ():
    if False and True:
        _dead_6129 = 98
        866
        483
    value = 462383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiHrd11pr7suIiaPnEWXBHEpwno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ππпοΑымВσσΦΦрΦ():
    if len('') > 0:
        _dead_8624 = 403
        88
        pass
    value = 144072
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAPXbQEq2I0mAw6O4VG6HykI8nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 37 < 0:
        _dead_1562 = 108
    total = value + len(text)
    if len('') > 0:
        _dead_9056 = 707
    return total

def _ЫΡλыπΤлгР():
    value = 674429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQ3pSXYRqYw7CDCn43KvYQIN8UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьνΣΦμΛΣЪλεМОΖυ():
    value = 863377
    text = __import__('base64').b64decode('bUVMalpqWEN5OVRIYlNqUFZNSk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ТпХНВωΥКΥΒι():
    if 76 * 66 < 0:
        _dead_1984 = 970
    value = 427570
    if len('') > 0:
        pass
        _dead_8129 = 601
        _dead_7333 = 324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSXsX1sv+58QKx6zxkCmMQoa6Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2540 = 183
        pass
        713
    return total

def _ЫЙпψЗкΧтЮ():
    value = 885620
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cjr3UXk6qqRXaTmv8GW+ARAO50A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 59 * 100 < 0:
        pass
        466
    total = value + len(text)
    return total

def _ЦСЗуΨοИБΓβрνυ():
    value = 843801
    text = __import__('base64').b64decode('RVBpbHh4ZGJISmdUODRBb2daNUI=').decode('utf-8')
    total = value + len(text)
    return total

def _аΜΤιμΜуЙнэтмι():
    value = 153944
    text = __import__('base64').b64decode('WGk2aXpvT190dmgxQVpkOHJWMWc=').decode('utf-8')
    total = value + len(text)
    return total

def _тξλγщюТΔоγйоοР():
    value = 526228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQvvd0kbx7hSMj6CwEexHDQA5ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξщНУΧΟΨдФм():
    value = 767487
    text = __import__('base64').b64decode('Tk9ISFhFVERjZEZ2d0JqOHlfZXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _μΤΧлбоΕиμЖ():
    if False and True:
        922
        _dead_7341 = 97
        _dead_5442 = 864
    value = 506798
    if 69 * 28 < 0:
        pass
        _dead_5244 = 911
    text = __import__('base64').b64decode('b1hscDd1bm5LVnVMNjN0Tl9aR0Q=').decode('utf-8')
    total = value + len(text)
    if 18 * 47 < 0:
        173
    return total

def _ΘЮΠюНΨχчΨ():
    value = 370376
    text = __import__('base64').b64decode('VWg3UXMyOVZQSXRaWDJYdVdtTUw=').decode('utf-8')
    total = value + len(text)
    return total

def _МФОЦνэΟξБ():
    value = 569087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3e9bFsY2pIKLR2Ix2m3Eh95yFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞИπвбЯυуΚзф():
    value = 150975
    text = __import__('base64').b64decode('UmZKWEJxRXBDNktNUFMzb3NRcHM=').decode('utf-8')
    if 78 * 73 < 0:
        pass
        1
        540
    total = value + len(text)
    if 55 * 58 < 0:
        _dead_3015 = 518
        629
        pass
    return total

def _ШуΦйЗгжΧΤΘп():
    value = 545044
    if 71 * 29 < 0:
        740
        _dead_2574 = 794
        _dead_7932 = 393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IATlRElr56klPVqn+3mhEyc5zGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        486
    return total

def _ИηОуΖΒΞκ():
    value = 668699
    text = __import__('base64').b64decode('cGtFN3h0SVZacjl2dm9zYXVDMnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪмΘюΕЗΗкφвΚгχΑα():
    if 60 * 14 < 0:
        612
    value = 81988
    if False and True:
        pass
        45
        90
    text = __import__('base64').b64decode('dVlOZVFxQWhPVnJueG5xcWtXZTI=').decode('utf-8')
    total = value + len(text)
    return total

def _узΥУЛΗЮаЙκгοмуΡу():
    value = 651370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Di7tSWELz48AMi2wkF2iOBA4sH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        816
        pass
    total = value + len(text)
    if 16 * 44 < 0:
        _dead_2604 = 276
    return total

def _ΟχщνфЬКιШзрΥцι():
    value = 982527
    text = __import__('base64').b64decode('dldtNkI4QU91SEd3bWxobmxFMTI=').decode('utf-8')
    total = value + len(text)
    return total

def _жβяφΛσΞρзΟΖβъ():
    value = 749053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('My3Wb3gJroQOICrwxX7DAyk59Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θζλдεНсд():
    value = 498960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSnjZ0U02IcuLS2QwGa6BA120jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хпτйЙηωηК():
    if False and True:
        246
        _dead_4058 = 930
    value = 137003
    text = __import__('base64').b64decode('VFl6elgycU56OW9CdFBpSTVLMFA=').decode('utf-8')
    total = value + len(text)
    return total

def _οηЮЭмηκншК():
    if False and True:
        _dead_7293 = 129
        992
        _dead_8480 = 189
    value = 364506
    if False and True:
        _dead_7354 = 498
    text = __import__('base64').b64decode('V3o4UTZMSTk0bjBIS2wzNTNhanM=').decode('utf-8')
    total = value + len(text)
    return total

def _эξыΑωтιэвъГα():
    value = 606577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axb+OH9grq8tI1jyxAanJjECykE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5234 = 411
    total = value + len(text)
    return total

def _ЫοΥχьΥЧΗ():
    value = 609256
    text = __import__('base64').b64decode('aE5oeXJYNnY4QUI5elREOWV1THo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣъΔιвлдсНςΝЩХΕя():
    value = 472115
    if len('') > 0:
        681
        49
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRDzd1s70L1RbzCl3VmgISgc820='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эαФЩΚьΟκЪςΨЗэ():
    value = 538894
    text = __import__('base64').b64decode('dGU0NGFKRFptSUR5R2ZqR1lqbmg=').decode('utf-8')
    if 25 * 100 < 0:
        pass
    total = value + len(text)
    if 49 * 28 < 0:
        pass
        pass
    return total

def _ΜεяЕвθΠвΑЫΨχΓθθт():
    value = 742383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnrXOwcq34ABNzyo3AeYbSof62M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 93 * 90 < 0:
        _dead_8720 = 788
        _dead_4010 = 736
        290
    total = value + len(text)
    return total

def _ФηΖхΟκТоГцωЧΠ():
    if 10 * 17 < 0:
        126
        248
        _dead_6970 = 210
    value = 942784
    if 81 * 13 < 0:
        898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ixb+dkgO0YYrCQOFn06eZwEE0j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БпнЪвтνηтςОлεΒх():
    if False and True:
        pass
    value = 449083
    text = __import__('base64').b64decode('QVpIblZYd0Q3ZkpXT29DNzFSTUc=').decode('utf-8')
    total = value + len(text)
    return total

def _κψетεдΚγα():
    value = 947226
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDztbX4B+vsTMCf74Vi5JXwDzVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_1440 = 35
    total = value + len(text)
    return total

def _ΡРнθЗИκА():
    value = 93060
    text = __import__('base64').b64decode('aTRPQ1Vlem5KMTNFQ01qVjhTTXk=').decode('utf-8')
    total = value + len(text)
    return total

def _НЮβУУыОвΟюЗ():
    value = 635144
    if 8 * 28 < 0:
        300
        147
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiP0YEls274sHQrwnQLCIAI9t0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 98 * 40 < 0:
        365
        544
    return total

def _ΓЧαЦψнΑθБжа():
    value = 941392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzzqPggq14kPNVuGkWGkJQEjsm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΡχмПРΡΩ():
    value = 725221
    if 84 * 9 < 0:
        pass
        _dead_5057 = 468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dg7JfGEoqvsmAwqHyWaHDHAa00E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 96 * 7 < 0:
        835
        pass
    return total

def _ЖΧТΦпνψМАЗΘΨЫ():
    value = 710871
    if False and True:
        _dead_2472 = 617
        815
        73
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAjqXn0f2q1QGyGH+g6zLDUi514='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АНЗωπПΝРУщйεшвΧ():
    value = 422123
    text = __import__('base64').b64decode('SkFSWUlVNVdNWGVtamp6NWw4ZUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΒΙНэΨηдБЦΖφ():
    value = 820615
    text = __import__('base64').b64decode('SmZlSm90ODVDUll1Z25ONUV0a3E=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        586
    return total

def _πΘΗДιГнαХбБΝтцΟж():
    value = 814828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQzGe38Qq/oAajmqmUGgFwE+9EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 23 * 14 < 0:
        pass
        933
    return total

def _ТСΚНЫΓЛΔ():
    value = 461401
    if False and True:
        957
    text = __import__('base64').b64decode('QnpIWmk3UjgyTWxsck0wNWhFREU=').decode('utf-8')
    if len('') > 0:
        216
        pass
    total = value + len(text)
    if False and True:
        _dead_6859 = 817
    return total

def _ΙΝΟРШФкκЪБ():
    value = 575926
    if False and True:
        pass
        _dead_8139 = 669
        _dead_4723 = 647
    text = __import__('base64').b64decode('ZVZOcXhBUG1ZV19fa2ViV1VaVHI=').decode('utf-8')
    total = value + len(text)
    return total

def _бαИΟΚэзнΥс():
    if 24 * 62 < 0:
        pass
    value = 694849
    text = __import__('base64').b64decode('WXc1ZFhXWFRoUV9IN2VCcEVTVks=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΗзΡьБХΑ():
    if 13 * 80 < 0:
        _dead_9758 = 659
        537
    value = 928397
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iw3LbGQ05582KyGlkGW5PCYXvWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 19 < 0:
        814
        _dead_6725 = 484
    total = value + len(text)
    return total

def _БШΗДшμσИчнфσБΣμ():
    value = 702373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD3DSG4r37EONBa26USdIhEM/E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИРκΤνДοоμςχхО():
    value = 626927
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('UGs0OXVFOHNKaFd0XzdkalpPUE0=').decode('utf-8')
    total = value + len(text)
    return total

def _цУуОьΕрщО():
    value = 202631
    text = __import__('base64').b64decode('czIwMUN1X2RrdERGOVpDcEhqOHk=').decode('utf-8')
    if False and True:
        _dead_8128 = 71
        203
    total = value + len(text)
    if False and True:
        pass
    return total

def _ШлΔйτφтжмяпт():
    value = 658255
    text = __import__('base64').b64decode('S2JMdjZuUTJiSUR5RXpfWTBrbTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΗΙλмоягХΞλИζξΞ():
    if 93 * 21 < 0:
        849
        pass
    value = 317392
    text = __import__('base64').b64decode('Zno5Vmd4YlJ5cFhQMXFodlZHVVM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7481 = 630
        _dead_5801 = 168
        51
    return total

def _ЫчαРΜκΜξдΤЫдιθнВ():
    if 98 * 28 < 0:
        345
    value = 788312
    text = __import__('base64').b64decode('dlZldk1ocFdPT0FkRF9weHFuSFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЫЗчЕΔюРКм():
    value = 796624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRrnRmAd5pgBMySP33S4OzIK7Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΛκΤШдΚрмξЖБаь():
    if len('') > 0:
        _dead_2362 = 550
        104
        pass
    value = 389590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChzxRXptzp4BLj6Xxk6RIjAg3Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΣβЛςедΗКшΥ():
    value = 413757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCbLZktg1fomFTyZ2VeeZBoW9WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _шрВжςъλя():
    value = 489873
    text = __import__('base64').b64decode('dnAxYm9USFdCeGdkZTEwWE1IMWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪвЕеячΠχИαЦΧФБо():
    value = 954099
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nzvhe0Ud2akBKDWR0VeSBzwHzUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖцδΤъХαгсЫТлηδ():
    value = 176861
    text = __import__('base64').b64decode('VEhBYkEycl9EejZBazZEcVNjYkM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        180
    return total

def _ωσΕΔэшφκρнмЛэγлω():
    value = 916149
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyXdbHgfzKwtLTqv22e/Nw151D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _еΟΜгЦрУΗиЮσСπβиБ():
    value = 410321
    text = __import__('base64').b64decode('UGJTZDZWTldzT3RVS3NOZDFaYkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟιγΘТИτэс():
    value = 745321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSHpSkNv7/wlNDCB/wSTHhYqsTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZA==').decode('utf-8'))
if len('xx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    pass