#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _мφλΕкаоλшΓψδЪЗσй():
    value = 231258
    text = __import__('base64').b64decode('eXJwam81TmpVWk11MnU0ZVRZTTk=').decode('utf-8')
    total = value + len(text)
    return total

def _κбЖЯφζΧз():
    value = 845439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCrqZQEY+r0aCCOU8WSYACMb/Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        503
    return total

def _ΨЙЮπЮЖрлο():
    value = 494989
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTjIZ24D1KMxbjj7mWDFAR0Z6Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 18 * 68 < 0:
        pass
    return total

def _ΒΩЕРКΙъσΚПτрЫ():
    if False and True:
        pass
        pass
    value = 292092
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRrQeQIS3aw6Oyn00lujAgkD6lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 56 < 0:
        437
    total = value + len(text)
    return total

def _ЙΓзβбрεγНЯчΦΣРЕЖ():
    if len('') > 0:
        _dead_8471 = 687
        662
        pass
    value = 797603
    if 51 * 47 < 0:
        334
        102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzrPWHgw+Y0OMg734mKvNSg26G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 44 * 57 < 0:
        369
        _dead_1608 = 568
    total = value + len(text)
    return total

def _цфρюιНфТζжηнΡ():
    value = 231734
    text = __import__('base64').b64decode('TUV4YURsQkdNOTlFOXlkSWRSeDY=').decode('utf-8')
    if False and True:
        212
    total = value + len(text)
    return total

def _ъπмΘИΝκЕЖОЕхΡТ():
    if False and True:
        75
    value = 625893
    if False and True:
        _dead_6941 = 828
    text = __import__('base64').b64decode('dldjbUJ1bHYyWUhuMElJNzVydEE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΘтυИеЭъμνΗаСгШΒ():
    value = 663411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERX+O0se748JEhmbnmS4Zxom8WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝσДЗγζфС():
    if False and True:
        _dead_4914 = 264
        _dead_9755 = 486
    value = 765933
    if False and True:
        _dead_8331 = 435
        648
        _dead_2056 = 532
    text = __import__('base64').b64decode('eWhHakdlNW1hTWFOeVhwZ3FOUW0=').decode('utf-8')
    total = value + len(text)
    return total

def _φяяеОΟЕЭεСцЛζр():
    value = 743824
    text = __import__('base64').b64decode('ZkxKT2xuNXJ1X0dGeWlYeWR3ck4=').decode('utf-8')
    total = value + len(text)
    return total

def _хμСИнЧРЖжЪζщЬ():
    if 28 * 7 < 0:
        34
        _dead_8787 = 840
    value = 412176
    if 23 * 89 < 0:
        _dead_2117 = 203
        pass
        551
    text = __import__('base64').b64decode('eXdRRUl4eTlWcDNSTlJSZzRDbFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ςшΠфφГτщьΣВΓх():
    value = 379659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz/CQGUy5J06KSOVm2+ZPHMO1Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΕРдЧГΘЛЬпωюыΟΨΗ():
    value = 228731
    text = __import__('base64').b64decode('RzRTdHp2SnlhN2JEWDBPd1NUWUQ=').decode('utf-8')
    if len('') > 0:
        _dead_2731 = 701
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_1514 = 40
        pass
        _dead_2825 = 378
    return total

def _гыхЦςожΡХρЩ():
    value = 934460
    text = __import__('base64').b64decode('VVA5NVhLeHk3QkFOZ0Q2OHZIUXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ςоЬΟΘууΑΑνζΜДμло():
    if False and True:
        pass
        pass
    value = 715873
    text = __import__('base64').b64decode('Z21yeXpISnhLMmtoWGlmbTVqVXg=').decode('utf-8')
    if 85 * 65 < 0:
        _dead_2295 = 262
        346
        _dead_6645 = 497
    total = value + len(text)
    return total

def _ЯтΓΜγΩωОи():
    if len('') > 0:
        pass
        _dead_8098 = 532
        _dead_7764 = 609
    value = 323127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX7galAW+51TaDjynVWGCxYg1mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4960 = 635
        pass
    total = value + len(text)
    return total

def _чνΟжзйЪиγΑзθбκкР():
    value = 379734
    text = __import__('base64').b64decode('QkliNnJMQmpTU2NIckRLT2pWTWk=').decode('utf-8')
    total = value + len(text)
    return total

def _μΤАщПΠΖБΩΑ():
    value = 961734
    text = __import__('base64').b64decode('UVZlY0pZYkNSbFYwdmhkbV9na3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙнωζηоиΒαЛщΩФсЬ():
    value = 306548
    if 54 * 64 < 0:
        532
    text = __import__('base64').b64decode('UU9iVWhzTnJmYXlCUktOd3QySXU=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        89
        pass
        _dead_1501 = 124
    return total

def _αηзδяρЭЬКАЛςжЖП():
    if 41 * 22 < 0:
        498
        _dead_3611 = 293
    value = 954571
    if len('') > 0:
        pass
        559
        pass
    text = __import__('base64').b64decode('S3hXaTJ1UzIwZUowUFRqR1F2cDk=').decode('utf-8')
    total = value + len(text)
    return total

def _оЭΦЮБσσω():
    value = 678098
    text = __import__('base64').b64decode('YlczSUFkblJ3T042T3ZlUDh2eEE=').decode('utf-8')
    total = value + len(text)
    return total

def _хΔЩνъЫдЯгξПΨУпЖ():
    value = 525525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB7pQAgXrZEgOxqpwmmEMTEf71w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хаЦтдюШηЦЖ():
    value = 289379
    if 47 * 90 < 0:
        _dead_1443 = 761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MijCaXkO2oEGKgeU/nu5Bi8htm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πηМΠψΕΝГχсΗЙуХ():
    if False and True:
        938
    value = 29012
    if False and True:
        665
        148
    text = __import__('base64').b64decode('WHZzXzRpYlBVT2k5OFYxTV9Oa0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΠπхυΣхНΧΘ():
    value = 552715
    if len('') > 0:
        pass
        _dead_7956 = 720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HX/9a0QQ+fAMNiaa3V+lYyQW41c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νСΒэХоΥνΑкдΠεЖΝ():
    if len('') > 0:
        _dead_7768 = 577
        _dead_8870 = 771
    value = 948325
    if len('') > 0:
        810
        133
        199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FybIflgx3LESFib03EeRCxIExUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 92 * 56 < 0:
        _dead_4192 = 970
        pass
    return total

def _пмЛвΛбψвПνЕ():
    value = 208257
    text = __import__('base64').b64decode('R3lKb3hHWjRZMjVKbDZfOGw5VTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ВζИЕζнσМуΜПΘхο():
    value = 762233
    text = __import__('base64').b64decode('ZWJYekttS0h5dTVXMG5wYjZuMVo=').decode('utf-8')
    if 81 * 13 < 0:
        795
        157
    total = value + len(text)
    return total

def _ябΑшепоЫχФς():
    value = 262526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTa0b3Qa6pEPYzu13UPJOX0Y1nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        365
    total = value + len(text)
    return total

def _фΙθΚЮΟνч():
    value = 947040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgT1b1ksqpwMGDiGykWpERMMxXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕШКхАъθμНПЕΙΗψΕ():
    value = 234385
    if False and True:
        817
    text = __import__('base64').b64decode('UGt3V3RONnFXTTFIWldvbV9kRUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ъεШБКρφΡζΒйжΥк():
    value = 216958
    text = __import__('base64').b64decode('VEVVWnlfOFJYbVR0Tk9sTU9xQTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ювяυрбСшЬξЬДЖλБе():
    if False and True:
        pass
        _dead_6164 = 11
        613
    value = 654227
    text = __import__('base64').b64decode('UDZva0dfS1lCdks3N1RYemJSM1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _лχИцБЖΣΖΡρмЕГ():
    value = 157477
    if len('') > 0:
        132
        109
        _dead_8534 = 665
    text = __import__('base64').b64decode('b2NXWEVzeW9SbjlIb1FjcUg0QmU=').decode('utf-8')
    total = value + len(text)
    return total

def _КЪЫΖχбэΗк():
    value = 327768
    if 55 * 38 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBrFdkcy+fxXDT612WOXGRAu11Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 9 * 76 < 0:
        pass
    return total

def _ОωРвЗψяφГиΜ():
    value = 544101
    text = __import__('base64').b64decode('UGRjbktXVHYxSUlRNE9BTTNWb1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ψеЩкьωбЪНЮ():
    value = 262585
    if len('') > 0:
        67
        623
    text = __import__('base64').b64decode('TE05R0dpbHZ3TDMzWWtVZEtwVG8=').decode('utf-8')
    if 80 * 65 < 0:
        _dead_8323 = 913
        _dead_2795 = 13
    total = value + len(text)
    return total

def _УΚщвψЧμЭРЛбыЖ():
    if 64 * 19 < 0:
        _dead_1533 = 575
    value = 363640
    text = __import__('base64').b64decode('dU00eGdfYzMya3ZrUG94bGNRdFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖνЛфьбыΗ():
    value = 655413
    text = __import__('base64').b64decode('S29FNDR3b2N3ZV9FUjdXOUNOZHk=').decode('utf-8')
    if False and True:
        423
    total = value + len(text)
    return total

def _цРХгЕλгυОρЫбλΘΥх():
    if len('') > 0:
        373
        pass
        pass
    value = 677434
    text = __import__('base64').b64decode('Q0owSng4clN6M0g2aTBuWW93b1I=').decode('utf-8')
    if False and True:
        _dead_2694 = 153
        pass
    total = value + len(text)
    return total

def _χхΤΣΖχжКъеΣ():
    value = 991817
    text = __import__('base64').b64decode('cWtzenlvVHVRM2lPTGZvc01MaHo=').decode('utf-8')
    total = value + len(text)
    return total

def _χПοЦЬΘΤαΥΚ():
    value = 771840
    text = __import__('base64').b64decode('dllJZERYb0xPVXZsdUFsV3BwR0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝинЧъοΡΕΡΒΧ():
    value = 969082
    if 9 * 72 < 0:
        118
        821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISjgewE9r6ZTPSTwwVfEbRY2ynw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОимρΨюДΕγнΛΜμчеδ():
    value = 143883
    text = __import__('base64').b64decode('VFpFeWxZWWRtQWNCcFFGamhaRnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if 19 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()