#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _БъгУЗиЫЙΙν():
    value = 446627
    text = __import__('base64').b64decode('TERNUmlyVVQ4RlBldmxnN1J6TmI=').decode('utf-8')
    if 88 * 39 < 0:
        _dead_5337 = 230
        765
    total = value + len(text)
    return total

def _ыКΠъΨЦЩЦξьнэ():
    value = 69640
    text = __import__('base64').b64decode('SlN2SlFEY295OHFKNlI5djlrYzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮвМсуΦΨяшЫыпИно():
    value = 494044
    text = __import__('base64').b64decode('b1ZTNzdWd0NaM0hzOHY0UGtVTjc=').decode('utf-8')
    total = value + len(text)
    if 78 * 93 < 0:
        _dead_9636 = 303
        pass
        pass
    return total

def _εΠΠЧмжЕЙ():
    if len('') > 0:
        pass
        152
        pass
    value = 223279
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwO3dnY72Jc2KiKrm32KEQ16wEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 67 * 98 < 0:
        320
    return total

def _ΘоΛΣЧθβеЖΔΠκ():
    value = 372603
    if len('') > 0:
        _dead_3140 = 495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD3sQVYup5onDRyS61LBDnR743k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эНξοπКЦΕ():
    if False and True:
        pass
        478
        _dead_3187 = 179
    value = 626282
    if len('') > 0:
        pass
        _dead_1755 = 96
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fy3JbH0A6YImNBW33V2lGRx5sXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩγъХХыЕΙы():
    value = 689938
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyDGXkgW+PwEIxz6/12nHh82tj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΙЕβЗΓГλζЙ():
    value = 662874
    if 90 * 22 < 0:
        681
        _dead_4460 = 634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxnMVEYb7fwgGx+5+ADCEXcExXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪРτгμΦΞβбο():
    value = 842291
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECn2WHwq//kvPhWn8nCcJAMt4mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΩуРБфтеУΨншв():
    value = 975872
    text = __import__('base64').b64decode('QkhhVnRrcVlTQzRwUWdKWWNlSUU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _хыИДхδиΤεЫΦГЩ():
    value = 478855
    if False and True:
        834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQK9ewZqq7kGHir7w2XEInx4vGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΒυгспЩΘοЛ():
    value = 79434
    if 31 * 67 < 0:
        _dead_2246 = 401
    text = __import__('base64').b64decode('U1RfTW1IRmFQclF3Y2tVRGxqa2U=').decode('utf-8')
    if len('') > 0:
        _dead_8182 = 630
    total = value + len(text)
    return total

def _АΘЩчζΞЩΔЕχΓВГСμ():
    if len('') > 0:
        592
        pass
        pass
    value = 805390
    if len('') > 0:
        80
    text = __import__('base64').b64decode('T0FnU0Y1RzNWZHUxYU1uZ0xibzA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _уΘτйНζщΠΨ():
    value = 18346
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSriYns45Jk1NDCpn32WIj857FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хджШαιгβ():
    value = 689071
    text = __import__('base64').b64decode('emdSMXhoWDBMeEQ2bnFoSE0xZGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ШКЦδΡιйВΦ():
    value = 68431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB6zOWshwbEaHAeK0kHCJwMl8lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        448
        pass
    return total

def _ЪрпшξясδπςЦυДπΑЬ():
    if len('') > 0:
        328
        _dead_3191 = 495
    value = 362163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KC7VS3YR64wxEh6N92XGYncX0Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФЖΤΚθФΖг():
    value = 130695
    text = __import__('base64').b64decode('TWR6SnBKTHBVV1dHX2Iycnh3T1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЫжяδψΟυ():
    if len('') > 0:
        _dead_9457 = 195
        pass
        _dead_7356 = 900
    value = 517138
    text = __import__('base64').b64decode('eU1mZHBrREpOUGlNdUhIdVYyZ2U=').decode('utf-8')
    total = value + len(text)
    return total

def _сШЙςлΘИуιфюЙκ():
    value = 796292
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyLLW1Vr5rJVOVmT3XuTOA0D52w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зикБфΖΦсΛХ():
    value = 973905
    if False and True:
        pass
        348
        _dead_9292 = 697
    text = __import__('base64').b64decode('bXpRQ09oVWFzU3c0S0Q0Qzc2S3I=').decode('utf-8')
    total = value + len(text)
    if 73 * 71 < 0:
        pass
        pass
    return total

def _ръΛОДΛдξы():
    if len('') > 0:
        pass
        643
    value = 475628
    text = __import__('base64').b64decode('VGNkdFQ3N2RLaVE0X2VXVFZrUVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞτФКΡΥθδаχςΝсΞΙБ():
    value = 272739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiS0S1hvrf8PAgz65U+dGA0M3ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΖПθЙтюΠПбΘа():
    value = 399238
    text = __import__('base64').b64decode('bnVpNWVtR3JEdGlQQXJBQnJBcEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ХЧΓγеδЪЩ():
    value = 793009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDngalIU6v4kCTCFzXCALH18sEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 8 * 53 < 0:
        504
    return total

def _ΒиΣξηΓскГо():
    value = 413614
    text = __import__('base64').b64decode('bG5KZ1l3U3U4RVVJaWdwOV9IcTU=').decode('utf-8')
    if len('') > 0:
        995
    total = value + len(text)
    if False and True:
        _dead_2006 = 157
        _dead_6816 = 207
    return total

def _ΔЩЯЦΟННξΧΤщ():
    value = 343573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AifIWlkf9ZwIBSqM+EWEFTYEz10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΗкЩΧΒБжТ():
    value = 198572
    if len('') > 0:
        _dead_6714 = 627
        947
        461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyKxQQQJrrguGTCx6WavDR8s018='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 96 * 13 < 0:
        pass
        141
    total = value + len(text)
    return total

def _ιΡΤшΒчщмΣ():
    if len('') > 0:
        pass
        _dead_6221 = 544
        pass
    value = 108087
    text = __import__('base64').b64decode('Q2JiT3RIVWoySUJxeGxaOFVkZng=').decode('utf-8')
    if False and True:
        405
        _dead_2815 = 244
    total = value + len(text)
    if len('') > 0:
        _dead_9608 = 400
        823
    return total

def _ЮθпЧАФЙΙеЦΚ():
    value = 345885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQnwTHBt9fESDz+pmGyBOjQO61Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛςДΦоАиΣΑтяж():
    if False and True:
        275
        _dead_3260 = 388
        _dead_8390 = 855
    value = 870556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji2zdAkp0YENODaQm1GWAAAH8Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _αгйнКτΟΓКцςзыИЯ():
    value = 9156
    if len('') > 0:
        _dead_6338 = 492
    text = __import__('base64').b64decode('S3g3c1RmUnB2UWN1TjdzdXEyUWc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        114
    return total

def _мчБВΑδБсΥРζεДщσ():
    if False and True:
        pass
    value = 292304
    if 15 * 4 < 0:
        _dead_2852 = 408
        _dead_4475 = 438
    text = __import__('base64').b64decode('VDgxRV81a3ZJVTlnWjlwNjIwbjE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1206 = 723
    return total

def _ГλФеЯКИУθα():
    if len('') > 0:
        58
        699
        _dead_8409 = 878
    value = 634260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzvxQ1ww2YAJHQiw90aYYh8d914='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΛГЭЯРсχуκΚъГ():
    if False and True:
        pass
    value = 135222
    text = __import__('base64').b64decode('RDhFOElHRnNrZ1c2VTFpQ05KZEo=').decode('utf-8')
    total = value + len(text)
    return total

def _дκξψУΠзиοэОБМς():
    value = 359454
    text = __import__('base64').b64decode('dGRzTFNmQjJxVWtnSHNzODNkejE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΕΜЙμςΘДΣφΦ():
    value = 200315
    if len('') > 0:
        721
    text = __import__('base64').b64decode('UkdXdmpTRGs1RFBGdjdZNWx5M0U=').decode('utf-8')
    if False and True:
        _dead_1384 = 392
        765
        pass
    total = value + len(text)
    return total

def _ψъПκΜπωФщΛбЩжχФЙ():
    value = 87398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D33VfUFrp480bRuPx3O1Jx8M90s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6037 = 479
    total = value + len(text)
    if 32 * 94 < 0:
        928
    return total

def _яКбхФГκТяяπξЬΔΣω():
    value = 448246
    text = __import__('base64').b64decode('bVFFZ2ZaX3dkZndDRWZ3UWU2OTc=').decode('utf-8')
    if 12 * 58 < 0:
        401
        _dead_6723 = 773
        pass
    total = value + len(text)
    if 58 * 70 < 0:
        _dead_1732 = 152
    return total

def _ΟψΑцΟфЬΔсΦΩα():
    value = 21824
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3zhV3g1+rIiawyo50KABg0i6XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОТеΣмШТΒюяфЦЗ():
    value = 551783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Chmze1cB35I6NhmtmXWRHQA53WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КжШгρцΤъцоаΞЬ():
    if 58 * 36 < 0:
        pass
        _dead_9007 = 257
    value = 177825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDveb2tq26UTax6Kx32hYAAO8WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7636 = 916
        pass
        769
    return total

def _οЗсСζЖЧδБЫгвюζй():
    value = 825173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IALqamEBr5JXDS6v+3iHAD8qw0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъаеюΙεκшАсΥлчοДη():
    value = 55019
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiDNeFAX16FbOFr6mkGoDRwp008='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7658 = 659
    total = value + len(text)
    return total

def _ςΟγβλЖяΘЬκυЦГпщк():
    value = 512911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgLqWwkcqfwMMgO62VGFEXYrsn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гЫΧПХИАΡЖξΕνξΜΤ():
    value = 624965
    text = __import__('base64').b64decode('QVNQb3dwcENuODVqTzZnVlg1NG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΝΞωацПщи():
    value = 527574
    text = __import__('base64').b64decode('dDY1WEpJU1EwT3Q0eVdKcXpjRDY=').decode('utf-8')
    total = value + len(text)
    return total

def _кГйТМНαпЭ():
    value = 426326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En7vREQ8yKEFLCKV0k65GxAl4W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тмтюЗςσωБλο():
    value = 258946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ayjtd1Q4xKACHyS34H2DMDF6vWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УнЩцШχпΦэсСЗΩ():
    value = 985720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhrQVkgzx5BQHyuM31GTbDch92M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _огκУΞΣбЖΤижτУп():
    value = 296811
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH7VT0Mo144VOF+0+lSABzU9zUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 24 * 51 < 0:
        pass
        219
    return total

def _οψьДξςъсОМΙГ():
    value = 165618
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjrRXgcG9oc5CA2ynH+FBQYcsmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шгΤτйыΦВςθΣΟΠ():
    value = 667222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jyf8fH4Ar6ZVb1qlyUKxNhN2z3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΝлΚЕЮУжЯБзЧИΜΨω():
    value = 13910
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj3bV3sQ8KssFDul6WWkAC4Yx1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВмТΞюΠдΡ():
    value = 138583
    text = __import__('base64').b64decode('cFlrMFFFRGNXZjZJX0ZFQUVheE8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        519
    return total

def _ΧЙασдрΝиЦцСШЗ():
    value = 687468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAy1NnIDyPwtCTj14XOYBy0p020='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8399 = 480
        _dead_4651 = 347
    return total

def _ЖЫЯАΑВхκΙПβзь():
    value = 326394
    text = __import__('base64').b64decode('WFZpejhLWHh6ZlFSZXBPUWJ0VVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒτКЭСΜМр():
    value = 685701
    if len('') > 0:
        410
        _dead_7761 = 996
    text = __import__('base64').b64decode('cWVKdEZ1RjEwQjF0RmZaZTR2ZGQ=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _КюςмйЪηΡΜуγЙ():
    if 6 * 66 < 0:
        63
        _dead_8484 = 578
        pass
    value = 701971
    if False and True:
        _dead_7029 = 512
        pass
    text = __import__('base64').b64decode('ZW1mSWJtWEI4bkdyRTlDNnFVVEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔсжЬГξΝΛΦШэαΡЫ():
    value = 693269
    if 66 * 82 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT7VNm482Y4pHTWb3HCYPjV2vWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 17 * 43 < 0:
        pass
        _dead_4727 = 332
    return total

def _ΤПΒЭРКΑМρС():
    value = 887377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAf0d30zybowNRb7z2+RYyoGzWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЕЯАκΟкαФχюШρ():
    value = 198399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyK0VHcJ6IouHyGUwVOiLjEdwGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        401
        _dead_8048 = 18
    return total

def _иωΝθЦθвНεΗЯЭЭкЭ():
    value = 197858
    text = __import__('base64').b64decode('d2h4dU5QbE5PbXFTVFBlbkJkamo=').decode('utf-8')
    if False and True:
        _dead_3542 = 379
        pass
    total = value + len(text)
    return total

def _ΚдΟΘΡчРуαωΩЮп():
    if 9 * 98 < 0:
        _dead_4377 = 679
        pass
    value = 136404
    text = __import__('base64').b64decode('T2NNd3Y2RmhCaGQzUUhrTk1ncnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛдΑПеЩτуиЖδВςΨЭψ():
    value = 968425
    text = __import__('base64').b64decode('YnIzSlU5ZW80T2k5ZUM3amRiemI=').decode('utf-8')
    total = value + len(text)
    return total

def _φΑЯщςχЗюЫШЮΓ():
    value = 839188
    text = __import__('base64').b64decode('UjhPbjRhVDhWdWNLRmJ0T2FiQTQ=').decode('utf-8')
    total = value + len(text)
    if 7 * 52 < 0:
        pass
        983
    return total

def _шъΠИьΜΧДэфΛχΔлгг():
    if len('') > 0:
        pass
        288
    value = 809020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nha0encq7YMGNQWxkAe5HDN361c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 9 * 48 < 0:
        pass
    return total

def _ΤЖηДжлФЕНЛρ():
    value = 573898
    text = __import__('base64').b64decode('RFVCb3E1TlNTeXVZcTFBV0NMNFg=').decode('utf-8')
    total = value + len(text)
    return total

def _νυМΕюДσгжζζя():
    value = 55332
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3azVkg7yq9UFyeF7nGCOCwc63Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        471
    return total

def _ПЧλΜЭъξщЕашЮпцчЖ():
    value = 563006
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTrlOV8725wnLFq62lKBGRcM7Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СУφΠΘгЭΖωΠКЪЫΑβ():
    if 69 * 67 < 0:
        _dead_9644 = 535
        pass
        _dead_5904 = 291
    value = 633688
    text = __import__('base64').b64decode('S3F1Mzg3WkxzeUVudkRWcjluTko=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        930
    return total

def _ЦбЛδβЖАБоояε():
    value = 500071
    if 92 * 16 < 0:
        844
        613
        900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DizFN1g39IpXMVqnmlzJYzQ3/kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПνЫэηХПΝΙЬКβδдυ():
    value = 294372
    if 51 * 50 < 0:
        885
        pass
        717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3jhYAQd/4osaQaUy3XAJwwhwkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эфМазπαΣчΧ():
    value = 342228
    text = __import__('base64').b64decode('WXptWWZJaWpXUWdDTl9QWXo2a2M=').decode('utf-8')
    if len('') > 0:
        pass
        195
        864
    total = value + len(text)
    return total

def _ζчΨЖтΙиνДТУΥо():
    value = 358525
    text = __import__('base64').b64decode('TERxRzIxSlVxZzJPbVNwNW9HNFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ваТΨοψΟεκ():
    if len('') > 0:
        512
    value = 419818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwDuYVA+/PhbKBeB3WCaASA191Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 18 * 44 < 0:
        pass
        _dead_1314 = 520
    total = value + len(text)
    return total

def _ΥЭΕЦжДндНγ():
    value = 823423
    text = __import__('base64').b64decode('a1U4QUJldFhRT2xSdUkybVJudFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЖЧςАЭЮψτΕΚζЕΞЯΔ():
    if len('') > 0:
        _dead_5676 = 575
        747
    value = 913655
    text = __import__('base64').b64decode('R05Nc0FxU1Z2R1BsU1lZRXVDRzc=').decode('utf-8')
    if 57 * 6 < 0:
        556
    total = value + len(text)
    return total

def _чуцαδТсψ():
    value = 696209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCPHOFoR0ZsOERr12nGeZX0pyT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΓЩςоυтΑυсΠΤ():
    value = 249575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSPAP3YSzP8gbDyAz3CoNzx/4zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9066 = 668
    return total

def _феνИΠСμΘчρД():
    value = 570176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ER/KQGAx1YBaEzqn/Ue3HC0fwno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 2 < 0:
        _dead_1136 = 473
        244
    total = value + len(text)
    return total

def _ΚГτАиΔΣφ():
    value = 543586
    if len('') > 0:
        pass
        pass
        _dead_3374 = 493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjvWVn0czb8bFCSKy1myGScI81E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГэДкйχРΤАΠХЧкεС():
    value = 723750
    if False and True:
        _dead_4000 = 624
        404
        208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjrxfHcpppInOT2q+mm6ZwMczEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΒаπЭχШνοЭРΗσЦ():
    value = 843324
    text = __import__('base64').b64decode('UDBXVzY0RFdQMkNwU3pZZEI0aWU=').decode('utf-8')
    total = value + len(text)
    return total

def _аюбсИσИθЫд():
    value = 258865
    if 90 * 96 < 0:
        pass
    text = __import__('base64').b64decode('ejNGN0dfZTUwR2lsMndtSGFmYUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡμΛθΑχоδИφΒк():
    value = 963413
    text = __import__('base64').b64decode('cTl3TEVVVmNaemUzUVo4aTZFdVY=').decode('utf-8')
    total = value + len(text)
    return total

def _δΚΨэκΣчΛυυΥБσχ():
    value = 92338
    text = __import__('base64').b64decode('bWJ5NWxaX1c2a2ZBVUhDU2pnYlY=').decode('utf-8')
    total = value + len(text)
    if 41 * 9 < 0:
        201
        pass
        _dead_2219 = 72
    return total

def _ξχιΖжΙясμМ():
    if len('') > 0:
        387
        _dead_5092 = 394
    value = 597925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxD2WWgo7KpbICv6nHSaNREf3Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _λхйΞΚеχΧΟΚςыфЛ():
    if False and True:
        _dead_5537 = 676
        603
        pass
    value = 690774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCj0P2hs/6IqMQ2h9368Ax1973c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 41 < 0:
        _dead_6453 = 371
        _dead_7651 = 348
        _dead_7775 = 941
    return total

def _πΡжияЩπΩачλΣИКпК():
    value = 211344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LinbbEkv1o4qEgn2/EWFEhMAsjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        849
        _dead_9308 = 104
    total = value + len(text)
    return total

def _рτОΥжΝΣЧщΝП():
    value = 532572
    if len('') > 0:
        312
    text = __import__('base64').b64decode('dHpHRVFCX1lOdmxwaF83UUJ4V3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛпΩмΠпаποβеΥ():
    value = 208744
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kyaxb3Qc+IcnBQr78nDDEx86tTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΥаКΗФξЪбρ():
    if len('') > 0:
        _dead_2543 = 486
        pass
        pass
    value = 242191
    text = __import__('base64').b64decode('TXdXMDJ2ekc4V3EyQmtZcWNJZFU=').decode('utf-8')
    total = value + len(text)
    return total

def _тΡсрηфЩъυΡβΠуО():
    value = 514423
    text = __import__('base64').b64decode('SGRKeFNLaDBFQjZYTERqRWdnb3Q=').decode('utf-8')
    if len('') > 0:
        pass
        313
    total = value + len(text)
    return total

def _кЪΟХЬЯпДъ():
    if 51 * 47 < 0:
        pass
        _dead_3567 = 585
        _dead_9084 = 89
    value = 309272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQbuNmUoxvE2Lyeg5U+iEAYe62g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЙНμΑГЮтГЯГ():
    value = 210798
    text = __import__('base64').b64decode('aWNhZ2JCUmlHOWdNWnJXdnRmMVY=').decode('utf-8')
    total = value + len(text)
    return total

def _τζбФжΙρПυχжчΡА():
    if False and True:
        822
    value = 81828
    text = __import__('base64').b64decode('emlfWlBpajNuZFpwT0ZrcVRmOFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜпУоκчЛМйβЖΜфπцЭ():
    value = 912562
    if 49 * 32 < 0:
        pass
        773
    text = __import__('base64').b64decode('eFRvTVg5eHA5QlhBaVFGeTVkM0k=').decode('utf-8')
    if 33 * 30 < 0:
        _dead_2643 = 715
        _dead_6529 = 960
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _БχμЯςдиΤЧЕΓΛбиф():
    value = 343222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D37MZXMN0Y5RDir7y3OfHQ97smA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ИςΓΤВцΠΘ():
    if len('') > 0:
        pass
        167
    value = 710531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXbRf3U60pg7GSqzwwW1Bz8i5kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        583
    total = value + len(text)
    return total

def _ΒΙΟΑΚςчдМΡФηдгбΣ():
    if False and True:
        _dead_4941 = 658
        71
        _dead_4977 = 203
    value = 521785
    text = __import__('base64').b64decode('bGlJUVpoTE5Wb3QxYkhkRUFRNm4=').decode('utf-8')
    if False and True:
        965
    total = value + len(text)
    return total

def _сСщγΕнШнΧЖЮЮВρЗ():
    value = 920118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACfpYFIV3ZALOBaJ8U+hNys2skY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΓзεΧΗλМτχщξμ():
    if False and True:
        pass
        _dead_1011 = 631
        _dead_7511 = 38
    value = 426720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyCyaAZh2asrPleJkW+oBAEm7Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 42 < 0:
        2
    total = value + len(text)
    return total

def _ΦμрвΥъμκпК():
    value = 511151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DS29SFwt6JkKNiaG/XKjDTcNtTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΟЧΝрΘФэγДъьаΙ():
    value = 78697
    if False and True:
        _dead_4189 = 323
        _dead_8345 = 494
        _dead_2793 = 34
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX/dRQlh+oBbKSGl7w6GGn0CvFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фμПσдеЭζыВυОДΕτ():
    value = 481392
    text = __import__('base64').b64decode('UFQ0bGR0VXFfZmJjazVGdjBGcWg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _θАЙЧУΛмеΩεμ():
    if len('') > 0:
        pass
    value = 96513
    if 68 * 35 < 0:
        _dead_6613 = 236
        pass
        _dead_6996 = 547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgD2SV1ozJ0HDCGi3EyCPwYMszs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        82
        988
    total = value + len(text)
    return total

def _уЙзяфΔκιфа():
    if 55 * 46 < 0:
        _dead_5010 = 734
        _dead_6761 = 731
    value = 561240
    if 14 * 78 < 0:
        _dead_3258 = 13
    text = __import__('base64').b64decode('UnNiQzE2RGQ3TGlPcEVuMFJFMU4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ДНλЧΕюЛξмШαΗτЮ():
    value = 856623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiP3QGcp2ZgqFRenwQWBNSwp/kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓьЧΠЫВΜБΦШъΗЧλяρ():
    value = 328095
    text = __import__('base64').b64decode('Y1pXM3l1c1Zxc0RhS3ljWUNqaGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΩиΙΝйьъΛ():
    value = 194180
    if False and True:
        374
        pass
        _dead_5063 = 895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASXqVGM30b82Mw7wnFDFZSAB03w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АζΠυΠВАшБυλ():
    value = 579366
    text = __import__('base64').b64decode('U21ncGNuWTdhdU9kZ2dNM05Zbk8=').decode('utf-8')
    total = value + len(text)
    return total

def _адΕΜΒджз():
    value = 454022
    if 77 * 8 < 0:
        _dead_5861 = 619
        pass
        138
    text = __import__('base64').b64decode('bFROMTUyUDA5R0RiZGJENDduamg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1043 = 86
        pass
    return total

def _ΞΧхэοодТз():
    value = 507746
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB/xTUUG26pTbgik5GKiGXF/4VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αξтζБФοшЬЬЫιЖωΖ():
    if len('') > 0:
        pass
        851
    value = 21655
    text = __import__('base64').b64decode('ZHlpNk9lbVJMQ25NTEFBa0FJSzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _аФБψжΚрΡα():
    value = 123295
    text = __import__('base64').b64decode('akEybEdMbnFtVEQ2X1JSOEkxbWk=').decode('utf-8')
    total = value + len(text)
    return total

def _бЕИχαЮйσ():
    value = 997013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhfCTGEtzpwSFzCt7ACpMj8owD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7269 = 224
        706
        355
    return total

def _μзμЭТдярвηΣΣΡ():
    if len('') > 0:
        _dead_9619 = 639
        22
        pass
    value = 521897
    text = __import__('base64').b64decode('cUFlZlN3YXhGeGdCcVhJZ2JxNjg=').decode('utf-8')
    total = value + len(text)
    return total

def _пуьΨфσνТζΓефΩсηя():
    value = 225781
    if len('') > 0:
        pass
        pass
        406
    text = __import__('base64').b64decode('V1R6aXZhTXFnY0lzRFByTjZGMWE=').decode('utf-8')
    if False and True:
        _dead_6583 = 418
        pass
        pass
    total = value + len(text)
    return total

def _ЯРюфΙттΒΣШ():
    if 3 * 84 < 0:
        pass
        332
        774
    value = 596447
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRnVPAc79PEHHT2W/gSnPg4oxmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БτΓΖхνΨГхΚψЬΛАрΑ():
    value = 77764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh3nXkATrIQ2ESGx6VmlFXQ94mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σЖзΒЗмωуυЩя():
    value = 680096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz/PbQNu1YRQHhyW4V+yHy8p7jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒчδοУЕРхВуг():
    value = 288372
    if 96 * 59 < 0:
        720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyTQa2Q41bgJHimA7weWBnx25jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_1690 = 257
        923
    total = value + len(text)
    if False and True:
        395
    return total

def _φДАсνΣΦεыПлα():
    value = 413261
    text = __import__('base64').b64decode('Y1pKa2tYM3poY09XTmFkc1h4RUo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3217 = 376
        pass
    return total

def _ΤСΤувιЯвΘЛτнвЧ():
    if len('') > 0:
        _dead_2802 = 473
        32
        pass
    value = 317033
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHzGP1sw7JEIHTuKm1uFPxB61HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 2 * 27 < 0:
        _dead_6198 = 357
        971
    return total

def _ФЦΟΟтΠЦνθεΜτф():
    value = 736752
    if 97 * 92 < 0:
        _dead_3838 = 512
    text = __import__('base64').b64decode('YTgxMzVGOVZ6VjNOa25YTW5PeUk=').decode('utf-8')
    total = value + len(text)
    return total

def _θΙεИГПΦοачσБηуσж():
    if 51 * 59 < 0:
        _dead_7579 = 99
        _dead_5233 = 326
    value = 672691
    text = __import__('base64').b64decode('eTZQUWtmaTB5RnFjQ2wzaFdIMGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝφщτБΘΛлΜшΔБδ():
    value = 461952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTb0N25pqZpaMFmTmnydJAoV8G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γсРΩялыΙд():
    if len('') > 0:
        773
        _dead_5230 = 970
    value = 296617
    text = __import__('base64').b64decode('Q1N3aUhSVU1ieDk2TlNTanNvZUs=').decode('utf-8')
    if 99 * 66 < 0:
        19
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ЖвчΞЙЦКВчςΧыΒЧу():
    value = 417310
    text = __import__('base64').b64decode('T2FLdXU0dngyZWhUVXpXZGdVSFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΚμπμЯЧЙХ():
    value = 148859
    if False and True:
        621
        741
        _dead_3084 = 306
    text = __import__('base64').b64decode('RFR3MHRXbHdBajJHbnVOU25kenk=').decode('utf-8')
    total = value + len(text)
    return total

def _φΥΓΣλкМКψ():
    value = 320132
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzXVUVAfrvgvNwCh3Gm7LjIq/no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιцυΟЩρЗψχшΑ():
    value = 482427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jjfgflws35c0ECSwwWG1YAgj220='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ινδэямμи():
    value = 868941
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX/ma0Es7YwMFzy50lGjZXUEsks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5534 = 307
        _dead_9114 = 130
        _dead_2637 = 208
    return total

def _ηρьΡЛχΚЗЯЪσΑ():
    value = 781762
    text = __import__('base64').b64decode('eWdxS19wUUcxZDQ4QXAyQ0xqTVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞτθгΜжщОΦцАΜцαпа():
    value = 232923
    text = __import__('base64').b64decode('ckFfak9aSDJhZHVreklCTGpOR1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒчηПΡЭΟΠНяя():
    value = 500616
    text = __import__('base64').b64decode('clRjaG1oeEM1eEJwNXFKSndxZzU=').decode('utf-8')
    total = value + len(text)
    return total

def _аΑΤΣЫΞΣΤΡпγСПТΛи():
    value = 851017
    text = __import__('base64').b64decode('RkFROUhsMUlKZ1RRenZjRFQ2YVM=').decode('utf-8')
    total = value + len(text)
    return total

def _гκтνЪψΦЛωνХΨΘΓцζ():
    value = 433884
    text = __import__('base64').b64decode('bmZwbUt2R1U0bjhaWE02SEwzMHo=').decode('utf-8')
    if 83 * 53 < 0:
        _dead_1465 = 97
        _dead_9603 = 5
        _dead_4216 = 196
    total = value + len(text)
    return total

def _οΟΗАЪχΜТэκ():
    if len('') > 0:
        236
        176
    value = 286863
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji3zW1AVq4otIzyoxWeaMSo4wnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        770
        _dead_4982 = 688
    total = value + len(text)
    return total

def _ЭШαиςПπηοΒЧΖшΔМЗ():
    value = 353996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hzv0ZwFv7b0CDAGL0WeIJyABsFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        425
    total = value + len(text)
    if False and True:
        194
        _dead_3815 = 413
        pass
    return total

def _ηЙПбΤЫсЕρо():
    if 76 * 60 < 0:
        _dead_5397 = 107
        187
    value = 745353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBzbZ3AM5qAFFAqinH6UZRU2t34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬУνЭζΥЛЪσ():
    value = 245293
    text = __import__('base64').b64decode('dmdpN05qZ08ySGFoNFkxeFVaTVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΠΤΖτΡδΜчΥЫσΡРδ():
    value = 557383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCzBfFgc85guK1aO206vLnB89mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        534
        673
    total = value + len(text)
    return total

def _ЯωеяςΥζπ():
    value = 737534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBb9RVIO7vg3MRWI6lSgCww17GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ββЬхεЗΓЮаΚΟеΣВлΓ():
    value = 22099
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDnoPQM/6YkMaSON2GSmMi8D8Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σζιΞьиюПфζ():
    value = 732245
    text = __import__('base64').b64decode('cXFWSlFydTY1QTJBTXBfYnRXdU0=').decode('utf-8')
    if False and True:
        _dead_2648 = 600
        753
    total = value + len(text)
    return total

def _эаΨσьΕνВΖ():
    if 91 * 7 < 0:
        201
        pass
    value = 138781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESvtQ2cM74APGCiZ/2mFPzA83mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        971
    return total

def _ΡЙДΚДДДιЭЯωю():
    value = 606639
    if len('') > 0:
        _dead_7633 = 646
        pass
        _dead_9212 = 523
    text = __import__('base64').b64decode('S19nenlfS1RJSU8wOGx4OWg5d3U=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5554 = 873
        pass
    return total

def _ЬНшγЭЙΘоμνμωγπРТ():
    value = 506538
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRbnQ0gj6JgUaj259w+xIQYEskM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜьχπыεΕαΤΘΞФс():
    value = 113270
    text = __import__('base64').b64decode('eUVxUm1jY01PWW9EWWk3WDdyeG4=').decode('utf-8')
    if 75 * 34 < 0:
        _dead_8494 = 176
    total = value + len(text)
    return total

def _УΞЭЙΚοΤйБРΨπ():
    value = 979506
    text = __import__('base64').b64decode('Z2VpMWg5VzFXNW95NUJTNXN1WG0=').decode('utf-8')
    total = value + len(text)
    return total

def _θΣСОβξыκ():
    value = 67400
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxXATwU635AiFAus7EC8IzR623c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝηъмΛЪИзЧ():
    value = 472640
    text = __import__('base64').b64decode('Q1VFU003SEZweDBRYjVoejVUN1M=').decode('utf-8')
    if 71 * 4 < 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_9516 = 659
        pass
    return total

def _ЛчЕтΙτВЭщνЧκшηыМ():
    value = 166645
    text = __import__('base64').b64decode('c01aYTNuYmd4VlVmd0I0V2lSang=').decode('utf-8')
    total = value + len(text)
    if False and True:
        412
    return total

def _хибχβЕαγΔцΒщκς():
    value = 357877
    text = __import__('base64').b64decode('ZFphR2liaW1mWlZldlZsMW1Fc0U=').decode('utf-8')
    total = value + len(text)
    return total

def _фПСοРДаΧΝДυ():
    value = 107652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ey7NY3pt6Yo1PFiNy2eAZhYj/Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΞчХШКэφΧν():
    value = 829797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyS9ZHBp/b8vIzWr5w+jZxwWx1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 22 < 0:
        760
    total = value + len(text)
    if 99 * 44 < 0:
        _dead_2472 = 943
        _dead_1623 = 931
    return total

def _зυярοΖпψ():
    value = 470313
    if 69 * 12 < 0:
        _dead_9921 = 450
        _dead_8864 = 677
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXjVZ0AQ/5wWFweS3WDJJSh7sjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΠщΞФЬВρ():
    value = 99202
    text = __import__('base64').b64decode('RGFmNEZrV1h4Q0d1cldrWDFnSXk=').decode('utf-8')
    total = value + len(text)
    return total

def _υωЪЧАОтαПмх():
    if len('') > 0:
        49
        pass
    value = 743917
    if 79 * 15 < 0:
        372
    text = __import__('base64').b64decode('bnBvemp2S2xMaGladlRlZU1SSGs=').decode('utf-8')
    total = value + len(text)
    return total

def _РΡымξОТмΚ():
    value = 573691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXjFRF9s1Po7NV6S2VGFZHYfw1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1370 = 63
        9
        _dead_8243 = 207
    return total

def _κщηгζднКΔгΜΔТ():
    value = 169392
    text = __import__('base64').b64decode('WWc3R2lvcGlmWTN4S2JobndRR2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ρжИъедχΘУХψЛβ():
    value = 225795
    text = __import__('base64').b64decode('RWNERzhBZ0ZfQzNGZFN2NjdzZFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟцыОυкБГΖя():
    value = 460665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H33LXWEzzpwVNCOQ31q5Agp94Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡАΦΞΙΣΒΒιгДЖδη():
    value = 960113
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyLsbENg26xWHhus7lCRIgor22I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΗЦΠΙΒцК():
    value = 59182
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg7MalMj76ErGSyr6gSibQI8wDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_1097 = 797
        47
    total = value + len(text)
    if False and True:
        pass
        597
    return total

def _цУΡςΙЬвΤΔγ():
    value = 749777
    text = __import__('base64').b64decode('bmtTdHJwVHNqWkNrYl9QdEFHX2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙηψΕυγзψТ():
    value = 200804
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQDFe3wU9f06LwWK0VSBDQMkyHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        676
    return total

def _зΩеЖοςхζШьРΟЩю():
    value = 798750
    text = __import__('base64').b64decode('YmM5XzJVOEtVODN4UHdsZVJhbmw=').decode('utf-8')
    total = value + len(text)
    return total

def _юФλΝЗΠгπΥΕФΧГη():
    value = 564270
    if 7 * 96 < 0:
        625
    text = __import__('base64').b64decode('dk05ZVlKeVpmeTZfRTU3OVppczM=').decode('utf-8')
    total = value + len(text)
    if 16 * 67 < 0:
        122
        _dead_5623 = 942
    return total

def _ЕуФκκΞηπΒКΝςЕФ():
    value = 471530
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQ7JeXgOqq4FKwGn7FeDZ3Iqt30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 28 < 0:
        _dead_9637 = 972
        pass
        _dead_5941 = 856
    total = value + len(text)
    return total

def _πηΣмΑσΔρЫЗЕйД():
    if len('') > 0:
        pass
        469
        _dead_6629 = 389
    value = 610571
    text = __import__('base64').b64decode('S1lHRzI4aHlzQnQxaXpNeWlBdkw=').decode('utf-8')
    total = value + len(text)
    return total

def _πнΠιХЧδЛ():
    value = 196014
    if False and True:
        _dead_6716 = 302
        984
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChXNTFMI3YMoGAqV3WnHFwgp80c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δтЛгΘΖΞЪиК():
    value = 548497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dw7GQFkGr58sHi6z2nWHAC4B92Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 63 < 0:
        375
        772
        _dead_8072 = 886
    total = value + len(text)
    return total

def _ΗΩтпδεзЪц():
    value = 23467
    text = __import__('base64').b64decode('c2ZDNkVPOFR3ZW56YlNORE5XNVU=').decode('utf-8')
    total = value + len(text)
    return total

def _цнЗдΝΝХш():
    value = 192014
    if False and True:
        14
        122
        _dead_7066 = 215
    text = __import__('base64').b64decode('dFdySmJZYzA0dm5vMnFDcnZpYks=').decode('utf-8')
    if False and True:
        153
        pass
    total = value + len(text)
    return total

def _ВзΤМчτδжΓο():
    value = 164557
    text = __import__('base64').b64decode('WWhZclQ1YThDdjdFaE8xQ0gyQk0=').decode('utf-8')
    if len('') > 0:
        pass
        769
    total = value + len(text)
    if len('') > 0:
        _dead_4869 = 377
    return total

def _мкιλΓγДζС():
    value = 967981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjXMQV8Y0P8uESOm3nWfLX083Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxxxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 46 * 5 < 0:
    _dead_7492 = 611
    _dead_1227 = 466