#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _мχκΑΩЗЬь():
    value = 357663
    text = __import__('base64').b64decode('SzhNNFZHb0d5cDRXaVdiVG9SN0o=').decode('utf-8')
    total = value + len(text)
    return total

def _дΑсНΜпГΣп():
    if 14 * 26 < 0:
        _dead_3991 = 478
        190
    value = 754062
    text = __import__('base64').b64decode('SGRqSTNPOWJMR183YjVkMWp5d2Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3777 = 597
    return total

def _ριηΤΗЮοΓ():
    value = 142514
    text = __import__('base64').b64decode('dXFrRjY0MXVQSzJTcHhpWUFhX2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦОХΙБъΥΛаьЮЕМщΟ():
    value = 973157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyzQeFg93YMbFRWhw32vOzY6sWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 35 * 37 < 0:
        pass
        pass
        _dead_6810 = 716
    return total

def _υъКΛΥТУγΞжΩρг():
    if 79 * 44 < 0:
        _dead_5566 = 667
        pass
        436
    value = 902426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHvhP2Bsp4cNYxalzVCnPAEo/Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 64 * 24 < 0:
        _dead_6792 = 113
    return total

def _ЖЮЭιαГΘТнΔЗЪΖп():
    value = 482548
    text = __import__('base64').b64decode('eGJmSE9UT1Y0S0QwOVgzYlUxYVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪυЫфΤцэΒη():
    value = 840580
    if 22 * 60 < 0:
        pass
    text = __import__('base64').b64decode('Ym11RkVDU3FrU3ppb3g3T2dzUnc=').decode('utf-8')
    total = value + len(text)
    if 87 * 58 < 0:
        935
    return total

def _ΒбΨσΝИобδЮ():
    value = 705853
    if len('') > 0:
        _dead_3177 = 897
        570
        _dead_8005 = 444
    text = __import__('base64').b64decode('Rk9HMDFWdnpUdEJwR1M1VW9YMHo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        546
        _dead_4579 = 251
    return total

def _ЯКγоХΓхэмβςιφσФπ():
    value = 996898
    if 88 * 54 < 0:
        854
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mjz8aAdo2/gzMi2Am0KqMwwY6j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 19 < 0:
        _dead_8732 = 301
        540
        743
    return total

def _ΨЬΓΝжтηΦеуГγΒ():
    value = 32644
    text = __import__('base64').b64decode('eV9Na3I0bmJRckp2V3VXRFRVOWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΡбДСхЗΩЬΔΣЫΩзΒ():
    value = 173247
    if 59 * 65 < 0:
        pass
    text = __import__('base64').b64decode('ZnZKUnF2Q1h5dnBEdjEzemZ6UUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙДБуГмСвνЬиθι():
    value = 951151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HS3hXXIuyosgGD+UkVCTGXQDyDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΞζΕЗУΖυгДΜΘ():
    value = 970008
    text = __import__('base64').b64decode('WVhUMEczN0pHTURWM1ZQa3huWUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ьψΩЧяςшαДдЗΞЩ():
    value = 550034
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChjdWlwO2PEGYx2JmESRHicd91E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йлΜртΟЮвц():
    value = 15511
    text = __import__('base64').b64decode('aG1DSWFiQ3Y2U0hMMHNPczhmNTE=').decode('utf-8')
    total = value + len(text)
    if 24 * 81 < 0:
        pass
    return total

def _ΞΦЧпМδΣΙиςм():
    value = 860109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAfNQUBo15kKLyCykFCmByoY71w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οηλЧΨθВΠв():
    if 58 * 10 < 0:
        pass
        51
    value = 135953
    text = __import__('base64').b64decode('aWY3Tm5ZdWEyWDBGYzVkd0IxTkw=').decode('utf-8')
    if False and True:
        pass
        464
        pass
    total = value + len(text)
    return total

def _ΚΗΒЮПпжζЧχиосξ():
    if 72 * 60 < 0:
        pass
        15
        _dead_9540 = 833
    value = 454244
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCvqXmUd670zEh2wyQCXNT0+yFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σеηЮκπηшΚь():
    if 10 * 64 < 0:
        _dead_3629 = 349
        _dead_9638 = 616
    value = 507942
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag7BY0IT8oE6Mi6Xy1mIPyw83Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чРзΛφκεΔмοΝτЯ():
    value = 381900
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCr1UW4B8KcKA1aL3AOjP30kxn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПμшΖцνЮзфС():
    value = 816921
    if False and True:
        _dead_6023 = 777
        287
    text = __import__('base64').b64decode('cUsyc01WQjBfRDdtXzVCTXdjakQ=').decode('utf-8')
    if 54 * 86 < 0:
        _dead_3088 = 74
        _dead_6345 = 837
    total = value + len(text)
    return total

def _χΙыХπгЛΕгΝЭОЦΩζ():
    value = 991752
    text = __import__('base64').b64decode('Ql9tR2k1NXVmOU8yOTNBVkxsTTc=').decode('utf-8')
    total = value + len(text)
    return total

def _чВκЙвеφЫюΘ():
    value = 758752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQvbRlcA04IraCO5y0epPQcB0n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хδщтεДρΜακΒπЛб():
    value = 62177
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXmwNgI006skCASM936nMnw31Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бψΩъςΡЧδМ():
    value = 425295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Enu8enZupvA3PTCB2g+cEXIZz3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒдΛЪΣбуΩвε():
    value = 864433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAqxN0cPqLsbayD3mXi0LjQg1G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φНεаПΧδПНΚЯах():
    value = 917508
    text = __import__('base64').b64decode('ZXBHN0RtVld4OEpINmQ4cUZCV0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΩМХΚмЭБξΨεУы():
    value = 713755
    text = __import__('base64').b64decode('bkM5WUZseDZtTm9xQ2JUTzNNal8=').decode('utf-8')
    total = value + len(text)
    return total

def _мАΖлλΗζΦΙυЯНυлШы():
    value = 825267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRvVaFUW16MNa1qX2maKEwM14nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γεΒωмяПБнЬд():
    value = 137597
    text = __import__('base64').b64decode('TnVscE45OVpnb1E3eW54SHF3eE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ХκΩΟμуΓυΥСйΩтЩЩ():
    value = 624596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChzsRnkd7JEIPVf7mV3BLHN+6kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        96
    return total

def _σдхцШЛдоВΧъЭШшΧ():
    value = 194624
    if False and True:
        _dead_9581 = 734
        _dead_2362 = 156
        275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjfmaWsDp7kwKl6W8Q+ALnMN9Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 80 * 75 < 0:
        pass
    return total

def _тТЙΝСдδхаьυЪя():
    value = 117581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQngeVsMrJAiCT+J3G/GHDIgtDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΛΧаФЯФχм():
    value = 93969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxrJRGMS1rEwPg7w4gW7Ii84yEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИθΖΙтσΨсзХеьвΥσφ():
    value = 435652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBDoa0MBqY8qGCqv4waJPwQO/Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΣΕуъЦαзΤχювΞ():
    value = 184277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTrCRXce2aQhNB2O+gWYBQ4K5kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦжοжπуЧσλΑ():
    value = 147157
    if 69 * 59 < 0:
        pass
        pass
        374
    text = __import__('base64').b64decode('VENCTWJsSHp4QzNzWm9rS0Q4MjU=').decode('utf-8')
    total = value + len(text)
    return total

def _яйРΨХкΞоГЗТе():
    if 11 * 74 < 0:
        pass
    value = 988931
    if False and True:
        pass
        pass
        217
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCzUUWg0rZkVNxin6QaHJXIEyVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ДбРыымΧФυу():
    value = 606637
    if False and True:
        _dead_2512 = 752
        21
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj7KWXU2zqsRaj6gwUSUDXYc71E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηХρтЙзιЩ():
    if False and True:
        52
        _dead_5812 = 797
        _dead_1756 = 705
    value = 27428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxfyWEQJ9JtTOwuk5USzOD0n4EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _АΙρχΚйΖОξ():
    value = 986481
    text = __import__('base64').b64decode('ZU1vQmlHcTM5NU1EcEpKZ1hQdmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ььшьнЛΡФκ():
    value = 500896
    if len('') > 0:
        pass
        _dead_7923 = 763
        _dead_5333 = 96
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxWxbWtp+rEpHTWCw0DCOQwOsEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦнΒΨряλτδЙνАςΤ():
    value = 994235
    text = __import__('base64').b64decode('cmNUdk9CdmN5SE1CeGkxWGw1SEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ξъτςιΤΒкюΩЩЦηч():
    if len('') > 0:
        _dead_8944 = 140
        943
        _dead_1394 = 58
    value = 940969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCzMTQUu8ooSPhf033SoPyB3wkk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        579
        314
    total = value + len(text)
    return total

def _ΝаΜΙНхЦэиΥцефНЭ():
    value = 714494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izv+dksSxpcSaler7VCqJSkW4no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        683
    return total

def _ΩКзΨшфγΨο():
    value = 992773
    text = __import__('base64').b64decode('dkttVm8zUkNJSWFDMkRIX1h3cWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥТΙэκςΔкЪоθзртΑ():
    value = 320888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgXSWEE0yrpVaViO6WeYMQc5814='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8850 = 637
        _dead_6705 = 60
        _dead_2182 = 909
    return total

def _ЫмКфχЕςЪэΜ():
    value = 340957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSrdOF5v87EQGFby2gTHMAIg6HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζщЭΙΞωЕфЦЛЭМЪйΠ():
    value = 539361
    if len('') > 0:
        _dead_2654 = 448
    text = __import__('base64').b64decode('RHIzUzB6OERweWNPYmtvR25IZVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝаωЗРΩΥхЦпΨЛ():
    value = 400835
    text = __import__('base64').b64decode('ZGpuYnFiTEJSc0NUMktFRlB3QXM=').decode('utf-8')
    total = value + len(text)
    return total

def _бгΔХйвЛγАωэοεΞЭ():
    value = 802941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz3RWAFsr/EPYgyHxA+bNzEf4UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 43 * 49 < 0:
        pass
        971
        pass
    return total

def _ΒοΥзμωμяιασΘνнε():
    value = 970249
    text = __import__('base64').b64decode('U1VCemRnT2pBMFRsN21ad1lkV1o=').decode('utf-8')
    total = value + len(text)
    return total

def _υХΕΣΚρΠчЙан():
    value = 500991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQL1PG4+1IM2Pli12WOdHSw4vX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МсΘФЩннλю():
    value = 640016
    text = __import__('base64').b64decode('eFI3Z3pMUGFGdWxzZXdlUHBDNU8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        646
    return total

def _ЮγФБКТвςЫΨζТξηΛ():
    value = 542333
    text = __import__('base64').b64decode('Yk1nb0Y4MUVKS3pxNmo0RmlWdm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ШяοЫюкрЬ():
    value = 292214
    text = __import__('base64').b64decode('QWk1RFc1bllVVjFQR29DRER1ZVA=').decode('utf-8')
    if False and True:
        706
        pass
    total = value + len(text)
    return total

def _λιГΩЬΑΔΜБЩЙΕр():
    if False and True:
        pass
        _dead_8002 = 193
        pass
    value = 415971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHiybVg604YlHxaOmAaXAAEE7GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чааотΙΙрΚкΘΞШ():
    value = 297816
    text = __import__('base64').b64decode('WldYRVZtMlZNdGhRMDZLNWpGV0E=').decode('utf-8')
    if 20 * 99 < 0:
        _dead_5855 = 598
        422
    total = value + len(text)
    return total

def _лΨκЛАеЭσκЪΠ():
    value = 990156
    text = __import__('base64').b64decode('dm1veWNyQ2E4SU9URGNzN3BWNWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ДъΦςΥЭνпΖΘηΔчΑчθ():
    value = 745349
    text = __import__('base64').b64decode('eVk4aFVKbXlzeEJxWGRTQzJJczM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗφАЖθΓΘΚсХΞθЪΧ():
    value = 831616
    if False and True:
        _dead_7555 = 723
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCP9Omg0yJIUKgG3zE6aIAop3l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 68 * 63 < 0:
        550
    return total

def _ωбГПъΒЩΛУνρ():
    value = 316345
    text = __import__('base64').b64decode('ZndvQ1lfanZEWnZSQ3lSdUlITjg=').decode('utf-8')
    if 36 * 91 < 0:
        _dead_9012 = 391
        _dead_4828 = 437
    total = value + len(text)
    if len('') > 0:
        _dead_4778 = 543
    return total

def _γцχЗШαςКЧХ():
    value = 719437
    text = __import__('base64').b64decode('bFBwVG91djl0UXBIaXJKN01kV3A=').decode('utf-8')
    total = value + len(text)
    return total

def _хοЛναЗΜαЗпΚыь():
    value = 87310
    if False and True:
        pass
        _dead_7250 = 76
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KADjeGlh64oVDiL12FrIYgQCs2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪЦьэеΥмТОиΚчιМ():
    value = 871199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB3nQQAJq5wsADe30mmXBXU54EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лςиΑнЧΟгНВΥЩкβΚ():
    value = 946488
    text = __import__('base64').b64decode('SDk2UDRxOGJCQzd5aVBxTzJDUkE=').decode('utf-8')
    if 19 * 45 < 0:
        921
        _dead_2980 = 144
    total = value + len(text)
    return total

def _ιΗλАБελΧЕθΗ():
    value = 857521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3fhOXQ66bwpKgiC63SmDn0dzXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _оПΨμΥξοΒΨακΣ():
    if False and True:
        936
        pass
        pass
    value = 630131
    text = __import__('base64').b64decode('Q3VmQ3JHZk1kUVVaWVZyVkt6SXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬМζщαеΙЖΙВΩ():
    if False and True:
        845
        _dead_2876 = 527
        246
    value = 382208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxXxbEU27okuFF3zw2/BLQMpvFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θπЯъεΡЬЛΓЪ():
    value = 23122
    if 11 * 10 < 0:
        904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRvAW0I8+okoHV/xz3ymIRwhvGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1959 = 91
        383
        pass
    total = value + len(text)
    if 18 * 28 < 0:
        pass
        970
        670
    return total

def _λюνЕыИλαΑγυш():
    value = 986910
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyrsP0Rr6KsyNV25+UDEZwQL7G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9156 = 624
        915
    total = value + len(text)
    return total

def _зγЮрαΖЧλδСбГмΣ():
    value = 17070
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRjNYFkQ/LoKLAWbzgekMhUJsko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙщθαςсΘλгнφф():
    if False and True:
        pass
        786
    value = 472625
    if 34 * 9 < 0:
        _dead_9386 = 777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSfUVmsfqacBaB/37lGVbXQE1W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АπΔпРιПΨ():
    value = 78437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH3tQUYR6KQvFh20nUajJywmzXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιмЬЯΦΙНЖνшΘοΥ():
    if len('') > 0:
        731
        217
        _dead_5678 = 247
    value = 561799
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHzqfEsX0Y0VCiKa31W3PQ0h3k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 15 * 38 < 0:
        pass
        328
        _dead_7363 = 492
    return total

def _оΨгЛщЖΡψРЛФЕы():
    value = 407125
    text = __import__('base64').b64decode('ajhRbG00T3dtcmMxblFDRUZKdmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩμλΖλνΠεшуπΦд():
    value = 520325
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3bSTEg9+64gOyCUmwGUYg8H3lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΩЛШбΜβΔ():
    value = 954078
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyfzSVAswYcAHwuywXu1ORca5Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΟΞЭΡσчузιΧавхα():
    value = 161167
    if 44 * 62 < 0:
        499
        919
        _dead_3362 = 485
    text = __import__('base64').b64decode('RnFvQTV6Z2tvZDFtTGN4YUtPOEs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9213 = 293
        pass
        554
    return total

def _юβЬэΣйВΛλδτынлΘΨ():
    value = 829751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax/FaXQj+KUiM1i1zw63YwoBsDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8289 = 689
    return total

def _αοвυγдЫΔДы():
    if False and True:
        pass
        _dead_4262 = 180
    value = 767856
    if len('') > 0:
        120
    text = __import__('base64').b64decode('U2MyQXhzRENfYnViZmg0N1NtZEU=').decode('utf-8')
    total = value + len(text)
    return total

def _мРΕшшΙНΨФυжи():
    value = 882411
    text = __import__('base64').b64decode('b21pRWxaQTFrbENXa0lIVE9Obkc=').decode('utf-8')
    total = value + len(text)
    return total

def _льСЖУςιρцΠ():
    if len('') > 0:
        pass
    value = 620985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgvnSH8OrYICOQXy8AbDNhwb3Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮПπΨΠτЛОРγнчΦглυ():
    value = 846378
    text = __import__('base64').b64decode('TUVlbUlTYmp3VDVucGRhMENMRjM=').decode('utf-8')
    total = value + len(text)
    return total

def _иρτΩвЧРгιгυΟнЪюΡ():
    value = 557662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETy0YlNv//lUOwun42mpESM7tF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        718
    return total

def _БΙБЛπηъΡΝсЦБ():
    value = 658810
    text = __import__('base64').b64decode('a3M3Ykd3NUtIZGI4X2g5UkRzT3I=').decode('utf-8')
    total = value + len(text)
    return total

def _АфвшГЩΞюγжШцω():
    value = 984855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HArMQVRo8Y0CaVaAnWecEwR95lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΙШνΙЖψЖψШчПбфτ():
    value = 153116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBjiX2Q81YsrEFfx4VGhMxF3y10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        16
        _dead_1373 = 423
    total = value + len(text)
    if len('') > 0:
        554
        pass
        _dead_1296 = 953
    return total

def _ΣъαΩθΟλоЖдЙγцΕЧ():
    value = 605448
    if len('') > 0:
        _dead_3087 = 801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxfdUUIAr/haDSeH+UWDYnQVyGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТдвочτЫхςΡяОгΕ():
    value = 205637
    text = __import__('base64').b64decode('dzUzSGY1N1k0RXlCeU5FSjJqalo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        605
    return total

def _ЛЯβχεГλΧ():
    value = 967763
    if False and True:
        16
        222
    text = __import__('base64').b64decode('SHlmbFI0dW1qZjF4dERPWDBTMTI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ТιχЫВпЛяμΡбЮΓбΖκ():
    value = 808490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyTbalQd15wtO17y+EzHZiw+3Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 50 < 0:
        _dead_5391 = 310
    total = value + len(text)
    if False and True:
        _dead_1216 = 221
    return total

def _ΧзйЖγЛμпτРУЪб():
    value = 103040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBu0bAkx+ZcLAhn0wn2vbQYk71g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВяΙНαйρΦФЪ():
    value = 174741
    if 57 * 14 < 0:
        _dead_1473 = 420
        720
        488
    text = __import__('base64').b64decode('Wm9PNjJpRmNkZWpLTHFKSmlnVDQ=').decode('utf-8')
    if len('') > 0:
        428
    total = value + len(text)
    return total

def _УШаСΚкШηχγΙ():
    value = 655403
    text = __import__('base64').b64decode('RFJOd3VnN3NIbmkxbXQ1Q3RKOVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ущΩαПΥдБ():
    value = 823888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhXiNgMtp/81KxrxwQeHNX03sEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МψΑшбΝΝЩΩΡхς():
    if False and True:
        380
    value = 22588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQXeQUEG9v0FKg23+WCeMyMm70E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8540 = 728
        pass
        _dead_5000 = 897
    total = value + len(text)
    return total

def _йυζДЗΥИΣыОХ():
    value = 795246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDbtbHA1q5BSaQCwnn+2PhA66mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7925 = 372
        445
    return total

def _νΔуфΖδζΦΘПπЮ():
    value = 381806
    if False and True:
        701
    text = __import__('base64').b64decode('aXdTVkZBQlpiSDZqTkFsMWF2VFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЙЙхπΛωмσЖ():
    value = 613410
    text = __import__('base64').b64decode('aG5kMmJfT0xncklnSzNGVGZFUU4=').decode('utf-8')
    if False and True:
        _dead_7949 = 683
        pass
    total = value + len(text)
    if 69 * 10 < 0:
        pass
        878
    return total

def _ШΠиШΧψэεΤαхЖЖ():
    value = 804841
    text = __import__('base64').b64decode('TXdrZ2p6czdDYTVLWktvNUl4U0M=').decode('utf-8')
    total = value + len(text)
    return total

def _жνшΚыσФЙЧбξΧΑАΖ():
    value = 220958
    text = __import__('base64').b64decode('amdRYWx5bjQzNGNtakdpT2U0dlg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3838 = 196
    return total

def _ψμснψΖςлЗуЫ():
    value = 580962
    if False and True:
        _dead_4788 = 893
    text = __import__('base64').b64decode('cFlualBqN2xsSkpTc2hOUUJMX28=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠШцΠчΝΕςαчР():
    if 76 * 41 < 0:
        _dead_8572 = 804
    value = 62591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CD/nZkIh7J8oaja27HyiAj0I1WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΕΠωвΚκюЭДΧσκΔ():
    value = 698662
    text = __import__('base64').b64decode('bDFUc3RPSjh5MFE2VTRnRVBPR28=').decode('utf-8')
    if False and True:
        pass
        _dead_2936 = 310
    total = value + len(text)
    return total

def _шηΠηьХΧЛλЩмΜМΦс():
    if False and True:
        pass
        pass
    value = 530867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EADRTwcS97E3Lx7173uWAH0ovX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χэУПΘΞгΖПЗЕЫ():
    value = 695168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTrLd1oS8rkQICG1zEaRLBcgyWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДАБбЙЙΜДПΓАоЖр():
    if 58 * 45 < 0:
        _dead_2427 = 879
        _dead_4183 = 224
        _dead_7270 = 534
    value = 711699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxjlZEgQyJBTYjiynm6yB3d9418='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΚОЛйλчпфЯЙк():
    value = 191409
    if False and True:
        243
        946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSnWS3sBqqoCKziO/FmYESsl0VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 19 * 96 < 0:
        pass
        _dead_8853 = 893
        788
    return total

def _оΠΘεμωЫρ():
    value = 519507
    text = __import__('base64').b64decode('ZzI0Mng2bXN5TEdsR0MzQVdUN2g=').decode('utf-8')
    total = value + len(text)
    return total

def _зτсΗагцΝΤΨγГкР():
    if False and True:
        _dead_1237 = 95
        pass
        438
    value = 651692
    text = __import__('base64').b64decode('WUwybktqUUx1NjJ4Y0F4VFRDR3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞИжбΓΑνШчηЬГжυ():
    value = 258060
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fy7MPEIX95AVbTiK0USFIiwe0G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЖОΗдΕτΩЬτхФ():
    value = 952138
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3fOR3w466Q2DDuVzFqVPTUV12Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭьЧвΞαδПЪЭ():
    value = 753626
    if False and True:
        _dead_7643 = 414
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj/3YnZs+v1WIBj23ESCbDN+yHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        236
        _dead_9645 = 221
    return total

def _θοмΝПΤΠц():
    value = 414926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnfmdHYD0KoSAwvxmEGnLg89sXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уеЕЮΝΩξрμАяΡ():
    value = 611926
    text = __import__('base64').b64decode('eEgwZWtRMTVSNFpDWGN5dTEwa28=').decode('utf-8')
    total = value + len(text)
    return total

def _τπЭςαцтπΔτоΚН():
    value = 323559
    if 66 * 7 < 0:
        pass
        pass
        _dead_2579 = 843
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSXCfF4LyqVQAgGwmAKmESx27z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1300 = 400
        812
    return total

def _ЩЯρщδЩДГчτчΘ():
    value = 79013
    if 99 * 77 < 0:
        _dead_3495 = 406
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhaxWGtrqYELCiSoxWaFG3B521g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5950 = 521
        pass
    return total

def _зπцбΓьζΥЪ():
    value = 89469
    text = __import__('base64').b64decode('R0RNYklmN3JrV3cwRUFTTUhjVDg=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_5158 = 785
        pass
    total = value + len(text)
    return total

def _лССЙγΩΖеиπΓ():
    value = 462338
    if False and True:
        _dead_4266 = 156
        448
        _dead_9038 = 988
    text = __import__('base64').b64decode('WXE1T3lJUTkxNDhkM3VTeFBpOE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ОπэУξωЦΤГЗΥН():
    value = 329775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARnSSXccxKUnKC6qyX+oPzwcvF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уГЫрйΤЗξИΓЯщрσΧ():
    value = 479321
    text = __import__('base64').b64decode('WWgyVjRLbHZEcVBSbEoxcFQ5Vzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЫНцλЛЗδЮхиВФ():
    value = 4980
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAOyX2QNqb5aaDjy2US2PgF76Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χοαζΚРρΖ():
    if False and True:
        pass
        pass
        133
    value = 424623
    text = __import__('base64').b64decode('TWV2c1poRThuVmxMdVNJdDJDaWg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3722 = 184
        881
        _dead_1032 = 456
    return total

def _аЧаξυНΦΙΜЦА():
    value = 156130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgfsdgEj6v8UBSO06lWvMSIc20Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГБЬЧΣуЦЮМыЙъиЪСμ():
    value = 291656
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LD7UV3406JwrbAuk30W3PD0Q/E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        357
    total = value + len(text)
    return total

def _ΕΤАмшΓΓЮΙЩЭЙРТТ():
    value = 455832
    text = __import__('base64').b64decode('UlFGTnVWZnoxb0tsT2doaDJ6cXY=').decode('utf-8')
    if 40 * 31 < 0:
        547
        pass
    total = value + len(text)
    if False and True:
        _dead_1468 = 785
        _dead_5158 = 359
        489
    return total

def _ηшψΔъДЕнωДηЦμЧκι():
    value = 166986
    text = __import__('base64').b64decode('dENNTFpTemJVYXVNU19wOERRRjc=').decode('utf-8')
    if 66 * 70 < 0:
        _dead_2573 = 586
        877
        847
    total = value + len(text)
    return total

def _οΟπХζхЕΜиξφ():
    value = 387413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnbIaUZv8/4oACybmVqBAnE13mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕτоΘоЮРΞγнЩ():
    if False and True:
        226
        pass
    value = 243076
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhvJNwAg0bsMazCm/H6YBBY+7Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        58
    total = value + len(text)
    return total

def _ЬЗφΕΦеЮЫΧΓΦы():
    value = 166247
    if False and True:
        _dead_5027 = 771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhCyQmkwr4MaPCGI/lClYD870G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪОΣВΗπМЙпд():
    value = 580339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBb9Q0g25oVTKjyE0gWcPhAaxUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οВψτэΨЫΖζуδυИφ():
    value = 626774
    if 69 * 14 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQXubXRt27wSGwSlnQ+6PgB64EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ςΙЭοвдяЩ():
    value = 748081
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESqxP3Q6qowwPim07WeHLXAJt10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙтлъΗШΔНαпΦΑГ():
    value = 79282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDbRQWBpwYwAYzC2/Ea6GHJ5tGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4062 = 481
        pass
        pass
    return total

def _ΘЧНКюφιМтΡΒоЙοЗк():
    value = 233405
    text = __import__('base64').b64decode('U1FVSHBvU0pHcDU5ZW51c01VMXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦβтЧГΥσП():
    if False and True:
        pass
        754
        _dead_8037 = 668
    value = 449975
    text = __import__('base64').b64decode('eTJ2bHNkdm9WYVpuc09lNzd6M3E=').decode('utf-8')
    total = value + len(text)
    if 81 * 88 < 0:
        pass
        _dead_1886 = 561
        pass
    return total

def _ιχрΡцЩщЕЩОΛΧ():
    value = 953398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRr9ZkUO1pEiMCKK43LBBC8NvWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 88 * 100 < 0:
        _dead_6528 = 728
        440
    total = value + len(text)
    return total

def _хфНыΣδХΖε():
    value = 722780
    text = __import__('base64').b64decode('bzV2NEd2Y1JHZF9TQ0NJZXpKaGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _втжчхυкъΓЛΟха():
    value = 245420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHrUfwQD0ZwCDwqUw2y3MBYF82s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓψΔοΣЗчя():
    value = 117014
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSjhSUgBy/ssCQv293XDYzE6zDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гИраαγзмфТΚξг():
    value = 883527
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAvTXncYxrkpGVaN0VSDJwM69Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΥюПβпГνъУш():
    value = 975024
    text = __import__('base64').b64decode('T2FBRGJPY0Z2bGVuNHRmTTJhRGk=').decode('utf-8')
    total = value + len(text)
    return total

def _αЩγХνыδμΑКΙНξ():
    value = 589955
    if False and True:
        _dead_1818 = 600
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTvqfVxp8ZhSCli58nioOB96yTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑχΠкыРщеиФх():
    value = 925952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwHBTGFr9Zs0BT2gmU65ZBYa638='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 44 * 48 < 0:
        692
        pass
    return total

def _ИΗΕυтНФШй():
    value = 212136
    text = __import__('base64').b64decode('VDduQ1pFWV9xdU54UWZvT2F4SEk=').decode('utf-8')
    total = value + len(text)
    return total

def _θбΖπухΒн():
    value = 923237
    text = __import__('base64').b64decode('a2NhZGdYMkM0bDkwUDY5Zms4Qmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ецУτΝЧΛРъРиΝ():
    if False and True:
        pass
        _dead_3595 = 902
        668
    value = 377984
    if 92 * 16 < 0:
        568
        pass
    text = __import__('base64').b64decode('V25HYlphTWZodGxneE0zX09SSjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒδдИхпШяΙГА():
    value = 103324
    text = __import__('base64').b64decode('QTkxSklVYldNVWlzZWdDbnFnSUE=').decode('utf-8')
    total = value + len(text)
    return total

def _πоЩЬкФуЧΣυΡμХβκ():
    value = 504429
    text = __import__('base64').b64decode('a0NXb0VCdmpoMG1RbktKZ2g2OVg=').decode('utf-8')
    total = value + len(text)
    return total

def _πΗΙΛйτжрмλмφЭаΣ():
    value = 636998
    text = __import__('base64').b64decode('TTlsSTk1QUlROVJhcU5kTXpwVGk=').decode('utf-8')
    total = value + len(text)
    return total

def _δΟхАΘнΨβκθΒΘΤцΚ():
    value = 409318
    text = __import__('base64').b64decode('WXlmeURmSzZoNzFjQXNIckh0R00=').decode('utf-8')
    total = value + len(text)
    if 25 * 67 < 0:
        _dead_8824 = 888
        392
    return total

def _ойЮцоЖфζтАξЩи():
    value = 396457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBniP31q/4dXIjiu/HSFYBcE72E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 29 * 84 < 0:
        _dead_2114 = 562
        44
        pass
    return total

def _ΩνшДζлЗуэ():
    value = 586251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JymwRVYX85IqNF6I3nqRZRAp7lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШβΠйμньнвπα():
    value = 819908
    text = __import__('base64').b64decode('VjY0eTJtbWU5U0pycF95aHNIU0k=').decode('utf-8')
    total = value + len(text)
    return total

def _γπηТОΒЙηЮЫιахчЦж():
    value = 224965
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AznLWnMTqpwFCF6Q8lyKZgR3wjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙδΦбΛμНεκе():
    value = 174725
    if len('') > 0:
        pass
        224
        pass
    text = __import__('base64').b64decode('WkswWnMxTnRPY1pINUg2a21OSmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ζлШЦУяСΓενЖΘ():
    value = 916073
    text = __import__('base64').b64decode('T3dGWkF3bjZMYjZ2Y2dqc1U3Nkw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9335 = 677
        364
    return total

def _θжКХрбΜτ():
    value = 704120
    text = __import__('base64').b64decode('VkFDNnNJNnpsN25BVXlEZ2s1QjA=').decode('utf-8')
    total = value + len(text)
    return total

def _πыъζμβοреьΣуκα():
    value = 972781
    text = __import__('base64').b64decode('TjRla0RjT1djY3YxdGUyRTYySEo=').decode('utf-8')
    if False and True:
        _dead_8749 = 1
        850
        _dead_5994 = 787
    total = value + len(text)
    return total

def _ΞоΠσьΣоФСωЯШфздτ():
    value = 685416
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQ3BWwgIqKQgKCiUxnieYScms1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щЩδэПΥдαЭШмэЮΙй():
    value = 951000
    if 56 * 24 < 0:
        pass
        pass
    text = __import__('base64').b64decode('dDFUSWdwRkk0OXdCYXduMmtqeTg=').decode('utf-8')
    total = value + len(text)
    if 31 * 44 < 0:
        _dead_3174 = 29
        pass
        _dead_4683 = 296
    return total

def _фΝЧЩεηΤμπбΔ():
    value = 729861
    text = __import__('base64').b64decode('b3FzY3RHbUJrb3Nnb1FRZnVVeks=').decode('utf-8')
    total = value + len(text)
    return total

def _хыМЙΕЩΟτушΞςχο():
    value = 578069
    text = __import__('base64').b64decode('V3JQcGFHb1B6bTVITWF4SXB2dVI=').decode('utf-8')
    total = value + len(text)
    return total

def _гчωШМπΙСξцБ():
    if 100 * 61 < 0:
        _dead_2750 = 192
        507
        pass
    value = 240941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwzFXlQB+pksIl2a2kOzOBUWzXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_5031 = 979
    total = value + len(text)
    if len('') > 0:
        _dead_7939 = 717
        pass
        867
    return total

def _ЬΝхΟΤячΧЭБ():
    value = 142663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSPSSnIz97IFFF2J6wO1EgAI8kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЮдщλτЩС():
    if len('') > 0:
        370
        pass
    value = 370367
    text = __import__('base64').b64decode('dGtxeXplcGVMcWJjekNTb2NDNFU=').decode('utf-8')
    if False and True:
        pass
        26
        495
    total = value + len(text)
    if False and True:
        _dead_7024 = 995
        pass
        27
    return total

def _ЭβМОΝБхΠ():
    value = 19002
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQbmXHUc1aAqIFqC21+9bC853mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        922
    return total

def _юЩΗΠππКАο():
    value = 149689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HATyVGAVzrsMIwCIzl6/YHAfwz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чδзΨжρБНЫδΛΦйΞ():
    if False and True:
        _dead_5160 = 912
        _dead_9942 = 845
    value = 684992
    text = __import__('base64').b64decode('U05McUFMYWRtcFd5eHlFYjVPZTE=').decode('utf-8')
    if len('') > 0:
        179
    total = value + len(text)
    if False and True:
        pass
    return total

def _ιеκУΕндмσ():
    value = 892233
    text = __import__('base64').b64decode('TWpwcTl4bjRGU3dicG9XRWJzMG4=').decode('utf-8')
    total = value + len(text)
    return total

def _зСмЖуХθСуЖЯκд():
    value = 408982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBnzXWEAyo9THSiA43SeLn078l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΗблοΠУМЫрДМЕ():
    value = 340430
    text = __import__('base64').b64decode('bkFJUTJ1a0dQQmZBVHBIOHNTZGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ТФξЭЦетуΛκН():
    if False and True:
        593
        pass
    value = 477517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRn8YlwO5PoIIiCQzUKFLQsE6GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ммΙΘΛшлθΓБΣγыЩΦ():
    value = 692776
    text = __import__('base64').b64decode('S3RTTjFBdkl5bUk4dE0xSUtjbWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪЮкПъθΣуη():
    value = 11273
    text = __import__('base64').b64decode('U0N1UVlmYWZqUzU5NGJCQl80cnk=').decode('utf-8')
    total = value + len(text)
    return total

def _унΣжβεпбλγЭΣЖо():
    if False and True:
        _dead_6392 = 54
        pass
        457
    value = 179530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Knzrd2gc540COyy76wa9N3Ib81g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        51
    total = value + len(text)
    return total

def _чхΔчψожКД():
    value = 490716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ND/zYVVh/68MPS6o8FK1B3IovW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШОКчПχФβсбυЖфцл():
    if 45 * 87 < 0:
        871
        pass
    value = 981717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IifyV1AIrfkTKgeh+mLAEzJ66Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЖзХΚΗΙγΗηγАЦЪОЛ():
    value = 6702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAvtWm4p1/EUK1yE5li5IxMQt1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _σβΗЬδЪΚшΚηЪ():
    value = 285085
    text = __import__('base64').b64decode('ZVZ0eWNhOFk0MUpGTDd4MW9XUWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΕυЗэщэмЧпДБаЬсψ():
    value = 363412
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQGzZFYr579aKQSpzE+yAwsL/GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХпΥΘΓДЙΓΥыЬαδа():
    value = 906119
    text = __import__('base64').b64decode('bnhJaW5LQV84VUJiNm1ZZFFxUzY=').decode('utf-8')
    total = value + len(text)
    if 85 * 48 < 0:
        _dead_2892 = 562
        _dead_9901 = 994
    return total

def _ЧλΤБйЯИО():
    value = 223370
    if len('') > 0:
        pass
        _dead_8908 = 637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRrWdwQT075TaiG7nWOmYykX0Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9342 = 613
    return total

def _КσγШФΑшщΩΩζΤσΑΟ():
    value = 611371
    text = __import__('base64').b64decode('SVJZNHdEZEh2M3lzRng4aXdFMkc=').decode('utf-8')
    if False and True:
        626
    total = value + len(text)
    return total

def _эΗμшλиΨεωεзИβΑщ():
    value = 972136
    if False and True:
        511
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITi1VmExxrAFKR6LmECxFgkG6n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пГАРжаЦζφθфΨ():
    if 98 * 7 < 0:
        _dead_7629 = 191
    value = 531702
    text = __import__('base64').b64decode('dUJ5dzBEVUpFOFg2TW5FS09DSVA=').decode('utf-8')
    if len('') > 0:
        _dead_6327 = 497
        pass
    total = value + len(text)
    if 41 * 76 < 0:
        pass
        _dead_2378 = 749
    return total

def _УКчαХΚΣбжОΣΧЕρЭ():
    value = 58897
    if 17 * 39 < 0:
        pass
        pass
        _dead_8197 = 91
    text = __import__('base64').b64decode('cEg4dVpDbzNES3ZxcGJaclpaQnU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        477
        _dead_5837 = 409
    return total

def _εомДьЧνЮ():
    if 64 * 43 < 0:
        _dead_7511 = 883
    value = 246320
    text = __import__('base64').b64decode('bkc5a2tiek51U1JVQmoxaDdjZ24=').decode('utf-8')
    total = value + len(text)
    return total

def _αξμЫЭΤТюυЧτИцУЗι():
    value = 730514
    text = __import__('base64').b64decode('c3lrOTczclpBZHdYQTIwYUh4SHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΑβοтфщηЧЮ():
    value = 128190
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EySxZWsW5qobFiSy4k7HNz8V7EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЙТПΞΒХУмятЦεΘВЪ():
    value = 828512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CADXfmg9p4Albwb27mnDEgw93X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘγΧЙΝгΜАΡΙсП():
    value = 390775
    text = __import__('base64').b64decode('aGF4ak1iQmtNREtNVXdNYUI2dzg=').decode('utf-8')
    total = value + len(text)
    return total

def _αсΡэτНКэ():
    if len('') > 0:
        pass
        650
    value = 11472
    text = __import__('base64').b64decode('ZlZpUm1mVTgyVU1JdHdqU21JNUI=').decode('utf-8')
    if False and True:
        _dead_8838 = 904
        _dead_8572 = 267
        812
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 31 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()