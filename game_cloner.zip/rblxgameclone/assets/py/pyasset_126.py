#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _пςγαЪКεΑЩΒχыζз():
    value = 73345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DALLWHc/+oUgIiO25UeIPiQB6V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        199
        485
        pass
    return total

def _лЫΚюΘЮчЮЕ():
    if 19 * 8 < 0:
        pass
    value = 797461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCn3YVAr5vsRPAugy0OJMQ5+0Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮαвθбψАб():
    value = 318914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cx7tT2JtwawRICiG8XeBED0ixmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯтξЧΙиΦθκюζψак():
    value = 281881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxXeZmMqrIpSNCH64lW9bHwd3UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΝТШΝΨιΕνиΔΚхΤдΘч():
    value = 412518
    if len('') > 0:
        _dead_7899 = 104
        pass
        926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCzWVEY3/5wxODD06UzDPgk//Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фВΥРΒСμнСъл():
    value = 52096
    text = __import__('base64').b64decode('ZUhFaldwbWliZWFQeDI4dDJhTW8=').decode('utf-8')
    total = value + len(text)
    return total

def _жΘчΞГбаНоΞα():
    value = 78755
    if 75 * 77 < 0:
        959
        158
    text = __import__('base64').b64decode('WkhFQl9WUXhmNU9zb2hoQ09oTTE=').decode('utf-8')
    total = value + len(text)
    return total

def _НЮΖяШТюш():
    value = 680686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDrhdwIo+J8uDRiOzHOXMwIFvFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑщξУΩΛТЮЮΧηχ():
    value = 204969
    text = __import__('base64').b64decode('T3VOOWdaT2wyWVR4X0wxd1pOT2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΜНкефΓγΙаεΣΑНШЛ():
    value = 841093
    text = __import__('base64').b64decode('dnNhMHIyQkIwNGsyWWhtWGhGTFI=').decode('utf-8')
    total = value + len(text)
    return total

def _щΨηθБΟЩеБЖцпиΤ():
    value = 678048
    text = __import__('base64').b64decode('cXhDWW1vYWtJT1dXVWVZU0FtMDY=').decode('utf-8')
    total = value + len(text)
    return total

def _пξжКηοΠхюωРΙΛйД():
    if False and True:
        pass
    value = 164419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3blRgYgrIQZbTWE8WLEJQ0C3l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1689 = 114
        _dead_2334 = 596
        _dead_9002 = 549
    return total

def _рЙРυчΓωмВОЫС():
    value = 703374
    text = __import__('base64').b64decode('el9hampmTGtNX3NlRUtKbjhrb04=').decode('utf-8')
    total = value + len(text)
    return total

def _οΚуΩяηΚьмдсαачθК():
    value = 953090
    text = __import__('base64').b64decode('b3dfdkM1YzlJUEpMRjcyQ21feWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΧтВЪΠМЭοΗНКΦ():
    if False and True:
        667
        757
    value = 943008
    text = __import__('base64').b64decode('UXVNYkdMUEFQZlVvNW92OFQ3Nmw=').decode('utf-8')
    total = value + len(text)
    return total

def _Бλиςωфρэυ():
    value = 349204
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('b0M3T3k2NnVGNlh5ZWRONFFpdXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΥδВГемГτЦзαжЫБ():
    value = 424172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3/IVgUg/fwzMiaN0nKhHR0WyGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        789
        607
        _dead_1142 = 659
    total = value + len(text)
    return total

def _ψРЯχоЗΡЭЗψлдПЙп():
    value = 169933
    text = __import__('base64').b64decode('QkNNaVFzM1Nwa2ZhRVprMnRZalU=').decode('utf-8')
    total = value + len(text)
    return total

def _χΓюχЦχγЧΨШхН():
    value = 839267
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID/mTAUw3IoqKB+hzn2VFSIH5UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΒьΝЖУмтЪΩГХЧжΣΞ():
    if 99 * 91 < 0:
        539
        _dead_4515 = 493
    value = 389270
    text = __import__('base64').b64decode('d3FWcW9aYnE4ZW52dkVJbk1xYng=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5553 = 272
    return total

def _РΓАауИιЗчςдНБω():
    value = 666195
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiCwV1Qgq5BXFA6z90KGJgA41Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞшТΥКпиЫЭшиЕюХΡ():
    if 63 * 21 < 0:
        _dead_8935 = 963
        _dead_4259 = 623
        pass
    value = 859255
    if len('') > 0:
        pass
        _dead_7263 = 850
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDzCbQk+zKQqECy67Fe/YhwD43o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оЙΔхУпηΩНМΗдΩ():
    if 9 * 95 < 0:
        765
        556
    value = 536013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCSzflsV2K4POBemnwebGSAW3nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _дКΟЩРфГμЫ():
    value = 865794
    text = __import__('base64').b64decode('VEk1U1BzS2s3ek9JMVNZdWdid04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛАаπЗβкΜг():
    value = 739990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwPGagED9PgCNx6JwG6qBhMW8Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΤΣЙЭйθШъΩ():
    value = 300858
    if 78 * 24 < 0:
        pass
        803
        pass
    text = __import__('base64').b64decode('dTA0V2NlendMQWxVYlk3aHd5ck8=').decode('utf-8')
    if False and True:
        996
        pass
        728
    total = value + len(text)
    return total

def _ΑχмяΒεйаУΙΩΒ():
    value = 689519
    text = __import__('base64').b64decode('bDAzUzlCTlN1a0ZYX3pfMkdWOGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛυωΘиΕΨΤО():
    value = 451478
    text = __import__('base64').b64decode('UG41TFhZWXFrRkYzZm05bmlibjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙσжφηθΥΖП():
    value = 428141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ly3cSlYDz6AIFFql8E64NgQN01k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯηоДлИСυд():
    if 47 * 2 < 0:
        801
    value = 432669
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwnWV3QS0r4TBSOq7WWFIRJ/vVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςШДЦχУгВιΛГпь():
    value = 663767
    if 54 * 61 < 0:
        _dead_9467 = 78
    text = __import__('base64').b64decode('RXJYd2xnMDRsV1J5dFRJZWcwRHA=').decode('utf-8')
    total = value + len(text)
    return total

def _БГчΔΚьΩρЫθиΛсяХО():
    value = 68155
    text = __import__('base64').b64decode('RE85TjNuZ1ROR2tjOUdzbHFJU2U=').decode('utf-8')
    total = value + len(text)
    return total

def _еяПЕиαΗθН():
    value = 879026
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSb+enAR1qEAIyuH5FK4GSwr7zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФуНТяΣуПςτχοΥς():
    value = 514331
    text = __import__('base64').b64decode('WmpSRjFLVzUwdlprWE1JUVp3OWI=').decode('utf-8')
    total = value + len(text)
    return total

def _йиρυΕмНшΓйЖπγ():
    if False and True:
        725
    value = 299831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fj6xZ3wa24MGMQmCmmSGAwQWz3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        894
        pass
    total = value + len(text)
    if 32 * 59 < 0:
        384
        pass
        _dead_7655 = 54
    return total

def _кчГщлсΧιаЯπΘΡшυΖ():
    if False and True:
        _dead_8598 = 212
    value = 864747
    if 1 * 60 < 0:
        _dead_9087 = 784
        _dead_9525 = 138
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh+1RwYY2Ys5IFmu7mWeHi48sW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΕεЬЯЧιгξβκИ():
    value = 274114
    if 72 * 8 < 0:
        _dead_9947 = 867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3nVVGk98fsEIB2QwHKkJDwrsH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΓΝΗДИцΖФγ():
    value = 858110
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxzsaGAcyKE7OBW75kKSDhoqslY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _вСΦΞΓШμгΗЛΛδ():
    value = 986977
    text = __import__('base64').b64decode('eGpYT283bUJuOWF5cHhxMkRVWEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΚΔΡЛγуЛЮ():
    value = 716947
    if len('') > 0:
        _dead_3432 = 242
        661
        _dead_1755 = 152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnfVegkt95kVCz+H7kPJLBwd5kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧпξΗзτΚвηЧ():
    value = 975501
    text = __import__('base64').b64decode('Z0Q5eXo5VW1ETVJZV3ZlcEF3QVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓрШπΓОуыЧ():
    value = 342845
    if len('') > 0:
        _dead_6442 = 847
    text = __import__('base64').b64decode('WURwTHpkYk5LM3pHa19RU2hDSU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒфΓωЯςъдШΚпψпΝ():
    value = 831831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg20S2Iyxp0uaA2F7lexPAkhsng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юрΨνЩажрвΟлИХдЮ():
    if 97 * 38 < 0:
        pass
    value = 392939
    text = __import__('base64').b64decode('TUhndmZjQUpqQ3pqdEtmX2ZuSnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ШАУμκСГΩικΗΗΕ():
    value = 184556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx72d3873ZIPHB6H8AHGEBw7tFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΣЗςчяΣбшВ():
    value = 114714
    if 31 * 49 < 0:
        pass
    text = __import__('base64').b64decode('T3FUT1YwN1A1YjA1UWpBMnlOMTc=').decode('utf-8')
    if len('') > 0:
        _dead_2364 = 746
        _dead_8681 = 583
    total = value + len(text)
    return total

def _сΔРЦδκшЫ():
    if False and True:
        _dead_9582 = 265
        80
        _dead_1207 = 633
    value = 148407
    if False and True:
        _dead_6419 = 296
        _dead_7198 = 735
    text = __import__('base64').b64decode('QVRKMmZzR2JZZ3pnckhteWE4UlA=').decode('utf-8')
    if 91 * 64 < 0:
        _dead_1335 = 629
    total = value + len(text)
    return total

def _ΠшнΑшзЛсΨХΖ():
    value = 775956
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgPSX0E19rIoHCuzygODMCob0EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭфдΘЕзУΖЗ():
    value = 557491
    text = __import__('base64').b64decode('YUt3R0tTTFFiMHlwNlVWa1F0SnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫνуΚьνчΝθМεюЧвΑ():
    value = 114176
    text = __import__('base64').b64decode('c2t2ZHhfb2ZvVFZVTE9kckpJOXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫДэгАЗΡоκςчλφρцч():
    value = 400742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCTvZXov1pIACAyan3ODPBYtynw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΟЗЫУЧжДτυБорЭ():
    value = 387967
    if False and True:
        _dead_9987 = 171
        pass
    text = __import__('base64').b64decode('S2NUV0hsdG1QYWJUQk52OHZwNlA=').decode('utf-8')
    if len('') > 0:
        _dead_1893 = 482
        991
        939
    total = value + len(text)
    return total

def _ъΝπЛιΖуцеЧ():
    value = 939464
    if 99 * 93 < 0:
        353
    text = __import__('base64').b64decode('bUZYUjFGaEdpR2dnWWJmZUFrTkg=').decode('utf-8')
    if 97 * 95 < 0:
        561
    total = value + len(text)
    return total

def _ЯφЦьΝΞπΔΑбРςАх():
    value = 60377
    text = __import__('base64').b64decode('ejhGN09Od19HWkp5ZWtaUUZvem8=').decode('utf-8')
    total = value + len(text)
    return total

def _хзβΚфОΕРωΚК():
    if False and True:
        34
        pass
    value = 507547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSDWZkQc1qUXLiSL2lqKHQEcslE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξιоджввыОФΟ():
    value = 547646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCm2R1469o8OHAHw+XKHDRMWtmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒАδοГнΚИХ():
    if False and True:
        _dead_9871 = 987
        762
        23
    value = 715792
    if len('') > 0:
        _dead_3216 = 196
        794
        pass
    text = __import__('base64').b64decode('dVhOV3VhbThTNFo5QTBzRTdtek4=').decode('utf-8')
    total = value + len(text)
    if 97 * 7 < 0:
        794
    return total

def _ьπΒΑΓΤбфдΙυ():
    value = 344296
    text = __import__('base64').b64decode('QWM1TnBmbWVnVUZGZ2hEdlcxOEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЯΜΟοΡЖωξΔщй():
    if 35 * 99 < 0:
        pass
        pass
        pass
    value = 479370
    if len('') > 0:
        835
        511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQvGVFAU2LgBY1eznFW6IS12xk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 77 * 88 < 0:
        _dead_1080 = 667
        508
        673
    total = value + len(text)
    if len('') > 0:
        _dead_9278 = 819
        _dead_5123 = 866
    return total

def _щКшΡЗвΙμΕΦψПРΞ():
    value = 986313
    text = __import__('base64').b64decode('SmNCVDd5cGQxYmJfdm1ubVNFeTc=').decode('utf-8')
    total = value + len(text)
    return total

def _КИΗДШЗЮχω():
    value = 794211
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHnsY2Ef5JtUMyytnFuHGjEpzl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оδилХμщТ():
    value = 594689
    text = __import__('base64').b64decode('T2tLcU16cGkxcGJNRXBSck5TU3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓЧΩПЛΚχОбФ():
    value = 548000
    text = __import__('base64').b64decode('a2pFb3NseHE2N003dmt4WW9pUW0=').decode('utf-8')
    total = value + len(text)
    return total

def _вζчЪъαпхΟДΥп():
    value = 950974
    text = __import__('base64').b64decode('SUdIMVkwa0JNNFFMOTVOU19DeU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘшΒмΔПВсφЬΙοтщж():
    value = 110631
    text = __import__('base64').b64decode('Y0xydDR4aHNnbmlOOXhQeHRYYnk=').decode('utf-8')
    total = value + len(text)
    return total

def _цβсГЕΟзбΚν():
    value = 140693
    if 74 * 69 < 0:
        _dead_8173 = 23
        pass
    text = __import__('base64').b64decode('UkZLaWRuNTlZWjNJTWliNnpmQ1Q=').decode('utf-8')
    if 61 * 31 < 0:
        _dead_6800 = 795
    total = value + len(text)
    return total

def _жΚЯιΙψхΧ():
    value = 664630
    text = __import__('base64').b64decode('ZHBuUW1KZGZPZmRvNjdWaG01Umk=').decode('utf-8')
    total = value + len(text)
    return total

def _нЮΓафЛΤмΒЮ():
    value = 258850
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('VkxOd0xaTzl1NVU1dDRvSmt4ZTM=').decode('utf-8')
    total = value + len(text)
    return total

def _μСΡэуΜхκλиХ():
    if False and True:
        362
        pass
        _dead_7240 = 918
    value = 697489
    text = __import__('base64').b64decode('ZDBJZWFjU1Q0RnJpMmx0bzVHWXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ежРΔιфΥрЧЩζВЪэ():
    value = 14429
    text = __import__('base64').b64decode('SnFzQ1RESDBFOVRlYzRQX2ZNOWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒЦΘΦυΡМцЯΗρκ():
    if False and True:
        pass
        pass
    value = 548011
    text = __import__('base64').b64decode('ajNRVmxSb1RZa0RYSW5YR3ZDYjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙυЗσШΦЬюЪυЗΧΒτЫ():
    if 29 * 2 < 0:
        570
    value = 113781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRzcdlw4r60JEheVkU7AJHV81XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΙΧГБωфаЬз():
    value = 166708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxnbbWIY+LAPAyaB6lGJOw4ps0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 87 < 0:
        _dead_8094 = 108
        pass
    total = value + len(text)
    return total

def _ξгсПКΨφТξыНкσ():
    value = 278516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HS7Cd1Md9okCEjeX/3mkBDJ2yko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 53 * 94 < 0:
        292
    total = value + len(text)
    return total

def _ωрЭΨΘЪнН():
    value = 57849
    text = __import__('base64').b64decode('blhqOHRyaXZCUEo4Mm9KWUVGOXY=').decode('utf-8')
    if False and True:
        pass
        _dead_7313 = 110
    total = value + len(text)
    if len('') > 0:
        52
        _dead_3634 = 730
        760
    return total

def _γуθЙΚЩЦЕΖ():
    value = 606864
    text = __import__('base64').b64decode('T0VTWWJzeXVkVXB3OHVQX291d2M=').decode('utf-8')
    total = value + len(text)
    return total

def _λθншЖΨКζЬН():
    value = 198441
    text = __import__('base64').b64decode('TDZLZWw2QVRyc3lCdGdGM1IwVGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙйаΤΧμТΠсГςΒьΑ():
    value = 387387
    text = __import__('base64').b64decode('T0prY0NVdW5TcXR4V1BCeGJOUDY=').decode('utf-8')
    total = value + len(text)
    return total

def _χОςΛжасΙдΦНуΥΜ():
    value = 315416
    if False and True:
        pass
        _dead_3640 = 270
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ER7VRnIQ5qkJD1epkHmFPBcp/H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сЪχλψςΜλбвξЮэВΙЛ():
    value = 958089
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KALVTwEb7oxRAzmN8XSmITd2wDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        50
        _dead_1689 = 689
        _dead_6366 = 358
    return total

def _БΛΘХΛΕΜа():
    if False and True:
        _dead_1494 = 226
        819
        _dead_2674 = 181
    value = 51733
    if len('') > 0:
        _dead_4756 = 347
        _dead_1469 = 727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mzvif1AS1qQ5MRyn3kSoMQQt9Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _τπΧяйЩβГгςσВΗ():
    value = 327572
    text = __import__('base64').b64decode('RHZqY3E3WTMzRVhndjB6Xzh6cEs=').decode('utf-8')
    total = value + len(text)
    return total

def _хςРΔμЖθШρЦ():
    value = 613311
    text = __import__('base64').b64decode('YmNhRXZac2hvbl9mNFRqYloxQnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΝлαтΒΕΚΦуыьУΛ():
    if 71 * 4 < 0:
        550
        826
    value = 517022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBiwYFkA2q83IyiN51CKOXQftmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        229
        664
    total = value + len(text)
    if False and True:
        pass
    return total

def _ψπШΤΛдМιμЯбΑτо():
    value = 732957
    if len('') > 0:
        pass
        _dead_1555 = 455
        pass
    text = __import__('base64').b64decode('TWxWMWdDWmc5aVNJNDRJdFJuSFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _шЙЗΨНьллвΣηИΖ():
    value = 431898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwzhYFsSq/gVFVmznwCfBCQ6wX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΕЙςκΚФНΑτΣсД():
    value = 464212
    text = __import__('base64').b64decode('Q1RrNnhpTkszZVhGejBsRERGQWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΛЭЩКζхςΞΔДΖΜΗЕρ():
    value = 491906
    text = __import__('base64').b64decode('eWhLSzg1ZjJDWTlhX3VNWTV6TTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΠαΧбκЩεΩЧΠΑ():
    value = 335226
    if 33 * 61 < 0:
        852
    text = __import__('base64').b64decode('SGNHdklFQ1NNUVlxdFpIXzZwUEw=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΒЙΑΝОΟДБΙяФΓοΞ():
    value = 758247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR7hZVk+yoYiPAOz0EDGMCMq9Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛЪΗΣрОΤыηл():
    value = 159020
    text = __import__('base64').b64decode('cmlPN21RbTIxSlVROHFscF9oYWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒщΛςУσЬΒΩлΖκεΖ():
    value = 269090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXbgQUUJ1pAXLlicwUWFHRMr73s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        942
    return total

def _γыΦшζТИΝеМх():
    value = 858269
    text = __import__('base64').b64decode('UmtIU0pDZ2x3NmI2Njc3NVo3Z0c=').decode('utf-8')
    total = value + len(text)
    if False and True:
        599
        pass
        390
    return total

def _πΛДγΝЯтΚΩ():
    value = 460919
    if len('') > 0:
        _dead_7498 = 764
        _dead_3925 = 330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pxi8TGkJ1YxUIlmLkAO6EwQ7tVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΛжαчυσΜвΡвЖοФΩ():
    value = 867067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHrzdn4uqZxXGyOZ8kS3YA0A20U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цзСЗΓΔрВ():
    value = 315138
    text = __import__('base64').b64decode('dEhHX0p5VzRSclVaNWtOT0FINzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥщпιсЫΘэЫнйщφθИщ():
    value = 337997
    text = __import__('base64').b64decode('V0tmWUxtNE03V2dZTW9veXVfZEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _еλюΗμΖΤοΝπΨке():
    value = 778352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx2zNmkDqaMuEAy521CgGih271k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨНΨЖэΟфξΘΜΛυТΕМ():
    value = 965026
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3jGW2Yu/bkQCTn30HTELCw66Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЙМΔθΤМΤΧλЫЦу():
    value = 373627
    text = __import__('base64').b64decode('U3BXMzljVGFTcDdSb2hnZ0U1OTA=').decode('utf-8')
    total = value + len(text)
    return total

def _йΥЦκΑшДψЮλЖЭΒ():
    value = 54894
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FifXQEgPzvk8EyqL5GWWZQQs9Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 61 * 68 < 0:
        _dead_1858 = 582
    return total

def _ИγэМыБПв():
    value = 297972
    text = __import__('base64').b64decode('YWFxaUdiakVpZ2FUdkcySkdnaTU=').decode('utf-8')
    total = value + len(text)
    return total

def _цΓνΤнрΝξСяνΞсъΣσ():
    value = 126555
    text = __import__('base64').b64decode('SXJoRlhlaWJiUkFQVG1tT3JUWV8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚщΟΥψαЖΝΗχгγа():
    value = 674058
    text = __import__('base64').b64decode('c3dqclZWRE94bVpjbTF3S2taVVk=').decode('utf-8')
    total = value + len(text)
    return total

def _зΜалЕЯλΛЗл():
    value = 794423
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwPvY2Fo0pJVPB+anXSbZwM/9mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΞλΘΓΒСЖЭзκКЭЧП():
    value = 182278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh63fHcUp/8COQObmAKlMw0/03s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝЩυΚΤъЮЙКοы():
    value = 774295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kn7PbXUp1ZJQEx6M7Fi5GHE+72M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6960 = 658
    return total

def _ΧмΤаЕυοЧεбаβкΥ():
    value = 339533
    if 90 * 97 < 0:
        _dead_7286 = 454
        _dead_3923 = 376
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj7xQUU2rJJUbCmW3UC2ITUKtmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КИНεΖкЛэЦΥЮгκМ():
    value = 521316
    if 26 * 16 < 0:
        586
        _dead_2552 = 457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx7FY2k++oQ2GR/7+meJBwwh42Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΗεКδНБΒР():
    if False and True:
        pass
    value = 360372
    text = __import__('base64').b64decode('TW5qNUNZekF3RElVejBYNGRDT0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЦтχРЫΕХрвЯЯΘ():
    value = 731648
    text = __import__('base64').b64decode('WW9ROE1ITmY5NFlYeFFJc1VvQkI=').decode('utf-8')
    total = value + len(text)
    return total

def _жхΗпοХЙχРΧωΕЗ():
    value = 752448
    text = __import__('base64').b64decode('akY1N3hsWV9ta1JSeE1kdzVFajY=').decode('utf-8')
    if len('') > 0:
        _dead_2372 = 116
        _dead_9657 = 326
    total = value + len(text)
    return total

def _кЪυωχЗТрбВХβΤ():
    value = 457246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhvFf2dh9awBbR6km1OSG3Qk7ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫСδΝШνдРхδымПΞΙ():
    value = 979686
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('bFkyTEVobUZsRUFoVWpRMDRXZDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙОмфθζЩξα():
    value = 152990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBrSakYM2voMHCqO/nLIHDQC8Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςнβуΓσБСτΖδΖУΤλ():
    value = 537680
    text = __import__('base64').b64decode('aHBSNUxOc25NWURQeko0REdHYTk=').decode('utf-8')
    total = value + len(text)
    return total

def _апΕΑЬΓηЧυЩβθΞ():
    value = 867457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Exr8V2A+77gGaBa70W+RGnQcsms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υюпΥфκьФυΘЯΙэЫ():
    value = 973505
    text = __import__('base64').b64decode('alNuUUlyU0pIYXFJSUFuR1BzUlo=').decode('utf-8')
    total = value + len(text)
    return total

def _НςВаУΟΠΘр():
    if 38 * 61 < 0:
        _dead_7654 = 776
        _dead_2477 = 817
    value = 727044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgXDaQcWy5IICgqW5mK3PTch0Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        325
        pass
        pass
    total = value + len(text)
    return total

def _нθζΠΘфδцНл():
    value = 364457
    text = __import__('base64').b64decode('cUpBSVR0YlROMTFtUXdreTM3RmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _фбΞсБΔλДРμυИ():
    value = 756054
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx/gRmkj7Jo8HDeb6wGjbBAQ5j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _удΥцпГЕЦΚЙΜАмьШ():
    value = 189921
    text = __import__('base64').b64decode('d0hGRlZ3aDhiSWdHQTVBYVB0cmY=').decode('utf-8')
    total = value + len(text)
    return total

def _υΩΗСςНΦйΒ():
    value = 162425
    text = __import__('base64').b64decode('aEw3OGd1UEJqcmt0c29RT2xXU0o=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6411 = 460
    total = value + len(text)
    return total

def _ХΚγХΠЬЕιФΛαЪ():
    value = 728727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3nJRkkz15sTFAuN6X6CNx0h1Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПφΠιΝΒοΑ():
    value = 127357
    text = __import__('base64').b64decode('aXhpVjRLTzVvSGl4eUwyemZoX24=').decode('utf-8')
    total = value + len(text)
    if False and True:
        486
        _dead_6828 = 459
        683
    return total

def _ЙυЭпЯΑцΖξЦИзчВм():
    if 37 * 74 < 0:
        825
        pass
        212
    value = 744978
    text = __import__('base64').b64decode('ZmRBek5BS1VjclF6clJOenBPNEM=').decode('utf-8')
    if 67 * 33 < 0:
        pass
    total = value + len(text)
    if 42 * 89 < 0:
        pass
        292
        _dead_5311 = 744
    return total

def _МШψψΟρгΦΡАпщ():
    value = 20770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh7OR3Y4+q01EDiH5l2qBQkhtXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒТуфφбяΖДИγеχе():
    value = 905667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCrlXXcY2I4qaQmlzVTCYh8b0Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭσλΙыГΤжΥσм():
    value = 55261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lga9Wn8V96EEHTCE7waTB30n6Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дьЩΡяΝЯπьВΖ():
    if False and True:
        _dead_1452 = 760
        pass
    value = 376530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCDBenYX774obj+cxn+EBQQ3/Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 36 < 0:
        pass
        258
        pass
    total = value + len(text)
    return total

def _ЕΑхΠλОζяЖΖЛ():
    value = 328640
    text = __import__('base64').b64decode('YkVTUWpBMzVzaTFHbEpmTDZUWlY=').decode('utf-8')
    total = value + len(text)
    return total

def _ψПЮъЙэцςунжрНκ():
    value = 153969
    if len('') > 0:
        pass
        pass
        _dead_5838 = 210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH/DfXcV1Zk6PQmn/F6yYCMV5ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьпРТΧюйсЭцМохψζΦ():
    value = 166908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhDQdggS05kJBT+azw7IJykg0G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЭтсΗоиЖХзΘЧрЗΝβ():
    value = 992575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgbcQlsN6qw3MwqS7weGIz018kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юθсχИЫсюΝ():
    value = 47774
    text = __import__('base64').b64decode('Q04wTHBISU1TaUMyaTZNbG1hUlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣηнδтгФΩкδ():
    value = 246027
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjnIN2INrakoLSCL3XiXOnEW21c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΣθЭοΠЙд():
    value = 643075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxDdZX8ax7EEFSuzxEKfJSIftlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 81 < 0:
        pass
        _dead_3292 = 396
    total = value + len(text)
    return total

def _МτφоТрΒΕчαБ():
    value = 341933
    text = __import__('base64').b64decode('dnMwV3NxRnJmVElpSDBRV3pYMDY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5130 = 224
    return total

def _υΕеςЫхΚο():
    value = 17644
    text = __import__('base64').b64decode('QTY4YXdBdjlIMEpXeGtKUUNGXzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘПΜПзКирСΚζЩчфЕ():
    value = 150624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dhj9eWgTq7gtYwas2kCkJR8j7Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖκзЮмИГМчΑΦЦΥβм():
    value = 432080
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISm2XGEQz64tIFqnnUCfZykg5lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЗΜΠΜуеУ():
    value = 891396
    text = __import__('base64').b64decode('eGVScktHSG16RHZFY2hqRDVRSnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ιТΨЮэхμлζΤъΠ():
    value = 614716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjnQSWgA0psgLyaN7HuFFjV56z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лнзпгцλрЫА():
    value = 322737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQ7NPlUQ/ZsGbDCN2wWVJCIltXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωвАЧъТнэ():
    if 51 * 81 < 0:
        _dead_2583 = 77
        _dead_8246 = 607
    value = 84275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwfsfmsSzfkUCyio2g6RbRQssGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        646
    return total

def _ΩΔНХХΧтЛ():
    if False and True:
        _dead_2154 = 703
        _dead_2121 = 231
    value = 944759
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwHhf0Mf66kRMQe6/A64InQ94js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тсΞбЩκЭβΞ():
    value = 264824
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBrqdHc4yYw1CgKHwnunMyga1GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4912 = 571
    return total

def _ΡΓАτΣьЗμчЙКΓΥуЧм():
    value = 972494
    text = __import__('base64').b64decode('WDFQaEtwVFNmS3Z3YU5wZGN0Mm4=').decode('utf-8')
    if 4 * 68 < 0:
        _dead_1251 = 668
        _dead_6726 = 284
    total = value + len(text)
    return total

def _чηΧΛдοιУασЫ():
    value = 918895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADnMOHxq1qkpYj+OwmW+HDc1230='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_3942 = 65
        pass
    return total

def _ТЫхбΧхьсΠВξιΠАΗ():
    if 38 * 48 < 0:
        608
        pass
    value = 361466
    text = __import__('base64').b64decode('S1BZUDFtV3NPdEQzbWtta0lYbXU=').decode('utf-8')
    total = value + len(text)
    return total

def _хΙΞПцсОШκЪΩ():
    value = 866942
    text = __import__('base64').b64decode('Vm9BZGVEN09aVDdRUjlhbnYwVXo=').decode('utf-8')
    total = value + len(text)
    return total

def _цЬЮИдбΖΡνсф():
    value = 491977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSW8b0E6rKQRale3wgapMnF35nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        853
    return total

def _ΩтмиРψΧψΕиУτΔλЗγ():
    value = 406584
    text = __import__('base64').b64decode('ZUtPbk9LcWFBUlBiS2t6YVFkM0o=').decode('utf-8')
    total = value + len(text)
    return total

def _δТцβκΔмΟηςэТЖЙОЫ():
    value = 102079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBDUbQkq2r47CiGr7H2bLD86wEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΥШДзэδжρςрΛθΒМК():
    value = 970607
    if 40 * 9 < 0:
        _dead_8922 = 567
        pass
        236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgD1OEU62qAhPl662gCVPnAJsng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        855
        pass
    total = value + len(text)
    return total

def _щкспγΙВщΙχΕΥυфΔΙ():
    value = 585885
    text = __import__('base64').b64decode('VjJEUUthaHh4c3N0NkV3NXp5SVk=').decode('utf-8')
    total = value + len(text)
    if 22 * 17 < 0:
        pass
        pass
    return total

def _ХхζХгψΗУλ():
    value = 789312
    text = __import__('base64').b64decode('UUo3dmJ5aE96RFhER3VmRnB0YmU=').decode('utf-8')
    total = value + len(text)
    return total

def _лσКзΣΛΠυуКΝρογ():
    value = 669014
    if len('') > 0:
        _dead_2151 = 506
        pass
        415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IH/8PUI+9a47N1uc7A/GMy024WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_4996 = 86
    return total

def _ЫΛΓщшεΣшаβмν():
    value = 707692
    text = __import__('base64').b64decode('V0RrcHUzcTk3S0toN2hiUjhmTkk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        999
        pass
        _dead_2471 = 910
    return total

def _ЖαΣгаΚЬδЮο():
    value = 974874
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBbsb0Ju1KUvKyqcmG+kNXF93U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФχцНςФΗб():
    if len('') > 0:
        _dead_7980 = 638
    value = 67738
    text = __import__('base64').b64decode('SXN1cW51ZUpSbUp3UVQwQWN4Z2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤМβьδВСВСπΣφηζо():
    value = 278535
    text = __import__('base64').b64decode('RGhPWENqS0EwbEpTbzA5ejU0bjY=').decode('utf-8')
    if 24 * 99 < 0:
        128
    total = value + len(text)
    return total

def _ΑπΞΓηэСЦУбЬςπыч():
    if len('') > 0:
        pass
        pass
        948
    value = 677526
    text = __import__('base64').b64decode('cjNqMTJDdDdSYlA2dktqYmVBSTE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        48
        66
    return total

def _жρУщΤεφпсΧЛ():
    value = 724179
    if 69 * 30 < 0:
        pass
        _dead_6768 = 36
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAuwREZpq74bEyWw3HKnPg8A6Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3537 = 70
        pass
        _dead_7518 = 376
    return total

def _оσпаλЕηЧ():
    if False and True:
        pass
        307
    value = 924693
    text = __import__('base64').b64decode('dEJwN1prOFpBeVZRTDBlS2trbGw=').decode('utf-8')
    total = value + len(text)
    return total

def _лΡуЪнщΚюΜч():
    value = 154337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSjgf1sr8owUEQyp+mmJOgMmvUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωяΔτСθЦо():
    value = 334415
    text = __import__('base64').b64decode('RmlFZDhaNnJOTUV4SDNuZ3dHVVI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1442 = 858
        426
    return total

def _дΝΒΡЩτСЛфлбЗΟ():
    if 35 * 97 < 0:
        pass
    value = 494713
    text = __import__('base64').b64decode('eE9DUENRbEN6OWo1SHp0cGJ3aUs=').decode('utf-8')
    total = value + len(text)
    return total

def _δΩζαδδщΑΝЛЬЗζ():
    value = 111859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDmwRWEN5qIFCASB8WOjIDIExVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩДΝφсьТδхμОγξΕ():
    if 71 * 68 < 0:
        pass
        846
    value = 594158
    text = __import__('base64').b64decode('all4c3JhRHdha2E2VE1rcGZGdDE=').decode('utf-8')
    if False and True:
        pass
        176
    total = value + len(text)
    return total

def _πЪЮДЫиуτ():
    value = 564420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IynVR2Zo34MyCgin/06EZS4l3Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μυΩΖХυЧШз():
    value = 294708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR3jQEBo+L4qPQOw/nnBNiQB/Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еδОΙэЮχΗΝЩОЯл():
    value = 319334
    text = __import__('base64').b64decode('dEJ6aGNwN2FiNFdYOGdZb3BmUkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _СρфΡοЩΛфуψггε():
    value = 578031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgfcN3QM0oU3Cjn7wFuGAioW22M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΗβυкΓΞΩφНьДΡ():
    value = 634397
    text = __import__('base64').b64decode('dHU0QXBHQUh0SXBUQ011M09xQ1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪЮшДβΞРмлΙδ():
    if 56 * 90 < 0:
        _dead_4270 = 672
        420
        _dead_1125 = 18
    value = 203365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQniYnQax6A3CgiR8WCqJRAl00o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 63 * 18 < 0:
        pass
    return total

def _тξΑκиТΝφμрο():
    value = 35692
    if 80 * 94 < 0:
        992
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MACwOV4S27wSG1eV20S6GS8I9mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        376
        _dead_3942 = 647
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3491 = 818
    return total

def _РъдиχΓКЭтΜуЛχΣ():
    value = 97745
    text = __import__('base64').b64decode('TU1wRkRuaFVNVWI5ZXNiS3VxTVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ИсΣτσΙηγι():
    value = 288525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In/qTGk30IdSFACO0EW6bSE54kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γгщΒκΜΥςЗφθ():
    value = 671862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3v1fHU7qIk5PAWB3kK4FhoEymM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εьЮΦэХщЕνщ():
    value = 84608
    text = __import__('base64').b64decode('R2xIREVJcmxnR3VCV0pvd1liZlo=').decode('utf-8')
    if 47 * 38 < 0:
        47
        pass
    total = value + len(text)
    if False and True:
        65
    return total

def _СΒцςтαЛΞΗ():
    value = 919866
    text = __import__('base64').b64decode('TWpKNldaVktZTDI3dTdYbFVKT0o=').decode('utf-8')
    total = value + len(text)
    return total

def _λЕΣйЭЕъΗΡпτγУΧюх():
    value = 623455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH7BTHw9x448Ilii5kWYZRQ/sjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2748 = 801
        pass
    total = value + len(text)
    return total

def _фΧзТлезОκКβωъм():
    value = 738487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT+3NgIaq/46KFn7nWO1NjF/70s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _флσΔτΠμπΜьτнжδЙ():
    value = 395296
    text = __import__('base64').b64decode('TXQ5cDBBMVd5Qm1SMldUV3dTRDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒэгЫУбыμαιясБΧц():
    value = 928805
    if False and True:
        _dead_8379 = 274
        pass
        pass
    text = __import__('base64').b64decode('UFh5Z3RKWDNMcXR4aF9wRmRHUGE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        859
        _dead_3321 = 407
    return total

def _ъАΙПΜЧΨШ():
    value = 920444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MArzYmsM6LoED1iW/Q/HIgd90T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оЫВΘξЩηЩοОв():
    value = 613082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC3IWGAU/5AyPRb1mnChBwcq/Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1468 = 116
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_1475 = 909
    return total

def _арεЕкΒУΦНζМЭяткъ():
    value = 61665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCLzSUsr/6MuClqA2nGpHXYKyXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΩδΖЯςпΗТδНνйβτ():
    value = 652751
    if False and True:
        pass
        488
    text = __import__('base64').b64decode('cmlNbU1nUFZlbExwRkpITmkwQms=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        468
        _dead_1415 = 876
        7
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if 51 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()