#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _бΟψМοξиюκЩ():
    value = 356168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASTAZAY//IYqCCGSy321PXYD3UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΑКИνчЩффНкΗΥС():
    if 13 * 50 < 0:
        pass
    value = 695754
    text = __import__('base64').b64decode('YmtFNEgyZEppNHd1Q0xkdnpmcVU=').decode('utf-8')
    total = value + len(text)
    return total

def _γлФуЖψσьЙя():
    if False and True:
        pass
        205
    value = 742773
    if len('') > 0:
        272
        _dead_1885 = 901
    text = __import__('base64').b64decode('VTg1WnhOajAwVlBNdWxlZXpuOFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _φмΨΘЩυΟνΝδΩΚ():
    value = 654735
    text = __import__('base64').b64decode('WDFMckpZYkZ1Y0pXUENWaURURlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛйΨнКУТξЦδαГОя():
    value = 779206
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('bm52UGl4QnJOUFVIWG8ySnNTazI=').decode('utf-8')
    if len('') > 0:
        495
        551
    total = value + len(text)
    if 81 * 20 < 0:
        _dead_2239 = 751
    return total

def _ЪЫοΙΛγΜчэτрΑΙи():
    value = 833321
    text = __import__('base64').b64decode('ZlExUllsOEtOcm13ZjExb2dWTDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒβЗΜкωΠЬиδψЦ():
    value = 947039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDbjRXoX1okpbQ2u0QOCZA8+6m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦАЛЕΥτЖшγюςΣжщОτ():
    value = 582280
    if len('') > 0:
        _dead_9441 = 993
        pass
        147
    text = __import__('base64').b64decode('aUNDTHoxTndaenoxQmQ0Q2VJa3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔфыΡψЯуЗΗγЖЩСЯХ():
    value = 212302
    text = __import__('base64').b64decode('WlZuR0p2dXhhUmd4QVhaRmE1ZjM=').decode('utf-8')
    if 89 * 18 < 0:
        pass
        _dead_5372 = 187
    total = value + len(text)
    return total

def _хοτбκχςшьΠΚζυ():
    value = 186876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQLpWVQtrY5WYy3y7w+eIjcY62A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κυΙхВχΕιСМ():
    value = 334975
    if False and True:
        905
        pass
    text = __import__('base64').b64decode('c0dpVF9lN0FOTXFOa0JUUVNHMkk=').decode('utf-8')
    if len('') > 0:
        _dead_3720 = 199
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ΗωГφНьαΠΖρщя():
    value = 168388
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3a0PWY63YUyIy6gzXOGNnIqwEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬфζαЩйΦЧх():
    value = 238965
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axu0ZGsw648AEjCyxEPBGx02s10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _бтиБвЦπΥιщα():
    value = 747647
    if len('') > 0:
        _dead_2117 = 467
        138
        pass
    text = __import__('base64').b64decode('U29GYmdLa0Fxdzd3VmFGa1RqbVU=').decode('utf-8')
    total = value + len(text)
    return total

def _шεθыЯΠБιυβйВΜΔип():
    value = 131422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAfbSnU0yqQHPViA53/GYycD/EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 69 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ИδъΔοвТμΛ():
    value = 941500
    text = __import__('base64').b64decode('RHRZclRuYVJKX2lZanB6Z0ZGMUY=').decode('utf-8')
    total = value + len(text)
    return total

def _оБРиΒъμΣГфьН():
    if len('') > 0:
        pass
    value = 73375
    text = __import__('base64').b64decode('WnJCdU5BSm16YWhnVUh6Y09wc3U=').decode('utf-8')
    total = value + len(text)
    return total

def _киμχВλШаκΒВΟР():
    value = 654895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRm1PH0u14M1KiqzkV2eNXI7sHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 57 < 0:
        _dead_7240 = 569
        pass
    total = value + len(text)
    if False and True:
        187
        pass
        766
    return total

def _ρМзлΘγΕбФъЫУγΘχ():
    value = 22755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQKxd3Mv+KUWazqcmGm+DRci0Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔмΑЩрпыГΝτЕΕωвμ():
    value = 335035
    if len('') > 0:
        _dead_1759 = 284
        128
    text = __import__('base64').b64decode('WUFCQmJLd1VSYUdmdm16T1BxZkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧгΠтηЯмНХΧшΩпЛυ():
    value = 191409
    text = __import__('base64').b64decode('QjlHV3R3SlJHcGthMF80UFNsX08=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠмСнТυоДЧОτшΑМ():
    if 2 * 16 < 0:
        pass
        pass
        pass
    value = 30845
    if False and True:
        315
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET3cTAMe9p4oGzvx6wGEYBwp/XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕсЪШυЬюбГξсЦШк():
    value = 622396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQTlXQNp9YQybw6l90y4MwgY20c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВνξφнΑщЙΚуψХ():
    value = 49123
    if False and True:
        _dead_2553 = 254
    text = __import__('base64').b64decode('VTVJYTQ4QUl3bGg4VVNTRDFGMmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΟπЦтαЛΛйοоо():
    value = 514304
    text = __import__('base64').b64decode('UFFYNnRJa2pJMDRQczNiS2tuZ3g=').decode('utf-8')
    total = value + len(text)
    return total

def _лщтιИуИэБуυοπμЭ():
    value = 428635
    text = __import__('base64').b64decode('blJXY1RuZEdSUkF1Zk5XMW54c0s=').decode('utf-8')
    total = value + len(text)
    return total

def _шьюΓДξΗжαюЧЫз():
    value = 31079
    if 62 * 56 < 0:
        _dead_7744 = 484
        _dead_1315 = 912
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHfqOHcd1aYxbg2JynmCFR8rtGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4112 = 797
    return total

def _ьηДβλΓУЯΘηΖΩюΚ():
    value = 927795
    text = __import__('base64').b64decode('aHFMM1B6VGdSdEFZQ19TS3M1V0M=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _КРтнΨиЗζ():
    value = 837463
    text = __import__('base64').b64decode('aXo5bW9SRjFGaTlqbzI3WDJqUk0=').decode('utf-8')
    total = value + len(text)
    return total

def _πЕΥОαδιχОрлΩэднΣ():
    value = 893471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CirLQ1o7q78HYzChkF3ILnR5sGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 46 * 2 < 0:
        1
        912
        pass
    total = value + len(text)
    return total

def _ЭТψοХΛςвΟмщпРο():
    if False and True:
        _dead_2139 = 923
        _dead_5991 = 802
        930
    value = 464639
    text = __import__('base64').b64decode('aEtqbjMzdnZRMWNBTGhJNlNLcjY=').decode('utf-8')
    if False and True:
        337
    total = value + len(text)
    return total

def _ЙμДπТШνГИρРτЮм():
    value = 999452
    if 90 * 97 < 0:
        37
        997
        _dead_1194 = 382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En3PSnc4zb41OAS70WKyMw4Xwjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βιЬδПЯΑμсΧ():
    value = 794070
    text = __import__('base64').b64decode('bnl2V0dJU0RHdVhDTW9lamU4RE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΩωПухУΟΥЪιχ():
    value = 709659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InrjXUQW+745YxmE+QWIEyJ75Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦАαΩЬХΩυξЕΔΘΔэ():
    value = 209515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCrFeAY26aVbNi6U90eJAz8Dy2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛυЦиΦыδσΒф():
    if len('') > 0:
        802
        pass
        389
    value = 427374
    if 85 * 79 < 0:
        pass
    text = __import__('base64').b64decode('eWlXZ3dFbkhhX1h2MmFPUlJDZnk=').decode('utf-8')
    total = value + len(text)
    return total

def _гξИτьφΒΚΡΖюΓРг():
    if False and True:
        _dead_2591 = 608
        _dead_3857 = 970
    value = 745202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChnrXgEs/4ciLDeF3UWpMxUQzHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТмПчβΤΝΘΣэЮЧΒлну():
    value = 593769
    text = __import__('base64').b64decode('ZDQ4dHhpSUNqMGVvc1BEOXg0VFY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        589
    return total

def _ЪιЮКωКςдΕΔΦЮρΠ():
    value = 606817
    text = __import__('base64').b64decode('and3X29VejY5YnNEemZ1WmtZeFc=').decode('utf-8')
    total = value + len(text)
    return total

def _пΠΙΩΚяΨИФξηяλЕШ():
    value = 893186
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCzLXm4+76A5bQKu31ihEgs+ykA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 58 * 24 < 0:
        399
        pass
        _dead_2696 = 958
    return total

def _ЗНшΡэсЕТχΠΘыРΑΠч():
    value = 673336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATy9bHgG3akrLD2ZxV/AECo543g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ДΖβЮφЛДΛщεШФШρзМ():
    value = 238744
    text = __import__('base64').b64decode('czJYOTFDT0xvV2dFRUlFU1BFbEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ТхмΞΖΔιλпυКонШ():
    if len('') > 0:
        907
        pass
    value = 646899
    if len('') > 0:
        _dead_8078 = 193
    text = __import__('base64').b64decode('U01sd3ZxWF9jSzdKYVQyZmQ5dW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ббъΨΡМкΜΠνРΡыΒο():
    value = 732441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAv2XgBo+pIOaR6J4mWDEzEYyEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КψπΑжгμояЕ():
    value = 697243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Exu1dH44/YNWPDWm0FCJBxc2/m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 76 * 95 < 0:
        pass
    total = value + len(text)
    return total

def _кαΔЧΞΑэЦцЦв():
    value = 312977
    text = __import__('base64').b64decode('VVVBbWg3d3F0UG10ZGVLT1lBWXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ъЖвζзΜЩΛоИυФρ():
    value = 427956
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiD2Vno324oqKSv2m0aELAMs/nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 89 < 0:
        191
    total = value + len(text)
    return total

def _АоЖΜΙШХАлЙα():
    if 82 * 30 < 0:
        _dead_4179 = 219
        _dead_5453 = 126
    value = 920183
    text = __import__('base64').b64decode('ZFFKa1BsRTFhOUd4UmtzSTZNVFI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3449 = 671
    return total

def _нЯΗγсΨξπΖюιΞ():
    value = 900428
    text = __import__('base64').b64decode('cVZ3d05ud0FTQmJEN1NBdkljeU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΑхΟмЫЗЗΔΚΔч():
    value = 328105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQncdH8I9vonFR6k8U6XDg8a12Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΞελшАсшв():
    value = 356882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dijcb3Qx+YwnLi2B8mS8EhQ3wGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥφΝΚДпΩΣΤθΨфωн():
    value = 140747
    text = __import__('base64').b64decode('bmpzd3JnV3p5YUhfcDNJQmFvaEw=').decode('utf-8')
    total = value + len(text)
    if 28 * 19 < 0:
        158
        pass
    return total

def _ψΔКπЫоΡгААДхС():
    value = 745404
    text = __import__('base64').b64decode('eHhVNVJaaXlrM1lKNXJhazdoUmI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЛНμЕξχх():
    if len('') > 0:
        273
    value = 788556
    text = __import__('base64').b64decode('cUM4V0tjSFVYc1hDZTFMb1BfVEw=').decode('utf-8')
    if len('') > 0:
        110
        679
    total = value + len(text)
    return total

def _ΘуДймΕεБ():
    if len('') > 0:
        pass
    value = 353038
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSPsOXIK2PAuFVuy6UKpC3IE1D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΟеΣЙгψЪ():
    value = 183171
    text = __import__('base64').b64decode('ZHFsWVpnS3dEbXdTQlNYMEJVcE4=').decode('utf-8')
    total = value + len(text)
    return total

def _γФвНсνХЖк():
    if len('') > 0:
        392
    value = 680948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQi1WFA1zYIpKAep63vCPQgewTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χгαЕэδφΑ():
    value = 14409
    if False and True:
        pass
        359
    text = __import__('base64').b64decode('U2k5dm52b2dzRnRPMlpCRzMwTjk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5788 = 584
        pass
        _dead_3312 = 944
    return total

def _ХψЦЯФчСХκЕΑИжшε():
    if len('') > 0:
        _dead_1355 = 350
        pass
    value = 953305
    text = __import__('base64').b64decode('SU9HMU1mSFZrNmtFWDlRN280eEo=').decode('utf-8')
    total = value + len(text)
    return total

def _гАΧЦпЭΠΖΩгъФЮхΨ():
    value = 81506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgnKZHdp3Z0UFwur4X2cDgF+4Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5502 = 922
        _dead_1271 = 590
    return total

def _ЩЖмΕчЬΒψζΒ():
    value = 914661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT7wXF0QxroQGyqB6VSVZyd81jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бчδТεюκщш():
    value = 786544
    text = __import__('base64').b64decode('UjI5b1JoU0RkY1JoelZGM2x0MnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ищΥЯΥЬωυυФЫΥΣПГφ():
    value = 970013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD3IRVUfrZ8OKTaW/Qa+DDU+3Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 18 * 94 < 0:
        103
        _dead_2553 = 388
        616
    return total

def _ЯχΕΡΜΖΧσжрЪ():
    value = 168034
    text = __import__('base64').b64decode('ZHVJaHlkdFNfUzlXdEd3R2FPSkM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4139 = 696
    return total

def _ЩЙЗΒАηъΟ():
    if False and True:
        _dead_3990 = 973
        pass
    value = 448557
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz3HSl8+1qI1bw6h70yXBjA3x2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЖзΙшЬυДι():
    value = 76078
    text = __import__('base64').b64decode('bTR0ZDVHUE1EOHFueWp6b29tVVk=').decode('utf-8')
    if 49 * 2 < 0:
        pass
        962
    total = value + len(text)
    if len('') > 0:
        _dead_2277 = 682
        974
    return total

def _ΣλλцЬδбΔχνр():
    if len('') > 0:
        pass
    value = 76967
    if False and True:
        pass
        186
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh3rQX0v8YsFKj6k5n+6AQcB4Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΩаБεюХОΥйΦя():
    value = 384997
    text = __import__('base64').b64decode('ZWR0UkVMX0NzNVlNRVRnQUVvMlU=').decode('utf-8')
    if 6 * 46 < 0:
        _dead_6434 = 726
        709
    total = value + len(text)
    if False and True:
        518
    return total

def _УΦΕΓπΘΤакΓиэмРΗ():
    value = 970037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwS2QEMt0YsKAhqy0WLINi836mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΜωПΩЬлщцΡЭωЛЙЭь():
    if False and True:
        874
    value = 632334
    text = __import__('base64').b64decode('cU9SbDBKQWdNOVFHdlZRUG9tTEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫχΡΤΖΦλЮХΤыΒΤЬΟξ():
    if False and True:
        _dead_8133 = 970
        pass
    value = 121823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3r0b3Ah+bgBCyv0x3KfBwQl7Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 79 < 0:
        _dead_3889 = 716
        _dead_9518 = 651
    total = value + len(text)
    return total

def _мЪшзρыυνωя():
    value = 116456
    text = __import__('base64').b64decode('dEo1bV9xMDJKbUVXWGluMFBiWEI=').decode('utf-8')
    total = value + len(text)
    return total

def _аΗЕρеΗвыσφЩ():
    value = 766830
    text = __import__('base64').b64decode('a29DVUd2cDJkOURDa0NNT3FqaVE=').decode('utf-8')
    total = value + len(text)
    return total

def _Ξкчρжβσиω():
    value = 496684
    text = __import__('base64').b64decode('SGlFUm5PY0V6YlA5RGdUYjBxY3I=').decode('utf-8')
    total = value + len(text)
    return total

def _СψАδКОΓАХюМωλбТ():
    value = 483422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgXbT2Rr+Y8ibDyNmVmKYRIH9jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иТςτΚΡПЮЦχдγуЧл():
    value = 888935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCfQQmI95p4qayH0xQK/ZSoG5Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гУШΤМΡтУΙбμЗ():
    value = 275476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAO0RV0dz71VGyX673TJGQ4H5kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΑυзчгΔωТδηпΜим():
    value = 855072
    if False and True:
        pass
        _dead_1701 = 849
        631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjfFaG4p8LEWaSCQ8W68LSQqxUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1131 = 376
    return total

def _эΗΕЗЛцГΑΦτ():
    value = 791262
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyPGaUI0yZwxOSOwwFicNg0B9js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9093 = 274
    return total

def _κезмвΘВΣ():
    value = 303808
    if 14 * 21 < 0:
        pass
        _dead_7691 = 807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwLCfQUt6qVbOF2O0VmBIw4X9Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _БαкΕЧкΧРФφοз():
    if len('') > 0:
        31
        909
    value = 22233
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AS78SH8vr781N1+px2+TGiQN018='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _χмΛΠлΛνФХωΚ():
    value = 182425
    text = __import__('base64').b64decode('aUhZTXhBcGFiU3FmWU1tZGpHRmI=').decode('utf-8')
    total = value + len(text)
    return total

def _пЪХПζζЩΩШяΜ():
    if False and True:
        pass
    value = 568646
    text = __import__('base64').b64decode('RTVITFJrUkRJZ1VrcjZMYTQ2cmM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2509 = 640
    return total

def _ыμЙΘκяΦПыνшηΖΟк():
    value = 272501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT3Sa0Up1JBVLyOa7QOvOQ4KvFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ьΛψэΣДΝвαΛ():
    value = 537586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyrmSEJpwapTPwKo7w+YLB0czUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΑΨШцЦъαЛ():
    value = 954566
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQzLZkk9zpkZHgCzmmmWMyEc73Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αмИШрΥИХЬ():
    if False and True:
        _dead_7532 = 962
        pass
        _dead_2029 = 815
    value = 532563
    text = __import__('base64').b64decode('cExoaExGcU1uejF3Mm1SNW1jZXo=').decode('utf-8')
    if len('') > 0:
        _dead_7359 = 502
        921
    total = value + len(text)
    if len('') > 0:
        _dead_9764 = 53
        384
        _dead_6006 = 102
    return total

def _ЖуюκΔкГΦьπВΔРр():
    value = 726756
    if 51 * 53 < 0:
        309
        143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDfXangL1bs3BSWimF2qJw97/mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2153 = 947
        pass
    return total

def _ΕνГбΘрБцНТвыойΘ():
    if 14 * 89 < 0:
        990
    value = 431513
    if len('') > 0:
        _dead_4093 = 442
        _dead_4677 = 916
    text = __import__('base64').b64decode('clBpSE5NZUFSb0JLYWpvT1pjUHM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        536
        _dead_5627 = 637
    return total

def _ишλκЕцΣМъΟΛγЕνν():
    value = 971186
    text = __import__('base64').b64decode('eWhHSmdTSnNaSmdWRGhiQUtQRkk=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _фΧΩдρΞфЭεбКΕΓпλ():
    value = 756800
    text = __import__('base64').b64decode('RmVaRFY5UmdqU0pueDQzM2RCQTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛψΧКвΛΤИЬР():
    if len('') > 0:
        _dead_2053 = 432
    value = 324790
    if 2 * 55 < 0:
        _dead_5830 = 305
        pass
        318
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDvva3QOrY8vCFmKxmWEESYVtFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΟЗωАΨХр():
    value = 55420
    if 66 * 92 < 0:
        pass
        449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyT0aHku+54BAxvx4lfEbTMoz0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        864
    return total

def _кОτкΗщΦЫе():
    if len('') > 0:
        pass
    value = 791534
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSjjSng01pAANSGp0m6aNiMK010='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯТЕκсивЯΟ():
    value = 875331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M33qO2Uu+5taYymGkEGmLRAcz14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γρНΝψυрμДΨδЙ():
    value = 454936
    text = __import__('base64').b64decode('TXFBQTFxeVc5czZWOUJyRWFncWM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6761 = 107
        _dead_1177 = 305
    return total

def _ψογЬНРЛΕΔцмΞКτюй():
    value = 323494
    text = __import__('base64').b64decode('dU52UFJXWWxKSmxSNFdTaUI0Rlo=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΒςβςЖΩНпчЮиЗρп():
    if len('') > 0:
        714
        _dead_6721 = 604
    value = 524516
    if len('') > 0:
        pass
        pass
        896
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwrvSQIYr/o3aSuT+0GULHIV1jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _офИςеБГλ():
    value = 55525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgjpO2Np1YlXPzmB7m/BLTN+z14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШψсρπΠδъсφИкыШх():
    value = 326378
    text = __import__('base64').b64decode('VHpPS09VMDZCX3U2ZkRLVWZzbm8=').decode('utf-8')
    total = value + len(text)
    return total

def _эνжгηΥТЭΘΒи():
    value = 405249
    text = __import__('base64').b64decode('WUk1MV9ZVmk0QUZtT2I1VlhLUzk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7646 = 789
    return total

def _εΚΦΔбΩζχ():
    value = 863087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhi9aVQD6okIDj2P2HiybQ938mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъПΖЭвηОЦзйРэεΩ():
    value = 635525
    text = __import__('base64').b64decode('d1pYNlM2MGxXOVdqclVVYldKSkM=').decode('utf-8')
    total = value + len(text)
    return total

def _зДΟжΤдаΑΘСЦξдБЮв():
    value = 222892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxzGdFgu17gQDViJ/kGjZTMg6Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝлχбГЧψХРШчΤΚΔ():
    value = 389564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR31eFw0y4w2MCqSw3q+OSk9yFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1345 = 59
        pass
        pass
    total = value + len(text)
    return total

def _уΑЙКЧΔΔβΛβиΓибеΣ():
    if len('') > 0:
        pass
        _dead_5488 = 33
        _dead_5731 = 618
    value = 762317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MArDZmA1p7AGBV+05n2JPhQG71c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1948 = 619
        _dead_4951 = 734
    total = value + len(text)
    return total

def _пгЗГΝфйнζшкПχЪρ():
    value = 981463
    text = __import__('base64').b64decode('RkxXVUtpZXdzYkxaNk9Qcm5abFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ТХеьйΛЧСΒоХчЭψ():
    if False and True:
        111
    value = 609334
    if False and True:
        848
        pass
        895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR7daXUK5PorExes5V+dNSgWyDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жыΘЪτАφю():
    value = 946117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgbeXXs16KUubCKw/mCYMzIi93s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        903
    total = value + len(text)
    return total

def _φтЮнΡзцωЙ():
    value = 913168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRbiaEkpzYUaCQbz2weXYxE6/Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τуΗνраяФΔЫп():
    value = 148708
    text = __import__('base64').b64decode('VDA5TVlNc083Smx0THBiVjF1OFA=').decode('utf-8')
    total = value + len(text)
    return total

def _цгτΨБμΓМцζУΣβаλн():
    value = 941904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyTnawg0q7gza1z0n26UFREt4EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΕЙеΘчЮΤζВГ():
    value = 531153
    text = __import__('base64').b64decode('Y2RGWkVmRGd4MzRvSml5SWpLa1U=').decode('utf-8')
    total = value + len(text)
    return total

def _юяЭПηШΥЖЭЛСДΖ():
    value = 335120
    text = __import__('base64').b64decode('eEkzRkx2cE5kckxVQW1OYzM1TnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΖУРсЦΟЖζΗωчн():
    value = 49450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxmxbX4V0IEmPTb6/UyqYnMY6Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΛМζуЧρКΓХζьШНβ():
    if len('') > 0:
        pass
    value = 680226
    text = __import__('base64').b64decode('Z2FzMHcxaGJYSkNHRzJ4cVpOSEQ=').decode('utf-8')
    if 95 * 71 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _чΧΔХсвшБхцвР():
    value = 51576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAbLQgco9/AlIwqnznK4Awci5Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςηΠКυштМЬθΒсλ():
    value = 171226
    text = __import__('base64').b64decode('WHBiR0hjT3E4RWNNcDI3OGE4MTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩЫшпθεмОЪ():
    value = 434522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HX6zWGAt9v8INV+zzlKTZDMH80k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣгуНΩАЛБеΚХ():
    value = 579856
    text = __import__('base64').b64decode('QklqZ1lnWklOeG80VlBnSUU2UU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЦзΩΜλяΡΦйПВδψ():
    value = 184755
    text = __import__('base64').b64decode('azRVSzhOUjltNDNHVEhsWTZwaFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ОλτНΓυгзφςгοσЭО():
    value = 92730
    if False and True:
        pass
    text = __import__('base64').b64decode('b0pQeTFkMjlrdjB3YVFQTjVjaEs=').decode('utf-8')
    total = value + len(text)
    if 40 * 22 < 0:
        pass
        84
        65
    return total

def _МωγςАшΝσИΡ():
    value = 575816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQCxSFkd84xXIims3HqzCxw7wl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧИдΙЫψКд():
    if len('') > 0:
        508
        _dead_2129 = 846
    value = 900510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxjFN3Ig3KEmIiGVylS3bTY5s2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΓΧσХΞШвНΔЬ():
    value = 553188
    text = __import__('base64').b64decode('d3B2X3pISFhXWDRBUHVWSFhIVXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ОгλΠοΕУрχцЯΠΨ():
    value = 215757
    text = __import__('base64').b64decode('eWtkRlFsSHVBdnZ1SEpvYzQ5Uk8=').decode('utf-8')
    total = value + len(text)
    return total

def _КЙбУΙвυψφΨТψюэ():
    value = 354151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSzIa1QA7ZcILB6GnFW2LCEp6jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 96 * 17 < 0:
        _dead_8632 = 363
        pass
    total = value + len(text)
    return total

def _КЮзуξμЖРΒμфхЭΦΑ():
    value = 813378
    text = __import__('base64').b64decode('clg2X21fVVpXVjRYUE16MEw4d24=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟШρτζАЧЕ():
    value = 71900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD+3SlAJ9fgwLQeUxUG4BzAo3jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 16 * 87 < 0:
        _dead_9206 = 749
        313
    total = value + len(text)
    return total

def _РыΔлыЧЫэ():
    value = 625726
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSLBR0Uu7P0CaQ6x+1CCAnN38GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _яωξΙΥэяРяλζΝΘшΜф():
    if False and True:
        507
    value = 208210
    text = __import__('base64').b64decode('TVBKaXBnTFY3c2JUMGpKQjY0MFM=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if 92 * 57 < 0:
        _dead_9858 = 452
        _dead_4912 = 93
    return total

def _ПЙσжШυеЧУчачь():
    if 32 * 9 < 0:
        pass
        27
        pass
    value = 263616
    text = __import__('base64').b64decode('c2dpeU9PQVVob2EwMmhSNUpzb0Y=').decode('utf-8')
    total = value + len(text)
    if 97 * 47 < 0:
        pass
    return total

def _ΦЮИшыЬЧДθпξωГΗ():
    value = 726220
    text = __import__('base64').b64decode('VkNHamdOeG44UUZ2ZTcwQlNrX1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _МЪΓужεеαДπЕПρΙ():
    value = 720546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxXJYlY1yIIVKhr6zEGVPXF6tEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 63 * 36 < 0:
        _dead_2071 = 593
        _dead_3127 = 451
    total = value + len(text)
    return total

def _аαаΞφдеЙгΓζлσοΘП():
    value = 749559
    text = __import__('base64').b64decode('bmtYRFlMREJwVXI1TXRQbVJnakw=').decode('utf-8')
    total = value + len(text)
    return total

def _юЛБСЙхуπ():
    value = 685602
    text = __import__('base64').b64decode('Z2ZFWUoyNklwNlFyVjloRVFHX1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ОφΗОЯΔЕСρθШкУ():
    value = 849649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyTRPXUv07AINzuS+EK8YzB49no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιФΔлЗрВψσΦΧкюωТβ():
    if len('') > 0:
        864
    value = 424537
    text = __import__('base64').b64decode('a0pjNTV0UTN0YnFqTWthQTVQR2o=').decode('utf-8')
    if False and True:
        _dead_8479 = 326
        285
    total = value + len(text)
    if False and True:
        pass
        262
    return total

def _ιаωлγоλнραзπ():
    value = 201388
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASDzP0E97rolbySFnAa+Zws251o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜпΣΘΗУБюЛТЩыβΣСф():
    if 89 * 18 < 0:
        pass
        pass
        245
    value = 506668
    text = __import__('base64').b64decode('YUkyeHFfbEdHMVVVT2Viblh0aHk=').decode('utf-8')
    if 89 * 38 < 0:
        _dead_4979 = 382
        pass
        809
    total = value + len(text)
    return total

def _ΩПθβхьЗΖΕ():
    value = 491758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBzvRGIr/ZkEKx2763GgMTF4sFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЧωΠωПРΝ():
    value = 633017
    if 4 * 31 < 0:
        _dead_4903 = 980
        pass
    text = __import__('base64').b64decode('WHZjYmZjU3Q5akFfNHRqdWkza24=').decode('utf-8')
    total = value + len(text)
    return total

def _иοШахψаудкΧ():
    value = 590620
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQ7IfAkN1bwAMQ6p3mDDZjwc/H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АτБξφдСхЩ():
    if 96 * 38 < 0:
        pass
    value = 471139
    text = __import__('base64').b64decode('V09uZjlNWDlBMFNNN3FtYkxYNmI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9021 = 833
    return total

def _ФчηНДηΧςы():
    value = 744566
    if 83 * 10 < 0:
        pass
        pass
    text = __import__('base64').b64decode('SGJSMnFDZzQ1X1VUWElMTnRadk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠШсГινпхΝχЧЗ():
    value = 976859
    text = __import__('base64').b64decode('THJzQnl4bU1IUlIwTHFkYU5XTVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥРκЮНзαХо():
    value = 715644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bze9b3YMzKVWFgmrn0TGLXAm6mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗЪБАПΧЦιПεξЫμЙ():
    value = 449706
    text = __import__('base64').b64decode('cTZrUlNpTXNxbXpWcmk3c2Q3RHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _γΣΜЧядВЬψΞЛ():
    value = 204441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwfuOl401fkBMCuQ+1mIZCoN0V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ГΑюдвγщбе():
    value = 336074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDvrWmMfx54kCzz0nFi4Lgoc12I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _взΒиеΣΔбэыпθτΓμΩ():
    value = 268540
    text = __import__('base64').b64decode('SFlrakZSZHdBckQyRGRibmdrcXY=').decode('utf-8')
    if len('') > 0:
        252
    total = value + len(text)
    return total

def _МψыхЮоοΖ():
    value = 623670
    text = __import__('base64').b64decode('UE4xYTZqUzFvbzdLdkIxMmowaG4=').decode('utf-8')
    total = value + len(text)
    return total

def _υτШЖΔЮΟΙЫ():
    value = 24039
    text = __import__('base64').b64decode('ekc0ZWY3SFlHQUZmVnUxTTNFM2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓυЦПНФБκτ():
    value = 577726
    text = __import__('base64').b64decode('aHpURjM0Q0VuNldzWkltdlpNMjM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        567
        pass
    return total

def _πιδЧσмΥЩХχЗ():
    value = 126891
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxzvfl0XxL0lESmy5EOiInEiyFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΧΙГьΦεηя():
    value = 954775
    text = __import__('base64').b64decode('Z0UxUFRFS0lHT2NIM2xNTF9JdFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЕКчУθЭНЯФН():
    value = 60756
    if len('') > 0:
        pass
        _dead_4179 = 9
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgTwSlwfxpJbK16R4k63AXIkt3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЗΨΣχΜγБ():
    value = 860913
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx7xd1Af55FSIl+umHC5PQIAw0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МчоνызчΖщπгΑξъч():
    value = 51617
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mji8RXBup4kIby6UzHPDYyMW5T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙмШυьНкξиО():
    value = 85010
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQnxRlwg/L0MNBmlx1WSBzUJ3lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щεΦвσРвйХωζсΙ():
    value = 391138
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB7cXGI0y/9VICmS/kykIxB98V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нθЪуоЪшФρβр():
    value = 388688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgriTX4byZw1KCOlzEWmHHMg8Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΖКсΗЩЫζοΤДА():
    if False and True:
        pass
    value = 110014
    if False and True:
        pass
    text = __import__('base64').b64decode('T2xrcktfb2xFcl9zZUVmdjlMUE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΡшЖЬюσΖ():
    value = 100556
    text = __import__('base64').b64decode('bVRyQzdDSDJIcENzamdGb1BxRGw=').decode('utf-8')
    total = value + len(text)
    return total

def _эρСγΤЙΒНμШАшЙ():
    value = 85639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSqyO2ER7a5WMlv0nHieJR8dyFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚλγσΝΗμтξн():
    if 82 * 74 < 0:
        296
        _dead_3714 = 320
    value = 107408
    text = __import__('base64').b64decode('eFlJOWhRV0h2OVZKRERFUEV4ZDA=').decode('utf-8')
    total = value + len(text)
    return total

def _шζкЪоΚηνГмΑЫαвΦъ():
    if False and True:
        _dead_6455 = 384
    value = 925112
    text = __import__('base64').b64decode('cjZlTjNMcnpLbXhNWUZON1RycVM=').decode('utf-8')
    if False and True:
        816
        pass
    total = value + len(text)
    return total

def _уНΞβсυЛς():
    if 87 * 33 < 0:
        479
    value = 241407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhXtQXc4/7Ibaimhm3ODHAAZw2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 72 * 75 < 0:
        192
    total = value + len(text)
    return total

def _ΑΑфСЧЧιχ():
    value = 923856
    if len('') > 0:
        81
    text = __import__('base64').b64decode('aXJEV2VSWGtfTmFLUk9DMkdwVHY=').decode('utf-8')
    if len('') > 0:
        pass
        410
    total = value + len(text)
    return total

def _зБρВδЮпτб():
    value = 567094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXj+QWcr668CbgP3xwOHNhonyzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЗЗгΘΤηГРΙШα():
    if False and True:
        pass
        pass
    value = 698232
    if False and True:
        311
        308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwLiZGYG3KcBCgygzECRPzMO12g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 45 < 0:
        551
        289
        117
    total = value + len(text)
    if len('') > 0:
        244
        pass
        pass
    return total

def _юШοСУртЬΗ():
    if False and True:
        _dead_1931 = 525
        _dead_2608 = 28
    value = 953871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CA7eZmEc/KQRNSiA2GPGBD0uyHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚφЮΩζиЕΒΥξΒλГеσ():
    value = 108754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AirQeEID6q8nMSyOy2KdIRU6034='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 14 * 23 < 0:
        _dead_1422 = 2
    return total

def _ВΘзΑвΝьПξэш():
    if len('') > 0:
        pass
        pass
    value = 687104
    text = __import__('base64').b64decode('WDBZeUdJM1FkYktpc1FJakVuZ2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ωψцεΧΡХчГτЩμя():
    value = 183457
    text = __import__('base64').b64decode('T3l0MFRYUktEWFk4V0RyblNtZW4=').decode('utf-8')
    total = value + len(text)
    return total

def _βΥсΖткΧσαΘςАςв():
    if len('') > 0:
        pass
    value = 219818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mxe0PV8o9vwoFyuT+QGnHjcMt1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щνΡзАеекиГц():
    value = 232679
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwW3eQMD9aQwOC6mkFO1GB8392A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωхгуΧεИΣΣЪЧеρ():
    value = 55155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBizT2lh2YwWaQW68GmdYRErvGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯГΡУιλкдгл():
    value = 609362
    text = __import__('base64').b64decode('RWQxVXhOcVpQUVdmekFJdDBNbHg=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _сФаγаΚуΜЫРяΘα():
    value = 667977
    text = __import__('base64').b64decode('aVhnX1U0TVVuNWZnazY5d3YxMkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ВδθвπуГЪщΨΗ():
    if 49 * 15 < 0:
        pass
    value = 326363
    text = __import__('base64').b64decode('a3ZfbkhnY1J2WWZBa3dwR1A2Q1k=').decode('utf-8')
    total = value + len(text)
    if False and True:
        928
        921
    return total

def _λΩЩΞсβАщлΩШчΖ():
    value = 626904
    text = __import__('base64').b64decode('SktJOHFkRGNPb1YxOHJVdEpBSjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ШяЙИλВΡЮШЛЛΒ():
    value = 111770
    if False and True:
        315
    text = __import__('base64').b64decode('WERHc1phTF9HVTVvVnNkUmlWYV8=').decode('utf-8')
    if 58 * 94 < 0:
        331
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('IA==').decode('utf-8'))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()