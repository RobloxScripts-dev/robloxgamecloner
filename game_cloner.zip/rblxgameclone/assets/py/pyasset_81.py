#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ςЫпШсоаςЪ():
    value = 445277
    text = __import__('base64').b64decode('Z1hWc192a1pFMk5LQzZDWUpLRUM=').decode('utf-8')
    if 59 * 70 < 0:
        142
        pass
        607
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _αφтθмПΨσπηПΘλциы():
    value = 694051
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH3QVFodrqUqERmA+WyTOg875zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΩοПΑбΚПоЮыМ():
    value = 989030
    if False and True:
        145
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABboZ24Uq7sbMhWN7XSpMC0E72Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        11
        _dead_7451 = 952
    total = value + len(text)
    return total

def _ΣτυκТЖΛы():
    if len('') > 0:
        _dead_3030 = 432
        _dead_9098 = 121
        511
    value = 105496
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('eVc4eEpVQnc5VWFjZ3ZyVmUxVV8=').decode('utf-8')
    if 16 * 76 < 0:
        pass
        _dead_9149 = 173
    total = value + len(text)
    return total

def _ΛΚΙыгЙΩΘеιΣЩΨфΟ():
    value = 947889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzXURAgv/KYkaQm693vHPScX9jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8683 = 634
    return total

def _ШъиЗЮнλпλΚπЧΟЛхи():
    value = 525294
    if len('') > 0:
        719
        781
    text = __import__('base64').b64decode('aXRXOERCX2tZV3JXRTBPbl82V2Y=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7974 = 883
        _dead_6322 = 509
        _dead_6329 = 696
    return total

def _ЬЕΞДφйτкКΗ():
    value = 162240
    text = __import__('base64').b64decode('dlh4VXl4T0NFZU8yeG55Q3MyZmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤОЗъюХЧΣъ():
    if len('') > 0:
        _dead_7587 = 245
    value = 347230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jxy2SXsP+ZoMHyCw3kG/AhIn8Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςгйпкеСΓτДΗΑО():
    value = 663447
    text = __import__('base64').b64decode('UDhIZ1lfNzZRQl83RkQzZjVqS2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤфцЯιнЛЮτΠ():
    value = 881347
    if 38 * 3 < 0:
        pass
    text = __import__('base64').b64decode('VzFMU2JRNWJ0RUJHVVdnMm5lSWc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        794
        915
    return total

def _ξαρНжкτζΧκХЖЧζ():
    value = 242004
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzzRP1kWyaBSFQaw/FqXIx0/ymI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υοтЖФΒтьцγΖ():
    if 45 * 34 < 0:
        844
        972
        27
    value = 653707
    if False and True:
        _dead_9009 = 320
        pass
        pass
    text = __import__('base64').b64decode('V0F0SlpNenBUTEltUkJsQjdPZkE=').decode('utf-8')
    total = value + len(text)
    if 38 * 53 < 0:
        _dead_5322 = 831
        _dead_2371 = 866
        _dead_5124 = 46
    return total

def _ΛφВΞυжΥε():
    value = 822412
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izr8SGgay4EqNVig/AOeAx0Cw0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΣΛЖЮоЖрБΨХсνиγ():
    value = 490606
    if False and True:
        _dead_1360 = 911
        14
    text = __import__('base64').b64decode('dGJKMnNiaGJ0ZWpWdHNPNmJ2clg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚМΔΟЙηаΔКΡл():
    value = 977012
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXrSYXhu2fg1MySE0GmAMCMO4kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 16 * 22 < 0:
        _dead_6350 = 801
        289
    total = value + len(text)
    return total

def _ЙюχеΖΛАмИΤ():
    value = 970679
    text = __import__('base64').b64decode('a1RsVVY2NE1xUl9vaXMweU44VEw=').decode('utf-8')
    total = value + len(text)
    return total

def _аЭщΡΒιΚθοпвмИ():
    value = 988269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ijv9XwUuza4gbh6S/nWxZAI/w2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жВθпΚμЬпσВьΞГчц():
    value = 232773
    text = __import__('base64').b64decode('UDFJMUVvVEZOUFFfdUI5Um80X2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _еЙьиΟτтΚΗΘЭЩΒ():
    value = 601228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjznaF1u97osCA7xxGO7GDEMz2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 36 * 33 < 0:
        pass
    total = value + len(text)
    return total

def _оΥΚцБЙгеΧыΘусъ():
    value = 679934
    text = __import__('base64').b64decode('cGFvVmoxQVBhY1hvQUU1RkE5WGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧСφηκκцж():
    value = 297742
    if False and True:
        _dead_9561 = 3
        _dead_2061 = 182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHzMdmk71Psqawj2+m6kHxQJ0GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 51 < 0:
        pass
        724
        540
    return total

def _ИыΞЖΝэΩР():
    value = 485212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRXvPEMY064BNTq270S0BXUntkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЙйΔпиΑΡеΤ():
    value = 497693
    text = __import__('base64').b64decode('YWxJN3RmT2VkWWNram84dXo4WHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬюЛΜγПΛчСφФхδωФУ():
    value = 597949
    text = __import__('base64').b64decode('c3AxN2JwSGF5MTUxZjFQR1gySE4=').decode('utf-8')
    if len('') > 0:
        _dead_1675 = 204
        400
    total = value + len(text)
    return total

def _ΗщьμΙТβФдΟΤДΤЫ():
    if 100 * 76 < 0:
        pass
        494
        351
    value = 916927
    text = __import__('base64').b64decode('V2dsMjBxMzZIT1hOQ0hHMEljSVI=').decode('utf-8')
    total = value + len(text)
    return total

def _дμМрауПМТкм():
    value = 644586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cz3QTFYz8I03MF/z3mCcBTIEzjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3437 = 0
        pass
    total = value + len(text)
    return total

def _ΓОυхΨЛοдпьφΞ():
    value = 711373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTXTPn0/wY0GajuGz0ynAxcu4lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        729
        242
        287
    total = value + len(text)
    return total

def _κλрΠиΝταανβдΧ():
    value = 610081
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ajm8O2UM+ZswbBi63n/AJh8H810='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рШфЯΑπКяХδЭе():
    value = 71369
    text = __import__('base64').b64decode('el9tY1dFdWt6SUNZQzNkZUo1bU4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        659
        _dead_3407 = 994
    return total

def _БνРΥιβогйОЮΕМΩ():
    value = 497038
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ahv9Z3sM8oASHFes6k/EHAIa0Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΝтМхμΒχБУжН():
    value = 923794
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjaxT2Ic1b0RPlqowHWGDTYI3l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟкЧΘωдτжЦС():
    value = 332637
    text = __import__('base64').b64decode('VkpOdWVfZ1UyM3lXUUk4TXp5WDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕЩЦвШУжβОЭ():
    value = 983680
    if False and True:
        250
    text = __import__('base64').b64decode('aDhyR3J2WWVvOHV2UEZhbG9JcE0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8321 = 179
        29
    return total

def _θъщЦχχнщμЬΗж():
    value = 737274
    text = __import__('base64').b64decode('TXlLR2FJWVZDZlFIOTVXc1E1OTc=').decode('utf-8')
    total = value + len(text)
    return total

def _υхуΥθрЮοсΡсГЧрц():
    if False and True:
        _dead_3004 = 242
        _dead_3946 = 858
        pass
    value = 871232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fj3XREhp6oYUDR6M2E7CPjEXsF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σшξХжωΔдв():
    value = 395172
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH7LYQkoxIIHIzyW43WKLSku3W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        68
        748
    return total

def _бжФοрЮПςςРыφΒМвд():
    value = 160931
    text = __import__('base64').b64decode('RmtfQl9VUDdpRXVaSTFKNGlvWEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΘЮуσщУхΧπβуιΟΩχ():
    value = 642997
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj61YQkt2IwZbiCb92mbZigovFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥжχбΩΚФκЛλπшκ():
    value = 937259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB7SP3htzvkkEyyA93yEGyc9yDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НсГΠВХζФьлΒлδηЦъ():
    value = 89677
    if len('') > 0:
        _dead_9485 = 19
    text = __import__('base64').b64decode('ZXlSaHdCWmpJbmc2RndsMmJNdjI=').decode('utf-8')
    if len('') > 0:
        914
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ηρΨЕΕΤОχЭЭΡβΑпЖЖ():
    value = 956156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3vSTUIa2pEMaD6EywSJJT8L9Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НλЩΘΖΥСΨΞαΡνпεΥ():
    value = 577105
    text = __import__('base64').b64decode('bk05dWJJYlVNUFJKSkZCVXpCTGY=').decode('utf-8')
    total = value + len(text)
    return total

def _еХΝКγЧЗчνιν():
    if 11 * 76 < 0:
        _dead_8080 = 942
        _dead_4634 = 68
    value = 487581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyLxXAEhpqARBS6J/VLIPjMd6Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 90 * 44 < 0:
        _dead_3325 = 292
        _dead_6090 = 59
        214
    total = value + len(text)
    return total

def _МруЙЪоьЖ():
    value = 919741
    text = __import__('base64').b64decode('ZTFsMERXb09yRE9GcDhieVNTaGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯαΡγΞНωδАСΨцкй():
    if len('') > 0:
        pass
        _dead_3372 = 215
    value = 36688
    text = __import__('base64').b64decode('b0FEbEduRmV0Zlh6dVY1WHJIeVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ВщηГσчρцνнъцΝш():
    value = 486954
    text = __import__('base64').b64decode('UXRJbjVKOUVsV2VIb0NWWHVYRzA=').decode('utf-8')
    if False and True:
        pass
        _dead_7975 = 53
        588
    total = value + len(text)
    return total

def _ξзтЩПΑЯфМгбβАА():
    value = 229556
    text = __import__('base64').b64decode('WWQ5X1hxTEpOaGk2ZmJQTHR5ZmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ХηΗΑυвшчοжΨ():
    value = 835186
    text = __import__('base64').b64decode('QUdKUHg2WE9GaUxqVWpOZUJ0aUc=').decode('utf-8')
    total = value + len(text)
    return total

def _юβΞСКРзηζъ():
    value = 461061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyPMYwY1wfgoMQ6q90G0AAM112A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _хΞΓВΜΘΖфэκЪΓΠзΥ():
    value = 561621
    text = __import__('base64').b64decode('Znhmc3oxRHF4ZEgyRWFQNUZPRHA=').decode('utf-8')
    total = value + len(text)
    return total

def _СΚΓоχвБимАаБ():
    if 40 * 96 < 0:
        143
    value = 792163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxX2NmsozbtWEQeWwH+VZBEVs3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чιξΝΗОΤиπ():
    value = 155796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IizoegYUrZkQPVihwme0JBA5wkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РбхЫοкТκи():
    value = 126549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj3+a0spxPpbCi2lkXzJLB0A2zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΓбоτПоАμЯзΟЙ():
    if len('') > 0:
        _dead_5466 = 58
        279
        371
    value = 443025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PATLS0Fh8oFVNDWczAamGw0rt34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9959 = 669
    total = value + len(text)
    return total

def _ΘΒΔΒХοъΣЕвΜЪНΖэα():
    value = 598308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxroYHM1/7EvKlaWzAGEIhUc/GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩωЬκфςΣβЪшρнымΖ():
    value = 593859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCfydnsJrfAuaBf30ES3BQ931mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 68 * 13 < 0:
        275
    return total

def _ЖЯуЩяИСзтРБσ():
    if 84 * 63 < 0:
        pass
        _dead_2364 = 219
        pass
    value = 802660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx/pZ0YSxLk7Ciih436AYxMj5kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υИщгΟняЭφπλТΠΒφΧ():
    value = 742263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hwzhe0cN+a9QL1qE5Q7IOB8A6jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΨОΛнОшйпжγЭПь():
    if 71 * 51 < 0:
        _dead_8443 = 18
        pass
    value = 803636
    if 50 * 11 < 0:
        936
        722
    text = __import__('base64').b64decode('eDB6dnFuU242ZVhfNElFQWZDY0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _зпКνΦбОнο():
    if len('') > 0:
        pass
    value = 321949
    text = __import__('base64').b64decode('SlBaQnVUeGNyVTBmU2ZJMDVXXzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЯЦАнТбю():
    value = 652517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASL2WnoG/YoaPzeRmk+hHCwMs3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВКсΝΗυоЖ():
    value = 39883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSe1UVph6ZEsLymRmHOVGBMQwT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 100 < 0:
        _dead_5621 = 766
    total = value + len(text)
    return total

def _эΚРфЩгτΛЯй():
    value = 864660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PADUR0cgp6ISbSuI5E+EJSh2sns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БмщЯБМщθιγЕ():
    value = 938928
    text = __import__('base64').b64decode('ajJyTHVUeDdzMmk3UE1yS1Fnc0g=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9886 = 674
        pass
        999
    return total

def _ДонШШоЦхσхρ():
    value = 955000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwqwTGY89LswChuM0F+BDBU141o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нκвςиμςгбβЧюΚΨ():
    if 8 * 39 < 0:
        _dead_6883 = 851
    value = 467809
    text = __import__('base64').b64decode('SXI5SWNUdkFYRURpdHZ5MlN2UFM=').decode('utf-8')
    total = value + len(text)
    return total

def _хИХэПжφшΟзвеγ():
    value = 721970
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBvhSmkU/KIrDVix3lecFhYdvWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μημАπТнЫΚ():
    value = 715659
    if len('') > 0:
        935
        pass
        _dead_8432 = 846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESHuZW4g0/EaCgjx3kODYDV+8Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩУЩΒШТиφЦчМΔВΥμ():
    value = 199978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXbmOHto54subSSl43yJARM//ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        624
        _dead_4137 = 483
    total = value + len(text)
    return total

def _ΚΦаЬιаЗΚСΞΡ():
    value = 269254
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAXjdkkLwfE3Ehak3w6bAxY8zVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОρΞПмеΓσЪТСΦν():
    value = 307247
    text = __import__('base64').b64decode('TkpNczk5dXlQeE1SZ2oxTG1OSFA=').decode('utf-8')
    if False and True:
        _dead_1160 = 799
    total = value + len(text)
    if len('') > 0:
        353
        498
    return total

def _τмΠΛкГΛΦ():
    if False and True:
        pass
        682
        pass
    value = 594220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTnFQn8B76ctFwCH7Q6KYTwC62w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        861
        296
    total = value + len(text)
    return total

def _ПΒυλнΞΟαηΗАΕΖΘц():
    if False and True:
        _dead_4019 = 419
        _dead_2477 = 503
    value = 294871
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCDcVwk86oRXLBaw+1qjNRoa8mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗЙΦКλΟΑнεйΓщыЗΙ():
    value = 747757
    text = __import__('base64').b64decode('Um4xSXhaUmhkaG00RXRwaTdQTVA=').decode('utf-8')
    if False and True:
        472
        567
        900
    total = value + len(text)
    if 68 * 7 < 0:
        pass
        231
    return total

def _γΣгуπяψΟЗЯ():
    value = 272459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCnmb14o0f1aEFnx6njIYBAt5WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        751
        494
        pass
    return total

def _ЛνюдюЫПвωΥα():
    value = 20764
    if len('') > 0:
        pass
        735
    text = __import__('base64').b64decode('akljVFVVTlhTWHNXYzhxNWxxZkQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        193
        pass
    return total

def _нδВθоΦаΘ():
    value = 120929
    text = __import__('base64').b64decode('akFBdlB5TkJKUlZwOXp1aVN4U3o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        202
        _dead_3439 = 913
        507
    return total

def _κФμθбνΛЫС():
    value = 428533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fhi3a3M+3fAMEhWymlOWDAMnzmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        406
        pass
    total = value + len(text)
    return total

def _Μρанажδν():
    value = 669362
    text = __import__('base64').b64decode('THBNS3UxQ1N3TGdYcENfM2VSb0E=').decode('utf-8')
    if False and True:
        _dead_8200 = 397
    total = value + len(text)
    return total

def _ΗцχЗМΛБяΕЙ():
    value = 19945
    text = __import__('base64').b64decode('ZlNPa1JESmZ5NFVhMmw0T2t3cGE=').decode('utf-8')
    total = value + len(text)
    return total

def _аΚНпζЦМъ():
    value = 604602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzX+SFs99owBGAyFnUPINQwtvGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2839 = 142
    return total

def _φгΘМςбΔап():
    value = 422250
    if 26 * 67 < 0:
        663
        532
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAD3N0IQ8asSHSKG4GmnBQcu6Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чцОΨιμЬпТΩΚ():
    value = 917744
    text = __import__('base64').b64decode('c3hjTVhWNVVQNlFyT1c1X21vdlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛнсνтИйЮδШΙпВσ():
    if len('') > 0:
        _dead_2072 = 284
        704
        403
    value = 634582
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nwzjd1QA+LgzbxuX72C/ATcb13g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        477
        pass
        pass
    return total

def _πΔжЪρΣΗΘΠγКΜο():
    if False and True:
        pass
        _dead_6615 = 706
    value = 818151
    if len('') > 0:
        _dead_7308 = 298
        810
        _dead_8169 = 999
    text = __import__('base64').b64decode('QzF0UjM5dnFMa3R5OUhkcjhkeEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ГьχОшжЭβφΕ():
    value = 715920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBWyX1UMxrkoaVb20GS7FgkW7Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣμΑЕьΨлПανюχπгРЙ():
    value = 508343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyvCPWUG9IwmKhiPwHe6Yj8B7zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 10 < 0:
        78
        _dead_1500 = 922
    total = value + len(text)
    return total

def _φзлсСцφωДшктэ():
    if len('') > 0:
        pass
        _dead_7280 = 135
    value = 983800
    if len('') > 0:
        593
        pass
        _dead_1789 = 196
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSCzZFg7zq9WLD+C6XSTHw0Hs0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 17 * 8 < 0:
        _dead_8193 = 27
        _dead_9307 = 370
    total = value + len(text)
    return total

def _ξыτσхХωЬεгεзφя():
    value = 618489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBjXSAgrp6syEietwXTJPnN572o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΚЩТΟииμΞшθу():
    value = 340371
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyzFREs8054KCD2Uxni6bRI55WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8465 = 420
    total = value + len(text)
    return total

def _иηМьСБюДφΑΒηнйй():
    value = 701963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSC2awI26PlSNSSEwXmiOBMlvEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦмλАаПΨИхж():
    value = 14297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj7GXgdv/J5UCBmGn1fHC3ABx0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цфηеρЪΤΜΔь():
    value = 752406
    if False and True:
        _dead_4764 = 271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR7TXWAK1KY2KSOX51qdBRwN7ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 19 < 0:
        _dead_7401 = 933
    total = value + len(text)
    return total

def _ρζΟδΕИШГЯΔКж():
    if len('') > 0:
        pass
        492
    value = 152942
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCfgf0cb+oIBABiCwAGEZH0Kwlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 95 < 0:
        pass
        _dead_3641 = 633
        pass
    total = value + len(text)
    return total

def _ЧрΩфэΞΙξЦζъТшу():
    value = 784224
    text = __import__('base64').b64decode('TXdFNEtVMmFSV1UydDBsRG1obXA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫψΛЪзΛεаΕρθΟРХ():
    if False and True:
        pass
        pass
    value = 375800
    if 54 * 99 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRn2XX8ep6omMFmuwVqFNnwowkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АГЖΗΕЬРк():
    value = 286895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICP1TXk99YwtaiOJx1XCO3YZ22I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γкЧΕрЛОЫИнЗП():
    value = 164851
    text = __import__('base64').b64decode('Z1RjMmlZWmF5bWI1WjNXYjRpdmY=').decode('utf-8')
    total = value + len(text)
    return total

def _υΙΤЩжуДγΧ():
    value = 201610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA3wQlwb+PFUaSug6l/BOiEKyng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВθВξЩΜΕъБЬδЗлПΧ():
    value = 561541
    if len('') > 0:
        638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjrlSmUI3asNACm32lOfGwF3tF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СэЖΥωτбТЬ():
    value = 342614
    text = __import__('base64').b64decode('UzBHOElqX25GZEJwWEFiQW00eHc=').decode('utf-8')
    total = value + len(text)
    if 77 * 66 < 0:
        pass
        _dead_2867 = 663
        431
    return total

def _УюКэαΚΕςТЦιηьГΤо():
    value = 251385
    text = __import__('base64').b64decode('RmVySFpyWjRVOEJKNG1NMnlRb3Y=').decode('utf-8')
    total = value + len(text)
    if 2 * 14 < 0:
        pass
        _dead_2536 = 341
    return total

def _зΒПΛΓγκРΛЕпСтΣΕы():
    value = 364469
    if 48 * 16 < 0:
        846
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQfITHc6xvgOCgm1/XelMhAq1EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МкдФьθσΩΥшАЙНй():
    value = 480173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwjbRUI//YUPFCaByVunOhIiwzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИПΖЬωтΗлδνιπЯ():
    value = 324374
    text = __import__('base64').b64decode('RWFWdzVVa0VZOWhLNHRvVGdJN1E=').decode('utf-8')
    total = value + len(text)
    return total

def _УιβсΛШъРБπХ():
    if 65 * 13 < 0:
        358
    value = 346364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyzIXmQI1J9TMle2906JJS0gy2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        681
        983
    total = value + len(text)
    if len('') > 0:
        939
    return total

def _ΣΚΘЭЛΜуΩΦΕΚ():
    value = 88428
    text = __import__('base64').b64decode('ZGJsOENzWmhlbTlJRndlVjBjZUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΚτΛΧЬбΥΟοйУяζу():
    value = 882448
    text = __import__('base64').b64decode('djc2UzFfX29nbElDYzNuX1dPUFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΕΡΒЗЧзΜДо():
    value = 736319
    text = __import__('base64').b64decode('cDZxTjZSM3RtVFZGbk5aYk51Zlk=').decode('utf-8')
    total = value + len(text)
    return total

def _арΗтΕφβсΑСОρη():
    if 30 * 2 < 0:
        790
    value = 820138
    text = __import__('base64').b64decode('VVpsZ1IzRXpqbzdTZHBCYW82SHk=').decode('utf-8')
    if 59 * 78 < 0:
        _dead_6512 = 482
        _dead_5584 = 446
    total = value + len(text)
    return total

def _ρзФιΩμьΧюМГχам():
    if False and True:
        468
        _dead_1871 = 103
    value = 976614
    text = __import__('base64').b64decode('QVZadEM2SlJyTVBmUXBid1J0NHo=').decode('utf-8')
    if False and True:
        735
    total = value + len(text)
    if False and True:
        pass
        _dead_3445 = 776
        _dead_4515 = 884
    return total

def _νυΒκфОΤкЦ():
    value = 786311
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnnrYlQ0+6BSPj+V4362HXMB/Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1216 = 884
        _dead_3289 = 438
        pass
    return total

def _ΚΟфРЦОηьκЧър():
    if 35 * 55 < 0:
        pass
    value = 299570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KijCb2Uz3IMJP1qv+1SmPhcot3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΓЕДШАВуλвЬχΠЖуЭЧ():
    value = 675162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDvdRksXrZAVLAan+VK2YSsm1kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7683 = 218
        805
        995
    total = value + len(text)
    return total

def _κпЫкΤθαл():
    if 81 * 12 < 0:
        _dead_9376 = 633
        _dead_7903 = 138
        555
    value = 733846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MA3FYnM9wZkUKV2wwl2hMAQe6Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 56 * 13 < 0:
        pass
        381
        679
    total = value + len(text)
    return total

def _ΣΑяЖРчцυΘрδχζ():
    value = 84964
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NX7tRX5t2bsqIh2EkEWKIi4+6TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 75 < 0:
        _dead_9182 = 642
        pass
    total = value + len(text)
    return total

def _ШΘщΜйΞТЧУе():
    if 27 * 13 < 0:
        pass
        _dead_6585 = 608
    value = 185620
    text = __import__('base64').b64decode('VF9NVlVBbUxXRWpLYVJDeTVVMUY=').decode('utf-8')
    if 14 * 97 < 0:
        _dead_1721 = 939
    total = value + len(text)
    return total

def _лГййСВЗкΧωβоαнЭс():
    value = 421572
    text = __import__('base64').b64decode('dTdDRVVjZHduMmNnNXJidnJONTk=').decode('utf-8')
    total = value + len(text)
    return total

def _мοΦΙЦΚОиΦμοστνΖ():
    value = 804168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj7qSkQb0o1bHi2KzmayLCoZs1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟНгЬФКЮДμ():
    value = 128588
    text = __import__('base64').b64decode('S0tXbHZqcFdCY0JGZzhMQ3A0dUo=').decode('utf-8')
    total = value + len(text)
    return total

def _βпΖЭνРЖЙЧΑк():
    if len('') > 0:
        _dead_5727 = 358
        pass
        _dead_4771 = 159
    value = 193961
    if len('') > 0:
        pass
        _dead_3398 = 157
        pass
    text = __import__('base64').b64decode('ZklXSk0xYjJZVlJWNkRDUm9XdGQ=').decode('utf-8')
    if False and True:
        886
        pass
    total = value + len(text)
    return total

def _бΡΛпжτфЫ():
    value = 135495
    text = __import__('base64').b64decode('QkRGMmI4WFJEakNGcWg4S0FrQnE=').decode('utf-8')
    if 92 * 48 < 0:
        pass
    total = value + len(text)
    return total

def _λИθюγНΨΣΤлршэЪΜЪ():
    value = 522349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgSyUVY2xKYGMwuL+VKpMwcWtFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гхжκΖЪΘλюЧνнΗ():
    value = 667646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR7uQAYj8aYab1uU+AGJJiA36HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟСРρΞσЬЧ():
    value = 457631
    text = __import__('base64').b64decode('WGhaOWdGcjdFQnhDTHh1SWRQQ1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤφωпЫзАц():
    if len('') > 0:
        _dead_8533 = 58
        405
    value = 525680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD7BbUEv8JBUCQCL0mmREz8Zynk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьшнρΥОфΕРτΡ():
    value = 38236
    if False and True:
        _dead_5175 = 449
    text = __import__('base64').b64decode('aUdkWGN3WmJ4MXU3RHdSSzc2M3c=').decode('utf-8')
    total = value + len(text)
    return total

def _χΔΦΞλЫЦхэЕ():
    value = 816486
    text = __import__('base64').b64decode('QXdRMTJueU5hVUZVREdTWG1QOXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ОшξεΤсфюпχ():
    value = 193702
    text = __import__('base64').b64decode('dnFSbDdBbl9aV2o2S180MHpjaEI=').decode('utf-8')
    total = value + len(text)
    return total

def _УΩшЗΩεςТМζ():
    value = 246473
    if False and True:
        pass
        937
    text = __import__('base64').b64decode('bUVCNEtJbnlieG12d19uZ0xMSmI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        270
        627
        _dead_9328 = 89
    return total

def _ЙСЭΙυνЛЪИ():
    value = 842162
    text = __import__('base64').b64decode('TFNSeDZkQU5VV0x4ejJaZDBnRnY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1285 = 658
        _dead_4388 = 466
        456
    return total

def _ЮЕциыЯΞКы():
    value = 362870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ij7zeQEW7IITFCq1ykyCEzEM72M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 7 * 56 < 0:
        _dead_9740 = 586
    return total

def _γηΨИачБзАηΝЖΚФР():
    value = 848574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjf0fn9u1LsybFmkzHGBBy428zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΣжгΒθΧб():
    value = 9189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITnef2hur6UFbTq592aDGHcn3kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φуΑвИΘУωΑΣωΖΨт():
    if 79 * 60 < 0:
        pass
    value = 166085
    if 89 * 85 < 0:
        pass
        pass
    text = __import__('base64').b64decode('Um15OTl1Y3BEU3M4X0h2ME4yaTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ηЗщΕΔΟыюδγюΧГьК():
    value = 342954
    text = __import__('base64').b64decode('VGR3T0hGekhvempHY1I2bjg3MnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥрЗЬΞЦσТΨ():
    value = 474640
    text = __import__('base64').b64decode('UjZtYjBpbTFmUFFxSFdJWnZod0Y=').decode('utf-8')
    if 59 * 92 < 0:
        _dead_3261 = 66
    total = value + len(text)
    return total

def _εΟЯСнсЦνΧюя():
    value = 268080
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSX+XERhq6sqFQTzmFHCGA0g0EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цХнμυЬΩησΘτκΣΕατ():
    value = 901541
    if False and True:
        336
        353
    text = __import__('base64').b64decode('Rnd1RHhQTEVwUkFXVU9VMGFhMmg=').decode('utf-8')
    if len('') > 0:
        281
        pass
        _dead_1028 = 750
    total = value + len(text)
    return total

def _δξΘωζЧнΨΩτЙΣψΚ():
    value = 988657
    text = __import__('base64').b64decode('RUVCNFdGVXZYS0Y4R0hkcER4dWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖδшЖЧΩХΑΧеψοΟЫД():
    if False and True:
        822
    value = 962016
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTy2PmELwalaNFuP6mSUIwc58Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗβςυλмБυиχγз():
    if 36 * 22 < 0:
        pass
        pass
    value = 768715
    text = __import__('base64').b64decode('U0VNbmhlamFMdjZZczdsX3FIb2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ζзΤУнΛШмψЮЧа():
    value = 402334
    if len('') > 0:
        _dead_6135 = 540
        pass
    text = __import__('base64').b64decode('TE1sUW83NUZsazR1TU5NY0lqYVk=').decode('utf-8')
    if False and True:
        739
    total = value + len(text)
    return total

def _УδлщюЖΒςςФΒшжТл():
    value = 312736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT3GekVh1/E5bD+B3gTCOises28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΔэеγηЮκ():
    value = 173791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bz/TaHQAyPkCHgSr93/FGiQd1DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьМфνуЯхИ():
    value = 383810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRq0QUVs9r8KMQ6C2EeILnY5/Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭδИАМЧςМΔ():
    if False and True:
        954
    value = 205610
    if 88 * 48 < 0:
        _dead_3938 = 581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fzi8aQkf/K0nDirwwnGbHC8d1H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КйДРΩЭяθЬДφιиКГИ():
    value = 963726
    if False and True:
        410
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQbIemAB8IYnaQaF0mG6IRQM9EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мηςКзΞЙЪКВΟм():
    if 94 * 53 < 0:
        pass
        787
        722
    value = 892473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj7xUQgq948RNgq0ygOGJBQ/72U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        233
        134
    total = value + len(text)
    if len('') > 0:
        643
        565
        322
    return total

def _СΘΥΧБщржфИФξищΖ():
    value = 186344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjfQYWAS2KMREja0nVy6IQ014GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьηОЛιλЛЭйФъэыΣЛМ():
    if 28 * 66 < 0:
        pass
        pass
    value = 893248
    text = __import__('base64').b64decode('dkxzZDBsREdfdTB5SjVfSzFXOU0=').decode('utf-8')
    total = value + len(text)
    if 55 * 16 < 0:
        _dead_2216 = 455
        pass
        pass
    return total

def _жбΛыβρуχ():
    if 34 * 14 < 0:
        pass
        56
        _dead_5823 = 58
    value = 734433
    if 4 * 89 < 0:
        pass
    text = __import__('base64').b64decode('Q3JLeFBGZlRwUEhvVm1vUmZkNGI=').decode('utf-8')
    if False and True:
        pass
        666
        _dead_2707 = 482
    total = value + len(text)
    return total

def _ОниΞЮФλЪσЕб():
    value = 150960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCXANwEwyrsLFC2kw1KfDQMN1nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΤΨλчпβθωя():
    value = 398380
    text = __import__('base64').b64decode('UGdqVDFqWnA4UnNraHdmRnJhRDU=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        895
        pass
    return total

def _ηюЫЧΤъΣЕΕдю():
    value = 281799
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiH1OmMt6pcbOBz35V+bGQwB80w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        17
    total = value + len(text)
    return total

def _ЧУωцЖζоУΦйςСο():
    value = 484724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH+2Vn4KrZsGAlvwnFeVNT15tXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 57 * 49 < 0:
        371
        _dead_5167 = 51
        pass
    return total

def _ДпΗнΣοкАΒνζπ():
    value = 448293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT3+eFUJ9q4sKyak+EaWAC0L9Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УеЬжДМξЯКФч():
    if False and True:
        pass
        pass
    value = 564799
    if len('') > 0:
        _dead_4852 = 399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgD2WFxp8/orEl6UmlOzPxor0mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΛχΑνσΟМΛИч():
    if False and True:
        _dead_3379 = 592
        398
    value = 662065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRfuSVhq96YxOSGZ/GGvPHB/zTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΘΡЭшΑΔуХОг():
    value = 758769
    text = __import__('base64').b64decode('UmdScFY2d3RwbmxaTFRSZkx2YVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΡдПιьκβνкФю():
    value = 140554
    text = __import__('base64').b64decode('UHBqcjRPQmIxYXpSQ1NJeEx2RnA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7276 = 324
    return total

def _мΥΓηвχχМАдςЬюц():
    value = 91958
    if False and True:
        pass
        685
    text = __import__('base64').b64decode('bDkzT2h2NGdURVJtTnNTWURWd18=').decode('utf-8')
    total = value + len(text)
    return total

def _υλωΗЧъλЙΓΚΔЕ():
    value = 382883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTXxSQIU7bgCDQHx7maBFRcVz3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΥпгшсДпДР():
    value = 168696
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('dHdqcGlQZDNLYXFKTDNwWm51RkI=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_6678 = 493
        pass
    return total

def _ΓΞОНЬЭкαРдΦΥс():
    if 44 * 9 < 0:
        _dead_2014 = 226
    value = 816531
    text = __import__('base64').b64decode('QVVwNmdrRXZJSDVRNkhQODN6cDU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9271 = 552
        751
    return total

def _ЯΖБиДХЖдмеΝιИЩΜ():
    value = 217009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACTXe2Yw04o0CB+V3l2hADMJyF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 76 * 14 < 0:
        159
        pass
    return total

def _ρпъτЛМρΦщ():
    if False and True:
        _dead_4604 = 227
        _dead_5248 = 478
    value = 419356
    if len('') > 0:
        5
    text = __import__('base64').b64decode('al85NnhaZnMwZmFLbXJ1bHNTYWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦσςΒΡΕΛвφ():
    value = 940027
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwPGdGMfp7kmDAG2/GejHwEO3H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦШτКЯιψβшιйы():
    value = 225488
    text = __import__('base64').b64decode('VnFySkxGWlcxblJTZm9idDg2aUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΥνΖЦиψаЪхωΖЫν():
    value = 616117
    text = __import__('base64').b64decode('UExsZk5vbk1UQmZjZkNTU0I0WDc=').decode('utf-8')
    total = value + len(text)
    return total

def _дΙуАьНζαлЙЪНъΣь():
    if 1 * 51 < 0:
        _dead_9045 = 183
        228
        pass
    value = 754763
    text = __import__('base64').b64decode('c1BXa1dlNzFhcVl1VTJQRmpYT24=').decode('utf-8')
    total = value + len(text)
    if 71 * 70 < 0:
        555
        pass
    return total

def _νТΣПψцςβΡ():
    if len('') > 0:
        496
        _dead_2651 = 88
        pass
    value = 373653
    text = __import__('base64').b64decode('bk5BQVRhZkhMT1c0UHdGekNvRTg=').decode('utf-8')
    if False and True:
        _dead_9336 = 296
        488
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('x') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    _dead_8424 = 577
    586
    874