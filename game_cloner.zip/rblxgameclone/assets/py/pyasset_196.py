#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _рμτΤδлιδМ():
    if False and True:
        _dead_7662 = 200
    value = 71871
    if len('') > 0:
        _dead_7550 = 133
        _dead_1758 = 472
    text = __import__('base64').b64decode('dzJTTkV0X1lHbVp6ZmhYTV9kYkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΙйΛνθцШωЗшγ():
    if len('') > 0:
        341
        928
        287
    value = 485341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyvBRVgIrowbaSSCnXLBBSw521w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψηΨΟеыФбΛΔμ():
    value = 388939
    text = __import__('base64').b64decode('dmJrVGNOMHhkckxCM2lNTkRPQ0s=').decode('utf-8')
    total = value + len(text)
    return total

def _МζЗξЖэМЙσρАΜΚΗЕΡ():
    value = 2552
    if 16 * 28 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyvjS0gf04IOOwL1ygO0EA8j02I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вТоφщΔЬшхЮ():
    value = 958573
    if len('') > 0:
        _dead_7807 = 519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAfyOkMTroYzDhet+V2+GyQJsEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩнлХΩνНЪβд():
    value = 456657
    text = __import__('base64').b64decode('R3ZVYms3QnVGMlMyUUt4UXo1c2M=').decode('utf-8')
    if 61 * 88 < 0:
        187
        843
        _dead_5839 = 75
    total = value + len(text)
    return total

def _ИШЪаΘЙυЛσцЩЙΙ():
    value = 483931
    text = __import__('base64').b64decode('eXFIUnhvbW9EbkVBSmF5YWlfMWw=').decode('utf-8')
    if len('') > 0:
        _dead_6834 = 204
    total = value + len(text)
    if False and True:
        _dead_8438 = 531
    return total

def _щчбΑЗлсБюЖЮ():
    if len('') > 0:
        206
    value = 719086
    if len('') > 0:
        650
    text = __import__('base64').b64decode('aVlzNVZMZmJIU0RMc0FtYmRBN2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ψοИеъαЫΔΕДωλф():
    value = 557428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AguxdlUa0L81Dlar4mHHA3EVsH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЬΨΘΜерΖν():
    value = 246591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSzWWQg30/5aGASxw0e4YXAK7kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _анЯφΡπДЬьчβΗиγЭ():
    value = 781858
    text = __import__('base64').b64decode('VmVRcWRVMDdhY21qa1I5OEM4QUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΔЧННΚЩΗ():
    value = 767633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAf1fm4r2PE2Nii25325MAp5/GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖεωмУΤζЫПсжЛАγг():
    value = 568035
    text = __import__('base64').b64decode('WkZvNFRnTndjYmhrRmFxWUk4ZjM=').decode('utf-8')
    if False and True:
        252
        _dead_2396 = 12
        90
    total = value + len(text)
    return total

def _υΠΞκΨЗШМцΩьТажьК():
    if len('') > 0:
        pass
        219
    value = 673892
    if len('') > 0:
        247
        pass
        pass
    text = __import__('base64').b64decode('VTI3cmNCaU5DUW8yeURVd2Jrc1o=').decode('utf-8')
    if len('') > 0:
        _dead_3928 = 763
        715
    total = value + len(text)
    return total

def _чΧζхγйрН():
    value = 219452
    if 24 * 35 < 0:
        412
        621
        _dead_9689 = 806
    text = __import__('base64').b64decode('TVdyc2lhd0dpZXJQV0dieDl5bG4=').decode('utf-8')
    if False and True:
        pass
        _dead_6874 = 870
    total = value + len(text)
    return total

def _увαλΡзБрМλбЗхыхΟ():
    value = 437853
    text = __import__('base64').b64decode('Q20wSlFOU3NyV0RsOUNsTGJ0akI=').decode('utf-8')
    if False and True:
        717
        _dead_4542 = 575
        pass
    total = value + len(text)
    return total

def _иμКΛΗЕΣъЦΔюΜТΠЮ():
    if False and True:
        240
        pass
        pass
    value = 639765
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CA7sTVca9psEFCKZ2WSZYSQa6jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЭьщЩΦЛьν():
    value = 727421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgDxZmsA+7EJYzaG0kKyHDM+vGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αПΚθгЖΞγдеσοпР():
    value = 550437
    if 11 * 44 < 0:
        _dead_1237 = 244
    text = __import__('base64').b64decode('TXp5aTRKblp4cHlXcndOMlpsSUY=').decode('utf-8')
    total = value + len(text)
    if 23 * 22 < 0:
        pass
    return total

def _ИыτуγΣиЛМ():
    value = 566405
    if 44 * 94 < 0:
        _dead_2411 = 807
        51
        454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kw3zdlwIp4I5NFaH8XuJJix4t18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХРрхΤмοБЯφкЯГы():
    value = 776637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBfzYFYNxKkBKCO66kKGJQIC82o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑφΤΦΥκгЪПЕυΓА():
    value = 951042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAbvWUghx6AbNBun/nyYYHJ/zlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μυЦЪжзΠВУжΕ():
    value = 391512
    text = __import__('base64').b64decode('ZEtOX1VxNDhiUldGek1LX2xUdWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩЕΥтБкЬУ():
    value = 207167
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX6wbW47ppJXPFmc6Vm3NicOtGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъбОКИЦМξЩеРγξяв():
    value = 933646
    if len('') > 0:
        _dead_9605 = 324
    text = __import__('base64').b64decode('akZKVlA0MFRnZmlSeFJqVTlKZjk=').decode('utf-8')
    if 80 * 25 < 0:
        pass
        _dead_9824 = 317
    total = value + len(text)
    if 27 * 63 < 0:
        pass
    return total

def _ОЛΧчнΖЪΓЙεМФσΟ():
    if len('') > 0:
        _dead_6294 = 10
        pass
    value = 111662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT/oOGM//41QMT6K5VTELCQjynY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωъЙслνΜьβςвшΔΩ():
    value = 806694
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyC9Pmhv6ZgGKwLz4WeSEQ8YzTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УтτθΝлνρиДЦуκВη():
    value = 984441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITrVaWc3x5ETbx6UwACBInwF6GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΘφοпγЩπΓθЫςσСНΟ():
    value = 359695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwnRYGso/5sWGSeX2k6CPTwtsWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΞэтγВИПЬЖйοтэЯ():
    value = 740927
    text = __import__('base64').b64decode('eFp2S2FMOGs5SkNSWGNtdkxNaDA=').decode('utf-8')
    total = value + len(text)
    return total

def _эъηьνχΤЖ():
    if len('') > 0:
        703
        pass
    value = 316948
    if len('') > 0:
        _dead_6162 = 815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDzHYl8GqphSbhjz4G6IMC4J4E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бвΔпΥαΧлπЦΜПЭοг():
    value = 332429
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC7wVEk+2ZwCFRqZ7GKpPQoO22k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        884
        pass
        744
    total = value + len(text)
    return total

def _ΜчыΒβιшτъεЗу():
    value = 230374
    text = __import__('base64').b64decode('YmtvcF9YMGoyV2ZxN0dkQWR5NmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪηγυυТγΗωЧ():
    value = 752412
    if False and True:
        838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBzMN0sY/6w5Elul63mWECglt0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        388
    total = value + len(text)
    return total

def _ωЧββΒΠхнΑχιЫ():
    value = 607812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix7HRQIB+4sqMlqR313EEXx43mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζбЩбπхΖρаΙυЖЧчЬ():
    value = 187433
    text = __import__('base64').b64decode('YkdNaGFGZ1hOY1ZPaTlmdk9UbzE=').decode('utf-8')
    if 35 * 50 < 0:
        pass
        _dead_5853 = 273
    total = value + len(text)
    return total

def _ΨбγςΧΣыλΗθЩΠψЭЖρ():
    if 39 * 77 < 0:
        pass
        pass
    value = 69841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB/pR0Ix+fwpHhaF6WOTGxUeznw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1187 = 573
        745
        _dead_7124 = 591
    total = value + len(text)
    return total

def _ОχСОγМΑπХΑκ():
    value = 270644
    text = __import__('base64').b64decode('ZHRzSEpkUUh2QUxPRkt3WDZjbFY=').decode('utf-8')
    if 91 * 13 < 0:
        570
    total = value + len(text)
    if 72 * 15 < 0:
        _dead_7819 = 819
        _dead_6644 = 711
        767
    return total

def _юЩЯΥБУγλλω():
    value = 995271
    if False and True:
        _dead_4291 = 695
    text = __import__('base64').b64decode('SEl2ZjByQVgyTmlOT2oyYVQwYXI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4489 = 739
        _dead_9006 = 846
    return total

def _ыΖΛυΛыхΗХΙкεφ():
    value = 309112
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fin3agUzr6wsMAGBn06JLgd+8Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фШСθИΩшΔНнτςυЭ():
    value = 747670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhXJegcVr7E2aher4U6RAQM882A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        175
        _dead_3351 = 792
    total = value + len(text)
    return total

def _щоΥΝЪэαΤшсЭЙт():
    if len('') > 0:
        _dead_2815 = 913
    value = 381079
    if 56 * 71 < 0:
        197
        _dead_7669 = 227
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSvlel4AqZAkayOzznKyNj0k51c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5748 = 828
    return total

def _ξзФИχЬЖΦяθзЯ():
    value = 780821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mij2fFMzx/AJKyKVy1GWZTwM6T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟгТтйΙΟГРυΞΥхуΚЗ():
    value = 578345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji39V2A/8JAsPBmowH6RBCEpwlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χОαХКЪАΘЬεэьЕФКИ():
    if 48 * 13 < 0:
        pass
        _dead_5171 = 166
        pass
    value = 29612
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHjgPWch3aQJNAz03nivZgA2xn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 34 * 21 < 0:
        752
    return total

def _φШОЬУβыЫтзΔдΚбл():
    if 11 * 86 < 0:
        709
    value = 895691
    if len('') > 0:
        519
    text = __import__('base64').b64decode('THNHbU9xazk3eDk0bDNJcWtvaEY=').decode('utf-8')
    if False and True:
        _dead_5780 = 327
    total = value + len(text)
    return total

def _оТηλлсΗпЯН():
    value = 881456
    text = __import__('base64').b64decode('RzM5bXJnRkJXcWo1VG9qS1BMVEo=').decode('utf-8')
    total = value + len(text)
    return total

def _υχΝЖоηωФπζΗТЛю():
    value = 60150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3bWYFcr2ZtbOFi27wCFEh8i9k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦηοΖлθυрШΑξЕбΑ():
    value = 906779
    text = __import__('base64').b64decode('anU3U3hGOFhXam1Sbkx6UnJUVDU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΝЬДпΜλЯдЗ():
    value = 238738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT/qbUQwzowwDib7+E+TAT9+0nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζЪчожΘδЫΜνРЖък():
    if 7 * 16 < 0:
        _dead_1697 = 980
        pass
    value = 246129
    text = __import__('base64').b64decode('TXlYSnBDNHQ5UVFrUjVZU2FmSWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ДхΖиΦΞεыИс():
    value = 168289
    text = __import__('base64').b64decode('cUhQS3JDM3ZRTmFKcFhCR1N4VEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤэΗβоФАкЗЖ():
    if 35 * 59 < 0:
        552
    value = 723293
    if 57 * 30 < 0:
        280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ch3wOFwq1bAzER+E6gGCNnYu/Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΔζФЭνισα():
    value = 993491
    text = __import__('base64').b64decode('d2szTjZQMG0xZG1ESFZBOHowZl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧυыιСЩαдЕитвУρΤ():
    value = 459997
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBW8XVMb6bEaKTmk+nLDEhYLwV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΓбЙЩθЩМхьΗВπС():
    value = 187932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyjPaXAS7Zc8bwTy6lmlMwwssXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8718 = 838
    total = value + len(text)
    return total

def _ηςНπКΣКλφцКЦДЩКΧ():
    value = 566423
    text = __import__('base64').b64decode('SnZtM2dPYXF5MzBpR3JQb05uNkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘтμВμФγΘ():
    if False and True:
        _dead_2774 = 976
    value = 513660
    text = __import__('base64').b64decode('Y3JHemtYc05RWHg3VXdBbXVsRmg=').decode('utf-8')
    if 50 * 27 < 0:
        433
        pass
        pass
    total = value + len(text)
    return total

def _αРηΨςρХэеЫРσΙΠ():
    value = 495997
    text = __import__('base64').b64decode('ZGJnU04xb3Vza1NPbGk0R05kTzg=').decode('utf-8')
    if 21 * 97 < 0:
        195
        _dead_3343 = 630
        pass
    total = value + len(text)
    return total

def _лэΖρΙУэСиЙФЬ():
    if 42 * 32 < 0:
        pass
        pass
    value = 638293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH3rQ1xpq5w3Gxut71qnEH0q3WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪрΝЮдАэΗ():
    if len('') > 0:
        _dead_7712 = 383
        pass
    value = 198102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dniyf2g0qvAzLQT19367Ag4u1Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬθГΛΔзЫКЬΒНфυРфП():
    value = 484435
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSHxbEYL360UaC6cxHWRJXcezXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        446
    total = value + len(text)
    return total

def _ωдτЖеьΕΧΝВ():
    value = 283242
    text = __import__('base64').b64decode('bFF5cTE3VnlVRGIxSFlITlVOcVE=').decode('utf-8')
    total = value + len(text)
    return total

def _вρΕοЩЦΟΧэг():
    if 61 * 30 < 0:
        68
    value = 340774
    if False and True:
        824
        821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh6wN3g/7KQOOCCk8GOcHCcevHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧАЪяζЪιπΞТЫыщΣΒЙ():
    if len('') > 0:
        _dead_4793 = 657
    value = 283415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRf3akcX9qo6D1iM8Q/EGDwKzTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьπΟмфлУμΙΔТаЫγ():
    value = 147157
    text = __import__('base64').b64decode('bW1hbDlab0FCSzVFV19tSkVHdWU=').decode('utf-8')
    total = value + len(text)
    return total

def _πЕΣюТΣψΗЩБМ():
    value = 434227
    text = __import__('base64').b64decode('S2ZTNlVidVNrQkxFNEo5WXJTelc=').decode('utf-8')
    if 32 * 34 < 0:
        pass
    total = value + len(text)
    return total

def _йЭβЩΖυφЮУЕεеАЯμЕ():
    value = 367030
    text = __import__('base64').b64decode('aEc5SFNMZUNadl9GYzVGdUFTR3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖлΜъφψΒэЙбε():
    value = 431684
    if False and True:
        _dead_5397 = 186
    text = __import__('base64').b64decode('cUQycHJUa0N2MnhJa0U4WG44ZUM=').decode('utf-8')
    if False and True:
        _dead_8937 = 461
        _dead_3817 = 611
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_2788 = 31
    return total

def _ξκЯτтЛΖωрΠДΒΠ():
    if len('') > 0:
        101
    value = 380940
    text = __import__('base64').b64decode('bXBrb1F5XzlrNnZNd1B5ZnNrN1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΕЯΑΕΚБΝЙχЛбнΧь():
    value = 916313
    if 58 * 61 < 0:
        pass
        969
    text = __import__('base64').b64decode('dzJPMFpWYkpfY01aTHFublhfZDk=').decode('utf-8')
    total = value + len(text)
    return total

def _τξФζЮρΨχΥλ():
    value = 517400
    text = __import__('base64').b64decode('QXpJd1BVYk9xcGVvT25iYkdoUXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣηЩЕΞРнιНαΩмΟм():
    value = 574650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHvMPHQty/kBGBevzl+DAhoM8Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ШββΓРсхНпюцУЬΟΜΝ():
    if False and True:
        673
        pass
    value = 648329
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pyr8WXYs8Zg6AhqK6w6/BX0fs2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЯнзорГНΑДΞτυ():
    if 22 * 38 < 0:
        _dead_6791 = 248
    value = 820519
    if len('') > 0:
        pass
        501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDruXAcTzPAlEjiV5XS3HDMO9Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 28 * 42 < 0:
        _dead_7467 = 382
    total = value + len(text)
    return total

def _ΖΜаΕΦξКЮВЮΛ():
    value = 406363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwnlO1c+z7oBOySKxUSbJgY4/lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζрнΗцнТγμкбτсθНн():
    value = 450635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyezWnhv1IQGFy23nnqxPCwd130='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΝЦЧτЛЭЕΜξΒЫ():
    value = 876755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgP9P3RvwfFSKlmSw0bJHC0t5zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дδьΕйэξε():
    if len('') > 0:
        459
    value = 9857
    text = __import__('base64').b64decode('WWhwaGRISTZpcDNsbG8wSWdmbFg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7435 = 291
    return total

def _ΠΤПфΥΗφОεпπΦ():
    value = 246938
    text = __import__('base64').b64decode('QzdKVGdqZ1c2QmZzR0xWME5OVEU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        816
        _dead_8783 = 166
    return total

def _ДжПεЙъЪПφ():
    value = 792704
    text = __import__('base64').b64decode('dnVtRlpKMUlaVWR3N0Vmd2JyaXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗξЖсКΝΛПφς():
    value = 295354
    text = __import__('base64').b64decode('VGE4X1BSOWhiQUxLX3pMSERBRXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ВσδτΛьλκцμΒ():
    value = 311436
    text = __import__('base64').b64decode('a2UzUG5pYlZyVzdiTEVWN2J2Zjg=').decode('utf-8')
    total = value + len(text)
    return total

def _дЩэЩяЭξьΟнвΚ():
    value = 262455
    if len('') > 0:
        pass
        208
        _dead_5935 = 199
    text = __import__('base64').b64decode('bW5ZaU9oNmxLdVFYRGZKeG1ONV8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3684 = 341
    return total

def _ДΩзΚрΖжЯΤхз():
    value = 806332
    text = __import__('base64').b64decode('TXN5ZDRPRFg5YzhfQnU2VG9senk=').decode('utf-8')
    total = value + len(text)
    return total

def _ζВΩΕΣΝщρОΟв():
    value = 264962
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgTHX1wWwZlUbl2Exl6WMzUL4Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒдαРДрлоЖежатпБΡ():
    value = 531658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KADFaWYR0qVTPyim6gbJLQMs6Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξзгЛШПуЛСМуЗТ():
    value = 884832
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERfQRQcU0qVXABuIwnSpDh8t90s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞхчЮγκλΧЧв():
    if False and True:
        _dead_4552 = 700
        346
    value = 232534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECnuRUJg9KEVEw2F/n2DIyo/20M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _БЛиβΜзАλаκюΘ():
    value = 35671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXzzSGgr/J0VPjqU/wKlOyYi/n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤνбгЕмЮЮъΓаηΟОδο():
    if 86 * 77 < 0:
        545
        439
        520
    value = 874547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx3lRF1qqv4hDRym90avDDAp80k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХмеΒАαΓΔЗЪΦφ():
    value = 296988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhjhNn4++rgzIx6N33qDMDYcyzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        355
    return total

def _лжВΝπйсνЖΤΕπуа():
    value = 344178
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fi3zY183354iOwq63HyqOHUq42c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭУжЬфбеμΞ():
    value = 770743
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjvdTAYvz48LDxev5F6KJ3Ap7kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΤГΧΔχςэ():
    value = 716265
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT3Od2YX8vkwbg23+ALAIyQN6E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖВШδЭΝΓΨЙΠ():
    value = 779253
    text = __import__('base64').b64decode('ZEF1T0NtSHFJR2RDRkNqYXpudTE=').decode('utf-8')
    total = value + len(text)
    return total

def _одДжЕρμαюΗ():
    value = 736533
    text = __import__('base64').b64decode('dmVJeXF6cG1hNng0MUQ0VlNaOVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒеЗнΡνΤъ():
    value = 716980
    if 79 * 15 < 0:
        _dead_6832 = 137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgfGalMey/wTYwa07A6XAwwX618='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МЗςПхκЭΖρчДΡΡпΗγ():
    value = 655105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhX2W3go0Po3HzD02lnCbT8K6GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΕΘытΝζГΘЕζΤюΔПъ():
    if 24 * 9 < 0:
        _dead_9730 = 580
        809
    value = 559472
    text = __import__('base64').b64decode('YkRMd2lGa3VxUFF5bU9GaThmV0s=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5506 = 802
    return total

def _юямМΡМИжУД():
    value = 480908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyC8f1lo37swKya0wEWzJzA54kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПэЖΧБЪЬпΟСριΓНС():
    value = 622403
    text = __import__('base64').b64decode('SnVKd19iREFNUE9PZ2lyWTZDSm8=').decode('utf-8')
    total = value + len(text)
    return total

def _θξΜΨзΩЫчФВЛЖεБц():
    if len('') > 0:
        _dead_4851 = 791
        803
        pass
    value = 314925
    text = __import__('base64').b64decode('eGRneld4T1VKd3FtOXdrMVBkbk0=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΔτкМЙλъιП():
    value = 224112
    text = __import__('base64').b64decode('U21LUkdJanZNSjV1d3Q1c2NtVHM=').decode('utf-8')
    total = value + len(text)
    return total

def _μХηиΦкΤΖΣνЩ():
    value = 318603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzzIV2YDzLhTIlfz7U67OjYA6mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыЖτΥТςыΤЖХЮνгιЪТ():
    if False and True:
        pass
    value = 597103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyPIbVgS3IZWMh6o2gWmPBE66D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ефιЕГΝλВΣΧνΔзтяΨ():
    value = 685110
    text = __import__('base64').b64decode('SENLV0Z0enNpbmdvQTJtS0tXMHk=').decode('utf-8')
    total = value + len(text)
    return total

def _юнχбΒяΘζΘ():
    if False and True:
        721
    value = 285812
    if 83 * 97 < 0:
        pass
        pass
    text = __import__('base64').b64decode('YXZfSmhUbjhEbXpsRkxNS19Lalo=').decode('utf-8')
    total = value + len(text)
    return total

def _йжΓρΒΜБхΒΝьнЪЕю():
    if 94 * 71 < 0:
        638
    value = 974257
    if False and True:
        pass
        pass
        849
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnbFPnM9y7kaORWk/1qvDAkt1jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗомРЯοГР():
    value = 303406
    if 57 * 22 < 0:
        _dead_1913 = 729
        pass
        _dead_3773 = 920
    text = __import__('base64').b64decode('a3lRZWY4aWQ5M2M1NGdOOEpMQXA=').decode('utf-8')
    total = value + len(text)
    return total

def _βГτμΕΞюΥцТГδЧшΛ():
    value = 298197
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eib2agMfzqcJCz305XqYGw0G0Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 100 < 0:
        615
        478
    total = value + len(text)
    return total

def _κζμОПΠХν():
    value = 673861
    text = __import__('base64').b64decode('VVQ5U1l2Zl9PTzF0UU9oblgyRU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЗаΨΕзφМчφβνζр():
    value = 922800
    text = __import__('base64').b64decode('aUkwSkR6TEFFMHNmeXdYNXFpVEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ХьςыПεНхАФεсг():
    value = 327558
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn3QZVYT17gOHlyGwFObEg4ftFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        325
        286
    return total

def _ΨЯеЭΜжωκδΛΩвπ():
    value = 730376
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3vOOl4N17oObz2m/FOJLis6tW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘьΗДυοΨΘбνΟΧξНП():
    value = 411717
    if len('') > 0:
        818
        150
    text = __import__('base64').b64decode('aF9VbnJad3BHTXd1MmZVMlg4RWw=').decode('utf-8')
    if False and True:
        888
    total = value + len(text)
    return total

def _ΗПψВяЫзΚВХΨοЬ():
    value = 478001
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx7nfX8trvsRYjWgzUG0GxQH1WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8271 = 584
    total = value + len(text)
    if 40 * 38 < 0:
        250
        _dead_9312 = 270
        _dead_4994 = 902
    return total

def _ΖΦъνжяЗρнжБъτ():
    value = 535243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NA7iS2Aw9L1aGAaTzGWqJhd6s0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ижΚИπΞйζзΚΔΓСа():
    value = 813079
    text = __import__('base64').b64decode('c1dSSTY4SzFvRENRVmdSaU9ObjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤПλΜчοΘГΛНы():
    if len('') > 0:
        536
        972
        89
    value = 141454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ai7bVEMLwYMEFhe64XfAbHwfxjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΨУοхьΥΝиХ():
    if 8 * 51 < 0:
        _dead_7518 = 860
        _dead_5616 = 99
    value = 754853
    text = __import__('base64').b64decode('cTZFT3pQOWl1OEs0VnFBcTVrOG0=').decode('utf-8')
    total = value + len(text)
    return total

def _гБΚβпЮМОΛш():
    if 89 * 57 < 0:
        290
    value = 885371
    if False and True:
        299
        _dead_2617 = 314
        728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jx/pO18y0IQzPyq3xli1BAsp81E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΞМЫΤБΠΝмζΣ():
    value = 576797
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('eGpEVUJ5eDFKMHFuM05leklqNWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭЙρμЪУЯУщΥКπе():
    value = 407719
    text = __import__('base64').b64decode('TkFyd1lPUWhPTnFmM2thMGxpdXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ИпεασУЛэцхВк():
    if False and True:
        pass
        _dead_5432 = 202
        995
    value = 532495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxrvOkI07bkILDaGxlW2DDUc3Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧуЦιПБΟηКЯтΣЮо():
    if 97 * 53 < 0:
        429
        _dead_4990 = 943
    value = 415275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwC2Twgq7LBWNVuP+VCjITF7w2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8057 = 896
        75
        170
    total = value + len(text)
    return total

def _ψΗθЮмыΠэьЖυλЫΦοл():
    value = 780372
    if False and True:
        pass
        946
        pass
    text = __import__('base64').b64decode('Sjg3a240aWR2VExHN01hS21UTnM=').decode('utf-8')
    if 11 * 62 < 0:
        282
        pass
    total = value + len(text)
    return total

def _цуЬЛЬдыΚэрг():
    value = 878706
    if len('') > 0:
        pass
        pass
        720
    text = __import__('base64').b64decode('a0NBREpEemFmY2xIN1U5VTcwZGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧОРбипΗДιω():
    value = 414095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHb8XXw4yodbEQC1kQCGIycO6EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еуЧсΡЗΤРЧΝньЫШ():
    value = 419386
    if False and True:
        pass
    text = __import__('base64').b64decode('UXBwTGJzVnhST2NNSldFWVowY1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _θЩХкΡεεΟΛЛнюЮΤ():
    value = 928556
    text = __import__('base64').b64decode('bDBnNUtabWVzQ2J0V1pzWUdnWTc=').decode('utf-8')
    total = value + len(text)
    return total

def _чκбсфМΗАЬП():
    value = 978297
    text = __import__('base64').b64decode('YlZMYURXRzd4RXl2MHlpMTZHZkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ГωΨπтΜκц():
    value = 855775
    text = __import__('base64').b64decode('SnkzaTRXd2dqdVhsZjJDVmdoQTg=').decode('utf-8')
    total = value + len(text)
    return total

def _βБφмЦΣюεф():
    value = 724717
    if len('') > 0:
        _dead_4670 = 260
    text = __import__('base64').b64decode('T3h5MlVUQnRHRXBXMnN1dUpmSWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΠсΣΞтγιρЛтΒС():
    if 49 * 53 < 0:
        pass
        _dead_7288 = 529
    value = 678290
    text = __import__('base64').b64decode('Z1hzZ2xPeTczV1RlaTVNMFVDajQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЬПДΠЙЩяшэΣρΩΠΣ():
    value = 705515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgrROlUR04IOFV6Z5n+fGi4Ezjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 16 * 75 < 0:
        460
    total = value + len(text)
    return total

def _νъΩзэωПСжκхΙфпаЧ():
    value = 770205
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA3seUIb8IoaMhasmASJHgoEtXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪрмЫЯгФлгΖюыΚ():
    value = 321081
    text = __import__('base64').b64decode('U1BGNjkydXdFVnNHY25IR2xxVk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭζΘЧГШЬфθε():
    value = 644315
    if False and True:
        _dead_3960 = 456
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBXuVAJo741RLwew2gO0NnMD7W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚγθχэΩΧЭщω():
    value = 24144
    text = __import__('base64').b64decode('ekdYUnV2Vk9PQ0JRUVRpbEZWQ1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ОЧюγЭТбξФхοΣΟχБэ():
    value = 465648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBvzQHgprLFTG1fxxQKkFgYb3nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кθнгЩфжЛкЯК():
    if False and True:
        541
    value = 915753
    text = __import__('base64').b64decode('VnNFN3pxTlJxdWswdGFlTDUzRlM=').decode('utf-8')
    if False and True:
        538
    total = value + len(text)
    return total

def _ΑяНувХыΑШъщξψΧΜ():
    value = 610208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nhb+PVge2/g2BReC/Xm/bBAc6G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΑЮρΚυфЬКжΞбрκШ():
    value = 849199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCLwQHwg0psJKTv7+GejYHIN3T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 88 * 75 < 0:
        585
    total = value + len(text)
    return total

def _αжОбΣΤшЬΙяΙэРжσД():
    value = 488078
    text = __import__('base64').b64decode('VUpGbkp0REFLQzVaUDdmOV9vMXY=').decode('utf-8')
    total = value + len(text)
    return total

def _щКπςΟБФΞВдξАВ():
    if 21 * 12 < 0:
        535
    value = 850583
    text = __import__('base64').b64decode('RE1tcHNIbURMOHZUc0FZcUxjT3g=').decode('utf-8')
    if 3 * 91 < 0:
        pass
        pass
        _dead_7188 = 188
    total = value + len(text)
    return total

def _шщСъοΦЮцФΜπл():
    value = 749477
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCjBSkMX+KUNKRagxG6kDTEt4kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑνΛАΙХζΧуО():
    if False and True:
        pass
        681
        _dead_2935 = 465
    value = 417270
    text = __import__('base64').b64decode('SkRVMHlLRUpYTkswV2FacjNYV04=').decode('utf-8')
    total = value + len(text)
    return total

def _фхμЫнξΨЫΠ():
    value = 156496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3ixRFZszboZGSL78U+xZBYV91c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГьεΥЖчЩΙΦшΠЫ():
    value = 312770
    text = __import__('base64').b64decode('bVNfdjdKNFFJOUVTTHRmMkRXVDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΗбКνШЬΝюαιΧλ():
    if False and True:
        pass
    value = 820120
    if len('') > 0:
        pass
        290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCbWX2E615c1aFqrmVq3GjId0D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ящξЖвесΟЛрλХ():
    value = 486296
    text = __import__('base64').b64decode('S05YTTVmZjBIX1ZTSXJvOFBJSDg=').decode('utf-8')
    total = value + len(text)
    return total

def _КпОшйΨηРп():
    value = 131707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgXDQEVr1KM7bRWEyXCxNXcVzjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7409 = 755
    total = value + len(text)
    return total

def _συιΠЙωΡСαЧсКяи():
    value = 651890
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSTPPUMa3b8IMy2A0lqJOx138W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 69 * 9 < 0:
        pass
    total = value + len(text)
    return total

def _ΛКζнνЛγщοйУ():
    value = 139776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX+3f3Ie8vkTPiOwzA+pLTc2sHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сКюЙπуШАΦβВПо():
    if 56 * 53 < 0:
        980
        718
        pass
    value = 401688
    text = __import__('base64').b64decode('cnlGdVNDQ3hnRnNJMUR2T2xyblg=').decode('utf-8')
    if False and True:
        _dead_1213 = 454
    total = value + len(text)
    if False and True:
        702
    return total

def _ςмΚΞωПφπЛАЗ():
    value = 767295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTb2VGAL2K0OFTux5H+GLSsm7jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕρОσиφЛфΛ():
    value = 977474
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nzngb3wW5q4mKle3233DMiF/wE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        917
        809
    total = value + len(text)
    if False and True:
        80
        783
        pass
    return total

def _вμΔπлХЧкЭξΥ():
    value = 824309
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgDJQ39h7poPaw710EKiPBMdwVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПЕЗγСααХс():
    value = 205114
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IS7JRAJh3/AmHzW66lmIYj0e5Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΧриЕбΠΒСΥβЮтρε():
    if 43 * 85 < 0:
        pass
        pass
        378
    value = 600598
    text = __import__('base64').b64decode('Z2J6aG9iTmtmeUZabEkzT1BjTWk=').decode('utf-8')
    if False and True:
        pass
        524
    total = value + len(text)
    return total

def _ЫясαйеΤκчЗ():
    value = 373517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT6zbFMr64dTPgmZmHSxZTAi0Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΚюΑЦΛхИχ():
    if False and True:
        902
        _dead_8547 = 55
    value = 886309
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej/zamMr3PAzDyOtzA+lHDMot0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 62 * 35 < 0:
        pass
        pass
        823
    total = value + len(text)
    return total

def _дεуςШКδрВЪшУЧр():
    if len('') > 0:
        _dead_2441 = 355
    value = 170559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXvTO2s41J87KwGy+3mpHCY57mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙκνιмыщΣκ():
    value = 580209
    text = __import__('base64').b64decode('R19jRGtaTlo0NDFxTVVwV1M2UEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΜΤЩαиΦωмзвВ():
    value = 892923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBq2fn03778XDCen6wWAHQEu/kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МелφрбωзΝаκγα():
    value = 230828
    if len('') > 0:
        _dead_5291 = 571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBXVN19orfwgKyCn8QTHLQoEwTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 26 * 45 < 0:
        45
        pass
        456
    return total

def _πьπΦΣςθГωХГωПуХ():
    value = 839348
    text = __import__('base64').b64decode('bHZvR1BJY3hLZzBWaU1WVVNtbmY=').decode('utf-8')
    total = value + len(text)
    return total

def _θОωоЩЩεЭАщВςδ():
    value = 949445
    text = __import__('base64').b64decode('S0NFUGJFR3NKT1JOQ2N6VTdyUFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬгЭΟΧИЬс():
    value = 243388
    text = __import__('base64').b64decode('Yl9taXhUZ1I4bkZJcF81MTJsZUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΗрВΔΕдΦАΣΓяΤхΤЦ():
    if len('') > 0:
        pass
    value = 14611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3uzN3lv+KYxDRWp6QC0CwMKsXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιПυЫШΣΕΘ():
    value = 125701
    text = __import__('base64').b64decode('cDdCXzJFaVZxc1VfMHFLUzdjamk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨяЧцбΙΙΩЮ():
    if False and True:
        536
        _dead_9162 = 641
    value = 579560
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICzQVGVgrKdQOSKx4wCnJBYAxWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξτΦигЛЯΕεЧφνэъΜΚ():
    value = 466480
    text = __import__('base64').b64decode('elk5ejMwMVN2MkIyNlRpTW03Smo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦςακΡΓчψΚЮΞΑУщ():
    value = 383952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACPHb0FpzqUWGQeX52LALSwY5UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эκбИΜЩцЧз():
    value = 247658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxC1aVJg35InCFq25nueIhE6wEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        562
        _dead_3500 = 851
        397
    total = value + len(text)
    return total

def _РιζτлзцΝМκΧΖμ():
    value = 109903
    if False and True:
        pass
    text = __import__('base64').b64decode('WU9ubllHWFpWMVp2Z3RVVnh4OUE=').decode('utf-8')
    total = value + len(text)
    return total

def _свΑΘДβηГПТХАеωйе():
    value = 451648
    text = __import__('base64').b64decode('eFh2bnBzYVFnSGR1MUNmSGtGUEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЕЦГΗщδеΒΚКеΨхъ():
    if len('') > 0:
        pass
    value = 583764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAHASQA18vFXEhWm2nqJJgYJwns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΦΔΨУΞъэΛЗштΣΑ():
    value = 193246
    if len('') > 0:
        226
        _dead_4606 = 964
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3ngT3kTzZEvFi70+U+WJgx4y2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЙяЛβδπΙцБХмСТ():
    value = 959627
    if 51 * 56 < 0:
        17
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASXuZUhv2J4rYxqTm0yvEgM9y1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οфΞЯмшМещΑξкξςМК():
    value = 916494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRDoVFw314sJFlqy7G6qBSh83Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жδμΖрэζθйπлρЩΤπш():
    value = 290112
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxDBO3Ae8K0pEzy25nmfYQgY7Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пβАХкгΝЪτπΜИ():
    value = 233022
    text = __import__('base64').b64decode('ZzZHck9GU0dHUm9TTkdrNFRRMnE=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΖБΩжμСβε():
    value = 773588
    text = __import__('base64').b64decode('RTV1N3RNZFIxaEtJRDlDc2pKRnA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8888 = 811
        pass
    return total

def _ЖνжйναςΗοφΞЮιхεм():
    value = 576079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwHlOQY787oGNTeE53KfFXUmwkg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 58 * 92 < 0:
        pass
        _dead_8158 = 748
        397
    return total

def _ΤьΨΜдωΡОΟРιΜТП():
    if False and True:
        pass
    value = 294119
    text = __import__('base64').b64decode('dklVRXNzSzNwVG9xRlAzMmRzWDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕъΤмΛЗОΩзΑΚψβ():
    value = 219764
    text = __import__('base64').b64decode('TGxTNHBhZEN6ejlxVU94RmM5Rmo=').decode('utf-8')
    total = value + len(text)
    return total

def _иМШСъМΠΜБэеΙ():
    value = 272908
    if False and True:
        _dead_9144 = 555
        _dead_3268 = 321
        708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSPSaGc1/4QbCT20/mKVNXIb00M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 39 < 0:
        _dead_1506 = 398
    total = value + len(text)
    if 11 * 19 < 0:
        _dead_5333 = 728
        _dead_4329 = 885
        _dead_8029 = 481
    return total

def _ΠΘвщКИЛυΔ():
    if len('') > 0:
        710
        851
    value = 49064
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwTyTFQMxocWDC22nnqvPXQaxjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _онбвηΒЖКСΖльСЫ():
    value = 811699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQ30OQUr6/oBOTuvx16FPzR9w0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        760
    total = value + len(text)
    if len('') > 0:
        _dead_5317 = 982
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxx') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()