#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _яιΡзбφУνεΠп():
    value = 904943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHm9alppwZ4QP1aPzHy8NjQk0Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΥΕιβΡΣвΖзνх():
    value = 579778
    if len('') > 0:
        _dead_9648 = 120
        _dead_1446 = 47
        _dead_2572 = 1000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eyu2aXRg9LwzP1almwTGDXQc92U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕсВдγЕЮЖ():
    value = 147418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAvOXX4/74MOExe7mWeWLAEJzWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 86 < 0:
        _dead_5975 = 785
        940
        _dead_1281 = 120
    total = value + len(text)
    if False and True:
        pass
    return total

def _пзДЛГΑщΦιыбηΚμΣЕ():
    if len('') > 0:
        pass
        896
    value = 716959
    text = __import__('base64').b64decode('cjdlWHNLQ0NjSk14MUNYNHB3c0U=').decode('utf-8')
    total = value + len(text)
    return total

def _χΩеχαыΞδОЛζΤΠ():
    if len('') > 0:
        _dead_1870 = 861
        837
        _dead_7430 = 856
    value = 325200
    text = __import__('base64').b64decode('TDU1c0p1MDVnOVVwNGVMVlJWVUo=').decode('utf-8')
    total = value + len(text)
    return total

def _РсъΤΠЪθТРΤΟ():
    value = 109790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iwrta1ce144JKDn6y3uTFTAN9j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΠГκμυЫшο():
    value = 893845
    text = __import__('base64').b64decode('dmJ3S1VjQ2RHcVM2bXF6bkVkdm0=').decode('utf-8')
    total = value + len(text)
    return total

def _χчΨОъыгЯРйдаΓзУЙ():
    value = 548293
    text = __import__('base64').b64decode('T1BuVzhlNkt5czJBNlRDQUxNM2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠпζΘζфШЧ():
    value = 51175
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHjAV0Rp6rknLzWo41CzGR0X5Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηοХЮйσεОЩ():
    value = 582488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgjRS1Ng1IkLBSen7kfADH0D5jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_5892 = 91
        _dead_1853 = 275
    total = value + len(text)
    return total

def _ыοΛЖΘЫНΨιυоЛβТ():
    value = 50211
    text = __import__('base64').b64decode('YzN0eVJRbjdkeTRqemdtS2lGX0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ьυωЫЧγЬΕудΟ():
    value = 697690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IirpZUkO8KcSHhqt/UaVADA36E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        916
        pass
        _dead_7100 = 6
    total = value + len(text)
    return total

def _ΖΗБдгЧΔЛΡΦЖ():
    value = 397465
    text = __import__('base64').b64decode('T2pPSmU4V1hMR0d0MVNFV3JhOTk=').decode('utf-8')
    total = value + len(text)
    return total

def _БшαΒЫΠББцдΝτΘ():
    value = 924741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQHhYkMvxvkMPCfz+XuGEnECwEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        212
        135
    return total

def _УΕοΥτЙвБмθИ():
    if False and True:
        138
        _dead_4110 = 316
    value = 252176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DC3MV2EKyv8VFSiQm2XIDnMrx38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВмУАГξΖΞУκзγи():
    value = 578124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CibTVmcp/6s7EgOhxwe1AH0t90g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 86 * 75 < 0:
        pass
        562
        351
    return total

def _βуΕННЖζΥΘξδШ():
    if 98 * 44 < 0:
        pass
    value = 421980
    text = __import__('base64').b64decode('U0RMY25MWm1nRnR6OE9qQVVwS1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _уΟμηаυИΖΛΙεχшНН():
    value = 930738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BD/iZmgL+pEsNAKW6UHDZR03/GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΝХλΖащβΘτ():
    if len('') > 0:
        282
        279
        pass
    value = 398796
    if 9 * 55 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwHmQl4Uypk8DSqv/Ee1LRwqzkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηлхΗыαπЭЕΠбΖЕ():
    value = 596278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3bUZ0Nszq4qHQb26V6oHCsW7mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νпЬмΧθиκТЬЗЬΞцАβ():
    value = 281304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTjQNgEXyaswOAmP60WkMSwqtkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔеепгТψΧЩΤръωιΩπ():
    value = 213287
    if False and True:
        _dead_7031 = 368
        _dead_8764 = 301
        92
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCzCNn8PyfwKDSmA0QCCLHYQxj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙψναжйΥξ():
    value = 873607
    if False and True:
        405
        _dead_2659 = 36
        _dead_3131 = 268
    text = __import__('base64').b64decode('UDdiZjZ2X2xSbVRWRjdLMDZubzg=').decode('utf-8')
    total = value + len(text)
    return total

def _фцНлСЕΒν():
    value = 102643
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH7ya2sO9q5ULSqMmAaTPDA41G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НьπΤмУЮΦееωσ():
    value = 475480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD6yREc7qvgmaxukxGenEXF64Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эςγфΗγсТΗПцδЪ():
    value = 517722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg7xZggexKohbAD161i8Di8I/UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 43 * 50 < 0:
        _dead_8715 = 23
        280
        _dead_3809 = 237
    total = value + len(text)
    return total

def _ΜВχЬъхэМаЯΜξблКψ():
    value = 976593
    if len('') > 0:
        pass
        263
        _dead_5903 = 531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT/mOGQJ24UwPhiS6wKIMAckzEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΝΛθЯйБξ():
    value = 790381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQPGZFBs76EsMiKk8FKCMjQN03g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РЧшзДюфюПУВΚμАΘ():
    value = 41082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyztOQJv0/ooKAewykbEZAR49zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞййτκжζπΒрц():
    if False and True:
        480
    value = 645552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQ7+dGEB/JIkPT+kzgOkHSwJzUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юЧрлλΒЖΥΣЗМ():
    value = 915301
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQrAZHsX8akWDR2cnHK1My0B6WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υХΠφЮΠησБЪКζ():
    value = 43399
    text = __import__('base64').b64decode('Q0NzdGlGYjh6S3N2RndJRU9FcW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕЙйПжΘГнсξфюрЧ():
    value = 633283
    if False and True:
        pass
        _dead_8809 = 755
    text = __import__('base64').b64decode('QzVPOTZKTl9fVUI2UUVMNEJZS2E=').decode('utf-8')
    total = value + len(text)
    if 42 * 60 < 0:
        pass
        _dead_3175 = 535
    return total

def _ΜыМΒΦφюВИΔЗ():
    value = 309954
    text = __import__('base64').b64decode('bWk4XzY0SnJBU0lJMHFxWVJRbXQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5320 = 340
        _dead_5247 = 549
    return total

def _ЯЪйНЬшΧΒкЗ():
    value = 929559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwXxSURgzL8gNgum4gaKGgAG4Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шхππμΠКπКМχфυ():
    value = 488709
    if 42 * 90 < 0:
        337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3nxS1sQ0YJTERun8XSfFRQItFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бКСГодιяηЧА():
    if False and True:
        pass
        784
        _dead_5423 = 721
    value = 266970
    text = __import__('base64').b64decode('eTB5anVXYTVzU2RiRG4xSzVOeXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ηιξозСлεΘиаκσςаИ():
    value = 631810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnrgQXwq5o4LHzawylOaOCM+wWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧмΨАζЯαющжЧ():
    value = 966927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxvCSVQN3Y0QOzqUzQKgBDN9zXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘвЗэΔкРΛзλΣΗΔ():
    value = 918700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQjRfGQz5o8pLDCCwlm7HB861mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        980
    return total

def _ΧцΚΘΚΚсюЖРКθη():
    if 57 * 91 < 0:
        636
        pass
        pass
    value = 475714
    text = __import__('base64').b64decode('b3ZEaTFydTduM3dZeTc5b3V6bVQ=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_1401 = 969
    total = value + len(text)
    return total

def _фДΟΒГβξФ():
    value = 563563
    if False and True:
        280
        _dead_9331 = 532
        _dead_3746 = 614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX/hfnQhz49bAFmX3kS2FQQ+sV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖрГВηΙΜυ():
    value = 747473
    text = __import__('base64').b64decode('TnBhOEZCXzVxNDJyWXZUQXpBQnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΑаΤнывΣшА():
    if len('') > 0:
        2
    value = 349383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAHPTXAd+KMtNSuUmHGyZyw34GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΔнΩгΔъφЫΧл():
    value = 663928
    text = __import__('base64').b64decode('TDdBZzYyaHVuSFBYRWtRM2RxY3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЩЬνшЫАΠΦτΚ():
    value = 587720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBfWV35o9f4RHijz7l+KHDJ+1Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 44 * 38 < 0:
        _dead_1478 = 173
        pass
    total = value + len(text)
    if False and True:
        486
        _dead_6784 = 355
    return total

def _λкΣМтγлюШθбЩ():
    value = 194343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj3Ce2Eowas5EiT7kEa1PQMetUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γοфсρиРΚλΝкФВЙСΜ():
    value = 472911
    text = __import__('base64').b64decode('SkhMbXBHeUtaemJTWWtEdEMzQzg=').decode('utf-8')
    if False and True:
        _dead_7236 = 940
    total = value + len(text)
    if len('') > 0:
        _dead_6552 = 470
        pass
        _dead_3129 = 447
    return total

def _фОΖγдΞОΣшОэН():
    value = 82498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InbTSWkY/KQmNwGvwFK8FXQmzTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θβлпιйЙчΧ():
    value = 508854
    text = __import__('base64').b64decode('bW55cUpmbndJeG5SeGVIc3ZKVFg=').decode('utf-8')
    total = value + len(text)
    return total

def _φμМΝъψгчФΜИ():
    if False and True:
        pass
        pass
        _dead_9424 = 230
    value = 892793
    text = __import__('base64').b64decode('YVQ0cHBIUmEzNGpYcFFvTm1iUkc=').decode('utf-8')
    total = value + len(text)
    if 13 * 24 < 0:
        pass
        630
        _dead_5480 = 390
    return total

def _ЗΥкШκМКμдХэЯ():
    value = 730524
    text = __import__('base64').b64decode('eURMWDNmZW5JeXhNT2gzQXpQZDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨυшыБЦκΖΕбш():
    value = 741252
    if 79 * 26 < 0:
        854
    text = __import__('base64').b64decode('cWJ1RTc2d3BKMTdjNjYyamZySk4=').decode('utf-8')
    total = value + len(text)
    return total

def _вΘΟοΛηНЦ():
    value = 426626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxzFbANu7IAELhiNyU6SAnEQvGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тШсСЖΓЦΕЕУΥфЦζχ():
    if False and True:
        pass
    value = 546624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAHLaAIP5IsTEh/1m0aCAyo/6js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 28 * 12 < 0:
        _dead_6126 = 112
    total = value + len(text)
    if False and True:
        33
    return total

def _ТмДξМγхΦИ():
    value = 415565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjbhT0Bo2o4MFyP251qxDnAJ3U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΡжΓωЛκЖ():
    value = 853202
    text = __import__('base64').b64decode('R0RCcmEwSG1TVDhYNmtlX3lacEs=').decode('utf-8')
    if len('') > 0:
        578
    total = value + len(text)
    return total

def _ΑПоλчΓСΠΜΛωАкμЭД():
    if False and True:
        pass
    value = 428307
    text = __import__('base64').b64decode('dmVYQVZtYmk5dnlQZHNPUXhta2s=').decode('utf-8')
    if 80 * 3 < 0:
        81
        84
    total = value + len(text)
    return total

def _ЖюФъыΩИдЛ():
    value = 499341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx3HbFwP171WYj6c+1+VJwQitUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 5 * 21 < 0:
        pass
        _dead_7673 = 64
        pass
    return total

def _флфаШШжЭЦЫШΞацωе():
    value = 441007
    text = __import__('base64').b64decode('UkhCSkUySG5BcFFoc0thVmVEVUU=').decode('utf-8')
    total = value + len(text)
    if 40 * 86 < 0:
        pass
        pass
        _dead_8373 = 470
    return total

def _ЪэψсΧψзуσ():
    value = 173663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnztWmQD+IwUNxym8Q6xZScF7l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝтΟШГвЬΝШуйЦΙκ():
    value = 234009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BibwUUYr+vENBS310UeDPTB+z1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яЖζБГАΟМЭжΩХГΒэ():
    value = 840056
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCW8XQgw/YI0Ky2X6W+hLBQX4XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        604
        pass
    total = value + len(text)
    return total

def _НυчРΑΑФψд():
    value = 165368
    if 12 * 40 < 0:
        927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyvBREYMr6QGMg6Sz2CZAzMtt2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СκΓαΤахΤΛΗΜзэΙΒэ():
    if len('') > 0:
        _dead_8986 = 846
    value = 241562
    text = __import__('base64').b64decode('WXg1cVlSUlpFcFU2Nm9rdmMzMUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩрΗΡφгΠδКфэ():
    value = 312935
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kz6xbEIe3/tbNh6F4XyzFS8Dtk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 61 * 39 < 0:
        _dead_7622 = 717
        pass
    return total

def _шжЩгΡтзНκэ():
    value = 722008
    text = __import__('base64').b64decode('WGpsbjVZS2NPZHgzSmJsTkpab1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΨεΡрΝΗДеνыХιкЖ():
    value = 364553
    text = __import__('base64').b64decode('VDJjMnNubGtBV1NGNkw1MzZvZks=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΥзЗЗΜжЯзЬД():
    if 58 * 45 < 0:
        414
    value = 283284
    if 67 * 36 < 0:
        805
        pass
        42
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn3Gdwge6bEOCCyQ71m1YC4K12s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠЦЦжΧжзΠ():
    value = 25553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bz7lf1Qg8LkkHiqx4ULBNRYJyjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мψςюыνυПОΞ():
    value = 748758
    if len('') > 0:
        395
        pass
        _dead_8916 = 897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxrPWlY+2IMIGSb14XKGHCsfzk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _УξоΥнрщΞУΘпХпφЮσ():
    if False and True:
        910
    value = 643933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxDNal0uzYMbHQvz2FuqYysByWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _σλΚθΞЬΒхδхτуОзЖ():
    value = 386513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3v+Pl8a9IwiYwr37GSzOjE2518='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яБНΕδЙЭЗΑυЮΒщЖ():
    value = 837814
    text = __import__('base64').b64decode('VkI5Q1ZISGg0ME1CcVJucGpzNng=').decode('utf-8')
    total = value + len(text)
    return total

def _аФδκФНχΝЦΖ():
    value = 689732
    text = __import__('base64').b64decode('cUJnSE16VUo3SE1QZERqcVhLY1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫФδΤοшΡФаρ():
    if False and True:
        _dead_3576 = 659
        _dead_5834 = 588
        _dead_9733 = 512
    value = 987058
    text = __import__('base64').b64decode('dXNYWUZiMnN3NVNXS0Y1cUdLdUU=').decode('utf-8')
    if 25 * 27 < 0:
        _dead_4995 = 475
        pass
        pass
    total = value + len(text)
    return total

def _ОйЫψжΣзεμфΒГρВ():
    value = 815960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JArCV34g9IwtNwvxnGOCECIVt2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НθдΝАΦЛЫ():
    value = 716606
    if False and True:
        655
    text = __import__('base64').b64decode('ZlJGMnhRMmNDQjV0Rzh2OW1nN2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _иιЯβУχнγЗх():
    if 76 * 61 < 0:
        _dead_6401 = 961
        _dead_6872 = 755
        376
    value = 888638
    if len('') > 0:
        pass
        _dead_9675 = 875
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiHLZnAt3aMgLRuIkXvDbAwV1k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 35 * 56 < 0:
        pass
    return total

def _ВьκхЩтιоΨΜθ():
    value = 319426
    text = __import__('base64').b64decode('eXBwNzRDZWR4VlVtTzdPeDlUMks=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        447
        _dead_7712 = 611
    return total

def _ΥΡΜΟυΡъΠΞтχΜΦΤΒ():
    value = 468732
    text = __import__('base64').b64decode('cExSejFxQXBTbExkY3BMaWJEQW8=').decode('utf-8')
    total = value + len(text)
    return total

def _нжωоδμЙα():
    value = 908185
    text = __import__('base64').b64decode('cUwyTlBoTktvV2RBNUo3dnI1ZUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣТМЭЭβиР():
    if len('') > 0:
        688
    value = 808001
    text = __import__('base64').b64decode('QUFTbF9QREcwRWRVTjdGUWZheFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ζнωцΘЪДΑ():
    value = 676245
    text = __import__('base64').b64decode('TnFHY3BDTkRCT25jUnVHN3RGWm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЦγсφпυХиЩтχэМκβ():
    value = 522147
    text = __import__('base64').b64decode('RjNxbW9vNzU3SGpMa0dsbDQ2Vk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒВСЮθΣρКΒЖМуδ():
    value = 145910
    if len('') > 0:
        702
        _dead_3769 = 605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC7veHY6yp42EyiZ6nuFDA9/zEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 41 * 89 < 0:
        _dead_5261 = 678
        _dead_1747 = 739
    return total

def _ΛЦГьгиμρПΨиГАΓ():
    value = 124938
    text = __import__('base64').b64decode('eVVJaXZhTFRkV1J1WWQyMEtZQWQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7506 = 32
        pass
    return total

def _иЭНΝшыυδωэ():
    if len('') > 0:
        952
        _dead_5613 = 277
        _dead_5707 = 148
    value = 28840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDvseWsr9v8KHVivnmK/HCgdtmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        56
    total = value + len(text)
    return total

def _эψЫфцЗЕяф():
    if 72 * 65 < 0:
        652
    value = 623753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AybhRHIR7qMJGTiWnWavAjcfxWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦШшΧΗΜдБβу():
    value = 264323
    text = __import__('base64').b64decode('TzRENHNVOERZR3lnSERDRVpxdXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ηЧδтΕЫюΚσ():
    if False and True:
        pass
        _dead_5896 = 492
    value = 458485
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ND7CX3ko/K1WFRuo216zJwkD8Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        934
        _dead_6712 = 488
    return total

def _ωЙхκηвЩбΞ():
    value = 204800
    if len('') > 0:
        pass
        327
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCX9Ygge57krbxWU536iFgk3tE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_3971 = 517
    total = value + len(text)
    if 10 * 39 < 0:
        _dead_2275 = 615
        _dead_9719 = 439
        pass
    return total

def _шγυжГтεΤа():
    value = 276450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTv8O0Iz//g2CjWu4VXBbRwFyUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΩвтЮΧыγкмιΨ():
    value = 341502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwDtPX0hzqxaCxiixGCmLAMBsFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΙΑчЬΖИΨΙЧχΖ():
    value = 286124
    text = __import__('base64').b64decode('eGhKdzR1bnhhaTVaS2ZYTFZtMEM=').decode('utf-8')
    total = value + len(text)
    return total

def _шЯфΗчΣвωΛΔо():
    value = 219024
    if False and True:
        _dead_9650 = 726
        _dead_6904 = 225
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyTOPUkw0bkoKCj33mGeLjMO5U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        279
        322
        _dead_9868 = 241
    total = value + len(text)
    return total

def _ЧτБςΒЗΡАЮэР():
    value = 683653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Khy8R0Jt+/kRFx20xX6JMg4DyFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣψЗЦпхаΔаЖАЧНηЦΨ():
    value = 452066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng3BSFIeppANIxaB7FqHJiY64lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПШхΥЮХЩсΚΑКЩ():
    value = 243648
    text = __import__('base64').b64decode('S1NIN214cGJneWV1ZUhsdjlmV2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥоΚσиΑШЖсдззАО():
    value = 980326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB/yTwE49402EF603W+YGw8k7j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠИδοςАηΩ():
    value = 409529
    text = __import__('base64').b64decode('T0tJOGt6WGRwbEk3VjBIa2U4RkU=').decode('utf-8')
    if 36 * 79 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_2701 = 54
        _dead_4760 = 392
        _dead_4770 = 415
    return total

def _ΘШρвНйσΚД():
    value = 168435
    text = __import__('base64').b64decode('cnZyc1d6UzJVczVTTFRJRnJscDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ГУцМквжяΑ():
    value = 40732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxXDfl9rq5AtaVnzn3nBACsj0Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КНΧΩηΣчΓΞΡΦΠ():
    value = 19395
    if 91 * 3 < 0:
        _dead_8588 = 849
    text = __import__('base64').b64decode('Q0lXb0lqVU1xMnB1NGRsUnA5cEk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2142 = 371
        pass
        pass
    return total

def _НΩГςтщдПΡΒθ():
    value = 724625
    if len('') > 0:
        738
        _dead_6194 = 31
    text = __import__('base64').b64decode('aUR3ejR0b0VpVXpfMm9zdzFJMDc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8869 = 534
        _dead_9608 = 428
    return total

def _ιЩνКЦюМσЕкБΠ():
    value = 17016
    text = __import__('base64').b64decode('ZWVBWldHRmd4WERJekllSUxsZmk=').decode('utf-8')
    if False and True:
        _dead_1365 = 680
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_4855 = 350
        _dead_5991 = 382
        _dead_7911 = 89
    return total

def _ΥопЫςογΤΑИТΑ():
    value = 347216
    text = __import__('base64').b64decode('blZGTHlYMG1WaHNHV1dLRjZGdG4=').decode('utf-8')
    total = value + len(text)
    return total

def _жюΝΕΧγΗНλВΕ():
    value = 565975
    text = __import__('base64').b64decode('UGIzSVZhQ1pTVFdYazIyNUQxNEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕςкОЧпμгυτУ():
    value = 215923
    text = __import__('base64').b64decode('R1lSQXdVOVlicndHZ0tqdWc2SUg=').decode('utf-8')
    total = value + len(text)
    return total

def _κзюхαЦΠΚΔМΨ():
    value = 906949
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgfLPmMN2KcQHBenwFuGBAgg100='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧуςчНЙхюЗρο():
    value = 771778
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICHhfmMB1qIvGwuHnnHGYAI70Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9195 = 322
        997
    return total

def _ΞφΠΡХХΣΜ():
    value = 274864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAbjZF0z+7oXPTmi0kaFZy4/wGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЙΩπаΣМΗΒΛэ():
    if False and True:
        pass
        pass
    value = 200930
    text = __import__('base64').b64decode('RnA5NDdKS3YwQ3NMRDBIXzNGNHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ζθηххλЖЩηАο():
    if False and True:
        _dead_1984 = 94
    value = 929242
    if 24 * 29 < 0:
        pass
    text = __import__('base64').b64decode('RzJpME1JM092ODJsXzI4Vm5LZ1o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        436
        pass
        _dead_8971 = 624
    return total

def _ьΘеΖμΓΥΠБ():
    value = 412274
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg3ueWU0870kPz+qygSILjQH0EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юΚуηαΚОфοМΜΗγАΛ():
    value = 88421
    text = __import__('base64').b64decode('UkFocTZFRGd5Y2JwdkhpX1FabXU=').decode('utf-8')
    if False and True:
        427
        pass
        pass
    total = value + len(text)
    return total

def _σуφδфсгχοηδцΡъΨР():
    value = 487681
    if False and True:
        451
        _dead_5674 = 8
        _dead_7959 = 255
    text = __import__('base64').b64decode('cGs1d0s3VGZubmNuUl9BUnU5eFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜжΛуйΠΕΡοДΞИκ():
    value = 279240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3+9VgERz50MNzz18USvF3ci6F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τеνВвюеξЖыЙψκщΕ():
    if len('') > 0:
        pass
    value = 15604
    text = __import__('base64').b64decode('WHpJS2xCWTY0OThsUTc4WGtxRGo=').decode('utf-8')
    if 82 * 97 < 0:
        937
        520
    total = value + len(text)
    return total

def _ЪрΗАхцΡΠΩоμхΜεлЗ():
    value = 91016
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQPOOlkLrJohFjea0VKvFQgNxjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωыΕеяюоЧпгн():
    value = 203842
    text = __import__('base64').b64decode('eF9PRUx3NzBOR2tDcWR4VGFlUUY=').decode('utf-8')
    total = value + len(text)
    return total

def _бцδГеχъаφψΗ():
    if 84 * 96 < 0:
        _dead_9219 = 181
        781
    value = 257594
    if False and True:
        _dead_2678 = 185
        _dead_8130 = 105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh2xbAUs95ECHTCBzF+vHXYmxlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        237
        pass
    return total

def _РТξΗХψкμλЙтμυШЗЯ():
    value = 847586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjrjRkkX8KoROwyiw0elIHwbt00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХВЮΝьжМυЩ():
    value = 942671
    text = __import__('base64').b64decode('UWxUNWt6bklvaHFWX0dQMHBsWEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΤддΟθкм():
    if 23 * 1 < 0:
        _dead_2022 = 96
    value = 866439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In/yUXUy7p1RGCW0mXiZHgh7208='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9045 = 749
        pass
        309
    total = value + len(text)
    return total

def _ςΔЮЫОΚЧΒМ():
    value = 81452
    text = __import__('base64').b64decode('cGZfNTBxZXdOYVRKQUhBZmllRVU=').decode('utf-8')
    total = value + len(text)
    return total

def _εюгЦшВйΝюψтΠдядΖ():
    value = 57697
    if False and True:
        _dead_5590 = 622
        _dead_9279 = 24
        _dead_8824 = 431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX31a3tr6qMRBQurnGmUG3U7/m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 71 < 0:
        _dead_7283 = 982
    total = value + len(text)
    return total

def _иЛзгЬЧаНБдυβе():
    value = 408306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fy3LbUQM3II7EDqt4VyCGS0V0zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПТсψКΛσΖгδΥеΣΘ():
    value = 147013
    if False and True:
        92
        pass
        _dead_3832 = 501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARbHX0Ug5qYSLSeJwU+/Aw4bxl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 43 < 0:
        554
        pass
        pass
    total = value + len(text)
    return total

def _ПΗрΣЩЙплκΡΛΟЗяц():
    value = 164744
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAXIOAED/b4HETiNmkamCzI68m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        471
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        571
    return total

def _ΖЫНДМψΟΧαЦ():
    if False and True:
        534
    value = 235574
    if len('') > 0:
        444
        209
        402
    text = __import__('base64').b64decode('TXBqSzVKYUtUcVhTR1U1UG1sNmE=').decode('utf-8')
    total = value + len(text)
    return total

def _укЫжδΒиЧгуьрвНλΜ():
    value = 927765
    text = __import__('base64').b64decode('cHZFejlJUEozOW52eFVEeHZLVDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮПбципЙψχфλδ():
    value = 455118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzfbN3cc06AubhquwWGIJSQGw0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥоьСббдΕфεηУσыр():
    if 76 * 100 < 0:
        pass
    value = 613018
    text = __import__('base64').b64decode('TmxmQUJGT0xVYW1wUU5mdXhQRnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _шцθЬωЛОВЯΠΟ():
    value = 10279
    if len('') > 0:
        _dead_8542 = 97
        851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiPjfABgrJAKEluSmwCdNyke8zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШЕцλОоСпе():
    value = 891978
    text = __import__('base64').b64decode('VUVZTnlMYl9hWGV1VFVITTNlc3Q=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _μХΘбΗЪуЭλшФ():
    value = 224819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Inn3a2k467wOPACM/X63OBw14mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζцРΖпЖжΙχ():
    value = 991452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B33QPgEM8/4pMhyT936ZBy0/xkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧщьΦΚαСφΔпАяФΥщΠ():
    value = 276146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fgm0O2MK2qUTFTmNkGyfIjAh/Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зωΩеЮгαТβгъЯδйιΙ():
    value = 695824
    if False and True:
        584
        pass
        _dead_7379 = 519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCLXaF0j75w5ABeLwVm4HDYrvFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3837 = 810
        pass
        pass
    return total

def _ΠΓζξнΑъЧВπ():
    value = 462260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQrAeHM/r5sgNx2K3E+yAwo/3jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υЩрОφΤРЭЬН():
    if False and True:
        pass
    value = 653225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jw3POnMzyawZDSqPm0a/OnN23nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АщхЯБΗмρЧйЭ():
    value = 244589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRrUSlUQrrsPIwLz3XGDFQAnzUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НТιγΑθФВОθндΦβ():
    if False and True:
        _dead_9753 = 502
        807
        _dead_2435 = 303
    value = 997800
    text = __import__('base64').b64decode('S2Y3ZGxOeE1oY2czNTFCVE1zOUE=').decode('utf-8')
    if 84 * 69 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _νэжФΤρЗНω():
    value = 899185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K33ren8Y86MECCum4gCdIQZ7738='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 83 < 0:
        _dead_5263 = 289
        _dead_6883 = 530
    total = value + len(text)
    return total

def _оπΔΜτЬкСΒδλδЕофΛ():
    value = 799391
    if len('') > 0:
        _dead_2543 = 856
        195
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhrVT0Ef154wbB6a5UK+GXw+210='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        907
    return total

def _ИжεΘКσВДΖΠ():
    value = 667132
    text = __import__('base64').b64decode('ZkpLRWhZSVdVX0VoRlh4MUh4NGI=').decode('utf-8')
    total = value + len(text)
    return total

def _кшλΩлφбΟΒΙχΔОΥЖд():
    value = 544361
    text = __import__('base64').b64decode('a3ZJZGY3ZjVPOTk1TXV1ZGxzaXY=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _οΖяλюЫΥαлаβλ():
    value = 555385
    if False and True:
        pass
        _dead_2655 = 265
    text = __import__('base64').b64decode('ZWtLTHpTQlU3ZTZVZ3VMVXVnQkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ςжчРΜЮТνΒγοЙД():
    value = 141987
    text = __import__('base64').b64decode('WmN4YXVDaGthZjhtb3BhNE9MZ0c=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _γыεХшΥуκ():
    if 84 * 54 < 0:
        _dead_2837 = 759
        44
        _dead_1622 = 811
    value = 117738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiGzZ2Qw0Z4RawSR7kO1ZjMt13g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 6 * 9 < 0:
        pass
    return total

def _ΝУΣλгοдюжЦΜлΛВв():
    value = 687911
    text = __import__('base64').b64decode('SHd5Qzc4VVNWVGU0ZjhIRDVHWV8=').decode('utf-8')
    total = value + len(text)
    return total

def _ωпΑКΙРεЩл():
    if len('') > 0:
        pass
        952
        916
    value = 822822
    if 83 * 94 < 0:
        _dead_8735 = 109
    text = __import__('base64').b64decode('dXdSMTJhd1FPdGFlNzlhTm01eVk=').decode('utf-8')
    if len('') > 0:
        pass
        784
    total = value + len(text)
    return total

def _φαιкΤГςгсОΚхВЪТс():
    value = 405305
    if False and True:
        920
        _dead_2852 = 115
        _dead_5473 = 813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHrSdgYY34kvA1eCy1WiFwl/0Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шξФθεΔкаοйыя():
    value = 364677
    text = __import__('base64').b64decode('aWVvelFyTXFDX0JMN0JXbDA0X2w=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8514 = 401
        pass
    return total

def _иПΜзФгВΥΨй():
    value = 767609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiTUaHIayLBSADaG8mSEDTUY4kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛυУмθИЗЛгΖВωъ():
    value = 512567
    if 28 * 40 < 0:
        _dead_3094 = 143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBC0XGBqp7IIMiuPxk63HAE+1nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        846
        _dead_5061 = 763
        _dead_2671 = 237
    return total

def _ψЙШтΚΠΧЬД():
    if 85 * 58 < 0:
        _dead_4882 = 126
    value = 466080
    text = __import__('base64').b64decode('RG1TMEpwMFpWZWNoRG1WQkd0aV8=').decode('utf-8')
    if 56 * 18 < 0:
        pass
        pass
    total = value + len(text)
    if 45 * 72 < 0:
        _dead_9214 = 234
    return total

def _ыΟΛфσРςοЗΖпυιΡЫ():
    value = 319825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MR7+eVsWp4EsbR2293uePXUbzkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΙΓΡлбΦнνζХΡΤ():
    value = 95259
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAz8WXlv8YE8PB2UwF2zbTcZ9GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΣгτМэτзнйξЙ():
    value = 695039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCHzbQA+3fwmbFv65H3EA3Ug/Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гυοσθσοΤюΧтζмΣ():
    value = 938498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn68bHkO8qlSNFz0zlucPwIqy28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ясπΕνТьΕΙМЯЭν():
    value = 821202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCHtQ3kcrfEwDBv28lucFhUC9Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЛпΓλтΑΗНцЭωДκΘ():
    if False and True:
        pass
        _dead_8935 = 405
    value = 710947
    text = __import__('base64').b64decode('TUowMGdSQjBqUHRnMnRwSWw3M1c=').decode('utf-8')
    if 51 * 31 < 0:
        pass
        878
    total = value + len(text)
    return total

def _фιПΜиДЦЗЧπ():
    value = 418934
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyjARlIe9KMnbhWW7GOdHB8Y1ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        524
    return total

def _ΗβοСΕбМсВπДЫ():
    value = 160873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnzhdFMK3akoF1mczGeHBi4CwWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ΝαаοκзДОΧтωшВЖпσ():
    value = 760098
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ii7CPGgc1vsmaSeV+myCHxMZ9Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χιΘψΩЕУжЪжеК():
    value = 294140
    text = __import__('base64').b64decode('VEdUQnVJMFFQNnZmMEdyNWlraVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕцЛДЪцЧΤ():
    if 91 * 44 < 0:
        pass
    value = 195996
    text = __import__('base64').b64decode('bUxrTUZvd0FyVUFIUWxXNmFXREI=').decode('utf-8')
    if len('') > 0:
        _dead_9168 = 640
        _dead_1131 = 631
        357
    total = value + len(text)
    return total

def _σиΩщВвщЙьΓψбЮ():
    value = 983737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwrsVmlh8/sIbVb3wEG2Fwt49GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φγЩтЖЯдкΛ():
    value = 697309
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjfPbHQ36Ps6Ml/3z3W5YwB2sz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    508
    617
    _dead_1390 = 365