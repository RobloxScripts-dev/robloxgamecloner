#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ζГнфАΥτυПзНИΛИб():
    value = 591581
    if 35 * 26 < 0:
        pass
    text = __import__('base64').b64decode('dzZJUjRfamViQk9UWmwzVlJ4SVg=').decode('utf-8')
    total = value + len(text)
    return total

def _мΣγοБЪкΟшαщьμβЦ():
    value = 230972
    text = __import__('base64').b64decode('WmNrU2EyZmkxd2dGc0VfZVhSczU=').decode('utf-8')
    total = value + len(text)
    return total

def _щИαΘΩμЭЕΡьУΧ():
    if len('') > 0:
        pass
        pass
    value = 374505
    if 93 * 44 < 0:
        53
        _dead_5366 = 952
        367
    text = __import__('base64').b64decode('YVhjM2laV2d6eWt2QlhuM2M3elU=').decode('utf-8')
    total = value + len(text)
    return total

def _ВχзшлΒΡΡΨΣ():
    value = 572590
    text = __import__('base64').b64decode('dEVkd3VEZ3VLRlN1dXhTZ0ZwcWw=').decode('utf-8')
    total = value + len(text)
    return total

def _βνлЛшΥВλαДΤμΖΚшщ():
    if 84 * 80 < 0:
        763
    value = 337494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAPgYnsy9qsnETaVxWSfDXUiyVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΥρΨТЭΞФьαЧжч():
    value = 320143
    if False and True:
        pass
        272
    text = __import__('base64').b64decode('SmM5RVo5ZXRyVGlfRGQ3M3RDak4=').decode('utf-8')
    if len('') > 0:
        561
        _dead_2523 = 834
    total = value + len(text)
    return total

def _ЙаРЩАΕбШψΞИКойв():
    value = 298059
    text = __import__('base64').b64decode('Y0NCZkNIOHVEeGp6amIzSVBianU=').decode('utf-8')
    total = value + len(text)
    if 5 * 31 < 0:
        pass
        pass
    return total

def _ΧХοщКЭΗεθмυγφ():
    if 14 * 95 < 0:
        _dead_2588 = 535
    value = 104747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex7UZVcdyJcJIzaWmV+SH3IX5T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зζωбЦΝЙЖΙςа():
    value = 260944
    text = __import__('base64').b64decode('WkdabnNfYmlRRnF4ZUtuZHlhWVU=').decode('utf-8')
    total = value + len(text)
    return total

def _РρΘЭΚЕхеΦΨεΨЗζχ():
    value = 650284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAnQXVMI/aMOOFqS50SvIwwL5lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_3082 = 574
    total = value + len(text)
    return total

def _оФΡяеΝамшωлΟВХкп():
    value = 224762
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXjGfkRg6boXbgWU2kbFBw8i1WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βφюκЯЦΚБΤπΘ():
    value = 37735
    text = __import__('base64').b64decode('T0tNNU1UU1ExUWxSNmFZaHNJU00=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮλЦψАθГΖХБΚΜ():
    if len('') > 0:
        pass
        694
    value = 983827
    if False and True:
        _dead_5597 = 358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASTJO2E0xJEREjjw+F6HFzAA61c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        831
        pass
        _dead_3857 = 578
    total = value + len(text)
    return total

def _ЕρадξубεΚψ():
    value = 873709
    if len('') > 0:
        pass
        _dead_5896 = 826
        258
    text = __import__('base64').b64decode('bVhTUGVIb1A4UXRFYkpYQVBSU2E=').decode('utf-8')
    total = value + len(text)
    return total

def _аΠΛεςψкχψσпвςδЛ():
    value = 17784
    text = __import__('base64').b64decode('SV9RTzBtVUNSQWlaQ2pCdVAxNjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜςςТОΙκδ():
    value = 326095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NH3XXGcR154WE1eE8X2SJiR+4z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βМНырмКт():
    value = 258588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn3hY0gQ8qNWCwzxwXGFNxI360k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВФЧЭдμРЕΨЗξФ():
    value = 353373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATjHaXgMrJkybC6qw2++Pg98x0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 76 * 21 < 0:
        _dead_2449 = 961
        pass
    total = value + len(text)
    return total

def _айεгяМπМхвРςЛςφф():
    value = 321560
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mzr2XwEc5qUBDDj1kFSJFiw5wjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪмρщЦБΒΗЮ():
    value = 809041
    text = __import__('base64').b64decode('VmU1a3hNYklqNjZBTkZPUlUyejA=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _еπкПкθЙужяжвФЮπИ():
    value = 798486
    text = __import__('base64').b64decode('V0xNbml3UlZRa2VyaHFmWEE1cE0=').decode('utf-8')
    if 95 * 70 < 0:
        pass
        728
    total = value + len(text)
    return total

def _ърΣζκмМΥζЩКΦνцз():
    if len('') > 0:
        218
        _dead_3536 = 536
    value = 711555
    text = __import__('base64').b64decode('ZHVGMTVyMHJKMXZNRjVJQ1NpM0U=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2763 = 389
        978
    return total

def _ПкэсΔхНцςДц():
    value = 724895
    if 39 * 7 < 0:
        _dead_6207 = 144
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRXXSWIe1IktFQKH+lCRIyMf9lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 17 * 42 < 0:
        875
        _dead_4664 = 132
        340
    return total

def _ΡЪМζΟΙъσΔι():
    value = 29682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD2zOXo29IcLF1+axnSxDH0X00c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΤΚйЦярγгХлΨЭ():
    if False and True:
        632
        pass
    value = 405875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAnmTV4J16sMMxWm5U6RNhoE92I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛгпδабΤжωЙЪ():
    value = 785938
    if len('') > 0:
        362
        _dead_6833 = 147
        547
    text = __import__('base64').b64decode('eEl3N2VVVEV2VlVSTjF5eWN4UXc=').decode('utf-8')
    if 14 * 93 < 0:
        _dead_6412 = 362
        pass
        pass
    total = value + len(text)
    return total

def _ЩЫпХγζδΡЗξΛЙςκ():
    value = 754239
    text = __import__('base64').b64decode('TmQ4OXlFR1BUM2p6Y3FUMldKVkk=').decode('utf-8')
    if False and True:
        _dead_7679 = 364
    total = value + len(text)
    return total

def _κςшГΖчГТΟμΕэφЯ():
    value = 332778
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mjf8d38R7L0QICGOzF7IBwM40Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оУХкрΛрωΞЩБΟРеφγ():
    value = 683308
    text = __import__('base64').b64decode('Sjg1cGxrYmJjNVRsazhBZDdLRDM=').decode('utf-8')
    if 59 * 45 < 0:
        _dead_6032 = 659
        _dead_4891 = 927
        _dead_6685 = 576
    total = value + len(text)
    if 92 * 31 < 0:
        pass
        791
    return total

def _МΚбИАуГαΦτч():
    value = 664786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3v8WlAR/Z4qYyGV31TFZxUl3Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 72 * 64 < 0:
        pass
    total = value + len(text)
    return total

def _йЗуящчбШзΣБΝч():
    if len('') > 0:
        _dead_5058 = 284
    value = 298589
    text = __import__('base64').b64decode('eWN3eGVVNGFrOEgwTHZUemV3MFA=').decode('utf-8')
    if len('') > 0:
        101
    total = value + len(text)
    if False and True:
        504
    return total

def _ΛиЯπзθйЭΙЙΔяъЧ():
    value = 45277
    if 38 * 10 < 0:
        _dead_9362 = 505
        109
        423
    text = __import__('base64').b64decode('ZUM3SUNRcDg5ZnFWR21tbEIxVkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΟАэμУБаМ():
    value = 360640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSLBTAkT54cOaB/zngTJIB0X41Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 87 < 0:
        pass
        139
        _dead_8182 = 814
    total = value + len(text)
    if len('') > 0:
        _dead_3237 = 816
        pass
    return total

def _ЧШчъшцАлфχ():
    value = 3231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRn8REko9boTMweW4WS3Jy0N3ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘЕХθХιγΘзΥоΒΑьТ():
    value = 307920
    if False and True:
        pass
        116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgHtQF8L66BbMCyWz2y4YCYrwWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_5882 = 315
    total = value + len(text)
    if 37 * 94 < 0:
        798
        920
    return total

def _оНοвξσΝююΖЯφ():
    value = 209562
    text = __import__('base64').b64decode('bHFjd2V5UE9rS2ZQRjBHaU5zZXE=').decode('utf-8')
    total = value + len(text)
    return total

def _йьПρпηΣМΧΙх():
    value = 472491
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQz1PlwPxpw6ClerwnKqADc620E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯИлΖшρΒεЯΟж():
    value = 875207
    text = __import__('base64').b64decode('aGxaWHdQdlp0VWtvVDVLOFJONDU=').decode('utf-8')
    total = value + len(text)
    return total

def _чФΔгпδΔДεξΥэ():
    value = 870027
    text = __import__('base64').b64decode('bUFpY0NNZWNERGxUM0RxM3BjTWs=').decode('utf-8')
    total = value + len(text)
    return total

def _НпщΒяμΤерΜгТ():
    value = 334420
    text = __import__('base64').b64decode('UGJ2VXBJeFY4eGFtcDk4RzhHQnA=').decode('utf-8')
    if 33 * 79 < 0:
        _dead_5250 = 726
        38
    total = value + len(text)
    if 60 * 61 < 0:
        _dead_7648 = 933
        470
    return total

def _ДдЮЬМσцХчШΣΞ():
    value = 77644
    text = __import__('base64').b64decode('VGR5cUh5VV85a0Rrd1dOZXFJZmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗμΝυжτыΡΕξВΖБΘ():
    if len('') > 0:
        _dead_2193 = 52
        _dead_4835 = 762
    value = 896760
    if False and True:
        821
    text = __import__('base64').b64decode('dXltUmV2dENVeDBwNThwN0VlZUQ=').decode('utf-8')
    if False and True:
        _dead_2236 = 68
    total = value + len(text)
    return total

def _ТНΣэЯЕΝзχгΑ():
    value = 633048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCTqWQcd5o0xaAqQm0WgMysZ830='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥъМтоюЫΩγΥЬя():
    if len('') > 0:
        88
    value = 895681
    if len('') > 0:
        pass
        509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBzxaHQS3IQZMjWl/wSXMXwft08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΟΝГкуГΒФЙьΖιΚЮ():
    if False and True:
        793
        _dead_5375 = 45
        _dead_3060 = 853
    value = 688731
    if False and True:
        732
    text = __import__('base64').b64decode('Y0QyOUFKZFFyVmtkYkltekFtdmU=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        890
        pass
    return total

def _σзαπЯЩУИйΒΑ():
    value = 465567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx3FVAEdrv0saQ6S+gbIIiR70GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1518 = 286
    total = value + len(text)
    return total

def _ЗΠЬНΟлΟΝγΕ():
    if len('') > 0:
        pass
        pass
    value = 28356
    text = __import__('base64').b64decode('bE5JNHRGal9vNmJiSmRFXzlzaHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ФκΩТРзΕОψο():
    if False and True:
        _dead_3168 = 778
        _dead_8083 = 129
    value = 495883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAjDRVtvyKsBHCT36VmUbDIq3Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        758
        _dead_2526 = 189
    total = value + len(text)
    return total

def _ιМеАцЦЗεΑΟИ():
    value = 131683
    text = __import__('base64').b64decode('cGFMb3V5OVhLRlJnWmRFNGdESU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΤαцЫδΡτтНГΔ():
    value = 188309
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTbuOmc22bsANlqFmXe1IhUK0Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 16 * 2 < 0:
        _dead_9363 = 501
        _dead_7818 = 760
        _dead_3916 = 460
    total = value + len(text)
    return total

def _ОΑяχЧπЮПшФΦ():
    value = 125185
    text = __import__('base64').b64decode('VnJ1MV9yeWYwcURESGZFRjd0YzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _еΧΠοςΞτчЖиΣЯЯΥзъ():
    value = 626112
    text = __import__('base64').b64decode('YlFOYm8zeUhHZ1FJNmZEX3NtckQ=').decode('utf-8')
    total = value + len(text)
    return total

def _гςщΗρЕΨΠЪοΨπср():
    value = 736721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3feO3kWyoo8PiSNzWOoGhN8xUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΥПМΥςэюΣщκпξΒЖэ():
    value = 368607
    if len('') > 0:
        921
        _dead_8627 = 80
    text = __import__('base64').b64decode('U1ZSV19LUXhKSVdPQVhuMEJ5Zzg=').decode('utf-8')
    total = value + len(text)
    return total

def _шΤСноΖКлвχккРωΞж():
    if 31 * 100 < 0:
        _dead_8842 = 244
        pass
        pass
    value = 308065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgzRWm4S864ONT2H+Q+vHyx94T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υлωТΖлСТΧΗΑы():
    value = 271123
    if len('') > 0:
        435
        pass
    text = __import__('base64').b64decode('TGFRbk9oeVlJZmtuSkNwa3c3QzQ=').decode('utf-8')
    if len('') > 0:
        355
    total = value + len(text)
    return total

def _НЭτΗРхБГшΒЗ():
    if 65 * 12 < 0:
        pass
        pass
    value = 55724
    if len('') > 0:
        _dead_3508 = 17
    text = __import__('base64').b64decode('THR2cDNDdHRGV3N1cjFTRWhieXo=').decode('utf-8')
    total = value + len(text)
    return total

def _νРЩθюΟοАΟΞΒщ():
    value = 734409
    text = __import__('base64').b64decode('SGdUVmhxalNTX25peW8xaXNkVl8=').decode('utf-8')
    total = value + len(text)
    return total

def _θΒаХΒκьδЙЩэπΠф():
    if 25 * 52 < 0:
        961
    value = 641229
    text = __import__('base64').b64decode('Z1hjbUxkSVFZRzdlOXpReWpMTEs=').decode('utf-8')
    if 97 * 65 < 0:
        358
        360
    total = value + len(text)
    return total

def _ФΝπбйΙЬЦЙσμ():
    if 17 * 66 < 0:
        _dead_6172 = 0
    value = 294133
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bi3SS1wf3aovORu3+1THDAc6zUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚδТюπГТе():
    value = 390727
    if False and True:
        266
        pass
        _dead_6483 = 10
    text = __import__('base64').b64decode('SjdfTmNqZjN5dE9MajZzYnd6dVM=').decode('utf-8')
    if False and True:
        _dead_9605 = 860
        pass
        pass
    total = value + len(text)
    return total

def _ЪτЭθФХЧνЦРхΥГъχ():
    value = 606844
    text = __import__('base64').b64decode('RjZDSzRTNW9EaDR0dkJvV2RpNU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ьωЕфЧеМΡνΞ():
    value = 722774
    text = __import__('base64').b64decode('WDZfckMzSzZ3NWF3UGt2Sm5rRmk=').decode('utf-8')
    total = value + len(text)
    return total

def _биρКζТЮαзГδθЧндЖ():
    if len('') > 0:
        738
        154
    value = 301485
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwK2aAEezP8MOybw0lnHEC17xn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        843
        pass
    total = value + len(text)
    return total

def _мюБичξΘΖУ():
    value = 857363
    text = __import__('base64').b64decode('c0UyOEpxOGVMZnhZNkd6endpalA=').decode('utf-8')
    total = value + len(text)
    return total

def _ъМΖψЖМχД():
    if False and True:
        pass
        _dead_1862 = 486
    value = 194079
    text = __import__('base64').b64decode('TjRKRWJPd3JsbkQxSnBsRjRCZDQ=').decode('utf-8')
    if 28 * 94 < 0:
        pass
        pass
        pass
    total = value + len(text)
    if 96 * 89 < 0:
        146
        pass
    return total

def _эυηωγΝπЙωαΩΗης():
    if len('') > 0:
        _dead_1314 = 415
        _dead_3919 = 747
    value = 958684
    text = __import__('base64').b64decode('SE96SWszcXZHd1NZcVhfVVdTdWY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        152
        455
        401
    return total

def _ψеЮЩЛхνМъгААц():
    value = 918281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzblX0ge1Z0nOz+KxnWlZTZ+sWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚςоυЛШеЖρσ():
    if 93 * 81 < 0:
        pass
        pass
    value = 789173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCXLRVge8rgUIFal2ALHBQQKzUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8611 = 593
        pass
        464
    total = value + len(text)
    return total

def _щΤшуШФьдγрХЩμξ():
    value = 615417
    if False and True:
        167
        515
        pass
    text = __import__('base64').b64decode('cEhYWG12TndveThVYVI5YzI4VUk=').decode('utf-8')
    total = value + len(text)
    return total

def _бмПωцΞцБЬοБγ():
    if False and True:
        _dead_8554 = 976
        pass
        797
    value = 326268
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAOxaVoV+foXFwD6y3C8ZAgEy2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чьчОюжУЬрЖ():
    value = 80668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3fpNkMXwbICbwaEmnWmATAF1Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5140 = 323
    total = value + len(text)
    return total

def _υζтЖЫйШтΔфΟςγΣΟс():
    value = 705307
    text = __import__('base64').b64decode('ZENtQWRtQzZySzd2RjBsSzkyQ2E=').decode('utf-8')
    if False and True:
        _dead_4865 = 752
        _dead_9287 = 637
        141
    total = value + len(text)
    return total

def _λЕΔαЧЧФнξмЧ():
    value = 261023
    text = __import__('base64').b64decode('SUZHSVNaVnJ1emtuMnQwTzJtYXQ=').decode('utf-8')
    total = value + len(text)
    if 45 * 78 < 0:
        pass
        _dead_4111 = 591
    return total

def _εЫйΗσμшЛЩ():
    value = 939596
    text = __import__('base64').b64decode('amU2SHcwVG4xeXFaVWRid0pvclo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2385 = 399
        _dead_8130 = 400
        pass
    return total

def _ьΙГΑΣФЭм():
    value = 247322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhjKT3YtppoTGAOx8mbJAyB59js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъЩλΡфΓτθ():
    if False and True:
        _dead_4812 = 407
    value = 799770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS3geXUJ8YQEMQSVnQG4bQQjsm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟсЮΛбкψΦВΤЮ():
    value = 417225
    text = __import__('base64').b64decode('bjBfOXZtdE9vak8yX2xnYmNsQno=').decode('utf-8')
    if len('') > 0:
        181
    total = value + len(text)
    return total

def _ΦАΨΞΗαΣъΦΩωΛΡεп():
    value = 906923
    text = __import__('base64').b64decode('ZWhIaVdmaXJHYkFpb3N6ODhhS04=').decode('utf-8')
    total = value + len(text)
    if False and True:
        142
    return total

def _ΓбτцΕМкςЕнψηΡД():
    value = 328891
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3n3R0s/qPwoNjCH+36bGHV5/Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΠчжулщΟбн():
    value = 737580
    text = __import__('base64').b64decode('R2Z3SXNiSzhwa3poV2tuTVFGeVI=').decode('utf-8')
    if False and True:
        387
        311
    total = value + len(text)
    if len('') > 0:
        pass
        712
    return total

def _ЭзиЦауΜΑΣσСцкюЧ():
    if False and True:
        _dead_2582 = 274
        _dead_2153 = 361
    value = 745636
    text = __import__('base64').b64decode('V0lJT2lQbWdsVHlYeTcwbFVQSjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _πΡэбЛУЦζрб():
    value = 338609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH+ybwUJzpgpLQyy5UG2MA5/9UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШιΡКвαЖэ():
    value = 959057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXbMPloSqvk3CDCn3wGpIjEgzEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юДЯщтцπαΓςαЕ():
    value = 197014
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHjcf2cdqZsCNVqU43yFMAJ3slk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒшДСτψВληΝ():
    if len('') > 0:
        _dead_4063 = 74
        742
        619
    value = 999170
    text = __import__('base64').b64decode('aTNlTW5qbW5tRDdTZDdOSEhYNDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ξτΟργψПмΞτхΘ():
    value = 499732
    if False and True:
        _dead_8822 = 937
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PC6yO1cz8oA5FSOM/UHCMAp/vEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψνΓЙλζжι():
    value = 76628
    text = __import__('base64').b64decode('V1FVM0NHZUc3RW5QeHhISE1yUWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭмЪДδыЧγΥξΓΡΞηъε():
    value = 361479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg7QX3cB16QLaFu14ke3YQQBtU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4997 = 691
    total = value + len(text)
    return total

def _ЫЯΛПйщςбюσ():
    if len('') > 0:
        190
    value = 601581
    if False and True:
        455
    text = __import__('base64').b64decode('UUdobHZPblVGanJJR2I3Y2ZQNDY=').decode('utf-8')
    total = value + len(text)
    return total

def _иοθПμЭАΤщц():
    value = 326014
    text = __import__('base64').b64decode('cFphejF1WWc5NmpkTnpOTmpzd2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΗξМсИчΝπбча():
    value = 212325
    if len('') > 0:
        _dead_8845 = 471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiDRaXM176oODSiB/w+8IS04/DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3247 = 254
        433
        146
    return total

def _ΙЙθΟΨΜτΜФΤΛЭо():
    if len('') > 0:
        _dead_1059 = 699
        pass
        pass
    value = 924432
    text = __import__('base64').b64decode('QlNpWEozX1NMem5PVmlCdG5qbVU=').decode('utf-8')
    total = value + len(text)
    return total

def _жУбςбΦбδЦжκ():
    if False and True:
        _dead_6985 = 356
        205
    value = 437731
    text = __import__('base64').b64decode('aEczVzdHNHR3T2RqOWhkYnlqZUY=').decode('utf-8')
    if 1 * 66 < 0:
        pass
        pass
        722
    total = value + len(text)
    return total

def _цкБцЖфУψиКΑδГ():
    value = 574420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ajf1dGkb3I0SCwypwX2GYxR7xkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        930
    total = value + len(text)
    if 17 * 99 < 0:
        12
    return total

def _пγηΗнЖΒΓΞРн():
    value = 558132
    text = __import__('base64').b64decode('bmFEZG12WThqdGJZTERqcEhZcG4=').decode('utf-8')
    total = value + len(text)
    return total

def _шΔДωΓΝГдΣυ():
    value = 861944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQvxT0MfxIYJEAuVn32yABwl4k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧцΙτνйΜυШΡчτдрф():
    if False and True:
        _dead_7666 = 323
        pass
    value = 88943
    if 4 * 85 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQfGNlAT8Lo3ayeqm12gDTE34mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 74 * 82 < 0:
        546
        pass
    total = value + len(text)
    return total

def _АоιΛΔРюАж():
    value = 854906
    text = __import__('base64').b64decode('Q0tHRUxwVkVsUGZoRGxBUjE3NXA=').decode('utf-8')
    total = value + len(text)
    return total

def _МцЩΗΧμРψсшξεЪΦя():
    value = 978627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzvVWwcQprs5GBXy0V6eZBYjx3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 4 * 31 < 0:
        922
        pass
        405
    total = value + len(text)
    if 86 * 27 < 0:
        pass
    return total

def _АхδΦΙйрНхвщ():
    value = 65950
    text = __import__('base64').b64decode('dlljNGc3cnIzSndOd0tDZDZYSWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΤПЗлΙΤОσΞΡБπБζХ():
    value = 610060
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAv2Olg39o9VKF6W0XKfAhcKsmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        688
        319
        758
    total = value + len(text)
    return total

def _СэσЕшΑλΣдΧΠйОΗδ():
    value = 46649
    text = __import__('base64').b64decode('ZEZ5YWgxV3EyeHZyM1RTbFdCa1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔεψОγЗянΧχΥАφΦΜ():
    if len('') > 0:
        569
        pass
        pass
    value = 59642
    text = __import__('base64').b64decode('cElueHlzVkZNcExoZjgwU2NwMDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪЬОжЗоСφΣ():
    if False and True:
        _dead_5239 = 438
    value = 689397
    if False and True:
        788
        923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N361f24Nr405LBiL8WeeAHwQzUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 52 * 31 < 0:
        292
    total = value + len(text)
    return total

def _κсуΥΗРЕγД():
    value = 27829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXzQaFA27Z9SETWtxw+nIjcuyUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СкλδсξУИлзДιγк():
    if len('') > 0:
        301
    value = 479623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwvgXXkVz6AENA30kQe2BXQY5nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εгСПεаΓα():
    value = 734332
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyHVbX0I3K0NaC7zwmG7ZjUFsVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΧНΕЦλЭЯΨ():
    if 43 * 26 < 0:
        771
        _dead_4743 = 741
    value = 955424
    text = __import__('base64').b64decode('akdKTm15Sks0bWg2c0wxaGZKcXc=').decode('utf-8')
    if 2 * 85 < 0:
        _dead_7807 = 709
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3269 = 195
        pass
    return total

def _ШЯωнΞМиейшАΥяΝИ():
    value = 555398
    text = __import__('base64').b64decode('aEE5NHgyNnRoejJXQjlTdWRsbG0=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΚеЯАЖαбσΔ():
    value = 522904
    if False and True:
        pass
    text = __import__('base64').b64decode('Umhwd2VUbUg0WHZKZXZJQ1FjRkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛψΒΙωΑйЮЪ():
    if False and True:
        _dead_3924 = 559
        _dead_7360 = 357
        106
    value = 445742
    if len('') > 0:
        20
    text = __import__('base64').b64decode('TXV1MThnSFU1c0k5YVk4M09UTmE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        958
    return total

def _ΡΜπщъфвΝщ():
    value = 248795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B37wXQIS+vwuGDWmxFymPnM16zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗЛМρΡоъτбьιτ():
    value = 575738
    text = __import__('base64').b64decode('eW9rTHV6b2JBYTZFcUVYS21VOUw=').decode('utf-8')
    total = value + len(text)
    return total

def _гжДΨΛлХΛφολмАξ():
    if 64 * 80 < 0:
        5
        _dead_8115 = 188
        315
    value = 196235
    text = __import__('base64').b64decode('VWFkR0tmdUxzUnpfQ25HcEtTR0k=').decode('utf-8')
    total = value + len(text)
    return total

def _вчξΧμκΥЖШфΑЧ():
    if 79 * 22 < 0:
        858
        396
    value = 249468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiHAalYo6q85CCKs33SbNgkW3D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖнΓΝΩрРсρΟφаИзЮЩ():
    value = 497446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ixr9dEUp7IkqAiq3n2nELBEe0GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟсΛчеСνΔАЗЩΞςяτА():
    value = 973338
    text = __import__('base64').b64decode('cWNua1kwa1VGeUIxQnc3b1RCS24=').decode('utf-8')
    if 30 * 43 < 0:
        _dead_6515 = 326
        _dead_3540 = 814
    total = value + len(text)
    return total

def _ЙГДΑъпПσНВΛΙδ():
    if len('') > 0:
        276
        _dead_7545 = 791
        pass
    value = 932763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxjMbHQ/8JxVOziz8ADCNTMpsU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υБмЮМзΙкΘДмΓΑЩБь():
    if len('') > 0:
        _dead_7967 = 905
        pass
        731
    value = 359278
    if 40 * 21 < 0:
        pass
        176
    text = __import__('base64').b64decode('dFpLdTk1NnpzeUhpRnVkenRzWl8=').decode('utf-8')
    if len('') > 0:
        _dead_2014 = 668
        618
        789
    total = value + len(text)
    if len('') > 0:
        _dead_3181 = 438
        pass
    return total

def _ИΟЪМΡЗλВфΡХξЦβ():
    value = 474962
    text = __import__('base64').b64decode('czVDclRjSmZ4VVFPSjduZE9mcU0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3719 = 430
    return total

def _μчΡмляВΚΨгξγЩжП():
    value = 202047
    if len('') > 0:
        pass
        _dead_3010 = 380
        _dead_5157 = 815
    text = __import__('base64').b64decode('QkdaeXMwYjRQUVAweFRzWXhEaUs=').decode('utf-8')
    if False and True:
        972
        _dead_9681 = 592
        pass
    total = value + len(text)
    if 48 * 43 < 0:
        _dead_2442 = 281
    return total

def _ПΞэЫΦΓыЯЙΡΠЬре():
    if False and True:
        pass
        940
    value = 796134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAT+elMj0a4AAzyt3ULEEzd4ymY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЩοΡЩеЦγб():
    value = 325708
    text = __import__('base64').b64decode('S3h4SUFkUVFJUTd0X1gwTENGUnI=').decode('utf-8')
    total = value + len(text)
    return total

def _лРшЦПπΔУоВ():
    value = 764314
    if 30 * 19 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwPsQwMG378Zay214HWvEjY80X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пОΙэсφЖОбΥчλмλУ():
    if False and True:
        60
        _dead_9364 = 384
    value = 269980
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwXFRXkTzJoXG16B+0+xLggr8D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8102 = 188
        _dead_2750 = 134
        64
    return total

def _νеσШРΝНΟмπ():
    value = 969717
    text = __import__('base64').b64decode('QjhMQ1E0bXF1MUx5dEN4am5jTE4=').decode('utf-8')
    total = value + len(text)
    return total

def _бΗνмπщрνΧФяΝ():
    value = 174641
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAvjSUEB+YMnHluQnkOEDiZ31WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧЙΧΨСΝμΧΜΩκ():
    value = 791361
    text = __import__('base64').b64decode('T0lWSnhDSmp4am5PN25GWkJBSjE=').decode('utf-8')
    total = value + len(text)
    return total

def _εМτξНгУщаΤΟΛО():
    value = 769206
    text = __import__('base64').b64decode('VTBRa2ZzUVcwYjdMa2p4UVRWNF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ккЫДДЮΧОбκЬгΜ():
    if len('') > 0:
        pass
        _dead_6506 = 72
    value = 414245
    if False and True:
        pass
    text = __import__('base64').b64decode('SzlDd0VnbFRYR1J5TjNtMTZxMEk=').decode('utf-8')
    if 84 * 8 < 0:
        _dead_7046 = 237
    total = value + len(text)
    return total

def _ΡэРЦξЪΒйЪШλοуцЯЫ():
    value = 801525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBn0e1gu5P9SKCzxy1WDBzB6vD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝШΒΘЙΞШЮГΚМФχа():
    if 38 * 40 < 0:
        pass
        pass
    value = 975763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyP+SnZrzbwMKCeNyQbDJDYg00g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФтΥΜлВшХ():
    value = 373726
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LA3GYgZp5psMNzD27XinEwN64Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тζΘКЩЩΟΜОж():
    value = 230002
    text = __import__('base64').b64decode('VGdSMXRYVzRyVkQxUG9ycFFWM0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЧеΖμμΘνΠ():
    value = 303644
    text = __import__('base64').b64decode('UFZSUFFKT1BYZUQ5OW9fXzBFQkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨпχθЮуξΥхТ():
    value = 390076
    if False and True:
        pass
        _dead_3077 = 714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pz3IV24GxJE8bTiFz1qpOTA+vGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 67 * 45 < 0:
        _dead_1303 = 162
        121
        _dead_7551 = 463
    return total

def _мЛΖМδЧψЫНнЙаΗθшσ():
    value = 65919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiDQV0tt7/sVCC6W/lGhFyk/4WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фОХΑζγΨвЦα():
    if len('') > 0:
        _dead_5013 = 457
    value = 911051
    if 77 * 61 < 0:
        _dead_4631 = 779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBrLamYV1Z8yNy2350WUHCEAy1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7893 = 794
        pass
        560
    total = value + len(text)
    return total

def _ЖТΚταТЩΚрфка():
    value = 267478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX3XZHcL2JcuMC238mPBLCwV7Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уРЗЬяТюеνДлЩКЖ():
    value = 585482
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDrQXwlgp78oHwWAzwWRFgIowFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΠжБςтΓЗΛтСЖκγ():
    if 76 * 61 < 0:
        _dead_6684 = 95
        _dead_6098 = 953
    value = 212674
    text = __import__('base64').b64decode('UUg5bVpaejFZYzg3WG1PZU4ySFo=').decode('utf-8')
    total = value + len(text)
    return total

def _иΩΦμгΙγОτФΖГх():
    value = 474213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB/wbGttqq86KQWZnXmyIwcd12E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙρρУπЗхΥΡ():
    value = 492679
    if 24 * 45 < 0:
        pass
        242
        451
    text = __import__('base64').b64decode('SjRjUkEyR0JpSmVnY2ZvMWd4dGM=').decode('utf-8')
    total = value + len(text)
    if 16 * 78 < 0:
        pass
    return total

def _ΙшБШгМχλжρБΘΣЭ():
    value = 867235
    if len('') > 0:
        _dead_8790 = 297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTjPeUQf3aE2ERmFnUS1BTZ+sEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΔσνΑфΛРΚΣ():
    value = 304098
    if 65 * 96 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD7can8g+IkhECWb+V+1LAkQ0lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫфЮπгΘЮΩΦΘГвюзЖ():
    value = 417250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHbCY2Zt+IsFIyqJ7kGDNycAtE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 89 * 33 < 0:
        _dead_3197 = 267
    return total

def _ΝНСΘъΦςСЙΔКяФηц():
    value = 918925
    if 92 * 14 < 0:
        pass
        _dead_1868 = 312
    text = __import__('base64').b64decode('dllsN0FhelFnVExpSjRkaHV3N1k=').decode('utf-8')
    total = value + len(text)
    return total

def _вΤШηυνЙчСНеιеοъш():
    value = 332644
    text = __import__('base64').b64decode('c29jbDBQWWZ6NTNJZUg0Qmt6WEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΞлЭΜпΤыΧεβчъэд():
    value = 259309
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQGxP1Uj0pI5FF+143u8BAgX6Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓзОαΑФУЯ():
    value = 100176
    text = __import__('base64').b64decode('c3lSZlVBdUJudEFhbTY0NWc1T0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΩЩэΡρΧбΔΛЪцЦСЛα():
    value = 811921
    if len('') > 0:
        958
        865
        _dead_5612 = 518
    text = __import__('base64').b64decode('cFA0VHZDUTZFRWdiUEpBWmhmT3o=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЙГΑΔЩююЮЬьγ():
    if len('') > 0:
        560
        pass
    value = 704697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn/AXFUozYESMVyhnHGWLSgF9nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯτИΘςΚΧΥ():
    value = 357562
    text = __import__('base64').b64decode('S19sMUZWUkZVZEt6MUN0RENLb00=').decode('utf-8')
    if False and True:
        5
        _dead_6333 = 283
        pass
    total = value + len(text)
    if len('') > 0:
        960
        _dead_2499 = 383
        _dead_6093 = 224
    return total

def _щыΝуυςζйΚм():
    if 9 * 57 < 0:
        642
        pass
    value = 977096
    if 52 * 48 < 0:
        _dead_9316 = 573
        265
        580
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjnOWAE/0ZIpFASbxg6/DSsE4kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩьфыгЫΛЕπ():
    value = 183405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAvgdlQw+oY8MCKJ+Q62M3F3sDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟζЫбγсхα():
    if False and True:
        314
        _dead_9784 = 140
    value = 342556
    text = __import__('base64').b64decode('TDNBWGNDM0VWQzJoY01ITlhXWEY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        396
        _dead_2690 = 645
        pass
    return total

def _ЮПΒθМςСυ():
    value = 645364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyjvaG4694IHbg36w0amHh819mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τξφвΟЧФΑои():
    value = 162180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyjvO3w3y6ESDiyU33uIZi139Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΖЛΖΩΤκгΤФЖΜХξЫ():
    if 61 * 38 < 0:
        pass
        pass
    value = 642971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kn22WWAwrJgsKTuR2gGYEik90Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        757
        _dead_1451 = 192
        _dead_5631 = 164
    return total

def _ηΚУΒПΡШОЦРΟ():
    value = 58442
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgLiekYVyok5IBePzW+0LR0Qzjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λσЦЗйЗдνГз():
    value = 58945
    text = __import__('base64').b64decode('ZzhGcmFBNUthUmVoTkNkT1d4YTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖГэмΑГθМррЪεΞυ():
    value = 808973
    if 80 * 19 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABz8PEYU9J4BLBv10gCKLjQr40s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 66 < 0:
        922
        _dead_7809 = 478
    total = value + len(text)
    return total

def _ΒШΛΞΥΚχЪад():
    value = 290837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgzRVl0f+KEabVmx0HSkYggovTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χηьΕςθюνрθеτ():
    if 83 * 99 < 0:
        pass
    value = 938604
    text = __import__('base64').b64decode('RWloZFFfYU1oTzJkc280bWVVSTY=').decode('utf-8')
    if len('') > 0:
        _dead_5102 = 172
        _dead_1907 = 624
        382
    total = value + len(text)
    if len('') > 0:
        _dead_3689 = 296
        _dead_3573 = 595
    return total

def _яΦйЙΘСЕΔΤοωιβГиξ():
    value = 207524
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXjKbEMy6IVSaB+A21SqPyMY42A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уКзфπηбМбνаГπΣХ():
    value = 230190
    text = __import__('base64').b64decode('YjZDYVlyS2MxTGZxRnNTR3d2akI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙМнηγЙχλЖЫТШν():
    value = 416793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fj7bQ1Y91vhVLheBw2CaPXMGwzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АеГкΨΩБтгзР():
    value = 805260
    text = __import__('base64').b64decode('elFoMjZzQXdDSEZvUEpvZ3FBeGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _лАγЭЯιСуΞАΑЭщпΧШ():
    value = 674041
    text = __import__('base64').b64decode('T1lWbHdCWmtCS1hYTXZ5d0twODE=').decode('utf-8')
    total = value + len(text)
    return total

def _κιΥΩψфЫК():
    value = 92243
    text = __import__('base64').b64decode('VHdpVDhVOXBXdmF1N1JrSUxqd1k=').decode('utf-8')
    if 41 * 77 < 0:
        95
    total = value + len(text)
    return total

def _яνμБРфεΧζЗζΖс():
    value = 551611
    if 32 * 68 < 0:
        pass
        920
        _dead_1511 = 298
    text = __import__('base64').b64decode('b2RoWklSWXBqMDZsel9mWnZMcjI=').decode('utf-8')
    total = value + len(text)
    return total

def _оЖЯПΒАΤБδЯ():
    if False and True:
        19
    value = 880969
    text = __import__('base64').b64decode('VzdneEYzYzZ3NEs1Vmd4QzRRajc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠрхпωγυХΓ():
    value = 482451
    if False and True:
        279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyPePgIzx/wTDwb27GWKLSk/3UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        31
        700
    total = value + len(text)
    return total

def _ЧЮΗЫОλΣνςσштЪйΙО():
    value = 334981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBjTZ3kM9aolORyuzXCyFScp4Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒагзΑиΦΩιΔΕЭЫх():
    value = 92024
    text = __import__('base64').b64decode('Z3laa0ZxZkhVZEJzTHBxVE9RVXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ρмврчЪθγ():
    value = 99945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHm3d2YByKkJCVyK0GDJJxMtzkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙЩСαЫΒΒγΨυΨΧΓО():
    if len('') > 0:
        _dead_4184 = 497
        754
        pass
    value = 640806
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSe8QmEUzLsqHCHwm3q3ERYX/no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТпΧΟοзяΞафξаυ():
    value = 258770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ahv2RkcV5/gtA1mwxXGTGxIq8Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μλΣΥЩЭΣο():
    value = 522475
    if len('') > 0:
        pass
        _dead_1167 = 871
        pass
    text = __import__('base64').b64decode('WkxqbUR2OEJORGEyU2Q1X1NpeHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘИвΣХΠОжσФΗПТт():
    value = 976408
    text = __import__('base64').b64decode('bURESDhDa1dZNVVEbnJ2Qkw2UlE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕоеΣхλщЪ():
    value = 879646
    text = __import__('base64').b64decode('bnVXZV85bUwxWXFyNWFTc1ZyQ3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _вуΚΤΡСβκПАσЬУ():
    value = 939838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSzBYUge6YcKIhmq21rIGTQi810='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨθхцΨЮμЧшΙπ():
    value = 771848
    text = __import__('base64').b64decode('a2NZOG5KdHNHQldmdmhNazI0RmM=').decode('utf-8')
    total = value + len(text)
    return total

def _эξΒяяъйγζНлйлВιм():
    value = 619470
    if 14 * 64 < 0:
        pass
        _dead_1216 = 274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3zKT3wt/7lSDRqg4nzFPzd+7Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЫЭоΜмφΓΥФ():
    value = 506276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSWyPFw2yf9RAwmVzXibPC4q10g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΠψЙдβθΗτΨДωδ():
    value = 61356
    text = __import__('base64').b64decode('Y2RSMld3WkNvQkxpMnNKM1RyUkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ФζΨηΔЭюсЪОиБЩυ():
    value = 676321
    if False and True:
        _dead_1644 = 585
        _dead_9907 = 969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRDDV10R7LEJFVan3FC3FTAX53k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦτξΛςоλα():
    value = 142207
    text = __import__('base64').b64decode('em5pOTVqUG85cHFlZEhkSHh3STE=').decode('utf-8')
    total = value + len(text)
    return total

def _ткΤЭιМШУэΞуδ():
    value = 993373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDXXf1QX8ZcOMFmixwOCADAG82o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цσмωЫХΤЧΣУйжВ():
    value = 878106
    text = __import__('base64').b64decode('c29RdjFJc2pnSHZ0VndtSnEyd3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _чβОСζΕΑΒБξлΠэΣ():
    value = 187839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh3qY0Fq5PAhFyGC73C0Pwgc8WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚυθтэЭрфτфдС():
    if len('') > 0:
        809
    value = 373161
    text = __import__('base64').b64decode('RFJrcHRYV2dCd0NiVlQ2T0c1MmM=').decode('utf-8')
    if len('') > 0:
        346
        pass
    total = value + len(text)
    if False and True:
        _dead_3996 = 422
        _dead_1711 = 941
        164
    return total

def _ΒоΣλспыьюр():
    value = 609638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgXeO2Etyf0HEjCH33yxBjY/9kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρгЩБΗφфнαдΨςδΛТ():
    value = 287631
    if False and True:
        pass
    text = __import__('base64').b64decode('Y2JHcHlsZm16NnhHbFlHT1RLMG8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        674
        482
        _dead_5031 = 220
    return total

def _яВКМэψЧхοΕгф():
    value = 465663
    if len('') > 0:
        _dead_1668 = 692
        245
    text = __import__('base64').b64decode('WDk0aTM5TGhVY193OFg2Rlg4OV8=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ПψфΗуЬПΠдςоο():
    value = 46366
    text = __import__('base64').b64decode('YllqU0oxM1A5YkQzM3hMZ090Yng=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯЧΕвρΗΥНеΑ():
    value = 954597
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRfGSUQ32YI8HhaK4w+DNwgo/ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωιРΨψΚζΕтБЙОакЕΓ():
    if len('') > 0:
        953
    value = 24061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njn8QV0t1oIyNSOn7lqgAyomxUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3328 = 64
    total = value + len(text)
    return total

def _ΥшρббГРθтλЯπ():
    if 19 * 28 < 0:
        _dead_8340 = 38
    value = 347784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fzu8flAaz4QCDA61kX+CJBctyHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 86 * 43 < 0:
        809
        pass
        438
    return total

def _дΧτЗИγΣФΒТ():
    if False and True:
        pass
    value = 134415
    if len('') > 0:
        78
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiO9YGlu6pslPTCRwlKBOBMFskI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΣДΛΠкБσуΟγкЧ():
    value = 17491
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAzHb2YL6/0tCwCKn0OGPgcWymQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5492 = 556
        689
        231
    total = value + len(text)
    return total

def _ВΟФХСЫякиЧγюАт():
    value = 734720
    text = __import__('base64').b64decode('RVd3dUpsdGlXbDNEX3BjTjZpN0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΖсΦΓуЖхДвеθ():
    value = 141329
    text = __import__('base64').b64decode('dXVJM2pmUlZzMHBiZ2lhZllJS3I=').decode('utf-8')
    total = value + len(text)
    if 37 * 40 < 0:
        163
        299
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()