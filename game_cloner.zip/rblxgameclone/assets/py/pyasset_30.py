#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _кαωТГсоЬоγДСΙЭβя():
    if 74 * 28 < 0:
        812
        _dead_7448 = 894
        pass
    value = 590769
    if 41 * 76 < 0:
        208
    text = __import__('base64').b64decode('eWpXUl9ZQzZKSTBaUmRPMEI2NWY=').decode('utf-8')
    total = value + len(text)
    return total

def _КИУХπЬΤζ():
    value = 879142
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('RTRvSkE1M0t2VENZNng2Yl9WSkY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        801
        pass
    return total

def _οЫЯζТΝъЬΥ():
    if len('') > 0:
        _dead_7871 = 566
        _dead_1412 = 333
        pass
    value = 594003
    if len('') > 0:
        696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDreVHwz2JkABV+RxVK0JnIf6EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хЕγДΗъΥйяΒц():
    if len('') > 0:
        710
        pass
    value = 441221
    text = __import__('base64').b64decode('d0RqTUNtY0dpUzVhNmp1dkhSeVU=').decode('utf-8')
    if False and True:
        pass
        738
    total = value + len(text)
    return total

def _ъТΞλΝνΓК():
    value = 952033
    if 17 * 59 < 0:
        pass
        877
    text = __import__('base64').b64decode('TDhvQWJOSkhjcjJqY3l2VUlxd3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΓψΜωтеΤБЯΡБц():
    value = 39008
    if len('') > 0:
        _dead_2015 = 216
        pass
        737
    text = __import__('base64').b64decode('Rll5SFNIQ2ZOZ0xCS2dYZ2xodUk=').decode('utf-8')
    total = value + len(text)
    if 92 * 30 < 0:
        _dead_9379 = 30
        _dead_1234 = 589
        pass
    return total

def _АΗВζρАΒбιвτврПеф():
    value = 648989
    text = __import__('base64').b64decode('dmpkUFVEMWlZeE1mbUlIUjJJV0U=').decode('utf-8')
    total = value + len(text)
    return total

def _вΣζшρрТШЦθтдЖсς():
    if 48 * 14 < 0:
        430
        446
        555
    value = 45870
    if 29 * 39 < 0:
        pass
        pass
    text = __import__('base64').b64decode('c1pwTTNEQ3d0MGlXSHgwMVJxd08=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗпΔΧΝъηΣмиθЦ():
    if False and True:
        pass
        886
    value = 899649
    text = __import__('base64').b64decode('THgyaHhzbjd2YTkxWGRFTE03Xzk=').decode('utf-8')
    total = value + len(text)
    return total

def _АяΡЕтοЗηхуиж():
    value = 601755
    if False and True:
        pass
        _dead_6030 = 901
        _dead_8842 = 792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAfjf2sex68AMSGr4VSEMjwtz1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 52 * 4 < 0:
        pass
    total = value + len(text)
    return total

def _ΚрθЖΥйСлβΑ():
    if False and True:
        _dead_5518 = 234
    value = 387658
    if len('') > 0:
        207
    text = __import__('base64').b64decode('dXluejdNM0J0bFdPYUc1WGtUZmI=').decode('utf-8')
    total = value + len(text)
    if 15 * 9 < 0:
        _dead_8476 = 316
        969
    return total

def _ΩΞΥΤΟкяпБНξФУΣ():
    value = 941055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Enq0Z1pgrLE8PST342XICwcM3HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΒйΜюΕξΛΖτтαΕеε():
    value = 855152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTv+TQlg6aYSCTmNkEXGBxU+tng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6529 = 223
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        883
    return total

def _τφωΕΡΛΥЫшΟк():
    value = 180590
    text = __import__('base64').b64decode('elhkeThLbHdrTE5iSm8yampia1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _АαЪΦΗЖИКξπйωΜΣхв():
    value = 487471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHbpVEE3rfw6agWq0geyFT0e3VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рШцтшνляΩΓΒ():
    value = 634662
    if len('') > 0:
        pass
        _dead_6570 = 51
    text = __import__('base64').b64decode('ZTlGR0VaMTlaNXAzTjN3VjU1SHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓθΖΓщяΘГ():
    value = 896055
    text = __import__('base64').b64decode('TGlyRmtJM1BsdTVMNTc4c2R5WjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΙρйтΥαДыщВτ():
    value = 688855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjjBWEUIrJwFNRaVxkyAJj0g0zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΦΨшΞЙжыΚΥЯΡюφВ():
    value = 606868
    text = __import__('base64').b64decode('eERsV3lMaHoyWmVQVlZXV1FrQXg=').decode('utf-8')
    if 78 * 97 < 0:
        pass
        813
    total = value + len(text)
    return total

def _ςуОыγЫΞμАоУ():
    value = 284015
    text = __import__('base64').b64decode('aFRYUXF4YTZuVXk3M3JhcnVZUlQ=').decode('utf-8')
    if 83 * 34 < 0:
        pass
    total = value + len(text)
    return total

def _ЮωщМρΜφпΠκиБжжσν():
    if False and True:
        _dead_4517 = 291
        pass
        _dead_8015 = 972
    value = 824195
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACXBXXoe/5IxMRaC+W/BPgguw3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        883
        265
        _dead_3230 = 644
    total = value + len(text)
    return total

def _дкяΣΠνчжФ():
    value = 571615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSnSXUQ/zYJQBRrz5X+bHRQH61o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΗΩяΚЫЯκФεΜпΗйОν():
    value = 307619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IirvW2lt8LEkFwS5wFCUIgIe1Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВДэЛυηьФφНΙςΖ():
    if 61 * 38 < 0:
        222
        pass
        pass
    value = 904217
    text = __import__('base64').b64decode('bEpTbGYxUnBFVDZhU0Y3cFlnUU8=').decode('utf-8')
    total = value + len(text)
    return total

def _πДЛτюψΡтьхΨφеглη():
    value = 29734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyTIYVkr2IwOOV+3kWOXDR8ZsF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6084 = 848
    total = value + len(text)
    return total

def _ЛΟΗМΥβбοΥγГ():
    value = 923398
    text = __import__('base64').b64decode('VzBpU21uTl83aDRMZ05teTJyZ2U=').decode('utf-8')
    total = value + len(text)
    return total

def _эνпβвρъΜТπΨλΨЛФг():
    value = 11434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRXpWnQSyfkmIh+nm0WvC30s/X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _атОαпКΞЙуς():
    value = 278577
    if False and True:
        129
        285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PX+zYWI1qa8yHAL0zQXBbDUb0X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΑбΩащΑΑ():
    if len('') > 0:
        pass
        992
    value = 709968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DinjY0s236I3MDWK+gGGCzF4ykk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        536
        pass
        pass
    total = value + len(text)
    return total

def _шОеясКρВζκΙИи():
    value = 16490
    text = __import__('base64').b64decode('WWVLTk1IV29IV2VaQWNORnVoa00=').decode('utf-8')
    if 74 * 25 < 0:
        _dead_3842 = 667
        _dead_3444 = 999
    total = value + len(text)
    if 17 * 74 < 0:
        347
        _dead_5538 = 370
    return total

def _рφПΓνΜЕΩφИтПРю():
    value = 84964
    text = __import__('base64').b64decode('aHhKbHlXVE9wYjQyNDB5a3NDQ1k=').decode('utf-8')
    total = value + len(text)
    return total

def _θΡАЛαςМΔзь():
    value = 704234
    text = __import__('base64').b64decode('Y1V2V1kwejl3T2hRdjJzQmJrdDk=').decode('utf-8')
    total = value + len(text)
    return total

def _чСйψΦШЦЩβтЫЛю():
    value = 793303
    text = __import__('base64').b64decode('RkVHekJIbnpRcU12Z1VTUnZnaVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΘшιУЖΖκЙЮκγ():
    value = 676178
    text = __import__('base64').b64decode('SGFGb0JSc1J3d0tqWEo2OW9tZUs=').decode('utf-8')
    total = value + len(text)
    return total

def _οшσΗЭмШАΖΠЦσМΥЖ():
    value = 605875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnbTfGYh7ZgrAwuJ0FKeLjwb118='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 11 < 0:
        719
    total = value + len(text)
    if 75 * 22 < 0:
        451
        _dead_5143 = 537
        _dead_9439 = 179
    return total

def _ΖχбсмΡЕнΡΧъл():
    value = 75039
    text = __import__('base64').b64decode('Y3djNnBKMU5wcHFEbVkyT0VCRXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ГДЭЦЭЪЗΖВЫПυЕ():
    if len('') > 0:
        _dead_8122 = 16
    value = 766134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC7DWX4crKsmMh2yw1WbHiR35n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞОъΚΧЭθЬОцλтГлСχ():
    if False and True:
        _dead_7570 = 243
        325
    value = 383143
    if len('') > 0:
        _dead_7205 = 641
        322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRbgSlYw7PokPzb7/gWHEzN/tWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эУΨαШΖΖΘЕЖπРχ():
    value = 653195
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JznJWHg+2KxWICyCw2WzJnEY72I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аъτСаΝХтΓΣЪω():
    value = 156467
    if 23 * 43 < 0:
        _dead_1750 = 858
        pass
        542
    text = __import__('base64').b64decode('cnZTVDdzc0E1T0hqa0VZSzZ6SXY=').decode('utf-8')
    total = value + len(text)
    return total

def _σцМΖψьτВКшю():
    value = 57632
    if False and True:
        _dead_8047 = 754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSjdVGgy1L8AEyaOnUOoE3124ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _СδραθΨЙттЕΡμψ():
    value = 769018
    text = __import__('base64').b64decode('UXFEX0t0UnpkbEVjcWsyWWJ4VWg=').decode('utf-8')
    total = value + len(text)
    return total

def _чЛБκнΚиνΛзм():
    value = 171655
    if 78 * 18 < 0:
        pass
        488
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MymzXVZp7PlaOV3643SpCyJ5znk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΝμΙКβΕДЪИя():
    value = 135705
    if 19 * 94 < 0:
        552
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiTAQ1xg078iOwqc2XqnDRQe4Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΑиКχδхНйΙЯ():
    value = 974040
    text = __import__('base64').b64decode('cG96QTBINDFibDdJMDMwNUFQX0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΨΤψаЬдХΨр():
    value = 362471
    text = __import__('base64').b64decode('TVMyZWVqeHhMUXlJT1J0YkdSeHE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7496 = 953
    return total

def _бθελьбΜσ():
    value = 674898
    if False and True:
        _dead_2006 = 599
        pass
        _dead_8453 = 963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwHNWVg3xIsaGwia0my1PQM/7Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦвβωЖЛΥц():
    value = 52610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzvrYgIU0oA3ah6N6Xm5AScA4WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΘΥοэыдΜЙЭныБ():
    if len('') > 0:
        81
    value = 853360
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N33UVgcyqfkoOB6nmHeTIRQQs2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6834 = 742
        pass
    return total

def _σΨЛχпιбшЮЧнЗΤδЭХ():
    value = 733140
    if 57 * 52 < 0:
        _dead_9625 = 199
        850
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQnbaEQx7r5QagGG4VDJBi8s8jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βНςαУЕсΥШУфО():
    value = 849031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FifxbFowzbAQbTapmXuHZi05xXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΣъΛЬАμχвуъЖΚΠ():
    value = 798913
    if len('') > 0:
        pass
        _dead_8696 = 395
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg3UOUYf5r4QET6wmUKePyt76EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 14 < 0:
        pass
        716
        987
    total = value + len(text)
    return total

def _УЖΛΗЖυЫъψХΤу():
    value = 611666
    if len('') > 0:
        995
        _dead_1365 = 651
        _dead_8107 = 683
    text = __import__('base64').b64decode('ekJhM2lPVG9DenBpWmtPUk91cW0=').decode('utf-8')
    if 59 * 93 < 0:
        _dead_6277 = 736
        _dead_5937 = 739
    total = value + len(text)
    return total

def _втχθОътЖОψМΩВлй():
    value = 428919
    if 45 * 48 < 0:
        pass
        pass
    text = __import__('base64').b64decode('STloa2dSRF9RRU44ZE1fOWlmbkI=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ТЫХινюВηт():
    if len('') > 0:
        _dead_5264 = 359
    value = 74854
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjfXX0U3y68KHB2GxWOqZwgr/Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΜЕΞчДсГΗГЗЯЖΣ():
    value = 580197
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwLBSkEhrKMoCAaC4E+vNnIQ1Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αЕιЖзВгфγАψΧкьΨΕ():
    value = 855337
    text = __import__('base64').b64decode('WmRJalMxdVRqa0JyRlJ6Rjh5bGU=').decode('utf-8')
    total = value + len(text)
    return total

def _КΨεЫбьвανсηε():
    value = 161650
    if len('') > 0:
        _dead_3658 = 257
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnbrencOxv8kHQip912fHSB+yno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αАΞйιΟнЛЗαΔБвц():
    if False and True:
        242
        _dead_6083 = 83
        389
    value = 911534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXzLZng9/IYXKCLx/VTGOhoBxzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 13 * 42 < 0:
        498
        pass
    return total

def _ЭΖсτΠхаχΦ():
    value = 57248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQ7QY2Yj8b0lbSaQ5gSHM3N/1UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΛИλαιцηκГЭ():
    value = 608320
    if len('') > 0:
        25
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CynTOwMKqI0aaCmH2WyEZiEM8l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_9558 = 456
        594
    total = value + len(text)
    return total

def _βИтμюΕфаΟУТаЭвΟ():
    value = 250961
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyrRfkYu1/AOPSuu2k+vJgsYyVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζСМЩΤвυζΞΡΞΘвΑΠ():
    value = 61290
    text = __import__('base64').b64decode('SzZnZHNubEdYMGZ3cXVReUJTOHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ъψΛΖЮλμЗΖкςΓХжЫВ():
    value = 952321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT/iTUQYp7IILiKo5GmpIDQo01Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 7 * 9 < 0:
        pass
    return total

def _ΞЙΖзноΝΨы():
    if 97 * 99 < 0:
        276
        _dead_8788 = 145
        564
    value = 427885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eyn2QkszyIM0Khmi5U+vNXV/vGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        86
        pass
        _dead_4546 = 165
    total = value + len(text)
    return total

def _ДφηдрЕФаОяνО():
    value = 798284
    text = __import__('base64').b64decode('YkFBczE5MW9neWtPYUl5cU04N3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЬκиΕψЫКΩгρУ():
    if 29 * 53 < 0:
        116
        pass
        pass
    value = 904001
    if False and True:
        pass
        _dead_5926 = 453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAfUfEdu0/kRbxat7lTIGwENzHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΧΚСΞηАЬрфΨΔ():
    value = 710426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DALtd3YX/ZAnaliMwG+UPzUs92w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        512
        pass
    total = value + len(text)
    return total

def _щνυЮФеκЧлПΝиЛХьх():
    value = 346165
    text = __import__('base64').b64decode('ZWt5TnZhYkNuaDdfMWdnMU9kWE0=').decode('utf-8')
    total = value + len(text)
    return total

def _хωХЩΗЬρΜввиωйεЛΓ():
    value = 809678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCzzTwAe+J47alfywlS+NzYm0FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        658
        pass
    total = value + len(text)
    return total

def _ΧЭΗΤΖЙОълтЖеΕщ():
    value = 972467
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj3UdF0A/KJTEiGtwQ6lY3cu8Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1387 = 280
    total = value + len(text)
    return total

def _УΜΑΦΤΒбΞκ():
    if False and True:
        _dead_4744 = 874
    value = 297038
    text = __import__('base64').b64decode('WkZ0Y2FMNlFUT3FTbThQQnZQVEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _θЬуΔЯΤмРΡυδσАφЦЗ():
    value = 786909
    text = __import__('base64').b64decode('UlJSTUEyUFRtam5raFRJa0Z4QTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЧЯαИЭЙаГρжβ():
    value = 493977
    if False and True:
        pass
        _dead_7265 = 279
        351
    text = __import__('base64').b64decode('S2UxMm5ZMmJxSHRsdGpQVWJCcm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΣδнςΧШяЬьрκχкС():
    value = 17805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwHAa0IN2v8wNFig0UOzEwN/1Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УλцбЧςΕηЗ():
    value = 908025
    text = __import__('base64').b64decode('Q3lRM010ZzBPd0hiTFdySU54T1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΠляХπшхςе():
    value = 248779
    if len('') > 0:
        188
        _dead_6084 = 804
        392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiDWelBrqaYXBTal5XebMy0j/XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 57 < 0:
        pass
        243
        _dead_9216 = 981
    total = value + len(text)
    return total

def _ьπьяΡΘςΔшΑ():
    value = 1341
    text = __import__('base64').b64decode('SVI2dnZrc1g1eVl2ajNHalh2TWI=').decode('utf-8')
    if 98 * 59 < 0:
        _dead_5128 = 283
    total = value + len(text)
    return total

def _КΡЙпΙςвЯφенθΩДЕΛ():
    value = 209751
    if 64 * 92 < 0:
        _dead_5726 = 898
        _dead_2514 = 723
        pass
    text = __import__('base64').b64decode('cHlEaUlKZTZteXNSb2xmbnRmVzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝЯβζωлγγςν():
    value = 352610
    text = __import__('base64').b64decode('cEhoVmRkV3BtdTEzT0w5b2RGM1k=').decode('utf-8')
    if 2 * 23 < 0:
        742
        pass
    total = value + len(text)
    if len('') > 0:
        225
        317
    return total

def _ηйхВηεНψςйЛВдπчР():
    value = 715464
    if 87 * 38 < 0:
        _dead_8689 = 163
        pass
        pass
    text = __import__('base64').b64decode('WkRVMTJOTTlzaEJ0ZTdIWlJPbUM=').decode('utf-8')
    total = value + len(text)
    if 18 * 85 < 0:
        pass
        pass
        pass
    return total

def _ιЛΣωШζЕξυΞΠΤПХр():
    if False and True:
        pass
        pass
    value = 514062
    text = __import__('base64').b64decode('YWxlRklaMTV0QWVrbUlHNUYzVWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΤюеАйзЗ():
    value = 52747
    if False and True:
        _dead_5201 = 30
        56
    text = __import__('base64').b64decode('SV9sT0JZN0I2ZHdnWVFBdnhJSHk=').decode('utf-8')
    total = value + len(text)
    return total

def _нЯфρХюХσяπΙжШТΞΒ():
    value = 685577
    text = __import__('base64').b64decode('S1JXbDJQaGhlall4RUowNkhFWEw=').decode('utf-8')
    if len('') > 0:
        180
        pass
        pass
    total = value + len(text)
    return total

def _ΜчЩДЩОΗЦчсрИσλ():
    if False and True:
        _dead_9002 = 972
    value = 650743
    if False and True:
        pass
        _dead_6240 = 14
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSjSOWMM8vArCij6kGWlYRYhyjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6575 = 244
        718
        270
    total = value + len(text)
    return total

def _γРГμфьΟΠПФй():
    value = 613186
    text = __import__('base64').b64decode('dG15TDkzZndPTkJYUkJFd1RTeGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ВьаηКНανЕυΣ():
    if False and True:
        _dead_2986 = 885
        pass
        _dead_4458 = 255
    value = 626808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EA3oRno1rv9baRqim26zNQ4e808='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _μΛΔсαεэдΚ():
    value = 429151
    text = __import__('base64').b64decode('dzhhc1JFTURLcG1JMjNtU05VZGY=').decode('utf-8')
    total = value + len(text)
    return total

def _МЦИρΧΒйΒαБРРКγπ():
    value = 486156
    text = __import__('base64').b64decode('T24zaXFoUGNXaEFheV9oVHlNVnE=').decode('utf-8')
    total = value + len(text)
    return total

def _чНοΒΠΘот():
    value = 653127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kg3BQmYt8boiEimV/2+qZxN7tUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кσΛΕНазцρΗйщΕ():
    if 33 * 2 < 0:
        pass
        _dead_5767 = 844
        _dead_1726 = 350
    value = 101858
    if False and True:
        _dead_9354 = 589
    text = __import__('base64').b64decode('bnU5R0FBWG96RVF2NDFFZURBTnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧгМПΟνТвтвДΖυτЬν():
    value = 102073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCH0Z18V3fkGFyugx2C7B3Z21Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΦмтчХΟΡвΜВη():
    value = 759888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxnhWQcvz40TPjWU3Q+xZD0+/no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 57 * 68 < 0:
        _dead_9270 = 351
        659
        _dead_5018 = 288
    return total

def _μΩщЯυЛΖЮшД():
    value = 185462
    if 83 * 73 < 0:
        pass
        214
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjX8W1VqzJ9WLyqMwnO/ITAf4UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if 19 * 45 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()