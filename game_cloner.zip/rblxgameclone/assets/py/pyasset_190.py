#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _АРжΛθςΑοωισюΣол():
    value = 225843
    if False and True:
        207
    text = __import__('base64').b64decode('V1BBWXk2Tk5yaUNjbjhqV1lac2c=').decode('utf-8')
    total = value + len(text)
    return total

def _дЬГκеιΓμп():
    value = 779828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRy0Pkce/I4RbRiNwH6YPxIn720='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сыееγΕΦνΕшχУЮαμ():
    value = 399851
    if 45 * 75 < 0:
        pass
        _dead_3088 = 169
    text = __import__('base64').b64decode('bFk1dFRydUFmZldxR2VTV3pWclE=').decode('utf-8')
    total = value + len(text)
    return total

def _МбЧвВоцсП():
    value = 995897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ7Ia2cI/5ArEjqO0FC2IXYF60k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щдрθΘπгДъ():
    value = 751969
    text = __import__('base64').b64decode('V1NITl8zM0dPcDk4TXZ4ZEtSeV8=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΝШфрΧπΞοВΨд():
    value = 592933
    text = __import__('base64').b64decode('TDV1UXd6SnhRa25HRjdJQ3kyMHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _еыΟλчюХЕΞΚоБЙαγ():
    value = 960634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzzNV3Zu+L4NL1q33leVGXEr6kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕАхщβсΛΕЮХдв():
    value = 284954
    if 65 * 37 < 0:
        _dead_9729 = 774
        523
        991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHbJVAgv+ZgPCwey+VC+Gh84234='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _УаОиьНпΛПЙκш():
    value = 460077
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhfuOUQUyoxWFByy2VOvGHI26Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щтдрщоЪрΠхιπ():
    value = 158405
    if 50 * 15 < 0:
        761
        pass
        _dead_2546 = 710
    text = __import__('base64').b64decode('TU5hVjAxbng4ZWdQQXlUN2xhc3o=').decode('utf-8')
    total = value + len(text)
    if 61 * 70 < 0:
        pass
    return total

def _щШЕТχЪΡΣЩζУΑ():
    if 78 * 30 < 0:
        pass
    value = 775504
    if len('') > 0:
        821
        916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FizcV3IV2ZALBT6C4AbAOAQG200='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 59 * 76 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_6265 = 148
        _dead_9760 = 810
    return total

def _ΛбМзτЦЙьΡ():
    if len('') > 0:
        221
    value = 996012
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwvsXkcA8IkvK1/7/0+6InEX83k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2962 = 950
    total = value + len(text)
    return total

def _σммюуδοъσсБσрз():
    value = 275570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Anfce0tq5J8iNQi25lioPS48zHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БНΞШщΚЕΩРЪ():
    value = 147788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICayYQAQzY8uKC2WwU6IICADx1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΜНЬΞΦщВЪФдч():
    value = 237575
    if False and True:
        376
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BybldmYJ+JxaK1n0xAa7ZnMQvEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЮΥσщΡΧΥρбдь():
    if False and True:
        pass
        _dead_2146 = 346
        600
    value = 835561
    text = __import__('base64').b64decode('dTlTbmQxVW16T2NEaE42TlBVYjA=').decode('utf-8')
    if False and True:
        _dead_1986 = 432
        584
    total = value + len(text)
    return total

def _σΝΟΙлοщсЛжκ():
    value = 372867
    text = __import__('base64').b64decode('V3FJamY3d2dqb0RaYXU0ZHhSS2o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        185
        pass
    return total

def _ΚрοεвйΑΝсгΟЗΡΔπ():
    value = 552587
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxjBZlo826svMyqn/32YE3Qf00w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖШΗсзΤДδцφЕΓиВΝ():
    value = 103607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiLGalxo/asOMF+Rw3G3Fyol6Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕЪВПуυΦЗΥДуΞХψЙ():
    value = 715090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bi3dfWFp3L0gICn65mmHLgMmxlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХфйъРΖегθхαиΗΤ():
    value = 93078
    text = __import__('base64').b64decode('S3ZFVXJEZFRzOGdFb2t5cU1kSkQ=').decode('utf-8')
    if 39 * 68 < 0:
        789
        _dead_4435 = 490
        pass
    total = value + len(text)
    return total

def _πЦтУыΣκччρ():
    value = 649520
    text = __import__('base64').b64decode('Y3pCWHlaRWRvVVJUbHVESGVveVQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        918
    return total

def _шнТгОКЗРΩвΜ():
    value = 451572
    text = __import__('base64').b64decode('c2gySlJrU25GOElOX3JfcjVrNUU=').decode('utf-8')
    total = value + len(text)
    return total

def _σшъХШцИмΕψЖГаΠцб():
    value = 869930
    text = __import__('base64').b64decode('TnJXQnFiWUZfUDNTRGhkMXdhRXo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1832 = 488
    return total

def _ЩхφЖΟυьХАγИΟф():
    value = 399885
    if len('') > 0:
        _dead_6944 = 215
    text = __import__('base64').b64decode('aDNDeGZIaGFyVE54T3JWQk5wM2k=').decode('utf-8')
    total = value + len(text)
    return total

def _щΙюεнЛηоФтΤΜф():
    value = 145104
    text = __import__('base64').b64decode('d2N6ZkFpZFBSN0loekt2bjJQTE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ηλЛБСжщυжАч():
    value = 707218
    if False and True:
        _dead_1127 = 106
    text = __import__('base64').b64decode('U2RyeWVyaFM0YjRfVGt2QWE3NGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _вйΑвЫΑΨιλωΥеΨф():
    value = 851554
    if False and True:
        _dead_3145 = 480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACSzRGIV7YM2AiCo2lCAGAQK40g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νζФиЯоνИкНЩЕλснΡ():
    if 27 * 15 < 0:
        _dead_1865 = 569
        pass
    value = 291744
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('VXVwUjRWQlJQRWYzaE9TSFlpVmk=').decode('utf-8')
    if len('') > 0:
        _dead_3310 = 650
        pass
        476
    total = value + len(text)
    return total

def _ΥкΟΠцгΡщКЮОμХ():
    value = 409366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgrtXQFp758Tbw2rmUG5MDQ7z2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _учΖжРβζμцΒрταΩЫΤ():
    value = 586278
    text = __import__('base64').b64decode('clRwRkZBOUJkb1ZBSzUwc0V1RFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕЗθъГЫЙΥьЫΤРμΑХ():
    value = 472841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHe2YHA23aUzMFq33nKYAQZ6z3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жщΥфζΝЪЕ():
    value = 893843
    text = __import__('base64').b64decode('T3RzUWZBbW9SNFRGNVJIQVh3Vks=').decode('utf-8')
    total = value + len(text)
    return total

def _ηξщцКΝηтζрЩлбю():
    value = 284476
    if len('') > 0:
        _dead_6455 = 623
        _dead_2508 = 639
        _dead_5118 = 243
    text = __import__('base64').b64decode('cWtybDFFU3R2YWpKZEZSOW1WbVU=').decode('utf-8')
    if len('') > 0:
        _dead_4400 = 807
        _dead_5666 = 280
        _dead_4036 = 711
    total = value + len(text)
    return total

def _ДΞκЪψХкяЫ():
    if len('') > 0:
        _dead_8762 = 180
    value = 656374
    text = __import__('base64').b64decode('QnZtbGVBVkhhbDFXR3pWZW5hVGg=').decode('utf-8')
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _кшΛφΩΞΗλμΜμαХаΡχ():
    value = 635249
    if False and True:
        77
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCXHZAJt3aZbHDWu5FLHNzAHxWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓсΝУНΨРъЧБ():
    value = 608700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT3CRGhsxvxWDCaqmGTGIREYsz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8259 = 504
    total = value + len(text)
    return total

def _хмωχΝΜυολ():
    value = 356572
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITjcOFgLrZs6Ih+W0F2vEnQBx0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФσΓРψхУΞ():
    value = 887276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lxy8a10BrvEGGAaJ3ACoZRQa8jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΘΛсοйЫЖκδΣ():
    value = 124779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRW8WVovqPAnIh/z3WmFZiI/y2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βΓφдъЦЭзщшε():
    value = 375195
    text = __import__('base64').b64decode('QVY1c1BNU3ViMU9JbklPWVRibmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯюБЯκφШταΧщ():
    value = 282932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fwj3ZmFo7YYKCj+v+ECpBiZ6zz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йςОгщнВПτижμΙ():
    value = 932720
    text = __import__('base64').b64decode('RjBfUEdwOEVsUnVhS1ZON0V3eW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑпЙψαВКΨΣПЕ():
    if False and True:
        995
        pass
    value = 536093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAi0PmYWpplXaxqR7Xe9DXcC0F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        246
        407
    total = value + len(text)
    return total

def _ЬиΝаΚΑζΘμζοОьТνД():
    if 71 * 89 < 0:
        60
    value = 237131
    text = __import__('base64').b64decode('QnN2cGhFQlFBRTBIbjJibjR3NTI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8561 = 456
        _dead_2491 = 99
        _dead_2446 = 589
    return total

def _ρδяцΑуκΣ():
    if 58 * 15 < 0:
        pass
        pass
    value = 616015
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRvHSHse+ZpXOyGy8neRACR99Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5891 = 84
        _dead_8826 = 775
    total = value + len(text)
    return total

def _ΛθπΡθγΑхЗРЦпе():
    value = 416124
    text = __import__('base64').b64decode('Y25ab0UyQmRXWVdoeFNBR01lY1U=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЧΣΓфΣиШУυПА():
    value = 149203
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD22OUAL8fsMFQm6ywaeYxF/wlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩЫмΗΝЯθРуфБΡкм():
    if len('') > 0:
        pass
        993
    value = 211583
    text = __import__('base64').b64decode('RGJUN0pROGVmc1ROWGJwRE1JU1c=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7221 = 767
    return total

def _ΩмЬЯЪсУжзΗΖщс():
    value = 361081
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCPKaV0pp4kkDxyr+32FEQMZ81w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        928
        _dead_5141 = 801
        _dead_1087 = 219
    total = value + len(text)
    if len('') > 0:
        _dead_9527 = 153
    return total

def _ЮαйНχУеΔщιθЧГ():
    value = 983576
    text = __import__('base64').b64decode('UUtVUjY3T01wTTFIVmtPNzFJbGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _рГкскЩиΥксйЧОΨ():
    value = 895696
    text = __import__('base64').b64decode('RWVub2c3RFlZaG5iZm1IcGxUSUs=').decode('utf-8')
    total = value + len(text)
    return total

def _βвΣΕСΖТβΠИЙЧЧеΘ():
    if False and True:
        _dead_5116 = 345
    value = 433742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBu0OQgW86FbDyy6x1qnMXEn620='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 6 * 29 < 0:
        pass
        499
        _dead_1983 = 706
    return total

def _ТшыИΣрбХΩфИзДКИС():
    value = 995579
    text = __import__('base64').b64decode('bFV3cE90SzlKQUJuWHNfaGlMbko=').decode('utf-8')
    total = value + len(text)
    return total

def _уΗХдЯΟАΦ():
    value = 143391
    text = __import__('base64').b64decode('QjN2V3VydUIybVVaaFNZcWszMHM=').decode('utf-8')
    total = value + len(text)
    return total

def _леΡλШмψнτХз():
    if len('') > 0:
        _dead_5009 = 27
        _dead_7147 = 603
    value = 574050
    text = __import__('base64').b64decode('Um50Q21vXzBhT0xGeGV1RkQxWGs=').decode('utf-8')
    total = value + len(text)
    return total

def _хψΤчЙεцδΙςΠΞЖЭ():
    value = 416729
    text = __import__('base64').b64decode('ZTF5ZFEyREpZYmdoQjlRWkFvbk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЖσбςνФοЦтυлшκ():
    value = 996090
    text = __import__('base64').b64decode('S2RVeEtmTkJtUFBHbnZpUWlwTVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ШъжΚιПθΝч():
    value = 22650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzrvPHU48q8oNDaV+ETGBTE7zkg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЩβшщιΑΩξщбяЮ():
    value = 735535
    if False and True:
        750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQbVVH0Syf4KaVi65G6bPBU2sH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔыДЕδΔΧαΝΗ():
    value = 195558
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzjbYVU29LgVaC6qngHJDRZ692s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сμуяоΗкАκΗφИеΦ():
    value = 541812
    text = __import__('base64').b64decode('YjZYQmRJaURTODhteGppX09pU2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _хщцшνчςФфТΕΚΘρБ():
    value = 941393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzvJQgk31qUCIjug4keRPAwfwFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σшγышΝЭΨЭΒЖыΤ():
    value = 431459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQm9dFBu+J5TNF2P8AOyIBR37k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛмдАъТмЗ():
    value = 148464
    text = __import__('base64').b64decode('Q0ZXWDl1SkpaYmw0V2FCY1BMVTM=').decode('utf-8')
    total = value + len(text)
    return total

def _цвУЦыуκΘЮξ():
    if False and True:
        _dead_9892 = 795
        791
    value = 597095
    if 10 * 4 < 0:
        _dead_9276 = 860
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjz9PmcIy64KGwe76We4DgIY4j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 74 < 0:
        970
    total = value + len(text)
    if False and True:
        593
    return total

def _ЬЬРяδμΣСЩЕаАЪЮъ():
    value = 895474
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyvCQGYzzaUZDCyx2gKiZ3w1yDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑθбΞΘλЙфтсГпЧБь():
    value = 824579
    text = __import__('base64').b64decode('cHh2Q1Jpc1hzdVVaZ3JOZzU4Mjk=').decode('utf-8')
    total = value + len(text)
    if 91 * 89 < 0:
        pass
        211
    return total

def _ΡζыζΞΞУΜδιγΤ():
    value = 430568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MADVeHY01pEoGSyM5gCfOys34EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фξΕΚΖΚΑн():
    value = 737192
    if 61 * 28 < 0:
        pass
        pass
        _dead_2712 = 807
    text = __import__('base64').b64decode('ZWdlQlY2NUlpWnFGZnV3ZUZpaHg=').decode('utf-8')
    if False and True:
        pass
        53
        480
    total = value + len(text)
    return total

def _ЩлАФСзΡИЭяβХзΞЯ():
    value = 312440
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHfOY3YS+/0xEgHx2g+JAB0Exjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЫЬВЗΓъС():
    if False and True:
        pass
        _dead_4145 = 825
        36
    value = 669533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KArXYl8DrbIMLyf6wg/JFzcj71s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зтπМΤЛяτУχι():
    value = 779821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXrCRUNuqKwiPzzy/WGiIxcp4l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6388 = 973
        pass
        _dead_6968 = 85
    return total

def _оςξΧαлΑΒАΥАып():
    value = 519741
    if len('') > 0:
        pass
        pass
        _dead_3179 = 708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3n1ZGlr1oY6CB6ImE63Mgk75zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λИθγППеъЪβζΦ():
    value = 300899
    if 80 * 14 < 0:
        _dead_9373 = 809
        215
        811
    text = __import__('base64').b64decode('UDFBU2lmOWhSSFh3alNOVnVJVWM=').decode('utf-8')
    total = value + len(text)
    return total

def _οРтлςиθБкэΟСЮ():
    value = 962684
    text = __import__('base64').b64decode('S2ZmSTFXdnZVdXQzSVhqaEI2d0I=').decode('utf-8')
    total = value + len(text)
    return total

def _нМΞНаЧΦгРуЛΠ():
    value = 300447
    if 16 * 90 < 0:
        448
    text = __import__('base64').b64decode('a1pwcXF3U1JoV2VjUWlBSXQzdlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _бλΜΩГФъιΛСΣжνε():
    value = 777905
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FD7KaQIM9fowGzb072+TbSQ9tV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЕΙгЦψСεΣУη():
    value = 748308
    text = __import__('base64').b64decode('ZHk3M1R1R1JYelhPZDVJNGRxZ2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗгΕтψΑΑдп():
    value = 785300
    text = __import__('base64').b64decode('cHRQc2kySjRLbDBfOUYyYmZDVmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔВνкОэУΩ():
    value = 672698
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3awOHsB2rwTbB6q4EXBMRZ87n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚβξΙΥΚюκд():
    value = 548187
    text = __import__('base64').b64decode('Sk5WUXdXbU5jYVlpbTB5RUNtSk0=').decode('utf-8')
    total = value + len(text)
    return total

def _лШЩАЗγеоЗК():
    value = 999961
    text = __import__('base64').b64decode('VjN5WmJPNGVLbVpEZEtIYkt4YVo=').decode('utf-8')
    if 47 * 97 < 0:
        _dead_6737 = 673
    total = value + len(text)
    return total

def _ΙщйиψβикнτЛπχМΤ():
    value = 816433
    text = __import__('base64').b64decode('eXpRWnYyckZ3Nnpzd0ZlbDFqbXY=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_6627 = 697
        pass
        _dead_2700 = 572
    return total

def _пщШЖжЙЛОυШЙ():
    if False and True:
        _dead_3552 = 480
    value = 36999
    if 34 * 21 < 0:
        pass
        693
    text = __import__('base64').b64decode('R0xtTTQ3cXJ5ME9CMU15R0htOVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _юΖπΝДЦуΖЕΛ():
    if len('') > 0:
        pass
        _dead_1248 = 987
        _dead_6963 = 393
    value = 537895
    if len('') > 0:
        669
        _dead_6457 = 581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDb1dAA19aIKPA63mFrBByYE/T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΘУРανМδы():
    value = 41463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXjpWFUAz54JDiOH3wW2EgEh71Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΨΖэΩιФΔцΞдΜψщЮχ():
    if False and True:
        17
        pass
        _dead_2180 = 727
    value = 306382
    text = __import__('base64').b64decode('SkZCM2ZUNUdGdEJVUFlxVDZJQm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔЧβποτНц():
    value = 103756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyfKd3k8+rxQbi2c/waDYAx9yUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гиΕυχЧΨсΝΖ():
    value = 144787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njj3f1Qd6KUWAiDzm2nBIgM31Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кщйЪЮхкφοш():
    if 49 * 70 < 0:
        pass
        687
        831
    value = 974564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiWxSn9pzp4Zaj+c0UeDLREptks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 56 * 68 < 0:
        pass
        666
        pass
    total = value + len(text)
    if False and True:
        334
        504
    return total

def _ыЮъΛχУЧюфВоΗФζ():
    value = 256436
    text = __import__('base64').b64decode('ZWJTT1UzTzJONDNFWENhYklfUDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜСиИШНЫаκоЦζт():
    value = 35195
    text = __import__('base64').b64decode('eVY3UEFrY1p3QU5KZE9uR04ySHE=').decode('utf-8')
    total = value + len(text)
    return total

def _щНΣδΗρТυЭзЮЪоЪРШ():
    value = 690590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiL8dwchxKMIOT60kHqlZXUh0Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣъЯΒΙщПю():
    value = 843411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQywTQAx/bIOCSL0mlCAYS8K4F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2695 = 141
        _dead_6432 = 155
    return total

def _яюрщЩΕЪъиэЖъ():
    value = 101181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT/qOm4Q65lXaivw+EO+HA4L9GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪξΜъЙρνΓСьцсгΑ():
    value = 993053
    text = __import__('base64').b64decode('ZkFPd2FUZ1BEcHgyUlBET0N6MnY=').decode('utf-8')
    total = value + len(text)
    return total

def _δψахЫΜжъΛσ():
    value = 837408
    text = __import__('base64').b64decode('V1R1eEh0R0xydnFPc3dPcGc5cXQ=').decode('utf-8')
    if 29 * 52 < 0:
        _dead_8335 = 570
    total = value + len(text)
    return total

def _ЯνΟяδпЗΝωР():
    if False and True:
        334
    value = 371333
    text = __import__('base64').b64decode('cVlWRWdWQlZNUU9MSjFCa2Nabjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦυЬуΧΕΝунКДРφσΩΡ():
    if False and True:
        pass
        pass
        40
    value = 604969
    text = __import__('base64').b64decode('VEFUdkFpR1lOTkpyVzFRNjJaU0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒБДЩюΥξЯЫβЪуфηхя():
    value = 851781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzjsXAQO2r9QMxuW63PHGjd97jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УηНбλЯпь():
    value = 940468
    text = __import__('base64').b64decode('Q001SzZVcmZDa3lfZXBsOVZIWF8=').decode('utf-8')
    total = value + len(text)
    return total

def _йξбСфрαхΗζΨцЦΘТ():
    value = 89293
    if 22 * 91 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FifuXFUt0KUnIjWcwV+ZOQEh8X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8361 = 204
        _dead_7340 = 676
        pass
    total = value + len(text)
    return total

def _ГйΧэγξΠΙξжΑХЫφр():
    value = 998982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwLMO2cMzoRaNFqly1rDNi4b/jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЛеЮυςΞΥнУЗψыЧхк():
    if 77 * 85 < 0:
        2
    value = 246215
    if len('') > 0:
        pass
        _dead_2974 = 35
        277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyDBRQVs1r5XI1iP8kORNRc/zWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 93 * 31 < 0:
        _dead_1576 = 130
    return total

def _МчρйыкЮχоН():
    value = 31273
    text = __import__('base64').b64decode('UTlNbllKRG0xSnRwOVF0dEQya24=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭζΞчдΕЕйΟцπКъ():
    value = 72121
    text = __import__('base64').b64decode('b1FUbjRTZWFPZW8xb2RfTFZEM2k=').decode('utf-8')
    total = value + len(text)
    if 86 * 27 < 0:
        664
        _dead_2665 = 522
    return total

def _ЧкЖХЫДοМЯΜикξ():
    value = 484059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3ryO2kq1aRXCz2G50LIbQB+3Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γЦЫΗΓΩΙхψщщьц():
    value = 590524
    text = __import__('base64').b64decode('SDhIb0toazl2NmpzNkNUeXl3V3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙГоцжлДСΠДжГΩДш():
    value = 898603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISnben0K1q9TDC2G6l2iGHYDxVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςлЛэГΩВЭοА():
    value = 936674
    text = __import__('base64').b64decode('YUJDWUk1MmwyYVpnOUY5V0JPckM=').decode('utf-8')
    total = value + len(text)
    return total

def _τФεχεхδцαЦΩжМιε():
    value = 222984
    text = __import__('base64').b64decode('c0NKVTlUNzU5azE5YnlFeDhrd0s=').decode('utf-8')
    total = value + len(text)
    return total

def _мβθρΩЛΨΔгοХвЮγΨ():
    value = 943157
    text = __import__('base64').b64decode('UFVDUndFVGFidlpxUkliSWZnSFg=').decode('utf-8')
    total = value + len(text)
    if 44 * 78 < 0:
        pass
        pass
    return total

def _яЫΑειγΩЛ():
    value = 995139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQTgbGId+55bNVqbzWSWBjQt3Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θКτЬРСηКПΠ():
    value = 985010
    text = __import__('base64').b64decode('TXB6YUVKMmZaWXliRkQ3RFRNOU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ψσεΩЪζогщеЫΗгνэ():
    value = 644250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg3hRFgN7PkRPh+R43uEETM95no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΘιЧμЦυππГ():
    value = 930548
    text = __import__('base64').b64decode('VlMzSG9uTkpDZ2FjVG5oaW5jTHk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _гΦгмΨарЗлΟΨ():
    value = 83484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCThW0MNq6UrEQ30zFWKAC0t0lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эКАΨлЙЯеЕХΞ():
    if len('') > 0:
        _dead_5916 = 980
    value = 108601
    text = __import__('base64').b64decode('TUZLQ25VMW1GWXQyMmR0cW52R2w=').decode('utf-8')
    total = value + len(text)
    if 34 * 4 < 0:
        pass
        756
    return total

def _ЕΛΠиΞΞφБ():
    value = 671202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADrzQm4L1qobFFjz5FClPTEY5j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УρφΣНΖΙУΤьжпЖЪζЪ():
    if False and True:
        _dead_2892 = 784
        pass
        _dead_7237 = 252
    value = 509923
    text = __import__('base64').b64decode('TGpiN1o3YUgxNmtFX2FyWGtMR1U=').decode('utf-8')
    total = value + len(text)
    return total

def _йθςЭВΖбξφЫД():
    value = 828501
    text = __import__('base64').b64decode('RGsyZzRPbnAwcndqU0dmYTFWclM=').decode('utf-8')
    total = value + len(text)
    return total

def _хμЮхμωйδВЫЙξуςпΧ():
    value = 778525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBDcXXYp8LIBOyuOy2SxbXQZ4Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъνπШцχυΝρЧΞмСςт():
    value = 292711
    if False and True:
        pass
        _dead_9122 = 422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx/1Nn0T7JoXEV6HnWWRJTIc4Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΗΤΩУοΞЕНΛушεο():
    value = 226078
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCD+QEYy1fAqPVaqyUTDEgIlwlc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        234
        _dead_1148 = 829
        _dead_7265 = 82
    return total

def _ΤоΞжεπчЕХυбΤБΠ():
    value = 903630
    if False and True:
        813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fiz+SlIg2K0SbQKpm3+oDRANzTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 49 * 72 < 0:
        _dead_2311 = 819
        _dead_7705 = 996
    total = value + len(text)
    if len('') > 0:
        _dead_2477 = 343
        pass
        _dead_6016 = 44
    return total

def _щδшСΗνучηЦаБ():
    value = 903213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTzFSkk16YEGFyXy63DIGzQq/Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗТьΘθЮФнюМβ():
    value = 956835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCXtd1IYqIkzNVjz7U6GJHcm4U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΡЩΑΛмэьь():
    value = 723794
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRXDVFMh0oUML1+UxHSkDCEs6Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιъΒяЯъΕхΚ():
    value = 952965
    text = __import__('base64').b64decode('T1YyMWVadVZnZ0ZISjVQdjFiSmg=').decode('utf-8')
    total = value + len(text)
    if 54 * 47 < 0:
        _dead_4927 = 9
        500
        _dead_9554 = 589
    return total

def _иЦьωЬΚДЕ():
    if 65 * 66 < 0:
        pass
    value = 269848
    text = __import__('base64').b64decode('elp1Mmg5QkhhV0pFSWk5c3VRZWQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1147 = 454
    return total

def _ΖСΙμЗЗφНчрΟΡ():
    value = 439981
    text = __import__('base64').b64decode('RnZWMDBzaEpQNWd1S0VRaV9OVXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤъЯЭчхАΡΧΥ():
    value = 720464
    if False and True:
        pass
        195
    text = __import__('base64').b64decode('eDhuRVNIbENFVDI0NHFqZ2NnX1I=').decode('utf-8')
    if len('') > 0:
        302
        676
        pass
    total = value + len(text)
    return total

def _ΔΩνцухΔжψ():
    if 62 * 68 < 0:
        pass
        pass
    value = 326728
    text = __import__('base64').b64decode('SVpqazZVSjRjV3dGVFFOQnk1M2I=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6234 = 468
        574
        _dead_4947 = 631
    return total

def _КθЭьΨЮлЦε():
    value = 622876
    text = __import__('base64').b64decode('YnpyeG45ejV6MmdkV2Y0Xzd5V20=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞАаΣыТΛΨ():
    if False and True:
        362
        916
    value = 927064
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxfheQAw1rBTCi2l7Q6DbQwV9Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κЮξξЖΑЛΡ():
    value = 325763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXjbRGEu3Z05YhiR+3TFP3Mb0mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        879
    return total

def _пΣχΣβЦйΘЩБцНэΡπ():
    value = 166839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTy8awY10qAgPx+u8WLEEzEmxnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зρπшχσщхЧχζЫ():
    value = 252757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISn1Q0YJ9Yk1Ej6z0nTGJBQC72k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1866 = 865
    total = value + len(text)
    return total

def _ОъьзУσςчШΝ():
    value = 584356
    text = __import__('base64').b64decode('cnlFUWZEc2tCYllUcWZJc1VzNHM=').decode('utf-8')
    total = value + len(text)
    return total

def _чΗΓшγЕСдκκ():
    value = 714194
    if False and True:
        536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx3QVmQs35orOz6iwGChHwYJs0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΜΥеьХчэ():
    value = 308581
    text = __import__('base64').b64decode('UG51OXFabjFLcGgwb3Jhc25QT28=').decode('utf-8')
    total = value + len(text)
    return total

def _жχеαМоФλОρΠι():
    value = 14929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCG9YmAI1rxQEQf1xn27BQN9034='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞθыэЪпРΦΔхХψв():
    value = 294871
    text = __import__('base64').b64decode('SmtxbzJBdWtub1hjS0RBdXREa20=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЧΜΥБфхИзюДЛπлоЪ():
    value = 538854
    text = __import__('base64').b64decode('elE5ajVydWVqM3Rpd2ZhcU44Ykw=').decode('utf-8')
    total = value + len(text)
    return total

def _УμςШжωТОЗ():
    value = 292143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAfNaVAfqvwLYlq65UG5MD8l1D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 23 * 17 < 0:
        648
    return total

def _РυηвЬυΟПЛгйХеЬξ():
    value = 809223
    text = __import__('base64').b64decode('SnJoVk8wWkxqbFRhZUM4eE14c3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΟтБпУХыЧБΨνρ():
    value = 417684
    text = __import__('base64').b64decode('d29YamUza1FiazZyYTJOcFdIX0E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΔЫαΡΤРΣτ():
    if 48 * 20 < 0:
        pass
        826
        pass
    value = 213911
    if False and True:
        pass
    text = __import__('base64').b64decode('TG43Y1V6SWxEbWhrdHlxc0hsTXk=').decode('utf-8')
    total = value + len(text)
    return total

def _иЫебαЗΞтрСуνДи():
    value = 985044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bi31fmEqy5klAi2x6VSgLQc50Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7766 = 206
    return total

def _ΞюЮЮφщфеоΚЖμЕ():
    if 55 * 59 < 0:
        _dead_5504 = 61
    value = 170724
    if len('') > 0:
        655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz30bH4B24EODVi53FmeAh0esG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_6015 = 412
        447
    return total

def _ЩΞПвжЩлρΜКСΜΣЮαз():
    value = 477111
    text = __import__('base64').b64decode('TEltS21pUXhfb0xSa2Y2aWRodm0=').decode('utf-8')
    total = value + len(text)
    return total

def _НчцЦρмΜΓη():
    value = 962651
    text = __import__('base64').b64decode('ZG84RWdHc3Q0NThEeEl3d0hCZEc=').decode('utf-8')
    total = value + len(text)
    return total

def _СФχМζΥнΗ():
    value = 469539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Egf1Pgkc2atXGwmKx0eWZSt+828='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        573
        _dead_1934 = 393
    return total

def _УчЯДЛБЬΖμΝЩψτ():
    value = 705062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EivTSWUQ7oNXMDyNmHOSODZ+8Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вюФвИξЮк():
    value = 826055
    text = __import__('base64').b64decode('aUFMV2RRemRjUHptUnFnWE91U1g=').decode('utf-8')
    if 4 * 6 < 0:
        995
        739
        _dead_6226 = 72
    total = value + len(text)
    if len('') > 0:
        _dead_9071 = 463
    return total

def _ючζωοΟΤЮφЦυпЖΨ():
    value = 932944
    text = __import__('base64').b64decode('emFQM194VHU2NUFoeTNqcTZaWDg=').decode('utf-8')
    if 7 * 42 < 0:
        pass
    total = value + len(text)
    if 91 * 55 < 0:
        _dead_4669 = 437
    return total

def _ХΟцсσуАШПД():
    value = 316077
    text = __import__('base64').b64decode('aHdQQ1dIZ2N5X3VIUnJwM25BUkk=').decode('utf-8')
    total = value + len(text)
    return total

def _уΓΟгыςэιзΝЭΕЕ():
    value = 10135
    if False and True:
        _dead_7224 = 364
    text = __import__('base64').b64decode('cWdVZ085TFVyVktndjVMSzBiZnA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_5499 = 162
        _dead_1496 = 62
    return total

def _ьцΞеъεκμзБиθХξ():
    value = 264814
    if len('') > 0:
        _dead_4403 = 963
        355
        _dead_5768 = 433
    text = __import__('base64').b64decode('WXpIWG5wa256azBYU01ya0F6MkE=').decode('utf-8')
    if len('') > 0:
        _dead_8278 = 252
    total = value + len(text)
    return total

def _ςыρМПъЙрНюЯио():
    value = 29984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CArAYQQD9vsCEDCNx0a6LCEJ8XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДдΩГΧбчътΜΡΧηЦ():
    if len('') > 0:
        _dead_5175 = 379
        pass
        pass
    value = 194585
    text = __import__('base64').b64decode('ZkxXdVhMY1B4Z2NKMzlzTUxRR0k=').decode('utf-8')
    total = value + len(text)
    return total

def _δТсйШнюα():
    value = 482420
    text = __import__('base64').b64decode('ZWZCeFo4WjBwd3FGTzVHV09ONzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ωшЖσΗДТжΓ():
    value = 292453
    text = __import__('base64').b64decode('QTZPSHNSZDF2QTZLOFowYURLeDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _юαДнУеТлΜБЯΟΑΗ():
    value = 953923
    text = __import__('base64').b64decode('bk5ESGdZSzB1V09LWVdtdHp1UnU=').decode('utf-8')
    total = value + len(text)
    return total

def _шρЦιοχРΜΚцхЙηεψ():
    value = 577953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwSwQUs+/LE7a1yK8U+lFxMKxng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БδЫΒσζωкΛюЬΓ():
    value = 906708
    if len('') > 0:
        246
        _dead_9347 = 272
        pass
    text = __import__('base64').b64decode('TnNnbVdLVm5zaHdEZEt5Q04xdmM=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _пиэьпещЮρ():
    value = 823736
    text = __import__('base64').b64decode('Z2t6eDJyWXVKUmxidWJUalkzUEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧУφαθΧΗΗеΝςл():
    if 64 * 92 < 0:
        226
    value = 561687
    if False and True:
        pass
        47
        _dead_1511 = 536
    text = __import__('base64').b64decode('Y0NmakpIbW9zTDVGSTcxZURpNzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 51 * 28 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    _dead_2722 = 564
    766