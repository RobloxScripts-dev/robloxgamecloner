#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΧεудеиЧйοИΛβьДΜΝ():
    value = 570522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MybBd3MR358VbDmKz37FJCN2/GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χνХофАГРωΒΛ():
    value = 434124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACz0PksVyakrbCuUw3ObInAp90Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        586
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _мрцεСЛькχΗΤδъЙλ():
    if len('') > 0:
        _dead_2021 = 0
        pass
        _dead_8190 = 814
    value = 381416
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB3Pa3447PsTKieg+2GSYXcl1H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        892
    total = value + len(text)
    if False and True:
        165
        390
        _dead_8938 = 703
    return total

def _ΥРΕΩФпЙεМяΠг():
    if len('') > 0:
        665
    value = 736106
    if 31 * 84 < 0:
        _dead_7316 = 320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBvMOncz24YFKQz0xnC2YwIt5TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 45 * 3 < 0:
        _dead_2411 = 672
        642
        397
    total = value + len(text)
    if len('') > 0:
        _dead_1713 = 643
        _dead_5193 = 710
        pass
    return total

def _ΩΔΘΗутЕЛΦЬΑж():
    value = 316252
    text = __import__('base64').b64decode('T29yRVhrSmpCcWRxVVpkUGxDbFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩфΥмАβКСΓΣсУνγОы():
    value = 756397
    text = __import__('base64').b64decode('VDZDUjJaY0pYcERyTjNPMTNqcGU=').decode('utf-8')
    total = value + len(text)
    return total

def _УдГэΠΖХЛЩм():
    if 15 * 24 < 0:
        793
        pass
        150
    value = 166340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax28e2AuyJtXNBeNx1G/IHYctzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТГпδЖГзиλ():
    value = 247040
    text = __import__('base64').b64decode('bDNtQWNhNVAxTHEzYmRhak9UdXU=').decode('utf-8')
    total = value + len(text)
    return total

def _λдНбεгΡуЩУψьβΨъС():
    if len('') > 0:
        pass
        pass
    value = 557297
    text = __import__('base64').b64decode('d3JCYk13Q18wWkJYa2VzOTlCVEc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        494
    return total

def _илГЕαръНАωЮмИч():
    value = 100111
    if 37 * 8 < 0:
        _dead_7879 = 565
    text = __import__('base64').b64decode('Q1BxNDhqZlk2bk1wUjQ2eWh1U0w=').decode('utf-8')
    if False and True:
        554
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _μгажΧЖкχκхеμ():
    value = 621425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAPOVnIJxpwqHVeiwFGbPhom1mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 43 < 0:
        _dead_2246 = 449
    total = value + len(text)
    return total

def _νсυяВΓΟпжянУЧ():
    value = 869209
    text = __import__('base64').b64decode('aUlHbUcyQ0lwY0VYS0tDWDhZVzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΧЬΛΟΨΚνΟкФОмοηΤ():
    value = 267751
    text = __import__('base64').b64decode('UHNDRF9pamIyRktqWUQwdWpPd3c=').decode('utf-8')
    total = value + len(text)
    return total

def _лΠЯюшЙμЛКвρрΠζω():
    if False and True:
        720
        _dead_9174 = 639
        390
    value = 566147
    text = __import__('base64').b64decode('SjRaMGhLbVhqdlhlbUFnZDF0MUY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4915 = 967
    return total

def _еРλДьΟУЦθЬρфяЧμ():
    value = 568712
    text = __import__('base64').b64decode('TlhYZE11WnlWendXX2xYczdGRDc=').decode('utf-8')
    if len('') > 0:
        335
        _dead_8964 = 672
        pass
    total = value + len(text)
    if 97 * 9 < 0:
        630
        _dead_3986 = 624
    return total

def _οжοΜтйΦПς():
    value = 892785
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCfMPnkIqqISHiuQ+XKXGww75zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΩСςЖΩЬσξяΒδЫЬΗщ():
    value = 218583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgrzRlcK16dSCj6vkAKcFyEn4l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 69 * 56 < 0:
        813
        28
    total = value + len(text)
    return total

def _ψφкКзНАщмжΦкαφ():
    value = 336705
    text = __import__('base64').b64decode('SjNjdUtzamRJcmxvUzI2RTZIR1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖГЬτКОЕθΒζъхυ():
    if 53 * 57 < 0:
        777
        686
        _dead_2687 = 859
    value = 165751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzzmOAY69YUQLBebwUOCOycusWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5344 = 190
        958
    total = value + len(text)
    if False and True:
        _dead_5693 = 667
        _dead_1818 = 25
    return total

def _ЪфΔФΙΒεψМλИг():
    if 23 * 63 < 0:
        _dead_1243 = 366
    value = 614319
    text = __import__('base64').b64decode('ZmxMZDNjbnFnWFFOemNkdERFTUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ρОγγηЛЬΕчлχуЫе():
    value = 800844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXj2R30b3KcpFgSLwX+yOzA7tGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖтюξΟЮжаΦχдΓбБ():
    if False and True:
        pass
    value = 841173
    if False and True:
        918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBfDeQc2/5sWbxalkAe4DHEH7WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рВΞФΝαяΣρωΥЯаХт():
    if False and True:
        396
        726
    value = 431970
    text = __import__('base64').b64decode('bzg3ekZwUTFmZ0FpNURFbGFwMk8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1026 = 577
        _dead_2556 = 274
        _dead_2279 = 558
    return total

def _ωНнУУΓцоЯΘ():
    value = 467401
    text = __import__('base64').b64decode('WVZwV09FRERjMEd5ZjFqTEFJRFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ОХκαБοΧрΙΟΕЭык():
    value = 712898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PACzY3pqyLIOPDCK71SHYR0D1jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΨдЭаΝбΞΥΞивГЭ():
    value = 994530
    text = __import__('base64').b64decode('ckZ5Y2tMS08xU2lfMDdMcHdvSEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЗчηЛмηпΥΖюξΚθФΩ():
    value = 882305
    text = __import__('base64').b64decode('RzFteWI3d0hUMGVVU3hpMlNlelE=').decode('utf-8')
    total = value + len(text)
    return total

def _χνοεяТДΜбΦωхиΩЪ():
    value = 925571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CC7jQGM/1/kbAyiw3g/AAT0C6Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΩьЕΗюлφхεЧцсΑρ():
    if False and True:
        _dead_3330 = 245
        _dead_3219 = 131
        pass
    value = 110559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTXLP0k+qrkuOQyI33SHCyYt8kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 6 * 85 < 0:
        pass
        pass
        _dead_2692 = 738
    return total

def _сΘфςчΚнωΒ():
    if False and True:
        _dead_4044 = 595
        _dead_3692 = 798
        307
    value = 368930
    text = __import__('base64').b64decode('VUdTMDNkbG1PMFNORHdaUDVpRVc=').decode('utf-8')
    total = value + len(text)
    return total

def _НгρАбшДΟΑ():
    if len('') > 0:
        665
    value = 681643
    text = __import__('base64').b64decode('SHVxMHZRQ2I3V0xIX3Zob0RuZkM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3670 = 473
        292
        _dead_2653 = 736
    return total

def _ΙФАοытхСιν():
    value = 80175
    if len('') > 0:
        _dead_8656 = 330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQ3CeGVp6IAQIAmA0mCTZQF2tmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЧδШУылЕςκйы():
    value = 327035
    if len('') > 0:
        936
        pass
        _dead_1160 = 823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwXbdkk7yrkvYg2uxwaGZQF/xXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΣшАеДЕБю():
    value = 294757
    text = __import__('base64').b64decode('cTdEelVXZ0N4WXJ6dTVQaWd4Vzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩВΑчφΩБπ():
    value = 291342
    if len('') > 0:
        _dead_1134 = 318
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBXFNloL9YNUNw6o8FKpJyYdz3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εфЪΝΨнΛЭл():
    value = 673594
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzzGYWgD7psCOR3xnF2CZA17y0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝμыпЛЫνЬΟεΑΞв():
    value = 243917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBjFOgIdzKcKaVegxHSgBSIB3D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЫЖьЭРлаζэοΩ():
    if 6 * 39 < 0:
        _dead_3317 = 937
        828
        39
    value = 242528
    text = __import__('base64').b64decode('TFY2Z2JvNzFSc1E2cDlYaGgxRkk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        50
        pass
        931
    return total

def _ΑгАΦπΞиΜПЙΒа():
    value = 356741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CR3XSgE61IdQDFqi+QGkAB0i1Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ЪвФсςΔΨΟρλγΚλυП():
    value = 847644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aw7lWkQ69KEialaA/U6WIn0r6z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СοъщΟηМр():
    if 65 * 52 < 0:
        968
        pass
        _dead_4587 = 389
    value = 638579
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiHyekEr2os2bFy22leyAT093jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΧУΚрυυηаΝΤжΣγ():
    value = 30756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LS7bX1QY/YQuDFaA30WxGRM8528='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АβднΨΒιЬψзΒ():
    value = 312723
    text = __import__('base64').b64decode('VzUzSGY1UlROWjh2VzlTdHhGcVE=').decode('utf-8')
    total = value + len(text)
    return total

def _λΙΧΕΦЫμЧ():
    value = 623730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB/jfAUe6b0HLgW62nKSM3Eh7EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΚХθопИЗОΑюΛрЯйν():
    value = 560234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jx32am4f34VSO16Z5VebBy9/1mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗзδнэΧζδδъγΞщс():
    if len('') > 0:
        pass
        _dead_5126 = 543
        925
    value = 518339
    text = __import__('base64').b64decode('b2VYTlg3X2ZLak9aRU5PM1N6UlY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕоσуρσТЭφ():
    value = 332689
    text = __import__('base64').b64decode('bXJWcm50UWhfUFFMcklMa3JUYkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΟγАβпΡЮΛ():
    value = 438355
    if 71 * 26 < 0:
        pass
    text = __import__('base64').b64decode('bm40aDNrbDVSbjdINDdwcWFPVG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕοΥθяППΛгπВ():
    value = 246469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgTeOVhsyf4UCD63xX6THg5/11Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦэЙтφσнГШ():
    value = 896920
    if 62 * 14 < 0:
        pass
        116
        pass
    text = __import__('base64').b64decode('d3poZEFQYnBOSmdnYmEySG9iSEI=').decode('utf-8')
    total = value + len(text)
    if 49 * 82 < 0:
        _dead_3949 = 233
        396
    return total

def _ΑΛоΑΖΒΟΜЫЖУУМΣ():
    value = 562629
    text = __import__('base64').b64decode('VlJaS0doazUxOVFNY1ZtcGhYMTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ТυЦФХζыТΦктгждбΨ():
    value = 884315
    if 89 * 5 < 0:
        _dead_9950 = 249
        pass
    text = __import__('base64').b64decode('QVBKbVlQS0pucHdrSmZBSkx3dWM=').decode('utf-8')
    if len('') > 0:
        _dead_7331 = 433
        pass
        225
    total = value + len(text)
    return total

def _иЧΤαλэХкьΩд():
    value = 675240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS73YX86rYc3ERms5XevYjIg5V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СхЪЫсЪЫΣПΛз():
    value = 735839
    text = __import__('base64').b64decode('eEd3RG1Tc1oxMHY5dEFtbGhlNWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ψчВпЙчξΤσТСЦξх():
    value = 96938
    text = __import__('base64').b64decode('TzdwX0xiNEZrcWIzdnl6WW9oM1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЬщψбнФхΤπБ():
    value = 959244
    if 47 * 37 < 0:
        36
        pass
        pass
    text = __import__('base64').b64decode('dWo2cGtnVEE5WXhQQ0V0UHptMzM=').decode('utf-8')
    if 69 * 93 < 0:
        _dead_6650 = 530
        _dead_6282 = 607
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _λΠνйυЕгΡБΕεφю():
    value = 735825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHrTPF5grKBSbQKq6mKSPA4F5Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        271
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_1713 = 700
        _dead_2502 = 114
        _dead_2746 = 52
    return total

def _υгΟзФπъТъпа():
    value = 664142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAnIQHwq16szPQix8luhFT8OvF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бТОγмοщσΛΜΜРДИиΛ():
    if False and True:
        pass
        345
        pass
    value = 971830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDi2f3Iu36cKERuU73uxBCg6vUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙЦщσЩζСΝсПУЫ():
    value = 432593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAOyflI15vwnCzymm32cNTwf6zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦпΜыЯбЪωрΕгщαц():
    value = 313117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzrWaXgK5IMJNl/3xFyeBzEf10I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1856 = 334
        _dead_8492 = 423
    return total

def _иЩлςΨжФЫχИ():
    value = 685325
    text = __import__('base64').b64decode('bFRjSndybUNueEtLQldCM1RKbFU=').decode('utf-8')
    if False and True:
        561
    total = value + len(text)
    return total

def _ФтβψкεεюЮ():
    value = 802197
    text = __import__('base64').b64decode('d0VTNUNlUmt6Z1M2OGRwN0N5WHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙУЛΟПΙвζУ():
    value = 594808
    text = __import__('base64').b64decode('UllhQlRKQ0ltQ1M5TzRmZkpPWU0=').decode('utf-8')
    total = value + len(text)
    return total

def _сыКΚэШΟΗυЭФΔφΦ():
    value = 660568
    text = __import__('base64').b64decode('dmk0Qktyc0xQN2hMc08weEozR2c=').decode('utf-8')
    total = value + len(text)
    return total

def _сχЕζΦТЮε():
    value = 410174
    text = __import__('base64').b64decode('RlFDQkM0VEZfeVJZY0hHRGhrZ0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _УфЭТΣρъКВВНуαм():
    if 52 * 41 < 0:
        235
        530
    value = 561019
    if False and True:
        _dead_4923 = 529
    text = __import__('base64').b64decode('UVhKcGxLeXJJMG04a3V4TWVfc2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛφЫЕπηαεИХπхпбΩи():
    value = 329078
    if False and True:
        pass
        _dead_4216 = 738
        _dead_7454 = 385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT7TSUIQrq8uDFmX4AScGg0Bzmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 87 * 60 < 0:
        _dead_7625 = 439
    total = value + len(text)
    if 63 * 57 < 0:
        675
    return total

def _σьηпΩЧρμΗλЮвΓ():
    value = 235007
    text = __import__('base64').b64decode('YjlpejdwV1dpYnRaYU5QZ2JaMXg=').decode('utf-8')
    if len('') > 0:
        _dead_3414 = 478
        pass
        pass
    total = value + len(text)
    return total

def _ΙΨЧΥьпиΤ():
    value = 961991
    text = __import__('base64').b64decode('Sk5Wdkl6b29EVEE0cHlpMXBWVUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯАуΤвΡАθЯЯ():
    value = 853886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAq3ZXgUqIJTazemnULGBgQ98Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙДМωΠхφΟζкЖ():
    value = 776968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR23RH0r3LggDiOp5V61DgggwmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςвхθыоБΞεшзЬΟа():
    value = 276165
    if 80 * 49 < 0:
        _dead_3921 = 910
        pass
        pass
    text = __import__('base64').b64decode('WnlycTJFMDhyaENrTm1aV0U2SEU=').decode('utf-8')
    total = value + len(text)
    return total

def _χκъЧΛθкЬцтЧАы():
    value = 8227
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh3bdn9vrvwwPAj7x2KdCwQX1z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΛкОοΩКЛЮ():
    value = 375772
    text = __import__('base64').b64decode('bGk2aWZaRWk3TF9kaTlqMU95S0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔзбйЗΡπΡαа():
    value = 934978
    text = __import__('base64').b64decode('VVdOazFYNmx5WkxYZHdfTER6T2E=').decode('utf-8')
    total = value + len(text)
    return total

def _μЛуОυνΠΥνΣзИρ():
    value = 737810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cyv1XGg91qYIFzyOx1KXFjMZ9kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΛδЦΞВцεЪюд():
    value = 709365
    if len('') > 0:
        pass
        801
        _dead_1274 = 293
    text = __import__('base64').b64decode('V19NUGdYbWFJOFUxMWR0Slp6Q1Y=').decode('utf-8')
    if 64 * 4 < 0:
        280
        697
    total = value + len(text)
    return total

def _ЛκυыΦБψξЗЗ():
    value = 182951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgvROVY9yvoiBSWw5lezJTQA8EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вСΑЗгЭхδЭЦЭм():
    if 18 * 85 < 0:
        46
    value = 64887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSLRQFUrqPsvKBb3/36EGiAFwk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        667
        pass
    total = value + len(text)
    return total

def _лιТωЪдЬЭΖΛлшΑа():
    if False and True:
        pass
        671
        611
    value = 199921
    text = __import__('base64').b64decode('WmxCMmJBeUVxbGp1WE5YWEkwbkQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2511 = 385
    return total

def _ΙцемйяψΞЪΠОμСяФи():
    value = 254332
    text = __import__('base64').b64decode('Y0g4eEc2Z0U4UWp2X3ZQQmMzZG4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        687
        _dead_2353 = 559
        171
    return total

def _σЩΗшеЪЙЧΒЖ():
    if len('') > 0:
        pass
    value = 690255
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwzJT10V759RPwG2nny6PRor3Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΧΕгΣККГΜΛθΔй():
    value = 552360
    text = __import__('base64').b64decode('UUo1cVBhUldfY1hTejdMaVBHRUs=').decode('utf-8')
    total = value + len(text)
    return total

def _фκЭущЛρΒЙД():
    value = 558680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhvFWmVg3LwEPVmR7VyaEnYss2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лХγοζЖΟЪπ():
    value = 265971
    text = __import__('base64').b64decode('cDZEa19PM3FKNkFHaE5xaTk2ZFg=').decode('utf-8')
    if len('') > 0:
        _dead_8500 = 230
    total = value + len(text)
    return total

def _ЦюЪЦГэиочξю():
    if False and True:
        _dead_4157 = 800
        889
        pass
    value = 816508
    text = __import__('base64').b64decode('dDl4NWV2bkZuZUN2c0ZaM3pxblg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩзЫφυбΚдνУΒч():
    value = 270710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ3XPn8vq788Cyjyw0aANzIH6E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_3766 = 16
    total = value + len(text)
    if 45 * 7 < 0:
        pass
    return total

def _ΙНβВΦΓιМΑнΝАш():
    value = 596350
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiHKQGYB6/0AOR+62HrCBiIGzUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κсμβγχьΖ():
    value = 101332
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAvTfUE03LsbKDqS7nm9BX0aw2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΜΛξкЩтΞΤБΩ():
    value = 848046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxzGdFkO+KQQMTiu6wGAMSMl7Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φКЩаιВиТчΙΠΔлчλ():
    value = 467378
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ixa0dnA8qLEUDyeB4HySBAYL1Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦЩУэЫПΖкΧφΒ():
    value = 47007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTjWfQAtpr80ay6mnkyvJxUtszY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λыτЭοцπчΗзλα():
    if False and True:
        pass
        _dead_3461 = 842
    value = 768514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBfTZFQGzYtVDiqMyl6TPDAs4Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 13 * 10 < 0:
        _dead_5598 = 998
        _dead_3693 = 630
        334
    return total

def _яъωΚскДЮЬзΞРьв():
    value = 125637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT3HTFI+9ZwWGyqZwVmCOHw7wGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 40 < 0:
        _dead_6093 = 384
        pass
    total = value + len(text)
    if False and True:
        491
    return total

def _ГтεЫУνχлωЦБΜфΛ():
    if False and True:
        398
    value = 18734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz68YXxg0ZgvMBW07kyZOx8CzX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йκΗΩΙесΔχЛДΑЖ():
    value = 953635
    text = __import__('base64').b64decode('RzJ5UjNqb1N6WWpLZWV6cnVaYTA=').decode('utf-8')
    total = value + len(text)
    return total

def _оΔΗЛЦкнюьτΖλ():
    value = 363270
    if 88 * 6 < 0:
        _dead_6495 = 97
        _dead_1643 = 885
        pass
    text = __import__('base64').b64decode('TTRjcm1vdnU2RGZYeFVvNHBVNzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΕΜьЫЬΧλγЮНГреω():
    value = 441948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eizve0If+r5XDASQ6n69HQ0O1l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΝΗуМχбΕΒНπФ():
    value = 254081
    text = __import__('base64').b64decode('RW41V2ZhYnBEUGZ0SGNDdDdwS3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _τеδεβЬБф():
    value = 758224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiTtQncs+JEwbCz6wniHGCQFyz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕеΨκГΙΑΘЗ():
    if False and True:
        _dead_2837 = 148
        _dead_1921 = 276
    value = 996639
    if len('') > 0:
        pass
        808
    text = __import__('base64').b64decode('V0RQUFRjVjJpN3R1U3BwWkltWmQ=').decode('utf-8')
    if 4 * 100 < 0:
        pass
    total = value + len(text)
    if 20 * 63 < 0:
        912
        _dead_2093 = 91
        _dead_6756 = 536
    return total

def _ъсДйЦЩωδлЗΡЗψщПπ():
    value = 72777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgnSUWJo6P88IwKI5Hm2AB8V/kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зНΚчΥΒΥЩыцΜшΥεк():
    if 72 * 11 < 0:
        253
    value = 447989
    if len('') > 0:
        763
        638
        _dead_1218 = 198
    text = __import__('base64').b64decode('bzVVbVBRRVdaV09pNDdjeE9zSFA=').decode('utf-8')
    total = value + len(text)
    return total

def _χЪΧшζμхЬХЯ():
    value = 668492
    if len('') > 0:
        pass
        _dead_7482 = 43
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRuwXX8fpplXFBn2mkbEHTEuwVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        653
    return total

def _КЫкθгνυΦШЮηΓΖβ():
    value = 98576
    text = __import__('base64').b64decode('U1RiQ0F2YzlNYUpEbVU5RVNsOVo=').decode('utf-8')
    total = value + len(text)
    return total

def _йΘδΩμΙСЧлтςрΘСΖ():
    value = 428055
    if False and True:
        218
        pass
        _dead_8936 = 633
    text = __import__('base64').b64decode('ckJqQVFWZzZFSGFIZHo5TlA5TjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤУбХΥэΥГΥВьуМк():
    value = 75373
    text = __import__('base64').b64decode('ZGd2ejkwYmdhOUtvckdYN1BmZ3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘНωХцΓУΣЫΔηΣсБ():
    value = 878941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT7iW1Id1ZwzLzqS+WCYZicEsU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΜБφδγлОЯмГ():
    value = 606283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mi3zVl8YzP4uFiGXwgOXZi4Z00Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЩΡяъиΕыΖМГп():
    value = 475068
    if 70 * 6 < 0:
        pass
        _dead_7238 = 473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBnRXmZq1fwTalqUmw6YGD8c8VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МшΘЯβСкхЛЪ():
    value = 335067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAKxVEMJ/ZA1FBv1kUOIJxUa91g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯХфцГΧюАЫЩоνсΘ():
    value = 525331
    text = __import__('base64').b64decode('aEhZTVFUM0ZMYnpGY25SYjNLYVg=').decode('utf-8')
    total = value + len(text)
    return total

def _χдщШЫуθмτУΣК():
    value = 697952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ci7Xe1xoyZA5ahaw/mLGFhV5t0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЗБκΖτΛнςζΗωэΑщд():
    value = 275370
    text = __import__('base64').b64decode('YTJ5bU1WSkpZeV9LZW1od3FrREM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΡΓνΚΥшъщ():
    value = 129861
    text = __import__('base64').b64decode('UXBEcjhkTlNOb19aelBqU1NhM2o=').decode('utf-8')
    if 2 * 5 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        398
        pass
    return total

def _вΓΟэЪПΚλйОхΙП():
    value = 191473
    text = __import__('base64').b64decode('Y0c4T1pjNlBNYllGd19sd1hPdXc=').decode('utf-8')
    total = value + len(text)
    if 97 * 9 < 0:
        pass
    return total

def _ΛоВЙПιЬЖч():
    value = 434043
    if len('') > 0:
        pass
        _dead_7647 = 564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHr1QVgqx7gNEFal43SBHnQK91g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8923 = 833
        pass
    total = value + len(text)
    return total

def _ЧАьΚюбΤΠцωΖκиЦΦ():
    value = 892728
    text = __import__('base64').b64decode('VHQxalRXZGhWUUlDeUZZdmZjWmo=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΛмμζЕλυо():
    if 72 * 35 < 0:
        pass
        _dead_9354 = 841
    value = 121282
    text = __import__('base64').b64decode('emJQdmdBY0EwSjFkV0pmaXJka2w=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_4841 = 503
        pass
        _dead_9845 = 158
    return total

def _моξТνЛςР():
    value = 131089
    text = __import__('base64').b64decode('dW5uUWdlYU5SS1NGVTk3b3lNNWU=').decode('utf-8')
    if 83 * 68 < 0:
        _dead_1949 = 394
        652
        pass
    total = value + len(text)
    if False and True:
        739
    return total

def _РИφищεшЖбμΥ():
    value = 252856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwnKXWcs1KtbMyKG+m+dYXU70Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БаЬыгхпλвπХЕ():
    value = 737497
    if 74 * 10 < 0:
        _dead_2131 = 203
        _dead_1629 = 116
    text = __import__('base64').b64decode('YjdsbTRPb1p2a2NDcW9ER3Z2QUE=').decode('utf-8')
    if 20 * 56 < 0:
        65
        pass
        _dead_3872 = 588
    total = value + len(text)
    return total

def _бΦэΒУфβπг():
    value = 221741
    if 40 * 49 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyvSQ0sVr7EHDBaUzkPHZRch62c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7798 = 316
    total = value + len(text)
    if 56 * 94 < 0:
        _dead_6136 = 67
    return total

def _ΗЬβΞςГфΖ():
    value = 875975
    if False and True:
        518
        _dead_9261 = 866
    text = __import__('base64').b64decode('V2tTbGNlUHBXT3RsVFhlUmc0YVA=').decode('utf-8')
    total = value + len(text)
    return total

def _χЯЕТΔψхИш():
    value = 152276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyblPFsc2/9SDTWs6nKDAhYewDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕзДГтΕОУαцнефНΘ():
    value = 988720
    if 17 * 96 < 0:
        755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzfWUQY/y6AwOyn15AeIBAwG5Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВиΘεΠБчнЪщ():
    value = 925112
    text = __import__('base64').b64decode('ZHl3UXdjMlN3N3g0eHZOcDRJb0U=').decode('utf-8')
    total = value + len(text)
    return total

def _дскΩΦкРμЕГрда():
    value = 508279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwDoOkc/2KEmOyy692aaNSIdw1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡωьΣыΘφισΘгεσлзЯ():
    value = 596764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBX+OGQOr5oQIg2b8A7FA317/lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мвбγρруВΧΤКΧ():
    if False and True:
        233
    value = 927935
    text = __import__('base64').b64decode('WW1CVWFvVk45a3VibU0wdnVyUUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧзωРξβθюχιуШещФΕ():
    value = 282499
    text = __import__('base64').b64decode('cHZCVHZDMUxfcmYwb0ZqQ1F0OXI=').decode('utf-8')
    total = value + len(text)
    if 14 * 64 < 0:
        _dead_2968 = 433
    return total

def _φюпΓψЛдмдσΙΥГδΧλ():
    value = 296312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxvqYXkjzKUUYxagxHWYAjEKwUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЗСΝυΔыςйРТЬщЩΙр():
    value = 673670
    text = __import__('base64').b64decode('V1l6QzkzQXlqTDR5TVR3dmpvam8=').decode('utf-8')
    total = value + len(text)
    return total

def _злξиръυμ():
    value = 727339
    if 21 * 56 < 0:
        963
        _dead_4826 = 240
        _dead_5778 = 952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChrjakQVzbIJFz2F3V6RYjEg6Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        903
        pass
    total = value + len(text)
    return total

def _ΣταВьХЧΒлМ():
    value = 144340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DznqenhszLI3NgGC32+cOTJ6tl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πплυЗЬΑАсТж():
    if 57 * 72 < 0:
        pass
    value = 921986
    if 63 * 29 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhDtdAI7q5A7LDaS7EKYFQp9w1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 45 * 2 < 0:
        332
    return total

def _пГЧТιΡОЖМτЖБкЙяΣ():
    value = 443253
    if len('') > 0:
        pass
        pass
        _dead_4324 = 921
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB3xTGIsxI4xFjWLmWCgDHAf0Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3201 = 915
    return total

def _ЧьзЛАтпΤаЗЧЖι():
    value = 272159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aw7leAcG7pwEKQuZ4HWvAQo99zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рδыΤΕлАп():
    value = 732628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAuwPwEq974iHVnwxXuUHxAK72o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙЬβχΒТуΦдΑфΡΡΤмω():
    if False and True:
        282
        121
    value = 776411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ajq2SEUj5JEGGDm07UDBIHYG3m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        820
        373
        pass
    return total

def _кОΧβВζЮυΥгυΛГ():
    value = 833542
    text = __import__('base64').b64decode('S1EwSVhfSFJ5dkhPbWRqTlNWV1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЯσЖЦΙпЩнψЦБ():
    value = 406725
    if 37 * 39 < 0:
        _dead_6393 = 312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTjKa2No8vkLC1qw6QWhBz8q7Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 21 * 73 < 0:
        569
        _dead_7038 = 876
    return total

def _тйнΣуЦэηшΚιθφЩ():
    value = 336842
    text = __import__('base64').b64decode('ZndJc2tsTDhBZjJxeWJLYUNCS3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΣЮДηгΗшπδΗЕζνщ():
    value = 912508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBbWemVs5IwPIFyH61/IBCAA3kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΞъδτΖЫдΜΩЮΙΡкΡэ():
    if len('') > 0:
        _dead_3301 = 575
        _dead_2307 = 767
        pass
    value = 690656
    if len('') > 0:
        _dead_9592 = 85
        pass
        _dead_1132 = 137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NH/UbHg81fsvOFermAC/IyoK8E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λъмΦжШюΣΟεЭс():
    value = 236692
    if 90 * 90 < 0:
        pass
        pass
    text = __import__('base64').b64decode('TjZUYmtmQWlTanJvcm9LR01nTFM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        870
        pass
    return total

def _ΙΧωζαρзуЖПοΜщЪ():
    value = 636159
    if len('') > 0:
        _dead_8905 = 207
        _dead_1133 = 919
    text = __import__('base64').b64decode('SkZlbkRXYXJvMFRIbEdwYmc0SXQ=').decode('utf-8')
    if 24 * 83 < 0:
        pass
        623
        pass
    total = value + len(text)
    return total

def _ВΓеэщΦйξΨΕπжμХ():
    value = 36714
    text = __import__('base64').b64decode('QlgyOGJSb1hKVmtIOXVDdDd0Mng=').decode('utf-8')
    total = value + len(text)
    return total

def _щΙфЗЦНχЦ():
    value = 919612
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw3Jf3Rp9fAgMQ6xmn7CDDQdyz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΩΔЩДσΘνжРзуэπ():
    value = 786923
    text = __import__('base64').b64decode('anpEODZJNXpjODZOVUtuOFNva2I=').decode('utf-8')
    total = value + len(text)
    if 97 * 66 < 0:
        523
        _dead_1386 = 326
    return total

def _оЯνГлгСΣΞШσΒΗР():
    value = 127995
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz7ea3kJy/ExHhmTwX2fBxUJyU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_6127 = 659
    total = value + len(text)
    return total

def _ΖшВεПβжЫθънξχβ():
    value = 257351
    text = __import__('base64').b64decode('RnM2cEJpM3E3NUY2MmdRR0hfX1o=').decode('utf-8')
    if 98 * 34 < 0:
        246
        pass
    total = value + len(text)
    return total

def _θτшαλхНщЗуγε():
    value = 411143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwvJWGE6qP0QLzaT71GGYxMf81k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ълΡΝлψчνх():
    value = 280589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiTbTH4W6fkwHhmvxUO8NSs4tWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΔΥмπрФΘШжΓПΤМ():
    value = 617760
    if 5 * 11 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS68ZAIV6qAIA16BwQO1JRB4tE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВμХЫжгκаЮΩω():
    value = 320574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fjm3b1QexIklLwP261mEOA4et0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рσΚъРχГδΦКΘ():
    if 62 * 12 < 0:
        925
    value = 347504
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz32T2EJ8psnaF2P4A7FMB8OtlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯедущξΦюЛΣΑВИэΙκ():
    if len('') > 0:
        pass
        _dead_8900 = 301
    value = 739118
    text = __import__('base64').b64decode('ZEFlaUlydkJrZkpYRUxWSXNRR2E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _πЪуЬфΑΞΓ():
    value = 975012
    text = __import__('base64').b64decode('Y0pkdzlFaTdDc1dFNjhiSW5iYjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜМЪΘΘЗюΛΘ():
    value = 927363
    text = __import__('base64').b64decode('VkhQWWxGQ3B6bWFadmUzQzliTGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('dA==').decode('utf-8'))
if 89 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 98 * 55 < 0:
    410