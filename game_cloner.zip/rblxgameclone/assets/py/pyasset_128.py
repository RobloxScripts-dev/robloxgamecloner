#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ιθРΖΔΣМμиτιΚмк():
    value = 433741
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jw22PGUX0q4PBTq58HrCPisb2zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЮЖПΗΔхоΘпЬТУЮЩЕ():
    if len('') > 0:
        _dead_2394 = 210
        pass
        _dead_2399 = 326
    value = 4908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgXWPXQ/qqwvGT2O8VjJERJ5tlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уРΚΩдΙτДмХι():
    value = 77762
    if 99 * 59 < 0:
        _dead_4561 = 279
        594
        _dead_7631 = 596
    text = __import__('base64').b64decode('T1lWcGVJb2RtQVhFVWhpSFFoNF8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4547 = 869
        pass
        652
    return total

def _ЧгПμдΓшΙζθΚΦωЙε():
    value = 212665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgrJR3tgy/stHgCl+2nCOAt5zWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 80 * 75 < 0:
        _dead_2826 = 99
    return total

def _сΖТαэγПфΚΧΖМВ():
    value = 93613
    text = __import__('base64').b64decode('dzBKVkJwcGJ6Y3dQVUhJMkdxTmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ълθЪРΠхэЯОьШ():
    value = 264653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyL9TGYzrPk1OFak+AGSLC8b4GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТψОиψЯяΗЩЫоъΡйд():
    if 56 * 70 < 0:
        _dead_8441 = 549
        _dead_9920 = 466
    value = 646306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnfMe1kR160JayCQnk6/ECwLs1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эςЙβЭббдЫΥФ():
    value = 270824
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCjRZWQWy/FTOze2/HnDHBAt9Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΗΤКοιΙыΟΨ():
    value = 2680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSfjZ3Ijr64LCV2H6nSgGSIDz1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        742
    total = value + len(text)
    if len('') > 0:
        _dead_5064 = 148
    return total

def _фЕΚЮλΩεΟΦУΝΡС():
    if False and True:
        _dead_7783 = 934
    value = 339342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwbsdH0q8P08BRm6/1ScGT8J20c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оοΑГЫΟΥШШφτΡСЙ():
    value = 31834
    text = __import__('base64').b64decode('aVVrbWlhX1FubjVoRkwxMW5GYjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЪΝεгΒχцЫ():
    if False and True:
        344
    value = 552734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABDQZUEG15cBaij6zn69ASsHwmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οэфКОбйΝч():
    value = 71613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH7XeFYU3P4hEQK1yWSeNSs56no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОλΚЛвχΞБйа():
    if 8 * 84 < 0:
        897
        pass
    value = 76288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy60Q2Uu7a8iNjaMmneKDgI2sHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γаФкЬηΠΡωК():
    value = 317395
    text = __import__('base64').b64decode('UXozdHNHN1p0bHRQUXpHeFZvOFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ιХΦъпΣчαΩΞΣЯщУи():
    value = 166453
    text = __import__('base64').b64decode('Q0dLRDg2Z2ZQc3RPZE4yYk55Uk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ςУΖшЧχоЕΕΝшоыЗяБ():
    value = 479932
    text = __import__('base64').b64decode('TFllMG55d0NiXzBFYm1XWXRiWFo=').decode('utf-8')
    if False and True:
        194
        _dead_4141 = 429
    total = value + len(text)
    return total

def _ЫΜЩНмЬΨаЪцρэΣЦзΦ():
    value = 307516
    if len('') > 0:
        _dead_7703 = 886
        _dead_3695 = 745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3bCWF1p7IUCExuP93zCPQB3sHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХНΡЭЕИдмэБкЬΔзθ():
    value = 85102
    text = __import__('base64').b64decode('U05nX3lSbUxOMVl5WmJhQ3N4bDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚιυτиΝПевъΠФ():
    value = 954325
    if 72 * 93 < 0:
        257
        pass
    text = __import__('base64').b64decode('dmRvRl9vWXFsUFBuVUxFcGNKbzM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        585
        51
    return total

def _уπхМξщμΕ():
    value = 677452
    text = __import__('base64').b64decode('ZlI1TE0wa2Z2NktobUVscXZJM3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΨНюРЯψБΨΜΠСΑН():
    if 1 * 75 < 0:
        546
        pass
        _dead_7981 = 679
    value = 458655
    text = __import__('base64').b64decode('Z1N3WkZHcjZuMlYzRUVUZzBnY3Y=').decode('utf-8')
    if 77 * 63 < 0:
        _dead_9205 = 681
        8
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _οаИЩβЭλЪтжкх():
    value = 674666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSz2TUgOrr5bYiSy/nvDByMgyUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЬλВπпппт():
    value = 708796
    if False and True:
        10
    text = __import__('base64').b64decode('QUl4N095dEpKaHRhSUcyaDUxcnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕШКвςЮαςΚτДυз():
    value = 222966
    if 36 * 14 < 0:
        pass
        694
        pass
    text = __import__('base64').b64decode('aGtpRjBVWlVUTjJQUlFkYlNaY1I=').decode('utf-8')
    total = value + len(text)
    return total

def _суΩВΟλΘлпиΠχАфО():
    value = 524266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDW1XVg6r/EFP1+kz3WWLnN99Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΡμСγЙΖсραЙ():
    value = 808895
    if False and True:
        157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx3TWXMP+ZcWaiOtmGy8DjYY9GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _НΚХЧξΟΝοО():
    value = 924518
    text = __import__('base64').b64decode('ak1QWlFjcXJYWFh6emdua1JfS1o=').decode('utf-8')
    if 61 * 15 < 0:
        93
        pass
    total = value + len(text)
    return total

def _йыΠжтячЦрΜ():
    if False and True:
        529
        258
        _dead_1192 = 177
    value = 687007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lna9Rnps7KMyIFmc0ga5GAsI72o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 32 * 48 < 0:
        711
        414
        _dead_6060 = 917
    return total

def _рηΞЙζшωδБзΩъЖεдι():
    value = 520664
    text = __import__('base64').b64decode('ZGFvcHhNNk1ySnR0aEFXVWxFUjI=').decode('utf-8')
    total = value + len(text)
    return total

def _уνШΜбИБοβ():
    if False and True:
        _dead_6391 = 225
        _dead_7321 = 952
    value = 396650
    if False and True:
        pass
    text = __import__('base64').b64decode('WUZBSld2VExwX25FbXNBQ21UZUg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8526 = 149
        pass
    return total

def _ΓфΡБξСэΞцкΓΘσ():
    value = 458643
    text = __import__('base64').b64decode('aWY0dGh1a2tRVEJiYU9XRWdrS2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥАΥИχθнйΟωдΤ():
    if len('') > 0:
        316
        _dead_7256 = 139
    value = 835054
    if 5 * 1 < 0:
        167
        _dead_3605 = 512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAvUXEsN3bwsOV+s4HOHMgIY7EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΩчΣπАΞΨ():
    value = 432157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyvDa2YzqYcAAiqFmVXDPHMd53w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чНЗιОηкΖдр():
    if 1 * 68 < 0:
        _dead_8169 = 578
        _dead_6316 = 650
    value = 494266
    if 18 * 80 < 0:
        440
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mnj+OVYLxpAHNxic5FyCGyMhxWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 74 * 42 < 0:
        516
        423
        pass
    return total

def _ιЩιюωРЬνζ():
    value = 36287
    text = __import__('base64').b64decode('TnpDT01jaW9pQVRxVFRrWWVfdEg=').decode('utf-8')
    if False and True:
        179
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _βАχЮчθрЕω():
    value = 943910
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSTeWVsby4MtOxqK4HSyMz131mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВκОуΚеοΚКу():
    value = 117238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JALienIs+aYEHwCB2GmiHjR8sm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1536 = 635
        974
        pass
    return total

def _ρмΦЖΓшΘχВΣЩΞДρТ():
    value = 726048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH/OZWAV+I1QLiby8nq0YigIy3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘгΓηЫψхςЯФκшюХэΘ():
    value = 24366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3zVf1YGx5waMiuh+kKpBgoi8zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьЬσЦοΩπЧπ():
    value = 270846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICvMaAEr7fwHGR6271CUZw5+5mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛьΟτеΑмрΩТπаэΧ():
    value = 267852
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An7BfEgq9v9XMiKtyXm0NQAh4H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠявΨХЮЮιΩΚΜп():
    value = 680868
    if False and True:
        _dead_1334 = 536
        _dead_1657 = 528
        480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDfwV1w0yvE2NwmK6X/GOS0qyTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рзУΩПεнΣИи():
    value = 10539
    if len('') > 0:
        926
        525
    text = __import__('base64').b64decode('d214Sm1HT1hPYjQxajBjdmRuaEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΚΙΣГАъηхфΤБпΘМΞ():
    value = 711391
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky3DWXgg5qYbLBWIy1m9ZRMdz2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХыνΦлβΧνμΧν():
    value = 600403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HArqaVpv6aU2bAaQmX+5MxR2xUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шσАωγюΧМиΠтЩψкσП():
    value = 555528
    text = __import__('base64').b64decode('WGtBMmRtVDZXNW5zRl9GNUJBOWo=').decode('utf-8')
    total = value + len(text)
    return total

def _йбоАξωМЖΓРξΣЫξС():
    value = 597805
    text = __import__('base64').b64decode('ZWdNeFRxWnJIRGxOQjUwRjdZaUk=').decode('utf-8')
    total = value + len(text)
    return total

def _вжΦΩβмΛΡαрнЮ():
    value = 557948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyvgYUI08oNRPwSN/0XFJjIEvUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5092 = 179
        _dead_7546 = 29
        918
    return total

def _φУльсεйνЧΧκΥмΘΟЧ():
    value = 990860
    if len('') > 0:
        810
        pass
    text = __import__('base64').b64decode('aXVlMVZmQmc1VXJLTXY3VklDVEM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ξηйюбυАΕгΗШДις():
    value = 550655
    text = __import__('base64').b64decode('ZHlFMVFzSG9vS0FuN1ZTZG94SEM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3888 = 740
    return total

def _ЛсЧтςαъΕйфγжщτ():
    value = 705629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABnMVGM8podWGVacmmCEZnE47Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        234
        228
        _dead_6200 = 858
    total = value + len(text)
    if False and True:
        _dead_4801 = 997
        _dead_6191 = 665
        _dead_9077 = 402
    return total

def _ЛΑΧЩУΙЖκзΟДчΡ():
    value = 646914
    text = __import__('base64').b64decode('a21HT3Jnb1d2WUsyUWFoeGE2d1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _κЦΦκηνоАШИШГг():
    value = 702027
    text = __import__('base64').b64decode('RkNyVVAwdG9yQWJDdHFqUHdWbjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ГЛτΦМЮЯΣ():
    value = 342052
    text = __import__('base64').b64decode('Rzh1Nm1iaWtnOXVpNkVtSE9sSVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΤΗлгеΥХЩτ():
    value = 788814
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAjyYUsOpq4JEgSc6mWcJgk1tzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _КΡΖαΦΠРΕΔфРъκβωΟ():
    value = 793184
    text = __import__('base64').b64decode('bFdhN2xQZUxjUWVjNjRPbTg3MFI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_7705 = 164
    return total

def _ΔоХΦΛαКМнЮъйΔ():
    value = 422058
    text = __import__('base64').b64decode('bFhENzdfQ3Mza1Z3b2R4WWdqajg=').decode('utf-8')
    total = value + len(text)
    return total

def _СЙсЬлΒлΗТ():
    value = 481409
    text = __import__('base64').b64decode('bkhDUnhkN0pndTRKRXR0YXl3Y08=').decode('utf-8')
    total = value + len(text)
    return total

def _οЯμлΜηкμκ():
    value = 362997
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRW1XQER8oUPIzis72mUO3wg4GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξзИωΓшΧΔНЛуПхкμΕ():
    value = 261762
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxfreVcw5K0iGS2vmUW8GysY0EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3745 = 658
    total = value + len(text)
    return total

def _уρСаςЪЭβюППЗΑΧе():
    value = 533743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BD3rP1UxrqJQLQey7meDLhUHyjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΟшЛъΔмЩ():
    value = 361231
    text = __import__('base64').b64decode('cHhVMDZhSGlGUlNpcGNWNUJmeVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫбΤвщшλΧЬψДπчЮ():
    value = 303306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCy1WQdg7owOHy2r61/INSN79lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _игэΛУеКДΟбАпаФмк():
    value = 471055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgXBRwAs8ZEyEQON/n/FNRMg3Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъεονзφΖНΨνΒΥπ():
    value = 150591
    if 62 * 60 < 0:
        _dead_9278 = 569
        _dead_9816 = 6
        pass
    text = __import__('base64').b64decode('cTlHT1dqdktWcm45MGJzTWRMUTE=').decode('utf-8')
    if len('') > 0:
        409
        _dead_8972 = 174
        _dead_7735 = 358
    total = value + len(text)
    return total

def _еτнχΛАηКΟФЪΙрБ():
    if len('') > 0:
        pass
        pass
    value = 537579
    text = __import__('base64').b64decode('aVNRcDlOZm9nRmlHc19FMWpYY0M=').decode('utf-8')
    total = value + len(text)
    return total

def _οкгУβΩΧН():
    value = 408882
    if 96 * 77 < 0:
        pass
        395
        966
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn7dWWIL8YtbHDeX8k+vJ3UC/EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜдΩΩσιΥвψ():
    value = 575877
    text = __import__('base64').b64decode('SURWT2traDZvTmpTUG9OeldadG8=').decode('utf-8')
    if False and True:
        286
        pass
        773
    total = value + len(text)
    return total

def _БЗЮКБжΞяρмΘцЬδ():
    if 68 * 97 < 0:
        _dead_6960 = 891
        pass
        pass
    value = 788700
    if 62 * 37 < 0:
        pass
    text = __import__('base64').b64decode('eFdRSEFQZ3dFM1RKTjlSc1BOQWI=').decode('utf-8')
    if len('') > 0:
        _dead_6471 = 291
        pass
    total = value + len(text)
    if 34 * 67 < 0:
        274
        pass
        pass
    return total

def _ΝοПΩβнκπПΣШоαμχΔ():
    if False and True:
        pass
    value = 663057
    text = __import__('base64').b64decode('bERackJsd3VCWUkzcmk5Sjh2cXA=').decode('utf-8')
    if 46 * 75 < 0:
        _dead_6099 = 652
        pass
        254
    total = value + len(text)
    return total

def _ςιτлΟгхΩЭ():
    value = 214204
    text = __import__('base64').b64decode('TDJqYzJ0dVhHZ1FCUUlqMHNFcGc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _НΔφйηηчД():
    value = 740636
    if False and True:
        _dead_3272 = 128
        _dead_5708 = 687
    text = __import__('base64').b64decode('ZVB2WkZTQUdlSE9oeG5nZDhRSXA=').decode('utf-8')
    total = value + len(text)
    return total

def _йνХШΩοЛЬЧμυ():
    value = 225471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ixe1fFIMr/AwNyyPmXWKMBILyUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΤаЬЮΜυυΓоΕмΠ():
    value = 943897
    text = __import__('base64').b64decode('V09Td1VIWlZMWDdwclhXMlBKZVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _АΝЮυΜатΘШμΡЙψΥθг():
    value = 281215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTbKQQE69JEQPguR0FeEJik+yX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΥЦψΦЮяΧεΜΒΩе():
    value = 329367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAv+VHo46ZkWMF+UnlPIBCYA53c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яιсωηКδЩΕЙΓ():
    value = 951204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXb8P3QB/6pTDVyJw1mvDS4Ky0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΛялμΗΨτГэΧΞКΛΧ():
    if len('') > 0:
        pass
        _dead_8030 = 987
    value = 359554
    if 85 * 12 < 0:
        _dead_9879 = 970
    text = __import__('base64').b64decode('TVB6WHhDbVpLekdmUlRGTm1Ybkg=').decode('utf-8')
    if len('') > 0:
        pass
        277
    total = value + len(text)
    if False and True:
        _dead_7341 = 482
    return total

def _δΥзгψβΣγфяе():
    value = 282229
    text = __import__('base64').b64decode('emZfbENOUU5GYm1Eb0J3eXg1VkE=').decode('utf-8')
    total = value + len(text)
    return total

def _щξБгРΙщξΖгЦΡδΣδτ():
    value = 664724
    text = __import__('base64').b64decode('VmtkT2dfQWZQYWdXa1IyTE02YlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΨХοΤуΩзТд():
    value = 704539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhjVXmQq9vhXCgytkQa7FSZ44Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШьъжОйαЖгкЪкΓΨж():
    value = 162587
    text = __import__('base64').b64decode('ckJRU0llTGlvbUVsdHBjVjFhb1I=').decode('utf-8')
    total = value + len(text)
    return total

def _λψΘзУяρщЬВδκΘΘρр():
    value = 887589
    if False and True:
        _dead_2739 = 830
        993
    text = __import__('base64').b64decode('TkZUc3VKU0VmWmtydVRHUm5mNXU=').decode('utf-8')
    total = value + len(text)
    return total

def _якжГЯкцШξ():
    value = 848327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXjlYmApx4YOYg2U90SfMwM56lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΩОкΞΛОСфУΤУ():
    if len('') > 0:
        14
        45
    value = 896340
    if 51 * 72 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiXgeXYAq741LQyR+ESFFwsB1Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΝлβЖσΧσнТ():
    value = 457827
    text = __import__('base64').b64decode('VTRubU95b2RhRkt5bXVqOFhHUHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮπεДΠрΔΦΘъ():
    value = 151652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHvBRkYRz4s6NDiv4XKdAyoZ8Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НζТпСδюКΖУΒρΛΧмΛ():
    value = 118904
    text = __import__('base64').b64decode('dUJNTldmSl8ydEppNUtMU2RzbmU=').decode('utf-8')
    total = value + len(text)
    return total

def _τατжΞЙщЮΩφНП():
    value = 682012
    if 75 * 23 < 0:
        pass
        pass
    text = __import__('base64').b64decode('RG1BYWt4X0ZTWHE4MjZ5RXZQR2I=').decode('utf-8')
    total = value + len(text)
    return total

def _йЪκдγЛяцΓхΤΛкУУΣ():
    value = 640286
    text = __import__('base64').b64decode('TXlVM0xCamdaQUtDTEUyRGJiTDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩХКцЪщηкρΚуΤ():
    value = 115418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N33QQHMNz58KCBWB7Hy8EwI9tXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΝеΙГΜОΒιΣ():
    if False and True:
        372
        pass
        pass
    value = 238874
    if 65 * 54 < 0:
        199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHfXNlYM7bpVNlf64A6eGT8X6Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эιωОиЗΙΣЦωнλξι():
    value = 56518
    if False and True:
        pass
        pass
        pass
    text = __import__('base64').b64decode('ZWFXQ0hLbTVqeVhBbG02SkgxbFU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8761 = 33
        pass
    return total

def _ΦюхαΨОсΖνес():
    value = 846716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwnHdwc/+4IoOFyFnUPGJwAH9Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΨтыхΕΚΧеμγИйθΥХ():
    value = 787442
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ay33N2kA7q0UPRum4lW2Yx8G1X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4917 = 520
        pass
        191
    return total

def _укпйшΕТΔ():
    value = 882779
    text = __import__('base64').b64decode('Z1ZZT3I5SHo5M2cyMjRWd3ZlcXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ФοЩЙΠБэкаЩиΗ():
    if False and True:
        100
        pass
        pass
    value = 214651
    if False and True:
        266
        223
    text = __import__('base64').b64decode('WUtlYVBiWjFtSGw3RDh3V2dOY3o=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8037 = 508
    return total

def _НТδΠэаπΒεбιл():
    value = 816894
    if 47 * 7 < 0:
        _dead_7988 = 25
        _dead_6364 = 751
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCrjamUhxoksPAGW71mWNSAptEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФКщЬΧοаΘаМзДмП():
    value = 761325
    text = __import__('base64').b64decode('VW56RlpmY083bjI0MDVqTHJFQXE=').decode('utf-8')
    total = value + len(text)
    return total

def _κЯыФλНΩπФωХ():
    value = 42180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAy2amY4yrw2ah+73lmgMjUEsU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΗВυΠкΦΡФμΙо():
    value = 386017
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACW2Z1M6xKcMAyqNzwbGZid5t0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯиехЗΚЩмиΚΤ():
    value = 935608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBjLSWtr94MhFB6By0GKZhI57V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮЩАνΛчХΕζМтСυβΨυ():
    value = 271258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnrSP0ke+IczEjipmE+XFxZ85UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фщэσςνЪΗяμΨРц():
    value = 867588
    if 36 * 7 < 0:
        _dead_6359 = 741
        _dead_2132 = 70
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F33bRXkW0qsxHzzw0GW5MzYn4mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 22 * 64 < 0:
        _dead_4567 = 324
    total = value + len(text)
    return total

def _НτΥАΙхВκςΚδцνф():
    value = 74342
    if 50 * 85 < 0:
        _dead_4555 = 74
    text = __import__('base64').b64decode('SzQ3OUxEWU5selNGVHZZMDM2SGg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8394 = 861
        _dead_5812 = 850
        742
    return total

def _эЙΖаΥπВхθξΥΚвЩση():
    if False and True:
        137
        997
        pass
    value = 308036
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjzUVggNy5wOPi2l5nmaOHcd1z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        653
        964
        _dead_7108 = 740
    total = value + len(text)
    return total

def _εэΡγψкςцΧ():
    value = 489355
    text = __import__('base64').b64decode('VW5jMWFzRWRlWTM0c2RqbHJNNWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЩзΝθΗμЧЩ():
    value = 262841
    text = __import__('base64').b64decode('ejBfcWpyX2NubFdqWnNfeTJ0Znc=').decode('utf-8')
    total = value + len(text)
    return total

def _ыρΧхШРσаьпΡеДЫΦ():
    value = 119855
    text = __import__('base64').b64decode('WF9aM1ZIQ205a3M5T2pNb2VrUTU=').decode('utf-8')
    if 56 * 74 < 0:
        _dead_2131 = 439
    total = value + len(text)
    if 11 * 2 < 0:
        _dead_3281 = 69
        _dead_6998 = 14
    return total

def _ГйиΒΔЕΗι():
    value = 198425
    text = __import__('base64').b64decode('UFZOc2JoZm9ucDVNMVVuN1NwZUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ξФΜМΕИЪγэюэΘαФ():
    if len('') > 0:
        573
        856
    value = 273980
    if False and True:
        272
    text = __import__('base64').b64decode('Y29Gbm1KRkRVcFRIcHQ0WmhwQ20=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕпПбыωεχЪΘАΧ():
    value = 418162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhnNZwM/0vAUCSaQxGO3bAAZtWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥоφΥωЭЩγβпΨЮπΘм():
    value = 754389
    text = __import__('base64').b64decode('WlVwNWRpYjEzTGpraHVzUEFZR0s=').decode('utf-8')
    if False and True:
        _dead_5175 = 98
        579
        _dead_9600 = 277
    total = value + len(text)
    return total

def _зΙыΤГνНбЧΩЖыЫμΠκ():
    value = 577948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Igr+PwMarZhVHyjww1i3PTB89Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΓεβαλьМβσΣМρЬЙπ():
    value = 521146
    if 43 * 63 < 0:
        474
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDzhVF0h8ZcQER2F4kzJLCwa63o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        192
    return total

def _ΙЛмКΧЙюф():
    if len('') > 0:
        972
    value = 617459
    if len('') > 0:
        _dead_4452 = 924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChXxQQc8q68sMgWQ4QWHOyM85T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΒПθьιΜδΘеΜо():
    if 40 * 68 < 0:
        pass
        _dead_9653 = 844
        298
    value = 348722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiHSOQUq2vEsFVqHkFi2JzIOxmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9285 = 298
    return total

def _НιЖμοйЯЬ():
    value = 965617
    text = __import__('base64').b64decode('dWs3aElIc2tXaWdORGdGOXFxbTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΒшνоΣОтш():
    value = 678602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwzRQms+/K0saiil7VLIDhAi9Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4711 = 667
        _dead_9480 = 379
    total = value + len(text)
    if 9 * 24 < 0:
        pass
    return total

def _ЛеφΝнрΠΖНПςμ():
    value = 918081
    text = __import__('base64').b64decode('Q0g5TGtuRXlRZDVEaUVHWlJXbnU=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        690
    total = value + len(text)
    return total

def _ΤЖХλфΓчЭаΙрΑЛ():
    value = 82478
    if 6 * 12 < 0:
        _dead_8445 = 607
        pass
        pass
    text = __import__('base64').b64decode('cVBFT0JsU0t5NHJrRTFXTXd5THE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΗЕчыКαНφ():
    value = 297005
    text = __import__('base64').b64decode('RXFyc2t6MGQ5T1VvWjUwNkpCRVg=').decode('utf-8')
    total = value + len(text)
    return total

def _σсΙΖΖЦΝΞШλЪΜεыΚ():
    value = 210546
    if False and True:
        pass
        _dead_8549 = 374
        pass
    text = __import__('base64').b64decode('R1FxNkxjZXJMd0wwZnRVUFdzY04=').decode('utf-8')
    if 50 * 98 < 0:
        pass
        pass
        _dead_2089 = 649
    total = value + len(text)
    if 39 * 2 < 0:
        639
    return total

def _ΔφΝЬΙкΠЧшКнфф():
    value = 461728
    text = __import__('base64').b64decode('YVZuMXhwNXhVZFFhRXRGZUJVRk8=').decode('utf-8')
    total = value + len(text)
    return total

def _АТγЭβωШΧлΙИЩГИА():
    value = 162884
    text = __import__('base64').b64decode('dXRIWUl5VGdiRmo2dFlrYURJUWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΚεΞжτнγуьλфΞТςΚ():
    value = 81622
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBjbQmJryr0qHgmh5EGqAQ598E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕωτщιяНеΤУχ():
    if 66 * 81 < 0:
        pass
    value = 755845
    if len('') > 0:
        720
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnroSF9v1pgBLAD2kHKAFi0B9Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪэιнΟЬΨΟιгСн():
    value = 568008
    text = __import__('base64').b64decode('bVc4UlUxSERlVVoxVDMycWQycVo=').decode('utf-8')
    total = value + len(text)
    return total

def _τхФηЛтзсИЭρвηН():
    if 39 * 12 < 0:
        _dead_4519 = 723
        946
        pass
    value = 12295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fga1ZHs/yY45Fzey93K4Ljd86Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2586 = 232
        344
        753
    return total

def _ΦеШФпμШЫζΓμτЧ():
    if False and True:
        18
        104
    value = 418752
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('UG5FUUFLR3RCR25icmJJT1VqX1o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        613
        233
        _dead_9792 = 357
    return total

def _лагАΥрЕфΕцф():
    value = 969890
    text = __import__('base64').b64decode('cTRkY3RnclNibnhKYTVTdlJIckk=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЦΙНФдвфЙОЕ():
    value = 271586
    text = __import__('base64').b64decode('QmhiYTM4MFFkVnZsaVRqS1gyYko=').decode('utf-8')
    total = value + len(text)
    return total

def _дκετΩΠΗεΡьξΤУрΒΚ():
    value = 412888
    if False and True:
        _dead_1737 = 926
    text = __import__('base64').b64decode('alE3NDZQanBRamxZdjJNTmdpNGI=').decode('utf-8')
    total = value + len(text)
    return total

def _φωнщТπЪΖ():
    value = 829440
    text = __import__('base64').b64decode('czdQbFJGWTh3N0sycWNJMUVFd2k=').decode('utf-8')
    if len('') > 0:
        _dead_9332 = 584
        pass
    total = value + len(text)
    return total

def _ςщбЙςскс():
    value = 272556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhrFRmAA9pk8aQ2H5k+pM3YEtGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        272
        220
        _dead_5694 = 760
    total = value + len(text)
    return total

def _ΝρΘΨЬРяжεЩУΝΛ():
    value = 426946
    text = __import__('base64').b64decode('a1ByQXA4WmpOa3l3bHBva1dRU3k=').decode('utf-8')
    if 72 * 55 < 0:
        pass
        _dead_7555 = 977
        pass
    total = value + len(text)
    return total

def _γσкιяΥτШΚων():
    value = 769239
    text = __import__('base64').b64decode('S3lVZ2lYM2lvWW1JUVo0SWhEUVU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1937 = 645
        pass
    return total

def _УъФэΩЫΛΝεчжξκе():
    value = 202400
    text = __import__('base64').b64decode('RDJjUmFNeHFWclVmTlFlUldWNlk=').decode('utf-8')
    if 20 * 29 < 0:
        _dead_6683 = 529
        pass
        pass
    total = value + len(text)
    return total

def _пзαζθМθΧфν():
    value = 962648
    text = __import__('base64').b64decode('ZDJjX2doUzlVdnh6N2RhNW45SEc=').decode('utf-8')
    total = value + len(text)
    return total

def _лчЦΡχΘЬωδΣ():
    value = 275176
    text = __import__('base64').b64decode('SzM2Vk5GcU8zM3ZOcFJDMmNMRlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ГδΚБΘЮЛмΗаδνωμλ():
    value = 750239
    text = __import__('base64').b64decode('aHlDbHdwaWV4YUY4VU5ETW5hOFU=').decode('utf-8')
    total = value + len(text)
    return total

def _РβξΟΡГЦНДΖοУЮε():
    value = 210693
    text = __import__('base64').b64decode('VWZXRnNieHh4bkhqak5meWlMblo=').decode('utf-8')
    total = value + len(text)
    return total

def _βνΦгТымΗъΩ():
    value = 393917
    if 27 * 75 < 0:
        pass
        _dead_7379 = 185
        629
    text = __import__('base64').b64decode('dnJORG4yaER4aFR5MHJSZ3VCcko=').decode('utf-8')
    total = value + len(text)
    return total

def _АтгΩυЪьфпλрЭю():
    value = 467955
    text = __import__('base64').b64decode('R0tKRGFwWFFldXd0Qldrd0xhODA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧκЛοкчрВйждΕοΖЗ():
    if 1 * 13 < 0:
        925
        pass
    value = 422458
    text = __import__('base64').b64decode('ZXFBRGVUNmFRQUVHVE85NEhCVXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΜРЧаКβЮζМΣЕшЙ():
    if 86 * 76 < 0:
        708
    value = 156319
    text = __import__('base64').b64decode('Q2VtTUV1Y1RHMTczV05aRFRvTGg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΧΑеΝпыλхΗ():
    value = 460039
    if len('') > 0:
        33
    text = __import__('base64').b64decode('cFZVbGYyUDM2N3JUZ0QwaThHcFo=').decode('utf-8')
    if len('') > 0:
        _dead_9465 = 506
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        745
    return total

def _ХΧΕвΤΣорψΡΣиΩΣжя():
    if False and True:
        _dead_2887 = 815
        _dead_6453 = 814
    value = 907322
    if False and True:
        _dead_9833 = 868
    text = __import__('base64').b64decode('ZGNhQnNqQkpZRE9hcGhZWU9YbE0=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _НэАΥοуθо():
    if False and True:
        261
    value = 151761
    if 24 * 81 < 0:
        _dead_6419 = 319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ig23W2UW86RaMxiv+myXIg57wz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _оВЩвПйБасπΩЮΖ():
    value = 381127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ahb8bWto0Y4HKxaS4Q+7BAh34kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αтΠФвВγЯπΖσ():
    value = 34994
    text = __import__('base64').b64decode('R0szVkp4SGJmRUFXRGJBU3hiWlQ=').decode('utf-8')
    if 40 * 83 < 0:
        pass
        164
        _dead_3206 = 536
    total = value + len(text)
    return total

def _пθДΧииоπΨс():
    value = 677684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRWyOkdt+/gMFj+E4WO2JS0CzXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΣΜηθдТοзмπГА():
    if len('') > 0:
        pass
    value = 679486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD/PeWEV+/svalaAnkGfZQN3xmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        848
        40
    total = value + len(text)
    return total

def _вэЖШДΒκζζБρдЪЮΣ():
    value = 885351
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHvVe3UW2PtWBTWE5XeVGgAZ0TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КОΑЯΕнЯξΧь():
    value = 525494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQfmXVoLzoUEKz3ymE+3DBcIxk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СεΩоЯЫТОЫΓЮΞДЕЮК():
    value = 932106
    if False and True:
        _dead_6223 = 864
        345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCewe0I095wNE1u572eIA306yz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δβξΗΔКХЛюΖ():
    value = 284349
    text = __import__('base64').b64decode('a016dTQ4ekhmS0tadndXTUJWb0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙρСζтссμЦИζΟжΔΡ():
    value = 411103
    text = __import__('base64').b64decode('SnRwczVieWhQbU0yTWg1N0Jobmk=').decode('utf-8')
    total = value + len(text)
    return total

def _МЭцκшΦам():
    value = 297868
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwbUd2kYrqdQFSb3kUCeDXUc3mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥЯНΔьникДΝ():
    value = 36226
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXjGOFpg2aMsDFqS7QOUOXIh53c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞянтΔГΣЯ():
    if len('') > 0:
        _dead_4925 = 565
        _dead_7194 = 659
    value = 224338
    if False and True:
        pass
    text = __import__('base64').b64decode('T3pCQUhJQ3E1NEcwUm5HekJmSlE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘγГΩЙΧПαΣωкВο():
    value = 282525
    if False and True:
        _dead_7446 = 186
        473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH3IRWMw1LI0EjiSwEHEHXUt418='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 48 * 10 < 0:
        _dead_7999 = 892
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3893 = 416
        _dead_5289 = 941
    return total

def _μтШПмБςφΚнчБι():
    if 68 * 32 < 0:
        _dead_8617 = 458
    value = 108305
    text = __import__('base64').b64decode('c1FTcDh1cjYxRU5CRm5vTm02UzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΕΕЕйαщмАС():
    value = 299833
    text = __import__('base64').b64decode('RGNNYU42dDE0VmwwN3NfYkpzWUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨбΓЕτжβΞЗχбι():
    value = 820740
    text = __import__('base64').b64decode('Z3FRUGdJMjFsUTBDN3hfUDJ4VGk=').decode('utf-8')
    total = value + len(text)
    return total

def _εХΗцЯγΓζΠψ():
    value = 244499
    text = __import__('base64').b64decode('dUtQd2Rhc1VpVFpJOEdod1FNR3c=').decode('utf-8')
    total = value + len(text)
    return total

def _δрΜΔЯыεфГГаιшΣ():
    value = 565358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBC8bAQ62vgaDgz77lKSZQ0esj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θμТΧΓвшМлВ():
    value = 319195
    text = __import__('base64').b64decode('VVBPdkZ6OUFaYm1ZWkd0ckd4Xzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩьОΩнМβωМйпЧ():
    value = 145331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwjAR3Q417wGIgeO2USYDAA+10s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗθςРВΚЮЛУф():
    value = 218489
    text = __import__('base64').b64decode('dGpjNWpLRUZ3MW9sVGh6WENLeXM=').decode('utf-8')
    total = value + len(text)
    return total

def _οχφγеΨΦΔσжЬ():
    value = 89232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji32ZlkGqJ4EHASo7W6/JQ8W1Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σюυЕРφуМ():
    value = 608691
    text = __import__('base64').b64decode('d3VlOERBTkI3NTk1d2t3TXBFYlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝмαΩКΝзγδтШВΗьЩΒ():
    value = 961803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiDWdlhh3aE3bj6M8kegFQ84xj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if False and True:
        pass
    print(__import__('base64').b64decode('bQ==').decode('utf-8'))
if len('xxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    pass