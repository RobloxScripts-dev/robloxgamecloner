#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ГξδΖΛуъψЗψЖ():
    value = 923494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXixb1Mxx4QEOQj1+XWlLSIOzEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        483
        pass
    total = value + len(text)
    return total

def _ΘθχχλБВΦТшΦНъΜШΕ():
    value = 964767
    text = __import__('base64').b64decode('bEdOODhyQlFuRndxOEthYzFOZWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬкεοΒшζА():
    value = 846334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECnWZncpq6w5bSuN3FWDbRUB1G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юТрПоыМАκЪУЭлΙλЕ():
    value = 403632
    if 55 * 77 < 0:
        _dead_6566 = 457
    text = __import__('base64').b64decode('S0VhdGdSVnhzX2lqRDg0N1JhNkw=').decode('utf-8')
    total = value + len(text)
    return total

def _уΨδгΠРкЧΦ():
    value = 206852
    if 1 * 47 < 0:
        pass
    text = __import__('base64').b64decode('b0wzd1BpVm5XSWFVWEgzMFhnbGc=').decode('utf-8')
    if False and True:
        229
    total = value + len(text)
    return total

def _ςΩσЕΩЦВΖкΠΤэЗХοи():
    value = 533325
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzXCeH465vgkHw2Q/QfGFSI4wzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝюгΖЧйСκςΧΔнσΟΓ():
    value = 728451
    text = __import__('base64').b64decode('b2U0MVBnUkY2UzNldDNiZW0wN0M=').decode('utf-8')
    total = value + len(text)
    return total

def _οΩцнфοΖτθ():
    value = 147402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQXNeWAX37tUAFuS7nO/JAQZ/GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬЖХΠУомΗЩ():
    value = 192421
    text = __import__('base64').b64decode('Z09QSlpGRXFSUWZzcEJ3V29xb3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥВΚРОАψβφ():
    value = 524005
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HX7lXAA89qoqHRqLwA+/YCkbsjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8092 = 207
    total = value + len(text)
    if False and True:
        _dead_6295 = 859
        pass
        _dead_8368 = 946
    return total

def _нΙΟαΧνЩΩЗΨюφуΠσ():
    if False and True:
        584
        _dead_6699 = 817
    value = 699301
    if 51 * 41 < 0:
        _dead_3181 = 538
        _dead_1252 = 302
    text = __import__('base64').b64decode('UFppWTMzQ0JSRkdUWnNNeVBkUk8=').decode('utf-8')
    total = value + len(text)
    if 78 * 25 < 0:
        pass
        pass
    return total

def _ξΙэЧЭХчΜΛςΙΧΞЭΘ():
    value = 748195
    text = __import__('base64').b64decode('bWppUW5kdW9qT0dHVk1UaWdzbVQ=').decode('utf-8')
    if False and True:
        423
    total = value + len(text)
    if False and True:
        _dead_3975 = 999
        pass
        583
    return total

def _ιУΤΖΒδξМфΣΨ():
    if len('') > 0:
        pass
        282
    value = 679117
    if False and True:
        _dead_1446 = 599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHjmW0cS8YUWLyWJy2O4Yi0D9j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 62 < 0:
        pass
    total = value + len(text)
    return total

def _ΖЯбρЮЯЫωп():
    value = 10853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy7QT1gy7awGBTaE42nDIS4a/U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΟΝοяΑняηН():
    value = 433752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAjnWX5sxPABAgCq/VyoY30fsjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9868 = 547
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_7427 = 28
        854
    return total

def _ЙΣВЖЗΡъЗ():
    if len('') > 0:
        74
        _dead_4423 = 809
        _dead_1425 = 177
    value = 773350
    text = __import__('base64').b64decode('cGFkXzV6MlpoU3hYRGpob3dFeGs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_2074 = 392
    return total

def _ΗШэβТшюэЛμД():
    value = 366066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz3BQksU64cRCj2R+2aFBAQp6W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΘПЫχρυСΨээβυъ():
    value = 724639
    text = __import__('base64').b64decode('SHVXa1hxaWFLeWkyQVpxcVVuQmI=').decode('utf-8')
    total = value + len(text)
    if 39 * 28 < 0:
        _dead_3039 = 855
        766
        pass
    return total

def _ΡИьФΨБЭΟиΨхБлπБΔ():
    value = 577405
    text = __import__('base64').b64decode('VnZueWNuSWNwYkZCUGE5VVpGRjE=').decode('utf-8')
    total = value + len(text)
    return total

def _τΠΣРНчЩД():
    value = 481471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHjpentq3/8baDjwml6pGRN3yTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΖгэγрγПиςп():
    value = 374199
    text = __import__('base64').b64decode('QzZIZG51T2FhUmM0dlpCQ1JaanQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ψОΕЮПΙπρθЗνηυ():
    value = 739823
    text = __import__('base64').b64decode('amQwdkhEdzZXcGxtYm9maFRCb3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ρпσςДКΞй():
    value = 778245
    text = __import__('base64').b64decode('RlBETUFaSk80RzV0RnBOU0F3MG4=').decode('utf-8')
    total = value + len(text)
    return total

def _АзφдβζЛΘΚЩλЛλΣ():
    value = 328654
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCzVagIJz40mCTb30HeYHAs2/X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗξΖаΦεμλξгΛЦШξЩυ():
    value = 362670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky7tOl0q9v0MIBiOx2KfIyc9/Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8665 = 946
        _dead_7216 = 193
    total = value + len(text)
    return total

def _ΩйНβЗныЗы():
    value = 182178
    if 98 * 8 < 0:
        pass
    text = __import__('base64').b64decode('YXRKNDY1X0ZZRzJXVHd1X3l4SFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛсйЧτσΓΛОоυР():
    value = 872570
    text = __import__('base64').b64decode('VUpiZUZtVkhVM2M4QTFncXdWbnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ξачяЯΞЫЗЪ():
    value = 576948
    text = __import__('base64').b64decode('RlpHQWVBNk5KTkRZdHgxbmg0SkY=').decode('utf-8')
    total = value + len(text)
    return total

def _вαΞσУИΡиФΑхыч():
    value = 216801
    text = __import__('base64').b64decode('bDRqTXl5Q1EzSEZjTjhobEs5eXk=').decode('utf-8')
    total = value + len(text)
    return total

def _υэБрθеθΕЭмеΨХξТ():
    value = 940087
    text = __import__('base64').b64decode('Y0NGV2poUVcxVWtkN0NVektFZ1g=').decode('utf-8')
    total = value + len(text)
    return total

def _μΚйРινρМШΥ():
    value = 106115
    text = __import__('base64').b64decode('Z2o4UVlucXd1YkJoN0dobjlsRHM=').decode('utf-8')
    total = value + len(text)
    return total

def _щидβхаДξΒчФΨΝз():
    value = 695002
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lzb+QVgq+6FUblzw7AGgZiY75z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        843
        723
    return total

def _ъΟΤКΥпнцц():
    value = 441405
    text = __import__('base64').b64decode('Z19fN3BwSm11dk1UM2dDZVpsZEo=').decode('utf-8')
    if 5 * 32 < 0:
        _dead_5373 = 770
        706
        _dead_7714 = 179
    total = value + len(text)
    return total

def _ЛДπНκИΞгЖрΚХΜ():
    value = 132429
    text = __import__('base64').b64decode('QlBKUVBtcUJ2c2ozT0dZYV81UVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ыζψЕυΚχмБъτΨβ():
    value = 450460
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDbwf2I095oELyKCzEOqJCwt5V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΝэχшαρΥХН():
    value = 84251
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('aDZEMndPQVNSb2lUYks3cnl3Z2M=').decode('utf-8')
    if False and True:
        _dead_1788 = 847
    total = value + len(text)
    if len('') > 0:
        984
    return total

def _ОλЯΤΑκσπΜβк():
    if 8 * 16 < 0:
        pass
        _dead_3744 = 638
        501
    value = 690014
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESX1SQEDzYcsMCH7+QGlBHImzVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еНГШбμПЬШНΕЫΠκдм():
    value = 362063
    text = __import__('base64').b64decode('SFVlUGFYSHd0OEE5X2lYR2x2WG0=').decode('utf-8')
    if 72 * 22 < 0:
        15
        _dead_7452 = 824
        453
    total = value + len(text)
    return total

def _ΙζйκξκθΣВΔяНдΞ():
    value = 650259
    text = __import__('base64').b64decode('ZTBvZno0cTB4N2pybktRMWFJUzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΣБгъιэзН():
    value = 552044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg7AaQls+v4paSyP+QWaMC0O/UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИςρВМδТйжщΛθψ():
    value = 261775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBvzXkEzxItQYlz70mymLTcavGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΔрΥτчзΦДбЫΛЦ():
    value = 388181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRfTR2ka8YUwBSazwFTBGSw8xng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КσяРΣъΑдуσπ():
    value = 572439
    text = __import__('base64').b64decode('TXRXVmczWWNWU2ZkTTR1dkJOTmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _εΕνΧνпшγСяо():
    if False and True:
        pass
        499
        pass
    value = 374950
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mi69eGMP3IBWDgGz2G+/AHIt9l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΟщЫεδТФθХχДпБЗл():
    if len('') > 0:
        _dead_4020 = 272
    value = 889758
    if 56 * 15 < 0:
        _dead_9168 = 847
        pass
    text = __import__('base64').b64decode('cFNqYVlqbldHOVlzQXdJaVdVaGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡшυЕэΙΗщδЙωэχМЦ():
    value = 208121
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCfwZGI4+LsFNiH20gS/JT8iyFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιьΠΑЭτаχ():
    if False and True:
        pass
        _dead_8573 = 945
        220
    value = 514066
    text = __import__('base64').b64decode('dHR5cV92elNhVVhRUkE4dFVGOVo=').decode('utf-8')
    total = value + len(text)
    return total

def _зФΘЙБмΛЪхЗΗЙКΞЧУ():
    if 36 * 4 < 0:
        pass
    value = 805386
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('dlhGRVYySVllZmxwcDBDRWc5WHY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8120 = 805
    return total

def _ΝыςьθΨЙζβяνΛ():
    if 55 * 73 < 0:
        pass
        118
        pass
    value = 49691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lga0UWMe5KQzbTW24w+YYiADtj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 74 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        516
    return total

def _φмρДВЫДЫΠΦΖΚτΙΙ():
    value = 242601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwKzYHNv17wqAgn66QSTJHcf0Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9506 = 276
        _dead_4843 = 594
    total = value + len(text)
    if False and True:
        _dead_6612 = 731
        917
        882
    return total

def _яфдАΡΗχωξυ():
    value = 257355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EA3AYgcVzZoGLjitww+VAnMj/V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        21
    total = value + len(text)
    return total

def _ΦЯΨюгΨΜВκ():
    value = 532427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQndZXka8P8gbAKE+VWkMSMC1XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        955
    total = value + len(text)
    if 32 * 64 < 0:
        702
    return total

def _ΜЖУчУΕНж():
    value = 829779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hxa9YmcvzKUhBR+s4gWcFhAf02s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σАЦХΤσсЮКσтξη():
    value = 884688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQTpSGg76JoTMjvynmezPC84tFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВφΚΑЬΘжΚФбοыэА():
    value = 364609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHj3S1AI2pokCheg23ugZxc3108='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣгΣЗбзΗгаЕΒ():
    if len('') > 0:
        _dead_8121 = 677
    value = 390295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InqwXFZuyIMICzbx43yGLRU8zmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 58 * 39 < 0:
        737
        335
        pass
    return total

def _δЛХπнКпπря():
    value = 531031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzndUV4Ky6c5ICytw0S0EjIeyzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖлЯΕνδΤУΛΤ():
    value = 828536
    text = __import__('base64').b64decode('eVlJem5WOGp4d2VtT0MyNFFtNWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤяςУГюЫεбεхαЪПтψ():
    value = 238127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDzXTHw/6LEvaSfw2FSICyI802M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 95 * 82 < 0:
        pass
        pass
        934
    total = value + len(text)
    return total

def _ЕчОкЦНЖмйΙЦрς():
    value = 352264
    text = __import__('base64').b64decode('YXFoUVNuNjNVZm91MEZ1NnBCSWU=').decode('utf-8')
    if 92 * 4 < 0:
        944
        _dead_9072 = 802
    total = value + len(text)
    return total

def _нЕΑΗιΖрэΕΠΑρηβЧκ():
    if len('') > 0:
        pass
        pass
        pass
    value = 527771
    text = __import__('base64').b64decode('WTJ3dHhNc0hNMzFlMEd5ZjZDQ0k=').decode('utf-8')
    total = value + len(text)
    if 37 * 26 < 0:
        _dead_3202 = 692
    return total

def _ЪеΦΩПρМа():
    value = 797272
    text = __import__('base64').b64decode('RTlsbGZ1MTF1dE1jbkpwR1F5dHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΑеοуцΚΠмЮЙΙςН():
    if 71 * 33 < 0:
        pass
    value = 260875
    if len('') > 0:
        _dead_3930 = 564
        _dead_5974 = 500
        _dead_1260 = 733
    text = __import__('base64').b64decode('aHhoVU5lYV9kSG5zNzVuazNSSHo=').decode('utf-8')
    if 16 * 89 < 0:
        36
    total = value + len(text)
    return total

def _АИЭγпχЙοΙ():
    value = 369663
    if len('') > 0:
        622
        pass
    text = __import__('base64').b64decode('a1hPemd2OEdoZV9jdGFoVzc0RDc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        224
        625
        773
    return total

def _φпЦΩγЗΣЗ():
    value = 960992
    text = __import__('base64').b64decode('aExPYWFUZHlBUHBIS1V5Q3g3ZEQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        471
        219
        348
    return total

def _ΥΧъΚσъчПзЙЩ():
    value = 567614
    text = __import__('base64').b64decode('d0ZmZ0toZGp3WVJGd1l3d011eVI=').decode('utf-8')
    total = value + len(text)
    if 15 * 6 < 0:
        pass
    return total

def _бмΗТΠГОХжΛΨс():
    value = 391656
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgnMOWY6q/xUP1mA21qGJQB+vUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΤлцΜЦСЕОнΥτΜН():
    value = 863245
    text = __import__('base64').b64decode('c19XdFBNdnpEV3IwMDQ0RWVxeEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛКοнξΘΑυп():
    value = 470808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyvSaXloypoxOCKxynKSPhEqsUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ατλГΨзяψΣжΓе():
    value = 278340
    text = __import__('base64').b64decode('Q19XNExfaG44aWFpU1R3UkJUOTA=').decode('utf-8')
    total = value + len(text)
    return total

def _νыхωчΜГΠЯΝпвг():
    value = 33594
    if False and True:
        997
        392
        _dead_9775 = 501
    text = __import__('base64').b64decode('eDlUaWE5SHJkT3U4X3Fqd3lGdk0=').decode('utf-8')
    total = value + len(text)
    return total

def _оОКЗвΝτЯρκ():
    value = 748136
    if len('') > 0:
        396
        732
    text = __import__('base64').b64decode('VjhjMDJseFJpUmZZamRBdjJxQXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΓрПθΝШΤΖθРΔΩшΚ():
    if len('') > 0:
        519
        143
    value = 665053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BADwPXMBprszNFjwyUKJIXAGszg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВξЪЩΤΕрηΦЙγ():
    value = 753759
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnbiXmlq2b8Ibzmc+AenGy4m7Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕШЛοΛЮρНμц():
    if False and True:
        pass
        pass
        902
    value = 954694
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR23WWdv8qUIAjqR4lzCMQp7vF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 71 < 0:
        115
        _dead_6025 = 887
        985
    total = value + len(text)
    return total

def _ΦмνЗАШФДξπнРПЫИ():
    value = 603471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgvhXmYt6fEODgCbxleVYysp6mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИБЫМθжгΤЗГΘψΠδэЧ():
    value = 276319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB/8QWcD7P4JLRiK2gSfMBZ4sVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПйγΜЖξΛΕΘЮП():
    value = 617777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzftO0sB060VMimokFepEwM6/H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΓξиПИИΨκ():
    value = 205558
    text = __import__('base64').b64decode('UWdCQXJmSDBERDZfZTkxS0FrTkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤьζУэΨСЩ():
    value = 525515
    text = __import__('base64').b64decode('Q1VMdjNkWGpNV2xIY2ltYVBNZjU=').decode('utf-8')
    if len('') > 0:
        510
        618
        _dead_8225 = 434
    total = value + len(text)
    return total

def _УγЮτьяиπдр():
    value = 301739
    text = __import__('base64').b64decode('TDRyY0dUV0JXTmF5QUlRZlFJdmM=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4949 = 569
    total = value + len(text)
    return total

def _ТΕНЛζУтП():
    value = 752890
    text = __import__('base64').b64decode('QkR3clJKMmp6eFI3Rlg0UDBiY0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΚΡЦπЕΩлοΓсюΔ():
    value = 316230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxjyNlAK7Ys1KFzxmmaGPzcqzH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        520
    total = value + len(text)
    return total

def _ιНврбЬУГаθМ():
    value = 391996
    text = __import__('base64').b64decode('eU40RGdrdER2NTZaUjcwaVFMTjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬМнγУЪπБΝЦТΚΕΗэ():
    value = 556554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDb+YEU/5JgpIzya5HuKASQ5w2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΕтΠуΖшπкξТВнΞο():
    value = 238074
    text = __import__('base64').b64decode('QzM0Zm9wRUM4U1BWTEZFTDIydDc=').decode('utf-8')
    total = value + len(text)
    return total

def _εТТюшИВΡйрхυ():
    value = 626987
    if 34 * 36 < 0:
        pass
        185
        _dead_5103 = 794
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ajf9N0sTr6kvIles4k6YMQYX8Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        857
        pass
    total = value + len(text)
    return total

def _ьΤжРμныΧДХΦНХгθψ():
    value = 458042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz3AdgMwwb8FDhW7m3u0Bh8D9F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑφУφхΦΒοФαЩШнκ():
    value = 967400
    text = __import__('base64').b64decode('ek5tTnYwYnhid2N6aXFVcGxNajg=').decode('utf-8')
    if len('') > 0:
        _dead_7221 = 25
    total = value + len(text)
    return total

def _εЦΜАМШндКгΖоδπΝτ():
    value = 143549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyDsZwY9pqRbAhiv41vADSsH/Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХωΥЗжΝюΤ():
    if len('') > 0:
        _dead_4219 = 364
    value = 421032
    if 79 * 85 < 0:
        _dead_3964 = 91
        _dead_5377 = 639
    text = __import__('base64').b64decode('UTRPbkdoc2M0YXdjYmoyTDNDWFE=').decode('utf-8')
    total = value + len(text)
    return total

def _χЕρЕГлТИжСд():
    value = 916815
    if 52 * 97 < 0:
        pass
        629
    text = __import__('base64').b64decode('eTRRX0x2cmxNOUVCVXoxdXY4TEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓуьθθЮοКςηβ():
    value = 276032
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy7HPlkh87sUKySl4F3AGBQB9D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5878 = 158
    total = value + len(text)
    if 23 * 16 < 0:
        _dead_5121 = 589
        _dead_6029 = 663
    return total

def _ΙБоουчλΖ():
    value = 242769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3vwegQhqLo5LD2P4F6XPAQM21Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪбнαТхΥΡψжιоΘζ():
    value = 788206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzXgdEQNyIQZCgG0zlulOi0t9WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6663 = 15
    return total

def _ηчСЮПгθыЩъуΣπψ():
    value = 286308
    text = __import__('base64').b64decode('UUg3MUszZ1VtVl9oVDhGamIwX0k=').decode('utf-8')
    total = value + len(text)
    return total

def _УΦЯщΒμρЭ():
    if 72 * 75 < 0:
        _dead_8054 = 778
        pass
        18
    value = 465137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EATWWX4Y2fsFIhmhw1CgESoFsHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 52 * 94 < 0:
        _dead_4894 = 687
    total = value + len(text)
    return total

def _нЕЮхΖψςхеяΛжРλ():
    value = 420464
    if len('') > 0:
        _dead_2424 = 811
        795
        _dead_6539 = 785
    text = __import__('base64').b64decode('VkdKY2Q4dHd6Tk5JTnNzbDVQSUM=').decode('utf-8')
    total = value + len(text)
    return total

def _νмфΧпГηЫ():
    value = 771661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwD0awEAro4tKC6L/w6SbCc34kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГмσгΙФдπЗΦтυЬТИЬ():
    if 88 * 2 < 0:
        pass
    value = 328870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyTyZWY0y4YEPjWn8GW0ER8O62g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞυрОΠТжЛχ():
    value = 561405
    if False and True:
        _dead_9337 = 377
        808
    text = __import__('base64').b64decode('SnBrYms5RTg2b1FJc3RDSE5UMjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΓλЬСΙΑρ():
    if len('') > 0:
        _dead_6035 = 545
    value = 839274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCnzSlM9pr4balybxVyDAi547Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бτΩчοцςπΒ():
    value = 59171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3jdOAcb1Z4NGzit63G3CzEYwGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хεТмкУнвξΕλТЯμΓ():
    value = 257690
    if False and True:
        135
        180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTnSfn5o34cxHgOI6Q+5PRc4sms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 7 * 21 < 0:
        pass
    return total

def _МюιНЙмτχзΚΔ():
    value = 109112
    text = __import__('base64').b64decode('VmgyQW55bk1CZGlXa2VwZzk0V0c=').decode('utf-8')
    total = value + len(text)
    return total

def _тПрΓθχжΜвтλωЪх():
    if len('') > 0:
        645
        _dead_5079 = 988
    value = 476878
    if len('') > 0:
        _dead_7994 = 374
    text = __import__('base64').b64decode('aVpoU3NxZURBemM4d1R5TWk5Smc=').decode('utf-8')
    total = value + len(text)
    return total

def _гЯПКкьэωΓ():
    value = 230963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBrpQGcz5qU6MzqC5XC7HQwJ71Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φКυлЕσШΘеδкθУТκ():
    value = 406308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxXxOgUBwacvHC6nxFm0IjAW3Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΕμзφθУΞηΩщЮЙч():
    value = 545670
    text = __import__('base64').b64decode('dzF0b0tNWGdpd2M3bldtTmtLZXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΚпоЪъЛυ():
    value = 237899
    text = __import__('base64').b64decode('bU5DVFpzblRRRWFTaG9ZY1c1NXQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_1274 = 142
    return total

def _γЖдУχΕωξΣΙфΣрШΞ():
    value = 405975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3zyawkyyvgWaziTw16kGQcdwUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζНнБΗιοωГΣΥРб():
    if len('') > 0:
        969
        pass
        657
    value = 723455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT/dQAMeyPgQEgSK4ka3AnEJ9V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯмζдΙψΕАλЯθЧΡ():
    value = 828726
    text = __import__('base64').b64decode('UjJvMDVldkJlS1RzX3I1c3haVlA=').decode('utf-8')
    total = value + len(text)
    return total

def _чБξΣпμλννЛΡ():
    value = 515630
    if len('') > 0:
        616
    text = __import__('base64').b64decode('aGR2eHQ1UEp5Q0dMT2pqa0lwTU4=').decode('utf-8')
    total = value + len(text)
    if 8 * 55 < 0:
        pass
        pass
        535
    return total

def _ΤΩγηΖΧаЕυΡ():
    value = 240781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3nPO2AVrbgQOQPx2QC4Owgcxms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧвρКΕΠχηкГюνΝ():
    if 17 * 47 < 0:
        _dead_7762 = 960
        _dead_6371 = 621
        620
    value = 44477
    text = __import__('base64').b64decode('b0JuemNhdl9admtpRnczbkE4OGk=').decode('utf-8')
    if False and True:
        pass
        932
        _dead_4689 = 797
    total = value + len(text)
    return total

def _ЖζΠφΑфΤМУЛя():
    value = 232392
    text = __import__('base64').b64decode('SEJTTm1TQVNDbll2UUkyVzR3VGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧГνьВзΜжГαЧβνШ():
    if False and True:
        _dead_6392 = 875
        651
        _dead_6431 = 44
    value = 289980
    if False and True:
        _dead_1575 = 924
        pass
        611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB7QUWE2+58BFQqk7X/BGjY80mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧнеΨιΔζКуыг():
    value = 672196
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiLTQmQ/2v0JOByr+QPJJjcgsEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κδИОдΒθн():
    value = 632648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXn+bFQo+qsxIxaM0lq0Zid4wEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΨйРνшщз():
    value = 177785
    if len('') > 0:
        _dead_9224 = 473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSTrPmQ62Pwubx2c4FudEQg59n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 80 * 81 < 0:
        _dead_6625 = 830
    total = value + len(text)
    return total

def _δкКΤξпяоηΝфЩЕнη():
    if len('') > 0:
        555
        _dead_7770 = 352
    value = 94198
    if 61 * 71 < 0:
        _dead_5609 = 165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx23WXZt0K4EbgyLmWGiLh0N41o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 38 < 0:
        _dead_2423 = 842
    total = value + len(text)
    return total

def _ΙТЕюОΨΣАΩйΜ():
    value = 1538
    text = __import__('base64').b64decode('R2NDQlRfSDN3VTlyM0I3VUFiOGw=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        337
        _dead_2944 = 886
        888
    return total

def _ΠЙБчвМИлНълτыиоο():
    if False and True:
        22
        _dead_2153 = 873
        _dead_7095 = 694
    value = 2166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cji9ewcY0Z0VMga7327JZQQMt2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мАοНеиΘНЬКΘЫΑх():
    if False and True:
        _dead_5286 = 184
        _dead_3536 = 42
    value = 23802
    text = __import__('base64').b64decode('aTRuMjZuamFjbzA0eDB3eUpFT2w=').decode('utf-8')
    total = value + len(text)
    return total

def _оКζфΗκэцЮтшωВλ():
    if 12 * 50 < 0:
        385
        74
        pass
    value = 981209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgC3RHwgroULL16qnlPCHHIQxzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 62 * 1 < 0:
        _dead_3666 = 249
        pass
        _dead_8660 = 842
    return total

def _мспαгτΟБχжβБγς():
    value = 992027
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiTrNnszr54mPjCk50G+Hhoat3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        508
    return total

def _ΣВΡΘжψОЗФ():
    value = 842464
    if False and True:
        387
    text = __import__('base64').b64decode('dDFZYUI2aFlCbTZ5QkVSTzZwYmM=').decode('utf-8')
    total = value + len(text)
    return total

def _СяНхГВΙЗεΠГ():
    value = 333598
    if 2 * 6 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDzhdnUK/IIBLi6t/gOIN3M4/UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        29
        pass
    return total

def _ыιρТИλэЧΜηςΒБшч():
    if False and True:
        570
        pass
    value = 269989
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw3lPnxu95EpCw653ma1Mih3028='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 4 * 47 < 0:
        673
        pass
    return total

def _АВтгэЬЙРΨν():
    value = 823724
    if False and True:
        500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgD8dFMr8Y0TKD+S2XGvYCcYw0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΝφΞсГШНεгΛ():
    value = 672831
    text = __import__('base64').b64decode('aW5BZU9ISmhTbk5Yb0ZlOXpobWs=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        633
        674
    return total

def _ТжωαХюμАΡ():
    value = 198694
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('UENvemlBbjNWSTk4ZHpNYjMxVXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΑςШуΜцΩψБц():
    value = 223343
    text = __import__('base64').b64decode('c1NmSnJfQTFVeU5xSjFjSE5KMDY=').decode('utf-8')
    total = value + len(text)
    return total

def _φχыТМЖξвгρШкπпч():
    value = 648036
    if 93 * 75 < 0:
        pass
        _dead_4258 = 909
        _dead_7750 = 967
    text = __import__('base64').b64decode('SWJyYm4wTU5kVkY3VlZhZTMzczA=').decode('utf-8')
    if False and True:
        36
    total = value + len(text)
    return total

def _πΕПοыΗъΒ():
    value = 601183
    text = __import__('base64').b64decode('dklVNTNYOUtqWUJCSFllaFVObXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΔδыκМкщеЬδ():
    value = 968460
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXriUX9orqMWLSD3z3WZFhA80UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5069 = 914
        pass
        _dead_9044 = 141
    return total

def _ФЩЪРΛШΚиЙΧ():
    value = 23005
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyTWXFowq6kIGAyP207ANQYksF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вшλЗрΥюΘнρψФФЖΛ():
    if len('') > 0:
        305
    value = 364981
    if len('') > 0:
        _dead_9143 = 796
        671
    text = __import__('base64').b64decode('VjUyN3hSSFp2bFRmRnpQRWdsTTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЬнΜРΡУЧДыθΔЙ():
    value = 387920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAj0TX0N24s3OT6Jz0CJLTc/yDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ипυБюΓζАъ():
    value = 751253
    text = __import__('base64').b64decode('ejdTRFp2UnVOQ2FEY3J0M3dVdl8=').decode('utf-8')
    if 77 * 25 < 0:
        _dead_2246 = 621
        491
    total = value + len(text)
    return total

def _δσуΙБЩμЗпΛΧ():
    value = 920307
    if False and True:
        124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Djv2Y3wc5JBXFgOiyQaGZj8a618='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъьβНμμΥπΨк():
    value = 954503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgvxUUUdqK0KPh+123/DBSAC7EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΡПψΥэΘАρζфщρ():
    value = 718053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxD3ZGEj9IwKCDuHw2OxDSwk4EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        295
        pass
        pass
    return total

def _йСиςεлзΝζΨСΡА():
    value = 490724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAXGOWAY87E7OAOt5UGdEHMfy1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βΟВиКУДΧΔСγВК():
    value = 899190
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwGxZ3Jg5v4iIDaW20PFADYq7DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 16 * 44 < 0:
        _dead_9556 = 314
        _dead_2902 = 665
        _dead_5223 = 962
    total = value + len(text)
    if len('') > 0:
        _dead_2600 = 593
        _dead_8676 = 621
        pass
    return total

def _βяЬуЫЧщЛкθζ():
    value = 617307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JibweAUjq70nMQaLx3GyPj8uyU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣςчЫжСфκιεР():
    if 63 * 82 < 0:
        pass
        _dead_4240 = 655
    value = 10708
    text = __import__('base64').b64decode('THBQVXBla0Z0dmtPMXZXT3FQamo=').decode('utf-8')
    if False and True:
        922
        _dead_5891 = 175
        586
    total = value + len(text)
    return total

def _АρΗпΨхεЫκЫъλшжА():
    value = 804859
    text = __import__('base64').b64decode('eUlzWDZYR1dBN0NrT2hZWWVJS2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ωЯλхΑндлτΙΠ():
    value = 589347
    if False and True:
        _dead_3046 = 533
        pass
    text = __import__('base64').b64decode('bzhjSWtMV01CazlacXYwX0NvQ04=').decode('utf-8')
    total = value + len(text)
    return total

def _ычУЙΘκΚθ():
    value = 890707
    text = __import__('base64').b64decode('TThNSDNBRUhfMGtmSkZNdU9wTEQ=').decode('utf-8')
    total = value + len(text)
    if 18 * 10 < 0:
        535
        _dead_2712 = 554
        _dead_5685 = 883
    return total

def _οΗΥЧпьΠΙβФΘΩжэπ():
    value = 858401
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('VjcxNzZJV3FtdDVNYk9jOVppUVE=').decode('utf-8')
    if len('') > 0:
        _dead_1695 = 647
        pass
    total = value + len(text)
    return total

def _ΦюБвзβΘЭфαΥ():
    value = 779029
    text = __import__('base64').b64decode('QW5IUVZkZnZFM2laSDZtMlppTFc=').decode('utf-8')
    if 7 * 18 < 0:
        _dead_1265 = 321
    total = value + len(text)
    return total

def _ЩθШξΚσψМξУщ():
    value = 502920
    if False and True:
        _dead_4981 = 731
        pass
    text = __import__('base64').b64decode('aEJQdW9qR1czWVBEanVEYzIwcGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛζΚνΔМψωХφюεк():
    if 64 * 12 < 0:
        _dead_5643 = 262
        pass
        pass
    value = 213192
    text = __import__('base64').b64decode('bGNESXNqUnNqRlMzVWZId2tXZlc=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4303 = 944
    total = value + len(text)
    return total

def _ΒЭНЙΑХγΣΘЗ():
    value = 80303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EArbRWRh2Io8OAKX/m6TLgJ+yTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        738
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _тэАбβяΥΗρνЪ():
    value = 640039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSPAdEEur5hXDCSQn1LFYnwQzmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΚФьпСвШΗФυс():
    value = 557112
    text = __import__('base64').b64decode('R1hIZUhrcXdpSW9KTk5uczF2b20=').decode('utf-8')
    total = value + len(text)
    return total

def _ωдВЪΚЛτи():
    value = 499505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCjrO0Uf3KswDDya70GFMQMk/UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _инЭХбηΑεΕΦГχςΡ():
    value = 514609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHrpfnYg8JsWPTrx91fCPQML7E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        523
        pass
    return total

def _θйОοЧεЧЛЧьПТХο():
    value = 516154
    text = __import__('base64').b64decode('T01tenpySVNja3EyVUU3TFE4d1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΑΘΒΛΔвИбнз():
    value = 146976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSy3YnQT8ZEVGBmC8G/DOCcNwn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7655 = 481
        pass
        _dead_5498 = 708
    return total

def _мдΔМЗВХЫЕγ():
    if False and True:
        pass
        _dead_2889 = 216
    value = 990751
    text = __import__('base64').b64decode('Uno4VVFBbTRaZ2RXMGFjVzVybHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪψΓΒΠМЫσΣьЛ():
    value = 104464
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyLtYUQNqP4PACD65n+fOhYGx2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РбХυАфΒОКШφΞ():
    value = 265748
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRb3ZlMj1786Owi0mESvZxU593s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кБΡщжЛЫмСБк():
    value = 668827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxzjdAIpx7EkDz2E0gehAyIAsVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шлΟεХΒЩчроγ():
    if 52 * 83 < 0:
        pass
    value = 862471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB/BWGhh14IvAj6qwgHHMAYBtkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΟдηщνΞξνъГσ():
    value = 31626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCe8QHcT8rBaHTeKkVGVMSwn9lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        674
        _dead_1390 = 538
        _dead_4117 = 89
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_3056 = 990
    return total

def _ОυΙεЫНημьΨΝпδηЦ():
    value = 848566
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCXtfGQs6/oyYxaK5QW6NSIMw1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τЛΖΝЮЬшяτΞ():
    if 94 * 1 < 0:
        _dead_4795 = 141
    value = 97169
    text = __import__('base64').b64decode('bldoeERMcWY2X180OG04U01mNWw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3193 = 446
        pass
        pass
    return total

def _οвΘгЭКбΣ():
    if len('') > 0:
        _dead_2557 = 479
        _dead_4972 = 912
        pass
    value = 331850
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX29eQU+7I8PYjz772CpMnM99ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _δшμщтАрВР():
    if len('') > 0:
        _dead_7289 = 938
        pass
    value = 520433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgXJXGst5qcyNTuK3nClIjEn/lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КκочЭЭяФβΝО():
    value = 955012
    text = __import__('base64').b64decode('bzFEclJLQzNPNUo1NXE2MG5ybHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞькЗЗдНΦЯ():
    if False and True:
        787
        pass
    value = 623550
    if False and True:
        _dead_2329 = 319
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IST1alsN5psbCySpml6mG3YV9VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        825
        206
    return total

def _ΖГμБхеЫдДЛшπЯΦΤ():
    if 22 * 76 < 0:
        124
        223
    value = 912334
    text = __import__('base64').b64decode('YzY4M2dNS2xjakJPMEdGTlRDcGk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8533 = 319
        pass
    return total

def _ΑςюΓΡэωεЩнрΥ():
    value = 761187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LATNPkEc670pF1+M2FPCLjAMwn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙφвΒυοЗчνθΖдПД():
    if len('') > 0:
        pass
    value = 27066
    text = __import__('base64').b64decode('T01lSmJ1SGZjc0xZY3F0UDNpTFA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        831
    return total

def _ΚЦЙΠΗсЮЙщЬΙΦИч():
    value = 934202
    text = __import__('base64').b64decode('anRpZ2FmOUREVDFqdDVRWG51eW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗНжЙκΑлЛшΜ():
    value = 530334
    text = __import__('base64').b64decode('SXVXVDZvc2d4ZFBlaVJEaVFoT2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛеъχΣчοктΒнАωλςФ():
    if len('') > 0:
        250
        47
    value = 144454
    if len('') > 0:
        14
    text = __import__('base64').b64decode('ZEhEQmFiRGk3c3dGZjNWSU5KNHE=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        203
        480
        _dead_1676 = 179
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('IA==').decode('utf-8'))
if 21 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()