#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ьжЖλЯкξИЖξОςфБΙ():
    value = 598669
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fge8dFcJyboELgfz5W+YHhwOzWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρнΔκФΤоΙОЕκэЭ():
    value = 874897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgX0eQYJ3/8HIBiO7kezMy8rvWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣРεΑγςхСτΙΦтмк():
    value = 384335
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCWxbG4M6vEBE1mNzlCFPAks91o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρвδТХρщγЛΨДΩκ():
    if len('') > 0:
        660
        847
        418
    value = 901998
    if len('') > 0:
        580
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjW2ZAUtqoZXK1e1zQa1LAED5lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юзхргАМΠς():
    value = 416072
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwTqVEYg574hMx2XmWeGGj0LyVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нτоΕУζρτ():
    value = 292177
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnvUVHNs2oIpAjr67FWjZCQjzkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        501
    total = value + len(text)
    return total

def _рξςΓэΙΜδθΔξй():
    value = 221003
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('S0V2ZG5xM3djX1FtSUthblhDdWs=').decode('utf-8')
    if 95 * 87 < 0:
        pass
        685
    total = value + len(text)
    return total

def _ζщοРКΦЧДзΗΑψΘ():
    value = 987963
    text = __import__('base64').b64decode('SEdkUmlJRnE1aXRkUWFnQU0wcTA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5301 = 562
    return total

def _ШзξφЗЬОηсв():
    value = 378746
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDfJaGUT0fgLORiky1zGPAsXxmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜζαлвΕШоωОγισВлΟ():
    value = 975987
    text = __import__('base64').b64decode('REtjZ2hDbXN1Z0YwM2cwRmRYQ3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞШξВκъгμчΣηп():
    if len('') > 0:
        _dead_8205 = 693
        _dead_6954 = 709
        _dead_1727 = 579
    value = 968742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyDtYlga8J1TGzyv7k+TY3weyVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зλрΕινьιИУθчХ():
    value = 189223
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAf+X31v0Jw1Ll2py3eRAi4V91g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μяΜЮΚРτΩиηИъΨб():
    value = 274721
    text = __import__('base64').b64decode('ZTU0cl9zMGh5OHp2akNZVzdRYjU=').decode('utf-8')
    total = value + len(text)
    return total

def _явхчБπМцжйφφчωЕε():
    value = 698227
    text = __import__('base64').b64decode('cHRSc3V1RUY2UFVNWUJRbXBqSTg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7520 = 627
    return total

def _ЖπЗΙБкзу():
    value = 908220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KC7+X2gGxJshAD/z/Q+eYXIEvUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 78 < 0:
        pass
    total = value + len(text)
    return total

def _ωДДбЮΟπυЦχξЮΙγ():
    value = 391566
    if len('') > 0:
        300
        pass
        795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyW1TV0jpps2MRuBwHqmHQkc3Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓκжΙЮНβσ():
    value = 674679
    if False and True:
        pass
        pass
        598
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQbzalQV6P1VAluL+wC5NxcftF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        295
        pass
    total = value + len(text)
    return total

def _зΑΒелУΗξδжΥДΝ():
    value = 514223
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRvqRXUGqKctDTiO/ga4OQEL03g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τψХХΣЩΝт():
    value = 279171
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('dzMwSHlGdEJaVXMwUDljeF84STA=').decode('utf-8')
    total = value + len(text)
    return total

def _юθΩМхЫΝДыΩвυы():
    value = 667632
    text = __import__('base64').b64decode('b2E1NWVKRU9hTXQydk5sMVBFRU0=').decode('utf-8')
    if len('') > 0:
        703
        pass
    total = value + len(text)
    if 68 * 50 < 0:
        _dead_4504 = 382
        _dead_8851 = 46
        _dead_9930 = 237
    return total

def _ΡυТЩСυОишΩацχ():
    if False and True:
        pass
    value = 512883
    text = __import__('base64').b64decode('VEhubzVkeXFkUVNjVXZZT0dRc3M=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if 6 * 25 < 0:
        _dead_8538 = 414
    return total

def _ЦэΩξιаλДδ():
    if False and True:
        _dead_1484 = 103
        325
        pass
    value = 220054
    text = __import__('base64').b64decode('YUs5VVlQeEpjaklSMmJBOW91RVE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ΧτилУяψо():
    value = 218619
    text = __import__('base64').b64decode('eFNZQWNXOEdZMkRhVmVod2xDaHY=').decode('utf-8')
    total = value + len(text)
    return total

def _рχНΔрΧξφη():
    if False and True:
        0
        pass
        _dead_1934 = 320
    value = 178177
    text = __import__('base64').b64decode('RXJWaDhoNTFBVU1GSlB1cEZaNWI=').decode('utf-8')
    total = value + len(text)
    return total

def _κτГЭШабΩЙЕЩЧ():
    value = 209697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EH7NeUQQrJ0GMB6yx1G/Dhwms1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪτБσδψφФβдθσλΘβ():
    value = 29629
    if 26 * 75 < 0:
        pass
        _dead_7860 = 919
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXjwN2Nop6VXAiOL0A+SC3MktEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2174 = 393
    return total

def _ЕεΝМζЧкΑсαΩс():
    if len('') > 0:
        952
        _dead_9373 = 667
    value = 889435
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Agj1OmEgybpQNDqE4gDCMhoh9kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 99 * 6 < 0:
        903
        _dead_7365 = 39
    return total

def _ΔэζчьтЙυζ():
    value = 443498
    text = __import__('base64').b64decode('RG00NkdkU2JuaFRHS2w4dGh4dlU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        35
        pass
    return total

def _йТЦБцЭΥПγΞЭΦ():
    value = 301256
    text = __import__('base64').b64decode('UWVCTXY0dHNQOFhnTDFMaUpFWkM=').decode('utf-8')
    total = value + len(text)
    return total

def _νΦΩЫσсΧюΩγ():
    value = 613987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS3KVG487b1RIBXxy3m0Ew12/Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зжЖеДНγιбмΗΙЖΨΒО():
    value = 28053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRrhYAZhzIQXEz2y512vYxc48kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 78 < 0:
        _dead_6185 = 1000
        _dead_8449 = 256
    total = value + len(text)
    return total

def _ΚьЫкΡЧФИЛН():
    value = 760445
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQruQmUc36UQbhaG61KvGXYJ62Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔПпРщΛВИПЛАςПГΜφ():
    value = 711736
    text = __import__('base64').b64decode('R1ZnaEw1N0pNdHR1YVRnc0ZVS1M=').decode('utf-8')
    total = value + len(text)
    return total

def _нКеιθνилΩνгЙЗхЬυ():
    value = 485751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C36yRVMO0v4kER6Q63nBYAR672g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙюЛДътЖΔ():
    value = 979168
    if len('') > 0:
        222
    text = __import__('base64').b64decode('TUhZYkJCWl93QWpDR0pUOVBTQXI=').decode('utf-8')
    total = value + len(text)
    if 3 * 32 < 0:
        104
        805
        pass
    return total

def _эΝΛвмЬοοЗкас():
    value = 367416
    text = __import__('base64').b64decode('TlM0azRlYXZDVTJ6aDREbUF3YTk=').decode('utf-8')
    total = value + len(text)
    return total

def _мφюασωΤΔХξ():
    value = 352068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQThRkEU6rIGHDyixW6WAjQV/GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σкΦνкЭφэιφЩγсбП():
    value = 443349
    text = __import__('base64').b64decode('ajFzTTNFVzdpWnRjRGRkQVIxMjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΒрОбΥΥЫГШδрА():
    if len('') > 0:
        pass
        pass
        513
    value = 697061
    if 72 * 81 < 0:
        602
        _dead_3754 = 494
    text = __import__('base64').b64decode('VnRsMFdhaUFfbDBlanJaZDZYU28=').decode('utf-8')
    total = value + len(text)
    if False and True:
        244
        771
    return total

def _фβηНФμΡΡΔЛПы():
    value = 678374
    text = __import__('base64').b64decode('ZDkwdkNHWGJEYTdGY1JsVENzVWU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7219 = 881
        pass
    return total

def _юГИМИςсΣΗПЧωм():
    value = 894308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjjnRGQ86oYLPg6q9wfBBjw4/UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠЩξΦПбχд():
    value = 123951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTnGUUdu7YUWLB26wQTIOiZ3zko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_5875 = 173
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ЮΞζΓфУкйеЧΟОЬЛЛц():
    value = 251865
    text = __import__('base64').b64decode('eUN4N2luQlpQeThPcmFNQnJMOTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _оДΨлВфьιρΩйШьЬΨ():
    value = 514551
    text = __import__('base64').b64decode('T0RwWndjQ2tsOE9RbjVCa1JzWm4=').decode('utf-8')
    if len('') > 0:
        811
        _dead_9311 = 722
    total = value + len(text)
    return total

def _еψпιΓРАθΙ():
    value = 558725
    if len('') > 0:
        _dead_4302 = 502
        _dead_3738 = 210
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT/TOHITrJwpbx6I+2+9ZBQk1GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 28 * 52 < 0:
        857
        pass
    return total

def _тжЮνΟДэχξрПХπ():
    value = 710556
    text = __import__('base64').b64decode('WDFNb0p0WEs1TmxVNVN3MDF2Zmg=').decode('utf-8')
    total = value + len(text)
    if 21 * 83 < 0:
        761
        pass
    return total

def _нАиκсνвτАц():
    value = 517094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTXcNmNv/YYNKSCo7nq3CzwAtTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пКΓКШΕЪХчСФ():
    if 60 * 73 < 0:
        443
        pass
        _dead_9097 = 889
    value = 842731
    if 69 * 58 < 0:
        pass
        _dead_5769 = 520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCm2emEX3bkaajqVwQLCEzc5t28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΟΥΟюзиΥΩсМιΓжзΔ():
    value = 799343
    text = __import__('base64').b64decode('bXNsTW1DaUNfRWJDYnAxemRvSk8=').decode('utf-8')
    total = value + len(text)
    return total

def _υθъвБθΗαУтЗЬ():
    value = 642453
    text = __import__('base64').b64decode('dDVockVCQldCWnQ0TTBOeEdTNmM=').decode('utf-8')
    total = value + len(text)
    return total

def _σψλХΝαΩΒΩрмΚЯЗ():
    if len('') > 0:
        _dead_2497 = 856
        pass
    value = 200443
    if False and True:
        _dead_5628 = 53
        168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgPCfWsWqPsNPgqc+wakAS4ZsTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8367 = 637
        427
    total = value + len(text)
    return total

def _ΗмξвξШΟйΨВχσд():
    value = 643734
    text = __import__('base64').b64decode('a0NHc1d6SGdNeGRNRlF0cUNiRFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ПъвСГПЙрκзФ():
    if len('') > 0:
        393
        _dead_9127 = 862
        _dead_5266 = 394
    value = 135796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxreRGMWxPoSAASu8lWRECMmzVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        pass
        823
    return total

def _мρΣдΕΧМГйНЙВКск():
    value = 926320
    text = __import__('base64').b64decode('QkVkbkt5TjE5YndOaGF6a3NuRUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ζТДΘΖхцΧЙОуыЪ():
    value = 922797
    text = __import__('base64').b64decode('eU9YM0ZUN1VaVVlSMVhHTGFUNE4=').decode('utf-8')
    total = value + len(text)
    return total

def _νЭЦЦΝНЭФ():
    value = 551823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXrVS3Q/9vgAAium6lG6BAF4x3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рДυесΔδфΗНΞσУ():
    value = 774141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAv0VAEQxIJTEiea8k/EOyoFz18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΜЖΣχωДΞЮНλ():
    value = 439261
    if 88 * 18 < 0:
        pass
        _dead_7901 = 736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyPAQ0AW+YQBNzuw506SFikHvTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        300
        pass
        _dead_1774 = 216
    return total

def _кχοвДЛэзгΡ():
    value = 559653
    text = __import__('base64').b64decode('bXI5NW1wN0dfcDNTZlpVM0VGTEc=').decode('utf-8')
    total = value + len(text)
    return total

def _хшВΝщРеΓυьжРнП():
    value = 403899
    text = __import__('base64').b64decode('aDNCR1VBa3FiR093ZEZYbVcxdEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ψКЭЭΘεЬзьПΒμνкгЩ():
    value = 34597
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyLOakkDzLAJCAiU8W+6OHR31n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _σпиаνМζЛх():
    value = 674822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgG1eGA27ospFRmy/VeUBXc1xjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПθΧлζЯΤΕψкцФ():
    value = 563368
    if len('') > 0:
        792
    text = __import__('base64').b64decode('SHFiaGdYUXA4aXZJeWhEZ2pLb2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΩубωшОЭчуτОψФΒ():
    value = 833669
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQbwdgI15oRQLVil8mmIED0N6VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯЫШМΚвуАηβйΖΛФ():
    value = 127227
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnnjYFUN84UKbj+U7HHIYAMHyX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЯкМнοζΚηπДνσ():
    value = 34238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fgj2SG4Mrr4AawWqkE+1JXQq6zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        582
        196
        _dead_8974 = 677
    return total

def _МъмфΚσИЮΟвυщΡ():
    if 38 * 20 < 0:
        _dead_2177 = 397
    value = 288266
    if len('') > 0:
        pass
        _dead_8404 = 623
        pass
    text = __import__('base64').b64decode('YXIwVzAwemVLeXBRNzJ2X2dDOV8=').decode('utf-8')
    total = value + len(text)
    if 9 * 10 < 0:
        839
    return total

def _ΚЭσквВαΛтЦЫσуЭλ():
    value = 102268
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxXwfwcsp7BSNTmxmHyAIhUpt2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧЦВΚΝσΑЪЬν():
    value = 552398
    text = __import__('base64').b64decode('ajd2Tm9KbHlFRVFQeHdKbW5EeFg=').decode('utf-8')
    total = value + len(text)
    return total

def _βΩхΝΛГλΙ():
    if len('') > 0:
        145
        _dead_5441 = 222
    value = 460517
    text = __import__('base64').b64decode('aXZ1aDBkWjVmeHVlMndoUENsQkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ИЙγДΔεЭΕ():
    value = 999504
    text = __import__('base64').b64decode('WmJZdUVOQ0N3eEFfVTdoNTRuWFo=').decode('utf-8')
    total = value + len(text)
    return total

def _СХчΝψΤдΖнъΨЕζи():
    value = 672255
    text = __import__('base64').b64decode('TW1SNkVsVm5JZGtFWHl2VHQxTWg=').decode('utf-8')
    total = value + len(text)
    return total

def _РТтялхцХбхгеγ():
    value = 117251
    text = __import__('base64').b64decode('SjU5TkVLQnlGazkxMWh2UFVqVzQ=').decode('utf-8')
    if False and True:
        844
        pass
    total = value + len(text)
    if False and True:
        pass
        713
        _dead_7743 = 447
    return total

def _тнцМяΙЭсςА():
    value = 552483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyXiX3UM5JE2Hwez8GK1MQs4zno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΔРКЭМΡΖΗд():
    value = 422004
    if 42 * 98 < 0:
        pass
        857
        109
    text = __import__('base64').b64decode('QTB4d2xYQ1FicHdtTldtNEFWcVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЖχчЫОГЩИъхЫυъ():
    value = 348581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cia2QwIMp6EnMgmN3lWyEQl50mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        750
    total = value + len(text)
    return total

def _БзθпΔΝοΠρЫΩУнфц():
    if 15 * 61 < 0:
        _dead_3468 = 257
    value = 905217
    if len('') > 0:
        207
    text = __import__('base64').b64decode('VnI4N1pQbld3SXZEbWIwNmU1VDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬцχаоΒхЖΝрΘΦγЛΘП():
    value = 649311
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBnnVEQg7KRbCQ2rn2WKLAN61F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _зκσДΙΖδλΗФωΞ():
    value = 164209
    text = __import__('base64').b64decode('QXhKRExFcGV5dk9KX3VaWjc2aVQ=').decode('utf-8')
    total = value + len(text)
    if 27 * 43 < 0:
        pass
        _dead_5723 = 929
        _dead_3208 = 805
    return total

def _υъмЬχЪΩμдυчΧΗЕ():
    if 30 * 92 < 0:
        pass
        809
        _dead_2256 = 22
    value = 728807
    if False and True:
        178
        511
    text = __import__('base64').b64decode('cUEzdm4zcjRZWjhQUmNiY0xSMGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜβγωδТΧΘ():
    if len('') > 0:
        pass
        pass
    value = 405948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHr9ekY+3Pwbbjem+kOWDQkn73s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2538 = 499
        214
    total = value + len(text)
    return total

def _ЙΙΧΤΜυδЫ():
    value = 569807
    if len('') > 0:
        _dead_7643 = 355
        _dead_6156 = 964
        _dead_9411 = 75
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBnJRgMN94khICu1m1CaFi438Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 62 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_5355 = 22
        pass
    return total

def _ςυχΒМωπκΔΘЯрГωΞш():
    value = 517067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dna1Zls89fEXalei62G+IDwn0WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _азοмеαКеПσυ():
    value = 182332
    text = __import__('base64').b64decode('TWRQcXdQb2loZjU4QTBwR2NJZHo=').decode('utf-8')
    if len('') > 0:
        _dead_3831 = 260
        461
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_2305 = 651
    return total

def _ΦЗЯμЭЬдСиΩΗРю():
    value = 918011
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bj7GQWtt9Lg2CT36+V+/EzYuyl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бзмяΙЖЫНΥΒΘт():
    if False and True:
        pass
        _dead_3811 = 587
    value = 239103
    text = __import__('base64').b64decode('WTZXenVNaWVoOTFINVlCRW9jbDM=').decode('utf-8')
    total = value + len(text)
    return total

def _пТыςΗχЙЪ():
    value = 501781
    text = __import__('base64').b64decode('TTZlemllTXVZQXFjNURlck44MUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΜΔЗуДΘΑ():
    value = 942266
    text = __import__('base64').b64decode('Z3VsakZPU3haOHR6c05GT0NfTnU=').decode('utf-8')
    total = value + len(text)
    return total

def _юРлοдвΖБαб():
    value = 41376
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAzgdFga2voKGD2q726xEDY4zzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _учΠΚζαщСφΧ():
    if False and True:
        pass
        _dead_2553 = 793
    value = 12184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ig30XXMK0pIMMSyq43GjZzQNsGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζΕЬыяВЙсЕкΝшд():
    value = 665336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTX0VHsU0ZcwaF+p7Wm3ZXw78Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮГσтμЬφЩТυΒΞ():
    value = 865332
    text = __import__('base64').b64decode('V0d2bVV0MjVBb2NnaGRrNWJRUXI=').decode('utf-8')
    if False and True:
        _dead_3899 = 382
        pass
    total = value + len(text)
    return total

def _ЛκБРκρЬМΕΕ():
    value = 310426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCjee0k38r48alqOnwG1DhE6vEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8364 = 598
        _dead_5215 = 577
        pass
    total = value + len(text)
    if 35 * 47 < 0:
        _dead_7542 = 478
        217
        _dead_5236 = 75
    return total

def _υДЙЬцДМЫвΠλЪкЕ():
    value = 334049
    if 70 * 98 < 0:
        _dead_6862 = 7
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwjoQEAAr40wIBi67H6IYTQh6js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4692 = 724
        _dead_8295 = 112
    total = value + len(text)
    return total

def _ЩΥФΔΣζΟюОвφЩψФ():
    if False and True:
        _dead_9277 = 776
    value = 918847
    text = __import__('base64').b64decode('dURPYXhPODlIZDlfMWNWUlRqV2o=').decode('utf-8')
    if len('') > 0:
        921
    total = value + len(text)
    if 37 * 76 < 0:
        323
        _dead_7415 = 117
        pass
    return total

def _ТьиКнПыдΧκЕдоκЛр():
    value = 506186
    if False and True:
        752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgTWPwc39owWYjb731eICz0O62I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        659
    return total

def _ΠΞτΤγωβжЩγ():
    if len('') > 0:
        292
        pass
        _dead_8063 = 44
    value = 223611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh/0fQQy9fgKFhmi4VOWLi0I3WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        630
        _dead_6400 = 411
        720
    return total

def _УτЙЧΘжхдллОКΥйιτ():
    value = 272405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCjeZEcP+PsWAyuqykXBIxx+xkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 83 * 85 < 0:
        pass
    return total

def _ЬΣΡΠЭЭатλησΤБ():
    if False and True:
        _dead_2656 = 263
    value = 550220
    if False and True:
        pass
        732
        452
    text = __import__('base64').b64decode('SjNXazJjeUVFdlN2bWg2ZDlWUDA=').decode('utf-8')
    if 19 * 11 < 0:
        _dead_8980 = 716
    total = value + len(text)
    return total

def _кбЩТКгδλПΣЮΜ():
    if False and True:
        _dead_9475 = 817
        _dead_8477 = 4
    value = 454422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESvzfX4S9JgUHwW24WWoZSd96Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЦΓчвзеЕΛуяΙОж():
    value = 20532
    text = __import__('base64').b64decode('bjBXZHZXbDlOZlhzNnhtNDBaVk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ВирМΔдФЖΞц():
    value = 391591
    text = __import__('base64').b64decode('ZTExd0xfRGhKYUtMZVpUNzlnUHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ъλЙеУъйΙαΝΚβТεΙ():
    value = 563784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjreeHQMz/lXIw2c7GzBJho+9Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оοхЩΒсοΞΟТУЮΒБЖψ():
    if False and True:
        373
        434
        pass
    value = 492120
    text = __import__('base64').b64decode('Y0FnMTlDWTZSRVd6TllYUVpDM0E=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3278 = 514
    return total

def _ВνзκаЦБΣΟБЛ():
    value = 996892
    text = __import__('base64').b64decode('cGR4TFBlT25QX2dPTTl3dkZjUkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΕγкърγп():
    value = 533415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NS3bTVQB8LIhIiKlyWG/ExMt1z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5832 = 650
        _dead_8173 = 560
    return total

def _ЬДеΛτσнΔОЧΘοχкλН():
    value = 831961
    if len('') > 0:
        385
        929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExjDSQcb344aCQWG0HfEMAY1/Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 5 * 45 < 0:
        _dead_9574 = 267
    return total

def _ΥуШΞρРΥρДЛуΚΚχШ():
    value = 950684
    if 4 * 8 < 0:
        724
        _dead_9936 = 37
        632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgPVal0WyL4CaxmG+m+ePwo5410='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _доτяμевЩДОПЛоυχ():
    if 33 * 25 < 0:
        pass
        pass
    value = 628610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwjJPWc856cgNRWOkXKTOXQ2wUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩШюφНΣΘзъρνйкнхο():
    value = 436475
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjvGXWQPqqMpHVnx4lWhLhME6zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΦсτЫШκпΝМΖБКА():
    value = 96466
    text = __import__('base64').b64decode('Q2YwelRjRFVVc0pYWWJGaFo3emc=').decode('utf-8')
    total = value + len(text)
    return total

def _ыπχΖцΡОφЪδбЦМΔλ():
    value = 996153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj33aHMg85o6ahmp+U6jAhEktV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уΓΕΚχждбМΞΦ():
    value = 188464
    text = __import__('base64').b64decode('Um5Qc2RZdk0ybWZlYmR1dnJzZHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯιытЗЕΔДШΥ():
    value = 576200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3b8UQYdxIExaS6pw27APTQh0H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цхΝОнбωЯκωΙЯСоαΡ():
    value = 972228
    text = __import__('base64').b64decode('b3lDRldEXzJhZ3pOSVdndmZHNjc=').decode('utf-8')
    total = value + len(text)
    return total

def _юВрψЕпЯΚАΡЮСхμ():
    value = 506447
    text = __import__('base64').b64decode('aW9RczMwT0RkT3JjNk9WZDFDUkI=').decode('utf-8')
    total = value + len(text)
    return total

def _αБαеЭЗΛρтζΥγ():
    if 91 * 69 < 0:
        pass
        445
        _dead_9880 = 244
    value = 98512
    if len('') > 0:
        pass
        _dead_2137 = 987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwrMPWMW1Y0mbACc8H+6bDMNx0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 76 < 0:
        _dead_4339 = 394
    total = value + len(text)
    return total

def _ЯчМаЦιЭλоЧщПЗ():
    value = 704889
    if 39 * 65 < 0:
        994
        _dead_9122 = 198
        pass
    text = __import__('base64').b64decode('WENtOV9QWXduM3lraDZfdWc3aEo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5202 = 627
        403
        pass
    return total

def _гоΡрλМНοκИγωΚиΑа():
    value = 269046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAPVR2Eu+JcJbgii4H6lOHU17mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 8 < 0:
        851
    total = value + len(text)
    return total

def _υυαΔΙйЩОттЭΗп():
    value = 132816
    text = __import__('base64').b64decode('Z2xXWndPODVSeUFNSUk5OE5xNms=').decode('utf-8')
    total = value + len(text)
    return total

def _йΠθεηΟмЮΒФРςгχ():
    if 80 * 80 < 0:
        _dead_5875 = 697
    value = 76457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQrbeEcy9JIPFR2xwlm+PSYN6kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _βΒΧГΖδэГКдОВ():
    value = 519005
    text = __import__('base64').b64decode('Z3BMMWtseWh5d2RESzFOUFppZWE=').decode('utf-8')
    total = value + len(text)
    return total

def _εσрФЕШηф():
    value = 303852
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgvVfWI8pr8BNAamzly0Ohci9ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωгпμЛПорλψ():
    value = 93435
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSLsXVg/xJ9QaQSLmVufJRM5ykg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕοшЩφπβεΟοΩΠ():
    value = 649130
    if len('') > 0:
        957
        _dead_5476 = 302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwPxRmc6/KcsPF2s4VmyZBINzzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 38 * 16 < 0:
        969
    total = value + len(text)
    return total

def _ηшΝоΥωσΙВщРαВЦ():
    if 71 * 22 < 0:
        _dead_5790 = 822
        pass
    value = 773948
    text = __import__('base64').b64decode('UVQ2U1V1dzE5RFU4bFZkYVdVRGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΧНдсПΛΧвЧьХЗ():
    value = 983629
    text = __import__('base64').b64decode('cnVNNGZ6NU95WHlDcWlSMFZLMHk=').decode('utf-8')
    total = value + len(text)
    return total

def _агΠρξЮξЫПИ():
    value = 91045
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQvRN2AX36wSGDe07Fi7I3F2zmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2967 = 116
        pass
        _dead_1620 = 604
    return total

def _ΕπщъЩвуЦЬэОЭζ():
    value = 316776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH7PUXYMpqAEHw6byluebQ8B6UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шфτОμдδιΒиΞщюка():
    value = 405985
    text = __import__('base64').b64decode('SkdJemNzb18yckNKckRRVFRNM04=').decode('utf-8')
    total = value + len(text)
    return total

def _φΤкгηΥщωεАпλм():
    value = 408602
    text = __import__('base64').b64decode('RXV5Z1lVTUVlMzZOOGJReklvN04=').decode('utf-8')
    total = value + len(text)
    return total

def _τМξлυцуθ():
    value = 238644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwnRSF4OybgaMQCw0nGpZyA/wks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιζΗХσъΔΑнФКжΜЩ():
    value = 114137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDr0RQksz64LAC6qy264Iy0j3kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        850
    total = value + len(text)
    if len('') > 0:
        _dead_8061 = 514
        _dead_3133 = 122
    return total

def _ыФЪЙΨιжеωε():
    if False and True:
        pass
        _dead_1052 = 689
    value = 956786
    text = __import__('base64').b64decode('SVFLX2FaVHl3RXVQeHhsaTBIS1o=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4515 = 62
        _dead_2925 = 553
    return total

def _тσыхИΟΚΤφмφХЧΨ():
    value = 670736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBvOWUQsxr8IKgSQzWGFbHB50kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тξЕЪзБχΤЯЪζЛΥс():
    value = 221681
    text = __import__('base64').b64decode('YnE0VjJrTkpsT2tlRHZFWHJlSlU=').decode('utf-8')
    total = value + len(text)
    return total

def _яяωдЫдψΩсψчУα():
    if 99 * 47 < 0:
        _dead_3125 = 759
    value = 143782
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnzASms1rqE3CVuykVDBFx8ivEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        191
    total = value + len(text)
    return total

def _всбΣоэΦΓ():
    if 18 * 39 < 0:
        812
        379
    value = 722596
    text = __import__('base64').b64decode('Y0RLSUVySUVZeGZRWHhQMWlXbHc=').decode('utf-8')
    if 22 * 85 < 0:
        pass
        pass
        54
    total = value + len(text)
    return total

def _ПΒΕВхмεДбΕοа():
    value = 207964
    text = __import__('base64').b64decode('Q2FrcUo1UHlZVDJkZzFtd3RqTXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦЮτдвмΠΠ():
    value = 322403
    if len('') > 0:
        pass
        381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PX+9TUlq14wBDxi02QeiZz0m3GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_4515 = 428
    return total

def _ξΗΓтйКяЭΡΔЕςеΓΟП():
    value = 407641
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw3Ta3Zh1a0WAgGLzEWJBwYFw2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        553
        pass
    total = value + len(text)
    if 41 * 90 < 0:
        pass
    return total

def _ДαΓюφМΠοцЫ():
    value = 118836
    if 87 * 63 < 0:
        _dead_8306 = 332
        pass
        _dead_1221 = 353
    text = __import__('base64').b64decode('WlM3eDAyWXRWTVZhcTRJSGFNV0I=').decode('utf-8')
    total = value + len(text)
    return total

def _РΦΖιδнΙκъкρЙ():
    value = 36651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3zVX34g87IrNyutkASjZw49ymg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гСзΩχΜщμжΖ():
    value = 225719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxXhQHwu7Y85DD+g7VSqDA4j/l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤκμΖβяэБЫ():
    if 23 * 85 < 0:
        pass
    value = 264304
    if len('') > 0:
        _dead_5372 = 217
        11
        430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LizQPkcXxPk0aTj04kGFGwYo1Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        315
    return total

def _ΙЩлδζсΛδΚΔКХκе():
    if len('') > 0:
        967
        884
        _dead_5088 = 654
    value = 959255
    if 31 * 64 < 0:
        960
        _dead_3911 = 737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj/mYwdu3YcTLiyJ6keULiJ950Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        32
    return total

def _ΦξБφсЙβεягУ():
    value = 17687
    text = __import__('base64').b64decode('Ylh4OVM4Y0JRMUlCa2JfSFFaQWI=').decode('utf-8')
    total = value + len(text)
    return total

def _жЫγЩУΩфвЛаκΛ():
    value = 179523
    if 7 * 95 < 0:
        307
        66
    text = __import__('base64').b64decode('WG1yQ1g3TTBkRnI2eHBjWlpWWEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ωыςΤцБЩЫηεаγΖΝ():
    value = 593471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCvsdABszqkLFFa7nwHAFjcJ0E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фмДΓФмЙН():
    value = 475055
    if len('') > 0:
        368
    text = __import__('base64').b64decode('blh2a0lRNk1pX0xremZlTjZLS3M=').decode('utf-8')
    if False and True:
        pass
        347
    total = value + len(text)
    return total

def _ψЫыЪкГеФ():
    value = 473351
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzjvOlw49p4sPweqm3+nIQ4Z8Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γμшΛиφЪΡπο():
    value = 822151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjnOPmEB9oYGLx+y0kyZMjQp5Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κэΧΧСЙρЦдυλ():
    value = 222131
    text = __import__('base64').b64decode('dmJiS0RobWozdnN0OGNqN1ZLa0U=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ΥлσзΟΕΑιΧυΕζυαΖЭ():
    value = 149036
    text = __import__('base64').b64decode('V21EUjdYN216M0g4UzE1TjJhUDE=').decode('utf-8')
    if 99 * 9 < 0:
        pass
        366
        951
    total = value + len(text)
    return total

def _юωΥумΚЖхНОПБαδ():
    value = 14431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyTcYkQzzKNabgKP/kyFAAsBzXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΥΣФЯυтЦζΓкжф():
    value = 719111
    if len('') > 0:
        pass
        755
        _dead_4754 = 266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwXcfGdg+rEzDiCn5mOhZgAi7mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΧβτωнΒωиПвΨΛШξ():
    if len('') > 0:
        57
        638
        pass
    value = 912390
    if len('') > 0:
        529
        pass
        _dead_8294 = 433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCzvUUQG3bAPPQiP/HeEJCw3xV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        364
    total = value + len(text)
    return total

def _дццηоэΩΒШμзбΣΘΜ():
    value = 461341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCDcQXw42vsLFQnywwHDGQkN02g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еДΣБςΕЧБКФЭСДлйК():
    value = 697461
    text = __import__('base64').b64decode('aGlaQnpLWmJObk5HTVJRUFRITnk=').decode('utf-8')
    total = value + len(text)
    return total

def _хХΠхХЦвЬι():
    value = 219278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzjBZVAe3P0KAz+H/XCUIgMf7kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        155
    total = value + len(text)
    if len('') > 0:
        _dead_9680 = 933
    return total

def _СПЭΡМνΧтΣЕЭΠη():
    value = 256436
    text = __import__('base64').b64decode('RERhV1FLQkhzeDdMeHFrWUc3UVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ФЦЫМπужν():
    value = 960059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiLvZ380/ZAxBTikxHKlDQt2zH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        369
    total = value + len(text)
    return total

def _ζιωαГΟэйэ():
    value = 819389
    text = __import__('base64').b64decode('dDFfM1hOSDdGZGJtdF9COUtyX0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΛςЖХΩΦυ():
    value = 202454
    if False and True:
        785
        pass
        _dead_4347 = 815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ3mWAgWp/4PLlagwH6bISMMsnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 25 < 0:
        pass
    total = value + len(text)
    return total

def _ΑЭθΨΛπεиβξаοЮΠ():
    if 78 * 66 < 0:
        _dead_9696 = 304
        pass
    value = 115522
    text = __import__('base64').b64decode('TTFNcmc1YjFrT2g1WFBlWVFvYjA=').decode('utf-8')
    total = value + len(text)
    if 14 * 77 < 0:
        pass
        _dead_7100 = 78
    return total

def _ьТΥфΞЫДфςΒйΞхо():
    value = 274704
    if 90 * 45 < 0:
        pass
        _dead_5485 = 779
        167
    text = __import__('base64').b64decode('T3hpNW1QX2Q0Y3MzNTZuRlVTR2w=').decode('utf-8')
    total = value + len(text)
    if 45 * 19 < 0:
        679
        490
    return total

def _ыθхБюΘχщгЯЯ():
    value = 685593
    if 7 * 19 < 0:
        50
        _dead_3008 = 594
        _dead_5981 = 533
    text = __import__('base64').b64decode('WEg3cmgwZEczZkdqcl9uYllwZnk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        729
    return total

def _ΡЪΒЕьЕΤεНПφζγя():
    value = 560201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Chy9O2A76JJQaiuV23O8PnB452g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оЛчХζΑρлВν():
    if False and True:
        248
        733
    value = 43844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fn7uNkEo+/oKHALxw3mnBgImvFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΛΔθязБψΑ():
    value = 612556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwfvW1Io75IONAionVCpMiY3sj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓζΧζΣΞτЪ():
    value = 856102
    text = __import__('base64').b64decode('ZkE3TWhSYVlmR2NiMU5pMWVMTWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΚКшΦυΚтΞΘхςцτЩЖ():
    value = 955882
    text = __import__('base64').b64decode('VThBSWNydnQxT3JrYXJVem5TZks=').decode('utf-8')
    total = value + len(text)
    return total

def _НРтνУμЮΟРша():
    value = 673861
    text = __import__('base64').b64decode('YlRiUmpUQ3pfN3lqdFBQNm5Zb08=').decode('utf-8')
    total = value + len(text)
    if 1 * 75 < 0:
        _dead_7410 = 510
        pass
    return total

def _ЬβΩΣвδЧейЫтОЪЧη():
    value = 487569
    text = __import__('base64').b64decode('aUdLU29SWW9pTUlSeTN6SUNwMVA=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _жСГΘеπΩчЙГΦιΤкΒэ():
    value = 794961
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KS3tbUE60ocXNDCp7QO1PCEFtl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йьΒБФΨСе():
    if False and True:
        pass
        _dead_9351 = 884
        pass
    value = 299658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHjoewggyIlVbgGm8EzIZjUh0kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цаΦΘлэΓАяуГя():
    value = 656108
    if 31 * 90 < 0:
        _dead_3763 = 860
    text = __import__('base64').b64decode('Q0VlSjBYZWZCVUpMR2RfcmNja2s=').decode('utf-8')
    if 56 * 69 < 0:
        576
        pass
        461
    total = value + len(text)
    return total

def _εэΣξхоΓмХЗτβхЮνю():
    value = 847506
    if 18 * 51 < 0:
        _dead_5649 = 794
        pass
        _dead_2639 = 526
    text = __import__('base64').b64decode('empkWEYwNmVfVWpzd2t6WlhUTWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΜξπЗСνТ():
    value = 450903
    text = __import__('base64').b64decode('d3NEVU5fSjQ3NnF1aUZWTUV5S2c=').decode('utf-8')
    total = value + len(text)
    return total

def _σΣтΞζΞЯθи():
    value = 428149
    text = __import__('base64').b64decode('WndxVmdidzI5bWVLWDBUVXJxdnc=').decode('utf-8')
    total = value + len(text)
    if 6 * 69 < 0:
        pass
    return total

def _тσыИГТВΔ():
    value = 324840
    text = __import__('base64').b64decode('UGw1Z3JGaGlGaUdlcXpldjZpR2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('cg==').decode('utf-8'))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()