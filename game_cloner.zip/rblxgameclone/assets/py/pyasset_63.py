#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ЦΙгрγΕдШ():
    if len('') > 0:
        350
    value = 676991
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('dHF3Uko2V1pKMGIyTWlmSE9Iemw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8166 = 739
        _dead_4346 = 226
    return total

def _кφтΒсΕМαяοСхьтЛΜ():
    if len('') > 0:
        _dead_9513 = 560
    value = 261104
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn7nencr1aEhFASky1KVOgwBtGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьЙяεуΣяΧ():
    value = 906183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBfvXlYo17xSIDqB41iYHih9/UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧοиЪφдялΙЫθЕкΑδ():
    if 14 * 59 < 0:
        pass
        _dead_9399 = 21
    value = 346779
    text = __import__('base64').b64decode('UWZ3QTZUcVNoR3NQeHpOM2hxX3Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5056 = 109
    return total

def _ΩЙΝЖчτΨΦбХеΑо():
    value = 480616
    text = __import__('base64').b64decode('R3ZGajFNRGswdTRhcHk0NzV4RDQ=').decode('utf-8')
    total = value + len(text)
    if 98 * 35 < 0:
        _dead_8625 = 474
        157
    return total

def _ρзβОπйιοΧα():
    value = 442932
    text = __import__('base64').b64decode('dUZya0J3Zzd5SFBuOThqOXFOb2E=').decode('utf-8')
    total = value + len(text)
    return total

def _шφяврнНСУδΩшνΨ():
    value = 967711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwzPT0UK3/oIHAGOwQe0O30Z3kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΓЮΤψςκξΠвΤаП():
    value = 923440
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQLGXGA4qKotOzauyXWJbCgj7zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЩтшРРаΨъЙхЕМΤσΓ():
    value = 106720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ajv8ZwkJ648WYyuR6XW/EikGvDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΗЧжвΛπΖлΒИ():
    value = 218352
    text = __import__('base64').b64decode('aFN2ajd6cElKWWtqYXpRaUtENDI=').decode('utf-8')
    total = value + len(text)
    return total

def _юΒΠСΠχьЗЧЭ():
    value = 349713
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzfPb2Qa1qwHKirywkyVOQgdvXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 18 * 61 < 0:
        _dead_7431 = 223
    return total

def _шУхΑфдлυуμλЗЖρ():
    value = 522454
    text = __import__('base64').b64decode('TEhORUIydDdYNDU3RFkwT0VmTHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗИФΘЮиΨοηмкυТЙΔ():
    value = 148258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESXmPkIt2KJUajWF7UGxGwQE0DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хяЦЭΝξОУΦМΗрПωоΒ():
    value = 875148
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhzCQl4Q8P4QPwuv/QG+OHA68WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эιΩТсΚяΞΧεΥ():
    value = 766898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTfXeQIc1f8FPF2nm0O9IDJ+/UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΑВΣхλШоΘсЫо():
    value = 443915
    text = __import__('base64').b64decode('QVJxSV9TR1BobHpoRXIyYXUyRGc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5193 = 840
        pass
    return total

def _ЬνραбΕЖδΦшдзξЗΦ():
    value = 688268
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQftUQgSrIcUKwn73l28ZSkaymE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨδΑГЙΛНцΑΚιЩ():
    value = 933009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBXHUX9g1oopPwOL/VvEEAwD6FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХЖΛργЩЪЩг():
    value = 198864
    text = __import__('base64').b64decode('eXVfbjBQTzhEMlNWZVlIbWZJZjY=').decode('utf-8')
    total = value + len(text)
    return total

def _хгЕЖνтРЗЖξΔйюςСμ():
    value = 358578
    text = __import__('base64').b64decode('QXhKRzRTSFFRM2VWY0hVeUFrcE0=').decode('utf-8')
    total = value + len(text)
    return total

def _вбμΣνъΕоръ():
    value = 408317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FirmPXcc+r8VKCf68gCDAjcXtFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        703
        pass
    total = value + len(text)
    return total

def _ЮхтαΥтсΛ():
    value = 15208
    if 23 * 70 < 0:
        pass
        303
    text = __import__('base64').b64decode('eVY3dFFnVXhCQzFBYkdQS1V1Qzk=').decode('utf-8')
    total = value + len(text)
    return total

def _δΛψΩЙοьСτпΟ():
    value = 262025
    text = __import__('base64').b64decode('Y3BzMmRkemozR1o4ZENwZW5BaXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦжДβРШΑΘэЦмЛΩλо():
    if len('') > 0:
        _dead_3077 = 104
    value = 309982
    text = __import__('base64').b64decode('Z2RGSl8ycDhQNUsxMVZlSGJyN18=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΡкдИеАΔв():
    value = 878517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSWzN2hh7a5TMCm191enBQB59V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΛЧΥΚяΩθш():
    value = 392280
    text = __import__('base64').b64decode('ZGVJOVpCNmJUa0xOWF9XTzBsbDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΛОζΑЛфЪЦξЕыеΗ():
    value = 708026
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAvLeH5tyJIUHQWXmgG0YjAqzXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъоРэЫΕχλМдАЫЩД():
    if 23 * 5 < 0:
        _dead_5903 = 823
        386
    value = 138651
    if 52 * 94 < 0:
        _dead_7435 = 924
        740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cxjef1YNxI8WMQ6XmHyoZXUDxTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ΜβКφфнΕβεΦΡвмО():
    value = 305184
    if 2 * 19 < 0:
        _dead_5296 = 174
        28
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBnFPHswr/0oLgi5kWzIMgx2wVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 62 * 90 < 0:
        _dead_9502 = 822
        718
        _dead_7545 = 167
    return total

def _ЖэЖΧтοэЯэЭΚЦ():
    value = 57185
    text = __import__('base64').b64decode('czMxWDRmWUFQWW5YandMWG4ycGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ШАъТςΤРПλ():
    value = 594744
    text = __import__('base64').b64decode('b2czeUZ4VnZVQ0hiSXpvWTRYMVI=').decode('utf-8')
    total = value + len(text)
    if 24 * 53 < 0:
        _dead_3602 = 910
        499
        529
    return total

def _МΩЬЛнχχυфΜκЖЕ():
    value = 524285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3m9OwkcrPEPNlmJ4nK/ZDYit1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БчРδлΣΓЕЖΦЮЭΡυЗЙ():
    value = 820853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwndbVc+5okuFRib5kexMil5wmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖтыЙШΞαεΜОнδщю():
    value = 566077
    text = __import__('base64').b64decode('Y2lEY19TQWdoMVNXek9fWWoxTDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨρΙКЗдΚСАцуφТΟ():
    value = 166287
    if len('') > 0:
        _dead_6088 = 280
        pass
    text = __import__('base64').b64decode('R3UxWGhhUWNpSDQ5TFpYdXA4bFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠμβηтБΞηΕψφыςзхΩ():
    value = 473603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCHLbV461a9TFwS77nOHOw0m/Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        243
        _dead_3234 = 783
        807
    total = value + len(text)
    return total

def _ЖзЧДкКЭыэЪς():
    if len('') > 0:
        211
    value = 350666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRDIX0Yj9f0CEFj6mFebBw4W52Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        825
        _dead_6165 = 764
    return total

def _ЪΩпЫЙχДцΥбεгъЮηц():
    value = 911920
    if False and True:
        756
    text = __import__('base64').b64decode('UHhQcUVtMVBGNlA4SUsyV3dWUDM=').decode('utf-8')
    total = value + len(text)
    return total

def _бΘПЛδОЧДэИ():
    value = 44695
    text = __import__('base64').b64decode('QmhEN1hHYzBXMDAyM05CMklCWlY=').decode('utf-8')
    total = value + len(text)
    return total

def _χΞСΟхδТΙьΡδ():
    value = 312914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iiu8WHgI1fsoKhmwmWyXGik77UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΛΙГΩЭξΖ():
    value = 21707
    text = __import__('base64').b64decode('a3dBVlFCbDRfT1RnVVpUSmtzRVM=').decode('utf-8')
    total = value + len(text)
    return total

def _июνуφощдΚлУΦдшΝ():
    if False and True:
        _dead_8652 = 260
        pass
    value = 515769
    text = __import__('base64').b64decode('UUZ3ZmpDMml4S0Y5NGkwMGxZeWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ρлхΙΕдщЗЦь():
    value = 815193
    if 1 * 27 < 0:
        509
    text = __import__('base64').b64decode('cXlsRXRNYXJ6WEExNzczVEFKUW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ТρΧгΧσыΝим():
    value = 233327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQe2RAE89/EGHD26xXSGOSg3zHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        680
    total = value + len(text)
    return total

def _ΛмщυвыБСΨЪ():
    value = 522893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dhv3bEU1ro0LMheP2Gm1Oi180Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΨΩшτξадЗОθГ():
    value = 69144
    text = __import__('base64').b64decode('S1YyOF9TaGRaRGFSTHhNZ0U3dGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓτΕςδΓλλюΝΖЦ():
    value = 887367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHzla3kd2KcXGxeP3AapBSEgtkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νцψиЭςΕρΗθЙ():
    value = 100904
    if False and True:
        694
        _dead_8611 = 325
        _dead_6544 = 646
    text = __import__('base64').b64decode('c2I3SmtWWFc1RV9uYXhrTlE2b0c=').decode('utf-8')
    total = value + len(text)
    if False and True:
        910
        _dead_1537 = 44
    return total

def _ъвΓгГΩЭдκТΟДΕΝ():
    if len('') > 0:
        _dead_9164 = 916
        _dead_1762 = 687
    value = 391682
    text = __import__('base64').b64decode('eEdGa0Fhc2xUODNjdnRHaEdZQnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _πΑяИЙВУбуУЬΗ():
    if 30 * 16 < 0:
        231
    value = 949203
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAz8T34bzIJVEiqvkEGINTMVwT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 53 * 26 < 0:
        _dead_1613 = 992
    total = value + len(text)
    return total

def _ΥБΜχΩеφаμзАς():
    value = 503043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSLbYX8QrJ9XEQi1+XTHIhQr1z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΚфψЗΛрΠςЫ():
    value = 773484
    text = __import__('base64').b64decode('UVRBWXlndWw0QXppUXlUamU5dnA=').decode('utf-8')
    total = value + len(text)
    return total

def _δЬжеΗцуΜλΑЗ():
    value = 131239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQmxPUgLrZsyPVeu3w6fIgQOzns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 47 * 22 < 0:
        pass
    total = value + len(text)
    if False and True:
        78
    return total

def _иΗυνποΓЭя():
    value = 887985
    text = __import__('base64').b64decode('TGpfbUNFUF9OVlF3YzdXc25qdTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΜφСбνΙХρκοСКлкИ():
    value = 578325
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fhe2dl872YEPICai2kXFFw8a/Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡВψЕτπхЙАи():
    value = 919008
    text = __import__('base64').b64decode('d2JfQjhVcGJCVTJ0eTlLWkJRZzM=').decode('utf-8')
    total = value + len(text)
    return total

def _МУдωΟЪΜΩπЬ():
    value = 723776
    text = __import__('base64').b64decode('Y3VFNll6QUFXWXBETERzSkE2dG0=').decode('utf-8')
    total = value + len(text)
    return total

def _яπрεαγΡεКЙ():
    value = 965596
    text = __import__('base64').b64decode('bFQ5dkRRNVlsT200RHI1SWRtZUU=').decode('utf-8')
    total = value + len(text)
    return total

def _λАηςЪΙΖαТжОω():
    if len('') > 0:
        567
    value = 699604
    text = __import__('base64').b64decode('S0gySU83dTBwOG1NYWpuOU1iOEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ВоνегΒζωцΦφфσкС():
    value = 885047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAvIWkQD/Ik5DhrxmgK7JB12zWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТφаΗггЭюΜЧαΠьСг():
    value = 627214
    if 77 * 65 < 0:
        pass
        pass
    text = __import__('base64').b64decode('SkJxVVluNU5vdjV6T05nY0dCaVU=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ДцΝгςадшк():
    value = 126179
    text = __import__('base64').b64decode('VHk0TWhqdWVPcE0zTzhZblZ5SDE=').decode('utf-8')
    total = value + len(text)
    if 58 * 47 < 0:
        pass
        _dead_9057 = 940
    return total

def _αчКΒтяΟцшΨЖαΑθ():
    value = 142905
    text = __import__('base64').b64decode('bWFGUGpkeXdpZVZWMGttZEduZ2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛηцξαψνЪκТЬъ():
    value = 218646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASvRZEkR+4AmEgqb8mWobA4ksUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОηΒЬоητайшω():
    value = 719793
    text = __import__('base64').b64decode('R3E2N2JYcE9XN0ozSTlNUWJlS18=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_7007 = 442
    return total

def _РЪζкПофλ():
    value = 426233
    text = __import__('base64').b64decode('SEtvN0VCYk1ZRUplcE1YSWdCNG8=').decode('utf-8')
    total = value + len(text)
    return total

def _шΘМйΝΙΞО():
    value = 865155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CinIZH4wz7FQHySRzEKTHQ0Q8U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪδзХйЫεζПδл():
    value = 179526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBDWVFNu5q1SCy3y8mCiGwJ70kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        390
        818
        pass
    total = value + len(text)
    return total

def _ΛвзΒψΥχЫК():
    value = 505717
    text = __import__('base64').b64decode('azE0RmpXUWg4Z3FTSTBQbXVKNHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ρСβцτТЦлЖХΥΘγПΥι():
    value = 72535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCTUTUFq+pEANj+L8QW+FRIDvXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВРяκжφΓοз():
    value = 26149
    text = __import__('base64').b64decode('WjBYckFuallaZ3NveHhwVkRrdjM=').decode('utf-8')
    if len('') > 0:
        28
        pass
        pass
    total = value + len(text)
    if 49 * 14 < 0:
        pass
        137
    return total

def _нκИΒАΥΔытεлХγ():
    value = 919757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iwjde2tg0qYMayen6QSdYQp9/T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хАλПεκσΝΨζнθΛИ():
    value = 747581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwThUUgS3/AVKSOS92GpDRUYvEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝдцХЪТеЧμΦφ():
    if len('') > 0:
        557
        527
    value = 158123
    if False and True:
        354
    text = __import__('base64').b64decode('VWdsWmIyS2llUm53ZW5WVzJsYjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡПбΣкΜΤЮΣ():
    value = 654300
    text = __import__('base64').b64decode('Z1VMNWVlMXBPaHNLc3dCSktWUGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ωωψχτηЩγεтζПАΝ():
    value = 288906
    if False and True:
        pass
        pass
        242
    text = __import__('base64').b64decode('aldxM2NkcEZhWW5NZkh5X3FFa2o=').decode('utf-8')
    total = value + len(text)
    if 66 * 11 < 0:
        pass
    return total

def _ΘαэьτдЪτтα():
    value = 199822
    text = __import__('base64').b64decode('ZnVRSTVMNjZpdUZ4S0lCQVdQY3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕЪΖйАΨΓδ():
    value = 81837
    text = __import__('base64').b64decode('d0VrWGFBWkJld3dqdzYxdTFWdFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ρйЦρЕΜцΛ():
    if 65 * 99 < 0:
        _dead_9118 = 88
    value = 829202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxfVPWMzqr4LYh6A71mfYXJ9sDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5806 = 272
    return total

def _ΟтьθЦьошо():
    if 1 * 61 < 0:
        pass
    value = 71077
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS6zZ2I8p68VaBv77Vq1Dh9+8jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠНΗНΖХцАЧεцпйψ():
    value = 326848
    if False and True:
        483
        _dead_3594 = 505
        _dead_5827 = 355
    text = __import__('base64').b64decode('Z3E2OGZHSmpnMmpObHVkdDVoNnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗчрγПЫΑЦыς():
    value = 54289
    text = __import__('base64').b64decode('WkRCWFA4MExRNE5xbTQ4WHB0eDY=').decode('utf-8')
    if 61 * 57 < 0:
        _dead_4686 = 304
    total = value + len(text)
    return total

def _УαХъΟζыцгΖццГΗте():
    if len('') > 0:
        _dead_8530 = 145
        376
    value = 550664
    if 36 * 84 < 0:
        _dead_5830 = 562
        pass
        _dead_9306 = 386
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjbmOWcj/K8yAgiJ+V69H3Is8kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫФΛЧνπΩШ():
    value = 568585
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In3sO0kS9rBaCzuC51CSYAkV1ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МцЙлОευамΤиηΙεΤ():
    value = 53966
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHvyRV0O6608KDal/ny8EBp83k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞцλωюхΨγишΚз():
    value = 802783
    if 83 * 27 < 0:
        pass
        521
        _dead_3006 = 784
    text = __import__('base64').b64decode('Yk45SzZvTXF6N25jalFPVnNOdEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΩЯБЭвτВΟбтΡξ():
    value = 238507
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDXDSWYW8YEpLwq3/kOXYBYj3lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5920 = 889
        177
        729
    return total

def _жΝгΓмзУΕДЮΦР():
    value = 628894
    text = __import__('base64').b64decode('cFBPQ1pDUVRfdWNwZzIwSUlvQ04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜεΜυьэσЮЪНΖ():
    if 86 * 55 < 0:
        pass
    value = 968210
    if False and True:
        449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXndRV0h260wOwOGynSEbTcLzUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        384
        _dead_2080 = 660
        676
    return total

def _еτСθφΞТΚΥЪζФШ():
    value = 393163
    text = __import__('base64').b64decode('cFBJZnlUZGpEdldiTlVseW9qSXY=').decode('utf-8')
    if False and True:
        _dead_2166 = 421
        pass
    total = value + len(text)
    return total

def _БщМуНεΞгςγКЯνЗФ():
    value = 615366
    text = __import__('base64').b64decode('TzJaMDdyZHE5SmlNMlQzOWw1MHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΛΕРαиυС():
    value = 621259
    if 81 * 51 < 0:
        _dead_7811 = 550
        pass
        _dead_1829 = 149
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IivBXFwzqqA6Myegw0y6Myx/vVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥъзЯРШκЭΦаФ():
    value = 727309
    if False and True:
        _dead_1328 = 548
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTzhQXsMxr9aADWqzGe2MQQY4Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 63 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _νψωЙНΖЯЯиΓαд():
    value = 411132
    text = __import__('base64').b64decode('RDVyamt5T0h5NmFVeUVKU3IxaFo=').decode('utf-8')
    total = value + len(text)
    return total

def _жОΤτфПжΘУυ():
    if False and True:
        _dead_8152 = 697
        _dead_1769 = 215
        _dead_7053 = 874
    value = 453105
    if 70 * 95 < 0:
        137
    text = __import__('base64').b64decode('czBMTWlwcjM0YUJRNlAwV2Nva0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔθшοεТΡΠБ():
    value = 743605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQS1Rnww8qZRLVj20AOcIgA65mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 12 * 42 < 0:
        pass
    return total

def _ΥΔФΕъдЫιΚЪ():
    if 71 * 63 < 0:
        _dead_7894 = 544
        506
        _dead_8176 = 519
    value = 585597
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAy9WUgMq446FCX2xk6DOAI2sD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6622 = 976
        352
    total = value + len(text)
    return total

def _νЪйλΓΗΗς():
    if False and True:
        _dead_4086 = 416
        _dead_9335 = 109
        _dead_7291 = 31
    value = 851426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAX2VnIGwaM8EB2kz3S+LS0Ay2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        310
        pass
    return total

def _ыΩЫрΦщгъσШЮ():
    value = 189659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx+2OkAu8LEaLVyA53KJZCY43Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 60 * 37 < 0:
        _dead_9806 = 587
        pass
        pass
    return total

def _хПДфОςоρФШΤхфФщ():
    value = 701364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lhz3RVNu9fs6AiCWx2e8HRwrx3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПδρρхΤΨШВЦ():
    value = 220997
    text = __import__('base64').b64decode('ekdYMTY1eWZMUWRSQk9DSUFKMU0=').decode('utf-8')
    total = value + len(text)
    return total

def _МιΩаψяюбςЪЛςαп():
    value = 245792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCr8S3ofzKUhMBiI432APAgc6Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _якυнνψμЙ():
    if 41 * 92 < 0:
        _dead_6452 = 429
        908
        _dead_2996 = 747
    value = 618356
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA3sS38c7ZgmFRuJ8ni5YDQp6l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΛφΝЬюЭΕΑχГо():
    value = 629451
    text = __import__('base64').b64decode('eDJwaVdISlFaQ0V3a0VnRHNueWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ζψαгЯЮΨсξВфкτγ():
    value = 201592
    text = __import__('base64').b64decode('TTJmZVZCNl90YkhqVGlFY3pPWlA=').decode('utf-8')
    total = value + len(text)
    return total

def _чтшΟнςκχ():
    value = 269970
    text = __import__('base64').b64decode('Tm91ZDdzZW9kdDRxcG40ZHVwajY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΑσνЦНДηε():
    if False and True:
        _dead_3308 = 229
        pass
    value = 617310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiPVZXocqolaIj+txES5Gisb1lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        339
    return total

def _яМЯуΦЗΟτυыЪьΒΓьμ():
    value = 709510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAngRUQG/b86Cias0EGFMyN3734='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 14 * 83 < 0:
        _dead_7893 = 63
    return total

def _йЭВВйЛЭХχ():
    if 40 * 4 < 0:
        871
    value = 15044
    text = __import__('base64').b64decode('QmpFYUZhUkJLbGFPZElVUGg5T2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙфАΦЭГοГΥЬΒЗΜρ():
    if 68 * 6 < 0:
        _dead_9795 = 609
        834
        323
    value = 914660
    text = __import__('base64').b64decode('azRDd1cySFhmTFgyRk9YRWM0QzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΒχΔщОфсгХЭδν():
    value = 647294
    text = __import__('base64').b64decode('Z2Ewa3hvVkM4bW9LTXJHdXFxUlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪТΛЯаиБβνЬЯлфΚΚК():
    value = 523599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH/JTFhpqZANAF2bkVTJPBEK7jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝтПНνфмЗ():
    value = 1093
    text = __import__('base64').b64decode('QWdGS09LZ0N1QVFrSjc5ckh3M2k=').decode('utf-8')
    if 93 * 94 < 0:
        810
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ΓΜИИвЫΚйΟβΨл():
    value = 91023
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID3HNnI0+rkmOF+L/WzJYzAc8Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 39 < 0:
        _dead_2018 = 505
    total = value + len(text)
    return total

def _ΥΦТжсЧξАΦфуω():
    value = 504295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXv3TVkg9f8OESqU92aKAwcd7Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙτкЛγкУυ():
    if False and True:
        pass
        _dead_8198 = 625
        pass
    value = 420426
    if False and True:
        239
        pass
        pass
    text = __import__('base64').b64decode('WHZjZzhWV1FiVFhTM2o3bFY1VEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΙεКωΩЮψνληъРй():
    value = 293100
    text = __import__('base64').b64decode('RGFpV3pwUHF3dXB6eXcwOE5xSmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ювθΒомιЦςЮЕφθ():
    value = 280966
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjruZlg1zpAGNQCt+FfBFRQl5ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _свиЧαΠλщ():
    value = 425465
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pxm2f1Mhz4EwaCfx4mLIBHB8wEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХЗЖχΛЛщΖЯΖΦлΩэз():
    value = 397106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jgn9ZEVqzaEXNAKmnQKdHx8H9X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τуΧПχχлΟΒΑШхΝц():
    value = 41868
    text = __import__('base64').b64decode('cnZQMXJvMTBlYnlMb3gwUHNhVDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤРОλфыпиΚаК():
    value = 615707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSjSb38x9foJbx335geYDjwo7kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БшсοφνπоςΧεлСыε():
    if False and True:
        832
        538
        pass
    value = 545139
    text = __import__('base64').b64decode('dUM0ZUJLS256MmV5OERoN01GTkI=').decode('utf-8')
    total = value + len(text)
    return total

def _МφΒщЯζωВыцаΛп():
    value = 254146
    text = __import__('base64').b64decode('WXlFdml0M284TGkwVTFEaWtEeFE=').decode('utf-8')
    total = value + len(text)
    if 50 * 5 < 0:
        301
        pass
        _dead_9820 = 290
    return total

def _МΣΝмηςСοαΦιГСт():
    value = 749677
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSu0WH4W5q9SFTyvzQCFMSAK1Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬЫыЫΑУΨςсЩМ():
    value = 926207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzmxUXAzyalXOQiKxHuJE3095mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯсэХψЗοШбλЩαξЫЗς():
    value = 954208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwvBN3Yvr74uLz/w5FSGNxw43UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        661
        986
        _dead_7474 = 479
    total = value + len(text)
    if len('') > 0:
        _dead_8529 = 552
        pass
    return total

def _ΨЪАΖТΠΣΡЖΨъФ():
    value = 822613
    if len('') > 0:
        _dead_4573 = 993
        570
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw7NQ0sJrZAHPACb+WCEZ30620k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 17 * 27 < 0:
        _dead_9224 = 194
        _dead_4204 = 173
        pass
    total = value + len(text)
    return total

def _βмΔЙΣЧξαоΒЙθΛъШ():
    value = 367129
    if 62 * 74 < 0:
        411
        158
        143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzjXQnct75sxHyGB2wS2YTMg008='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сШжζтΠСС():
    value = 479954
    text = __import__('base64').b64decode('Q19TVmUzNVVnMnh1b1dab3VwUW0=').decode('utf-8')
    total = value + len(text)
    return total

def _вТтοαчнрсхεПεБ():
    value = 731530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQi0OAMV950waTCo2WXEPgYI7Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 86 < 0:
        _dead_9434 = 529
        pass
    total = value + len(text)
    return total

def _ПнЭнНоЖюЮЩжπИТ():
    value = 518787
    text = __import__('base64').b64decode('VVZNcUJGS05KWHdZblpuR1RTeGI=').decode('utf-8')
    total = value + len(text)
    return total

def _лψВΝΣхφρξυЯι():
    value = 716770
    text = __import__('base64').b64decode('aFZ5V2lwX0wwMUFWNnJ2UXBsNUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΜМШεяΗпσ():
    if 45 * 83 < 0:
        _dead_4099 = 507
    value = 190079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHmzTXxu9ZoCPVyhzWC9YSsl7Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        491
        _dead_2035 = 532
    return total

def _οБРоМЯЦξψβχХΜιШ():
    if 74 * 34 < 0:
        _dead_3182 = 902
        pass
    value = 72266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICzCSn4yyp0vGQGi8HKDGhou1EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πшγΓЯΣПляЦτΓΒ():
    value = 518473
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR72SEINzboiEFig31ScOTc31j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡυЗЮЩΙиΕ():
    value = 594073
    if 60 * 23 < 0:
        pass
        _dead_9416 = 814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECHrbHsw7Jg6Y1yKmWeJJD0a70s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_8010 = 43
    return total

def _ЦΒчБэмδУψУ():
    value = 443572
    text = __import__('base64').b64decode('R0k4cHN0ZUNNNW1EZ1E4S3RDODc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЕщмКьΕοьЧкЪ():
    value = 691481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyvlOFwSyJ1XEAW1xUG8Lj85618='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бДйвТкΧηЭЫъ():
    value = 650833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw3RPGcq0IIOHwKZnQeoGywutGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩДрЫΡβЧμТсЮКΩΠю():
    value = 236065
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('bWtOdHA5VlZMVWEwNFdYNTd4ajk=').decode('utf-8')
    total = value + len(text)
    return total

def _юДТΙΡЧЙзΥλΝυ():
    value = 48143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX/BeAFg74AxHTmm7lm+LHcE5X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΞΒьφхуΝψЛξΝъиΨг():
    value = 323437
    text = __import__('base64').b64decode('aV8wZlB4VnppRlcyS2JiWFFJWWY=').decode('utf-8')
    total = value + len(text)
    return total

def _нσфщгнЛгΧΟπдж():
    value = 862851
    text = __import__('base64').b64decode('dFFENVJ2WXRWVFlYakFMQTlHa3M=').decode('utf-8')
    total = value + len(text)
    return total

def _шξМвΙЫΓэΤБъБ():
    value = 577396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F37DQ2Qr6qsmGFeS8HS1OQkr100='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 69 * 37 < 0:
        _dead_2949 = 846
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _РδΡщЬЧИΘКцρШЖкλ():
    value = 918275
    text = __import__('base64').b64decode('SVNBU1JDSUFFbmtXdEtUTFJSR0s=').decode('utf-8')
    total = value + len(text)
    return total

def _βйψвЖКиβН():
    value = 265552
    text = __import__('base64').b64decode('UkJ6d25FVXAxTlBzRlgxUWlJUjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩяΑΜеДРπξΗди():
    value = 634217
    if 83 * 78 < 0:
        245
        _dead_6102 = 635
        904
    text = __import__('base64').b64decode('bG5rZFNYckRwWTlBWW5DV0RDanM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        726
        pass
    return total

def _ыερΑЛЙΠΗцΘИυ():
    value = 999243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSrSb18jraA5FiuMwUC2Y3Mo4XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        304
        340
    total = value + len(text)
    if False and True:
        _dead_6065 = 474
    return total

def _γκИγоλυο():
    value = 70331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3vhXAEhzLI2Fhas727IHRIjslo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бαЯΜγхδыΘ():
    value = 547540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHfXeWAfyP0GEBWPwleWOXV6030='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4809 = 487
        pass
        530
    total = value + len(text)
    return total

def _аΡыщκШКιъ():
    value = 821628
    text = __import__('base64').b64decode('eFhjbERnVkJTa3BXVUpHczNVVHQ=').decode('utf-8')
    if False and True:
        218
        pass
    total = value + len(text)
    return total

def _ΣХΕΗКЪσιюΖчΙъГκΙ():
    value = 28907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pyy3Vmcx6YkEAhqUmQGzDQYjzFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΙαБСъоаЩ():
    value = 836834
    if 25 * 94 < 0:
        _dead_4320 = 829
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh6wPFM2rrlUI1qC4H6lAwA9tjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 3 < 0:
        pass
        pass
        _dead_9557 = 5
    total = value + len(text)
    return total

def _ббЮспυййхΑκХ():
    value = 109237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3i0PVc/+PxXPQKTx32cLQsqync='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        950
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        146
    return total

def _еСΤτΔΣχΟЖπТМьΕ():
    value = 120798
    if len('') > 0:
        pass
        293
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwfHTXM4+J1ROQ6ynWWRbS4H91o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШКХИθЬВЮЮНЯиСΘь():
    value = 777374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NC7CZwRhyK0SPzWn+nOgYHIi92c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иМЖοξαЮБОλлйчЙΜφ():
    value = 44974
    if 93 * 84 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzX3OFYQ3/kKORj04HO1JRF93Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7138 = 602
        264
        _dead_2571 = 319
    return total

def _αЫЯЛρκΛХхфπЭχУж():
    value = 864671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3j2ZVVhqq9UEyX1kA67YTZ20Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΦГΞκмЩЛШχΣИН():
    if len('') > 0:
        _dead_7747 = 747
        pass
        _dead_5090 = 751
    value = 821226
    text = __import__('base64').b64decode('a1YwTHJoMWdLSEpIc05laTlXdjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒгΩЮχΗΔΠМжеΖΘηΝВ():
    value = 528061
    text = __import__('base64').b64decode('aFI0SWZHR3VVdnZMQ1QwU2QxUnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗθТΖТρжφΡΧМЪδΧлщ():
    value = 886168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQqzV0c70/tXFSeQ7Qe1ZD0Cs0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪφщτыбеЙЧЫОεζεζщ():
    value = 976333
    if False and True:
        808
        _dead_4073 = 789
        _dead_1214 = 83
    text = __import__('base64').b64decode('WE9zTncxZDBRY1RSWmk5c2dvX00=').decode('utf-8')
    total = value + len(text)
    if False and True:
        177
    return total

def _δУιЖиθтф():
    if 30 * 34 < 0:
        pass
        _dead_4343 = 639
        81
    value = 460460
    text = __import__('base64').b64decode('ZmVENEl2VXBPQUoyTGJQcjBwTFo=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _КуЩρщΨДиГчП():
    if len('') > 0:
        pass
        14
    value = 187392
    if 66 * 38 < 0:
        pass
        647
    text = __import__('base64').b64decode('UEFZd3FCazBpb2RNN3JDMHA5dFE=').decode('utf-8')
    if len('') > 0:
        _dead_5269 = 646
        pass
        247
    total = value + len(text)
    return total

def _ΙэЭνчπзΖОγ():
    value = 75364
    if len('') > 0:
        630
        pass
        910
    text = __import__('base64').b64decode('aktwZFNoZTlKaXNEQXpXU3JtOVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ιоЭПΜΔζяΕыле():
    value = 891723
    if 77 * 31 < 0:
        315
        pass
    text = __import__('base64').b64decode('eXAydkJxUDBNU3JJc3ZWa2xsbzQ=').decode('utf-8')
    if 16 * 13 < 0:
        _dead_7218 = 169
        _dead_8259 = 192
    total = value + len(text)
    return total

def _ΣοбиπδψσΥρЯЪЯЩ():
    value = 429743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnvrZn04rJIvKhz25FyiIwgJ2zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡφΗПΚЭыХцεΡ():
    value = 368735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyXxfFI/xKpWPSeC8FGZBXQh0WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 32 * 34 < 0:
        _dead_3524 = 197
    return total

def _щθчЮНΡЧζξюЕΚ():
    value = 863014
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzXbdAAy8qpQCF23w0a1Jxc58W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δоГαΕСшзыФΨ():
    value = 286504
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax7gYlUL/YxUCwXyzEfAEycA90k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 43 * 15 < 0:
        pass
        pass
        pass
    return total

def _ηЩБΕЛνΥςъδΣΙ():
    value = 466376
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQa3QgcLx/lVPiOvzEGSLRN88WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7207 = 369
        841
    return total

def _ΟЩЧиВмΘл():
    value = 28332
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQS1fGgfyowaHQSJ2H68JgN+7nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИεξςЬГγσщΞ():
    value = 925395
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FD3oZXwX/KchbF+t3XfGYhof3Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йДзщЬьЖьвΚЭΩ():
    value = 676047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy3gSXU8yI8hER2yymS2GS1621k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κОкΞЕБЩъРКлэκ():
    value = 57690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCPbQn4P/aBRbj+u90W3BQM8tnQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οаνоЛςυЫлΞΤ():
    value = 953786
    if 39 * 82 < 0:
        714
        _dead_3567 = 125
        _dead_1573 = 821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICy8eGdv7rknMwiw2XzGDQ5/5kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЕγΚΠΡσЮОЭБχ():
    value = 771057
    text = __import__('base64').b64decode('YTJBdUdqdUFUZzZxRDdxS2RjRVA=').decode('utf-8')
    if len('') > 0:
        pass
        780
        210
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if len('xxxxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    _dead_7276 = 701
    739