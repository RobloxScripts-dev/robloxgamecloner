#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _рКроΑьзуИДλВ():
    value = 116524
    text = __import__('base64').b64decode('QUU5MnFZcFFLcnRCVXY2U2U3Zlc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _γθηΤΛΥΩΜЙ():
    value = 34054
    text = __import__('base64').b64decode('Vm51cjJ3R3IxUHVCUHBwZmIxelo=').decode('utf-8')
    total = value + len(text)
    return total

def _гНμЖβΛиЯΘМчΝЖЮ():
    value = 128861
    if len('') > 0:
        528
        913
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTfSa2Mc8IUZG1utw0ejOjAV3jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΤδЦХдθи():
    value = 575721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiLvdmIBpqMzMCmvz3qADCs38Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 83 < 0:
        991
    total = value + len(text)
    if 53 * 61 < 0:
        _dead_3699 = 222
        pass
        pass
    return total

def _ΧΡΩοωчрНкФяψКвН():
    if False and True:
        pass
        _dead_5118 = 984
    value = 592958
    text = __import__('base64').b64decode('R3ZRdlZlallFRlNxQVoxMU11SEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕгξКσЩБЩξΦСΗг():
    value = 594112
    if 21 * 11 < 0:
        pass
        _dead_8054 = 606
        _dead_6783 = 573
    text = __import__('base64').b64decode('RUpwNUVoRW9TdFNsbjNOOFB4c0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭЙЗбНЕτΧИΓЧя():
    value = 306323
    if False and True:
        245
        _dead_3247 = 30
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBq3WXUgqawIHhe53Ee5ZiAn8mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7897 = 188
    total = value + len(text)
    return total

def _нПвΙΔвψΦЪуЛч():
    value = 890319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACDHTQQjqJFQLxiB/kzCGQcnwGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БνВρκеδΧЧлςЪΦрЯЧ():
    value = 723920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnfjRHM2/PpSPxynwHHJCwJ6w1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9989 = 98
        _dead_6225 = 511
        934
    total = value + len(text)
    return total

def _ΘΓЙфυυЫЩШΒΥ():
    if 20 * 54 < 0:
        pass
    value = 114025
    text = __import__('base64').b64decode('REtsVWZDQ3dNRGpnVHdvb3lDN2w=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9416 = 953
        pass
    return total

def _ΩυψьΑΦТΝе():
    value = 732978
    text = __import__('base64').b64decode('aDVWQ054Nm9LT01QaldVX1pYUVc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        673
    return total

def _ΑэΧрΥυАсЕ():
    value = 970119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fzz3N0MxrqMPYgSM326lGX0+3Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кξΝσΡкδЩ():
    value = 164626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cx3pQVYu6Y0RDQyF7XWyNyt29Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        160
    return total

def _АЪцτЗБНеφΠЙхиΓΧρ():
    value = 10414
    if 28 * 53 < 0:
        _dead_3919 = 799
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DADvSAZr0vARbFv1/AGAbDIQwms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РФФЦΦΥЗФЩχ():
    if len('') > 0:
        40
    value = 333800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ki7KYGUt6407aguMzGaoGQoO5VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βΧΗαΕΗωВыиΟБТ():
    value = 557138
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax7VWX8LxJ9XGweQzwbAAAAFz3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1252 = 944
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _щюпЕγΡΕыВФΕ():
    if 84 * 9 < 0:
        pass
    value = 520452
    text = __import__('base64').b64decode('bmhKVEU5Q0tYYkxkOUUwT0VwS2s=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ЛФТРωζΛΕжЫΒ():
    value = 404183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxXHZ1UPpv9VNB2W63LHOAt+82w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωНΛΝΣΟιлЪфьЛθ():
    value = 635689
    if False and True:
        _dead_3462 = 765
    text = __import__('base64').b64decode('RDBjbTlHNkdWYndkcjBfZFlEXzY=').decode('utf-8')
    total = value + len(text)
    return total

def _эЧΧΖаγεЕьжЭрЧ():
    value = 136821
    text = __import__('base64').b64decode('YTBfSjd1YWc5NHdBVGlyT3lVQ08=').decode('utf-8')
    total = value + len(text)
    return total

def _фτТРСГЖрПйЕа():
    value = 816692
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mnv3dFUA7KwJLViB23KdCxY5sGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8233 = 551
        pass
        pass
    return total

def _δаЮэгкΛΠ():
    value = 72345
    if len('') > 0:
        pass
        _dead_7072 = 657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax3MXgAb9/4LAD+T/EeyPnQ58n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        178
    return total

def _ЪρФΓΧψАΟм():
    value = 480109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhvFUXIxqKoBGVmK+VCDYikYs00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΚШаεмитρФЬθЯδ():
    value = 888297
    if len('') > 0:
        212
        904
        _dead_6237 = 887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jym1aHZq1vxWIz32mVvBNyo/0Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        724
        _dead_5497 = 368
    total = value + len(text)
    return total

def _РςуЖΔаъυ():
    if False and True:
        pass
        _dead_2141 = 707
    value = 581592
    text = __import__('base64').b64decode('dGhITVlpd0czUVVMZThTVHJUQ1Q=').decode('utf-8')
    if False and True:
        106
    total = value + len(text)
    return total

def _λэЫсютαрьΕΩΧ():
    value = 153870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyXOOndh/Y8tCDW04waJYgcg0Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τаΔБЖИЖиζюхцΞβз():
    value = 330821
    if len('') > 0:
        _dead_2643 = 73
    text = __import__('base64').b64decode('anNfWmhNNU1WdXlucUtBZlM1Mlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ШФιΗρпио():
    value = 103456
    text = __import__('base64').b64decode('Um1HRkxsRzhPbjdIdzd3RGdBT1U=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_6403 = 37
        _dead_8412 = 631
    return total

def _ущСИΣЖьУξΩБтλΑ():
    if 87 * 93 < 0:
        pass
        49
    value = 608086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgrVXVZv24cyBVz12EHGLBo45mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5412 = 966
    total = value + len(text)
    return total

def _ЯЩыЦчжτМЩчЗЮы():
    value = 840972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQToT2Q7qIITCB2www+VLhAAwmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΝθкΒμНфΠГеΜаЕα():
    if 14 * 16 < 0:
        _dead_3278 = 130
        _dead_1635 = 965
    value = 403457
    text = __import__('base64').b64decode('a2tJM0dwVjJIYzhPVnM0UFI0MEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ПππΨЖОЮκβΦΟ():
    value = 860800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyHHdl9q6Ik0IwD38k6AYAk84nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вζЫдΓвθΡа():
    value = 320362
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjrIVlVoprsZNC6b/lmSInIl9kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 65 * 51 < 0:
        pass
        73
    total = value + len(text)
    if 20 * 58 < 0:
        _dead_8585 = 636
    return total

def _ΧΜЯΔЭοФвΞАΦз():
    value = 104850
    text = __import__('base64').b64decode('UXNXVDNKUlZlb3FMMFBrQjE2TWQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        185
    return total

def _εэКрщΙШшЯπГνЩъ():
    value = 304613
    if len('') > 0:
        pass
        703
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy3JRAMP2KUhaAKk4G6HMyB63E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        468
    return total

def _АПΜςШвУбсΜЧΖУΦ():
    value = 174389
    text = __import__('base64').b64decode('Zlo4eUt4WWppV05BeF9rc2QyTVU=').decode('utf-8')
    total = value + len(text)
    return total

def _щηэыΘЖЯьЮаОе():
    if 44 * 96 < 0:
        988
    value = 307252
    if False and True:
        587
        _dead_5889 = 244
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX72dlIDwbAQYiGLxWWoMAAE7W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εэРГГвοы():
    value = 626834
    text = __import__('base64').b64decode('WkQ0Skl6R3gzTnlDYUtZSl9xeFI=').decode('utf-8')
    total = value + len(text)
    return total

def _йяяЩΓкоГжΣкυΒЮЯΣ():
    value = 362255
    text = __import__('base64').b64decode('QVlCZkI0cU03cWlxdVNheklNR18=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЪЯЖоΕЬΨ():
    value = 890862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAbXbXUqy4clCxiA7ESKYS8A434='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΔηΥΘμИЮн():
    if 90 * 88 < 0:
        _dead_5300 = 317
        456
    value = 290043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiK3aHI92J8gD12szFzCNygIw18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЧφщΔΛэΩ():
    if 18 * 87 < 0:
        _dead_2562 = 948
    value = 567828
    text = __import__('base64').b64decode('cHZIQ2RXU1NBUmlrNEhiSkFrTmc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΦφэχΝШУГЩАЪЭοΨ():
    if False and True:
        _dead_5511 = 483
        pass
    value = 460347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCvFWFQIz4IlbQeXy2SWZxc90Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4199 = 448
        885
        _dead_8906 = 392
    total = value + len(text)
    if False and True:
        pass
    return total

def _йлΩΣЙηйлμηЖΕНΚνΩ():
    value = 955204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRXjSUBpxL8RCAGcmAfIFxx94ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бИъΝΤсцηηЙХФΟЧКΩ():
    value = 118876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgHRbXs47Yxbaxyz5VSZPxV6sTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΧΨешγхЧцыρЭД():
    value = 567205
    text = __import__('base64').b64decode('TnN2aUNHTVV4Y0tteEZaS0pXVEk=').decode('utf-8')
    total = value + len(text)
    return total

def _вφоδΖТζηкДЦпοЭχ():
    value = 223251
    text = __import__('base64').b64decode('VzA0YjdsRDhkZkhpNW55aDA4RWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ньшбλПШычлΞ():
    value = 148747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAnNdlgh+Y85IxWt5XzHHXw95Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        838
    return total

def _ДΨпрвМоΗПЫζΩыо():
    value = 32414
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CirbZAIW141QFV+Fz1yELTMY6z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        19
        907
    return total

def _ОЬΗъχЭШΚКИЗΦ():
    value = 338170
    if len('') > 0:
        999
        307
        516
    text = __import__('base64').b64decode('UDFCVG1vRjRRM0xzcG9kUk9IUUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΙοэβЗΜΖτС():
    value = 76528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjrHWGQNqo4REFep8UKbZwM91H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9254 = 991
        716
        _dead_4556 = 123
    return total

def _ЕβЩдрЯτФΓΠГры():
    value = 968360
    text = __import__('base64').b64decode('VnlUYjhqc1hIcTIwbms2Z2tfU0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ВκΙωОокщбψЫЫ():
    value = 617192
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABnMdwAKrrkUbl+H2X6fETA1/lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аβЗйКЩΒξКеκЪУ():
    value = 194084
    text = __import__('base64').b64decode('bFhGelNPUGFGamdVWkNJeDM0czg=').decode('utf-8')
    if 60 * 33 < 0:
        _dead_5971 = 694
        529
    total = value + len(text)
    return total

def _ΦδТωзζГЪυυФ():
    value = 918928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng7IQ144058wMgWV7Hq4Yzcr6l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 26 < 0:
        _dead_1512 = 240
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ςΙЮΧΕδЬюмτπчχω():
    if len('') > 0:
        _dead_8618 = 600
        pass
        _dead_1868 = 876
    value = 627687
    text = __import__('base64').b64decode('ZVFfMGF3TnFibjlKSWFSUUg2X3c=').decode('utf-8')
    if False and True:
        pass
        732
        pass
    total = value + len(text)
    return total

def _ΝэυΘбзйςщ():
    value = 987427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jj7BaAcVwYsNDgKR40zHLiQX3D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вюфωкθыξ():
    value = 762397
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERvLelc/p4EVH1eWzQCgBXIIsWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖιЭУКΦВΧΙΞуΦηчτς():
    value = 220137
    text = __import__('base64').b64decode('anE1RkxYU1QydUF1STdZcHk2M2g=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6004 = 403
        _dead_3109 = 783
    return total

def _жτΟБвεζсγеΒ():
    value = 848843
    if len('') > 0:
        _dead_7398 = 819
        pass
        _dead_8486 = 731
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXfTfQMs5LAPAiGX+EKmCxAEsWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬфФβΜиΨλζΥ():
    value = 586864
    text = __import__('base64').b64decode('R3Bwa2YxVThEVjY3Um1mb0lsZnA=').decode('utf-8')
    total = value + len(text)
    return total

def _тΠΛοМΙТω():
    value = 392921
    text = __import__('base64').b64decode('Q0pMNGpPUjJTNmNReG5oSVBaNDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΚДηΗнЕвОщΣтр():
    value = 897842
    if len('') > 0:
        _dead_5772 = 402
    text = __import__('base64').b64decode('VlEzTG1Dd3A1MmhUekh6bGVMZzI=').decode('utf-8')
    if 59 * 80 < 0:
        _dead_8375 = 648
    total = value + len(text)
    return total

def _ФФЧхσдайβН():
    if False and True:
        pass
        pass
        pass
    value = 301215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwaxfUsB6rkKAhu7z3SeEA0tyn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сКнΚкМΠйгТΓΡхζк():
    value = 270107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSvoRXVo5I00bQOawXWcIigCwk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гвВжΨжСяЫИβρΔжМ():
    if 80 * 12 < 0:
        _dead_9802 = 206
        _dead_2517 = 323
        375
    value = 706144
    text = __import__('base64').b64decode('amRLenlxZTlJT2d2a3pLZjRvams=').decode('utf-8')
    if False and True:
        552
        384
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8880 = 287
    return total

def _ПННйжфΑнюΥн():
    value = 856158
    text = __import__('base64').b64decode('b2lQeHZhWmQ1aVVvQ3luN3RRcm0=').decode('utf-8')
    total = value + len(text)
    return total

def _χУВΩЧΤЖмдвИкцс():
    value = 860799
    text = __import__('base64').b64decode('ZGV6R0RqYl9CTGU0SlBNXzV1X1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЙЪτЕяυйΥЦξςΣ():
    value = 359302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXa0Vn0NyZEKAi2l+W6SbBF84jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯХФεачнДЛЮЗейπμз():
    value = 76279
    text = __import__('base64').b64decode('SERuN2hZeFZBUVlFejJucDJPUEc=').decode('utf-8')
    total = value + len(text)
    return total

def _сбδПΥΛоΕгрэйхУ():
    value = 685935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyPWaQkD0Y4zNDaB2F6RAnI57mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЖΑрΟΒКЪ():
    value = 975546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Biu3YAcgqIQNNyOv0g6oG3cnxkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦЭΣВΑаΞΕзкΩКО():
    value = 268674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAnVZwcc9Zg0Ller0Ga2Mhd6wkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КψΒγЗлξΣΛΤ():
    value = 897334
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwLuVm46waZWCwul/EWAZAIGwUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πСΓНАτΑфψнЛЕьμт():
    value = 72285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETi2PX8TzasiLQ326lqYZzMMzno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъзηΓμъюэΚΔ():
    value = 535913
    text = __import__('base64').b64decode('ZXpuSHF1SjZXZ0Y1bXpKdG1XRV8=').decode('utf-8')
    total = value + len(text)
    return total

def _δΤДΒцНσЬРмА():
    value = 793112
    text = __import__('base64').b64decode('TFA5dzVrQ0laMXRNX0lqR0NiV0U=').decode('utf-8')
    if len('') > 0:
        _dead_4374 = 841
        397
        _dead_8267 = 784
    total = value + len(text)
    return total

def _СшБаηИГΜЩОГЦПЩв():
    if False and True:
        19
        pass
        149
    value = 857971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzbsOXkW/JwNaQ205GmaODA6smQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЕкθЦЗΤΥПМζЬт():
    if False and True:
        pass
        _dead_6086 = 128
    value = 45233
    text = __import__('base64').b64decode('WW8zblJXYWJFRU4xN05OZXRpSHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗχишΜΗлашχεвΔρΔЦ():
    value = 543833
    if False and True:
        pass
        pass
        256
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQ7AN2tp6KYGbgqa5HiFMyMLzF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 13 * 8 < 0:
        703
        521
        pass
    return total

def _хЭΓαфэлфЗьΗбη():
    value = 934856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BibRX3cs1aYrbySo4Wy3OXYl90k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΖρрыμЗЪ():
    value = 281617
    text = __import__('base64').b64decode('RzF2R0hYbF9sNTVoTTN6MklJUmo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _тδΤУеВЩυΔρръη():
    value = 458527
    text = __import__('base64').b64decode('djdqZEJfOTRJUGFRRnBrZ2E2dVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦνςыοМЛεХЖЛЯΩΘΤя():
    if len('') > 0:
        766
        _dead_8161 = 222
    value = 914297
    if len('') > 0:
        pass
        _dead_3333 = 505
        266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwrWdn4Bq50kKSGF4GKSJ30i028='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        739
        pass
        pass
    total = value + len(text)
    return total

def _ρбДπиζγхщзοδя():
    value = 837909
    text = __import__('base64').b64decode('ZXM0SHVmRUhueWhtV3dhMFEwZHU=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _κΞГщЧючπфРΤШΤЯФψ():
    if len('') > 0:
        _dead_1095 = 874
        302
        499
    value = 287827
    text = __import__('base64').b64decode('V3FXdTVoaXlhc2JuWXpXSW5LTlU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        277
    return total

def _ΥхЗуЩΘΦλаν():
    value = 57455
    text = __import__('base64').b64decode('bVVDSnJuYWg5ZzI3VHhpeldnMVI=').decode('utf-8')
    total = value + len(text)
    return total

def _μюфБΦΖКеηЙЛρ():
    value = 222774
    text = __import__('base64').b64decode('QkV1a2V4aXJtX3Q3NXlSS0xQdVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ψшРейСυдΕТυАЫφц():
    value = 573539
    text = __import__('base64').b64decode('UXg2a3dfT2ZvdkhvTlB3bVVtVTk=').decode('utf-8')
    total = value + len(text)
    if 11 * 1 < 0:
        54
    return total

def _εхЙЪТθздагЗΠж():
    if 12 * 64 < 0:
        pass
    value = 158791
    text = __import__('base64').b64decode('U2o5Mm9ldmJUNHVLY0lKa25CUVM=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6675 = 844
        _dead_5165 = 142
    total = value + len(text)
    if 41 * 71 < 0:
        801
    return total

def _ΜδоΗВпΟхЦМκжЧΗκ():
    value = 922654
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR7JOHUh/Y8EPSeg0neHOyY792Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if 67 * 25 < 0:
        876
        _dead_2077 = 727
        _dead_4879 = 660
    return total

def _ХКьδПΞφлпфКшЛ():
    if len('') > 0:
        144
        pass
    value = 241236
    text = __import__('base64').b64decode('cE0yQ3dfaEZEaHZfU290ZmZ4VDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΣξжЛΛωНΡр():
    value = 549826
    text = __import__('base64').b64decode('WFVGZnkwdHpsd3A0SUpUSFBHS3k=').decode('utf-8')
    total = value + len(text)
    return total

def _εοτΡΝΑЗЭхФ():
    value = 401006
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej/BelBt1IUoBTex+wKdZXUnxzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΤΕШЧсλАяΟΛσ():
    value = 89826
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBzQOHMy07kGPVf6mF+6PHMk/Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хПΖοΥяЕц():
    if len('') > 0:
        pass
    value = 846004
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRjvOntt84caLji221KoYgYoz2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 5 * 11 < 0:
        _dead_4892 = 206
        666
    total = value + len(text)
    return total

def _фхΘΙоΤЗшΝξσΚη():
    value = 677116
    if len('') > 0:
        201
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBfBYnoc5roPYgCC8AamEXwE00s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        727
        647
    total = value + len(text)
    return total

def _ζΒСΓПлОυх():
    value = 782781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgHlYWQX96wLFxmxnH7HLnwt3jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΡΨРΡοΣΜпЕяУ():
    value = 767638
    text = __import__('base64').b64decode('TWhzZHNaNmZkaDd3eXR6NENLaVE=').decode('utf-8')
    total = value + len(text)
    return total

def _рДФДνΕΞΦ():
    value = 636639
    text = __import__('base64').b64decode('eUkwcmJmbk8ybkswdElxWjd6T0c=').decode('utf-8')
    if len('') > 0:
        pass
        713
    total = value + len(text)
    return total

def _еНΦΝмиеЭвФγх():
    value = 207269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDWzT1c6x4NbFAOt8kyRbSZ5vEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πшщψкАЙσъΞЖихАны():
    value = 224615
    text = __import__('base64').b64decode('SG9Gc0hZZFJfQ3BaTThhamhwaWk=').decode('utf-8')
    total = value + len(text)
    return total

def _щЩуиХυκз():
    value = 736738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjzqVGUw7fgzGwOJ8WyaN3cLxT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чφЙбΣΩнσ():
    value = 499399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LS2zOwhs8YkqHRyKyw+HInEfyT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щξΖαΘлιХΚΜΦ():
    value = 257488
    if False and True:
        _dead_3162 = 184
        _dead_3109 = 507
    text = __import__('base64').b64decode('YndLWlEySElLMFJRTjV6NlVoanM=').decode('utf-8')
    total = value + len(text)
    return total

def _ъшФЬмδεЭΑМаЮ():
    value = 822143
    text = __import__('base64').b64decode('RlVSNjBOWUVzMGUyS3VWWWU5TFE=').decode('utf-8')
    total = value + len(text)
    if 28 * 80 < 0:
        _dead_7478 = 263
        342
        135
    return total

def _ΔАΠΖΟЕОζβпжиχв():
    if len('') > 0:
        _dead_4707 = 39
        _dead_3047 = 813
        _dead_2028 = 127
    value = 59576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHzjQQgc9PgBGAmg+lLDBywO1lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οшτМΔУЬРкыаГД():
    if len('') > 0:
        _dead_3329 = 881
    value = 276954
    text = __import__('base64').b64decode('TmNQYW1kUmgxbFE4cFpmQ0xqSW8=').decode('utf-8')
    if 49 * 42 < 0:
        351
    total = value + len(text)
    return total

def _ιΘΣβЛШοςблιЗЙΙ():
    value = 938640
    text = __import__('base64').b64decode('Q0h1cHp4eXpJNnc5NHdHR1NGUUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ОιФДЛЕуδ():
    value = 856880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgSzZQgV9IU3GBeA6nODGBI2vTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХсφЙтεΚкΖюχΧ():
    value = 754789
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCbnfmYWzr0bbz6PwmCUIDV+0U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иЯΓАМЕПйяΝлиυ():
    value = 316263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQHAPXc41YM5DV+M7XTIZ30r7Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бдчΓРяэΒжΤг():
    value = 260840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw7pRlA+6JcFDx2W62S0ABMh3kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΑяΞηЩОΞΨДЫ():
    value = 13082
    if False and True:
        259
        612
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwbQOWQb74QnNBeI92DCBXI2yXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        833
    total = value + len(text)
    return total

def _ΙυлΗΑАΓиωΧы():
    value = 938441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FijMXlMeq/sxMjyu7EGcABQKsU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΩСДωВΘрЗВΑТУзх():
    if len('') > 0:
        885
    value = 320168
    if False and True:
        99
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESr2ZXRuqrAaFxib4EGeMCQCzTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 99 * 80 < 0:
        pass
    return total

def _щмюМπКхβΒГ():
    value = 856326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyPVX2YXxpdXET6t+0+kJxIG4Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _бОνςψичθНВЦв():
    value = 618284
    if 93 * 22 < 0:
        pass
        86
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cgn1YVg3zr9WCwqnz3OnBDUr530='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5781 = 647
        886
    total = value + len(text)
    return total

def _ЖЦΝРτЩвΟπΛИοеи():
    if False and True:
        pass
        _dead_6900 = 385
    value = 885923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHnRSnUa9b8mOx+56kfHPggu9mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2921 = 26
        _dead_4958 = 901
        348
    return total

def _ΒДλΝлКмДсшюЙчЩπЖ():
    value = 930826
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzjJR3kBp4c1OCWkyQaCDRMHxmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖтΔΚЫЮΤΔпнл():
    value = 771016
    text = __import__('base64').b64decode('b3g5b19BN01uN1AzdlJRN1lHX2k=').decode('utf-8')
    total = value + len(text)
    return total

def _сфРΠχЙΣЩВΛнΓ():
    value = 948403
    text = __import__('base64').b64decode('ekNDRzR5dk8xMWVHMnRRRHpRMG4=').decode('utf-8')
    total = value + len(text)
    return total

def _бПκΧмΔиДоΖΞΒыΚ():
    if False and True:
        159
        139
    value = 460039
    if 22 * 99 < 0:
        572
        _dead_5539 = 832
    text = __import__('base64').b64decode('ZFZpS1JYT3ZDcDV1aDlZbUZvNmU=').decode('utf-8')
    total = value + len(text)
    return total

def _МеъτΚρСЗΠΑфχΜ():
    value = 274284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX3TPGsG+rouLQGiyUSlDiok62g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 84 * 79 < 0:
        _dead_1901 = 327
        376
        959
    total = value + len(text)
    return total

def _ЙАЩΨφЙσЕΕΧψакΥХ():
    if 65 * 26 < 0:
        _dead_2639 = 108
        pass
        _dead_1398 = 548
    value = 606678
    text = __import__('base64').b64decode('aGtMeEY4SGhweVFaR3ZLZzdrMEI=').decode('utf-8')
    total = value + len(text)
    return total

def _υρтЭςτуБЗРΖфБ():
    value = 565273
    text = __import__('base64').b64decode('ZDR3SENpUzRUbVFlV250a2V1eTE=').decode('utf-8')
    total = value + len(text)
    if 30 * 88 < 0:
        174
        pass
        pass
    return total

def _ξбРγγυΔБ():
    value = 499140
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DST2dlIR6r4ICBWUyWyzHhMn9ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΕнАηЕθΘΘγΒпФ():
    value = 666640
    text = __import__('base64').b64decode('V3ZCZ1EzaVR3aVpYMDZlOVBQV0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _οΖπцЪΧκрτтωЕΛ():
    value = 924665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRmze3k+qaYkEjaL7m6cNRMntFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΟΔЧгωэΝδΝТмЖ():
    value = 80530
    text = __import__('base64').b64decode('dFlpSGg0bWI1cjZCYzNCTjhGTWg=').decode('utf-8')
    total = value + len(text)
    return total

def _еρиπΒΑаФ():
    if False and True:
        840
    value = 602576
    text = __import__('base64').b64decode('dU9aaTQxTXBuZVFYNkRvcWJpTWU=').decode('utf-8')
    if 39 * 51 < 0:
        pass
        pass
        324
    total = value + len(text)
    if len('') > 0:
        585
        pass
    return total

def _ξКЩвиВΛΒДН():
    value = 726234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LC7jfUNprLAFFSSv0gaIYQt8xmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΝрлгΦитςЕιΥрХцЧ():
    value = 975307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HArVOEkp7ocwagSc+H6yBycA/jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кЫηНΤчиΖиΧжΟЖ():
    value = 325997
    text = __import__('base64').b64decode('dGFwZ0tNQjRTaXR1ZjRxeXAxbW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΞХнεАЬΠ():
    value = 81062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID3CXgAL75cFFQHx2lGlYHwb9nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΦВфАΛхРΚдпНВЗр():
    if len('') > 0:
        pass
        pass
    value = 820497
    text = __import__('base64').b64decode('V1pHN1A5NHdVZkk3MUxJNDRxRkU=').decode('utf-8')
    total = value + len(text)
    return total

def _НфЩзΣΦкΦ():
    value = 456777
    text = __import__('base64').b64decode('bzg4RmtQWG9FNFJ2UmI2NFdva3g=').decode('utf-8')
    if False and True:
        _dead_1417 = 709
        pass
        897
    total = value + len(text)
    return total

def _ИτωΣλρΚсШδЯЖ():
    value = 144203
    text = __import__('base64').b64decode('cGU1YUJwRlA2RlZLVU1wUmo1TVo=').decode('utf-8')
    total = value + len(text)
    return total

def _БбΛщцЩΘΞэФъб():
    value = 313348
    if 49 * 80 < 0:
        pass
        pass
    text = __import__('base64').b64decode('WkQ1WWlBbEFhU0NxODV3aEtFTDE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        677
        _dead_5298 = 223
        _dead_1861 = 315
    return total

def _ΒΣπЦπкΒγΞτθΟΠВμ():
    if 81 * 27 < 0:
        pass
    value = 316694
    text = __import__('base64').b64decode('Sm1xbUpsRFRuZUZhWlRXd3l3YjY=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _вδЙΕωμЮψуаθ():
    value = 415778
    text = __import__('base64').b64decode('dFNYcGI0YmZCM0laUzNZQml1S28=').decode('utf-8')
    total = value + len(text)
    return total

def _ηЬσкЭэτфΔφъ():
    value = 950024
    if len('') > 0:
        666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnzXRnoRqfkuPS2T4EC7GQAh1Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _феЕшэιΘΕΧΙΥ():
    value = 795069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCbAdlQM6ZsnAgP6wnSGMhc9sUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лРЕКΥχЫЗыμΛЗδο():
    value = 1586
    text = __import__('base64').b64decode('aWhPcXFkUFY4YzEwM3FVRllpMXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛщВΖΔяψΚΗγЧχФюγ():
    value = 167471
    text = __import__('base64').b64decode('dEtlNV9IeWlHdjJlM29EYTJyUDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _тΛНΛΤЦνВηЕνТΤхΖ():
    value = 114753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQT+TUMN2Y4TLwqW72yaJAAM7XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КωХΟτхδЩσνфχЭ():
    if False and True:
        pass
        223
    value = 427192
    text = __import__('base64').b64decode('bUV1eDRIX28zSnJtQng2N3dYNU8=').decode('utf-8')
    total = value + len(text)
    return total

def _РшΡчΔВШЙлЯςοрЬ():
    value = 546723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jiuzd3Qv2/ETDV2g+FzGBS974ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓщгЫзΧЖΑОПπмγЗ():
    value = 543338
    text = __import__('base64').b64decode('QUNEeGFfSF9Qa2phX1lxYmNaZWk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _нТбЙЪΥсрЭЕМΩЖТβЦ():
    value = 687834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXr1PHoY2KkZPDq0/HC0NiMitlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 45 < 0:
        _dead_6175 = 650
        188
        pass
    total = value + len(text)
    return total

def _НЗЙФиδуΦЮΝε():
    if len('') > 0:
        _dead_8662 = 938
        _dead_1470 = 838
        579
    value = 810040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC3bR0Q15/owBQeQ4X+VMRQ/zE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        448
        _dead_5508 = 23
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _БРτныΖΕμхИεωЩΨсΙ():
    value = 398653
    text = __import__('base64').b64decode('Q0dTR3VMVXdEM1JFbUlvYVpQMEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ψГχмХЗΨΓ():
    if 47 * 99 < 0:
        pass
        pass
        _dead_2163 = 724
    value = 910594
    text = __import__('base64').b64decode('QVZFMjI3TzFRaExUUVdiWGZJSmo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ыΣΕαΗФЩΦΔτхП():
    value = 390074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgPhYEM/54ZabS70nnOIACt64EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΨРωΙюΦЧЛςΕВрчЦυ():
    value = 160542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHnteAAN6aE5MVb0/QWjEzIf00o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΙΛΞуЖпλьηΒНтл():
    if len('') > 0:
        _dead_5146 = 628
    value = 291247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD/yTVgYyZcWYz2E8GGeMTx59GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЭΧγΙΙяδξοφр():
    value = 58314
    text = __import__('base64').b64decode('bXEyazQwc2VFdTRNSWQzWXBfRVo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4774 = 447
    return total

def _мЩФХфЧьωΖЙыΓаΘо():
    value = 519477
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAjXPVoN0Ycya12r/EbEHwl48GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πνΝЖφΙиФЛВяνЫц():
    value = 907502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXi0YXphxKcbOyaRxGyEMBMV4lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _спγьЦПуУиαΤдωζзЪ():
    value = 212478
    text = __import__('base64').b64decode('YmVfVU9wbkluOHIyYTBBbmtWRFY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6661 = 95
    return total

def _эνЛфΠΛФУΞ():
    if len('') > 0:
        _dead_6404 = 852
    value = 69629
    text = __import__('base64').b64decode('YTRKekh4aEc0Y0xhS29uYWwzUVg=').decode('utf-8')
    total = value + len(text)
    return total

def _жУΜтДΥтΓΥδ():
    value = 23029
    text = __import__('base64').b64decode('THU4ZVdtQUZnTUFWNjBsaW5jaXk=').decode('utf-8')
    if 17 * 19 < 0:
        _dead_7449 = 508
        _dead_2385 = 64
    total = value + len(text)
    return total

def _ηфрψφьюοΙИ():
    value = 354673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxvOSUgB8/gICyuNkGGzHhF2xn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βСУйщьРо():
    value = 105450
    text = __import__('base64').b64decode('eE1NT3JiNWJubHJoc01uRUlrSXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞМэКОΣдιСεцεЗХСΤ():
    value = 168528
    text = __import__('base64').b64decode('Yk40QXhteWVVTmZjOXNvWlpESmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _гЗузΚщвμκтЭ():
    if False and True:
        pass
        pass
    value = 514013
    text = __import__('base64').b64decode('TVU5aVB0YWtHMjhuYjJhNExEMWM=').decode('utf-8')
    total = value + len(text)
    if 76 * 74 < 0:
        394
    return total

def _тΓмфЬκκθщζ():
    value = 210418
    text = __import__('base64').b64decode('aG5Dd3VaTVBWYTFWMXkyRk9ET3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛβслαηβζТΞпΤμ():
    value = 140021
    text = __import__('base64').b64decode('UHMyaUNvVlpyYWRib0FIeXBlbUw=').decode('utf-8')
    total = value + len(text)
    return total

def _АЩыΑΘЖΝΛЙщψ():
    if len('') > 0:
        pass
    value = 829521
    text = __import__('base64').b64decode('YzE4RGMzamVrcXlHREdMMUxlX04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕГъЖЙюΟкоЫκНМщу():
    if False and True:
        pass
    value = 650321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiS3W0dv9v41LSaO2QKcDD8210Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4484 = 327
        _dead_9435 = 941
        _dead_7022 = 469
    return total

def _тяδэРδιΒЦч():
    value = 56229
    text = __import__('base64').b64decode('RWVTdVBlMkpUdXlIZ2RXTlNKMkM=').decode('utf-8')
    total = value + len(text)
    return total

def _хкοъЕсъαφЮпиιй():
    value = 482659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgbOYVMUprFSAjy7xQa4LB8Ow2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 2 * 69 < 0:
        pass
    return total

def _ЛГΩИΣζωрεηнκЭбж():
    value = 488150
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzXXS347/KBRH1mm60PAEB8H6lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НτΜюαчКεЮΣктψ():
    if 64 * 56 < 0:
        pass
    value = 597637
    if len('') > 0:
        _dead_5815 = 396
        _dead_3893 = 502
        pass
    text = __import__('base64').b64decode('blNaM1lzdDRvdGhUZGNTRE9jOFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _дМшθιΗЦΤνПшютю():
    value = 229640
    text = __import__('base64').b64decode('VGR1TXVRT2lMMEtzZlJTdUtDWUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ХидаφэΗбΜ():
    value = 266927
    text = __import__('base64').b64decode('TWJINGJMcEI0WFozM1VKZzhoMUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪМаканеεн():
    value = 99306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzrobUUc+YEACRX2nWLHMgQN9UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2634 = 859
        pass
        pass
    return total

def _εГΜΑхηΣаξσДΗтЛξ():
    value = 237768
    text = __import__('base64').b64decode('Z3U4aGpyUWdTdzYzX1VzNmEySGg=').decode('utf-8')
    total = value + len(text)
    return total

def _шЙκζеЗΡмΗ():
    value = 239951
    text = __import__('base64').b64decode('QU1pUkRwdUFhaVM5bUpTaTdTV1E=').decode('utf-8')
    total = value + len(text)
    return total

def _БЬМυЙμφΖДΝеЛ():
    value = 975485
    text = __import__('base64').b64decode('V1E2SjFIOEROUU5UWVowbUJKZno=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        846
        _dead_7823 = 920
    return total

def _Ηрσρонου():
    value = 190749
    text = __import__('base64').b64decode('RzhSWEpwSFFuZnNpOXBocldENjE=').decode('utf-8')
    total = value + len(text)
    return total

def _окэбЧΡΤΚςиΕдкДκд():
    value = 517723
    text = __import__('base64').b64decode('ZkVLUEdqYTFyNllTSVNFdWZSSm4=').decode('utf-8')
    total = value + len(text)
    return total

def _κςРσεЗΤΑДγ():
    value = 769337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjvCQkkxwbJaEB2A8ULFZXAG41E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 88 * 53 < 0:
        pass
        _dead_3497 = 797
    return total

def _ЙхЕФρыοЯμ():
    value = 611234
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ln7tPUI68r5Tbj2t0HmDMQkgzn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥНЧЮцЬЛПςЗΓАНΘХС():
    value = 166899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCvtYAcY+JgKGV2I3HulYRIhxkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФЗΠιнЖчТДЪακИЩβ():
    if False and True:
        pass
        382
        484
    value = 306399
    text = __import__('base64').b64decode('dzN6bmc3UW5WTVJ6SlFCOTRnOTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΔΚρЬψьωΝυΛ():
    if len('') > 0:
        _dead_4117 = 881
        292
    value = 745904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhq3bX5h27kJAxay7Fu6ZnwLw1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΣμаεаоλПШОΛ():
    value = 111252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQHSfV1o3aYaFQqG/QHGOwE4y1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_2690 = 466
        pass
    total = value + len(text)
    return total

def _ТΥΙаνмгξд():
    value = 768835
    text = __import__('base64').b64decode('dWdQN0s2bk9INGMza3hEc3Q4WU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒтωШδΦТξΝЗ():
    value = 223514
    text = __import__('base64').b64decode('STFhQTVWblZCb05oQWNkM0NIanM=').decode('utf-8')
    total = value + len(text)
    return total

def _ыКыαмЗХюОρζ():
    value = 691231
    if len('') > 0:
        _dead_4999 = 687
        _dead_4305 = 642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAuzPHZh/L8bH12pxnGoPxYc5WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΘΟυАЬδВΓмχμ():
    value = 468970
    if 17 * 49 < 0:
        _dead_7026 = 473
        _dead_6117 = 15
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSHCYVU27JoNIj+Z/FGVYzMYsXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨОΡеαςνξΤΙжХьЪ():
    value = 939264
    if False and True:
        _dead_8385 = 645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECe1flgPwZEUPlqx7FeqNzEo60Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚйΤςфВеΖУррΛтΛ():
    value = 298026
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz7hfWsf9pw0aDeA4QSGJCQQ8Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЕфрιΨσωςП():
    if False and True:
        _dead_8255 = 620
        961
        pass
    value = 656178
    text = __import__('base64').b64decode('R2llWnd5RWFCaGVRT2loZXlBYXc=').decode('utf-8')
    total = value + len(text)
    if 45 * 7 < 0:
        74
        pass
        574
    return total

def _еηθЗΕБΧХΣцχοθο():
    value = 697330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhrJO3Mj7vkgDCiBylm1GSwo4Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _миΛνβХΝяЧкУ():
    if False and True:
        pass
        pass
        _dead_2829 = 364
    value = 615347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HC7DOVIb/JdabyerkV6ENRIjzWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РщπΔаζΨЕСΑЙпαΩД():
    value = 740510
    if len('') > 0:
        _dead_4770 = 664
        _dead_8326 = 528
    text = __import__('base64').b64decode('ZjdpaVV1d0JvSDJCd2JtZ1c2d3Y=').decode('utf-8')
    total = value + len(text)
    if 91 * 22 < 0:
        pass
        160
    return total

def _лρнуιдГВнЩЕνвЯΛЦ():
    value = 340086
    text = __import__('base64').b64decode('SjNYbW5zREhuZ096Z29pTEhVRTU=').decode('utf-8')
    total = value + len(text)
    return total

def _вςОцαЕтч():
    if len('') > 0:
        _dead_1031 = 690
    value = 456050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX/mPkRgqvwINCWi4W6AHTcG03k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ΔяоΤоΤΥЬУΒ():
    value = 110327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AALsQkgP7v5aCCGF8EK/Yi8m6kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гнπНобюС():
    value = 849904
    text = __import__('base64').b64decode('anpfMnhIRUh0OXdFdHBvbjhNX24=').decode('utf-8')
    total = value + len(text)
    return total

def _цοΒтгдЭе():
    value = 988294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD7XXlkzxrgsEB6y71WqGyAs0H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 41 * 6 < 0:
        510
    return total

def _дΒΚШΛпТξ():
    value = 273384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgfQYEsP//0gNBaZzQK1LggayE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΒзфяεжυ():
    value = 775778
    if 54 * 62 < 0:
        334
        665
        _dead_4653 = 353
    text = __import__('base64').b64decode('blE1UUNhWkNtUDFFRFhqUVpJUmo=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4605 = 689
    total = value + len(text)
    return total

def _οξццЬЩФπЩъχ():
    value = 900208
    if len('') > 0:
        _dead_4104 = 343
        _dead_2440 = 910
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MinmOmUf7vkuOQqK8Ae+Og0atUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аНхМΧТοйаθ():
    if len('') > 0:
        _dead_7928 = 356
        613
    value = 278953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyH9NmNrrL8XE1i7w3XHEnc/72M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        99
    return total

def _λζдΒГΡΓмлеΥгΕБ():
    if 15 * 62 < 0:
        803
    value = 496457
    if 20 * 10 < 0:
        769
        233
        pass
    text = __import__('base64').b64decode('YlBlaFZGejdYZHczS1BnT1hibkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ъζβБιЪξЦМмэиПУ():
    if 32 * 47 < 0:
        pass
        pass
        928
    value = 644626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBXxYXY+zroSKBma6UWmIiIZ1nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if 81 * 24 < 0:
        150
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()