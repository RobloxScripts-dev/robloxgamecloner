#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _щΜинВλгжιΙШπЕтΡ():
    value = 224095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fn70bFQu6LopEhX37XqdOyF5tGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΘΡЕЦНςРЫΨкЛΖτη():
    if False and True:
        pass
        _dead_4534 = 742
        557
    value = 954106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRnBa38f1YwZbBqi4XHHJxYB93g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΨПΠНψпδжΤΘрК():
    value = 148327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQDJP0It7aI5KjycxX2nFhU2yEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гТΖтφНαΗЬχζИΧ():
    value = 160213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCvrPmkG8owzHS3w/3mJIzcaw0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΣθδΟъΚхмОПο():
    value = 426743
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axfia1M88IIAPVqI0libHg03wno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 12 * 22 < 0:
        _dead_4204 = 63
        _dead_7203 = 227
        _dead_3588 = 378
    return total

def _ТрΔУΔджΦьζβЙω():
    value = 408719
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz/XNmQ9+qcyYyGm4mK+BQ8F6G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _щЧиибЯзΨ():
    value = 581466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAf8XVsxrKpXCRuc4X2eBAMttmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΠИεζмСδП():
    if len('') > 0:
        608
        _dead_5546 = 357
        pass
    value = 114031
    text = __import__('base64').b64decode('d1pGQXJUc3A4aXZ5YVJVN2g0YzQ=').decode('utf-8')
    total = value + len(text)
    if 8 * 28 < 0:
        pass
    return total

def _ΗλζгπΣΠФО():
    value = 887071
    if False and True:
        _dead_8374 = 653
    text = __import__('base64').b64decode('WGgyR0UwNE1YdXdXRjRRT1pob0E=').decode('utf-8')
    total = value + len(text)
    return total

def _иφИσщВΩΟб():
    value = 666447
    text = __import__('base64').b64decode('YmRrNlFObkZadXdkZF9CZUNaOVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩГΜФρьΤЙΑНБΕррвЕ():
    value = 27823
    text = __import__('base64').b64decode('WHRvbVJORFlVRFNsdDE1RWxNTFc=').decode('utf-8')
    total = value + len(text)
    return total

def _εГЪУФΝТΦπ():
    value = 962159
    text = __import__('base64').b64decode('djlUaXR1aWVja0ZqdU9zam5HNEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯλΣχиΡХΗЫπιΠВУβ():
    value = 621307
    text = __import__('base64').b64decode('Z1NVcjBJOXJFVDJucVZadUFpbWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔжФГЦНшτРш():
    value = 727247
    if False and True:
        _dead_4414 = 789
    text = __import__('base64').b64decode('SmJiUURZdlhZS1RjRlZaSWVPVl8=').decode('utf-8')
    total = value + len(text)
    return total

def _сΝЯЙΒЕΟΘΝ():
    value = 156362
    text = __import__('base64').b64decode('ZXJyUXpYUzBTRTdRSzdoSnBlZTI=').decode('utf-8')
    total = value + len(text)
    return total

def _хеξΔζЭςТΩ():
    value = 57097
    text = __import__('base64').b64decode('a2hQYkVWQ2ZqY1BoQ0g3NWh2aG4=').decode('utf-8')
    total = value + len(text)
    return total

def _γΝυвчнσызς():
    value = 937914
    if False and True:
        429
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASS3SlpvzJkxKB6XmH7AHgoW4FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΞΔφЙЭΦυμβЧπ():
    value = 29485
    text = __import__('base64').b64decode('SGtzS2ZjZHlJMUhKdDlIbWhjVU0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        7
    return total

def _νршЦБаμЩроΡΕРН():
    value = 943781
    text = __import__('base64').b64decode('T3FEYmVCV0xkUVNfckZ3b2p2eEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΣοιΣΜЯкЙΖ():
    value = 60533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih3WN3w26IkOMgX0/3+FbXYY0mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΣБηЫЭΧХφσЧЖШ():
    value = 590631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxfKXl0UqvAnNgKgwmGmMgM740k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΟРΒΠΕЗΝρЙ():
    value = 231630
    text = __import__('base64').b64decode('dFZ1OE85ZVN4ZXNVaEkzNXdjYms=').decode('utf-8')
    total = value + len(text)
    return total

def _σΖшΡΘЬγнΦΑΥ():
    value = 418893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FH7DQmAS+r8sNxWp6lmGYywB/kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛЬуοΤЦщСяΩΞэ():
    value = 783183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwncanYwzq8MEweJ/AKYNh93y3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЭΓΡΣλςж():
    value = 423131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyfWZnId8ZxRMAvzxkyEPi4jslc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1001 = 472
    total = value + len(text)
    return total

def _ΧЖΡЩΑХΤъХСΜнАИψ():
    if len('') > 0:
        _dead_7005 = 768
        144
    value = 856384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh22VwIf9rAEayK15FmqPX0Ax3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оψЗЗζЛГκгφδн():
    if False and True:
        _dead_9209 = 492
        _dead_8401 = 159
    value = 354756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXzPQAI/5rI1Kj6h93GWGiEi7lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αфΙΥΩнБΓΚШΧГвэЧ():
    value = 934379
    text = __import__('base64').b64decode('Y0NTVGpNaFQwd0RGZ0ZpRzdWY3g=').decode('utf-8')
    total = value + len(text)
    return total

def _юΚΖΠдΠЫΓΗЩцΒδΦЕ():
    if len('') > 0:
        _dead_4455 = 377
        508
        pass
    value = 661476
    text = __import__('base64').b64decode('S3V6YjF6TDBGRTZERWpRazRMem4=').decode('utf-8')
    total = value + len(text)
    return total

def _ζрмβКмμйμωжυъоΡ():
    value = 475596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxrBZUgJ7okNCiK25myWAyd89Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΨаЦГРИζДΞτνЧзН():
    value = 234405
    text = __import__('base64').b64decode('a2RvZWJkRndoc2FOTkJLenJTcHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯτюъИэШГφгΧшШνО():
    if False and True:
        447
    value = 285036
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQHHTHwx6q0JDhWzx1SxZBw7t10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьеΞНсШиБЕсШьЧΞ():
    value = 403997
    if 81 * 80 < 0:
        293
        pass
        _dead_4703 = 821
    text = __import__('base64').b64decode('ZFYzOWlNMTNyV2xPWjRCeVdjQ3Q=').decode('utf-8')
    if 57 * 96 < 0:
        pass
        867
        760
    total = value + len(text)
    if 81 * 68 < 0:
        pass
        _dead_1603 = 642
    return total

def _ЪГЭθЩЖюГ():
    value = 678343
    text = __import__('base64').b64decode('VE1GRnhTbk54TEY1b1MyMGNqMXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧδΚρФКχσπ():
    value = 571847
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBbyO2cDrZEsGyu26WOBMQ0HvFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 71 * 84 < 0:
        pass
        _dead_6886 = 23
        _dead_2404 = 855
    return total

def _ΟэшВВМУЯΣΞВйΖй():
    if len('') > 0:
        pass
    value = 184982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3vCaWVr27IPAwGTyn+3LB87/UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μφκΔрιфΓΞЖΛΨфΕ():
    value = 390277
    if False and True:
        995
        pass
        _dead_8397 = 138
    text = __import__('base64').b64decode('Um1tYXNCYld4eVJWR2p0d3dyNjI=').decode('utf-8')
    total = value + len(text)
    return total

def _уΜςеьΙΒаΒ():
    value = 531244
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwD2O3wrp/gSDFaNmwC+ICwu/F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΧγЧЭΦηΨШэφАΡ():
    value = 699104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzjyQEE67vEUPTChwnm4DS9+8Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1708 = 981
    total = value + len(text)
    return total

def _ЧΑпΩφΡЧΠЭΔР():
    value = 298354
    if 20 * 46 < 0:
        _dead_3204 = 166
        _dead_5118 = 256
    text = __import__('base64').b64decode('WE43ZGluclByT3REZndKcXo0amQ=').decode('utf-8')
    if len('') > 0:
        682
    total = value + len(text)
    return total

def _ψзжжφЪТς():
    value = 167888
    if 24 * 82 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSO1XEE4/LkkLhWZ2UGIMxIn/Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σεщζЦαΠαе():
    if False and True:
        682
        pass
    value = 316621
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('ZGM0NlppMjh3dG9QYTFoZ3VYUVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭяЭΒеЬΦлΒγβ():
    value = 573430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTeyb30B9qZUGA2Qmn+IHzULylw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εеυκοСфБ():
    value = 578204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTzeTUJo740GNSyR6kWCYAwq4jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЬαΧОΚξкΞЧΨцΩτΓМ():
    value = 174274
    if False and True:
        pass
        pass
        613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBrAPV8AzoNTOFmK/0yCGhB8xX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6431 = 755
        _dead_5398 = 17
        969
    return total

def _ξλыαΓΝθвчьцюЕ():
    value = 520956
    text = __import__('base64').b64decode('dlFIRTdqcE55Q3VrYUg5S2JJMjc=').decode('utf-8')
    if 49 * 80 < 0:
        pass
        _dead_7730 = 941
        227
    total = value + len(text)
    return total

def _пяиΨИθΥΦтακд():
    value = 663515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwHTRVggrrwQED7z2XGfDjYFw3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚιиχΜνЭΙΖШСИ():
    value = 365980
    text = __import__('base64').b64decode('a1FBeXJnNlRBUm5Vd3hxbjdIM2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _εГрАКηЪκπνЪχδ():
    value = 235275
    text = __import__('base64').b64decode('VjI1MXY5ZzZENkRqZ1JTS0Y0SVo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        440
        557
    return total

def _ρдПΓцЙΝεЖτяФЫ():
    value = 704736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IibsXFo13PoBFl2m7w+iPncm7Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        174
        pass
        pass
    total = value + len(text)
    return total

def _жКеΒκЕмαаφЙΕ():
    value = 632669
    if 81 * 58 < 0:
        _dead_1496 = 822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAHbW0koyqosHiOEzUCeYyYmwno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        272
    return total

def _пЙΛΔЫμйΦηц():
    value = 857333
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By3sdFoIqqIGNTj130agITYu/Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λеоΔБкЕΛЛ():
    value = 928671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjfhOXkz/PEkbgj65WWiPD9+1Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТηЩТпΓЫзФдСφДрэ():
    value = 115192
    text = __import__('base64').b64decode('WmdFUVdGMVRpcVg2WkdlbXlnRUw=').decode('utf-8')
    total = value + len(text)
    if 61 * 94 < 0:
        _dead_9661 = 380
        pass
    return total

def _ШлжБΑΟЗΑс():
    if False and True:
        674
        _dead_1840 = 810
    value = 289276
    text = __import__('base64').b64decode('YWp0bEMwWFdsNWt2bFM4SzNGSlA=').decode('utf-8')
    if False and True:
        _dead_8870 = 231
        619
        _dead_2945 = 546
    total = value + len(text)
    return total

def _ЬБДДΝΚжчΘ():
    value = 37314
    if False and True:
        0
    text = __import__('base64').b64decode('VENPMExZVDdoOFNSN1BlbDJiRzQ=').decode('utf-8')
    if 24 * 99 < 0:
        337
        _dead_2520 = 528
        pass
    total = value + len(text)
    return total

def _ЯλΕЯβмεδоНЗсНΛЭτ():
    if 82 * 54 < 0:
        910
        pass
    value = 134220
    if len('') > 0:
        320
        _dead_8404 = 266
    text = __import__('base64').b64decode('Q280YW5PVndBQXlxM0Fhc3QzZXg=').decode('utf-8')
    if 47 * 26 < 0:
        pass
        _dead_6855 = 907
    total = value + len(text)
    return total

def _ζκлзσЭубБζжФвιгД():
    value = 634569
    text = __import__('base64').b64decode('ak5COWhPWTBuMl9SVGM5RklpRFg=').decode('utf-8')
    if False and True:
        658
        pass
    total = value + len(text)
    return total

def _ХζБШдцКРхКРИ():
    value = 629691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M33xQ2dr2ZEQAyulykLFCz8H6j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гужЗλρяΡΖΓЬ():
    value = 820159
    if 42 * 94 < 0:
        761
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSqwekE70osKIiylwmm1ISQ8x2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5770 = 897
        _dead_9093 = 831
        996
    total = value + len(text)
    return total

def _ОγщШςПяΝФΜ():
    value = 151116
    text = __import__('base64').b64decode('SFhvVE8ybkc0VGg0SDZRMWJ3WW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ъгΖшшμωуκ():
    value = 363762
    text = __import__('base64').b64decode('RVpnbmtGMFNuTnlBUnF6SFJUUnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞэΒидΠуэ():
    if False and True:
        301
        _dead_1371 = 790
        _dead_7094 = 984
    value = 196215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyvJN2Jv1b8AIDnx2XW/IXMgwUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РυνΟτпфОяеΥΕыТΘ():
    value = 975307
    text = __import__('base64').b64decode('UjAxZW9BZ08xV2EwRmY0RGlObks=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _φοπОхΡΛкΜνйбъλ():
    value = 295628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBXUQWg96o8gDxq07kzEYx0Mz1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 15 * 61 < 0:
        _dead_4970 = 220
    return total

def _ОЦЗЧτΗяγΤИДΡКчχЬ():
    value = 986543
    if 36 * 22 < 0:
        _dead_6504 = 12
        737
    text = __import__('base64').b64decode('Y2dBTExMX2Q3UzJFdUJId0tfN2c=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        873
    return total

def _ΜΓЕрΨщΤОпМσх():
    value = 342247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyzweHA2xo9SaQGs0l6RNQYLtWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕИΡЪХφсВφкюЛИα():
    value = 890825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX3QaAAv8YQKNiScx26TMw8BwXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        919
        616
    total = value + len(text)
    if 2 * 81 < 0:
        _dead_9670 = 188
    return total

def _СχНοьжщΧЭωШο():
    value = 680678
    text = __import__('base64').b64decode('UzZQYW5kQnZyYWNMSEVjZ3I5V3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙФмψΕτСΥю():
    value = 877822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESzQYmgSro4ENTjznUOXIQIZxUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψαАвъМЛсХΔюΤпЧ():
    value = 513726
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwL2V2hv/IsrLyWI3weFMzIttns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙσмюσуρщбхΣ():
    value = 134516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQDbRHU15qsXMFuZyV28DBZ79Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηкнιΩΑψξГ():
    value = 110865
    text = __import__('base64').b64decode('WjJlcHNrOGRDbVJWQncxejI4YW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΡкТΦвугΧ():
    value = 56657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx/+YEks+akCFj2cx3yIDAcQ73s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лωζюлчкмωσМапζπ():
    value = 299290
    text = __import__('base64').b64decode('RGtNX2xQMFpjQXpiaGNRRTd3RzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕφδΟαμФГ():
    value = 36862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESnMdHk4ppIrOAOMx2GgPTMk0GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АφεΛРУΩдИВ():
    value = 421146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzrHR2EcrKEwPgCQ7U61MDIX6Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δМЖφΞβплпвβ():
    value = 954419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD/ybWYv0KkpCBah63SXAAI5znw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΨЭφζοВлМИ():
    value = 454812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy2wVFxu2voGEQOp+n6aHw4Bz3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 57 * 93 < 0:
        666
        838
        pass
    return total

def _ΞΟГКжΛιаθжυЛзЖ():
    value = 683897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn3QWAMJqoAIP1eL6gavFwEm1Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъпбшСолΔЪκнτЩη():
    value = 745062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3fAO0cs1Kc5ODeg61yxPCc+xXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬвыЖМчНΣТаΤτ():
    if len('') > 0:
        pass
        pass
        23
    value = 111786
    text = __import__('base64').b64decode('Y3J3YW1GUFp3VUdlUDBNeFB2UTA=').decode('utf-8')
    total = value + len(text)
    return total

def _МλНБσΕьанЖБвы():
    value = 549910
    text = __import__('base64').b64decode('Y055aElSUHp4bVppRHRKVXI0VXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚшθСДучкλКпσфΚе():
    if False and True:
        _dead_2772 = 658
    value = 609310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQjeO3oG7P9XMxyNmVqFHhYWsVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ючΞЙΦлацπυζσ():
    value = 5678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCjzdEFr6rJRKiio6mafOwEezHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΣгτΨζΠξВλчΠ():
    if False and True:
        _dead_6553 = 678
        pass
    value = 184538
    text = __import__('base64').b64decode('QkluM24wV092b0d4ZkhaN2JXZTA=').decode('utf-8')
    if False and True:
        _dead_8742 = 476
        _dead_1895 = 999
    total = value + len(text)
    return total

def _ΥТεγρΞφСЫж():
    value = 591327
    if False and True:
        _dead_1767 = 935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX7ifmIa8ZoAEQW1kVGHbTQ8sGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΦшЫКюθЕжαΗтΗжΕй():
    value = 114664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTbQRnJv7rgHbzeo3gSnDSQ4xz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 75 < 0:
        _dead_6247 = 845
        397
        _dead_6398 = 218
    total = value + len(text)
    if len('') > 0:
        pass
        141
    return total

def _παοΛоПтиξΖфφων():
    value = 538859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSSwRXMhwftXHSi0/2aaZSYZ4Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юγЧэγИιиФζт():
    value = 106502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCX8d340+Lo2Igew4QSGEA4dy3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        586
        pass
        pass
    total = value + len(text)
    return total

def _рйхЭхяъΙьρщΠγнг():
    value = 399006
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQXHan9o6vEFFTX263zCBnU87m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 87 * 37 < 0:
        pass
    return total

def _ТΖΥΕΝмΔденуΡнΤН():
    value = 745866
    text = __import__('base64').b64decode('eDlwb2hzUlpvdDREV280WDFDSWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟУраНΨξΛЧ():
    value = 277576
    text = __import__('base64').b64decode('VkNrNVZ1eEF4WldZcThjWWdBdkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ВлΙВзэЛхрΞПЛυ():
    value = 142795
    text = __import__('base64').b64decode('VTJmU2xzSnp0SGoybWd6cXlXMUo=').decode('utf-8')
    total = value + len(text)
    return total

def _φЩрΥωЫяэΦЮρДωЗ():
    if 50 * 15 < 0:
        _dead_5001 = 469
    value = 883347
    text = __import__('base64').b64decode('eUdOMnplQUp3TnZqWTN5ZDgyUHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟПΙяψжΡΡЦ():
    value = 649761
    text = __import__('base64').b64decode('ajJscnNiaUxxQmpzN2NVNnBEVFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ъλυЦΒψжлЙπ():
    value = 210124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzfNQAdq96UgAzyCnVKUHi0pw1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μφЖπΖΩΥρτоω():
    if len('') > 0:
        516
    value = 160797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwToOnIX9fkVYg6rw1fEZXMqyEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΗφскПъЦВ():
    value = 146108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgPAbV9u2ZhbNzD1mmyqGT8p4lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΕиЭΗвζν():
    if 18 * 59 < 0:
        pass
        979
    value = 328703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3bGe2gfypgaAAG53w+lLgx+sV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _вσшЪвαфу():
    if False and True:
        530
    value = 195813
    text = __import__('base64').b64decode('b21WaVNkT0xXdFk0dDcyUmJyWDg=').decode('utf-8')
    if 20 * 45 < 0:
        507
    total = value + len(text)
    return total

def _СЧнλяЧΙχйТλΜОΒъы():
    value = 969465
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQW3OHoVyK43aiH6yVi7MiYq43w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΗХюζονΒуЩ():
    value = 36811
    text = __import__('base64').b64decode('UUxtMEZzREZpczNtMWFoZGFyRW4=').decode('utf-8')
    if len('') > 0:
        599
        _dead_8794 = 480
    total = value + len(text)
    return total

def _ψГδлξСфСΑ():
    value = 984627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DA2zQHIX1bkCAFe73W6YMygo6jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 64 * 47 < 0:
        _dead_8986 = 390
    return total

def _ΒТΩНΩмμУДδВωюΤβщ():
    value = 485789
    text = __import__('base64').b64decode('VGZwcXRUYTBpcGxVTXhySzNWdHQ=').decode('utf-8')
    total = value + len(text)
    if 54 * 94 < 0:
        pass
        pass
        _dead_9709 = 746
    return total

def _ЕΜаΛΘаЮсΠК():
    value = 146931
    text = __import__('base64').b64decode('eHRDNDQ2TVgwak80X0FfV0NCUHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ζРПтεЯбаΞ():
    value = 51756
    text = __import__('base64').b64decode('Vmp0UFVQUzJBa2RBNDhKVVhnWEs=').decode('utf-8')
    total = value + len(text)
    return total

def _κгЭОЬчΘдΠлηСКΣ():
    value = 524620
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS7pbGc9yPsnDBmI61DFEi4GzUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κЛуФνυΞЮπΔЮυ():
    value = 696347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDa9Nkk+54sBKxeznFGWEhF74VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νуγссыьχХьфеν():
    value = 268448
    text = __import__('base64').b64decode('TXc0NTVLRlVRRDd5ekwzX3lPbnk=').decode('utf-8')
    total = value + len(text)
    if 34 * 55 < 0:
        763
    return total

def _цΒоηΑкЪем():
    value = 271453
    if len('') > 0:
        264
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DizwVwAt8IlSLCec5mK2OCwltGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘШκвьЩЗъΑΝθ():
    value = 28024
    text = __import__('base64').b64decode('a21VNENXZkFBZXlua0xFOEpMQ0E=').decode('utf-8')
    total = value + len(text)
    return total

def _цУΤАхдΤрΚβБ():
    value = 370406
    text = __import__('base64').b64decode('dmtFNlZTck82OXdLQ1ZmZHlNcG8=').decode('utf-8')
    if False and True:
        627
    total = value + len(text)
    if len('') > 0:
        _dead_4886 = 212
        pass
        216
    return total

def _ιξοеЛГкοЮτρ():
    value = 885492
    text = __import__('base64').b64decode('RlppcGJpcDF4aVU0UUxNQ0xBWVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _βГπЪΔшеЗ():
    value = 69215
    if len('') > 0:
        179
        _dead_1770 = 197
    text = __import__('base64').b64decode('dlM5cUN3SlNYS2tWV2lEWWw5VjQ=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        922
    total = value + len(text)
    return total

def _λПЛφАлги():
    value = 988792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg3UT2gL8YkZFFazzGyzIx8Y1VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3768 = 124
        388
    total = value + len(text)
    return total

def _ЬэφеΜΘεАЛωΑьςОЫ():
    value = 703601
    text = __import__('base64').b64decode('RmF4MUxXNFVQN3p0RUwwTUFqZ3I=').decode('utf-8')
    if len('') > 0:
        _dead_5524 = 986
        pass
    total = value + len(text)
    return total

def _аЬЖЗΨΥжЙυξыШΑβрЮ():
    if len('') > 0:
        pass
        244
        _dead_4399 = 626
    value = 667822
    if False and True:
        56
    text = __import__('base64').b64decode('ZlFkRVhVOUE4UXdjVXNVeUN6MG8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        792
    return total

def _кθзжΒΗΦЭЙВСьЫГЩ():
    value = 422098
    text = __import__('base64').b64decode('eU9TV3phOGg4QjFqSmhCN1dSYXc=').decode('utf-8')
    total = value + len(text)
    if 34 * 40 < 0:
        529
        827
        786
    return total

def _ЬзЩλчΤΤэЕωш():
    if False and True:
        pass
    value = 216001
    if False and True:
        _dead_2770 = 236
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASrpegIq54kyPCub41qENgEt3mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λФγИΒяςξе():
    value = 820612
    text = __import__('base64').b64decode('RW9scnhVcE9neV9Rc1dCaHZDeGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕψΤчΔНЦИЛЫ():
    value = 128457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAa0RVwO0LoXIBunwVO0ZR8gskU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νЮтΙИСХυκ():
    value = 336395
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izi2TWI48qoPKDCC3G6+An09zXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        850
        _dead_4188 = 34
    total = value + len(text)
    return total

def _ШπξтЦКΡШушΘЕЛ():
    value = 927731
    text = __import__('base64').b64decode('eUpmSUFGdTdjc1NieDkwaUtjc0s=').decode('utf-8')
    total = value + len(text)
    return total

def _яйκэюΕΨσφИΦеΥпεа():
    value = 822799
    text = __import__('base64').b64decode('YU00MXRON1NOUkxjalJJSU5MQ0E=').decode('utf-8')
    total = value + len(text)
    return total

def _χЗЪлμΖуюΞЗφвΘ():
    value = 279641
    text = __import__('base64').b64decode('TFZndEtpTDFvdlU4MFN4aEY0YzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛуΒВΒΡιбΦ():
    if len('') > 0:
        315
        _dead_8106 = 489
        _dead_8615 = 709
    value = 745055
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnbOa2gox/glazua3EOxZg8LyUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΓуЩНЙиАьФхх():
    value = 771745
    text = __import__('base64').b64decode('QWcwS21CQWFBZzg2TDZmcHNNbUI=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_8134 = 418
        247
    return total

def _БθСФАИЬмυ():
    value = 498033
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JznMal0M3bosKSGC/WPJZxp981Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 29 * 28 < 0:
        _dead_7082 = 49
        59
    return total

def _σφпКΑφАρ():
    value = 420495
    text = __import__('base64').b64decode('RmdhX1dFdHh4cnlwWXZpbUVzcEo=').decode('utf-8')
    total = value + len(text)
    if 42 * 82 < 0:
        pass
    return total

def _еАЧпзюΛςЛСэΞχΛют():
    value = 650148
    if len('') > 0:
        956
    text = __import__('base64').b64decode('WV85XzBzdDAyYkk5Y2pDalkxUHI=').decode('utf-8')
    total = value + len(text)
    if 40 * 24 < 0:
        _dead_8345 = 119
    return total

def _ΞбЮθΒЗΣХαΕиШ():
    value = 407584
    text = __import__('base64').b64decode('b0JoUzBfUXpoQnNCOFUyTEJpV2k=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        439
        288
    return total

def _ЧΠЭΒэЫФп():
    value = 972087
    text = __import__('base64').b64decode('Z0ZYYm5rYTFfd0ZSYXFFdWRmV3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _νΒЦψΕлΑвΙκГмΔΝЯφ():
    value = 790366
    text = __import__('base64').b64decode('d1BQeGk4ZDBYd0FZd0t2TTkzQUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΖЫмШЧшΝω():
    value = 945287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgXqQUJtqZ8qDCKVng+UFzUrsWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7906 = 186
        _dead_1148 = 818
    total = value + len(text)
    if len('') > 0:
        _dead_8244 = 835
        49
        pass
    return total

def _ΡЯэБΜХНШуΔδшПΞΩ():
    value = 418156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjjpQFth8fwiMVyZ8GGUZR07xWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фιтΦΣсκοУ():
    value = 927798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTrNPHsj1pA2PBf141CmPQIQvHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сЙФςλαПφхφЛΞЭ():
    value = 556077
    text = __import__('base64').b64decode('bWNMNWV1aFg4bnk5ZG10aWRpT00=').decode('utf-8')
    total = value + len(text)
    return total

def _σΨниАΨηΓНμЙС():
    value = 477532
    if False and True:
        _dead_3144 = 718
        831
    text = __import__('base64').b64decode('eUZDQ3JCamtRbUdGc2I4cmNVU24=').decode('utf-8')
    total = value + len(text)
    return total

def _эμАЕθЕπЮГХ():
    value = 802911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHfiOFZoqrksKh/1zw+6AxN9/Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σιБеЪЩКηΝΖ():
    value = 208905
    text = __import__('base64').b64decode('bmx5UDFhMmM5YWJXUnozMXdEMjk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5541 = 965
        pass
    return total

def _шГθвЦГФтВΒΕЩ():
    value = 306566
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSG2V1Yz1K0wPyiTwwXEERoowkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СμрΝΕψβяβγΨГ():
    value = 831536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQLSPEUPxvo1Fly24VnBHncX9D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΝξшΤμдцηΠбЩσλд():
    if 84 * 28 < 0:
        pass
    value = 952827
    text = __import__('base64').b64decode('bFdMdVhxdUxjdWVjaGRnRnhkeE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΧавκЖТс():
    value = 345441
    text = __import__('base64').b64decode('U0pwWHA1bHNyalQ5R3RpczJ3c3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΑψΖлΙΣпН():
    if len('') > 0:
        _dead_4848 = 454
        326
    value = 24234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy72N24/8ZkwCjinwA+REjEixTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δЙНнюСчэйΙΙχ():
    value = 371073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDrJeFga0oYrCDasx0+lBR0ayXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞКΔΤиЦЯΨв():
    value = 961722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCDFTUhq66Y5ESeg+V6TPycF408='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        743
    total = value + len(text)
    return total

def _ςШЫкΜкпΒщζχΦ():
    value = 912912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXjgOHIP8pgAYyKQ0nG/DhEV8j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οфςТыηαчЪ():
    value = 857311
    text = __import__('base64').b64decode('YTQ5UjVHMWRxZldEMVd0YzBiSl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕяυΕдμАΧΣаЕЫыЭ():
    value = 492258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgLbbVoJ5vkCaFuin0CfZyMW1lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оβЕγΠПνафι():
    value = 882086
    if len('') > 0:
        _dead_6175 = 316
    text = __import__('base64').b64decode('c1RjeDhhUkplQ0tBTnI2TnJ6aUM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        229
        76
    return total

def _ςΦПΞΜнКπФ():
    value = 727139
    text = __import__('base64').b64decode('SnhCSWJ5eFhWVmg5bHNQRUd4NXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩвсЮΗекλπЩ():
    if False and True:
        pass
        _dead_9581 = 182
    value = 573533
    if len('') > 0:
        504
        _dead_1536 = 240
    text = __import__('base64').b64decode('YjNKcUMyREJPWnJFczdValdHekU=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΒζΜпηεΔΩΛΓМл():
    value = 918743
    if False and True:
        pass
        _dead_6850 = 565
    text = __import__('base64').b64decode('REZGaGd5ZE50U2F3c1VrdlpnTmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _эγΩηΣсеМЗтыкнее():
    if len('') > 0:
        95
        _dead_8627 = 280
    value = 478813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F37KN3sh65wXNBmo8kKHbAZ96W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _вΟъδμЧυюηγνм():
    value = 868774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhryRGcQ36I1LQ6x4W7BZyA26Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δСКΨπφωГКе():
    if False and True:
        pass
        129
    value = 77322
    if 59 * 46 < 0:
        _dead_5718 = 410
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHjLRwIf7fw5NBuK3m+oAxx6zFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        375
        17
    return total

def _ЕУνНπбΠΝ():
    value = 822068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRnUWEUS0fo2Pw2byluEPDR2sGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УьνУИμΓΣΖЕκΧ():
    value = 506604
    text = __import__('base64').b64decode('QkFrWnhGTkllWVZzM1ZiWmZRbmU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΤψОαЖΜйσΨ():
    if False and True:
        pass
    value = 350593
    text = __import__('base64').b64decode('c0loVUd0MGRPbWliOFZzaVdzc3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕСуйШВвЙию():
    value = 707273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXvTRlMv3foaPyGl2HrFbCQn1HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шωеπЙПαΞВαчμх():
    value = 297158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx63fAER8/wsMzy75l+eZxAbt0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΤβζΗзλЭШΒХФΣπЦ():
    value = 136280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiX+fHtrqp9UI171wwKjJzwr7EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КрЗηЭκЫΩуΦ():
    if 41 * 90 < 0:
        409
        pass
    value = 111294
    text = __import__('base64').b64decode('VE9Kc2U4SV95a2NoYVgxbTVWQXI=').decode('utf-8')
    total = value + len(text)
    if 46 * 86 < 0:
        _dead_3556 = 984
    return total

def _ΣΔВΡΜΥΗσι():
    value = 361264
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex3TWn07zZchMj/36XC+ITMD/E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еβзκЮаΗλ():
    value = 788577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwjNf2Ayr7kWBS20wQG6JAcM9n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аХцΖφβэτΖσфιςО():
    value = 934605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwHxZnsT6b8VPyaP+FGfDRo2sT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρξΖигбуПШМПыΨНεр():
    value = 964219
    text = __import__('base64').b64decode('ZUJUbHpLNUhjRUpfbWoybzQ2OXI=').decode('utf-8')
    total = value + len(text)
    return total

def _κшэоςЬΤμμРμ():
    if 68 * 98 < 0:
        95
        pass
        837
    value = 209216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EijJZl9t8KYgbBeZxEGBDHMo/H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2292 = 759
        pass
        pass
    total = value + len(text)
    return total

def _ъσΑΟΘяУΒЮΡ():
    value = 867314
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy7meEIN6L4aayKGxE7IIwIVyEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шЗщрΥЖΚε():
    value = 127784
    text = __import__('base64').b64decode('REdSOGQwSTA5THdyalNrODlfeG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙВΠзиςДΛЛΝвшΠбη():
    value = 405992
    text = __import__('base64').b64decode('ck8xN3lESnZnTTRScW5KWDl0c0I=').decode('utf-8')
    total = value + len(text)
    return total

def _оУδоΙЬЭΕζΦБ():
    value = 862430
    if False and True:
        pass
        _dead_3107 = 613
    text = __import__('base64').b64decode('RE12eWIwQ25LT0s1MWVnTURqZkI=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_9825 = 344
        pass
        88
    return total

def _БФΕναЪшο():
    if len('') > 0:
        _dead_5196 = 716
        224
        pass
    value = 586743
    text = __import__('base64').b64decode('VTh1NDk0VmxIYWNNa28zNFpJM1k=').decode('utf-8')
    total = value + len(text)
    if False and True:
        789
        pass
        348
    return total

def _ΘШλщяпνЭА():
    value = 39151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3q3dwJuqrsyMFmt4UaGLnI5vTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if False and True:
        pass
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()