#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ζφъθΧυПΩ():
    value = 365461
    text = __import__('base64').b64decode('bHJqenhhVzI5OHc3dUJmWVMxQkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ηαЧδΠаφрШыα():
    value = 907318
    text = __import__('base64').b64decode('RUtlVzJRS2tsalBuUk9QN0NrV1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫРмйαсэζ():
    value = 671697
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR23e3kOyakgFyO2wGeHAA0czTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξηчСтΣΘΦδ():
    value = 205161
    text = __import__('base64').b64decode('clJ2U0NNMVFjZ0RhSUpTUW1td2s=').decode('utf-8')
    total = value + len(text)
    return total

def _АвМΥвΖпмооРβ():
    value = 763151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX7tYVkb6/8oNDal20KHMCp8614='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_3119 = 402
    return total

def _РμДΗΥμΚтΕ():
    value = 235542
    if 32 * 89 < 0:
        _dead_6798 = 81
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH3ISWsx0aIJG1mr3USANXAczkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЗΕЩΦТНεчΩιЕ():
    if 40 * 6 < 0:
        _dead_9748 = 284
    value = 858786
    text = __import__('base64').b64decode('aDN2TTdaelQ1emhQaGdiTEdtYUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЯΧИсДЪэъμΣЩΜΜЦψ():
    if 75 * 30 < 0:
        499
        303
    value = 3128
    text = __import__('base64').b64decode('ZnVCTFZZTjlxMHhHZ2UwMW9lWks=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤωзЙГлΔΩЭъΟФЫО():
    value = 672905
    text = __import__('base64').b64decode('a1lKT25aSVVDS1VoVlVyeGtyeHg=').decode('utf-8')
    total = value + len(text)
    if 1 * 54 < 0:
        204
        18
    return total

def _ΙΞРτФтξАцΡχыз():
    value = 172551
    if len('') > 0:
        pass
        _dead_4643 = 897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwPOS3Ucyf0nKAySzGGmDhwn7kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΝтрΗχьΓСΥβцλм():
    value = 266242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nnr0T1IQ2PkbHAO5nQ/DMzM98n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7140 = 806
    return total

def _ВΣΥκβΨφΔΠП():
    value = 337591
    if 97 * 42 < 0:
        58
        712
        632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBixNkMxr6ZXCliI3WexPDcGtmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9659 = 558
    total = value + len(text)
    return total

def _ΕШεΕпΤσыςφΖμΡМΦΞ():
    value = 70366
    text = __import__('base64').b64decode('Rk5RWkNmVTZmcmlTcG5uNkxlS1I=').decode('utf-8')
    total = value + len(text)
    return total

def _нφΟΤμщнеуСдφτГ():
    if False and True:
        _dead_8382 = 94
        pass
    value = 957777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhnHZn4+8oQQICmP+HyxOR8L1kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юхφЮΩбзω():
    value = 137596
    text = __import__('base64').b64decode('R0hnYkVlSk5DX3VXVlBJVmFuZHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ιτΕβЛРΟуΓННΩΨΦΑ():
    if False and True:
        728
    value = 52452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgXrdG4p7JoGaTaI5HqEbBAWsD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        95
        pass
        685
    total = value + len(text)
    return total

def _μюκиΓОβМФпπдφрД():
    if 56 * 40 < 0:
        _dead_2899 = 373
        _dead_8001 = 657
        pass
    value = 161342
    if len('') > 0:
        492
    text = __import__('base64').b64decode('QkV0VVpncnRjZ2Jlbl82QTlQUTM=').decode('utf-8')
    total = value + len(text)
    return total

def _оюλДπнρЛ():
    value = 420811
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRXRSVUVwaIuCzv13UOXNigIzUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _стиГηχΩШωο():
    value = 326411
    text = __import__('base64').b64decode('ajBaQmliU0o0cFg2YVlMeEU3bF8=').decode('utf-8')
    total = value + len(text)
    return total

def _МоσΨεγρъиφ():
    value = 441509
    text = __import__('base64').b64decode('WjkzMTNQd0xNZ3NsYmdxbW1sOFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨБΗцιιРцЬΜЗβа():
    if len('') > 0:
        pass
        pass
    value = 470395
    text = __import__('base64').b64decode('WVZUTzlFNGRWaTZXNEt6QkxISE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΞпШρΤСφΓЬОЕΗ():
    if False and True:
        pass
        _dead_7159 = 459
        pass
    value = 51864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDbVNmkc3IYpAhaR7VWkJSokykg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _боΑХЕиГΓΓЩГРΨω():
    value = 902422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT/KfUlo5vgQBRytzXO4LS0K8HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬжойωκЪΡыζι():
    value = 916509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgTISgBs8LtTDx2P7w+SZR8rzW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 2 < 0:
        _dead_1610 = 572
        49
    return total

def _ΣУБθςКмемПииχдаμ():
    if 18 * 38 < 0:
        _dead_6558 = 736
        pass
        pass
    value = 863144
    if False and True:
        _dead_5670 = 767
        728
    text = __import__('base64').b64decode('Q2lWazFBeWNBYnlSZGNNVG5oRnc=').decode('utf-8')
    total = value + len(text)
    if 29 * 34 < 0:
        _dead_2043 = 875
        pass
    return total

def _ΨΤЩφбрΕχΜдΨПσΒЪ():
    value = 239024
    if False and True:
        378
        427
        _dead_2941 = 143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXfOX0I6zfpVMhqF5EWfIAd34EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΕКλΘЬЛЦПΒбьλЭ():
    value = 907666
    text = __import__('base64').b64decode('TldMaFZMN3c2cDluUWRCdUtGY0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭαГаЦШюЗъςεйМдн():
    value = 802755
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('ck1mUHl2NlhGOU9vU19ZcUtvTTI=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        980
    return total

def _ЧПμΘьΧфΑ():
    value = 957555
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT6zPmsV7aALYlmy+XS/HC4E4ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 94 < 0:
        96
        pass
        898
    total = value + len(text)
    return total

def _уЭΦΡЕвОМЯВ():
    value = 407073
    text = __import__('base64').b64decode('Ym54bDZMb19VQzM0NEUwd1U3eGw=').decode('utf-8')
    total = value + len(text)
    return total

def _БЖτбλοУΥФλιοтΞιЙ():
    value = 25057
    text = __import__('base64').b64decode('ZWp3NWZXOENXalNmMkdhaXJ1NTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦШкηБЮюЭΨαЪ():
    value = 970149
    text = __import__('base64').b64decode('cXBGM0JiSWdPejRmZ3BOSFBWdnY=').decode('utf-8')
    total = value + len(text)
    return total

def _рнДπθКΧФψΦΡΕуЪΣΨ():
    if len('') > 0:
        _dead_4833 = 968
        _dead_5028 = 637
    value = 303421
    text = __import__('base64').b64decode('djhEejZWSVVfdzlHc0VsTVZ3Mkw=').decode('utf-8')
    if len('') > 0:
        pass
        631
    total = value + len(text)
    return total

def _щмуαГаНъсгцкЦбΚШ():
    value = 440396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHrGV3Yg+vk8DSyMmmmHFRoqtlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚхЫЬνчΙΛ():
    if False and True:
        770
    value = 909940
    if len('') > 0:
        pass
        594
        _dead_6716 = 568
    text = __import__('base64').b64decode('ckFXeGZVSkFVRkxkMkQ4NmhncVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ξςΔВРСΟЪбχωГ():
    value = 910940
    if 97 * 6 < 0:
        303
        _dead_8348 = 159
    text = __import__('base64').b64decode('amt0WnV5RGFnaVpyaF9COGdtNmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΘеχШкмЖΝβΖТΒНйЯ():
    value = 963416
    if False and True:
        _dead_5100 = 160
        15
        591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyDNWX1s2Y5UChix4gG4PysE3ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1283 = 515
        _dead_3053 = 347
        pass
    return total

def _яхчΣοΗИΡжВцΒΒн():
    value = 912446
    text = __import__('base64').b64decode('czhSeWN5cThheXN0d0V5SmU4QmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ПιбχΠЧτДХΙΙηΚζЫБ():
    value = 437476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRyxQ30qqoQCajqP5WOqBQ8V/Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕяβнОцρЗяаМΠΠы():
    if 21 * 62 < 0:
        pass
    value = 723184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3rFSkQQ2aIyPia6yQCyJHY40Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞЭΡЛЕЖПЗλуΝοЕТ():
    if len('') > 0:
        pass
        pass
    value = 385474
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQ7rfUsby4AuOwr3kWyAOj0Dx0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 54 * 63 < 0:
        _dead_2452 = 345
        pass
    total = value + len(text)
    return total

def _ЧДЭшЩΕΦΨвЗξЧΗΥИΓ():
    value = 978712
    if 3 * 88 < 0:
        _dead_3277 = 812
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHe0Slpq+q0uNRuuylCCYHcBtF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_3787 = 74
    return total

def _ВΟλцΡπьβαО():
    value = 829911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ai3zdksGyI8sIjnxmw6lHwIk/k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΣоЬδрЧΨ():
    value = 908490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISXeWlMB5oMnFyel7g7DGQB/szk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РЦпЗμЯεяюпЕИМЭУα():
    value = 518851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT2wQQc8/6AONDjy8HK9EjcN7kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мТХЪГΚУщγЮзфн():
    value = 140604
    text = __import__('base64').b64decode('YnZrYkpQNnhOTklCX3ZWUHZnTzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ФАΜЗпчРΝОК():
    value = 862560
    text = __import__('base64').b64decode('c1lBVnF3aGd0WmxIX3hUSWYyT2k=').decode('utf-8')
    total = value + len(text)
    if 20 * 3 < 0:
        pass
        844
    return total

def _ъΡзФЬШΙΖΦΟжμβРζн():
    value = 97563
    text = __import__('base64').b64decode('T0RLMWVMbkQzcXZobm45WkJhanc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΓμКδΖЪΞЩψΘνκФщ():
    value = 137249
    text = __import__('base64').b64decode('UlhGakJHeUtsY0owREdWUTl4NGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛкпχЦεΕЛΝпΧΦ():
    value = 153118
    if len('') > 0:
        689
        60
        982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAHXVF4d16MOMAH77HGlLBR77js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΥИΗКеφИпхАф():
    value = 11672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSD+VHU6y6QaNDm35mWlDDV2/UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        350
        pass
    total = value + len(text)
    return total

def _ЬеАиεΖЛΕςвЯΘΔО():
    value = 839646
    if 29 * 20 < 0:
        970
    text = __import__('base64').b64decode('SWtJVjhCcEwzY3M4OEQ4QU9fVHg=').decode('utf-8')
    total = value + len(text)
    return total

def _цφТΟЗμОΣπζητК():
    value = 882642
    text = __import__('base64').b64decode('QjMxekoyRXRVTVJJazJ1bHRuckE=').decode('utf-8')
    total = value + len(text)
    return total

def _μгэКТυρг():
    value = 56555
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lg3VWwgb348MODil51mvZB0I23s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝζИэψЯρξЯοΥΤцП():
    value = 183082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAa2XXNs6vgmHBytkFSpZhcmzn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΦςЯπяδλΑУΓХυ():
    value = 475514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCjBZgQDqZAmNQOnwEaTG3wk9ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖбТДМΓЖΙργ():
    value = 526927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cyu2YnwU85ELHTnwmAKzNQoZzDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        879
    total = value + len(text)
    return total

def _кρйеЩЙнвΤΕοεЪ():
    value = 661106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwL2NgYYr60Ubwuk2gKTLS4L8ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_4548 = 932
        349
    total = value + len(text)
    return total

def _ЧΦψмΩψТυЩщхΘСГ():
    if 30 * 34 < 0:
        pass
        5
    value = 918231
    text = __import__('base64').b64decode('eGRyeHV0eFp3Wl9MRWlpYklNUDU=').decode('utf-8')
    total = value + len(text)
    return total

def _μОЬωРафдьλЗФшμф():
    if False and True:
        _dead_2398 = 109
        _dead_5351 = 63
    value = 805644
    if False and True:
        364
        _dead_7640 = 700
    text = __import__('base64').b64decode('UU1ZZ3VoMWJNT3BQRWxvcjVzRTU=').decode('utf-8')
    total = value + len(text)
    return total

def _μэΦΖжγао():
    value = 964999
    text = __import__('base64').b64decode('SERXWFZQSVVLdDFhNmdRbG9QYTM=').decode('utf-8')
    total = value + len(text)
    return total

def _μЩбΗνΣВУЫГСщΒ():
    if len('') > 0:
        298
        pass
    value = 128847
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQnsTwAa9qUnGSi7zwKcZyp20ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _пОΖаΝΦНСЛуΣηЩ():
    value = 479723
    text = __import__('base64').b64decode('RkE0V2Y0XzNHb1FMSmRsMkxfYU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠαввΛΘуηзЖцΞВΣШ():
    value = 771180
    text = __import__('base64').b64decode('SWZ3cVN4YkFhS1ViaDJyU1dvaGE=').decode('utf-8')
    total = value + len(text)
    return total

def _λρκРЕΠΠСЩБψχЩΕΧ():
    if 36 * 34 < 0:
        662
        194
        _dead_1003 = 715
    value = 907271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT7DXm4V8PgPPAKQ4VWHZhY/s0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑъябтψщМШЦъеΜОВ():
    value = 535916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT/zOUMw0oARKgux3U+pLh8n1Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гбΙщюΔΘнНы():
    value = 816952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwK0fQRr9JI8Ll6Mxl+lLjM2vHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΗШΒзΘΘфьΡςψЫ():
    if False and True:
        pass
        196
    value = 832687
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRnDeFkt1fgsaCm60GOSAwEX80s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сРЛнρΙΖу():
    value = 93689
    text = __import__('base64').b64decode('SDF4ZDhQMnVlWWx3Ylo2enR6WTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΩуйδБХΒΩδΕДвз():
    if 15 * 14 < 0:
        pass
        pass
    value = 516905
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwG0W3oRx/8MLwGA4AW4GnR48zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 15 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _угжсЬщдвΨРζΦ():
    value = 478067
    text = __import__('base64').b64decode('YzdMWXNfTG9QYnVMT1huTWxwX20=').decode('utf-8')
    if len('') > 0:
        340
    total = value + len(text)
    return total

def _ΘшбвЬАюηω():
    value = 681445
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDblT15h0qYgMCePxleIOgIJ4z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пМкззΔψЛπ():
    value = 36959
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AR7tTHIbzYsSbDankGOSBXMMtFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫζоЯΡЙΑΚяυΤпωъλ():
    value = 26658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAT8OFMA3YAGLiKrzHSTYTEmzUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βЗυφΦНчНОΛυΣ():
    if 99 * 44 < 0:
        _dead_3850 = 905
        _dead_1915 = 43
    value = 820143
    text = __import__('base64').b64decode('SVF1NXpSNFFJNjdCUnBJNnZIMXA=').decode('utf-8')
    if 74 * 72 < 0:
        458
        _dead_5650 = 696
        425
    total = value + len(text)
    return total

def _НэξювοПιлАυηЕΒΦ():
    if len('') > 0:
        _dead_6523 = 441
        _dead_9359 = 47
    value = 333619
    if len('') > 0:
        _dead_3207 = 190
        pass
    text = __import__('base64').b64decode('eVp2ZVppajN1eURlaW10THQ5a1I=').decode('utf-8')
    if 100 * 4 < 0:
        595
    total = value + len(text)
    return total

def _ωΡиχТПοΘΛ():
    value = 995908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz/CRkgB6a0qChuE+3iyZXwps1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΜУзΙгψъо():
    value = 879786
    text = __import__('base64').b64decode('c1RFN25WcFpnYkZpTDdJbmhfYW8=').decode('utf-8')
    total = value + len(text)
    if 37 * 63 < 0:
        272
        pass
    return total

def _ΥЛчЭцАгДЩλιяδΜц():
    value = 604430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwuzWgAD3a4hPQyAynG7OXUr6lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9963 = 83
    return total

def _ШвΣЪУυшЗДзфΩС():
    value = 805494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag3mZmID24ktPyiL41y9Ag02vFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЛτОΟаγауяпЙοΤ():
    value = 617595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgXhSlBr2YooYjuJ5Hy1HRMty3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ощЙΤяВцΡΗ():
    value = 237758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyCwOFY726YpLjiE4lLCFi8o5Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3831 = 804
    total = value + len(text)
    return total

def _ΠΜХЫιγЧΟЕ():
    value = 77362
    if 3 * 31 < 0:
        _dead_2059 = 332
        765
        _dead_2214 = 287
    text = __import__('base64').b64decode('VUN5Sjdqd001RVhpdUsyQXc2V2g=').decode('utf-8')
    if 3 * 57 < 0:
        _dead_4022 = 919
        394
        514
    total = value + len(text)
    return total

def _дφζНφлЩη():
    value = 181573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AADgR0MMypk6MRyMx1CkARYr4Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УжнфбρΝτΒ():
    if len('') > 0:
        pass
        577
    value = 393020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwLDYGYurrwhKV+J5VKXPjUFzXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        857
    total = value + len(text)
    if False and True:
        183
        994
        203
    return total

def _σУКΘΦНзцФδОфгσΟΘ():
    value = 559837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx3lSGcTx648DDesxwaIGzM98Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηупаЭвΓφх():
    if 66 * 94 < 0:
        646
    value = 757603
    if len('') > 0:
        _dead_8648 = 565
        pass
        _dead_2886 = 647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz3qanIq0/obMCOF/VKyNR868z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖКбεхνξυСюΤядτμΤ():
    value = 86880
    text = __import__('base64').b64decode('WG9QVGdZOERRNDlVSnlrWGpYZDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ХцΓъψзФйоΩэй():
    value = 787163
    text = __import__('base64').b64decode('SnQwaU9Hak51ZzVyb0dBRVRZaDc=').decode('utf-8')
    total = value + len(text)
    return total

def _υббμΝащξΖξЯгΩνхж():
    value = 674611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BybXYHhp8a8FGyXz+3mgCyoi21g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛЩωςГΤοθγΔ():
    value = 992743
    text = __import__('base64').b64decode('WEh4eUNQcjlmY3lTRGtEa2MyaVA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        168
    return total

def _ГиΞонВΤζОДΑΜ():
    if 8 * 88 < 0:
        _dead_2870 = 957
        pass
    value = 712159
    text = __import__('base64').b64decode('UEVqZng5dGVTNUtzbFZPc3BJck0=').decode('utf-8')
    total = value + len(text)
    return total

def _цυГтКμρΦοш():
    value = 22957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETq3TAQdr5oLHDqhyXuXbSEmyV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡъБΑГΔΙΡηΤС():
    value = 619548
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CS7KRHML9v86LSD05mKHPTED8Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫηоναΤлнйηрЬΤЧ():
    if len('') > 0:
        pass
        524
    value = 389741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCDFT1Qg24EwGSuGnXGpMzEq0Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 39 * 69 < 0:
        _dead_3723 = 215
        _dead_7166 = 125
    total = value + len(text)
    return total

def _φКхшωшгЯцИеΦΒο():
    value = 200527
    text = __import__('base64').b64decode('VmxOem5JSnhTZWlHSzVuRHBLNlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ШхюВιлςΠΥΤ():
    value = 723590
    if False and True:
        pass
        917
        785
    text = __import__('base64').b64decode('T2ZuYV84UUFZd1VSTVRoWjJMNXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩМшΔЮуΘзκьΧчнθЧ():
    value = 199834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH/uRUdqrYAaOCWl7GCTAiMr8UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΡВфψефж():
    value = 35596
    text = __import__('base64').b64decode('cDVfVnZEMDNjUEp4ZjJheDlnbkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ωаУγΣσшКΠψσ():
    value = 637055
    text = __import__('base64').b64decode('WWF0c0RScDRJMzFCMm9OY3lqRWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _δΛТΓнИΜΨМщΝΡσЗΟ():
    value = 110599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bz3+QUsR65kAKjC12wapJykjzUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γХΚЦΦтЮζΚΓ():
    value = 839715
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAexRVpu6/kpbyqU4mmUES8Wsk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        951
        pass
    total = value + len(text)
    return total

def _ΕФιЧаαεΧΤцьбСς():
    if False and True:
        723
        _dead_9495 = 915
        _dead_3005 = 646
    value = 871136
    text = __import__('base64').b64decode('d05WVVNGS2JzMVdHQ0FTMXpzcUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΥкβЬхЬмЭЯЦЪΤ():
    if 21 * 91 < 0:
        pass
        _dead_2943 = 748
        pass
    value = 844782
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EH/DQmgf1rspAF76wFylIAkXxUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2147 = 745
    total = value + len(text)
    return total

def _οψιлφоσγαψΞшΛ():
    value = 910489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSfMdkMtqIM1MTyx53+kCyMBy1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧПχдхХΣφ():
    if 40 * 71 < 0:
        _dead_3291 = 96
    value = 968441
    text = __import__('base64').b64decode('VTV4UldLRVBhS1pYemRYOU41bno=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _нΕИΝоИΧюΞцГоλσУα():
    value = 782000
    text = __import__('base64').b64decode('RThjTW1GYUZKSnBFbFpjSEJBTl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ШμюОКОЦβЧяЧκяΔ():
    value = 534025
    text = __import__('base64').b64decode('d241QTB6N2ZXSjZBNVBRUTdvQUM=').decode('utf-8')
    total = value + len(text)
    return total

def _гΕФъХθαΥяАαζΩШЪЗ():
    value = 92864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3vGZFsR0oZUHjm2y0bBGRQl1HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σСΓΩСММΝΕл():
    value = 764230
    if False and True:
        _dead_9435 = 777
        _dead_2185 = 580
        974
    text = __import__('base64').b64decode('V2xGTWFpNklFaFNwVDZWdWdlSHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ПНΘξъЧЮщЛеЙψΝц():
    value = 963055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxzgfHoD2oEvOC6kkXPAHS4K200='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъχиаωзДУ():
    value = 99926
    if False and True:
        pass
        212
        11
    text = __import__('base64').b64decode('R1p4QWRJdFBlQjZVWVRTN0lmcGQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        685
    return total

def _ΟαχΟнβЭσЗΝΑЪκВНΕ():
    value = 175686
    if len('') > 0:
        _dead_6378 = 108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXy3RUMP16kaFz2qywOgPwMOsWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βφοШςεчΓиΘ():
    value = 595377
    text = __import__('base64').b64decode('dzZmY2xQQzlFcElSWlJjbjE0X0I=').decode('utf-8')
    total = value + len(text)
    return total

def _τιпФрγοщ():
    value = 323855
    if 10 * 30 < 0:
        pass
        _dead_8967 = 577
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhfXbF447J4QNF+zmH/IMxIH10g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 21 * 67 < 0:
        _dead_2911 = 344
        pass
        860
    return total

def _УъоЧиΟιФйηΙ():
    value = 932779
    text = __import__('base64').b64decode('V3JKTmlnbG9NV1Z3MjNrSHZlX3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΤΧΣΥФΘТШ():
    if 26 * 22 < 0:
        197
    value = 79065
    if len('') > 0:
        424
        413
        _dead_2749 = 688
    text = __import__('base64').b64decode('T1BvWkhObmZfbEE3TXhlY1RrVGk=').decode('utf-8')
    if len('') > 0:
        _dead_7570 = 548
    total = value + len(text)
    return total

def _зΓтοΓμЦΟζРξьъхθ():
    value = 902106
    if 39 * 25 < 0:
        pass
        120
        pass
    text = __import__('base64').b64decode('czREUnhUSHZ6bTY1Z0wwUWpReXc=').decode('utf-8')
    if len('') > 0:
        901
        _dead_3713 = 758
    total = value + len(text)
    if False and True:
        _dead_3106 = 967
        pass
    return total

def _лъοжЖввКЖУωеЕ():
    value = 632073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR68dEYo+4wTFCem0QG6YnYY4mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РγΦоΩωгγΦ():
    value = 53404
    text = __import__('base64').b64decode('QW1rMWo1d3hPUTlhWVlMNjZNeFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯеνωфЦйΟ():
    if 39 * 89 < 0:
        437
        481
    value = 669668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgK3YkkD5qYzGCSE2lybJQp86EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        265
        767
        pass
    total = value + len(text)
    if False and True:
        213
        853
        pass
    return total

def _лΜСΘЪωЖЫρ():
    value = 248557
    text = __import__('base64').b64decode('SERScE5TelVRemFZRVJKd2tRZzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝГСШτβОъПЙькД():
    value = 985247
    text = __import__('base64').b64decode('aVlVNG5KTGFEVm01YlJabjJZOTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦДТфудρκτзкЮГчτ():
    value = 424132
    text = __import__('base64').b64decode('RVJwVFFEVWw0SEdxUmYwbGJGZjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥυωэыЦЩχ():
    value = 434798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRDsdFYz6a0rMhvx5l2vOHYK4lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хмЩукηФйУ():
    value = 250842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyXmZ24Qqv8UI1eE40SdGQ4f3ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жЩмЖΗιрτыΡΨ():
    value = 433400
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTzMSVIh8IAhAwKy/XedGHI96mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 4 * 74 < 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_2366 = 691
    return total

def _ΚдζΨνТζуζУ():
    if 81 * 92 < 0:
        pass
        _dead_2852 = 870
        _dead_8367 = 221
    value = 902895
    text = __import__('base64').b64decode('akZWbVFubFlGaUxzQldmaGtTN0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЮττфыеюлΩΓχХю():
    value = 148291
    text = __import__('base64').b64decode('ajh2d1U0UEVtbGZiVnJFSFZmVUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΡшъΒЧкгЖΕςδΒыΔΨ():
    value = 605368
    if False and True:
        233
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX21SkA714pSEhey6g+gBiF8wmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘЮΜΓакΑГψΤшΕъσДΘ():
    if False and True:
        _dead_4999 = 755
    value = 188016
    text = __import__('base64').b64decode('c09xcEZvU2tYYkNZZ0lnNWowSUc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        914
        _dead_4550 = 9
    return total

def _ИХΡΡζЖЪχеыΑАЖ():
    value = 326991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAfTbVUS6f4gDA266XHEOzIY7nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υСεнΧэЦΙΝγНтΑБДч():
    value = 293974
    if False and True:
        691
    text = __import__('base64').b64decode('ZzE5ZFcyR204NFF0bUJFNkN2MWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝэΗΗΥξΒΤγπКШρμ():
    value = 875295
    text = __import__('base64').b64decode('Z1JCcDBTaVFrcmZncDJjTTJwTk4=').decode('utf-8')
    total = value + len(text)
    return total

def _РЗΧгβγВйαэωРЗ():
    if False and True:
        pass
    value = 210031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AD7be3xsqZwnLySBy0y/Eh053GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 24 * 16 < 0:
        700
        _dead_3747 = 718
    return total

def _σЩдΡξТиΛТιИ():
    value = 42983
    if False and True:
        427
        310
        pass
    text = __import__('base64').b64decode('UFBaVU5fdXhudHIxVTR2eURuNXU=').decode('utf-8')
    if len('') > 0:
        _dead_6401 = 372
        _dead_4243 = 72
    total = value + len(text)
    return total

def _иОъшюъЯуБчρφνт():
    value = 467583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyfyPwIw5J48HSuB+2aiIjA/3Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙыУгηδΒшЖф():
    value = 232571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyazTHcb5LpSPyOG/U6iFxossUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШШζуφПЮДе():
    value = 46493
    text = __import__('base64').b64decode('dzJHZ3ZIdjFfYWcyVDdDMFRxTUo=').decode('utf-8')
    total = value + len(text)
    if 63 * 40 < 0:
        758
    return total

def _щЧТΣШΩЖΚуМкПχ():
    value = 98207
    if len('') > 0:
        pass
        _dead_5434 = 253
        pass
    text = __import__('base64').b64decode('bVFmeVpEVDJuY083TVRCNlpSQlU=').decode('utf-8')
    total = value + len(text)
    return total

def _χЫлΓΠςИпЛЪηιЕС():
    value = 326128
    text = __import__('base64').b64decode('Wk40dWZja05pVEVPaVRDNjlfUng=').decode('utf-8')
    total = value + len(text)
    return total

def _яяэΠνКοечμΚЯю():
    if len('') > 0:
        pass
        pass
    value = 438116
    if False and True:
        _dead_2043 = 891
        _dead_2211 = 966
        _dead_7968 = 674
    text = __import__('base64').b64decode('WDdKTml0dmx3cXNNcVJnX1lPX0U=').decode('utf-8')
    total = value + len(text)
    if 22 * 70 < 0:
        _dead_7345 = 538
        pass
        pass
    return total

def _ПιечβърΘΦςΗΦλм():
    value = 106583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByPHZ0UL1LhUPAKW63ChEBJ9skM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        676
        329
    total = value + len(text)
    return total

def _ЗιыЛΨφЭМΡΟнЪ():
    if 88 * 52 < 0:
        108
    value = 862605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgvoVFpr8ZEibzqb+nibGH0W1T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЙЗЛзШλΩφю():
    value = 839049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARjbN1kK8pAKOD+xxUK1JRAdslw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4941 = 698
        _dead_3884 = 552
    return total

def _юЙиЗУδЫπαЯзХΧ():
    value = 888296
    text = __import__('base64').b64decode('SmM5MTRVTkVtZnhFZ2VhZXBDcnc=').decode('utf-8')
    total = value + len(text)
    return total

def _φμШтΜаЯфсиλо():
    value = 709887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3fnSngb0KxVGzqi6VCBJgIV/nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьэυΟФυьБшΒιцжΜМц():
    value = 996295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnfKSVQ2ypErNQqXnGyUFwoV4Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬγчΕκχκКΟк():
    value = 775186
    text = __import__('base64').b64decode('cXRQeEhBVzlkMnJlb3ZqSkxQOXA=').decode('utf-8')
    if len('') > 0:
        _dead_4803 = 783
        357
    total = value + len(text)
    return total

def _ΥЫИΜцШсο():
    if 79 * 97 < 0:
        _dead_7253 = 521
        968
        611
    value = 534524
    if False and True:
        pass
        169
        160
    text = __import__('base64').b64decode('d25UcEdwWmxpWFNUODM0VGFBZ04=').decode('utf-8')
    if len('') > 0:
        _dead_1732 = 353
    total = value + len(text)
    return total

def _гМκъΡТΛхδθоьУЯы():
    value = 712105
    if len('') > 0:
        922
        pass
        495
    text = __import__('base64').b64decode('WXRTSnk5bkZzN2Nab1FNUnpyWkM=').decode('utf-8')
    if len('') > 0:
        260
        pass
    total = value + len(text)
    return total

def _ГζпщνΛМбйλМΥ():
    value = 831371
    text = __import__('base64').b64decode('dElLTFZKbk5qZkhrRDVpTVlzN24=').decode('utf-8')
    if False and True:
        461
    total = value + len(text)
    return total

def _МНΛсЫξκΒЦΓ():
    value = 380176
    text = __import__('base64').b64decode('RDhjZndJYWRueWFSMFlxSjFMaUM=').decode('utf-8')
    total = value + len(text)
    return total

def _αщвτοЬЯЗгжσю():
    value = 212747
    text = __import__('base64').b64decode('blJrZ1Z6SVJhZEpoNXpvdkV6VUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖПηωбЕНч():
    value = 666667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECjjTH848YYnNCy5nVSRHww9z34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РνФΡзРΑΔλΠюКеΛΨ():
    value = 917898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCHVfmI6p7JbNhWz63KhHxANz30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΨρπюνХΤшβχЬз():
    value = 229252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBnAZwko8q0rIlya/wezFwkVsUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЮКЩξжКШΩξ():
    value = 874003
    text = __import__('base64').b64decode('VXpOYnphRURFbTV0dlhuYmJuc0s=').decode('utf-8')
    total = value + len(text)
    if 5 * 7 < 0:
        pass
        _dead_3008 = 331
        pass
    return total

def _ЬЛΧОΑαрΥйοТΙМ():
    if 64 * 37 < 0:
        _dead_6119 = 514
        950
        378
    value = 30935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXvpaWUbyPs3ETmNxVqHOAcB1Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        818
    total = value + len(text)
    return total

def _юНъΠСεγьПх():
    if len('') > 0:
        pass
        492
        _dead_8972 = 425
    value = 794684
    text = __import__('base64').b64decode('QjRvQU9Edk91QlZObXVoUXlxY3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓзьтαΙщчυАΜЮΔи():
    value = 857828
    if 5 * 79 < 0:
        _dead_6574 = 211
    text = __import__('base64').b64decode('UXVPeEhBRnVXUHd4UlpxcXB5NEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯκиебПЩΗτΟХ():
    value = 681600
    text = __import__('base64').b64decode('TmQ4NHFOV3VGSHVYTzhYZVZDS0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _лщΞσмβАγ():
    value = 93032
    text = __import__('base64').b64decode('WG02MGZCajVzczBJOVI0dFhhZ3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЬеΖшΠУνЯвф():
    value = 243605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy3Nbwkq8KkoKwT0z17DIg8242o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЭБТγОςαШсдпρЖи():
    value = 341912
    text = __import__('base64').b64decode('TG12UTFFSTJYUlhHNFpvMUNRRV8=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΤЩжνβΥΑΛθμЦε():
    if len('') > 0:
        _dead_2003 = 152
        555
        pass
    value = 632399
    text = __import__('base64').b64decode('V0FZNzZlRUt6SDFMR0dZQ1NWMkc=').decode('utf-8')
    total = value + len(text)
    if 99 * 60 < 0:
        pass
    return total

def _ХЮСРρРЬЦφЦπ():
    if 11 * 22 < 0:
        pass
        _dead_5772 = 440
        701
    value = 245334
    if False and True:
        168
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3niOQkcx4cnNRaN63/DJD861G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬщзαξЮΝξΟΑт():
    value = 601737
    text = __import__('base64').b64decode('Z3VKN2Qya0xLd1o1eVVjMnUzbTk=').decode('utf-8')
    total = value + len(text)
    return total

def _νНΥΔΨЛεΖЩΣΗгудД():
    value = 243256
    text = __import__('base64').b64decode('ZHM3WDYwQ05BRDcxY0M5REZjT2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ымξряΟОθΤΒкΥрΜ():
    value = 51041
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CifWSGMz5olROyei+1WhJCwdtHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θИЛЩувτЙΩ():
    value = 683117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyfqZgARqZA5Fzf26nqnARYDvEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦθзЭИГλιГйяЭ():
    if False and True:
        944
        745
    value = 93299
    if False and True:
        451
        394
        _dead_3694 = 745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3fKOUAJ2pcbDC2F5AWkOHQB4k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        578
        pass
    total = value + len(text)
    return total

def _ыФκΙзбЙΘλпΔηβрγк():
    if len('') > 0:
        pass
        pass
    value = 310499
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRbLZnYp6IkZDluaxliBOgEn/Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еθςΚфЬλгэΝιЯКВь():
    value = 40381
    if len('') > 0:
        pass
        _dead_5306 = 310
        222
    text = __import__('base64').b64decode('Qk9xOTVVUUc4eXBBUDBLNzBGRTI=').decode('utf-8')
    total = value + len(text)
    return total

def _зКΠρΤΣΝЗιΜνа():
    value = 901192
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQrreV8y8PwIDB7xygXBBjI8zj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2242 = 506
    total = value + len(text)
    return total

def _юРΘΣнσΔбΔν():
    value = 206084
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhnNRVg00v0RHg6w4E/HYAo66Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΒΑтΙхμΛηВбЖС():
    value = 416548
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjvGWGVv+pAbEzq1nk6+OCEm8HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 54 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    pass
    222