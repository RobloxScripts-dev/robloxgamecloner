#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΚδχΝΓΠАФСΣйчζλψ():
    value = 550923
    text = __import__('base64').b64decode('dHd5ZWp2aG84RHNjaU5wX1RnbHE=').decode('utf-8')
    total = value + len(text)
    return total

def _χпЖлщоОЩΚъгΗ():
    value = 34836
    if len('') > 0:
        pass
        _dead_3944 = 491
        pass
    text = __import__('base64').b64decode('V0pRbDFFX2VFazVLTE04aVJRcks=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        718
        426
        368
    return total

def _АугΤΓΗкκ():
    if len('') > 0:
        pass
        _dead_8193 = 709
        pass
    value = 991502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhjtWWg6yIkQaFilkQTHGiYJxzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        643
    return total

def _соΔςмθρЭсАЖИЬΡ():
    value = 924631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICnTOm4Q6Z4TFxmA23emPzYkynk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6171 = 801
        465
    total = value + len(text)
    return total

def _ЩΝΩЭЮΓΠс():
    value = 646609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCHMdn8e6/AIES77+QHGDXAss3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΘΧΖЮΤΧРаζт():
    value = 438838
    text = __import__('base64').b64decode('R05fQjJ3dkJMVGsyd0Z4UUY3em0=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΠθΛιгρыфΨчΚξαΒв():
    value = 326575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiPdN0c+1rsTM1iu5FCyG3Ui0Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        117
        851
    total = value + len(text)
    if False and True:
        221
        829
    return total

def _κхΧΝΡсЮЩрμ():
    value = 117221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3fMSkU89YMuCyOw+WnENygo60A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΙшЮЭρоЖЦВт():
    value = 168659
    if len('') > 0:
        _dead_6942 = 451
    text = __import__('base64').b64decode('WlNXeE9iNEJLZWphdURhNHVOYzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΣГЦΦεВΒΛьИΧΙТ():
    if False and True:
        _dead_9645 = 478
        _dead_5745 = 752
    value = 263022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgbQUUMV660UETW531GCEQEs03Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΛεнνЦηиаςПН():
    value = 876082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBrHVHU81aQibj6x7G6RYhx+3lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΥφΗхΓЕηшнΖλΒ():
    if len('') > 0:
        pass
        pass
    value = 163383
    text = __import__('base64').b64decode('Tkg5dHFvOHN5Tlp2NzBVeHAyeGo=').decode('utf-8')
    if len('') > 0:
        935
        420
    total = value + len(text)
    return total

def _ηеΒюпИГΟκФ():
    value = 904903
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgS8WlIS05FaDC6J52mkBgp33kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΑвΨΤКЩΔΝХо():
    value = 218688
    if False and True:
        _dead_2095 = 426
        pass
        105
    text = __import__('base64').b64decode('YUREaHJFb2ZOY082ZkxFSlVrU0c=').decode('utf-8')
    total = value + len(text)
    if 95 * 75 < 0:
        86
        _dead_4388 = 814
        pass
    return total

def _тчΘэХΝюξбАΔ():
    value = 245596
    if False and True:
        pass
    text = __import__('base64').b64decode('bHkxSGFwUDFnZTk4cVh6eExYcE8=').decode('utf-8')
    total = value + len(text)
    return total

def _вдиФЪчПγшаВЪю():
    value = 932342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx61bQU3zqYhAiHw+lyeLHI76UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τШйΘΒπГо():
    value = 947113
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHvXQ2E/yI4HHB6tzA6cZDY60X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 91 < 0:
        768
        _dead_2784 = 254
    total = value + len(text)
    return total

def _ЫлΝРгбπЩΙМΧиКЬЙЙ():
    value = 444945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jzrdens80vsNHgLxzWeWZBM6tEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 20 * 69 < 0:
        _dead_5515 = 433
        pass
    total = value + len(text)
    return total

def _βзГπφΖΠИКΙЕΙΚТ():
    value = 169187
    text = __import__('base64').b64decode('R1FYV3M1Y2VzNTdydnpxMkJLang=').decode('utf-8')
    total = value + len(text)
    if 46 * 28 < 0:
        pass
        _dead_8165 = 101
        709
    return total

def _ΩυУβЫфυΚ():
    value = 837126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PybhZlwU7fsqOSqu/X+ZLhEG70c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        232
    return total

def _ΖырιμШςк():
    value = 776104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mgb1YF1g95ciNAurz1q4PjMH7zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЛνятуУфивχΣΥЩ():
    value = 580005
    if 93 * 78 < 0:
        255
        pass
        _dead_7433 = 221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRDdPmQpyJgoOxf6+HuSNit3sWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 46 * 53 < 0:
        _dead_3402 = 657
        _dead_1498 = 940
        pass
    total = value + len(text)
    return total

def _ΥвКξннΟΜ():
    value = 770616
    text = __import__('base64').b64decode('ZDRtOGhHZTB6SXJUdTk3dFVpZ2g=').decode('utf-8')
    if False and True:
        971
        228
    total = value + len(text)
    if False and True:
        795
        pass
    return total

def _αУкΣьцρЧΒЫжп():
    value = 102312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dg32XVU6xqMIKQOs0ELELHY8wUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΓыπиЫТПτ():
    value = 753287
    text = __import__('base64').b64decode('ZERsYzdUQ1UxY1pCZTVvOTNKN2I=').decode('utf-8')
    if 34 * 74 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΜеφςΞюнЫσψРΣγщ():
    if False and True:
        _dead_5887 = 656
        768
        pass
    value = 313217
    if len('') > 0:
        _dead_4620 = 382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQP+aQkPp70lF1r03E+fHQYitl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΟХΑРАШΗяΣгΤяαΕΨ():
    value = 614434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwPXOVkWpqMOKz2L+W6qZgF73GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сХдеΨЗξйβ():
    value = 622912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3/SRHkM/b4zbRma/ma0Cwp+t3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩβЬХкΘΞθп():
    if len('') > 0:
        _dead_2919 = 183
        302
    value = 580031
    text = __import__('base64').b64decode('b0lCRGNLMlFhZlVoT21BWjJtbFA=').decode('utf-8')
    if False and True:
        _dead_8429 = 700
    total = value + len(text)
    return total

def _ΩςЖсΣπψшΔвГЗΣЗ():
    value = 844011
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ7GYUcM0J8NaRWJ0QadDAQe02Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        862
        pass
    return total

def _РβωΞэюдτЮΛаеЭй():
    value = 598929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MC7KTwID/548aADykESdBxMI9F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РЕыΚЩσоег():
    value = 600145
    text = __import__('base64').b64decode('TW1lbUIwT01JQzlaNk1pbVVzTzA=').decode('utf-8')
    if 65 * 53 < 0:
        _dead_8663 = 806
    total = value + len(text)
    if False and True:
        _dead_4281 = 218
        pass
        702
    return total

def _κрμγЗпΑЭСУЯη():
    value = 529215
    text = __import__('base64').b64decode('RXJYUzc4cm5YekJ6cGdDUVRIMmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ХПЖΜйЬзμЬрοмμΥжР():
    if 28 * 96 < 0:
        pass
        220
        _dead_2407 = 39
    value = 365135
    text = __import__('base64').b64decode('ZlpndkFwX0I2cG1ZSjFPQk9lVmc=').decode('utf-8')
    total = value + len(text)
    return total

def _щΝτΜυЧцл():
    value = 938337
    if 28 * 92 < 0:
        477
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAzzYwUy27gEDAeHzFmTEXc67zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 54 * 88 < 0:
        pass
    return total

def _ηΔшшΓЩУψжтιеЕΩб():
    value = 353080
    text = __import__('base64').b64decode('TzM4MkRmakY4WGZ5UzNqdjJPbkM=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if 18 * 52 < 0:
        _dead_6811 = 818
        pass
    return total

def _КюяΑξСφоμΤвΖжЪλБ():
    value = 404639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ly3mSnIY3asHYzCnw3S+Enwitk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        346
        pass
    total = value + len(text)
    return total

def _μρКИχρρоΚπΣпξ():
    value = 234412
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRzpbXho+fxVbhio5GOqIB98yks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гНЭβДэИчЗуυоνΓ():
    value = 734089
    if False and True:
        pass
        _dead_3115 = 178
        _dead_9582 = 433
    text = __import__('base64').b64decode('Z2Q1S2JHX1llaHJzRkxSR1hnWnA=').decode('utf-8')
    if False and True:
        _dead_7247 = 926
    total = value + len(text)
    return total

def _ΩφРЛКЭЩыыуΤΡгП():
    value = 497096
    text = __import__('base64').b64decode('QkFCQ1FfeUtGTGJMSVhXdkNveXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒРПпΨΖОΧε():
    if 83 * 98 < 0:
        _dead_5136 = 280
    value = 227186
    if 75 * 5 < 0:
        _dead_4068 = 12
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lw7oeWgr07kqGTn07Hy1OR8+vFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΤЯХМΖγΠΖъДδпв():
    value = 265835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSbmYwM+raMNHA7y2EHBEAg6s2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДртгиκωЕчЙΦеЯОδυ():
    value = 364353
    text = __import__('base64').b64decode('SkFXX3V4NGVOTlRzX0NkM0FnQWg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9880 = 363
        _dead_6665 = 714
        449
    return total

def _ηшζтШЬгШχЖуλЯ():
    value = 957385
    text = __import__('base64').b64decode('dlkxN3Y3TlJIbGtSakR3VmpJSGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ХбфиыΩПιик():
    value = 738090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjjmTH0Gyf9aaCf74wK7JgsQ7XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        566
        pass
        _dead_9667 = 391
    total = value + len(text)
    return total

def _РеαОγивкΖЬμЖΧЯюθ():
    value = 19488
    text = __import__('base64').b64decode('TmtpUVlYV3RmTzg1WGVSN0VsTjA=').decode('utf-8')
    total = value + len(text)
    return total

def _шΘεеδΤХηдηЦΑС():
    if False and True:
        pass
        _dead_9318 = 761
        _dead_2425 = 679
    value = 726661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyHnQXAQ3ZgvCwux73WJAH0CtHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫвΠТсλΑΙЭμф():
    value = 457234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHy2eAUx1PsWICiE42+WZAEA90s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςппΣБхчиЩСРШХΟ():
    value = 322752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyuyVlgO5rhTNAaF+QCXBAwI01o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖьПοАврЫЧψУЪΖБД():
    value = 247957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En3HTHA/+YVRYzeH2VS8Gyd/yU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХНηШΥЧφΗгЖзΤς():
    value = 440535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB63VEEJxIoCNh2xnVKoER9942g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШЛБЦωЮςщμС():
    value = 32469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADrjW30M7v4nOwu671CjAi0f4V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΡφЮШшЙηΧлΦвΕ():
    value = 959324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhayOUYr+5AUMiGh70W9AQMY1Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        243
        _dead_7688 = 806
    return total

def _ЙЕюΑюМΟΡ():
    value = 457420
    text = __import__('base64').b64decode('ckM0d2x2VGlSc1NUM0ZwY0wySjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭгхВйШЮжьμяηρсν():
    value = 518368
    if False and True:
        _dead_5390 = 716
        _dead_8045 = 276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwLVa2ID5ootaT206wGFEQkf00E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 55 < 0:
        _dead_8209 = 496
        pass
        _dead_3500 = 115
    total = value + len(text)
    if 92 * 52 < 0:
        pass
    return total

def _еХγΩщЕлωΒ():
    value = 895820
    text = __import__('base64').b64decode('TzJoc1VCOTJqMGVSYmN5WFh4eHI=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if 49 * 40 < 0:
        617
        pass
        _dead_1259 = 800
    return total

def _ωыфξξУЙшΨΜЖсФΤ():
    value = 365472
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERbqRkESrPkJCyLxkEy/AzMp0FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тьЙрлΨψхΦ():
    value = 193155
    text = __import__('base64').b64decode('bElzY3BoRFl5UXlOSHhkTGt3aHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ШуТШЗУΗЩηлЮγ():
    value = 676507
    text = __import__('base64').b64decode('dUtmSVF6SF82TDE3MDdvZmdTSkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑΥКθДυесΕлЕκΣЗа():
    if len('') > 0:
        pass
    value = 928528
    text = __import__('base64').b64decode('RFFEeU1TQm1vU1lzZWdyaTVFc04=').decode('utf-8')
    if len('') > 0:
        _dead_2837 = 691
        738
    total = value + len(text)
    return total

def _σΙУлΓαкЙρΘЭ():
    value = 131330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDziamYTxIUyND6w8AfADjY+yUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7570 = 227
        336
    return total

def _τΦыΝЙЗφλΤχΧη():
    value = 965021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQLbSXcR6/oJHTyG7Fi6AhF4xWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔЬΥβмцμωпΔΓεζсΠп():
    value = 480859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyTeNnodzKYJAhiPyQPGBXMH3kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _амИΗчζЮСвИ():
    if 55 * 17 < 0:
        _dead_4698 = 887
    value = 368019
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQ3Cf3cQ7p8TIxylw0+6JCEs8Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 74 * 86 < 0:
        587
    total = value + len(text)
    return total

def _ЦБВЖУΜιμ():
    value = 309825
    text = __import__('base64').b64decode('aU5YZFJEUlZmeWRRY2VHc2VtVHU=').decode('utf-8')
    if False and True:
        884
        _dead_9413 = 934
    total = value + len(text)
    if 11 * 66 < 0:
        _dead_1357 = 298
        _dead_3620 = 518
        220
    return total

def _УаЩуεэюОεШΗХΒπшм():
    value = 309264
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDbWPF40zI8JKCGE6XmvHzM3vWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧСЕшДΑδбГΨкΗ():
    value = 384847
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISi9RGRq9fk7GFm6wUKVJiE24lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥκФζΩЛςΙШΛΩА():
    value = 754713
    text = __import__('base64').b64decode('ek1aalNUVjVKN3lGWTBaNFRubWw=').decode('utf-8')
    total = value + len(text)
    return total

def _κμΝΣΠΒοЫЖлΗЭ():
    value = 357049
    text = __import__('base64').b64decode('bHRrdUxxRFlJSlpTbjVobXFJWUo=').decode('utf-8')
    total = value + len(text)
    return total

def _пТкΝΡШζпΘΒкхЪΓЩр():
    value = 712114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MznSbVkL07o3aDqimHeDGikttT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘНγАяΓцβМΓчι():
    value = 993508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHnTTEhvp4krIimPyVLCPBYa1Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        268
        _dead_4301 = 473
        809
    total = value + len(text)
    if 35 * 48 < 0:
        390
    return total

def _ОЭφьΨδωΜатЪ():
    value = 554977
    text = __import__('base64').b64decode('TUhFZGV5ZDRQNXBWbm0xcWlPV24=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЫςπЮВоΤΝОσθъф():
    value = 13802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjjPY1opq4QvbRuR52SSASx53j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        261
        432
        885
    total = value + len(text)
    return total

def _ΑСсорΧГπБМСωщ():
    value = 485678
    text = __import__('base64').b64decode('R3I1VmQ0d3NISHA4Z1BzYUV0NFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΡЮщωеПУэЛυλη():
    value = 61247
    text = __import__('base64').b64decode('bFV6N29LVzJhcFJoTU1BWGpVUmQ=').decode('utf-8')
    if False and True:
        574
        98
    total = value + len(text)
    if 26 * 60 < 0:
        974
    return total

def _шΓйΕοрэΗынФоφωСΖ():
    value = 213914
    text = __import__('base64').b64decode('ZnJKVEFyWjd2Z3VBRmYyd3RiUU8=').decode('utf-8')
    if len('') > 0:
        432
        965
    total = value + len(text)
    return total

def _дхръаЪСпЩω():
    if len('') > 0:
        _dead_6063 = 819
        pass
        pass
    value = 260044
    if 72 * 73 < 0:
        845
    text = __import__('base64').b64decode('cGRMdDl4MXJ5TnBkbEE3SElFNWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪδΩΡΓχΟшΧτθ():
    value = 36737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cw7bQnRqx4IPDQHz2U+/IDM+4Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οпΝРιΚПЪВυвΣ():
    if False and True:
        pass
    value = 700721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQnMX0dr26wvKye27mOEMygk80U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        285
        _dead_7611 = 154
    return total

def _ΜжцЮкωЮκςζσΗБΟ():
    value = 693369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh+2e2I3+pI6KwGt3EG4MjQf21c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕцРхМΟαμ():
    if 98 * 89 < 0:
        pass
        _dead_2218 = 894
        pass
    value = 780997
    if 43 * 49 < 0:
        pass
        pass
        _dead_8268 = 700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgzrW2sN1/stHwez0mKHZh17wFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        141
    total = value + len(text)
    return total

def _лρςλАικД():
    if 26 * 54 < 0:
        pass
    value = 344922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjvdYAMs6pwgHBuP7lWiHC585kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ВЪНΕμγТεΤкКχПъ():
    if False and True:
        926
        _dead_8135 = 791
    value = 649902
    text = __import__('base64').b64decode('Tjl0N3l6Q1liS3N0YnVBVGlQMWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖфьяПТФЛЬΓΖ():
    value = 208679
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kzv1SHIs/I80BT2LwQS+YAMrtlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СаЗνφмЩЦфΙй():
    if False and True:
        _dead_8496 = 866
    value = 520608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy3pRQFv5oUhPCeW2GOHFSMj40M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖργУΨηМΝЙШΦТХхв():
    value = 857772
    text = __import__('base64').b64decode('YnJOdVp2YXFKb0lHT3IwWmtmOWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘηΖрΦРШЮЗь():
    value = 41710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQPAb1hh3ZcgFAWxxgC5PQYY90g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РйφεφЯеΕхЕυΗР():
    value = 877514
    if 49 * 4 < 0:
        pass
        184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDvHSFcI/actPiKS+QeHY3QB72o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 55 * 61 < 0:
        _dead_9834 = 385
        _dead_8386 = 924
        pass
    return total

def _αЪаФςААμΤюθ():
    value = 618919
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('alZUNkpoRXREdjFSY2ZvdnFMX0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕνπЖΕхκΩм():
    value = 90031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzewPgY4/5AwMjmmwlWXHw45tEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΘСμуλΖΕΛзΕΒб():
    value = 253544
    text = __import__('base64').b64decode('eHk2TzNNMGZ2bjRoT2U5TWhJa3A=').decode('utf-8')
    if len('') > 0:
        216
        pass
    total = value + len(text)
    return total

def _яМιΘΗЭφъμΞαЯ():
    value = 462866
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX22PwEcppsFFln1wAa4DX0hxks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯςБΥжЩΧΞψφμθь():
    value = 615532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ES3jf0Af3aYbNSG7y2mFEwQ5tUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЦябзηцЬмРφнγСЛ():
    value = 327951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERzCX10Q2PBQGCC251KmIB8L9Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψИσУλгΛοсζσхψτ():
    value = 864690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiLIVAIGrqs8NjeAkUOFZ3YA1nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηреωрΧБρзфщΠχωйΧ():
    value = 757982
    text = __import__('base64').b64decode('bDZqZmd0Nlk2NERUTFR3ZkVBQzM=').decode('utf-8')
    total = value + len(text)
    return total

def _УеЬОщυТΠЛоΦΜГ():
    value = 670514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Byu8XgQh054WCBanxWeRYzEX4VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖζлυЭωТуΘмНЩπ():
    if False and True:
        951
        pass
    value = 960349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgjyVmQa8IcKahaa+3XILA07smg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 21 * 83 < 0:
        _dead_4176 = 251
        pass
    total = value + len(text)
    return total

def _ΙΠεγТЮдВотУуΨφι():
    value = 889118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyXeQGEjqaUpPgW691SCASAiwz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДнΥΣОЕГъεαНйΤдС():
    if len('') > 0:
        _dead_6834 = 364
        _dead_3815 = 49
    value = 709571
    text = __import__('base64').b64decode('a3VjQjBjT3ZnZUU3Nzc2T3h6QV8=').decode('utf-8')
    total = value + len(text)
    return total

def _бδΞΞψαРИэюΑЧΖРΗ():
    value = 274296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxrzaHAL74YoY1aJ31/FZBMo82c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΤΨтНρеοΓХнЗοΗθΟ():
    value = 809704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgvxYgMW+ZIUPj+3zFSTHyQc0Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        217
        pass
    total = value + len(text)
    return total

def _БνΔЦγуЪρФ():
    value = 680852
    text = __import__('base64').b64decode('am1vbUw0YTRRelltTEhHc0RCdjY=').decode('utf-8')
    total = value + len(text)
    return total

def _σиΩΩΒЕаИэм():
    if len('') > 0:
        pass
        560
        pass
    value = 306155
    text = __import__('base64').b64decode('WURMNlE2V3lzNWFLbG5qeTBRWWQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_1647 = 500
        _dead_6553 = 513
    return total

def _юΖΑЩЧйГαΝчтΧПэς():
    value = 789071
    text = __import__('base64').b64decode('ajNMVWhUR1ZiS0syaktfb0JhSVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡФΙυβοЭьшЮоγΓΗκβ():
    value = 877970
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCDLPn8K6IQVKgabnHC7FQ8sxnQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _алРоΝРтΙжИьЕςШо():
    value = 578795
    if len('') > 0:
        _dead_6623 = 780
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CirXVkQp6LovDTmxwFGpHw8i4jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        961
    return total

def _УъγеПΒξЭЙБКХκ():
    value = 578076
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSTLfwNrx5JVDTWZ2XmHCwkctXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жЪЫвеνнЫиΚηЭτдЖ():
    if len('') > 0:
        pass
    value = 420221
    if len('') > 0:
        pass
        _dead_9941 = 744
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwLda1QMz5AyOx37432lYBQryGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩФЧΠυЩГвξцЩρ():
    value = 393059
    text = __import__('base64').b64decode('cWh2SEhBUDVrTVVBYkJEN0VndW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΕкαъψЬΔжОЧИ():
    if len('') > 0:
        870
    value = 176036
    text = __import__('base64').b64decode('U0ZTdXRkOFQ3S3ZrZWFKU3k1Wks=').decode('utf-8')
    total = value + len(text)
    return total

def _эΓΥκΕΟЪЙ():
    value = 941571
    text = __import__('base64').b64decode('eTZud2hyWFRVM2Ywd0p4TlNKUkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ПуАσΞМрщφиοГрμь():
    value = 637916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cxe8a3kJyrE2Ljeg4mO3Z3M/3HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γмбяуБШΧФρ():
    if len('') > 0:
        _dead_3495 = 423
    value = 428362
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSzbeUEOz5gyaByU+VG/LRQE/Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗηЕхУэмΦ():
    value = 79785
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw7MeQQW974OMQCS0H2jDAQ4zEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 21 * 91 < 0:
        924
        pass
    total = value + len(text)
    return total

def _ЖПьμЬΚппюΤДх():
    value = 538131
    text = __import__('base64').b64decode('Q3FacElXT09jYVZDWHFtdDRKaWM=').decode('utf-8')
    if len('') > 0:
        pass
        392
        pass
    total = value + len(text)
    return total

def _μэΜБЬЖБΡлаХПΨο():
    value = 243079
    text = __import__('base64').b64decode('aUZEMXBqb1kwc1Nsd3VHSnNLUTQ=').decode('utf-8')
    if len('') > 0:
        289
        692
        pass
    total = value + len(text)
    return total

def _ΤТьφΧωЖОпАЯυЛ():
    value = 185993
    if False and True:
        504
        _dead_7290 = 762
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICPoR0Iw1J4kKlmumXy3MCEitGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΦΩизΥЬЕфВεαНωдΣЯ():
    value = 319275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHj0SWAr86k0DQOP5gaHYRcQy34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уУΝΘλΡΑЪΣτяΑЪГψк():
    if 59 * 62 < 0:
        280
        _dead_8374 = 867
        pass
    value = 886909
    text = __import__('base64').b64decode('blA1TExQcG82Qk8zVUJKNjJQRnQ=').decode('utf-8')
    if len('') > 0:
        _dead_6670 = 637
    total = value + len(text)
    if False and True:
        _dead_3810 = 922
    return total

def _фГпОЬцъШΜμЬΜы():
    if 94 * 35 < 0:
        _dead_5066 = 111
        _dead_1500 = 858
    value = 136900
    if False and True:
        _dead_2374 = 591
        pass
        _dead_1044 = 707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCnSPmsu/74EFCyu0XqKFicOwjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аςлΣαψтИ():
    value = 337201
    text = __import__('base64').b64decode('T2FnUG5nWkJ0TlRQU1FfZzNvbWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖхОрСенБ():
    value = 630568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh/cPX4NzYkSKQOb/2ChJhoa8Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        634
    total = value + len(text)
    return total

def _ЦεЯмъΨмбЦзΛ():
    value = 859252
    if 84 * 11 < 0:
        _dead_3490 = 403
        449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EifKWnkh+aAALT6K+lK2NXJ3y1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        507
        pass
    return total

def _ΥωПхьУΜц():
    value = 711127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX3NPAc98f9VOyunkG+AMQh53m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΓсГгШеΦдζДοКЖ():
    if len('') > 0:
        pass
    value = 699650
    text = __import__('base64').b64decode('ZWkxa0VyUFlSTWE1Z2JqZDlFZ20=').decode('utf-8')
    if len('') > 0:
        674
    total = value + len(text)
    return total

def _χωκΘбΜΕθΡΝЮщАу():
    value = 406044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IATqXgY6+/kBPiiZnVO0JTIFyUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еоΔΞкξДнΝοΣГδ():
    value = 258357
    text = __import__('base64').b64decode('WGlRdHZhaE5iOU9nekhJYndwNVU=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ДггщμвηЭИоςЭЩΜωМ():
    value = 506504
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KybUXAQV1vAhDyavwXSKHCN6vG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κВШΕρЮбΓзфΖЧЮςзΟ():
    value = 279060
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyDgRV8t8YEMCiq6kH+UYjYfy1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 11 * 42 < 0:
        964
        pass
    return total

def _зαδОвНПЖ():
    value = 748658
    text = __import__('base64').b64decode('Q2RWQUZNb3FZaFJHYllVTzU4Qnc=').decode('utf-8')
    total = value + len(text)
    return total

def _гΨевΘУωВ():
    value = 287819
    text = __import__('base64').b64decode('YmlWSHFkZzhhOGJSRjRVQ19TNUU=').decode('utf-8')
    total = value + len(text)
    return total

def _τЮтσЫδьЪ():
    value = 954245
    if len('') > 0:
        285
        _dead_8228 = 77
    text = __import__('base64').b64decode('cXpydmU4cktjZ2t1MWZRWE04M2w=').decode('utf-8')
    total = value + len(text)
    return total

def _оηнйыΥШαηисшΜΦΑΓ():
    if len('') > 0:
        pass
    value = 847128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwXlRn8QqYE2Mimi/32fbAwQyn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_4975 = 305
        _dead_8931 = 746
    total = value + len(text)
    return total

def _баθζЫΦсδсΧυωбΘ():
    value = 473821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQH8bGcVzIYAYz6zwHXDG3Ec7zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨиφΟΖΡцΤг():
    if 28 * 71 < 0:
        pass
        _dead_3480 = 547
    value = 610644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICXcQWE7qf8sHRqcnnqVHHU/vTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 60 * 24 < 0:
        11
        733
    return total

def _ЪзΡмрХвγзΛЛ():
    value = 325418
    text = __import__('base64').b64decode('bjVWYlFPUUhCRHBuR2Zud2NvWEg=').decode('utf-8')
    total = value + len(text)
    return total

def _жкΛдФЙХΤтнΤΝ():
    if 41 * 41 < 0:
        _dead_4476 = 425
    value = 255312
    text = __import__('base64').b64decode('WUtaSmNNblpaZmZRcnl1T1o5SGM=').decode('utf-8')
    if False and True:
        677
        863
    total = value + len(text)
    if len('') > 0:
        _dead_1254 = 270
        _dead_6742 = 199
    return total

def _ΙтяυΦνΤл():
    if len('') > 0:
        pass
        pass
        982
    value = 563633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSrxXkEG27AgGzqOm1GDPgsM0ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦЛΧЦКΧтψбμΙхИЕ():
    if False and True:
        369
        _dead_3216 = 332
    value = 918512
    text = __import__('base64').b64decode('VkpGeUc3R2FjTkdYTmpoOFViSUY=').decode('utf-8')
    if 83 * 87 < 0:
        _dead_8385 = 780
        _dead_9514 = 324
    total = value + len(text)
    return total

def _ьρуХΝТМФηяΡηΔ():
    value = 424834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jze8d3o21JkbGS2u3kKzDTwV5ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ικσЧыЫλкЕσв():
    if len('') > 0:
        pass
    value = 469773
    text = __import__('base64').b64decode('R0c4a25BZGpYcUFSdDUwQnBpTkg=').decode('utf-8')
    total = value + len(text)
    return total

def _сΥОЬΙτнΘыΣΑΩ():
    value = 460743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ21Q3A8xP8PAxWM3XSeAAc3z30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψηфБεΔΓЫСθφΟюΡΦΤ():
    value = 470648
    text = __import__('base64').b64decode('TlAxVWlHQlNzVWpmREprT20wTTU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        793
        pass
    return total

def _ХΜаΘкКοгΦШ():
    if len('') > 0:
        _dead_8604 = 890
        183
    value = 600406
    text = __import__('base64').b64decode('UG1rYzNCVkRzcjZuTXdDZzdwcWQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_5711 = 330
    return total

def _θΠНьγуВйαъНΔР():
    value = 836594
    text = __import__('base64').b64decode('aUFnNVhzYkNtNmNkcTk1UjVxVHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _θМυЖЫΠйλйзθκцИ():
    if 70 * 52 < 0:
        280
        _dead_2344 = 509
        pass
    value = 808380
    if 41 * 49 < 0:
        635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh/JPAVvpoQkGwyv3nydHwc5yUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘлΟчуδΣиε():
    value = 699322
    if 46 * 84 < 0:
        pass
        pass
    text = __import__('base64').b64decode('RndyQTdObnBTTDEwR2phUkUydk0=').decode('utf-8')
    total = value + len(text)
    if 99 * 72 < 0:
        pass
    return total

def _ΒΙχпυΞРыНюи():
    value = 775356
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyzsOmAY+oURICXxxwSnCwl6tV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σДрэаυъфЯΒζ():
    value = 48506
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwrJe0E00pgia1uy3FGlPA0Xs3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΠыюτьπОζπвφλЕ():
    value = 23607
    text = __import__('base64').b64decode('c1k4SERJOFd6TWlnaFhvQWRvbVc=').decode('utf-8')
    total = value + len(text)
    if 14 * 2 < 0:
        pass
        pass
    return total

def _πСκВШεтУШйΧЕΤΘΨ():
    value = 698758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyG9ZVwywf5VMRirmnSKMAsu8GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΑМΨΖсгΒΦ():
    if len('') > 0:
        pass
        pass
        pass
    value = 552754
    if len('') > 0:
        pass
        626
        _dead_7043 = 873
    text = __import__('base64').b64decode('WGFJTEZ1aFFxOExESHFZczczSG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΖθΨΜНЫЛΑ():
    value = 251530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyLBXgQz06omAA76z37FFjEOy2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΧцывОργцθН():
    value = 93454
    text = __import__('base64').b64decode('ekU1TERVcGlVRFl0bTBKandsT0g=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7141 = 623
        pass
        pass
    return total

def _вδвΝГΔυΦс():
    if 47 * 67 < 0:
        _dead_6655 = 189
    value = 334130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRj8Q3448bIXPw2Ry0GIIyoo9EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΧοκΘΖφβΤйο():
    value = 96948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDbxXlQX1rAOAyuG0g6zEgx71kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΡГШπΙΘцφПф():
    value = 761103
    text = __import__('base64').b64decode('azEzTGs2VkRhcjQzVWlhZl9wekI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        839
        _dead_5741 = 237
    return total

def _ЩыОЙΧωоЭ():
    if False and True:
        pass
        pass
        _dead_6035 = 900
    value = 81135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnvAY1843KoACR2sz1SfGh0DsGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 59 * 28 < 0:
        _dead_7342 = 571
        _dead_9771 = 695
    return total

def _ξКψςαπьΙЕΓΒ():
    value = 662252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fnm2T3sx8osRGSKEmlmhASoOw08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3837 = 712
    return total

def _αΓαРсвСηηзЦЭχр():
    value = 394412
    text = __import__('base64').b64decode('ZTducEg1UDFzT3ZPR0pIUW9XUjQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        367
        _dead_6418 = 114
    return total

def _зΗатУμΘσСΑΝю():
    value = 372748
    text = __import__('base64').b64decode('cGJENDZYc3Q3cG1UQTBhRGlrdmw=').decode('utf-8')
    if 63 * 63 < 0:
        _dead_4218 = 165
        428
    total = value + len(text)
    return total

def _ΔАηпупеЬΩЪрτТςΣ():
    value = 688307
    text = __import__('base64').b64decode('UWNhRWVxbXhWckVaSWd4a1VJRU8=').decode('utf-8')
    total = value + len(text)
    return total

def _жСаψЦБχΓ():
    value = 563796
    text = __import__('base64').b64decode('ZWZ0VG5CRTZiYzhESWpyRTRUaEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧйσξаμΖзФвΧ():
    value = 677342
    if False and True:
        pass
        pass
        570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgX+RnwK6oURBRab62azMz0Mw0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФжηюκΖΛвΓЪМШ():
    value = 714569
    text = __import__('base64').b64decode('YmtDQVBKVWJwTDhLX3pNSDNONlM=').decode('utf-8')
    total = value + len(text)
    return total

def _жЧшТбвгфЫΕшЮ():
    value = 167507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBj0VlkLqIBbAx+F4VWAEC8pyEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮζΔШЯζТπΦπ():
    value = 284316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB/FS3Iq0oYRGTaRx2anED8i/ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пγΕΝξΗΗх():
    value = 218263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx/nZmYs7aUuOBqT3ka6FxwjzWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_1702 = 938
        528
    return total

def _эΒθЮζΚяыΟΙпХмς():
    value = 333174
    if False and True:
        _dead_7705 = 441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB/bZXU0z69Sb1+a4FCgMCYJ8Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖОАΙΔОΜΨ():
    value = 971244
    text = __import__('base64').b64decode('VHV2WVMwUVV6RTJMYXpDQnd3UEU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2558 = 913
    return total

def _ЛасΒылχνΝχρЖъц():
    value = 616329
    text = __import__('base64').b64decode('cldabkxOUFR2MXUxcHlHcXlDMEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ИЖВΗПЭΤΓС():
    if False and True:
        699
        pass
        _dead_8264 = 878
    value = 909288
    text = __import__('base64').b64decode('RklGNHdiNHpzVXk2S1RvWEFabGY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        383
        914
        _dead_2082 = 534
    return total

def _ЧнъКαθюЭΩеΙΝЖΩН():
    if len('') > 0:
        996
        _dead_6559 = 66
        31
    value = 828341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiX8O1Y1yqknFDC2kGWmYwcd8Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оХλХХнхΔД():
    if 14 * 25 < 0:
        _dead_8206 = 33
    value = 638861
    if False and True:
        pass
        _dead_4422 = 460
        pass
    text = __import__('base64').b64decode('cmJIQ0RSeVUxWnc1NUFxOFhHVnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        pass
    print(__import__('base64').b64decode('bQ==').decode('utf-8'))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()