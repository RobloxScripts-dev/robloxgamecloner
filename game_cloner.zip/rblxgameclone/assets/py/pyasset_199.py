#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _кΥνξъКцΣ():
    value = 415940
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASq0anQNr7ohDSjwygCjE3QO/mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шАжδьЬдΨ():
    value = 715073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCrlTXkb54kLIBa0n3mZCzMJwUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΣжεΝЦτЭЕ():
    value = 560297
    if 17 * 48 < 0:
        pass
    text = __import__('base64').b64decode('T19zVXN4bDg1QkR0OWsyWW05V28=').decode('utf-8')
    total = value + len(text)
    if False and True:
        497
        _dead_6271 = 719
        185
    return total

def _ΤΙεЩρИΒν():
    value = 118286
    text = __import__('base64').b64decode('WkdFMFRxcFM2TjZZQzZfWnllSlI=').decode('utf-8')
    if 88 * 9 < 0:
        595
        452
        _dead_5664 = 816
    total = value + len(text)
    return total

def _жЦИВгБыЬь():
    value = 329586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCTOfkUh1/tUCSiH2QS9MnMc7j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜιиΙΚЪгζ():
    value = 49474
    text = __import__('base64').b64decode('VE9BV2tjZmt4b0xxZURITWthV2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _αгеβΦΠьΞТ():
    value = 439870
    if len('') > 0:
        pass
        8
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjbuXVxqwYkiNjeU33fGPiI84Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΗЪуЯвΡУвδΖΛΤеиж():
    if 20 * 69 < 0:
        950
        _dead_9767 = 553
    value = 140740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHe2ZGA62pEpPT6on0+nAhwByjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вσΖυΛьйЧЬФΨзΩхыκ():
    value = 200335
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhXRdnoY94ckIh6c41i1MiYQ8nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩрΣβуΘвдλЫФΞ():
    value = 590749
    text = __import__('base64').b64decode('bXVLSV8xT3BzRWYxYVFFQm5aZnI=').decode('utf-8')
    total = value + len(text)
    return total

def _пДΨжΝыχЬсζДзбБлπ():
    value = 868972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB/eZHk90IVaERnw9wepGHR+vEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        463
    total = value + len(text)
    return total

def _ЫуηЫИЙτЧУаЗ():
    value = 732517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhC2TGUuq/gyEzex62eSPggE7Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЛεЯЮуэΖм():
    if len('') > 0:
        _dead_3185 = 519
        _dead_8474 = 705
    value = 750684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyrqUWIK/4YhCQSPzHGxGSl5vUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        962
        pass
        pass
    return total

def _нЩХшХΛαΓДУ():
    value = 590295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSnmeFNvqbwtIzyN+nupOhUHxX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΝθυωΠМэ():
    value = 823707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnvVP1w4/I8nCT+R4UyzH30IzW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йиΜМκΖоКεаΘцС():
    value = 67063
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX69OmNo8ZBQLgGGwGGbO3IMzj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΜρДЙχψъЮЛа():
    if 81 * 20 < 0:
        517
        81
        678
    value = 183725
    if 54 * 62 < 0:
        pass
        pass
    text = __import__('base64').b64decode('dFU2OU51cTVsV0tGNE8xUjRPVFI=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _φСЕΔχчХрςΗ():
    value = 452061
    text = __import__('base64').b64decode('TGFZS2NYdXZVblhWcTZCRHh2WEg=').decode('utf-8')
    total = value + len(text)
    return total

def _иλσαΛθΛΠЪвΠλРъПЯ():
    value = 901617
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3zda0EcxIpUOw6sm3eaHTwj400='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6883 = 310
    total = value + len(text)
    return total

def _юЫСаэλЖςςЖΥΚиЛΙ():
    value = 736432
    text = __import__('base64').b64decode('WWQ4cnBESmpXZUtZWlVjZERwclo=').decode('utf-8')
    total = value + len(text)
    return total

def _зЪюуЪСκюцΣΡηπг():
    value = 308958
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB3dPH839IsHAiqu/nHHDjEi43Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 50 * 95 < 0:
        _dead_4897 = 931
        pass
        _dead_2227 = 9
    return total

def _ТрТψΜΣрΨφшΒЦΠшΟΕ():
    value = 383132
    text = __import__('base64').b64decode('WFVWeERYSlZtdGZibjJ1aXVoeHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤνсЬΗКЭЩΑζΕφв():
    value = 163655
    text = __import__('base64').b64decode('TXFkM2hzZ0dRcjJLQ1pZWTZWR3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭςоιχΓΖδяЦω():
    if 26 * 52 < 0:
        pass
    value = 676772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQDJfmMIzLETbxz6mEeUYwR8tTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        420
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2302 = 869
        869
    return total

def _θъΗκеοНΗх():
    value = 719225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IALLVlwD+p0gCVf2w3rDbXEV6HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТОЭЭоχΩВΖХшζΜ():
    value = 95797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAvzdkgtxowlNCKM7UOhZg4Q0zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡλХυΒЖдЪцжρΤЫп():
    if False and True:
        _dead_3432 = 940
    value = 853024
    text = __import__('base64').b64decode('bXVGR3FDN3ozaUh1TG5faExIV2k=').decode('utf-8')
    total = value + len(text)
    if 19 * 18 < 0:
        _dead_2657 = 55
    return total

def _ηИБοπюΓы():
    value = 497239
    text = __import__('base64').b64decode('REkzajdSVDY5ZXhWRXdFVXROZmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ПχЙЮИЯΦсμяΡцбЧΡΖ():
    value = 888028
    text = __import__('base64').b64decode('Qk9aSDlwX0JTcEhmTEp3SkNqN2o=').decode('utf-8')
    if len('') > 0:
        _dead_5807 = 784
        12
    total = value + len(text)
    return total

def _ЫуьМλмχъГюΚЮΨБ():
    if False and True:
        _dead_6712 = 935
    value = 875009
    text = __import__('base64').b64decode('TzlHdlJjQ3J4S3cxY3BfblpuRG4=').decode('utf-8')
    total = value + len(text)
    return total

def _зψАВиρХШΔЮκЕΥЧωΜ():
    value = 938170
    text = __import__('base64').b64decode('WTNmaDZ3V0pYVFIzQlhoTTdJT0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ыаАΝЩщΗηПйΕф():
    if len('') > 0:
        626
    value = 345199
    text = __import__('base64').b64decode('UFFsTGd6RjhJdjAyQUVwUVFqSFA=').decode('utf-8')
    if False and True:
        pass
        _dead_6792 = 949
    total = value + len(text)
    if len('') > 0:
        51
        pass
        _dead_9777 = 526
    return total

def _уΠΙΣЫсΗнΗςе():
    value = 809780
    if 61 * 51 < 0:
        618
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fhu9d1AA8KEPERqt9wOAPgsZ9Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χЪοчλИЧО():
    value = 394258
    text = __import__('base64').b64decode('bU04OFJNa19UMk1OR0ZDNzQyZXA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        265
        _dead_2724 = 944
    return total

def _κБΙцбЛЛыΥ():
    if len('') > 0:
        _dead_7424 = 824
        _dead_1630 = 516
        _dead_4247 = 40
    value = 853205
    if len('') > 0:
        _dead_1042 = 945
    text = __import__('base64').b64decode('UUhodnQ5cmxnbG85SmpWVlNiWFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣθκЫпλЯΖенуχХБφТ():
    value = 766458
    text = __import__('base64').b64decode('V3B3SUtQckFZTUZZUVhmRkVfQUI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        972
    return total

def _щΩьχксШςνЦμ():
    value = 624277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDy2O3MN15kGGQW6xlyXOQQX8Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φЖΓвψыач():
    value = 944937
    text = __import__('base64').b64decode('UW9aNlIxb25DcDY1blppbmdLbVI=').decode('utf-8')
    total = value + len(text)
    return total

def _фСςιюнжЖνлХεрψ():
    value = 404853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgndUQUhrbI3KSGX5EebEXMh72o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ζνΦιАЯζвΡπηУоЦ():
    value = 829416
    text = __import__('base64').b64decode('bTBNQTRGWjRoNDlGMXVyTTRnaTY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3445 = 561
        _dead_6550 = 208
        346
    return total

def _рфΞΞцУУΨξтщуа():
    value = 793554
    text = __import__('base64').b64decode('ZERqNkpQeW5fY3B3U0xwUzF0b0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _сИМзОфςμИАСЯ():
    value = 446169
    text = __import__('base64').b64decode('ZnhpUmZtcTBRYmNpeVJ3ZEFPWmg=').decode('utf-8')
    total = value + len(text)
    return total

def _НйрзыНκЫьΜΩЦвДв():
    value = 296658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx/CRlIS87ErBVaR0FmiMwAo83Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρДηςЫЬОвК():
    if len('') > 0:
        23
        pass
        793
    value = 979364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IC7sQHYU6PslDBWSx3qiLRQJ4kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 15 * 93 < 0:
        pass
    total = value + len(text)
    return total

def _ωхΟθЙΘχμахιυΠβо():
    value = 559687
    text = __import__('base64').b64decode('UHpSTThLdkVrNUhpblZnVFlOQmU=').decode('utf-8')
    total = value + len(text)
    return total

def _мЗφРЙΘГΛМКбςΥ():
    value = 438845
    if len('') > 0:
        pass
        _dead_6615 = 516
    text = __import__('base64').b64decode('bnliZ0pZYlBTNlRJUVFmMWV0aF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭπгβЭЦΤηАБΞ():
    value = 592933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR/MdH03y/hRIy6X22KHDTd2zV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥПΝцуШΤΕСЕщ():
    value = 685545
    text = __import__('base64').b64decode('UkhBT1duMnNnNzIyTHYzSV9SbW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ТыюмαμюЩ():
    value = 927083
    text = __import__('base64').b64decode('WFI4eU9pVzBUVTVtY1JBUkJZbnE=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_8807 = 479
    total = value + len(text)
    if False and True:
        791
        pass
        _dead_6636 = 91
    return total

def _ζЪШпПОМщжΙρυεΞ():
    value = 472419
    text = __import__('base64').b64decode('cHBEdGF2anVOY1dzR3hqYVZ4ZVc=').decode('utf-8')
    if len('') > 0:
        _dead_2697 = 494
        pass
        _dead_9172 = 27
    total = value + len(text)
    return total

def _ωявзНТРСЭфδрУ():
    if len('') > 0:
        92
        _dead_2437 = 733
    value = 881701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETfnR2ELqq4xPVmixkLGDBQ21Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЕЫνзΥΒнБσ():
    value = 792868
    text = __import__('base64').b64decode('dElPdmxwbUdhVFd0RVM4UjNTOGc=').decode('utf-8')
    if False and True:
        pass
        pass
        533
    total = value + len(text)
    if 71 * 48 < 0:
        pass
        _dead_1073 = 33
        pass
    return total

def _бψэωИЛъΞп():
    value = 634499
    if len('') > 0:
        193
        pass
        532
    text = __import__('base64').b64decode('bkRXZENqVlNQdzZUU2tIcF9tOUc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        398
        pass
        701
    return total

def _изюχюЖмδгασψмΜщ():
    value = 607754
    if len('') > 0:
        751
        pass
        911
    text = __import__('base64').b64decode('ZXVIWkE1SmE1X3Y2dEJVRmJYRm8=').decode('utf-8')
    total = value + len(text)
    return total

def _АяφΤщйβЙхьΦΕΙΛ():
    if False and True:
        pass
    value = 793567
    if 93 * 65 < 0:
        pass
        233
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBvrUWID8IsPPRfy5AaVPXc701Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑмшΕвВалЯ():
    value = 535048
    text = __import__('base64').b64decode('WVFvWVpreGdTSjczbjF2VGVxZ24=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ιНгχΘрщΣ():
    value = 350776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwDCWwAa+6skaR+z0gSZYywA0WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΦупыЕУΟТяθк():
    value = 726686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz/veQQN2rspHSb66VqnMHEnzUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФεθюРςΔψГ():
    value = 575030
    text = __import__('base64').b64decode('akZYaTMxNlBkcUJ0V2YxbVhMeWc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4158 = 188
        pass
    return total

def _αуβςΩγдяБэЕНЭтρ():
    value = 504083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhnqTX0t5qdUDlyJ6geoIhI40n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦλРКЬПτδΡ():
    if False and True:
        312
        _dead_6048 = 485
    value = 722193
    text = __import__('base64').b64decode('TjZYTXJ3M0VxNW9EWG53dU90R2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ХφχУжпεΓΛдΧгСкч():
    value = 542690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgjbTFAc/4o3ahuHmV2iDnx31FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВцμΡчЮθАиλэК():
    value = 303108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CC7zT1lp0IxVbFrz0EOkISZ9420='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УйσфхшЖκΥЮΗдъΡъ():
    value = 18886
    text = __import__('base64').b64decode('cUpYWU1fWlVKbVlJaGFleFRkWXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΦЪжЕкКΕ():
    value = 689169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgPwXENoxKIhPimg3F+BGQgmyTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 33 * 13 < 0:
        _dead_3105 = 692
        497
    total = value + len(text)
    return total

def _РШφΨФдЩФзъθΟФ():
    value = 120055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxvSYHUt5rETIiW0mEK1EjMV1mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρωΧωЗχψεαΠ():
    value = 902266
    text = __import__('base64').b64decode('UUQ0eml4SWlXMTNwV3NBc1hFV0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒэгТΝКΟζВΡУ():
    value = 885239
    if False and True:
        pass
        _dead_3804 = 203
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiXtbX0N7YkFIB6G/E7AN3Met1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6643 = 356
        pass
        pass
    total = value + len(text)
    return total

def _θΑιднНвч():
    value = 553998
    text = __import__('base64').b64decode('T3VwV1Iwd1FleFM0eW44SDl4bEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ъСοХΟΩфЛтЪΣ():
    value = 316010
    if 77 * 16 < 0:
        _dead_3777 = 428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LALCPnY/3ZksbSKx2UXCYw0eyGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        694
    total = value + len(text)
    return total

def _ЬιтЕВβниζωψщеΤФτ():
    value = 90231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByywRF403aoQHTek7FHCDHMXvHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠтΝΗτνΨцθз():
    value = 231581
    if 16 * 16 < 0:
        _dead_3012 = 318
    text = __import__('base64').b64decode('TFBEbjF5UlRySEZLZDFVMDlCX3E=').decode('utf-8')
    if 65 * 39 < 0:
        _dead_9160 = 255
        _dead_3061 = 126
    total = value + len(text)
    return total

def _ΜΦθρΘоυγъз():
    value = 263840
    text = __import__('base64').b64decode('VXRCUGtBX215dWRzdjFpYkxzenY=').decode('utf-8')
    total = value + len(text)
    return total

def _οШрββжТьФψа():
    if len('') > 0:
        973
    value = 497629
    if len('') > 0:
        429
        _dead_1266 = 228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiK2SkEL/6AXLzyly0OyERIdzFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        934
    total = value + len(text)
    if False and True:
        _dead_8767 = 880
        _dead_3028 = 148
    return total

def _ЩьλЭмΞюРΖ():
    value = 415823
    text = __import__('base64').b64decode('dmdLYjV4X2pLTmVsc2k1R3Bzeng=').decode('utf-8')
    if 10 * 10 < 0:
        _dead_1085 = 845
        _dead_7578 = 410
    total = value + len(text)
    return total

def _ΥσНςΟΗΨЖ():
    value = 456827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyLITQYhxPAzCxmSkXqTGR0byDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9353 = 434
        815
    total = value + len(text)
    return total

def _ζΡНθсшΠтФθ():
    value = 143487
    text = __import__('base64').b64decode('VkMzdDdTZHdCaWxBemxyUktfaHQ=').decode('utf-8')
    total = value + len(text)
    if 52 * 85 < 0:
        _dead_2280 = 550
        pass
    return total

def _эδΚεΞЙσТжы():
    if False and True:
        pass
    value = 569105
    text = __import__('base64').b64decode('bUJZU1kyQnRhV3lzZDUxOE9qQl8=').decode('utf-8')
    if False and True:
        _dead_9185 = 652
    total = value + len(text)
    return total

def _ХМωЧδтζχФΧыН():
    value = 563078
    text = __import__('base64').b64decode('YlV2QTJBQnBwSFRuMTFvS01IaTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΓбσмГλοωΟΘ():
    value = 959207
    text = __import__('base64').b64decode('aFlfOUlFV3BmNnVBc2Rxc1dWczU=').decode('utf-8')
    total = value + len(text)
    return total

def _ИюμζиΥРΗΥζΝыκу():
    value = 608432
    text = __import__('base64').b64decode('aWVtNndKRkVxRElURE13dUZyNHE=').decode('utf-8')
    total = value + len(text)
    return total

def _РхюЧЭυРчоμ():
    if False and True:
        858
    value = 629450
    if len('') > 0:
        _dead_2756 = 447
    text = __import__('base64').b64decode('azI1dnJUYThkekZFbnJyMmkxbDU=').decode('utf-8')
    total = value + len(text)
    return total

def _еχОщηλνЪТ():
    value = 754378
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7gf2BoxvkzFj2n+ALHAHEW7UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧЙбΩдГкФщЮζбφцχ():
    value = 988445
    text = __import__('base64').b64decode('bnhhTjZMRGdSRVEwdk9MRUZnUU4=').decode('utf-8')
    if len('') > 0:
        469
        pass
        pass
    total = value + len(text)
    if False and True:
        419
    return total

def _ДρΤЛΥΓζδТьΞηСοΛ():
    value = 771730
    if len('') > 0:
        _dead_3053 = 23
        _dead_9697 = 269
        885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwvHPF8B+rtTICmWxFSSGQwK9FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙвχтδеОΧЖΗΜПΑ():
    value = 411658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzvoeUgI8Klaalmx92S5bSYNx18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΞΙдμΨλρыЕι():
    value = 895470
    text = __import__('base64').b64decode('RDJNeHJsNlBUSW9Ea3R2V2ZZNFI=').decode('utf-8')
    if len('') > 0:
        89
        28
    total = value + len(text)
    return total

def _ζзСОΔуОΝεΖΝям():
    value = 495157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DizAagAY3aVVNAy55wOFLh8/0GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θοΝΞοуοВаФΑ():
    value = 341281
    text = __import__('base64').b64decode('bzhDQ1RpZndyejBHYUltVk15NnE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _нБυМцΥУОПЦΘΝ():
    value = 296850
    text = __import__('base64').b64decode('cXc2eGlZYmF2SlRXdV8za3h6Zkk=').decode('utf-8')
    total = value + len(text)
    return total

def _δсбгΝнΩуиξпρ():
    value = 581138
    text = __import__('base64').b64decode('RmVoSEpsSE1SWTkwM0U2bzczMXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙеЩБКГЕθНΖоеΑу():
    value = 379720
    text = __import__('base64').b64decode('UTMxX2hMdDQ5NGxjUDA0NW5PMmc=').decode('utf-8')
    total = value + len(text)
    return total

def _иЦΤσΘЭΔтαШρъ():
    value = 864428
    text = __import__('base64').b64decode('bWhGeGRyVjNTRl9VOVZQV1NjTU4=').decode('utf-8')
    total = value + len(text)
    return total

def _хАЪεеТοΚΦ():
    value = 128781
    text = __import__('base64').b64decode('QkE3d0xWa1VDVmJ2REF1SUJxR1c=').decode('utf-8')
    total = value + len(text)
    return total

def _дЯМΨΝΝμΓ():
    if 7 * 2 < 0:
        148
        pass
    value = 978519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSjhQnRvrYwvNByR4QOKZwYayms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔλЙΤΟΥсЛπзчΜЭ():
    if 17 * 28 < 0:
        792
        608
    value = 673254
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRjydkgJyfg0P1yO0GezHXwJsFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        550
        _dead_6130 = 500
        pass
    return total

def _ΘцΖЭЫΟГГχъТщдЯГн():
    value = 727131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgbVPV8u6vgKD171kWm/CyAb6Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΗΩШюуДζΘчΤд():
    if len('') > 0:
        687
        _dead_8204 = 834
    value = 876967
    if False and True:
        pass
        807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCLyXgEO3f4FLViQ6nu6JhoIyXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЧθΖХτυΨКΥХи():
    value = 849786
    text = __import__('base64').b64decode('U3NWeWVtU05OVXRUdHpPWU5CcmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _οЭмЛσСιб():
    value = 732824
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx/QOFZh/KYNKxWXym+iMiQV0EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8821 = 36
    return total

def _ΞθΑΣнΔοκиζЬЧξЗΩ():
    if False and True:
        pass
    value = 923017
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQvtQlUczZACaz6mwmW/bXV/ykQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μАпΝρЮΑΛЯθυк():
    value = 205506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAX+SFAr9IsvADm70VqdHykrz2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥсΣСνξсщЭτ():
    value = 692773
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHzKRV5hraQHHVywnGKoGSArsEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΓΔПфραК():
    value = 10594
    text = __import__('base64').b64decode('UXY3QTcxcmVKb1lJTGpMVVZfUHA=').decode('utf-8')
    total = value + len(text)
    if 15 * 84 < 0:
        pass
        _dead_1549 = 316
    return total

def _АНσШβЫλлФДУк():
    if len('') > 0:
        pass
        _dead_8927 = 246
    value = 149548
    text = __import__('base64').b64decode('Z05vSEdiaUdCeXpxdUxHYkY2X0E=').decode('utf-8')
    total = value + len(text)
    return total

def _аΧμбрЩФГΑзЕЦоσλ():
    value = 322212
    if 8 * 79 < 0:
        pass
        502
        304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED/1PGk6wY8nNib7wmexPhAQ90Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ζЗΒхБШАшШιРюΓ():
    value = 578432
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAG0dEEAzYUMPzuwkA6XYQsQ40o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        895
    total = value + len(text)
    if len('') > 0:
        _dead_4668 = 569
    return total

def _ФιπЕγгΧКζχбДЖ():
    value = 18684
    text = __import__('base64').b64decode('Ym1LMEVIaWtrY29UVzVWMU5MWng=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΜξΦΗЯωРπьОζρф():
    value = 502028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgPwX2kWr60SYzeTzVLBLn0D4X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чφлЫΜΦβГрμт():
    value = 65129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDz2emcKwfE8Aw2HnnGqHnAl3Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юπΘΧΑчЙЪδα():
    value = 618658
    text = __import__('base64').b64decode('dGx2MHU4M0tDc3dzbzJRaUtyN2k=').decode('utf-8')
    total = value + len(text)
    return total

def _αωвμаΗьРθΖрп():
    if len('') > 0:
        pass
        707
        pass
    value = 473849
    text = __import__('base64').b64decode('dGl4VVhQbTVSMkdERnc5ZXNEa1o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _языэАХУчΧεΠ():
    if 12 * 96 < 0:
        pass
        pass
    value = 840133
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTX8OEkAzJICMQCSmGSCPHw/7Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_3013 = 95
    total = value + len(text)
    return total

def _ОЬηАкЧХΟЖΦδш():
    value = 710363
    text = __import__('base64').b64decode('Y2c5bGZpaE9COXphRTdRaWRSR2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΛρΞΤСйщυНΘΔхоЫ():
    if False and True:
        pass
        _dead_7390 = 538
    value = 984500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyayfEZp9PoKEjmC2X67BAs25jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 54 < 0:
        pass
        823
    total = value + len(text)
    return total

def _рΗебЪυаЧΕ():
    value = 257399
    if len('') > 0:
        pass
        _dead_3445 = 90
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAftQkQ27Zo1OBivnF2TFQEt8mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΛмλρДΚпΔψ():
    value = 562961
    text = __import__('base64').b64decode('UnhsMG5SS1VlNXFXcklibl9kQUc=').decode('utf-8')
    total = value + len(text)
    return total

def _дХфЩΧΔλβωщумО():
    if len('') > 0:
        852
        573
        pass
    value = 564201
    if False and True:
        951
        pass
    text = __import__('base64').b64decode('UTBQcGNWcEtiN2pKRmhDRUMwRko=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _яΤГиЮНΨВсΑНхмУЫШ():
    value = 78300
    if False and True:
        pass
        pass
        pass
    text = __import__('base64').b64decode('Z0dzZmhrYjVfVnFhNGlMS1ZkdnQ=').decode('utf-8')
    if False and True:
        _dead_8776 = 185
        _dead_4114 = 357
        pass
    total = value + len(text)
    return total

def _εжЯιЩэΞиωυΑЗеΛбЛ():
    value = 389791
    if len('') > 0:
        413
        pass
        pass
    text = __import__('base64').b64decode('SlRnUTZscjZET25pRGY3M2JrT3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛθКΑΜΑοδю():
    value = 776846
    text = __import__('base64').b64decode('R1o4SDhMNWlIRzhVbUJTU2NhZUw=').decode('utf-8')
    total = value + len(text)
    if 46 * 12 < 0:
        247
    return total

def _ιζςΣΙΓкнтΚиΥйΘЗ():
    value = 535309
    text = __import__('base64').b64decode('aW9YUmRNZnV3OVRrVmJTTnI2TEo=').decode('utf-8')
    if False and True:
        _dead_4334 = 211
        pass
        412
    total = value + len(text)
    return total

def _хШДвοОхзψв():
    value = 477735
    text = __import__('base64').b64decode('UUNGN0hIUXk5eUZtRzhIaHdNMWU=').decode('utf-8')
    total = value + len(text)
    return total

def _шοъдρΞΩЮΡРρкτФЗΛ():
    if False and True:
        _dead_5426 = 612
        304
    value = 669667
    if False and True:
        _dead_2407 = 356
        447
        _dead_5854 = 58
    text = __import__('base64').b64decode('YmxRMEN2Yjc3YXJiTXFNX29zeVo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΤηПλΠΔтςЖЧ():
    value = 343415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRfRYHY6rb8NFli63gegJxIus1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФμπьρθЗΘУυщФδо():
    value = 632310
    text = __import__('base64').b64decode('YjN5NXRIN2QzX0ZCQ25tcnh1NWY=').decode('utf-8')
    if 26 * 14 < 0:
        800
        _dead_8713 = 411
    total = value + len(text)
    if 9 * 11 < 0:
        _dead_9116 = 770
    return total

def _дЕςссФцлЫςхτЭΒΛй():
    value = 44063
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh3SOwZoy/A6FyW05A+bOXU87nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЧХνВТХгμΤ():
    if False and True:
        _dead_3175 = 45
    value = 192994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fh7xWnwL8J4BNF2imWGlAiAas3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΣΖбΚψЭйγνΩЪеШВ():
    if False and True:
        433
        301
        _dead_9866 = 162
    value = 639862
    text = __import__('base64').b64decode('cWFLeTd5aVlIcWw3TU40c0pQRFE=').decode('utf-8')
    if 52 * 33 < 0:
        810
        pass
        _dead_1842 = 299
    total = value + len(text)
    return total

def _ЫΕяЭШеνЖПΘиээ():
    value = 847944
    if 47 * 90 < 0:
        76
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgTPb2Maqbo1PQeSxm7GYx058G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        828
        _dead_4870 = 639
    total = value + len(text)
    return total

def _еРΡиΗΜΔΑ():
    if False and True:
        pass
        _dead_3981 = 993
    value = 102379
    text = __import__('base64').b64decode('dTh0T3piU0VSV0RNSVhVWWtpc18=').decode('utf-8')
    total = value + len(text)
    if 87 * 52 < 0:
        pass
        _dead_7486 = 257
        _dead_3960 = 530
    return total

def _ΣΓнЦпΑψЦБЙжΕПδ():
    value = 354346
    text = __import__('base64').b64decode('clFvRF9kcmZ6REFIVFJPT3FGMzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _тφοХЗΑΓΤΖеъЛσ():
    value = 757926
    text = __import__('base64').b64decode('TWdQbFNrTGsxb3FnNTVZdHlwZFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨЦεΖмтΥАΖΠΚбНΠ():
    value = 101422
    text = __import__('base64').b64decode('aHJ5OTNXakxkdkNOam90Y19mQ1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ъРζММШжψлΨΞсДфт():
    value = 96135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSy8WXA3xpA2EA6N0HiUNTYozjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΩΘАфΛШУ():
    value = 364553
    text = __import__('base64').b64decode('QkdobUlvNXNTc2lTUTRvQk5zRVE=').decode('utf-8')
    total = value + len(text)
    return total

def _сгφΗвωипΜУ():
    value = 441046
    text = __import__('base64').b64decode('T0lFOEw3RWd2SWdES0ZnZzRsN2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ζПΙоΡАδсΖγκξο():
    if len('') > 0:
        _dead_3388 = 552
        pass
    value = 620249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgjFOgQbrfAQAhr2kXWGYg138EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йъЪйΜκςКΕ():
    value = 31907
    if 72 * 21 < 0:
        pass
    text = __import__('base64').b64decode('TDYwQ1JCdVdWcG1sSXZJUGNlNU0=').decode('utf-8')
    total = value + len(text)
    if 55 * 21 < 0:
        _dead_6004 = 268
        887
        pass
    return total

def _υиθЬЬοъжКτΛΤηηБн():
    if 24 * 45 < 0:
        665
    value = 73496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3m8Z3Ix5K4pMgP68H/AGgYB900='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δВЯδаκΜεАца():
    value = 786985
    text = __import__('base64').b64decode('VmtDVmU2clFmT0t6Y3pJd3I3cHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩщиμτΜΧЮвЗХДΩΘСБ():
    value = 52937
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nn7VY1lq57ogHA2Q2WK1IHA56EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΥπщмΧΨсΒραυ():
    value = 777968
    text = __import__('base64').b64decode('YjZyekRiR3ZHbFZ0bDMxbm1Pd04=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9401 = 285
    return total

def _υсΩΙяηχиΡСю():
    value = 76341
    text = __import__('base64').b64decode('d091NlJsdkVISE8yQjRCeEVwVW0=').decode('utf-8')
    total = value + len(text)
    return total

def _гυΓэмλмГс():
    value = 95997
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3bheFc1661bEi674GK3ZTYEvW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΟРЫТβЕβΑ():
    value = 47133
    text = __import__('base64').b64decode('ZVZFX2lOSGlzeFNQOGFQRWJwTjc=').decode('utf-8')
    if 74 * 36 < 0:
        _dead_5756 = 580
        _dead_4674 = 423
    total = value + len(text)
    return total

def _ЙοфΑμцФрγ():
    value = 345320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBDlSG4D+4UGF12m7WSmNgh+xUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΟЪъЦΑθнΣХεеηа():
    if len('') > 0:
        _dead_4102 = 194
        pass
        _dead_1154 = 616
    value = 734316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBfoO2dg0YMxbleg7gfCLg8lwmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дκλЬтЩΚτИЯΡζрκАа():
    value = 481445
    if len('') > 0:
        pass
        626
        366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSLQYUJgrLE8Yij1+GCFJnAM7F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖдΦЗФаДΣбΧΓсХΩ():
    value = 829070
    text = __import__('base64').b64decode('cFUybXRIa3k0dkRqZUxicm9Cdng=').decode('utf-8')
    total = value + len(text)
    return total

def _исΒчЫΚΖΑΑΗ():
    if 20 * 61 < 0:
        7
    value = 503621
    text = __import__('base64').b64decode('dXNwcFdpWjlsQjNHaUNnOXRoV0g=').decode('utf-8')
    total = value + len(text)
    return total

def _σШτνΔьΦФιЙЩэοΦ():
    value = 655776
    text = __import__('base64').b64decode('b1dINzg2bVpKOWFNcWpfalpycm8=').decode('utf-8')
    total = value + len(text)
    return total

def _нЯЯэΦиХΗЬйцюВН():
    value = 452387
    if False and True:
        170
        _dead_8303 = 508
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB/oQnYzrL4bElf3zA+pJBo44Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τЖнгЫрНшβζτуΙ():
    value = 816363
    if 71 * 57 < 0:
        pass
        pass
    text = __import__('base64').b64decode('dFJZZzRQbVBNT2E3aThtVzE4UHM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        646
    return total

def _ρНζыΤΛПцθгωΞφοΞ():
    value = 294371
    text = __import__('base64').b64decode('djAwRGVvUHpFd0Q3REdpcEhPZEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ьнΜаχΝаΝ():
    value = 301452
    text = __import__('base64').b64decode('V2RfbU1zekllNGFSeGNfUnNhS1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΑφΠοжΑЦ():
    value = 293699
    if len('') > 0:
        pass
        16
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dwq2YwMDrp8bagyT7QSxZTM120Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8084 = 604
    return total

def _пКрγъρяχквοε():
    value = 634968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyLzZnIa7ockKh2hn0WSDiEFw2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ьΧВпЕУИкЗ():
    value = 695842
    if False and True:
        pass
        0
        pass
    text = __import__('base64').b64decode('ZGw2VDVIRnFVOTY2UWVXbU93SFE=').decode('utf-8')
    if 65 * 51 < 0:
        _dead_3848 = 893
    total = value + len(text)
    return total

def _ΞχΕνΛΔНΨΞΥμыΟСБΖ():
    value = 980733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQPRam5o9787bFaQ50OoNjMO1W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юςгРΚζρΝшсфζνЦлλ():
    if 60 * 69 < 0:
        369
    value = 185598
    if 82 * 90 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAHIOUUIr/oMHRiI5ACUbAZ28zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        595
        _dead_3001 = 152
    total = value + len(text)
    return total

def _εΟκЪδβЙЭЪЪξΟБЖу():
    value = 710679
    text = __import__('base64').b64decode('bU43bGtreENHTjUxQjJmSk4xS08=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ьНΘΣшΣЯойθНΙарЪ():
    value = 268115
    if 67 * 38 < 0:
        398
    text = __import__('base64').b64decode('UFQxaUhDN05xTVJmaGdzX0YwenY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗфКъДΤЧБφыМтТ():
    value = 684391
    text = __import__('base64').b64decode('ZnlvV29PWnRCYXpEcTdmejRtYnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ДсйфаειДАΣфъИЧκ():
    value = 707576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiC3ZHZp8pdSAgaInAWJBhwDzV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        898
        _dead_8841 = 165
        506
    return total

def _шуΤыηРεъΘυдνυ():
    value = 177440
    text = __import__('base64').b64decode('TWxPcURHYUtzZ3hfc1Vzc2ZGUFc=').decode('utf-8')
    if len('') > 0:
        2
        303
    total = value + len(text)
    if False and True:
        322
    return total

def _ΖбйэлпаР():
    value = 981674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDjdQHswq4oMbjqC40HGGTU922w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _екΔΩμЕρЯШОΓуπТо():
    value = 859375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDbWOQlq2vkbIBry/EC6HAEN/ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цкΖνΜхпСЦсЪШΜ():
    if False and True:
        _dead_6593 = 508
    value = 961203
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAfwbHgz2b4QIimh+WSTIAw9wmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦШтгтΝσΧэΥ():
    value = 372454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID39V1htqZsnIwCa936YJQwB6ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рцКΞΧΣΜцдΛмψЖΚξ():
    if False and True:
        pass
        pass
    value = 344133
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR+wS1Ar3fsoLTaw7XGEZj15sk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υμьΛлΧШΙΣγΛэюдгМ():
    value = 768512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgzFOQUbpqoCP16m5XC4MCMdzUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыωγЫθΜοшοГъЫ():
    if False and True:
        pass
    value = 912922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAeza3Qo+LFVNSS57XGXOTJ600M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΛКβОΣПМΠαΞЗσ():
    value = 40295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzvIPnBqrIFbDSeW+0WnJggu72Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΒжььЬαтСИЖκ():
    value = 65651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj3sNgQ98KkOKlr3m3nINR0cvHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΦγΗЕПэЛΣΝη():
    if len('') > 0:
        _dead_8280 = 426
        pass
    value = 281728
    if 19 * 73 < 0:
        _dead_6776 = 335
        pass
        580
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxvcUUts/KZaE1eOwWLFNxcY0Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тбΒфμβюΒιч():
    value = 666147
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('bzh6cm1qcGxZazQ4dHBTeHRKdWc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9267 = 717
    return total

def _ьеиаиΗηЪьσΟАμ():
    if 41 * 30 < 0:
        pass
    value = 15919
    text = __import__('base64').b64decode('ZzlNaTM3MEx2aTdVVmt6dTFlZlg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8607 = 433
    return total

def _юΟеχΖΘАΙзхΙЪ():
    value = 609189
    text = __import__('base64').b64decode('UzNmTzhldG9ydHpUUmxaazVPYTQ=').decode('utf-8')
    if len('') > 0:
        366
        _dead_7138 = 971
    total = value + len(text)
    return total

def _δНσЙоπлб():
    value = 491018
    text = __import__('base64').b64decode('YTRMaW1LTVdJWnhid2pCdDJfZ2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮηГхъбХξυцпΥΛΠ():
    value = 72937
    if len('') > 0:
        73
        pass
        pass
    text = __import__('base64').b64decode('c0NsWHdfbWNhNW5Ya3NDR3FoUko=').decode('utf-8')
    total = value + len(text)
    return total

def _сШутЫωяьМдХεΕТц():
    value = 737458
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By7rdkgv8oouOzeb2nDCEi990Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛщЪЬχβАрГЫИуζΖвч():
    value = 49937
    if len('') > 0:
        _dead_1083 = 493
        _dead_6519 = 459
        181
    text = __import__('base64').b64decode('VnpNRjRwWEVmUEptQWw0M2UzaDY=').decode('utf-8')
    total = value + len(text)
    return total

def _πГВψκΕжΞълМ():
    value = 675601
    text = __import__('base64').b64decode('cV92TDdDSUZKTVFtUnkxN0ZtaVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _УЦдиУэηΟпЯγМ():
    value = 966615
    text = __import__('base64').b64decode('Z1p3UWtCRWhQbzY5aXBPSGFWZnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _оδЯΤояДБиЬх():
    value = 671830
    text = __import__('base64').b64decode('VzNLZjdydk5zZWxFTEdaVkxsN3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if 86 * 93 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    pass
    pass