#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ГъιзСΜΨΘС():
    value = 264188
    text = __import__('base64').b64decode('TVJzdWVSOFpZWDRzclBiVTJjcU4=').decode('utf-8')
    total = value + len(text)
    return total

def _зζЩщОΖюефκΣщ():
    value = 572534
    text = __import__('base64').b64decode('aTZ4dXE1b3dfTExXNEZJY2tacDM=').decode('utf-8')
    total = value + len(text)
    return total

def _γмВэΓЗЪσсΙКΜ():
    value = 803305
    text = __import__('base64').b64decode('cVNoZW1BNmdzM25SNVBTTVEweDA=').decode('utf-8')
    total = value + len(text)
    return total

def _СγаΥγΜΘГцптМз():
    if len('') > 0:
        86
        pass
        _dead_5283 = 31
    value = 159338
    if False and True:
        pass
        _dead_3515 = 935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nye8O3hpqqAlICb7n0+fJQQE62s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠуУРγНΦэФβ():
    if False and True:
        _dead_6771 = 243
        _dead_3466 = 369
    value = 827146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHfQPwEj2KcJblmI0QCTNQEm8H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _соЗΑφюρεДξОНкΟщ():
    value = 216539
    if 93 * 24 < 0:
        _dead_4431 = 742
        _dead_7791 = 195
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgnobAZs6owwaBvznHqIEn0d8DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΠшΡТζΝФ():
    value = 640343
    text = __import__('base64').b64decode('a2M5T1RwQ0xhTnRkNG9oanBNUVA=').decode('utf-8')
    total = value + len(text)
    return total

def _λυΠΖьΗвщΦΣшΠΒиψ():
    if False and True:
        631
        _dead_5069 = 951
        _dead_3478 = 640
    value = 587099
    text = __import__('base64').b64decode('d08zencxYTJoVjl0V2NoaDVUeTY=').decode('utf-8')
    if len('') > 0:
        734
        530
        _dead_2524 = 309
    total = value + len(text)
    return total

def _ΖΨЫθеюМΥ():
    value = 970943
    text = __import__('base64').b64decode('Wng0N0F3QjRCdmJlQ1ZzOUl3N0U=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _τПКΤωРΦιШΣΛ():
    value = 892271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRDhXggdx6taIwaC2lKSYnY2608='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΣΣарЛвФбЭυмнβвж():
    if False and True:
        687
    value = 448557
    text = __import__('base64').b64decode('ZzVZTG50cXJrazg3Y1dzVTZuS0o=').decode('utf-8')
    total = value + len(text)
    return total

def _θεχдΕΗΘдюρΤ():
    value = 558908
    if len('') > 0:
        _dead_7506 = 81
        541
        _dead_3936 = 75
    text = __import__('base64').b64decode('TW1VQXJmMk15Q0w1QTZwWFVvN3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ШБΟЪСΚЙГМωДβЦМю():
    value = 112239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyPubwQa6r4WLSqX0mymZS4g814='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γзπпμτДЧгΑт():
    value = 694851
    text = __import__('base64').b64decode('UmQxRWVZRE5wZUp1R3BfTXNpcVA=').decode('utf-8')
    total = value + len(text)
    return total

def _σЕσΘγеЛГМμЪБбоЪ():
    value = 897358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAvQVGAc9qNbOB26xVuFZRUqsHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        691
    return total

def _ЯκЗиΦΞьΜΤχнвЮКР():
    value = 763696
    text = __import__('base64').b64decode('eU5OaERKc2RSS0Y5N3ptQnVwaUM=').decode('utf-8')
    total = value + len(text)
    return total

def _δбςΥβΠζЬ():
    value = 858418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBexZVgty54FNzCE/VykFTB+tz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 38 * 78 < 0:
        pass
        pass
    return total

def _υΝЗНОΚκДυΖюДФб():
    value = 427094
    if 68 * 56 < 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('UFVSQ185QzVGVV9CSmFsc2FDekk=').decode('utf-8')
    if False and True:
        372
    total = value + len(text)
    return total

def _ЭЗРцЖΦвηНжфΓП():
    value = 806118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwjefmAepv8HGB2C8WCiZx8KznY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΓΕΔЦрИпσу():
    if 11 * 27 < 0:
        pass
        _dead_4591 = 987
        pass
    value = 820402
    if len('') > 0:
        pass
        637
        _dead_1527 = 477
    text = __import__('base64').b64decode('V3dBMW8ya3lMTzZ5TU5SM1VuemI=').decode('utf-8')
    total = value + len(text)
    return total

def _эΛбМмЭΚлσах():
    value = 292844
    if False and True:
        pass
        _dead_8117 = 337
        28
    text = __import__('base64').b64decode('cTdEbWc3Y1pBbVhIckNWRHhJcmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ФжΑТбΞтμЙΘ():
    if 6 * 37 < 0:
        _dead_6898 = 665
        454
        966
    value = 181140
    text = __import__('base64').b64decode('V0FqSjc0aFU5aDFZRXhNOFA4VWQ=').decode('utf-8')
    if len('') > 0:
        _dead_6392 = 498
        547
    total = value + len(text)
    if len('') > 0:
        486
    return total

def _щΗафмυъйХпроΛЪх():
    value = 379022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXbKX3tt5JEKK1n3zm7JYCoutV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        252
        562
    total = value + len(text)
    return total

def _рЛΑφΜгЕΞΟΝ():
    value = 604565
    if len('') > 0:
        pass
        47
        _dead_8287 = 32
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzayfwcD7rgRMR2X33eFBn0g1Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3925 = 721
        569
    return total

def _γАΡοыУξйЬ():
    value = 379623
    if len('') > 0:
        106
    text = __import__('base64').b64decode('QkRNUVZKazZMUkhOa2ZQUXdOVlc=').decode('utf-8')
    total = value + len(text)
    return total

def _РοΒфΟΝωАηΘ():
    if len('') > 0:
        pass
        _dead_1269 = 946
    value = 10541
    text = __import__('base64').b64decode('elFidlFoSlJIVjFYQzBaNFZjSXk=').decode('utf-8')
    total = value + len(text)
    if 66 * 96 < 0:
        _dead_9520 = 880
        _dead_4019 = 193
        pass
    return total

def _ψξΦцВоΤйψλκНф():
    value = 8285
    if len('') > 0:
        _dead_7422 = 308
    text = __import__('base64').b64decode('d25Nd3pqSGJudXg2N0FmOFBfOEc=').decode('utf-8')
    if len('') > 0:
        654
    total = value + len(text)
    return total

def _кПЧφΨΞΒД():
    value = 305584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzrdZksdx45WKy6l5g7JJD08snw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σФΛΦυαΗτν():
    value = 333378
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXnnQAcY9bsrHACIz0HBICYp4lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 63 * 42 < 0:
        _dead_6181 = 605
    total = value + len(text)
    if len('') > 0:
        _dead_1112 = 887
    return total

def _ЦζЪΙКΨιηыΦΜОч():
    if False and True:
        pass
    value = 264849
    if len('') > 0:
        _dead_2984 = 913
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQXJQgErrv8kHwCQykSWY3J+0Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ибΓΧМщЬкΟрοю():
    value = 840526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED3wZWAI8J8mABqOxQO6GBZ/tXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΘнЬщЛдМνтγн():
    if False and True:
        pass
        _dead_4833 = 171
    value = 894535
    text = __import__('base64').b64decode('c3pPNURxcWhrd0lxM1ZDNlVQN0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒрΩыАШΝлγрЖУОψα():
    value = 878141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjjnagE+6v8ybV23kV2CMi0Q1FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φχфΝθБыθΧтιφыτнγ():
    value = 448794
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw7Jfmgz6I1bLTeGzFmWLQ061WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣсκЧзПπвηЬЖСДу():
    if len('') > 0:
        871
        721
    value = 794591
    text = __import__('base64').b64decode('WGV1VHk5QVhaQ19haW4yWjFVUjc=').decode('utf-8')
    if 35 * 17 < 0:
        pass
    total = value + len(text)
    return total

def _νйΓχκЩыкЛпχбΘИ():
    value = 560243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhzuXANuz5ILLgqcnXOmEXEGtjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нгчΔмηмЧхкЩ():
    value = 689642
    text = __import__('base64').b64decode('Vm54djJjbEZ4Tnhkb05rSmtlV0s=').decode('utf-8')
    if 72 * 77 < 0:
        _dead_7736 = 780
        pass
        _dead_9776 = 916
    total = value + len(text)
    return total

def _жξАΕАЛΚσΠТаВο():
    value = 416642
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAjbR24R7L1VIwKFzUKBYyMeyEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΣφьЦЭΨΣΖψΞвΜι():
    value = 614709
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3/tO3IO67gXEDaG8gS+P3QZyEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΗУщЩяΠν():
    value = 441316
    text = __import__('base64').b64decode('dnFxZ05Ebm02NzUxOGM5RzlwRFk=').decode('utf-8')
    total = value + len(text)
    if 8 * 15 < 0:
        732
        pass
    return total

def _ппΣΒιоΓΣΟщ():
    if False and True:
        pass
        339
        _dead_1291 = 838
    value = 487549
    text = __import__('base64').b64decode('UGlsOU9DUnNXQXpSa3E4c24xbzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ПερЖАΗρτ():
    value = 480779
    if 89 * 59 < 0:
        pass
        pass
        _dead_2823 = 882
    text = __import__('base64').b64decode('YlFfWDBPVjFqdE1FQk9hV3p1aXY=').decode('utf-8')
    total = value + len(text)
    return total

def _εγΥδИαςКρбΤνЛνυ():
    value = 989723
    text = __import__('base64').b64decode('YlUzZG50bEJYTTNDal9TbktyVDE=').decode('utf-8')
    total = value + len(text)
    return total

def _πρгαЖГΗсЛ():
    value = 640849
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhD3ZUEA9q0vIj+Iz0OVG3MO1V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ожσУТзБυЩμьЧюцΙ():
    value = 884014
    if 82 * 42 < 0:
        87
        14
    text = __import__('base64').b64decode('ZFloNUpaX1JQT1Q3R2JHcF95Q0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _зТαДоαаΔФДАъλБ():
    value = 17574
    if len('') > 0:
        601
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ71TQloxqIKKwaG4H2XOTwltlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бοΡьΠХщКЙсЪ():
    value = 312143
    text = __import__('base64').b64decode('ZWJqT3VfNlFmZlEwREs3UDE3RUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛυьэНмιБ():
    value = 434788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Anz2a14R1782aAapnQDEOjcVt3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ожκТчκЭο():
    value = 721995
    text = __import__('base64').b64decode('cXZqb1V2YmxRYnpTemVFU0FlMXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΟвИТхЦЦяσюυΩдТ():
    value = 694420
    text = __import__('base64').b64decode('ZjVNWFpJcU8yTkhvMUdfZjV4TmQ=').decode('utf-8')
    if 17 * 67 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΤЖζΗЙЮδЗБъХρκдΩ():
    value = 220842
    text = __import__('base64').b64decode('TEltVUhBOWJVVmN4cXV5OXdMRE0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        426
        372
    return total

def _ЦАцфΥЙфЭЕНΘГμыЬτ():
    value = 39922
    text = __import__('base64').b64decode('U3pla1FlNUV6ZERnRzJObGdXMTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΝφсοθчμэτэ():
    value = 87929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQvRQQArxvAyLAGw5lepPX0QzEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕэйΩβщИΛβТэΙΩ():
    value = 985709
    text = __import__('base64').b64decode('emFoUGZDNU9DZFcyWnJfVHF2UHE=').decode('utf-8')
    total = value + len(text)
    return total

def _бУмГοΦτПэ():
    value = 129237
    if len('') > 0:
        _dead_5682 = 467
    text = __import__('base64').b64decode('UTBaaThhZEFVQlFOVnZ1bTBySjA=').decode('utf-8')
    if False and True:
        _dead_7347 = 73
        _dead_4184 = 940
    total = value + len(text)
    return total

def _ъγπΝγГлΗПыΩуςВ():
    value = 67451
    text = __import__('base64').b64decode('WFRkM2J5N210NGFwM2pVbExhb0U=').decode('utf-8')
    if False and True:
        _dead_2987 = 313
    total = value + len(text)
    return total

def _ЬННτφοαУлΩ():
    value = 366459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3uwO0UO1/lVLB2t7WyyGREVykI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΗωΧЗψЖНКСθигΗγ():
    value = 381533
    if len('') > 0:
        200
        725
        885
    text = __import__('base64').b64decode('aFN5TUlteEl4NDZXNkZ4WmRaZW4=').decode('utf-8')
    total = value + len(text)
    return total

def _аΖСщτдфΨγοКТ():
    value = 778379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBvHZ1ptrv86bweW8F2oGywn7W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡЕЫгΡθОЧ():
    value = 713774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD/sQUs6qZkUbhqNmWm9PgB69l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _смΗНοеφффРνЛ():
    value = 692613
    text = __import__('base64').b64decode('UDdUMDZoMWNrQkd5NFZFeTJnelE=').decode('utf-8')
    total = value + len(text)
    return total

def _ξμжшбνУЧюЧкΠβΔ():
    value = 502413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQT2Qglg749QHyuow2KbCwgjs2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9689 = 870
        688
        _dead_9208 = 556
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЖгνδФЖΛΡχΖЪкνΡ():
    value = 547725
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji20Q0sKqqMTal2U32CzJhwFt20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АКΟυδбΧЛΖρм():
    value = 273227
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjXiNnMqyoQgG1+ymwWabC8n8mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъВΡббχΔΑеι():
    value = 277063
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyzBY0Axqa81HgyV6XzDAiYMvTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΛиΛΙуМШΔΣыΠ():
    value = 758419
    if 31 * 75 < 0:
        _dead_9405 = 967
        944
        _dead_7175 = 461
    text = __import__('base64').b64decode('UXVmWm11eXlwN3hIblpMNTBSSnI=').decode('utf-8')
    total = value + len(text)
    return total

def _иΙπЙЧЛψжκφΛ():
    value = 28399
    text = __import__('base64').b64decode('TGNGbUlDYnpVc2NPNkZwc2tEX0E=').decode('utf-8')
    total = value + len(text)
    return total

def _фуфьψАжθΣχЯςД():
    value = 992743
    text = __import__('base64').b64decode('a1N6RUM3MHRGd2ZFN0J2M19sSjU=').decode('utf-8')
    if 51 * 36 < 0:
        997
        _dead_2580 = 290
        pass
    total = value + len(text)
    return total

def _ΙΖшοЖХСХ():
    value = 627418
    text = __import__('base64').b64decode('WTJDSV9zSDFMaUQxanFzZGVRQ2s=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        220
        _dead_3325 = 52
    return total

def _ςХсЫΘΟюШ():
    value = 88147
    text = __import__('base64').b64decode('UTEyM0NtNk1KdnFqZUNXbUtQdk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕφκηзяχζЯ():
    value = 190324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgDIfG4QqLpRGSyL3mSZF3Z+tn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пηРжτβсГБЗы():
    if False and True:
        pass
    value = 984828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiLOR1kUrIIEClmC+1W9ISwK0T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 6 < 0:
        _dead_8069 = 975
    total = value + len(text)
    return total

def _ШЗυΛТщРЧЗСлαЦчΓ():
    if 67 * 25 < 0:
        593
        14
        _dead_2460 = 89
    value = 953290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICrqP1od3P0lGTeZ5g/IBA4QyHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩφКΓΓМев():
    value = 863750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MC7xRGkJ6J4QN1mkyV2oZhp880U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лЯγφΓΦΗΗΑΧχΝΛьхц():
    value = 515159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwzKdlw9qYE8MSCn4FXBJQIg6z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СεЪЫΦщΦоыЙуΩЙχя():
    value = 402153
    text = __import__('base64').b64decode('RklvWmpzVDZHRzlkWkxMOU01S2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ξТзςцβюαХжΡΗЭΥГ():
    value = 483355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxDrd2gy85ggIg2lnlOGPgd+5WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟραЭыςкΤ():
    value = 375930
    text = __import__('base64').b64decode('dkhqY2VBaGFzV3BOSHpYZ3N1UWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΨйэςΠθт():
    value = 594936
    if len('') > 0:
        _dead_2221 = 680
    text = __import__('base64').b64decode('ZUo4NmFSTjBLUTMxY3BRdnRVekk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗРШВδξγшЦЩъфюлΤ():
    value = 940053
    text = __import__('base64').b64decode('QWpvQ19nUWZZZnloVEM3ZjVfbG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪβςгΥΒялΑЭΙЛνЫс():
    value = 265467
    text = __import__('base64').b64decode('dDY3bzJ0dVNWUnRTWmttd0dGcTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤтдФИШэЙтШπбяρа():
    value = 363623
    if False and True:
        463
        pass
        _dead_4184 = 174
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ln/TbGsz9q8hHBfzy2OyLAgZt2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓχЭΩтΒДξРΝΕΣ():
    value = 633448
    if False and True:
        _dead_4555 = 523
        pass
        _dead_9359 = 15
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDnBegk22Lo8aj2Km3GREws911c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 48 * 40 < 0:
        _dead_2874 = 366
    total = value + len(text)
    return total

def _кяЫУιφςЧЬнπюυЪ():
    value = 672374
    if 87 * 94 < 0:
        pass
    text = __import__('base64').b64decode('d0M1VkZubjNrY1psRlRpdzFqVTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЖΞδьХΚχπшσхψ():
    value = 867221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwjBS2Rr5IcvIzyuzmKTEwc17G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φθОЫΡКщχШδхΑНζО():
    value = 879201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQXNWVkRr/orMQS5zVeEATwewV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чχьЦЩΙИζΛЮкΧТ():
    if len('') > 0:
        515
        200
    value = 348301
    if len('') > 0:
        544
    text = __import__('base64').b64decode('eVplckhzQm9FUVU4T3ZtZllCaWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ьюпσφбβΗЩпнео():
    value = 423951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiDjXFMTp58iGQ7z5FKcHRR9t2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΜлΕδлΚγ():
    value = 561215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAe0e14syL0hABaG8mXHbH17tWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФэоΤΝκЭξ():
    value = 747156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyHpNgcc+5EpaimSzEyYYjEE73s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υфπРεтζхΣоЮЫΔв():
    value = 431244
    text = __import__('base64').b64decode('QkNXa2V1S1ZITFB6ZGFpQnhKWU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ХщΖЮШμМШггΩшЯσΔ():
    value = 137816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHn+ZkYD150NLVer+VHFZwN+s1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝЩΞмΤзγЭАΑгЛХрпσ():
    value = 812486
    text = __import__('base64').b64decode('Z1E1UHhwOU93VERhTTZrY1MzbWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΜυцвΦйиΤЯΩлЕ():
    value = 699262
    text = __import__('base64').b64decode('VlhPSjhhcHZ0eXlaN1BrR21heTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ъδщЦτцςРйψюНξ():
    value = 981961
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxXjdHQL978COVat7V+KBAQ+w3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΤьтЫЮхтаы():
    value = 828041
    text = __import__('base64').b64decode('YWtRbzY3d1dFX3pVMlByMlUwYTc=').decode('utf-8')
    if 41 * 48 < 0:
        _dead_9161 = 256
        pass
    total = value + len(text)
    if False and True:
        _dead_2445 = 677
        pass
        pass
    return total

def _σΒΑцξολΙηГ():
    value = 295805
    text = __import__('base64').b64decode('VFlrUk9vclpTR1Z5Y3VyWFZLRTA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _грΔШςЪШЧ():
    value = 113358
    if False and True:
        463
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aib3a0dprZEuaViO/UGAYBQJ3Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΒμλΖФςσЛЧΜΖэΡ():
    value = 323327
    text = __import__('base64').b64decode('V2VQeWpqTVNmNXVIYk9xSklEZDE=').decode('utf-8')
    if len('') > 0:
        _dead_2844 = 610
    total = value + len(text)
    return total

def _ΝЭξαжеζεΨδШААΚ():
    if 46 * 87 < 0:
        590
        _dead_4486 = 308
        pass
    value = 710242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiGydlk9zKNQYiD7/2mHDg44yX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦщэяТмчтεΗгЩсюΜ():
    value = 68410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETjlO24T8vsPYwaI8HS0Mw4n10w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫвνяαЬШДчьтΕЗΥ():
    value = 943476
    text = __import__('base64').b64decode('RTAxSlhESHFPanBGbmhRNzJydE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝефпыΘσμβΡΠМΡ():
    value = 932518
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz/qYFturpEEHx6z8HeePT08tVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рьяжμЯэВψ():
    value = 808129
    if len('') > 0:
        685
        pass
        _dead_8164 = 29
    text = __import__('base64').b64decode('UjBIWHRrRmZPZGJ3TkZTU1pjRXE=').decode('utf-8')
    total = value + len(text)
    return total

def _φΡκшЗЫфΗΓξνΡΝ():
    value = 798485
    if 92 * 59 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mw7KNkAj6btQFyuS436fLQoE6T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5021 = 855
    return total

def _эςЗбЛβРщэЭΜΟ():
    value = 697114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxrPZlMO+KQGag2P+HqgFgAdxUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йζСοςТθр():
    value = 197055
    text = __import__('base64').b64decode('R2p3cVBPb3BvMjdORUxLbHlVcUo=').decode('utf-8')
    if False and True:
        _dead_8916 = 141
        pass
        _dead_4476 = 164
    total = value + len(text)
    return total

def _ювΜγΞБДΒζψхХаЩ():
    value = 962203
    if len('') > 0:
        _dead_2628 = 184
        _dead_4833 = 302
        pass
    text = __import__('base64').b64decode('T1BvOF8xbGFXR2NieExmTlprUjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ПμεРеЭωΣяΥкΙЗЪн():
    value = 487980
    text = __import__('base64').b64decode('dkdZU0xFZF9TR3JDSjd6dkF3QW0=').decode('utf-8')
    total = value + len(text)
    return total

def _бζΑμΞθШΤк():
    value = 731570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CivBZwUo3bANMAuu+AGeFTMesDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вУВяΧсЗлРΘБΧΛуБг():
    value = 486556
    if len('') > 0:
        347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M33MVkVp8J08KliQz3HHEy033Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
        400
    return total

def _тζΩлщуЖыябΣΣЩε():
    value = 945168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyzpWQYyr4o5GDu00W6EDHIKwkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗЙΤψбΗЭшьЫ():
    value = 304567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABa8WHMU6fgxGTeskWW3AzY+xmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ККСЧΩАρΜΕжВл():
    if False and True:
        _dead_8921 = 649
        _dead_4571 = 97
        974
    value = 699724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnbXf1Yf1bpTYhaP/3ygNTQW3G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 15 < 0:
        _dead_3783 = 167
    total = value + len(text)
    return total

def _ΙзШνзбдΛХПЩ():
    if len('') > 0:
        pass
        289
        803
    value = 52472
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh3PdnQ11/tVNlu3/W+ZZXEds3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        802
        _dead_9664 = 702
    return total

def _пΚгΚьгФн():
    value = 607638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjvUXFs98J42Fhqp5F6oY3MX6n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΑПЯΘфИБηЙО():
    value = 258982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H36zP1Id74YgayqX51qjLAMbsno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОНΚвиЦжБξ():
    value = 906055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQHHYHMJyqQ1NC72kWPIGRI5skM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εаωθцЬαчЖΘΙНΓΚ():
    value = 863999
    text = __import__('base64').b64decode('dFJ6eV80UVQ3Q3dBakhPb2NLQ0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩЫВчлРΚνΑΘлыЫХ():
    value = 755622
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bne9R2k+9b0Xbiyg5XyIHSQL7E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΦрωνРЦΡ():
    value = 495425
    text = __import__('base64').b64decode('VGFoVjd5TExsd3ZYbnRHWDdSYXk=').decode('utf-8')
    total = value + len(text)
    return total

def _иЯιЗπызЭΦξςмЯ():
    value = 509708
    text = __import__('base64').b64decode('TVhnYzZsX3J3UDU5a2dESWcxYnM=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΘμДЬκвεΞфΔπсκшмА():
    if False and True:
        pass
    value = 791559
    text = __import__('base64').b64decode('RGhrVVk4dGF2WlBOX0gxQWFKYUg=').decode('utf-8')
    total = value + len(text)
    if 38 * 76 < 0:
        98
        pass
        23
    return total

def _ΛχΛИοЖΒУ():
    value = 307174
    text = __import__('base64').b64decode('d2FEelI0RGFsY2x2QmtIOUVyamc=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΠιЭкΨэе():
    value = 991176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQv9PnoJ5LoPLDiCzXiBOy0b5VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 46 * 85 < 0:
        _dead_4573 = 353
        pass
    total = value + len(text)
    return total

def _ЦжИΥЬЬЬδЭ():
    if len('') > 0:
        681
        515
        pass
    value = 101652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDrMX24r1KcKERWUwlCqZD06ylc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4546 = 29
        _dead_3223 = 103
        pass
    return total

def _нуЪшйющзПπЩΤпΜГ():
    value = 966589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxjeZHgG5owsblar+neHDA0s42c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩМδуκяπЬΒΤΠЪГ():
    value = 742431
    text = __import__('base64').b64decode('WUJhczlEUEw4QzFNaGs3SENXSm8=').decode('utf-8')
    total = value + len(text)
    if 78 * 23 < 0:
        pass
        pass
        pass
    return total

def _шΓЛζΘЪЖЙТεку():
    value = 983714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhzeQ0Rp8otUGAuozE6oAi0NtWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖцΨБΨкйу():
    value = 335718
    text = __import__('base64').b64decode('ZTBxQXpmUlk1TDRkb2FzYU41cHE=').decode('utf-8')
    total = value + len(text)
    return total

def _σΦСУБτΨДΦ():
    value = 582667
    text = __import__('base64').b64decode('Y2dDRFdKdjh6MWNWUUtLUkI4dW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬяВНсбскЧуΙΓ():
    value = 673432
    text = __import__('base64').b64decode('anJVWmR4QmUyS0cybjBpTkRKZ2E=').decode('utf-8')
    if False and True:
        _dead_3546 = 934
    total = value + len(text)
    if len('') > 0:
        136
        pass
        pass
    return total

def _ΜюаЪηБпРφн():
    if len('') > 0:
        pass
        _dead_2488 = 348
        955
    value = 362186
    if len('') > 0:
        132
        152
        _dead_2802 = 558
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISHIW1cI76IBKQmGxAOgLSp+x2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        959
        _dead_6855 = 598
        _dead_5662 = 771
    total = value + len(text)
    return total

def _ШΣБнζΟΡЪ():
    value = 196756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDfCP1YS574THF6F0lqAIw41110='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 47 * 54 < 0:
        567
        _dead_8783 = 415
        pass
    total = value + len(text)
    return total

def _уΣχрцχЯΚοИяэ():
    value = 409457
    text = __import__('base64').b64decode('Sng2blJtaU4wVWoya0E4NjdEMnU=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _ψΓΝηχξξнагЬΚωΕн():
    value = 827364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERexZEQv0KEHKwmq0nKRMTcC0lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ονΥЭжаеЗПек():
    value = 537234
    if 46 * 81 < 0:
        405
    text = __import__('base64').b64decode('ejZMejJlS0MzWGJTbEdJMTZ6NUg=').decode('utf-8')
    if False and True:
        _dead_9642 = 643
        370
        pass
    total = value + len(text)
    return total

def _χГГыШςяЪαξМΝ():
    value = 54737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In/baHYY1r9RLV2hzX6bEhQ1/n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΘяоАΚэθωУΠЗъ():
    value = 726609
    text = __import__('base64').b64decode('a2l2TVBpdkFoS1lYeWpneVVjWGc=').decode('utf-8')
    if False and True:
        48
        pass
        _dead_6412 = 809
    total = value + len(text)
    return total

def _аОМбЖЧыОζηηуЮШш():
    value = 219522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbDTWcq7aYBYiuZ7nmXNwsn22c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗнжВяδγΦ():
    value = 34066
    text = __import__('base64').b64decode('c1JSY01wSVE3Yk1IX21DVENnbWk=').decode('utf-8')
    total = value + len(text)
    if 65 * 100 < 0:
        pass
        _dead_8844 = 276
        530
    return total

def _МΠНтыξπΗ():
    value = 357387
    if len('') > 0:
        497
    text = __import__('base64').b64decode('QzlRaDJiT0FsMXkxMEpFZUxHd1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΧСфναъυзФ():
    value = 871426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxD1S24NrvggPQiv/XKIOhIO4Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛξΠкΡсАфμлΠшЛ():
    if len('') > 0:
        978
        655
        246
    value = 246469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzvTZXMOzatQPi2r+0WaLXcj53k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΦКΙΒФСЪΛ():
    if 2 * 54 < 0:
        47
        pass
        _dead_8791 = 48
    value = 783062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnroPQgW2qQLMTqt0EOmDRwhtj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        794
    total = value + len(text)
    return total

def _ΛДъΗЕЬОЦΑвс():
    value = 696693
    if len('') > 0:
        46
    text = __import__('base64').b64decode('WU1EMW90WEhWa1FnSzVPRk03VnY=').decode('utf-8')
    total = value + len(text)
    return total

def _εуαцΩбрМз():
    if 44 * 72 < 0:
        76
    value = 276272
    if 59 * 66 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAbzSn8s3I4BKVaS3weAEAcVvDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 44 * 92 < 0:
        pass
        341
    total = value + len(text)
    return total

def _οςΖΥщНμδ():
    value = 972703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTfAV0k0wfwpACL64VKoDDN46Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чζνТπιЭρеЙчСтΘн():
    value = 720067
    text = __import__('base64').b64decode('VTB5ZVEwc3I2NmFEZmcyY3NpSmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣХУυюлДοМ():
    value = 842420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBfAawVhyZgaKAeu5U6lPCII1Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕοйЕсχшйЬж():
    value = 325100
    text = __import__('base64').b64decode('VndSeEpCVk5vUU82b1kzaU5uWTE=').decode('utf-8')
    if 50 * 53 < 0:
        _dead_9010 = 135
        pass
        974
    total = value + len(text)
    return total

def _тχлηηиΚΙιЮза():
    if 87 * 61 < 0:
        _dead_4147 = 336
        _dead_1950 = 527
    value = 206648
    if False and True:
        782
        _dead_4317 = 52
        377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXm3Q2gN6Ik2Yjern1eAHTIj6EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РиаЛΦΟКμνγφмΡ():
    value = 443621
    if False and True:
        207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRrURVAwqoAEESylxHy8GAIdwU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭВςДΩιαРЮцуς():
    value = 461569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx7sb3IJ0ZgCOTby+HHAMDIn918='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3284 = 407
        pass
        _dead_4089 = 451
    total = value + len(text)
    if len('') > 0:
        701
    return total

def _τзΒЧфЙρДρΘΘОФΔяЭ():
    value = 612130
    text = __import__('base64').b64decode('b1A0UE1XYWdaV2s0b1dnX0dXR1c=').decode('utf-8')
    total = value + len(text)
    if 99 * 31 < 0:
        431
        908
        _dead_3151 = 232
    return total

def _оκΗοΚВκЛгИΒ():
    if 22 * 15 < 0:
        396
        344
        338
    value = 105224
    text = __import__('base64').b64decode('cERpa3dGWFc5eUVVVTBCb1dUOWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓεСπΕиЖΦхΒγкΦ():
    value = 889886
    text = __import__('base64').b64decode('YnpWOUsxN3JQbnVMbkdMelhEM3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩλмАΩГμмμВΟН():
    value = 115916
    text = __import__('base64').b64decode('cE5aMXM5Tllid19aMUFSeVJvSGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΙηκΒχλмОΕ():
    value = 601358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXzHQQcT0vEkHhyU0gHCMS8h80E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        112
        368
    return total

def _нлъοэбСЩнвНζщωΨС():
    value = 682042
    text = __import__('base64').b64decode('a251YTJwNGt6T09QY05PWGU0SjA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        308
    return total

def _лщиШьψσйιй():
    value = 688867
    if 70 * 94 < 0:
        _dead_1723 = 426
        _dead_8344 = 920
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxvxagUV0qMpbVuA2nSpIAZ3vW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥιψЪтαμФΑ():
    value = 19237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH32bGk/5r0kYz+L71CcEAcK9TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩАЦχΠχкΘНΓюΒЫРРρ():
    value = 705512
    text = __import__('base64').b64decode('cTk3MkhyUHdReEExamFlVHIxZ3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΘДβαΜЯДяжИЪвБиΘ():
    value = 681084
    if len('') > 0:
        _dead_9880 = 305
        _dead_6377 = 513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj/Hagks16xTOzip/lK/Fz1/7mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НйΞуяδωΗввЗκ():
    value = 558072
    text = __import__('base64').b64decode('S0VVU0NSaVZZSWdoUmlNMnhwVnU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8539 = 571
        658
        pass
    return total

def _ΨΔΟιИιЖДВэЩγ():
    value = 369279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAi0eXww5o8AA1aTwFLAPDUF6Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 80 * 58 < 0:
        pass
        _dead_7949 = 311
        pass
    return total

def _ΝЛбκЦпйГη():
    if len('') > 0:
        313
    value = 164818
    text = __import__('base64').b64decode('ZG5zNTVkbzJxQllHUlhZakw4Vlo=').decode('utf-8')
    if 20 * 80 < 0:
        _dead_4636 = 77
        pass
    total = value + len(text)
    return total

def _ΔмΚЬняиΠАнКрЮвщ():
    value = 400625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pzf9QAgV7osPFAj2+0WkHQI36Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_5969 = 876
        pass
    return total

def _κΗТρζЛΔуЯΖийЯь():
    value = 43123
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED/baVgh55E8Ljrxx3SDFy8e1n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 40 * 30 < 0:
        194
        261
    return total

def _μЩЧюнбпыдЭПφ():
    value = 877374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESLJPQEN/JkXFDCC8QKUFncH83Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝчκСΣпбψ():
    value = 250882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwnzWGQ956MJAFfzmWmkBHEg008='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖПщηΓЦοЕд():
    value = 150732
    if 74 * 41 < 0:
        529
    text = __import__('base64').b64decode('bVBSZ2s2UVJhU1NyRGY3WXMyYkw=').decode('utf-8')
    total = value + len(text)
    return total

def _вνъΥоЪΗЗκЩΛУКδΩψ():
    if False and True:
        819
    value = 416947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHmyaAU91LwsPl6TkQ6bOS8N6lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 37 < 0:
        557
        750
        _dead_2743 = 580
    total = value + len(text)
    return total

def _ρθΗЩρцαΦΓ():
    if len('') > 0:
        701
    value = 939644
    text = __import__('base64').b64decode('TmpWT1cxakJ1ZmsyRUI0OWNvOUQ=').decode('utf-8')
    total = value + len(text)
    if 33 * 85 < 0:
        pass
        _dead_3038 = 684
    return total

def _пЮδщИАкΨλΟаβем():
    value = 136351
    if 99 * 32 < 0:
        683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cwf9YHYJ6KILDSeqzQ+gNXwB3Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        942
        _dead_3149 = 359
        751
    return total

def _вкЗΔΕКΑчв():
    value = 492849
    if False and True:
        947
        pass
        _dead_4137 = 334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mhf8V0Vr7JoIbgPx3g+1JwEs1Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        228
    return total

def _υΧщυнЭКΨΘнщυΗ():
    value = 61006
    text = __import__('base64').b64decode('dEtHSlBRc2VfZ3gyRmZ6MjVrcVg=').decode('utf-8')
    total = value + len(text)
    return total

def _σΑПЦйВзσвΦΑ():
    value = 33829
    text = __import__('base64').b64decode('TjJ0cWswTmdMQkRGSUxCb1FSQk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΙГКПЮУШОЗχйшΑЫΖ():
    value = 347072
    text = __import__('base64').b64decode('VzhFUVFFaTdMY1U0VTlkVkp3Z0g=').decode('utf-8')
    total = value + len(text)
    return total

def _τНФιΥΤΘσωψγοпαΗ():
    value = 21884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ey3rWkc09PgVGzym3G6TNScd81Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИхяИωΟиΣΧчΞсЫаЮ():
    value = 356525
    text = __import__('base64').b64decode('d1pCTzUzVlJDcGFzZmtBRzgwU28=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙчщяОщΩΞНλ():
    value = 293706
    text = __import__('base64').b64decode('T084OHJxcWx5MGx6dnZqN0xHMW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЧТЧФииοΠдЛГщнЯδ():
    value = 982814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjzlbGgexv0hIjaUmHW0Fyl69Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜОαΡΘЫλОдГпηе():
    value = 567727
    text = __import__('base64').b64decode('Y2RzMlllYzcxX294andaNzhWQU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞτюЮΔπζоΙтэИζ():
    value = 199561
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHnLXHoqpv4HYwT3xWK+LiYO3UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΥФхπпΝΠβ():
    value = 308071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTzJXnM/ppcCIx7z0QCqPTY98Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σЖцИακЩЦαЫ():
    value = 782569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTbCWXg+x58OaAeM4FGoZDV2zU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АфСοмэлΔдэμ():
    value = 349395
    text = __import__('base64').b64decode('dUFGc3NSSF9mTE94T084MVQ5Y3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΓηСДΡЩаΚбоЩЫЖ():
    value = 879029
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRrdYF4P/I8LEhu5xnObMAcF40c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зЬйОяεуЖЛΒηψιΤгл():
    value = 598494
    text = __import__('base64').b64decode('blI4dmlDR1VaMHRmNFh0aWlhSzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔзγσХθяМъΝ():
    value = 767918
    text = __import__('base64').b64decode('U2xoWVd2QTkwY2kzREJqQmY2cFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ηМαФςκьШЪщτΓЫΚзΜ():
    value = 390689
    text = __import__('base64').b64decode('UEVlaVliM2hzWEhqMl9DTndkc0s=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_3923 = 370
    return total

def _ΜΙτλΚχЮРщАхЭεщЬб():
    value = 978952
    text = __import__('base64').b64decode('U3JpdjJMNkFqQUJhb1ZpbXBTbTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()