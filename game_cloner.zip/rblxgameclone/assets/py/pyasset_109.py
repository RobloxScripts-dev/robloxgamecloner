#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _щρξЬъμΜбХ():
    if len('') > 0:
        583
        125
    value = 813359
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXuyWHIW8qEmEDuk0HmgAT0t4m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БβσЬДкдАΙθΜиΔДР():
    value = 404606
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXfzQUQa0ZBUOQih2FezGSIuvV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тьОβΞλУСБθ():
    value = 43407
    if False and True:
        847
        _dead_3411 = 393
    text = __import__('base64').b64decode('aG53YUZXUWdrUWdRMkp0MFd5NkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ρЙТгΩκтмНвиδ():
    if len('') > 0:
        _dead_2721 = 685
    value = 875345
    text = __import__('base64').b64decode('RVhseEVuTzNjZmZHTDY3dUZaSVg=').decode('utf-8')
    total = value + len(text)
    return total

def _СΤαΒΒγΠББπъντΛ():
    value = 762954
    text = __import__('base64').b64decode('b25RUVhsMllldHBjTnhsNEtFVlM=').decode('utf-8')
    total = value + len(text)
    return total

def _πΕкЙюΘΙр():
    if False and True:
        pass
        pass
        _dead_9691 = 510
    value = 771426
    text = __import__('base64').b64decode('SmVxdzVmMW5MbVpjcDZTd2xPbFc=').decode('utf-8')
    total = value + len(text)
    return total

def _лМмαγчКεεγаГΓБ():
    if len('') > 0:
        702
        _dead_7167 = 545
    value = 997990
    if len('') > 0:
        pass
        _dead_6344 = 357
    text = __import__('base64').b64decode('QThYQjA3dWoyWEljZ25sTEJ6ME4=').decode('utf-8')
    total = value + len(text)
    return total

def _сΚэяуСХΩуПжλ():
    value = 873745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXzjWEsB6PAKYwmrylOTOgoH8Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 78 < 0:
        _dead_2843 = 77
    total = value + len(text)
    if 34 * 39 < 0:
        386
        171
        363
    return total

def _ВοΜγЯρηПРΞМщμςΤ():
    value = 270293
    text = __import__('base64').b64decode('QWpFNUR0X2IzX1Y1dUM2b29VZm0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _λΚбΜΩйεвШΝωЧαψ():
    value = 845579
    text = __import__('base64').b64decode('RWxweWptSEZ3Ujg2TEhROHJ4MmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _εхοВδΛΞΘйЮ():
    value = 465686
    if len('') > 0:
        pass
        _dead_2094 = 442
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn3ASnodxPA2PCSr8GGjNn0Yxzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 17 * 31 < 0:
        _dead_9446 = 938
        pass
    return total

def _гЙРыЫΘЪгЮТΗИШ():
    value = 711439
    text = __import__('base64').b64decode('RFk3MkoyT01KOFJjNnhHaFZUeFM=').decode('utf-8')
    total = value + len(text)
    return total

def _γωЫтδοгΑуЯй():
    value = 107258
    if len('') > 0:
        _dead_1609 = 21
        _dead_9978 = 370
    text = __import__('base64').b64decode('bzJGdTZ2ZzhOVXBJNm4yOFZJYWw=').decode('utf-8')
    if False and True:
        237
        _dead_7379 = 702
    total = value + len(text)
    return total

def _УхчБтйСΜΟрβνσМ():
    if 92 * 50 < 0:
        pass
        _dead_7944 = 161
        pass
    value = 228290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz7vSWgOqpsXLCKT0VWxHBUK0mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гжУιсρУЩΓΞω():
    value = 147976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHvSS0cf+qAvKzD7mmmGJXY69m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΨωМмΔβμй():
    if len('') > 0:
        _dead_3181 = 772
        _dead_8692 = 80
    value = 11124
    if len('') > 0:
        pass
        _dead_2847 = 772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjrOOFIT6JgUbVia3AOqGwghzEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7396 = 145
        pass
    total = value + len(text)
    if False and True:
        846
        pass
    return total

def _υΛТΟюυРнσРГΩ():
    value = 454041
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXreSUAQ1vATIhiw7H7DOCA9wkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 60 < 0:
        pass
        _dead_8366 = 120
        pass
    total = value + len(text)
    return total

def _ЬζκΘФюЪζвФ():
    value = 144645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjzJeGYr078RCCON8H6JZnF7/H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 9 * 84 < 0:
        714
    total = value + len(text)
    if len('') > 0:
        762
        _dead_7397 = 851
    return total

def _σцЦчΝΕΡсρЛЭГ():
    value = 442493
    text = __import__('base64').b64decode('Ynp3QTFxekJlc2lkajNHNWRCVng=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣЮрΦΨДЬЖЧЪ():
    value = 301131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB6xZQch85hQABuT7WakMnQo5mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дзВхΒояч():
    value = 410833
    text = __import__('base64').b64decode('Rm1PcjNQQlFKM3hpNGZBZ0ZMRGo=').decode('utf-8')
    total = value + len(text)
    return total

def _РмοΗдИжфΞЯΡФ():
    value = 463534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjvMf0IV8JcECRqB3FS7ASt5wzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔδъпзπσωδьΔяЛω():
    value = 411058
    text = __import__('base64').b64decode('clNWUUlsUGtYRVNtd2NZbl8zems=').decode('utf-8')
    total = value + len(text)
    return total

def _ПηАйςЦЭΤβστφ():
    value = 698884
    if len('') > 0:
        485
        605
    text = __import__('base64').b64decode('eUVzc0QyU2F5UjB5WkxXTUVIcmI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝрΑμξрхΗΓДа():
    value = 837753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQv0N2E27fEMGSmrylO0bTAYvTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 14 * 73 < 0:
        pass
        _dead_7558 = 564
        pass
    return total

def _χссфΘГПЧ():
    value = 589927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kg20QHJpy/4aNyew2EKHDC967Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аувςωΓΒτосЕБЦΚШη():
    value = 459283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBqwSggD0KYQPDyb8AagMTwl9Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑψцЮΥфΜюыλ():
    value = 896164
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRjgZ2k085spBQ2C92ClHTIqzVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НγБμдΡрРΚσΔη():
    value = 709202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj7Vd1Ub6awPHCe3wVe0J3QNykE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СуΘχλХНТГ():
    if False and True:
        _dead_4519 = 469
        pass
    value = 156710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRf+aHQL+f87BQK20UK8Mx0+618='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _иЖпΔСфτЪШЦзФΘηΝτ():
    value = 142957
    text = __import__('base64').b64decode('eWRPMWhZQTVha2g2Y281M0p1UUY=').decode('utf-8')
    total = value + len(text)
    return total

def _λщΜхΛΒΡхФΔжΥΜ():
    value = 624757
    if False and True:
        660
    text = __import__('base64').b64decode('S1pxc1VFRWRzbEs4X3hSOFRxQnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΔьЦСнωэφν():
    value = 447328
    if len('') > 0:
        _dead_7921 = 285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSXsOWsP2r4gIh2U5VSjPwwYw0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФβΨНΧΟмφТξЮΚВφλ():
    value = 785858
    text = __import__('base64').b64decode('elhZRmVzTXROZ1ZlaE0xT0xRR2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΜΩИеъσΝЧΒМйαμ():
    value = 318992
    text = __import__('base64').b64decode('VU1PTGZwQTJfZXYzTENZamxCQkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ОпяνфзъМΡςΑОцАΥ():
    value = 622050
    if 90 * 67 < 0:
        pass
        _dead_5247 = 134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxvKe1U+p6MnMACZm1CaBwIr3EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤРβΠлΓйщсгИцВιΕ():
    if 94 * 67 < 0:
        pass
        569
        pass
    value = 868049
    if False and True:
        _dead_8604 = 194
        198
        pass
    text = __import__('base64').b64decode('QWNuTml5UURoYkJuMThhcE1qYmM=').decode('utf-8')
    total = value + len(text)
    return total

def _χЧЭыкΜпΧнΗКΒСС():
    value = 696721
    text = __import__('base64').b64decode('TVhVUVFYWjZUamRKY0c4TnVWTnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ТЫΧЛΛЭΦЪΡэаψМ():
    value = 665749
    text = __import__('base64').b64decode('bXNWVEdDNzlxcDZsY3loRVczbEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЮглЬΣФРερфβкю():
    value = 252630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyrTeXIf/ZkCFQOUkXipNnwH6D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        508
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_2157 = 966
        pass
    return total

def _ΙФЖЫНхФγЩξΣΣЮτ():
    value = 636496
    if 78 * 90 < 0:
        pass
        pass
        _dead_5269 = 338
    text = __import__('base64').b64decode('emJGTTZSNnNQYXJOdWV5WTdGNjA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2396 = 251
        _dead_3847 = 58
    return total

def _еωκГпζЪΡэβα():
    value = 95859
    text = __import__('base64').b64decode('dExDRDY0ZXVIZk0yVG83VTRHOVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ГжВψЯЦΤЦЯΒЖχεъоБ():
    value = 886280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ixi9WWIPqoFRKxnz8AOGFSwC1V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞвГΜСΣφАТΝΧЗκи():
    value = 981009
    text = __import__('base64').b64decode('Qmg5ZFV1dTVXNEdxRXc2em0yRkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ыσЗЖГμмРρμΠΧΨДй():
    value = 562214
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH3sVAkax4MvER6t/HyVYiolt20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μлΗиэΜΝξЙДμ():
    value = 547139
    if 51 * 72 < 0:
        _dead_9312 = 256
        155
    text = __import__('base64').b64decode('RDBoN1doUzk5NnU4aWVNUTlmN3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΨШцРщуу():
    if 66 * 63 < 0:
        pass
        _dead_5516 = 976
    value = 106056
    if len('') > 0:
        _dead_3466 = 942
        14
    text = __import__('base64').b64decode('dDhWazJhUk1ITGJsYk0yQk9ZR1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖъСΘДςΥΥ():
    value = 42490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej7bWEgY3Lk2EVaE90XDJnMQ0k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζζηюгεПрΗрΛ():
    value = 905428
    if 95 * 69 < 0:
        _dead_7183 = 103
        658
        650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnzGQGUd05EIKQGq6Vu0BgE36nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 4 < 0:
        _dead_9974 = 611
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3348 = 912
    return total

def _иОΙэШαΨζшΩБ():
    value = 12293
    if False and True:
        _dead_8902 = 341
        _dead_7477 = 154
    text = __import__('base64').b64decode('Qk96R3dFdm01dU9YYjZDaU5UbVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΑξкКαΦЩщПьэεξ():
    if 55 * 30 < 0:
        478
        pass
    value = 53165
    if 81 * 61 < 0:
        176
        _dead_8665 = 589
        409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH3cS2QgzJkSLDqP4m6cIB94sWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        662
        _dead_2299 = 544
    total = value + len(text)
    return total

def _ГκРЬΣψОψнмаНчоοх():
    value = 179034
    if False and True:
        107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDvUagUr764Ob1ywxX3CNi4a908='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        744
        pass
    total = value + len(text)
    return total

def _ΗσθνΜςΠПε():
    value = 745116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRyzdEYO5r8vHRutwnvJMxEc5UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΒВАРςЦΣяеλФΗ():
    value = 985086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCnCQgQw6fosbSzy+1fGbCEf6zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηрΧпνΔХξд():
    if 29 * 9 < 0:
        4
        _dead_9175 = 423
        339
    value = 429059
    if 79 * 77 < 0:
        _dead_8235 = 352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRn1RH4a/4MsDSyFyVyyNxQA50I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        248
        _dead_2000 = 22
    total = value + len(text)
    return total

def _ιСЛркмιΞЭ():
    value = 115294
    text = __import__('base64').b64decode('WDBheXpya2JBVmFQR1RZaGZWMzg=').decode('utf-8')
    total = value + len(text)
    return total

def _схюирьУλоκЬΜНГЮ():
    value = 986637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzjGQngX8I4Bbhen5UHDEHQb0nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βтνωΑМЕΚΤУ():
    value = 721390
    text = __import__('base64').b64decode('Z3ZRUzdkdVpmbG9OaGFHTERiMFY=').decode('utf-8')
    total = value + len(text)
    return total

def _щЫЗЛЙЬдЩвьφ():
    if False and True:
        _dead_2336 = 477
    value = 451923
    if 63 * 41 < 0:
        pass
    text = __import__('base64').b64decode('bDJ6MW9HalNINWppMW1OS0FxOUI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        832
    return total

def _ΥΣΕяхжΗеТ():
    if len('') > 0:
        pass
        pass
        _dead_7886 = 363
    value = 598360
    text = __import__('base64').b64decode('VGhfYWtRdmxaY19iZE92MzcyaVA=').decode('utf-8')
    if False and True:
        316
        pass
        _dead_2771 = 579
    total = value + len(text)
    return total

def _ΥΔΡцΦфэυφД():
    value = 146678
    if 89 * 95 < 0:
        437
        pass
    text = __import__('base64').b64decode('SHhINW1LbzhZQlRhZld6NlZCelM=').decode('utf-8')
    total = value + len(text)
    return total

def _жМймδюПμψΤвОЯΞ():
    value = 636460
    if 12 * 3 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An32b2QqqaY3OFaLyg+VLDwe9kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΚΧоЖАНбдΕяМДаδ():
    if 74 * 10 < 0:
        pass
        647
        pass
    value = 292305
    if len('') > 0:
        _dead_9673 = 718
        _dead_3254 = 578
        281
    text = __import__('base64').b64decode('b2FMaldZUTVTcHEwblQ2UG5xaVo=').decode('utf-8')
    total = value + len(text)
    if 11 * 70 < 0:
        pass
        _dead_9479 = 733
    return total

def _ηАΧοτсΥгцНΑЦзοЫκ():
    value = 51660
    text = __import__('base64').b64decode('SjNkVnlJM1JmZDBfV1g4Q2szRjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _пΗыΣИΞτеοШчЭ():
    value = 124864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjjlfAhvyaoqKAKz7H6cJXR2zzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уγявννфεΒвБ():
    value = 45348
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('bkJTTEdtWHZhNl9WNUhISVNfWjk=').decode('utf-8')
    if False and True:
        825
        659
        _dead_1507 = 930
    total = value + len(text)
    return total

def _УДТЩчхΔдαыΤ():
    value = 507796
    text = __import__('base64').b64decode('bGVMWUJIMXFzbW9namJiczNZYnM=').decode('utf-8')
    total = value + len(text)
    return total

def _РθΑНυБЬε():
    value = 904077
    if False and True:
        531
        984
    text = __import__('base64').b64decode('WW9LMFpSeWo1djFFYUVsbGpTUG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ηфοЛрιρДЮЧ():
    value = 649058
    text = __import__('base64').b64decode('c1VaVTVTaEFtWWVYaUE4dHkxRFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ηщЯСΑжХτЧΑΥг():
    value = 268197
    text = __import__('base64').b64decode('eHdYYzJDWThJU2Jkazd0cVJKb0k=').decode('utf-8')
    total = value + len(text)
    if 79 * 94 < 0:
        pass
        pass
        43
    return total

def _ШсдюрαΙχτъνΩД():
    value = 34033
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRfXTGAqqI9SGQWgxAa4OAYCwGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЙтεΣУΠςΩΚЗΡ():
    value = 501139
    text = __import__('base64').b64decode('Y0V6YW5OeGthUEx0R0tMYjdWSnc=').decode('utf-8')
    if 25 * 31 < 0:
        _dead_4582 = 149
        pass
    total = value + len(text)
    return total

def _ηЩΩжеΚГρЦγ():
    value = 844260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nhrqd3Bq1ZcWD1as/3uFOAEe218='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нχκγдеΓνιюИ():
    value = 827271
    if False and True:
        pass
        _dead_7780 = 468
        pass
    text = __import__('base64').b64decode('TmxPOWJ1VTZhazNicDNwcWtMZ2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨйΓЪЗΔνЛΤΟсоФт():
    if len('') > 0:
        _dead_1503 = 186
        pass
        523
    value = 982254
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3rtN0Ya5psLHxaV3Q+kbAIm4Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        545
    return total

def _χκвκΒωτЭЭδχθ():
    value = 925398
    text = __import__('base64').b64decode('RlJ3SGRadkdZSGhZWkdpODlCa04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔпчбИИΔβΡΦχαΖ():
    if False and True:
        952
        171
        767
    value = 686318
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCDqaXAy66ESNlai/AC+bS979T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛРЯЕζΟьχκсΝΜАεΤ():
    value = 781591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH7yOW4sxPoXNgKFwwCpBQ56wEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 31 < 0:
        450
    total = value + len(text)
    if len('') > 0:
        771
    return total

def _ΝШζγНΕДссθюьЬтΒλ():
    value = 174687
    if 65 * 51 < 0:
        _dead_2460 = 804
        _dead_4614 = 238
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwTMQEdv1YE2IAuQ/ViFJXI8tWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΥАМбсЙιЛОлЪУΞβπ():
    value = 566587
    if len('') > 0:
        _dead_4809 = 424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ES7cWVshz78zAiORzESVMBYisFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВψοЬЫьЯΦζΣпΞЮЪДЙ():
    value = 5919
    text = __import__('base64').b64decode('R0ZfZ2p0ejVUWjloVmNPSzk0aTc=').decode('utf-8')
    total = value + len(text)
    return total

def _жΓιЪиыΔοзЙВ():
    value = 412956
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhftdFAtyaYzEjmRnQCKDnYCzWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6451 = 114
        _dead_6789 = 114
        _dead_1455 = 990
    total = value + len(text)
    if len('') > 0:
        747
        376
    return total

def _ςΤкΓиΣзЛлξЖβфπОχ():
    value = 118812
    text = __import__('base64').b64decode('cFkxVExGYWkySnV4c3p0cG4wTlo=').decode('utf-8')
    total = value + len(text)
    return total

def _НΘЬσζХυИщфΚ():
    value = 670113
    text = __import__('base64').b64decode('UUVZM2hYejcwZzZTc0RHTEEwV2o=').decode('utf-8')
    total = value + len(text)
    return total

def _хΔсьρδюсγчΨςκΚ():
    value = 143778
    if len('') > 0:
        _dead_2480 = 745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HS3AZQksx68mPgT0zQ+1HQQr6FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_6247 = 275
        pass
    return total

def _ЛΜМФΦЫкУ():
    value = 885383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz32OlQ624xSHi6BmGefbAN7tHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ινОЛаυψΤВЮъпДхб():
    value = 684050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lxj3PmMW/LEONQmGnnCkNSYQyn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨаωюεрФДυъШмΤб():
    value = 250779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3bcYQQW0rwMLTyOxVuJEw83sXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬБοκζЮθжμθ():
    if False and True:
        397
        489
    value = 858493
    text = __import__('base64').b64decode('bDdYSEJoQU9JNno5QkY2cmRzZkI=').decode('utf-8')
    total = value + len(text)
    if 16 * 50 < 0:
        _dead_6042 = 682
    return total

def _СΡζειяΝОΝ():
    value = 599420
    text = __import__('base64').b64decode('UF9EV0FsSkptOHpnUURVR2d1RG4=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΝΔаΧλΙГтωДЬΒЭ():
    value = 388629
    text = __import__('base64').b64decode('dGJFRkZFWmk1UTVCQkwxSmdlc0Y=').decode('utf-8')
    if 51 * 85 < 0:
        pass
        pass
    total = value + len(text)
    if 35 * 36 < 0:
        381
        pass
    return total

def _νШΞЮУзωΤΕдс():
    value = 225933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDvzOVVs8oYHNCWy0UK7ATV59FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΙРЦΨъйюсσЭσφΛξΣд():
    value = 189334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCrLT38a9JkQGz+AxFC0DhN76Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шЛμШяшδΒΜс():
    if 67 * 86 < 0:
        _dead_8309 = 462
        778
        pass
    value = 45287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LinyN0Mb+oAHOVyLnEzCOgMNykQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΘУΓиΩиΒ():
    value = 578104
    text = __import__('base64').b64decode('SWRORk1SdWh1YlBBY3ZDVEg3QWw=').decode('utf-8')
    total = value + len(text)
    return total

def _дфЧψΠхστПЭηОο():
    if 33 * 81 < 0:
        _dead_9371 = 583
        _dead_7551 = 977
    value = 716068
    if len('') > 0:
        _dead_9328 = 848
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwTveFkT0bIaEQ2R3UPGbS8ksGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2195 = 688
    total = value + len(text)
    return total

def _мПвпдκпΛ():
    value = 758869
    text = __import__('base64').b64decode('Vjl0SjhTNnZwQ1RTNnFIVjFDYWs=').decode('utf-8')
    if 29 * 36 < 0:
        944
        _dead_3467 = 424
        pass
    total = value + len(text)
    return total

def _фΥπΟКЩэΡФξЬЕ():
    if False and True:
        pass
    value = 234980
    text = __import__('base64').b64decode('aXlCWTAwX2JwNHVVclo1alpKU24=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        121
        796
    return total

def _уγΘθИоЖеХε():
    if len('') > 0:
        393
    value = 922181
    if len('') > 0:
        158
    text = __import__('base64').b64decode('amR1REtTVlNlVGxMREVfbEllT2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ζрБμЮЙРχчШΗνοкхσ():
    value = 689159
    text = __import__('base64').b64decode('eHFCT1NEQ2dPXzI0YVRROVZDd2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _РΤтΟЩШΓΦЖΩЮаθ():
    value = 28444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCDJQmIYq60hNQa0kHiDGCAhzzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9881 = 18
        _dead_4397 = 581
        593
    total = value + len(text)
    return total

def _ΖцхЖмςДπΖфвΓеΤ():
    value = 351988
    text = __import__('base64').b64decode('QzFQd1M1SFZzTG84Y3FrcG1HZjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ρИρΤЦεΓεθΒφ():
    value = 423650
    if False and True:
        pass
        _dead_7148 = 539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fn/COWEe75FaOx+6/nmKGTAh1Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧЧЕДХззш():
    value = 389654
    if False and True:
        888
        pass
    text = __import__('base64').b64decode('WU5nb2o2WV9XUmlLc3NyOVhlTlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _гΞЗΒДкдКωЬμΩве():
    value = 641791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSrNYn43pp1XDzep0F2HbDUd4HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βНΖЕφιпЕйΔЖ():
    value = 480836
    text = __import__('base64').b64decode('TTh3Nk5icDhvSDBKVFBxTFZZcHQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9653 = 670
        948
    return total

def _ρаэГбτΖЗαΙХ():
    value = 918134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwbIWUsQxL4gDRaO5wGWIR8gzmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХвеΑΥοюΑςΖΕκ():
    value = 691298
    if False and True:
        pass
    text = __import__('base64').b64decode('bW9WUnh4VlNReTg1eWZVak05VTM=').decode('utf-8')
    total = value + len(text)
    return total

def _юΦкλΞΣЖφЙψτэς():
    value = 20742
    if len('') > 0:
        _dead_5720 = 178
        _dead_8406 = 791
    text = __import__('base64').b64decode('SWNIYnRlelRmdEZrYm9OdGdVZmY=').decode('utf-8')
    if len('') > 0:
        627
        867
        pass
    total = value + len(text)
    return total

def _чуΘЬЭЮщςνθιΔ():
    value = 194319
    text = __import__('base64').b64decode('TFh2ajF3aUtsM0ZvUkw2VGNrb1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΓячГΧυщΙκπ():
    value = 93660
    if 73 * 91 < 0:
        841
        pass
    text = __import__('base64').b64decode('Y2dHMW1saVBHdVJ5ZWNMVTBFSzk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        931
        9
        pass
    return total

def _РКАΔЬЭωЫмгфуыщгΥ():
    value = 221372
    text = __import__('base64').b64decode('WlJtajZLUWtrTG0yekJEbUVoSWw=').decode('utf-8')
    total = value + len(text)
    return total

def _мОΦΖΔзΦоΙοΚзραΜж():
    value = 332871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX7de3IRxrIMMVyoxmnCHC4C0VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЛМΨЖςωιЮтфΕнθΗЦ():
    value = 75476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njztflw+3KkgEACo8U+jIi4Yszo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΜаΝΛЪЙьн():
    value = 893477
    if 29 * 92 < 0:
        159
        pass
    text = __import__('base64').b64decode('Y2JibEp5akQ3TWJnVlI5MmtGeTQ=').decode('utf-8')
    if len('') > 0:
        546
    total = value + len(text)
    if False and True:
        pass
        _dead_3932 = 365
    return total

def _сξΛΣεпМСσςзΝ():
    if False and True:
        pass
        44
    value = 218248
    if len('') > 0:
        _dead_5261 = 247
        244
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiXLSmc98oUzMiCw/XmyHyYa8k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8065 = 934
    total = value + len(text)
    if False and True:
        pass
    return total

def _оъЗаΘωΘКΔЦ():
    value = 728481
    text = __import__('base64').b64decode('R3NYSU5UZV9YSXk3Q1dRWmdiTkY=').decode('utf-8')
    total = value + len(text)
    return total

def _йΝΞъъΦΥЖфιЮ():
    value = 531311
    text = __import__('base64').b64decode('SDA1OU81aUpLNnRFTkhYQk9TZzc=').decode('utf-8')
    total = value + len(text)
    return total

def _σфнКъΘγΘЙВХΤшызΩ():
    value = 963812
    text = __import__('base64').b64decode('SHNaTUhJUGduMWw5QjFsejRuX00=').decode('utf-8')
    total = value + len(text)
    return total

def _εΠУΗΖЧλθΘд():
    if False and True:
        267
    value = 855415
    text = __import__('base64').b64decode('amYyNkFjWWVrUXpRaWxkVTZ1S1U=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        13
    return total

def _ИΟΞЫξψΕςΦМж():
    value = 314922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESLXVnwu0LBSCCKW332iBnE63mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        906
        pass
    total = value + len(text)
    return total

def _ΞΓТпΨΚЙΓ():
    value = 749694
    text = __import__('base64').b64decode('cWszUnYyY0hBUVFRRmRTeG1nMlk=').decode('utf-8')
    total = value + len(text)
    return total

def _хУιЮжфЯЩςГΣ():
    if 92 * 98 < 0:
        392
    value = 311339
    if 25 * 73 < 0:
        413
        784
        263
    text = __import__('base64').b64decode('WURaYjlTa3Q5RzlFOWNoWWJHX0I=').decode('utf-8')
    total = value + len(text)
    return total

def _κταξеЖейвΦΔ():
    value = 852087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyfpV1kf1Is6KVeh2UalZR8k1jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΦфнгАЛкжΙιоТУцΤ():
    value = 136474
    text = __import__('base64').b64decode('U0E2T0FyUUtmTUxNM2lzbXdhYmk=').decode('utf-8')
    if 49 * 88 < 0:
        _dead_9907 = 319
        868
        pass
    total = value + len(text)
    return total

def _ЧτΥυδФθυσΥШΟХΛн():
    value = 632582
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCvGRmg0zbskKSmvn2+4JSAX6Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡэйЧХΨйΣХШΗрф():
    value = 744179
    text = __import__('base64').b64decode('QjNhSDhMel96bHZKMHJwN0hwVzE=').decode('utf-8')
    if 25 * 3 < 0:
        _dead_6866 = 686
        _dead_5568 = 866
    total = value + len(text)
    return total

def _щЩπΑТΔРЪС():
    value = 161605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSTeSH8R34lVDTu02He0ZxQK4Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АрЩхΘоΙИΑΤоΧр():
    value = 18653
    text = __import__('base64').b64decode('ZUtzeEJ4M0FSczhwWXdGTWd5MUg=').decode('utf-8')
    if 40 * 55 < 0:
        955
    total = value + len(text)
    return total

def _νΕΕИξЗЯεΥГι():
    value = 280716
    text = __import__('base64').b64decode('U2VDMElEU2h6YXFRSjlucVRSVTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛςПβΒэВΙυщнкυ():
    value = 636183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjbgeWcP1f0waQmQ/0S1MT164kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛПЯбэХдсчΕУрФΧч():
    value = 440311
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ln6xSAkQ7IwHKBmo/G+BFigh4lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИАΣψОΣВЪтЦβρζз():
    if False and True:
        _dead_2621 = 147
        pass
    value = 74842
    if len('') > 0:
        _dead_5202 = 167
        958
        pass
    text = __import__('base64').b64decode('a1JrY3NlMllTZmdoMUFfVUYwalk=').decode('utf-8')
    total = value + len(text)
    return total

def _зЭΧжкйχΩφЩ():
    if False and True:
        pass
        _dead_2457 = 816
    value = 319757
    if len('') > 0:
        382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az7XOFhgzLgbLiKJ2US1B3Ul118='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8044 = 92
    total = value + len(text)
    return total

def _τΜιЩвЧКЬβνψ():
    if 73 * 72 < 0:
        _dead_2831 = 231
    value = 519456
    text = __import__('base64').b64decode('clRDNHZtb0NKZWh0TmpwbHI1d1E=').decode('utf-8')
    total = value + len(text)
    return total

def _пζЭдюцвΞвРΙΧγΚΖ():
    value = 387460
    if False and True:
        625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AATnW2YIqrIxHTywxFOiJywttEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 8 * 89 < 0:
        pass
        pass
        _dead_8748 = 750
    return total

def _цЧкΩскΔЭΙ():
    value = 111663
    if len('') > 0:
        pass
        _dead_6808 = 909
        933
    text = __import__('base64').b64decode('S2lybG96OGdqUnlRem5jWHA2OHo=').decode('utf-8')
    if 45 * 96 < 0:
        pass
        124
    total = value + len(text)
    return total

def _ОβΥзυЦйбΩΒΟ():
    value = 278707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRXSaloq1IwUHCCunk69YjU71kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖУφэГοΙαрβЗτ():
    value = 876967
    text = __import__('base64').b64decode('VlYyZ0h2aVFtaDhTUm42bHpZdGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ζЭвъΙзκя():
    value = 476057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxzoXFc3+phWEQaA0ga3OiYI6F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙЬοΔΒταЛвФΒ():
    value = 616208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQazUUsM+7hWbxyu6ma8P30742E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хНГδЫТчп():
    if len('') > 0:
        pass
        744
    value = 973661
    text = __import__('base64').b64decode('ZUFlT0JiN2lLWWVpeUZ2S2lQeFQ=').decode('utf-8')
    if 65 * 21 < 0:
        _dead_4833 = 702
    total = value + len(text)
    return total

def _еШηнХАШцмθм():
    value = 177374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHvxWkU79q02FiWr8QXIGgEq8W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΝιЮΝлзЧгβрζйКΟΠ():
    if False and True:
        764
        _dead_5755 = 308
        _dead_9211 = 219
    value = 301287
    if len('') > 0:
        pass
        286
    text = __import__('base64').b64decode('WG5oRnA4SXJ4aEZ4WExabngwSks=').decode('utf-8')
    if 69 * 97 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΛъοΥъλσТΔрЮиα():
    value = 958557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXzFPkVg6KAOHAqsmXChOTd361k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μВхΜцφΑΟζηςнц():
    value = 247783
    if False and True:
        _dead_9443 = 921
        880
        822
    text = __import__('base64').b64decode('bHBXUmUyaVNHb21BNlBuMHVZc0Q=').decode('utf-8')
    if 48 * 45 < 0:
        602
        pass
    total = value + len(text)
    return total

def _МΜςпИЯΟДъυΓν():
    value = 734289
    text = __import__('base64').b64decode('cGZkVVc5dmczMHh2YlBVcl9RTGY=').decode('utf-8')
    if 32 * 32 < 0:
        630
    total = value + len(text)
    return total

def _λХρΜЯЕΗЪ():
    value = 670807
    if False and True:
        pass
        _dead_8119 = 961
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh7ceHoMp5FRKDWx0HGybT0I0jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5985 = 180
    total = value + len(text)
    return total

def _ΣМКΕсηвνЩщА():
    value = 696887
    text = __import__('base64').b64decode('TGpQaEZuZDBBZlBUdWNKcU5rUUE=').decode('utf-8')
    total = value + len(text)
    return total

def _кЫΗμЙπδЪмШ():
    value = 50396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AS7nRWMszYxaMA6Z43KyJyEi6Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΦΡИтБЫь():
    value = 252171
    if 13 * 77 < 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('TkRIY0JZSlg3b3FYTF90bHZiUjE=').decode('utf-8')
    if len('') > 0:
        _dead_9792 = 707
        _dead_5469 = 159
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        940
        475
    return total

def _юΟъΦЦςЯКΠпчЕз():
    value = 408535
    if len('') > 0:
        419
        _dead_4628 = 291
    text = __import__('base64').b64decode('WUZwbktXUmQ2VWk0ZzVJU2F5Njg=').decode('utf-8')
    if 19 * 5 < 0:
        _dead_4490 = 520
        _dead_7148 = 106
        _dead_2669 = 208
    total = value + len(text)
    return total

def _ΥюЫиСΥфЦАЙуПуΖ():
    value = 409470
    if 42 * 67 < 0:
        40
        682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCznXH0B7I0HIxio5W+BNQgDyTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        528
    return total

def _уδУЖυТеανйьΣыΙΦй():
    if len('') > 0:
        _dead_8866 = 922
        415
    value = 192782
    if len('') > 0:
        pass
        _dead_7564 = 994
        _dead_9180 = 814
    text = __import__('base64').b64decode('Rm1OT3JLX1RFNjg0dklzeXZLUkM=').decode('utf-8')
    total = value + len(text)
    return total

def _аЙЗэШγдΞгυилβЬσ():
    value = 892889
    text = __import__('base64').b64decode('R21oa3FhVEl4U2hSUXF4R0lla3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯчвπоПΩрΜΓЮОφч():
    value = 113635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExXAeVk2xJwVORWVnAGnPQMk3lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΑяηрЖПЙΨΞτПΖъΚ():
    value = 92453
    if len('') > 0:
        678
    text = __import__('base64').b64decode('TUJTSlNpWGc1Nkxzc09vV1BQNlg=').decode('utf-8')
    if 74 * 6 < 0:
        366
        pass
        _dead_3402 = 463
    total = value + len(text)
    return total

def _ΑкФυιлвΕЭПωщпψΡ():
    if len('') > 0:
        _dead_5414 = 968
    value = 115421
    if 61 * 20 < 0:
        947
    text = __import__('base64').b64decode('R214aDlyN0xGMHpudHFxNFJFV0k=').decode('utf-8')
    total = value + len(text)
    return total

def _мвжвКгнРζοнвюΥЪΙ():
    if 21 * 1 < 0:
        _dead_1574 = 71
    value = 671319
    if False and True:
        _dead_8196 = 967
        _dead_2200 = 614
    text = __import__('base64').b64decode('dTRFVFdwckNkSnp1R2F2SWdiVnQ=').decode('utf-8')
    if False and True:
        pass
        430
        pass
    total = value + len(text)
    return total

def _ХоΧκцσЗΙ():
    value = 432467
    text = __import__('base64').b64decode('elBZcTB4OEp0S2VXREZZZ1lGeVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΛσςνψΥцЛζ():
    value = 694538
    text = __import__('base64').b64decode('V1dnX1ZtUDFwZ3VGUWFvdE9ndFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ηаΝъВаВЖлКβЕιΛУ():
    value = 767518
    text = __import__('base64').b64decode('ZTA3RENOQzRkY2V2bHp3VFgxdzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯбРшЭξΖΕчщοΩπР():
    value = 230090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCPxSAEw9qZUPx+PwkeyGTchsH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΥЩЗΥοχΑКΖ():
    value = 877779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAnASQMe158bMC2q8X2RNSl3/To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФρЫλзЦκΒ():
    value = 427011
    if len('') > 0:
        _dead_6534 = 164
        pass
        50
    text = __import__('base64').b64decode('eWZWamFkaFZGZXExdjJTZnh4dEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜγΤэЗКνя():
    value = 595039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESq3QnYN1YclKj2L+2aUEyE3/EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 77 * 93 < 0:
        pass
        137
    total = value + len(text)
    return total

def _ψХКΕхЭдю():
    if False and True:
        45
        pass
    value = 757958
    if False and True:
        pass
    text = __import__('base64').b64decode('d1V0V0hfVFRSQ1Nza2c0bVRJQ0c=').decode('utf-8')
    total = value + len(text)
    return total

def _оΒΡЗΔцчΛ():
    value = 640005
    text = __import__('base64').b64decode('Znp6ZjNhQ3BHWklRbVlHMEZiZ1k=').decode('utf-8')
    total = value + len(text)
    return total

def _αфΡλςУмφъИДДυς():
    value = 663539
    if 48 * 44 < 0:
        pass
        _dead_5984 = 964
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTqxP3cIp4U0KSip8HXEIgoqyls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _αАεЗюΔыЧСΖυТ():
    value = 423352
    text = __import__('base64').b64decode('RVpBN3g1NkZUdUNSZ09iUEpoREw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΗδΓΟШЙюцЫ():
    value = 729058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHa8eEUp/ZoPMxqw/F+3HjEY3GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _увТΚНΜωЙяψθΗ():
    value = 762201
    text = __import__('base64').b64decode('RlQ3Ql9vNDZNV19tZ3p1ZUxOdmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬσТлЗМъεΠΤ():
    value = 967169
    if len('') > 0:
        614
        _dead_1780 = 793
    text = __import__('base64').b64decode('RWxnUE11ek1SeEhoUThIclVVdFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ыкΗъΛЪаεΟЗ():
    value = 515442
    text = __import__('base64').b64decode('bU5maGoxUUNOOG04OGdzZDV6X3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛДνыкλΘГТИδωБΜ():
    value = 179523
    text = __import__('base64').b64decode('S3Nld2x2ZzUwaDJXUkhCZjhhQU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΓЮЫΣхΖΤЬх():
    value = 28251
    text = __import__('base64').b64decode('S1JNNVJGMWExUFJueTNNT2lxMGU=').decode('utf-8')
    total = value + len(text)
    return total

def _щΡτЩЯвдаΑΠьν():
    value = 451718
    text = __import__('base64').b64decode('eExUUDNGc1BWNmZpTXhKdjNvbnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮωΒТΤΑаПΣςΖ():
    value = 341738
    if False and True:
        169
        _dead_5794 = 61
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRz9e2QY1otaFzyVyUPAJ3MYyHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_9163 = 385
    total = value + len(text)
    if 83 * 94 < 0:
        590
    return total

def _ΕЭШфЮьΡηΛξπ():
    value = 486470
    text = __import__('base64').b64decode('b1pkekJOT1V0bzRwTVV1YWxES0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ыβВжΘоъядвζЕαгю():
    value = 667392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjvVTX461PgaMjD00QCFMTMr50o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 64 * 97 < 0:
        522
        _dead_8938 = 200
        pass
    return total

def _аςΟбаμЛΦΚеΨхΠс():
    value = 38700
    if False and True:
        _dead_8147 = 719
        355
    text = __import__('base64').b64decode('SFowWGJhVlM5MUpzYzF1U0dsWHU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _юΝвΨΟъвЪВ():
    value = 363055
    text = __import__('base64').b64decode('WmdLd01LbEwyck9teFFrcDNhYjE=').decode('utf-8')
    total = value + len(text)
    return total

def _йкКοРБζкθжηЪМΖ():
    value = 644880
    text = __import__('base64').b64decode('VnZGemVpMXVnc3k1a2xjaXJwemE=').decode('utf-8')
    total = value + len(text)
    return total

def _ИνвΠьПχΝшФох():
    if 54 * 7 < 0:
        _dead_6124 = 324
        _dead_6974 = 942
    value = 905936
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX/KPnts24Jbbx6A8FeDbTQGwWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞТЭачъХНЩλδΛЛπμΓ():
    value = 735566
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Che8RVYLyJkOPgWonX+2GRF6y0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6197 = 711
        _dead_1027 = 286
        pass
    total = value + len(text)
    if 34 * 15 < 0:
        309
    return total

def _ЬПДеЕаΜςΖ():
    if False and True:
        _dead_8539 = 621
    value = 546137
    text = __import__('base64').b64decode('VjlxbDdHbzhJMGthd1E3YmoyVjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()