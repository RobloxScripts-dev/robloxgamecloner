#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _υаηкΧΠΡриφηЧξΜА():
    value = 574682
    if len('') > 0:
        726
        391
        _dead_5972 = 628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCGwSgE36I8PDyanyXyDYSYrsTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РНЛτσшълο():
    value = 302907
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3nWR2Iw2LFROSGqkHGkDg81xTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        975
    total = value + len(text)
    return total

def _λрнιγνωУρλ():
    value = 172861
    text = __import__('base64').b64decode('d3hJOXZjWWM5SDVkczV2YkoxeTQ=').decode('utf-8')
    if 59 * 59 < 0:
        831
    total = value + len(text)
    return total

def _юШιУНРχζ():
    value = 745524
    if False and True:
        pass
        pass
        _dead_5101 = 460
    text = __import__('base64').b64decode('cklYWkN0SjVtVGhvZTFqNFFDbTE=').decode('utf-8')
    if 47 * 56 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЬжКгΚΣГιΧψЙкКΩ():
    value = 49163
    if len('') > 0:
        pass
        _dead_2844 = 526
        _dead_1453 = 163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz62dFIDxJ82Nwz271OKMzIoyTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 5 < 0:
        _dead_8813 = 778
        _dead_2206 = 148
    return total

def _ГτШΨЫΓУьψж():
    value = 121525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ayz1Pngp8v0WFRamw2mfYT0eyks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВиЛκμΠюнΜΡЕβμМ():
    value = 710800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwPvQGcD35g3AjaOzmCDbHwJyEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛЧφΧγЧБчΗсΙμуχΦ():
    value = 376059
    text = __import__('base64').b64decode('a3c2cjZXX08wZ3hqTGRzMGdBbTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΚбγРчИΝЪΘТуφШ():
    value = 591934
    if len('') > 0:
        702
        _dead_6528 = 278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bwv2XAMa3ZApOAGa+XKGETR/80g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1554 = 484
        _dead_6328 = 245
    return total

def _цΖρζрΗшυ():
    value = 307150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiK1PWgA64EMDhuKmHudZiYg4Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йеΞδщЪΚΒοюВОΙъА():
    value = 36959
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jg78bV0G164vCjyX+GW3GHYQ6z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φПΨжθΟΣΗЙСХΩЛш():
    value = 18974
    text = __import__('base64').b64decode('eGZEQ01XTW5VMTdkNjNMTDVxSVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ШροΗяцτЩБнрΤрЬΠ():
    value = 802199
    text = __import__('base64').b64decode('cUUwZU5Xb2ZvRGhlQ1ppNkFoejk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5568 = 260
        pass
        826
    return total

def _λХЭрРγЫхΥγ():
    value = 158415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXbWUWAAyosnLRaQ+XmRMyMp7E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        43
        pass
    return total

def _РфΤΡμГКκХζЪЛ():
    if 21 * 41 < 0:
        701
        _dead_8393 = 177
        pass
    value = 497542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxC2OVgYrYE0NRqF4UO0GX0atEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 95 < 0:
        _dead_5773 = 991
    total = value + len(text)
    return total

def _ΣιчЕлзСТдоΟ():
    value = 667102
    text = __import__('base64').b64decode('aGZVenZDN0JZc00wX2pJMHlzeXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΦсЯгληГλΞΡаΑΤωй():
    value = 939684
    text = __import__('base64').b64decode('YjhET1BTakI0RWdvUWFoZjFHc0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦπωлБМγΤЪΜБШΡΑ():
    value = 162685
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgfgXmIcyasGESuo7EynBj0l6kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 19 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_4635 = 614
        _dead_4134 = 936
    return total

def _ОяωЖъчОγянрмъΡΔς():
    if False and True:
        pass
        968
    value = 927325
    if False and True:
        _dead_9569 = 447
        _dead_9728 = 566
    text = __import__('base64').b64decode('dVJxQ3l2aGdBM1djTldWd2hSSmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫчχЖчрЪп():
    value = 547616
    text = __import__('base64').b64decode('TkE5MmFDdGNSMElmbGdCcjJ6b1g=').decode('utf-8')
    total = value + len(text)
    return total

def _СяМΚΠΨУйΝε():
    value = 149723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAjHSlk4zrJXLDCby0bHBzcK4Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦшοОМΜЪфшфχθЦМЙ():
    value = 394327
    text = __import__('base64').b64decode('Y3lpTEVjS25sejNESjJXekFPN0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒиΑШйэзФуДγягУ():
    value = 887954
    if 50 * 37 < 0:
        295
        _dead_7099 = 365
        pass
    text = __import__('base64').b64decode('aldkcnV5QzFfMGFORVJPVDRjek0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _εщЭτЬτьЦАΘтеЗ():
    value = 959009
    if len('') > 0:
        958
        645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxvtR1sT05kXKzv15mOqAgAb5W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮМЯφοрЫБИΔьΕΟщξβ():
    value = 947883
    if 5 * 5 < 0:
        pass
        _dead_9591 = 904
        _dead_1015 = 572
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ly3NdmMw9YsMFlbzmmCCDSEJ0kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8619 = 90
    total = value + len(text)
    return total

def _ХαΩЬΓщНШχь():
    value = 456126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD21aVYt0vkiMziI5gO7LTUF0Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮмДБЕΑΥΘΖЙΥγθλνН():
    if False and True:
        473
        pass
    value = 861609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSrHWHs3qf85Hj362wXCDgQc4EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шЧПΡеНтШψржτтХ():
    value = 480422
    text = __import__('base64').b64decode('Z0tCVHdlcVBoVnlwbVFSMnpPenk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _РαВζΘГЕσΒамΞЦиБ():
    if len('') > 0:
        353
    value = 708568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESPrNl847oUMLl7z23ClAnIo0ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 52 < 0:
        575
        pass
        pass
    total = value + len(text)
    return total

def _ΣυыγΖЯцЧφГ():
    value = 781180
    text = __import__('base64').b64decode('Y2lXWThaN05fTG02b3VhZlVJc3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЫΕЬυЯΡΖмдЦξЖν():
    value = 287669
    text = __import__('base64').b64decode('RE9RTWo0S3RUQmRCcW9Bc3ZlS0s=').decode('utf-8')
    if False and True:
        _dead_1212 = 973
        _dead_1522 = 40
    total = value + len(text)
    return total

def _δДвκψΕчЬм():
    value = 139715
    text = __import__('base64').b64decode('UEtDNDZ4dDgyU2d1SVRVM0tlTGI=').decode('utf-8')
    total = value + len(text)
    return total

def _τΡΑжаЫΩΛ():
    value = 468615
    text = __import__('base64').b64decode('Y0lnZVhXMEJBSndzMGE1TWRia04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΑЮΘпбэΖРΗΗο():
    value = 411427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT/8dG4x16BSGV2QmwOTAxV/tF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΒаωτΝЗэΝκιиρхΗ():
    value = 978285
    text = __import__('base64').b64decode('RHphX3N2dHBWMVFKOFpmUGY0OW4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        661
    return total

def _ΔЗЩыЗаШζВэъ():
    value = 854856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT60R2g79qQxCiT17w/FDnAb62c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2832 = 541
        202
        _dead_6149 = 66
    total = value + len(text)
    if 5 * 62 < 0:
        pass
        918
        _dead_4049 = 892
    return total

def _ψΑЦΕδЙюΦХΛббЦΔОΝ():
    value = 519904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyDdSn4W8LlbKC6s4HLJEiAN3lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пеΖиΤΝОЗмψκьоое():
    value = 54733
    text = __import__('base64').b64decode('SHRtVnA0RkZ5VjByX3NHdjhickg=').decode('utf-8')
    total = value + len(text)
    return total

def _ςгγяйцζΧΦанэ():
    value = 721819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnzLTG5g77s5FSKc93S6GXI+yVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΩМηρΘΣЮХитρ():
    if False and True:
        pass
    value = 976652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnjqekIV/bE0bh/63mSyOxcO22g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 47 * 54 < 0:
        pass
        648
        pass
    return total

def _ЩοКШмγγфАщ():
    value = 638881
    text = __import__('base64').b64decode('dk5GZnpvVmthWHNLYXdKTm5jWmY=').decode('utf-8')
    total = value + len(text)
    return total

def _τΦвΑΡССУκЫςΟШΞЖ():
    value = 415435
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDnDUUMz2qoqLBmA6memDRMNyH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙηфΣгυоиΣΒэΛΔ():
    value = 811848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHbjQ2EW9o8naACR0l+cHh8BsWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _илйЗσЬψфΕοСΣЗй():
    value = 526663
    if 77 * 10 < 0:
        477
        606
        _dead_2616 = 387
    text = __import__('base64').b64decode('RzJSZERIN3VMc2pKc2JKd0k0Z3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΦННβΦκΥΣШδΓтα():
    value = 632105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR7FN2UsxI4vM1v00Xi4IgkXzlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 9 * 62 < 0:
        _dead_1464 = 576
    total = value + len(text)
    return total

def _ζυнЪθΤτβД():
    value = 62888
    text = __import__('base64').b64decode('T1pyN0tMaDVRUlB3dlR2UjA1T0I=').decode('utf-8')
    total = value + len(text)
    return total

def _хΦФχчпцщβЫ():
    if False and True:
        728
    value = 92978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ln7WOUYvwZEHPyGrz0+ZPHA96UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 32 * 35 < 0:
        838
    return total

def _πΨτаПяαЕηбεАсК():
    value = 437132
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQjbbXARqvssLDa5/Xy2YAg251E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΥХШКμиФшγХνщΧξх():
    value = 452549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwzTUQYz8K0qKCCGmnyJOAYJyH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мψИΛшИуЬСр():
    value = 172304
    text = __import__('base64').b64decode('VU94QzNsWjhhbXNlN0xCQ3Fnb1E=').decode('utf-8')
    total = value + len(text)
    return total

def _μмПαГдЩЯΙЦθИЗРФ():
    value = 207046
    if len('') > 0:
        _dead_6753 = 68
        pass
        _dead_2854 = 716
    text = __import__('base64').b64decode('Z0hOQ1FXNTV5VkpDeHM0eEVjckk=').decode('utf-8')
    total = value + len(text)
    return total

def _БΖКΝОΑсΩρХУθДγЬκ():
    value = 129928
    text = __import__('base64').b64decode('SlB6SFcyQktwbzhnQUNtM3FQbWo=').decode('utf-8')
    total = value + len(text)
    if 22 * 66 < 0:
        pass
        397
        _dead_1634 = 706
    return total

def _ωΒъЖλςυΔμ():
    value = 129029
    text = __import__('base64').b64decode('UnpiRlpTMmZINkdPTm9xSXV2NFc=').decode('utf-8')
    if 62 * 72 < 0:
        914
    total = value + len(text)
    return total

def _НъЬΡУдΛФμЖЯνЬ():
    value = 855946
    text = __import__('base64').b64decode('enB6Mm51MEJGRXBvQm9iUUg2cGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚеЫΠсΧφΞψДэнгΡл():
    if len('') > 0:
        513
        _dead_5333 = 195
        pass
    value = 971325
    text = __import__('base64').b64decode('c2xzVlNLSXhBQl9uOEM1dWU2T3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΠтμуГυтΓ():
    if len('') > 0:
        pass
    value = 634864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSrHaVQKwY8EDxWTxXPJLHcq5jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΛμβжτΖρ():
    value = 686308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCLJVlZhrYUNLFi0w1C4FiMnzX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝрцθуьГълчΩфΑ():
    value = 411187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgHXOWE1qJEnClmq2nvGYDYf23c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΞζζйСвΚυ():
    value = 614081
    text = __import__('base64').b64decode('ejQzUzdKS04yRENxX2hUUmVydFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗωΔфχξХЯдлζεμиЮβ():
    value = 768721
    text = __import__('base64').b64decode('SDQ3NHhKYVJranhXVklGdXVnTDg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7718 = 656
        222
    return total

def _дьПνьΙхяОрοьиОυ():
    value = 666268
    if False and True:
        _dead_5931 = 384
        pass
        12
    text = __import__('base64').b64decode('TEtLYzQ2Zk1GZGVfRmZOSFpvUEY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _κΞЙΚΤфГа():
    value = 214671
    text = __import__('base64').b64decode('emc3UlpLcmpyUVRMVGEzSVVrTVY=').decode('utf-8')
    if False and True:
        pass
        pass
        335
    total = value + len(text)
    return total

def _ЖЬпМЫΝЭУΘΚΒОнД():
    value = 500709
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3fPfGEQ6os7DFb67ESJPiA38Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йУГйΞτΟяЛθκμяМй():
    if 23 * 90 < 0:
        _dead_5740 = 774
        pass
    value = 382029
    if False and True:
        _dead_4646 = 426
        _dead_2455 = 812
        pass
    text = __import__('base64').b64decode('cFcwSFNJdTFXcTFCaF9zOFgzYkI=').decode('utf-8')
    total = value + len(text)
    if 96 * 37 < 0:
        21
        565
    return total

def _βυДПΥЯЛΚенΨЗ():
    if False and True:
        231
    value = 830641
    if False and True:
        _dead_7137 = 167
        _dead_2602 = 652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAHwdgdqz446ADCixW+/PgYOsUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЭΘШРτЖЯτОГΤΦω():
    value = 21240
    text = __import__('base64').b64decode('Y1hvNzFyaXNvOVdvMERWUTc5RWY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        918
        pass
    return total

def _λΙСωΣζгжθχуςа():
    value = 697204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCDgVFJu7ZsUYxap7lLGNyon6WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩГЮТмчыЪψλШКτж():
    value = 56350
    if 95 * 19 < 0:
        _dead_4208 = 91
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgHHQGEv/ZFVAD2um06kBhU39VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4764 = 839
        _dead_1131 = 860
        _dead_6746 = 521
    total = value + len(text)
    return total

def _σпΜΨоЫАМИэхΧЩ():
    value = 923657
    text = __import__('base64').b64decode('cTZ3SW5UWXp0bU1keUxLMzZubEo=').decode('utf-8')
    total = value + len(text)
    return total

def _εЩПкзИкΘυзпВйφ():
    if 40 * 92 < 0:
        pass
    value = 230065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAu1OlQ46KcrPSj1zg+5E30jt3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЪΥρШΖНΘЭБЩщЙЫΒ():
    value = 953650
    text = __import__('base64').b64decode('ZTNuZTZKSXJ1V1pxMmU5RUEwT1o=').decode('utf-8')
    if 9 * 44 < 0:
        _dead_9319 = 437
        _dead_2692 = 355
    total = value + len(text)
    return total

def _ΕΙЪΘΑυζμζЛющиΕХю():
    value = 404907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj7GSnka1o0wDC2G6nqbByEB50Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пщмИΠЫρСссДη():
    if 92 * 94 < 0:
        _dead_9695 = 794
        _dead_4233 = 919
        946
    value = 2030
    if len('') > 0:
        574
        pass
        67
    text = __import__('base64').b64decode('cEtqeWhQNXRHMlphUXpNUGdCU0I=').decode('utf-8')
    total = value + len(text)
    return total

def _κБщПΗΒΖγЫρεΨο():
    value = 364534
    text = __import__('base64').b64decode('bTcwYUhEeTZjcTdDdEJtUGpfTmw=').decode('utf-8')
    if False and True:
        9
    total = value + len(text)
    return total

def _ΨрΟСнАςщΜΙοЬ():
    value = 997129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCSzXWIw5q8nMhq2mFKqEw4o1zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яГεΟшцОкΡД():
    value = 97375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3nlRHls5K8VbQyQ5UyeBRQ41zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 64 * 93 < 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_9861 = 974
    return total

def _чΘгуъεЩцЙλоΑлΧМТ():
    value = 529582
    text = __import__('base64').b64decode('YlI5bjRiVVhlWVhyWmlZcEhsWjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗжнΩιΓЫΝЩТ():
    if len('') > 0:
        pass
        pass
        _dead_7246 = 618
    value = 702060
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRzbTUg00P5QOyO7/EOyBjMNzns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘρАЗΠХΝΠαшλεπΡВσ():
    value = 82453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiHKf3IBr5ILEjC5/n21Pyd8y1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝКТыμзшъбψс():
    value = 108444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj3nNmUG954ONymG5HujLCIoxzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭτэΩζьГςαεΝ():
    value = 82737
    if False and True:
        pass
        543
    text = __import__('base64').b64decode('YW03X2NOQTVrcWdUTzRtWTNlNXk=').decode('utf-8')
    total = value + len(text)
    return total

def _тнΔнПωτйΛБсхк():
    value = 80685
    text = __import__('base64').b64decode('TmFMMWtiODJyTG56VFVRVTFzeDU=').decode('utf-8')
    total = value + len(text)
    if 54 * 52 < 0:
        pass
    return total

def _ΛΞПГцΔМцуηС():
    value = 62048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAToPHkwy4cEODCHwwWBOncB4Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еοθВдХчщαδ():
    value = 663967
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAzMdlkNrZE2Ljia0nOpMBx29jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        608
    total = value + len(text)
    return total

def _фжвИβΡЫеςΞδЮмκщ():
    value = 770789
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EC7tYmYK/aQSLi6i+wTAGQwXyX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 58 * 53 < 0:
        489
        pass
        pass
    return total

def _РнοСαΒжСЪφЗθИοΚь():
    value = 229129
    text = __import__('base64').b64decode('WElwNHVDNllqSWhPa2M2U3FPTkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫоЕβТχΑΤЭ():
    value = 70387
    text = __import__('base64').b64decode('SUM2S1AxTjNxVXVuaGZKb0Ntb3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΡΕетμГνΗЖчβΟ():
    value = 641879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxzhSVQdq/5aED+o6XuvJwAVsEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МμДμЕΞвιВΣΦПЫΜЭ():
    value = 516456
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgnvWlQj+/0tPSqN60O4GA996W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛЧШПφΓмфэуΥЭΑщ():
    value = 552868
    text = __import__('base64').b64decode('S0czMU96OVRfVHF4NThGNks5OUI=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4116 = 852
    total = value + len(text)
    return total

def _ьχПιΧАЧнОщΔ():
    value = 699943
    text = __import__('base64').b64decode('Yzl4UGFGMXRHOHhPZ0pGcnRYcGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗъБοεЙΖπΡκЯЛзΔЩЫ():
    value = 844946
    text = __import__('base64').b64decode('R0x0akJXd1dPRndONGdsMGZrNWg=').decode('utf-8')
    total = value + len(text)
    return total

def _νТΤСждУυεΥΤΒΖ():
    value = 373989
    if 43 * 21 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FifUfEYD9poCEACm2HiyBQcb73c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        819
        _dead_7774 = 723
        475
    total = value + len(text)
    return total

def _νБщНρΗπГν():
    value = 429162
    text = __import__('base64').b64decode('UXZaUW9jMU43WHR3TzBtQmI5dEE=').decode('utf-8')
    if 32 * 93 < 0:
        677
        _dead_3968 = 339
    total = value + len(text)
    return total

def _ωΝЧвςШΓΚЦοРЪξΤкΑ():
    value = 715690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhiwPmIt7K88Nwz37WC6OAQm7Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕэНУιτЬΛΠГΘЮаР():
    value = 153625
    text = __import__('base64').b64decode('aURyeDY4RkJaZEdHTVo2eDY2dFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΒйайΔЕтЫзΛυьЕ():
    value = 394870
    text = __import__('base64').b64decode('dDVVc3EyRFluRnVRTndFcFFiSkc=').decode('utf-8')
    if 43 * 83 < 0:
        125
        _dead_3224 = 200
    total = value + len(text)
    return total

def _οαъцшωΙζЗχЭαΣЙо():
    value = 493844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSPxVlQQ8o4pGAmz3VShHwEC6ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΑκΥшмчΧΦнιЕΓл():
    value = 558327
    if False and True:
        _dead_7261 = 792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXjpTENp2LkaYgKZm1KcZA4B8mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 86 * 61 < 0:
        _dead_7544 = 617
    return total

def _эуΩюΦυΤφдУΒВ():
    value = 846349
    text = __import__('base64').b64decode('R1hfU3JRVVpwUm8zOGV1ZmpnVG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ыдЕоχЦΞλъςΜΤαγ():
    value = 798575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwX2dngyrL0Iax6A5k/INykcwTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _βбΤОρдΦрΠМ():
    if len('') > 0:
        276
        67
        279
    value = 99830
    text = __import__('base64').b64decode('dkx3Q3paWjlkUk1OZTN1WEN1SGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗлΗчξьйФтΟςАД():
    value = 829211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwbrY3YXzpBSLluC2kzIZSc5tVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2108 = 869
    total = value + len(text)
    return total

def _ЯТоъхЙДΧΞχ():
    value = 364238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBnMfUgAz44TDgaa8k6kERx63jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΜΔΑшζυгУΔФХφХμшε():
    if len('') > 0:
        pass
        pass
    value = 676926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PB/rOFsg0/EvLyyx/HWSZ30/0WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υпΞЖγψгΥηоιь():
    value = 680101
    text = __import__('base64').b64decode('TEpKQTdaWEJPVWU3aVlzdEZFWW0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        17
        47
        256
    return total

def _ΣΩηУδЙйКΥэΕСΚьτ():
    value = 3513
    if 35 * 47 < 0:
        _dead_9871 = 547
        180
        477
    text = __import__('base64').b64decode('aEJfblZqeTFKOTBlWDBtQkxSNzI=').decode('utf-8')
    if False and True:
        pass
        124
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ыТжшотлнщХз():
    value = 578324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXn0UXMu0aAEIw6P8XqaNnQ5x0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВδοеΦυчщ():
    if False and True:
        535
        _dead_7453 = 977
        _dead_1712 = 75
    value = 962712
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCzhRVwg5IUXAgCm4mGaOg0B8FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 16 * 35 < 0:
        491
        _dead_2441 = 258
    return total

def _ъΩΦθΑЭхβΖамΚль():
    value = 886171
    text = __import__('base64').b64decode('Y284am00NE54YTRYdHZENFMwQ0U=').decode('utf-8')
    total = value + len(text)
    return total

def _вΜРλТТГεЪΗ():
    value = 672864
    text = __import__('base64').b64decode('dXNuUDRVSFFUSDVKdzJjNXZTOXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ДеνДШЙωСЙшФоΜе():
    value = 320099
    text = __import__('base64').b64decode('QVAzSmxZQXFSNmxiMms1N1hPd2U=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6522 = 689
    total = value + len(text)
    return total

def _ΕЛΖРΗНьΩΙщσ():
    value = 68202
    text = __import__('base64').b64decode('Q21GYURIYzBuSEpKeUNGaFhZSEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΔιΑЮьЯъиьжΔΥэ():
    if False and True:
        _dead_2100 = 547
        pass
    value = 721368
    if 97 * 30 < 0:
        pass
        _dead_5434 = 287
        879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn/LP0syxJwKLSel3Wa7JDwN9ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΣρυжчДол():
    value = 242844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAqxbEFo64kPDDyw2WKzFRQE9To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_9367 = 921
        pass
        pass
    return total

def _кνΥПИΧдвсπКАэν():
    value = 614008
    if 59 * 51 < 0:
        _dead_3442 = 990
        138
    text = __import__('base64').b64decode('RnJEUjFzV0xKVVJYMEd3NVViaVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ξуМФгξЧпκИЩзЧπяв():
    value = 405876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHjlRlRg1KApHyWw4we/IRYcznw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яКωнκυФвФζлДФэ():
    value = 640929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDb8f1pg76AkawKE2VK/FxcI5kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЗοΛЯΡΣσЦИΛΓτЯА():
    value = 516501
    text = __import__('base64').b64decode('dzdXS3M4RWpldXNVRFIxR0xBc0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЭσΩψутвΩаыα():
    value = 656933
    text = __import__('base64').b64decode('WHFmNGt1SFZlV1pXdjhQTXBNT3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭЗБψδяГкК():
    value = 356685
    text = __import__('base64').b64decode('ejhwbXNLQjRXQW9nSFZHeXF6cmw=').decode('utf-8')
    total = value + len(text)
    return total

def _пΕТΣДβЯщеΥЮςьмκБ():
    if False and True:
        _dead_1861 = 36
        81
        _dead_8951 = 926
    value = 828855
    text = __import__('base64').b64decode('QkpXTXhlckxvS0F1cHlHcVlQbWg=').decode('utf-8')
    total = value + len(text)
    return total

def _юфЗнΛοажΘΖΦΤШч():
    value = 566824
    text = __import__('base64').b64decode('RXpHNnFVcU1RNE1SdWRteHA4WEc=').decode('utf-8')
    total = value + len(text)
    return total

def _яЮζкфΗΙγЦцΖ():
    value = 962562
    if False and True:
        161
        pass
        _dead_8969 = 603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KizbbFJv9IQFDAyG/V6IMQZ980Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бЗБΚФпвΝДθεАΧхц():
    value = 471525
    text = __import__('base64').b64decode('c1NKSlJlNEJTYkVUZXNGQjhJa04=').decode('utf-8')
    total = value + len(text)
    return total

def _кжАэЩЧмхιΟΨнКλθ():
    value = 81230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXrUQHcT6YI6aAKB3EbDZDQ85Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γхкαΞэЗиШз():
    value = 312517
    if 38 * 63 < 0:
        926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyzQeQcNyvoqPAG2mnrDNSEasEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        41
        pass
    total = value + len(text)
    return total

def _ччБΛнΛηιПΧБЮы():
    value = 629813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgrsTEAe/bInCR6R+36KBgcZzT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МАτξЧДЩηмΗθ():
    value = 398146
    text = __import__('base64').b64decode('SHhTb2ZKWlpkaUVodE16YzhESTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛιОвγЮжъмю():
    if False and True:
        706
        pass
        113
    value = 316279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXvDYGs4roI5Kyakz2C4Zx0a8ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 82 * 49 < 0:
        _dead_2949 = 558
        _dead_1589 = 548
    return total

def _ДΓЩтхЛзΒоΔ():
    if len('') > 0:
        _dead_8049 = 742
    value = 257427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dgv8dGMs7YEUHgutzVimJXcJylQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣεςЭВчΝε():
    value = 808049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwDFVEML+oU5NSL10FPFIHIJ4U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΙМКξйеοΞβтЪЛΧНо():
    value = 713783
    if len('') > 0:
        903
        _dead_1202 = 675
        _dead_7952 = 290
    text = __import__('base64').b64decode('aVNyYms1ZVFtMVZnU3Z0SHJXZ0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΡсΤнэΕΑуωЪδЗ():
    value = 975078
    if len('') > 0:
        187
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgHPP2Iu/IIvAwaozn2XOjAV43w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иυэхОЦуςЛТщУк():
    value = 879665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCGwegQ6rp0SKimP2XuRMXE93Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        200
    total = value + len(text)
    if len('') > 0:
        _dead_4772 = 900
        _dead_1377 = 159
    return total

def _РэаτЗищкεμпбρЗйκ():
    value = 223635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRW8ZAcsppozNT2PnlWgCy4h3Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1405 = 924
    total = value + len(text)
    if False and True:
        _dead_5803 = 664
        pass
    return total

def _оВХЛχюυсεнГδЕТ():
    value = 52690
    text = __import__('base64').b64decode('R1NwVXc2RnJncUVNSUl4TGxpQnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _КИωΕоФΨμКΝсМΗλ():
    value = 220966
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSrbXn071JENIA2p5WS8YSMs0Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УψΕβτЗτΥωΓК():
    if 72 * 31 < 0:
        pass
        pass
    value = 100327
    text = __import__('base64').b64decode('aTJJNFp6SVJlaXphTjk3eTVkOTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ωςЫЪΩщαАг():
    value = 795402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BB7CZ0I72adaLyiomHGZOHc+w3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 82 < 0:
        pass
        _dead_2404 = 89
        262
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _εСГтФжвσжЯ():
    value = 877820
    if 52 * 38 < 0:
        _dead_8018 = 474
        _dead_7641 = 975
        _dead_1287 = 648
    text = __import__('base64').b64decode('V2V4cEk4TWFmQzVSVDRId08zdnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ςγδсΦΘщШСζΣγ():
    value = 818912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgnqWmALxo5VGAGX/HqTLBp9/k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 70 < 0:
        161
        _dead_8375 = 346
    total = value + len(text)
    return total

def _аγжτφΘЦшФх():
    value = 216706
    if len('') > 0:
        744
    text = __import__('base64').b64decode('SVNJaFk4ZzFoR3Uwc0pMT1E3TG0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9261 = 430
        pass
        pass
    return total

def _уяЧмоΤергьГ():
    value = 649526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz7zalYG5KUoOyqK50aaIwZ+tT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νЦкθχЬτеΔΠВ():
    value = 739427
    text = __import__('base64').b64decode('YURYX2IzdUVGaFREVDlIRHRWSGY=').decode('utf-8')
    total = value + len(text)
    return total

def _μИυΜцψυЩЛ():
    if False and True:
        pass
    value = 577601
    if 94 * 82 < 0:
        832
        _dead_8494 = 735
        761
    text = __import__('base64').b64decode('YkVqbFZmc3psczJsa1RwTDY2bDI=').decode('utf-8')
    total = value + len(text)
    if 58 * 43 < 0:
        _dead_3307 = 587
        pass
    return total

def _μΠΥчДНЧьсΩΨΥ():
    value = 912536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTjxP2429KUTGQuEynibDCYlznw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 98 < 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        865
        297
    return total

def _ΡΠРηΙςйЭΞОЭюфх():
    value = 477792
    if False and True:
        pass
    text = __import__('base64').b64decode('UVpSaUluTGZ3TUEzZ05VSG0xbjk=').decode('utf-8')
    total = value + len(text)
    return total

def _еνХТΑιжЕΘпςцοЪЫ():
    value = 155143
    if len('') > 0:
        _dead_5647 = 306
    text = __import__('base64').b64decode('a1N3eFVtMUxEZkdhblprRFQzWW0=').decode('utf-8')
    if False and True:
        _dead_8733 = 102
        _dead_8280 = 729
    total = value + len(text)
    return total

def _рΖыЯЫаыЯ():
    value = 48231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FB/sbXk37KQRbSny7EaWGjE9wVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΠιιИВСθΟΑЫ():
    value = 321756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQvIYV8c27kGaB2B3n2yHwga9ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оνρРЩыИφлй():
    if len('') > 0:
        pass
    value = 605389
    text = __import__('base64').b64decode('Y3R1bzNKWUlYcDRLWklGYTAzSmg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        161
        _dead_7796 = 203
        _dead_4555 = 527
    return total

def _ΔιшΟАдσцιЖΛРЕЦτ():
    value = 796957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQDvV3YByPwBMQCTngOWHygQ/H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧдЬЗЮΖΨЪ():
    if False and True:
        pass
        121
        _dead_9448 = 938
    value = 262186
    if 43 * 12 < 0:
        _dead_7203 = 382
    text = __import__('base64').b64decode('RUNQS1pQdm5JQWJDa2o4ZnpNZ28=').decode('utf-8')
    if len('') > 0:
        pass
        390
    total = value + len(text)
    return total

def _ЙΝБуΝыбь():
    value = 840254
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnbXewAQz6sSLg224F2CATU64mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑнΚζЛиτЛφм():
    value = 313756
    if len('') > 0:
        pass
        _dead_7251 = 284
        _dead_3433 = 825
    text = __import__('base64').b64decode('ZDhFU0VfaFZETlhBVllEeTdXeWU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        754
        723
    return total

def _УсШзАαДΕэмΠψкъмю():
    value = 578494
    text = __import__('base64').b64decode('REgxd2NyQnl0WnhnX0NseWhiMFM=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_3519 = 994
        pass
    total = value + len(text)
    return total

def _ЫβкΕβйμΠρХΖЮэΕУ():
    value = 127814
    text = __import__('base64').b64decode('UFlRaVRvQU42VTNlWGYyb0R1MkQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        130
    return total

def _βυткиκχюГМω():
    value = 587613
    if len('') > 0:
        _dead_9473 = 157
    text = __import__('base64').b64decode('Ym9RMU5pM3VKbGZSWlRjTWVZUm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΨΕЕОШВΑΔφ():
    value = 669934
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTfLOnMt36pXLyWQ5VKDFiIo1Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 89 < 0:
        276
        139
        _dead_5616 = 846
    return total

def _αОιмЪπвφ():
    value = 978788
    text = __import__('base64').b64decode('TE53OTNfa19CZFpJNUxzYWpOQXA=').decode('utf-8')
    total = value + len(text)
    return total

def _мрщъаьоΓθΔκΚьΦ():
    value = 564295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRnQRFUB0ZoqNgfx8HDENjAd4Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΞτЗярлЛил():
    value = 903865
    if False and True:
        _dead_2990 = 881
    text = __import__('base64').b64decode('dUg0V2tHVU5rTzU1RUlqanpxdG4=').decode('utf-8')
    if 7 * 30 < 0:
        _dead_6296 = 669
    total = value + len(text)
    if False and True:
        pass
    return total

def _δηрТПΗШοхЕΩпρ():
    if False and True:
        _dead_8121 = 709
        pass
        444
    value = 89143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRjIPkI10vgJa1ao3H6WbSol20k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        457
    total = value + len(text)
    if 13 * 26 < 0:
        321
        904
    return total

def _ЕΕЯПσВГΥ():
    value = 374902
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESbIRXUo+LgmFjql+ADJFzR2wjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        573
        _dead_7134 = 283
    total = value + len(text)
    if len('') > 0:
        _dead_1878 = 189
    return total

def _дтСХσΩЬзΣюΓЫуκ():
    value = 611585
    text = __import__('base64').b64decode('SXVnZFFBTWZtVzBWU1NJTWoxSGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ИкоЬσδОωГυцуΩЮиЫ():
    value = 280149
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhjQOm4p9bg2NxW2+3SoOC8Xy0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        111
    return total

def _κβШοηЧшΓЙ():
    value = 687648
    text = __import__('base64').b64decode('cU5WU25HcUVSTDNWV2hMRU5zUjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜοαλеЖψαгТΩ():
    value = 22877
    text = __import__('base64').b64decode('bE04V0lrc0Z2REFUNUxqMm80R2k=').decode('utf-8')
    total = value + len(text)
    return total

def _тгκσΞыσЬЭв():
    value = 844511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXbTbUtqx7xUEirx7UDAJwcB8UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЗюЪЬΠρΜцκчЧ():
    value = 396321
    text = __import__('base64').b64decode('bktxVFZUQlJ2TlI3Y0FpYWNzX1c=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        705
        _dead_2442 = 255
    return total

def _КΒΤцУыΡΙэ():
    value = 702895
    if 66 * 7 < 0:
        _dead_6220 = 786
        pass
    text = __import__('base64').b64decode('Y0FWcGZ1UTVnWDBhT1ZzWWtIem8=').decode('utf-8')
    total = value + len(text)
    return total

def _еΞΣМлΨРΗРрЦαСиκэ():
    value = 537290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjfqYUkpxq0SbFm2mQezYhEh5kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αМεδьяМЕЦοЙΦχωΕ():
    value = 824147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESnVOUAB+bk2MBuQ4VS/LjIWyjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αДΜжλκηЛΔλЬоοрО():
    value = 450638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHvpXngK/LgsKAaFnHmXE3B86Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШнτЦаΨθСРАΟыΝΣ():
    value = 20645
    text = __import__('base64').b64decode('Z2VtazlGY2FEM2dtc0gwMHBjY3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _χсицΣαρгηхκПаΘ():
    value = 758552
    if 91 * 82 < 0:
        76
        pass
    text = __import__('base64').b64decode('RmVRTkdqOUx1d2hYOXRvUGJ0QzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ζСЙΖЦАИЮΣξΧυΣοΟ():
    value = 377394
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('TTZkOXdEU0tTZHZwVDF2bzlLQ0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑяДсВδΟΔЪЬЙΥ():
    value = 611295
    text = __import__('base64').b64decode('WGZRZTJDWlRyNkxiaDQwako5VTg=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _СшъДχнνУ():
    value = 752324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwrMRmQw7fs2Myiu/nmfEj1+sjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2272 = 796
    total = value + len(text)
    if False and True:
        _dead_4422 = 814
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()