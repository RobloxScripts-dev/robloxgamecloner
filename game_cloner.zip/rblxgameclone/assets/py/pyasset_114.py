#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _уΛъΙдЪιдΡчΑγψ():
    if len('') > 0:
        398
    value = 716706
    text = __import__('base64').b64decode('SVB6aHJUcGV1aWNENVBieXhBRE4=').decode('utf-8')
    if 68 * 26 < 0:
        pass
        262
    total = value + len(text)
    return total

def _ΨОЬБΣΨΖюи():
    value = 483541
    text = __import__('base64').b64decode('UXRYUDVzX2lVZnhFQTNZVHRiSHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡМЗζЭΓюηЯΗл():
    if len('') > 0:
        404
        pass
        pass
    value = 116513
    if len('') > 0:
        _dead_8838 = 477
        149
    text = __import__('base64').b64decode('enVoV2ZwSTFPblBzM3FybVFRMDk=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_5147 = 0
    total = value + len(text)
    return total

def _вШπρЗщΕνЮДΥеωжЭ():
    value = 134525
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dz+8V2cLprIVDVix6kXJOBE7wmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΜпСнцщГ():
    value = 386806
    text = __import__('base64').b64decode('clcwOF8zNUpONlhVSURQTF9LbkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦПΖфΨΦсщγΑΖя():
    if 3 * 2 < 0:
        592
        230
    value = 525190
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnrjfV8yxIAVawCz8VOXYSoiwj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮКΟπеΞКъЙχΓчЖ():
    if 25 * 22 < 0:
        _dead_3292 = 337
    value = 289477
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwP1SUYQzJxUOD6m33OYPyYN8lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЛπΚδЫΣΤΟΘЪФμΑφ():
    value = 690941
    text = __import__('base64').b64decode('Z0Vzd1d6S1JFZkpSaWppNGR0b1E=').decode('utf-8')
    total = value + len(text)
    return total

def _БθРхΜрьΑΖп():
    value = 477586
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRnMYgAT6vsyFlb222STBXYl5kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 95 * 75 < 0:
        _dead_7632 = 135
        _dead_4366 = 556
    return total

def _тιАкЯςοАышб():
    value = 2108
    if False and True:
        427
    text = __import__('base64').b64decode('S1plQWpfdE5WeWNpOFRQVkdiT0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ОмгθЫΠсΛΞРыηΓφЕЯ():
    value = 357368
    text = __import__('base64').b64decode('UkpOd1V0OXo5SjF1aUV1RXdBVjY=').decode('utf-8')
    if False and True:
        181
        389
    total = value + len(text)
    return total

def _σΙΒυχαКРЗфЯИвΑφ():
    value = 706518
    if 17 * 1 < 0:
        _dead_9130 = 611
        _dead_8421 = 352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERXvPn8415s1DjiN20CUNgkZyFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        127
    total = value + len(text)
    return total

def _πжρΞЛΨτШзуΚчιе():
    value = 946008
    text = __import__('base64').b64decode('R3FKdElZZXhOa0s0ZWU5SDFodEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪнчνжЯΜЩΝаяυкРΡ():
    value = 749971
    text = __import__('base64').b64decode('ZkN3eVlJUDRqajlTTXdjcm16R0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ТЪξρπгвρгытнЪ():
    value = 221388
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kxv+OGk97qktCFuan06/BRwOvGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΒхΡΜΜЖИσъψъбГнε():
    value = 51870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DC3AY1Icr6IhIDazmUOmGHMVzEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 14 < 0:
        _dead_4199 = 868
        pass
        _dead_1809 = 554
    total = value + len(text)
    return total

def _ыНΖЪгиСРЬμΘςΟюзζ():
    value = 871694
    if len('') > 0:
        pass
        _dead_8906 = 911
        _dead_3616 = 183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pyi0WFwV9YEEIFqwn0TIIHMrxns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТсΜХΥуΠΞΑΡСЪΕыΦф():
    value = 920024
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCzxaFZrzb0BNAOlnlybPy8/wUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔйЯчЛρРбΛΦ():
    value = 234260
    if len('') > 0:
        _dead_8551 = 622
        255
        pass
    text = __import__('base64').b64decode('dFc1RWRmV3I1aTNLM19BeVVySTM=').decode('utf-8')
    if 2 * 19 < 0:
        225
    total = value + len(text)
    return total

def _юЙаЗΘΘэμξд():
    value = 402371
    if 65 * 79 < 0:
        _dead_7830 = 437
        720
        908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz7rbWIgqqpWCTeQwA++ZBU3wjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧЭЭуЬпСАЩιПβφΕзф():
    value = 562474
    text = __import__('base64').b64decode('akFFaHVOM3FiR001UWlUT2hHRU0=').decode('utf-8')
    total = value + len(text)
    return total

def _олζγΚХодτРΜωπ():
    value = 336676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRvIfV8Yyf4AIgTz4A+4Cyo400w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шъЕИΠдαψΖΓρкПнрβ():
    value = 792385
    text = __import__('base64').b64decode('bl9iVDBqTThOQUZwS0FqYlF0SGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЛΦδхБΛыΤхΝρЛ():
    if False and True:
        _dead_8730 = 206
        733
        _dead_1317 = 424
    value = 998448
    text = __import__('base64').b64decode('dm9HRVY5TF9ZYWZUM1VEWnV6eVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ХτбωΑМДо():
    value = 542327
    if len('') > 0:
        645
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyvJWgYb0aATaDqN0liCPnU/8WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θШσйЕТыΖЕи():
    value = 32979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AC3lQnIJ9os7ACK55FqSNTEo3WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цσчЦЬЫΖΤНеξз():
    value = 687615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In3XZkE7yqEoAjrwygXBGnU4tGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гχрΠфСΤС():
    value = 418923
    text = __import__('base64').b64decode('WkJlajhtaG9RZnRYR25BZFZ1R3c=').decode('utf-8')
    total = value + len(text)
    return total

def _тΥУллНхΘΚδΩξ():
    value = 169080
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiH9QWYc2Kk0OQmb+FOCIAAN62o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8161 = 110
    return total

def _ээСщгςΙΑΝ():
    value = 27742
    if 73 * 4 < 0:
        _dead_3994 = 353
    text = __import__('base64').b64decode('SXVpQ0hWckVmSUFOQXpWenlMSUI=').decode('utf-8')
    if 19 * 31 < 0:
        pass
        556
    total = value + len(text)
    if 59 * 88 < 0:
        pass
        pass
        _dead_4448 = 344
    return total

def _ΨсοΓΝβАЬσΟЫξς():
    if len('') > 0:
        857
        274
        817
    value = 712351
    text = __import__('base64').b64decode('QjdnN3E3Y1daMTkxMFd1VWZBU2o=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _βйΒъОкпхвНс():
    value = 197152
    text = __import__('base64').b64decode('UmlPalA1aFhrd20wa0UxUVZhYVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ПВРнМсПΡл():
    value = 987901
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXjQYksz37g2FDiA3QK3JSgk228='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5183 = 174
        _dead_1439 = 299
    total = value + len(text)
    if False and True:
        880
        846
    return total

def _ςπΣьκькРσМωНφъβδ():
    if False and True:
        116
        _dead_2819 = 268
        pass
    value = 207664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDfuPWcy0YlWG1+h2mPIJTAmvXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        657
        _dead_1115 = 428
    total = value + len(text)
    return total

def _δБσъΚЫуεΒ():
    value = 554338
    text = __import__('base64').b64decode('ZmV0U3JpeExQM2taQ1JuSFpWaHM=').decode('utf-8')
    total = value + len(text)
    return total

def _евζдхμγЙчЭиОοχ():
    value = 532579
    text = __import__('base64').b64decode('Z1A3MDlpV3FVXzU1RUszMnNWdGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ыψΙбΕцгηЛМЖηυв():
    if False and True:
        _dead_8488 = 328
        pass
    value = 429073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwjhW1ADrYkVLgq2w2CGOiQZ3lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΡЕΧΣАНШζΗ():
    if 43 * 18 < 0:
        pass
    value = 706647
    text = __import__('base64').b64decode('WnFLaE16Y21YWDZlTG9Dd0QxcF8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4147 = 111
    return total

def _оωФΜΥΝΛКε():
    value = 866287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAPLQgMy8p5QDyuTwmOZbX0D020='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 1 * 66 < 0:
        983
    total = value + len(text)
    return total

def _УАоΔЮзуβЦΓ():
    if 85 * 6 < 0:
        516
        _dead_1683 = 751
    value = 98349
    text = __import__('base64').b64decode('Q0hXbVRnTkdsSnJaSl8zbTllOHY=').decode('utf-8')
    total = value + len(text)
    return total

def _κбэбчΟМΨξΞ():
    value = 530608
    text = __import__('base64').b64decode('WFRvcWJMZV95Sm5UajhNb0NqODc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫРΛβКΗπрΜ():
    value = 706321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3f+TAYt+4YXMReCngO7bBwa/Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΧμПуСоцсΦВΤцБх():
    value = 679158
    if False and True:
        pass
    text = __import__('base64').b64decode('c3VUR01wNnpGem9aRFZWMnlPdE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЦΖολАЕιξШЛжσ():
    value = 945076
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxrBYFMY0a8zHQWP30CIADI/1l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 91 * 8 < 0:
        _dead_2895 = 664
    return total

def _ςιлШΖφЙт():
    value = 305267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhfKYVxv1/oQMheS0makFgsZ3ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _χνЖβнΞΦνΑΕПг():
    value = 607124
    if 75 * 23 < 0:
        _dead_4910 = 513
    text = __import__('base64').b64decode('Q2EzY1hqckRKQ2haUXdLUHJHalk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧогμΘΛреЦ():
    value = 584002
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD3MfWEXqaIgKweS/1WqZyp4xX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щжτвБЫΜдΚ():
    value = 636068
    text = __import__('base64').b64decode('RU1KekVPeGlBV2dndlZNTXpTeWU=').decode('utf-8')
    if False and True:
        443
        _dead_6587 = 622
    total = value + len(text)
    return total

def _тΞθнχПуΕа():
    if 27 * 19 < 0:
        _dead_4460 = 887
        pass
        194
    value = 44993
    if 38 * 95 < 0:
        597
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwmyYlkw+IQ0FwSizHu8Zign8mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξКβгλнξοΗψ():
    value = 905758
    text = __import__('base64').b64decode('RnVDZnFlRXFmQkJ6elN6OTY2Vkw=').decode('utf-8')
    if 71 * 62 < 0:
        pass
        843
        220
    total = value + len(text)
    return total

def _ημΘΧСБпчдюЮΟе():
    value = 523674
    if len('') > 0:
        805
        807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRmwOQg67pc0CBv7mgCXP3Ie/nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩуαΘЕНсиτт():
    if 92 * 41 < 0:
        _dead_2759 = 839
        842
    value = 718990
    text = __import__('base64').b64decode('RUNHdzRKZW4ya3lIMHJaSmx1Szc=').decode('utf-8')
    if False and True:
        pass
        _dead_7290 = 73
        pass
    total = value + len(text)
    if False and True:
        113
        _dead_6622 = 278
    return total

def _цχСΥεХΙЮ():
    value = 754868
    if False and True:
        pass
    text = __import__('base64').b64decode('TXRwWW1nckVCdlQ2ZXUxYU9tZVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΠмΞΕцδкУ():
    value = 707596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj3OWVU/wbo3LiyHz3ioZhEH1Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝЪтξιΗΓфΣчЗХДπζ():
    if len('') > 0:
        pass
        pass
        426
    value = 246046
    if 78 * 94 < 0:
        154
        pass
    text = __import__('base64').b64decode('SXZRcmxxWnQxeFM1S1JLM0Z1RXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩДΜЩкСΡοΩшΖθ():
    value = 268293
    if len('') > 0:
        pass
        496
        _dead_2912 = 558
    text = __import__('base64').b64decode('dFU2M2VhbHAxS3NtM3VxZUdXbzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ОСЫΣЮОБс():
    value = 132690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSCxXWUWxp80Ng2XwUGTAxUp8VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΝциΖяΠЦυμГρчТб():
    value = 835296
    text = __import__('base64').b64decode('RmlyczVTWGpucGNHaEs0SnhLQkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝπΛъЛυШιшωЦЬс():
    value = 821378
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn3DP2gs1fg3AzmI8mmlAncZ8z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дφьξΠΒσΙз():
    value = 341631
    text = __import__('base64').b64decode('U3BYV2UzM1hZdVh3U084cl96eWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯЦрΥЪγСвЮΜΤοΣΙωА():
    value = 549390
    text = __import__('base64').b64decode('V1c3QVNqaW5aMHliZnBseEVqTUw=').decode('utf-8')
    total = value + len(text)
    return total

def _юЕлШδХйΑиΙз():
    value = 874808
    text = __import__('base64').b64decode('YTBKWXhTcWM1R1N4OHBSUW9ZZlk=').decode('utf-8')
    if False and True:
        pass
        _dead_7248 = 738
        875
    total = value + len(text)
    if False and True:
        306
        pass
        pass
    return total

def _ЩзЬЩфЙυρΦγε():
    value = 63195
    text = __import__('base64').b64decode('bTRDWmlLRkpCTXdNV0VDSW1mSEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕАχшэωдНχ():
    value = 390431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InjVekk9yIQyOVyoykKhYic76Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΡιΗΩφУш():
    value = 371345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBvhNwIh8Y4BHT+uwF+fEg4X938='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δЖτΡЩгЪΧΠУΝ():
    value = 456503
    text = __import__('base64').b64decode('TVhaeFJ2UFVkTER4OWhYMmE4SGw=').decode('utf-8')
    total = value + len(text)
    return total

def _χΓИΗΞихσЛЬВщΩо():
    if len('') > 0:
        _dead_9825 = 98
    value = 442020
    text = __import__('base64').b64decode('T1E1R29iMTJsUTNlR2JVdGJ4d2U=').decode('utf-8')
    total = value + len(text)
    if 48 * 90 < 0:
        7
        204
        pass
    return total

def _УиλяυсθЗбУ():
    value = 881002
    text = __import__('base64').b64decode('SEFfNW9TMXBNZHdFYUtpWEFfU3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΘηъчВЩъΟЫΩ():
    value = 512495
    text = __import__('base64').b64decode('aUUzblVWM296TXFscGZudkNBdEI=').decode('utf-8')
    total = value + len(text)
    return total

def _οХГιΥАЕχη():
    value = 302659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyDee3cL1bEVFwX07lfEBgt+10o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЩΖυеοЮнχη():
    value = 719941
    if 14 * 52 < 0:
        39
        _dead_1515 = 90
    text = __import__('base64').b64decode('Rk1FREQwQjhPZmxnckR1aEFPOTc=').decode('utf-8')
    total = value + len(text)
    return total

def _цοПХяЮАКВα():
    if 60 * 70 < 0:
        pass
        8
    value = 160295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBnRNmIy17kaPT2U9wbHByMI9T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВнωрЛтΒτЩΟΕаδф():
    value = 947882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lwu1OVA3qIEZKDWb5FOxIQ935WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щγтзνЙЙбсΓνψσ():
    value = 501575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J33rQmYI8LEBHl737EOgGzUVwlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цμУТПсΝδфοΩ():
    value = 801688
    if 83 * 62 < 0:
        pass
        _dead_1509 = 836
        pass
    text = __import__('base64').b64decode('WV9sYkpCMTRMSmhQRmNBdjVFTkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _РФвЬЕβюшЬδω():
    value = 945704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzrbRVMA0fEoDiqA7EGHMi8p5X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЩλρυэυΤЕ():
    value = 286608
    text = __import__('base64').b64decode('Wnl6ZzVOeWNWVXd2QUttaGlYMXI=').decode('utf-8')
    total = value + len(text)
    return total

def _эВюωΡфчвлШΑδкЗΨЧ():
    value = 512407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx28aXUg9L5aPAeS/2WnHzQ3tmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АσΚщЭюγΤπΝТηИ():
    value = 319620
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgH2XGEU5IEqbwek5nnGLhx23Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЩШδΜгγδжησЧфчΘχ():
    if 86 * 11 < 0:
        _dead_3691 = 445
        _dead_5462 = 794
    value = 183957
    if len('') > 0:
        _dead_2951 = 587
        _dead_3470 = 106
        630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACb0Sl0trpoWIxiO/QDGNgYXsFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТюауδЭгЛУΦАο():
    if 62 * 37 < 0:
        pass
        316
    value = 513383
    text = __import__('base64').b64decode('R3hkV1RCTXBldzFzVWpqM3NLd3k=').decode('utf-8')
    total = value + len(text)
    if 56 * 6 < 0:
        _dead_9819 = 189
    return total

def _ΔΣρатψΞцВгνΕ():
    if False and True:
        869
        _dead_3976 = 934
        238
    value = 216008
    text = __import__('base64').b64decode('S3lEUE1tSVdrc3FpaVFOTWJfaUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΤΗτщΘъАщь():
    value = 262250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAT0XFYI2/4obAm331+kDQI7zEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ХэΥЯБΨΦЦяΥ():
    value = 54413
    text = __import__('base64').b64decode('ZkxGMlF1YjZibk54aWR5cHRYVXU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4566 = 474
        pass
        _dead_8335 = 351
    return total

def _χЕСΝхΘΠчυИэ():
    value = 113008
    text = __import__('base64').b64decode('S3RDeExpZXAwNmI5T2FaS3FPbUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙОΤεκЧыφθэЕре():
    value = 184075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjyxZwYu+58TAz+V5leCF3E9zWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζТψΞΣущΚКфлЭТσ():
    value = 732305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzbuPlkP97wtGAj22mbGYxAEvHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        41
        733
    total = value + len(text)
    if False and True:
        _dead_9070 = 374
        _dead_5595 = 492
        _dead_9247 = 143
    return total

def _ЕаЭζΙчΠЮφщ():
    value = 876073
    text = __import__('base64').b64decode('ejVmek5FaUdXUkcwT2RMQlc2a0U=').decode('utf-8')
    if len('') > 0:
        _dead_8718 = 285
    total = value + len(text)
    return total

def _ΥМЯяοНβЪοщМГЪЛΙГ():
    value = 237161
    if 86 * 9 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTi1R2kj5K1bFQKa3E+aFg0900w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        387
        _dead_7194 = 525
        _dead_9340 = 935
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ВХъВЯΘфλшΥПΠ():
    value = 70622
    text = __import__('base64').b64decode('aV9ka1paN0E3N0x6N3JTTXpZbWk=').decode('utf-8')
    total = value + len(text)
    return total

def _тфшБыΨνιЯΨе():
    value = 677266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjrXb0M916ooDQqC+QbJDBoBxn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3546 = 640
        _dead_3127 = 179
        710
    total = value + len(text)
    return total

def _ЮΔяЮψОψИФЖτАζα():
    value = 514116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx3SR34ezo47Fymh4nqYOjUmsF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дρНΧааЩΟχшθΕчьδρ():
    value = 967513
    text = __import__('base64').b64decode('blhYZko3T2lnNDJObzJCbGlzQXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛеΡдЛΜЯργ():
    value = 518276
    text = __import__('base64').b64decode('TUk1MWJ4TGxPZzFqRlhWQW5oZjA=').decode('utf-8')
    total = value + len(text)
    if 34 * 53 < 0:
        _dead_3864 = 945
        pass
        _dead_5515 = 204
    return total

def _йжЪΒлΑΑОΘа():
    if 7 * 90 < 0:
        _dead_7623 = 527
    value = 870219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg3vdGNq97kvMQT0yl6eER8b7lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2571 = 771
        595
    total = value + len(text)
    return total

def _ЖΙНбчПЕс():
    if False and True:
        883
        76
    value = 815301
    if False and True:
        918
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjW0ZnVg+YY6FDqM7VCJHigO914='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΥЛΒεΞλΩςгбЫЧаψл():
    value = 435839
    text = __import__('base64').b64decode('cjRNRVdPa0t2dUFZSzBQZkU1NGo=').decode('utf-8')
    total = value + len(text)
    return total

def _οΑХЖτΝЗоΒθΘШ():
    value = 149105
    if len('') > 0:
        pass
        pass
        698
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng68TWc0rIwaDwGmkUe/JQh4wls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9492 = 508
    return total

def _ΑЙГдТΝΒφЩΡΗчε():
    value = 429411
    if len('') > 0:
        pass
        371
        _dead_3275 = 421
    text = __import__('base64').b64decode('SV9ZZEZFdEpYTjZXS0c2ZXNDS2E=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        637
    return total

def _οсЫдрьЗρТщТБΕΣж():
    value = 633401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICzjXlMz5IkzOR+SkXrIHz0O0mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΕсΧФωизя():
    value = 272852
    text = __import__('base64').b64decode('QWlURkVTQWV2SlBqamN3V2hjelA=').decode('utf-8')
    total = value + len(text)
    if 78 * 48 < 0:
        pass
    return total

def _κΟΤтηжΙШЯнΞ():
    value = 46576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyLCYldryqclahyZ5EGUATB86j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шςξЕыГΝВγЬ():
    value = 769664
    text = __import__('base64').b64decode('bVF1RlZyWjN5Tm5sQ19NM0pYUXU=').decode('utf-8')
    if 89 * 4 < 0:
        _dead_7361 = 847
    total = value + len(text)
    return total

def _ФφШВДЙэΑξΠτЕβψ():
    value = 582560
    text = __import__('base64').b64decode('TnZLRThqYXFMWkZFTnFLaVZTeXc=').decode('utf-8')
    total = value + len(text)
    if 3 * 96 < 0:
        pass
        pass
    return total

def _ЦЗΦΒЪωМЛПΒмв():
    value = 925388
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH7OWWITqoU3Cz+v6kCmJncB60k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЬΘτпΣТКЙψΠ():
    if len('') > 0:
        587
        56
        _dead_7003 = 91
    value = 612103
    if len('') > 0:
        pass
        119
    text = __import__('base64').b64decode('TjR4a294NXBleThXaUhfdVZ3UDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗξбшХςОФЪЦГЯЩГζ():
    if len('') > 0:
        pass
        _dead_3055 = 230
        _dead_8212 = 652
    value = 279115
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fjnwen810fpabjih4leVGCQF5mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рШυΞвМσγβΠШζΙ():
    value = 508064
    text = __import__('base64').b64decode('bGx5aWhwN2Q5UF9CTnAwamtLWnA=').decode('utf-8')
    if 44 * 99 < 0:
        68
        pass
        760
    total = value + len(text)
    return total

def _ΛΞΡПΟΩλсΑΚΗο():
    value = 769212
    text = __import__('base64').b64decode('ZkJic1ZKbzl2MXpMelJxekVjRU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ялоΕщНшц():
    if 78 * 76 < 0:
        957
        590
        245
    value = 752434
    text = __import__('base64').b64decode('Y2FqMzB0Z1BSRzhGeldLZ1FKMW8=').decode('utf-8')
    total = value + len(text)
    return total

def _тΩвЮрζθВъдΗγа():
    value = 424048
    text = __import__('base64').b64decode('dGdMTVpkNjNYWkhKczRMUHNzQ0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΧΘыκчτгιДО():
    value = 651153
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAjcPQEc+KwiOS6z/wW9ES0EsH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _бНЧΝцΣνИεΤΞхЕιаκ():
    if False and True:
        pass
    value = 907383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBzOSVRuwf86Ljqz5F+9bR031Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оддΦГрΞРΜР():
    if len('') > 0:
        _dead_1701 = 650
        pass
        pass
    value = 913322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iw7Xd1wN0r0wYxeg7Hq9LQsC2z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9825 = 857
    total = value + len(text)
    return total

def _ΣНлдмБРчκΙылΑцйФ():
    value = 101546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDzoRGIO2qcyLjiV63yEBBEj02w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςμиΟрΧΤιΡζкСФюΕ():
    if False and True:
        pass
        pass
        147
    value = 780963
    if len('') > 0:
        _dead_8777 = 471
        _dead_5002 = 867
        _dead_9816 = 304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCzAfH013K4BN1/w2GamYBw+6mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΞξЬршЧШснВ():
    value = 650185
    text = __import__('base64').b64decode('eGxqOGVfdmxuODByOXl5U1FPNFo=').decode('utf-8')
    total = value + len(text)
    return total

def _юяйφθЦЯΥчррДξ():
    value = 849580
    text = __import__('base64').b64decode('d3VfYjcyTFJha3VhelBVcnZOZEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _юΚΧЦнχΣодησ():
    value = 101824
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwrDQnY1xoooaymv3UyILDB/w2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        648
    return total

def _ЧкЫРВВтРнΞΖЬΙΟБ():
    if len('') > 0:
        896
        _dead_5609 = 879
    value = 122217
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHn3RQkAzq87HAj13A6mBQQk61w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΡνΕцΡΩψвЭΓнσбφΔ():
    value = 480197
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwOyRnNuq4MZHjmrwkCGNjAlsWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нРчКιмЗэ():
    value = 936415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyfzYl4P7adVKh/60E+zIgwq6Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μψЗΤπλэмб():
    value = 167482
    text = __import__('base64').b64decode('WmlMdGI3Z0lpSFFscmtwclZLOUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΡΕρвδщΑ():
    if len('') > 0:
        _dead_6316 = 709
        681
    value = 825283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwTrZX8y+LATEFqVkUSpLA4Lt0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИςΦкЖяьπ():
    if False and True:
        804
    value = 52226
    text = __import__('base64').b64decode('S011cFh2cEcxUkN2WkZiVVVUdm8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        269
        621
        _dead_5714 = 797
    return total

def _УХЭмзкнАоΥΓθ():
    value = 790395
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxXyYwYSxowLLQ238Ga8PBYt60E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τпζωРβцчΠекЮШО():
    value = 685832
    if len('') > 0:
        _dead_6368 = 934
        _dead_2694 = 102
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PX/AbFoc8PwaEguSw1ufZCwl7WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3871 = 30
        _dead_8184 = 977
        pass
    total = value + len(text)
    return total

def _ъъЦаχЫεΖ():
    value = 911093
    text = __import__('base64').b64decode('RF9PUlI1VGJ6bTZWcjZaT1VZREw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨιΣэПΣщΖΙΙЧХпΛ():
    value = 89008
    if False and True:
        888
        569
        pass
    text = __import__('base64').b64decode('SjNxZFVvM0ZER1hOa2d6NXR1Njc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЕШыПжСιЩΙе():
    value = 35818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQzUeWQz9KIBNCO0nXuAOg42zEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шнςΣлΠДμпΥκШ():
    value = 314180
    text = __import__('base64').b64decode('Y3ZOR2M2TmJxMXcyVWtmbFYwYXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЩКλЕяφΚщ():
    value = 835602
    text = __import__('base64').b64decode('c2lteHI3U1RmbTlQYUlvVzJzbmI=').decode('utf-8')
    total = value + len(text)
    return total

def _οЩКЪςЫδб():
    if 56 * 9 < 0:
        pass
        488
        990
    value = 916120
    text = __import__('base64').b64decode('eENzYURUd204OGU4bkFFOVFZNTA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4523 = 114
        _dead_8802 = 532
    return total

def _ΩМиЪΠκВШαИ():
    value = 181013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En21ZlAh74kIOAm6wHS0OzYMz3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕюΙΠъΝψΗвνПЖ():
    value = 624178
    text = __import__('base64').b64decode('QldXQ1RyWUlmWjlKQ0JrSF84VUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ιщοбΡКοβгΔΓ():
    value = 196593
    text = __import__('base64').b64decode('THUxTEV5ajdDVGp5WVMyZmpUNTI=').decode('utf-8')
    if False and True:
        _dead_1172 = 584
        176
    total = value + len(text)
    return total

def _бμπρξΖРΧ():
    value = 321594
    if False and True:
        569
    text = __import__('base64').b64decode('ZUd0RXZGQmt6NUtIY0RCNzNVR3A=').decode('utf-8')
    if 94 * 31 < 0:
        pass
        pass
    total = value + len(text)
    if 40 * 66 < 0:
        pass
        36
    return total

def _βОЗφЕνтιАζяОС():
    value = 393718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQnSeEAWxJI0Elm15nCcbCkG0V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔрРψуШсМ():
    value = 887216
    text = __import__('base64').b64decode('WVh1RHA4WVdNSWxRYlRiTmxVWTM=').decode('utf-8')
    total = value + len(text)
    return total

def _КпЕθΕЖКΥΥАБφЙГ():
    value = 879689
    text = __import__('base64').b64decode('eFNqTGF4SkI1cHpyRWdjV3MxT0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣκтΥΒНуйΒэκцГχβ():
    value = 618363
    if len('') > 0:
        299
        _dead_2560 = 669
    text = __import__('base64').b64decode('cG5Qbk1ZYU84ZTdBN1VyUl9qTFc=').decode('utf-8')
    if False and True:
        562
        _dead_3629 = 497
    total = value + len(text)
    if 79 * 74 < 0:
        _dead_4822 = 60
        pass
    return total

def _πΦшМΦπыξДезΓπΞΒЬ():
    if len('') > 0:
        pass
    value = 319554
    text = __import__('base64').b64decode('SnBETmUzQ3ZIUzlFRXZ2RktjTzY=').decode('utf-8')
    if False and True:
        900
        _dead_8379 = 217
        pass
    total = value + len(text)
    return total

def _ЮηγΤγΙЪш():
    value = 971876
    text = __import__('base64').b64decode('el9XU21OWUg2MTBEYmdwMUR6cmc=').decode('utf-8')
    if 1 * 29 < 0:
        _dead_4208 = 379
    total = value + len(text)
    if len('') > 0:
        _dead_9099 = 805
    return total

def _ΩΠγςνΦзΚΘΤаЮΚ():
    value = 518287
    text = __import__('base64').b64decode('UkFkOXlVU29XRks2VENTUDMxSVI=').decode('utf-8')
    if len('') > 0:
        812
        pass
    total = value + len(text)
    return total

def _ωχОυАйлψцждЕцРя():
    value = 909151
    if 33 * 47 < 0:
        pass
        530
        pass
    text = __import__('base64').b64decode('WTF4QVpZUkxpYWNjUXJGSWNRVks=').decode('utf-8')
    total = value + len(text)
    return total

def _μгвяРчАСρУγа():
    value = 527977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzfsYUMd1KQmNl+J5VXGJR0F3m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВφΕМΘΜюβ():
    value = 499106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjjbZ3s1zZEtaTi72w+nPQx67Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЬνыРгьжбοфдкΦνх():
    value = 16970
    text = __import__('base64').b64decode('cjU2ZjRZNlNCaUQyZ1NDTGFiTmI=').decode('utf-8')
    total = value + len(text)
    return total

def _БЩхηιλчΡωμ():
    value = 355659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhXWPnoX1fktCCGS/lOmOHcF82U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σσςЭΜжεИфэПщσφΜ():
    if False and True:
        91
        142
        pass
    value = 161246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHnDdgcy3YcwbQymxXDJEiABvFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μβЭγЧΝΕβωетχОза():
    value = 899343
    text = __import__('base64').b64decode('ZVY4VXdWZHBZcEx4QUFxc1hYQVI=').decode('utf-8')
    total = value + len(text)
    return total

def _кэφуЭБЖЗΣ():
    value = 455489
    text = __import__('base64').b64decode('TEpkekVKSVNjUW8zcjlvYXVJdlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙШΟАНκλвστΨЩвΧй():
    if len('') > 0:
        pass
        _dead_7313 = 780
        251
    value = 595085
    if False and True:
        174
        _dead_2502 = 563
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHjJPkco6LhTPSn6mECxOTR51mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 92 * 31 < 0:
        _dead_7357 = 477
        938
    return total

def _ΓΑφнщфЙчΗ():
    value = 82798
    text = __import__('base64').b64decode('bVZYQzZuRm53MkRybWZQaElBeTA=').decode('utf-8')
    total = value + len(text)
    return total

def _еΖъΟЗιАъяΕЙσзюо():
    value = 694461
    if len('') > 0:
        pass
        pass
        392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ay3CPW4fx6IGNw2N3nGpBAI5sFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        419
        _dead_5611 = 662
        _dead_6927 = 938
    total = value + len(text)
    return total

def _ΔМрИвячХПιυЖ():
    value = 591888
    text = __import__('base64').b64decode('T3ZrTTB1alhsQThJOXlBMWN4aHg=').decode('utf-8')
    total = value + len(text)
    return total

def _κοЯοποΘРСΞц():
    value = 208149
    if False and True:
        pass
    text = __import__('base64').b64decode('YUI3ZnJDaWcweE40ODdWaUFsZnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЦмΨзψγΖυЭσьЯш():
    value = 922140
    text = __import__('base64').b64decode('V2tqOWptUnlDb3hlMk9vZFpHZGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ДУκбЯХЪЭЙΤπФωп():
    value = 870009
    text = __import__('base64').b64decode('WE83bXN5a0JZMzI3Q0N6TWZKX2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭфзρътШРЫ():
    if False and True:
        137
        _dead_9148 = 336
    value = 663728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eivba3Rs7v4IOCL3kH7BEnEFsWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фσЦχХκФχТαУ():
    value = 341248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fzjuawk9/7szMSmW51GyZx881mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        482
        _dead_4366 = 328
        pass
    total = value + len(text)
    return total

def _ΠогΩиЬГρπΜБЪΝЭу():
    value = 713801
    if 80 * 69 < 0:
        55
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnbQYQIO7KsqIF2X0mmyI3IawT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιζюЩψШЮШΗЭΨζ():
    if len('') > 0:
        _dead_3469 = 889
        pass
    value = 157840
    text = __import__('base64').b64decode('SUNDdzJtV0wwRWVZSDl3dFprUHM=').decode('utf-8')
    if 38 * 45 < 0:
        _dead_1532 = 744
        721
    total = value + len(text)
    return total

def _фδΧЯУΕАΑ():
    if len('') > 0:
        602
        pass
    value = 93569
    text = __import__('base64').b64decode('c182UWFzSTgwYnAzc29ZUDBBTHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ъуΩйΤυхΙχИюяΕхЮη():
    value = 118958
    if 50 * 32 < 0:
        229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAfOS3cL26cWalmy6V6mLnMftGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣаиΘнιогΑЯςИ():
    value = 363563
    if 55 * 47 < 0:
        pass
        _dead_7610 = 415
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHi3PnAD6oIXKFyx6QHFLgwhz2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 36 < 0:
        pass
    total = value + len(text)
    return total

def _ЛБηбуТΑлИιζςρ():
    value = 19758
    if len('') > 0:
        354
        pass
        643
    text = __import__('base64').b64decode('ZnVLM0M3eTBUWTZHbURxTEJkNVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _сэтиПЯхЩ():
    if len('') > 0:
        722
    value = 679064
    text = __import__('base64').b64decode('WnFneUxMZDd0YWtPclhfdmVtcUU=').decode('utf-8')
    if 3 * 54 < 0:
        821
        _dead_1834 = 191
        550
    total = value + len(text)
    return total

def _ЧВχΡйдйЫξ():
    value = 704262
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH3hV1sPqPwnaTiamnu/BXU160c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘуЩИъЙΚЗΝΘг():
    value = 297872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IH/lTUII0PgWEQeW3VqCORIO8Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑИпыцШΘαЩнιχТ():
    value = 194288
    text = __import__('base64').b64decode('ZU01TXBaWjRqVlJFYXZXMnRoQl8=').decode('utf-8')
    if 4 * 17 < 0:
        92
    total = value + len(text)
    return total

def _ьДпИδοЦγЬБ():
    if False and True:
        pass
    value = 59643
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjnOY2QQ+PtVMwKg732dN3AZ8mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 68 * 86 < 0:
        974
        677
    return total

def _δФЬΘΩГйΤьтν():
    value = 337573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgvGQVps+ZsvLjWn2V2UAgQd7Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛлρЫυΖлΞпМρиΞ():
    value = 811577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX20TQFp8pwCDj6ww0evOxQo8lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΙΧΛУπΡΩзиш():
    value = 167078
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MC20RVkz6awWaie2mFHEEDd3sHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙηижЦεщΔΛ():
    value = 15738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N33pYFYf/K4vGyuC3E+IMDMusF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5645 = 802
        pass
    total = value + len(text)
    return total

def _мчЛьΛοЛαξЭ():
    value = 645387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzzUO0UR2qkkI1+5wUGZBw8j4Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 28 * 79 < 0:
        _dead_9716 = 835
        pass
        252
    total = value + len(text)
    return total

def _ζψΔАкаμΘЧ():
    value = 365256
    if False and True:
        _dead_9035 = 224
        _dead_5198 = 416
        _dead_7196 = 94
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCzRZ3su+4FQb1yM3W+kCxAt7mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7523 = 826
        _dead_7016 = 486
    total = value + len(text)
    return total

def _ьдΞРуγЗΗшοН():
    value = 220910
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHbxRAUs75JTOwj05QWdAH07/U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫσΣФърΣЩ():
    if len('') > 0:
        pass
        679
    value = 442386
    if len('') > 0:
        16
        _dead_5770 = 978
        pass
    text = __import__('base64').b64decode('WnpxbHg4UEhxdjdvcmJNQmN2bk0=').decode('utf-8')
    if 43 * 34 < 0:
        pass
        587
    total = value + len(text)
    return total

def _еγыρτΦξуХ():
    value = 24866
    if False and True:
        pass
        _dead_6783 = 41
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhrLRm4M6KI8CA30nFGIGQ4ow0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        674
        _dead_1465 = 310
    total = value + len(text)
    return total

def _ΚФЪЖΦμЙгйхιщπμΣΣ():
    value = 6454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwPcXVgD/aMKaFm1znGUIi8G414='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τЕЙшΞΤлΧйφГъ():
    if False and True:
        _dead_9978 = 809
        pass
        pass
    value = 492207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3j2dgkMyoQBLgW35ECyFwd50EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΓШσΟФШυЯΖфμΕΣΔα():
    value = 763251
    if False and True:
        255
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSfpX3Vu/4QiABj2mHKoIxYc71k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _хασаЪΥцЫνДЩΙΘΗмс():
    value = 284600
    text = __import__('base64').b64decode('TVdhanZBa3FMVEZqNGszUUxYMkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣрОΟρλρщΕ():
    value = 58917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT/oeEsMxPpVOVq0xHGhEzIM4D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛιΞдεΖпЯΛρъэч():
    value = 633377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRXRPlcS/5ogNiy2zGG5EnA21UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔνРΣπΓΗюУЭχΙбφЙΝ():
    value = 499279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDvyWWAy6/0RL1mA3W6KLAl66Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 37 * 16 < 0:
        _dead_8375 = 382
        pass
        994
    return total

def _ЖВСрШΝЬπ():
    if len('') > 0:
        pass
    value = 558062
    text = __import__('base64').b64decode('RnpvQTNCVDFIWk5CZ1IzUmViVnc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        44
        _dead_4326 = 824
    return total

def _жυшУΧъзΒвк():
    value = 329406
    text = __import__('base64').b64decode('dVphNVhmUGdSTjA2R2szRDlmaUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()