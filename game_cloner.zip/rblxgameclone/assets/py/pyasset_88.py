#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ХΟпбЛБЗηεпξТεр():
    if False and True:
        _dead_8572 = 873
        334
    value = 365566
    if 59 * 66 < 0:
        155
        _dead_8084 = 536
    text = __import__('base64').b64decode('ZGlQVEFjOVl5aGt6S05BUllxYmo=').decode('utf-8')
    if len('') > 0:
        _dead_5727 = 227
        _dead_3333 = 659
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_8882 = 952
        _dead_3659 = 653
    return total

def _БГхБъΤРγаλσлΧД():
    value = 394674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgK3PUMw+4AbDgby5XGnYi886Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧжΕтъВтЧЮ():
    if False and True:
        _dead_9453 = 368
        905
    value = 838977
    text = __import__('base64').b64decode('YkdhUGhpT1ZlNVZhYmU3YlQ4aXc=').decode('utf-8')
    total = value + len(text)
    if 25 * 12 < 0:
        pass
    return total

def _ЙАЦКΥБΝбΟυξОНΕ():
    value = 773942
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhnVeHcvrKMiOAuP0kSBECg78T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЕκταΓΩΥЩγΙчНΧЧК():
    if 45 * 18 < 0:
        pass
        pass
        _dead_6039 = 108
    value = 178477
    if False and True:
        pass
        880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSn2Rlhv/Z9SNAmI8E7HATF8sUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΥαъΔБξЯЪГνΒФрэ():
    value = 358662
    text = __import__('base64').b64decode('bGd4dm1hdms0dVZJY0hFZ2RCTVA=').decode('utf-8')
    total = value + len(text)
    return total

def _рхГΑаЗцΗδжЩэΜΗхΕ():
    if 56 * 99 < 0:
        282
    value = 973134
    text = __import__('base64').b64decode('V2NtaFI4TDJTRWZSNVBKNVBkcmo=').decode('utf-8')
    total = value + len(text)
    return total

def _суΙаыШЬоΔжГ():
    value = 561546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HX3pemgW3JgBKgqQwkyAFzwMwn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФИγъΓΜγΖЖ():
    if False and True:
        827
    value = 531514
    if 51 * 26 < 0:
        _dead_3412 = 217
        _dead_7416 = 547
    text = __import__('base64').b64decode('TjlJUVFVVlJDTHU1cFZENUhFT2o=').decode('utf-8')
    total = value + len(text)
    return total

def _δАИΦЧαеИйЫх():
    value = 214019
    if 78 * 23 < 0:
        _dead_3024 = 798
        67
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQPFeGUx3ZgFGQm1xQ+SIwx2yD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 12 < 0:
        _dead_3639 = 613
        _dead_2489 = 164
    total = value + len(text)
    return total

def _ΩΔЪΥΠдПтφбиδΧЬ():
    if False and True:
        159
        _dead_4987 = 118
    value = 595815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCroYWI17YlUFx2L0H6IOykM92s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _μμΩдяЖΛДΣвДВЪвй():
    value = 824218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT/0fGAh+K02NgW5+ACDGDF69jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΔБкЭιμуаμЫДЗ():
    if 60 * 53 < 0:
        pass
    value = 990415
    if len('') > 0:
        pass
        _dead_6614 = 715
    text = __import__('base64').b64decode('QmxHaFMwOWhvSlR3M0NGd0F3UGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ρтτμФдтΗ():
    value = 906024
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyvdfgYXwZg5Kzy5/FGdIDcj4jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оьξБЖпЪαЫΞΠ():
    value = 94185
    text = __import__('base64').b64decode('U3RRNDBTZ3BhUVJZcmpJMlpTVVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΝχЕЛΖюγАΣг():
    value = 644761
    text = __import__('base64').b64decode('elk1NDhUd0t5Vl9Ca1ZaVFZSbVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥчвΑΗΥлШπτЮвζпГτ():
    value = 975647
    text = __import__('base64').b64decode('QXJRdDM3NlNDTVV4bTFxWFM4T28=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΚοзэРЪφшФяр():
    value = 586595
    text = __import__('base64').b64decode('TFJTR25UTmJBUGo2NjVtYkdlcGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ГАΘУεΘΠзυНЗуΞΡЮ():
    value = 36652
    if False and True:
        590
    text = __import__('base64').b64decode('dnlFb2V3eG1iNU1QSHRqOHJyNTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟкъζСΑΝэΟпжθιγ():
    value = 338221
    if len('') > 0:
        _dead_6524 = 702
        702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P33VRlIR+PtbbTaunEyUYHwL4UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1287 = 206
        _dead_3326 = 626
        188
    total = value + len(text)
    return total

def _ΜГюЕХΠιΥлθЛоРП():
    value = 646307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxfJR15g3I8nMAKKnQKEYyoDxjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΤАκхЫфмЮНμμКΒφχ():
    value = 481295
    if False and True:
        pass
        170
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQrseWsr2qxUaD2E4wS0JC0g50E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        53
    total = value + len(text)
    if len('') > 0:
        575
        _dead_5353 = 910
        pass
    return total

def _ТНνШэьдЬψЖχхэ():
    value = 679794
    text = __import__('base64').b64decode('VmR3dmlaRWxUV1EycFd0MEpaWkg=').decode('utf-8')
    total = value + len(text)
    return total

def _УτаΚЖοЦΕяχФ():
    value = 857526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDa1a18XwZ8lPCOZ7kOCYHI3t1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уГλΤчшЙКЕкςВΥΡ():
    if len('') > 0:
        811
        371
        pass
    value = 456974
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiHWQVo96fkWLiub5VSKDHN8yF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _СщΨιΔаΥлЩψЖδ():
    value = 214285
    text = __import__('base64').b64decode('bFk1SHhEdkRISzc5RUpPbG15b3k=').decode('utf-8')
    if 56 * 41 < 0:
        _dead_9207 = 598
        pass
    total = value + len(text)
    if 8 * 62 < 0:
        844
        _dead_3062 = 185
    return total

def _мКЯмЮчΩηδжй():
    value = 124582
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiPGY3896vkoPxiN0QC0EAIV8T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДиаЩΒььΣΨЛшξГьф():
    if 15 * 40 < 0:
        _dead_4288 = 223
        16
    value = 173950
    text = __import__('base64').b64decode('bXgxTGlBc0NoYVViNVYwcmNCTEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚйσшЯψΧωσΟσБ():
    value = 770287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQzuUVcX34UJLR6b7lLJJx8t1T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΚШфψйялаΧν():
    value = 401424
    text = __import__('base64').b64decode('djJhOWx6X3hNd0lqN3VZM1NPUkE=').decode('utf-8')
    total = value + len(text)
    return total

def _зΛΜΠΙΧΙТРЪςЕ():
    value = 386359
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQnpSwUc5oEIDwDz0gSCYhR2sHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜлзЪШΧйС():
    value = 600507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxrVV24MraENblrxkXeGGDUq0n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чЭзζΣйЬΜξжзшцСЭο():
    value = 688374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXy1b1Y21ZggDV+gnUe0YA0D/T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЗΣΑφЛΖυЯΒτКζΚчξ():
    value = 692693
    if False and True:
        pass
    text = __import__('base64').b64decode('UlVnT0JIdV82eEtJdE5fajhsSXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _эьФьГЗΟрВбдАК():
    value = 453084
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fxrnb2I02ZkXL1v32lG5DgIX70E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨэЯШхйΨСЮЦДйτиь():
    value = 938996
    text = __import__('base64').b64decode('endUejNKX054SWRLZWd6TDE4VTg=').decode('utf-8')
    total = value + len(text)
    return total

def _юУΕпΒΖФΖ():
    value = 394033
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjrcfWcqxIlWKx2Wm1ucEjAj8mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛбμИλРΥΥλйρ():
    value = 533082
    text = __import__('base64').b64decode('clpjQnVFMzJvUjBJZUNLcEpRTmw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        273
        _dead_4851 = 328
        pass
    return total

def _ъπΥιπΞВΗфΞМшΩφ():
    if len('') > 0:
        886
    value = 325314
    text = __import__('base64').b64decode('cGR1TkttRXJvRDdMYmw1OUpEdGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤβЪБλΤψмΦб():
    value = 523686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXr8XVkfzI8bKAKp8AGiMzUixng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вСаΛбчΜσшΗΑдЦр():
    value = 342604
    text = __import__('base64').b64decode('TmdiN3VMbWhWNWFia0tPdkNnc00=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙШβоφΠотηн():
    if len('') > 0:
        pass
    value = 833254
    text = __import__('base64').b64decode('Wk45UVhaOXZaNjVTeXRPcW4ycXk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ажψθфРЭΣКДαМρ():
    if len('') > 0:
        _dead_1041 = 247
        pass
    value = 972092
    if 48 * 26 < 0:
        pass
        332
        _dead_7441 = 896
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXfdWnk1wfALEFimxU7IDR8n53Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кЕштВΥμФТ():
    value = 172154
    text = __import__('base64').b64decode('bTQwaENxZTVxWVNLT2x0bWNlb24=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧхяπЖяНЩт():
    value = 657232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSTTT3Ax+JkRKluv5FLAFQt44mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τРΨхОυФЦЕδςΘЪ():
    value = 695061
    if 97 * 5 < 0:
        pass
        346
        _dead_9931 = 940
    text = __import__('base64').b64decode('TW03ZWV5X1poTVhjbU5yeEhUV0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЖбыδФΤЙРСжЩЭЯΧ():
    if len('') > 0:
        pass
    value = 836249
    text = __import__('base64').b64decode('bTUwSWc4QWVPcVhRZ1NhYkdUa3k=').decode('utf-8')
    total = value + len(text)
    return total

def _фпЯσЭμΖΖоτЗуп():
    if False and True:
        844
        18
    value = 150981
    text = __import__('base64').b64decode('QW1TUkQ0U21kRlhab0hIMnlnTk0=').decode('utf-8')
    total = value + len(text)
    return total

def _щλΧΤМЗПΘЖдиш():
    value = 541907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAz0fUcfqfAXKwf62luoAS0V9E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΜεКΩХБλпοбИщПΗε():
    value = 571615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bwfudggyq6YJABiXnmCyMHUd8mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЖΥмшнЫАыЬцяК():
    value = 262996
    if len('') > 0:
        661
        212
        _dead_4199 = 554
    text = __import__('base64').b64decode('QUhVZUhWcEp4TV9xWENvV25tZEM=').decode('utf-8')
    if 39 * 14 < 0:
        109
        _dead_1171 = 393
    total = value + len(text)
    return total

def _βΜХЫЩΔυъНΗВ():
    value = 445860
    if False and True:
        219
        pass
    text = __import__('base64').b64decode('bld6VFlJalF0Q1JhbFJ4WEg1Y0M=').decode('utf-8')
    total = value + len(text)
    return total

def _фЧθψИНЭЪхΨςиГаδΝ():
    value = 766235
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCrcO10q5oIaMgyH5UaKOhwnwUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψσэхΡЩДКьгаЗοЩК():
    if len('') > 0:
        pass
        pass
    value = 496088
    if 30 * 75 < 0:
        486
        pass
        _dead_6713 = 577
    text = __import__('base64').b64decode('YjF2dDFoRE5JVURDNjZXNmJSa2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΥяπдТΩΛГХЬ():
    value = 443016
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDy2Qnoo64MZICaB/0avFQcW6mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УяμаъЭЖН():
    value = 22707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kj/9QAEArfoCIjms90G6YT8L4D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭПХЮьЛΦЦ():
    value = 948757
    text = __import__('base64').b64decode('emp3ZGRvX2VRR1dvQzBFbUd3ZVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _вЩΟΖЪΨФΘбщя():
    value = 417321
    text = __import__('base64').b64decode('aXA4cVpTX0tibDA2X3IwVkxSNlM=').decode('utf-8')
    total = value + len(text)
    return total

def _εχМιКтДЭΜ():
    value = 569385
    text = __import__('base64').b64decode('bjh6QnNiQ2hMWTFxdm1PS1ozOXg=').decode('utf-8')
    if 24 * 90 < 0:
        pass
        73
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4248 = 150
    return total

def _ЪΤвчтуτЭΦаπ():
    value = 79704
    text = __import__('base64').b64decode('TFdBNVNhZkZMNDJ3WGR6RmVIWlk=').decode('utf-8')
    total = value + len(text)
    if 72 * 91 < 0:
        _dead_6834 = 803
        pass
    return total

def _аθЩЛсЫчНψф():
    value = 385974
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgrQTHM11ZgGaD+K2gWfHCwbwWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7007 = 350
        252
        135
    return total

def _ГдЦьЕιθηфи():
    if False and True:
        pass
        _dead_5519 = 379
        pass
    value = 662201
    text = __import__('base64').b64decode('aEhuNWl1eW5HbGt0UVlUU0ZOR1M=').decode('utf-8')
    if len('') > 0:
        394
        pass
    total = value + len(text)
    return total

def _дкэТоσБΜвΖρ():
    value = 924412
    text = __import__('base64').b64decode('RHFEUHpVc0duMkVHblNIdTVSUmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _шθΛφΠУηсерЬ():
    if False and True:
        833
        _dead_6408 = 687
        pass
    value = 483248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwyzN1g4xpkgawahzF24Yyo7/UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρкоСΓΟзЖ():
    value = 436926
    text = __import__('base64').b64decode('R2hfVk9ROE5adlBMZUxfOVYyMlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ТеπултΝКγΧΜφВп():
    if len('') > 0:
        pass
        pass
    value = 991948
    text = __import__('base64').b64decode('Y191RUNpcmxRbzlLR294ckxqXzg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9486 = 430
        _dead_6051 = 670
    return total

def _φжΜЬΒпЭοКψπьМшУ():
    value = 613093
    text = __import__('base64').b64decode('VThpUUx4bWUwTFlnVW9xbWhwTWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ζСγωΑΞΓИχжяαЯΦДЮ():
    if 85 * 87 < 0:
        pass
        pass
    value = 878775
    text = __import__('base64').b64decode('TnRWOUs4OHlONnI3bTRRRTlCTm8=').decode('utf-8')
    if len('') > 0:
        92
        302
        pass
    total = value + len(text)
    return total

def _АБХμΟфЦΖЖдΕ():
    value = 811978
    if len('') > 0:
        pass
        182
        pass
    text = __import__('base64').b64decode('ck0wUFlrdVU4aGh5Z0JRdzdLUVo=').decode('utf-8')
    if len('') > 0:
        535
    total = value + len(text)
    return total

def _ьЪЕςΚδжΙэεΩбЗ():
    if 58 * 66 < 0:
        _dead_3844 = 317
        pass
        pass
    value = 427196
    if len('') > 0:
        pass
        355
    text = __import__('base64').b64decode('eDk2dkdHNTU5WXY5aFpYS1BsZlA=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _мΕΥдЗΕыιе():
    value = 702055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwHMdHAx0r0iawv7y0DHGQYfyWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 21 * 68 < 0:
        629
        368
        _dead_9592 = 926
    total = value + len(text)
    if len('') > 0:
        _dead_7612 = 841
        415
        _dead_8459 = 779
    return total

def _μИЪζωбΥΔЧеъЪωШг():
    if len('') > 0:
        _dead_4520 = 932
        pass
        _dead_6768 = 308
    value = 874004
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATfzZHhqqoMQMhmJwFmIIy4M6XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2029 = 627
        pass
    total = value + len(text)
    return total

def _СЭДлчНΜχЛηдглυзΣ():
    value = 109578
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRjSXGUJyotTFTi3mnKUJhF+910='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΤμμΝеуΜЗΤφΑνАΤ():
    value = 602716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz6zZmsO95IvIFuImG+RDHYV0mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪευпΟМэлΤВчтЯΜΩ():
    value = 42263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTqwZmg16JgmYlmm2UHJbAx+wEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нбЯЙЗВΙРВЫЦСМ():
    value = 444630
    text = __import__('base64').b64decode('STFPMGYyRE1Qemo4WVdTVk9lVmI=').decode('utf-8')
    total = value + len(text)
    return total

def _θмδΒЙсюцЦΚιξγ():
    value = 657612
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDX2ZFA635BTPDCL4gOhYgMf6k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7046 = 655
    return total

def _ΖЛΓБξБЫдπКнБЮο():
    value = 419422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzvleWA1+fAOFV+ox1qcGg0gzH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 10 < 0:
        45
        _dead_5132 = 196
    total = value + len(text)
    return total

def _КьβлτфТβью():
    value = 561287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JADtWGEj5qUtbDagkXKebQ4l9js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΔρΟлΨμЯтРνΕФц():
    value = 144872
    if len('') > 0:
        329
        825
        588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izy1RgYD2Z46GSuc0W6qPwIYxkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΟЭЖΩаЪπЬ():
    value = 240298
    text = __import__('base64').b64decode('QXk1V3lRN1NuZFc0eE40TmVRNkc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8451 = 931
        _dead_8865 = 3
    return total

def _κχψυΥπθТδχб():
    value = 690168
    if 19 * 54 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MA7ofnUQ8qoHO1+Cy1qxESYa/FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        686
    total = value + len(text)
    if False and True:
        423
        pass
    return total

def _псЫМйσюεФΑшοПс():
    value = 691379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ay3iT2Ap1pcGPCyUn3ylGid+tUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЮрΛΡНζТЭ():
    value = 823727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSi0N1w30Jg2DiyGmQHCCww943Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗаΥΑЬαрдΤМяЭΡГ():
    value = 471941
    if 86 * 79 < 0:
        _dead_1523 = 376
        _dead_5509 = 355
        526
    text = __import__('base64').b64decode('cHhQVHIzZzdPc3g4aUNVa0Nla0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _νΓΖωчмκτхДЖ():
    if len('') > 0:
        _dead_8116 = 951
        619
        pass
    value = 61887
    text = __import__('base64').b64decode('TkpkZ2tOOE40YXc0VF9XM24xM2w=').decode('utf-8')
    if len('') > 0:
        _dead_8397 = 821
    total = value + len(text)
    if False and True:
        958
        483
    return total

def _λъбЬрЖбфаηΦ():
    value = 201735
    text = __import__('base64').b64decode('dzgydmpQU3plTE1DcTN1ZkxxTE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦιйПСвΑсЪΤ():
    value = 541270
    text = __import__('base64').b64decode('RlRWWEJLVDRfbmJVY2JLaG1mWVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ОМμΚГηζЪЩτе():
    value = 231248
    text = __import__('base64').b64decode('TGJRbG1WT1JmVlNFdzBhWURBRnU=').decode('utf-8')
    total = value + len(text)
    return total

def _еШЛЮЙЕΖсъΔΓ():
    if 96 * 92 < 0:
        40
    value = 43762
    text = __import__('base64').b64decode('Q3dpb2RvQTkxU1BFcjhWdGg2X0M=').decode('utf-8')
    if False and True:
        783
        612
        499
    total = value + len(text)
    return total

def _τЬιОΣвΠο():
    value = 574305
    text = __import__('base64').b64decode('RGIwVFE0c2ZIZVdQc0E1X1FZQkM=').decode('utf-8')
    total = value + len(text)
    return total

def _еΒЦСмΓчε():
    value = 732578
    if False and True:
        598
        565
    text = __import__('base64').b64decode('WFg1aGk2OTVzUXk0cUkwYjlTbk4=').decode('utf-8')
    if False and True:
        pass
        pass
        513
    total = value + len(text)
    return total

def _мΖЧСтιАιМЫυΒ():
    if False and True:
        _dead_9181 = 384
        182
        pass
    value = 719986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwXBRlZvybsHKiCmxXG5GHUZ12k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 4 * 92 < 0:
        pass
        140
        673
    return total

def _ΤωбнонФрΔАЕубЙ():
    if 4 * 57 < 0:
        _dead_6339 = 646
        807
        340
    value = 763353
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('WjVQanBjX25aZTdhSUFJV0ZwYVU=').decode('utf-8')
    total = value + len(text)
    return total

def _дτллтΞεттЩЩМЙяу():
    value = 170490
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('cDFBaDY0NHFWaER5Z2lsZkZPc0o=').decode('utf-8')
    if False and True:
        920
    total = value + len(text)
    if 92 * 78 < 0:
        818
    return total

def _аиФлиδΝЛЬε():
    value = 50400
    text = __import__('base64').b64decode('VnZkTGl5RGFQT0pYa1dQT2ZqUVU=').decode('utf-8')
    total = value + len(text)
    return total

def _фΟщъЗγВχΑ():
    value = 477702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LADseWcY27gCLTCZ0k62YnAi0zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 82 * 57 < 0:
        pass
    total = value + len(text)
    return total

def _τНсγтχοςфюг():
    value = 117935
    if 28 * 85 < 0:
        pass
        _dead_1097 = 251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDXhemZsqJ8SCg775HrGGwYo7H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХЩΞΘСЦωЭЩЪΕгΒК():
    value = 501199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT7gRmIJxvAzFDav5QG0AHY1vWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΔπβЯЕΞдюχΩΤЯ():
    value = 201689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA7sNm43qIdWHFnx/AS/YQwCtlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЪΘзЖаюуΒъуΔψБщο():
    value = 366142
    if False and True:
        986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBvJSnIe2K8zDzqMzXO3ODcn1X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΥΛΗЮъДНс():
    value = 647219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgXuYkkp26sTPgqkznyZI31+sWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        306
        295
    return total

def _чΘНΔοЬνМТσэυ():
    value = 545218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji3zSHoI7LAsawK5wnCUbC8Es28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПГρΧρМαбтζΟΜζОП():
    value = 692769
    if len('') > 0:
        722
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnjjRWsTqqc6OSu13QCvJBAewDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τятβЖΟλΣГЩц():
    value = 661827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kz3OS2cvzLstAwP0+GTJGjwsxjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΔΒхГеатΞφζрПВρЯ():
    value = 558901
    text = __import__('base64').b64decode('SkFSYlY1ZG4xMURsN2tJV2l1dEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮρМΧоΩыΦюΖъУчωπ():
    value = 776970
    text = __import__('base64').b64decode('VVdnUHFUZThsd19TNHk1RUFPUUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ρиμжкυπΩ():
    value = 908571
    text = __import__('base64').b64decode('c3V5cGhRc3J5elBybUx4ZFp2am0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΖρСιДрΞΜТйЬ():
    value = 93919
    text = __import__('base64').b64decode('U2Q4dnFxZzhudnpJRVJtSU92QXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤНψшηΒИΑПеЖζπ():
    if 20 * 81 < 0:
        _dead_6419 = 67
        642
    value = 746289
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXjCOFtqwZcWYxX692C9LQ8j6Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        305
        159
    total = value + len(text)
    return total

def _αΛючрΑлχ():
    if len('') > 0:
        _dead_6293 = 354
    value = 130683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgjjeFAS+qQlFDWG4Wa0ZRUB000='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 63 < 0:
        740
    total = value + len(text)
    if len('') > 0:
        409
        473
    return total

def _сΖΔςοфРъγΤМ():
    if len('') > 0:
        119
    value = 178796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B37wZFtt8YYgHQHx7G+0GR8KyT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пююЛгνγръШГ():
    value = 908636
    text = __import__('base64').b64decode('ZHFqOEQ3bjJwYkNoeFdRNlVxb0k=').decode('utf-8')
    total = value + len(text)
    return total

def _дμΦΓΔХНдπυλΗμЪ():
    value = 335739
    text = __import__('base64').b64decode('TE45OWpRUF9rcEVlMjdrdE9TUXk=').decode('utf-8')
    total = value + len(text)
    return total

def _лυзЩΟΡГγ():
    value = 363557
    if False and True:
        482
    text = __import__('base64').b64decode('ck14ZVpOS19GbFl5dzB2ajk3ZWQ=').decode('utf-8')
    if False and True:
        _dead_5288 = 241
        pass
    total = value + len(text)
    if False and True:
        335
    return total

def _ъΑΣσЯиυзИБΧФУгθΚ():
    if len('') > 0:
        pass
        _dead_6660 = 156
    value = 401074
    if False and True:
        _dead_5487 = 1000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBDFPVMd0rIAHQ6Xy2abPQc71Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 65 * 21 < 0:
        pass
        340
        pass
    return total

def _лгюΕλЦуВИρыОЬοΞβ():
    if False and True:
        _dead_1207 = 761
        _dead_7222 = 932
        609
    value = 541962
    text = __import__('base64').b64decode('dHBfQU1QQl92THMzWl9MRkFnZ2Q=').decode('utf-8')
    if False and True:
        pass
        _dead_8644 = 612
        73
    total = value + len(text)
    return total

def _юΖτηМφняЮ():
    value = 189214
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgXuOmUSz/gsLDeqz0+jECgKt2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВеШрΗжсΛ():
    value = 425724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3fxaVUzxIoaGyuo+XSdBjJ2t1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒэтеКаΤμюΙбςΕβ():
    value = 582304
    text = __import__('base64').b64decode('eHA2UE0zbmF5SWFFRExXajZGZzE=').decode('utf-8')
    total = value + len(text)
    return total

def _νННσΡйвОЮσ():
    value = 599734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxbbYnJv7I4JFCmq4nqaCxMttEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΡАЙυΟСуΗΓВаЙЕφ():
    value = 104661
    text = __import__('base64').b64decode('dUw3RGVNM0ZZaVlzOVZHd0ZfZmk=').decode('utf-8')
    total = value + len(text)
    return total

def _хеΤΠΠιςуУЗβдНя():
    if len('') > 0:
        pass
        955
    value = 233498
    if 96 * 22 < 0:
        _dead_7722 = 681
        pass
        681
    text = __import__('base64').b64decode('am9SYXZYWnVqdmk5NDFmSFhWQ0E=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _КφХэшσΠαζςπшΟΔ():
    if False and True:
        _dead_9588 = 144
        pass
        pass
    value = 543533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB38QFUo069VaT+wwXWjJyorz0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        873
        370
    return total

def _ХчΤηдδцΞЗτуЪ():
    value = 568408
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxj+OnVvqJsXPj6k0gTBIjwO8X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 55 < 0:
        _dead_6304 = 217
        _dead_5225 = 133
        _dead_1040 = 953
    return total

def _чΞΔЖτлЗЧτщωΝ():
    value = 898146
    text = __import__('base64').b64decode('RjRRQWJvMncyY0F6UXlWcEJSZW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧυχΜσЖеψΠμΦБΥгιΓ():
    if 92 * 81 < 0:
        pass
        pass
    value = 604252
    text = __import__('base64').b64decode('SGpSZlNuUmNwNllJNDR4SXUwbHk=').decode('utf-8')
    total = value + len(text)
    if 30 * 42 < 0:
        911
        _dead_8959 = 594
        _dead_4242 = 99
    return total

def _ЩлЙСЧδЮЧЙΙ():
    value = 254637
    if False and True:
        _dead_9884 = 625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARjCemgu2IQ2Axan5U6DMjJ8y1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 87 < 0:
        pass
        _dead_8180 = 324
        430
    total = value + len(text)
    return total

def _ΠκВΛτЩμзОκйγ():
    if False and True:
        _dead_8000 = 225
        573
        _dead_8684 = 494
    value = 549065
    if 72 * 92 < 0:
        _dead_2619 = 777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzXwTXUw2LkqMj+Ow0XAPik2514='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щаХдвφъО():
    value = 497379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHzVY34w2JEzIxqB/lCVYzAI/Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨЩХпвΩωΞЭΞоνь():
    value = 671599
    text = __import__('base64').b64decode('UWJoS1V1SHZ6bE1GWURBOURCU1I=').decode('utf-8')
    if 55 * 49 < 0:
        _dead_4102 = 717
        _dead_5516 = 894
    total = value + len(text)
    return total

def _οΓΙςЙфИЯ():
    value = 953482
    text = __import__('base64').b64decode('ekliNEhEWFR4WjFYRnE3NXc2RG0=').decode('utf-8')
    if 92 * 28 < 0:
        _dead_3437 = 212
        _dead_9788 = 387
    total = value + len(text)
    if 60 * 28 < 0:
        663
        pass
        198
    return total

def _ΖγРδρЮΒΧьΧЛшΑΘд():
    if False and True:
        pass
    value = 412488
    text = __import__('base64').b64decode('WlVnWXlJQlZMeWJEaEF4aUNQalU=').decode('utf-8')
    total = value + len(text)
    if 53 * 68 < 0:
        737
        _dead_2176 = 79
        729
    return total

def _лЪьиΜσглфΧАЙ():
    value = 665734
    if False and True:
        pass
        _dead_4177 = 762
    text = __import__('base64').b64decode('clZvdzhUQ2l4TVFrbW9SZEJ3TWc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        105
    return total

def _γΜΗΔξиддЯ():
    value = 824855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDnOaGA6248ZA1+n73+FEhEOsGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΗВэОγΥςЯγуЦΠЪΧ():
    value = 341541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERzdXVlt9LA2MAqG8ESoBHF381E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СзνЗцсΦζΛιЗЗАн():
    value = 900961
    text = __import__('base64').b64decode('eWxTYXBwbXVmSmZ0NUhvcUFheDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΒЧμдεΟР():
    value = 534185
    if False and True:
        pass
        _dead_5195 = 975
    text = __import__('base64').b64decode('TUpzYXNsbVNrUlN5dUVadVNOeVY=').decode('utf-8')
    if 37 * 17 < 0:
        954
        pass
        916
    total = value + len(text)
    return total

def _МХкοΘдфлцю():
    value = 748230
    text = __import__('base64').b64decode('dkR4akF0cFNkYUMxWExKWjQwZF8=').decode('utf-8')
    total = value + len(text)
    return total

def _фυзХΣТλФэηцφхξφ():
    value = 766609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3vnO2ky5ocnGTCy0UCVBBoB5U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥщоυтΘΗΣ():
    value = 454890
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTfNRmYA96ZbMiSt2ne+G3E65jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЙюЛΨЗοИРкυς():
    value = 756074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCPoWW5h14MEPhmM7QfJGQMa9WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δъΟηЭИςКιГДΒъСΑ():
    if len('') > 0:
        694
        3
        _dead_3177 = 268
    value = 17302
    text = __import__('base64').b64decode('c0lzNEhrb0RJQjBHa1Z2dk05eF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ςКфЪиМПη():
    value = 551142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjmxbGsQxv8ZBT673XeGbScbzEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αУЭмςΣивΘρДн():
    if 34 * 75 < 0:
        541
    value = 668444
    text = __import__('base64').b64decode('aTVTNXVPQXNrOER2VzcwZ1ZkTTc=').decode('utf-8')
    if 23 * 56 < 0:
        pass
        508
    total = value + len(text)
    return total

def _ЯЫβΚηЫΑшηФЪЬΤЮω():
    value = 763673
    text = __import__('base64').b64decode('SGdHc1VBSV9nejBFc1hUWWFOT2g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7068 = 527
        _dead_3644 = 143
    return total

def _θΧФцШνфГн():
    value = 943911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRDge0Bsx4ozFSG6zGm/LBMIylo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3443 = 864
    return total

def _χеΔКЮτθЯлщωЕμ():
    value = 707410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DS32T1cTpqsUH1qu4mbDGjN8vEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 13 * 15 < 0:
        _dead_8561 = 590
    return total

def _яΥЮбдИЙΝнчΓψ():
    if len('') > 0:
        _dead_9279 = 668
    value = 958642
    text = __import__('base64').b64decode('Y2hteThLRGY3bkljODlEczd3QVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ιъΘыГκτρσРмЫгσ():
    value = 43411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg7dW1Uy+44saFqu7Fu1Bn0cym0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нτΨЛΖпΩрЖУ():
    value = 339696
    text = __import__('base64').b64decode('RVF2NnplTTJFT0tBeUZYSG1rZVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _БΨοИЧΣΥыФυ():
    value = 832895
    if len('') > 0:
        pass
        334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwDNSnkcy5whKlz74WG9GQN70FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΖтΗΦмЗΡнφгЭч():
    value = 376331
    text = __import__('base64').b64decode('ekJveThvYjg1NVVwcDZEdjluQjg=').decode('utf-8')
    if False and True:
        256
        _dead_9730 = 151
    total = value + len(text)
    return total

def _ΗΨдКΓАТФ():
    value = 978824
    text = __import__('base64').b64decode('cWRpdTJDNGJ3b0xyM2dVNGcybFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΙΓЖУзтσ():
    value = 365817
    text = __import__('base64').b64decode('RURnN3J6RF9HWHJDaFdsTkV5X0Q=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_5201 = 579
    return total

def _ΙИδъщРΣηΑ():
    if 85 * 28 < 0:
        pass
        355
    value = 435411
    if 1 * 92 < 0:
        pass
        pass
        787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDXCPAIwyKdUEBiOygSKLRF67zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1149 = 323
    return total

def _ъθоыΣПАΣсСГ():
    value = 523154
    text = __import__('base64').b64decode('TTYzUlNpanoxSFJKa3diSkE3RXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙйМьΞτμъТ():
    value = 809342
    text = __import__('base64').b64decode('SnhJeXZmMTBQSE9SMEl5bzVZV2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _аΔэчЯвТΚ():
    if 68 * 77 < 0:
        pass
        pass
    value = 208888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHf0XWYh5vgIDjC50nS4YR8O4zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜЩЬξΞТΞλЮьΖРεЗΩЩ():
    value = 600865
    text = __import__('base64').b64decode('enl1aE84bzlUUlBBX1JURzNNNDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨЩΒтяълСΜаФ():
    if False and True:
        pass
        _dead_4924 = 213
    value = 928758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jg3HTWMq+70JNz6v53m8FyY8sFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        322
        997
    return total

def _ΕтжπбΥνΚν():
    if len('') > 0:
        _dead_4290 = 869
    value = 637729
    text = __import__('base64').b64decode('SDdweVdKYmJYTzZ1ekxhRVFUblc=').decode('utf-8')
    total = value + len(text)
    return total

def _ηубЕДеΙΟο():
    value = 994024
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxvDNlYSrP0OHCb77EOAFSc+tGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τлΟζгΚΔФЭКξεхаΥΜ():
    value = 873017
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cyu1X2Qt54JaKAiGzW/HFRN48EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИσξБФшΡφЗΗ():
    value = 828047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx3KSWUo0J4AFQSF6mnCFnIY1kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΙСьΤнТθεΡДМΥφξ():
    if len('') > 0:
        _dead_5590 = 245
    value = 352369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAXSWkkK7IBTBQGsxFmmAAc952Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЦьμПΚэΩн():
    value = 613367
    text = __import__('base64').b64decode('S3FnYkpLaEdNeXVBcVBJc2ZXc2g=').decode('utf-8')
    total = value + len(text)
    return total

def _δΝаапбχфηЖΦζ():
    if len('') > 0:
        158
        _dead_5254 = 269
        _dead_4127 = 597
    value = 455457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NynOVH8u14IwCTiX70+xDSQ/6Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _УКоЦλЙУЯчхχτЫ():
    value = 123695
    text = __import__('base64').b64decode('Unhpem5BbDR2RzgyMElQYUJrNk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘюэяогνыΟυφгфμоΘ():
    value = 60757
    text = __import__('base64').b64decode('QXIzalF4Wjh3SjZISm0wN3NocGc=').decode('utf-8')
    total = value + len(text)
    return total

def _оΘмςΩКΚЕдЪτβΛд():
    value = 862013
    text = __import__('base64').b64decode('a3Fxc0o1QzU4OFdpTzE4Q0dDRU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔгΚгεφβЦзшРΝΡδ():
    if 20 * 86 < 0:
        _dead_8749 = 109
    value = 721248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX3jWFQz0ZIZDy6v8FOgIXYn7X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if 18 * 8 < 0:
        _dead_8403 = 171
    return total

def _ςЭРмФσυΕгРХсζ():
    value = 593209
    if len('') > 0:
        pass
        _dead_9797 = 299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS33RXsJq48ZNSymn3+7DSEX3Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        109
    total = value + len(text)
    if False and True:
        615
        _dead_6600 = 211
        pass
    return total

def _ΝπыяМВιβΚιбГъ():
    value = 950631
    text = __import__('base64').b64decode('TTRxZDVRamJXdFp0cFppNUVTOUw=').decode('utf-8')
    total = value + len(text)
    return total

def _гΦΜФγξΥЧЗБащ():
    value = 297608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah7SZ1wc1KIMLAqcnA6pMQoQ4Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эеΖδажλпφсиФтΨтЫ():
    if 42 * 46 < 0:
        30
        718
        pass
    value = 542599
    text = __import__('base64').b64decode('WWRDNGFJQXBVbG4yMldJMVpqVk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()