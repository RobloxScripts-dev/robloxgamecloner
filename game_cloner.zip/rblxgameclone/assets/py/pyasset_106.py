#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ηшвПЗПλгрЪПшλ():
    value = 258842
    text = __import__('base64').b64decode('Wnc3ZjAxX0lVX2I4VW1TWFN6dEU=').decode('utf-8')
    total = value + len(text)
    return total

def _λΚΓοЕеЛΔΗрΚуйо():
    value = 745955
    text = __import__('base64').b64decode('cjlDYW9OOFNEUDFjV2hadDdVbjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ояηНΝжкψ():
    value = 865798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyXIUWYcwY8gawic4QCyNjAI8GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πшοΜμЭЙКЧΜοΧω():
    if len('') > 0:
        pass
        pass
        pass
    value = 360892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AX/0bwAu9YEpMDC3zWG/BjQM9kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        279
        pass
    total = value + len(text)
    return total

def _ЫрцтνЖйζфΞЩ():
    value = 932871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjfXRG4s87EZYxuN+waiGXIu0VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΕШыЭрηπΦγах():
    value = 946698
    if 38 * 98 < 0:
        _dead_5765 = 96
    text = __import__('base64').b64decode('R0NpVG1zQUVoYk81RFBWWFdVdnk=').decode('utf-8')
    if len('') > 0:
        625
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΜЯМжЪхΩТ():
    value = 765841
    if len('') > 0:
        _dead_9928 = 901
    text = __import__('base64').b64decode('aVVQcVRZMkZJZEZSWUhRcjFUX0Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        668
    return total

def _ыеρΘЮоΓΙιτΧЧв():
    if False and True:
        pass
        pass
    value = 478287
    text = __import__('base64').b64decode('YVhwVUs0NkNFeGcyamF6RDZkMkc=').decode('utf-8')
    if 12 * 1 < 0:
        _dead_4277 = 61
        _dead_9224 = 161
    total = value + len(text)
    return total

def _ΟΩрζμΩуΕφςλЙ():
    value = 386230
    text = __import__('base64').b64decode('RmVyRW9xamVoX0R2SWIyUmJRMGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΚрЯΠβПДИ():
    if False and True:
        pass
    value = 826491
    text = __import__('base64').b64decode('S2lXZ0FLa1VNdU1SRzdzRERhUlg=').decode('utf-8')
    if len('') > 0:
        202
    total = value + len(text)
    return total

def _ИΧщεашΟМΨтУοΤΠξ():
    value = 46248
    text = __import__('base64').b64decode('SGNzcmpqQTduVzdYNXVVcExERVI=').decode('utf-8')
    if False and True:
        _dead_6072 = 628
        _dead_6079 = 212
    total = value + len(text)
    return total

def _σπРТнВзаαсΤЩХеΦ():
    value = 950391
    text = __import__('base64').b64decode('QWozMXRYNlJCUDRTVnBwekkxcHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ХуφυΨΞЭιф():
    value = 569066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXnFWXoK3bhUOA60ymbIAXE5xUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        986
    total = value + len(text)
    return total

def _смεцνТξэαλΝκмЖЪΠ():
    value = 14279
    text = __import__('base64').b64decode('QlFXZXhYWkhtQzN4RE1QUTRsbGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΒЦтяЯтΨЧниАг():
    if False and True:
        pass
        pass
    value = 234468
    if False and True:
        pass
        pass
        _dead_5711 = 815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAvAX1gQrYEmOF2KkUGvBysK21Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧнνГΨЭΩСρ():
    if len('') > 0:
        222
        pass
    value = 482154
    if False and True:
        37
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ay60WHsgyoQFMzWpnnyjHwEu6lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6619 = 852
        pass
    total = value + len(text)
    return total

def _ХпочΥΔΝУЕΑκфΛ():
    if 68 * 98 < 0:
        93
        pass
        pass
    value = 605634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB7Df2Qey4cWDRvx/VOjGQsgt0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МςрбвξΝχφζΞ():
    value = 304224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTzQRQAT1qIUOySp/VS8ZT069n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζяωхρЖЭЫ():
    value = 857606
    text = __import__('base64').b64decode('cWJIUmczS0dNRDU2b0VrYkFkZHo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8143 = 80
        pass
    return total

def _ΗГθКΨαГцуνМΞП():
    value = 488573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHbxTQMt378ibjeVxWGTOQMftFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΚωΠмФςσΡЯχсαъΩ():
    if False and True:
        _dead_9962 = 648
    value = 906995
    text = __import__('base64').b64decode('V0VQbVY0X2tmQ1RjX3ZWQnRoOFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪлκφШхΥФωЫЭЬΝΡ():
    if 31 * 7 < 0:
        pass
        _dead_9281 = 336
    value = 689390
    if 91 * 97 < 0:
        _dead_4974 = 392
        pass
    text = __import__('base64').b64decode('WlZBcWNaY09uRklhc0tpajVVSUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΧζΙΑςΔуНΓцоа():
    if 90 * 45 < 0:
        pass
    value = 225911
    text = __import__('base64').b64decode('ZXJ2a1FyQVlIOHh3d3FONmdWUUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓψШΜΤψХиш():
    value = 572696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwHyZGgY+powDweK5W7ADBMew2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 58 < 0:
        73
        pass
        _dead_6602 = 781
    total = value + len(text)
    return total

def _φΖоΠЕЫΤиΛ():
    if 13 * 94 < 0:
        pass
        pass
    value = 750946
    text = __import__('base64').b64decode('d09SaEVFTEtwNUtXcGJRQ2cwMnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓЗХΔνδЦВοч():
    value = 452730
    if len('') > 0:
        698
        _dead_5701 = 228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHbUXmM66KswIweq8GLAAHV68Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝψгМЯУоЪМδωρвχсЩ():
    if False and True:
        pass
    value = 616534
    text = __import__('base64').b64decode('cGpUVnBvUGl4VnBVWnE0RF9mNF8=').decode('utf-8')
    total = value + len(text)
    return total

def _чιеИиγЪΛΦυΠщΠΠЙ():
    value = 857356
    if len('') > 0:
        _dead_5893 = 92
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lwjud0AT/K08bS6R21fFFgd57T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 51 * 64 < 0:
        pass
    return total

def _ιЬπЛΔΑΒςУЖ():
    value = 879680
    text = __import__('base64').b64decode('dEk1Y3RmdE1JX0UxVFNSYmFnMWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ФωςяιΝТЬДдν():
    if False and True:
        _dead_2677 = 938
        pass
    value = 192625
    text = __import__('base64').b64decode('YlBQcUtFaDJOOERzQWlrZHRMUzA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8000 = 314
        pass
        _dead_3684 = 176
    return total

def _ψзοθθБАψρςщИαцоп():
    value = 929379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiTceV0e249bOCSH5VmbAHB64Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эЖфХДηπЩЫй():
    value = 184934
    text = __import__('base64').b64decode('WXVZdjdROVo0Z2diQW5TaU9hRGQ=').decode('utf-8')
    if False and True:
        _dead_2680 = 386
        pass
        pass
    total = value + len(text)
    if False and True:
        78
        pass
    return total

def _ΕφРξЬΗΩЕГЗ():
    value = 592519
    text = __import__('base64').b64decode('WlNBdmFTYnRvQm8xMUpnVnNoRHo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8524 = 978
        353
        208
    return total

def _ςнщуΩΘμςδωФЫф():
    value = 327379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnfwQXM95KsEKQC153HBDTN70Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙЭэФаγΟСУ():
    value = 97441
    if 36 * 99 < 0:
        _dead_5759 = 48
        225
        933
    text = __import__('base64').b64decode('ckFWSW9GWkJ5WnRKdUZvaExtMnM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7730 = 660
        pass
    return total

def _ДЮЦнмβжΞТΗΞПлзЪ():
    if 47 * 53 < 0:
        862
        _dead_5889 = 286
        323
    value = 573232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCrtWUcB1rIhaBu54QaqGzEqyHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 91 * 22 < 0:
        _dead_4766 = 202
    return total

def _ПвΙЯяэЧгШΖвζο():
    value = 42071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT3NWXJr16YtP1ua53eSNi566Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Олζуμςыζыιжψвмη():
    value = 668035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETnVZFkv570XPzySm2LJESQayF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βΡΦТΑЫХЫΖ():
    if len('') > 0:
        pass
    value = 579002
    text = __import__('base64').b64decode('c0dPOHVYZUt4NkVZZDl3V0dLOUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΓιЕцσΨбΞлЭхλ():
    value = 577195
    text = __import__('base64').b64decode('dThLd2pmS1JNVm1XRzdXUE5yNVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩЪκпΙΠΥзωΥвκьορз():
    value = 632981
    text = __import__('base64').b64decode('SlFDcE5MZl9HZkZwcGpJRG5sZTk=').decode('utf-8')
    if False and True:
        292
        _dead_1955 = 245
        143
    total = value + len(text)
    return total

def _ИЕшΡзйωЪΜ():
    value = 576187
    text = __import__('base64').b64decode('Ql85UlJhYjNwUzhiWlJjSTh1aHk=').decode('utf-8')
    if 72 * 37 < 0:
        651
    total = value + len(text)
    return total

def _ГУφОωτЧуЕ():
    value = 971401
    if 45 * 63 < 0:
        _dead_3886 = 254
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AivSfnBv05gzGB6l3WaaDCEo3Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        913
        pass
        pass
    total = value + len(text)
    if 44 * 7 < 0:
        _dead_2822 = 851
        _dead_5845 = 293
        118
    return total

def _яыυХКЪпШфспНщκ():
    value = 563151
    text = __import__('base64').b64decode('SDlVUENidkI5UGpZSnl0TjUzVTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΝСцμшыщиνΚп():
    if len('') > 0:
        220
        _dead_9109 = 937
    value = 654000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAHbN2Uor647Ax+h+EWkASE18UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 98 < 0:
        720
        _dead_1971 = 775
    total = value + len(text)
    return total

def _ΕιςΗЦЫфмΟбиθΗЧ():
    value = 477700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBn8NwES+5EEaSeu4gPEZCYl4kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вοΩзщцКНЩИЗαЩеΣ():
    value = 325353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHiwOX8O2I87Lze6y0W3Zhwo/Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        708
    return total

def _ДαтмяΙικтΑεМΓπь():
    value = 902314
    if False and True:
        _dead_7594 = 519
        _dead_9876 = 450
    text = __import__('base64').b64decode('STNwSXFwdTlicnFEZVliVEdtdW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ξЛλθсьзΩαЧΥβД():
    value = 911928
    if len('') > 0:
        _dead_2868 = 610
        _dead_7945 = 835
        722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyfFZAkA7awEbiOVwW+XJiom7XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯпЩЭлφлаχИЯ():
    value = 576787
    text = __import__('base64').b64decode('ZWVtcVVzOWZPY2planlKYzhIOUE=').decode('utf-8')
    if False and True:
        _dead_2699 = 162
    total = value + len(text)
    return total

def _γЮХЫьςюжьиМб():
    value = 489184
    text = __import__('base64').b64decode('QWpweE9DZVVZNnJMdjJlUDI2ZkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖσБВуМГΑА():
    value = 156130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBvIO0Zu9/5QBRykmlXAZCF30j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иοТακЮυβςνЭΨеСΘ():
    if 4 * 89 < 0:
        97
        949
    value = 660645
    if False and True:
        _dead_6474 = 456
        pass
        _dead_9534 = 307
    text = __import__('base64').b64decode('UHdVRktoMkZlZl9Ra3ZVdnd3aTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΓчсΘΔΥυςΤΘ():
    value = 475648
    text = __import__('base64').b64decode('VWhfTnV4UjJoNFR2UW05b1FrZ0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠхЕкжΖФιЛкДЯп():
    value = 189964
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSu3fWgz1oUMYwWyzWCBYzQJzWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΟЛЙБгСНΞμ():
    value = 952253
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiPeYFMRrq8uC1+r7l+5ICQf8D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪςкσбетμβκжЩэЗ():
    value = 958484
    text = __import__('base64').b64decode('a0twU2JKb3JRdkRSdlZCcHFCSXc=').decode('utf-8')
    if False and True:
        421
        _dead_8096 = 614
    total = value + len(text)
    if 6 * 24 < 0:
        pass
    return total

def _ХωΠшиЭΘΙΤЬ():
    value = 523003
    text = __import__('base64').b64decode('STRmcllMdzFqWlA1T2xyRzVLMTc=').decode('utf-8')
    if 37 * 88 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЩθшΟεЖΒΟвчЩЪΝωШ():
    value = 412613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzrhXQcR9bgXPAGI4keIYzd5tTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΕΡьаνРνЫ():
    value = 716245
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxnjWUgbqb0WBSvzzHHEEQEN8jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2817 = 19
        558
    total = value + len(text)
    if False and True:
        pass
        _dead_1588 = 700
        341
    return total

def _ηоюЯФчхχэςАμцιр():
    if False and True:
        _dead_6374 = 865
    value = 204374
    if 49 * 28 < 0:
        951
        pass
        _dead_7765 = 204
    text = __import__('base64').b64decode('ZXh4Zkc4aE56ZTM5dU1jbFJRUXQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        169
        _dead_2896 = 674
    return total

def _эΧΜονсτрпЖ():
    value = 669115
    if 82 * 17 < 0:
        103
        _dead_4064 = 888
        943
    text = __import__('base64').b64decode('TnZ4UndRU0Y0NGY4NDJEOU5yRWk=').decode('utf-8')
    total = value + len(text)
    return total

def _πъΡΚнЭξЖВбη():
    if len('') > 0:
        _dead_5231 = 86
        pass
    value = 863065
    text = __import__('base64').b64decode('Z3dWWHNfZnllYkN3ODk3WDVBV3Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ъδΗпΕπΑΨΔхо():
    if len('') > 0:
        _dead_7704 = 660
    value = 174281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgPVagIv65goDwqwz1y3AAEk4jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 33 < 0:
        pass
        _dead_4098 = 598
    total = value + len(text)
    return total

def _ρΚωмшшХΡφφушУγш():
    if False and True:
        115
    value = 927105
    text = __import__('base64').b64decode('cElsdk1xUW9fM1pEUTh6Sko0X0U=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        245
    total = value + len(text)
    return total

def _МЛЯзчЩИЩК():
    value = 860551
    if 76 * 70 < 0:
        876
    text = __import__('base64').b64decode('YTI1Q3ljNUtvWTFxZ2xmOXYwckM=').decode('utf-8')
    total = value + len(text)
    if 17 * 11 < 0:
        _dead_2228 = 772
    return total

def _λЬЧГηДЖуеКТСГι():
    value = 619080
    text = __import__('base64').b64decode('T0d3UThxcl9QQ0tMVTQzVzlEYjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑОωΚШУнЙзσтΒЦ():
    value = 909760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3zMdGQBzqwhFwGE6lK6ZzMY438='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кЖачпПδЭΔθΞπ():
    value = 48584
    text = __import__('base64').b64decode('ang0UENWOXRNRm54XzJjUlNWUV8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3491 = 434
    return total

def _НΘαсЖФυΦйпΦйВеЭΨ():
    value = 792792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz7rXGUG/44kYjitngK4JnYi22s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖясгьыУιсЪθх():
    value = 743859
    if len('') > 0:
        524
    text = __import__('base64').b64decode('ZGp1dEl4RzNOTHBueEZ4Z1d2bVI=').decode('utf-8')
    total = value + len(text)
    return total

def _χλЭэεиπЫΑΡ():
    value = 332334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSu3WAE60oYHHx23+VO6PzMt5zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        410
        745
        pass
    return total

def _ЖйиΔεэДΟзцАΔКτΧз():
    value = 656778
    text = __import__('base64').b64decode('QzJHZzRLUUkwYXBUWEdIcDZ0M1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ПХπжшМАΜьъτЭЫδ():
    value = 5151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQjXeWMGqoIiCF368AfGCwYu1Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΞτЖИΑιεФп():
    value = 599736
    text = __import__('base64').b64decode('aTJidkxfVFNaMG80SzI0WlREVmo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣρШТшδъуΔеЕ():
    if 88 * 20 < 0:
        380
        pass
    value = 373912
    if len('') > 0:
        _dead_8498 = 540
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCD+Zmk/8aIRCSSn7kajFTwr738='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΔΤПЗХΨзиьгБΧСЭ():
    if 76 * 87 < 0:
        722
        _dead_1464 = 136
    value = 643041
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CirUQQkLrb4pbx2EkVmHIwkfz2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫУЧΗΕИΕэНъСГΨБЛю():
    if len('') > 0:
        2
        _dead_6226 = 913
    value = 469482
    if len('') > 0:
        455
        pass
        _dead_9874 = 419
    text = __import__('base64').b64decode('YzFEMUFwdk1pekdKYTRZUkxkNlE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑЫυВьМΑΧгξФΛν():
    value = 849922
    text = __import__('base64').b64decode('V01MTWJVMEZFbmJ3YVljWjJVdno=').decode('utf-8')
    total = value + len(text)
    return total

def _ыινщИΣПεΒчВλ():
    value = 891296
    text = __import__('base64').b64decode('QUJrSG5rR0pSbTBMNGJDd3d6ZnY=').decode('utf-8')
    total = value + len(text)
    return total

def _βэАЮΥтΝλыППгςоС():
    value = 628984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARnpa3s+x/sWPzqNwnmyAAYL00Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΩШδωЧВжν():
    if 71 * 59 < 0:
        pass
    value = 594716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyDdfARs+6Y3HD+50Vq2AXN3s14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΜγΦлХΕρЙλΩσ():
    value = 256146
    text = __import__('base64').b64decode('anFlWEVsUXNsY0VkcnBSdVBFQnQ=').decode('utf-8')
    if 1 * 38 < 0:
        76
        _dead_4405 = 359
        pass
    total = value + len(text)
    return total

def _оДΔδρЧΦΡиχΣОυΛХ():
    value = 770212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cg7lSwEMzv03O16R+VC5Yy0r4zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δσΞλыГφпςЫ():
    value = 882462
    text = __import__('base64').b64decode('S2JXTTFSb28zdVRqclJubWxHMUI=').decode('utf-8')
    total = value + len(text)
    return total

def _рцШХЦисΕ():
    if 30 * 18 < 0:
        _dead_7255 = 864
        pass
        793
    value = 968526
    text = __import__('base64').b64decode('Z21YVlA0amVsdjZIS2FpS2FrSXc=').decode('utf-8')
    total = value + len(text)
    return total

def _θχБΣюцХσНδХъДкШθ():
    value = 20686
    text = __import__('base64').b64decode('RXBWbDQ3YjhINVVtSWM5WWRzNWk=').decode('utf-8')
    total = value + len(text)
    return total

def _тπишЧιΞА():
    value = 712166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATvhT0Quz5goCCCOzGO2JzcN1WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σдуηжЗΟγнς():
    value = 816657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSiwbUkA37BVFB25xGSjBDMkzEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εСюхιуβΜМнеГТΣч():
    value = 467459
    text = __import__('base64').b64decode('dDJ5eGxOenVEZWZaXzI2TGYyTVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΑΩΕЭΥΑгАъνыΕ():
    value = 568834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NS70WQIT765XFj2Nym6zGnQ25Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σαΤюЬЪπμ():
    value = 32316
    if len('') > 0:
        562
        636
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDnAR2MrrJsaaiGq/magYygI8Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        908
    return total

def _ЫяβъαВъзВЮο():
    if False and True:
        pass
    value = 875548
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH3VNkUy1r5XAjupkGOjYAIm6D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        359
        pass
    total = value + len(text)
    if 82 * 89 < 0:
        387
        _dead_9236 = 408
    return total

def _НШВщСΚНАΣЧГΕ():
    value = 61454
    text = __import__('base64').b64decode('em9VdWFtVV9mR1I1bkg5TURwcTI=').decode('utf-8')
    if False and True:
        352
    total = value + len(text)
    return total

def _αжбυρЖьэρз():
    if False and True:
        456
        pass
        797
    value = 85572
    if 68 * 73 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXn3VEctxP4vFiH16nGzFSB+3FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 89 * 42 < 0:
        _dead_8581 = 757
        _dead_5861 = 678
    total = value + len(text)
    if 78 * 98 < 0:
        338
        pass
    return total

def _ςχьйЫпΕЖγМΑЕς():
    value = 247220
    text = __import__('base64').b64decode('UjFpc1pQdmxOWVBJR1FsM0VXTlk=').decode('utf-8')
    total = value + len(text)
    return total

def _УΦΝПγЛпЬЧСзΕ():
    value = 323166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSC3eVY8prISDjnx31imLgoQ70Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГУΞГбλтχΡ():
    if 33 * 90 < 0:
        _dead_9270 = 550
    value = 827542
    if len('') > 0:
        pass
        pass
        114
    text = __import__('base64').b64decode('b1FxaGFvRVlmTTBOdjF1eWRkczE=').decode('utf-8')
    total = value + len(text)
    return total

def _ОλφбМΙБΗщРΨфλχЗъ():
    value = 676654
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRnVZHkA6IxWESyPnm67YgQpzmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΧХШНжΑы():
    value = 709107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHjFamQj8qA5NQugyUC3Bzwrz0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δЯубрхаРΝθζИку():
    value = 129613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBz1ZVxuq7IRNzX1+kyRIQk210M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХъχοψЯСЫГиχ():
    if len('') > 0:
        pass
        _dead_9270 = 373
    value = 514625
    text = __import__('base64').b64decode('T1dhWGZQQkIydEJmQ2RPX1R6TmI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        872
        _dead_5334 = 220
    return total

def _ΜКъξЕОГлμςХМлφεЮ():
    value = 824784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARW2bAU/zokCFSC2mlnDH3Ej6T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΔΥштЪΙΔ():
    value = 205457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhb8R14S17wXC1652XmbZTR/80A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μπдТлвяШшχУ():
    value = 412733
    text = __import__('base64').b64decode('SmUyZWVwcWNERGdHRGw1cE96U3M=').decode('utf-8')
    if False and True:
        _dead_8294 = 32
    total = value + len(text)
    if 68 * 49 < 0:
        _dead_2715 = 956
        76
    return total

def _еЭОΤЯюπЧМΥбαмΒф():
    value = 153347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBXxe3Yexo4qaR73mHy5HB983lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 20 * 67 < 0:
        847
        pass
        66
    total = value + len(text)
    return total

def _ΛтЬЯмμИИ():
    value = 204865
    if len('') > 0:
        124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnmxWUk/q/wiMQe6+kKoAHQuxkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕХюυгσЖЖ():
    value = 179887
    text = __import__('base64').b64decode('Ukc0NjR0dWdJVEpNUW5iMDRYZGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖфИλΞШВмущЫωе():
    value = 209352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH3mY0s11KwhNgSC3A+xInAW/Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оβВъСΓΩЩТ():
    value = 808975
    if 16 * 73 < 0:
        _dead_1220 = 777
        pass
    text = __import__('base64').b64decode('TEZuQloxTkpKSURLVUFlNDhhOEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜуΩΑЖсюΗ():
    value = 382202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg7RY3IT3KMXbia7zHyVMS143jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВζηЫπφλПΕΨЩС():
    if False and True:
        _dead_7192 = 660
    value = 443637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LA7rXEIt/P4IPgevx3O+AzAJ83s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 48 * 36 < 0:
        pass
        _dead_6794 = 992
        950
    total = value + len(text)
    return total

def _ЖεζЕИВτОψ():
    value = 160736
    text = __import__('base64').b64decode('Uk01c1BqVW5SbmUycnB4em9LT2Y=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        16
        850
    return total

def _ЪφЮΨхнфя():
    value = 115833
    text = __import__('base64').b64decode('ejJGOHBBb3VBT25yTUF4RDBrTGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓεΟΩИфбΓбе():
    value = 898440
    text = __import__('base64').b64decode('Z2MxYXVzWDlkYVRYUDlrSnl5U0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ИПΤбХπΠΜμξиωΤΣλф():
    value = 6703
    text = __import__('base64').b64decode('c29EVUt6TVRJaDdhbmVQbm9XUnA=').decode('utf-8')
    total = value + len(text)
    return total

def _БςйоρюХωИζйЕ():
    if len('') > 0:
        pass
    value = 186719
    text = __import__('base64').b64decode('SmJqbVp3Y0lQd2N0Nmt3cTczYk8=').decode('utf-8')
    total = value + len(text)
    if 37 * 53 < 0:
        _dead_9806 = 104
    return total

def _дρΜзсλσлΛЗЦйце():
    value = 776987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwTqOUAv0/wrESWb2UOIOhUq81c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        49
        pass
        382
    return total

def _дγΠЯΨАΠтХΔЖ():
    value = 822454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDi8aUgVwYQJIxvwn0SaYX0ntVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΗпπНУΚЛΡζзБ():
    if 37 * 62 < 0:
        474
        115
    value = 149347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAf8bUg1/akBNjqBmH2pbHIZ22s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εψКСуηгЙЬгМЫМαС():
    if len('') > 0:
        pass
        458
    value = 231970
    if False and True:
        _dead_3713 = 789
        _dead_3016 = 641
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgPcUQcs9Z0vECyLxVS6ASgfzjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3328 = 678
    return total

def _ЙъρЛЦхЯцрθКΩν():
    value = 405225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXa3bHlu+YoiCSP321G8Mio363s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7924 = 439
    total = value + len(text)
    if False and True:
        _dead_7409 = 741
        _dead_8619 = 403
        pass
    return total

def _μжеΗЪчхЧъдх():
    value = 242659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3n+V0M4/69QFRyZ/n2ybA8a5mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΙΘΔΥΣрΠцΒ():
    if False and True:
        _dead_6300 = 911
        _dead_5566 = 814
        645
    value = 352133
    text = __import__('base64').b64decode('RUtMTWtsMl9fTUw5WTNCMVkzVUM=').decode('utf-8')
    total = value + len(text)
    return total

def _хэαНсθΠНδςб():
    value = 73429
    text = __import__('base64').b64decode('bjhKdUtJVXE5VGhDSmI0UVpucnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡВΦΧсаζχцρ():
    value = 543511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iy7CSgZqzYxSO1mZ+magIBMgy1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПШηБΣдδЧн():
    value = 763647
    text = __import__('base64').b64decode('eGgxSXZvMXdtSFRIZXRqdlBpaDU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛпшΣхЧОΤςσγσ():
    value = 348667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzjrbWk0zYVbCAzy+Qa8GQI8wGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пθгΦЯшξΟЪэΠΑи():
    value = 800501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAPhWUgI0ZwQaliTmw+HJh82/lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςЖдтфςφдΡГ():
    value = 725317
    text = __import__('base64').b64decode('TTBfUkxvenBBdlJsajdSalpNbmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ылοфжξДСОΝн():
    value = 762421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwjeW1g+/KEpFQiUyVKpHRoexnY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        774
        546
        _dead_2332 = 324
    total = value + len(text)
    return total

def _ΔШБΙБщыьА():
    if len('') > 0:
        _dead_1308 = 845
        pass
        pass
    value = 262413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBzzZUAvqroaFwS1w1WSHhIIwVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝдИΝΩСρКΦЪρзΠλπδ():
    value = 103151
    text = __import__('base64').b64decode('UWRSN2w4MVZHUnJKVGFRdXlCMEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭκЕεψΜсВΓψИ():
    value = 148168
    text = __import__('base64').b64decode('VmptYU5fazd2TUlIUzNWb1EwcjE=').decode('utf-8')
    total = value + len(text)
    return total

def _гΜΖчУνУλЭЗΑФ():
    value = 772156
    text = __import__('base64').b64decode('b3lvRVd3djRGNFlzZlVIWDh6MzY=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ιпΥдХξсΛΒΞβΩчд():
    value = 409195
    text = __import__('base64').b64decode('YXRHXzhMaDF5SjNNQlZlR21URFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _КΚΞτЪУяаσиφλЦдΡψ():
    value = 423144
    text = __import__('base64').b64decode('Q0FNbEVSdjdxY3FJcE90VlhaTUU=').decode('utf-8')
    total = value + len(text)
    if 1 * 50 < 0:
        694
        pass
    return total

def _ДυЛΣΓΚВНκγρЭц():
    value = 302930
    if len('') > 0:
        _dead_8804 = 98
        _dead_9804 = 736
        _dead_5762 = 166
    text = __import__('base64').b64decode('Tk9mUGRMeG0wWmFqTVNzamNIWXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ДмΟΡЩиъФΔТУУΣ():
    value = 551802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx79ZFMo+aIZMjWEwkyCJxp6zWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΓΟЮΦмαрπцАΥ():
    if len('') > 0:
        pass
        _dead_3229 = 678
        305
    value = 342479
    text = __import__('base64').b64decode('T0NnOE5MMXo3ZnVrSzJKRjNuWkI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        458
        pass
        pass
    return total

def _ζλνщЭсγф():
    value = 677185
    text = __import__('base64').b64decode('aW9sOFJYcU1Oc3RQd0JvUm0xaTg=').decode('utf-8')
    total = value + len(text)
    return total

def _БяΘСζβΞьь():
    value = 970134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB/AaX8S9PEhEiqr3kOpGAAtyF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        465
        311
    return total

def _дΥВιЖзψБуφжЖΦИ():
    value = 106393
    text = __import__('base64').b64decode('WFRDMzFGWUcyRnpzSkxSZG9zaFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥιдωηйЕηΛβРцдс():
    if len('') > 0:
        pass
    value = 25817
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXnUYHs1xokrKx/1wU7HGjAa9G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДЪΑъΝχчрγЮΖΙцΠ():
    value = 657774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KirLdlgtqb4wEiWi6V6APnY1zjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РКζφβθιпνИЩз():
    if len('') > 0:
        185
        _dead_8591 = 251
        pass
    value = 966503
    text = __import__('base64').b64decode('ejBGNnpCaHhFMDZOSFRCVFdtbUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЧЮбчэσНΙФХΡφф():
    if len('') > 0:
        _dead_8883 = 73
        pass
        pass
    value = 873881
    if False and True:
        _dead_8480 = 547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiPdVEhp24cyPR2V+QW5BgEl/kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        300
    return total

def _тяΥЬδГЧτЫухТμξφ():
    value = 908901
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQjNfUMbp4c7PiyX5kW8GAEdyWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бЫцΞцζчцПФλУНτΛ():
    value = 952588
    text = __import__('base64').b64decode('ZlM1WmR5cTVrdVNjeEM1VnNkYkw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1935 = 4
        pass
        _dead_8078 = 490
    return total

def _АΟνφьаΝΝвОΔβСθм():
    value = 296861
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAi8fQkur/gOYzeqn0G5HQws4jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΓПΣЫΑμΠщ():
    value = 908074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQDQN0cxq5oRag2QxVKbDQQJ6UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3079 = 76
    return total

def _ЪНхηмαΜΔφ():
    value = 286583
    text = __import__('base64').b64decode('YW5zdXp5MGJRUXhxYzdfMnhtcG4=').decode('utf-8')
    total = value + len(text)
    return total

def _УΨьΗμΛюЙЪАΑэΑБЮ():
    value = 356649
    text = __import__('base64').b64decode('bnhTY3YxekhNd0NfTlZXc1lYQ1c=').decode('utf-8')
    if len('') > 0:
        _dead_8036 = 206
        _dead_8259 = 127
    total = value + len(text)
    return total

def _жΖСεΞОЪлаσΑ():
    if False and True:
        _dead_3238 = 961
    value = 195502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHfJbHZu0IAtYl+Ly1icZAo20no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΤΖΛΞΝхъвΝрψ():
    value = 262084
    text = __import__('base64').b64decode('a2J1MWs0alI4a1MyeTVJT3FnV1c=').decode('utf-8')
    total = value + len(text)
    return total

def _яйξпюЧВкΤкΖцъцН():
    value = 812913
    if len('') > 0:
        887
    text = __import__('base64').b64decode('ZkJ4VTFZelhnWGF2RXBrMHg3MXc=').decode('utf-8')
    total = value + len(text)
    return total

def _мФΗИюБοойβΑв():
    value = 240383
    text = __import__('base64').b64decode('V2VCcDJ4YnZSdmlWWWVjc0FVUnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΡθЭЦТхЕ():
    value = 326270
    text = __import__('base64').b64decode('b2JqRUt4TXY3N3pmdE5Ua1ZWUHc=').decode('utf-8')
    total = value + len(text)
    return total

def _РЧзэмЭΩξч():
    if len('') > 0:
        659
        pass
        _dead_1980 = 12
    value = 979554
    text = __import__('base64').b64decode('SUxCZ05mb0RKQ0RZR0FnaWQ3N20=').decode('utf-8')
    total = value + len(text)
    return total

def _пατοχуΨеЬθЪΙΣк():
    if 42 * 78 < 0:
        pass
        _dead_5556 = 874
    value = 592963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBDFfwU+rKoSFTCCzESVPHws9Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сСЧЬбдЙш():
    value = 283707
    text = __import__('base64').b64decode('R0ZodjhkTDdyOEdNOXJIdU85ME0=').decode('utf-8')
    total = value + len(text)
    return total

def _ПшеЙΤыΦΚφΗмАщМл():
    value = 25271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDfvOUBr85cwMCCl3nTAZDIj3k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΙбШΡДЯΓШΑдΞΟ():
    value = 226840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChnMOkUw86M7H1a551WlGzEs8Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΛщΣπГПη():
    value = 91930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRrRXWQWyZ0rbgmzxAWfBCEo5WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮччμюΘΑЦ():
    value = 513277
    text = __import__('base64').b64decode('ZWgwbDdSZHpIZWt6TmVmajRqSHo=').decode('utf-8')
    total = value + len(text)
    return total

def _шατεηВищмΛФΩς():
    value = 704335
    text = __import__('base64').b64decode('YUdYa2drVVFPRmNTbEQ0NWRQcDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘоβДИωγэιя():
    value = 308410
    if 84 * 50 < 0:
        _dead_5909 = 839
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyvsY2gvp50QCh+w90aTEhMB7mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сЬμсΔтЦКδХ():
    value = 769467
    text = __import__('base64').b64decode('TWNUMHRhUEdfb3ZEN0hxcXlxaXk=').decode('utf-8')
    total = value + len(text)
    return total

def _эъЙΗΣеЧφттюнλьЮ():
    value = 154590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3/vWXcg5/tVMCqRkGLBIAIp7mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        44
    total = value + len(text)
    return total

def _ТνыΤцскυεВдкв():
    value = 203946
    text = __import__('base64').b64decode('aEJ0RkJOUzlUeFhyNGJpOVlsZ0Q=').decode('utf-8')
    if False and True:
        161
    total = value + len(text)
    return total

def _НζЧхПЦιЮΓ():
    if False and True:
        _dead_7517 = 926
    value = 374243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh3CT19t0/gaHTq543uCYnc77Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΕΥσХδαмχΔЪ():
    value = 743795
    text = __import__('base64').b64decode('c3FKRUxBak44V1VjX29BSVZEYlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΚΤЗСςΔфЗЦεьоΛΖ():
    if len('') > 0:
        _dead_7166 = 885
        619
    value = 656261
    if len('') > 0:
        _dead_4299 = 52
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cwz2NgIa54kuHQSo5XSeBXQL6V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςκκилиМΤСΙοΨЗΩк():
    value = 257852
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjnIaHUQzvEtPQCK2lqCLAkH8zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7908 = 926
        490
        979
    total = value + len(text)
    if False and True:
        346
    return total

def _ΦОФрΩψАжХШΨΝ():
    value = 47541
    text = __import__('base64').b64decode('bzBqbkJYd0tyUHI5U3dWbnNTU3c=').decode('utf-8')
    total = value + len(text)
    return total

def _РЕдРΛΜМγψΙЖъθу():
    value = 918865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgbMZmQeyvsvaSW27lmcZ3cN7U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тοщщΠΒКГУМсэМ():
    value = 996878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSmyemBvqfgmICaO5F+AMSQkzjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΦγμεωτγ():
    value = 575843
    text = __import__('base64').b64decode('WDlldkhkODdHcFlYSHdka0g4b1A=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        338
        423
    return total

def _ΑЪητясγцπνВПш():
    value = 965000
    if False and True:
        635
    text = __import__('base64').b64decode('ZVV0bXo0SUw5a0JfTk9FZUFQNFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ПрθиνσξзКβЦθΘ():
    value = 57525
    text = __import__('base64').b64decode('TlBTajRUSldFSzg3aDlOSVRJYXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ндζяцШжΟЪΒΦЩгиΞ():
    value = 764519
    text = __import__('base64').b64decode('cDl1QVBPRzBIdkhUb3NfUHNMVzY=').decode('utf-8')
    total = value + len(text)
    return total

def _бιζΚЩЭгЙΗΧΧνυΧ():
    value = 162138
    text = __import__('base64').b64decode('eWxfNHAwMFBBQzNlNWp5bkx4YXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫыЩσЗЫψкξДКс():
    value = 119371
    text = __import__('base64').b64decode('RTBLbF93V3d2ckZfUkZFemNWZGI=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ГαнψЪыΡζΑμыйКχжΝ():
    value = 643569
    text = __import__('base64').b64decode('YkpRUTZpRDJndGxhSFZBbFA2cUw=').decode('utf-8')
    total = value + len(text)
    if 2 * 76 < 0:
        _dead_2540 = 642
    return total

def _гΞЭрΜγοФΕшΝΟВΨй():
    value = 354669
    text = __import__('base64').b64decode('QkZvamwxMWd2RnBrcjVMUTAzWkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _нПнЮРψрΓΥλζкЙρлЕ():
    value = 724576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgG3OmYB5qErAiul5WefODwo8Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δрЮΧЪзΦπ():
    value = 148824
    text = __import__('base64').b64decode('eVNVbTNNRV9PeXJYVVhkSlV6TGE=').decode('utf-8')
    total = value + len(text)
    return total

def _φмтвцЯλгσяο():
    value = 823716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR/RNlU7wbBaaQ6v+gaZMwA27VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΔΘжщаξΑψЫυΙζΓΞж():
    if False and True:
        _dead_2545 = 296
        579
        pass
    value = 712381
    text = __import__('base64').b64decode('djhET3E1VUxmYXpkTWdJTFR2QVo=').decode('utf-8')
    if len('') > 0:
        885
        pass
        pass
    total = value + len(text)
    if 31 * 95 < 0:
        953
        800
        pass
    return total

def _ЕхΚΣаπЬΤя():
    if len('') > 0:
        439
        348
    value = 644650
    if False and True:
        _dead_7873 = 857
        pass
        335
    text = __import__('base64').b64decode('Tzl5TWoxT013TzFHQjczUWVPeGs=').decode('utf-8')
    total = value + len(text)
    return total

def _гτГОρщΘεГΜβκψ():
    value = 740918
    text = __import__('base64').b64decode('UEpydDFxTUFJRFI3X25Ual9DOUg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7125 = 1
    return total

def _ДШыΦяΟЮΠφИ():
    value = 577775
    text = __import__('base64').b64decode('aXRkSU1Gbmt2NlhYV1JhRmltWlY=').decode('utf-8')
    total = value + len(text)
    return total

def _юЩΤδΦтΝα():
    value = 651152
    text = __import__('base64').b64decode('VHVHUlZ4Wl81R3lfNWVUTDJjSnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ДηдΤЩΝΚβИΙчЯепθΙ():
    value = 475553
    if 64 * 45 < 0:
        _dead_9456 = 503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH3oZUQOy4MbIDCh+w62OwM8w10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9376 = 799
        459
        587
    total = value + len(text)
    return total

def _ΕЕаΡΨызΔЛΠФржρ():
    if False and True:
        588
        954
        pass
    value = 638513
    text = __import__('base64').b64decode('ZkEyX0tYOEI4YlF3dXV1MXl4OFE=').decode('utf-8')
    total = value + len(text)
    return total

def _шЖыщεЭαнΒσ():
    value = 705067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDbKPQQpr4MxLjeh212GJjQJ5Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΡΖЮвΙоьИΜ():
    value = 752341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAXMV2gy54o8CxWN2gSCHn020Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2422 = 612
        294
    return total

def _ΑэοΞιдъоΕедЭκγΗ():
    value = 585839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwK1bGsp164pDybxxVKfIT8h81k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if False and True:
        _dead_3091 = 615
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if len('xx') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()