#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _йхΝЗНИΟЗβсИр():
    value = 244220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjfMPAYy6vwSIAyPx3iTZAkl4Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        392
    return total

def _πЮДΠмжбыкЙъΧΞ():
    if 7 * 43 < 0:
        824
    value = 592585
    text = __import__('base64').b64decode('Um5DaDlPYmx2bXdEZjU2aldNOWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЮфυςΞьлкрω():
    if len('') > 0:
        775
        31
    value = 804878
    if len('') > 0:
        527
    text = __import__('base64').b64decode('bzRUdENHRTF4MHQ2Y0ZFbllJSE4=').decode('utf-8')
    if 14 * 46 < 0:
        _dead_3628 = 438
    total = value + len(text)
    return total

def _πΘнНмЮкЪЧф():
    value = 734415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axn9ZQQ8xKcEMgek7me4HgM183w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΠКпΑОеРъЛΚ():
    if len('') > 0:
        pass
        pass
        pass
    value = 891628
    if len('') > 0:
        _dead_2661 = 214
        319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQ3XaUsA8oVaOV+2+36YZHI17To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 100 * 66 < 0:
        _dead_3678 = 742
    return total

def _ΡεЪщеδЫгОΒчУΩιцЖ():
    value = 29170
    text = __import__('base64').b64decode('cE9IRVJ1Y0toWlIwS1Ryd0daMUU=').decode('utf-8')
    total = value + len(text)
    return total

def _БгОССэнΚΣЗλЖ():
    value = 45527
    text = __import__('base64').b64decode('WFBYdUZZVEFBOUZXMHBQSEduNzY=').decode('utf-8')
    total = value + len(text)
    if 75 * 48 < 0:
        236
        _dead_2927 = 188
        644
    return total

def _γΡзИζЗρЮъЪПιЦ():
    value = 274797
    text = __import__('base64').b64decode('ZEdxVG92QjRXbHR6aHBrYTZRaEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΙΩЦδΦнюйщ():
    value = 825791
    if False and True:
        _dead_9425 = 180
        _dead_9353 = 570
        pass
    text = __import__('base64').b64decode('TUEyZUNoMU1uSUUwbUFER05zREU=').decode('utf-8')
    if len('') > 0:
        613
        pass
        _dead_3297 = 360
    total = value + len(text)
    return total

def _жΥйэΔЕκч():
    value = 551311
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnjJY0QQ/58JPF2A8GyXBw84zEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        928
    return total

def _ЮщθуτοОδФАр():
    value = 854188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDzRRFs965wLMjXwww+RN3w1wjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3410 = 646
        54
    total = value + len(text)
    return total

def _нηгΜψψпПΕΙвВЭξΒ():
    value = 206367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3vqeHYcrrIvP1aPxQWpE3cFskg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΓΒэβяθтΣτШπΡИΒΓε():
    if False and True:
        pass
    value = 414063
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB3FY1Q855JUI1/y/1SpYnN87G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΛνιΥЫЙλΞРΤАηч():
    value = 19104
    text = __import__('base64').b64decode('TkhMeDlsM01MTm9Bb1FmbVVHbnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЖПΖеφΚТ():
    value = 951061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRbWYwhqrK0CPVzy7U+TAxwV1UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рγЫВφШεжφΤГκ():
    if 55 * 72 < 0:
        195
        _dead_7966 = 525
    value = 141185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnzeYXZszLErbF73zGzCOzMZ3Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 44 * 77 < 0:
        pass
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3174 = 4
    return total

def _ЧΞачξфьμюиΝдΞРА():
    value = 31244
    text = __import__('base64').b64decode('VHMzaDVNUnJBa05pbFk4TXV0UE0=').decode('utf-8')
    total = value + len(text)
    return total

def _УСдзЙКΠсоЙО():
    value = 20084
    if False and True:
        _dead_5575 = 815
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnrgYFIfybA7AASF7HyZHCEh9Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨКчΠЪΗВЕцΨςΡαГ():
    value = 884945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwjlT38U8oYBKxas6U6ZAT0h4WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 67 * 7 < 0:
        _dead_4509 = 291
    return total

def _πЫΧΣНяШΠυκχнπΜξ():
    value = 514519
    text = __import__('base64').b64decode('VGI4eXdRb2Y5YkdfZUFjSHUwbGY=').decode('utf-8')
    total = value + len(text)
    return total

def _бΦφαЗтηςκβ():
    if 85 * 22 < 0:
        _dead_8845 = 896
        967
    value = 214584
    if len('') > 0:
        283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiezTFA1zLgNGz27kQPHJA8lxXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 75 * 45 < 0:
        pass
        905
        pass
    return total

def _ψδзΕЪыμбεКψ():
    value = 567678
    if 72 * 6 < 0:
        _dead_2761 = 3
        pass
        525
    text = __import__('base64').b64decode('WVlLVXZZTTI2d2dDVFRnZDM1cEc=').decode('utf-8')
    total = value + len(text)
    if 31 * 59 < 0:
        pass
        572
    return total

def _ГЬЙпЖБφΞφЧ():
    value = 179302
    text = __import__('base64').b64decode('YXNwOXNCeFN1bkNOZV9EVGc2cW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜяТΕПαВОъπАЪПдЗΦ():
    value = 176875
    text = __import__('base64').b64decode('dDFwT3VGRnA4dWZUU2Z4TDVrVU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠσΤНΠεкΠ():
    value = 594016
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Knj8dEYU7pcbDSmZ5WyGOwEH4Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αГМαΝвσЧОБ():
    value = 335139
    text = __import__('base64').b64decode('VE9UdzN6d0JoQ1lmUWs2TDZtdlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΥШΓиΔНлΒΩβΡλячФ():
    value = 829255
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAC1NwQX8KRSDjCu/3SKOgkrxV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞжδЧЯμиЫμΜφΨОΠз():
    if len('') > 0:
        575
        pass
        _dead_8939 = 736
    value = 259832
    if 4 * 1 < 0:
        664
        97
    text = __import__('base64').b64decode('cVNIWkNCZkRKMW56amNlV0FqSm8=').decode('utf-8')
    total = value + len(text)
    return total

def _эЛцкΨШЗХυ():
    if False and True:
        18
    value = 327889
    if False and True:
        621
        pass
    text = __import__('base64').b64decode('QUdqR0JUTVk1WjhZWmJ5cXJYSDE=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЫνκдуЧρыΧ():
    if len('') > 0:
        283
        902
        _dead_2305 = 339
    value = 576833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh/rQwlg+fA7L1iJ5X28PxUBzEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УКζρКэτκυфБβлз():
    value = 978431
    text = __import__('base64').b64decode('WkM0Sk5GVHdLenB3TUQwUEpHWU8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3514 = 351
        _dead_9186 = 521
    return total

def _ЬОΨРγЫиτβΡΛОΕе():
    value = 928470
    text = __import__('base64').b64decode('cGVXSG5tc1hOMjZTa0Y2dXl4NTk=').decode('utf-8')
    total = value + len(text)
    return total

def _дΤжщАнТυРΠ():
    value = 384118
    if 61 * 99 < 0:
        883
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NA7NegIR+7AWAgai+V2fZHMdyUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        619
    return total

def _МККМЕΚхΜщЩΦγΤь():
    value = 474769
    text = __import__('base64').b64decode('YU8zTHJVb21KMlpaMkVfWFVheVA=').decode('utf-8')
    total = value + len(text)
    return total

def _СЭτНλЧаВЕΦТьθзЦ():
    value = 301129
    text = __import__('base64').b64decode('bGdKbnhjZEpBX2p4WmxYTEs5STI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1840 = 45
    return total

def _θэΒдзУсеΚ():
    value = 688050
    text = __import__('base64').b64decode('STUyV2lZN2hOMGhKdV94WHQ2YkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ζцфДΔкςЗυц():
    if len('') > 0:
        pass
    value = 994273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PC7GPVcM9Y1TKBWVkEWzNSMF600='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΡΒсΛЪяτπбκ():
    value = 289903
    text = __import__('base64').b64decode('Z1VNN1pJeTEya3hpMklZQlRIcUk=').decode('utf-8')
    total = value + len(text)
    return total

def _щΨΠЯπΡсиιωςд():
    value = 217510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSC3RgUSqL9QEw2s6gK1Awx5sHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9066 = 668
        _dead_1905 = 336
    total = value + len(text)
    if 27 * 7 < 0:
        pass
        _dead_1658 = 800
    return total

def _ГЬАΤΠзЩВЗДчфДТ():
    value = 227277
    text = __import__('base64').b64decode('a2szR0FlZXZXOUxDT0lLQkJMQkE=').decode('utf-8')
    total = value + len(text)
    return total

def _щРποоТРеЪЙρдΚя():
    value = 211078
    text = __import__('base64').b64decode('T2VJMUM1eG5JVDBFRkpuVHdCem0=').decode('utf-8')
    if 43 * 11 < 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_1182 = 921
        844
        pass
    return total

def _τκΔЛЬиДрлЛС():
    value = 239632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgLDQ3ss1PgNHAyPw0CHHC488Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жЧθΡИШщπСжФ():
    value = 35848
    text = __import__('base64').b64decode('WnpPS3NNekMwVUpHUFJqejZOaGE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ВщΧаЮмΑхΕкΜΨж():
    value = 407446
    text = __import__('base64').b64decode('QVVOZlRIdHNmUUNNeWU4VGlfd1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮХΦдмНΚХюдЭΜφψщ():
    value = 663931
    if False and True:
        500
    text = __import__('base64').b64decode('QVpDOVZDNTAydGVDUm9iWnhLaTg=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _щρΜЗхρρяЮсΧδυ():
    value = 726636
    if len('') > 0:
        pass
        736
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxDjN3I+rKpaayKln1mmJXUbt2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        423
        _dead_1232 = 227
    return total

def _ΩигьΘΡЕй():
    value = 775476
    text = __import__('base64').b64decode('dXh1REN6Um1NclBfMXBPY29yam4=').decode('utf-8')
    total = value + len(text)
    return total

def _ρχЧАЮюпМкхйΧЕкξ():
    value = 854204
    text = __import__('base64').b64decode('bkE0X3dWa1lONjVKNUlNOFgzMEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ПюЖЫλФΨСΤЫΟЛг():
    value = 919427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzzRNgI05J8tID+F0gaaHXMJ8kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЪЗДΑζΜΙЖМЪлРъφ():
    value = 131051
    if len('') > 0:
        838
        742
    text = __import__('base64').b64decode('dmxTbVVpWldvU3BvRmZ4X2F6WGo=').decode('utf-8')
    total = value + len(text)
    return total

def _КДПшыТиИ():
    value = 492829
    text = __import__('base64').b64decode('ZGM4YnNEWkpWS1VCc1ZsZ0xKTkQ=').decode('utf-8')
    total = value + len(text)
    if 68 * 92 < 0:
        _dead_5758 = 198
        pass
    return total

def _ЯуοΩОжζоΓΟπ():
    value = 878207
    text = __import__('base64').b64decode('bndLbl9VSzNiakxVWnVmRDNyUlc=').decode('utf-8')
    total = value + len(text)
    return total

def _τткпιΑδΗΙШ():
    if 10 * 8 < 0:
        pass
        _dead_9405 = 725
    value = 723612
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fxu8X2Y66rpbIACt0XCaNnIosmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 91 * 21 < 0:
        pass
        pass
        _dead_9844 = 88
    return total

def _ьΥζφЬσЩчλ():
    value = 295803
    text = __import__('base64').b64decode('V1l0czBCNXhrSF9ZdHZKUVlDN1A=').decode('utf-8')
    total = value + len(text)
    return total

def _аΤαΦФЩΓРцΑιяηΙ():
    if len('') > 0:
        69
        782
        pass
    value = 79935
    text = __import__('base64').b64decode('QnBBSk9VcHg4UzFhU09rbHBGRFM=').decode('utf-8')
    if len('') > 0:
        _dead_3662 = 560
    total = value + len(text)
    return total

def _ьЩШхΥτВЭρε():
    if 55 * 33 < 0:
        pass
        pass
        pass
    value = 799991
    text = __import__('base64').b64decode('T2NJejFYZkVnVFNFTjRxTlNOXzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΦЯтεΕЕюΔмμРηΞ():
    value = 323166
    if 78 * 4 < 0:
        pass
        pass
        _dead_4748 = 562
    text = __import__('base64').b64decode('VnBRZWJ4WHU5c3NmbHYxWTVweWw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _пΥТпБΝΚΤΛщΔТΔδΦЮ():
    value = 100325
    text = __import__('base64').b64decode('eEJLQW9DVWdJQmtNRWJ0SEhqWjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ВПΘЮАσъьτз():
    value = 280664
    if 77 * 36 < 0:
        _dead_8091 = 694
        _dead_1381 = 676
        _dead_6316 = 165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnfdbH0Awb0xMiSInVDCOy4j1WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7142 = 221
        70
    total = value + len(text)
    return total

def _ζнЯйΛрЮц():
    value = 755973
    if False and True:
        pass
        565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwHPZngL7akZIyuL5wOhHBcQ70g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЧющΕкЯН():
    value = 987427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTXGP1YW+4soKCKCwHWfBCZ+9DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΚΨΨДδЩЩφгнб():
    if False and True:
        225
        849
        pass
    value = 485326
    text = __import__('base64').b64decode('RDcxWEtqbXVISU1VRUFHZnN1Zjc=').decode('utf-8')
    total = value + len(text)
    return total

def _РГΦЦЛзЬλЗΑςγΤ():
    if False and True:
        _dead_1074 = 789
        612
        pass
    value = 101896
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3fLWlcYqbwZFjuynVrEYgk/6Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЯЛΧЕкзЧмвЬβщσΠ():
    value = 498605
    text = __import__('base64').b64decode('RGhMcTQxZnhyU21aQldNVVUwMEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮГзΞΝΔпΒΜβΚ():
    value = 518067
    text = __import__('base64').b64decode('SDRaeHozZ2JaUm84NU5tanBXRVA=').decode('utf-8')
    total = value + len(text)
    return total

def _леуΓπΑМЛяΦг():
    if False and True:
        322
        pass
        67
    value = 753088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhjuT30s/6pTP16m8mOyAj0d5ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5032 = 860
        pass
        pass
    total = value + len(text)
    return total

def _γρхΠйиеΚΗΒλΦ():
    value = 311647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzfSZH1syvoFA1mt63jGZA0swWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙЩгΥЗзКФСΗ():
    value = 265195
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC7Rd1kT+LwqaSyokWOVMy0N3jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ечЯλωРηъμνрξΚМ():
    value = 517298
    if False and True:
        _dead_2058 = 783
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBvsQGsK5oMFDjaX0Fe1Zih29Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αдржзбςНемиχχ():
    value = 429069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBXNenQJz4NRDCmbwlqxOC8V9EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨЪнΡъΠоΞцΞЖΠЖ():
    value = 51199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHu1YGIQ+4kKYjym+mnIJiYX7WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 74 < 0:
        _dead_4759 = 338
        901
        491
    total = value + len(text)
    return total

def _УΨюΡУХηγЬςГял():
    value = 945460
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSDpVggP368nNiqlxAKBADwm4nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        174
        540
    return total

def _ОΕРгΔЛДъΣΜηΘ():
    if 91 * 16 < 0:
        pass
        _dead_5572 = 247
        _dead_1390 = 369
    value = 571046
    if False and True:
        pass
    text = __import__('base64').b64decode('RF9GeEczX2JDUnJDS2hBR3Q0WTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗβШйθοΘвуВαШ():
    value = 337093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQnrdwY+xrsHFi2UwHGvOy8H0Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4158 = 999
        135
    total = value + len(text)
    return total

def _ВоДνъηгΖЕЗгξσхУ():
    value = 526168
    text = __import__('base64').b64decode('V0hiNFdGcWtibWx1V2FjcV9vWk0=').decode('utf-8')
    total = value + len(text)
    return total

def _μДфγοΣθδррπЯ():
    value = 645222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lnu2TGNgx5kqPyH3+VSRDjUDzUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эαЬΥιЬКпШΑΔНЬΙκΧ():
    value = 651660
    text = __import__('base64').b64decode('cHNncW1sQXozSG1GeEVZTTlVWDc=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ηςЫаΑЯиνЧΠвΡЛΤщС():
    if len('') > 0:
        _dead_5359 = 244
        317
        _dead_9891 = 321
    value = 44788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAPvWUEY168uPFqI5wSlMit89zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кЫЙΙоηΦΓθΟΤγψ():
    if len('') > 0:
        738
        pass
    value = 492236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHjPZGRgyKkUIyKNynqdICw6vH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        356
        pass
        947
    total = value + len(text)
    return total

def _μιГχЬЮЗξФЖλеΞ():
    value = 302435
    text = __import__('base64').b64decode('a1NocmVFaGRtdFFLMFZFZ05mZXA=').decode('utf-8')
    total = value + len(text)
    if 33 * 100 < 0:
        pass
        351
    return total

def _йНФωгЕОΔЬβΡф():
    if len('') > 0:
        _dead_2207 = 4
        _dead_4801 = 941
        _dead_3665 = 532
    value = 317945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQ3PV3c77JlWMySbxECdH3AA0D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 85 < 0:
        _dead_1501 = 108
    total = value + len(text)
    if 30 * 95 < 0:
        pass
        pass
    return total

def _УНΧψЕγпΩАЯжшΤ():
    if False and True:
        pass
    value = 790998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BibQZmESyfwyHRmN7GCSYx8Gw2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йаηЬεаЧНъςΘО():
    value = 112729
    text = __import__('base64').b64decode('WkpYTXBQVmVCZ2hDQjZaYXhUMGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ξоοЧΟχВΤо():
    value = 734495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRzCaEgUpqYuAj+E6VCJOjEF2z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_1356 = 271
        628
    total = value + len(text)
    return total

def _ΙГьзΦеνбοДДцСб():
    value = 619447
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCa9SgQV1qcIMzmVyQ+VYQcJvTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РВαлЕΙье():
    value = 21467
    text = __import__('base64').b64decode('SWRFNldjOUprYUM0NFNKTFBjYk8=').decode('utf-8')
    total = value + len(text)
    return total

def _гЙЛсЪаЛя():
    value = 636322
    if False and True:
        _dead_7089 = 455
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHb+N0kszopUHySF3magOy4t6X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΖьоΗШКλжЩлξби():
    value = 933500
    text = __import__('base64').b64decode('akhMSmN6YzhXMXYySUlrNVNkMHk=').decode('utf-8')
    if False and True:
        526
        _dead_2817 = 113
    total = value + len(text)
    return total

def _дαЛΞТωмГыΜЦ():
    value = 320352
    text = __import__('base64').b64decode('RldZOHdqd1NObTRFTVdmZ21Fd0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮыΤОЙМΔι():
    value = 334109
    text = __import__('base64').b64decode('cEkwNnhHeDJoSmlTZVFtbzVMMGE=').decode('utf-8')
    total = value + len(text)
    if 14 * 62 < 0:
        pass
        _dead_6247 = 314
        pass
    return total

def _ОςяЛдγχπуΜΓΜυрА():
    if len('') > 0:
        pass
    value = 221196
    text = __import__('base64').b64decode('ZW5DcFE1ZFAzOXVZY0FSTWRfODI=').decode('utf-8')
    total = value + len(text)
    return total

def _НхннюзΟкΥРмΛ():
    value = 839717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwqzRWk2/KUWLgD123W6MQsQslg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 92 * 20 < 0:
        _dead_4651 = 911
        363
    return total

def _ъΚжфγЩЯн():
    value = 189011
    text = __import__('base64').b64decode('TnpSNkYydnBSd2JVSXc1dDFFeFk=').decode('utf-8')
    total = value + len(text)
    return total

def _СΞΒμξЯλэЩчΨΟ():
    value = 880532
    text = __import__('base64').b64decode('WG4yTDJKTmhVeU85V3JmU3RfUWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ПКλдбеΘФ():
    value = 564607
    text = __import__('base64').b64decode('V0VVcW5za1NxTDJ3bzhkU25zMkU=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ИψГКеЯиМυοбλχΤ():
    if 90 * 26 < 0:
        _dead_5821 = 151
    value = 205772
    text = __import__('base64').b64decode('anAybHZSdmZSTXllVmVrYlREdmM=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 48 * 22 < 0:
        _dead_7431 = 271
        820
        _dead_6299 = 116
    return total

def _БΦлОдΟМьгΙ():
    if False and True:
        pass
        pass
        pass
    value = 527077
    text = __import__('base64').b64decode('aTM2RTFkS1RUTElPVFJ2aGJQZHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬПоОβЩчмУМσюЯУΗφ():
    value = 628534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwbvRXIbwaAnNzfw8megDX0i8GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΧΩЩЛАйДЫы():
    value = 982413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiDcZGsc2o0xbAvxwn6HGiQk7zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬпΔЪщΓФΔлЗах():
    value = 469377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQjwOFlp3YIkIASUnWWvZDADxUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙтКδΣИжиКπΠ():
    value = 500580
    text = __import__('base64').b64decode('ZWwwYjlGaHZuTzhHT0l1Y2o2alE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨζςЖωΠΙσεθεпρ():
    value = 466658
    text = __import__('base64').b64decode('WHBpQXJqVkw5eHF0RmJXRGdPUWg=').decode('utf-8')
    total = value + len(text)
    return total

def _убΧяСΑυΚρрчтДгτ():
    value = 909862
    if len('') > 0:
        pass
        pass
        _dead_6099 = 434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhnKPHMt/bsvHhatyW6UbQ0e5kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΦэфбдΒΕβв():
    value = 252030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDzUPnYB9ftXLw2wn3WvHg8B728='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΚιдοζбзЭЭΠдИЩ():
    value = 643261
    if 70 * 51 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgTKa3UO7ZwiHwGK+lmWDDYW/kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σяУΘЦΘΘНунэψзЯΕ():
    value = 547734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3zOfm46qJEgbSmE0F+CZXIL60o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΘЖДφοκЯр():
    value = 999420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyfDRWAg2Pg1DRmxzFrBZig/8lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        73
    total = value + len(text)
    if False and True:
        _dead_8878 = 734
        _dead_5503 = 386
        270
    return total

def _шуцςЫнТяμр():
    value = 704498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHjcN1kQraYBOFaPmXGcZgEE1z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7398 = 601
        _dead_3423 = 423
    return total

def _уσцΦΔМТцПΠΡΘψαη():
    value = 212535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBjGaFAUq4A8NFyR+3meGgk283Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кбкзфЕςΗηκ():
    value = 916524
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSj9UQQx7L4nNCWq2neJFjY9t0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςμосΘхьЯияЯΘΓ():
    if False and True:
        pass
        28
    value = 71788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PznLVgkhzrEQHBvw6XS4BzE+3ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        116
        860
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _λйσЦЧпыЮнНΣ():
    value = 331759
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NADSWlMv6qMHAi2Fn3eXGDQMwkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        362
        _dead_6730 = 883
        179
    return total

def _пхКхΣχщивДъыФЫЩ():
    value = 242195
    text = __import__('base64').b64decode('VWZwYWhVelRwbDlvd0tQWVUwT3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭοюΡαПΛНγЛМ():
    value = 220264
    text = __import__('base64').b64decode('WEo1TmVwTUNqVkV5YzU0aG9HY2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠοφΦωΚщП():
    value = 194853
    text = __import__('base64').b64decode('V2VGZEFsU2gxRjF3RWl1bEZqY1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜβΛарюСчдшζυКых():
    value = 742649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jgb2RwIczbINLgasmVmjbXcs000='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОρΒτΗыψΛфψ():
    value = 438474
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3/Ha0tqxo8uMCWm/lymDAI39F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΛОιемЧцΨΩНΛγ():
    value = 406561
    if False and True:
        288
        979
    text = __import__('base64').b64decode('WlpNZDY1YzU5NzZOellYUndTeW8=').decode('utf-8')
    if 9 * 93 < 0:
        pass
    total = value + len(text)
    return total

def _ЮΑьνΥОъцКУ():
    value = 327459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3bOeVwY1akZGTCJxE++FQgs7Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цыΑОηфЗаеХΘιΡ():
    value = 230977
    text = __import__('base64').b64decode('eGR0MnZIQnFIbnc5cHUwcWhDamg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        126
    return total

def _ΖмЩвЕсφΙΤыЯ():
    value = 390534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQ3cOWQMzJcFbCn0nnSxETwf7T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        727
        pass
        121
    total = value + len(text)
    if 70 * 19 < 0:
        pass
        961
        _dead_4827 = 467
    return total

def _тΨδщаΛКГЩψ():
    value = 970279
    text = __import__('base64').b64decode('a2J0YVh2RW1QQnJ6bVoydERwekQ=').decode('utf-8')
    total = value + len(text)
    return total

def _τВββэйдАЧ():
    value = 569533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH/iQHUY7/4yPjmnxHigJxYs3EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛψΙФΒщξмьпΙцπЕ():
    value = 549819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnvJflIqyphWFwuC3lS5ZQgq5kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΡсωТΒмοИХдΤ():
    value = 461522
    text = __import__('base64').b64decode('RGpYb0Z3aExBUU9GWUt5cHdGbDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ПεОйζгсΤГб():
    value = 665376
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXvWRWY/2/9RLjqR7E+WHnx49EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χЫξИΚМИΟсνЕΔжΙ():
    value = 643234
    text = __import__('base64').b64decode('Z25iY1ljajlTUWw2Nnd4ZmUwSnU=').decode('utf-8')
    if 24 * 83 < 0:
        pass
        837
        217
    total = value + len(text)
    return total

def _ΒшιЗδТТиЮМГЕчσк():
    if 41 * 44 < 0:
        pass
    value = 661886
    if 16 * 60 < 0:
        pass
        _dead_5766 = 560
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz/pS0hspr0tKF+590CKJQwVxzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        464
    total = value + len(text)
    return total

def _ОκΣзвьΚву():
    if len('') > 0:
        39
        _dead_5384 = 164
    value = 166430
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACrRf3402r05aBXx+AO4HAg63k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9248 = 619
        _dead_5813 = 609
    total = value + len(text)
    if 60 * 95 < 0:
        251
        pass
        240
    return total

def _ΕмιДЩΧΞОΧА():
    if len('') > 0:
        pass
        14
        780
    value = 652306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHjzWUAT6aMsLSWVzA6kEQYGynk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 6 < 0:
        pass
        975
        535
    return total

def _χнТаХΧΕυιспεХΩмζ():
    value = 855713
    text = __import__('base64').b64decode('aFROa0F1VElGMk9PNTA3VEpDUVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥТвбЮΧβΡбЕΦЛΡЭ():
    if False and True:
        pass
        pass
        785
    value = 110375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag3xfXRq/awTOxqM8FPCOggm12s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        648
        _dead_4117 = 334
        878
    total = value + len(text)
    if len('') > 0:
        610
    return total

def _ЖЕСщσюΩΣΖθФЪ():
    value = 574977
    text = __import__('base64').b64decode('bkR2WjFXdFE3M0p6MG5rUkdOdGk=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_2250 = 443
        _dead_2561 = 496
    total = value + len(text)
    return total

def _τΑЭΚνЬИΖ():
    value = 747667
    text = __import__('base64').b64decode('aGtla0VmNUt4V09UR1BPX0gwR04=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ижвХХкΟлХкЭΟοΤΛ():
    value = 951488
    if 28 * 74 < 0:
        _dead_6318 = 435
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En/FaUkj67xaOVuaxXGRLQcH0zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜцΞυъψΕжч():
    if len('') > 0:
        _dead_9605 = 235
        pass
    value = 252646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESfWf1Mo0fAzaQSXm0OTACN/00E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9042 = 162
        421
    return total

def _ΓЩЭэьΩрζξЭμθ():
    value = 166876
    if False and True:
        _dead_2674 = 754
    text = __import__('base64').b64decode('S0hBMXIwN0duZ2hoN0lHN1UweEU=').decode('utf-8')
    total = value + len(text)
    return total

def _οςИуЬξοΘЪΧфΠΤξ():
    value = 711433
    text = __import__('base64').b64decode('cVFSeVRBQm4wWlJqcURQdzJ6V2Y=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _РΠΛчХЭηюКкн():
    value = 117600
    if False and True:
        727
    text = __import__('base64').b64decode('VFNQZ080TG1wNHhISGN6Z3hVaGU=').decode('utf-8')
    total = value + len(text)
    return total

def _зОηЮияЦμμьЗ():
    value = 434127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCfNYgBp76wNGA2z6UKSPzZ/1Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВВДМοφъγкπ():
    value = 447800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fni2UUcR66orECCU6nyxbQklw0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θшеαйΩнΦгСАΥоωн():
    value = 521620
    text = __import__('base64').b64decode('ZFdTNnFDZlBuMXVfbWdiemJUdlY=').decode('utf-8')
    total = value + len(text)
    return total

def _οΙтπΡοэαΝΔμфθиΜю():
    if len('') > 0:
        543
    value = 892119
    if False and True:
        _dead_7273 = 723
    text = __import__('base64').b64decode('SlV1dmtYWlZaX0hZTGxiVzg4ZzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ьтуυМйОЗоδτ():
    if False and True:
        pass
        573
        pass
    value = 326779
    if len('') > 0:
        785
        812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3vQPmM966Q1CDb28UCYDBwX5zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 4 * 9 < 0:
        pass
        _dead_6252 = 24
        273
    return total

def _бУμΥвΑпА():
    value = 993230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSvTTF0GrvonKC2P5mOAJxQO8EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 73 < 0:
        918
        pass
        pass
    total = value + len(text)
    return total

def _φΡМΜмЩνюμсж():
    value = 394943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCSxZ3ke679aP1iczUC7CwADwTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΠΣПΜЦщюлаС():
    if False and True:
        pass
    value = 917291
    if len('') > 0:
        981
        787
    text = __import__('base64').b64decode('R254eW92bHBwUUE2eElQcEIwUGU=').decode('utf-8')
    if 38 * 57 < 0:
        _dead_4018 = 213
        _dead_4272 = 24
    total = value + len(text)
    return total

def _ьβЮωЭεъбаΜ():
    if 37 * 90 < 0:
        pass
    value = 746705
    if False and True:
        725
        pass
        pass
    text = __import__('base64').b64decode('VEJta3p2WkVJTllJVE5zSDZmNDA=').decode('utf-8')
    total = value + len(text)
    return total

def _бциγλБАδИζεСΔΛυ():
    value = 70091
    if 53 * 48 < 0:
        80
        59
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCztPUErp4MEaxy60nyjJgE7/Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πρпщΜЧыΨΜПΑΕβιыΖ():
    if 36 * 74 < 0:
        pass
        _dead_6412 = 653
        849
    value = 404101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQPGOUMz/a4XNg6gmVGUFSsk5k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        575
    total = value + len(text)
    return total

def _ΑжΧΨΟмХАοБЩБ():
    if len('') > 0:
        145
        550
    value = 511608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3rAaGgJ1rBWHjymz1yeISAZ1Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        707
        _dead_9744 = 780
    total = value + len(text)
    return total

def _ΚωРΑЧπςЯΨ():
    value = 200522
    text = __import__('base64').b64decode('Q29ZYWpuQTJkVUU5cGt3d0liVzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _γБЯΓΜшΟρчЮψ():
    if 97 * 16 < 0:
        pass
        pass
        458
    value = 655973
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('bHVYYmtUc3hBYVdmQjBvaDdmTDQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        448
    return total

def _ΙκρжбЫηЭБъφмЩΟЩΩ():
    value = 116669
    text = __import__('base64').b64decode('VzlXZjZIbUNFdVMzRlZBNHJlR0g=').decode('utf-8')
    total = value + len(text)
    return total

def _σфЩЬπΚΝТΞςμΙζ():
    value = 863578
    text = __import__('base64').b64decode('WFhoejluRER1cmRhQjZnZTRzZkQ=').decode('utf-8')
    total = value + len(text)
    if 96 * 65 < 0:
        _dead_6457 = 309
        _dead_4744 = 487
    return total

def _АЮфрйщΜЦδΨыθТ():
    value = 812547
    text = __import__('base64').b64decode('YmdEWkhVSktkdXFfYmdUV0p5bGw=').decode('utf-8')
    total = value + len(text)
    if 53 * 57 < 0:
        pass
        635
    return total

def _пгβьЗМβαΚυУΞаэ():
    value = 65723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCXXWQc18f4tDgXzmkzGMnwL90Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΔЖμбογΩтВζлΡ():
    value = 126699
    text = __import__('base64').b64decode('SkxwT1lfREdEMXdvTTJ4SHlUOXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _БцЬОбЬνΧьхμυΨς():
    value = 815118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBXAZH0j0IclbRaM8H6YLAF9/HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЬγτЯςαΓЫ():
    value = 773903
    text = __import__('base64').b64decode('VkxLYlo2OUJicHBYR0IwczJQbEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ρφωщσШГΖмЫтл():
    value = 457944
    text = __import__('base64').b64decode('QmZjU1hLWm1lbHNjSzhMa19Cblg=').decode('utf-8')
    if False and True:
        998
        777
        607
    total = value + len(text)
    return total

def _пΙΩЩιЦЕЮψβη():
    if len('') > 0:
        117
        _dead_9155 = 372
        _dead_8102 = 601
    value = 120108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jnbha0AX0v02bVmly3nIOwwI0UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЛЕΡХΛнеРΞщБаτШΜ():
    value = 670236
    text = __import__('base64').b64decode('eXBLaENSWWdJSjUwazl0SW9fbFU=').decode('utf-8')
    total = value + len(text)
    if 77 * 5 < 0:
        _dead_1692 = 796
        853
    return total

def _ΦεИъфоЯυДηΕΤΒ():
    value = 879259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FH/CT31v3aMrMhWAn1WhFx06sE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρяшΝΘΚЪДЧυΛыΑ():
    value = 429495
    text = __import__('base64').b64decode('SU1mQWZvOEg5WVhUTVhPdmtMOFA=').decode('utf-8')
    if 1 * 37 < 0:
        801
    total = value + len(text)
    return total

def _υΓοигхмρ():
    value = 89828
    text = __import__('base64').b64decode('Vkd2aW9pejdTcG5VbVpQZ01RMlE=').decode('utf-8')
    total = value + len(text)
    return total

def _йяΨЗВмΟΠмЛШΙΟ():
    value = 462332
    if len('') > 0:
        489
        _dead_2034 = 159
        pass
    text = __import__('base64').b64decode('UnZvWWlKVXRNTzF6ejVvWFhqZFQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        217
        710
    return total

def _фжрЮфДцжчΛфυааЕΩ():
    value = 722075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyP1QWJg9LgJbi368VKxJXAJwns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7799 = 446
        _dead_8324 = 446
    total = value + len(text)
    return total

def _ЧξФΓαШГΙαВΙн():
    value = 992766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzzLTFRv5KIuPAOp2lDGP3QO0jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΑσоСΟеΟΞныЬ():
    value = 927964
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CR73ZnAt2ZclGQW22HmkBwY10F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΣΖшяυωΩф():
    value = 141196
    if False and True:
        _dead_2458 = 758
        631
    text = __import__('base64').b64decode('UmxwTDlyalFlV1ZSazJZeTZ1ZEw=').decode('utf-8')
    if 85 * 13 < 0:
        20
        _dead_9636 = 134
    total = value + len(text)
    return total

def _ΥЗΨΗвдΓПрα():
    value = 874195
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhDFR1Yd+qMkbwiZ3ECvBxcl4Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЪРКЖΕλД():
    value = 838318
    text = __import__('base64').b64decode('VEZuUFNpd1AxYjRnRnAwd0xiRmw=').decode('utf-8')
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _μзαξВдοψ():
    value = 716697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCPhd0YV+6MZA1bx2AaHATc980c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЙωΘэυθтεэ():
    value = 917892
    text = __import__('base64').b64decode('ZjNHc1V2V3Iwc0Y1RWVCcVdkMVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΤΞθдЭНЖюΝαЕНы():
    if False and True:
        pass
        pass
    value = 297262
    text = __import__('base64').b64decode('WGJyN2FHV1lWbVh6cTNydGRfRmo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8929 = 387
    return total

def _КοΝЦЬяМΝ():
    value = 191717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzvGaAET56pWKTaoml2cExEJ620='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜпΞΨκУπАΗΗоГ():
    value = 608789
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSLQO0UU2rE3D1+7nA7GPDMF71k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()