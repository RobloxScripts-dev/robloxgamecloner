#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _χВмωΔΚβΣΨН():
    value = 301182
    text = __import__('base64').b64decode('aDJQeU1GOU50Y1RjNGxuVnl6YUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _КлМРηοЗщωр():
    value = 39697
    text = __import__('base64').b64decode('Q2c4eFZxcjNvSXRqdVdDVzNXbzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧъΝВРωΨучθмΦУШ():
    value = 603206
    text = __import__('base64').b64decode('RlV3V2ZDZEJ5ZUVMQlhxeFF6TEY=').decode('utf-8')
    total = value + len(text)
    if 58 * 97 < 0:
        pass
        157
    return total

def _жΥηрδЗΞетй():
    value = 164951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXrvRnMzyIILaD/74FXAJzIY8Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЙШЖβеЕйИΞ():
    value = 583863
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NirQXloV+bIvNQOw0gOREiEj3V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЭДΗПΤΩςСЪыκфЗ():
    value = 532270
    text = __import__('base64').b64decode('QjJxWXVpdm9HX3N0RWtDUWhwUDY=').decode('utf-8')
    total = value + len(text)
    return total

def _μαδщυΗβЮхкΣЙРжφШ():
    if len('') > 0:
        345
        388
    value = 44291
    text = __import__('base64').b64decode('Y1hmaVBfbGNTbmY0d1RWOXpuQzU=').decode('utf-8')
    if False and True:
        pass
        964
        pass
    total = value + len(text)
    if False and True:
        354
        _dead_1412 = 913
    return total

def _ΞτΑУΗКΩιннΖхЮкΓ():
    value = 677751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD+wSUc0xKw5aAaOn3+zZAkeymE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΙΘзкΙΥУЭβмβΝσе():
    if len('') > 0:
        pass
        pass
        182
    value = 755389
    text = __import__('base64').b64decode('dUx1QzVrdG5XeFpBNjdQZ2g2RDU=').decode('utf-8')
    if False and True:
        pass
        _dead_1460 = 4
        305
    total = value + len(text)
    if False and True:
        _dead_6303 = 664
    return total

def _θυЬΑВЕγогыЪιαХ():
    value = 815310
    if len('') > 0:
        762
        708
    text = __import__('base64').b64decode('SUk3VjhwMUhMU2k1Z3lrdFBsV1U=').decode('utf-8')
    total = value + len(text)
    if 80 * 93 < 0:
        704
        _dead_2036 = 327
        _dead_5042 = 875
    return total

def _пцмехУχА():
    value = 508376
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiXQaHct7LtbHVqS62PCGBAQ8lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7939 = 624
        242
    total = value + len(text)
    return total

def _яγИбΔуΘΞ():
    value = 147889
    text = __import__('base64').b64decode('YVlKejhVTGlUSlhLWUdGWWNlcWM=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3168 = 414
        pass
        58
    return total

def _ΧЛйЮЬчνхР():
    value = 126655
    text = __import__('base64').b64decode('YzdCb1d1THF5OVMzUXRITFNDU3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖзПΒΠТΘφζЦΑθεе():
    if len('') > 0:
        _dead_2684 = 747
        pass
    value = 320125
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARb+Q30c2r8NHQCK4HqlPXYM9z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        695
        pass
        _dead_6668 = 152
    return total

def _ТωПТуΜЬωΕ():
    value = 16551
    text = __import__('base64').b64decode('bFVzTFdfVFlnY2ZLb29weUY4VXA=').decode('utf-8')
    if 75 * 9 < 0:
        _dead_2230 = 597
    total = value + len(text)
    return total

def _ΘσГИдГЩι():
    value = 13152
    text = __import__('base64').b64decode('YXhuQ0VvSEFGMUxnVXptSWR2aEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕзнΩИΔаρΟ():
    value = 661398
    if len('') > 0:
        _dead_4353 = 27
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRi9OEEa5v1VCT6o/l6CMSonyEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 43 * 18 < 0:
        pass
        pass
    return total

def _ΗкΕθЕФρъξλЧдЬнЭМ():
    value = 199463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgrPYEkf3JIGFj6341yjMgl8yGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΥζΞждδЛбУ():
    value = 196622
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQrcWEkM34IBPCGZz3OzHXMEyW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΙρДбыΞΛ():
    value = 529923
    text = __import__('base64').b64decode('cFk3MXo5QXBROTg3ZDFZTEJkaUo=').decode('utf-8')
    total = value + len(text)
    return total

def _хιΨβрТеξыΖ():
    if len('') > 0:
        pass
        _dead_2738 = 721
        pass
    value = 860283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACzPWwRu+Y02LieszlGhP3Us428='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φЮЧΦКйΥβΒζΔΑκъхШ():
    value = 399679
    text = __import__('base64').b64decode('eHpaYURjbGN5aGtqQjlBZkJyVno=').decode('utf-8')
    total = value + len(text)
    return total

def _ОТПЖμСББηк():
    if len('') > 0:
        pass
        pass
    value = 673530
    if 87 * 53 < 0:
        pass
        356
        _dead_3900 = 670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCrPT1QPxp4wDl6z91mvGDIG6lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЙЙРγмОФε():
    value = 167831
    text = __import__('base64').b64decode('c0RJbXRaMG81Uno0REx6amhnbkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ρλΙηΤζщх():
    if 21 * 40 < 0:
        pass
        _dead_9095 = 799
    value = 977715
    if len('') > 0:
        824
        pass
        pass
    text = __import__('base64').b64decode('QkJUbXYwX0JoSF9XcFZVckR3NG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ιασдШЫЕЧΛ():
    value = 699403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBbIbVUV0f1RMQma8F3BEAkp208='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 71 * 99 < 0:
        _dead_6633 = 671
    return total

def _ДЯτэцμΦеЭΓРΣгКТч():
    if len('') > 0:
        pass
    value = 254552
    if False and True:
        765
        28
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExDsb3o4r6EMbiGPx1C2LhEl4UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΛχкδыΜд():
    if len('') > 0:
        pass
        pass
        413
    value = 744723
    text = __import__('base64').b64decode('ZkppSHhuUkF1c1VSOTNVQlV2VTk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8573 = 450
        612
    return total

def _НТФоαΡрξκэуθΡМΕς():
    value = 983455
    if 26 * 22 < 0:
        230
        989
        _dead_4186 = 644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAjJd3MQ36U1HQiK3Ua1PHA3xkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΥαжоΘβΙ():
    if 6 * 22 < 0:
        pass
        _dead_9763 = 525
    value = 649207
    text = __import__('base64').b64decode('R0lTbWpNQ3RNVFZ0VnMzd0tLYmc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9187 = 332
        _dead_4983 = 859
    return total

def _ΜγнΜωЦχΣнарφοΤλ():
    value = 735956
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnvuWmkd2P8JP1+GkFm2ZDN7xlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚЦПσВюХΧΨΓ():
    value = 521491
    if 68 * 33 < 0:
        _dead_8134 = 650
        _dead_8802 = 776
    text = __import__('base64').b64decode('aFdWYWlRQ2ZPenFqTHg1V3ZOajE=').decode('utf-8')
    total = value + len(text)
    return total

def _φЧΦΧπяΒΡπψ():
    value = 375924
    text = __import__('base64').b64decode('WEFTMVdxWUprdlJlMVh3eVhFSTc=').decode('utf-8')
    total = value + len(text)
    if 42 * 14 < 0:
        _dead_2365 = 752
    return total

def _ФОоλΝΥткл():
    value = 834815
    text = __import__('base64').b64decode('WWI4VHBNckxSMl9ZU0VkTkVVVGc=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_7692 = 12
        _dead_4018 = 366
    total = value + len(text)
    return total

def _рСдφНπБΚΥ():
    value = 802519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AATLPHY79LgBIgiI4UeeZTZ31kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 22 * 64 < 0:
        _dead_3179 = 954
        _dead_1582 = 676
        849
    return total

def _нКмЪβхТμПЖйΓХγ():
    value = 90655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjf+Q14J+oYPHCmB0HjJYQMq3Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        550
        868
        _dead_9911 = 451
    return total

def _ΔРнХЖСψйРΨИЗα():
    value = 348592
    text = __import__('base64').b64decode('T0ZiYXQ4WTNuVWV3UHlyZ2NHZ1g=').decode('utf-8')
    total = value + len(text)
    return total

def _мШщζхвфχмπЗжΖ():
    value = 685091
    if len('') > 0:
        pass
        _dead_2318 = 263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lzrnf1oDyJgBIDus/HeFIjF/8jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 30 * 99 < 0:
        pass
        _dead_4721 = 131
        _dead_6986 = 469
    total = value + len(text)
    return total

def _ΨΓАκεΗфзΑхЧΥ():
    value = 7963
    text = __import__('base64').b64decode('WmlOYktHUVZMTnFwajdHaDhGWEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ιлрЩИГьЩΛл():
    if len('') > 0:
        pass
        652
        _dead_1075 = 42
    value = 644792
    if len('') > 0:
        517
        396
    text = __import__('base64').b64decode('cXpjZ2V0cDBTanc2c0ZEak95WUg=').decode('utf-8')
    total = value + len(text)
    return total

def _вАВОΡΞφρ():
    value = 92255
    text = __import__('base64').b64decode('QlRPV3Rob1d3ZmQ3NGc2QmdOM2Y=').decode('utf-8')
    if len('') > 0:
        856
        _dead_9322 = 973
        pass
    total = value + len(text)
    if len('') > 0:
        785
    return total

def _саЦаΑячЭβΩΦΙхББδ():
    value = 896707
    text = __import__('base64').b64decode('czkzNldtTVp6b1VYOXB0RzhmcFA=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_1361 = 416
    total = value + len(text)
    if 14 * 56 < 0:
        _dead_9039 = 95
        659
    return total

def _ΘПΥΤΥБВΩΒь():
    if len('') > 0:
        835
        pass
        pass
    value = 56026
    if len('') > 0:
        752
        714
        476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHn0T1U6xKMMIiGJkFOpDHYFtlc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΑΘЖчΧЕλφяеΗИГ():
    value = 18792
    text = __import__('base64').b64decode('anY2N2dlOEI4WFF1dWR1UmtxSF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ПνθмджояцжΔэЫ():
    if len('') > 0:
        _dead_6208 = 116
    value = 102982
    if 45 * 64 < 0:
        522
        823
    text = __import__('base64').b64decode('eEZtQWFjZkhUZW9aOGdIQ0FFOUo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1681 = 343
    return total

def _ДрЛЗъδλлЫяνг():
    value = 515781
    text = __import__('base64').b64decode('YmNxeW95ekU2OG9NSUdmNmxmM1E=').decode('utf-8')
    total = value + len(text)
    return total

def _АЗΘДЯξЖЛδΑΩΓчЖХ():
    value = 35274
    text = __import__('base64').b64decode('RWRCSndPZVBzcGFvU2RoMUt0dHc=').decode('utf-8')
    total = value + len(text)
    return total

def _иМΔПΛИρШΕςЫнеχНЭ():
    value = 783591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgnHVEA4/P0Oawj2nVmXMxAs/EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 42 * 15 < 0:
        _dead_9416 = 173
        555
    total = value + len(text)
    return total

def _ΚωηмвΤКΝзΩ():
    value = 283705
    text = __import__('base64').b64decode('a3JqRFc2dnJlaEd5ek9IdWozQUo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _βΜΥκТюЗыΝКъМХж():
    value = 635754
    if len('') > 0:
        pass
        _dead_6305 = 429
    text = __import__('base64').b64decode('alVWUFhXTW84SW1JNnZVRTFKc1c=').decode('utf-8')
    total = value + len(text)
    return total

def _κρΗяюηьβЛγсσξи():
    value = 944068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwLbPGsMyrAEEAKhwl/FMSAXtX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 76 * 49 < 0:
        pass
    return total

def _ΞАНйъшюΤэρКБвнζО():
    value = 961438
    text = __import__('base64').b64decode('cGRWc0I2QTBsX1hEX3pKRjF3ZGU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΓСΙюιаъйΒНцожЕΟΨ():
    value = 422806
    text = __import__('base64').b64decode('c0xCX2draWJ1OTlQMU1McGkxS2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯςОеκΣςπСзΖ():
    if 63 * 32 < 0:
        pass
        pass
        77
    value = 614972
    text = __import__('base64').b64decode('aURmRXZfcENTUW10WkM1SjY4ZHc=').decode('utf-8')
    total = value + len(text)
    return total

def _эρеЪφПфΠΠхМαхЪТ():
    value = 731805
    text = __import__('base64').b64decode('YUZIVW5TN2lCWlY3XzZGNlN5cmI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟαНΜОАΔьβщΛαΥп():
    value = 129820
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR6wO1890J5aLA6xkVS8PjEj71g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыμбЙЦωΥФВо():
    value = 852107
    if 78 * 34 < 0:
        726
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzvGdmYP9/ALG12C91WTYi074Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9877 = 614
    total = value + len(text)
    return total

def _еЪЖΘщΓΠΝφΓ():
    if False and True:
        pass
        321
    value = 56500
    if 1 * 59 < 0:
        913
        pass
        _dead_8711 = 258
    text = __import__('base64').b64decode('a1kyNTQ4MFl4ZHNEOUJXVmtoTko=').decode('utf-8')
    total = value + len(text)
    return total

def _ыъςπмΕЦЬηΗУ():
    value = 980546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHjmXn8W+bERLCjyzgWiMTcH0WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νяλаΦμЗЬΡьΛ():
    value = 810189
    text = __import__('base64').b64decode('Vm9BVVlfWFlkenpSTUVQR1ZUYnE=').decode('utf-8')
    total = value + len(text)
    return total

def _жЪоаьΗОчКηцЧеςъ():
    value = 820605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwvoR3Uo3aEtaSb16QSfFSYItE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ЙδдδΣφФΓδι():
    value = 332047
    text = __import__('base64').b64decode('STlzVUlMQzVYRllQV3RnM2lReWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔЕэъοχαэРλΗ():
    value = 256095
    if len('') > 0:
        348
        _dead_5098 = 176
        _dead_5684 = 655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lgf9X1UX/6YzaCn7+nSdCxU2wXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        707
    total = value + len(text)
    return total

def _ЗυуΤΝΑЭΥΑανЬл():
    if False and True:
        pass
    value = 640761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwfVPH828/8EMRX6wnKhB30920k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟСФфЦψΞЪΞоТц():
    value = 342878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETr0YVUSzpgkIjCCwEKqPxUlyjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        155
        pass
        873
    return total

def _ЫОЛаπЧнαψ():
    value = 7804
    text = __import__('base64').b64decode('VkFUX2luNUVJSjIzM3RVbUlqVFc=').decode('utf-8')
    total = value + len(text)
    return total

def _укщхΗсЩЩη():
    value = 440651
    if len('') > 0:
        889
        563
        695
    text = __import__('base64').b64decode('bklvRUc5a213YWNUMGRwU2psa20=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        336
    return total

def _ΥΡΡΓкΧФιипχΞΜ():
    value = 150758
    if len('') > 0:
        899
        pass
        _dead_7251 = 741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dingd2Ue66ciOVaTngSfDBM9slw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фяБЧхизΚрΤпΡβГ():
    value = 3136
    if False and True:
        659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwnbbV4VxPAUHRiO4FmBY3AK83Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БηюφΜςфАЯшД():
    value = 425371
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXbNQGEa/I4WOFaVwH6+AA833j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘρΤпнΟвМΧΟτΤπХтю():
    value = 98441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgflNlwQ7ZE7Gyuw/VC7PnYW1lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΞδДΛлсетΠ():
    value = 845992
    if 67 * 12 < 0:
        709
    text = __import__('base64').b64decode('ajl4Y3c5eHRuNXY5M2JEaDNBMlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΣЫгвТΝЛεхаб():
    value = 652708
    if False and True:
        11
    text = __import__('base64').b64decode('Zm5fdVBqZjRGVnNDemJXdE5SX2U=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        100
    return total

def _Ωъмηъγφэ():
    value = 103273
    text = __import__('base64').b64decode('ak5JM0R4enJKa2FmaV9va0F0OHo=').decode('utf-8')
    total = value + len(text)
    return total

def _чΩΦШςβгΤΖεсЩч():
    value = 605956
    text = __import__('base64').b64decode('RmltSkdFWDh6STFEYWh5V29SQWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔμΩтθψκλБΒБΝЕδЧ():
    value = 393715
    text = __import__('base64').b64decode('WVY3OXk2SlhfenlFWU9GNVEwZHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣмΣΚνелсДΧъ():
    value = 575237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXa9PkA9yq1VHAWHn2PDJQYH/nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жбчξμωθгКъΕЕБЯ():
    value = 566576
    if False and True:
        pass
        _dead_2327 = 69
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InjPO31h3IJbLC2T/HmDGD96yjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2206 = 197
        557
        916
    total = value + len(text)
    return total

def _дΟЪЯРПОζхβИРΘ():
    value = 545817
    text = __import__('base64').b64decode('eDZUUTNCNWIyWG1FbHRLRGJub04=').decode('utf-8')
    total = value + len(text)
    return total

def _АНЬШкβпшСхъЗΛИЖ():
    value = 617698
    text = __import__('base64').b64decode('c3NTYUM2SGlyeDVLVkdHZW1UMFk=').decode('utf-8')
    total = value + len(text)
    return total

def _бГХвΠэДκявХΙЮюоξ():
    value = 911222
    text = __import__('base64').b64decode('VnJ1ZV83aGM1M0x2R3ZTSzVXeUE=').decode('utf-8')
    total = value + len(text)
    return total

def _бΘθυшужл():
    value = 755851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MADqSQUP1aMXDh6Tm0WgYis44Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βьΦμΑωτИκεф():
    if len('') > 0:
        147
        pass
        711
    value = 694509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQHePgNt7YwzKh+C93ejJncXzk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 41 * 88 < 0:
        pass
        pass
        _dead_9288 = 206
    return total

def _ЕЫΛНδквΖЫ():
    value = 797685
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXz8ZWYyrZ4raiOO2H67bDJ2wUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7307 = 959
        pass
    total = value + len(text)
    return total

def _υυΟщпьοЛπλ():
    value = 21724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgfmOFYwrfArHBaUnkagJDchz2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩνиьЬВΤσ():
    value = 698946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwWxT0Qu94VWMyucxX6aYQA+0Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        759
        _dead_5222 = 680
    total = value + len(text)
    return total

def _υбΙуΙвνйЮжδНΨΚ():
    value = 93760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXi9OUc6pv8SbVaLy1CRNnAr4jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗдθΘθιεζ():
    value = 223183
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgnSZls8rLhaYgeuxnO2O3QV5Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗβНξωΝΩοГзτЩк():
    value = 599071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dib8eVoX+akyNRu24lmbOhoG7WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βпОАсЩЫΜκ():
    value = 575375
    if 24 * 12 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRXWVlM82/kLA1up7njAPjUXzFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_1808 = 495
    return total

def _щοцΖЩδйЙСлЪ():
    value = 365212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ22f3Msr6w1ageHxlybYzE91Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фИуφΡΜЯδ():
    value = 838925
    text = __import__('base64').b64decode('bEN6bmthVGp3QXh5Z1N5Ml82WnM=').decode('utf-8')
    total = value + len(text)
    return total

def _зпЭΖуεЖАьσυΠ():
    value = 176137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FArmaQAr/bErH1aU7gHEJwcW80s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        740
        _dead_5072 = 382
        pass
    total = value + len(text)
    return total

def _ΧχινгλΗШαоξβо():
    value = 561968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzvSdERu0fgZPD2v4gPDPwJ7y0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θхчяξЫΗПχэН():
    value = 482166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NA7CT2cw0YkIHxmEwUbBHyk59E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖσΩΧФаςФ():
    value = 729959
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQTAaF0V0JAbCzeunVuCPgx7smM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡβкωζоКεμ():
    value = 796568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBbxXkgD+Kc7Py2OnwOmJisOvTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 87 * 33 < 0:
        pass
        767
    total = value + len(text)
    return total

def _ЭЪχгχЬрКДжΣаУΩ():
    value = 171322
    text = __import__('base64').b64decode('UXRDOHliM3lWZGVkT1l0bUQ4bUg=').decode('utf-8')
    total = value + len(text)
    return total

def _θгΣъοВфΞшρΩ():
    if False and True:
        pass
    value = 155025
    if False and True:
        _dead_6905 = 987
        pass
        _dead_1540 = 635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiPWamlv8v4GBTyP7FSdEQwL4mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иХΓфяКшъиΞρ():
    value = 147820
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAzGVwkgzJxaChqhnnLBbBIN4j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        57
    return total

def _мγεΛΘУχςнρ():
    value = 848057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3/3QUcVy78IChaJzlKpBz0cwDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΗΠГΨικηοЭъАЩгЮη():
    value = 488747
    text = __import__('base64').b64decode('R1ZoOURCWFB4SjJWV1l4T0R4NUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ПαБΚЗУэΑдЬυΧТ():
    if False and True:
        pass
        _dead_7507 = 984
    value = 754050
    if len('') > 0:
        _dead_7194 = 645
    text = __import__('base64').b64decode('VzgyWnJ5RzYwQ3doODNYdzJpVlE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1984 = 540
        782
        _dead_1345 = 983
    return total

def _ΣщвфэΒδэψ():
    if False and True:
        _dead_1992 = 777
        160
    value = 954037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnbtWWQeyrBXbluK42SANTwq4jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жνбΠАтЯλΓИΗЙфΩ():
    value = 99181
    if False and True:
        529
    text = __import__('base64').b64decode('QnRHc2pfZDFzX3VYVE81XzdoZ18=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        614
        440
    return total

def _кΜДмЗζХР():
    if False and True:
        _dead_4137 = 343
        _dead_4443 = 503
        _dead_3389 = 588
    value = 298387
    if 6 * 88 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyHwP0Rg9qYiMh6BnlWmM3cI1mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡтЬДσфеЙι():
    value = 787822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgPuZVsY564aF1uJzX/IHhAYzFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖιγЯСХГγкΗ():
    value = 266007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwDwWEEo9YBWKSmZ8A6IMTM//nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΧΒΘΠΡοиωшΦВЯΗЪ():
    value = 238489
    if False and True:
        _dead_7766 = 169
        pass
    text = __import__('base64').b64decode('WnYyODFDbGU4dHdkNlN1T1dRQks=').decode('utf-8')
    if 37 * 69 < 0:
        pass
        pass
        pass
    total = value + len(text)
    if 21 * 76 < 0:
        967
    return total

def _ΣДъГΓχцυ():
    if 98 * 8 < 0:
        251
    value = 172640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSLNa187zZ1aaCOI/HmqADUhtFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нιяуДχΔщιТτЯГЯχΚ():
    value = 832840
    text = __import__('base64').b64decode('S25ZVWxlZFV3WU9MOFdaUW93WW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖГмжρцСρχψСδψ():
    if len('') > 0:
        351
        pass
    value = 831629
    if len('') > 0:
        _dead_7202 = 771
        173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3/LR1MpyfAPEQSV0ACeNXUJy0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        356
    total = value + len(text)
    return total

def _ΘσрζОЬзΓ():
    if len('') > 0:
        _dead_8568 = 84
    value = 297703
    text = __import__('base64').b64decode('c01mQXB6VlZNRllHeHI0ZlRFeUE=').decode('utf-8')
    if 25 * 68 < 0:
        513
        pass
        pass
    total = value + len(text)
    return total

def _ΗасΧСκζТУпΗθωь():
    value = 156944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDu1PQdvxLoHPxiv7UGzbTIBtHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΟНεркνΧЦВФсдβιΔ():
    value = 509496
    text = __import__('base64').b64decode('eGNoNjdLaHhUcG9WVkZHZmFfeHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨЕЗηжЪкΞ():
    value = 805455
    text = __import__('base64').b64decode('ZzFkWGFHakgxSFpHMlZhZVVYOG4=').decode('utf-8')
    total = value + len(text)
    return total

def _пψΧцΜПуπЕЫщξДυЕ():
    value = 624613
    text = __import__('base64').b64decode('alFZcFhzaDlwRFl5ZzM0ZFFqYVA=').decode('utf-8')
    total = value + len(text)
    return total

def _πфзмιИΟмΕхΓ():
    value = 832493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgXHe0QJqppWKjy10HLCYTEmsm8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΟΩчτИΑБшя():
    if 30 * 46 < 0:
        552
    value = 587855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRzyS18Aq6EUAB2m70/EJis8/Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        558
    return total

def _хΞΔчуΨΡшуХпΩ():
    value = 466411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3f0XFAdqq4WKQqFmXW8ACsc6EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7259 = 875
        _dead_9910 = 178
        _dead_6284 = 451
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ψβΒΖКΝТελψчЪоо():
    value = 753257
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjnQaQke0Y4lDDWF2gS+LnwKvEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΘЗψΜΝЦοНКΜчπЖ():
    value = 658221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzbXO3k72/03awawwHegJQAe22k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮАфμηοГΛУэΣ():
    if 8 * 37 < 0:
        534
    value = 858236
    if False and True:
        132
        _dead_5204 = 917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHndfFwVxp48PCGZ6g6oNyEn51g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МЯφсМНφыχ():
    if len('') > 0:
        pass
        937
    value = 774332
    if False and True:
        764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwrTS0sG/I5TaRWn3Ae8OTIO0UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        596
    return total

def _РΔъτеΡьоΔζМт():
    value = 254724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxqxbVAL1bI1Mw6Bm2W5LCAa5Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠыЭеΩрξμμмЗωы():
    value = 54307
    if 13 * 38 < 0:
        pass
        pass
    text = __import__('base64').b64decode('WHZLcDRzMVNBU0FuNV83ZjVieVM=').decode('utf-8')
    total = value + len(text)
    return total

def _нлдυΕшΚсСы():
    value = 945158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg3bbF8drpogBTX0y1SfBX0lwzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝδΨΘЮжфЛεоκΝабп():
    value = 426608
    text = __import__('base64').b64decode('QmIxVXFiM21rdXk2bGo1WUkxeUQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3713 = 208
    return total

def _αцУАУψЦПσΑΔБφзоЩ():
    value = 575579
    text = __import__('base64').b64decode('SDI0dXZBZjk4VHFSdlltMmNJbkU=').decode('utf-8')
    total = value + len(text)
    return total

def _шкДжЩкЙсПυвЮКЖвУ():
    value = 947096
    text = __import__('base64').b64decode('VVZIZExPX0tJTGhUaWs2Q1NrZW4=').decode('utf-8')
    if 80 * 86 < 0:
        78
        130
    total = value + len(text)
    return total

def _σвνсЙΧйаилэ():
    value = 865975
    text = __import__('base64').b64decode('RjZHV200aWlRS1pGa2phNldPV2k=').decode('utf-8')
    if False and True:
        pass
        766
    total = value + len(text)
    if len('') > 0:
        320
    return total

def _КеχΡШяжτеГΔжыδ():
    value = 476147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX/qSkkor/wwYgON+HnFEAgdwFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΓρσΞиΓтзщ():
    value = 950147
    text = __import__('base64').b64decode('Vzc1T2lkZ2NvY043YjNwMnZlcjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬъΤμйξАΨхЙъЧъреΝ():
    value = 582061
    if False and True:
        253
        pass
    text = __import__('base64').b64decode('Q3FBM2lYTF9JRWxIdHgxT2N5Ujk=').decode('utf-8')
    total = value + len(text)
    return total

def _ραлнИΗяΝт():
    value = 552732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AS7GVGdgqa8uPgaQzWGoZxAetUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МятрΔπΙΠчτНΠΦΕΘЩ():
    value = 127464
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MATQS2YS044PLyT02Xu1AwA4zG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        236
        pass
        14
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _зαλХξΕьΜпэωъУ():
    value = 681351
    if False and True:
        512
        _dead_4843 = 426
    text = __import__('base64').b64decode('cTcwYW13MU5NOWhDODFWbVVFVmQ=').decode('utf-8')
    if False and True:
        _dead_9484 = 544
        pass
        _dead_2210 = 575
    total = value + len(text)
    if len('') > 0:
        _dead_7525 = 270
        795
        902
    return total

def _зПжЬΥςСΡΩΨЙυчηψ():
    value = 26138
    text = __import__('base64').b64decode('QXlnbnJxVHdMeFp1VkE5SmV2eWk=').decode('utf-8')
    total = value + len(text)
    if 2 * 22 < 0:
        pass
    return total

def _ηКМПιЮαтΩЕв():
    value = 854539
    if len('') > 0:
        pass
        _dead_4707 = 984
    text = __import__('base64').b64decode('WDdqNWczNkZrS0JERGZjX3VtTng=').decode('utf-8')
    if 82 * 42 < 0:
        802
        _dead_2052 = 489
    total = value + len(text)
    return total

def _ЭХхЖЧтΚΘΟКυАαцъ():
    value = 415411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Azr+PUQyrq0UaCL15mKRGDwe82Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 17 * 61 < 0:
        pass
        _dead_1062 = 888
        69
    total = value + len(text)
    return total

def _УуφνγкуЧдΟςцПρ():
    value = 846156
    if len('') > 0:
        325
        _dead_7804 = 623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDfbXQIJ1Y0uOFfz2HKfNQ4rwHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘжШлауΕψбЦΧωЖН():
    value = 719806
    if 57 * 60 < 0:
        631
    text = __import__('base64').b64decode('SmJrZ3VQVGVxRG91OUVzVjZSeW0=').decode('utf-8')
    if len('') > 0:
        _dead_9223 = 337
        42
    total = value + len(text)
    return total

def _φМвΑГηСЙОееβй():
    value = 918456
    if False and True:
        _dead_9917 = 745
        _dead_9552 = 117
    text = __import__('base64').b64decode('YWJ3dENJeXpPMWtyeHd0cDhXWEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦκуЙγВичЪοыяШБΗν():
    value = 109731
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByfiPno2yfkvOR+lw3fJFgcssHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шρчΔЗαэαн():
    value = 419930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyTUVH0z9/xTCxev/X6hPCk20Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΓΟΗюфφωЬΖχ():
    value = 973799
    text = __import__('base64').b64decode('dlU3UTdhSDBMamRZOGEzcVJHSmw=').decode('utf-8')
    total = value + len(text)
    return total

def _шδЦδЭФθμКФ():
    value = 824339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiDLREBr36JaPQGQ33WADXAGzFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςμОШРЫΨσΑХцΙ():
    value = 523769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTfRbWM9q5kMNRiL5HG1DjMk/EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠЫФΠОьбυнВΕщΡΗοβ():
    value = 966556
    text = __import__('base64').b64decode('bmlGeFdtamQ1N1FlbU5oTHlheEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩξЪЭЗвΚмыз():
    value = 46478
    text = __import__('base64').b64decode('QnE3Y2cwTm9XVnNhR1U4X0l3dVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡθэΕиΧψВρΙъ():
    value = 572017
    if 13 * 19 < 0:
        _dead_6636 = 26
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCD1SgQAr58yLyCP926DZgkD0UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПИдЮΛЦΚεСΞОЙ():
    value = 12318
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR7tQ1QW84slIxy5+HuRMSgby1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыЕееΥζρАйзσнΕΓез():
    value = 640180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBDQR3wOqbIWFV6JyWG5YAA7szg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔХχβΖИеΤЫЫ():
    value = 152294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn+yR2gv2p40OyCPx3e2HAcs7jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цζгΛтцХτΒК():
    value = 268598
    text = __import__('base64').b64decode('SmoyUEhpNmMxRHo4dG83Ukl2Nk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖлВΗцΩαθВЗю():
    value = 408803
    if 40 * 61 < 0:
        725
        _dead_4296 = 412
    text = __import__('base64').b64decode('RndlTEJzVk1VQnVFbWVRU1gwb3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΨδзχАыНППджэΕ():
    value = 324148
    text = __import__('base64').b64decode('cUV5X1N2dDFkVndRR3pxUGxFQUQ=').decode('utf-8')
    if False and True:
        774
    total = value + len(text)
    return total

def _юЙИβΣэωЯθδ():
    value = 183340
    if 13 * 41 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQbxZAUW3Zs3Kyqk5m+TFwQE7ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 62 < 0:
        _dead_4931 = 919
        620
        _dead_6510 = 935
    total = value + len(text)
    return total

def _ΒЦδшΠΒεγΝбξχ():
    value = 635490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBvRZEQb27BWbC25xAS4IAcAvDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΙιЦψπвОМΧεΛк():
    value = 248077
    text = __import__('base64').b64decode('Z2FjaGtMR0lmcGtjcE5zaXRHNm4=').decode('utf-8')
    total = value + len(text)
    return total

def _блархоΛЪαн():
    if len('') > 0:
        _dead_9728 = 947
        487
    value = 791045
    text = __import__('base64').b64decode('Q3pJTEE4X0tKaHlFcnRnVnQxbVU=').decode('utf-8')
    total = value + len(text)
    return total

def _цжατелηЯЦяτΘТΔΣъ():
    if False and True:
        _dead_9032 = 454
    value = 42112
    if 49 * 16 < 0:
        pass
        _dead_1249 = 981
        417
    text = __import__('base64').b64decode('T3Jkc2FvaWh4TlJDSUdaSnJVakM=').decode('utf-8')
    if 88 * 93 < 0:
        985
    total = value + len(text)
    return total

def _БдПιηΚФОαйΑΧЛΚρу():
    value = 266645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhXxPEsu/6U2OwGzzVKvJDcBtU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕдСдЫЗУЦ():
    value = 522341
    text = __import__('base64').b64decode('ZGxnUlRyd3ZxTFJ2SHdJTURSaGU=').decode('utf-8')
    total = value + len(text)
    if 75 * 61 < 0:
        _dead_8617 = 393
        _dead_9938 = 263
    return total

def _ЕИΜςОωЖθΟ():
    if len('') > 0:
        _dead_7649 = 901
        654
    value = 94542
    text = __import__('base64').b64decode('aHRRTFRqSGZMM1lVVjVXT0ZrdTI=').decode('utf-8')
    total = value + len(text)
    return total

def _θεγЙХφпФы():
    if 5 * 30 < 0:
        pass
        pass
        pass
    value = 211421
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('ejJTTjVTc0paOUMyeDZpUG1SMWk=').decode('utf-8')
    total = value + len(text)
    if 54 * 78 < 0:
        pass
        368
        pass
    return total

def _пйЛяИΚΑΜοщфσЬΛ():
    if len('') > 0:
        _dead_9555 = 597
        594
        pass
    value = 851745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ci7oYXYxyL0sND7zzXuxZDR6w0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩЛЦΒξвΜΘвКнБнТШк():
    value = 938610
    text = __import__('base64').b64decode('QUs0TW1lWFFhZHJidENzRVdldDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡамπΒуЗξУП():
    value = 791190
    if len('') > 0:
        543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzzmTQcgroRQNl3x4EWZFg8jvTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ВбΟπΤΞΥГΑкΙμКυп():
    value = 205230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IirvQGIz3aEuMxaN5X6YOXQFzlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧαΛрΨφпДРΧ():
    value = 621521
    text = __import__('base64').b64decode('WlNySU90WkZJRVJoN09Dc21ZQjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦБьВΕдлТЩнΗЧΧ():
    value = 810404
    if len('') > 0:
        _dead_8655 = 477
        377
        _dead_4359 = 755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxjpXVoe8Y0VAB2b+gCCMB8E5Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βЛκιτвОФΦерτССψ():
    if False and True:
        pass
    value = 46612
    if False and True:
        _dead_6903 = 266
        _dead_8617 = 781
    text = __import__('base64').b64decode('SFF0MnEwcTVVdFByMmlsaDdLN2I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1646 = 314
        759
    return total

def _λбΒЪδЯяДСиТ():
    value = 407094
    if len('') > 0:
        _dead_6000 = 261
        pass
        _dead_5933 = 431
    text = __import__('base64').b64decode('aTl2NFpNUzYzV0tkc0oxNHh5ZzU=').decode('utf-8')
    if False and True:
        _dead_1515 = 665
        742
    total = value + len(text)
    if 9 * 73 < 0:
        pass
        pass
    return total

def _йρГЧцбχыηκ():
    value = 95771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kwy2eHg75K0JAiWl4UWhYBB/52I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5330 = 242
    total = value + len(text)
    return total

def _ΙэхΟМхэτιψЖфΔ():
    value = 46455
    if len('') > 0:
        pass
        947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwH9XWEo1fobEFyy6w6jbCklvFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 87 * 41 < 0:
        _dead_1579 = 57
        pass
        604
    total = value + len(text)
    return total

def _ШΣЦγМςЫДжпΦεΝЫΝ():
    value = 393235
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhfpYHQS3aAuIjuS5US2MwM95n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оХΛПΑΘавΣμаΖцЭ():
    if 6 * 60 < 0:
        _dead_4578 = 131
        pass
        _dead_5396 = 344
    value = 118229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCu3eWAx5oUxNyuK/HezETI6xnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6664 = 296
        pass
    total = value + len(text)
    return total

def _ДγьвρШΘКΙΣСыςΔψ():
    if False and True:
        pass
    value = 673297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTfFb3Ru+50IDFiTxUCEAAg5yGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        168
        pass
        pass
    total = value + len(text)
    return total

def _ΨΙχκгΡхЩ():
    value = 632065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhrVPlMI84wqGwWz2FvGbSAQ4j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠπΖηΧийΝГηЭНЮсбπ():
    value = 206169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwKyN0E+5qs1bRj7zFWzHQcC6kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΛзЫΧфаβрψыЗΛеης():
    value = 353564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRu1fQQKr606HQG72ESSMRo28jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5817 = 890
        pass
        _dead_3978 = 772
    total = value + len(text)
    return total

def _πтЧКφФШФΙЪн():
    if False and True:
        _dead_4270 = 96
    value = 843911
    text = __import__('base64').b64decode('ejdvdE5DMU9sVXpZaWZ6RzhUMjE=').decode('utf-8')
    total = value + len(text)
    if 40 * 10 < 0:
        171
        853
        107
    return total

def _ТРдсξΦьПλΝεΡαоβ():
    value = 186433
    text = __import__('base64').b64decode('bWRmbF9keUgzcm5KbHJHaXpoejU=').decode('utf-8')
    if 23 * 16 < 0:
        588
        782
    total = value + len(text)
    return total

def _ЬБХЬйτΧЧць():
    value = 883327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXvFT1wQ/JcpF1qV3UCfZBp241o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΦΛвιяхипяδ():
    if 86 * 22 < 0:
        pass
    value = 12807
    text = __import__('base64').b64decode('a1luZlY5TzhGTW42QjdMME1ubGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦπгΨбУεφφ():
    if 77 * 53 < 0:
        695
        pass
    value = 45691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjXcfHcM7Y0FICWZ8H7GDhEn7Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1981 = 26
    total = value + len(text)
    return total

def _СыφРЬбйΓΘыеλΑΚщб():
    value = 294416
    text = __import__('base64').b64decode('WTBIaE5sVlI1elNKVnM4c2ZIUFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('bQ==').decode('utf-8'))
if 87 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()