#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _εьεРТАιДюу():
    if False and True:
        pass
        _dead_9320 = 395
        pass
    value = 630732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQLxRVhqp7ImNyWPkAGgGyAh9z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4387 = 145
        pass
        pass
    return total

def _αЯΨτйВΥΝ():
    if False and True:
        _dead_6453 = 166
        _dead_9444 = 63
        pass
    value = 769354
    text = __import__('base64').b64decode('aGZYQ0tPa01MOTdNYUs0R1ViZmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _МΒуΘНоβΖ():
    value = 584384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg3QNkY8q58kLVyKn0+KDhEh/nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΒХпτςΨΡЙУй():
    if False and True:
        311
        412
    value = 441642
    text = __import__('base64').b64decode('UGc4WkRzZUY2MFIyb3VvR3Rjb0M=').decode('utf-8')
    total = value + len(text)
    return total

def _уАйХТШΤΣй():
    value = 184053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCHoZWYc3fwXLBy1z3WXJjUm62Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЬгΝХЬвжσеЖэ():
    value = 814757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kyvod1QA+YMqAg2JzQGaNwQ7vGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΖчмХЬиЖΤЭйσΣ():
    value = 906439
    text = __import__('base64').b64decode('UFJxV0p5dmhPZkNzRnFuRHpSalk=').decode('utf-8')
    total = value + len(text)
    if 21 * 36 < 0:
        pass
        _dead_5644 = 511
        pass
    return total

def _δнсαАοУНорπ():
    value = 931527
    text = __import__('base64').b64decode('cDk4YktkYUpSUEtqVmt0X0EyWDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _сСХψλЧΝцΞсуьфλжл():
    value = 787542
    if len('') > 0:
        _dead_1676 = 552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fy7SbUIX9YsZCR7yyUO9PXB53jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хтωЧэЧδЙ():
    value = 34987
    text = __import__('base64').b64decode('YThGaGN5WURXX2ZfdnNhQ0prTjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΔЩΚЩУШХЪвУεΛΗΔ():
    value = 864297
    text = __import__('base64').b64decode('UE9XMHZJb0xNeHFwX01EcHZhR2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣфαωАфψэажЧΩкΖ():
    value = 814908
    text = __import__('base64').b64decode('SDhYUWhEdnhyMEFydF93V3RUWDI=').decode('utf-8')
    total = value + len(text)
    return total

def _аΜΚъбзХдНνκΛυχл():
    if False and True:
        _dead_1785 = 486
        pass
        201
    value = 52706
    text = __import__('base64').b64decode('VjZQd3JaUHQxbU9DZld6QTVHMVg=').decode('utf-8')
    if False and True:
        611
        386
    total = value + len(text)
    return total

def _КШуьУΥЭαНхИЬΑΗΝщ():
    value = 395465
    if 85 * 75 < 0:
        pass
    text = __import__('base64').b64decode('eURJeW9HRHJzNEoydXlfU0cwaVg=').decode('utf-8')
    total = value + len(text)
    return total

def _мзлΚτΑгВАΠомд():
    value = 180605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH3yb1Rv14VWCQWakViBECYF5Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 97 < 0:
        pass
        _dead_9053 = 928
    total = value + len(text)
    if False and True:
        126
        pass
        _dead_6493 = 273
    return total

def _ηιΕъΟрσΤэπЦΑ():
    value = 255994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji7yYgkW+7paNymM5kOiDHQF5m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 16 * 29 < 0:
        731
        _dead_7075 = 777
        _dead_7758 = 400
    total = value + len(text)
    return total

def _χβΗъΘЪΔΠдΔК():
    if False and True:
        pass
        pass
        _dead_3684 = 499
    value = 408898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADvhQmsGpp8vPgv07Xm7LCMK42g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лшнцнΓЩΠΧПДρ():
    value = 946870
    text = __import__('base64').b64decode('VWtpdVFCODRfNHMwSkxzeFhyY3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _щσРыКмΓТЧУк():
    value = 539269
    if False and True:
        471
        _dead_4394 = 750
        _dead_4434 = 906
    text = __import__('base64').b64decode('UmZOZVBQTWJDaml6cGRtTTRRcjE=').decode('utf-8')
    if 59 * 82 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _НфΡлЪЩЮЭλθΙРЬЭΦΣ():
    value = 742575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAnCPmgMqIcRMBa73HulbXQV4T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΞнзамΩуСΓΨνъγ():
    value = 742947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnrvSAQe+o1SIAKJmXm9Eg43vGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЛΡпДВьΒκУфЧΨ():
    value = 4515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCTyRAYh1f46YliA/1iVEjUI0UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΛЩσιςρΜчбм():
    value = 357084
    text = __import__('base64').b64decode('WXBwTUpiSG5PMVBVU05ERHZEZVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ъωεрНЙЦРбΠсРКнЛψ():
    if False and True:
        pass
        404
        _dead_9750 = 633
    value = 965322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnjCZUkJ1aVTFi2n0VikOSsr0lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬнэΣщаЖАπлЙИφ():
    value = 590234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCrsOmEpzp8wExnxxGOpZjMhtVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лπпоΝζλρ():
    value = 120718
    text = __import__('base64').b64decode('UHR5akRwaVNmcHJpUUtYem9UaE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ιКΤςΒеЩЫЫζЬфдξЯ():
    value = 885618
    text = __import__('base64').b64decode('SkNuX1Q0bEFHMUUweE12dG1PRlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜЪКЦЗАΠчьΠМοχ():
    if 60 * 81 < 0:
        915
        857
    value = 364990
    if False and True:
        _dead_5229 = 602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3qxV1IQ54k5HRygx3GmAn0j/j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣОΦδκπхΝуοМωзρβτ():
    value = 392223
    text = __import__('base64').b64decode('VWgzTFV3aDBIWTEweWhvb1BLdXI=').decode('utf-8')
    total = value + len(text)
    return total

def _яХдΚΖфφТψτΡ():
    value = 395797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Exy3TWUD/LsGChyT8lW0ZyIe4kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 65 * 14 < 0:
        _dead_6050 = 634
    return total

def _цΠРйеΤΜКΗЗЕгΥЩС():
    value = 341189
    text = __import__('base64').b64decode('Um9BRnpOOUE3MWFMcDNZVE1ONHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ОζЧЖρЭГΟеΖκФ():
    value = 970136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjjSfFYGr/0tBT+x4VfADiJ8/lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛхЬΧсπΔЕ():
    value = 2135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATywPnYP550LNjCu0Wa7LhwJzEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιИмьηΗνНзδАдДч():
    value = 253282
    text = __import__('base64').b64decode('bHd3YkpsdXpQdl9fUjZLM2hpWkQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        751
        116
        pass
    return total

def _мшДΚгЫαΒΘΧΨζ():
    value = 509625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQzmSH84xLoOYxaZy36dNzF28X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ыхКθЪШπλ():
    value = 792134
    text = __import__('base64').b64decode('U1NHS0VzeW1QQUVBX0FlUTNldnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨιЩЙшоΨΔλжδо():
    if len('') > 0:
        pass
        pass
    value = 140007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyzKYgApyYYvCV6v32GoGjUQ/kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_3810 = 878
    return total

def _цζкΠΘЦΑЩтлОΠДΞфυ():
    value = 212548
    text = __import__('base64').b64decode('bmdzaVFJQk9vMnpFYUZOOEtJSmY=').decode('utf-8')
    total = value + len(text)
    return total

def _чΔЮΗχАМςщуИπеΣζ():
    value = 406358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh33bwZs2ropNxis5XqpBiF590k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шУЛΡщηъХПΞи():
    if False and True:
        503
    value = 121355
    if False and True:
        42
        _dead_7362 = 792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxDiawUxyJwtESe7607FYAd9y0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εуΜΧΡЩζчвνδо():
    value = 623165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Py7MSlU71roWAAir53+kNTF63Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΚЦЪыШХЭиτ():
    value = 996661
    if False and True:
        pass
        327
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzvLRlVq2I0HMSqa4we5FyM2tlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 59 * 62 < 0:
        pass
    total = value + len(text)
    return total

def _ШЙσψТЭЛпЪЭ():
    value = 372841
    text = __import__('base64').b64decode('ejJINEx5U0ppbUJPeHVuQUdFSE4=').decode('utf-8')
    if False and True:
        pass
        353
        pass
    total = value + len(text)
    return total

def _ТЦЫωΠΥЮωоΑИΣχθΝР():
    value = 744116
    if False and True:
        pass
        259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwL+VAY36ZAiLQWvkXe2E3Esx0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        440
        pass
    total = value + len(text)
    if len('') > 0:
        392
        _dead_6432 = 676
    return total

def _οьβзапξидцαН():
    value = 520159
    text = __import__('base64').b64decode('ZWU5bHJtaWRHenVHZThxbm9JTUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ъЕΣΘΧюΛλЧзьβъ():
    value = 611392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy3tRWRt640ADyeNmATAJid55WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧЯМΕнтριγηВ():
    value = 437783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjXyeUUB+bgEMw21wmaGMj8BzVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        421
        _dead_1661 = 768
        _dead_6236 = 144
    total = value + len(text)
    return total

def _ΩΩЫрВщΑασΝНτΝ():
    value = 74556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDrxNlts1L0Ebx+q2Ve7OyJ7tX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _одКШЙξиΓЗУЪу():
    if len('') > 0:
        pass
        pass
    value = 387073
    text = __import__('base64').b64decode('T3hBazFEOXdzUnVfSHQ2SlBZYVU=').decode('utf-8')
    if 28 * 46 < 0:
        62
        992
        _dead_2018 = 416
    total = value + len(text)
    return total

def _рΨΒΒηрτΘζСфТЫ():
    value = 296549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBjqRX07r/wAOD6K52mWMBcG9GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔПΣщйκσмщλНЙβιΛ():
    value = 61729
    text = __import__('base64').b64decode('ZXltNTVYQmpVNW1ObU81YjNoTjM=').decode('utf-8')
    if False and True:
        pass
        pass
        763
    total = value + len(text)
    if len('') > 0:
        323
        pass
    return total

def _ΠηЗΒэЯЛΗχИЙяУТ():
    value = 476553
    if False and True:
        pass
        249
        pass
    text = __import__('base64').b64decode('aHBoSE9wdGhpaXlkZlgza19wY3k=').decode('utf-8')
    total = value + len(text)
    if 3 * 82 < 0:
        pass
        pass
    return total

def _РЭηХъλΣσναО():
    value = 312385
    text = __import__('base64').b64decode('SjY5Tlo2eHZuMUhkOFJfX2M2WTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓзгΖςζωδТΦОнΛΩрχ():
    if len('') > 0:
        pass
        pass
        pass
    value = 949139
    text = __import__('base64').b64decode('clNOc1NRUW8wWWRmazlrSFc3UUo=').decode('utf-8')
    total = value + len(text)
    return total

def _АеИеΑυмиЖАΚькрβΧ():
    value = 738221
    text = __import__('base64').b64decode('d0tDYkswcDlqYjFkVGYyWTg3VDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕσπшμКρРЯФрч():
    if False and True:
        335
    value = 900610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQX3WkJv1vkGLAjxxFfDJD8G0GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χтоΞδяΟДРфХεыцνψ():
    if 97 * 91 < 0:
        958
        827
    value = 602774
    text = __import__('base64').b64decode('Q0RHNEl5UkhFVjZXVEhJMlZkZmE=').decode('utf-8')
    total = value + len(text)
    if 38 * 11 < 0:
        _dead_8270 = 548
        _dead_8914 = 617
    return total

def _αЭθбΙΒщπаΑДлπРεч():
    value = 598589
    text = __import__('base64').b64decode('Z09tZDlyWFpKNU1md3d2cF9ZVTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЯρЕаЪΞЫνЧΩьЙΙЧ():
    if 71 * 98 < 0:
        pass
        228
        728
    value = 50672
    if len('') > 0:
        846
        pass
        23
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCKwbEMg2/wvaT2r0GS5bRV65lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щμгьЯюнμυАυΘ():
    value = 428419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiWwYmIV87knIi2Smw7JHQEc20k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦГЛлΒРжΕюэШя():
    value = 569927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAXbYXxh75sGOxmt6gbHLR0Vx2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рτщЧοксеχлъМ():
    if len('') > 0:
        pass
    value = 570455
    text = __import__('base64').b64decode('TjQzbDZUYlp2d1hwVHFpdkg3b1o=').decode('utf-8')
    total = value + len(text)
    return total

def _фΝбαьΕКυВьЦщКящ():
    value = 468978
    if 63 * 63 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgngN3sazqQKDyGJ4F3CDSMtwz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σЦКΟννΤОЬтЛЦδΚЭρ():
    value = 961271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjuyT3o+37EFAjeq0FKlJjZ4xWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лШиЖТχйщСНГЕΕхκ():
    value = 673545
    if len('') > 0:
        pass
        _dead_3717 = 408
        _dead_2139 = 239
    text = __import__('base64').b64decode('VXVIVTR1STlkeW5vTUVaS3I0V0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΖτпТΞζσчΩΨ():
    value = 667971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBazN0UDrYMSbze5mV6SNih/vUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΦРνСβςβλЖИЮьЗ():
    value = 263712
    if False and True:
        _dead_8618 = 781
        _dead_8431 = 698
    text = __import__('base64').b64decode('ZktQQW1PRG1JOUFSOFJNTFEwRzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠеЛьσШμωΤ():
    if False and True:
        _dead_6642 = 92
        _dead_9196 = 88
    value = 117500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBnhQVxq3IBRKl2OxVS/GiMB3kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        259
        _dead_1684 = 40
    return total

def _нρагРЙнμζφΓТΥюл():
    value = 817123
    if 72 * 5 < 0:
        277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3r3QFMQ+JAGP1yP6wS1LRE5/GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        238
        pass
        133
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_6315 = 963
    return total

def _ΔΝτΒШμΞД():
    value = 152530
    text = __import__('base64').b64decode('YXlGanRScVpmYkkzZ2tVakNCczE=').decode('utf-8')
    total = value + len(text)
    return total

def _юТκЯаΔΜм():
    value = 310369
    text = __import__('base64').b64decode('cGx4UURhTERaQ2VidV8yVURuN1k=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_8712 = 70
    return total

def _ΜйηГЕσΟμЧ():
    if len('') > 0:
        54
        947
    value = 781573
    if False and True:
        _dead_1434 = 756
        558
    text = __import__('base64').b64decode('YkhTZkh0VW11N0NrM1piUjhldTY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7573 = 118
        _dead_1931 = 747
    return total

def _δТцщялтκηΖκτкж():
    if len('') > 0:
        571
        14
    value = 58942
    if False and True:
        _dead_5263 = 401
        _dead_6343 = 145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCPqQEQO7vlSGAK02V/BZhd91Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡэтΦкΓΕВцнв():
    if False and True:
        13
    value = 598706
    text = __import__('base64').b64decode('YW5mamxubG9Pd1lrWW5tQVE2cmY=').decode('utf-8')
    if len('') > 0:
        pass
        284
    total = value + len(text)
    return total

def _ЫщρζτвЩй():
    value = 841454
    text = __import__('base64').b64decode('WWpTOVk1U182NHdReFo0WmdfVlI=').decode('utf-8')
    total = value + len(text)
    return total

def _δИМσщсюΝЕсτΟОПв():
    value = 556939
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQjBYF4J2oFQKiGc5g+ZNTV99Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΛΖΛрβБдлωгИбрЬ():
    value = 397825
    if 29 * 18 < 0:
        pass
        160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiewPUUpyYUJFgKQ61HIEQMK6Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 77 * 79 < 0:
        pass
    return total

def _ЗαШэΒετΥЗэ():
    value = 89995
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3f9R3Mr1bIsCCG23E7JDCF852k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΦрκδΛΦэ():
    if len('') > 0:
        _dead_5755 = 258
        pass
        pass
    value = 872107
    text = __import__('base64').b64decode('QmhuMjFVMjM5VmZrMHpoQnNLOVM=').decode('utf-8')
    total = value + len(text)
    return total

def _жιΟаΙбЪαдюΧЕαΓ():
    value = 629050
    text = __import__('base64').b64decode('UkhrOHk0eERyV2M2Q2Z6RUVEQlE=').decode('utf-8')
    total = value + len(text)
    return total

def _ζСеЙюФυΛαоиζФоΧ():
    value = 905196
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiayUVYI744AHzmE50S3GR8Qw1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БηжδОйσуЖωεЬΞЙΣΜ():
    value = 363782
    text = __import__('base64').b64decode('UUJRUTdFcE5mYUdnZFJHdm0wTUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΙπиζЬхфрщ():
    value = 841968
    text = __import__('base64').b64decode('RW5mTlZmQ3BhMG5Jc0VBZkNCUEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ъρТЖΟωΚОжΧЗуσЯ():
    value = 419181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyvyP0hq87kTMFmgnHS8NQ4XsmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τθЮΓрЩΤДкΛ():
    value = 4183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn+9XXYI6voFN1u3/AeGPSon7mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡъхъχоπЙΩН():
    value = 120237
    text = __import__('base64').b64decode('Vmx4SUtYNno4aTdaMDRfYTB0R0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _λιСЬИввжоЙ():
    value = 904584
    text = __import__('base64').b64decode('aFNCSFF4TGdQUVIya3ZLdWdpSEE=').decode('utf-8')
    if 95 * 88 < 0:
        _dead_6311 = 278
        561
        393
    total = value + len(text)
    return total

def _κθнΥφСψΛНαЯфξД():
    if 95 * 100 < 0:
        _dead_4664 = 989
        pass
        _dead_7971 = 398
    value = 246039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSzDOQc38aQbPiei2WeUFSM950I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        266
    return total

def _ΔχθЮудбΕДхРХЩ():
    value = 190604
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjnGREEOzv4zOzit3gbJABoO3GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζОνφςωШτ():
    if len('') > 0:
        _dead_7305 = 108
        794
    value = 298559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC71OgER9r45NCS6n1KxAh0B/k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 34 * 34 < 0:
        _dead_5123 = 627
        960
        209
    return total

def _ЮνБλΨΔπμθ():
    value = 285050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHrBS3wS8q00PzWb4GCRZTEawEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        617
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_9135 = 183
    return total

def _ХшДьТδЩщΚэ():
    value = 107297
    text = __import__('base64').b64decode('dnFhRk5BQlNUZ1hCSVo5YzFvUEY=').decode('utf-8')
    total = value + len(text)
    return total

def _дσΤПςмνтЕеΣдТуЖ():
    value = 929811
    text = __import__('base64').b64decode('WkFiUEx6ZHJJczZiQ25wUTRMRlg=').decode('utf-8')
    total = value + len(text)
    return total

def _ыгΥΗДфЯяΩлθΡ():
    value = 998930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQvgPUIa5qo5PSWv+WCkEHAbzT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥъвЫлШιΖΚЩμ():
    if False and True:
        pass
        _dead_6116 = 741
    value = 946155
    text = __import__('base64').b64decode('dDh3QXFfVElTQ2VTYnRrVkNBN2g=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _φтШξШбΠВνтφ():
    if 67 * 71 < 0:
        581
        65
        832
    value = 927561
    if False and True:
        429
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTuwW1sD+JgEawGVmQSiEwZ251Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цеХайжΗΡΞγ():
    value = 460779
    text = __import__('base64').b64decode('aXpJbEJiaGlIenlHWXRpV0JkYzM=').decode('utf-8')
    if False and True:
        _dead_2335 = 917
        _dead_3087 = 144
    total = value + len(text)
    if False and True:
        pass
        _dead_3288 = 613
    return total

def _цРΩσζьΦнИ():
    value = 693882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjfybGNrx6YZMCeT8AWCAQx7wlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υЛзвДУпΘΧхΩЯЯефЛ():
    if False and True:
        pass
        _dead_8609 = 623
        _dead_4862 = 218
    value = 451464
    text = __import__('base64').b64decode('YjJpYTV4Q3pWVmZOWnM0c3d2Vms=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘкομСΧУкБΑргΚ():
    value = 435375
    text = __import__('base64').b64decode('YkY0aWdjc3ZCdGliWjM4U1AxSGc=').decode('utf-8')
    total = value + len(text)
    return total

def _шΗΦγΦφΨД():
    if len('') > 0:
        pass
        _dead_6880 = 258
        pass
    value = 736409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSvJYXcXp6UEHiyz/EG7BBAZy2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5412 = 849
        pass
        _dead_1304 = 188
    return total

def _еιСΟлΣЬΚθ():
    value = 575323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHu0ZHQU/KoQIjqp/XW+Cx0V634='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_6132 = 111
    return total

def _цТЗсΖиДсΤууΙτПЕ():
    value = 592332
    text = __import__('base64').b64decode('Tk1MSDNEa2FQX2xGTFc1amhhU1g=').decode('utf-8')
    total = value + len(text)
    return total

def _αУλЕμГφУщФΩδУПЛ():
    value = 951217
    text = __import__('base64').b64decode('Q0FlVGgwUUo3d0lFWXl1a0hkTEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪικΘдбЕξфχηеЪ():
    value = 319909
    if 20 * 34 < 0:
        _dead_4875 = 407
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiDFfF1oxK0lEFz00lHBFycA5UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7507 = 448
        922
    total = value + len(text)
    return total

def _πщηζоρΨωУЖΠЩЩТςе():
    value = 922948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjfpP0gQ9aZUGy6m3geTFyYmxl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юΠνХωδЗΑξШΝГгэ():
    if 59 * 46 < 0:
        _dead_1313 = 745
    value = 376202
    text = __import__('base64').b64decode('Z0E1dElVNUNEc191TjdFMzVrU24=').decode('utf-8')
    total = value + len(text)
    return total

def _φΞЖΛΗξкХМΦΙΓДШ():
    if len('') > 0:
        _dead_4298 = 520
        620
        pass
    value = 480834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh7cSHg3prtUaDivyw6pMioF13c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 17 * 6 < 0:
        _dead_1008 = 309
        _dead_1234 = 631
    total = value + len(text)
    return total

def _утХамдгΣуΤ():
    if len('') > 0:
        895
        _dead_5147 = 864
        388
    value = 504292
    text = __import__('base64').b64decode('RDEwajh4S1paNE9vN1RpS3ROaEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕзлΝбΟнρИΜψ():
    if 44 * 55 < 0:
        _dead_8660 = 576
        _dead_4848 = 807
        pass
    value = 40537
    text = __import__('base64').b64decode('b05ja2xfTlBFTWZ0aTE5MTF4U0U=').decode('utf-8')
    total = value + len(text)
    return total

def _УΣтщΒоьρЯырΟτ():
    value = 460811
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjzVRARhzoUyLxuE2H67DnEc4Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чТбΔΒвΗβ():
    value = 174868
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQrqeH1h165QKgzz3n2EDQ0+8X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕτУΓτиρΡΓΧе():
    if False and True:
        pass
        792
    value = 58918
    if 97 * 9 < 0:
        92
        314
        748
    text = __import__('base64').b64decode('Z1E3YWgwbzVVcldJRXhpVzlWeHI=').decode('utf-8')
    if 3 * 47 < 0:
        _dead_3919 = 932
        _dead_5396 = 858
        pass
    total = value + len(text)
    return total

def _вπμΠΑλйыь():
    value = 571877
    text = __import__('base64').b64decode('VzhUNFpESFRWV29EV080MDROMEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЫаЦΤΓОμъΛмПλшОж():
    if len('') > 0:
        _dead_2807 = 822
        pass
        _dead_6890 = 478
    value = 886989
    text = __import__('base64').b64decode('cDJTaHNnbEE3eUYwUnNDQ0JwWHY=').decode('utf-8')
    total = value + len(text)
    return total

def _щΕΩΣЦЦОπδВЧπ():
    value = 613330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiC8Y3MO5PwRKFeR3XyCEQEe42U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘθΠρΞαΔθъФμ():
    value = 826303
    if len('') > 0:
        pass
        pass
        543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxfGa1ko5ItUPSGMwwC8IjwgsWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μυПъμЖИцДщΩ():
    value = 428907
    text = __import__('base64').b64decode('b3p3R21sbVVFTWc1QXJjMVBQcmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛЩθγуВπαЬν():
    value = 530595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgruQUhszatTaDqa52S0Zzcf72c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УацΡχαΞрΒш():
    value = 412724
    if False and True:
        553
        pass
        125
    text = __import__('base64').b64decode('bUFKdERtMkQ4MjY2S3dlWnRibzA=').decode('utf-8')
    total = value + len(text)
    return total

def _шмПхζπΕΘ():
    if False and True:
        _dead_2460 = 256
        _dead_5469 = 756
    value = 959016
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3/lXkcG04Q3OCeR+GGmbDUVvEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 55 * 60 < 0:
        _dead_5967 = 558
    return total

def _ΘΕцЭяПССΤΒΙΙс():
    value = 799010
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgvUQXNu8/kvLxq5mHimLjU76FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1116 = 763
        _dead_6729 = 273
    return total

def _ΥюАψЩЯЦтΣζψΒζοВв():
    value = 899393
    text = __import__('base64').b64decode('WVVUSHRGX1gxTUdqSlNrSVd3UXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _гεЕεΦяδςЯ():
    if len('') > 0:
        pass
        _dead_7199 = 916
        _dead_2419 = 979
    value = 511049
    text = __import__('base64').b64decode('V1FURWo4dUc1eG15XzBsdE5LalU=').decode('utf-8')
    total = value + len(text)
    return total

def _χвдΒИΠσηнйнΔВ():
    value = 393729
    text = __import__('base64').b64decode('U0sxYjlWNDVzazR3Mm51aWxNTTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ωшоφчЗЦρМЬΥ():
    value = 57887
    if 69 * 36 < 0:
        _dead_6739 = 200
    text = __import__('base64').b64decode('QnlZV25LZzAyRmtFSGNhNjV4ZFE=').decode('utf-8')
    total = value + len(text)
    if 7 * 72 < 0:
        pass
        _dead_7932 = 844
        pass
    return total

def _ФкΥγрЮΨρДЕЛηр():
    if False and True:
        pass
    value = 888205
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXnsaAgq0JIBPFj0+167GRV881c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_2614 = 948
        pass
    return total

def _НΡАЖΣЦСкЕЙΔгςΔψ():
    if 39 * 57 < 0:
        pass
    value = 118127
    text = __import__('base64').b64decode('bDE1QXdhWURINW9sekl5ZXZjdUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _чΔΨйδМЯХнΦποпЮ():
    value = 711577
    text = __import__('base64').b64decode('b2R5VlhDVW5fbXl6VE1sVkdFRzU=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _фПпХбэΣИОа():
    if False and True:
        pass
        598
    value = 306804
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KC28aFQPqa8BHga65FOcB3Qq0UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пνЗαЖΩВГТ():
    value = 593420
    text = __import__('base64').b64decode('WGsyeEpuRzNXVjNXR1Q5SUJCcjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛчиЯПоаΦΝйнΒτц():
    value = 473076
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jx7QS1Yu8qwkFTW5xwOkIx8jt2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7053 = 410
        978
        523
    total = value + len(text)
    if False and True:
        _dead_6380 = 327
        _dead_5092 = 892
    return total

def _ФзζтжЛΗΣΑτΠжщΕ():
    value = 898338
    text = __import__('base64').b64decode('aEV6Y0V4VEI2dTBDM21Gd3NFcVY=').decode('utf-8')
    if False and True:
        7
        36
    total = value + len(text)
    return total

def _ιξдгηПыΔρКΥΛпйьэ():
    value = 397069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQrMf3c+6KAEPV6skAe1LTAZ41s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΧАжфΥεкчΒБТ():
    value = 574324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiHLSVNs251QFTCt+QKbYXd8zT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΚΒНУτрЬзЧэБдт():
    value = 838600
    if 32 * 51 < 0:
        835
        pass
        186
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EADAdEgh/ZcRai328FfHIHw872E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξξТчцэсбЭВ():
    value = 428111
    text = __import__('base64').b64decode('VzZnVHhTX2N1aUNrdWZDaVNoZWU=').decode('utf-8')
    total = value + len(text)
    return total

def _λЦАЕйДνΕифΥчΩψ():
    value = 577828
    text = __import__('base64').b64decode('d05kUEczbkZnNkh2d2V6dXphdkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ыυЛνраВНαдГλΙγуλ():
    value = 116277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pwy0NmkArIAuAja6nAS4HSIp0GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΧΟХΤЕВΔгЬвВΜА():
    if len('') > 0:
        pass
        pass
        pass
    value = 991736
    text = __import__('base64').b64decode('TXdmYkZFRUlBQjVwNGpfMkh6Y3I=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΖБνΠΕΔτпЦЗΝъΗяΦβ():
    value = 9552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBryPGEx2Yw6OC6PykOiDHM792A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛеΦэξΤКΨΗμΤΒΖ():
    value = 917681
    text = __import__('base64').b64decode('VmxRdm9WZ0QxVE1zSjI4VE1BdWY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6735 = 2
    return total

def _УХΚВйУлХΛзζь():
    if len('') > 0:
        pass
    value = 13761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXfoVl841pFaFhaS2U7GbXAu0HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΞГЗιАМгΖнεЕю():
    value = 879399
    text = __import__('base64').b64decode('dkRCeVdYcEsxb1I5NDV3aEVSWTk=').decode('utf-8')
    total = value + len(text)
    return total

def _кчσθЦГξАъςνдЩΡ():
    value = 209650
    text = __import__('base64').b64decode('bl9aenNYQVhhS0hJM084Vlc1WWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ПГοМПγψΓЯЫьюфΝΨХ():
    if False and True:
        373
    value = 154914
    if False and True:
        _dead_7455 = 797
        _dead_2795 = 326
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDixeWs/86o7OB6n716FJSF86lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛвсΜецЮпЙ():
    value = 349681
    text = __import__('base64').b64decode('TjNsUW00aHZzQzdkWXpJVzZVQzU=').decode('utf-8')
    total = value + len(text)
    return total

def _пρЧχθтшБЦβ():
    if False and True:
        pass
        pass
        pass
    value = 972663
    text = __import__('base64').b64decode('UWRSMFc5NlBjQWxTcjh5dmtfR2s=').decode('utf-8')
    total = value + len(text)
    return total

def _πποΧΥЕαыИΨΓ():
    value = 385150
    if 90 * 35 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXb9PEML6/gLMxaSmF+lMCYL/Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟсПγьзΙξйΦЮ():
    value = 683718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAjdTGE42IcuIDWHwVGzOgIW7m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 15 * 6 < 0:
        _dead_3739 = 442
        pass
    total = value + len(text)
    return total

def _цбБΔкчΑъ():
    if len('') > 0:
        pass
    value = 8420
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('eU9GdHMxWlpuQkdQcU5Tdk9SeTc=').decode('utf-8')
    if 69 * 87 < 0:
        pass
        874
    total = value + len(text)
    if len('') > 0:
        _dead_9033 = 551
        447
        156
    return total

def _ЩΠТфμЖЧпΛр():
    value = 141188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAG2dAgYp6QaDzWE7licZQQF41w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 17 < 0:
        _dead_4665 = 411
    total = value + len(text)
    return total

def _ΠйςΥΜσλсе():
    value = 360293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHzWW3cV0p1QAAmP4XmzGSYcsE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΕвΙΤΑЫγοΘФД():
    if False and True:
        pass
        _dead_6740 = 754
    value = 224928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTzFZkgcwYc6YwuUx1fHJQQFvWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        480
    total = value + len(text)
    return total

def _ЫΥЬфсЩБрα():
    value = 987943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCXQZ2cPr/EqFF+MmniYMAMY4Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρДТСΝνРАΙЖДИгΧЛ():
    value = 307708
    text = __import__('base64').b64decode('YUM3Zm1ha284SmdXS05ONklONm8=').decode('utf-8')
    if False and True:
        _dead_2505 = 86
        643
        866
    total = value + len(text)
    if len('') > 0:
        pass
        73
    return total

def _дРЛУЛΟδΞΠΣ():
    value = 894868
    text = __import__('base64').b64decode('dE9kcVRZUjRDWXpVZXJZd1VlNXI=').decode('utf-8')
    total = value + len(text)
    return total

def _БбюφФοмΛгХэΑпэкХ():
    value = 504968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhbvTWIu1oEUM1/6wm7CGBAWsGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭйгвцЙЕτДδ():
    value = 792325
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCfrOUczqPotDCe0mgS5Azce9EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        395
        _dead_4941 = 8
    return total

def _πδтΛмОΖЦВσ():
    value = 763702
    text = __import__('base64').b64decode('enAxQ29fcTZTQktvc0cyNjBoaDM=').decode('utf-8')
    if False and True:
        _dead_9069 = 751
    total = value + len(text)
    return total

def _пцΜеЛθяббχξя():
    value = 825348
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSfuWXos6v0kK16VngKfESB/7Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БгΩμυХфлФ():
    value = 462497
    text = __import__('base64').b64decode('VXNJX3UyT1cxX0t0YnJoNzcxSWw=').decode('utf-8')
    if False and True:
        149
        166
    total = value + len(text)
    return total

def _πуρгтжλфζνпβΒИ():
    value = 946292
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyiwR0sxxKNSN1+K3kXFOgctwUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яйпщσущЗΓЙΟЮ():
    value = 483708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATreSXpu3ZtQLSK6w3OROiQh/UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эсъДλξЮТъуεмθеуф():
    value = 817980
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR/WYQQRrKYpagKi91zFZQIL038='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮъУδБьςΞЖюψшЭгх():
    value = 557936
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHmyZQI/zYVSDRj35wS5Pwws1EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΚμуЩТςРзЖ():
    value = 994101
    text = __import__('base64').b64decode('WGhqV3I5NFYzWm1VeGZJNnl4QXc=').decode('utf-8')
    total = value + len(text)
    return total

def _яςуΚΔΕΜМ():
    value = 7805
    text = __import__('base64').b64decode('dmkzRmhhYU56ZUNTbWI3T3l3ZjM=').decode('utf-8')
    total = value + len(text)
    return total

def _κНуХΛЬψКмЕТΩпуНψ():
    value = 999180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXbRalUw+IkoMwWim2aXOwx/72Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψТεШьЮэсλЧθг():
    value = 322652
    text = __import__('base64').b64decode('TEc3THR6WWR5NUNKU0JTNHloTm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ξАηБςхсΟ():
    value = 997287
    if False and True:
        839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lhqydm4L2qklEDyI+06TOAwY4HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΞАОыΕΞφ():
    value = 730224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ngr9OlMw1rwlHl30+XKUBA4/0F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΝΕΓСΜΩоыΡ():
    value = 963452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRbmQlATxrgVGx6k/mCWJSQ77H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4202 = 720
        _dead_1509 = 483
    total = value + len(text)
    return total

def _ъξпАδηαзΒεЖΩЪ():
    value = 410683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQnKN0tv7YouCgmh0HTBETY89FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1607 = 607
    return total

def _ΙгБЛИεΔЩММΗΤρβК():
    value = 844830
    text = __import__('base64').b64decode('UEI0dUcxWFhTRzhYa24xZFFTN1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ιмδЗтςПΤχΚΩθВлПъ():
    value = 899948
    if False and True:
        _dead_4317 = 815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHvTWQYX36IFaSuQ5k6THD8fs3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣцυшиΓφγгШζοГФЦΓ():
    if False and True:
        _dead_8161 = 802
    value = 367015
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxntS0kJ7K4AKhmG9w63ZSZ5s0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 60 < 0:
        640
        _dead_2328 = 505
    total = value + len(text)
    return total

def _хΛьХЭδΦЦΞфЗжЫ():
    value = 980699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARrXZUE8yYxSYx/z3nqAFiY79ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еоξлЬомщЙЪВγВЮЗЛ():
    value = 310690
    text = __import__('base64').b64decode('cEhWcWZQMmNYYVlER0lVSlpUeXM=').decode('utf-8')
    total = value + len(text)
    return total

def _аΜрщδΙСЧяκАΞБ():
    value = 301412
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnrmaAke075QHlqJxAe6JhB/13k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 44 * 78 < 0:
        827
        _dead_1501 = 370
    total = value + len(text)
    if False and True:
        _dead_4554 = 812
        _dead_8523 = 27
        _dead_1889 = 459
    return total

def _ЙщвнчгЯκБВВиКЬ():
    value = 551282
    if 65 * 83 < 0:
        _dead_4472 = 56
        344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCbIS0Jp8JohPxWi7E7HFTcLs3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧθжμΚШΧДΣζλЗ():
    value = 205477
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSTuZGA6zPwsb1ey+w6TBxw46Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛБтОιюжΗБмΒБфь():
    value = 30122
    if len('') > 0:
        _dead_2536 = 23
        869
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgbVX0YS+KQ3MDi54EC2bSwl038='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8492 = 372
        948
        790
    return total

def _χΨεΣъцΨэΙщЮΧеП():
    value = 163918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P33Cewkc04UZMher9walYQEH5nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лεэпλявπΒρуй():
    value = 74524
    if 66 * 88 < 0:
        194
        pass
        pass
    text = __import__('base64').b64decode('TG9zYVhCeXJoekczWDRzNGs0YTU=').decode('utf-8')
    if 15 * 32 < 0:
        _dead_2148 = 888
        _dead_3399 = 204
        _dead_4066 = 244
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _μбЖσжЕдЬ():
    value = 308923
    if 48 * 31 < 0:
        pass
        pass
        _dead_8037 = 634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjnBdlQO/KsrPD25m1eSZBx4xWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙЙΒβΦУΔТхΜκΕмφρ():
    value = 178252
    text = __import__('base64').b64decode('ZVNoQXFNdkV2enpvSTV0Z2hOcnM=').decode('utf-8')
    if len('') > 0:
        _dead_1371 = 697
        pass
    total = value + len(text)
    return total

def _ΥаЮлЦДвΒπЭχэ():
    value = 337653
    text = __import__('base64').b64decode('SmJyczZ2ZjZGRDRjejVfUHREalE=').decode('utf-8')
    total = value + len(text)
    return total

def _πΛΡбтСаиЙКΤδШ():
    value = 41564
    if len('') > 0:
        pass
        867
        _dead_4355 = 917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh3ddHAI9rkRMTWazgCbLhI94mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тГеесКнδбьОхΖ():
    value = 818293
    text = __import__('base64').b64decode('ZkNtRFEzMGRGd3ZXZXlTZDhDWGw=').decode('utf-8')
    if len('') > 0:
        535
    total = value + len(text)
    if len('') > 0:
        _dead_2172 = 205
    return total

def _ТхЫДБчВы():
    if len('') > 0:
        _dead_6413 = 873
        917
        _dead_8099 = 69
    value = 284642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FD30UVhg2adUPg6u6UOGDigr6Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        263
    return total

def _ΓΡПРыΝиЩз():
    value = 613337
    text = __import__('base64').b64decode('eFdLMHV0YXhENG5iN0VEWHpjTGk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        579
    return total

def _жймоηΔьмΡπςψУщΡΒ():
    value = 710085
    text = __import__('base64').b64decode('Y20xQXcyX0VCc0VicXF3ZkJKczI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4588 = 193
    return total

def _ζφζωДуξУΞиМФРК():
    if 54 * 21 < 0:
        859
        pass
    value = 480744
    text = __import__('base64').b64decode('QWtqY1J3bTVRM1RSX2pvbVhMNVE=').decode('utf-8')
    total = value + len(text)
    return total

def _аЗзЩАЗΜЖЪ():
    value = 681162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRb3PVAO9PwMDCqK5gLAAjwGyEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗκЮτюΗЖβΗЙЫ():
    value = 219291
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyS2XwU7qpcIDTmszQ/CIHwM4jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if 18 * 78 < 0:
        _dead_1687 = 517
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()