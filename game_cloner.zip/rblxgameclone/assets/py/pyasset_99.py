#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ЬκцΗζΑρэфяαюГ():
    value = 352032
    text = __import__('base64').b64decode('TldGMkVpcHo1NngySG5NckZ2YzM=').decode('utf-8')
    total = value + len(text)
    return total

def _еЧηяΝςΤΛΠσκбψπΚ():
    value = 925396
    text = __import__('base64').b64decode('djVSSUJEcjR2dUFSY3NGUUVqMUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _нΓчλйΓΖэκТ():
    value = 948416
    text = __import__('base64').b64decode('dWJEbFpmOGJNZlNUREE4Qm10YVc=').decode('utf-8')
    total = value + len(text)
    return total

def _щΛΦδωωηΕ():
    value = 440796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH/rSFYN67oEDCermUG1PDB7xjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        814
        660
        630
    total = value + len(text)
    if 92 * 69 < 0:
        _dead_8996 = 752
        637
        _dead_8643 = 19
    return total

def _ДΘллτοгμυп():
    value = 897052
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwDLSXoA1Ywka16g2gWXACB+43o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8208 = 62
        _dead_2108 = 790
    total = value + len(text)
    return total

def _θΤηЖщмЦβьшоКΒ():
    value = 618596
    if False and True:
        606
        _dead_4393 = 229
        742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCLcW35t8Z48IDmy6mG4ESk5/U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1717 = 447
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8895 = 518
    return total

def _πФхεΝιОоУАмийДΚ():
    value = 155705
    text = __import__('base64').b64decode('R00wSU9yWElmZ3dDZlhhVkdTbVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ъυΙлжаШθшвο():
    value = 648220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kyz0Z1oD0axSAiqg/0+/PR046Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘдλДмфЪЕзΟтΤπЪ():
    if len('') > 0:
        pass
        734
    value = 15450
    if len('') > 0:
        790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBDCemMQ/fsOKT+0+nShInYi220='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТбЦЫШИПιжЖТχЛ():
    value = 143927
    if len('') > 0:
        pass
        _dead_2381 = 413
        pass
    text = __import__('base64').b64decode('SkpmQlJreTVjU2VqNElqR2w1OXM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2298 = 460
        _dead_3685 = 362
    return total

def _φКςжпВФτΦψЬ():
    value = 802097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQf1fGAa1f4FHgyqwWGgLA4p0V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΒеδХотΧБΦн():
    if 81 * 30 < 0:
        _dead_9089 = 360
        pass
        941
    value = 538083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBrxPH0hrY8HMRiKnGCqHAAo12g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эыβпρнЯΧЯыКвδСС():
    value = 247694
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBntYl1spqkMFluR4HDIAhIE928='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        582
        _dead_5182 = 170
        pass
    return total

def _ΥΛъоΜΤКΠβχСυΗΛΧ():
    value = 716620
    text = __import__('base64').b64decode('aV9TYVBvMnJFeTc4dklqcExDbTg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЧзαПУИБΠςЖЫθΖμΖ():
    value = 76714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCzGe1Bq0KEqFwWXxVuoHS0r00U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΑΝφТνηыънΑμ():
    value = 936270
    text = __import__('base64').b64decode('RXNsS0FNajNLN1dVdGlHdGZ5ckg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦЬфΥξσων():
    if False and True:
        _dead_6788 = 986
        791
    value = 705665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwnFRHZh0KAgDTmM+3igbCoe2zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ςЭМιψфЛλΡМηЮΨ():
    value = 432341
    text = __import__('base64').b64decode('SE1GUnpVSVFjTGtURUVGUHFZQUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧэφξюОГлДЗзЫО():
    if False and True:
        _dead_7996 = 666
    value = 245632
    if len('') > 0:
        _dead_1337 = 480
        _dead_8752 = 546
    text = __import__('base64').b64decode('eDlJTHV1WTJXZmJ1WGVYXzZmdTU=').decode('utf-8')
    total = value + len(text)
    return total

def _итЮФλθЬГ():
    value = 647721
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhzQPkEG2YQkOSac+HqXHH0YsDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1267 = 247
        _dead_7880 = 491
    return total

def _ΒЯΔЮшЮΘЛΟПЖлξлФ():
    value = 103174
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BibgQFwV+Z8TDTqnnnzJAB8+zGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΣюЬγкОΒφнЪ():
    value = 640498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAbvZ2YMzYISPiOU+3qCYyd8034='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЦкОэпфЗιω():
    value = 948228
    if len('') > 0:
        _dead_9574 = 981
        _dead_5801 = 62
        67
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjXKekQgqpwCDl6V+FCgGB0/tjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗюмΕΦГЦΦдЮСΣ():
    value = 772837
    text = __import__('base64').b64decode('a0JzbGgyR3FzOERMRDdhYjh4Zm4=').decode('utf-8')
    total = value + len(text)
    if 6 * 98 < 0:
        819
        _dead_9173 = 682
        _dead_1961 = 550
    return total

def _чΨωмΖШυΛδХ():
    value = 659038
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSf2RWhh1vlTDx2L21SoOgo/xU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХОВЦκМЭИН():
    value = 697990
    text = __import__('base64').b64decode('VkN3VzR6VktublZHX1c3bnpBa2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΜΤЦдηЕηеΑЪТ():
    if 82 * 2 < 0:
        pass
        556
        208
    value = 735783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExXSewYcqbEPPwG50lmWEzZ4yXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7891 = 235
        _dead_7152 = 327
        _dead_1717 = 748
    total = value + len(text)
    return total

def _МиΑЕЪхфЯΔЭΚαФОз():
    value = 742795
    if len('') > 0:
        pass
        _dead_4972 = 554
        106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3/uQVs3qPsWYwT23WfABiw352U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΖεьηйМмΠΥесзЫ():
    value = 694909
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwzRV2ANr/FRIAGS5FOYAxF50TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓωфтωШАηψчАΒэ():
    value = 777587
    if len('') > 0:
        _dead_6558 = 582
    text = __import__('base64').b64decode('RlRaZ1VlaUMzcDAxUHNWQm1iUlM=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _жΧТГЦΑνγυ():
    if False and True:
        pass
        637
        pass
    value = 577926
    if 49 * 41 < 0:
        _dead_3886 = 354
        642
    text = __import__('base64').b64decode('cGxCaVdmQ0N2MEJVR2RBUGlsVng=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔпЬхмЭΕХПзЩЬ():
    value = 187235
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzrUNnQ62bsLEQL32Q6FAj064Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3722 = 962
    total = value + len(text)
    return total

def _щΗОнЛЛΞЮ():
    value = 289864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECfgZFsUzboIFVaa+n+iMx8ZtF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χμΗБАτмнФе():
    value = 352887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgLQf3Js2547OCL1zFCmEgE99Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 83 < 0:
        785
        96
        _dead_6350 = 11
    total = value + len(text)
    if 3 * 82 < 0:
        633
        346
    return total

def _ΚπШЕПΤВкГЮыъН():
    value = 568903
    if False and True:
        _dead_2027 = 298
        673
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjXqWGcQ6rk2FQqh5GWfOXcY4Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        272
    return total

def _ЙЙшιхψХЕεЪИΝхЭ():
    value = 792082
    text = __import__('base64').b64decode('Qnl1N2JyOXZTTk1CTEJ2ZXBzVEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΔцАЯφбζЬη():
    value = 344573
    text = __import__('base64').b64decode('ZXJBeVFJVkIxcWZVT0hZZjFKdUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛЮΧЙнЗοЖωΗэОΥΠйж():
    value = 432105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRzMWXBs9q8BPwaq+H2lFz0Wx3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΡΞУОФΣΒгРцУЩ():
    value = 152680
    text = __import__('base64').b64decode('dl9GcGZjcUlWVmRMTURDTnVJaWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞлЪДφΨΙΥужΝдΨ():
    value = 443841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH/PbVRgyf0CDDWJ6niBLCkd3jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОТНЩΛщΟВЧ():
    value = 309139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBfrTF8t//ElHRrw5A6UOzEC1Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        33
    return total

def _ξηΠωъμПшТмΙΠθЫУн():
    value = 983836
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3jARnsRzrI5CgmO5XjGJHIk/l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χιрρηξзыΧЛДьаСΨр():
    value = 577808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fj3DQm4Ry4pUKF/161KZDi8A4W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        813
        _dead_3116 = 984
    total = value + len(text)
    return total

def _ΑжκΔΝПΖΔΥδЬвЙμΟ():
    value = 855126
    if 88 * 1 < 0:
        756
        _dead_1463 = 824
    text = __import__('base64').b64decode('RXRnYWxwV2dCZzRIYXYxd2t2cEg=').decode('utf-8')
    total = value + len(text)
    return total

def _щεНйφщМΞн():
    if False and True:
        416
        _dead_9865 = 42
        215
    value = 767140
    if False and True:
        _dead_4237 = 334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQ73aFw76q8lNRexwQW+Agc18GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨηсλПμъЪζБЙ():
    value = 813142
    text = __import__('base64').b64decode('V0RvdGZ6cW9iNzVLRlZtMkNHUE4=').decode('utf-8')
    total = value + len(text)
    return total

def _μГΩΥΦξτиκМиχνеΘН():
    value = 370391
    text = __import__('base64').b64decode('cDB3UFVvWEhaVXZ3UkozOHY0djU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫγΩэщпВΡΡ():
    if len('') > 0:
        631
        558
        453
    value = 911717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwbgYXMJ/5wNBSismF2VMRR+yVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1629 = 396
        _dead_5715 = 746
        _dead_2672 = 666
    return total

def _тπзΥЗчΝд():
    if False and True:
        _dead_8079 = 806
        805
    value = 989941
    if 66 * 48 < 0:
        _dead_5516 = 265
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyvveQANwYkNKS2542mJIwMfwEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 70 < 0:
        _dead_1157 = 678
        pass
        9
    total = value + len(text)
    return total

def _ЖοΩшЪΓыЦпЗθт():
    value = 185351
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQ7yYH8x8YcUHSOLxXenYww55Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 93 * 95 < 0:
        420
        487
    total = value + len(text)
    return total

def _ДпΞРςδуδμгμйФЕΑ():
    value = 151297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAvnQAEjzrAKDA6tzg+0DSB+w14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βшЦΥγηзΕПγ():
    if False and True:
        879
    value = 426016
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSnPeVsp/apSNliR90GzNiMK/Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        157
    return total

def _ΨδщΤпξΞΙбχЙΤ():
    value = 673587
    if 94 * 54 < 0:
        _dead_7828 = 205
        775
    text = __import__('base64').b64decode('eW9SbzVveHlmMTNGQlphRnpkYWo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        950
        _dead_3114 = 16
        _dead_1205 = 860
    return total

def _ηγΨΟцГХйП():
    value = 381057
    if len('') > 0:
        790
        _dead_7627 = 348
    text = __import__('base64').b64decode('R3I4d05HbDdlYXl6U0hmdXFMenI=').decode('utf-8')
    if False and True:
        167
        _dead_7387 = 625
    total = value + len(text)
    return total

def _гГдαΝмйη():
    if 22 * 83 < 0:
        pass
        _dead_3121 = 139
    value = 449218
    if 42 * 80 < 0:
        _dead_6448 = 887
    text = __import__('base64').b64decode('RllSQ3NIRE9RVkNTMWpDdHdQNks=').decode('utf-8')
    if False and True:
        920
        pass
        _dead_8565 = 460
    total = value + len(text)
    return total

def _ХЭΔγνЙΒКЕс():
    value = 304494
    text = __import__('base64').b64decode('WGhjYkE5bUtLQ3N2aTdzVWI4TW8=').decode('utf-8')
    total = value + len(text)
    return total

def _шгΞωЯыуЪЙЛо():
    value = 860084
    text = __import__('base64').b64decode('d0ltZTdxRGVoVWtNajF4MjNpbnc=').decode('utf-8')
    if 9 * 35 < 0:
        pass
        _dead_4829 = 532
    total = value + len(text)
    if False and True:
        _dead_5251 = 688
    return total

def _уνδΑУДэзбηиηΕ():
    value = 781609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSn3VHgo1vEWGCSB/VqJG3c1420='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        75
        _dead_7220 = 206
        616
    total = value + len(text)
    return total

def _ΛΙЩΔθяшΠаιщшфМ():
    value = 339557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3vGYWAwp4kgagaI42ygJzQX1mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΦшТЮеΒсεлыв():
    value = 70750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAeyfkAQ8L8QPCqa60CfMnU49Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьвндлνξμАΣК():
    value = 585135
    text = __import__('base64').b64decode('cEtMaTBUNEdOV3VUNE1xTDdCRHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ФБωψТБΡЗК():
    value = 461393
    text = __import__('base64').b64decode('Z0xpdnI1MGNSS1kyc0NnX2EzTWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗкΜЫΓсΣхνΜΚш():
    value = 267714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRbGYlkA14UqDwagnGzHNTAJ0WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤяТρЖМкФТнрН():
    value = 496415
    if False and True:
        130
    text = __import__('base64').b64decode('UmxHUjloV0phSFBISWZzMFdqMFU=').decode('utf-8')
    total = value + len(text)
    return total

def _επαЛХнΠοЗ():
    value = 460971
    text = __import__('base64').b64decode('VndCMWdVRmxTX185UDE3anhNbnA=').decode('utf-8')
    if False and True:
        889
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ьлцЛзТдαаΗцθЮ():
    if 2 * 50 < 0:
        pass
        pass
    value = 759349
    text = __import__('base64').b64decode('T0JyQnBVNVpoanZlOTZfbE1VRWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΡβчгρьХΡВσ():
    if False and True:
        _dead_7641 = 416
        426
        165
    value = 459030
    text = __import__('base64').b64decode('cHIwRm1kUGpHVk5PNDJ1RE8xUHY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        145
        530
    return total

def _УуЧЮΦЦΤΠЮΗеВ():
    value = 495012
    text = __import__('base64').b64decode('R2U0QXRHd1dMQXEzX1UzVWNoVW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜψФπΔдελΘεчΔΦ():
    if 79 * 96 < 0:
        540
    value = 582701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwzQUUg357olCByL0kOiJiEhy0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧЛжецхЬосЯдЙбχ():
    value = 171620
    if 96 * 27 < 0:
        833
        395
        200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxzHT1kvzIw0bDCz73OJMj0tzU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘυΟШαЯΙψйРЫСΙΓζ():
    if False and True:
        725
        932
    value = 168361
    text = __import__('base64').b64decode('Q2FGTFpmMnNjbmJZY1Y5UjM2d1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΟΜθнστψΛΥφτζΞ():
    value = 505897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQjtWmcsxrlaDimk8WyfFSENw3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юτанФоСИΣжуΤЫч():
    value = 73999
    text = __import__('base64').b64decode('dHRjaXRVX1FzUEZpUFZncjU1bm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗуУСΠьЫζгΙΠшюХх():
    value = 557924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H33pVAdg5K0ialuAmkWpIR8K0WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йυЩτсщЦБДΣН():
    value = 783409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDfUaHAc76k5YwSnwHXCYAAM90I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2605 = 843
        pass
        _dead_5452 = 825
    total = value + len(text)
    return total

def _χУяъΩΙΡΠω():
    if 49 * 32 < 0:
        pass
        pass
    value = 63308
    text = __import__('base64').b64decode('b1NaVjVJQ2h2eUU4UXpzV3hFcEM=').decode('utf-8')
    if 81 * 92 < 0:
        pass
        102
    total = value + len(text)
    return total

def _ΕфЛΛνγХВНφЦπΑκπ():
    value = 855603
    text = __import__('base64').b64decode('engzQkNsbWIwNmZRSmgxMjlFTDc=').decode('utf-8')
    total = value + len(text)
    return total

def _δΨοНξюοИωΧЮфЙν():
    value = 848632
    if 69 * 49 < 0:
        _dead_2453 = 730
        _dead_6475 = 221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgfGS1I184NVLxy77ky6EQl4x1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ркрοεΛΔМλТХζΣрЯ():
    value = 320234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDX3R2cK/K0TPySSw3i6EnI1/ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зАΣУΧπλΑθΧΒЧв():
    value = 438288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3/lWHgd57w0Dgeq32mYB3Yrzn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΩНйюξпуΩτ():
    if len('') > 0:
        167
        pass
    value = 948428
    if 89 * 93 < 0:
        pass
        pass
        _dead_8182 = 541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSHPbXIKxKEgKwG6ylWKOhQ79UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЫΠЛΣαИБΚВзтСъΒ():
    if False and True:
        _dead_5886 = 596
        _dead_4088 = 357
        pass
    value = 594331
    text = __import__('base64').b64decode('QzFPQW5zNnZwZElsSm1GcnVHVlY=').decode('utf-8')
    total = value + len(text)
    return total

def _ψсМΗСΟπΘЙПγμ():
    if False and True:
        _dead_2296 = 46
        pass
    value = 494950
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh7Mal4f/7FQCgzykViVJgcq/Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        423
        791
        pass
    return total

def _ΜεйуρУеΔЯвΚЮ():
    if False and True:
        _dead_8391 = 320
        pass
        18
    value = 776430
    if False and True:
        pass
        788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dnr3dlYR8/giYjqo2lDDZyEb0Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        771
        pass
        _dead_5391 = 608
    total = value + len(text)
    return total

def _РпяωрЕЛμ():
    if 39 * 91 < 0:
        _dead_7068 = 926
    value = 372886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwPxVGk8y5EANlqcxHO4FiwB/kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 38 < 0:
        316
    total = value + len(text)
    return total

def _ωΕΓΗλλτбуΟВЯА():
    if 26 * 84 < 0:
        _dead_8323 = 255
        715
        _dead_9344 = 956
    value = 637560
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzvSaQIpz50PDAqpnA+2YgYQw28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 56 * 21 < 0:
        _dead_2088 = 460
    return total

def _ЙΧςдξнЩΗιшюиж():
    value = 317710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwboagIW6aMbPzW52lqkJAsayVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КщΥΨεБХΟтυоΩςΗ():
    value = 186597
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR7rOQFprJtQAgSZ5XGIMREr9kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΝδмΔИΟΥГРО():
    value = 953625
    text = __import__('base64').b64decode('UkZxYnd2X1VLMXNaWWVVeFFpNnM=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        254
    return total

def _щτШςςИйГΩ():
    value = 670684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjvnYFdo7642CSP1+A/JED8H21Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔЭЮζαрνПιΕИΟμп():
    value = 701342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MziyfkUI5oU6HlmbwATIJhUAyXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АФιЮчЗΣподП():
    value = 484009
    if 57 * 57 < 0:
        177
        _dead_5100 = 943
        84
    text = __import__('base64').b64decode('dTFmWjJzU1BEWlhkdzlzVFBKT1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _лИьгΟрАб():
    value = 912652
    if len('') > 0:
        168
        _dead_6331 = 934
        _dead_5281 = 862
    text = __import__('base64').b64decode('ZGR6a3BFMHJhck9PU1JqNWJtTTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЧйцΖΙΘοσνВЯ():
    value = 533071
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('TW1RM3JhdkFyckc4ME94VGZ0ekY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯЙΖНκωдЖАωΨХФυ():
    if 32 * 21 < 0:
        pass
        pass
    value = 294883
    text = __import__('base64').b64decode('WWF3Z2p1dWZLSDE4R0pneWJDWG8=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _зэЮΨцιышα():
    value = 850338
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiL+ZVQR9LkzDgKX6QC4ITMJsXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΙЗАΨкБЯЩЪςЕ():
    value = 993772
    text = __import__('base64').b64decode('eXBzUzRfVVllV2ZVd1RPY2RmSVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙвΨμЗΤΧеуμщх():
    value = 969318
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECnxagI+7pwHbzaBmF25HyAL80k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 74 * 40 < 0:
        388
        pass
        _dead_1924 = 14
    return total

def _ФλξВфΓев():
    value = 414908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhX0RXIu04IZAjWBkWGzOHIGs30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πымюшΠЪωΕжЧг():
    value = 430540
    if len('') > 0:
        736
        pass
    text = __import__('base64').b64decode('WGdxNmRIOVJRcF81YldtUWphbng=').decode('utf-8')
    total = value + len(text)
    if 70 * 7 < 0:
        571
        773
    return total

def _δМΠоЧйιΠΓжЮ():
    value = 500795
    text = __import__('base64').b64decode('eG9nSkhUMkNTdWpzXzJfeW85U2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ηγщрзτκπКΚ():
    if 18 * 25 < 0:
        pass
        _dead_4869 = 714
    value = 183886
    if len('') > 0:
        _dead_5478 = 450
        _dead_5877 = 686
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQjXWgQp6qEBEV2b6XGAMD0XxTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зМрπщδΘηΖιΓΩИΘЛД():
    value = 17230
    text = __import__('base64').b64decode('bEtuT3pacUs5XzFHM2FGZ0llbWM=').decode('utf-8')
    if 11 * 51 < 0:
        _dead_5784 = 265
        pass
    total = value + len(text)
    if 2 * 14 < 0:
        859
        pass
    return total

def _нΑюВΛφФτ():
    if len('') > 0:
        927
    value = 302041
    if 57 * 21 < 0:
        _dead_9688 = 789
        _dead_1790 = 598
        34
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhXSZWUY3IxRLCCL3F2jGwQCsmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γψИψΛαΛЛКЯ():
    value = 785879
    text = __import__('base64').b64decode('UGl1OWV3VGY0Mmwza2hyM0Z3VkE=').decode('utf-8')
    total = value + len(text)
    return total

def _бΛШоЩснбвττЬΒНΙΚ():
    value = 958014
    text = __import__('base64').b64decode('ZWl6X2hoSVRJUVNuZjJ1OEZpQTM=').decode('utf-8')
    total = value + len(text)
    return total

def _νЖЛΝКрАНΧβοСθυΓф():
    value = 236886
    text = __import__('base64').b64decode('eXg2bHU2SmcyeEVtS2dtSTVsZ1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩОюςчωΙςαш():
    value = 673398
    if 13 * 88 < 0:
        _dead_9326 = 263
    text = __import__('base64').b64decode('S1V4aUJycU00WDZCXzBrN3d6V3Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1997 = 259
        pass
        _dead_1592 = 915
    return total

def _ΚΟойАлΦпСΟ():
    value = 335393
    text = __import__('base64').b64decode('Y3JLY3RrUU1WQU9Td0xZNjhVTnE=').decode('utf-8')
    total = value + len(text)
    return total

def _еЭΡΨΩаРхщыЦχ():
    value = 178595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQXsf2EG5LtXPzyRkFCEEicLxkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        197
        _dead_5227 = 810
    total = value + len(text)
    return total

def _ЗοЭΩρЩежМδАΥрАИШ():
    value = 24851
    text = __import__('base64').b64decode('VG9rWVE5ODl2OXQ0OEF2d1NLU0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _νЩУЪΗΜΗвζлδи():
    value = 113840
    if len('') > 0:
        _dead_3245 = 447
    text = __import__('base64').b64decode('STBwdF9JZmlVd3B2d1VsN1BBdkE=').decode('utf-8')
    total = value + len(text)
    return total

def _кюлнσдЫыгσФтКфψ():
    if len('') > 0:
        pass
    value = 471911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CA7hY2lt+bATbCmAnHOfPyQV0zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5005 = 444
    total = value + len(text)
    return total

def _ьЕжьωРйяЭλкπТρ():
    value = 417891
    text = __import__('base64').b64decode('YjhQZFluZEgzMm8yU2o1d0hUOUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ФωГΑΩыωγν():
    value = 398389
    if 79 * 12 < 0:
        _dead_4060 = 850
    text = __import__('base64').b64decode('UjgxNjAxT1NiWWNUTnhDdGNONGs=').decode('utf-8')
    if len('') > 0:
        13
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_6189 = 477
    return total

def _αФЛъυдςпΕωτωфЕ():
    value = 173408
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AR6zank085wXLha68kyJOx067ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        288
        265
        _dead_1794 = 543
    return total

def _бРЛΚπξοκ():
    if 82 * 31 < 0:
        _dead_5419 = 893
        902
    value = 158806
    text = __import__('base64').b64decode('c1FxcWx5ZkpORzI0UnJSZG9qakI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕрΛζыЧжΟЭчωαН():
    value = 913235
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAnsNnlqzvkSMSGH/nSZLXN/5WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φшαЙОфбИЦЯтИЦξΚ():
    value = 703988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICfjPWkJ0aZVCD2M3gOvIgsQ8Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шкΒωюψΩдго():
    value = 711610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgPWZnoa2ow1NgyV8EWjMBV+70Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пеαЮжΒЭиющмΕОж():
    value = 525713
    text = __import__('base64').b64decode('QWEyZkZGRUpGRm9uT0VvWTR2dm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΠжЛРςΒζλДХ():
    value = 193675
    if 73 * 50 < 0:
        _dead_9342 = 623
        632
        _dead_1515 = 47
    text = __import__('base64').b64decode('SUU0anIwSV9Ddjd4RDVpcXNzNVg=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _жЗΡΑΖшΗИМΦу():
    if len('') > 0:
        571
        pass
        _dead_3168 = 381
    value = 746935
    if 48 * 70 < 0:
        984
        _dead_1055 = 229
        _dead_5430 = 867
    text = __import__('base64').b64decode('bmtjZFVaR2NVRUJ2TjlvX1pRZUU=').decode('utf-8')
    if 88 * 3 < 0:
        pass
        273
    total = value + len(text)
    return total

def _ЪΠмсщвσроξОуΞ():
    value = 58642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Khv2YVxt0YIkbRiGxnyCZgg13X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЬΑΩΘКяаζΨуБβ():
    value = 671690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ig7PS0E8+5pVDiW7y1i5YxAu1Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηклΙРΕсБφП():
    if 52 * 26 < 0:
        123
        _dead_4242 = 609
    value = 276528
    text = __import__('base64').b64decode('TXR6MHZLbkxOX0JkMnZKcFpxbUo=').decode('utf-8')
    if False and True:
        _dead_5948 = 93
    total = value + len(text)
    return total

def _рοъЬψВгЕΡςщΦЖЫ():
    value = 567407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MADvSQEO9KAAGB2N40SVYxUE028='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 80 * 92 < 0:
        295
        pass
    total = value + len(text)
    if 79 * 40 < 0:
        pass
        766
    return total

def _ЪыτβаΓМЬΖ():
    value = 453597
    if 93 * 81 < 0:
        _dead_6304 = 366
        364
        93
    text = __import__('base64').b64decode('U3NUa1FTc0w3dEtDS3JFREsyMDU=').decode('utf-8')
    if 60 * 38 < 0:
        _dead_5962 = 594
    total = value + len(text)
    return total

def _ЛШкжθΦвΨчωъфуΘ():
    if 5 * 80 < 0:
        126
    value = 103461
    text = __import__('base64').b64decode('c0l2MXdPZ2FLeUdjamdCRGRIVzE=').decode('utf-8')
    if 30 * 97 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _δНΨЗωΘΨндеΕλсФ():
    value = 874557
    if len('') > 0:
        _dead_5028 = 265
        _dead_5957 = 397
        _dead_9926 = 548
    text = __import__('base64').b64decode('d2JpYW9sU2J1OEZ6U2tIb3pQOUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕъΛзпъσλΠαВφЭΠ():
    value = 811838
    text = __import__('base64').b64decode('bk9zTVpoTUtDRTB5RnlwMVpnc3A=').decode('utf-8')
    total = value + len(text)
    return total

def _КцДОΧуйУяΖОв():
    if 62 * 72 < 0:
        _dead_8943 = 999
        pass
    value = 687927
    text = __import__('base64').b64decode('bmJteGNZTEY0RVJKaEEzcVo3b0w=').decode('utf-8')
    total = value + len(text)
    if 84 * 31 < 0:
        pass
    return total

def _юАэпΜЬкυйУЛюημ():
    value = 552293
    text = __import__('base64').b64decode('VWxiZXA5a2ZvSXZ2U29tT1QxV3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭЖΘсΦСтχу():
    value = 797451
    text = __import__('base64').b64decode('ZHByX19EbEtmQWtpcERaWGJ2X0o=').decode('utf-8')
    total = value + len(text)
    return total

def _εГαφЭщηкΦΕеΚβ():
    value = 945549
    if False and True:
        pass
    text = __import__('base64').b64decode('YkhZZHd2azdnU3hjenREQmxLNE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΠχΝЯЫοσΒ():
    value = 455333
    if len('') > 0:
        _dead_5413 = 474
        754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjfVWWQPzo1WEhv03FG1YT9822w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эτιъζΜΣΧιДЖ():
    value = 81586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCnPVgQv+P4GNAKU+XeoNXckxm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΤЛαΖΓξЬОςτ():
    value = 887309
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex3TSGgAybAVCh2h7k+vIhA1xm8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζлζЛΧΞнрйΦΞХ():
    value = 90198
    text = __import__('base64').b64decode('d0o3d1htSnZVNWtIanlRWk9oa1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ГсюКьтЧς():
    value = 431385
    if 85 * 77 < 0:
        _dead_2323 = 920
    text = __import__('base64').b64decode('eXNNYTdGTzJ4eXBFVXpkd0liWnQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ЬυΡрιΠνеАЦНΕАА():
    value = 269429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQHuTWMSqf42G1anwV6hDiog7lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εσцεБΓЩιο():
    value = 227370
    text = __import__('base64').b64decode('QUU4Z2dtQjNfNVFLZlc0UGxGUkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚиьДΤΡνΑяΩыфэЙиΞ():
    value = 338876
    if len('') > 0:
        pass
        _dead_8954 = 504
        pass
    text = __import__('base64').b64decode('QXpyNzdPellvT2k0bmx0TXZDS18=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _κνтшТцНΑεнШτττР():
    value = 737011
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3nmfX0U2IMvaQn7mHeCLhF62z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДЖζυΧгэΞчΑХΘЧнα():
    value = 429333
    text = __import__('base64').b64decode('RTdqTW1MbWxUM1FOa2NNMDVUWUg=').decode('utf-8')
    total = value + len(text)
    return total

def _дкΓφδΜιζВ():
    if False and True:
        pass
        _dead_8655 = 878
    value = 735922
    text = __import__('base64').b64decode('cnFOam1SR0VVaEpvd3A0V21sUEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _фщχвΞуОμΣиΨ():
    if 97 * 17 < 0:
        612
    value = 991906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Di3LPFQgq74nYyuTkWKdPAk77G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜЮУΚλθΨξ():
    if 28 * 30 < 0:
        pass
    value = 87175
    text = __import__('base64').b64decode('c3VtY0tzTUF6ZmMyNFZhaTJwNFQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        112
    return total

def _δΝΟσεОΗД():
    value = 708044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxzRYUMb2J1WIhW5nHCpZw8/9U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цгИДПШКεЕы():
    value = 792482
    text = __import__('base64').b64decode('cDR5SDNsa0JSVEJ2cmZBU09XbnU=').decode('utf-8')
    if False and True:
        _dead_4170 = 614
        pass
    total = value + len(text)
    return total

def _оЪΡЙδШΛΡΝΡвб():
    value = 650066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhW9bQVh+Ik3Eyeo5U/DNyoe1V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΤтЖЩОΨΙз():
    if 20 * 88 < 0:
        pass
        _dead_8482 = 141
        _dead_9562 = 178
    value = 717573
    text = __import__('base64').b64decode('TG1QSXBPaktGTGRfcjRfVjg0eWE=').decode('utf-8')
    if 7 * 82 < 0:
        _dead_1005 = 667
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3361 = 138
        _dead_2577 = 148
    return total

def _ψΑйζЭгπψЗлΛлМз():
    value = 567394
    if 68 * 37 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyXvf2gsyY9RDymH2kayFwYC3nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓβЖйшнΧа():
    value = 484084
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzvlTwg/5PEkM1uQmFGAHyss43Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬгШохбηрΔОπО():
    value = 648977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgTeaUMj//kaMheo4gS9ZwEI5j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ζйΘиιаБΑГНюφρδ():
    value = 667149
    text = __import__('base64').b64decode('Znh2SmpPUTlyUkpWQTI2bHZCeTI=').decode('utf-8')
    total = value + len(text)
    return total

def _АβГйфепИΑВδЭА():
    value = 918897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjrjYm4L65lQDg6722S9Jjwh9lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯюАРЕЦΞРΟ():
    value = 658690
    text = __import__('base64').b64decode('SFVHRmNJTXV6Rjl4V19CdE4zRm0=').decode('utf-8')
    total = value + len(text)
    return total

def _юЛηЪπПЭωх():
    if 70 * 82 < 0:
        _dead_8120 = 606
        901
        _dead_7273 = 8
    value = 791998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRvvXGE7z4YoD1ik7mLGIHF/wGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 58 * 93 < 0:
        _dead_9653 = 866
        _dead_8704 = 468
    return total

def _сΧкΙцΒλΣΚ():
    value = 194431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCXpRHgy675RChiV3QOyOw8O4EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8072 = 481
        pass
    total = value + len(text)
    return total

def _эβЧΗАΗнΣψЕОΣЪ():
    if False and True:
        _dead_2143 = 29
        124
        pass
    value = 578122
    text = __import__('base64').b64decode('d0Nma3ZBZnNVb0dPcFM2RlZrMEw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        105
        52
    return total

def _тΨЪэТцЮΕΗΔ():
    value = 328723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjfHY1Yv6LIsNV+7kFinYw0B0kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_1254 = 976
        _dead_7285 = 645
    total = value + len(text)
    return total

def _ρΥΞъЙιэΖМРжς():
    value = 452976
    text = __import__('base64').b64decode('Zkk4RkxvbUF5UGdNQUQ5dVNWVlc=').decode('utf-8')
    if False and True:
        472
        pass
        pass
    total = value + len(text)
    return total

def _γШΦπμθΙΘшΖλδΝ():
    value = 343024
    text = __import__('base64').b64decode('VFJGMER2Q09JMWJDU0Z3Z1MxdU8=').decode('utf-8')
    total = value + len(text)
    return total

def _τьФЦэОцРΛΚΔнωН():
    if False and True:
        pass
    value = 719046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IADWSWYs0LkoFQ2m/w+CGi4F9Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3473 = 548
    total = value + len(text)
    return total

def _ЭюЪунЪΝчЯяЮΩХ():
    value = 971504
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAnjSQBrr/klDz+v6Wy9YjElyWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 19 * 5 < 0:
        946
    total = value + len(text)
    return total

def _шМюДЯТЖЛΟеТκ():
    if 62 * 54 < 0:
        361
        _dead_6687 = 287
    value = 666789
    text = __import__('base64').b64decode('a2FHaFYzTWg5TnlfVUl4UnFTNW4=').decode('utf-8')
    if False and True:
        _dead_7057 = 289
    total = value + len(text)
    return total

def _ЮБΤΗρΓΜИΚτΩσνλτ():
    value = 982613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnbySnQR1o0HKTaKy2yiLBQEt3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_7519 = 752
    total = value + len(text)
    if False and True:
        _dead_9216 = 659
    return total

def _ИцλчСΙКΣЙοΡΞ():
    if 66 * 36 < 0:
        pass
        pass
        253
    value = 800939
    if False and True:
        pass
    text = __import__('base64').b64decode('bE5VSWJ5c0FVQ3dEU0dKZUZWWEg=').decode('utf-8')
    total = value + len(text)
    if 71 * 23 < 0:
        pass
        pass
        pass
    return total

def _АΠλиξУψфψΖКΠυπ():
    value = 459468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCjHQ1c80oc1Hz2UmUadPRMIxkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        704
        769
    return total

def _ЭΡχьΙОηВЕищ():
    if 34 * 20 < 0:
        pass
        357
    value = 595881
    text = __import__('base64').b64decode('YzJKMFRtd1BwbHBra1pUREpaT0s=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6458 = 230
        pass
    return total

def _ЙιΧΣчпΥΖφωγвςм():
    value = 848461
    if len('') > 0:
        pass
        98
        _dead_6798 = 171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgTXY3k7/KAoEwux5FWvH3Ie50M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _смΧεΠζДεщπΣмнΝτ():
    value = 137925
    text = __import__('base64').b64decode('bmJiOEtwdVFDb1kxeVZHd25wcTk=').decode('utf-8')
    if False and True:
        _dead_8469 = 286
        124
        pass
    total = value + len(text)
    return total

def _ΜЩмЗюеЕΕбЭБ():
    value = 196672
    text = __import__('base64').b64decode('QTB1SFNpQV95N2p5VlVzMlh2cWc=').decode('utf-8')
    if len('') > 0:
        419
    total = value + len(text)
    if len('') > 0:
        970
    return total

def _вПНЦИЮνвЫ():
    value = 905475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAnwQ3Br/IJaNSyw5U+TbAIKyX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4002 = 22
        pass
        241
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZA==').decode('utf-8'))
if 24 * 16 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    _dead_8003 = 428