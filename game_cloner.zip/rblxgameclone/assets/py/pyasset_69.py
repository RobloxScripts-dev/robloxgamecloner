#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _εМΔБΞθθαΑбΩШΘГ():
    value = 659035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT7nZwcu0q8LKDWlz0+6Misd4z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МщЕрινыαζМΤτПΨ():
    if 42 * 85 < 0:
        pass
        pass
        pass
    value = 975247
    text = __import__('base64').b64decode('Rk9jTXZqR3VlZ0psczZLc3IyWTU=').decode('utf-8')
    if len('') > 0:
        233
        pass
    total = value + len(text)
    if 85 * 96 < 0:
        143
    return total

def _бпΟЯπГжЬ():
    if False and True:
        _dead_5428 = 623
        _dead_4347 = 753
    value = 75883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn/BVwho7q5XHw2p/Vi4AxIFyT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 4 * 96 < 0:
        47
        pass
        101
    return total

def _НЛФΒΞπгνΛΥ():
    value = 874847
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSDyY3k404otazav3HmiYnMC02k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩψВэρЗЪЫреΞΠй():
    value = 288031
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('TnJCdGhhNlpHUkU5YllKU2wzSEk=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ПыΡφКΧаΛДφ():
    value = 844851
    text = __import__('base64').b64decode('WW9RdXRSTHVpek1nY3FvckhWTGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ТяΜшЙτΤБμяΛЗтцд():
    value = 337673
    text = __import__('base64').b64decode('aVBtaFd3aVNPUFI3VHZ4UXcycFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ШθΤыΔαИΚ():
    value = 975364
    text = __import__('base64').b64decode('cVA4N2J4dzVTWTBpMEkwRnVEZlQ=').decode('utf-8')
    if len('') > 0:
        _dead_9802 = 210
        pass
    total = value + len(text)
    return total

def _μиμЫΕΠоеΥшΒЗΖωΘя():
    value = 202985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhfGZABr3JhRIj+18FeUDRJ93U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9871 = 262
        pass
        77
    return total

def _аΨХβΝβХυЦζЦ():
    value = 433672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByywOWMX150rC1yWzEa0bHV23X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΖΙЛвНиξΓЖΚΟ():
    value = 737460
    if len('') > 0:
        353
        _dead_9371 = 708
        259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgfzQnggzIw1CReM3HSIDBwKwXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4006 = 810
        _dead_2122 = 263
        pass
    return total

def _ξψмЩεαΠЫ():
    value = 375339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDmzQAgtxrxVGQGc3Gy4P3cmzGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юωоЖяΠЫΘ():
    value = 900087
    text = __import__('base64').b64decode('ZERhYjBwMkh3cTM1SXUxckFQUG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝερЦЮΥαχΗ():
    value = 348047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjrGd18R758NCR2Ew1GTOg0X4jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΧΕΤκΣΚЗФμцКЩ():
    value = 874896
    text = __import__('base64').b64decode('dnFiS2RtQnpHdnNZU3lBdXZjMjM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9183 = 382
        pass
    return total

def _ΦЦξβσЙЩШωькэЯγБу():
    value = 812041
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiLmbXY+56YxFA6t8We3LR0n9l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖПетжΘΙξζхи():
    value = 883372
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhD0XUgr+6tWLziz3kKzDg0D4WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШуЩνλΑΠΨНδшаΝщαг():
    value = 841506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3zCRXA0xoAZPCKg317HFwAJs3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σьΑνцβщΠςιжζΕЮв():
    value = 980074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iy2weGEU67g6PQW12AXFASA8wDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗТβεшΔГεьΞξДк():
    if False and True:
        49
    value = 878048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCXwdHo9za03Kima2UaCBzc7900='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _θъыΒЕΠοщА():
    value = 942434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTnlZ3kyr/wJFzutwEC6AgYgsW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝькоεвцςЪβЗЯя():
    if len('') > 0:
        352
    value = 332781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXztfWk++alWNDmJwXGHZzY49kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЭДЮиχэсъ():
    value = 691584
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX32XEEY+q43FD2L8VWkOCgb118='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        983
        _dead_6054 = 576
        824
    total = value + len(text)
    return total

def _ΦλΟнФλΣгΠςΞГ():
    value = 55417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDnSVwUS5I4VKQOV31KgFygitTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 21 < 0:
        pass
        _dead_6188 = 56
        pass
    total = value + len(text)
    return total

def _ΘκηνЯΘбθЯΔОНМЭ():
    value = 615699
    text = __import__('base64').b64decode('dl9mZVozQW1wb0hwb0pHWnVBT2g=').decode('utf-8')
    total = value + len(text)
    return total

def _чοКВЖшФдΡζиΕΕδъД():
    value = 7135
    text = __import__('base64').b64decode('UE5sWEZZeUdCMll6SjBYYWhPSjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩνтНαθЗω():
    if len('') > 0:
        pass
        452
    value = 864614
    text = __import__('base64').b64decode('dU1aTkcweHFXVE1RZjVORVVIYnk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4119 = 97
    return total

def _ТχГэчОδψΤ():
    value = 216216
    if False and True:
        _dead_5254 = 206
        485
        3
    text = __import__('base64').b64decode('U3JWMUdSWklKcTFWb2pxVlZYUjc=').decode('utf-8')
    total = value + len(text)
    return total

def _σΕΣφьδЕЯяФ():
    value = 609272
    text = __import__('base64').b64decode('TDZxT1huSmRWWFhKd2o4Rmd0WkY=').decode('utf-8')
    total = value + len(text)
    return total

def _νψТЩζΞΨА():
    if 80 * 60 < 0:
        648
    value = 860629
    text = __import__('base64').b64decode('VzR4OEpCTlFiaXYyVFp0TXRldFA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        610
    return total

def _тΜΡΕдВλΜδτкΔ():
    value = 536810
    text = __import__('base64').b64decode('ajhqdThlTDBmbnBtazRtbk9YR2g=').decode('utf-8')
    if False and True:
        pass
        217
        236
    total = value + len(text)
    return total

def _φхТжΗнΙΕζ():
    value = 345200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRj2O2cRr4NaKxWB5VjDHS8N/E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ййЦюнυАωΚЕξЙщΧтЯ():
    if False and True:
        310
        pass
    value = 73083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgDWO3gUx7gUNVu07WmvByYt8jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        362
    return total

def _σεμфλνЭзалтΟΕη():
    value = 172655
    text = __import__('base64').b64decode('SzdWcTh2MVlrZzJhTm9tOHd4UEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝкэобЪЛθРУθ():
    value = 545133
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DC7UP3kW3b46IgygmV+0BzQA5mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6500 = 991
        532
        _dead_6236 = 543
    return total

def _юζρηрНЪэΤΖ():
    value = 631966
    text = __import__('base64').b64decode('bnZpVTFMSFduTzBjaW1uOXNqU3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΑЦАδрФтъХц():
    value = 167951
    text = __import__('base64').b64decode('RVJjUGJoUUJBYVBncWxybl9lY1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ИтΑншμλΧδΧфπьЬσ():
    value = 137066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix/UOkcSqr0pCA2k3H2BMR88zGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡМьнБΝΥшβσэЦμψ():
    value = 332291
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DA7+RAQfpq43FRWQ/necHXM/t2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θπпΤΤεΘΖΗΜ():
    value = 620382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXv8YXkLqqBSLB+Q8QXDLXUp8z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗдуψыЗРεμЕч():
    value = 868741
    text = __import__('base64').b64decode('ZGgxQmNRSVVIZWVDTzczTlhxREk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯВΟΧЧΞфЗВρΠμЖα():
    if False and True:
        pass
    value = 307825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AibhbQYM97oxMTag32e1JHx+9Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥяΞгЧМιτщ():
    value = 661995
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQvTd2gg9K8mLCL1+QGHAhIXzFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СлэЬюыυгВдλг():
    value = 475610
    text = __import__('base64').b64decode('bW9qem9RdUVYdnRERHVVcDJwVUw=').decode('utf-8')
    total = value + len(text)
    return total

def _φΨюσяΩэфζЗΨΒлуωα():
    value = 597370
    if 81 * 43 < 0:
        700
        621
    text = __import__('base64').b64decode('S3BPOEVZQWNuNHBqcGZTdkVScGU=').decode('utf-8')
    total = value + len(text)
    return total

def _твЯмРζβΠΞмЭ():
    if len('') > 0:
        pass
    value = 701622
    if len('') > 0:
        _dead_6702 = 280
        486
        _dead_6465 = 369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji3sTXIuqJ0yCCH640yWMzYH0F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШυжДКвйΡЧζБ():
    value = 721334
    text = __import__('base64').b64decode('YjNPMVZ2blhPVWJhN2RNd0kzMzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ВгΩΖΟΦЪΙβΥъ():
    value = 499246
    text = __import__('base64').b64decode('SVdvZjFfSHBSTUpNUWplSXFrbDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΧΙγΦпЦΞκκъЩΖ():
    value = 987360
    if 38 * 80 < 0:
        _dead_1784 = 811
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgjTemAPxp0bNA2C7Qe2MyN66GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1967 = 81
    return total

def _ЫцлδΥвзЛ():
    value = 431543
    text = __import__('base64').b64decode('SGp3RnVCYzlIUEtkRjNiTmtKa2Q=').decode('utf-8')
    if len('') > 0:
        300
    total = value + len(text)
    return total

def _УΛэтΩοξПφщτμвхγ():
    value = 62104
    text = __import__('base64').b64decode('WjZhVzZqOExoSjVpckt4RW1iSnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _эДМΠпΣЦΧЯцς():
    value = 477487
    text = __import__('base64').b64decode('VHYyMlRNUlVFZXUxQUFVbHluME0=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΜξйДТИα():
    value = 416490
    if len('') > 0:
        _dead_5001 = 142
        pass
    text = __import__('base64').b64decode('aEhITFZjXzl0Ylo2TVVsOEdqN2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЬкΛшЙΡγиНБςΝΛ():
    value = 500404
    text = __import__('base64').b64decode('ak1HYktXa1dncFIxcndjMVFLYUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖФνθΨБςйлтκΜП():
    if 39 * 45 < 0:
        513
        875
    value = 404279
    text = __import__('base64').b64decode('eWRGc3BHc3JnNW9PdU03Z1l2NEY=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_8264 = 607
        _dead_9824 = 334
    total = value + len(text)
    return total

def _эУОφΛхχΔΨзκОц():
    if False and True:
        pass
        _dead_3426 = 518
    value = 125293
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRf+Nldtwa06ABet/mKFFiMezEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 27 * 89 < 0:
        582
    return total

def _ΥβОθДяРΒМΩУΨлΦγ():
    value = 607257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzX8SAkvrY9QFgi722/JJCl5vT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        439
        252
        _dead_7945 = 993
    total = value + len(text)
    return total

def _ЪЦРΗъΞОεюъ():
    if 31 * 64 < 0:
        739
    value = 910218
    text = __import__('base64').b64decode('c2NSMUpmQ1hQTkRGOHhQbWdMUTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑКθοΔБвΟрΒζхй():
    value = 432781
    text = __import__('base64').b64decode('T01UWVNfRWpLa0RNTk5hMzY5amc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΧмεΟЧиβб():
    value = 193401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mym3VnAhwYYNaCqo4l6BEgJ/9kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5980 = 0
    total = value + len(text)
    return total

def _οюТΞдЩγЪдτО():
    value = 724681
    text = __import__('base64').b64decode('YXQ4bWpvVEJnOVNMVGVCaUVpb1E=').decode('utf-8')
    total = value + len(text)
    return total

def _δШΖцΘΘИΜцН():
    value = 234777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCPDeGEh94dQHCqx2VqGFi8l534='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩвΗΚьСЫΟБυр():
    value = 242372
    if 70 * 85 < 0:
        343
    text = __import__('base64').b64decode('SjdLbXh6clo5cERMTWdOMHNnYWI=').decode('utf-8')
    if len('') > 0:
        _dead_5579 = 385
        _dead_1489 = 291
    total = value + len(text)
    return total

def _еΑΟοΕΣПΓΚщЦЭишΙЩ():
    value = 28887
    text = __import__('base64').b64decode('YzFoUTlPajcydk9wZ1daNGJ4YTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛиψπΩйуΤαрМ():
    value = 85195
    if len('') > 0:
        _dead_9053 = 394
    text = __import__('base64').b64decode('TnI4NUhLdjJIdlk5SUExVXcwdUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΓлΒнνΝσ():
    value = 861700
    if len('') > 0:
        pass
        pass
        500
    text = __import__('base64').b64decode('RzVTY1hBb2pJYTdWdlA2bnVubDY=').decode('utf-8')
    if False and True:
        _dead_5169 = 361
        29
        272
    total = value + len(text)
    if False and True:
        pass
    return total

def _φЪυУΚпМτΞй():
    if 51 * 19 < 0:
        _dead_1824 = 267
        pass
        _dead_8298 = 987
    value = 402709
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ND7OfkMJz6kZNjCL4U6XHCI6vFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦсЫψΣΙйоСΥοэдςач():
    value = 834240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHu8PXwg3LwwbSH00nrJMQ0d0Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _злыокτАМфаυ():
    value = 622341
    if False and True:
        _dead_5643 = 683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA7SOVUg9aEMPTfyzVyZAwoAx3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 69 * 22 < 0:
        _dead_2208 = 553
        _dead_7252 = 751
        340
    total = value + len(text)
    return total

def _ЦШΞγЫЕкεζ():
    if 34 * 26 < 0:
        pass
        392
        345
    value = 408401
    text = __import__('base64').b64decode('T0pfZTBSYjNWS0RibWF6TGxFRzk=').decode('utf-8')
    if len('') > 0:
        _dead_7066 = 568
        pass
    total = value + len(text)
    return total

def _ΞμΧэΠщΔдо():
    value = 597781
    if len('') > 0:
        _dead_5777 = 587
        418
    text = __import__('base64').b64decode('Wms5QnJnU194M05xUzlFbDFsdnM=').decode('utf-8')
    total = value + len(text)
    return total

def _υΩхχιгΤΛχχРЙΓοξМ():
    value = 209701
    text = __import__('base64').b64decode('TTJJZWJKSlhzUlRsNHhWU2tNVVU=').decode('utf-8')
    total = value + len(text)
    return total

def _λςтГΩгПκДφΞ():
    if 27 * 35 < 0:
        _dead_1458 = 715
    value = 202646
    text = __import__('base64').b64decode('SlliQnZoNDcwcjlJZFdlV1N2MmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΒнΠВейщИПεОюΛ():
    value = 780883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRXdOWkV26M0DAyLnWXFMwALyUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НьлиШцΞв():
    value = 126291
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzvKTVA8qowBIB7x2lKoYyYV7Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫξалЛГужΖ():
    value = 848783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CD7pQX088vAqKzj7+HqfEXQjzWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΘйΚδжигХСΤЪЙ():
    value = 642866
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASb8d2hvqr0ABQnxwGmUZSQFw0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΚЪэρΜЖлОР():
    value = 853592
    text = __import__('base64').b64decode('QTIxUGlJblRNV1lKTGVqMWNleG4=').decode('utf-8')
    total = value + len(text)
    return total

def _уИφΩΤлЯБΔγηΥΟΥΛО():
    value = 546101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiexXWsr9oIQEwyu4n22NSB+sDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        729
    return total

def _ЕβΛСоγθвЖЪλеψр():
    value = 402390
    if False and True:
        _dead_7543 = 372
    text = __import__('base64').b64decode('WjZQMHlaYkNONXZod1FWMU5HQTA=').decode('utf-8')
    total = value + len(text)
    return total

def _оΚмωьηφβΜλЛψμΟα():
    value = 526807
    text = __import__('base64').b64decode('UXR1TVh2N2VyVHppdGRMS1NhcHE=').decode('utf-8')
    if False and True:
        329
    total = value + len(text)
    return total

def _ЬАΘжЖЛШцσЩ():
    value = 4975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgjKVFou7bg1FVa0mnOhHBZ/3Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПвЦцПьддгОωΨνγ():
    if len('') > 0:
        pass
        _dead_6934 = 765
        pass
    value = 479902
    text = __import__('base64').b64decode('ZHI1WWkxZUxVbHE1VmJlamY5cjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ςхУмφяΘΓφ():
    value = 444664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgDANlUG6ZgLIiqC4EK0HAkbs1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЗЙξγЗЙяφΓΖβΨ():
    value = 893883
    text = __import__('base64').b64decode('WDBhb3BlZXB1U0d0VXhydWRvRXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΡσЖьЦεΩΓщтИРы():
    if False and True:
        138
        383
    value = 151734
    text = __import__('base64').b64decode('VjJwbTZYOXU2a0EyQWNzRkp4ZUo=').decode('utf-8')
    total = value + len(text)
    if 56 * 88 < 0:
        609
        _dead_4667 = 287
    return total

def _яΙщφдνЮψЗаοДХо():
    value = 460120
    if False and True:
        _dead_4891 = 635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBC9PVIL+q80bTr7ygCoOBMe6UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8174 = 168
        828
    total = value + len(text)
    return total

def _ИηКгБСαΓМιыπΟцэД():
    if False and True:
        pass
        pass
        _dead_7272 = 620
    value = 543640
    if False and True:
        _dead_8448 = 139
        854
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQbAXmhr2r87CzuU30a2ZysK3Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХкχБαЩΟтаАЫ():
    value = 55335
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjXseUcy+pcHbRqOnAeVZHQH5V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛзоПхγΔΩ():
    value = 27975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgPIX0Mu5oMHOSCgxAGJLR011n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΧЛσжΨτμΞν():
    value = 858171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MizyWkcuxKpRCAaQ0kavZg048TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υρКнЖыуоКшкУвΕ():
    value = 605464
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHrzXlstzqYNKTzzwU+ZMzYp7Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΓЦТтΩиКВскΗэЭ():
    value = 968809
    if len('') > 0:
        512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR3seVM90L0PEQv17WKdPyMV6EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        3
        1
        pass
    return total

def _фвОΣяЗЙΩэзешυс():
    if False and True:
        _dead_2307 = 415
        738
    value = 446521
    text = __import__('base64').b64decode('V1d3VFZQd2JIN2wxVXdNVTR0dmw=').decode('utf-8')
    if 14 * 65 < 0:
        601
        _dead_9533 = 242
    total = value + len(text)
    if False and True:
        _dead_9200 = 434
        _dead_4435 = 525
    return total

def _υχЛПζШπχЧΟЛЯщДο():
    value = 688165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BivLVlQo758nOTan20OdZBV/xUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΞΥГъЕЛΕЕДНαιГьдЛ():
    value = 415455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyHKXF9g66QyIiGF31+xPyouvGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζЪςΠΑяМψ():
    if 19 * 30 < 0:
        pass
    value = 339152
    text = __import__('base64').b64decode('eHVpYlJEVTM5MWtNMkZ6a185WXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΦφΠΧΩИцгЖЛωΕ():
    value = 749209
    text = __import__('base64').b64decode('ZzNnNVI3VmtjVjF1QVQ1ZU9ZdkY=').decode('utf-8')
    if 58 * 71 < 0:
        495
        pass
        _dead_1595 = 414
    total = value + len(text)
    return total

def _ΡшкΠлвяψиδЪЕΖω():
    value = 229038
    text = __import__('base64').b64decode('SGVHMWloNEhobEV5ZEl1ME1ZSm8=').decode('utf-8')
    total = value + len(text)
    return total

def _χЖΜьПШЯмцЦζΑХ():
    value = 367473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx7jYQJq3PEabhaGmwejAi4gtWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        682
        257
    return total

def _θΛχаδКоωοЯУпιΖβ():
    if False and True:
        pass
        _dead_4773 = 905
    value = 372177
    text = __import__('base64').b64decode('dnNmaUJnbXVsMVY4T2R6OVhGRm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΒХηТΝΝυΝη():
    value = 833097
    text = __import__('base64').b64decode('TDBMODlRX3A2ZFQxMk5WTXdhbkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛдьσСлВρ():
    value = 987577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgfjbwNo6qUmMR2CwmOnAQN53GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩТЯГμбρАΘфъ():
    value = 590859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCnjeFU3+ZsnLxaR2WyEBhUQw2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        384
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΗυбβДΘВΕжΡЕяτ():
    value = 70210
    text = __import__('base64').b64decode('cTQzSk9VWVB4TlgyTUxOUVd0cXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖссυпГеΝΦЦЮΗξ():
    value = 36589
    text = __import__('base64').b64decode('bVdYVzR0OGlsR1NuY1lwNTBiOG0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6819 = 955
        _dead_9115 = 339
    return total

def _УψФΙуОуΓ():
    value = 939008
    if False and True:
        _dead_8964 = 73
        _dead_6229 = 304
        756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQrqaFUc1rEPPyaS4nCgLDV8wD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4038 = 83
        _dead_3088 = 409
        400
    total = value + len(text)
    if 81 * 13 < 0:
        67
    return total

def _εзЪΔьηΠΚР():
    value = 503987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3u3Y3kN2PgybzqQ+UDJGD8q4F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΠъЮЮфЭνиΜБН():
    value = 467967
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAT0XXMKrP5WCzqG7QKmNicnxVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΣЛΟхντΒЛЕΗΞВλ():
    if False and True:
        _dead_1636 = 642
    value = 409215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDrAYlA3rb4KNDCknV2nYyd451E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        460
    return total

def _ηзЕοЯΚτкΨеγмβ():
    value = 38806
    text = __import__('base64').b64decode('bWhnOTVxd1o1RlV4ZWtxRjRMM3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΜФщΕθЫИхжЮщэМа():
    if len('') > 0:
        _dead_8787 = 267
        pass
        pass
    value = 834116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NArlZQIv7v4PI1iz40CCERQd50E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БηατиΙгΜык():
    value = 485572
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgjeWlk4pr0vFx2rylqmDA8c7Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТНЮψПΤПΘЩйλМЧΙ():
    value = 283428
    if len('') > 0:
        242
        148
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTfUTEMX6qIEMg6v5lCEMww9s2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вфеΜвКθвуЮыΗуΣК():
    value = 639156
    text = __import__('base64').b64decode('djNPN2RYU1RmVVU3a1ViSGZWeGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΜΥАжбΨОсфΛ():
    value = 63381
    if 30 * 33 < 0:
        pass
    text = __import__('base64').b64decode('V3FJa0lSUDVDTWYzbnRhZWM1X0g=').decode('utf-8')
    total = value + len(text)
    return total

def _жоЦοМБυυΛзпΜΛпЫч():
    if 71 * 88 < 0:
        pass
        321
    value = 25342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQWyXUgP3YIgOB+mxWmfZXM96kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΟΜеафбиΙпто():
    value = 810375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjrNOFIo9YsOaT+KkV6AEX0Vs1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жаХуЭΞззЖΞяШυΕΒ():
    value = 119947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAr2Plhq2o4sGSKu71mTLAQO6kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цяеΞиююя():
    value = 771091
    text = __import__('base64').b64decode('a0xOTVkxV2huSlQ0eUF6MmlON1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛδъфлΝЯТЖижΜТ():
    value = 555671
    text = __import__('base64').b64decode('Sm9TcnB5eGJBNVpmSElySkxmVEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚСρΕТζΛчЛпШΨчλБ():
    value = 382990
    text = __import__('base64').b64decode('czA3bVZ3eXVhQ1FSSDhCZzE0dlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥДуюЖΗиΓмγяΝιεва():
    value = 873207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In7rQ1MTrJ0MaweNxVSFGzAd23Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нбΜДъБяХθъσ():
    if False and True:
        pass
        pass
        pass
    value = 658860
    text = __import__('base64').b64decode('TGpqRlhEdmlfaFdpZjZvdWZKZXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧαНЯтюσЫШиρΔν():
    value = 409126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgHQfls75J8NHz62nQeWPnQs0Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6454 = 166
    total = value + len(text)
    return total

def _наЗΠξЯЬΞиΝ():
    value = 270382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDzuSEU004cgDl+tnmCFMyY+3kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыЧИКхδΡН():
    value = 935334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px3xZVZt8vtSBQqC/HyEA30M52Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7407 = 51
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_1272 = 159
    return total

def _БоΜμτΠβШΙΤе():
    value = 663228
    text = __import__('base64').b64decode('dXVjc0JjeVV6Um1yN2FkcDE5S3Q=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4341 = 881
        789
        _dead_8305 = 742
    return total

def _еΘМСхχψвиΤА():
    value = 140290
    if False and True:
        47
        pass
        _dead_9556 = 564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyDceUUT96MuFSqH/n28N3Un8G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4261 = 510
    return total

def _ГυΨПбωΓдЫ():
    value = 382884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mw3BY1Bh7pkSA1iQ8nPIGxB66Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9378 = 0
        58
        _dead_8332 = 525
    return total

def _иπТςΑρΦУψоЧгΔΕ():
    value = 427116
    if 29 * 29 < 0:
        pass
        483
        _dead_6821 = 587
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAnDTwFh54EoFQqMn269Bw0D3Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПщΖνΡψΧи():
    if 13 * 90 < 0:
        653
        810
        pass
    value = 220686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQvqW3sd74NTGxmBzlqyOwB553w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χοΟоЙфЪΕΔг():
    value = 900950
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTrNeFkYy5wWNA2JwF65Aw1+zj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хоςДсхΛκлКвчж():
    value = 345020
    if 56 * 66 < 0:
        pass
        223
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHnmbV42p/lSDFyT5GOZNhcZzEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эψυПλТНКХηξ():
    if 34 * 89 < 0:
        49
        _dead_9757 = 710
        _dead_8780 = 425
    value = 565374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSPvRwhvz7guKyn0yWWRHi4/3lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бЧуΦЪιΧуЖХθшβЯΦ():
    if False and True:
        723
    value = 226717
    text = __import__('base64').b64decode('WlNGUE9ONktoNTA5aWhKTkVKTW0=').decode('utf-8')
    if len('') > 0:
        _dead_2130 = 802
        _dead_4587 = 969
    total = value + len(text)
    return total

def _ΚЧзΗХΨжξΧχШ():
    value = 894308
    if 93 * 39 < 0:
        pass
        _dead_4912 = 190
        _dead_7022 = 804
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSvvWmgQzLw8Mwfwy0+3Fw0CtEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        652
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _сρДцЯωβьΕу():
    value = 77189
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCq0X0RgzfktG1i0mE6iAXYZ4l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 96 * 67 < 0:
        110
        pass
    return total

def _ьБМΜннΡбэМюψ():
    value = 23965
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwvAd2A8qYpTHgj0xQemHSsEvWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вМΝΛΜςЖЙδчΦδА():
    value = 836771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAS8bF0Ux4wKMyPyx2OxATF86H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΣБкτПμΞШурΘν():
    if False and True:
        pass
        _dead_8390 = 424
    value = 593196
    text = __import__('base64').b64decode('VTRVcjZZaVk4RTNjVG9OR3UwSkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΧΙτγИЫЫгнΓτМ():
    value = 112202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCf0QEU9yI5RCwOO3mm0DCIf/UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡыσςΔсΠΘπλΔ():
    value = 643844
    if False and True:
        541
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRvoZFo++Z8NHj2C4n+GPh8kzWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДъЕоРΒлВдЭбΕ():
    value = 792167
    text = __import__('base64').b64decode('cmQ3d1FuQUV0bE1pNmx5SU5BSU8=').decode('utf-8')
    if 6 * 69 < 0:
        _dead_6190 = 201
        _dead_6268 = 261
        pass
    total = value + len(text)
    return total

def _щЗЦςΔχБδЖ():
    value = 812408
    if 36 * 81 < 0:
        _dead_5255 = 994
    text = __import__('base64').b64decode('Sk5STlkzN1RINlROOUNyeFpmVTg=').decode('utf-8')
    total = value + len(text)
    return total

def _НХЯΛЕзйБξвсΡаμ():
    value = 300762
    text = __import__('base64').b64decode('WU90SUpHT1BRUmMzdGRnTGRXajY=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЧвсвИЬямΓΛЖΞ():
    value = 163025
    if len('') > 0:
        _dead_4016 = 327
        _dead_3110 = 701
        440
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQLxXUczxq8mYgqH8X6oFh94zEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        959
    return total

def _мъΙвρАЯΚжчЯΛКОσ():
    value = 900057
    if 92 * 25 < 0:
        669
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHnSXWtu+LwmODn0wGm2ZgAd9UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шμχΒнυОНЛαЛ():
    value = 859545
    text = __import__('base64').b64decode('REpwWThMRGE1QU1yUTVVWndEaVI=').decode('utf-8')
    total = value + len(text)
    return total

def _сΚξШΘжлΔρ():
    value = 955425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnjyW3Y46r5bFlez+mDJNXUItGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БξНцоХвσъΒпμЩКЫ():
    value = 517087
    text = __import__('base64').b64decode('aUJhZ3oxT3E0Ynp3M01PazZEeXA=').decode('utf-8')
    total = value + len(text)
    return total

def _ьНФьЦдρЩЯτаχЯЩ():
    value = 673849
    text = __import__('base64').b64decode('YVVETjZhSks1RUR2QWp0bFJiNFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ηδЦζЖжχЩТ():
    value = 573491
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTvpVkQG66QEGD+W3lCfJSQc6Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _скψкβЦΞЙωΗЪΛцοЖΖ():
    if 36 * 80 < 0:
        pass
        742
        pass
    value = 787947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx7dQ1kJ6YMNGSONy06/Zw9+wUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жтωЫΙсйλΛКсЙУХ():
    value = 296068
    if False and True:
        _dead_8369 = 463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kz7gW2cJ6Z5TCyuw6mbBZT0r82E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΟАПΩΗуγСΜ():
    if len('') > 0:
        237
    value = 463129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjjAegUU/f9RLwDzylOTHwkcyns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        466
        pass
    return total

def _ЗЛπьσаЮνΟ():
    value = 175486
    if False and True:
        _dead_8179 = 558
        _dead_9240 = 76
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADvdQ1sj/aM8bzCh8U6vY3AB/kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 20 * 28 < 0:
        pass
        _dead_5957 = 111
    total = value + len(text)
    if 23 * 89 < 0:
        pass
    return total

def _ШΜМιιМшκсΥσН():
    value = 22785
    if 35 * 76 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3nUPGNr1oYROCexzweYOzEjxzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦαзЧиРнЛФНΠ():
    value = 553975
    text = __import__('base64').b64decode('VHM1dU1US3NiSFppc3czSEYwTGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ьпεζΒялΟΤаНζкМЛ():
    if 50 * 49 < 0:
        pass
    value = 328675
    text = __import__('base64').b64decode('a2R3OGw2eERQWUhQUnA1U0liMkk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        42
        _dead_7338 = 98
    return total

def _яЩξчΡДοαΒщбпщ():
    if False and True:
        _dead_7484 = 239
    value = 538406
    text = __import__('base64').b64decode('VHdieVNMZEM1UHRtdEdQd3JndXc=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _КγЪςαΚАщ():
    value = 838688
    if len('') > 0:
        770
    text = __import__('base64').b64decode('Tk1fS0ZmbzFQOHoyQU0yOVpGUkU=').decode('utf-8')
    total = value + len(text)
    if 13 * 87 < 0:
        52
    return total

def _ΤнχхУМИζВυъЫГдЮФ():
    if False and True:
        80
    value = 498034
    text = __import__('base64').b64decode('ZW1XcnZIWGlXMVVvX1ZOc2xraGo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ядзЬЕξфБЫζφΧыθ():
    if len('') > 0:
        pass
        _dead_5976 = 850
        _dead_9707 = 199
    value = 733379
    text = __import__('base64').b64decode('RFdYWXR5SU54R3FVaXhzTmgyWGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ωσλоνтСΑλР():
    value = 665385
    if False and True:
        _dead_6771 = 739
        pass
        319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzjBVAY/7qwkYiuknlq0AHIq0mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9127 = 92
    return total

def _γηРΝНЖλΞю():
    value = 461786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHm2TXQA94ASGAmn4nCCICl66Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φИяςδκΠдеъΩΞаο():
    value = 12879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQnNXXcgroQXKiaK+WSDPhMixVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        572
        494
        187
    total = value + len(text)
    return total

def _вяСτПЭьΧЩШгν():
    value = 793771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Agb3eAUTwZ0VABqwxmK2G3UN3j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕСзδтцδΦρΒψев():
    value = 56237
    if 92 * 2 < 0:
        _dead_7160 = 199
        851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhWzb1cp6PwPbAK5/lvGCxws1Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 5 < 0:
        720
        143
    total = value + len(text)
    return total

def _ενςЭожэюНΦнρ():
    value = 282917
    if 47 * 13 < 0:
        pass
    text = __import__('base64').b64decode('TXpoMnB3UGl3UEp5S0l1cTdHUFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖСαπЕςΠυю():
    value = 797944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQbhawUT8fw0Hh6n6VmIBSkLyWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЯΓМΤΙекСнДΠтСщ():
    value = 655966
    text = __import__('base64').b64decode('b09YbTJaZ2N4ZHFjdXVJYUJQOV8=').decode('utf-8')
    if 25 * 66 < 0:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_2221 = 143
    return total

def _δφΘаСнГΡ():
    value = 44400
    text = __import__('base64').b64decode('b3BWQWowcTJ5aEFmUUlYSmJCQmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _вУОςεСЙИΣшΖБΚуΖδ():
    value = 94833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXvyQkMYx6wLEgeX/0STAXcWxXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РζУΟхщεЫιΕ():
    if False and True:
        156
        368
    value = 471785
    if 85 * 59 < 0:
        pass
        pass
    text = __import__('base64').b64decode('d0ZqYVVqa0k3UDR1SmxyZHJaZHc=').decode('utf-8')
    total = value + len(text)
    return total

def _κяοфТωюоЯшЩΑ():
    value = 959781
    if len('') > 0:
        481
        172
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cw60VwgA26Uqa1yzzV/IPjEj1Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 20 < 0:
        pass
        754
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        485
        _dead_1153 = 738
    return total

def _ΠοθЯяЬФЗσΔπуΒυγЩ():
    value = 86088
    text = __import__('base64').b64decode('ZDFDQkVjdzh2YTZqdTdlSUZ2enk=').decode('utf-8')
    total = value + len(text)
    return total

def _υκБИιΑΜпюΝуΘ():
    if False and True:
        pass
        pass
    value = 629285
    text = __import__('base64').b64decode('SzAybnl3WnhVM05NOFJnSGY1Ymg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧтКРГАλкФ():
    value = 462868
    if False and True:
        pass
        _dead_5977 = 689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDi9d2I++IUrDhiq2wWKIXcV8WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωИяΗЪΕЛΡвВоЗПД():
    value = 658324
    text = __import__('base64').b64decode('UkJaRktDOXg3VHo4WEVyam1wZXM=').decode('utf-8')
    if 3 * 74 < 0:
        pass
    total = value + len(text)
    return total

def _υζТцхИΚсЫεΞс():
    value = 264788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz7AeXIA6o0UKyS0y3e7Ogx5s0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5743 = 435
    return total

def _тζςβЧЙψЦНБπОМбЬ():
    value = 456610
    text = __import__('base64').b64decode('aFlnVGRYcFF2TFBlX1JyTVhJaEQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΡοΙΑЬщсВкνм():
    value = 97510
    text = __import__('base64').b64decode('RVdzSHVWSk9taDBnUkp5VEQzWUo=').decode('utf-8')
    if 10 * 28 < 0:
        927
        pass
    total = value + len(text)
    return total

def _бтцыοИΨэΑΝЙδгЕ():
    value = 571715
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH7sSGQG35EmEBy593O1OhZ83ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        900
    return total

def _ργЧιоωλХΜοиСОΠυ():
    value = 524659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxvFT0Y296EUEVyam0G0FQ133kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΖθΥйМΞЛΖеΩ():
    value = 966422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDzqQAgu1qwsFyn32m7GJSIAxUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯЭΝЭеΤфω():
    value = 245242
    text = __import__('base64').b64decode('Q19FOFlLVzlPNWNBS3Y1TVBqWWs=').decode('utf-8')
    total = value + len(text)
    return total

def _РшЭапΖьΠο():
    value = 276668
    text = __import__('base64').b64decode('YUx1emx5ZlcwXzBmNUFGN3dSeGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _μХρΝΙРрΕб():
    value = 720311
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSuybVUuyIUQEx+22XC/IgcnzWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 59 * 1 < 0:
        pass
    total = value + len(text)
    return total

def _аОюΚеУАЭэОα():
    if 54 * 37 < 0:
        _dead_9482 = 562
        362
    value = 155752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3zhQ1MA26IwaSeIxGW4Oi4fw2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()