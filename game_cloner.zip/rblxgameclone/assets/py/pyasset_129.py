#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _шнΠιуаΣπΣсΒσμΚЦΛ():
    value = 82101
    text = __import__('base64').b64decode('SzJicExYVUh2MFV4ZmlUMk41REU=').decode('utf-8')
    total = value + len(text)
    return total

def _яΠЮТюζйβеΜΙεЦΖγ():
    value = 462642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAfjPHUgq6cFDDaPzVGfEx94sFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓГБЗλιжηфα():
    value = 586266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB/bRwkjp5ggawb10FjHZiwlz18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПκνЖЖыλΝпΟцФУ():
    value = 253805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhXgY2JuqoRaCRes70y8ETE78W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _сзοЧеЗЭΝиΠαЪуαЧ():
    if len('') > 0:
        pass
        _dead_2917 = 666
        _dead_5334 = 683
    value = 769474
    if 9 * 72 < 0:
        673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRe1dksb/KESbwew51qHEi0BxW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 93 < 0:
        pass
    total = value + len(text)
    return total

def _χκΧЗСшωΔΚΥЛИЩ():
    value = 560217
    text = __import__('base64').b64decode('ZERkbU9MdkgwZ1JYQUZYdEU4anQ=').decode('utf-8')
    if len('') > 0:
        _dead_3608 = 258
        pass
    total = value + len(text)
    if False and True:
        726
        _dead_8476 = 270
    return total

def _ΜΗΖβДЭΨтνЮξψПьΝ():
    value = 377386
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhjzZXIj/ZJWFT2ozAKWJnYZyGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХчγЧьГΚЧοс():
    value = 502305
    text = __import__('base64').b64decode('UTFHZXpHWm1Oc0owaDZtb2hTU3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _сЦγνψΡУκЭ():
    value = 225058
    text = __import__('base64').b64decode('VlN6OHBoZXRSazdLY3JPWE9CX1U=').decode('utf-8')
    total = value + len(text)
    return total

def _γякФбΧМΑЧЪхбиΨжτ():
    value = 371331
    if 75 * 22 < 0:
        563
    text = __import__('base64').b64decode('UXM5aDd6NUFaYUpfMDFmRVpvVHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ηβΦМιвЫΠЯι():
    value = 173522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwC2Z181yfEtYh6t0EO0Bgx25Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жлзΥФДТζηγθщБΨ():
    if 49 * 16 < 0:
        pass
        pass
        681
    value = 756744
    if 55 * 8 < 0:
        840
        802
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBnFWFgayZ0vECCMywa7OiEsyGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        907
        844
    total = value + len(text)
    return total

def _ФРЫυУихιΗ():
    value = 210153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAe0Z3du8bE5HTCP7Ee+GxoJ1ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жщφюΧρΖραвξθΔ():
    value = 480170
    text = __import__('base64').b64decode('VkE3b0VwTnRnU3FQUVkxWEdMdHg=').decode('utf-8')
    total = value + len(text)
    return total

def _йФΒчτΒыΦΔ():
    value = 101273
    text = __import__('base64').b64decode('RzV5MHJfQTdxOHM4V2d6Q0dSTnE=').decode('utf-8')
    total = value + len(text)
    return total

def _ейбМηχЮζΞμΣ():
    value = 622384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3fmQ2cez70WCAWqnXmqAion4Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЧНБΣРЮИ():
    if 91 * 7 < 0:
        961
        _dead_3053 = 556
        pass
    value = 839139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwjAUWJty4lUaTCa7QaWBR0Mynw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 45 * 34 < 0:
        544
        pass
        915
    return total

def _ЭСшλΒκюолζςтчя():
    value = 956176
    text = __import__('base64').b64decode('aWd0aldMRVVwWW1GdW9KY0pVejg=').decode('utf-8')
    if 95 * 32 < 0:
        _dead_2813 = 437
        _dead_6598 = 553
        639
    total = value + len(text)
    return total

def _ОмΙЕйяκγТФЭхб():
    value = 210361
    if 3 * 49 < 0:
        _dead_8580 = 913
        210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Li3xOXgT14klbTiUym61LT0o3H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        996
    total = value + len(text)
    return total

def _ωΗΕΚУвΜВю():
    value = 528823
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhfTd3QPpv8KAweHnXLEJCgtyWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БσΧοцяΙΨЖΒ():
    value = 60669
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MijWSQcv8Z5aFiOz53SeGCY+9mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΔσЦЫβзΟοΧУЪαъΝ():
    value = 311662
    if False and True:
        _dead_5740 = 995
    text = __import__('base64').b64decode('SkNCczY4NVZuUGJ0NzdIQVVfY28=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        566
    return total

def _ΜΩνςТьВЦИψ():
    value = 993698
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSPifXco+4EaAlmyx2ejERQesWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьμΗдЩгОΥюφНμЬНБ():
    value = 741475
    if 85 * 4 < 0:
        _dead_6315 = 360
        514
    text = __import__('base64').b64decode('QkFrMmpUcDR0RU9wUEtldVBRcFg=').decode('utf-8')
    total = value + len(text)
    if 33 * 24 < 0:
        _dead_7468 = 101
    return total

def _ςвАΚУжΒωΚфВΠщЫуΟ():
    value = 957719
    text = __import__('base64').b64decode('QUsxdUlLS3MyMlV2Z05FeXp4ZXY=').decode('utf-8')
    total = value + len(text)
    return total

def _яПЧйεψгυξ():
    value = 671493
    text = __import__('base64').b64decode('aksyRkdVam0yWTNiOHIwandrR2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _λцφΑΩγψσДСБΞΒΘνΝ():
    if False and True:
        pass
        547
        pass
    value = 824339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PALDVmtg2/1SHly132aABh0cwWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 22 * 13 < 0:
        _dead_5466 = 927
        601
        225
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9621 = 831
    return total

def _εΥуΒΨαУΞъΓ():
    value = 352972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CibHfnUo27JQFgiKznHGNRc46Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПбзяΙТРь():
    value = 329159
    text = __import__('base64').b64decode('ek43VG1tb3hCMkFTUTJZSFNGMjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ηЦнМνκзВ():
    value = 422232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAbqVFsPpq5bFgGy2myJBA8Kz38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ονэгιψАтφт():
    value = 7370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J33AY3YIros1DFbw4HOyPjUVtEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _КгныфЫдσΔΑьΘΠ():
    value = 316549
    text = __import__('base64').b64decode('bnMzTGYyTkdXR0NRNmRZRjg4Nkg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _θΜЪΧцΒΟкλтχΓΛ():
    value = 599548
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID7HXHcKx7pTGSiZ9wWiCzE/ylw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фБξΓΑΙфиρΕχЪМΙг():
    if len('') > 0:
        pass
    value = 864260
    if 96 * 34 < 0:
        868
    text = __import__('base64').b64decode('aVJyek9Gd3Z1MlpFQlBYampMYUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕхШεКдОИΑΙч():
    value = 701807
    if len('') > 0:
        pass
        713
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dhnvfwkvq75bYiSr0HOYZh85/Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зАОχΞЕаλ():
    value = 256791
    text = __import__('base64').b64decode('VDE5RjZZQlRuN2M3M1ZJMURNYVk=').decode('utf-8')
    total = value + len(text)
    return total

def _нАβωρГдχРу():
    if 66 * 66 < 0:
        pass
        _dead_3340 = 752
    value = 674336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px/RO3xvyapTPC6LmHWKJXQm02M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΕОαЪЧηοьЪу():
    value = 170826
    text = __import__('base64').b64decode('czFxNjdwRVVWM0RicDZVOFVPNEU=').decode('utf-8')
    if 66 * 24 < 0:
        pass
        pass
        638
    total = value + len(text)
    return total

def _НπФΤхсΡЛσУλλγБ():
    value = 616399
    text = __import__('base64').b64decode('ZmtnUVlobFZYMkQxekd3YTNBQ2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛρчдπЙЩчφ():
    if False and True:
        pass
        646
        _dead_9947 = 565
    value = 851570
    if False and True:
        633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAPdYgQU7a8bbDq1kQbIPgwcskE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _меБАΚШΜзьΨλΘнΑΙ():
    value = 506527
    text = __import__('base64').b64decode('eG44V0VCd0VuR0dMcVNxS25ERXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛηкΚСΧТΒχΨъα():
    value = 137332
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyXxUVM+xKUJb12c33/CbD0g7n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        209
        _dead_3553 = 494
    total = value + len(text)
    return total

def _гРΛαхγыτиΒ():
    value = 481301
    text = __import__('base64').b64decode('cTZSWlY1ZnY5ZmNMcGhhT3RDZGU=').decode('utf-8')
    total = value + len(text)
    if 78 * 77 < 0:
        254
        pass
    return total

def _ΚеΧςМЦτХΤХΑΙπθИы():
    value = 943855
    text = __import__('base64').b64decode('ZlpwYXptWjdIajlTMHhRenBGTGg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6898 = 266
        pass
    return total

def _ΗеχΓЦсΥΛδКδюо():
    if False and True:
        _dead_2061 = 641
        pass
        pass
    value = 982299
    if len('') > 0:
        _dead_9234 = 114
        _dead_5576 = 51
    text = __import__('base64').b64decode('dkpBNW0yemtXc3lvUXdFZzBValA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨчдзфΛжтжщцАω():
    value = 235552
    text = __import__('base64').b64decode('c2tTV20wNUJiR2ZwcUlrSDlWd2k=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        37
    return total

def _ηгΩАжСЦтсμτΗΛ():
    value = 883724
    text = __import__('base64').b64decode('VHN6VW5UT3F1bWdMY0N1Yk1KM3k=').decode('utf-8')
    total = value + len(text)
    return total

def _уУшΔрУКэжз():
    value = 209924
    text = __import__('base64').b64decode('VzlheG1mS2ZlYktHRFB5Y1NkU28=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΧЯθΘЦμЦσυчьΧуцИ():
    value = 310543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAfXOkFhwbkKLiOX/GW8GCcow3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЖДЧеНσуΑЯΒ():
    value = 453884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChrnXnMw1ptRIzCOzkS/OhoM60M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μχвςνВΩΟ():
    value = 530502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pwvgal4B7aYZFBionXOCbTAmz10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еьЮΠХςγΥГшλОд():
    value = 76027
    text = __import__('base64').b64decode('QWpmSWlSaHBiWVBjcVg3NWJtN1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ПцфεΕгоΗΦЩщЧш():
    value = 592059
    if 50 * 57 < 0:
        115
        _dead_4731 = 884
        pass
    text = __import__('base64').b64decode('Q3ZnRzdaclNUdjRlTGdlZ0o2WW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ρδДХОΕоЬλΥдδΜ():
    value = 737900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAvQfXwS0awoDxaK/XmDJnc4028='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6928 = 267
        _dead_6014 = 14
        pass
    total = value + len(text)
    return total

def _екЭЯйРгнι():
    value = 148161
    text = __import__('base64').b64decode('c1FlOU43RU1kOUJ5UGlTZTZDclA=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _бШзδΤΧεφГΡш():
    value = 525992
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnnbZlUD/LsGFCevnVS9ZiZ/tzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АτЧδлилвуπςЙαдνМ():
    value = 838875
    if len('') > 0:
        _dead_6459 = 60
        333
        125
    text = __import__('base64').b64decode('dWdfbVFwRWg0cHdmSG9VeXM5Ykk=').decode('utf-8')
    if 61 * 54 < 0:
        pass
        516
    total = value + len(text)
    return total

def _ЙЕγΕцЙψщФφБ():
    value = 125301
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX3mSX4o0olaKQ2o7mWTLRoX6zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лЦСωчΔаΟдλЧς():
    value = 706213
    text = __import__('base64').b64decode('dURkS0ZqREpWdzI2TzVidk5HUGU=').decode('utf-8')
    total = value + len(text)
    return total

def _δαуξΑАΧπш():
    value = 838930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRntPnI4yqUSCFqo6gOoDTIosls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьπΦυыЩГδЖШв():
    value = 651905
    text = __import__('base64').b64decode('WU1tQ0VOQ0hhNHlnS2l2RXRHdmI=').decode('utf-8')
    total = value + len(text)
    return total

def _БЬДΡгωχειМБчΨΡК():
    value = 673380
    if len('') > 0:
        _dead_1555 = 104
        pass
    text = __import__('base64').b64decode('TDJSRzdfR2dCWFpId0JpX0FUSms=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЯπιьБЖОΓВХΣκΟоσя():
    value = 910605
    text = __import__('base64').b64decode('ckJnOTNqV3EyekZQUWFxb0RBNEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΕνыДφκНασкХаА():
    value = 241509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAnAS0UX3IAPYj2t4HKjOwsY9Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξνЕΠΨΗСγσблЖΖΚΨь():
    value = 369142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSLpb2kL6acxPRahkESaAXIbyT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧеννЦΤОмΟΕнοΣ():
    value = 287419
    text = __import__('base64').b64decode('ZGF0VWVqR2U1NktBQ3c0akN0OWc=').decode('utf-8')
    total = value + len(text)
    return total

def _аЫЛШхΟЬαЫШ():
    value = 183750
    if 37 * 61 < 0:
        458
    text = __import__('base64').b64decode('WDFtcGZUWkhtbUlCdUlzZWtmeGo=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_8235 = 847
    total = value + len(text)
    return total

def _ρВгЗιΜЕΥБ():
    value = 373011
    text = __import__('base64').b64decode('dk1lMWVMMXN4a2pTS2JNMGVCZTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨЙгЙчЯжΣВθОΕЗπΑЧ():
    value = 445230
    text = __import__('base64').b64decode('Z0x1Y3pjR1AxVzVmUkdFQWxoX2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΡолΦЪμнΑΞΚΩΧ():
    if 23 * 39 < 0:
        923
    value = 882432
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jhb2P2ERr4BaA136/VODPH0Lxlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νюшκχΚΤΝБнΩωΚХ():
    if len('') > 0:
        pass
        794
        _dead_9535 = 488
    value = 162778
    if False and True:
        49
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eyb8PGkQ2qpTMDmI7Fu4BBIr63c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1735 = 579
    return total

def _фккΓХЖΤКмЪржмх():
    if 81 * 95 < 0:
        pass
        _dead_6126 = 43
    value = 116616
    if len('') > 0:
        _dead_6470 = 731
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fh3WbFUD9LABNF7yz3eKZxwE03k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        733
        14
        pass
    total = value + len(text)
    if False and True:
        _dead_3564 = 277
        _dead_8080 = 896
    return total

def _φΧΩζχхлЙθПщ():
    if len('') > 0:
        pass
    value = 843336
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXz0fmU90Jc6aVqA2nLHB3YgyFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХφЦΑВχаТΥο():
    if len('') > 0:
        pass
        pass
    value = 886883
    if 14 * 92 < 0:
        _dead_7482 = 5
        _dead_7092 = 152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATW8aFVq3/BUMR+OnE+pGCcL7lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯПщηδΗφФЫ():
    value = 277173
    text = __import__('base64').b64decode('QnF4VUhlV0xob2pOVThfblBsQUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯЙηρучАΞΔΩΒЧЛηъ():
    value = 984112
    text = __import__('base64').b64decode('YVZNd0V2X0lDaUdpUVpBakwxSnQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8767 = 377
        926
        _dead_7576 = 722
    return total

def _ТΨνρΧΖΖжТσеЫΕже():
    value = 65326
    text = __import__('base64').b64decode('Q01ZelJOeG1TT2g1clpNblM5YTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒЯВЩΛЖЦьΚэшΠюъб():
    value = 762484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgbtTHct7IIzDwzzmHqfMTB312o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αУЯνΦНΝаньΓЗАпμ():
    if 1 * 65 < 0:
        pass
        _dead_5849 = 416
        566
    value = 911459
    text = __import__('base64').b64decode('Z0NobnBSOHJhOE1kOTlETEtKWXM=').decode('utf-8')
    total = value + len(text)
    return total

def _шΛЛΤΧΟЮсΛΩφюЖ():
    value = 277638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgLRQmUs6rkGC1e3mw67ZHAC4zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4592 = 168
        pass
    total = value + len(text)
    return total

def _БИТνЪΒнΑжΥж():
    value = 142893
    if False and True:
        _dead_8883 = 165
    text = __import__('base64').b64decode('VDRsQ1lFcmFPZG8zSzhjWmNtYWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ςПΙηПΦΨχΙЙ():
    value = 458345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBbnVnot24ACGRWXyQOlIC47zWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МГΕΤнΕцяЗнеψ():
    if False and True:
        pass
    value = 231461
    text = __import__('base64').b64decode('R0FrU1Z3a3RPZUMwdHZISGV6ZlA=').decode('utf-8')
    if 8 * 61 < 0:
        _dead_8635 = 259
        _dead_8582 = 802
    total = value + len(text)
    return total

def _яκβбБαηЫпΣчкюηЭρ():
    value = 84545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyzIQwQf8oIxPiiQ30abOTAF9U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4230 = 74
        pass
        _dead_7547 = 235
    return total

def _БЫрРцжчяААаЮ():
    if False and True:
        _dead_9785 = 738
        pass
        pass
    value = 956441
    text = __import__('base64').b64decode('UDJwUUN2UmdSYV93WTl2SHNhTWY=').decode('utf-8')
    total = value + len(text)
    return total

def _чНЮокЧαе():
    if 44 * 27 < 0:
        _dead_8075 = 204
    value = 933818
    if len('') > 0:
        pass
        400
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBD0SHs68oAMGQT2xkSKEiR70HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗβλпзаЗвζ():
    value = 402136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnngeFMrz59UMz2qx2OWBS8kwzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жЪЯΨκΘЫΖφ():
    value = 65454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3ywYVAz5qMFCgSA6g+4GjV67VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чпРТгαβΚцΛкеедζ():
    value = 296735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhXKVEYb/44OLxWu42eKNzUHw18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8956 = 177
    return total

def _пГмДΒВэъПЗΘυъцХν():
    value = 977867
    text = __import__('base64').b64decode('VjBpck1HckFYbzNpTnYweGVoWlc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _НОΙΣΔγΦφОς():
    value = 310433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw29PVgXrqImFRer4UKHHQ8W1Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_4665 = 147
        972
    total = value + len(text)
    return total

def _ΝНЙМъΚъμФγΤΡм():
    if len('') > 0:
        _dead_6184 = 76
        _dead_5975 = 793
    value = 904417
    text = __import__('base64').b64decode('dzExbU9lMnN1Qmd3TG5UMEN4VVU=').decode('utf-8')
    if False and True:
        303
        7
    total = value + len(text)
    return total

def _ΒβщърΔΒкШЕγ():
    value = 146896
    text = __import__('base64').b64decode('eW9MNE9hSjRkTXJUd2FIYnkxY1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔФфнΟερжХξΕР():
    value = 485001
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hxb9VkBsxqU7FCOQynWXHzF70nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВθрнνФэеГКμ():
    if 48 * 14 < 0:
        295
        pass
    value = 518396
    text = __import__('base64').b64decode('SkgyQ2dXcGVJMXkwNDg4SVFGQTk=').decode('utf-8')
    total = value + len(text)
    return total

def _цХμЗΡсΣΡДΛΘΛСπ():
    value = 58545
    if False and True:
        556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICPjSwAT9L9XAjmJz12jDCEM5nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΤгщФВΨйπιЗТυдмφ():
    value = 607350
    if False and True:
        _dead_6554 = 910
        608
        pass
    text = __import__('base64').b64decode('d3NtdzVwcGs0dWd3ZEIyb1dKQXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ωφΡμΒηИΞΧερρНКм():
    if 73 * 49 < 0:
        _dead_6203 = 21
    value = 229178
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw3hTFU/z6MrO1eXym7BFyMc8Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 43 < 0:
        pass
    return total

def _дРЬСλυΣП():
    value = 403405
    text = __import__('base64').b64decode('TzcyUkpTYU9uRDcwT0d6N3BkSDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΓОДΟТйхЩФΗΩЖЯΠ():
    value = 905298
    text = __import__('base64').b64decode('SWhINEt5cElZZzRqZFNHcEJhalg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬμуηКъкОНН():
    value = 266640
    text = __import__('base64').b64decode('RmJxOXBHZUthVVJYNHNJZW5sYlg=').decode('utf-8')
    total = value + len(text)
    return total

def _еΔβщμчзнЙοе():
    value = 927590
    if 75 * 78 < 0:
        _dead_1371 = 192
        _dead_3000 = 499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3jsR0lrr4xQEiKpmFm5YwR+12I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫхΧЬеβжРмαΥ():
    value = 816274
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn3Lf1Yc/fEJMz6C6wKUMCII0Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧηМπизЙτКчζσЖΨλ():
    value = 157552
    text = __import__('base64').b64decode('VlMwNzVKRWp5bUtyTlBIeU02QTE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        663
        484
        _dead_7017 = 528
    return total

def _ОΖхХωΘЖΒШιАΑзш():
    value = 857324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz/nXggq04YIDS30kH2EZyYu0j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 86 * 96 < 0:
        671
        _dead_8665 = 502
    return total

def _фОμсЬγэζΗχлУΦЪΓЮ():
    value = 65506
    if 47 * 33 < 0:
        pass
        pass
    text = __import__('base64').b64decode('T0Q5QW92Z1ZVc1MxV2pmTUZqX2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _йΠХФЬйΗКйΙΧщρ():
    value = 768847
    text = __import__('base64').b64decode('UllxNUttWE5kRzVsVXZvemcybGk=').decode('utf-8')
    total = value + len(text)
    return total

def _лгБЩцψχХрсΟΩλ():
    if 37 * 48 < 0:
        _dead_4493 = 367
        597
    value = 796296
    text = __import__('base64').b64decode('cE9JUDJaa2ZOcFBWZDlaelBKYjI=').decode('utf-8')
    if False and True:
        _dead_6421 = 483
        pass
    total = value + len(text)
    return total

def _ΟбφΠмрАκбκΓΞΡ():
    if False and True:
        140
        _dead_3098 = 221
    value = 748440
    text = __import__('base64').b64decode('b2VMdVZrS1A0U3N3Rkt3NUZpN20=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        638
        pass
        _dead_6978 = 209
    return total

def _ΦУξβЧсΤЭФяЙφрБЫ():
    if len('') > 0:
        pass
        795
        845
    value = 659172
    if 41 * 87 < 0:
        987
        _dead_3840 = 202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lnrbdlcaz4U1LgWpn36kE3wkw1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        244
        349
        854
    return total

def _мкУЕΥΨЫвРΒΜγΑ():
    value = 192858
    text = __import__('base64').b64decode('c3BIN1BnNHBhT3paNUZaaWxicGM=').decode('utf-8')
    if False and True:
        _dead_8274 = 448
        _dead_6771 = 12
    total = value + len(text)
    if False and True:
        147
        _dead_1012 = 500
    return total

def _ДνθйжДмΩΤУΤДΨЙ():
    if 25 * 45 < 0:
        156
        _dead_4956 = 654
    value = 282808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3rSdwU9zK4XNxWNwXKUZTEa80w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        167
    return total

def _ΦΒσηЦΚαТОаДβς():
    value = 890945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICjlbwcg9ZIzAgmQ+F+VGisWwVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЬъФυОТοФвЙ():
    value = 666307
    text = __import__('base64').b64decode('RVlmWkk0bTVFN1lSTXdPa1RLZjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ИЗЙεифюЮΕεгЦнΩζл():
    value = 91458
    text = __import__('base64').b64decode('d1ZCN2RyNW9qSWg5dlZ5NU9MVUU=').decode('utf-8')
    total = value + len(text)
    return total

def _елΧЛρчшбΙбΦξμф():
    if len('') > 0:
        303
    value = 704466
    if 66 * 97 < 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('dU12MGVaYkV3YTFCa2cyUWpEb1Y=').decode('utf-8')
    if 26 * 90 < 0:
        _dead_7632 = 566
        668
        pass
    total = value + len(text)
    return total

def _рφьЩζЭАπ():
    if 21 * 87 < 0:
        681
        20
        pass
    value = 676413
    text = __import__('base64').b64decode('Zk9obERyc05IdGM0Q3NxbXhoajM=').decode('utf-8')
    total = value + len(text)
    return total

def _ъЦуЕκςζιΓρфЗξр():
    value = 611683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESzCaXwd1r4ubgGb3GWXPX0DtkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛШσдЦЯςьΗиθл():
    value = 512153
    if 72 * 11 < 0:
        pass
        _dead_2691 = 910
    text = __import__('base64').b64decode('RE9XMG5LRVZZSmxGSzlrTHhURHk=').decode('utf-8')
    if len('') > 0:
        _dead_1173 = 797
    total = value + len(text)
    return total

def _ЩаεЗРυψΜЙЯфΓ():
    value = 337983
    text = __import__('base64').b64decode('eGpod1ZSX1BKZmpUVWpfZFUyZFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _аβΦюжτΨХ():
    if len('') > 0:
        833
        _dead_1588 = 826
        478
    value = 874004
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAPxSgYjyaUCCwaFm3+yPAt21no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зσΠΧΙЭΖΟл():
    if False and True:
        _dead_2422 = 718
        pass
        pass
    value = 122085
    if 95 * 71 < 0:
        _dead_3130 = 175
        pass
        633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxDlbAc/5LsHFT2P7F2COgB64Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΨΝХмμоψНЕТωΕκ():
    value = 971118
    text = __import__('base64').b64decode('VVkzUGdWcnFSREQ0eWxISUdXeTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮкΡХΣυζнΨРΛоэζЙΝ():
    if 72 * 82 < 0:
        pass
        pass
    value = 805344
    if False and True:
        692
    text = __import__('base64').b64decode('VFZJTmpqMWx1T2NYeGxBSVNzR1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΘЖзηиЙЩСзβπρσвА():
    value = 229216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3rtYF0uqLFXCB213W6ALQEM91Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8625 = 944
        _dead_4886 = 385
        pass
    total = value + len(text)
    return total

def _КωΓπЙφκъСΡΝо():
    value = 474666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB/UWlwy2YM7EVaCwFe/Iy8F3FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣчТδΦΜрΚΨκΨφНмЮ():
    value = 553807
    text = __import__('base64').b64decode('TVJwZXdUb19VMGZybXJkdHhWM0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΓЩСЯКфΧтΖхф():
    value = 659899
    text = __import__('base64').b64decode('bVlNUExDaTV2cHZDNmljMHB5Q0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _οΛвЮОμΟс():
    if 52 * 9 < 0:
        pass
        pass
        103
    value = 498008
    text = __import__('base64').b64decode('eEhyQlU0MjgwNDdMZ01qd3ZRbTM=').decode('utf-8')
    total = value + len(text)
    return total

def _σрюСгнщХΗнэ():
    value = 248650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASHVP2UtqbBRK1ywkA+FJHAW6WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шжДΕеβСαЙГЙτШ():
    value = 479180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSbTO15grrkPAizy/E+vOw424Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εмСфναАγΗШ():
    value = 45005
    if False and True:
        _dead_2587 = 29
        pass
        369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxzQaW4L6IovIiqKmW+eOCcFtzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λаъθΔξнбα():
    value = 840543
    text = __import__('base64').b64decode('T0x2VG9NNjhUdzBLRjBuRTZ4ZG8=').decode('utf-8')
    if False and True:
        354
        pass
        pass
    total = value + len(text)
    return total

def _ψуκДгПμИΞθφχс():
    value = 996135
    if False and True:
        pass
        _dead_4217 = 858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH3VOARpyp87HV+b51egGSs19Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2989 = 197
    total = value + len(text)
    return total

def _РаυапαΤл():
    if 12 * 72 < 0:
        _dead_8754 = 8
        771
    value = 561426
    text = __import__('base64').b64decode('VGd2T2phYUVadWZGNzFDSDBoOEE=').decode('utf-8')
    if len('') > 0:
        938
    total = value + len(text)
    return total

def _йγΑΡδхщНυμτЭд():
    value = 235255
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBX0OQc60bg0OVin3FPALSEq9kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙςйΗШΙДΝСЩ():
    value = 613293
    text = __import__('base64').b64decode('R3Fob29WNE5JMXBvTDNsdk9OSTk=').decode('utf-8')
    if 41 * 66 < 0:
        pass
        390
        347
    total = value + len(text)
    return total

def _ьтЦТΞЧдβ():
    if False and True:
        128
        649
        404
    value = 715318
    text = __import__('base64').b64decode('c2tPeTZfT0RUZ3p6QmtjQlZDTE4=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _оцΜοЛιΤДдυПμ():
    if len('') > 0:
        pass
        pass
    value = 163212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDfGdH4Vr61SEhWS0g+nMBE+0jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞЭДэΗзФΑΗФΦеωΤκс():
    value = 572862
    text = __import__('base64').b64decode('dmpvY1YxTUpzT19PTlhZMG5NZFE=').decode('utf-8')
    total = value + len(text)
    return total

def _аЪωοЗЯΚтΩκуνй():
    if 20 * 71 < 0:
        _dead_2733 = 10
        pass
        143
    value = 209480
    if False and True:
        _dead_5047 = 813
        342
        _dead_2297 = 513
    text = __import__('base64').b64decode('U3VoRlRWVlBiUWh4N0tjek1nVEw=').decode('utf-8')
    if 70 * 89 < 0:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_1209 = 134
        _dead_2585 = 968
        pass
    return total

def _τυοЕΓЩζЗΝΑБμА():
    value = 294488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjfofH8Szb0ub1uJ/0+TORQH4Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4603 = 495
        pass
    return total

def _ВхяфоκзЖыЯΚ():
    value = 25977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjnxPnssraUKaTCr8GCHM3J37Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СμжρЭφοъρξысш():
    value = 558711
    text = __import__('base64').b64decode('QVNvdXg3N0I1V09hWHdxOWZ1VzE=').decode('utf-8')
    total = value + len(text)
    return total

def _υАВьНмйюриЯцμ():
    value = 300680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwHHaUcBrJgFbBah51KGIXwItXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙОсπΙξΑШ():
    value = 812111
    text = __import__('base64').b64decode('WDVLbDFTWWVDak1Xc2lJRXB1cWM=').decode('utf-8')
    if False and True:
        pass
        299
        pass
    total = value + len(text)
    return total

def _νθЕЛзЗςΝЙσΜмБ():
    value = 539988
    if len('') > 0:
        557
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3/3ZQMW5IBUDyaIylOYF3J7wUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        900
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        404
        _dead_1800 = 427
    return total

def _βΣγфπΒΣΨЙΛ():
    value = 41764
    if len('') > 0:
        _dead_5900 = 2
        _dead_7552 = 445
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AizgWHRrxK4mG12P43e9JQMLyUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζΓсбΧσΨвλΒЩофрЯ():
    value = 898450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH3RZkkjrf4NY1i5nFSFPAg6xTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГиΛΤУΒьτФшмΧанФз():
    if 70 * 62 < 0:
        646
    value = 432825
    text = __import__('base64').b64decode('cVZYeE01cE1ZZWtxbWl4VWZOdmg=').decode('utf-8')
    total = value + len(text)
    if 75 * 55 < 0:
        118
    return total

def _πМЩΖЩлМсν():
    value = 643795
    text = __import__('base64').b64decode('TFF0cmloekV5cktVSDBpbXNzSEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΒыΠчΛЯвγι():
    value = 960999
    if len('') > 0:
        pass
        535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCOxN2k9x7EPLzr1n3udERYtylw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 81 < 0:
        994
        971
    total = value + len(text)
    if len('') > 0:
        _dead_9823 = 829
        _dead_8562 = 971
        649
    return total

def _ΜЕОφюδευмΖъ():
    value = 776034
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BATTT3kU1o45LDaTxUSlAD8isD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _едТεβςПπчΟσЖ():
    value = 917801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR69WUhsza8lND+wkHGiFx8e5X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _джθанπдςЖч():
    value = 718596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQvgYXQeqf07aAyzy2K4GiY/7U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔφЕИςζърοыРΔ():
    value = 334913
    if 12 * 37 < 0:
        pass
        543
    text = __import__('base64').b64decode('b0JqY3RJU0dlTG1mYWlieHNka0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧкАУнεРμρ():
    if 19 * 77 < 0:
        _dead_1237 = 267
        pass
    value = 103472
    text = __import__('base64').b64decode('TzFtdVdUX05aVE1Bc0dnT2VHTzg=').decode('utf-8')
    total = value + len(text)
    return total

def _шщнфΑьбБяαуλЖΛ():
    value = 392486
    text = __import__('base64').b64decode('c1NTcmxQT0hKQmlFcnhHaGR2M08=').decode('utf-8')
    total = value + len(text)
    return total

def _СюζйАΝΑрΦайЕξдα():
    value = 671628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXzbYlMKzYYMGziN5kaEEhcI1nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νЯТбΨξαδещЮВΛΧυщ():
    value = 505014
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnrmQVUg94MAbCSa7HGIDQ97wn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζхΑвΣъΕеа():
    value = 348374
    text = __import__('base64').b64decode('TXFzMHgyeDA0Y2FMQ05tSV9Pb08=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЪПвΕьхΣСИΓчаβа():
    value = 37951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRC1dFZh/ZkVIiylnGSZHBx7xT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΟФгλШΛΗЦωФнк():
    if 75 * 22 < 0:
        802
    value = 974308
    text = __import__('base64').b64decode('VkVneGRSRTRialZ4UWRXZWhkaGk=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _дχЙуηрιΙэ():
    value = 204407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj/Xfn1q1/0vbhnywlPDY3cZ5kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        366
        169
        _dead_5107 = 728
    return total

def _кΟьΑаπηШПτΡΙБм():
    value = 506085
    text = __import__('base64').b64decode('S1pxNEJ0QnVmZFJIMnhIUk5SSGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ыХψςΤΜШξРσХФΤ():
    value = 969124
    text = __import__('base64').b64decode('dU56WXNCR3IwZDdWYzZZeHpRNVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖВБΤМиЮπцΚγΤ():
    value = 745433
    text = __import__('base64').b64decode('TGhaQzNRU1VkRFpmNGp4Y0twOXU=').decode('utf-8')
    total = value + len(text)
    return total

def _νГСΨΔκПΘηι():
    if False and True:
        _dead_2056 = 591
    value = 13654
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cxv9ZwAL9fgNBQOmw2SdI3Isz3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υЕΘχЯеοСЖ():
    if 16 * 59 < 0:
        pass
    value = 16703
    if len('') > 0:
        _dead_6867 = 590
    text = __import__('base64').b64decode('QnVGeE5JdWxhS213cG9ZZkJmSDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ωвδЦьτΘЩΕσΓксμθ():
    if 27 * 50 < 0:
        pass
        722
        _dead_7303 = 370
    value = 627622
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhbWagMMzIAtHQWt5l60BAMb3Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        593
        838
        pass
    return total

def _φβЙыъйτыπ():
    if 83 * 36 < 0:
        _dead_3641 = 382
        245
        967
    value = 271053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyvjfwMtqIYAblabzl+EIBYD91w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бХφОβжεΨоФ():
    value = 157348
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An3LXXU26L4OLgmTzVC0ZCwr4HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мОЭЮжйΨТЛцЬΑЗςыΧ():
    if False and True:
        _dead_6162 = 378
        pass
    value = 644131
    text = __import__('base64').b64decode('c3NTRjBaMXNpYkNNY2pnMHZySWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _лОΑυЦшΧъЙ():
    value = 663510
    text = __import__('base64').b64decode('WnFCbWQ5U0NETTB1clZ3TmFWdjE=').decode('utf-8')
    total = value + len(text)
    return total

def _γφфЭБжЫеαЕΦЧл():
    if len('') > 0:
        _dead_4436 = 364
        _dead_6812 = 435
    value = 827877
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn3uRW4cqvEIaDnw0k6mOzwA03Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хббчЬЪЦпЩεйφηлБ():
    value = 706382
    if len('') > 0:
        pass
        _dead_3928 = 572
        56
    text = __import__('base64').b64decode('R0FfeXVnTlBhNHZnbXJxRGtjbjE=').decode('utf-8')
    if False and True:
        530
    total = value + len(text)
    return total

def _ИμυМВВдΥьХνбУ():
    value = 799515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD7NdnYz7o8hADCHn1WUGCIEsXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠЕЬеΧХςΔΧφсΤях():
    if 51 * 7 < 0:
        pass
    value = 73533
    if False and True:
        _dead_1737 = 29
        _dead_5986 = 269
        _dead_8500 = 884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRvjQl4G0PoADD6t+ES8YnYX9G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЖЧъаγяθжЧРъ():
    value = 716117
    if False and True:
        739
        260
    text = __import__('base64').b64decode('eUNxeUhmamlNWEhUNGtXX3JkVk0=').decode('utf-8')
    if False and True:
        _dead_7968 = 699
        pass
    total = value + len(text)
    return total

def _зΔсГχΚсγьШΙυЪ():
    value = 467433
    text = __import__('base64').b64decode('bjFiRlRpYmhGRTBad3BsTmVaZUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _τЗьΦΓΓλβδζЙмΛΜβГ():
    value = 972391
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBi2ewYjyo0MFSrw6V+EBwB7zEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΑМΘВПοζΣХЫΟпΜ():
    value = 384922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDz1dwkc+oEUPQaG5ke3MBEh0WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬПςБОΙиΝвАΞ():
    if False and True:
        247
        836
        _dead_9596 = 866
    value = 356978
    text = __import__('base64').b64decode('amZtbmJMdXhWdU4xUjRZQl9NVlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩОрιОΚфΨΗ():
    value = 758623
    text = __import__('base64').b64decode('eHRxRjBGMUJ4QlJYVGtzbFpsclU=').decode('utf-8')
    total = value + len(text)
    return total

def _ωτφАФρИЙЧ():
    value = 438247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCfxa2kf5/wmGS7wnlCgYX0NzDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оБЛпЙСПяΖ():
    value = 221727
    if len('') > 0:
        _dead_4394 = 867
    text = __import__('base64').b64decode('RXZxWHdQUDJGVHdyWnJRYzlXUnE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΨΣяΚТΔуоЦΝΧИяеД():
    value = 958420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERvRY2gV65kqED2wzgGKYxMhxlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 84 < 0:
        282
        _dead_5106 = 406
        _dead_7812 = 206
    total = value + len(text)
    return total

def _θλьАςрзВ():
    value = 242364
    text = __import__('base64').b64decode('Q2dEYXR6cXI4SXpYdXlEYXBUZHM=').decode('utf-8')
    total = value + len(text)
    return total

def _μЦΑяιшаΠΘΤЦ():
    value = 847140
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDvmRFk2qY9UFTWz5XfFGSMZxW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЬпцΤЬзКШВзΔгК():
    value = 53132
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBjxQVY9z68XFzW0wXqILgt9yTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_2369 = 62
        pass
    total = value + len(text)
    return total

def _ΞЗΒЭπυеЙΝΟ():
    value = 783215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyTBZEgT6LwlGADy3UzJJyd+3ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИьЪЙεгυΑюнνйμ():
    if 53 * 75 < 0:
        354
        pass
    value = 633249
    if False and True:
        _dead_5713 = 430
    text = __import__('base64').b64decode('RXFYaFRqXzRvZUY3bW1rbU9meFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΞΟКдψэχнфαЦфвΧ():
    if 92 * 15 < 0:
        pass
        pass
    value = 978282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh7cS3Np0PAiLAWO5V2VHBwM8XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жНнσбΑыыпто():
    value = 468105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxvldlYK8Ko8CFeU+lfGAzEMw3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μжЯΒЕоЩΖτΝФВчФщ():
    if False and True:
        245
    value = 363316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3mydgQ80qIXOV238GC/YHI2sjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΕоаπΡтх():
    value = 383444
    if False and True:
        _dead_2217 = 222
        _dead_6329 = 725
        _dead_5562 = 672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3u2SnIJyKQ8CFin2w7BHzAJ/mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _няΒиюΥδАινЦдθ():
    value = 914301
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('VDdVQmJidHlTR2F4R3NWM3F2WHc=').decode('utf-8')
    if len('') > 0:
        _dead_1991 = 197
        _dead_1812 = 425
        995
    total = value + len(text)
    return total

def _жαξΕηπаШ():
    value = 136145
    text = __import__('base64').b64decode('WTVTd05YdzlvUGo0VFNEMFRQejQ=').decode('utf-8')
    if len('') > 0:
        _dead_8701 = 408
        184
        336
    total = value + len(text)
    return total

def _θΒОгФыτШоЫиМηФ():
    if len('') > 0:
        892
    value = 643191
    if len('') > 0:
        102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnvmZmdvqKwEIiaa3Q6KERYdvWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        780
    total = value + len(text)
    if 25 * 30 < 0:
        _dead_2744 = 732
    return total

def _οΣЛΟюьλΥЦΡвς():
    value = 615211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAe1N3ow64tQIjqKw3+HMw094lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УνΙΕςЫшФ():
    value = 376743
    text = __import__('base64').b64decode('REtENmprUW9LcnZCbzhUOVo4V0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞшЛТξНΞξч():
    value = 835683
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAnJNkNvrKBWKz+25lSkMQkD12w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2372 = 893
        _dead_2015 = 357
    total = value + len(text)
    if 46 * 29 < 0:
        193
    return total

def _лмЭЙАΨчΑЯг():
    value = 173681
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhnNeUMe2fg1ET+S7g+UbBcB51s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕЛЩбΕЙанφ():
    value = 594527
    text = __import__('base64').b64decode('UXVQN2wwX0RGbXdZQm9lYlIxdWw=').decode('utf-8')
    total = value + len(text)
    return total

def _бДъЙеТщπн():
    value = 823145
    text = __import__('base64').b64decode('b2w3aG1XcG10c0hNVEVWWFhScDI=').decode('utf-8')
    if False and True:
        _dead_3743 = 530
    total = value + len(text)
    return total

def _υкэλΓωыΩИΡΦΣΠЖЛ():
    value = 294229
    if len('') > 0:
        pass
        981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3jgS3Ua/6cnFAL29162AXYA1mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АмΥвλΘнЮЭН():
    value = 190769
    text = __import__('base64').b64decode('RUR1Vl9EUFlsN0lDdzBQVGFrb3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣэъЗωμιх():
    value = 949856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KC79SlMPy4MVaFqm/mOBZSIN5Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чФЩΨЭηЙЗγΖ():
    value = 723959
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHrGTGcQ9YxTECSk4GW2EBIG1nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8757 = 929
        _dead_4423 = 439
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()