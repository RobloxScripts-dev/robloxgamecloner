#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ыЯκψмοдНΠьнХУ():
    value = 116148
    text = __import__('base64').b64decode('cjdqcG9ZVUptMDhkcTAxZ1pkM2k=').decode('utf-8')
    if len('') > 0:
        pass
        833
        pass
    total = value + len(text)
    return total

def _гΤψηЩρОБ():
    value = 666121
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAnQXFwKzLA1PwyE5XCkHDMesmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νζκΣмγпВ():
    value = 720926
    text = __import__('base64').b64decode('d3BWZlE2bDdTeHhSQWs2TVlWSjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪУσΩХЦАθοΥФΘбΘ():
    if len('') > 0:
        189
        573
        _dead_8002 = 251
    value = 502147
    if 87 * 97 < 0:
        20
        _dead_8558 = 116
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH3dTAQg/IMbOz22zU69OwR65WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΥНтфΖΩЦЮсΑκΙфρсς():
    value = 869892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQfNS0Rhq6RVPz2pzEKjMiY66m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мβЖθГκЙэα():
    value = 953622
    text = __import__('base64').b64decode('UHhkclNvNndhTGxIR3pITmNTRUw=').decode('utf-8')
    total = value + len(text)
    return total

def _βКσщдЛХΩ():
    value = 938451
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiTmXXoh2bFXbxa18F+1Hxw2xl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4557 = 56
    return total

def _фнΙγбΗΜеΩΠΓφу():
    value = 939801
    text = __import__('base64').b64decode('ZGpwZGQ5U2k2dHg1eGU3bVczY1I=').decode('utf-8')
    total = value + len(text)
    if False and True:
        868
        pass
        pass
    return total

def _дтгλωвиь():
    if 88 * 74 < 0:
        pass
        pass
    value = 440951
    if False and True:
        754
        418
        _dead_7983 = 858
    text = __import__('base64').b64decode('dGM5RTdkN1BKTWU0SW5HVVhmVm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ψшРТтыχωкъЪСО():
    value = 275429
    text = __import__('base64').b64decode('bkJLRnRkSVo2ZHMwam1zbUlSRmo=').decode('utf-8')
    total = value + len(text)
    return total

def _хСЕууΓНБдиЯЮ():
    value = 456438
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBbSRmgc0Y0oHTX17G6eASQi10E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 93 < 0:
        _dead_7721 = 632
        _dead_3940 = 613
    total = value + len(text)
    return total

def _ΥЭΔрЙοФΓе():
    value = 220886
    text = __import__('base64').b64decode('SURFT21qNjVGUkw1S1lTMERXS3A=').decode('utf-8')
    total = value + len(text)
    return total

def _μдΓкэγэεΕφ():
    value = 164082
    text = __import__('base64').b64decode('akZGMWl6anphUzdlZDlvZEJJUlg=').decode('utf-8')
    total = value + len(text)
    return total

def _юαбхтΙЗыΣзф():
    value = 581904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyOxankKrZAUCleZ2EXHLAYD730='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςξПδКρъыΕФРКΨσ():
    value = 8895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECfCflRg/LAvKymb2Wm/PSd60Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        911
        228
        _dead_9324 = 620
    total = value + len(text)
    if 89 * 100 < 0:
        112
        pass
    return total

def _νΦСВευεыΑзаηМЮ():
    if 76 * 13 < 0:
        pass
    value = 209773
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQHCYlcz+6MmIwyHkETBOQF9yl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΗЪμΖΝчыΓ():
    if False and True:
        _dead_1537 = 821
        103
        803
    value = 109919
    text = __import__('base64').b64decode('VWNubVJoUjJzWTNoM0xEUkoxMEY=').decode('utf-8')
    total = value + len(text)
    return total

def _жЗβсμΜоЛДЛРъьΑщ():
    value = 997747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR7QeH8K/L4IEy6y/QGgAnce5UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4343 = 357
    total = value + len(text)
    if len('') > 0:
        _dead_9479 = 161
        pass
    return total

def _ПνΝΨτΔри():
    if False and True:
        _dead_5713 = 835
        pass
    value = 570864
    if False and True:
        _dead_8785 = 686
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExfQf3kDz/E3bza0wFudLR8t7Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кξЧРΥЖФКЧλщψщ():
    value = 689200
    text = __import__('base64').b64decode('R3diYkJHNjZRNUozQmUwMWFHR3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥθжхрΩЙЬрΙйпт():
    value = 784495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iw7mRFZo2KoIFlqS0gGcbB0L20k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жφьМэΒрНХЮЮгрЙх():
    value = 54544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDbUbVga5JwPHVu3/n/IAxUaxUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΗΟεпδτиГ():
    if len('') > 0:
        610
    value = 400631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQiyOkgDy602bguh4nylByN71Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9251 = 840
        _dead_8690 = 635
        _dead_1742 = 15
    total = value + len(text)
    if len('') > 0:
        139
        pass
        _dead_8786 = 240
    return total

def _εЙΩйыηЖгЩ():
    value = 272798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LT3MOFUWyIooHg6pxEeVDCsJsFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψеЛЧφрПНΘΘън():
    if False and True:
        pass
        800
        _dead_4633 = 631
    value = 313733
    text = __import__('base64').b64decode('UVEwY0JYekZpVFphVFZqX2J5REE=').decode('utf-8')
    total = value + len(text)
    if 65 * 27 < 0:
        pass
        575
    return total

def _σΒЬшаωшэБρУФЭЧЗ():
    value = 77636
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ngr0RWQQqL82OT2UwnDDJiccwGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФуьΞνΙЫхаλΡУ():
    if 9 * 70 < 0:
        831
    value = 577597
    if 17 * 54 < 0:
        28
        pass
    text = __import__('base64').b64decode('VnRTeU5ZM1pHbENfcWN1Wm54UEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΑМΥрхεюМжуΞ():
    value = 740857
    text = __import__('base64').b64decode('TzVZVnRRY21NdlZ4UWYxQjZmNEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ιμΕΗУσВтΕъμζээД():
    if len('') > 0:
        pass
        _dead_6572 = 906
    value = 839381
    text = __import__('base64').b64decode('aktwenJTNDhFaWw0bUYxT3lfQTA=').decode('utf-8')
    if 26 * 44 < 0:
        876
    total = value + len(text)
    if len('') > 0:
        _dead_8484 = 248
        pass
        pass
    return total

def _снЮМнЛьШψ():
    value = 374369
    text = __import__('base64').b64decode('YUhhVXhiYTNrUDdaUm9Bd004bUU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _одМфΝКМΥ():
    value = 657992
    if len('') > 0:
        _dead_9474 = 321
    text = __import__('base64').b64decode('RDBSQkQzdkhSeDE4RUZCYTd6Rk4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        885
        pass
        _dead_9869 = 172
    return total

def _ΩмОηΑЭЩеΦфгΣЛ():
    value = 939337
    text = __import__('base64').b64decode('aVVaUVFiNGpPd0RJV25jNVlqYlk=').decode('utf-8')
    if False and True:
        _dead_6950 = 691
        384
        _dead_9183 = 29
    total = value + len(text)
    if False and True:
        pass
    return total

def _эσφИΛРЩшэхУИρΟ():
    if len('') > 0:
        _dead_3148 = 334
        _dead_8822 = 906
        pass
    value = 100534
    text = __import__('base64').b64decode('VExUMnBFaGJvdUp5NzBDWGdPRkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΡиЧОЦщсЮЗλΡФυпχ():
    value = 27153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQnnXUkg+YVUCQeznHqzMnUd42U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΦΧΠπсхχИσ():
    value = 35644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyvWT1M60ZohMDeP/FGpHAEf0D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧωΔфймсШВΙОθчΓд():
    if len('') > 0:
        _dead_7993 = 54
    value = 108692
    text = __import__('base64').b64decode('SFNfV0gxc1NVUTd0VG9wcWQzRjM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        400
    return total

def _ωΕДАςΓТЙωξГ():
    value = 770981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KS30WEE17ac2IgKJwwe0IicAsF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЧжбΕрЮьсРζΨεЫя():
    value = 230356
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh3lTVUTrrkLHwSa2QaTBxB8/Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        24
        91
    total = value + len(text)
    if False and True:
        863
        230
        pass
    return total

def _ΜУονмшаИьΒνйф():
    value = 369775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FD+ybHVp+qozLlb78keTDSof1zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        375
    total = value + len(text)
    return total

def _ХΥьЬνЗгЬρю():
    value = 319016
    if False and True:
        355
        507
        922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH72bwgxzIkbPh+N6U/INw0+038='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БτЮωсОвρ():
    if len('') > 0:
        354
    value = 896611
    text = __import__('base64').b64decode('Y3Z0MDlnYWJOOFNaaWlWbkpTQkQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ОиРзбЙОтΠНрщъιУ():
    value = 541847
    text = __import__('base64').b64decode('WnprdENmcFB4ZTR1akkzUE1FOTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬπПπгЕκΟТГзЛш():
    value = 961832
    text = __import__('base64').b64decode('TDhBTnpXSEowb0tZcldldDZXcXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΚчνΚΤяε():
    value = 533865
    if len('') > 0:
        _dead_8468 = 896
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQjLeXsx//AOIyawzFrCLXwOtWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νдΔВΗхМпр():
    value = 214306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgTmRUUr864pbguJ3kS3ISB3yHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΜЬрЬжуΦΦΩЗ():
    value = 981666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhrtO3lq9IUhYgTz8HipIXA5xko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        421
        540
    total = value + len(text)
    return total

def _σБτοΦчхΗζсъКУΛ():
    value = 646794
    text = __import__('base64').b64decode('ZkdydWVYOUd3QXZ4cDAyWjhfcmE=').decode('utf-8')
    total = value + len(text)
    return total

def _τогΖъΕфοζχЭψыа():
    value = 242144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESfiXF4uqYYrKCKb30/DEhYo7WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εнΨΥΟλПΨτрюйЮ():
    value = 809683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD3mUWEBwY8qahicmESjbQZ/tXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΚИЯЮΠΗП():
    value = 632727
    text = __import__('base64').b64decode('ZVBxUUFtUkl3RHZfb1VHU1JaVk0=').decode('utf-8')
    if False and True:
        _dead_5857 = 801
        pass
    total = value + len(text)
    return total

def _ЬоΦξΩххνχаΧ():
    value = 354681
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD71a1oRzLhWNTCbyQ+FBQgWz2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨδЗΡηЬЦΝ():
    value = 419325
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAXue3ws1KRRHAqHz3uFBnB4znY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иαгωЭОееΦ():
    if False and True:
        pass
        pass
        _dead_8805 = 857
    value = 580712
    if len('') > 0:
        _dead_6639 = 477
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ni7hWX8Y/aAbNQrwwXO1Nyd6xW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _АИЬЛоыШмЬР():
    value = 864442
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyfpZ2UIzaEFPgmL7lfANgIExl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωпΒиΠθΟΛУβЙфΗЭьг():
    value = 353453
    text = __import__('base64').b64decode('V21ZcHp3UnFRSEhGU3djeXEyMG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ρωЮшлЧΑπξκЦКБ():
    value = 879325
    text = __import__('base64').b64decode('ekQ4YVpYZ01Qb3JVOGJxcndsS2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЮШВΛΨηΑХчλ():
    value = 618342
    text = __import__('base64').b64decode('bE82WENYVlM2a21jNjFScFJtaHM=').decode('utf-8')
    if 97 * 46 < 0:
        pass
    total = value + len(text)
    return total

def _НφщΙΓρЛλжΖ():
    value = 678087
    text = __import__('base64').b64decode('b3pVa2JYUEFKUEI4UEJDeWlIU1I=').decode('utf-8')
    total = value + len(text)
    if 99 * 51 < 0:
        pass
    return total

def _ΥΟщШМэучΧφЙй():
    value = 313075
    if len('') > 0:
        759
        _dead_6900 = 821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADjsaGAay6NWKwWc0AWlYQkC3jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟНΨοяЪюъωЬСуА():
    value = 154165
    if len('') > 0:
        _dead_9440 = 277
        pass
    text = __import__('base64').b64decode('SFJsVWRqRnVQQ2NmWTNWX0dqSDY=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ФωХГρρЬтΚЬυыЯдЭρ():
    value = 21335
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSrAd2Yz1P0Fby76nw+BEyh+3Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λγτчьΡΖгфпλЪК():
    value = 800214
    text = __import__('base64').b64decode('alRqc256aFFHWXhSVE5LTVphR3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _нΜеЭВЗцΖВ():
    if len('') > 0:
        pass
        pass
    value = 304318
    if False and True:
        5
        _dead_9517 = 10
        _dead_1625 = 469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kgy8RFo4rYw8LzyFnWKxPQF/1Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ЫфЭИДкЦΗ():
    value = 488349
    text = __import__('base64').b64decode('V0VjZEsxY2F2WHlSOXUzZHUzVVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΞОΞЭЩЕвЩμθз():
    value = 932917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg7bbAdgrYcJCyuCxUTIIygbsXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рεпκЩлГшоюу():
    value = 449625
    text = __import__('base64').b64decode('b3JlMWZyU2k5cEZGeWJvTFFXc3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦСпΖрΜюΝ():
    value = 393193
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCXyO3gqxIouLlaTz1XFGz0gxzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 77 * 47 < 0:
        675
        _dead_8452 = 936
        _dead_8018 = 572
    total = value + len(text)
    return total

def _чЭΥκиΝХъρ():
    value = 512365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M33XWUJt04YmHDqZkFvCOBV5yjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        186
        pass
        pass
    return total

def _νΠгΩЪτΟеΞДПР():
    value = 649860
    text = __import__('base64').b64decode('S21vZmRxWjBwNVdtcmlYaFhfVEc=').decode('utf-8')
    total = value + len(text)
    return total

def _УОаиБΟγэρг():
    value = 258952
    text = __import__('base64').b64decode('c0wwQ1E1UVdjSTFrR05WdHpjTng=').decode('utf-8')
    total = value + len(text)
    return total

def _вαδЗгхРθдпΞВα():
    value = 16623
    text = __import__('base64').b64decode('QWV1V29ucVFvOGtYakZXWkdFQTY=').decode('utf-8')
    total = value + len(text)
    return total

def _βсΜвщηΦΧςуфωκ():
    value = 164579
    if 90 * 67 < 0:
        pass
        942
        990
    text = __import__('base64').b64decode('WUd3T1RZZjdDa2trUWwwQU5rcUw=').decode('utf-8')
    total = value + len(text)
    return total

def _φοΛшκиъγ():
    value = 869567
    text = __import__('base64').b64decode('cU1PblE1QTRjcjdpMXkzQnFzdEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _БТΦтИΚΧΝκσΧШГЛ():
    value = 884588
    text = __import__('base64').b64decode('cEtQUUNxTzI0WnRpM0Jac05aemk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒЪаСьВЪеЮххΔотН():
    value = 426342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCTFZkRg56wvMgSr7kylOQQp7Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣοЖρуβасα():
    if False and True:
        427
    value = 52482
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IizLQ1w00rgwaCqEmATAJzUq6VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        833
        593
        _dead_3375 = 595
    total = value + len(text)
    if len('') > 0:
        _dead_7320 = 563
    return total

def _шεφΜЕЩΞλхэСΨгσьЧ():
    value = 658514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBjxUVRrzKQ2FReT2WSWDigi8Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΤАΜΧιчьΑφΙΗАΓΓм():
    value = 216777
    text = __import__('base64').b64decode('ajVwSWNMRHo0bnYwZTBLZjhGQkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑЙθтРνЙУбιуЗг():
    value = 899449
    text = __import__('base64').b64decode('SWxNQVpTUENVQUplajJ1U0YzMW4=').decode('utf-8')
    total = value + len(text)
    if 41 * 90 < 0:
        pass
    return total

def _МΖαБЫАης():
    value = 304598
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P33MZXUB6fBVKVyU0Q6eLS4Q/Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШыπСжнΓРВβЫФФοгЖ():
    value = 249077
    text = __import__('base64').b64decode('eGpTVkxtT19iaTBSTmlVcnpMbVo=').decode('utf-8')
    if 8 * 25 < 0:
        _dead_2662 = 508
    total = value + len(text)
    return total

def _мжгλψдАеГ():
    value = 282056
    text = __import__('base64').b64decode('ZHhROEsyQmVYWG50anFZSjh1eHM=').decode('utf-8')
    total = value + len(text)
    return total

def _хσЖγλΛфыΨюДκγЪΛ():
    if 91 * 84 < 0:
        pass
    value = 451533
    if 78 * 33 < 0:
        614
        pass
        pass
    text = __import__('base64').b64decode('QTB1S0hqeThOWmhMUDhzU0k1TkE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _νΡуΝψЗЭβтσуПГ():
    value = 908110
    text = __import__('base64').b64decode('dDBHa1E1dzFFdm9QRUZJZG5XOE8=').decode('utf-8')
    if 47 * 5 < 0:
        pass
        212
    total = value + len(text)
    return total

def _ТьΘЖΜСмπНКχИ():
    value = 653345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDrRYHZuqrIsazqvmEyBMh0lx00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΨэгΩΧжθТЧхΣωβТ():
    value = 949746
    if 56 * 68 < 0:
        _dead_1145 = 435
        _dead_3013 = 968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzeyY2QW7Js1Kl2p2VqqORUDy2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        415
    total = value + len(text)
    return total

def _ΙЫΗявбХВΖЦδΓщρУ():
    value = 423840
    text = __import__('base64').b64decode('aE9ENHlfVnZ4M0xSVndXNjZSTUM=').decode('utf-8')
    total = value + len(text)
    return total

def _КъΠκρТΖйгΩβωπл():
    value = 90296
    if 67 * 63 < 0:
        _dead_9764 = 21
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MR7SUXQO1JlQDD+l/Xy5GjAo1lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7609 = 125
        844
        528
    total = value + len(text)
    if False and True:
        991
        339
    return total

def _ЛΛγэΝοΟΒ():
    value = 529557
    text = __import__('base64').b64decode('VENkbWJldUtFZnhWbEFGVURQNVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _φκшцωΦфφεξλрб():
    value = 289778
    text = __import__('base64').b64decode('TjdHYThqZElEbVhYYVhlTkRuOHY=').decode('utf-8')
    total = value + len(text)
    return total

def _рЙЙЕаЙξкЭц():
    value = 865581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwbhV30OzasMCgukm1qTNw8qvWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цφзδрУФξ():
    value = 293100
    text = __import__('base64').b64decode('YVlHVXluQUJUeEU0Sk9UVGZOa0o=').decode('utf-8')
    if 8 * 15 < 0:
        _dead_9676 = 835
        pass
        _dead_5690 = 133
    total = value + len(text)
    return total

def _ΧчγэЪξьБΧМΗЗвн():
    if len('') > 0:
        pass
        _dead_6993 = 98
        _dead_2009 = 577
    value = 904313
    if 85 * 51 < 0:
        _dead_4859 = 368
    text = __import__('base64').b64decode('VzBOTWxMZlJoXzRBY3B5TDcydmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖРшЧΦξΩΝ():
    if 49 * 47 < 0:
        402
        671
        _dead_8945 = 526
    value = 197250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dhv2R2Qg+/4tIl702GemExwY52o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 93 * 72 < 0:
        926
        pass
    total = value + len(text)
    return total

def _λцσНспэуεΕζΦΓω():
    value = 3694
    text = __import__('base64').b64decode('czVYNzBiXzM4WWluYWtta1FBR3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬшΨΜΥΡРςнΩжНТчΣн():
    value = 613273
    if False and True:
        114
        113
        _dead_5187 = 279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LT3WX1cP/YoFEF7w52yAEi0s3T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зШЭыΨьФοΔВπу():
    value = 989918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An22el0cx6klBRe1mVTHBXd30ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΑОцьгВΨΘпΥаМλ():
    value = 947234
    text = __import__('base64').b64decode('bnlpeWpNVWQ2ZlhJak1paTZFUk8=').decode('utf-8')
    total = value + len(text)
    return total

def _жΡЙιЖΦΠΒιчьθЙй():
    value = 508403
    text = __import__('base64').b64decode('a1VCWlkwTXo0R1NKXzZ6M0pKX3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЬБωмΓХЧДЗπжшсСэ():
    value = 521837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyH3O0YgrfguKTyakF2XYyMp8lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МОрΠΨчΚΝым():
    value = 330697
    if False and True:
        _dead_8345 = 719
    text = __import__('base64').b64decode('RW9fVUNJQ1pEVHNlSndTblduY3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬαηθПΛсδаΞ():
    value = 989710
    text = __import__('base64').b64decode('aVlGa2tWcHI2SVhwVGhRaGZLNEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЩΠеξБΩхΕ():
    value = 308674
    if False and True:
        236
        _dead_4993 = 409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj3SX3UA0PA0AAS0mUCpYxMg7zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩξЪχшЗДЗскы():
    value = 609249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITrjWn0f0P8TBQen3mGvPgAI6E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кХОеСΥйΝ():
    if len('') > 0:
        _dead_2150 = 966
        pass
    value = 53509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCzFS3YP9JwaPzurwkaTEBM1sn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΡыΖхηΟΘГХΠнв():
    if 47 * 36 < 0:
        _dead_4703 = 586
    value = 557174
    if 44 * 81 < 0:
        12
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh3nfUQ4p7gVKCOWwQLBFhA64Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЙСΣαγцπЪйВκ():
    value = 430725
    text = __import__('base64').b64decode('QU5ncHZpaWlib3hHZHBkdzQ5TlM=').decode('utf-8')
    total = value + len(text)
    return total

def _κψηРКйχЛΠэфΝЮг():
    if 95 * 31 < 0:
        _dead_9738 = 693
    value = 356730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjrTREsQ5/wsHT2Z8A6hYREXsDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 86 * 78 < 0:
        882
        _dead_3480 = 279
        673
    return total

def _ΝЗкВψПъВвкιВΑ():
    if len('') > 0:
        615
        pass
        pass
    value = 42027
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSX0XQcS6Z0FDgWw5wWaZzIi4Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7164 = 226
    total = value + len(text)
    return total

def _сЕαЗφρуγω():
    value = 856486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCDsRkY8560Mbyq1wV6aAAh90UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГβаЫνΕτУαθ():
    if len('') > 0:
        pass
    value = 943105
    text = __import__('base64').b64decode('WWZQY2JyX3VTNGNvRjk1TDlhVkM=').decode('utf-8')
    total = value + len(text)
    return total

def _оФΞσρυвэΠЙν():
    value = 879825
    text = __import__('base64').b64decode('YXpxMUY3a3B4NDh6NmlFQjlfNEY=').decode('utf-8')
    total = value + len(text)
    return total

def _чρмцЪпεэщ():
    value = 762928
    if 55 * 68 < 0:
        796
        pass
        pass
    text = __import__('base64').b64decode('aW5YWTBxT3RQWG9wODlnUGVGa1o=').decode('utf-8')
    if len('') > 0:
        _dead_1258 = 401
        _dead_4798 = 477
    total = value + len(text)
    return total

def _μθдаθзшЯцΘλф():
    if 82 * 99 < 0:
        731
        97
        709
    value = 699882
    if len('') > 0:
        _dead_7835 = 460
        917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3bKYXY10P06CBaw5V3HAx8K7Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΤЛΘΗφШΡαтΩλБπΒХ():
    if len('') > 0:
        pass
    value = 348841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRnKZFUu8bEwNxWA/3eqMBJ870c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        345
        pass
        _dead_9442 = 425
    total = value + len(text)
    if len('') > 0:
        164
        pass
        _dead_4990 = 524
    return total

def _ΝΠшΘщνШЭднθΞνΞ():
    value = 232184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXjHOQYU/Is6bAC02H23Jxco8mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εсЕЬσууΝфФдЮ():
    value = 327850
    text = __import__('base64').b64decode('bzJUMG42aUpIeW56M21fUUpBYzU=').decode('utf-8')
    total = value + len(text)
    return total

def _εΟωШΞΘωΟςΣЭ():
    value = 950440
    text = __import__('base64').b64decode('WDdjTzhBU3BwSlFtS1d0U0I5TDM=').decode('utf-8')
    total = value + len(text)
    return total

def _йιТеΗΓΤνцбНΒПД():
    value = 324126
    text = __import__('base64').b64decode('RWhhZ3U5cWFZaXhYY1RLc2xlRmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ηВвоТуЙДΘ():
    value = 34419
    text = __import__('base64').b64decode('aXFndFREZERnZU9xYzJPSTFZX3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ВцСцψяяψэ():
    if 58 * 69 < 0:
        pass
    value = 360502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kyi8TEto7YkFCQS750SRITN5xUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПθЬЭПΨшлβκΛйΒДк():
    value = 892064
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3q9OWc28robAz2g92OTLR0I5T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΕχнгΠЩКμ():
    value = 751607
    if 4 * 12 < 0:
        980
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISbDZgI09ao6KwawzVi3PxJ/4Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΡЫгХцιБМΜвξ():
    value = 975401
    text = __import__('base64').b64decode('SzFyaW5faVpBTkY1aTFxTVpDSVk=').decode('utf-8')
    if 51 * 2 < 0:
        713
    total = value + len(text)
    return total

def _ΧнΨИΡшФГχэΣЧя():
    value = 826511
    text = __import__('base64').b64decode('VGtaQlpld2xHZEY0dXNQVWVvRHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ωърΒιЬχαΚΤ():
    value = 882677
    if len('') > 0:
        pass
        pass
        _dead_4485 = 931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3f9RkE6yvsBEQGa3Ee7LQ16sWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕМуΖСΖЗЖЙЧΦ():
    value = 23153
    text = __import__('base64').b64decode('aWZkdF9EVlZ4SjRfdGJHNWRBUGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙχЭβЬьБνεΩ():
    value = 633497
    text = __import__('base64').b64decode('STlXcjdCcTRYMldNa29QMTRQeFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯХΖМЪΚΝЪρЙΝΧВРфχ():
    value = 681307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3jnOnUS/5A6Eiqk2mGaHgkr20M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дръοРγьΤЖДγ():
    if len('') > 0:
        pass
        _dead_3985 = 764
        211
    value = 516436
    text = __import__('base64').b64decode('cVFKOU5zWE1aVUVBR1RQNXNnQks=').decode('utf-8')
    total = value + len(text)
    return total

def _ωЯФзцкΠъэΗФΠ():
    value = 555082
    text = __import__('base64').b64decode('SlByTDRWRmhXUTc4SlpybUswYVU=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if 49 * 16 < 0:
        pass
    return total

def _жвКΒяξοΩ():
    if 19 * 36 < 0:
        _dead_3686 = 868
        762
        _dead_8255 = 549
    value = 151140
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgbWdEUN2/knOSDz2X2vIBYstV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΧεлцйμЮЩзЫ():
    value = 544336
    text = __import__('base64').b64decode('ZG1BUlk5Q0Z3Q2h0QmVFRlZ0NkU=').decode('utf-8')
    total = value + len(text)
    return total

def _шПочΥоΥδΛΔ():
    value = 916924
    text = __import__('base64').b64decode('VzZaY3NEenB5RUliTmVHTGxnZVk=').decode('utf-8')
    if 61 * 84 < 0:
        649
        pass
    total = value + len(text)
    return total

def _ΒΕΩмэФΥЪ():
    value = 827095
    text = __import__('base64').b64decode('bUtVYzFpNjJhb043RmxuaGNMWWk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7810 = 487
        _dead_7964 = 586
    return total

def _дοχЯдПΞΣфщκйΔ():
    value = 76516
    if False and True:
        _dead_9566 = 887
        _dead_4549 = 571
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzywVwU2+p1TFwiz91SgJRU7s00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΧΜЬТρΦΖЦνМΩБ():
    value = 119468
    if False and True:
        _dead_9660 = 36
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxjGfAkKqoRQIFis3lKGGzE4s0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 55 < 0:
        472
    total = value + len(text)
    if False and True:
        _dead_1315 = 941
        pass
        pass
    return total

def _κΔХшМηαшУШςЪышУ():
    if False and True:
        189
        pass
    value = 612822
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCDDSFsc2otVOCin60ajNQk71EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8454 = 872
        pass
        _dead_3551 = 456
    total = value + len(text)
    if len('') > 0:
        494
    return total

def _БδΕτΕςЭΧ():
    if len('') > 0:
        _dead_7888 = 611
        pass
        pass
    value = 343144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ND7rP1QVyoIQDwmQ4lu8GQgF52E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чМэшШΥэЗΑбв():
    value = 405628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSnzSwAIyaYiA16A0HCKLiQetUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιдхΟλМИνХΕβφμЛзΟ():
    if len('') > 0:
        480
    value = 835429
    if False and True:
        694
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD/lNmRo/6s6aBry+2mjGnEi1n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙьЩНИζρηьЩыθфиля():
    value = 904297
    text = __import__('base64').b64decode('ZTA1cHFMUFpJR010RWFxSFAyZFQ=').decode('utf-8')
    if 9 * 15 < 0:
        _dead_1616 = 818
    total = value + len(text)
    if False and True:
        392
        pass
        pass
    return total

def _ОυΜрщΣхзПРРуЬ():
    if len('') > 0:
        pass
        447
    value = 428696
    text = __import__('base64').b64decode('dVVqY09zMmFwYmtmTnZNbjBHNWE=').decode('utf-8')
    if False and True:
        765
        _dead_5651 = 805
    total = value + len(text)
    return total

def _ΟсΗОзΔΑσΤвΛΦкхЦИ():
    value = 424883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQL3ZnQNpqBWKTmBzQCWLQM5538='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уΧЫКсзΔΩЫо():
    value = 463394
    text = __import__('base64').b64decode('S2x2dmNickxkSWJocDlyZWM1clQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΙхξЯЗКΨ():
    value = 161585
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxW3amMM7pEbKCikxQK3ZhQs5VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΧэдОуυюΙο():
    value = 587855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mzn8THM70oxQCVeS8g6HB3wY0EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 31 * 77 < 0:
        _dead_8187 = 413
        pass
        270
    return total

def _ЩζУσюзлбοкй():
    value = 216644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDvRV1IK36ZTbFuc93OFAgMA3FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥДξΟшеΡАЭнΠэшΜ():
    value = 672440
    if 76 * 54 < 0:
        _dead_7561 = 318
    text = __import__('base64').b64decode('RGJsdTF5eGs5ZzhucDR0eDh2cnQ=').decode('utf-8')
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ΩмвЯюаΡлвςьХдАив():
    value = 350971
    text = __import__('base64').b64decode('Y1N6ZUsyOFpFUmljYWxtcE02ZHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓрюъηΝνи():
    value = 978664
    if len('') > 0:
        _dead_9305 = 370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBzsSl9q16khAwaH+We4MQwr7m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        891
    total = value + len(text)
    return total

def _паπΔщςΦжСЭЬΣ():
    value = 550502
    text = __import__('base64').b64decode('Q0draXhVUmtMTjlCZUNjMTRQNnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЮОΑыρЬП():
    value = 913399
    text = __import__('base64').b64decode('alNuQWtqOWpuc3pBN2dLVUVGaE0=').decode('utf-8')
    total = value + len(text)
    if 70 * 37 < 0:
        _dead_9200 = 735
        pass
    return total

def _уδЗιΣεвбΔЙкАΧ():
    value = 714580
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FD3JTEAzqY0BIhmg3kCWZCJ+3jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 84 * 68 < 0:
        _dead_8454 = 848
        930
        _dead_8611 = 657
    total = value + len(text)
    return total

def _ηУуМщΣΒЕКудΛбо():
    value = 8761
    text = __import__('base64').b64decode('Z3JHVVNVdGM0NEhHNjdzTUJqZ20=').decode('utf-8')
    total = value + len(text)
    return total

def _УжΑкЖΑΡτ():
    value = 320135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHzifV8Q5vAUPVeFz3G4MAc50Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧЮжлрΖδПлΩЫачψ():
    value = 929917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH7OOVYq+IwuHA2B/lLFHBx3130='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        271
    total = value + len(text)
    if False and True:
        467
    return total

def _ψΔΩюεКωΒ():
    value = 776124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzrsR3hs6PtbIyOczFHJYC87yEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΧιΧСщрψв():
    value = 623886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHfRWEQxrLIkOQKB5UynIxM+8mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΚГнΡЭОΔяЪΞи():
    value = 621294
    text = __import__('base64').b64decode('cFFTb2drcEQyNjJKNUZqdkR6aHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ιωχпΔЩшβиκΒмыКΗ():
    value = 596251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axf8VFQMq5JWMBv7xEGzEyB63V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РУЦбλΓоТВΥωВχ():
    if False and True:
        pass
        _dead_8783 = 788
    value = 851730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxfIYAYd3ZoqDSyN5F2CN3AO8ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΕΥсшеΘцИΞЭΒΞβΜ():
    if len('') > 0:
        _dead_6184 = 329
        _dead_3005 = 924
    value = 163689
    if False and True:
        pass
        866
        _dead_9216 = 221
    text = __import__('base64').b64decode('cHdJbW9rSzBZZ3N5elB2YzBjRF8=').decode('utf-8')
    total = value + len(text)
    return total

def _КΝγЗЯβεΚΑΟз():
    value = 701685
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzyxbQY2ro0yKF+t6XiiORd33F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΘПчяοДФИщ():
    value = 109806
    text = __import__('base64').b64decode('cl9uV2ZSSXF3RzBYQWNvbDVtZFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡцΓуеФΒη():
    value = 112885
    text = __import__('base64').b64decode('bkE4c2x5aW9oUjNrU3RobFd2WjU=').decode('utf-8')
    total = value + len(text)
    return total

def _αэгαСΓΚчъ():
    value = 570629
    if len('') > 0:
        568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz/PTEMxyfFQKiWOxUeKOAwixjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        621
    return total

def _бщΙъищэзаМρТγжνζ():
    if False and True:
        _dead_3862 = 634
        27
        pass
    value = 169055
    text = __import__('base64').b64decode('dmtiN3liWHBmcko2Qk1pcWNrU1A=').decode('utf-8')
    if len('') > 0:
        _dead_8997 = 166
        517
    total = value + len(text)
    return total

def _ΧСφΛкνпεΥΜρ():
    value = 511070
    text = __import__('base64').b64decode('U0J6RGZYbkFROFhQUU9vOGc0dFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЮβΣМΔΙЮЛкжОφ():
    if len('') > 0:
        _dead_8038 = 345
        pass
    value = 563488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETvDOn0w2rAVLAH3xmyeMz0Y9EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юωфЮИσΠωЦюОΚбσαχ():
    if len('') > 0:
        466
        817
    value = 297664
    text = __import__('base64').b64decode('UVVKNDd5M1NVUDdXc3plQ243cUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦцξΚчЩΑΤΗьΟхЛзЯЙ():
    value = 650989
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnzdTAARppEkNTCQxVWyZHJ9wjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΚπΠρГзИ():
    value = 523676
    text = __import__('base64').b64decode('ZVBwVVNzbmwxdTYxb0xaeUJrdjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΔΥАХΘφд():
    value = 412531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KijTWmkLxIM7NgWcnW+YH3181GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8678 = 25
        _dead_5059 = 178
    total = value + len(text)
    return total

def _ΗпьΙλΓυНюΩац():
    value = 346583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiuxXXMRq50WA1+W42+kJw1//j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЩΠЩπΤΧегσλΩЬ():
    value = 316841
    text = __import__('base64').b64decode('bnBRZGNzdlBtWThtSXVQaXJFT00=').decode('utf-8')
    total = value + len(text)
    return total

def _чςιρщΟдЫИбιНзЩ():
    value = 25336
    text = __import__('base64').b64decode('QW9ibzhhVW1zSDFqNWhPMGkxTWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΨЩусшвηфМΑСРр():
    value = 534053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwLhRUEQzoRaEAWu5FLAOit2tGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 60 * 34 < 0:
        445
        _dead_7060 = 435
    return total

def _оыЩдбΓмΨл():
    if 98 * 83 < 0:
        _dead_9696 = 274
        pass
    value = 571703
    text = __import__('base64').b64decode('cHZNSHdrRFdGdmZiMGM5Vk1yR0U=').decode('utf-8')
    total = value + len(text)
    return total

def _цгбυνйΖиХ():
    value = 867216
    text = __import__('base64').b64decode('amRhZGV6czNZOXpkVTRKT3JRczE=').decode('utf-8')
    total = value + len(text)
    return total

def _еУЫΝяφыζк():
    if len('') > 0:
        pass
        _dead_6614 = 669
    value = 327836
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FibXVG4D7pFSNQ6cymCUNSgnzD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οπεОμρΑЪоφ():
    value = 707381
    text = __import__('base64').b64decode('U0lSVlkzSHpDV0xZejlrejFxR0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨДиθеφΨБΥ():
    value = 364432
    if 59 * 51 < 0:
        _dead_2709 = 844
    text = __import__('base64').b64decode('QWdHUTlWZUJoemtIWFRpRFpkSjA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        182
    return total

def _ИсνСΩЕΖΣκАасП():
    if False and True:
        _dead_2189 = 271
        pass
    value = 222448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BD7MaQc8qp8NbBqK7FyyEzAY/Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 67 * 75 < 0:
    695
    pass