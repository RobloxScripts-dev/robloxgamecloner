#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _σЕъΒΔΔОюПдΨ():
    value = 24435
    text = __import__('base64').b64decode('UGpyMWliTVFwMXNETmZ3eXRQbEo=').decode('utf-8')
    total = value + len(text)
    if 81 * 83 < 0:
        _dead_1637 = 306
        162
        _dead_9750 = 80
    return total

def _ХλρΖШΗюβМχ():
    value = 153953
    text = __import__('base64').b64decode('STNMdkVuMTZ0QkJzYVBQVEQwUXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖацйзщЮЮΗνΖВ():
    value = 90438
    text = __import__('base64').b64decode('RVRGczlNdGpEYVhQNmZkWThGdEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ВСЮмΖМЯΔн():
    value = 495390
    text = __import__('base64').b64decode('ZkFiZWZ2UXV6YktLSTNQQXhJcEY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _БфПτИЬоτΑΨ():
    value = 602472
    text = __import__('base64').b64decode('Y216dmNhNnpFZ1htcFlwdkpaZ1k=').decode('utf-8')
    total = value + len(text)
    return total

def _χиδАοэτОδυθψχΦЮ():
    if len('') > 0:
        pass
        pass
    value = 259848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH3GQEIXqbk5P1v67gaxNg8Jy3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_4191 = 953
    return total

def _ШΩΔАвΝρЖλψЛωΨΑκ():
    value = 866484
    text = __import__('base64').b64decode('QkJDT0c2akhSWURPdlIwRmNnQU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡρЩчетβςЧКηрμΗυб():
    value = 290489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXryb2A41ZEhGTDyzljCPgEc6Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΓЩΖμУηЫΝЭЩРД():
    value = 841416
    text = __import__('base64').b64decode('ekhMVWltdkt2YTQ5WGR4dElBcXQ=').decode('utf-8')
    if len('') > 0:
        682
        466
        895
    total = value + len(text)
    return total

def _ΒφЮшΓнПΙ():
    value = 690691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Biz9dGAs9/8GGSya0HzJH3J+zXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОαСЙΝАфвΦ():
    value = 154812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH7nOwMO3f86OTiyxniYOit/5Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уψγωОωмЪΦψΦΞδνМ():
    if len('') > 0:
        pass
        pass
        183
    value = 337437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiDLVABoy78vExzyyQCjITN3yVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κξΖΑΖΑгΔнаэαщ():
    value = 31277
    text = __import__('base64').b64decode('Z2xfVkllTDJJNXJsS3lESXhnM0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣБΨсКвΙπЙπΔД():
    value = 787260
    text = __import__('base64').b64decode('RXNES3RjUkhocUNwSm5IZkdpV24=').decode('utf-8')
    if 41 * 14 < 0:
        854
        _dead_8292 = 520
    total = value + len(text)
    return total

def _ιΓЖцΣχτЪЮξΣσ():
    value = 615574
    if 77 * 35 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzXHYmct/4QFDQ7zxlGZDXR9vGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩЖιλθГωДΤЧ():
    if len('') > 0:
        pass
    value = 458730
    text = __import__('base64').b64decode('SmM0elJodGlRdzRwcWwzNXpxa2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ГиРКшΞθηуЙσЛδП():
    value = 129380
    if 59 * 77 < 0:
        _dead_6598 = 273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCXrSG4x+IEJPw3z8lS3Nx988X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΔЯлερΧΩоШЛκΘ():
    if False and True:
        pass
        75
    value = 565306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXbFSAE70aYsaB3y5lG1Mxc1zjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _зИΔИАχусωοΞОНЭ():
    value = 322538
    text = __import__('base64').b64decode('VFBFZzFURmxOQWNLOE04TFFHaGQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3239 = 187
        278
    return total

def _ЬΘνСъζΓКνΜ():
    value = 520677
    text = __import__('base64').b64decode('d1g0emJyVF9mQ0FfV1NQZTNDMnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _МЩАСςЩюцξярЙЩΖ():
    if False and True:
        954
    value = 918421
    if len('') > 0:
        108
        657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQi8flQ02rotNiKG/FK8BiM50zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        709
    total = value + len(text)
    return total

def _НБθУоμтψкцτ():
    value = 788662
    if False and True:
        _dead_7134 = 575
        pass
        116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRv1V39oz6pVEVf32VqpLC8txm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 20 < 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        216
    return total

def _ΑμκтРзгоψНКΙ():
    value = 960389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCDtWmQy24IkaTqJxFnHJDYb4mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 22 * 87 < 0:
        _dead_1430 = 693
    total = value + len(text)
    return total

def _ωЖХсШМΟС():
    if 98 * 1 < 0:
        504
        _dead_2103 = 989
    value = 199299
    text = __import__('base64').b64decode('QmVlZlljZnN2SnVjSUNGRHBPTlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ИχΙМъСΠЗаФЭсдс():
    value = 884935
    text = __import__('base64').b64decode('TkMzenhRWWFvV0dRRGJaVDJvSkE=').decode('utf-8')
    total = value + len(text)
    return total

def _элΒнΟлβмνΜъКκЗ():
    value = 28481
    text = __import__('base64').b64decode('SnVnSDIzQ3NNNldOOTNhbUFzX0Y=').decode('utf-8')
    if len('') > 0:
        _dead_2961 = 29
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2457 = 441
    return total

def _ΗвΓчЫщйжЩгзТΙЧХ():
    value = 57377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgjIO1so7K80AFeb2VuKPzElyGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зжμоцτΞЛ():
    value = 771419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESbBXmsOqqQKPjaKxWS/YnU3tWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 4 < 0:
        pass
        pass
        60
    total = value + len(text)
    if False and True:
        pass
    return total

def _ъъδΧαΞУεΙфА():
    value = 322749
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDrIdwkDz7IyMAC652STPnUbxVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Гыθмδгρлтм():
    if 58 * 94 < 0:
        583
        913
        _dead_2421 = 963
    value = 107967
    text = __import__('base64').b64decode('c1VrbTJxTVVXalVtTkIzTTAzYjI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _зΧщΧцБЪфыΗйбιИΟ():
    value = 231581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQ7ceFIXqaorFRe1416qCz0H8V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪфηКрΜНΞ():
    value = 171239
    text = __import__('base64').b64decode('RWlpTTRCRGlBQUFPZUxXVkpwbHk=').decode('utf-8')
    total = value + len(text)
    return total

def _НцΥвШΔΖУΩ():
    value = 199864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAfcTH8r66QbGFeP/V+JLCM4xzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔЭвΑМΤъуЪΛσчщшЛ():
    value = 166605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjbpY3cv74VXPQuc/2S9ZzMYwX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 65 * 60 < 0:
        260
    return total

def _ЮжЬоδΩΕγζηιΞь():
    value = 882938
    if 90 * 96 < 0:
        pass
        _dead_6492 = 585
    text = __import__('base64').b64decode('dWdCbmVQM2c3dEJ3TG0wTVRpUlY=').decode('utf-8')
    if False and True:
        151
        _dead_8173 = 910
        pass
    total = value + len(text)
    return total

def _ηоЦυфпΦεдΤψ():
    value = 488117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAi0emco2rBRbCGlxW+XDhZ6s1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙсАйЧвхФкα():
    value = 712073
    if False and True:
        221
    text = __import__('base64').b64decode('dEhBYzNkN011T2hsZzliZmwwdTM=').decode('utf-8')
    total = value + len(text)
    if 19 * 2 < 0:
        pass
        pass
    return total

def _ВяυепΗрЖΚ():
    value = 920662
    if len('') > 0:
        pass
        151
    text = __import__('base64').b64decode('bXBxVmdqUWQzaFlpeFg3Y3dBRlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨθοΡдΗОηηχРΚμЩ():
    if False and True:
        _dead_8348 = 124
        455
        256
    value = 319729
    text = __import__('base64').b64decode('RlRvbTVIRmhWaHNwMnMxb0VKdWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ШχμωЬΗЭжЩΞФ():
    if False and True:
        623
        pass
    value = 95535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCneRAkg5vAuaiaL/kKXDhI/9Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        499
        pass
    total = value + len(text)
    return total

def _ωЧОΝΩфбАΠЯΩьβ():
    if False and True:
        59
        _dead_7372 = 614
    value = 954591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQTjXQQ/86M5FTycwFjGEBA10UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_7572 = 729
        pass
        _dead_5065 = 164
    return total

def _γМлοмΤГу():
    if len('') > 0:
        585
    value = 369678
    text = __import__('base64').b64decode('V0JVRnJoWjVGRHJTWGhqT3R1X2g=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        477
    return total

def _ОМЧЮωВШШεЬγω():
    if False and True:
        _dead_5765 = 601
    value = 406910
    if len('') > 0:
        pass
        926
    text = __import__('base64').b64decode('RGF6NGlEcUY2eFVpTmhaQnFwcWI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        437
        pass
    return total

def _юнΒйβоЗΖ():
    value = 540600
    if len('') > 0:
        _dead_2773 = 146
        652
        530
    text = __import__('base64').b64decode('Y3BEaW14SmhlOUtGdHZHSU9XbF8=').decode('utf-8')
    total = value + len(text)
    return total

def _εчιΓомВХΒλУеЗΥ():
    if 23 * 5 < 0:
        pass
        _dead_6633 = 986
        689
    value = 498615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnznZ3Uyy4c8HlqawFC4DAgYw14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ХζΟшЭйЗТСδ():
    value = 162919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAzsZwA21IoAEAPy22nBOzAn9Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖЗюЩЗθΟΛСОΧ():
    value = 221058
    text = __import__('base64').b64decode('VnpiNkRrSWVGc0xqUXRFMjhaN2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨеяκБΑΒшΓ():
    if 57 * 65 < 0:
        356
    value = 242555
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB7KQlgXzKcOMxuXxFShFgY1sjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 38 * 83 < 0:
        194
        882
    return total

def _ьΚВξПзБΚξцΧГΨ():
    if 78 * 97 < 0:
        881
    value = 627398
    text = __import__('base64').b64decode('QnV3QTU0MU00SXpnamlmaFl1Q1Q=').decode('utf-8')
    total = value + len(text)
    if 87 * 79 < 0:
        _dead_3553 = 755
        pass
    return total

def _ДхΙΣΕоΝпцωΙ():
    value = 224323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H33vZ2ETpqYzaFysxW+WHD8u1Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1861 = 313
        965
    total = value + len(text)
    return total

def _ЯτеуКяΧπΦΗ():
    value = 112345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lw3XXlsrzbgMCB6B+H2WHCc8z2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чуФчεΜЦЬУ():
    value = 701292
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgHqYgM02/8GESmhxALIGA8l52U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ацΤЗмйωκчцν():
    value = 133487
    text = __import__('base64').b64decode('RXNkaXAzdFFtRVl5WGlrT3ZoR1A=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        137
        pass
        861
    return total

def _цЬЕΧσΡРεВьπаЛφЛ():
    value = 506114
    text = __import__('base64').b64decode('U05vVFFpbHpMX0hOejFTcnlwQ3g=').decode('utf-8')
    total = value + len(text)
    if 10 * 38 < 0:
        pass
    return total

def _ШνοМШΝΞΓЛλΡνТΡσм():
    value = 899414
    if len('') > 0:
        367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh7rUUE3yoI7PBr2wnivJD8msTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3420 = 118
    total = value + len(text)
    return total

def _ΚΜЩγююЪКдδЯοяΘωΗ():
    value = 701344
    text = __import__('base64').b64decode('RlpuYlhNSndVNHdsZnJDNnJhcFg=').decode('utf-8')
    if len('') > 0:
        716
    total = value + len(text)
    return total

def _ΓрДЧСηжΔΗχςΜγЩК():
    value = 490871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQDnfV9qz6RQFCm6+lmdOiI7/Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΞЗэΧГяΔθζЕνОр():
    value = 687454
    if False and True:
        776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwC2bEQX7PsFCzrywVDFA3c53Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уАзАφοМю():
    value = 70717
    text = __import__('base64').b64decode('b2FldWNqckUyS3NUQlU4aDFINlg=').decode('utf-8')
    if len('') > 0:
        _dead_6284 = 992
    total = value + len(text)
    if False and True:
        105
    return total

def _АтχШьΙБΔξο():
    value = 1020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAeyd0Q+rKoHGxa342yBJnA8tm8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 4 * 68 < 0:
        _dead_6474 = 188
    return total

def _ЮУСЯηЖФΣ():
    value = 945807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyPJUUBrzqlTNzu07ASYYnUE8XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯмΩвεΤуωЮШРΙЦ():
    value = 518586
    text = __import__('base64').b64decode('WHhRNjBPODR2blZweElFTzh0YUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒаЦЧтΡыθΟΕННр():
    if 82 * 13 < 0:
        642
        406
    value = 866946
    text = __import__('base64').b64decode('Rjh3S1RBN3JkM2xnQmNzdU5FVUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΧβΤЖаьЩеуШМУЭьщ():
    value = 705481
    text = __import__('base64').b64decode('Y1JlaU5FdnNhMl9haXh0ektkbkY=').decode('utf-8')
    total = value + len(text)
    return total

def _нМρΖΙФььΡΜ():
    value = 441997
    text = __import__('base64').b64decode('RXVjbGpXcldFZnNmZEhvTE1mN0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΠквТρОψ():
    value = 659813
    text = __import__('base64').b64decode('ek9oNUdQWjExYTVqUWNCNUVZZTg=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        99
    return total

def _θЙдаΨΗтыЦθ():
    value = 827589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAj1SAIS3aAlADmG/FepExMn6UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        870
    return total

def _МΣпуΦУбЕθЙΥъЩи():
    value = 589400
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH/UOmky9KxUH12CxVOKMBEHz2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8218 = 890
    total = value + len(text)
    return total

def _ΖДтцκЩΔακВ():
    value = 119447
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgnxSEc+2I0RKAa0/AeoLRI24zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΑΗζκуσΑγРг():
    value = 105213
    text = __import__('base64').b64decode('QzRTRmNkVnI5NWVTem5mdmNQWTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭьχЩδΒχΝΩ():
    value = 483744
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Czf3dmAM1JwpBRur7k+SJSsn8jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зωлСсΨУяςκ():
    value = 400205
    text = __import__('base64').b64decode('SG1iN2FXdFZTWkR2Zm1iZmdOX2U=').decode('utf-8')
    total = value + len(text)
    return total

def _НξΜДνчλюη():
    value = 434013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3nJfVxv3YsTFRu5mXujEyd7vEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΣοЧСПдыЕдр():
    value = 130554
    if len('') > 0:
        521
    text = __import__('base64').b64decode('akxRSWVZVFUzZnBkRHZDWmUzRUE=').decode('utf-8')
    if False and True:
        179
        pass
        _dead_7816 = 506
    total = value + len(text)
    if len('') > 0:
        _dead_5120 = 210
        pass
    return total

def _ΔβΝЕΛΞцфοвЗедΣЖК():
    value = 467838
    text = __import__('base64').b64decode('QmJuOUYzR0V3Vk5iOGttMDBDRU4=').decode('utf-8')
    total = value + len(text)
    return total

def _чσуδЬКТκи():
    value = 182221
    text = __import__('base64').b64decode('V1h6N1QyWUtOdXh1RExFbnRrakQ=').decode('utf-8')
    total = value + len(text)
    return total

def _щξЙΕщδςкЛ():
    value = 219442
    if len('') > 0:
        _dead_1319 = 921
    text = __import__('base64').b64decode('Wm42aFM1aTJFY1dLRHVyazExVmE=').decode('utf-8')
    if False and True:
        _dead_2489 = 727
        pass
        745
    total = value + len(text)
    return total

def _шЮьρφιЪВЛэΞμ():
    value = 32654
    text = __import__('base64').b64decode('UWdXcVppVEtHVnE3cWQzWjdoMzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪθπΧΚνцξ():
    value = 431125
    text = __import__('base64').b64decode('TWFQc2U3SXhVMFFIR2w3dGxJeUc=').decode('utf-8')
    total = value + len(text)
    return total

def _КмΥЭпρνΚщфЛМК():
    value = 240634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgLcbEJs5/taEyCZ/1KAMisYsWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мыКηдЬΒшΒнЪΝ():
    value = 521583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRnMeFAL1oY7ChmO3le7FSw96nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мρиρΕκιΞθσнΧμ():
    value = 40018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwD0YEUIxokRAguBy1DFGHMt7Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гЗшТЯьэΗЧΨΤПШΗ():
    value = 369460
    text = __import__('base64').b64decode('Qkp5aEI2djAxMkxLSGVBX3VyakY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮпΚΡρТнσηδЙΨаЮΙ():
    value = 86121
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx3BQ0QM0poWORq742KELAMuwTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        321
        502
        pass
    return total

def _ΑΤλжνнΞΞъпЭиЕь():
    value = 660426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiXGYnUfqrwxaj+v3V+CG3Z23Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠπВКпЯπΓхфΝх():
    if 69 * 93 < 0:
        347
        _dead_3622 = 141
    value = 942257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXvIe0RhqvoEFSyv3EWyO3wZ7mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЕгмцЖОВωщπ():
    if 86 * 88 < 0:
        _dead_7794 = 31
        pass
        504
    value = 838323
    text = __import__('base64').b64decode('RE4ySWZZMGdnNkxCazJPdVNTUFE=').decode('utf-8')
    if len('') > 0:
        958
    total = value + len(text)
    return total

def _κΟΒπМΕΡΒΡαдЦзκе():
    value = 458393
    text = __import__('base64').b64decode('eVNIV0NBaHViSW91QlFHYmp6U1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _яχрσаΑирΟв():
    value = 639791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhXDe2s8qfAtOV+pwXSvHSYb40Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьРφγЖοΥψξЗВОΒф():
    if False and True:
        pass
    value = 183695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3bXeWEBq4waNjm18AOaJxYJsnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыμеΛюλЫιΜБл():
    if len('') > 0:
        pass
    value = 852067
    if 22 * 22 < 0:
        646
        _dead_8725 = 89
    text = __import__('base64').b64decode('YklfNFJWcXNaSDJTQUVKRFUzdUI=').decode('utf-8')
    if False and True:
        _dead_5476 = 608
    total = value + len(text)
    return total

def _БΔУШЦюащЖФнςсΝΔ():
    value = 247507
    text = __import__('base64').b64decode('UG1hbENocEZyektUNW1KZE41YUg=').decode('utf-8')
    total = value + len(text)
    return total

def _жяфЪψЩСТ():
    if len('') > 0:
        pass
    value = 565803
    if False and True:
        _dead_7150 = 569
        83
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Czy3SAkf8pEEFhmVxwaTBhoE8EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _тфюΛсогψΡΡмдднΡΨ():
    value = 114158
    text = __import__('base64').b64decode('eU4zeFhxakV2Sm5hd3dEYWhUTmw=').decode('utf-8')
    total = value + len(text)
    return total

def _юСГТрРЙΠРυФχΓΤνΧ():
    value = 846296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyLeP3Qa6r48KiCEwHicLAZ8wj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 33 * 41 < 0:
        503
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΓуηоςηηЪмбп():
    value = 640996
    text = __import__('base64').b64decode('VXZ3VUwzS3NkVVo3VlNkRDBrTVk=').decode('utf-8')
    total = value + len(text)
    return total

def _щЕνθоΜцЩΗ():
    value = 234493
    text = __import__('base64').b64decode('dkFKRFF1M0VkVjV0eVpHaFgyd2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓрτΔЫМИЩчΨчяΣЪΟ():
    value = 961322
    text = __import__('base64').b64decode('b3V2UWd3NjI1UTVfMUNfeUp2eFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤжФΕЪωьΡ():
    value = 418995
    text = __import__('base64').b64decode('bVd0MGdYbEU4WFNyYjNNNmhFYm4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        558
        _dead_2433 = 324
        _dead_2879 = 609
    return total

def _щЬξΜоΨμгъΛΣδЩРυ():
    if 91 * 26 < 0:
        868
        268
        _dead_4002 = 612
    value = 263372
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjvBe38IxKAbHTa1mgaVJgZ6/kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑυВδчдЗО():
    value = 313869
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRWwRF4X05dbHlqEznPJBQ4K0F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сθьΔРςηхΜ():
    if len('') > 0:
        pass
    value = 724178
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQ33ZHk40qciHRzx+gS5Jx0j1WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7537 = 329
    return total

def _жАιнΑЫζыУп():
    value = 406948
    if False and True:
        pass
        pass
        735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxDrOVYgyJcBNB+T71+7ZyAF8D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2742 = 170
        _dead_3824 = 0
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _рτАΖсΕнξЦΓΚдИ():
    value = 935621
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAjIRQgcyqE3BTj74UavAXMV73Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬЮыеΝХΡсцьΧМыП():
    value = 871370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwPMYUEN0qAtDVn66l+oPSoCsTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σωФΘаИΞйЕбИмΦИαп():
    value = 612430
    text = __import__('base64').b64decode('UExOald6eFNzVzlfV0JaWmhTQmk=').decode('utf-8')
    total = value + len(text)
    return total

def _МΒЛуοΧтО():
    value = 123408
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mgj3e1Bsr/0rHCKbyVemETd9wzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _впςнРΝΚмЛУπбΓЛθъ():
    value = 821272
    text = __import__('base64').b64decode('SFBPa1RfWDFlZjJCUmxxNVQzeTk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6716 = 326
    return total

def _ЩΝεфЛНьхΣ():
    value = 580364
    text = __import__('base64').b64decode('TkwxcFpKZl9ZQWdZYm9zbG1GbGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗЪЖЛκΧКДαЦТй():
    value = 615128
    if False and True:
        _dead_9999 = 812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lwr1Xkga/4YOGw6r4nGiZQQq9Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        147
    return total

def _зφυΘЖУхοςЬГрзΧ():
    value = 548005
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IibITHot+KAaPB+Nx0K4Cx18yWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еХЫΨОфЮВφУА():
    value = 187831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCboQWcsyY0AFCS1kQ6xBSII22s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 58 * 63 < 0:
        _dead_6690 = 887
        _dead_6536 = 427
    return total

def _λЛΥЬрРкюТЛЮш():
    value = 541962
    if 53 * 26 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzvufVUf1pkCIC6T50OKZnwg4Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6420 = 816
    total = value + len(text)
    return total

def _φΒДηΙЛГρξСцтΨКЧ():
    value = 427083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwfOYnUq/Y8oPA6y73yeAXZ25mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РГбьσАψΩСνρящдΔ():
    value = 809334
    text = __import__('base64').b64decode('aUhWbVh6S2JEaWFPbzljRTFpNks=').decode('utf-8')
    if len('') > 0:
        766
        _dead_4132 = 859
    total = value + len(text)
    return total

def _ΠВομЛφиИΗΓЪΣДΛ():
    value = 603632
    text = __import__('base64').b64decode('SzFpTl9FOHBvR3lzNmlKdDVSeHA=').decode('utf-8')
    if len('') > 0:
        pass
        526
    total = value + len(text)
    if False and True:
        _dead_4835 = 228
        _dead_6817 = 791
        pass
    return total

def _иЪфγЬλНΒωхΓъβ():
    value = 449116
    text = __import__('base64').b64decode('aFV1WW16bHBpcVdNODlqWDZvUnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ζШΦΑХχчрнπйЪ():
    value = 219432
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQfxfGlt2rgrNget53+CIjB81Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦЛσКΧрβэСЖйпЧ():
    value = 760100
    if False and True:
        _dead_5897 = 822
        _dead_6489 = 488
    text = __import__('base64').b64decode('cFRaNjQzU3pqdkxPbU1LazR6eno=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8469 = 299
        pass
        _dead_6040 = 314
    return total

def _фηИхΘХкЩΑ():
    value = 196441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDrVanYM+p8lKT+G8nSGNi4QyEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝъзШЛΦΤПЮДужαгΧА():
    value = 887178
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzbxNlsOrr8OIjuW0W7HH3YL538='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мЭпзωбμуцПΚдАВΥ():
    if 38 * 89 < 0:
        _dead_7572 = 934
        pass
        _dead_6022 = 132
    value = 699565
    if False and True:
        pass
        _dead_7770 = 949
        898
    text = __import__('base64').b64decode('V2pRNjRadlU1NVdwdWVlTnJ5clY=').decode('utf-8')
    total = value + len(text)
    return total

def _τЗгοιρВχηЖΕΟΙξжε():
    value = 29578
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('RnY1YjdZbEd3N1NkbXdtS2dnWDM=').decode('utf-8')
    total = value + len(text)
    return total

def _χаДлχрηЬΠχπщΤ():
    value = 193829
    if 72 * 58 < 0:
        pass
        _dead_9168 = 440
        pass
    text = __import__('base64').b64decode('d0hWaFFzVlc4YXNpOWRyUHNVS3A=').decode('utf-8')
    total = value + len(text)
    return total

def _рЮдηлΛдрζνЙΕъЙЭδ():
    value = 50204
    if False and True:
        _dead_2169 = 681
        _dead_1494 = 569
    text = __import__('base64').b64decode('ekdzdmI2Z2N0emEySkhISXVIcGk=').decode('utf-8')
    if len('') > 0:
        710
        29
        _dead_2438 = 409
    total = value + len(text)
    if False and True:
        _dead_4462 = 208
        _dead_9260 = 74
    return total

def _пвфΚкΜУиЕιкрφ():
    if 48 * 16 < 0:
        pass
        pass
    value = 221967
    if len('') > 0:
        _dead_9099 = 672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRvLYlcS7bswLQqnwXrDZ3QL5nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УμηБлШЦЕωЗφААЦ():
    value = 669908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjfQeXwyxroqBQCtzgabFTwm5UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮВЯψШυлΡГэ():
    value = 618545
    text = __import__('base64').b64decode('VU9hek1MejF6dTFyM3dHd21Bclo=').decode('utf-8')
    total = value + len(text)
    return total

def _кцХФνоΦМ():
    value = 388066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwHUYkZtyaIZDCiX42nJZR8qvWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εСюАΔσЩςа():
    value = 31912
    text = __import__('base64').b64decode('SGZQaFQ1NEdja092WUVzdFhzbGg=').decode('utf-8')
    total = value + len(text)
    return total

def _мΤΒфΧоβщ():
    value = 302799
    if False and True:
        _dead_9389 = 917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgPRaGJt26IJYgGBkV/FCygn9j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨзЫκъΞЦΜ():
    value = 661340
    text = __import__('base64').b64decode('RnpvX2tMa2ZmQlRRekV2TXE2UGI=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ъХΜудЬΩοΦΜσыЛы():
    value = 95704
    if len('') > 0:
        298
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAG2f1hqz5klKhmU8GCXPS4e9zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8144 = 798
    return total

def _ΙзвюΞΧЖφлИИКФЛ():
    value = 457488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgHxOGgbx5c8PAH6zlCIHhd61FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υχШжρВДο():
    value = 236569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgfQZl8x74IkOTqv0UWDZSJ97XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гУМуΩчгТο():
    value = 381331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXy9YAYM/74lPjy63XGdFyt27l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1311 = 831
    return total

def _тΖКШьΟЩвςТюЬ():
    value = 974283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AArWOHstq5gTAA6FxALEYTQos2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аМУЬиΙррТяЦЯЖΖ():
    if 75 * 5 < 0:
        _dead_5730 = 960
    value = 693218
    if 61 * 32 < 0:
        _dead_8610 = 115
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx3tX0IK+fo7NRqa5XC5JBUk6F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 87 * 86 < 0:
        _dead_8639 = 697
        785
        pass
    return total

def _ΨσρкΟкХърЭЦκРλ():
    if False and True:
        _dead_1280 = 475
        _dead_1071 = 874
    value = 386334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB6wa1o2yYUCYwGc5myTJAE33Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΤнМЗьЯЛЗ():
    value = 645604
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQHwbFsV7r9RNVia6UW2EHEetT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЗΖуΨεΒтΚ():
    value = 116501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRW3f2dq0aQENgWVw26qEDZ26kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΞсЦΔγФрддοΜр():
    value = 959580
    text = __import__('base64').b64decode('REJZb2pCN25tTVg5NHNSVUNvWHU=').decode('utf-8')
    if 99 * 22 < 0:
        19
        _dead_9738 = 719
    total = value + len(text)
    return total

def _νТЕΝκсΝЩЖδιζи():
    value = 101869
    text = __import__('base64').b64decode('c3ZteURwZ00wcF9pZjV4Rkd6N1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЯМшаЦуΣШыБ():
    value = 845014
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn7BOwQ36pgPCSSE3mKpGTB8tWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤωКжУЮξυъοΙщ():
    if len('') > 0:
        pass
        pass
        486
    value = 821832
    if len('') > 0:
        _dead_4266 = 103
        _dead_7693 = 846
        457
    text = __import__('base64').b64decode('QmczN09oTTBVX1dReTBkUTlTams=').decode('utf-8')
    total = value + len(text)
    return total

def _вΣжаЭζЯШτжн():
    if 97 * 51 < 0:
        pass
        335
    value = 405158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bye9ZUA4q4QNPweA6XmiIh0f0WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЩμкΗОпχМшъЭΛщ():
    value = 970623
    if 61 * 80 < 0:
        _dead_3845 = 462
        pass
    text = __import__('base64').b64decode('WWZ1N0ZOa3hMcmJJWTREVzlHNlE=').decode('utf-8')
    if False and True:
        _dead_7387 = 751
        _dead_9129 = 673
        _dead_6312 = 121
    total = value + len(text)
    return total

def _ГлΜнμцЫжΟΕΦтΥ():
    value = 76448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyjTZQYv0vpWND73yneRHCk29Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κμυЖЫХЕяζДμςΔшαЫ():
    value = 331379
    if False and True:
        pass
        680
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Agi8a2Yx7JItNAqcygGlABUm8Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΤлΨΥτЗОеθе():
    value = 276010
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjjKXG46xL1ROTiTmX3BYzEX3Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΟφκуιΔλвΦИэΦζШН():
    value = 367886
    text = __import__('base64').b64decode('cVkzdlZwejUxM1JJZ1VtaUIyQ1Y=').decode('utf-8')
    total = value + len(text)
    if 11 * 71 < 0:
        pass
        pass
    return total

def _жЪΚγφΡКοИзйЧ():
    value = 640624
    text = __import__('base64').b64decode('bW9NdjROcGk5MzV3MHVkRjlRTjU=').decode('utf-8')
    total = value + len(text)
    return total

def _φεьючдΚЭРГ():
    value = 165660
    text = __import__('base64').b64decode('TU1WWTExd2VSZ29KWjkyTXJQdDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘВУДЬтеЩαйк():
    value = 664043
    text = __import__('base64').b64decode('eU5vcTNJaDhXVXBiMER5WXVMWWU=').decode('utf-8')
    total = value + len(text)
    return total

def _шДΝβцνПΣЩф():
    value = 727274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ly21REcL+ZoIbQWO91mVLAN+3EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8228 = 676
    return total

def _νΠХЕЛЕΝмвШγ():
    value = 704331
    text = __import__('base64').b64decode('c09WclQ5bGg3S19LbVdvOWlfeE8=').decode('utf-8')
    total = value + len(text)
    if 1 * 87 < 0:
        236
        _dead_6789 = 743
    return total

def _РΣжΠΔдЪΦйθ():
    value = 554453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3zObQU35Poaaz2q52W+DgEEsEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΚеЕщЮЪвОЗΚΔЭ():
    value = 450124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxfpeWMy8v0zAwKr20K0LnEHzUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 62 < 0:
        _dead_5970 = 554
        267
    total = value + len(text)
    return total

def _МΣΦЫΥσππЛрЪ():
    value = 518476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATfjRloh0643YimgkWaiBR0G3WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        78
        pass
        pass
    total = value + len(text)
    return total

def _ЬСμЛйпХΗЛΖтτξд():
    if False and True:
        _dead_1262 = 746
    value = 482950
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('T0l6UkhjTlZmZmJtUm03UFF4THI=').decode('utf-8')
    if 49 * 24 < 0:
        _dead_2791 = 486
        _dead_4456 = 800
    total = value + len(text)
    return total

def _ПωЙОНЭВυмдτГэ():
    value = 194134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS3CYmUM5KMGbyipmXHEBAAm6kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юЫΩщШвокПπШΡХ():
    value = 790808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHzVbH9s8Y8MIAyl4gG4OggqxlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚЙΩξщΑтαцσФ():
    value = 923523
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhXgXn4V0vtXHxaN4HWBbBE57Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΛΘΓχцΨУмгχΥР():
    if len('') > 0:
        pass
    value = 927688
    text = __import__('base64').b64decode('TTJheWVVOGpOTjhJQkZPdDg2b3k=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        574
    return total

def _ТЪλδЗхΟюкчЙЗΞιЦΖ():
    if False and True:
        pass
        pass
        436
    value = 704229
    text = __import__('base64').b64decode('TVFsTjdBcnNFSXJLZGlHSlE5Mm0=').decode('utf-8')
    total = value + len(text)
    return total

def _λΞнΥΧχΖПΥκзФΜчЕп():
    value = 680688
    if False and True:
        pass
    text = __import__('base64').b64decode('T25EdFZMZ0pIYXhwd1BGY2FpTmU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5908 = 699
    return total

def _σΘπЬΓμСβςшОΚΕнеХ():
    value = 91015
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSTGRVtg/asQMgz2+VSxEhYg/Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЗлНμδιΣюй():
    value = 696330
    text = __import__('base64').b64decode('YjloN3ppbnFGMTA0NEFCT2x1OVY=').decode('utf-8')
    total = value + len(text)
    return total

def _вДЕэМХψт():
    value = 288222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQDzamUsprkHID6l6liKCzcYyzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_8129 = 591
    total = value + len(text)
    return total

def _ΖΜВκуЫμχчμΘ():
    value = 757142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSbxXwEN/ZBbFBjx2H2SZBIJxnQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 96 * 74 < 0:
        _dead_6733 = 904
        716
        pass
    return total

def _ΜьУЛςЪТжВΡрЕΠФΑ():
    if False and True:
        837
    value = 370518
    text = __import__('base64').b64decode('cldWTVRUUFVXclBRVkJPVG5xY3A=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        202
    return total

def _ΑαдοφΦРЕЦс():
    value = 373560
    text = __import__('base64').b64decode('VUtDZGhPZXIzMFF6b2UxbHpQU04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖШетЮχΨλσιεиΞεγ():
    value = 539012
    text = __import__('base64').b64decode('emZKWndJQXpRdXBQYlBOTzgwSXg=').decode('utf-8')
    if 83 * 42 < 0:
        _dead_9431 = 870
    total = value + len(text)
    return total

def _ΣЖЩНИлΓщИКηФЭЩ():
    if False and True:
        pass
    value = 578714
    if 89 * 63 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQPFUX8I0KJXCzuQ+l7HEC563Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 89 * 4 < 0:
        71
        pass
        _dead_1565 = 121
    total = value + len(text)
    return total

def _αΔКщΙиμП():
    if 47 * 50 < 0:
        pass
        709
        _dead_8287 = 297
    value = 229294
    if len('') > 0:
        pass
        _dead_2114 = 686
        628
    text = __import__('base64').b64decode('VnB1WDVUR3VIc0NzcE9sTGRDY0c=').decode('utf-8')
    total = value + len(text)
    return total

def _оΑчμзΔΦΗЧσИец():
    value = 283661
    text = __import__('base64').b64decode('RTJXNGdTb1ozbUtLRlduOUhMX0U=').decode('utf-8')
    total = value + len(text)
    return total

def _эХЦШйхλΓΞшмπлρΚТ():
    value = 122871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kj7GYG4h8L0IDiON52eWEicd63c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σЭΧгΡΡгЬΣρΞжиВС():
    if False and True:
        _dead_5886 = 128
        775
    value = 649132
    text = __import__('base64').b64decode('UG9pQkVqM3VxYUFRXzhZRVlXblc=').decode('utf-8')
    if 23 * 61 < 0:
        886
    total = value + len(text)
    return total

def _жςГηФβЖψнδςΝД():
    value = 62944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQK2RGE37P0UOw3zw1jDGT8u8Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗФΤиИгГОеВД():
    value = 831730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzjbN3ca7/86DieyngeAEho3ykQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НвτбаΡгχеΑ():
    value = 820557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB3PbF03q4AFYjzw/3e4Fg55w14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κχЙдΓКЛюΙΧЧ():
    if len('') > 0:
        pass
        pass
        773
    value = 414745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjnNWgE9/ZkXDD+16kfHLTw69Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δЖΟзОφΙσсющшРйс():
    if len('') > 0:
        318
        pass
    value = 753483
    text = __import__('base64').b64decode('RkcyS0loZHNzN2lZM0l6Z2lZSTI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        567
    return total

def _ЯκТЯгςяοи():
    value = 256463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3ezYQQsqbsJIzr10lfCAnMZ1EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κεФдτΕЕΙуμν():
    if len('') > 0:
        _dead_2473 = 874
        pass
        350
    value = 807665
    text = __import__('base64').b64decode('YllueVRLZjN2c0piUjJXT3c0VUc=').decode('utf-8')
    if len('') > 0:
        pass
        729
    total = value + len(text)
    return total

def _оеωρзνΓЩсφ():
    value = 379444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABCxbWY+wbsVGCmE3k+bDSMBtWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        765
    total = value + len(text)
    return total

def _цйΞДмσгДβмБ():
    value = 644742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDW0ZXYXy/8pC12tnHSaGDE21mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒККΣлОΦΗζΡЬω():
    value = 713206
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAD9eXxopqAgaTWu2Hu/FSM8ykY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        167
        pass
        pass
    total = value + len(text)
    return total

def _хΣзхбгΗЯЬΟςЕΤΓд():
    value = 58846
    text = __import__('base64').b64decode('bVB2WkZqVXNRbTBSV3hFNE5SV04=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        526
    return total

def _ТЩΓФаωΟΕ():
    if 25 * 57 < 0:
        632
    value = 464839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBnyWFIfp5AbPxaJ91qzM3Eh7lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 1 * 10 < 0:
        pass
        745
    return total

def _εжпПюсρь():
    value = 261592
    if False and True:
        pass
        _dead_3451 = 299
    text = __import__('base64').b64decode('Z1pBUXFkSHJUaDVWODh5UWdkRkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _дΩμψЧσΦСвмлτЯ():
    value = 186860
    text = __import__('base64').b64decode('cDN2TnVQeUhIZ3RWN050UkVhNTY=').decode('utf-8')
    total = value + len(text)
    return total

def _шΧцλИйаащρΤΠтР():
    if 32 * 15 < 0:
        pass
        807
    value = 263816
    text = __import__('base64').b64decode('YnRTRnBnd2xveVg5VnlEMEpfSlE=').decode('utf-8')
    total = value + len(text)
    return total

def _мωвТΘьНΚи():
    value = 778451
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQvmPwkqyr0UHBirwlWyPBd4zWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔАцЖχлЦт():
    if False and True:
        pass
    value = 232923
    text = __import__('base64').b64decode('enV5WEFDY3lsWEY2SFpIaUQ3em0=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΙΔфΒχэГПЫтΣΘΦξг():
    value = 853895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB7RY3I+9pgpOwGRy26yYQZ26jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φвφьЧдΜяΩУГщΙπ():
    value = 189166
    if False and True:
        _dead_5082 = 140
        pass
        pass
    text = __import__('base64').b64decode('Wl84c3dISmRtdWg5dXdMcVhmX04=').decode('utf-8')
    total = value + len(text)
    return total

def _ОχЛβτюйε():
    value = 351660
    text = __import__('base64').b64decode('RmZleHJ3VnBJbjloNzZ2R0hYZGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛкωаЗогвцβу():
    value = 655135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiDjQ2gtqfA7bxuV+1WGEism0GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шХτрΣχδδγφ():
    if len('') > 0:
        714
    value = 126102
    if False and True:
        _dead_6044 = 540
        647
        pass
    text = __import__('base64').b64decode('UWh1Q252N19BR0hBQUNDamMwYUo=').decode('utf-8')
    if len('') > 0:
        _dead_6560 = 873
    total = value + len(text)
    if 7 * 76 < 0:
        pass
    return total

def _лΟКэУτΙδΖΣэгпφφμ():
    value = 633304
    text = __import__('base64').b64decode('WDZGZVluWHFadUloM1BUdW1nWTA=').decode('utf-8')
    total = value + len(text)
    return total

def _РЭПМгπλΧΞΔсΨφыа():
    value = 75230
    if 12 * 31 < 0:
        pass
        _dead_4560 = 501
        _dead_4290 = 478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyX+PWJs0p8zNAuT23SYYgF2y0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭσΑеλΙρΜУ():
    value = 808271
    text = __import__('base64').b64decode('blpseFdTbkZGbkRoajBDRFc5X2w=').decode('utf-8')
    total = value + len(text)
    return total

def _чΣΟКТΔвэεЯγОЛэМ():
    value = 227160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JivpW0Jh85kgAgyvyQeUHC4J1Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΑФгΗΤГФΓшηО():
    value = 664724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwPKTHk79r4tNxWk3l+IJSN8smo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()