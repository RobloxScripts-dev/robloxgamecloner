#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _РдэГпэΟЗйαЫΒн():
    if False and True:
        pass
        89
    value = 562883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQXXXkEI2f8tMxb7/0+qZTUr7VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7790 = 294
        _dead_2267 = 963
    return total

def _ТэЩыеΓιςвЛэъ():
    if len('') > 0:
        pass
        pass
    value = 531781
    text = __import__('base64').b64decode('RjNKZVpocU9DcUx6SmE4NVNVYXg=').decode('utf-8')
    total = value + len(text)
    return total

def _НΧеТΚθаΚМгσ():
    value = 66011
    text = __import__('base64').b64decode('UXVHZGhTMVR1OXlVNURvRWR4ejI=').decode('utf-8')
    if 81 * 5 < 0:
        pass
        763
        _dead_3134 = 817
    total = value + len(text)
    if False and True:
        _dead_2550 = 961
    return total

def _ЛДΤιфаГэЮНЙ():
    if len('') > 0:
        pass
    value = 598209
    text = __import__('base64').b64decode('S3h4cDNValFMaUZNM1JuOHRhMFM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1454 = 377
        _dead_9925 = 810
        195
    return total

def _ΗяτзШЪОΔиЗΓыдοр():
    if False and True:
        235
        _dead_7109 = 780
    value = 169045
    if False and True:
        284
    text = __import__('base64').b64decode('Y1pUWFdrd0xUT3dVMWhEM0JuWE4=').decode('utf-8')
    total = value + len(text)
    if 87 * 80 < 0:
        916
        _dead_1243 = 442
        pass
    return total

def _эτЪЛЗйβΕфФЖ():
    value = 915256
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ln/KQlRrpo4KH1ePzWSXYwwN6EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЮжφκНюΕРбУ():
    value = 309913
    text = __import__('base64').b64decode('TUtZMktNb0F2TGdEY2J1ampYMDg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3612 = 875
    return total

def _ΜКΡΤофνβεςδψ():
    if False and True:
        pass
        _dead_8347 = 792
    value = 350652
    text = __import__('base64').b64decode('WEM4Y2VoRnBrWFlQbEwzSFFBQzY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        33
        pass
        _dead_9410 = 705
    return total

def _ΛЩςΙхвйпеωДарσ():
    value = 600819
    if len('') > 0:
        504
        _dead_5272 = 401
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCjeOVg7p44tMhmlnUCdZjM5s0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΔлшκΨПυ():
    value = 975694
    if 77 * 63 < 0:
        _dead_5183 = 129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ci6yQQkc7plVaxui/E+DN3cr8mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _σРБωΡΣχδБАРоΨН():
    value = 48826
    text = __import__('base64').b64decode('bkJhQXAwZW5SOGZlQTZ3RnNrUXY=').decode('utf-8')
    total = value + len(text)
    return total

def _йнВςАхзЦδФИξжΓ():
    value = 441073
    text = __import__('base64').b64decode('S3dBV1JOaXhKeGM2bVdJVF85NE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪδзБГлпΦκφЕξ():
    value = 318487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQflN183/4EFEziT5G6aJzV/zl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЖтаΓрΤΔΧλв():
    if False and True:
        pass
    value = 42372
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ij7HQkQg/LAIMhWq0m+dLhY88UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗГНюЫнЗруΘъ():
    value = 430760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRbjQlUGyK8WPCa65lyFY3Y57jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        530
    return total

def _ТэМТφСχσχмΡΥχθ():
    value = 542438
    if 72 * 80 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnvDXnoUq5JXA1+N6nK+IxoGy3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        158
        pass
        602
    total = value + len(text)
    if 32 * 84 < 0:
        pass
        _dead_4266 = 386
        _dead_7638 = 808
    return total

def _ЯφοмΤажпυψ():
    value = 567892
    text = __import__('base64').b64decode('UkRDeDA1OHZPdzRfYTZkeVp0VXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖДΚиГШЖΒздνП():
    value = 871495
    text = __import__('base64').b64decode('aXp3REwyd1h5OU55N0UzZENVa0U=').decode('utf-8')
    total = value + len(text)
    return total

def _кБΓЗоΘЭψηΕрЭпЬθ():
    value = 525804
    text = __import__('base64').b64decode('QmxfSjI1T290R1J2TkRRdHRiVHE=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 12 * 71 < 0:
        147
        _dead_5953 = 281
        166
    return total

def _ЕΗАхЗρАξψВΞогΥΞ():
    value = 513743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBrSN0ES3JcJHRymyVfBIR8d/Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εδБыνΗцбмΚρ():
    value = 741718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3jJTVs2yqQnNCSx3GCVAXcY3UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯθпθЮнχΑ():
    if len('') > 0:
        pass
        pass
        518
    value = 29872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz7lbXMg6YMrHyyZkFeKIwgMvTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠкχнчьОе():
    value = 201579
    text = __import__('base64').b64decode('Z1dtTFhMTllyUzY1Zmdnc0k0Wlk=').decode('utf-8')
    total = value + len(text)
    return total

def _τхβВυэεν():
    value = 627852
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT33f1Qjr45UOCu7wWm5BSoO70o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яжЧΚШоρыЖЫпмКΥа():
    value = 945630
    text = __import__('base64').b64decode('b3FnRkZGdnB2VnJFcWRkbEo1RE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΦВΥЬяοζЩМв():
    value = 252806
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bj21NwkRzpJWLguswFm/JxJ8zzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КМΜКДЖЭюοПЪЙΟζ():
    value = 322838
    if 18 * 60 < 0:
        24
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex3nYkgJ0oUzDxjw4F2xACkk5kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣΛГкШйРиιηωЭΗ():
    value = 550249
    text = __import__('base64').b64decode('UF9xN3M2N3pqclBWbUVxVVhYZGc=').decode('utf-8')
    total = value + len(text)
    return total

def _λφЖФйсΠЭфаΠГщэЙυ():
    value = 263300
    if len('') > 0:
        pass
        _dead_8246 = 803
        302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyXySgVu1LsRD1+m4261IBoN8V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 78 * 79 < 0:
        488
        _dead_5951 = 799
        _dead_5064 = 953
    return total

def _НεЧΧеπζκык():
    value = 250780
    text = __import__('base64').b64decode('cG9Vd2hadFlPVl9pcVoxVFl1eUs=').decode('utf-8')
    total = value + len(text)
    return total

def _СπбХЪрοΠΑю():
    if len('') > 0:
        _dead_9412 = 382
    value = 373261
    if 7 * 81 < 0:
        pass
        689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH7oV2gP14FRAjCbxkCALDMX6EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υвΚΛэεΝυНюЮИιЙвЫ():
    value = 302308
    text = __import__('base64').b64decode('RDNOVXFuaEpuQXpQbEdJM21qS04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧνМйоΥΝъψнπ():
    value = 678225
    if 48 * 89 < 0:
        218
        517
        pass
    text = __import__('base64').b64decode('aFVpTDVuZEM5ZjBqMXlrUXBrdmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫчΒЯкΓννЖσωН():
    if False and True:
        558
        562
    value = 382034
    text = __import__('base64').b64decode('VGpJUFVMRnNKNmVoV2xtSlhGYW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΗσΓКеЪΒи():
    value = 583312
    if 62 * 62 < 0:
        269
        pass
        _dead_4797 = 878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH7DdGsD1bJQD1uWzVynbAIuwTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪψвЮΨυюкμЧтМ():
    value = 955327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxntWnBpqK0JFFaszAO5AAB7tlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΡΠγχуфЛΚыщαЖю():
    value = 68956
    text = __import__('base64').b64decode('cWY2ZHBqOG9Ba1hiNF83eWpZTGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _βФΖЦλаъιыγψ():
    value = 186694
    text = __import__('base64').b64decode('WHFtSWxRZXhkVGI5dkdfb0p1UnA=').decode('utf-8')
    total = value + len(text)
    return total

def _пκχзΟЖПΓЛ():
    value = 375102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRfBbF090b0lDh2smwXFGxA85kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МьэσΑжХюγХρеюεσ():
    value = 325572
    text = __import__('base64').b64decode('UkdBMF82dGE2VWJ2RElrS3BGTWk=').decode('utf-8')
    total = value + len(text)
    return total

def _МШвΛфАςΙ():
    if len('') > 0:
        _dead_4061 = 804
        501
    value = 484471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwLMW30o64ZTMDWN0GKqAi4W6lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 36 < 0:
        578
        _dead_1537 = 750
        pass
    total = value + len(text)
    return total

def _СВьδΡОςозоΖНЫ():
    value = 60255
    text = __import__('base64').b64decode('Q3c0eVVTRVBCcGtMYjE4aW9RaXI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        572
    return total

def _лτΞΘαΓςфЕθΛβч():
    if len('') > 0:
        pass
    value = 499418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiiyaQELyKoMIwq70WCDMBEN22U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨεСыММΚηСрΞθΟ():
    if 41 * 90 < 0:
        _dead_3874 = 556
        _dead_8915 = 727
        953
    value = 800682
    text = __import__('base64').b64decode('TW1RUzRFS01NYTh2aGpUSEViVjA=').decode('utf-8')
    total = value + len(text)
    if 85 * 83 < 0:
        _dead_3884 = 972
        _dead_6554 = 997
        15
    return total

def _ζθКπРГЯмυΑЛυСР():
    value = 576975
    if False and True:
        _dead_4018 = 442
    text = __import__('base64').b64decode('bXhLWkg1cVpfMkN4VGh6SGVFRXQ=').decode('utf-8')
    if 30 * 80 < 0:
        581
        381
    total = value + len(text)
    return total

def _оπςЦуыТТ():
    if len('') > 0:
        _dead_7290 = 730
        pass
    value = 775573
    text = __import__('base64').b64decode('cmpiWFZTaF83Vmg5SUthRGxBdHo=').decode('utf-8')
    if len('') > 0:
        468
    total = value + len(text)
    if 73 * 45 < 0:
        _dead_7769 = 437
    return total

def _θΕмйжтНΜрфЬуэИΜЦ():
    if False and True:
        pass
        _dead_4063 = 42
        pass
    value = 692831
    text = __import__('base64').b64decode('dmlHUWJIRWxfVlNLbm5RbXdLMG8=').decode('utf-8')
    total = value + len(text)
    return total

def _уКЭшЦΞΜβ():
    value = 844413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iivdf0ks9YU2MDaEmFi4GQQA4mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8178 = 32
        _dead_2074 = 869
        _dead_2066 = 218
    return total

def _ΞΣЦΙШРюЭГσΧзНζм():
    value = 531636
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cnn3a0tt1YtUI125/gajBgAG7FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΝГуБСΔχд():
    if len('') > 0:
        pass
        _dead_5264 = 32
    value = 134050
    text = __import__('base64').b64decode('UE9kZnVuWTJvNEpCOE9DY0VRSEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭηςыЖмсκЙ():
    value = 477054
    text = __import__('base64').b64decode('YXdBcVVOZmZwbFl5ZjZZMHJRUzI=').decode('utf-8')
    total = value + len(text)
    return total

def _тμξУΘаффМλΓΟы():
    value = 238985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgTGfnMxx6wWLyKs8FGGIjA6wFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эρлπыνыψΦβФΦ():
    value = 153988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQLOQHYJrbEWLRqI41+qGBEB4H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 41 * 96 < 0:
        pass
        _dead_5355 = 188
    total = value + len(text)
    return total

def _щзβИжюОχм():
    value = 42455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBfHbAYv355TCwH04Q+CYgwn4H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        569
        _dead_1197 = 586
    return total

def _ЭτлφБΚΘεΦпΞΧ():
    value = 33549
    text = __import__('base64').b64decode('QnNfOXk3NWplTmVnSVJmQXM2dVQ=').decode('utf-8')
    total = value + len(text)
    if 69 * 87 < 0:
        _dead_9543 = 470
    return total

def _фαВъΤщΞдрλΤ():
    value = 692924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxDGX0hv5645ERWI7lmdIh0f8kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1458 = 100
    total = value + len(text)
    return total

def _ΝΖМΖбΤΕтРбΗθФюχп():
    value = 350371
    text = __import__('base64').b64decode('SExCN0pVSkgwOUpjZ0FENF9DV0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΝщΦΩЭΞΥиαπ():
    if 12 * 27 < 0:
        pass
        29
        _dead_6033 = 775
    value = 566424
    text = __import__('base64').b64decode('Vmp4bHh4YnZVUmhkSVYwT2Fta0M=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        363
    return total

def _ФСКμЯρθфгηφΚθхΘΡ():
    value = 884986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXj1Rkce+YpSPC2q/luREw8MzGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚιНГОλвМκдззξα():
    value = 292498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTfqP0MIq7ogCBb25U/HFxcqzWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ююεБπΒχлβΡΔΡΞуы():
    value = 356525
    text = __import__('base64').b64decode('WUYyNHk3U08wc3R6YmRYN0doUkc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        540
    return total

def _БΙСоψчЯΝЛοяΡψωЦЫ():
    value = 518141
    if 92 * 61 < 0:
        46
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3zHSnMp+5EMPgGPm3qEAic64WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6254 = 904
    total = value + len(text)
    return total

def _ςθЪвΘнΨγЦξΑ():
    value = 837274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgnPYGIQ/4cpGD6CwH/BBRcXtVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПДГθеιΜез():
    if 28 * 94 < 0:
        _dead_7578 = 821
        303
    value = 468981
    if 10 * 85 < 0:
        _dead_1683 = 873
        _dead_4451 = 964
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhXeXlkDzI8yEAitxQLBJw0fs2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤεωΝΙкαЛРτИβуС():
    if len('') > 0:
        _dead_6887 = 159
    value = 96703
    text = __import__('base64').b64decode('eUt6dnpUdlA0ZnlndHlTMlNndHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _фΑЮгРΕМθθψьσш():
    value = 947532
    text = __import__('base64').b64decode('a2J0YWZ5NUNrOVdJS29tNzZ1WXI=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _аΜОХКΛΑοΗМ():
    value = 704348
    text = __import__('base64').b64decode('Rm8ydFNlTEtkdHV0bm81NzlMQk8=').decode('utf-8')
    total = value + len(text)
    return total

def _υьдДςиУП():
    value = 264205
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj/wQW4Mq683Lw7w7nyBZh8CxXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЫзпΘтΥъР():
    value = 168522
    if len('') > 0:
        _dead_3461 = 77
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDmwaloGrqEHLwT14A7DBCE1zWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3959 = 106
    total = value + len(text)
    if 76 * 42 < 0:
        _dead_8539 = 203
    return total

def _мфΘйуХΙωςХЕΔвΟИЧ():
    value = 278179
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhq2Zks/rIEnLF6zmGGXEHYuzns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЫαψαΚеΥоюбΙΓ():
    value = 221518
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX70NgEo25xSFQak0VPJEx13/WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4285 = 831
        pass
        188
    return total

def _ГΞвЫзΖπчΒ():
    value = 560511
    text = __import__('base64').b64decode('Tnl3bDFjdlZwYjFUVGhPZ3Z3bVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ομΞЭШΩΒЭлмщгуδΤ():
    if len('') > 0:
        _dead_4413 = 916
    value = 456613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBDHf2kYz6kzMVrz3kaiC3w5vUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λМкυυοФΖэΡΕΑвοΣъ():
    value = 114787
    if False and True:
        933
        885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRrvZnsQ7ZxaKT/z+wfFMiJ3ymY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХкнщμъьЭцΥ():
    value = 895698
    text = __import__('base64').b64decode('b2VmUlZhMDJSRVFnR1BhVzJRMUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ζМφЕΤСΨыКΛзΣ():
    value = 528589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX/wOVpu1KAJGVuixACEFQ8k9GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        204
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _χТхюьчЕКЬΧΡνΒΥ():
    value = 323713
    text = __import__('base64').b64decode('Q2QzdE1mSTlSSU5QcWd3OTN2U3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦκЯоαδпЬ():
    value = 321092
    text = __import__('base64').b64decode('Ymlpek51SEtjeWJPZ0VnU1pvcko=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠθΨЛψΩοСтЩя():
    if 31 * 52 < 0:
        986
    value = 804209
    if len('') > 0:
        874
        _dead_7974 = 355
    text = __import__('base64').b64decode('REtYRHdhQjBXZ054UThjclpzYTY=').decode('utf-8')
    if False and True:
        _dead_2550 = 31
    total = value + len(text)
    return total

def _ОАΣΣΔφфЙυЩя():
    value = 920374
    text = __import__('base64').b64decode('WjU1aWZ3WmlTd21MSndYb0ZQcWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦЧбΥРζъгοэΗКф():
    if False and True:
        _dead_9163 = 756
    value = 249896
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyTqYF4yx7smGz+q5g/FIA0C4Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΥΦцаЬзЭΣγφ():
    value = 746485
    if len('') > 0:
        _dead_7766 = 509
        pass
        755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH+zd1Ij75IPLxuI4wa7JiJ6sH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 37 < 0:
        _dead_9936 = 178
        707
        801
    total = value + len(text)
    if False and True:
        372
        pass
    return total

def _бεАхηУЦΖУ():
    if 25 * 94 < 0:
        744
    value = 367027
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxuxdnQN6qc1aDq5xWOvODIKz0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 53 * 27 < 0:
        766
        425
        _dead_6015 = 471
    return total

def _ΤтлωΧьГΨτΩщзНт():
    value = 278630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyPeQH8t6PwSbgycmQWSCwYCwWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _суΣΠЗьак():
    if 29 * 51 < 0:
        pass
    value = 367042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByfIdn8o2PEXAgSx2V6kNjYW51g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИЖцэΙзΘΝиΤцΘ():
    if 47 * 98 < 0:
        _dead_4086 = 72
    value = 945973
    text = __import__('base64').b64decode('dEhpNzRvcWRsM282TVN3X1VxTkI=').decode('utf-8')
    total = value + len(text)
    return total

def _счыΖλЫизчΠ():
    value = 480135
    text = __import__('base64').b64decode('bVUwN3JWT1ZMSG5KUFlJblNpbkc=').decode('utf-8')
    total = value + len(text)
    return total

def _СрΨлγЯВСρЮ():
    if 37 * 10 < 0:
        pass
    value = 389279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQXmNmcp+I8RC1ix2XuCODMnsUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 53 < 0:
        pass
        _dead_3985 = 333
        25
    total = value + len(text)
    return total

def _ηщЯЖяΑΤсρΒ():
    if False and True:
        296
        532
    value = 936223
    text = __import__('base64').b64decode('UnpjYTFKTGpDOVdNRkwzRWNfQWw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7620 = 136
    return total

def _πΝЛτΥςΖμιΨЧГй():
    value = 638307
    text = __import__('base64').b64decode('ZnRKTXJ1YTNma0JWNVpSajNmSHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _шцЦИΞЩκчςЬв():
    value = 907530
    text = __import__('base64').b64decode('WTNPSktpdHl5OHdSQlh0Tk9xVlE=').decode('utf-8')
    if False and True:
        _dead_7516 = 744
        pass
    total = value + len(text)
    return total

def _φАЫшΔΝжΜхΔЫМзπ():
    value = 327027
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('VFI3bDVHZWprNDJNR0dWcU83a1M=').decode('utf-8')
    total = value + len(text)
    return total

def _φРПΤЯζΣΚ():
    if False and True:
        pass
        pass
    value = 60061
    text = __import__('base64').b64decode('eUFlcU1xOWY0bVpyQ0NwVkxyb24=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝГШεФτУμеЕΟρхφяй():
    value = 483913
    text = __import__('base64').b64decode('WHhsaGZBanA3YWJEenFMOEFpNVo=').decode('utf-8')
    total = value + len(text)
    return total

def _βКЯσεюдΧзΖ():
    value = 954105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRDzRVNh+v4JGDy773HAbDMO9HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 42 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΒθеъНчЕнζкψД():
    value = 474146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An3RQ2Jp1aMxagmO4GSlOyQB3lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        945
        pass
    return total

def _νАΗμαИЛшΗъп():
    value = 486768
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D33mSV5t2KYJKy6U8kWSAB0+3Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 63 < 0:
        pass
    total = value + len(text)
    return total

def _λΖЮЛаιΕΓψрОпы():
    value = 30164
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgrVdH4h340iDw33/lGEGSgf7Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩЙехρΕэх():
    value = 525342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCezb14u+5oiHgWu2Ga8YB0q7jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓωлЖИΠΦйф():
    value = 879708
    text = __import__('base64').b64decode('SFNXb2tlSEFUdThPdXA4ZlFOcG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖЕжψЭλСΕЦаЗ():
    value = 546683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTjXQVwJy7IUDzCv7wa9FwImtWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΒфФτРΝΧБμΠТΔ():
    value = 193310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgLea3Uq1plWDTWtxH+HZAd35Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΧБТωшΣΘ():
    value = 656377
    if 21 * 65 < 0:
        414
        _dead_5430 = 878
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjzTOV8hzZ8rbhiX5mSoEz8Q114='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        588
        860
    return total

def _РνТκТИοЪфи():
    value = 734295
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En/BaAIo2qJVDRiP3gW9AwAG7ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 90 < 0:
        831
        _dead_2684 = 57
        pass
    total = value + len(text)
    return total

def _уΩκΜΟИνΘ():
    value = 373698
    text = __import__('base64').b64decode('ek9iMVdocVU3Tk5VNmVaUHd6eVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖфВЙЪκаЬрХЦг():
    if 56 * 26 < 0:
        pass
        321
    value = 200695
    text = __import__('base64').b64decode('VG1naUZjOEhUVDVJajltVDJTaWg=').decode('utf-8')
    total = value + len(text)
    if 62 * 74 < 0:
        pass
        _dead_2178 = 468
        pass
    return total

def _тбТΒщΦυΕиυКгиВБΠ():
    if 55 * 10 < 0:
        pass
        447
    value = 105189
    if 20 * 53 < 0:
        _dead_7909 = 568
    text = __import__('base64').b64decode('aFBBVUJNWDFXVHFHSGNvbXczTUc=').decode('utf-8')
    total = value + len(text)
    return total

def _еΗяхзбфД():
    value = 225169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyXCTAkN5pIULx2zm26GBjx7zEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υλУсΔГЕЕ():
    value = 563314
    text = __import__('base64').b64decode('RVNCcVFHUVdHeGdCYjN0VHI2VUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟРТχςОЪЦψεОΩ():
    value = 723222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSa3QXIv+/FWaiut/XeGLDw40js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦхнРηΔЗЛ():
    value = 402734
    text = __import__('base64').b64decode('UVdpbEJZM3p0UWlmNHg3U1N4OWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ζхИΔАСχΖоΚγΨИгЛ():
    value = 45284
    text = __import__('base64').b64decode('SHBod0Uzd1c0cVVRNWJPSXllSmY=').decode('utf-8')
    total = value + len(text)
    return total

def _шΟχъцчΡЕ():
    if 25 * 28 < 0:
        pass
        667
        pass
    value = 927523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRr3S0EX+KssaVz2kV2KFyYaykw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 93 * 66 < 0:
        _dead_3806 = 150
        _dead_2298 = 646
    total = value + len(text)
    return total

def _ςвΝκΖΦμΦЫСЛ():
    value = 523698
    if len('') > 0:
        282
        pass
        823
    text = __import__('base64').b64decode('bDJZdWtnMWtqNlZrUkxVMER2WnI=').decode('utf-8')
    if False and True:
        pass
        _dead_9747 = 309
    total = value + len(text)
    return total

def _ΥγηΦцζаЧХΗбΙЙиπΚ():
    value = 653276
    text = __import__('base64').b64decode('dDZyMldNeUw3WURVVmQwblBNcmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭуСΜяЗεΛπζΣМανΖ():
    if 47 * 61 < 0:
        534
        _dead_4199 = 841
        _dead_5831 = 343
    value = 244988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxjVenY/+Po1GD2TygGXLisD4HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 66 * 45 < 0:
        _dead_1811 = 522
        pass
        pass
    return total

def _юЛуЬукΥхюЭ():
    value = 342545
    text = __import__('base64').b64decode('Tmw1SjVid2FCWjFzZnhGblMwb00=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΤаАЯχΒωΠ():
    value = 654448
    text = __import__('base64').b64decode('aFJVMDhsTXZBakZNdTlpVzlET1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΥЩτЮЩτъΦροΓЕА():
    value = 549924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjjpVHtr/P0kOCeR0Q+HGj8H6n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 53 * 86 < 0:
        pass
    total = value + len(text)
    return total

def _ΦπΤКвщΕеυ():
    value = 599300
    if False and True:
        _dead_5655 = 14
        _dead_3558 = 105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRz3VHMo+f8oAAzx20KAZA0l51Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        77
    total = value + len(text)
    return total

def _рЫожχЫЪнЮСЩщвмч():
    value = 491173
    if 64 * 15 < 0:
        _dead_9883 = 191
        _dead_7118 = 985
        126
    text = __import__('base64').b64decode('ZFZVNDlFcklDRkJtN19nazlPWVQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        74
        988
    return total

def _ΙЖЬвΠΩΒСΘЕΖσ():
    value = 450602
    if 48 * 87 < 0:
        _dead_9992 = 367
    text = __import__('base64').b64decode('anQzMEpLWk9TdWt0alM0RDV3STI=').decode('utf-8')
    total = value + len(text)
    return total

def _гυΨΖψпЭуχшμлцΡвΑ():
    if 48 * 80 < 0:
        pass
        727
        pass
    value = 425777
    if 5 * 35 < 0:
        pass
        _dead_1538 = 91
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDb8b38z5P9QPxag+X6EAAN9y2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΡзλδΟЩΝγЖΓЧσЖχс():
    if len('') > 0:
        _dead_2522 = 280
    value = 108745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQrIPmku6L0OMSqpww7AFScDzl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔβΡрщиδв():
    value = 879373
    if False and True:
        pass
        61
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwTPSAUV8ZgLFQWm3WyFZwcMwk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζОоΘФδЬОЕμуЧθψΞ():
    value = 248024
    text = __import__('base64').b64decode('Wlh4alJfY2RkTVpYdTNkTmdEWWE=').decode('utf-8')
    total = value + len(text)
    return total

def _πЩЮЦУтζЪρ():
    value = 868680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwqxRFgb774TLDmUmGnFIQEdtmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗМαыМБαХ():
    value = 437641
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDrQSQko6/gFFDf2n36eMSo2wWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВχйяЮьжΤЯеτοаΞ():
    if False and True:
        536
        175
    value = 932163
    text = __import__('base64').b64decode('UWRVOFhycncyN2VqQUNxV3ZZelg=').decode('utf-8')
    total = value + len(text)
    return total

def _кЪιψэλЧпБнЬλΙ():
    value = 965043
    if 86 * 63 < 0:
        _dead_8281 = 654
        _dead_7235 = 62
    text = __import__('base64').b64decode('aXphZTdncmMxNTU5ZlBwS0hxdTA=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_2214 = 826
    total = value + len(text)
    return total

def _ΧΘςγРйвФЙЯοδщэсΜ():
    value = 187738
    text = __import__('base64').b64decode('a1U0TkVjTFl6NDhlV05aam03NTg=').decode('utf-8')
    total = value + len(text)
    return total

def _εйрФеεыЬΣЯЦвюЛΡ():
    value = 400050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT3ca1At17E8CVyHyUSaNQIcvDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уΡавωНΒУдΟьΚΤПУ():
    value = 714856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Myb8dEUd2fFQNj6N5H+SNwx5vUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8913 = 564
        _dead_8872 = 754
    return total

def _δΘδпВτΗьЯφФν():
    value = 740998
    if False and True:
        pass
        _dead_4752 = 726
        pass
    text = __import__('base64').b64decode('QzdJbWw0elppNVlGM2JKMkQwbl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜМΒЗдЫαιЪΜμчΘ():
    value = 374270
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyXtT0UR16YBN1mO5V/GJDUsyD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЛзΔыΔμΚДРρΘЗюΑΩ():
    if 58 * 63 < 0:
        _dead_5857 = 792
        _dead_6432 = 477
        810
    value = 168189
    text = __import__('base64').b64decode('RXh0M1A4VE1xT0JickdYU0hfVE8=').decode('utf-8')
    total = value + len(text)
    if 92 * 98 < 0:
        _dead_2835 = 659
        83
    return total

def _χБуΞАЖυвΘ():
    value = 82745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgXvSVgcz4Y0bSWt3mO5Zysr9U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 90 * 49 < 0:
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЪГсοΛФΙЧΜщаΗΜ():
    value = 428013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXrOZEs3+r4pIiuP5FqTbQA89Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        194
        115
    return total

def _ΔГьцпЕΨуЗΚπ():
    if len('') > 0:
        pass
        _dead_8936 = 136
    value = 850760
    if len('') > 0:
        _dead_7770 = 928
        66
    text = __import__('base64').b64decode('emdJU3dndFR2VEM2eGhaUVVXbzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗπЛЕΩΕыЗюκ():
    value = 737600
    if 87 * 85 < 0:
        pass
        _dead_7891 = 158
    text = __import__('base64').b64decode('d215N1JsQVphcl90bGh2Nkp4SEM=').decode('utf-8')
    if len('') > 0:
        pass
        326
    total = value + len(text)
    return total

def _ОΑЙωШΟχΖЙТ():
    value = 381187
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCrcRAYs5vtbADn04A++HQ55w08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠζотгюЮоЦΨ():
    value = 161347
    if False and True:
        834
    text = __import__('base64').b64decode('bURCcUl3eHBCMXlKR3lhNDZWMXU=').decode('utf-8')
    total = value + len(text)
    if 26 * 84 < 0:
        _dead_4467 = 899
        pass
    return total

def _ТИΔΒνБМΚщЩωф():
    value = 518846
    text = __import__('base64').b64decode('eDNmX0ZKZUNxeFpKcWdzVVZfMjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЧДйоЭЬюаνξаПθмо():
    value = 727103
    text = __import__('base64').b64decode('dmRyYlk4SEtzQXViNmYySGpva3I=').decode('utf-8')
    total = value + len(text)
    if False and True:
        469
    return total

def _τВψικζΝЮЭЮ():
    value = 955858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT62SHwG0qkXaCG77UG6FRN+4jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОяРЛΩШбЩψΔтΜМΦД():
    value = 624117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P37MeFYpyIIQKD6p5XCSEQ8ssWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АчЫΜцФΤΦφыгЙдΚθΣ():
    value = 240770
    if len('') > 0:
        _dead_6271 = 102
        899
        _dead_1017 = 872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSzQWFQTqrEiOVmN+XWvJAh+7mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒσβУЦΤвκЮЧξыУюуΝ():
    if len('') > 0:
        334
    value = 417934
    if False and True:
        _dead_2983 = 641
        107
    text = __import__('base64').b64decode('bTl1SF9hbG1LelVJcDlFNGxRMVk=').decode('utf-8')
    total = value + len(text)
    return total

def _йОКНЫΥЦщνРκъχщψ():
    value = 628917
    if len('') > 0:
        _dead_9316 = 646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg32bF4X+rEkNgKG0XqbADEk8Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1873 = 377
    return total

def _αщΝΧззυми():
    value = 728256
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3zqV2cq6/gMMQS5mGe5DgR63EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яτЭЭщьθШΟδωΕШβφ():
    value = 252776
    text = __import__('base64').b64decode('Y1dDZzA0Njl4SDEwb1pONkJkdmI=').decode('utf-8')
    if 87 * 85 < 0:
        pass
    total = value + len(text)
    return total

def _ЛΝМΘЧВиνΠΙА():
    value = 539491
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXzsamUPxIopYxqx6VCHIjY64Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХειябХЗρсΝЕСЙΒ():
    value = 991297
    text = __import__('base64').b64decode('Smh0X2VQTGFRV3pBZHVpRHVHVHI=').decode('utf-8')
    total = value + len(text)
    return total

def _эЯΙСнПЙζИМрα():
    value = 113825
    if 56 * 39 < 0:
        565
        _dead_9353 = 111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyPqa3wIxopVbwC373uVIxULyns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩкζфСΗВСΥвυэбЮρ():
    value = 8807
    text = __import__('base64').b64decode('a3E2elNORWZHenpsc1MwV1MyaVU=').decode('utf-8')
    if 69 * 44 < 0:
        pass
    total = value + len(text)
    return total

def _ΒяρΘЗСΠΩΒΚЬлрωХШ():
    value = 348959
    if False and True:
        pass
        _dead_7290 = 66
        35
    text = __import__('base64').b64decode('TGV4VTd5MjlzQm5DOV90TldZNUY=').decode('utf-8')
    total = value + len(text)
    if 38 * 81 < 0:
        _dead_7006 = 79
        pass
        pass
    return total

def _оцуЧсйхΜЪ():
    if False and True:
        397
    value = 138834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DA3lYX4b7o8hPyqmwkOeYwka63o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΤΠВиенЖИМатΠуΙ():
    if len('') > 0:
        pass
    value = 597167
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3/Da0BgqPgEHSSZn3yGMnMEwX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 3 < 0:
        pass
    return total

def _ХΞчИьΕВΩжЧ():
    value = 442052
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRu0S1Vr0YxQKDeh5VGpLBIN7Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9926 = 198
        822
    return total

def _ДАτΛфяψπЧ():
    value = 281747
    text = __import__('base64').b64decode('RzV4UUJjZ2hqT29pMDBnXzlTaks=').decode('utf-8')
    total = value + len(text)
    return total

def _УУΘЮаΗБучбвФ():
    if len('') > 0:
        pass
    value = 994087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyjVVFVhxI1VAj2ZnVqoFSI78Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if 61 * 16 < 0:
        888
        853
        281
    return total

def _ьнχЛμДБЖЛωвПя():
    value = 62191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Khm2a381q4U6HgKKw1SzZQcm/Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓφЖвВЦнλ():
    value = 581543
    if len('') > 0:
        pass
        837
        _dead_7836 = 153
    text = __import__('base64').b64decode('Z181dDFOWGVmUl84WnUzMzhxU3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙТъΘфьΝδςΙЩЙΖΚψз():
    value = 915733
    text = __import__('base64').b64decode('ZVh3RDdMMkF1am5JeDBNT21EYXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _κнЩΥяΣΒνλуКз():
    value = 409794
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3jpd3AwrY0EAz2KyXSdZggD71Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вьфΡЩжЭэШ():
    if 11 * 16 < 0:
        258
        225
    value = 921446
    text = __import__('base64').b64decode('TG9vRkhGb0Q4Ukh3YVFFY1U3QjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _лИκαЯβΟЩГВзшм():
    value = 90999
    if len('') > 0:
        pass
        584
    text = __import__('base64').b64decode('aDd0YVFsdWNTbkJuaWY1UVFKdnY=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΡибΠξПεмΤябЩю():
    value = 160348
    text = __import__('base64').b64decode('Q2RJeE5QbVp6RThTQ3dYdll0M0o=').decode('utf-8')
    total = value + len(text)
    return total

def _αнΤцΞΞρбсφМл():
    value = 668425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISDteGNvqKkZFVmLm1e4bC0qsmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υиЩдпβНтЛпДχфσξγ():
    value = 395582
    text = __import__('base64').b64decode('S3liZlJDRzlmczhjdXlsbVpteWI=').decode('utf-8')
    total = value + len(text)
    return total

def _хЯκγУΚΨΔЪы():
    value = 778445
    text = __import__('base64').b64decode('ZzN2SWp0NlIxTUM1cGs0RDNQaHY=').decode('utf-8')
    if False and True:
        _dead_5612 = 882
        pass
    total = value + len(text)
    return total

def _ΨζчγΝπямκИΔпЕыщΠ():
    value = 663491
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRjsQWA63IENCS6AkEevJjwC8WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θКегλγъЛшмΥεзΨ():
    if len('') > 0:
        569
        628
        830
    value = 279091
    text = __import__('base64').b64decode('S21JQXcxU0UzcW5GSFAxZTFyRTU=').decode('utf-8')
    total = value + len(text)
    return total

def _иοΣСЕтЫχТбПМλΖшР():
    value = 3047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwvRZQJo2ZAuMgn0+Ey1HDcQ4Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗαΑΦδчиΙбрαМ():
    value = 234786
    text = __import__('base64').b64decode('dHVibDR6VHRrZW1FekdxeXZEMG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΟэКчЫрйу():
    if len('') > 0:
        pass
        pass
        pass
    value = 517146
    text = __import__('base64').b64decode('VkFZQVdyZGY0N0IwM29vcmhNSWI=').decode('utf-8')
    if len('') > 0:
        _dead_2927 = 387
        pass
        pass
    total = value + len(text)
    return total

def _ЫбЗΧгЗφΙБГ():
    value = 713382
    if False and True:
        _dead_9455 = 395
        _dead_9208 = 334
    text = __import__('base64').b64decode('bjdVYXBLQ3MxazZaaWlfNDRfbXo=').decode('utf-8')
    if len('') > 0:
        _dead_1643 = 675
        pass
        260
    total = value + len(text)
    return total

def _кαΟχнΕшн():
    value = 607542
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxXmZ3go75IyOxnzyga1BCcI4jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 27 < 0:
        927
        pass
        pass
    return total

def _σЕЦЪθΨςΜβΙгЧйοщω():
    value = 50804
    if 99 * 86 < 0:
        547
    text = __import__('base64').b64decode('YlozZzRJU1JIVE9HTjVLcE9kMHM=').decode('utf-8')
    if False and True:
        _dead_2496 = 752
    total = value + len(text)
    return total

def _МлагЭΦжБΟщκ():
    value = 838653
    text = __import__('base64').b64decode('WTZtRmV4TmxOT3l4Vzh1VVR1a2U=').decode('utf-8')
    if False and True:
        _dead_6852 = 297
        672
        498
    total = value + len(text)
    if False and True:
        pass
    return total

def _тЕбΤБдΚш():
    value = 129948
    text = __import__('base64').b64decode('dnVWdVZjTmk1WnBma2xzb0hENG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙεαΚлУЪхВω():
    value = 477573
    text = __import__('base64').b64decode('T0Izc0RKWHdUck56YXpEN2Z6MDg=').decode('utf-8')
    total = value + len(text)
    if 15 * 80 < 0:
        _dead_1704 = 268
        pass
    return total

def _ΑπЙγΚδΤсωΣЪΙΟξуК():
    value = 884536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHbRYkYIyf45Ny23/EO3BTUZ3Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_6928 = 802
    return total

def _λαНюκТцος():
    value = 521240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bgjoan9t2qlbNQfwmVKqYAwkt3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яьсЩчχтΥа():
    value = 179428
    text = __import__('base64').b64decode('SDZiaV9jNG9QelFTVzRlQ3JYN20=').decode('utf-8')
    total = value + len(text)
    return total

def _жОНΤкφКψΦΦΒ():
    if 90 * 97 < 0:
        839
    value = 125580
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADz8X1Yg+4MsbB6J8geWMTJ77FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 21 * 38 < 0:
        _dead_7332 = 254
        _dead_8147 = 108
        233
    total = value + len(text)
    if 53 * 23 < 0:
        _dead_2418 = 160
    return total

def _пВЖΙЭгΣΨьйнσΝдΡн():
    value = 570168
    text = __import__('base64').b64decode('b1pFZ2lGdV91SDNibmYxRXFQdGs=').decode('utf-8')
    total = value + len(text)
    return total

def _βΜлτОЖΞр():
    value = 131775
    text = __import__('base64').b64decode('c3hyRlhjNmpHdUFCYmRGZ012MGk=').decode('utf-8')
    total = value + len(text)
    return total

def _εψΖξШяΥΗлш():
    value = 627995
    text = __import__('base64').b64decode('cW1WWFM5MTdjZXBrSWpacVU4eGU=').decode('utf-8')
    total = value + len(text)
    return total

def _НЗмνЖΥфСΨуσ():
    value = 177645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhzFSHoOrKwlDV2W0UGALiEV9n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        384
        80
    return total

def _ЗΧПΨυοωГ():
    value = 452331
    text = __import__('base64').b64decode('cFBaNU9vTUtCRVlmRkVYVmFpV0M=').decode('utf-8')
    total = value + len(text)
    return total

def _тыЩЖψΨяПаτИзгд():
    if False and True:
        284
    value = 257823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRjBT10p+b4hCC2c7H+UOnEOsEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αСΠΠыχшЯщЕ():
    value = 826917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgTdTEUf9YcWDDqP3mKEJwN9zz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if 68 * 55 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    pass
    213