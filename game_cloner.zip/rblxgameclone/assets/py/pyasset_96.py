#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _бΙΞΞΧТНβΞиЯβ():
    value = 195227
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAHASkMWyZsAEyn6x1i/EhYI40g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4524 = 859
    return total

def _ΕΖЪсйΟγирП():
    value = 265454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCDqT0kU/LgMaibx3FGmDA4F1HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 6 < 0:
        479
    total = value + len(text)
    return total

def _БωРΝΡАσДζО():
    value = 67297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHy9fH9v0aonCx+G0UayEyQA1Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        348
        _dead_2814 = 80
        792
    total = value + len(text)
    if 76 * 45 < 0:
        _dead_2691 = 513
        pass
        pass
    return total

def _ъНΟΩбςнИ():
    value = 708104
    text = __import__('base64').b64decode('dFBtRDcxanpMbndyb0tLaW44bTM=').decode('utf-8')
    if False and True:
        428
        698
    total = value + len(text)
    if False and True:
        pass
        _dead_2876 = 362
        pass
    return total

def _ΦенЪΨΛХл():
    value = 41468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgjtWXAr+KovDjaH/QOKIwB+sX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХψηъшЭжХШΤЕШΛ():
    if len('') > 0:
        pass
        _dead_8631 = 447
    value = 222429
    if len('') > 0:
        130
        308
    text = __import__('base64').b64decode('c3JSckxaZEdrajVmR3ducThrZU0=').decode('utf-8')
    total = value + len(text)
    if 61 * 94 < 0:
        _dead_2078 = 476
    return total

def _цφιεНсЖямΖКψс():
    value = 188569
    if len('') > 0:
        844
        _dead_7407 = 553
        pass
    text = __import__('base64').b64decode('akg5dG1aRG5lRjRncVgxMmkxT1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚШЫιυνОΜдΔςπсκХξ():
    if len('') > 0:
        918
        104
        pass
    value = 718612
    text = __import__('base64').b64decode('Vno2NTVfdHQ4anJpQ2w0X3B2R28=').decode('utf-8')
    total = value + len(text)
    return total

def _трицБЦыΦнοΩχΤ():
    value = 765816
    text = __import__('base64').b64decode('T0F3bGhtUGhyUVVuMk9nYjlWZzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ГυΞюцΤиΓγγΨΤЯ():
    if False and True:
        pass
        _dead_8431 = 605
    value = 99314
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IS6xRHce1IlTaDmqnE+UMHQ6xW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЮЯуητХΥЪτπΔΤыЩ():
    value = 392462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiDuYgQq0LEQIxy731OFJgAO9mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠОЖΑΥъжθβнткΞ():
    value = 448789
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ewq0THUq8LobOA2kzAfIbCM8/jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭρλгЬΚαцгюеыММΙ():
    value = 518915
    text = __import__('base64').b64decode('WHg5R2NBbzhfZjdOQVhHb1RSZTg=').decode('utf-8')
    total = value + len(text)
    return total

def _тЬдтЙейтНулЭζνΛΖ():
    value = 357397
    text = __import__('base64').b64decode('dEFnOG1LZDBrd25xVTVDU0gxMkc=').decode('utf-8')
    total = value + len(text)
    return total

def _κЫпХоГЗΑп():
    value = 158364
    text = __import__('base64').b64decode('aTZ4QUt4dWN2ZjRmOG5iSW1tOF8=').decode('utf-8')
    total = value + len(text)
    return total

def _φυЕφλюпΨъεΛδэьМ():
    if False and True:
        706
        _dead_8026 = 94
    value = 421466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgvWbG4r+p0zOySk41y1Ohx7sGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        565
    return total

def _ηвΗΟхЯоПЫАλвЯβПЧ():
    if 14 * 38 < 0:
        pass
    value = 654236
    text = __import__('base64').b64decode('V3pETUFqU2o3TDlac0dCZUJObU8=').decode('utf-8')
    if False and True:
        pass
        374
    total = value + len(text)
    return total

def _ρзΠЩДфβΛΙщмζМм():
    value = 66817
    text = __import__('base64').b64decode('UkdSd1dVbWNlVTJWQXVvSXlMY0Y=').decode('utf-8')
    if False and True:
        64
        725
    total = value + len(text)
    return total

def _ΦЮЖЭЙπιδΚΒ():
    if False and True:
        pass
        pass
        _dead_3678 = 536
    value = 269350
    text = __import__('base64').b64decode('VDhSZTIyanU1TGRpWTlvWlZEU2Y=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        28
        341
    return total

def _ТσвцБΘиΙνηгζАФΗΓ():
    value = 515969
    text = __import__('base64').b64decode('bVJaMWNoMHdLU3JOWUFIekcxdWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟлюξφΜвЦзФБь():
    value = 43252
    text = __import__('base64').b64decode('Skt1c2FBZHd4V3VSekpZbnA3NFU=').decode('utf-8')
    total = value + len(text)
    return total

def _еьмФЪСПАζ():
    if len('') > 0:
        _dead_1066 = 845
        826
        pass
    value = 843918
    text = __import__('base64').b64decode('UHdOdjg4V1kzTmlOMzRfbVhiMk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒбτаОГьφБыΧ():
    value = 596209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ii7edkc85r8KPwaSmm67HnIC3jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аθшгΓРΙΗΓιЕοсс():
    value = 21198
    if False and True:
        393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iya1ZUUqy7w2Hzb770SEJyMlz2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        619
        _dead_1270 = 502
    total = value + len(text)
    return total

def _ГтБЩиΙдуξРτХ():
    value = 815503
    if len('') > 0:
        _dead_4727 = 853
    text = __import__('base64').b64decode('SjFKN29LbU5KSUZ2ZFJ1R0I5WTE=').decode('utf-8')
    total = value + len(text)
    return total

def _эаЕАΦофбсκΑЯκ():
    value = 746459
    text = __import__('base64').b64decode('RGIzMElUVGlaUDdiUWFhTmpZN1U=').decode('utf-8')
    total = value + len(text)
    return total

def _оъэΜЦоΖνΩШЖ():
    value = 77836
    text = __import__('base64').b64decode('cEhOd0VvVllHT1VZbWFiOXgzV2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΘψοЕЗψДκшУβρ():
    value = 141056
    text = __import__('base64').b64decode('YmJFT2QyaTVNOHZSRmhWYkNLX0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨξΦЗΡθΞЭМюΝαΣешп():
    value = 830383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH3oWwMa+Zk6AyeC52WnbHI66z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УшЧηΑΨθΔδψ():
    value = 557093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CADtUWNo8IsyNh/0x1enBzJ3xm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 47 * 75 < 0:
        660
    return total

def _ιмβдрьνμжΓ():
    value = 665709
    text = __import__('base64').b64decode('clFVWUZfNnZxYjlHQ1ZNSnJhVG4=').decode('utf-8')
    if False and True:
        674
        _dead_4119 = 377
    total = value + len(text)
    return total

def _ΧтНμιуΗЙγРγ():
    value = 613148
    text = __import__('base64').b64decode('SGFIR0lxd0FIY3hWSHBsbk1PalM=').decode('utf-8')
    total = value + len(text)
    return total

def _НЙКЭψмιрρβРψБ():
    if 51 * 80 < 0:
        _dead_2393 = 655
        _dead_1623 = 579
        _dead_3843 = 299
    value = 803031
    text = __import__('base64').b64decode('aG1zN2tfYm1BdzNfVW93RFR4Wmw=').decode('utf-8')
    if 50 * 98 < 0:
        pass
        pass
        _dead_1504 = 371
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _цΔДλЮςсКфДюΙИ():
    value = 883416
    text = __import__('base64').b64decode('V2NjYlVkX1Bkb3FKQk9xMmFEMUM=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ξСЩшΓπМШчЩЯπЛз():
    value = 74252
    text = __import__('base64').b64decode('YU5nMlBmNlZvVlFUWlpDODhZZGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦМЪКΑФВиΨΒΛЕрЫ():
    if len('') > 0:
        _dead_5367 = 810
    value = 193317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwD8PnMd7oYGGwe3ygTBLAgq0lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΛтολЮχФЖφЛΧвεφ():
    value = 22250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KC63aXQ3ppwJPF266k+dMjN2/E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΗΞΗρаоЗψТшр():
    value = 442204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxveeQNs9o4INSTw7lCKFSEhsHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΙБζРЗжОΚБлΗ():
    if False and True:
        pass
        _dead_3067 = 763
    value = 670875
    text = __import__('base64').b64decode('VGVvbzRDb3FIY3h1ZmozZEVyeTg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЪЪπΩΥδМεтγзΜТшΩъ():
    if len('') > 0:
        _dead_2861 = 306
    value = 366798
    text = __import__('base64').b64decode('ek5tZHpCWTc3OTRYSGxVNVRrZTE=').decode('utf-8')
    if len('') > 0:
        pass
        120
        561
    total = value + len(text)
    return total

def _γΓжлЛЙкΘРжφЬЧЛм():
    if len('') > 0:
        _dead_2449 = 138
        144
        pass
    value = 7842
    text = __import__('base64').b64decode('QUdXV1R0dnFaS2JWXzRGVjVyNE4=').decode('utf-8')
    if False and True:
        pass
        _dead_9795 = 428
        pass
    total = value + len(text)
    return total

def _кαΓМΘΝхехςΧ():
    value = 609720
    if 29 * 88 < 0:
        pass
    text = __import__('base64').b64decode('eTVsQTRIbmxXNkc2eDNSYWVNOGo=').decode('utf-8')
    total = value + len(text)
    return total

def _пиκРЖаШρμГГΞБлц():
    value = 909323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExzoPnIY6o4aDT+znn/DFys+1nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΤφъνГЩΠГЙзЦщα():
    value = 713857
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCHqfwJr5PkGLhaAnAWIGgQt/Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        234
    total = value + len(text)
    return total

def _ИПβτъΡБвИΚηЕ():
    value = 789751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgzNZFsU75tUbCuQwVCxGiQm518='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юΖΖηНоъячбКЯοю():
    value = 954534
    text = __import__('base64').b64decode('ZU1RQlJyU243ODI2RW80RWMyWHU=').decode('utf-8')
    if 99 * 89 < 0:
        _dead_6940 = 196
    total = value + len(text)
    return total

def _ШШХαЧβΗΛκττ():
    value = 198853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDizb2IQ8ZcKPhrx4k/GNh8i6GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΚερυЭеμξΦэκн():
    value = 187507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhrVQHUwrpsbFlak3XzCHiwlw2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝЧЧлЧсыйφЭοшкд():
    value = 737174
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn/8V1Yarp82Flar8n+ENzIG3lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓВНиузРПЦ():
    value = 781003
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nxq1YQE3+as6Hz2H+QOjFwgE5Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΦΥЯхοпДΘΘ():
    value = 556120
    text = __import__('base64').b64decode('bUpkYjQ5eUJKcFpyQ0RSOTdwenE=').decode('utf-8')
    total = value + len(text)
    return total

def _чтГСЫЬЭσьЭ():
    value = 857290
    if len('') > 0:
        _dead_3519 = 815
        929
        _dead_5839 = 494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lnj8Rn0d0bIxGw2X5me/JQ04zlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΗΩυΤτφΥп():
    if len('') > 0:
        223
    value = 146964
    text = __import__('base64').b64decode('c0ZrQ0oyVElQWTM0Tmc1SGhRTUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЗгΚРУЧЭБИμЖψα():
    value = 885506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAjgQ0Iz8/9bNSmh7E/BOyJ+yUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        257
        572
    total = value + len(text)
    return total

def _ЙДзАкΓгΔΥ():
    value = 517109
    text = __import__('base64').b64decode('SEZ5MU9GQ1RxSEZCcWJJU0JjS2o=').decode('utf-8')
    total = value + len(text)
    if 98 * 6 < 0:
        160
    return total

def _κξΤЯОВсХαНΡφйΚΟ():
    value = 101698
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxbiXEgd0bsMbl6UxAO4EzwF0T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΤΗΧуцЗηΨηчΛΨ():
    value = 458894
    text = __import__('base64').b64decode('Tk5uMGZOVVpfMzJiYklGT2o2bGE=').decode('utf-8')
    total = value + len(text)
    return total

def _φμЙбΟΘχПСМΤЦж():
    value = 71956
    text = __import__('base64').b64decode('Y0lvemRWdjF6MDljaVV4WmtEY3o=').decode('utf-8')
    total = value + len(text)
    return total

def _фινЗγΒВΩфε():
    value = 961797
    if 95 * 50 < 0:
        952
        337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCPrT3030v80Fh62/ASKEyEZwUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йωκΒαХсж():
    if False and True:
        _dead_3073 = 555
    value = 803322
    text = __import__('base64').b64decode('Q3hyWTg2QjBsNEV1dXROWDR1b0U=').decode('utf-8')
    if len('') > 0:
        659
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΡρςнΨΞΓφмРЬгБΣω():
    if 31 * 87 < 0:
        479
        pass
    value = 183391
    text = __import__('base64').b64decode('cEZPNTI0RnpFWFVHdHd2eHhDUVg=').decode('utf-8')
    if False and True:
        _dead_2062 = 67
        956
    total = value + len(text)
    return total

def _πθξлαнАТΔηΠΘΝ():
    value = 79999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD69OVYs6pI6BT6oxn6RHCkqzkg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВтπΟΛЕΝчωОыΥ():
    if 95 * 71 < 0:
        pass
        pass
    value = 42367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAvPXUgSwZATYw2Z+ka6ZjIuwUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УОДУзΖΚτ():
    value = 882720
    if False and True:
        pass
        pass
        _dead_5432 = 735
    text = __import__('base64').b64decode('dlowX056Rll0U3BMYmM2WXo2TzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΥЖрсρьтμΔбΚЛΥЫ():
    value = 465125
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHbSYlIx6oM1LB33wFOgJykGyUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1634 = 284
        _dead_1457 = 79
        _dead_9092 = 548
    return total

def _εЮкбЛчΝчшЖφ():
    if 39 * 66 < 0:
        811
        401
    value = 309301
    if False and True:
        685
        77
        231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH7RRVAT/a8JPTi62EKjNgAj0Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9589 = 197
        981
        _dead_8995 = 945
    return total

def _αΨΠπезΙοФλΗτОШΒ():
    value = 35681
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AS3VS1s6+JcXGzm7+FrDIQMcx1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕИσРЮцуδлρ():
    value = 47651
    if False and True:
        pass
        _dead_1888 = 910
        246
    text = __import__('base64').b64decode('dDBkdHV6WWdZRTB5VlhIUXlEUGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ρщΘγηШЬςγΧо():
    value = 788578
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ane0WVU80JcnMT65xEzDGHwi3jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЦγПтииФΤ():
    value = 299660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSzRW1to1oU7LT2Q4HeeBgw83k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        947
        _dead_3292 = 212
    return total

def _яяЕΜυцπШУаЗжФ():
    value = 916740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxXpYXg0xqs0IBv73WWDBzUItDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        742
        _dead_3770 = 997
    return total

def _ΙЗΚξΩуШХΕβ():
    value = 731597
    if 57 * 9 < 0:
        pass
        484
    text = __import__('base64').b64decode('azFxejBndXNhQklpaUdVUk1yM3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ДХΕщΜπЖςβΘьι():
    value = 472569
    text = __import__('base64').b64decode('YXZLZndQSTRzREdWc3hmRk92bUk=').decode('utf-8')
    if 77 * 1 < 0:
        659
        pass
        754
    total = value + len(text)
    return total

def _тΜΣЭПЦΞΘйΑκτШΛ():
    value = 524412
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQbGN2IY0JFXIluK2HGSDRc9sUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3803 = 740
    total = value + len(text)
    return total

def _ШΒфЪитζЬиΗФΘνςПЧ():
    value = 575107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iw22PV0wz6M0PAT2ykSGJzMM82o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωпаεХюЩΙΜφХыΠЦу():
    value = 585187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnnyWAQa+qUrMgL12H3HbAci/kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШωλПκКψпΠдς():
    value = 322075
    if len('') > 0:
        pass
        423
        520
    text = __import__('base64').b64decode('bURTYm9ZZ2Y0d3RFNFBhY0V1RWI=').decode('utf-8')
    if len('') > 0:
        _dead_6747 = 592
    total = value + len(text)
    if False and True:
        584
    return total

def _ψлκиιвсνэΒΜψδЭχк():
    if False and True:
        _dead_6426 = 224
        _dead_1106 = 898
        pass
    value = 812261
    text = __import__('base64').b64decode('Vm5xNHBGNEs4TGRqZ1RxSXFpVnA=').decode('utf-8')
    total = value + len(text)
    return total

def _аκΘоХΚΖУЗазο():
    value = 329822
    text = __import__('base64').b64decode('cHdtZTFFRlR0c3p1OEcyRXdOSmU=').decode('utf-8')
    total = value + len(text)
    return total

def _υθΑωασΣΔπЩγДЭζ():
    if 36 * 21 < 0:
        _dead_7219 = 437
        93
    value = 24770
    text = __import__('base64').b64decode('ZFJ5SkRIbENpWFFkU2RMSzZEVlQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if 28 * 94 < 0:
        pass
        401
    return total

def _ХГФΒВΝβФψξ():
    value = 586389
    text = __import__('base64').b64decode('TGozWjNHYTUyWld6eGVGQ091Rng=').decode('utf-8')
    total = value + len(text)
    return total

def _ПγЯсΕΟяπВПЬς():
    value = 249816
    text = __import__('base64').b64decode('SXkwN2p5d1o2RU1iNXViVkVFdnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ФχнπνжЦЬΧ():
    value = 716276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bwz3OUYW+os5Fzex6X7ADC4K3X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΩιΥΓТСΙЙοюЯ():
    value = 250786
    text = __import__('base64').b64decode('Q3dvSnNxU2ZZMnhfQ21NSUR4WGo=').decode('utf-8')
    total = value + len(text)
    return total

def _юЯБηАΟупе():
    value = 512057
    if False and True:
        pass
    text = __import__('base64').b64decode('VmNfTzVEVUV2bm5YR3BkR0dZeTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΜтΗжИИδМПΦη():
    value = 628529
    if False and True:
        pass
        _dead_2372 = 320
    text = __import__('base64').b64decode('VlRpZzB4N2JZMThGTTZVX0I5Mkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦъΒуΠДДЦΒЫЦХУ():
    if len('') > 0:
        _dead_8227 = 524
    value = 614285
    text = __import__('base64').b64decode('SklwN0E1VWlBOGVoQ3pwZjRDS2I=').decode('utf-8')
    total = value + len(text)
    return total

def _νтюРьГΘαψ():
    value = 989153
    text = __import__('base64').b64decode('V0JCSER6d0h3RmxZZkpqcFl4TkM=').decode('utf-8')
    total = value + len(text)
    return total

def _γПМβαПτшΜζЯЪ():
    value = 710086
    if False and True:
        _dead_9398 = 352
        922
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD3PbXoArqwnNV6A+mOSFgcO9VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 35 * 37 < 0:
        748
    return total

def _КмщДэБκжчИΡбΡ():
    value = 830244
    if 25 * 77 < 0:
        _dead_8224 = 483
        621
    text = __import__('base64').b64decode('dmx5NTdaeDMzY05EbVJlc0Y2bnQ=').decode('utf-8')
    if 57 * 52 < 0:
        _dead_6017 = 329
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2805 = 889
        pass
    return total

def _СжΒΛΚЪγлμПпХ():
    value = 399850
    text = __import__('base64').b64decode('YnJjTURiMHRzVURXOXlteUQ3ejQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ςеςΗτΥщА():
    value = 346636
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQu1XggKzb8mNQKH3269EBAo9nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υωНУВЮПωУЕйНв():
    if len('') > 0:
        pass
        52
    value = 655557
    if len('') > 0:
        pass
        _dead_3840 = 567
        _dead_2500 = 261
    text = __import__('base64').b64decode('alIwTF9UX2hoclRNY2xFa2tpMWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦФΝψυωΥЕпρКмАλЦт():
    value = 313983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTXMb3URqqASE1uv4kCePC4+7Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЯΘГкςμΙδ():
    if False and True:
        pass
        131
        170
    value = 860374
    text = __import__('base64').b64decode('U05YT0lnRzBuazV4blNabXd4TWY=').decode('utf-8')
    total = value + len(text)
    if 90 * 12 < 0:
        _dead_6084 = 965
    return total

def _ΝсбΕΚμыШулРΥя():
    value = 58458
    text = __import__('base64').b64decode('SkU2V01YdVRVZTZOYmpCbTY5SEc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        304
    return total

def _πБαъИЖйюζΡаΥυу():
    value = 239195
    text = __import__('base64').b64decode('S3VMUGlYMXBwUjA3OTFMZGRkemI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5396 = 409
    return total

def _ОΝрΡσΖΥηдςч():
    value = 139647
    text = __import__('base64').b64decode('TXk5OUp1NnRpVWF1bzcxOWxiOFc=').decode('utf-8')
    total = value + len(text)
    return total

def _тВбΟХυРΤΦМУГу():
    value = 124897
    text = __import__('base64').b64decode('SDFsUHNyQ2RSYnJlQjhRZlFid2w=').decode('utf-8')
    total = value + len(text)
    if 51 * 78 < 0:
        426
        _dead_4557 = 119
        pass
    return total

def _ΘεΥэΓΝΙбГЦ():
    value = 619421
    if False and True:
        752
        _dead_9846 = 43
        301
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3jBZWEL8a4NGzbw/QS1Pz053Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        469
        109
    return total

def _ςЯΘΑκРгюζсйΘ():
    if 82 * 87 < 0:
        _dead_7019 = 296
        _dead_9066 = 747
    value = 483458
    if len('') > 0:
        322
        _dead_9150 = 913
        _dead_9244 = 316
    text = __import__('base64').b64decode('YnRBcVowWFdwMjBhXzNwc3pNbjk=').decode('utf-8')
    if 82 * 50 < 0:
        360
        _dead_5397 = 669
        886
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2866 = 774
        _dead_8548 = 923
    return total

def _ЙшΜэшЙШкйфутΚъпμ():
    value = 730656
    if False and True:
        207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAz1UVgc/5wQHhyT7mapECwG4Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘотρшλΖΗιс():
    if 79 * 11 < 0:
        144
    value = 485648
    text = __import__('base64').b64decode('bWx6WjFqb0RTcFV5ZGQxTmhYaUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪвжцδЮчДмЮУμАБ():
    value = 25300
    text = __import__('base64').b64decode('alJDbEx1M0tCMGQ5OXdtUnd2YVE=').decode('utf-8')
    total = value + len(text)
    return total

def _чрШΦВЫХШΣЪΡНΒω():
    value = 935923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnvlQEEfza8RAD+GnluTLQkh4FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΨлκΦДнЖΘμОЧ():
    if False and True:
        pass
        pass
    value = 930736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnewO2Yv8KQBDAOU8E+JPzMkzko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3174 = 699
        _dead_2858 = 931
    total = value + len(text)
    if 3 * 88 < 0:
        _dead_2143 = 649
        428
    return total

def _ДъкδзШφΖ():
    value = 128090
    text = __import__('base64').b64decode('ZE10WWR1UmlMT3lvZ2hLUVd1REo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕαаΠβРμЗξ():
    value = 54159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwjzP3cs3/xWNVuH/VOEP3MlwFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сιΛΙлΦΞЯК():
    value = 608950
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX7AT3w43P0GHALx33KXDD8N43Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыЛХХοшΞΡллκΓ():
    value = 825532
    text = __import__('base64').b64decode('REpiZ2ZHczAxcVdhbXY1d1hNenk=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΚΗьυηУιψδ():
    if len('') > 0:
        pass
        pass
        pass
    value = 670225
    text = __import__('base64').b64decode('Sm02M2RBc2lqb05FREFMQzhsSG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ФяцхюкиμВ():
    value = 619484
    text = __import__('base64').b64decode('YzA0SGJSQWpJX3V4TTVGWTRNaXc=').decode('utf-8')
    if 8 * 20 < 0:
        pass
        _dead_6195 = 581
        pass
    total = value + len(text)
    return total

def _НЛРъςΝЪμχοΤяΖХΧ():
    value = 288988
    if False and True:
        516
        _dead_9967 = 982
        520
    text = __import__('base64').b64decode('bTh3ZWNUa09Tczl6eTQ5NkZDaWk=').decode('utf-8')
    if len('') > 0:
        828
        pass
    total = value + len(text)
    return total

def _πФЙВδΨзΑνωΩΗЯγ():
    value = 302838
    text = __import__('base64').b64decode('YUpEdXFNb3NOdEJ6VE9GZjh4WnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦвΦМДπпΕДΤЫФЕеа():
    value = 262611
    text = __import__('base64').b64decode('cWhBV3dMczRIRkk3Nm5GeDNubDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ДφαδЛθиЮΘχζχΛе():
    value = 759106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAr2VFcy5rswbCS67mbFHSkr3Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΝмбΨсΛΝжΡСΒΤ():
    if False and True:
        310
        _dead_6850 = 336
    value = 992189
    if 100 * 82 < 0:
        827
        _dead_2494 = 277
        pass
    text = __import__('base64').b64decode('RzZ3MjJYZHdvUmJGN1lEU3BPdW4=').decode('utf-8')
    total = value + len(text)
    return total

def _бФχΛюЗАтΩДятЪθЯ():
    value = 713474
    if 51 * 36 < 0:
        pass
        865
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTbXfHks0YcTFjrznWyjZiYnvG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φУΡνЬтΖК():
    value = 724943
    if len('') > 0:
        pass
        461
        774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDu9ZUJpza0XH12V+lKjDCoq8mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛςεНΠΧφол():
    if len('') > 0:
        235
        671
    value = 217762
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NX7HRlxs2p0tKT+JmmOGJzIszV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δςΤοГфшГЯυς():
    value = 336708
    text = __import__('base64').b64decode('ZDRyR0RaZVA0d05sT05DR19OZHY=').decode('utf-8')
    total = value + len(text)
    return total

def _цаюΩТΓаЗюЭθΡЭ():
    value = 946403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASr+YHY89IEXGyWwzWy7ZDMd7jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яЪНΗрΜЫбζ():
    value = 220097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxnQelQ92J0HKlbw30WGMTIJ0H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εδΒжЮΛΓΡ():
    if 95 * 26 < 0:
        668
        362
        819
    value = 437342
    text = __import__('base64').b64decode('V09qOHpXVHA3YWFBOEUzajdmM2g=').decode('utf-8')
    if False and True:
        _dead_6853 = 624
    total = value + len(text)
    return total

def _ΟηПυпρмΤσΓьμ():
    if 31 * 27 < 0:
        _dead_5163 = 760
        961
        pass
    value = 30635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQvPRmQB6YwiGTyE7EyZZXcNsWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щσДГХοкεн():
    value = 232614
    if False and True:
        _dead_2590 = 832
        833
        792
    text = __import__('base64').b64decode('TE1icWt5TXY0YXRsalBFeVRwWms=').decode('utf-8')
    total = value + len(text)
    return total

def _θΛΩХΟΛΤΟωэ():
    if False and True:
        339
        pass
        640
    value = 747426
    if 89 * 51 < 0:
        _dead_7118 = 951
        pass
        _dead_1250 = 858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Byb9ZXsc3b45FxbxnFu9Gi4i9mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_1478 = 577
    return total

def _ΟНркΨФΧζγжРвαΚф():
    value = 356076
    if len('') > 0:
        68
        _dead_1297 = 695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jgb8VAkd67g2GSv0nXSyDgMAzD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_3372 = 184
    total = value + len(text)
    return total

def _θοΘпξςщжα():
    if 70 * 56 < 0:
        _dead_2546 = 205
    value = 417528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBzRPQlg/fhTFDu6+0XEBCM512M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 53 * 6 < 0:
        pass
        _dead_9209 = 831
    return total

def _КΦэκНθзЕσыюЮЦγβр():
    value = 625217
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mgq0bGswqL01KDih4UazLicYyXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5347 = 383
        _dead_8954 = 171
        _dead_1902 = 747
    total = value + len(text)
    return total

def _кΨчЮУΕΔΣαΓΕΨЛο():
    if False and True:
        21
    value = 859503
    text = __import__('base64').b64decode('VEZoYWpvMDdxM3FiRXg5aTkyTHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖξСРьλбРΕ():
    value = 762834
    text = __import__('base64').b64decode('eE90YlZNcFY0X3NqTUQzNnJHcUs=').decode('utf-8')
    if False and True:
        69
    total = value + len(text)
    return total

def _τΑΩΧТЗνΡвйδ():
    value = 788845
    text = __import__('base64').b64decode('WjhXZHlxX0dEam95d0c1UWtQbkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞηящπщЮΧП():
    value = 221663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT/NN0QP+J8PKwuy/3qWExYZ914='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔщшΒΕШФθыиЫζР():
    if False and True:
        pass
    value = 390482
    if 77 * 6 < 0:
        258
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSnrbVwP0JwwLQGsn2+jIh8r7U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 75 < 0:
        _dead_7987 = 890
    total = value + len(text)
    return total

def _ΟΓΣΔννЮдФХΨЮН():
    value = 845772
    if len('') > 0:
        _dead_1062 = 73
        _dead_1308 = 214
    text = __import__('base64').b64decode('eWlZNXY3ZXV6V05aTzhUUVpJeGI=').decode('utf-8')
    total = value + len(text)
    return total

def _δΨадΟΝΨсΟВφ():
    if len('') > 0:
        pass
        _dead_7891 = 419
    value = 374678
    text = __import__('base64').b64decode('UnRISThSRXhETHVJT2tId0ZSREg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖАЛРвИВшΘΑш():
    value = 672995
    text = __import__('base64').b64decode('eExRbXpFbWFkVk53dV9OM0xvc3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥιьηζЯΣη():
    value = 194925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAX9Z1Nv2v4PMASm8W+bGxYM52U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠψΛχξθЫθηΥЗπΘЙκй():
    value = 827713
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQ7GXQI4+Z0nAB6V+kyJOjUj4FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΜрΥΛЯΖΠαтВрЮоιΥδ():
    value = 455944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABjxO3Mu2/gvFh+V2HHHDiIW8Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΤЪΚЦΟШшЖМЧЦΙиτ():
    value = 149994
    if False and True:
        727
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jj3IOAEUrZwWaBaHwgPIFyh5zz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хаВβЪΩЙЛωГоΖΕЮэΘ():
    value = 716970
    text = __import__('base64').b64decode('V0dwal9xRzVjWjR1S3ZGOGowdng=').decode('utf-8')
    total = value + len(text)
    return total

def _сΙИйΘСъЗΚтΘΝдσ():
    if len('') > 0:
        146
        145
        _dead_8792 = 682
    value = 864911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjXtSEgx5qwSDQKi4HfBYXwCx1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыЭΕЦςΙκпςΟхТЬОГ():
    value = 26664
    text = __import__('base64').b64decode('cEg5cDEwVENiM0wxTTFzdXRISlc=').decode('utf-8')
    if False and True:
        278
    total = value + len(text)
    return total

def _МТшΖκуЪПο():
    value = 557294
    text = __import__('base64').b64decode('VzJvR25jMHlWYlpfZW4xcFBQQTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ξрΜΧΑΜйьα():
    if 59 * 41 < 0:
        _dead_3339 = 532
        _dead_7112 = 363
    value = 505759
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDzVeAUj8oYPbSb7wkyRHXYVzD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 69 * 36 < 0:
        pass
        307
    total = value + len(text)
    if False and True:
        _dead_6294 = 364
        641
    return total

def _ζΗΖΗЖЧЬτΨДТП():
    value = 909231
    text = __import__('base64').b64decode('djdHVU1TV05XNmpuYzVveWtaQmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _цЦμюΙψаΞ():
    value = 548800
    text = __import__('base64').b64decode('V0p4amhTVFJvQktVWjJsblZYelM=').decode('utf-8')
    total = value + len(text)
    return total

def _КΜзΑжОχеШх():
    value = 634625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ch79Q3087bkyAzmMygCSAAktyFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑцОιΝмЩХ():
    if False and True:
        640
    value = 509855
    if len('') > 0:
        _dead_8189 = 789
        pass
    text = __import__('base64').b64decode('clMzVmU5VmZOdllmYXljWFlzaDM=').decode('utf-8')
    if len('') > 0:
        661
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _нΒτБΝдЪΛщншя():
    value = 989967
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N333e1oJ7KYTOyy5xFenMXQW1Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρТЦлΡЖТмСγл():
    value = 506232
    text = __import__('base64').b64decode('aF9GS0xZZHZpNWVUNjRoMmNwMUk=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ДЫвочпгКппΘσНЗф():
    value = 358304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTuwV1Nh2LIUAgmz4XOgNwog0T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΡΠНεΦΨΥКεДΕΒЛЛб():
    value = 979613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCz9W0Iu66oaDwSszWeeNwwisFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗйТзКТЭинНΦΦьЩ():
    value = 233880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiyzOAlryoUmMCbzkXyyFi45zmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        853
    total = value + len(text)
    return total

def _βΨХуφъячф():
    value = 40208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC7yRF0J5IQoFwSv6VGvYgIatV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μщφΣнβψЧΡΘξψ():
    value = 294043
    if 94 * 4 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kxj+akE83fpXE1j37VunNwc3zFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣйЕвλюЬγφлπΩП():
    value = 224331
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('dDBFRTRibUlGSE5KYXV2amRVWnE=').decode('utf-8')
    if 37 * 33 < 0:
        _dead_5117 = 10
        pass
        pass
    total = value + len(text)
    return total

def _НмοπхсΒπЖжцМЪнΣ():
    if 7 * 3 < 0:
        _dead_7308 = 321
        _dead_9152 = 55
    value = 549358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjzPWVIJ2r8zPxyB42SoNw4My34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δυзδУрНэжΥФχζеК():
    value = 216667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx/mTF0x+aVSHAWnw36hN3ALtl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НъсιΜаяштΗ():
    if False and True:
        pass
        283
    value = 873996
    if 22 * 78 < 0:
        _dead_4777 = 159
        _dead_3833 = 556
        pass
    text = __import__('base64').b64decode('bmxqTFJzWUMzWmx4QWlRN3U2Z20=').decode('utf-8')
    total = value + len(text)
    return total

def _БуФбТΑЭЧ():
    value = 366722
    text = __import__('base64').b64decode('SFhUSU5WTVJqa0FUSmRxcEpiUkg=').decode('utf-8')
    total = value + len(text)
    return total

def _πΜЗхиΦΤΠзκα():
    if len('') > 0:
        _dead_4718 = 889
        520
        _dead_6655 = 63
    value = 231397
    text = __import__('base64').b64decode('TVdoQUwzWXZYckR0TExjZmU2Mm4=').decode('utf-8')
    total = value + len(text)
    return total

def _πσБеΠΨбΑцЛο():
    value = 727146
    text = __import__('base64').b64decode('cU8ycjhYWlNzQkhocV9pbEtoS1M=').decode('utf-8')
    total = value + len(text)
    return total

def _рΒюДζрωЬЙРАχиΗ():
    value = 614225
    text = __import__('base64').b64decode('dTU0TkxGTlVCbnZyVTBNSlFjTzA=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ГЬШΖμНЧΝРΤ():
    value = 906538
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pyf0PnoN96UuHyG52WCJDS4l60c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΝщΑХΒαбЮеи():
    value = 228550
    text = __import__('base64').b64decode('VnNobV92UU1ma0VZYmNvMUdCdUY=').decode('utf-8')
    total = value + len(text)
    if 30 * 69 < 0:
        _dead_1117 = 381
    return total

def _КЕчтэβтлηΖΟ():
    value = 82644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChrXdHIb7YMwFTun/XuXYAx31Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘлσнЛчΒНУБ():
    value = 476316
    if False and True:
        _dead_2646 = 461
        pass
    text = __import__('base64').b64decode('b1Q2d0Y0c2VfQ1R5OEVoTXJkRWQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        306
        832
    return total

def _μФζΤцπΔςдφ():
    value = 708462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRzwTQIW0rwkF1qywX2bOh0W8zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 61 < 0:
        pass
        334
        pass
    total = value + len(text)
    return total

def _юνДбмЕκπСУыэБ():
    value = 33423
    if False and True:
        336
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3izdFsNqbAhAi734ASELBw4sWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 18 * 96 < 0:
        370
    return total

def _ьΩΓЩЧζьυХ():
    value = 283447
    text = __import__('base64').b64decode('dHR1dllMTTlvMlY0S3EyVmlvbE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖζМβджфсШΣΕΥРсЪ():
    value = 230858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQjgPEk637sPDguqz0e7FikpvDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _РΩТΚΩЬзΒоΧτΠΙΜβθ():
    value = 291167
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITu8N2MPqIAJKC6V2HCUAws5008='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЖαЛαюΔοлΠΩьДеΘτΜ():
    value = 171889
    text = __import__('base64').b64decode('WFEyVEVNNmpiVXNLQWFtR1FTUW8=').decode('utf-8')
    total = value + len(text)
    return total

def _рРΣμσьйΕωсжΗ():
    value = 255403
    text = __import__('base64').b64decode('Qjl2Zm44dUx4ZHBPM2ZNa2xNSUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЧаΒгμВЩΦт():
    value = 757277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njy2YFQe7oMvYhyV7GS6DCAl1Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4308 = 33
        _dead_4268 = 139
        pass
    total = value + len(text)
    return total

def _мтΩιБφνрΑщαЧωЮ():
    if False and True:
        pass
    value = 730048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxD8O1o08rALCQ21yn6DGXY7zGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψυтОфРтιυЪΥф():
    if False and True:
        _dead_7068 = 899
        pass
    value = 841905
    text = __import__('base64').b64decode('VU9OZVhfNFJvc0xwUmJfZG12a1c=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6251 = 604
    return total

def _тАεХχъТνζдМ():
    value = 871884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgP3T0gA2p5SEy6A+gC6IzQf9DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βΡгПλНтЪбЯбμкβηд():
    value = 314725
    text = __import__('base64').b64decode('TmJrdjUyaVVOdUJ0Tk9QdUMwTm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯμοΞШгныΣЫιБΩιт():
    value = 218272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQvUfl4M06A3FCPx3wS1J3Ue7UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΔχφЮςПЧ():
    value = 740179
    text = __import__('base64').b64decode('am1va1h3bXVWNkhzQWRuemlYX24=').decode('utf-8')
    total = value + len(text)
    return total

def _ςτΚΒКТΣРПЧЕΔΑ():
    if 44 * 8 < 0:
        _dead_8655 = 533
        pass
    value = 901453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwXWOlcp25wsNh36+EKWLiYkyX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 89 * 75 < 0:
        _dead_4118 = 907
        _dead_9994 = 163
    return total

def _ТБЫЮняыОΡМ():
    if len('') > 0:
        _dead_8037 = 606
        pass
    value = 768405
    if False and True:
        990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDvMYHUWrrAJP1yhyWe8ZRAj9nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σХИДΗιρПиуЬΒ():
    if False and True:
        575
        _dead_6478 = 523
        155
    value = 208205
    if 36 * 42 < 0:
        _dead_4250 = 205
        pass
    text = __import__('base64').b64decode('Y0g1RnQ5M25idHNTdkhGS1BtclA=').decode('utf-8')
    total = value + len(text)
    return total

def _αшлгτΔяπьчΕтПЮκκ():
    value = 287193
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxzmeAYL5LsEOwKt3Wm8MjE840Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛПсΓνиыΡЮЭЩΓфζ():
    value = 457600
    if len('') > 0:
        332
        _dead_1207 = 662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiTdOUZs6ZEVHQrwmQazLg0nwU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9814 = 698
    return total

def _ΥρРΩРυεАΓΔъΥУйЧж():
    value = 347614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHrFQWI38PhUIxez0V+bGhUoxVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5044 = 514
    return total

def _ΞξАδξЮРцδфθгΘτ():
    if False and True:
        855
    value = 564680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCbAT0MI3JsHYxX23V62HiM/7Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7944 = 152
    total = value + len(text)
    if 10 * 16 < 0:
        pass
        pass
        pass
    return total

def _ηЩιρиυКΟйжцЯΧΖо():
    value = 898984
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('UWZZVkdXVzNOUHJuX0dpR0NlV1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΔьπΞΔΡΕΕ():
    if False and True:
        969
    value = 126717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgPyPmM9z6U6Yi2G+33IOB01ymk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цοЮЦДΩЙψьВБ():
    value = 116776
    text = __import__('base64').b64decode('bkdkMnBvdmgzWDBCbWpxa2dHN20=').decode('utf-8')
    total = value + len(text)
    return total

def _жνΑΘнБонΚΗнΤЦ():
    if len('') > 0:
        129
    value = 703294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSaydkUIyfgBbDea6n+IOC02xWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _окйΕΤβнουΜЙχ():
    if len('') > 0:
        _dead_7578 = 156
    value = 801739
    text = __import__('base64').b64decode('WVJYUzlIMGd4NDBIY0pobWJWdEI=').decode('utf-8')
    total = value + len(text)
    return total

def _фШρЪКящСγИрЛ():
    value = 815211
    text = __import__('base64').b64decode('SHVFbGJlOUp2QWljWWhpMjJpSDc=').decode('utf-8')
    total = value + len(text)
    return total

def _мЫЙΦΞсфΜ():
    value = 467660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRb9PEgb/f0xChm6+GmoAgh39U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УсβбяΝУΥЖΛ():
    value = 904304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATXXT3Q22IsXPwWlygG8IzUXzGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΤЩтδΨΑΘΝБнπЩζщ():
    value = 140588
    if 75 * 61 < 0:
        867
        _dead_3299 = 517
    text = __import__('base64').b64decode('VUR5R0x6M05CNzBoeTVrUWZZa1U=').decode('utf-8')
    total = value + len(text)
    return total

def _πβΛνМаыΣ():
    value = 424217
    if 73 * 91 < 0:
        _dead_2260 = 531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXvCeXwPq5A7Mgj04ESFGCF/7T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        554
        _dead_9128 = 24
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('bQ==').decode('utf-8'))
if len('xx') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()