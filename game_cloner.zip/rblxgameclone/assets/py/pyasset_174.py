#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ЙιΦРχЬцΙ():
    value = 433669
    if len('') > 0:
        _dead_2120 = 241
        pass
        _dead_3246 = 43
    text = __import__('base64').b64decode('dkJia2Nwdl9LVlJPc1JNdFcyWFE=').decode('utf-8')
    total = value + len(text)
    return total

def _сηΞΓωπЦЯгРΧчΟуπ():
    value = 864527
    text = __import__('base64').b64decode('Qkd4TzhoWEFZS3JsSmNzYmVsZ1g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        400
        pass
    return total

def _сЕΙгЯХЦмйτЧпЖЯ():
    if False and True:
        _dead_7291 = 505
    value = 618554
    text = __import__('base64').b64decode('TFlZZWRfelFGbEhHYnNxeWUyc0g=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΑΠЙБПРбыОаΡулы():
    value = 776200
    text = __import__('base64').b64decode('Ymp0ZU1lRXBuZmFTQlpSZnZaX1c=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8301 = 167
        pass
        pass
    return total

def _чΦΨОчθΘΣЖε():
    value = 277673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB/rQVAIyqJSaDry7m6WPBol4V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΕЧΝсЧОыωΓбЛ():
    if 75 * 55 < 0:
        751
    value = 541533
    if len('') > 0:
        _dead_9272 = 191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En7UY1kIypoEGTWW7QOzZDYG/ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 99 * 5 < 0:
        _dead_9252 = 920
    return total

def _шфЛЧПΔοЧυыΝрξ():
    if False and True:
        624
        730
    value = 240968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjbwZns86o8WbR/z5GCnJSYXsEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яЙζИстεΣПΞьВς():
    value = 315174
    text = __import__('base64').b64decode('R04wSFQyNU5lU1c1Wl90cWVyR2I=').decode('utf-8')
    total = value + len(text)
    return total

def _νщλξΞωсΜΦдУоф():
    value = 114343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDzqfAMz7I0NKCKo8FOeOSEb7Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΕΝзТΛυκγΜβΑЩэ():
    if 31 * 43 < 0:
        _dead_7115 = 688
        _dead_6977 = 12
    value = 749724
    if False and True:
        307
    text = __import__('base64').b64decode('dVNXSlJZTUZQa251NFJRQ0dmd2U=').decode('utf-8')
    if 3 * 91 < 0:
        _dead_2468 = 718
        _dead_2451 = 808
    total = value + len(text)
    return total

def _γτьэТΡЯМνаиΕ():
    value = 57859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXr2flQv9pwkMTaz21SFDS4r/n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_1155 = 215
    total = value + len(text)
    return total

def _οМσдРΔШψΠΩЛа():
    value = 56678
    text = __import__('base64').b64decode('WnplQ040ZmNuTXVjWGl2bVBjcXg=').decode('utf-8')
    total = value + len(text)
    return total

def _шыпΜξТΞψяКт():
    value = 690564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQfMS3pp/aoSaQq54l/IBxI8zjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΧюμЭЭнζлαςηη():
    value = 192575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxCzdgkN7Ps3OCinzlmAEh0t9WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΨСЪзЯΓциΤδъ():
    value = 643572
    text = __import__('base64').b64decode('dDhLeVdfQlVwVGhaWnBFenVaRFM=').decode('utf-8')
    if False and True:
        _dead_2441 = 555
        522
    total = value + len(text)
    return total

def _нθющΓрΥеаΖНΨеγ():
    value = 381416
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgeyRUYQzqMzPhq3/2SqJgoI1Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΞΡЕФЙχэπй():
    value = 442628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag3lQGUR7ZtUKVb2yXeyCxMYtEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 48 * 33 < 0:
        pass
        _dead_1892 = 840
        _dead_6532 = 998
    total = value + len(text)
    if False and True:
        pass
        386
        pass
    return total

def _ЕηζχτЫΔтщ():
    if len('') > 0:
        513
        _dead_9303 = 939
    value = 125804
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSjnNl8R1JItYxn0nHykLAN46Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _дΠΓХκгтШЯ():
    value = 996752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxW8eQU/6r4MHj6U3FfBABcMz0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зпαχμфЩЯΒτψιи():
    value = 655094
    text = __import__('base64').b64decode('Rmx5a2ZyNFJBa2F1eWkydXZFb2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ащйфМЕННпОΦчнЯд():
    value = 506150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn7NQ1o88IMHGyr0nXnAYy8i7GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1484 = 690
        _dead_9553 = 202
        pass
    return total

def _ΡТΜсΙΒЙА():
    value = 403667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J33lYXAO3KAxPwm08VmCEBd64WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нКφбΤχΜΞБИЭЬΦπсщ():
    value = 572394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwnSd0UB1L0QCQyZ2XCdEy998Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖХзχψωφЕойνУЮψΚΝ():
    if len('') > 0:
        _dead_2334 = 815
    value = 825154
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHywQ1o394IlOR6V91OfNwcI80s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_4086 = 927
        pass
    total = value + len(text)
    return total

def _ЖρшиярΤνвУБ():
    value = 6237
    text = __import__('base64').b64decode('Tlk3all1NERIUk1DS1M2UGhzYUU=').decode('utf-8')
    total = value + len(text)
    return total

def _фΙФвШТζьлХпыΦψΔΑ():
    value = 859180
    text = __import__('base64').b64decode('QmFXNnpQRkZQRG9jaWJUalAxd3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕАΟτЕβыωрπ():
    value = 283709
    text = __import__('base64').b64decode('UU9kNHZfMUlPb0I2Ynpad2tnWGE=').decode('utf-8')
    total = value + len(text)
    return total

def _овΒпЭелΡИΥΖ():
    value = 850337
    text = __import__('base64').b64decode('aVR1dkQxMGswUzRmY3JrS1V0ZXE=').decode('utf-8')
    total = value + len(text)
    return total

def _щξδАεъζРΟ():
    if len('') > 0:
        _dead_1091 = 498
        356
    value = 445455
    text = __import__('base64').b64decode('WFVXcEFQYmJudnY1YllocGpOWVQ=').decode('utf-8')
    total = value + len(text)
    if 1 * 100 < 0:
        pass
        525
        _dead_7501 = 973
    return total

def _ΙЬрЪΨОξφσΕΚυΤΝΛ():
    value = 27679
    if len('') > 0:
        pass
        _dead_2337 = 888
    text = __import__('base64').b64decode('cXB5NkJXVHJpYk5OYVRGeVlPSk8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _ΚязбΝуоλЛГμΡΘ():
    value = 444261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCzKXghhz5I1PxuE6lW0Iw0f5Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьαΧΔГЪЕХΞφΧΚДΘ():
    if False and True:
        _dead_5199 = 551
    value = 177322
    text = __import__('base64').b64decode('T0hFRTdieG1HX0NOOTNMRWVydHc=').decode('utf-8')
    if len('') > 0:
        _dead_2015 = 889
        pass
        386
    total = value + len(text)
    return total

def _вΠьγνδютфΨсЦψКо():
    if len('') > 0:
        _dead_9854 = 947
    value = 537042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3jlQEE39PAzPF2Fzk+qCyo29Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗγвψΟбеφАΤА():
    value = 353554
    text = __import__('base64').b64decode('ZXFVT2VqMGNDU1NsVElSYjNyVDA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        758
        184
        _dead_8688 = 727
    return total

def _ШаαΦИйυΚΤТЫАе():
    value = 163657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxC1OlwNq4ZWYx2h4H+1Nww//FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юΧБΗΦТанξμ():
    value = 169341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah/3P1MepoVWbAKm8UavAAoE9kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΖкРσшχуТΕ():
    value = 3529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzzeXHcdqIYqOQGwwUC+A3AL10c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΔэδГело():
    if 44 * 90 < 0:
        734
        pass
        856
    value = 883792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ayq2VEscwZAKFBWh+0WAInAkxkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        289
        _dead_2166 = 909
    total = value + len(text)
    if 53 * 56 < 0:
        _dead_8499 = 523
    return total

def _ЗυρΒΦΕφΑ():
    value = 19280
    text = __import__('base64').b64decode('VGtsQ2hpeU00WVlpak4yMndDbEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕυΝХЧсйεЙШΕκк():
    value = 459782
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT7VYG4S8aILbDyOzGWfOhEXx3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦсюμЙЩжвщЯЕΚЯр():
    if len('') > 0:
        86
        498
        _dead_7460 = 522
    value = 542278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jyvgb3s1+qYNNjyanA+4FiIb4Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 72 * 64 < 0:
        _dead_4570 = 313
    total = value + len(text)
    return total

def _эτραаΠυДАИΔηδЙαр():
    value = 963642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj/CZEctzbAmPxia53emOjIF5n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΗιелАФвμΟΦЕΩ():
    value = 93444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyzgPkZg6Ykpa1uM6nmdGRAk5mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СψОβρΨκпьХΨЗνα():
    value = 532770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FD7+VwNvxItVLDmmwnyzIx0c/D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        196
    return total

def _ЪЖλДЯьεΓς():
    value = 605229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXbMWngf36A0HCDxml+IGyJ9xmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΞοВШХГΡВΟ():
    value = 437391
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCDgR2Uw5KU7D1qVnm+YHx0r/GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΥЕΕТЮэΑЩψд():
    value = 997533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHjSdlIo7JwvEgesw3CCEyh6vGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮоКΕкмαЕ():
    value = 313723
    text = __import__('base64').b64decode('emw5ZmthSEZ4T2dLOEhlTGhydm0=').decode('utf-8')
    total = value + len(text)
    if 14 * 39 < 0:
        pass
    return total

def _αфШзИθΚЩОюуσкг():
    value = 442118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiHFaWVt85sGahmr33mzPxA94Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пцлдЬΖΙХρкζвкяПа():
    value = 588398
    text = __import__('base64').b64decode('WGJsUm9mZVJ6d0NlZExHWDB0Q0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΘОΒΗьВΟеБйЬζ():
    value = 841720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyLWZncjzLkNEguM/3SYBQcn1ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕБвτЫνЫыЯ():
    value = 162718
    text = __import__('base64').b64decode('aFpfemNEclk0eUdORW9YNGtfeWk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7330 = 983
        _dead_1616 = 459
    return total

def _ΒСθйΘцхА():
    value = 790219
    if False and True:
        _dead_6185 = 20
        48
        932
    text = __import__('base64').b64decode('QlhrVG1WUnlEUTNlMjJ0YWFkTlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _уξэΗоΩоωΡχ():
    if 10 * 64 < 0:
        161
    value = 115729
    if False and True:
        315
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSj+Ynhty7s0Ch227EezBSYCt38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 60 * 26 < 0:
        538
        728
    return total

def _РιКЫяжЦΕΚГυмΩ():
    if len('') > 0:
        _dead_1449 = 74
        _dead_5511 = 904
    value = 234183
    text = __import__('base64').b64decode('cjRVNnJGdDkxWGxReGN2SEpLeDQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7025 = 755
    return total

def _ΖьΣЙπыУй():
    value = 887078
    text = __import__('base64').b64decode('U3A3R21yQ1ZDMFcxM1ZYc2JNSm4=').decode('utf-8')
    total = value + len(text)
    return total

def _τοсВмΦТχΙВ():
    value = 40111
    text = __import__('base64').b64decode('TmVwS0RldVVxaDRkVGJGXzY0U2Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        474
        817
    return total

def _ΗНшоβΣΣЛШлО():
    if 95 * 87 < 0:
        pass
        746
    value = 766036
    text = __import__('base64').b64decode('TGFGX1dhMkdZZU03RTNrT0NzTjU=').decode('utf-8')
    total = value + len(text)
    return total

def _βСμрлεВΩПΕюэцОκρ():
    if False and True:
        98
        414
        pass
    value = 875496
    text = __import__('base64').b64decode('Vm9BRTRmN2RfXzJoWmxZa1JyVUY=').decode('utf-8')
    total = value + len(text)
    return total

def _аξСбχАΞфοΒПкθσΚН():
    if len('') > 0:
        430
    value = 788419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwHTX30rraohFyqLmGeYFXAetXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШхгщэΛмБ():
    value = 359611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izq1UX8wwYk8LRunnFGJJhQ//Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖБЕжЗφΒρТηΠλξ():
    value = 763021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyvHWlMPyL8PaVqJmwe2ZCx78Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГлКςЧζμБΥьΦХΝ():
    value = 914396
    text = __import__('base64').b64decode('U016VUoyaWNzbzI1Wk02elFKeFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦχγЫθЦΑЕюΓΜП():
    if False and True:
        pass
        pass
    value = 208084
    if len('') > 0:
        195
        _dead_7631 = 880
        _dead_7009 = 6
    text = __import__('base64').b64decode('cFZLdjVjMGlmOWNzSzBYZnd0bUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤψεижΚΤуμнγАкσοΟ():
    value = 104301
    text = __import__('base64').b64decode('bG14aGZQUFlFOVc5M2pyTFlvVDg=').decode('utf-8')
    if len('') > 0:
        617
        pass
    total = value + len(text)
    return total

def _ЯΝΜЩςΤψЦиξαιдηΗ():
    value = 721817
    text = __import__('base64').b64decode('RWswclhkbnh5R21sQno0SDlka0o=').decode('utf-8')
    total = value + len(text)
    return total

def _νΦчωуεΒИЙ():
    value = 792001
    if False and True:
        175
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgW1VgAe7L82PgWU8F+UHTYctF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        758
        pass
    return total

def _ςσЗсΑιяδЛΑΒЭаμψ():
    value = 245953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lwe2QW4vxIIEBSe6zlqXBygYy2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧςνσГЦбЛСΜхЖΡиγ():
    value = 837804
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX3LNktg65oKBRmxw0HGFRZ+8Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΥΣΓуπЧОοΟΔΘтзЧШ():
    value = 125544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh7CR0YR7L87FVmynw7JOQ972zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 13 < 0:
        77
        135
    total = value + len(text)
    if len('') > 0:
        550
        _dead_2321 = 621
    return total

def _ςЕΛфОξЭтечЬΙπа():
    if len('') > 0:
        376
        pass
        pass
    value = 429473
    text = __import__('base64').b64decode('cFVEM0x1SnN1S09HVzFxb0VoaEM=').decode('utf-8')
    if 88 * 2 < 0:
        2
    total = value + len(text)
    return total

def _ФлЙχμΠΩαχЕзΕтΑОΩ():
    value = 149786
    text = __import__('base64').b64decode('dzc0bU4xRVVKaHA0VF92eWpBcGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘρЙЦЦψзΕЮΠШжΠ():
    value = 622347
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mhe0N0ka7YYoIx6h8GGqIAEZ1EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        453
        pass
        645
    return total

def _ομκэбзΥνη():
    value = 324761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXnTVFMu+6RTEByp20yIbCB9x1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шδζλΗФτωюМμΥ():
    value = 644966
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzXgP1YXzadbEQOvnFm0YXY300M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 97 < 0:
        915
        _dead_9773 = 22
        pass
    total = value + len(text)
    if 14 * 67 < 0:
        _dead_3834 = 687
        987
    return total

def _ΙΜнσъЩиγэБγ():
    value = 284009
    text = __import__('base64').b64decode('cUM5bDFrREY0OEw0elZmaEc5SDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤВΘгСξнρтЮЬτПΨЦ():
    value = 605337
    if len('') > 0:
        729
        157
    text = __import__('base64').b64decode('eGFxdUh2U2pnWW9lRmQxRk54QUY=').decode('utf-8')
    total = value + len(text)
    return total

def _еЩηΘМЪРΥ():
    if 66 * 51 < 0:
        pass
        _dead_7848 = 537
        _dead_1405 = 939
    value = 894375
    text = __import__('base64').b64decode('Z0tuZE51VlVRMWpGSzczWW8wUXU=').decode('utf-8')
    if False and True:
        pass
        761
        pass
    total = value + len(text)
    if False and True:
        _dead_1227 = 125
    return total

def _вЩΙЪнξЧАθфТгФЫΥΑ():
    if 56 * 30 < 0:
        225
    value = 543957
    text = __import__('base64').b64decode('bXhwVVFoSXFpVGcyVGl6eENVbU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ХεиЬДДμΡдмчШ():
    value = 183699
    text = __import__('base64').b64decode('azBhMFhEMl80YzFJaE53RzNKWWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _РМеπξΣΕΦΤθСьЪ():
    if 69 * 21 < 0:
        407
    value = 231934
    text = __import__('base64').b64decode('ektpQTUyYjFvTVRfcDFmRGRiRDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ФСΝЮщаяεД():
    value = 777432
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRDSSFUW+ZElFQWmwFCjOHce/Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φгρτПЛОУΜαюЯδНа():
    value = 74616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDy8eGNr+qslEiW68nCEPxAMskU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тэκКгОзΩзλдюζМΑН():
    if 40 * 75 < 0:
        pass
        _dead_5818 = 663
        pass
    value = 846085
    if len('') > 0:
        _dead_8874 = 304
        542
    text = __import__('base64').b64decode('TjZ0OXkzZzZfU0dROTZSMGRTOXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ьлНμεκЗΟτΟΛШс():
    value = 525677
    text = __import__('base64').b64decode('TU1qVVlDTzlxQUVKVXh3SWRDVTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ДρкνтФςлΙλπдКζ():
    value = 228642
    text = __import__('base64').b64decode('dGhfb2R0cnJVMVhZeUFKa1E5N3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ВКгВΠфΩОιОνюξΙγΗ():
    value = 111151
    if False and True:
        861
    text = __import__('base64').b64decode('UmJuRzAyeGtnSGJhckYzYnFFQnk=').decode('utf-8')
    if 40 * 66 < 0:
        _dead_1369 = 884
        _dead_8817 = 80
        _dead_6858 = 162
    total = value + len(text)
    if False and True:
        2
        pass
        533
    return total

def _щвХωЧнэΕгЙЖ():
    if len('') > 0:
        pass
    value = 25450
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FySwPXoyqr4pCQvwmQWGYxMBt0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _НнΦЮЮκПΓιДωνδ():
    if False and True:
        902
        _dead_3396 = 92
    value = 152947
    text = __import__('base64').b64decode('WGRsR1o1NEgyUDFSTk1qRk01U2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΔРхЗΚЦξыЛκνΒТρУ():
    value = 61598
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj/3aVlr06A8E16GkUekPggrx3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λУсΦыψнЦιΠΙΑυυ():
    value = 581916
    if False and True:
        pass
        _dead_9643 = 569
        367
    text = __import__('base64').b64decode('dHpJR3dGVUFnOFBBY2xRdVBFbVk=').decode('utf-8')
    if False and True:
        486
    total = value + len(text)
    if len('') > 0:
        _dead_8997 = 806
    return total

def _ыСζεΖΜψпц():
    value = 656513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwDtZnkDrZswFSazzQCxYDEGs1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3288 = 96
        803
    total = value + len(text)
    return total

def _кιНΘтΦοΝоψ():
    if False and True:
        159
    value = 173764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTizWWk26pcMLg2N5VWTPxYd70U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 95 * 20 < 0:
        _dead_4051 = 794
        998
    total = value + len(text)
    return total

def _вνТρΚшйОσНн():
    value = 457052
    text = __import__('base64').b64decode('cUo1bTRwS0ZaWEo2Tl94c3N5c0w=').decode('utf-8')
    total = value + len(text)
    return total

def _βбΙыбДΙλ():
    value = 904642
    text = __import__('base64').b64decode('TVhiVTZwemxBSGtYZm1PdlJYUlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ьωЖшЗНюОζ():
    value = 970363
    text = __import__('base64').b64decode('QjdmbjBiNm9ScE5ITlJRSjFNQWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩνцлΠΡешБЯежηНь():
    if False and True:
        _dead_3268 = 577
        _dead_2790 = 533
    value = 547919
    if 43 * 51 < 0:
        _dead_6918 = 125
        _dead_1340 = 989
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSr8X34JrrsoPzCmngWZJ3Mi82U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1244 = 894
    return total

def _ΨаπжвСЕЧΑ():
    value = 175888
    text = __import__('base64').b64decode('cnp5RnY1dlRiTlpJZ1RBNm42T1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ДюЮΚбгςТΔнΒРвПτА():
    value = 911226
    text = __import__('base64').b64decode('YU9ac0FFTGhSd001RXI0RHhsR3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΜβХЦγОХςζЫ():
    value = 402868
    if False and True:
        pass
        378
        _dead_4251 = 740
    text = __import__('base64').b64decode('SWJRTFFUMDdsT21SYnFvU20zOTY=').decode('utf-8')
    if len('') > 0:
        565
    total = value + len(text)
    return total

def _чνΠΨΓзНРзЮ():
    value = 346052
    if len('') > 0:
        _dead_7723 = 770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRb+ZmMD1p43HluM/Hu8NwoI/Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 14 * 40 < 0:
        pass
        631
    return total

def _ТААНЗςОжЭΓЮΗ():
    value = 804049
    text = __import__('base64').b64decode('SDhHOTd5QXZUNVVObVY4WDZONlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΛЕΖρνΥЭσЦμΔы():
    value = 931279
    text = __import__('base64').b64decode('YVU3S2VvdzJ4MjM1YmJmczZ2Rm8=').decode('utf-8')
    if 90 * 34 < 0:
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _еЕйъожΔσфΙяЩ():
    value = 506090
    text = __import__('base64').b64decode('WlhFek5Gd2doUDBjZ3NzbG01Z1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬКΚзδΠθΚΣΧιиМΒΣ():
    if False and True:
        729
    value = 325445
    text = __import__('base64').b64decode('UzJDUmMzbzZsdW5mY3phVmVhRTk=').decode('utf-8')
    total = value + len(text)
    if 97 * 60 < 0:
        131
    return total

def _ЖвэΤИρгΗфεΟьΜΝЦМ():
    if len('') > 0:
        911
        pass
    value = 668777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAvUf0gOyv5SaFyA4luzIQIG91g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        860
    total = value + len(text)
    if 70 * 48 < 0:
        pass
        pass
    return total

def _ΝΛНΨЫωЗςβνςσ():
    value = 591064
    if len('') > 0:
        434
        _dead_6597 = 133
    text = __import__('base64').b64decode('T05YVk10MkVwSmxXRk5nVUw5TVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ъэρЩΣΔДθΥ():
    value = 817581
    if False and True:
        114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3bHdH8P8JcCIgapymefIgEa6Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        465
        _dead_9491 = 36
    return total

def _юмТΛαΞиψΗеаЪяЭ():
    value = 492095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRn3QmRv1vw1almI2UacZDQQs0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛнΩζыσΩλβΩΑбчЛ():
    value = 566034
    text = __import__('base64').b64decode('Ym9iWlY1blJmcHdvNjRMYmxjXzk=').decode('utf-8')
    total = value + len(text)
    return total

def _βДоВшеибР():
    value = 626480
    text = __import__('base64').b64decode('TzNuZ0ZaYzNoTFlTYmNKcXpsQTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓЕΕЛЗψЖйΘчΤЭΡσЮ():
    value = 415498
    if 94 * 74 < 0:
        _dead_2477 = 935
    text = __import__('base64').b64decode('b2VYUWZWNFVDaDF1bGpMaEV3Umo=').decode('utf-8')
    if 53 * 12 < 0:
        pass
    total = value + len(text)
    return total

def _υЦГβΨΕвζΖЗы():
    value = 161790
    if 47 * 31 < 0:
        pass
        124
        938
    text = __import__('base64').b64decode('Q2ltMzMzNmRVOGNaVFRzWEt1N04=').decode('utf-8')
    total = value + len(text)
    return total

def _АυдωьмΡμ():
    value = 940494
    text = __import__('base64').b64decode('QWgzMU9nd3h0a29Nb3RoM0ViSHQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_7284 = 96
    return total

def _ΗЫБΧДЪиυΘгд():
    value = 777079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj30TFgR/KRQDBuIyXy6BhY65Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΖлτγΝΟйКθΘЙчμ():
    value = 15485
    text = __import__('base64').b64decode('azZZUHJRRTZUQlpCbFNYVnRZSzk=').decode('utf-8')
    if 11 * 9 < 0:
        986
        5
    total = value + len(text)
    return total

def _αЩΨχЪНТБФ():
    value = 786109
    if len('') > 0:
        _dead_1928 = 635
    text = __import__('base64').b64decode('Y29vVjdnaldZaVpjemk0THVZWVQ=').decode('utf-8')
    if 14 * 52 < 0:
        pass
    total = value + len(text)
    return total

def _ъоГκΕЙδШЛΜБ():
    if False and True:
        428
        _dead_4408 = 401
    value = 512981
    if 32 * 84 < 0:
        _dead_8492 = 162
        641
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxDWVgFuxI5VaiOW8HuKLj8Hsmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 19 * 13 < 0:
        963
    total = value + len(text)
    return total

def _ЭйРхΔЮΓЖЪржξгγ():
    value = 30996
    text = __import__('base64').b64decode('eTFRQ3p5eEFDUm9hbjNCRF85SzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _σРΩκΩΟοβнщЭΕΤ():
    value = 986996
    if len('') > 0:
        _dead_6583 = 768
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzXIXVwjqfomMV+yyn6DNQsr70c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыЛчΜψЭΝΔХΥΑΝь():
    value = 879233
    text = __import__('base64').b64decode('YlFBcmk5cUMyTWJDRWI2bGVydXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΦΛТΥРΨхшΠгСА():
    value = 299592
    text = __import__('base64').b64decode('dGJJV05MZmJhTFZtUE9EcVE2c0E=').decode('utf-8')
    total = value + len(text)
    return total

def _χρΣнОНΝсяЫТΕФ():
    value = 818007
    text = __import__('base64').b64decode('SER5YUx2cWJYd094bE5vZ0ZwcUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭшаСαЖЗδΒдΕιηзθЫ():
    value = 920062
    if 79 * 39 < 0:
        _dead_8067 = 243
        _dead_4127 = 989
        _dead_1531 = 381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISfHWVAaya4bLBqu/3TJAHU54Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 77 < 0:
        pass
        125
    total = value + len(text)
    return total

def _БДыψтζφпδЫСКβЭр():
    value = 193081
    text = __import__('base64').b64decode('YmxIVkN3RE9RTmRwSndqVFQyeUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗЧбяДχγУОЮνэΩиЧ():
    value = 894404
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxv9OFwK7v81Agep0ACmIzx+3Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΠΧШъΦΦσψΛ():
    value = 571186
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTznN3USx78UDxihmgS4NXEWyUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΚωпоιЛЧющΚφЩбЭ():
    value = 335146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DC7seFAVqoo6ID2L8QK1bAMW/lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щУβзωзτхΘ():
    if False and True:
        553
    value = 660263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3vbYksY1bFSHw2OnFC+Yy8c8jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξγоЫηΨΑΕтυΘΞиΘхΑ():
    value = 500634
    text = __import__('base64').b64decode('d21mUUhTQklqN3lQNEVIQjJZT0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΞψЮДАςΛа():
    value = 298921
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz7SfX9v+owVYziLmWGEGC8dzHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        36
        _dead_1978 = 20
        _dead_2584 = 226
    return total

def _ΝЛΖαΟεΞΤΜчри():
    value = 829431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej63egYq551SDyOzkXfBARAf1z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠвъжΓθβм():
    value = 938625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjXtSm5q2JEyaSi5zF+FBXd2yXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _биНυвркгдγΒιШΤ():
    value = 948012
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji7ndGga6KQbIiyuzAK0Hx0Y0Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КХбυπΑЛывш():
    value = 638125
    text = __import__('base64').b64decode('emhuS01YWmxjdUd3WkFxQTFpcmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛцΕηΟЛΝΖηΚй():
    value = 341345
    text = __import__('base64').b64decode('WjdkOVZTa192WGxwakR0TmNham4=').decode('utf-8')
    total = value + len(text)
    return total

def _чθЦмΗКпДЕп():
    value = 667477
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn3BPwIa640nF1a6/XvEMnc9/D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 62 * 75 < 0:
        _dead_6502 = 964
    return total

def _ΡфΖюКжψγΗЗЖΥд():
    if False and True:
        678
    value = 407173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAncaUMcya0QaAzwmgWCOzwA238='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 9 * 92 < 0:
        pass
        pass
        656
    total = value + len(text)
    if 22 * 84 < 0:
        _dead_3961 = 979
        236
    return total

def _ΔΙΞЯшЭдЫκЬ():
    if 94 * 68 < 0:
        _dead_3055 = 39
        pass
    value = 462497
    if False and True:
        624
        _dead_5587 = 972
        362
    text = __import__('base64').b64decode('aG5Ndm9la2lXVEY2VTZ4ajZUSUE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5971 = 104
        pass
    return total

def _ΙкТηПπδΥЦЗΞ():
    value = 975254
    text = __import__('base64').b64decode('aFlCbnJudnhpNFZrbW1uUUJUc0k=').decode('utf-8')
    total = value + len(text)
    return total

def _эςβμΝωКуοуσ():
    value = 277647
    if 69 * 32 < 0:
        _dead_3210 = 354
        _dead_9137 = 751
        _dead_1129 = 579
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ez/wf2IawaQtbVyI/gOzZhJ2vF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5013 = 783
        pass
    return total

def _щΗсςΣФΧчδΗу():
    value = 463577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgXpfkMU6pAAaRyg432DMQs9yVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΟйьΤжьΦΞπυΛБФВ():
    value = 654758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBjsSVwU7qkrNwGH8XKEbHAh7VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 6 * 94 < 0:
        _dead_1502 = 219
    return total

def _ΛфτДуΖЯλΓ():
    if len('') > 0:
        463
        _dead_7247 = 853
    value = 389818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jyb8eWtuqYEJKyWTxGPFIQIg0Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΖвΟΤΗЧфрΝЭЛЩ():
    if 9 * 37 < 0:
        _dead_6034 = 770
        833
        17
    value = 823906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACzhd1ob0rEEH16F7GO9Ox1+1m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 55 * 42 < 0:
        pass
        pass
        324
    return total

def _λωъПБнтφоюЩА():
    if 33 * 9 < 0:
        398
        pass
        pass
    value = 151501
    if False and True:
        _dead_2535 = 838
        437
        _dead_7313 = 619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cz+0RQJhzqxVNB22+HiqBBYm9Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эьΣβщфγцбкΣΨД():
    if 55 * 67 < 0:
        989
        _dead_2835 = 987
    value = 755353
    text = __import__('base64').b64decode('elVteU5wV19hVnlEYWdPVUlPajI=').decode('utf-8')
    total = value + len(text)
    return total

def _цсΔщωπЙφεВ():
    value = 686166
    if len('') > 0:
        pass
        _dead_1831 = 444
        pass
    text = __import__('base64').b64decode('eHVXbXVQRFR4Ykl5N3NSOUVhaHc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        813
    return total

def _рУаΥσЭΩВΤшΒЯЩшФ():
    value = 880180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3f2NmMy6fkmCl2G+lWeDgcL4H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦщЕДРΨοЕσЙфдΝ():
    value = 908943
    text = __import__('base64').b64decode('ZUE5bHFiVVNjalpSbU5QQ05UMjg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЗλИβΥЮОСФд():
    value = 903665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB7uYHUtq44KMBiH0X+BbAYH5Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬоΝνНаЯχηΜЮЙΛЯсФ():
    if False and True:
        _dead_5684 = 493
    value = 777735
    text = __import__('base64').b64decode('VVp4elpYaWpEMGp5Z1Z2d0oya2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ιυдьвΣячХυΡμηζо():
    value = 510077
    text = __import__('base64').b64decode('dU1OY3plWWF1M3JINUtsYUFkY0I=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        174
    return total

def _нλρΛζбΡωбНΜ():
    value = 852822
    text = __import__('base64').b64decode('bjhLQlZLV3hKaUxqZFVyeTk5ZTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩщρΘпΞКοъ():
    value = 747366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mwa1UW5rqJ0ZNSKTwFmkMi0EwDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λйнЧлИзΒиЦΗУ():
    if False and True:
        pass
        _dead_6601 = 860
        pass
    value = 171762
    if 70 * 45 < 0:
        570
        _dead_4811 = 14
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyLjXUE8ypgraxfy0HynBjYIx1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 40 * 53 < 0:
        _dead_2022 = 774
        _dead_4614 = 535
    return total

def _οΔхΒыкиΔцЭθз():
    value = 554548
    text = __import__('base64').b64decode('Wk1xYmlOamZ3RzZJMWtmdlY0Tlg=').decode('utf-8')
    total = value + len(text)
    return total

def _ъЮОШшчΩрΤυοшφ():
    value = 441003
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DguzWFssraMzKzCEz0SZbSkY0kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДшξλФΕθШяАю():
    if 60 * 84 < 0:
        pass
        _dead_6458 = 429
        pass
    value = 859564
    if 38 * 33 < 0:
        _dead_9188 = 387
    text = __import__('base64').b64decode('ZDFhTlk5Y3NKb3UzNUxXNTFmWHo=').decode('utf-8')
    total = value + len(text)
    if 92 * 28 < 0:
        _dead_3008 = 159
    return total

def _ФτЙΚνхарΔςЪцжσЕь():
    value = 890679
    if 83 * 12 < 0:
        _dead_9290 = 779
    text = __import__('base64').b64decode('THlNaUpGQUpJa21sekZabEhFNHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟψОδоχбΑΜδψ():
    if len('') > 0:
        _dead_8115 = 557
        850
        pass
    value = 173827
    text = __import__('base64').b64decode('UlBVeXBsWFJ6bV83VW9qTmpXb1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜμАЭΔλЦВеЮλπЧΚ():
    value = 729847
    text = __import__('base64').b64decode('SjdnWlVOdUJDMDdYQkJwQ2lrRlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ικκВωДеЪΦпΠгΧЖ():
    if 44 * 73 < 0:
        _dead_4575 = 867
        pass
    value = 5617
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('dmVLbV94NktvQ0dMUENZMEI0YUg=').decode('utf-8')
    if False and True:
        _dead_3262 = 552
        737
    total = value + len(text)
    return total

def _мХЬΟοУаЙсΞ():
    if len('') > 0:
        39
    value = 321399
    text = __import__('base64').b64decode('dzk1UmlNRTd0RXdPU1NaZktUMFk=').decode('utf-8')
    total = value + len(text)
    return total

def _вηцΖхЙвЗτвБΣТг():
    value = 513839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAjeQVwhqYoZLSSXwQGWGXABwFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛοеуαХхиλфЦчъАΧΕ():
    value = 90681
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxDIeAEI+/oQbSqz7wS5Gi5/8Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οИМЫПφμъоьΔСКяп():
    value = 186806
    text = __import__('base64').b64decode('eGdnNVZOa2RlRlpTaHBRUjRQY18=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨКιΑеЩнМ():
    if False and True:
        pass
        _dead_3325 = 872
        pass
    value = 16609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAL0O1kMrf4iFgWt21eKCwk41WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞфβъфΜсΜΒ():
    value = 982083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQi3a2YhrrsTFVmT63vJOXw17FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗτБυιπъЭφςеНцм():
    value = 673253
    if len('') > 0:
        157
        _dead_7434 = 4
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mi7bZAdu8aUZNz2i4HKAGgodyjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лУθбБЫЪΟц():
    value = 624770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiC0Qlw85Iwzazv2zA+UECgB3WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЪΖцхχЧΔйСςγηЮ():
    if False and True:
        pass
        878
    value = 160914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhvtVElq8JAPLCCGzlOyZQ4dvFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цδХΔшΨНдшМΥ():
    value = 440825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pyn1bWsDzJo8aSCB61iGYDw+91o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6623 = 908
        _dead_3000 = 56
        66
    return total

def _цεΝКЬоΟрсЩЦса():
    value = 568911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwvVXQMjraMtAhmR8ESbZyoj8n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОюэрΧιφΞΓОΣяб():
    value = 723276
    text = __import__('base64').b64decode('b0NBY2hPV0JMWWt3SXdHdVB1dGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ωζΙΧθЭαцЩДг():
    value = 320954
    if len('') > 0:
        546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fy3JPwU08owaHxyE/3+bMnIN9Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        20
    return total

def _щшРχгζΣβеЮс():
    value = 22357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ngzidwcb1LwJDC25+Fu6MQktyVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДφМЩНжСиКвжЬΣбы():
    value = 967024
    text = __import__('base64').b64decode('UnBFdFZXWXgzWm50VUNiektDYkk=').decode('utf-8')
    total = value + len(text)
    return total

def _БЙыЙЗΩТбΕэω():
    if 73 * 72 < 0:
        165
        _dead_9888 = 977
    value = 417630
    text = __import__('base64').b64decode('aXN6WWU0R3lYY1IydE5Vb2FpOXA=').decode('utf-8')
    if len('') > 0:
        _dead_6688 = 864
        23
        pass
    total = value + len(text)
    return total

def _лмσЩΘκФЮ():
    value = 355279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj/GOHAQqK0yAhyy0n+lA3UG8ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2496 = 967
        395
    total = value + len(text)
    return total

def _щбЪЯЮФЗΙιΟфΦ():
    value = 865045
    text = __import__('base64').b64decode('ams5QXpWWVRueW04MVFMM3hUWFI=').decode('utf-8')
    if len('') > 0:
        _dead_7849 = 224
        151
    total = value + len(text)
    return total

def _ππмΖШκЛΤΝ():
    if 78 * 41 < 0:
        pass
        pass
        _dead_2946 = 518
    value = 11144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwnhaVI0p/8kKhac6lOYHH199n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7505 = 799
        pass
    total = value + len(text)
    return total

def _нАσьΞкЬж():
    value = 38475
    text = __import__('base64').b64decode('V3ZMY1JocTZJM0V2WG9XNHp0Nzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 11 * 26 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    _dead_7622 = 600