#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _хρМГгΧШЭрзЕН():
    if 3 * 7 < 0:
        589
    value = 47883
    text = __import__('base64').b64decode('dVdjYndzRXJxMURTOVhvZGFTeFg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        795
        630
    return total

def _ИьνэΝкΛтπ():
    if 53 * 63 < 0:
        _dead_9815 = 354
        697
        pass
    value = 820777
    text = __import__('base64').b64decode('SGpKYWJzTVJVOF9iZzFoN2VPTkE=').decode('utf-8')
    total = value + len(text)
    return total

def _τеВΕЫοξΡзΗеоλ():
    value = 71713
    text = __import__('base64').b64decode('V00wSVl0dzVvalN2SEdDVnZkZGM=').decode('utf-8')
    total = value + len(text)
    return total

def _умяЬνΔΤаъ():
    if False and True:
        pass
        pass
    value = 428544
    text = __import__('base64').b64decode('TnJBa3pJeEMxd0Y1bTV0WTA4eXA=').decode('utf-8')
    if False and True:
        734
    total = value + len(text)
    return total

def _ΥЗΦΚАΧЬПяΣΘΠ():
    value = 400265
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSfvflkV9ocpagmx43yoMnwn53Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔθΙАГΡНЧζΚ():
    if False and True:
        pass
        pass
    value = 479978
    text = __import__('base64').b64decode('U2FId0xFSmF1Z1hPbnZEN0wwMGE=').decode('utf-8')
    if len('') > 0:
        _dead_9482 = 556
        _dead_6133 = 577
        pass
    total = value + len(text)
    if 21 * 56 < 0:
        _dead_9649 = 287
        _dead_7991 = 27
    return total

def _СЙсшβщюъ():
    value = 457003
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSmzT3tg/4wGGCCN+HGXAAwY9EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЫξωРΛΙЭхΘТχЦчΠе():
    value = 57834
    text = __import__('base64').b64decode('ZGlfSGNVb1g2Z2ZjWVlGeGhvdHE=').decode('utf-8')
    total = value + len(text)
    if 46 * 76 < 0:
        pass
        _dead_1974 = 997
        pass
    return total

def _СщЖθΝКйэμЩЬνΝ():
    value = 831449
    if 81 * 77 < 0:
        210
    text = __import__('base64').b64decode('d0RvMW9LNEtzMDdFSWRHTkRJWlo=').decode('utf-8')
    if 28 * 19 < 0:
        833
        _dead_5659 = 591
        911
    total = value + len(text)
    return total

def _СщВΕψΠъЮЖяδЪЪт():
    value = 521462
    text = __import__('base64').b64decode('UDJDdk1lRUgxOXI0V3FYUnZ0dVE=').decode('utf-8')
    total = value + len(text)
    return total

def _βЫХАЛдΠУЕе():
    if 61 * 95 < 0:
        pass
    value = 286910
    if len('') > 0:
        210
    text = __import__('base64').b64decode('cVRJVTU1aUFERWFVcXo1X3lkU0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑυСТχΚνηнΨΑΡ():
    if False and True:
        pass
        _dead_3300 = 549
    value = 665088
    if len('') > 0:
        _dead_5699 = 636
    text = __import__('base64').b64decode('V1dxem5EN3VKSVBKcHRMTmNsNk8=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 92 * 17 < 0:
        352
        7
        pass
    return total

def _ЬωЮμъйягдйΝ():
    value = 625595
    text = __import__('base64').b64decode('a0NBRUJjT0FBZUN1cFVKc3V2cGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΗΣАЛΚοКΟПьЪΤδСσ():
    value = 569327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD/HT2UMqaAEHRmT+ECbDSAC8n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 10 * 4 < 0:
        pass
    return total

def _юфΣЧγλρОеОвΜ():
    value = 701399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CC7RaWkWqKkzHzrxm2enGA599jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 42 * 56 < 0:
        285
        _dead_1885 = 676
    return total

def _СЙΞфεЙζрЗΨχδю():
    value = 467592
    text = __import__('base64').b64decode('b1pEQTJJek9hbkFKWE5oWXZuQk4=').decode('utf-8')
    if len('') > 0:
        161
    total = value + len(text)
    return total

def _ΥсΙЛГОПХМХβп():
    if 91 * 8 < 0:
        522
        pass
    value = 205307
    if 88 * 48 < 0:
        _dead_6755 = 300
        255
    text = __import__('base64').b64decode('QjRySGJWU3FmRkRfZXljMUhWbng=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΩЧяσьΛоИμ():
    value = 39780
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx7HRlcWz5sVEyqu3GaKJCsu3G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΑИΖμΦΒоοΞα():
    value = 283675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTjHUQEqrPBaaACO7QepYjU6sGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙиεчνθрσэдφКЯω():
    if False and True:
        pass
    value = 457858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzvVQHcO1ooybQSGnm+pYg4E7Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΕЫАΟΟзЙэιнοΖд():
    value = 259311
    text = __import__('base64').b64decode('eUVPN3kxWjlUcGlZZnFCZDNyR1E=').decode('utf-8')
    total = value + len(text)
    return total

def _иыЗляΥЫζΑΙ():
    value = 145974
    if len('') > 0:
        941
    text = __import__('base64').b64decode('WnlZYkh3aHE4ZHBndDlpa3VBUnE=').decode('utf-8')
    total = value + len(text)
    return total

def _уЦσΦΜΒλжСУε():
    value = 421583
    text = __import__('base64').b64decode('QnV5WDlhSGFIR18wVEFLa01NeXA=').decode('utf-8')
    total = value + len(text)
    return total

def _вгэЛВΟςЧρσ():
    value = 126999
    text = __import__('base64').b64decode('anZ0OVhyTnBYS1ZhQXhmdjFSQkU=').decode('utf-8')
    total = value + len(text)
    return total

def _сиРАΟмбοь():
    value = 338800
    text = __import__('base64').b64decode('dEppN19xTlNmT3A4bzl3QlRVcFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΛΩИМΛΗяζзцΞЗдΚП():
    value = 706626
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax7cVlo+qv1WPS2V31OSNgkr8Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥЬΘААМуЪЫждНΗзΘ():
    if False and True:
        378
        pass
    value = 806044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBjXTFMq2L0SEgf76XqSZyA99Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8505 = 309
        355
    return total

def _нЮдзФВрΧΘ():
    value = 50110
    text = __import__('base64').b64decode('cE5zRW9aQ1JTejdYWWdScDZtVk0=').decode('utf-8')
    total = value + len(text)
    if 25 * 14 < 0:
        pass
        253
        pass
    return total

def _аδОМсЦфРЧΜт():
    value = 880990
    text = __import__('base64').b64decode('WGhhcjhyaEhzbjlpRnBmM0JtaHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓГеОЛΕьΨаСαцαυЕш():
    value = 532383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHnCXAcD1bEqYi2L7WeWED12528='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΑΘηПΛπюοтλ():
    value = 760992
    if False and True:
        65
        _dead_3875 = 301
    text = __import__('base64').b64decode('czFYTHd2V2RXTTlCcU04c1dhZmU=').decode('utf-8')
    total = value + len(text)
    return total

def _фКЯЪэΥРУФΩроСβы():
    if 84 * 32 < 0:
        pass
    value = 323648
    if False and True:
        757
        _dead_4132 = 896
        519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH78ZlUVzf8lbRn66n+UOggMs0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔЗрκΦΧтЯΨΕ():
    value = 732297
    text = __import__('base64').b64decode('UFpSakw1YXNTYzMyNmRKbjN5QkU=').decode('utf-8')
    total = value + len(text)
    if 100 * 33 < 0:
        _dead_9144 = 288
        _dead_4352 = 777
    return total

def _νβΩσхцηУΧΨБΙαβРн():
    value = 60543
    text = __import__('base64').b64decode('S3U5aGFFaDQ2OEtYbUdrUmFSbDY=').decode('utf-8')
    total = value + len(text)
    return total

def _аЗяАшΜΞμЪ():
    value = 150842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRjVPVkYrp8iDwyByg+vZiMq72g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υгиΝзЧШκωЦΓэΗσΞ():
    value = 490636
    if False and True:
        _dead_6815 = 951
        _dead_6363 = 40
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Igrle1Y93JgyGzuP92fJEyAF1no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЙΝΩЩχДжЙ():
    value = 44752
    text = __import__('base64').b64decode('TVFYQnlTMXpaWm5VTlo5T1BhMXA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_2604 = 600
        877
    return total

def _ΞцкΒвΝзуκжФи():
    value = 815919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cwj1OUkfzZ4KAlfxmnWaBnE2xmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔеθΘαΛгΨ():
    if False and True:
        _dead_5976 = 164
        pass
        _dead_3643 = 196
    value = 845730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzbFb2442rwZEyOb/XedBSwnsDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        664
    total = value + len(text)
    return total

def _ηЫгΓφπПъЕФβγΓЗ():
    value = 791342
    if False and True:
        307
        _dead_4715 = 156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCDoSlIu351bLjWL8HSfABc36EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПгαΟДЯнйλΦΠ():
    value = 580310
    text = __import__('base64').b64decode('Y0FvUVNZcWg1c2JkXzlSX1RTNlM=').decode('utf-8')
    if False and True:
        641
        pass
    total = value + len(text)
    return total

def _ицΣшЬΚξΨЦЕ():
    value = 486800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj/BWFJu+YdXKRWQn0TDEgsZsDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΣюкмЛКДЖкΛ():
    value = 603743
    if False and True:
        _dead_9506 = 748
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISCzWEk6168FLCC02GKkG3V2tnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦЛΓфΦВβπРτ():
    value = 976795
    text = __import__('base64').b64decode('amx0MVU5Tzh2Vk5PMDlvVWFPcmg=').decode('utf-8')
    if False and True:
        _dead_2729 = 120
        _dead_5392 = 419
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3493 = 907
        pass
        889
    return total

def _зхЭаυМцνЖНΘМп():
    value = 964664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgDrSnIA7owsHBr6/WSfJQ4V3kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        935
        pass
    return total

def _γΤмПяΦяιЖВ():
    value = 943628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh3SOAU/34kmHSmC91KHbRp823w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дцгΣοшГαΦεЪ():
    value = 624380
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lw6xPWAsx4JbIluI4QaHAQECz2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦпсьοηЮΙφрθЕЧ():
    value = 951252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EATndAFtyYomDSrw8Fi6BHMG9WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 47 < 0:
        627
    total = value + len(text)
    return total

def _зξнηΟοΗΓΜΓ():
    value = 374541
    text = __import__('base64').b64decode('UWpnTmZBdE4xTWlabU9fc2s4eHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖГМΞКГξΒυБαЦσΜыс():
    value = 49538
    text = __import__('base64').b64decode('WFJMSzJwMjNaQlhmaFd2U0NDN3k=').decode('utf-8')
    if 38 * 15 < 0:
        pass
    total = value + len(text)
    return total

def _ЩвΧЙинΔфлθЪуЧφβ():
    value = 795194
    text = __import__('base64').b64decode('eWJITVh1VnJFWDRxNW1vWmF6MnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ьРΩΨызлБДХζΜОξЮф():
    value = 749875
    text = __import__('base64').b64decode('QnFVZ1B4d2VuVEJiSVpUQzhvMTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜйξοМДΓΓгθщю():
    value = 562842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHjyQ18D5JgSAziH7Q+9DS4q6Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιфиγэЪСδГэъΩ():
    value = 875915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MATdd3UW57AhHDWTzUCSDi4WyEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шПΡЭησркпЛΒи():
    value = 138174
    text = __import__('base64').b64decode('ZzlxZjc1QjBGRDBCNzJVRmpwbU0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΕκГщΝчβΧХЛЬ():
    value = 457432
    text = __import__('base64').b64decode('Vmh5Z2w1Y2xsc25LUzFBTGtXVEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ηЩДтйъЖпыβΛ():
    if 61 * 92 < 0:
        pass
        _dead_6102 = 419
    value = 739119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzvDTQdvq59WMF22wVeGMHYL420='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οэιτЖξхφΒДП():
    value = 576596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KifhYHgo76Jab16m0H/DLT941mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΠйζДюοΝЦИχδΑΠ():
    value = 212924
    text = __import__('base64').b64decode('V3U4RDJOMDYzOEFWWmVQdE1zR1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ιЧоΤΗΞΖхч():
    if len('') > 0:
        _dead_8865 = 617
        _dead_2458 = 717
    value = 477766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH72Y0sPxPwALiKByW61HiwK20U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 55 * 18 < 0:
        pass
    total = value + len(text)
    return total

def _ηΣмνБиуζ():
    value = 627782
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnbQVHQJqokvIh+yzFKEISR85mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τмЭθΧГΜΕзЧσσБ():
    value = 183622
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESezfWcN5PFTIhak0VyfOnYK1mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5243 = 627
        pass
        765
    total = value + len(text)
    return total

def _ЫДφΝпэеΤсНΜυР():
    value = 834591
    text = __import__('base64').b64decode('QUtvMEw1TF8xVnl2MWJiaEdIcUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ζРμУутΣЕΕδ():
    value = 604985
    text = __import__('base64').b64decode('cEdqSElUX0ZVajV6RG1HSDNUMVY=').decode('utf-8')
    total = value + len(text)
    return total

def _γяκкФпΘДШδДцσΤα():
    value = 282241
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3fVPXRhr4wTMQmy51zBJwIbx0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оцΙюΠЯΠОμηс():
    value = 959028
    if len('') > 0:
        553
        pass
        863
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PST2emcR1LpXEV6y5mmyZRcuvGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        266
        783
    total = value + len(text)
    return total

def _ΚтΘЫθβζМюнΠ():
    value = 860735
    text = __import__('base64').b64decode('dFZ0ckc0eHgxVHdsV1I4aVVxRG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΔβДЬХутЗжЖтчσ():
    value = 237681
    if False and True:
        pass
        950
    text = __import__('base64').b64decode('b3VaeDl0VzA4RG5FWjd5S3c3U1M=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΤμΘсγНΣао():
    value = 589202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ciz3WUY/9KETOyOO/wCVNzAq8kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кЩЭИйНХЯΟ():
    value = 726783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwfqPHAQ9I9Sazyo7Fy/YHw6wH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οхψэζΘчАл():
    value = 958438
    text = __import__('base64').b64decode('blRXcTdxNEVCa0pmTzIxQ1BSWE4=').decode('utf-8')
    total = value + len(text)
    return total

def _σΣςЩбцггκρωΖΝ():
    value = 35490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAe3eVwI7qIXPSCL0F+cHSJ/wFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        498
        pass
        pass
    return total

def _жюуТъΓΛιΡъπ():
    if len('') > 0:
        pass
        _dead_9311 = 127
    value = 988626
    if 27 * 35 < 0:
        _dead_7466 = 66
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh21QWZp/ZoHLSKUx1S1NjUV4Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΑЙΒζЩЖуγйχдцθя():
    value = 422955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3/wYH4trLsxDh2v2F6DGC8B6zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 32 * 96 < 0:
        pass
        981
        18
    return total

def _ζΑтЬдиНъИюЧнзмΗ():
    value = 93513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAjHQ0YP8PA3Exqm0ALGEnwB60k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΓЦΥбΤХφт():
    value = 758123
    text = __import__('base64').b64decode('bzRZMHhGQVNnZEI4NFljMl9xSlE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑδРпБэπкКйОπΛρδЗ():
    if False and True:
        _dead_6265 = 856
        pass
        pass
    value = 965385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iim2QnoQ3Iwmblqa51O8Ghwazmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        578
    return total

def _КδБмΧлСжΘСΤφеψ():
    value = 174366
    text = __import__('base64').b64decode('Z1RRQTZnTXpGSWhySDFMakZ5NUM=').decode('utf-8')
    total = value + len(text)
    if 70 * 42 < 0:
        _dead_7968 = 981
    return total

def _χΩХюνΟνЙцθβΨйоκ():
    if False and True:
        _dead_6655 = 157
        pass
    value = 752465
    if 84 * 77 < 0:
        100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg3sVHNh3JwPIgSSxlmnIxED7Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЛсηλбХΦρρΠргтτΑ():
    value = 814555
    if len('') > 0:
        754
    text = __import__('base64').b64decode('WEE5dl9pQndpS1pfdVpfazAyRWs=').decode('utf-8')
    if len('') > 0:
        pass
        98
    total = value + len(text)
    return total

def _юеЕбВЛВщЧΓПΛΗеМЦ():
    value = 838187
    text = __import__('base64').b64decode('UHR5ejhFa0JoR2ZjZ1ZGaWxmNXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖлσψεвηΔ():
    value = 427820
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwPbfmQgzpwgbwOC8mavLjYgsEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эпфΕαДЩЬМП():
    value = 192548
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgztTEgB1b4hOTmPnnvCMSY2vF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣχКОДИΜΧъΩΚνдΝ():
    value = 995875
    text = __import__('base64').b64decode('Q1BEQlVuWnRJX0RnaGdPOXlodW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨεПозМЙηΖйΕαЪшб():
    value = 403812
    if 13 * 3 < 0:
        _dead_4044 = 624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExbsR2AW3/5REDepmmfFMnwN4zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧмΜсΨπщРΖΧйЫΤ():
    value = 357669
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCLJa0swq4siMwW2mACnDRoN7UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΩθεΖОЮоΥφн():
    value = 354336
    text = __import__('base64').b64decode('c2xHNTFTbWw0cVl6el80NzNXSXc=').decode('utf-8')
    if False and True:
        739
        _dead_7649 = 376
        133
    total = value + len(text)
    return total

def _иΨζΕΟξШωηНжφΨΝ():
    value = 759216
    if False and True:
        pass
        906
        _dead_3049 = 645
    text = __import__('base64').b64decode('RlJ1VnVGd2ZJODhmRkpwbWRSZ0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕοэΓΘжιцсЙΘΑЖ():
    value = 167637
    text = __import__('base64').b64decode('aHZ0UGxxSnZLMmpQTDlCRVJmUlg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮфυΥБЛЩδАщθΓЮЪЖ():
    value = 455989
    text = __import__('base64').b64decode('ejJfa294VURjSU5qU09aUGp2MWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ОяезΤЮпЧКБΗΩρ():
    value = 991889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSzgOVcb+pEObA2M8G/CAjAf6EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οзМΛτЕйΗμб():
    value = 618513
    text = __import__('base64').b64decode('YmRZWHV3MlFyUWhPb2RLX3c5MzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ыхΔАБрщоδΕР():
    value = 490528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQrzN1YP9YQBKzCqz1qUYTUMwzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИчТжΝЗΗдιаεуς():
    value = 202933
    text = __import__('base64').b64decode('YklRZl9MOXJ5QWh4S0xqSk1nUjI=').decode('utf-8')
    total = value + len(text)
    return total

def _фВΒζЩХфΘдλРЯЗм():
    value = 111298
    text = __import__('base64').b64decode('WG5XcXFwbl9Hem81RVVKc0tKNzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΡУБбЬЧхσЛιΗЙ():
    if 59 * 81 < 0:
        585
        pass
    value = 930812
    if False and True:
        _dead_7208 = 643
        56
        _dead_1232 = 344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSHoSXIp7/Fbbzit3F2zHxo+90k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        479
        _dead_1770 = 330
        772
    total = value + len(text)
    if False and True:
        pass
    return total

def _πςчθНДΧЙ():
    if False and True:
        _dead_5881 = 778
        pass
        383
    value = 493497
    text = __import__('base64').b64decode('blFSbEVnSHJydVpvT1NIM0pmeXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖψηТΦюγШνх():
    value = 768604
    text = __import__('base64').b64decode('YU9QeXlTd2IyU3haSTdIdG1Jakg=').decode('utf-8')
    total = value + len(text)
    return total

def _чαУЦвΙΕτΩяδЪВΡΧэ():
    value = 387258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgbuTGZg8Y0NDjn3mEWlEREi6z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θШЙдшсΝЧкγΙτ():
    value = 381513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH7hWHkL1qoVbhiN/F/CDhAN/nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МθнφΕлтПс():
    value = 450941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXz1RV8Dq4o1Ph+nmky6MyEttV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФЦτβΛκχφсБяψωχΗΞ():
    value = 941160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQDdeAARzr4FMw737XfFGi4LxU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙλΥЭОлючъςζХΕ():
    value = 740322
    text = __import__('base64').b64decode('amxTN2ZtWlM4TkxXNVpSd2FDQ2M=').decode('utf-8')
    total = value + len(text)
    if 49 * 20 < 0:
        _dead_7690 = 663
    return total

def _ΦйщвκхрΙОжх():
    value = 723323
    text = __import__('base64').b64decode('cVhnMVBQRGtSM294OW5zR0FOQmo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞζоГΦЖГкωςλш():
    value = 745788
    text = __import__('base64').b64decode('WXd2V244enlNQ3NuSWsxYk9JdDk=').decode('utf-8')
    total = value + len(text)
    return total

def _вуЖμΟΗъЖμт():
    value = 674647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FybqfFw6+bEpHDb73kyoAi0G7Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤБЩαлλΘЪщθ():
    value = 693166
    text = __import__('base64').b64decode('Qm5qdjRZNjVyd2NGMDFGVWIzTW4=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_7799 = 116
    total = value + len(text)
    if 58 * 65 < 0:
        pass
    return total

def _зκψммрвΣΡнμжΖоρ():
    value = 996530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHb9PAEoyoU8CTyZ/m+yJD1+8z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МωьюηΘσЧΞЦ():
    value = 421182
    if 24 * 84 < 0:
        374
        948
    text = __import__('base64').b64decode('bkUzR0xFQWUxRGJWUjhSV2hVV3E=').decode('utf-8')
    total = value + len(text)
    return total

def _еЧЫЯПΧиΦА():
    value = 532253
    text = __import__('base64').b64decode('ZllqNHdMNFpOWTVwTlZ4TFViQUc=').decode('utf-8')
    total = value + len(text)
    if 67 * 74 < 0:
        pass
        _dead_3952 = 399
    return total

def _чэсЯБххуыЬчЕσыДг():
    value = 113194
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQGzOWEgxLgFHBz673+HJy419kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μщЖζыπИэΔТμΔу():
    if len('') > 0:
        133
        70
    value = 752422
    if 41 * 38 < 0:
        517
    text = __import__('base64').b64decode('eXBBXzNxYmVRMmoySHVtamh2ZHo=').decode('utf-8')
    if 4 * 90 < 0:
        _dead_2671 = 454
        795
    total = value + len(text)
    return total

def _ЙвоΖЧцЕΘрΠ():
    value = 219373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iy7mOlIe151SNQm1/kHGOg0I43Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АηΞЯщБсдСщС():
    if len('') > 0:
        _dead_2220 = 216
        pass
    value = 563845
    if False and True:
        68
        _dead_2051 = 544
        _dead_1491 = 336
    text = __import__('base64').b64decode('YkRSZUxObzFhZHh0VEVmcXZLdl8=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЦхΥЮкзΒйуΔБδξΗс():
    value = 681800
    text = __import__('base64').b64decode('TlptX0F3Z25CUWY0NUZwVHV3Znc=').decode('utf-8')
    if len('') > 0:
        _dead_8358 = 481
    total = value + len(text)
    if 45 * 69 < 0:
        _dead_5842 = 319
        _dead_9345 = 57
        _dead_5710 = 535
    return total

def _φΖЦилβБρΦ():
    value = 722001
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAzvVkgV2fw3DRb02QeDOBAu6Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΘΘζπτιаΖВΙшХΣ():
    value = 836022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxnJV0Iu1qkPYyqJ5g+ZGD0s5UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АвДΖвνΨн():
    value = 147157
    if False and True:
        _dead_3678 = 128
        pass
        _dead_7260 = 44
    text = __import__('base64').b64decode('enl3U3E2UmVJSnA2RUNYVTR2ako=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4875 = 847
    total = value + len(text)
    return total

def _ΙДчтРμЭΞ():
    value = 988180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTzXYWlt8LwSEA2pnVTHPhoCzWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЯΩЗλхПЗцфζοбΛΒШ():
    value = 996051
    text = __import__('base64').b64decode('djN6TXI3aGpQb21sZE1Ed3ZCZWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ОυψэΓхρΣРΦδве():
    value = 141946
    text = __import__('base64').b64decode('ZTdybFdldnV5Mlo0cXgyQUhIbnE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ΗЖЪηЗΜйИПΨΝгφυω():
    if False and True:
        _dead_7894 = 13
        _dead_2646 = 855
        888
    value = 924459
    if len('') > 0:
        617
        _dead_7787 = 721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzjHaEEt3P41NyS5m320PyILyXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        28
        pass
    return total

def _эИφрΠгΡбΘЛ():
    value = 106663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQT8O3Yw1aMPLTfxy1C7DhV77l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦςмηΒΖЮУ():
    value = 700958
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbTXWYA8psSLj2U43uVAR977H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣδЫνюΛΤΟЯЮщνфюς():
    value = 623434
    text = __import__('base64').b64decode('WGRsVjBCUl9Hb1Z3WmxmTXVZUTk=').decode('utf-8')
    if len('') > 0:
        _dead_3173 = 441
        pass
        475
    total = value + len(text)
    return total

def _ЛθющюΤФΙх():
    value = 608564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAzjQHM107sBYjf70QOvHg8jtlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СКφтчΜНюРγ():
    value = 43169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh63Z2YU5IZaDTf3wWWnOiAD1lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭρМςыηЬΑμЪγФюВ():
    value = 195247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3rgXlk39asxbAOgxXCBPggGyUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШτюΧλАшΓьΡΨΦыΠ():
    value = 932578
    text = __import__('base64').b64decode('clQ1TWdmTll0Y2V3SlZWTjRBaE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ГеэЮэчυэШαяАθЬ():
    value = 563049
    text = __import__('base64').b64decode('ZllpaWc3T1ZvUTFydDZudDVpZTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЮοИутζΑЛмΧЫΙЗΦγ():
    value = 387093
    text = __import__('base64').b64decode('V3hocnFhZmhaZkJNNVAxVENzU2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚαсΔЮзСτЦχМΖΛ():
    if 50 * 29 < 0:
        pass
        378
        488
    value = 749328
    if len('') > 0:
        _dead_2728 = 16
    text = __import__('base64').b64decode('SGhHZkw3RUJSVW5wbkNKQkZza3A=').decode('utf-8')
    total = value + len(text)
    return total

def _цΠщрХХψγУЯωещΚ():
    value = 784481
    text = __import__('base64').b64decode('aGk2andJTHg0SE5rbEUwTWR5MHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ρаαЖΠЧГγ():
    if len('') > 0:
        360
        934
        976
    value = 791525
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('UllHS3p1U2FPWk5ndnBiYWt2eTM=').decode('utf-8')
    total = value + len(text)
    if 15 * 12 < 0:
        pass
        789
    return total

def _ЙΒнΝЦвыφΣ():
    if len('') > 0:
        pass
    value = 43682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag72UUEgyf0UAgm27E62DRY49Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χБпРηΧйИφοМШδнзе():
    value = 48609
    text = __import__('base64').b64decode('RmgyUWhzVXIwUF9pb0ZhNlJIa2Q=').decode('utf-8')
    if 51 * 14 < 0:
        397
        _dead_8754 = 832
    total = value + len(text)
    return total

def _ΓрлЯзбλΕχШугπъ():
    value = 410752
    text = __import__('base64').b64decode('dGFROTRGY0UyQ1ZsVkh0cDBFRDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ОРРδςрДЪКЪрьЩ():
    value = 373384
    text = __import__('base64').b64decode('a1k5NlpWYk1EWXdnZjR1OV9ScTg=').decode('utf-8')
    total = value + len(text)
    return total

def _МΔХΙГиГуЧδбΚ():
    value = 260948
    text = __import__('base64').b64decode('WXI5Tkl0NlBKdHR6NzJRVjA4S0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬυеΠΞьбΗГΦьΜЖ():
    value = 286367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgvHOWQ/prgiBSKV5VXCOjwr0j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΨδξНвΙюэΣвκЦ():
    if False and True:
        _dead_5100 = 483
    value = 578938
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARa1fV4YxoYoHje56w67F3Z/5UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γμφςκΜΞц():
    value = 119602
    text = __import__('base64').b64decode('a1hSeUk3VWxLWE85SHc4MmNzcWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗιΘδАфтй():
    value = 481338
    text = __import__('base64').b64decode('S0toYm5nbXdGTW9aaXh1bFEzbnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ХилъдЕЬθ():
    value = 184069
    if len('') > 0:
        _dead_9050 = 164
        _dead_4552 = 995
        _dead_6324 = 601
    text = __import__('base64').b64decode('cnhCTmFqXzJnTGp3dkFscEZ0eng=').decode('utf-8')
    if len('') > 0:
        pass
        592
    total = value + len(text)
    return total

def _μбьЛφЕςΒфΩΣζДχДψ():
    value = 235790
    if False and True:
        pass
        _dead_6915 = 479
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBXVXH4Y+qUqaRec73ihOiEgt2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςБкхκАЕуХюсΜ():
    value = 175689
    text = __import__('base64').b64decode('VkJGSUp0RkpTRnozSzdDcGdKRWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙщЭΒΖдτΑΣЯδБεΟ():
    if False and True:
        pass
        894
        _dead_4730 = 879
    value = 490714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH7cT2czq5FTajuE737GCykW8Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 60 * 17 < 0:
        _dead_4812 = 957
        252
        _dead_2962 = 919
    return total

def _зкЛЯцζτюΡъΖτюΖгξ():
    value = 521294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgL+REFh8ZkJbAD38XySNw579Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        341
        _dead_8632 = 184
    return total

def _хψσыΚфнщςμмξЙУ():
    value = 7507
    text = __import__('base64').b64decode('UkMzbU1vRzRHZDVKbjVYMVl5cG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΣαΓкЭΤЙВжΓЖΧΧг():
    value = 959698
    text = __import__('base64').b64decode('ekM5VWVscVhyUHJwaDBaQzVPQ1c=').decode('utf-8')
    total = value + len(text)
    return total

def _бНШΚиΙРРπрУηм():
    value = 165134
    text = __import__('base64').b64decode('RnEyZERldHE3clhoemlwalZBTjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        848
        _dead_9999 = 347
        _dead_2827 = 485
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xx') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 78 * 63 < 0:
    _dead_6339 = 901
    191