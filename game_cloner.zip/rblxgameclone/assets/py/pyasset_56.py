#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ьΔМшэьНЗБС():
    value = 137040
    if 38 * 8 < 0:
        pass
        _dead_6020 = 53
    text = __import__('base64').b64decode('Z19oZ0pONHZVeWtjbVRkazRxekw=').decode('utf-8')
    if 8 * 15 < 0:
        pass
    total = value + len(text)
    return total

def _ФонγМΗΧьΩ():
    value = 456312
    text = __import__('base64').b64decode('TGNqUlQ4c2w1QXFvcHlTQnBFdkM=').decode('utf-8')
    total = value + len(text)
    return total

def _зρеРйΕпΧЛΑЫκΖкйτ():
    if len('') > 0:
        _dead_7152 = 22
    value = 936712
    text = __import__('base64').b64decode('Ukg3dzRWQnloQmhSaU5jNGNfSUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮжйβечсХςοωΔпэ():
    value = 8642
    text = __import__('base64').b64decode('cWtUUUFScDBfUmQwenJfX0l1ZmY=').decode('utf-8')
    if 60 * 8 < 0:
        415
        26
        894
    total = value + len(text)
    return total

def _хОΙфΣψψь():
    value = 622983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByvXQVgb8KoVCBmm426mHnYN7jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СФΖФηΣеуθΤωгЫΓОь():
    value = 829438
    if False and True:
        _dead_6343 = 585
    text = __import__('base64').b64decode('YkZKZGR5UFh0YVAwelFtOVpkWmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ьюΘеΕщνΞМΗαЪλ():
    value = 425589
    if 94 * 9 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En/iWlghy5AtA1uCnX6RYiF300s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        540
    return total

def _щηψΘπФθЕуЪсШΨ():
    if False and True:
        pass
    value = 790654
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3q2SkIp2aJUBTC592+dMCk45W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 9 * 44 < 0:
        928
        pass
    total = value + len(text)
    return total

def _КйьςΦεтЭЭ():
    value = 493280
    text = __import__('base64').b64decode('YWNmOUljZ3diQjdHRXhGb214NFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ДЬΨвδΤγФβоАнτЯρБ():
    value = 562701
    if len('') > 0:
        _dead_8505 = 963
        42
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzrLXmAxrLALODCCxXmoZwQW1zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФςΓφλТъйбмμКΡЩΒн():
    value = 78748
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQDVWwke9q8bGFaa8g6kPRcE8W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3527 = 625
        _dead_9518 = 144
    return total

def _УΖфΜЩξьФΔЦЪ():
    value = 345697
    if False and True:
        pass
        _dead_4590 = 97
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgPnelxq86QvECq23lDINRUl/HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖЫтЫΠΤδкНъΘΕΚУ():
    value = 311793
    if 30 * 92 < 0:
        _dead_7556 = 674
        _dead_4630 = 744
        352
    text = __import__('base64').b64decode('d3NfUXZTMUkzaHV1OFBvQnhtOXM=').decode('utf-8')
    if len('') > 0:
        _dead_7905 = 38
        pass
    total = value + len(text)
    if 43 * 70 < 0:
        pass
        pass
        558
    return total

def _πφяΘкΗΤβΨ():
    value = 962808
    text = __import__('base64').b64decode('WHNUbVVoSjhWVDhLR0hyNDYzQTA=').decode('utf-8')
    if 62 * 24 < 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_6406 = 971
    return total

def _нАЖΜпЯчЗθΘΟци():
    if False and True:
        pass
        pass
    value = 444695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzvCd3Iq0b0CODiW93+YYRx2wF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        227
        pass
    total = value + len(text)
    return total

def _ΙχΒоφμΙвввνо():
    value = 965502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgqzOwE95q0JCwuXzHOhLTUO4F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3204 = 366
        pass
    total = value + len(text)
    if 99 * 31 < 0:
        866
        578
    return total

def _дφжΞхиΠпΩЪ():
    value = 975762
    if 40 * 42 < 0:
        621
        pass
        763
    text = __import__('base64').b64decode('dUdyemxCWHZKWXVjUEV0QWx0R3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩγΒдаеЖьΝнЫЙусшΔ():
    value = 480696
    text = __import__('base64').b64decode('bmphclk4VDFucExsNEljRVZEdVk=').decode('utf-8')
    total = value + len(text)
    return total

def _κУЭΨИφγΝ():
    value = 271743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHzHVkAsxvwNMR2N2U6WNjw7zzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιΞκζпΧΑцωμΒеΕΘф():
    if False and True:
        636
        _dead_2968 = 444
    value = 377892
    text = __import__('base64').b64decode('aUhFU3BZYmVhRzlKQmZsTXZ4OHA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2646 = 226
        670
    return total

def _ьφТΖΧЦθΡЪфΓ():
    value = 575067
    text = __import__('base64').b64decode('UlFob1NIWHBPSXZTRWtDZ282eW0=').decode('utf-8')
    if False and True:
        _dead_7360 = 376
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_6834 = 210
        _dead_3408 = 15
        522
    return total

def _нτΗβτЭНΗΥиλΔсα():
    if False and True:
        pass
        484
        pass
    value = 913331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX/cRXof/YwbHQiM+HzGNRAk610='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        452
        _dead_1185 = 626
    total = value + len(text)
    return total

def _ысКУНωйθ():
    value = 888907
    text = __import__('base64').b64decode('Ym1IdzlCUVhtUXh5YjNXRjVCUlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙτΑζыЗЮμοΑоυП():
    value = 396047
    text = __import__('base64').b64decode('dm9VcWFMdUdjRHZZTjVXcWlacXI=').decode('utf-8')
    total = value + len(text)
    return total

def _аЮцΜЖМΥаьυз():
    if False and True:
        _dead_3989 = 362
        _dead_4533 = 796
        422
    value = 282936
    text = __import__('base64').b64decode('aHFWRTVPWUVRaWFLWWVTMlVQTDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭодБΑδПθцζ():
    value = 908008
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCfLbHIe7b1VPT+Q4mPDOQwnz2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩχαШОИЙИЛП():
    value = 153823
    text = __import__('base64').b64decode('dXZDaUZwZGNmUTB5eFZERmNBWUs=').decode('utf-8')
    total = value + len(text)
    return total

def _υФςэжБЩБы():
    value = 719279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB7cY2kW2p5bIwOP+kSnOBY91zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤиηΩЙΘчгяеъΥ():
    value = 386498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwLSXl0/8aBQEwOM7W6UHxc6ylQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωρнπΞбΦОЪ():
    value = 513675
    text = __import__('base64').b64decode('SlQ0NkxOdHFOVVU2Uzk1YWlTS3A=').decode('utf-8')
    total = value + len(text)
    return total

def _вфФлδАειΥΥыбТ():
    value = 126987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSnwa3c+971UKViQwU6VP3F/9Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫρΧоγЯЭЪйГρЙ():
    value = 254127
    text = __import__('base64').b64decode('dDRMYkx3YXY3TktPR2tkX2RoNXU=').decode('utf-8')
    total = value + len(text)
    return total

def _дОΕиγзхΛжМ():
    value = 685473
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('UWVYUmNYb0lraTlfUXM1S1BXTzE=').decode('utf-8')
    if len('') > 0:
        _dead_9760 = 368
        _dead_9495 = 634
        pass
    total = value + len(text)
    return total

def _ΣяΨбιВΜТΓΧΣγщХ():
    value = 994644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQr9UQMs5K0HNCKWwkaqLQIt6zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΧОΥεΟмрЪΕЕцιХТ():
    value = 540248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBjbSwgG7aMIPhiRnGW6Iw4L/mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χСΤιЭЪЙλ():
    value = 220902
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAX3dmQP9KEHCDCJ8V6UOX03tGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сНеФщЯΒрФмφазΔ():
    value = 297485
    text = __import__('base64').b64decode('ejRNMjRnMmF1NHdsbkJWcGxlRnE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        201
    return total

def _ЙΛωшЕΓΖиюτКοЙзΓЙ():
    value = 107784
    text = __import__('base64').b64decode('Y29MM0pIYnpEV203TlBORkwxNHo=').decode('utf-8')
    if 72 * 26 < 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _АΥВГгФΚφфβΥВΝ():
    value = 127796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwbCZgJt64xTLRah7XidGx8gvTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АрЮΞΚъФЕщΦΗыДΒ():
    value = 969586
    if False and True:
        pass
        _dead_8283 = 335
    text = __import__('base64').b64decode('TzNBWm1QZHV3Y2hGVzh2bUFtbFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ъОЖΤзрΩζοΜНТпβЯ():
    value = 597634
    text = __import__('base64').b64decode('dXhQZGJoYlpySURndU93anVsdUQ=').decode('utf-8')
    if False and True:
        559
    total = value + len(text)
    return total

def _φкмОΟμυφζэЫиаЖ():
    if False and True:
        pass
        607
        _dead_4208 = 14
    value = 269653
    if False and True:
        pass
        pass
        _dead_8279 = 340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBbAY2gD8vg0KQCLzAKiBhw6010='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 74 * 89 < 0:
        848
        pass
        pass
    return total

def _ВнΚΩвсλнцЦ():
    value = 750488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BArISUsh2fs0Hx6B6nW7ZQsVzX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζсΖйЕХВрЧΧию():
    value = 756655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzbMTVYgyI0EHBmb/2O8Gyw30zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        46
        pass
    total = value + len(text)
    return total

def _вωИυАΓΓфΣ():
    if False and True:
        _dead_1815 = 332
    value = 832607
    text = __import__('base64').b64decode('R2V6Q0xxQThvVm02WHFPbzlmNXI=').decode('utf-8')
    total = value + len(text)
    return total

def _РΑзОδΣвСбЭλД():
    value = 20354
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDfRVF4O66cMYxaT/QaFI3AO72k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩмПчΦΩхБлΜλФΑУφΗ():
    value = 727850
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSzsS3UrxKUCHAeP8E6UEggltGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΕΨЗшβιцγρГφЙ():
    value = 834302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nguwe3xv65A1LiOT6gSdZCE7730='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8893 = 398
        _dead_5083 = 254
        pass
    total = value + len(text)
    if 65 * 20 < 0:
        pass
        335
    return total

def _сРΕсΡΤьФГаЕχЭ():
    if False and True:
        pass
        819
    value = 301940
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwjQSXwu+vAzMluK20TBGhMmx0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3488 = 394
        312
    total = value + len(text)
    if 23 * 15 < 0:
        pass
        51
    return total

def _ιиГрΞυРΡΝцьдιΛпψ():
    value = 628293
    if 11 * 71 < 0:
        951
        164
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E33SX2g806A8AjilnAOCFw4hvGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дГπΗэРΗπτцД():
    value = 625472
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BivqSwg9zpFXESiRyW6mOykDtVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ярΚвАТЙзТοШч():
    if 51 * 3 < 0:
        491
        _dead_8593 = 269
        _dead_2716 = 355
    value = 487198
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC3NSQYb2o0wHTm6yVPBBik40mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΖоЪθνидΡНЙИгУΛ():
    value = 897097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHnCaUgO6Y80Hj+00k6zZhUesGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 85 * 21 < 0:
        pass
    return total

def _γкυρψьзΖЬЗ():
    value = 653411
    if 17 * 13 < 0:
        563
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwPgdH02q4UiADmvyk+qJxd+4lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 59 * 44 < 0:
        702
        pass
        844
    total = value + len(text)
    if 45 * 8 < 0:
        pass
        _dead_4106 = 944
        pass
    return total

def _иГπΜΣΥРйРФΣσφч():
    value = 557379
    text = __import__('base64').b64decode('dDBfa0w1RTltZk44R2xkUFVZRWU=').decode('utf-8')
    total = value + len(text)
    return total

def _юΝΦЙрΩυΜЮсΟΚλо():
    value = 718385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyHyVmNg1P8mNQSNy0XFNRYm/Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        926
    return total

def _υЛдъβщχΠκзФΥ():
    value = 6759
    text = __import__('base64').b64decode('QUMwZlpGN1Fndkh1NFM0SmdVZ18=').decode('utf-8')
    total = value + len(text)
    return total

def _эξИЮЫχρчЬαЕЮщ():
    value = 887557
    if False and True:
        728
        _dead_9561 = 692
    text = __import__('base64').b64decode('Q2kzVkFGU2wxc3dRRmNHWTJMMjg=').decode('utf-8')
    total = value + len(text)
    return total

def _цттуЖΞюοЭжΚΡь():
    value = 419747
    text = __import__('base64').b64decode('dUFFZG10YVh5VFRVbl9GeHlMOUI=').decode('utf-8')
    total = value + len(text)
    return total

def _АЭηсШΜΓΧ():
    value = 234594
    if False and True:
        _dead_9460 = 542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTXFTAAa15ohNTCI60SvC3QC9W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖнгжΦОИν():
    value = 790283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXnofUI1+ZERagm67HyTMg0q7ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μщΠσнлΟΧяшμ():
    value = 491976
    text = __import__('base64').b64decode('WW01NjZMUGtMdHF3QmVhNzFqOEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘαΓΓφъΦТΠцβПбζβΗ():
    value = 622678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRfGWwQD2LIzHFyU4WmXHDAu8U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞНЬΡфГψКΑβцЙЕЗй():
    value = 81792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj7gRgAbxLgRaxaUwgeJLAQ/y1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гγΜГяСφΑппξЮ():
    value = 885203
    if len('') > 0:
        973
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwvifkEQ5rEZMwKwy3SgACs+tUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ымбЧэРРПсЮЫΣхНмη():
    value = 175203
    text = __import__('base64').b64decode('ck9SdVZqa2RvSW1WU2h1MlVsaG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘγРεΚμТДчШ():
    value = 483317
    if len('') > 0:
        _dead_2969 = 173
        pass
    text = __import__('base64').b64decode('Q1hJOEdPREk1dnNLRzQ1a0x6N2g=').decode('utf-8')
    total = value + len(text)
    return total

def _πζκФξοъЮгΟН():
    value = 172427
    if False and True:
        _dead_8520 = 356
    text = __import__('base64').b64decode('d015em5LSVVMV0k2WDdYWk9tNms=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3786 = 305
        647
        109
    return total

def _эГξΘыеВΥΥВβΤΔ():
    value = 642923
    text = __import__('base64').b64decode('RW5YcWcyVjRYZXdQN1hBMWN6dDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩщЛеЕΧΚНβ():
    value = 521713
    if len('') > 0:
        _dead_7490 = 887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQjxXmkI6f0qEhmJ6nGqHRY//X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3012 = 551
        _dead_6609 = 283
        pass
    total = value + len(text)
    return total

def _ЬЙΕъЕжЫгЫбг():
    value = 441672
    if len('') > 0:
        _dead_7218 = 680
        _dead_2321 = 763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Czf8eUQ8ypsSLCGF7X6HH3Mt9Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 28 * 21 < 0:
        _dead_2297 = 898
        238
        pass
    return total

def _ΧπЦЬаэьуηΓШт():
    value = 839979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRjFf2Ys9IslAiy25QapFQYJ3F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7214 = 16
        pass
    return total

def _щΙгπΙЖиοΨвП():
    if 43 * 36 < 0:
        _dead_9296 = 44
    value = 807495
    if False and True:
        101
        pass
        421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3nqXnY2/4o2PF2c90OGPQY7/Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 42 * 83 < 0:
        _dead_5582 = 41
        _dead_9548 = 855
    return total

def _вπеТσρεΑΞυЫΗОЖ():
    if False and True:
        pass
        _dead_1911 = 764
    value = 329396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxizXgdp/5o1Ly6BkATIJyd66ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3318 = 184
        _dead_3375 = 978
    total = value + len(text)
    return total

def _ИлХФбэыкθЪЛφςнГЧ():
    value = 171351
    text = __import__('base64').b64decode('d0ZtYlJtQlJFV3lVMzF2d0tPeVQ=').decode('utf-8')
    if False and True:
        _dead_7342 = 155
        _dead_7434 = 225
    total = value + len(text)
    if False and True:
        660
        937
    return total

def _РЗρξЙЙΠΗъЖΨξиуЧЯ():
    value = 214190
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3nqXwRp2K0lOCqV60GHEwgh1Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βящΖрЫтςЯξΔΥ():
    value = 154271
    text = __import__('base64').b64decode('Q0NtekU2RHhfY05iYnRNM1BISnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖУΨγНчеζθЦΧа():
    value = 187424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3zIRHkSyrkGbTuCynmIFRI8tkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6660 = 731
        pass
        _dead_1403 = 347
    total = value + len(text)
    if len('') > 0:
        _dead_6674 = 504
        431
        632
    return total

def _πтΦкταΖлγХ():
    value = 367375
    if len('') > 0:
        _dead_1466 = 640
    text = __import__('base64').b64decode('RGZKeGxyN1FVQ0pLRWxzMG1yTG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЪиγЮРπβΧОХцК():
    if 87 * 93 < 0:
        pass
    value = 113804
    text = __import__('base64').b64decode('azc2Q2lUSFpKTUphYzFUcGxfYk4=').decode('utf-8')
    total = value + len(text)
    return total

def _дщΔνТπθЧΛ():
    value = 155884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhD3e2IJ65AtHCj3nE6iZj0D4Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΙЭафШХοэπвмЖ():
    if len('') > 0:
        _dead_6333 = 387
    value = 674998
    if False and True:
        pass
        _dead_2515 = 334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAbyawQR06YpBRiM3k6eGw4HyFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2460 = 674
        879
    return total

def _θτξЩсЪьΜ():
    value = 862240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA7VOUcO1IoiNi2py2azM3MHsWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        956
    return total

def _ΛГЯΚьМъΠПιзωμγЬθ():
    value = 701787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAbWRVMV36MuLVmN4luKGDQJxU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6467 = 520
    return total

def _ГρΛКПΤυβΡμК():
    value = 755504
    text = __import__('base64').b64decode('T2NtdFRNSk1zYTNka3h5cjUzeFk=').decode('utf-8')
    if 5 * 24 < 0:
        pass
        392
        _dead_7046 = 382
    total = value + len(text)
    if 81 * 42 < 0:
        pass
    return total

def _пΟξΤΙИЯππэΖКЧ():
    value = 468962
    if False and True:
        25
        684
    text = __import__('base64').b64decode('ajhYbGFZbE01WjZlUXdVXzZmUVU=').decode('utf-8')
    if 74 * 93 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _рЖеЭльМЭζ():
    value = 491820
    if len('') > 0:
        pass
        _dead_8305 = 3
        91
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDbeQVIuy6cUOxmX8ge3PwYuyHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПχΨΣΞЛбсГнθэ():
    value = 365857
    text = __import__('base64').b64decode('TFFBVFE4Ujl4RkUyYUp1elNhWUI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ГеяΣχιаΠκνлΙЦПеΣ():
    value = 719738
    text = __import__('base64').b64decode('T09CTWR5b0M0bzFfeklJb1RUWVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙνнΛΚМΙлмΟμГλΟП():
    value = 119337
    text = __import__('base64').b64decode('bFFDaHFkT3ZTRmtYaWl4Q09VTFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΔχнΔОςДχ():
    value = 590353
    text = __import__('base64').b64decode('cjlWSzBtRFZqOHlGRVV1S1ZzTHY=').decode('utf-8')
    total = value + len(text)
    return total

def _εаАсеФТЭπСфюдημ():
    value = 814202
    if len('') > 0:
        527
        _dead_3859 = 823
        pass
    text = __import__('base64').b64decode('Wmdfbk94bGc4SF9rSTBHajIxcmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦμБГφитιЗςΥο():
    value = 330520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxX1XXU49f4lbiWJ6UWcE3Afx0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΑχцъΠьУσ():
    value = 401783
    text = __import__('base64').b64decode('VE1zYU9xSDJ5QVlTa3RsU1pxM0U=').decode('utf-8')
    total = value + len(text)
    return total

def _Ψσщυуζьб():
    value = 982753
    text = __import__('base64').b64decode('SzRkdHdneXVuTHFId0xKTlMwNWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡεσшмвТΩτНлПы():
    value = 602247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnbXWG4orPhVPQ32/nO6O3QEvXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΤΚУХЭНюе():
    value = 814746
    text = __import__('base64').b64decode('U0hZcU05a0ZTaEVjd1RtM3NONG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΜοЪЩкοЕ():
    value = 897910
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD7ld2ltxKYPAiWu+361NyoDyD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛСζχэЫдψп():
    value = 703466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgLOZQM+1Jg2YwGL3Gy9B3MV4z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΖφΟмЧйяχГЮяψСя():
    value = 143057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCO1S2Azz44PbgSO5X+CABx7z2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СεцРΣПИВз():
    value = 949088
    if False and True:
        533
        _dead_4842 = 907
        _dead_5188 = 18
    text = __import__('base64').b64decode('TExqUzBQT01RSnpZc0pTMUFhM3U=').decode('utf-8')
    total = value + len(text)
    return total

def _νХЙСлπΨЖχмΕв():
    value = 625117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICDdZVUwyZgObQutzUe2JhY43Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еФЫбАΑγу():
    if 53 * 90 < 0:
        _dead_9729 = 276
    value = 463273
    if False and True:
        160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQjTY1sj+JgSbgecxUKkHj0FwEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3685 = 512
        pass
    return total

def _бшΔмρΜоΒ():
    value = 902879
    text = __import__('base64').b64decode('U05LUDhmbUtfbUJWVWxoenBsQ3I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5268 = 697
    return total

def _ΧΩфаΟμЦщπΩε():
    value = 722952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX7mOHY08pIQEheRyUGDbCsg1zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΙуфΚхжДэ():
    if 95 * 68 < 0:
        pass
        pass
    value = 204500
    if False and True:
        196
        883
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyzKRlka6o9aMwL062eEDiJ70EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 70 < 0:
        878
        pass
    total = value + len(text)
    return total

def _бαхΔЛδΨΧψ():
    value = 772171
    text = __import__('base64').b64decode('TzBtU0RkajJPRHhyUDA1Y3B6NGY=').decode('utf-8')
    total = value + len(text)
    return total

def _АΓЦπТМТШΧслЫГΥ():
    value = 741726
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyfWfFhvx6ECPFmr6U6zJikKwzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХЦΧЫНφφЛфΟ():
    value = 465871
    text = __import__('base64').b64decode('aXh0TEFsT3RJa1dkczBxcVEyWGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪнΔαКэΟΞьВШмЖФы():
    value = 500049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSS3fEkPxp4sKh+m/3eEHCd5zH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 74 < 0:
        pass
    total = value + len(text)
    return total

def _ЙΓРЮчжЦЪξрИКΚΜιЖ():
    value = 782768
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzzVbHI30okmaSLw4kPGIi9+xU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЪЯхуЫΩαУΦУΛС():
    value = 782655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyL3RnYIzYwINSSF8AWIHXN3zlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 41 * 87 < 0:
        pass
    total = value + len(text)
    return total

def _ΓйΛΥвбЪз():
    value = 700480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwjJZG5p2PEICBiz/FyxPXx68TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 58 < 0:
        610
    total = value + len(text)
    return total

def _ОЗσСδεгфρбЖΞкοЫ():
    value = 296213
    text = __import__('base64').b64decode('bkhQcGw2blZSOENlckFFaWVKNkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ξЖМμУΜΣΩОычсЯΛ():
    value = 263057
    if len('') > 0:
        pass
        _dead_3014 = 64
        pass
    text = __import__('base64').b64decode('QUZ0bDc4TWFuR3l6NXFQbVB0SnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛдтΓЬГщЧйξψщΛ():
    value = 952360
    text = __import__('base64').b64decode('TkxiS3FYXzhUc3NpMUVjV2E5eGk=').decode('utf-8')
    total = value + len(text)
    return total

def _цЭσβэςλц():
    value = 594887
    text = __import__('base64').b64decode('UWl3d1dzdHNqdXZWNllnNm05OHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧСΞψящнЮпχЯ():
    value = 778453
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('ZDVxSTNqUVpkaGcyV3JhUzU5cGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥрψбОсзАЦдСПыЬ():
    value = 522699
    if len('') > 0:
        322
        823
        _dead_2059 = 403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyLrS3Jt+ZkzOBmi5GKEOx8Z6DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 43 * 99 < 0:
        _dead_4753 = 519
    total = value + len(text)
    return total

def _МБλΦоκЪаξΝлΔ():
    if 75 * 90 < 0:
        _dead_2309 = 295
    value = 795493
    text = __import__('base64').b64decode('bjhmOWJfNWJpUzlKMXVSTURBSEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗЕУΚБыУπσπы():
    if False and True:
        pass
        _dead_1879 = 499
        _dead_4347 = 39
    value = 763858
    if len('') > 0:
        _dead_8463 = 778
        _dead_6504 = 942
        _dead_9932 = 702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyjzYEYD7p02Hjj27gS4bA4Bzms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        633
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _γπКгΙзйсюμο():
    value = 230652
    text = __import__('base64').b64decode('Q04yU1NrcVZEYnE5MTFnUTZtQjc=').decode('utf-8')
    if False and True:
        pass
        _dead_3714 = 987
        _dead_6635 = 794
    total = value + len(text)
    return total

def _вгВОнсШшгΥ():
    value = 135480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgzuW14096QvBQyp8l3JBXUi7D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 96 * 63 < 0:
        pass
        _dead_6482 = 466
    total = value + len(text)
    return total

def _ΦθЬХИеХΝιςΑУпΕдΜ():
    value = 861141
    text = __import__('base64').b64decode('Z0Q5NHFRcXpHY3c3X1JxdVZxaHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯвВСΔΜАюгТГρнилГ():
    value = 585190
    text = __import__('base64').b64decode('SW9DN045QkxrRl9NY1JmWFZOQV8=').decode('utf-8')
    total = value + len(text)
    return total

def _НСЮοΙвНцгΣτπч():
    value = 825200
    text = __import__('base64').b64decode('ZnJodXBnWTNxRWJ2QTB6MVZGS1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΣτцΤΞλНяа():
    value = 294245
    text = __import__('base64').b64decode('WEtEZWpCWDBqekJyVjFzSzFXSVc=').decode('utf-8')
    if 42 * 78 < 0:
        _dead_7145 = 458
        pass
        pass
    total = value + len(text)
    if 72 * 32 < 0:
        _dead_4697 = 844
        248
    return total

def _ПεФΧΩиΡΦыыМΓЛη():
    value = 131541
    text = __import__('base64').b64decode('WnlvOVdxV21fT2tfS05QWGlVUnc=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _τпλΕгΧμиΩΘ():
    if 48 * 40 < 0:
        476
        669
        969
    value = 532464
    text = __import__('base64').b64decode('TUQycU1KbFRvOFU2ang0X1g1a0U=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_6586 = 932
        371
    return total

def _ΞφоШЖвΨπτδш():
    if False and True:
        428
        _dead_1675 = 274
        pass
    value = 922177
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTXbV31tzaNXPAj1mEa3N3wb8kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 13 * 95 < 0:
        504
    return total

def _ΛΟΒιуСьНΔЮадφΝ():
    if False and True:
        _dead_2474 = 915
    value = 734387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSXjaVcX+f4wAhu14W+qJg0O5Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        9
        _dead_1026 = 211
    total = value + len(text)
    return total

def _ЪкΞъВжμЗφχЙΚ():
    value = 883585
    text = __import__('base64').b64decode('dDdPbGxueHlHZENJZVJyYzRUREM=').decode('utf-8')
    total = value + len(text)
    return total

def _вΒκπФиςю():
    if len('') > 0:
        655
        653
        pass
    value = 513123
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('UGlhTDhTSWhUeWhPZTF3dGpYRUc=').decode('utf-8')
    total = value + len(text)
    return total

def _УΧΑΗДζΙυΒДη():
    value = 930603
    if 32 * 87 < 0:
        _dead_8555 = 855
    text = __import__('base64').b64decode('TzFHY3V2UmwySWJ0d2VVWHVSRkg=').decode('utf-8')
    if False and True:
        _dead_2019 = 673
        pass
    total = value + len(text)
    return total

def _ОΔνюΛΤΡПю():
    value = 476371
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy3bZ0Y0y4c8H1nw8lfEIRMEzGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΜΡчΑυτηДмκ():
    value = 529823
    text = __import__('base64').b64decode('b1JjeXBNTkIydENfMjVsRGFhWDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞμкεθΔχпЭΝкА():
    value = 662120
    text = __import__('base64').b64decode('Z3YxR0JZWTRDVlJNVDY4S3RNOVM=').decode('utf-8')
    if len('') > 0:
        71
        _dead_8101 = 566
    total = value + len(text)
    return total

def _ЬΚдЙцσЗΒТА():
    if False and True:
        172
    value = 952412
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTyyXgca2LgkCzWAxU+nIQkD82E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _γХΒрБцоЪпΧХγΖΛ():
    if False and True:
        _dead_7795 = 16
        219
        585
    value = 511029
    text = __import__('base64').b64decode('b002VkxaaExSWUQ0S1dGdVh3Z3M=').decode('utf-8')
    if False and True:
        pass
        _dead_2774 = 654
    total = value + len(text)
    return total

def _хζτζκΩμЙΔэзΔЧμΠΔ():
    value = 822211
    if len('') > 0:
        788
        pass
        _dead_4025 = 176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAnnZAQK+I8lCjCv/kCeYDMq42U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шбЛσςчгΣотΙΤΖЗРю():
    value = 551961
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3e1ewY03PBXDRu552y4YC54vWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2985 = 160
        _dead_9195 = 478
    return total

def _ξΤШΟюΛИАгтΟГНЗ():
    value = 665107
    text = __import__('base64').b64decode('dVZMTGZHVERwcFJzOUNyY1JWSWM=').decode('utf-8')
    total = value + len(text)
    return total

def _оυΨПДЭШΚδЖЙпОЧиυ():
    value = 451237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHjPbUA17aE3HVubmHC3IhQY0Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МκътαΩОяЧυЪΨч():
    if False and True:
        271
    value = 114251
    if len('') > 0:
        pass
        _dead_5771 = 541
        pass
    text = __import__('base64').b64decode('T2lyQXRPWnJyWDNJSnZCcDRVb24=').decode('utf-8')
    total = value + len(text)
    return total

def _укАΛЯГΨГ():
    value = 704758
    if 54 * 86 < 0:
        pass
    text = __import__('base64').b64decode('eEc1T29wanVtTG9VRmpwSFdJY0E=').decode('utf-8')
    if 87 * 5 < 0:
        486
    total = value + len(text)
    if len('') > 0:
        _dead_2671 = 382
        _dead_4432 = 347
        _dead_3859 = 444
    return total

def _ГθΡΒрΟφγΔЩΖ():
    value = 621158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3v3SAMIrowxIgSLmQSVYHQfx2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λАпгΗоРбжεчσВч():
    value = 43654
    if False and True:
        732
        560
        _dead_1792 = 750
    text = __import__('base64').b64decode('UU80U1pNeGgzWTg5NjVEZnRfcjI=').decode('utf-8')
    total = value + len(text)
    return total

def _яЧοеЕξΩпΦφМПωъП():
    if False and True:
        _dead_6268 = 509
        _dead_8602 = 237
    value = 953389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnjtOUBtqPsFbl6wwVKhPysr5Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χмЗΒМνщАθνξμ():
    value = 34568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3bjUV9q+/oBOxapm1yhExEl614='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 13 < 0:
        pass
        531
    total = value + len(text)
    return total

def _ЙςΩξуъΠГΟΑΠβθΛο():
    value = 971818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABjHOnYD3ZoyNzqu/VWfIwEozU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖЯΚΨъТПχъАЦщ():
    value = 822407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzqzeQU11IwmNBmsz3+7Oj82tV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УшЪХЙτΞα():
    value = 523605
    text = __import__('base64').b64decode('eklEaDg1N21lZ3JLVFl1SGhhTFA=').decode('utf-8')
    if False and True:
        pass
        741
    total = value + len(text)
    if False and True:
        _dead_5214 = 546
        _dead_4116 = 197
    return total

def _ινξΛЧлρχχЯгΖлσ():
    if False and True:
        _dead_9108 = 791
        pass
        _dead_8095 = 555
    value = 96043
    if len('') > 0:
        pass
        934
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgrJR1wD7qogAluw0nSIHgYI02Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДВΔδйαΝоβй():
    value = 927375
    if 25 * 13 < 0:
        770
    text = __import__('base64').b64decode('b0d2NGp4TkJ4a0F5SzBxWWtvSEc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_2126 = 496
    return total

def _аμЩеηоηиοЙЗфМг():
    value = 60911
    text = __import__('base64').b64decode('UnFuT1prRU11Qms3TnFBOHRwZzc=').decode('utf-8')
    total = value + len(text)
    return total

def _υеΖδЭηеэΕερυ():
    value = 806332
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ES3cW3YM6qYVCSGH512TFgkpylE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νзΔПШτюяΤкопац():
    value = 804468
    text = __import__('base64').b64decode('eVdpejNQaWtmTnpha2IwOVVxRWw=').decode('utf-8')
    total = value + len(text)
    return total

def _уψУИьЫθшЛдιΟ():
    value = 306463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESbxPmcS76saKzqt7waECzYZzUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟрΣυΦЕНΠЛυΠιО():
    value = 836571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSDybQhtqpEPIzy2+GLFNnE6614='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΖфσЦаОсΙлμΗογЛП():
    value = 992244
    text = __import__('base64').b64decode('UWJLMmNLMzhGWWZxa1lrdjZSUXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝхλГГАвμЩРыφΓ():
    value = 839521
    text = __import__('base64').b64decode('U0lLQmUyMjVHTmxGZzNTNktGZG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛШΔΙдилθГцЫиαΜжδ():
    value = 901549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSXKWX0U7b4EMgi75gC0GQIYwFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИцΓβвζНμΜОΕулрφθ():
    value = 765559
    text = __import__('base64').b64decode('YkFFS2VvUU5TazdfNDF0Y1hzX2w=').decode('utf-8')
    total = value + len(text)
    return total

def _юялрπЖМГЩШНΩУΞяи():
    value = 296530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByDIfnsV0rslOFiQ21GvIHQF4Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΣЙРΚЪМТτχТθθСИ():
    value = 150726
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARzvVG4IzKpWEwSC5w6cExcF3Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        758
    total = value + len(text)
    return total

def _σфΜжθΚИЭЯΘдτξЮ():
    if False and True:
        928
        742
        _dead_7882 = 758
    value = 309863
    text = __import__('base64').b64decode('VExEUUlEamdhWHRRc180YkpUTkw=').decode('utf-8')
    if 67 * 19 < 0:
        901
        pass
        12
    total = value + len(text)
    return total

def _ΘΡцъЬКηφΓИΟрκ():
    value = 186924
    if False and True:
        _dead_3155 = 789
    text = __import__('base64').b64decode('WGZzZDFJbUl4YVZpemtPWm53WEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩθωЧаеЭЧ():
    value = 475175
    text = __import__('base64').b64decode('YmtZdm8xOWRCT3Rva2FsYW9QNzE=').decode('utf-8')
    if 1 * 30 < 0:
        _dead_4470 = 908
        pass
    total = value + len(text)
    return total

def _ЧчвΑААщψЖκэо():
    value = 62944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDv1RUQT+a0NLAmM3ge9OQEWsVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5614 = 971
    return total

def _λЬкшФζэтς():
    value = 172362
    text = __import__('base64').b64decode('ektmZFBjejhRNWt3eVBWbmFxQ3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if False and True:
        _dead_7682 = 831
        pass
        213
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxxx') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 57 * 54 < 0:
    505
    884