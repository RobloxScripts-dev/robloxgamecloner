#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _эκΠьΑюэыШ():
    value = 928955
    text = __import__('base64').b64decode('dTdpT3FtRUlPc1JMX2tTOFZEbmY=').decode('utf-8')
    if False and True:
        _dead_5263 = 54
        34
    total = value + len(text)
    return total

def _ШхкΛПδзнх():
    value = 281443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB7iSkIGyoowIyi1512RDREYsEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΖзθνβθыКΛΗО():
    value = 487529
    text = __import__('base64').b64decode('TDZBTDJfczBTQVRYdnBkNGJIbWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЩΖθΞЮΨΕГκΖИΘхξ():
    value = 424392
    if 47 * 16 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT31eXo/9aoxFFeI73GyAQJ812Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СβюεнΑΕηχξψχΧζη():
    value = 86338
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBvFY10aqvk3ER705VKnEAwezFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пдъξНΒχъΔлΠΦЬλΒП():
    value = 307752
    if 53 * 79 < 0:
        pass
        _dead_9484 = 706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PX3pdlgRzIE1NDCazXW8HwsB3mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХссбΦПΣΗС():
    value = 829170
    text = __import__('base64').b64decode('QUozOU94SWlJRHdXSXhKc19NTEg=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_2320 = 424
    total = value + len(text)
    return total

def _ЫηΧΑσΔδΗФΠВ():
    value = 791985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx2zUXwr97AEKwiZ+33JAjUCy0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΜьλАшΥξЭАΥМφ():
    value = 414959
    text = __import__('base64').b64decode('a2d0NHVBUDZiVEE2eWtRVUJSdlE=').decode('utf-8')
    if False and True:
        _dead_9335 = 672
        _dead_4147 = 63
    total = value + len(text)
    return total

def _иЛуОъГябΗοΕ():
    value = 796375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSXtT1we7LEGFzy3+FC2A3wh7U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        334
    total = value + len(text)
    return total

def _тςШШБΗΦнеЯΔдΨЗ():
    value = 332023
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBqzS3wQ+YYuOSj15QaRYzB793k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φзДΓтТШвР():
    value = 148247
    text = __import__('base64').b64decode('RF90aGh6cm5RWVJGOTRnVGxIZms=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЯγλЛχΟдмаβЫХыЧ():
    value = 343940
    if False and True:
        pass
        49
    text = __import__('base64').b64decode('UnI1WWF0VWFZek9hOGkzUlRZVTI=').decode('utf-8')
    total = value + len(text)
    return total

def _БУΥΜбшЧХΕλ():
    value = 342651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nja8dn1q15BWDFmAyVO5YHV3t1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        757
    total = value + len(text)
    return total

def _ЫЧΘνθзФΝоцЭΘЛ():
    value = 957731
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjnHRHMB2/pSEgGo22eyGS4mvV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 30 * 3 < 0:
        pass
        _dead_5667 = 488
    return total

def _ΗβИгэтΙХгΟз():
    value = 671508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH7gSABv8LgwMiyvxl6iIRAuzGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓяГΨщΥеКς():
    value = 70887
    if len('') > 0:
        313
        944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh/HR2UN96IZLAON/HHCLDYWxWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЦщзрξΟчΟφЕШβδ():
    value = 884397
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXzQXQZv855QFiGkmAaFPQY47XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΒΒЪτΞХФΣЬт():
    value = 833488
    text = __import__('base64').b64decode('aG9rZUJuX0tZUW5vQlVkQWZlRG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘщпΧдΧвΔκЙΒΙνэг():
    value = 722066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3zwaXIpzphbMQO1+kemJBx2yl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΘоΚΓЮуςтг():
    value = 930519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExDWZ3cA8KQVAhir8VC7LRUFsGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЫκΓρξМэеΘ():
    value = 924822
    if len('') > 0:
        559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MADMXn4Y3/ELNAX1zkO2Lh895Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΦвязВЛмббнρЛΚ():
    value = 493125
    text = __import__('base64').b64decode('Q3poYzliTGl6bnJUWWhXYWRuMWM=').decode('utf-8')
    total = value + len(text)
    return total

def _МΥеΔиχМеΒΔ():
    if len('') > 0:
        _dead_4039 = 23
    value = 603112
    text = __import__('base64').b64decode('eWh6VDE0OEpmTDZuUTBaUEhSVmo=').decode('utf-8')
    total = value + len(text)
    if 55 * 78 < 0:
        pass
        pass
        pass
    return total

def _тΑЬдγЗοЫΙШ():
    if False and True:
        532
        612
        _dead_4583 = 155
    value = 722522
    text = __import__('base64').b64decode('c0xoRzlhVGVEVGhmdTBCMUdPb28=').decode('utf-8')
    total = value + len(text)
    return total

def _СΜПршюИИ():
    if len('') > 0:
        _dead_9262 = 213
    value = 435774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3rQZHMq67AzDFal2FezZXQ50mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 58 < 0:
        129
        725
        _dead_5455 = 231
    total = value + len(text)
    if 73 * 83 < 0:
        480
        207
    return total

def _πνΠИЮГсПΨδзΤГβ():
    value = 388046
    text = __import__('base64').b64decode('YjVIMmxNSDJBMEFycG9rTE5fMG0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        539
    return total

def _νξΖαΗтΔΟΞЗсПΦых():
    value = 937151
    if 13 * 73 < 0:
        931
        _dead_7724 = 277
        _dead_5986 = 698
    text = __import__('base64').b64decode('b2VoYkxCcVpyeDJacWRTMElxQW0=').decode('utf-8')
    if len('') > 0:
        818
        _dead_4892 = 487
        241
    total = value + len(text)
    return total

def _ΖλχЪфРлβΨвα():
    value = 616420
    text = __import__('base64').b64decode('dm5zZ1dCa3NLaURaX1JZbHoxbEU=').decode('utf-8')
    if len('') > 0:
        668
    total = value + len(text)
    if len('') > 0:
        _dead_2147 = 940
        _dead_4373 = 86
    return total

def _пνΘΨДШЛΓэзкУ():
    value = 771884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQ3Ve1s1/fEzbwKU3EGJJRcYvFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 35 * 26 < 0:
        _dead_5930 = 514
        pass
        pass
    return total

def _ΧПιΣΔζμсШΥЦζΑυкτ():
    value = 65616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DimxSwAz05sXF1ehyQSHHTItymY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 10 * 1 < 0:
        192
    return total

def _йыаЮТЯхИкΨПЛΠΩ():
    value = 716539
    text = __import__('base64').b64decode('dU1DSjVGMjRnMkJOYXhSVEE2dHk=').decode('utf-8')
    total = value + len(text)
    return total

def _зΗψςяψρрхΗзχтмС():
    if 7 * 6 < 0:
        158
    value = 338092
    text = __import__('base64').b64decode('ZVhFbHBWNGZFRHlPT0xETDZ6RlA=').decode('utf-8')
    total = value + len(text)
    return total

def _щяяйЖтшЭ():
    value = 970578
    if False and True:
        995
        728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx/XNgU30p1bbgaP+w6oMjMZ9ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝθпккЭτЪκμΣΠΕь():
    value = 696762
    if False and True:
        _dead_9640 = 267
        561
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHvobVsxqKo7ABuOz1icGDEW53g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΩΘυΙΠюφЙζ():
    value = 688645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NinXTQMLzI8SCzaqxlqyJAwDs08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟЦДχЖςаЭΒΠХкΥξПЖ():
    value = 18240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR7SbXko2pIsblaI3lydYi48sj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χщыμΚβСμ():
    value = 946810
    text = __import__('base64').b64decode('YXAwSjVPQVB4MW9qdXNaVUl6aGM=').decode('utf-8')
    total = value + len(text)
    return total

def _сΙΖωΔгλфΗцηιωЭοΙ():
    value = 946944
    text = __import__('base64').b64decode('TVNqN0c0alYwWnZwSHlZTFhKdE0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_9810 = 163
    return total

def _еЦЗэγΙδρЩЪ():
    if False and True:
        _dead_8268 = 541
    value = 7577
    if 96 * 67 < 0:
        292
        pass
        pass
    text = __import__('base64').b64decode('cGl3V1doV0J1cWJ6N0w3QjM2S2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ξηΚВРбκιΘΒХд():
    value = 585265
    if False and True:
        318
        374
        _dead_4352 = 586
    text = __import__('base64').b64decode('amlFaW1Wc3dURTJhQkRlSnJnOGY=').decode('utf-8')
    total = value + len(text)
    return total

def _оыΗжзЗцΑωЛбТьпсч():
    value = 847343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnrrXwEu5qQwKluM5wWEJiN4z2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШζΝκфζΥΣζИСбиЦ():
    value = 187328
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISHpQUMu/4cJHyGEkWKjAD0F8Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γωΙΧπгЫрΘЩДΑ():
    value = 589149
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHnmP1k/5K4xaiOL/HClOCk672c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 90 * 4 < 0:
        pass
    return total

def _рΝПχвЫЬτЖΧλΧФЫΩШ():
    value = 590981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwPdYWEo74IQGyyK23ujYSEZ9Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _маЪшΘΚηш():
    value = 429621
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwniQ3wW358hEwKc3UWjJgwc9T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θυрСδФΜΕЬб():
    value = 412708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgDMaEUj7ZwECgn36w6DOCsOvTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПкМΞΧЫжтοχЧη():
    value = 771104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxrmPWAj0IUbDViR31XEFyR55WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пСΟξΜεθымΘЕШ():
    if 67 * 55 < 0:
        904
        pass
    value = 517804
    if False and True:
        710
        pass
    text = __import__('base64').b64decode('cWl3UW9WbW04SG1yRUJjaTlFMDg=').decode('utf-8')
    if len('') > 0:
        761
        pass
        pass
    total = value + len(text)
    return total

def _йΩμчОλεЧΤщ():
    value = 77603
    text = __import__('base64').b64decode('Q3JqM3g2a3J0Y0Y0eE1wdzBVWnc=').decode('utf-8')
    if len('') > 0:
        _dead_6922 = 394
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΒшЕΦβужΞШДщкЕ():
    value = 227104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDnvQkAW+J8KOzD630zEPhUC7Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 39 * 17 < 0:
        298
        pass
        _dead_1132 = 596
    return total

def _ωΠЯυΟΜνмΕαЯЪБρΥ():
    value = 176315
    text = __import__('base64').b64decode('Y1ZtRUZJd19nYkZsZExLODNIcm4=').decode('utf-8')
    total = value + len(text)
    if 10 * 42 < 0:
        pass
        pass
        _dead_4027 = 297
    return total

def _ΟΘδΗмоΝИщ():
    value = 820403
    text = __import__('base64').b64decode('bXN3eExWUGNYeVhjTEVBTmo1NWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧсΦΑйκΟκЬ():
    value = 619336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KST2OWQyx5xRHgO26QO7LSB9sVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 56 < 0:
        _dead_9145 = 688
    total = value + len(text)
    return total

def _ЬнжэмцΙцАζ():
    value = 837039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3mwXEdo3KIvEDyl63GRHgwQwlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        841
    return total

def _УβмλΑЦΕЯЛУуΝРщБх():
    value = 297808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSzHYHcT8/8VDAya3WOpC3I46Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НπРкАщχγμΖ():
    value = 199281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCXAUX803akrFx+J3F2pMAst3Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΞπхμяДδΧΘК():
    value = 464494
    if False and True:
        600
        747
    text = __import__('base64').b64decode('SWdTd1RzRGdXcjZaenhxZFRxakI=').decode('utf-8')
    if False and True:
        190
        621
        577
    total = value + len(text)
    return total

def _ωηНсйδчфπΑ():
    if len('') > 0:
        _dead_9475 = 504
    value = 942954
    text = __import__('base64').b64decode('eFdUdFBRbGRubF8zRlRVUEFYd04=').decode('utf-8')
    total = value + len(text)
    if False and True:
        354
    return total

def _ЗьХкЖЧюъνвцνΨЭ():
    value = 309956
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAPdNkNpwb8hLFii3wXFYAgq0Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9023 = 686
    return total

def _ЪЖясΖιцΨАГРο():
    if 34 * 58 < 0:
        pass
        _dead_2815 = 984
    value = 869950
    if False and True:
        725
        845
        264
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC3MRXph96YQaw20+WeZDR0e9XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        64
    return total

def _χхηОΘΧδКЫ():
    value = 144254
    if 42 * 10 < 0:
        pass
    text = __import__('base64').b64decode('UFZUY2E2UmZZZEJxTDVKdGRfUTg=').decode('utf-8')
    if False and True:
        529
        pass
        _dead_5946 = 427
    total = value + len(text)
    return total

def _ΨйЪЛМЦЧЕΖфа():
    value = 856319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnnBSwRt0Z8oFz6S7wO1DHZ/5WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нЦйГζςСΗψΗπ():
    value = 750961
    text = __import__('base64').b64decode('SFF2SUd3aXJZcFBIQXVIa2tLcDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ъхгнвνЩЛвЦμ():
    value = 642457
    if len('') > 0:
        _dead_4183 = 2
    text = __import__('base64').b64decode('ak5od2h1bTNlbWxVbXhOdlllTTQ=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        591
    total = value + len(text)
    return total

def _рΝΑЧωАяηъшλιЫшС():
    value = 880895
    text = __import__('base64').b64decode('bFFRRkFZVGJ2X1dHd2p4NGQ1UEY=').decode('utf-8')
    total = value + len(text)
    return total

def _вюэΕЧκСиεЖΚο():
    value = 386672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mxq3VgUY86c1Eg7z2VSlYjEl21g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔνЫЖΝψξπψ():
    value = 338760
    if len('') > 0:
        888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISjSXGUuyI4NbwSU4FuIMjE5tGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цИиΣаэψюгзΑ():
    value = 36386
    text = __import__('base64').b64decode('amZGYlM0X2JRcUpvMkczdW1aWWs=').decode('utf-8')
    total = value + len(text)
    return total

def _АΓТлτАсьйεΟЩυНчΘ():
    value = 563790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhrMT1Yb+7wqGRqR8GmnJSgo9j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪсхАЖаЖЫВИ():
    value = 134056
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSXwO30J/JI3Izvw71TEFygK9Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧХΦΕαЖГΟ():
    value = 987474
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAL8YUIr0pErNAOzy2S/GwEd7Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΣПνλъъГЦсьбъЬ():
    if len('') > 0:
        pass
    value = 408090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jx/uP0Y634EqMSq6m3+/YjR7xlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ΠЕΡΧΘτΛапЗи():
    value = 117198
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHfpOwUc9oQqDiGEyVegMHMN40g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΝЮЮαоΩДΘο():
    value = 980888
    if 47 * 27 < 0:
        321
        _dead_7539 = 416
    text = __import__('base64').b64decode('blJXelBpVWp3WTR2cnYyS0Z5Ung=').decode('utf-8')
    total = value + len(text)
    if 54 * 64 < 0:
        pass
    return total

def _γХΣясбиеθШКΞΜнд():
    value = 337106
    text = __import__('base64').b64decode('ZEdEc1BUMHFJZ2toR05Xamd6ZHk=').decode('utf-8')
    if 2 * 53 < 0:
        175
        pass
    total = value + len(text)
    return total

def _ΕΟαΔΣμрЕчαλауι():
    value = 613944
    text = __import__('base64').b64decode('c0dDcWo3X3RNcjU4SXc0UVNOcFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟУИηИΔΛΙуνЙНΤл():
    value = 924634
    if 28 * 59 < 0:
        pass
        _dead_2849 = 186
    text = __import__('base64').b64decode('TW1WUGF6Wk95VmJ3TVNfME5sZEI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        264
    return total

def _эюЮοΘΨПЗСИГЕЖπρ():
    if 69 * 73 < 0:
        pass
    value = 768009
    if 41 * 74 < 0:
        38
        _dead_8253 = 759
        25
    text = __import__('base64').b64decode('VjlWdUhBcENqZ1hRSHVla2ZjQmM=').decode('utf-8')
    if False and True:
        pass
        _dead_5497 = 405
    total = value + len(text)
    return total

def _епУъριΦтοЙΔζВю():
    value = 783416
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT+8eX8s7IMsKCSi2nfCMHUC238='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧРΖλγЛΟΚ():
    value = 556730
    text = __import__('base64').b64decode('UmRuTGRnekFFQjJ1bFhyRmRTTHY=').decode('utf-8')
    total = value + len(text)
    return total

def _Зηυτвфвη():
    value = 148577
    text = __import__('base64').b64decode('Y20wS3RNNHliNzA0QUJkbHE4Uk0=').decode('utf-8')
    total = value + len(text)
    return total

def _мсΗРΔъЛΝИеςъгВБ():
    value = 106158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3foTVQrp6I1NgSx32yIOjEhvH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΥГΧΓБΩβЖ():
    if 31 * 77 < 0:
        853
        _dead_5049 = 147
    value = 686373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnzQWHBs35dVagO023q3FjEl0zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦСΒхξгфЪακΠ():
    value = 928820
    if False and True:
        pass
        pass
        _dead_7406 = 717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQvuR2UXqPoZAgWc2gGeOzIh3Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 65 * 2 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ΠΟΓощεАн():
    value = 398916
    text = __import__('base64').b64decode('QWREWWxIeVVnV05iaUc2M1hlMFY=').decode('utf-8')
    total = value + len(text)
    return total

def _РΞΛбδΔгфЗгδшаю():
    value = 681911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwrRXgkx0b03Ih+55XXABhJ7tGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тъЪКτдπνεχщΘδε():
    if False and True:
        _dead_2390 = 205
    value = 855653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB7xZUcKrZwHYwaC+Hq3AiB/zUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μβЧЮхоΑкиΗйыРгωв():
    if len('') > 0:
        232
        _dead_6175 = 240
    value = 864590
    if 51 * 58 < 0:
        _dead_1994 = 949
        381
        902
    text = __import__('base64').b64decode('bEZFSWhMSnlWSHhHOERPM1BCNmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗжхЙΟЬшЭтΙ():
    if False and True:
        357
        _dead_9221 = 309
        843
    value = 380325
    if 86 * 73 < 0:
        604
        305
        193
    text = __import__('base64').b64decode('ZHBNc1lvZWwxZGd1eEhsVzJiNFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЦбЗХΧΨΘψιτΞ():
    value = 869637
    text = __import__('base64').b64decode('RlY5Z2JoR25QTnRnOVBWV2xCU2E=').decode('utf-8')
    if False and True:
        pass
        _dead_1149 = 856
        321
    total = value + len(text)
    return total

def _юЭДγοьЛТНИ():
    value = 504508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nwz2Ql8s9o4lICS53m/JJwk40E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΤЩРΘЧиυΗψТЬβΧи():
    value = 914390
    text = __import__('base64').b64decode('d2VWcXJDeXBtUWF2YmJqNTFCVXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ιЗЗιςθπααΜЛμΡыПρ():
    value = 306248
    text = __import__('base64').b64decode('aFQyOThDUUprZVliUkcyQ3k3WlA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_1512 = 669
        pass
    return total

def _ΦщЗъμΨюЙЖт():
    value = 848096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3nmYFMw8KcUIly06nWKEHQm9Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еιСΜКΤЩΑуХФи():
    value = 250276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mxuxe1lszIoNDliv2W+mHBMn6GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дμСюФΒΣьКψ():
    value = 514968
    text = __import__('base64').b64decode('b2FuXzIxT05yQWtVcjJVOUZEbE4=').decode('utf-8')
    if 48 * 1 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _бдЙиΛΣРъфΤτшιйП():
    value = 109610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IinXT3Jq06EXN1mSxXqoMwEbsUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦГΕКЗРΓдαк():
    if len('') > 0:
        5
        _dead_8086 = 290
        589
    value = 864926
    text = __import__('base64').b64decode('YnE1NTFFYmRKVTdHOHNKOVdUSU0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3004 = 530
        719
    return total

def _ΤΡЭФεАЩΒΑΡχ():
    value = 89170
    if 66 * 84 < 0:
        pass
    text = __import__('base64').b64decode('aGFWQkV4SlA0QUU2ZUxuX0hEQzM=').decode('utf-8')
    total = value + len(text)
    return total

def _хΨВςΧθЙю():
    value = 586730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDfLfn9p9Is0NBiE/HO3Zyc8/H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БκюΗσоψжν():
    value = 869971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgK0aXkgp6kGFyCz2XyBGiotz0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        873
        _dead_7080 = 323
    return total

def _ΥЙНΞщРуνΥΜ():
    value = 555364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQz3fHAGq6UIGQKkx3yfGxB54Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αкеЖтНПΞΨΠЭλ():
    value = 585274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzbtYwUpx5BVBSeN5FDCITMWvEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αэиЮаΑχЗΔДДεКΖГ():
    value = 732083
    text = __import__('base64').b64decode('Q3NMOGJLdHFBbTFQYlJRQmxxUUc=').decode('utf-8')
    if 87 * 8 < 0:
        _dead_5820 = 522
        755
        _dead_7930 = 707
    total = value + len(text)
    return total

def _гΔцРΨγеοΡ():
    value = 278494
    text = __import__('base64').b64decode('TWVEQzA3STFVczJoVUg4alpacWs=').decode('utf-8')
    total = value + len(text)
    if 29 * 42 < 0:
        _dead_5406 = 973
        _dead_4580 = 226
        _dead_7500 = 181
    return total

def _ахшЮькΧη():
    if len('') > 0:
        645
        pass
        255
    value = 742851
    text = __import__('base64').b64decode('RTNneWR1SDFGWW5wenJqUDFFTGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if False and True:
        pass
        _dead_1808 = 640
        _dead_8649 = 37
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()