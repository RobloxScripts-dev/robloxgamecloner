#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _СηъΔσЮνДΧ():
    value = 706703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx7SSkkqqKYsaQqP+06xBSkNtkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЙεΩЮуΣДΛΠμЕ():
    value = 858182
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('SEpRZllMR3VGaWtSX0w3X3VqbVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЕСжιЪυсΔΘ():
    value = 31875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTrnSFcy+oQwbB+M0E7GJwd2vFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩвИωшΟΣХГαзςооЮ():
    value = 500881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kg20O2I7z/8THy30zHOeYgQhxTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βлкфьδФΡЮ():
    value = 513344
    text = __import__('base64').b64decode('cjg0d0ZHMnVSU1A1TFVuc3hjRFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _НМφлЩщвШοГΖщжχТ():
    value = 304073
    text = __import__('base64').b64decode('Wlo1UGRJMnVZMFR3OUtwX01kYXI=').decode('utf-8')
    if len('') > 0:
        553
    total = value + len(text)
    return total

def _цМΞбΔμιοдЬε():
    value = 627044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EizCP0c67ZgCDh6AwH2eInx5zWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЙξЧΥΞχαДзП():
    value = 581491
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('ZkRfbnZrRjhEY2IySExuS0xFSEc=').decode('utf-8')
    if False and True:
        565
    total = value + len(text)
    return total

def _ъτфдДДгЧЯГζΤаρξΘ():
    value = 914803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3bnV0g20PwgD1mskGCBLhQdyEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        658
        _dead_8508 = 797
    return total

def _гυтζйБΕΘδπЖЦИП():
    value = 875805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bj7JOUkj2qYTFCWt8mGTZjcB1k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        608
    total = value + len(text)
    if 23 * 61 < 0:
        _dead_9517 = 293
        393
    return total

def _УЯДΒювиςγРΣД():
    value = 306491
    text = __import__('base64').b64decode('SjhSWnd2bzNoc25ZM3c4YkczeTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩьΞпΜΝдТΦεщΞМЗлσ():
    value = 582744
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxz8fAA08K4qGFqPkHuFZBI95ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γρβдιЛЧεЗ():
    value = 708334
    text = __import__('base64').b64decode('Y0g4b1lua2ZUTlZ1Wkt5NVVKSk4=').decode('utf-8')
    total = value + len(text)
    return total

def _кΑаыФсΞΕ():
    value = 702997
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB7zY1Jh2ftVNQf23g6IGCAK1lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        525
        865
        718
    return total

def _МэωМΡрАэξΡΓЧΛγЯυ():
    value = 853379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax/tS3A8/5gAGVqCwFeHbDB922k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨλΥДхΦχвθ():
    if len('') > 0:
        _dead_8974 = 86
    value = 505348
    text = __import__('base64').b64decode('bmlkSHc4MGhFODhfR2Fwc1laTG8=').decode('utf-8')
    total = value + len(text)
    return total

def _μηГвКμТΥ():
    value = 214942
    if len('') > 0:
        53
        _dead_6297 = 373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjXzSEcJ9P0VMTip91WHYjQG5To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хХЯХΨβьвτΝмΦΧιБ():
    value = 271510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwDqSUAPqaYxCxqy+0OeBi56yHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кзτЫШαлχДυЕЬΞУм():
    value = 576638
    text = __import__('base64').b64decode('QzdnUlN0QmZYVGZKTjNoS3VXM3c=').decode('utf-8')
    total = value + len(text)
    if 1 * 54 < 0:
        pass
    return total

def _ΕУешцТИνзΚ():
    value = 598189
    text = __import__('base64').b64decode('WTdPU3dKelI5TnZzUjREM2FtTWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥφΗβЬκЫρδьЫτХип():
    value = 111445
    text = __import__('base64').b64decode('blBDc2NuamxVQm1UWXhlNGhHdUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕСоНβхШΟщЕΩвμΛП():
    value = 686981
    text = __import__('base64').b64decode('dEs1amxVaURoaWplSFg0NE9uX2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΝфςкκπМбΣ():
    value = 22379
    if 87 * 71 < 0:
        _dead_1942 = 967
        739
    text = __import__('base64').b64decode('UlBZdUVGUXZWWG9tVlA0c2JWREY=').decode('utf-8')
    total = value + len(text)
    return total

def _πΝгкλφΠэο():
    value = 582721
    text = __import__('base64').b64decode('UFRZZml3ZGVkYjFVb0F2bUlBMHk=').decode('utf-8')
    total = value + len(text)
    return total

def _аμмдМειЦБξφ():
    value = 935576
    text = __import__('base64').b64decode('TEpBRF83OU5rMklLZGtlUzNSZDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥηЮхυКчеЭыΕРФУФУ():
    value = 654271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBvtfnwQyYktIwb660+9ESEBs2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФьцмаБЧδогБяЯΙЗ():
    if len('') > 0:
        pass
        _dead_1049 = 78
        pass
    value = 974823
    if False and True:
        _dead_4777 = 509
        318
        _dead_7208 = 689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PB7mYAUh0/4pIzWM0WLFBT176Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΧЛξΑЫуφЛυКх():
    value = 379908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyT3RnM//KBRACql2He6HDcVtHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        919
    return total

def _щρХЮΡЫγжОγГлй():
    value = 30215
    text = __import__('base64').b64decode('QkdndU1Mak5QTzdwYnIzQUJxX0g=').decode('utf-8')
    total = value + len(text)
    return total

def _НΟρЗеΝεцΗΦш():
    value = 330731
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ly7KOkUT+ZI3D1y27n65PxMX4U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 26 * 73 < 0:
        pass
    total = value + len(text)
    return total

def _ΜΗГψцζΟηΕнΞчς():
    if len('') > 0:
        pass
    value = 316089
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAbyRXcYyIAka1+twXORbCN66Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9791 = 193
        pass
        pass
    total = value + len(text)
    return total

def _ШвΗТπЗшΓΡκψθΗ():
    if 48 * 50 < 0:
        _dead_6657 = 491
    value = 552803
    if False and True:
        pass
        730
    text = __import__('base64').b64decode('cEFuMERVcm5RUHBUWXF5T09LMEQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1825 = 764
    return total

def _ЩχΒαПΧχпЖΨЬп():
    value = 449231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh7iaQAK97lXHDqr4k+XbQQisWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩфЫИвЛфХЪМψΓαΣх():
    if len('') > 0:
        _dead_4769 = 741
    value = 251899
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('Ym5RbmlQRnVCNWNHaktrNTg4MzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ρσющЮОНьΧρ():
    if 23 * 24 < 0:
        685
        pass
    value = 935678
    text = __import__('base64').b64decode('TU0xM1EyNFhwUTdNRWhrRVFSYXc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        623
    return total

def _σюжтЯΡттхйъΙΝИ():
    value = 647416
    text = __import__('base64').b64decode('UFVuaXFXV3lBVzBHXzFuNDhDTmI=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _дРщЦЬлΕυвиХЛΛ():
    value = 418584
    text = __import__('base64').b64decode('cDZCOEVldk9BSnBrX1l1VlJTd3k=').decode('utf-8')
    total = value + len(text)
    return total

def _иЭθΖτмσΨΦ():
    value = 53392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT/WbUAP8ZIZHzivxwLFMCkYxz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬДМνΘδρολЩΜп():
    if 21 * 24 < 0:
        432
    value = 921293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTfLOW42/Yo5CgOc3m+nZCAu91w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4797 = 433
    total = value + len(text)
    return total

def _ЙΑρжΩЗЭθΓσУΠπΔс():
    value = 615944
    text = __import__('base64').b64decode('dm4zTnJoaDQzbFF5bWN4SGNjRXE=').decode('utf-8')
    total = value + len(text)
    return total

def _йчьЬЦнΗМξδУλая():
    value = 634037
    if 45 * 68 < 0:
        825
        _dead_2882 = 419
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR3ddkI8yYYHET6PnnqSAHUfx3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        422
        921
    return total

def _иЮΠΛδΔηУаБ():
    value = 517559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwXAN0E/7acJPx6Fy2OaO3Qe43Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΥнκτтβΖО():
    value = 677208
    text = __import__('base64').b64decode('eWQ5UnRMcjZkSEFTMU1qYTE5UHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΜсхμεгйξΦςвчзαε():
    value = 224146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ehe2dEQT7oEXKBq14AOaITV37Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧщуЮЩБλΓζйвΝоΦЪУ():
    value = 42458
    text = __import__('base64').b64decode('d05GWlpHV2RseWVwX3VJTU95dEo=').decode('utf-8')
    total = value + len(text)
    return total

def _чυιξэοдэγΖΧςΚΞж():
    value = 856453
    text = __import__('base64').b64decode('S2duWWc5dlpaUnlBazRLcjlWblA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЯоЖθпхуιщΠΥРЗТй():
    value = 571434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3vLWFYe0JgvAh6a0niULH0M728='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γκкЕΓηгсΤΡАбΩ():
    value = 51237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EA68YFoTwaQ5HTyKwASzPx0LtFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΡРΗОατσ():
    value = 332872
    text = __import__('base64').b64decode('WEFxd3J1a0V1ZzFkVThwSFlkSVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ρезщΓΥςοсмбΠςДФ():
    value = 410729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECHbX0MzxIoUPQ6F5l67FhQE8ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зПλНЪΒШк():
    if False and True:
        _dead_7508 = 804
        pass
        _dead_8373 = 781
    value = 505238
    text = __import__('base64').b64decode('VTZRaXE2WGs3MHV6OVN1OWVvNDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЩяАοеλΖШЦЕЧЛ():
    value = 47273
    text = __import__('base64').b64decode('QVJDRW1OV1Q1M3VxOTJQUHUwVEM=').decode('utf-8')
    total = value + len(text)
    if 63 * 24 < 0:
        774
        19
        pass
    return total

def _мГψюΞлΔφчГ():
    value = 484458
    text = __import__('base64').b64decode('ZVdmeXh6QkxhRmUwQm1DSmlDRG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ВюъптТΖлВΑЧуюдГΘ():
    value = 41984
    if False and True:
        _dead_9581 = 190
    text = __import__('base64').b64decode('aF9YUVk5Y3dBd3Z3Tmh4MF9vcHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΚΜΠЙхΔθВΗЦБΑ():
    value = 418971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhDCPHgM/ZwZKwCcw0PCBwF59mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4121 = 776
        pass
        pass
    return total

def _ΥβΠцψΓУЩяΟΟ():
    value = 446981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCPbeWIx8K4uHSav8gaoNTA/10Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        453
    return total

def _ФкктжгπФ():
    if 81 * 41 < 0:
        _dead_7077 = 606
    value = 663614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAW2TUZt0v8NaFarnkWvGDIGskY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 27 < 0:
        _dead_7492 = 544
    total = value + len(text)
    return total

def _ηВρΠхψиРΠЪЭπч():
    value = 820163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD/PTUA2qp1SFyqu4QaUYh8G6mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6253 = 65
        _dead_1561 = 901
        _dead_4857 = 686
    return total

def _ЫγЗъРФрζЭ():
    value = 553704
    text = __import__('base64').b64decode('SER6WDN4TUNEY3k4eUF1d3lXMEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _шψδдεфΦυ():
    value = 254190
    text = __import__('base64').b64decode('STZvb0FLSXdfTGl2aWdONHZ6eTU=').decode('utf-8')
    total = value + len(text)
    return total

def _нтвΒΙТψщуА():
    if 81 * 44 < 0:
        _dead_3277 = 462
        _dead_2706 = 842
    value = 386899
    if len('') > 0:
        _dead_6010 = 77
        74
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhreSUsT3P4sI1+hmnKBJXd93X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ьчθοПαюЛКνπ():
    if False and True:
        _dead_8006 = 707
        pass
    value = 217257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InbQTwkT0KlVMTen0XKEHyQb9HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РЕГЯμΝпρΑл():
    if 4 * 39 < 0:
        225
    value = 887183
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxjRYQc/qaEHFSSZ4E+VJig16mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΣзонκФбнТрγтСыЪ():
    value = 621060
    if 23 * 98 < 0:
        pass
        _dead_9473 = 95
    text = __import__('base64').b64decode('UUwzRnhvZEVrSmt3T002ckJlTEQ=').decode('utf-8')
    total = value + len(text)
    if 79 * 73 < 0:
        166
        _dead_9747 = 698
        pass
    return total

def _Ъτвкφлεω():
    if len('') > 0:
        993
        673
    value = 24676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwC0Yl4D7Iw8NTv26m6FETE56l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΥЦλЗРθΤΝЪИωΥЯа():
    value = 345649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz7SOAU41owybzbz8ACFLBV/snc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нъВΗεьякц():
    value = 500533
    if 64 * 61 < 0:
        pass
        _dead_4733 = 685
        924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCLDRQMwx7kmMziZ6VukGxcLzV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КАрδΚаьЙυщβДЙΖ():
    value = 721796
    text = __import__('base64').b64decode('RmRNVjVOZ0ZxTElJYVVIQUYzeXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ААχЫΑυьρΟЧЯχΗΡЪ():
    value = 440014
    if 1 * 9 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AC3dZHwgqKsgAhak2kOmIz015ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пπБΖΛΓΑΡΠ():
    if False and True:
        940
    value = 564986
    text = __import__('base64').b64decode('TzB3SDZIb1oxOVhuVVZ4WG0zUmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕоΓμОшΠΞАЮЮУΑъФ():
    value = 659073
    text = __import__('base64').b64decode('WWNmaDhvOGxaTlRZb0JwSWJ6VEI=').decode('utf-8')
    total = value + len(text)
    return total

def _мОГЫдЭθρθззΘАΙВ():
    value = 810836
    text = __import__('base64').b64decode('SG5FVTdpTFhTSVRFX0tzVlF4eGQ=').decode('utf-8')
    total = value + len(text)
    if 80 * 31 < 0:
        612
        378
        258
    return total

def _аοМΧшχπиΘх():
    value = 436132
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('cXFsNm1zU0JUc29qNEJGRGpfZUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΕУχаξνλЛκЭмЗтαЧ():
    value = 545385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Exf+V1keyoA2bgryyXGvBzEO600='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΓЖυкпεεЯ():
    if False and True:
        _dead_4426 = 295
        pass
        690
    value = 971457
    text = __import__('base64').b64decode('YVVkTGpwdzdDRFE4ZVlRM2dGX1U=').decode('utf-8')
    if 44 * 63 < 0:
        311
        _dead_2463 = 632
        _dead_9779 = 514
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _αΛεцωΥБъИъδЪΤΙ():
    value = 907915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDvjd0AT2qk0aD2V4gOeLBontkk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дтШοзζΡящεМ():
    value = 687230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3n9V1YpqacrERr1yk6jJQsJ8kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЭЮЕфμγΦδдΛТдΦ():
    value = 413308
    text = __import__('base64').b64decode('ajBzU1JIUVBDWVI4eWFMdlV1SzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ρЙхйТжЙΦЕ():
    value = 591375
    text = __import__('base64').b64decode('TUNvSFhfMGgxTzZlQnFwemJ6TUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓьгΘЙπιψΥРΦЛΥк():
    value = 86900
    if False and True:
        121
        573
        _dead_4431 = 224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQO9VHsY65AiGVyr/AC2NQEO8Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7868 = 417
        pass
        _dead_4341 = 287
    return total

def _ρθКяηΗНγВΤ():
    value = 680334
    text = __import__('base64').b64decode('RmVkWHVNR2tBTmM4aERoV2ZKZ1o=').decode('utf-8')
    total = value + len(text)
    return total

def _щлΜΞЮеριΚΦкΝ():
    value = 823006
    text = __import__('base64').b64decode('Y2o2SmZNY0FsYm1iVkhZV2RHR2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ыЛщαйнΝτ():
    value = 915093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAXuY0cprZE5agusyVuzJXILzGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уцвЩΗΘΣПπΦΝφТζα():
    value = 974867
    text = __import__('base64').b64decode('Wm00TThjczhsUGM4MXZvd3JiSDg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        949
        pass
        977
    return total

def _ЬεΡХΘβКПАХ():
    value = 548373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRjUN0M7xqEvODmH4w65IA16yDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΞЩχЗадηδиЩзΞΠ():
    value = 27904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBuwdwgw8poCLQyO7QWDMwF/t2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 55 < 0:
        pass
        pass
    return total

def _ЖеΑΧХΓЩщоχγЧΙΑΦ():
    value = 834513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3+wO0gg/6EqL1iJw0K5IRor5Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 100 < 0:
        _dead_3628 = 500
        703
        _dead_3116 = 587
    total = value + len(text)
    return total

def _ТγСдГΝζΟиαΞ():
    value = 478917
    text = __import__('base64').b64decode('V29NY2xwUXowQ1FIc3BlcWp4QzM=').decode('utf-8')
    total = value + len(text)
    return total

def _цηΕЫΠΙЫξГ():
    value = 540163
    if False and True:
        pass
        654
        pass
    text = __import__('base64').b64decode('QzIxWUxpVkVzRVYwRzJzWTlMNDY=').decode('utf-8')
    total = value + len(text)
    return total

def _эИЛκΙΨΖж():
    value = 523549
    if len('') > 0:
        55
        pass
    text = __import__('base64').b64decode('SmFSOFFmdDNnUlhpOEhnbVZwNlk=').decode('utf-8')
    if False and True:
        _dead_8899 = 756
        242
        pass
    total = value + len(text)
    return total

def _ИАωуοιфЯΚΡМ():
    value = 443274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiPmQwI+ppAIbVqy4W+UMysl5kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _меΧζАЛдρуεЮ():
    value = 38389
    text = __import__('base64').b64decode('dXBmUlVSMTVtVXZzUWg0cVp4WnM=').decode('utf-8')
    if 8 * 81 < 0:
        _dead_3628 = 256
    total = value + len(text)
    return total

def _МΙЙιΞщоАшНξΣрΛвГ():
    value = 366024
    text = __import__('base64').b64decode('dGcyQ3E2a093bTAzQW1UMFN1UVA=').decode('utf-8')
    total = value + len(text)
    if 65 * 13 < 0:
        _dead_8666 = 62
        79
    return total

def _ЫйсШНΨЮцДΗνйΓι():
    value = 684670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lg70fX0g0q0vPQa2/0K0PnR7wko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧЪИЗдαФΗτкШΩщ():
    value = 551890
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnblV3sf64FXDTaIx0eVPCQ63k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1149 = 688
        pass
    return total

def _щςΚеβХрΠУΧЩдρх():
    value = 947918
    text = __import__('base64').b64decode('eHNsYXhreU50bUNNUUFBUmJWYzg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        945
    return total

def _тжзΩъΦυμЪτаЕΝЯ():
    value = 167597
    text = __import__('base64').b64decode('TVhtX1ZMRWJOajdFUUs1YzBBSVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩЩнКзФДμсΝλяш():
    value = 480367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBzOR1hs7po0LSv75gC3Pxoot0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МхМЗΔψГЬхрВΘΖЛσσ():
    value = 78856
    text = __import__('base64').b64decode('ZTI5MXRMYVVPRDBEZndVX2hRRTE=').decode('utf-8')
    total = value + len(text)
    return total

def _цαЙχуλЮе():
    value = 924533
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('bl9GU0o4S0luQnp3VnNBc21kUGY=').decode('utf-8')
    total = value + len(text)
    return total

def _дУΘχЭЫσЬе():
    value = 870518
    text = __import__('base64').b64decode('bHpBb3FJUFRaUnFUM3ZLV2RaMEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _χъΑьМΧδРω():
    value = 250356
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQHcRXkX75wRGFipmUG4IB8N0m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1579 = 816
    return total

def _щгМжΔСτΣυЗ():
    value = 435914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRznS3Q38YQWNDiAyXnFIyIb71k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘгмАγΜβΗзП():
    value = 497718
    text = __import__('base64').b64decode('QWpRTlRUeE9SYlhta25SQ3FkTTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛшΓΑЩτъЙрШ():
    value = 14960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CD/NfEgo8aI1ECSCn0exEnYl/kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 26 * 21 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΖΒСΓЛХΝХФт():
    if len('') > 0:
        _dead_7586 = 860
        pass
        533
    value = 845218
    text = __import__('base64').b64decode('ZEQzdDg2cFhwVjNFYWlvTVB6NnU=').decode('utf-8')
    total = value + len(text)
    return total

def _βΙισтΗАнЭξмΦξΦВГ():
    value = 948837
    text = __import__('base64').b64decode('cHBwYUxKMEhhNDlXU2haMUNMcTk=').decode('utf-8')
    if False and True:
        660
        285
        pass
    total = value + len(text)
    return total

def _φБπФνЭДвΑΔ():
    value = 467619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSLyYkY87poNaR6FwUKBExw55Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞшСтЧΞαΧЛА():
    value = 605667
    text = __import__('base64').b64decode('elRTZjAzV3V6SFlQZkVxS2F2VWs=').decode('utf-8')
    total = value + len(text)
    return total

def _οЦλЖΓЕШЯαхξ():
    if 15 * 13 < 0:
        _dead_4967 = 199
        pass
    value = 73829
    text = __import__('base64').b64decode('YzJWN0JjUHowZUhUNlcwSHVGSUQ=').decode('utf-8')
    if 38 * 17 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _зфУЙЖДеΩαΛХμжН():
    value = 922962
    text = __import__('base64').b64decode('ekVpdUFXYXpJRXZtcjNFbEVWb3c=').decode('utf-8')
    total = value + len(text)
    return total

def _щфΔΔсρЪТΙΣ():
    value = 708101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgTuUWdqrqQIKTe1x3ecIgwkt0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        691
    return total

def _теλыΜОεХρъΚΥ():
    value = 531798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS38Sl4d2KlTDz/1yWmDDQQqsEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ьιжьюαэΕυΞ():
    value = 311082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnfzbF4V1oYgEQeMyXy5DSgu4Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вдЫорνъπωфтΣьκУ():
    value = 626619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD7MPEI6p4QiaVux4mOZbAkk6kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οДЬсиЦлξхγЧэфН():
    value = 824193
    text = __import__('base64').b64decode('dmNNeFo4VWxldFJzb3d3VkRTVGI=').decode('utf-8')
    if 44 * 59 < 0:
        898
    total = value + len(text)
    return total

def _ψТНеΟЪλПэΖ():
    value = 241141
    text = __import__('base64').b64decode('a2Rlc05MWDRTNzJzVEVSUjdESFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬβбЪΖυЭΤУλкГηш():
    value = 313252
    text = __import__('base64').b64decode('WEdHWUJuT2FNa3RtR0lJTzFISV8=').decode('utf-8')
    if False and True:
        308
        _dead_3229 = 254
    total = value + len(text)
    if False and True:
        _dead_2325 = 174
        pass
    return total

def _мΔхкρΡΗΟξМΜ():
    if 29 * 9 < 0:
        pass
        _dead_5719 = 381
        pass
    value = 976136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCvlY0A42ZtSIx2r2Q+kBit68Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МвΡμямτΔΕьΣ():
    value = 78765
    if False and True:
        _dead_6066 = 310
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwrjPVc2pr5UAA6a4EW0J3w992U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        738
        826
    total = value + len(text)
    return total

def _ΩνяуΘξЙг():
    value = 39174
    text = __import__('base64').b64decode('VVVOM28xc1JJeEpnMGlPd0RSSUU=').decode('utf-8')
    total = value + len(text)
    return total

def _уσАζКιЯпδΙЙЭЭэ():
    value = 541695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx72fEg1q7E0AyGT93yHFwJ8wkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕμзфвыΟαфДЭИГФЫΜ():
    value = 894167
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCTxZ3A155gOMFy5wFuYPwwVtHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЮЭυΛцςσδςΝку():
    value = 191610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRizQ2A/q4QlLVyqmk+4MxYA/mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔтΥХΝмбΒΞЬΤщбтΠι():
    value = 108462
    text = __import__('base64').b64decode('YXpVTzl4Z0k3WTFvTWxjQ0JNbzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙχΗтοΙуυΝτИΟ():
    if 18 * 28 < 0:
        _dead_3123 = 630
        79
        998
    value = 967178
    text = __import__('base64').b64decode('V0Y0MVNDejlnaWsxcWR4R2pISUo=').decode('utf-8')
    total = value + len(text)
    return total

def _κΦрЯБэξτХνψΡй():
    value = 254006
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiyySmFqxI1VCj2HnWm3OQZ64GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΚнфНЕΞΠДοЗ():
    value = 924518
    text = __import__('base64').b64decode('VFFvSThoUW50ZXMxMlRxd1RwRGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖкψΨΝМЪΒАиξМΠш():
    value = 1426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD3VUUs22JEoPDu64E+RBCsGvFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞУжцыΠβЕйιБ():
    if len('') > 0:
        913
        643
        _dead_4296 = 763
    value = 912362
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQ21YlMB8JBWKjDwzQG/ADJ+7U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χчΕЙкζπсαиυРЩ():
    value = 813062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH7xdlgcr4khE126wkClCxU+5lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НПэΕβЮЧυγΙΔΝИς():
    value = 300037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhDTan800/8IMl+AwWGnICoI4Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        687
    return total

def _ЗдлπХεяяПОдΥшНюБ():
    value = 801069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3n+XmEQ9oYaMSOu4XuzGxY1s2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЫНΚΛЬυΑлοБюяΤΜ():
    value = 333768
    if 87 * 78 < 0:
        _dead_1647 = 486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L329YEQzzIdWHAKE5069FT0H234='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ρАееΠыτМдΜцеОы():
    if False and True:
        713
        pass
    value = 791034
    if 28 * 18 < 0:
        _dead_9207 = 880
        pass
        976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQzMZ0kL1oEUPga23AOJPhIX614='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖИЧИΒимнΘςм():
    value = 156559
    text = __import__('base64').b64decode('dUJTNzBEanJwZVdDSFZ6VzNTRTA=').decode('utf-8')
    total = value + len(text)
    return total

def _аыцНγиΧψъъ():
    value = 996864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQHoUXU+z6taNAqz+Fi0ESYK/Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 56 * 90 < 0:
        pass
    total = value + len(text)
    return total

def _ΠБΞΖдЖХй():
    value = 413486
    text = __import__('base64').b64decode('bGRVUFI2R21xX3JZcHJBcTgzaVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛαΒъΝБςн():
    value = 926076
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg7NPXg325BVOCSm5HOfYQoXzjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РсΥчЦκвнТцхρюΖъ():
    value = 612832
    text = __import__('base64').b64decode('b1VIRTlBOFhESFR3SFBOMnpUc3I=').decode('utf-8')
    total = value + len(text)
    if False and True:
        495
        pass
    return total

def _ЖΧΑΚΑτЭПΥΔжЕвσθи():
    value = 216116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ3FY1A67vFSb1mrwUK5DCEg4WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЦωΕхΣΠТаκмИ():
    value = 741360
    if len('') > 0:
        699
        _dead_9096 = 340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISXlRnlryZAROzyOwlKyYT139Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩХЪΠЮшμНЙΨΣиΕιΙР():
    value = 585555
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRrSQHw8r6xUYin72wGaPHJ+yDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 62 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _оΜФφαаВБзθФε():
    value = 334903
    text = __import__('base64').b64decode('bnFPdHRtNm1Qal85a19VZlg2c0k=').decode('utf-8')
    total = value + len(text)
    return total

def _АтМДφτетШ():
    value = 787969
    text = __import__('base64').b64decode('U2o0a0VqeGdUVldmZFphZ3NSZmU=').decode('utf-8')
    total = value + len(text)
    return total

def _убρЮШБΛθ():
    value = 192832
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjbud14LwfAHalqJngGRYwAYtE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МрΩΧЖлСΞαΜΕфΥζТж():
    if 7 * 50 < 0:
        pass
        _dead_9239 = 561
        659
    value = 590304
    text = __import__('base64').b64decode('RU9QZ3BoNThqS0xOQnAxSWVBZ0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ыχуАωΚЭΖШΕтτβзЪъ():
    if False and True:
        89
        _dead_2240 = 116
        374
    value = 943243
    if len('') > 0:
        286
        pass
    text = __import__('base64').b64decode('bUZleTVHMElZMlpLZVR1TzZsajM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΛФыκЗфπζ():
    value = 703887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyXJQQkpza0CNh2E0mmWFgAe3Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΧФΜςюρоωξΦъΜ():
    value = 768851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwnHd1cX85EmD12B0FqnAy0g3kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υПвΖΕцсЮφΣщΘδΒ():
    value = 860948
    if 12 * 73 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgDmZ1AO8YwJKzrxxQOCY3Y8tWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        506
    return total

def _ЖфЛЙαΑςι():
    value = 402731
    text = __import__('base64').b64decode('SHI3NjZQYVdLclg1eXdXOTlBQng=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЫЖЩЮЙзЭΙпЬ():
    value = 568741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCbLO2c+2qAnKAuA/waoMnR5yWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩνъψИαΨΨлψОνХХκй():
    value = 967561
    text = __import__('base64').b64decode('blFxTGo5S3o4cjlkbTcxTVlQNmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΦШΝкнΧΖ():
    value = 443552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyTweHdo0qMwDyq690eSAX0G7V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГκΖюБмтΛДэПЮΡ():
    value = 787775
    text = __import__('base64').b64decode('ajZzekNNX0FxSVlZZEJBSEpwYkY=').decode('utf-8')
    total = value + len(text)
    return total

def _щΥЯΠДсΨыИж():
    if len('') > 0:
        pass
    value = 223057
    if False and True:
        21
        pass
        132
    text = __import__('base64').b64decode('aVdwV1dDR1JtRHVVX0Q5M3dPUUk=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΓΧΚδчбΧρчζЛВΠΥЙ():
    if 50 * 98 < 0:
        _dead_8902 = 118
    value = 304222
    text = __import__('base64').b64decode('Z2d0SklPTGtaWGlWeUVPSFp1bFQ=').decode('utf-8')
    total = value + len(text)
    if 28 * 4 < 0:
        _dead_5397 = 983
        _dead_7938 = 894
        pass
    return total

def _ΘРψЙεыΡьΝΗЕΞω():
    if len('') > 0:
        699
        900
    value = 87180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B37BYWE4rJIkIh650A7GYwwm21Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        219
        _dead_7903 = 329
    return total

def _ыйсвКκΩХδ():
    if 52 * 2 < 0:
        866
        94
    value = 324636
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JirwW3oa9YVUKSClwlq/Gg0nzlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШекДΤΜаυкдЛЛылΧΦ():
    value = 493732
    text = __import__('base64').b64decode('TWtaV3JRUmlPZ0dMTEtRRmZiYWc=').decode('utf-8')
    if 2 * 72 < 0:
        809
    total = value + len(text)
    return total

def _ΥоЧУдызεψρΩУСзπй():
    if len('') > 0:
        _dead_3116 = 378
    value = 120411
    text = __import__('base64').b64decode('QkI2TUJEM3VHSzllbEZISWlmUHA=').decode('utf-8')
    total = value + len(text)
    return total

def _кΓЧэлыΟνхχуΝ():
    if False and True:
        343
        pass
    value = 440562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCjiX3QV14oVaAKgxXC8ZnV61GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝаθЗΨЕтСЯжВΣκ():
    if False and True:
        830
        pass
        pass
    value = 308459
    if len('') > 0:
        _dead_3063 = 795
        _dead_7240 = 464
    text = __import__('base64').b64decode('THA2cWVQNDYzUVFxWVJGNk1lXzk=').decode('utf-8')
    total = value + len(text)
    return total

def _КπаюфπΚЪТΦοξИуΩ():
    if len('') > 0:
        _dead_3880 = 76
    value = 92247
    text = __import__('base64').b64decode('b1VmZHpGX1BpbjJnX2NoNDRyWkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖςπкГхсΓΠΛьт():
    if len('') > 0:
        _dead_4794 = 776
        _dead_6246 = 352
    value = 880892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LA3cQ3Usx4k0NDucngKYHxcY41Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        550
        _dead_7166 = 255
        pass
    return total

def _лТФεюΝΟИΓκ():
    value = 110566
    if len('') > 0:
        _dead_1665 = 837
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjXhNwEM8LxXPlqx2HWDGzQ4z0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 55 < 0:
        pass
        904
    total = value + len(text)
    return total

def _ΣМωчбΟЭδΓдФйО():
    value = 270392
    text = __import__('base64').b64decode('UlJ0cHY5OVJjTHBBTk5KNG9mTkg=').decode('utf-8')
    total = value + len(text)
    return total

def _οΘΤКДЪГШХΦА():
    value = 2702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXvHSHoS+5IgHQWtw3vHOQ0ZzGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΕδшΑαГоΚьλиМ():
    value = 280763
    text = __import__('base64').b64decode('SDRMWk5kTVdzSDViX1NIWlFaSlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ВрπъХзгЬяθΚДΧ():
    value = 290341
    if 6 * 18 < 0:
        pass
    text = __import__('base64').b64decode('WmRZd3hpTFNxVTdaOE9WQ1djY1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ыБЯяЯΛмНΙΜηЮ():
    value = 342600
    if 9 * 27 < 0:
        _dead_4237 = 671
    text = __import__('base64').b64decode('ZjdxYXU2Qlh2N0lUVUp0Z2JOdFI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6305 = 14
        665
        728
    return total

def _ΕЕюηчЛЗηТΔξЬЦюПы():
    value = 59402
    text = __import__('base64').b64decode('WVBTNnJaNUxWTDdOM2lIcVY2bDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬψμЗχςΛιКγΘχрч():
    value = 995531
    text = __import__('base64').b64decode('dmJqWG9taHh2MEpKOGROSnFyN3k=').decode('utf-8')
    if 19 * 66 < 0:
        pass
        702
    total = value + len(text)
    return total

def _ТцщЪβυДыΜχегЬλЯВ():
    value = 990473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3u2ZgAe2ZcmAFaC3g+RN307sEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κыξκЬБфГψе():
    if len('') > 0:
        _dead_5382 = 998
        _dead_7898 = 516
    value = 24174
    if len('') > 0:
        657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSHdT2kp5qkrD1/z3Fi0LB180D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΖΘщшРЪЯθηЬαиаυ():
    value = 90321
    text = __import__('base64').b64decode('U2Jja0FmYkYzTU5selNNRkU4S1g=').decode('utf-8')
    total = value + len(text)
    if 36 * 26 < 0:
        pass
        226
        _dead_9386 = 605
    return total

def _оБхΩεξеΝщНκЙζшДЕ():
    value = 793339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjfFY3IA9f0oPFy1wULAEQsG/Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 59 * 40 < 0:
        _dead_9034 = 326
        444
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _рЗσΞнХжυωξΩчсπωο():
    if len('') > 0:
        pass
        pass
        pass
    value = 334187
    if 77 * 41 < 0:
        327
        pass
    text = __import__('base64').b64decode('bzdQNTZsQk1jWnIxRHN2ektVelQ=').decode('utf-8')
    total = value + len(text)
    return total

def _βЬтκЛбОВΤХς():
    value = 16305
    text = __import__('base64').b64decode('S1pmMEZ0NmNWcU1mbDZXVEdEcU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕφψΞОШЭДЦсΞρ():
    if len('') > 0:
        _dead_2005 = 384
        598
        837
    value = 724405
    if 39 * 8 < 0:
        _dead_5333 = 550
    text = __import__('base64').b64decode('aWlBdTVCb2Jia2pYYm4ydXRaWVc=').decode('utf-8')
    total = value + len(text)
    return total

def _КннГжУμΧζчκβюьθД():
    value = 56656
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cyn8OWUNr48pHz62nH2nNho473c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 83 * 92 < 0:
        pass
        pass
        pass
    return total

def _ΣФфИЗЙωαлхЧΟγе():
    if len('') > 0:
        40
    value = 673692
    text = __import__('base64').b64decode('TXFlMjNmYkxvakxUUnVkR3NVcVU=').decode('utf-8')
    if 66 * 3 < 0:
        _dead_5243 = 755
        pass
    total = value + len(text)
    return total

def _βΝлЪЪВβЩ():
    if 19 * 41 < 0:
        _dead_3635 = 785
    value = 707814
    if False and True:
        _dead_5013 = 83
    text = __import__('base64').b64decode('SXFUR2RlbFNqVUlKWTNFak5HZHA=').decode('utf-8')
    total = value + len(text)
    return total

def _αОИГρСыΚΩыΔие():
    value = 569301
    text = __import__('base64').b64decode('TUFfbG13WUV3N2FGdHptaEs4U04=').decode('utf-8')
    if 24 * 77 < 0:
        pass
        _dead_2194 = 428
        _dead_3644 = 686
    total = value + len(text)
    return total

def _ΝΘΕχЫБЯЫτ():
    value = 313663
    if False and True:
        pass
        204
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgTmZlA93PksHRyi5W6ZABAX01w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2757 = 172
        pass
    return total

def _ЧΡΞцпжΤΙВм():
    if 8 * 31 < 0:
        _dead_2844 = 128
        pass
        _dead_5356 = 406
    value = 837419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgXJZ2ULwYA6GSnyzUaDZXB7/Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _даξРХδРь():
    value = 811314
    if len('') > 0:
        _dead_1225 = 788
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQuxV1kpx/0UKlal22CfFgMZ5Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙυРчоЗРС():
    value = 171676
    text = __import__('base64').b64decode('VGJPUHYzZGVOTnRqMGxOOVFGR0s=').decode('utf-8')
    total = value + len(text)
    return total

def _πεΑбΤγηфΒ():
    value = 278569
    if 80 * 44 < 0:
        _dead_3241 = 489
        _dead_1788 = 415
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjvDPX861YYBKFi051ScDBwixXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЯнчΨюΑУΟ():
    if len('') > 0:
        _dead_3875 = 658
    value = 792875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSrRSHUhy4I2IDaA2G+qJD96wEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭοФβεЦπкχмΗЪ():
    value = 406328
    text = __import__('base64').b64decode('eWRPZlM4NnM4MW1pZUhCOHRZWHA=').decode('utf-8')
    total = value + len(text)
    return total

def _κΑδдψлνвфРΓηн():
    value = 607018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgrIXwFszZpSAgSIyUKpbAQFxVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if len('xxxxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()