#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΣγρцιΠυΥζτ():
    value = 550895
    text = __import__('base64').b64decode('bkYxbGpVa0R4eHBDcURWOHVfSEE=').decode('utf-8')
    total = value + len(text)
    if 7 * 14 < 0:
        _dead_7828 = 49
        _dead_5751 = 212
    return total

def _ψЯШиедЧаО():
    value = 42999
    if False and True:
        pass
        _dead_4968 = 985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITvrOVNt2v4ZOxmqkGSFMHEKzkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хШЮηжТЯюиπΔΗσ():
    value = 925928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESjPR3Qp950NLzaVw0CzABcI7n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιяζюΖзжйδπЮδμξω():
    if False and True:
        pass
        pass
    value = 222726
    text = __import__('base64').b64decode('czJOVHVrdUVQTDNyNXJWUHdDM1E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9589 = 12
        _dead_9242 = 471
    return total

def _ΥΚΨγΞδωΤПμУβτΠΔω():
    if False and True:
        _dead_9153 = 437
        280
        _dead_7971 = 346
    value = 987549
    if 93 * 19 < 0:
        110
        267
        pass
    text = __import__('base64').b64decode('SGNpQVY4cnQ2dlNnbENBeVVkdGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΠΞЗινΑΩΨΜοЕшп():
    value = 183208
    text = __import__('base64').b64decode('RjBKMlF5SGhkZ0xhQkhrYmNFMDk=').decode('utf-8')
    total = value + len(text)
    return total

def _цзЫввηΒф():
    value = 619924
    text = __import__('base64').b64decode('WXdxa1ZvYUlCX2pFc3U2Uk9Gdnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ωЫЧΣμρψэνΛаЯφЙъξ():
    value = 563582
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRnGTVUB+4JUHQqK4GekDgF4ykc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 62 * 79 < 0:
        364
        pass
        _dead_7914 = 134
    return total

def _чΛЯζЧπυс():
    value = 612302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQH9bHBvr7sVLTCP+FihbCR+23k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΤΔзςΣαъεнπ():
    value = 659721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRbTV0U7qZ4UFSy7yXPIEgY9skU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖНЭΡзыЯэγЮВХПш():
    if False and True:
        176
        980
    value = 812891
    if False and True:
        pass
        _dead_7416 = 658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQLtN0cT5KAJLgKwz2+2CxAh50k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΠЦгΙΖОλΝμцηГдΨΖ():
    value = 189687
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSe8VmEIqvAMMSyB+XSxAj8i208='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЕбМΦΓуτКЛ():
    value = 679279
    if len('') > 0:
        _dead_6637 = 69
        849
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3flQFAK368rLAOUzXzFMCgI1ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯФЯЩΛЭОβЭъпιшь():
    value = 235013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHfBe2gJ6LwoMAmE3EaZOzUW23s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑшζЯσхГнρθлυзΧ():
    value = 519946
    text = __import__('base64').b64decode('VWljZ0NKREF6RDdYcjNIRllfV3o=').decode('utf-8')
    total = value + len(text)
    return total

def _рΞХΖΑбНΤΖδЗДФР():
    value = 322013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bi7SfGQ4r5AROF3w2g64JyYEyEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФцΕЩпЖζΣ():
    if False and True:
        _dead_3916 = 372
        _dead_2437 = 745
    value = 719760
    text = __import__('base64').b64decode('Rm9TZTRydmJPSzdKUWhqYjAyMDk=').decode('utf-8')
    total = value + len(text)
    return total

def _МΙиъхΗΨЛцαрЛγρ():
    value = 443414
    text = __import__('base64').b64decode('R2lTdHp5RWhWazMzNTIxSlo4U28=').decode('utf-8')
    total = value + len(text)
    return total

def _БйфиЧκσβе():
    value = 486274
    text = __import__('base64').b64decode('ZUJYX2hUMFB3elFVRGtNWTJhNVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩоНЙъΨΡКΘъΡΩρςЮ():
    value = 950567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nxr1fX4h5Ks2GCyC0lOfCz0swHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒоГχηδЛιъΦΛыχаяΞ():
    value = 441000
    text = __import__('base64').b64decode('cnlENURyUUxLRmF5TXl5dGpyRUg=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_2962 = 827
    return total

def _αучцξКΕΗψ():
    value = 32472
    text = __import__('base64').b64decode('emsxa0tienBwTHlZOTVHMEt5NW0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3500 = 793
        _dead_6224 = 913
    return total

def _УξаΡмМАвξФоЙΝб():
    value = 377416
    if len('') > 0:
        558
    text = __import__('base64').b64decode('aUVWQmRfS1pjbm5wbVZydmRnb1Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        185
        pass
        pass
    return total

def _ΤΡηъщκκй():
    value = 757577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHrIN2lp6fESDyqQ+H65OgoF5Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤУθηξΞΝвΞРеГВ():
    value = 281333
    text = __import__('base64').b64decode('S2F0TVNHX0JNd215Umh4VFRsOW4=').decode('utf-8')
    if False and True:
        _dead_9968 = 354
    total = value + len(text)
    return total

def _ΕΥηЬοлΜτхмыΘγПэ():
    value = 260591
    text = __import__('base64').b64decode('YTdiMnF1bE5aVG5rMGNWZVlGSXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛψЧΤΖΛΑηв():
    if 61 * 50 < 0:
        236
        pass
    value = 768197
    if False and True:
        _dead_9687 = 952
        pass
    text = __import__('base64').b64decode('VFFyblZkT2hUeDJwTEJTeUNobDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ыфАΖΗΛΑζдШымΘмк():
    value = 669496
    text = __import__('base64').b64decode('eGNqaVpVQ0pLNXJqTWt6MnVnY3M=').decode('utf-8')
    if False and True:
        _dead_2908 = 25
        pass
        _dead_2810 = 737
    total = value + len(text)
    if 64 * 69 < 0:
        _dead_1311 = 625
    return total

def _ТΩбοНяζεЛδрεςπб():
    value = 293146
    if False and True:
        118
        886
    text = __import__('base64').b64decode('dExZeGpkeEZoamVvZmd0QTU4ZXM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        501
    return total

def _ЕПΟХχωЭπΨγκξЩбΣС():
    value = 357918
    text = __import__('base64').b64decode('Tkc0WU5rbkJiRFdOeWVZQXNXUng=').decode('utf-8')
    total = value + len(text)
    return total

def _гΟЦЪβрхΜоТф():
    value = 819003
    if False and True:
        _dead_5293 = 506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgDHOQAUwfAWOR+H4Q+CLhw/3G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9428 = 755
        265
        784
    return total

def _ςЙχΨбρЧχШ():
    if False and True:
        _dead_2927 = 936
        pass
        806
    value = 117826
    text = __import__('base64').b64decode('SWhyc3JRMzZhc3Nma2FsWXpWRUg=').decode('utf-8')
    total = value + len(text)
    if 75 * 77 < 0:
        pass
    return total

def _НЪΠΓσТΧАχδшοιй():
    value = 367484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT+3fnUMzKwpMwes4AeaAi8q6nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7582 = 650
    total = value + len(text)
    return total

def _ПΓΟУψУΘυдζбЯ():
    value = 652238
    text = __import__('base64').b64decode('Y19GeUR5a1A1NUVYMDExcExEeU0=').decode('utf-8')
    if False and True:
        _dead_1827 = 136
        _dead_3492 = 377
        pass
    total = value + len(text)
    return total

def _ноηΥοΛГУ():
    if False and True:
        _dead_1186 = 532
        787
    value = 628763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQbUaVoj3L0FIhqE/mzAYww46WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 92 * 87 < 0:
        247
        _dead_8597 = 79
        856
    return total

def _ηЩΛуΞΝЙΟ():
    value = 397321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSPMemE0yvEXDR2EmF+2Eg0VyT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФσвΣΔσΜΓΛУлΔαЗΝθ():
    if 68 * 59 < 0:
        _dead_2127 = 71
        pass
    value = 396420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh7AP2Iz8Y8NDD+3znXGHXF571g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 72 * 8 < 0:
        _dead_8812 = 429
        949
        _dead_1341 = 57
    total = value + len(text)
    return total

def _ΟνμΕфвдйЩМЫЖХсчк():
    value = 468714
    text = __import__('base64').b64decode('SmdHU3h5MGZmMUtJaEtpdXpTUUY=').decode('utf-8')
    total = value + len(text)
    return total

def _λζцδчΚΝПрδωИОυПт():
    value = 232282
    text = __import__('base64').b64decode('TlNKaTlpSWhRUmFFQUVaUXhZemg=').decode('utf-8')
    total = value + len(text)
    return total

def _λваαЪИкξэς():
    if len('') > 0:
        _dead_1840 = 366
        327
    value = 739988
    text = __import__('base64').b64decode('R28wZ05ybWZpcW43YXlUT0Q1YW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ςтдΧМΩаοгяГνгЕ():
    value = 346473
    text = __import__('base64').b64decode('Z3NGaHRhSWFTTHdQOUhOYkoyM0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤзξσνВВΞФ():
    if False and True:
        _dead_6226 = 886
        pass
        _dead_4016 = 980
    value = 235175
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DB/SeHAU9b9aMCDx8l3CEnMX40o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_3944 = 689
        _dead_8306 = 102
    total = value + len(text)
    return total

def _ΠОэлδΟΔУз():
    if False and True:
        729
    value = 794523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In7HW38/x4wgNCCq716BGAkQ008='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        818
        pass
        pass
    total = value + len(text)
    return total

def _ΙхαγΗΨυЛс():
    value = 662491
    text = __import__('base64').b64decode('S05TeHYzWFA4a19BUlVhZzFERUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧφБξъΕΦВЮοЫΘΚ():
    value = 220871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxjvSAYY+oJbER21y1nFMQQ4wWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨРЩΜςψлς():
    value = 833854
    text = __import__('base64').b64decode('SldfQWFsSkx4cjZUb2F3UzlxUHc=').decode('utf-8')
    total = value + len(text)
    return total

def _χΙлэНδΗΝαζ():
    value = 767164
    text = __import__('base64').b64decode('dHJGM3JFQVdnMzNLWGV0dm1Pb2E=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6579 = 525
    total = value + len(text)
    return total

def _ШΧсτхЕвΣеιЪВИйΛК():
    value = 355587
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh7UZ0Zq37oWaiqE2GW+AAYat2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΑδяδЗΞГЫ():
    value = 295470
    text = __import__('base64').b64decode('UW16cnBhOVk5M0QzM21tOWo4YXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦσжζΚαЧъчТй():
    value = 974636
    if 99 * 86 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhDGeWdv85IHIzeNz3WFAR8e83w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 42 * 6 < 0:
        pass
    total = value + len(text)
    return total

def _ΜыυщΨфДσхдΗп():
    value = 722148
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSz0eF4ur/wPHV6c3ELAZy8q/mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТчηнςοАжех():
    value = 952540
    text = __import__('base64').b64decode('eXZycHNHeFZaRTdtbnV3Y0VMdXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕβфеΘΕΖжΖгХυΧЛцЪ():
    value = 543990
    text = __import__('base64').b64decode('RGNaS0xWRkE4dDRKSTE3Qkpxc2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘаΩЕнζМκΩΘтλ():
    value = 65004
    text = __import__('base64').b64decode('RmZheWEzd0JrZ18waVk4dGpVcXA=').decode('utf-8')
    total = value + len(text)
    return total

def _εЫИпκКψБΡюЕюмр():
    value = 459864
    if 79 * 92 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTjna3oo+p0EbQyL3GCyZzEW1mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 60 < 0:
        _dead_3644 = 499
        pass
    total = value + len(text)
    if False and True:
        _dead_8691 = 658
        pass
    return total

def _ииσраηвΛυвуШэΒυδ():
    value = 608675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ixm0QFsArb4ANl2VzUOnJh8F02U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κКглоиеыгθэЙкЫ():
    value = 324580
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQj9Pks+7oc0Pwuo236pB3MrsDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1192 = 932
    return total

def _аΚΕΦΙдЩΑЯМ():
    value = 264658
    text = __import__('base64').b64decode('dWFYWG5KNGpya1BBdHhOYmF0SVg=').decode('utf-8')
    total = value + len(text)
    return total

def _вКΞЙсξΥЦΦцЪПρΤΔ():
    if False and True:
        pass
        pass
        869
    value = 552063
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR3DVAYNrYpVPD6qwmyIPAN/tU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УηΓвωψвЭρθλΚ():
    value = 165400
    if len('') > 0:
        841
        pass
    text = __import__('base64').b64decode('bElwdXZiUkJUNEhlTHJPV2dMN2s=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _гбφУλФгщιΥ():
    value = 980976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fy7cfANv7fkACl202gKSIxcn9GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШβФΧГЙйСΠАЕγчΦ():
    if len('') > 0:
        _dead_5654 = 404
    value = 43168
    if 1 * 85 < 0:
        77
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQnFaGQ2/Yk6EgqQ31G2GzYOskk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σшшЫШэΗκγ():
    value = 667180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjjOOldo8oETCCGa2w/DHhUXvHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гЙмЙβЫΥЯΕσиΡξкπ():
    value = 398591
    text = __import__('base64').b64decode('ak9HM01YalZvVTFCaUxTODQxMjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞДщкяχμьУ():
    value = 704592
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECT3SXps+pkKbha17HSnMzYpxUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΞАφνьΝеΞЛδ():
    value = 812492
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCTTbAMb6ooHCRiQ5ACzJQAu4zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 32 * 80 < 0:
        pass
        pass
    return total

def _йοηУΤΧΙн():
    if 4 * 47 < 0:
        358
    value = 951798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBbTX14b0oYBaVeFxw+EA3Ye/GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5511 = 453
        55
        _dead_4208 = 263
    return total

def _ЯЖьΦεΤΡЕυγ():
    value = 23445
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHrPPAJv7Y8uPC6pxmOeBxUl7EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΥлцюТЮχ():
    value = 149274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCXxXFssz/5aaVqNzkeTIQB4sGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤюйЮηΠУΘ():
    value = 380439
    if 94 * 41 < 0:
        _dead_6792 = 358
        _dead_7876 = 261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXvnTXAdyaUTIDmOzEKfJjYZ3WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦиΔОΡлΑωΝΡ():
    value = 678943
    text = __import__('base64').b64decode('enh2aXJaUlFlSmR5YWlzdXRHYjE=').decode('utf-8')
    if False and True:
        140
        854
    total = value + len(text)
    if False and True:
        _dead_9641 = 11
    return total

def _ЫφΣηβΦУШ():
    if 14 * 25 < 0:
        _dead_6193 = 487
        pass
        pass
    value = 47884
    text = __import__('base64').b64decode('WXdmclZadjhUZkdGSXlMZHhtRnQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        31
        pass
    return total

def _ΛνыФΘБΚЙΕ():
    value = 808981
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jj3bRgcq/aEiLwSvyVG5FjF89mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЦЦЧътаОжыζ():
    value = 793595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICj0eFwN+YAoMB6b+UTDMC8Q1Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЬЯлΞдХЯЭςΗξΛςβ():
    value = 995330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBfeeUU2350BMzag0nSkA3csyTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛъΘΦνскНοУχζδβ():
    value = 72936
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwD3an4O9awyLVmq0A6eDgcK6zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 24 < 0:
        _dead_8475 = 328
    total = value + len(text)
    return total

def _ЕηЫшАΗΓВΡΒωρρ():
    value = 587177
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3frSggO/68uKw6lyUG7DDMd5W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПАяΩшЗТВП():
    value = 654458
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyjIR1hq/aVTN12M+m6/JBJ71W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЪИρфΜалраЬуЧ():
    value = 579023
    text = __import__('base64').b64decode('YnJjQlNhNVV1T24yX1VFZjZCU2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦρояяΨρПф():
    value = 513023
    text = __import__('base64').b64decode('SUxvdFVycjU1aGlJM1NkUXdqTWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ПщдλлλγηΒТНΛλЦβ():
    if len('') > 0:
        322
        pass
        186
    value = 339938
    text = __import__('base64').b64decode('TUFPQ1YxRGZBWGZVQW8xcmExcGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯхσщуыχЗЗφВЦнρΞю():
    value = 645463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD3LXHIsqKMZGyiCyUyJHQZ+5kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 55 * 26 < 0:
        427
        _dead_5468 = 183
        _dead_9564 = 131
    total = value + len(text)
    if 58 * 39 < 0:
        pass
        683
    return total

def _μθБШРΣΔО():
    value = 988246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjndXVJs17wtGD+cnHzFIzZ6w2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 88 * 43 < 0:
        _dead_4527 = 1
    return total

def _гσЦнпбъА():
    if 49 * 47 < 0:
        _dead_4580 = 976
        _dead_4774 = 219
    value = 616215
    text = __import__('base64').b64decode('dm1YWkM0ZE5Fc2VyczVmVUVNYk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΘτηКмвΝГЛтъ():
    value = 270307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDbxfHBg8pw0DS2I4m+iFw49/Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        254
    return total

def _ЦЬСЖЬкцЗвнΨР():
    value = 277906
    if 18 * 82 < 0:
        _dead_3296 = 685
        _dead_5013 = 493
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxznW1gUx6wAFR2EnnWHIgt79FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 47 * 37 < 0:
        967
        pass
    total = value + len(text)
    return total

def _ДΤУЙΖχЯкΕΩΓАΟ():
    value = 442548
    text = __import__('base64').b64decode('azVZMFY0eF9MOVNHV3RqN1VBT3c=').decode('utf-8')
    if len('') > 0:
        _dead_8552 = 810
    total = value + len(text)
    return total

def _яμηцςδΕЫБа():
    value = 785661
    if False and True:
        727
        _dead_3488 = 753
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MArVWnUgqIENEwOw51qyLTw77js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        122
        325
    total = value + len(text)
    return total

def _ΑгψХΥΦΖψυТКО():
    value = 931233
    if len('') > 0:
        988
        _dead_2157 = 368
    text = __import__('base64').b64decode('WUFoaXNrWGlhWVJNSmsxV0VuRjI=').decode('utf-8')
    if len('') > 0:
        570
    total = value + len(text)
    if False and True:
        767
        pass
    return total

def _бθιμΔοчδУλΣДАβ():
    value = 216151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjfzY1041b48PgX0yXOhOi4D7Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зГшПΜБМЕΔΙйяЮΦОψ():
    value = 48954
    text = __import__('base64').b64decode('dkJkUlFES1dHVHVMeTc1Q2lKamc=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΣГОСЦсΔщьοаθэь():
    value = 118116
    text = __import__('base64').b64decode('SW0yT2VoQkZhbmNjbGpxMDZka00=').decode('utf-8')
    total = value + len(text)
    return total

def _εΨПΘчφθЬТακЖΧЗ():
    value = 798020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBflbVI/p4EAGRnx7gOUBiJ+s1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦпφγОАПдГНнляъ():
    value = 960535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBW0S2kT7rsgawOV/lqHYS8p9V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 70 < 0:
        pass
        pass
        pass
    return total

def _нΠщБσΙюΚгε():
    value = 807788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxrpaVc78oQWKgyB2UyVABUt1k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еЭψΙΗиΧτΘхцΩИцΦ():
    if 45 * 92 < 0:
        pass
        _dead_3081 = 769
    value = 54895
    text = __import__('base64').b64decode('ajlFV1RMV0tITnhPcDBTMlpvY2U=').decode('utf-8')
    total = value + len(text)
    return total

def _αΦяΡλΡБπЫфш():
    value = 36562
    text = __import__('base64').b64decode('Y0VqNGFpYTg4b0swOUZDUzNtenM=').decode('utf-8')
    if False and True:
        pass
        30
    total = value + len(text)
    return total

def _ПдЭыЖНιЭς():
    value = 6697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwTPYkYTwbEQA1yH+EXFO3Ejx30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧρъκвΖсОκεШЬΦ():
    value = 195941
    text = __import__('base64').b64decode('SDlUamJHdVFnMW9OSmo3OFdxV3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _жΩСйΩΟσшγΑμ():
    value = 365935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cnq8X10IxLlTKTeq4mWEBwEutl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        850
        _dead_4110 = 728
        _dead_7940 = 170
    total = value + len(text)
    if 26 * 85 < 0:
        _dead_6766 = 125
    return total

def _ρεЕЫеоАКκяцξΠψЛ():
    value = 304846
    text = __import__('base64').b64decode('cGhIcDRXQ2hhQ3paVG5UTXIxWTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΓЕαΠЯΔНψФΠςчтΦ():
    value = 859298
    if len('') > 0:
        258
    text = __import__('base64').b64decode('ZnhvVjFmNW1jZm1RUmI0MzBJRzQ=').decode('utf-8')
    if len('') > 0:
        _dead_1261 = 853
    total = value + len(text)
    return total

def _ΝээЙκЧБюШχΦΗЦнщ():
    value = 636482
    text = __import__('base64').b64decode('VTVSTFl4THVtRUJ0ZlRucFc0VkM=').decode('utf-8')
    if 16 * 1 < 0:
        pass
    total = value + len(text)
    if 97 * 10 < 0:
        _dead_3045 = 611
        _dead_2468 = 230
    return total

def _ΚΟωльξЕκЗεεΞоΕу():
    value = 628398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj7lWlQA8qdQaASP3Q+hFjIGyUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1229 = 492
        _dead_4517 = 312
        pass
    return total

def _ψзδоΥυΗΙκοйро():
    value = 766505
    text = __import__('base64').b64decode('QlBBWnpjQVFzd0ZkNldTVW1oRVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠВцмВЯυТζ():
    value = 871920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQrVa1cU8a4OHgiA5kCcIScE8Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фцаςЬωпωвΗΗ():
    value = 265354
    text = __import__('base64').b64decode('aFFFanN0TnE2SjZicTNweThqdmk=').decode('utf-8')
    total = value + len(text)
    return total

def _фΟΤЯиПЧО():
    value = 289272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBfMQ2Nt3LAPbDrw5UG4G3Mo3X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЫкΡцЦМцτНЗψΘХ():
    value = 380056
    text = __import__('base64').b64decode('T0E0dnhRUXRrTklBcThsNnF0UzA=').decode('utf-8')
    total = value + len(text)
    return total

def _гоΠυУсдЗзφжΕ():
    value = 605237
    if False and True:
        pass
        221
        _dead_4258 = 555
    text = __import__('base64').b64decode('d3NvWlA3c1FLZXNFMTNQTWdMV28=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟИИйσЪαΜБ():
    value = 393413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzXtRwA784dRCQSx/gKgIiJ88Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _твΟκГхΓΝΓвτΩК():
    value = 900162
    text = __import__('base64').b64decode('WU5QME1tZmRMOEpMQWc0Q2JrTVE=').decode('utf-8')
    total = value + len(text)
    return total

def _щзцжεртПπλψЙΩ():
    value = 433497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jwi9VmIA6Y0JMTip8AOpExU6tFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цЙЙΑΥдпοΦОДНΑщ():
    value = 469117
    text = __import__('base64').b64decode('emdKcnp0N2JESTROOUlyQm9sWVc=').decode('utf-8')
    total = value + len(text)
    return total

def _дЫбΟφЮΑЯАβχρ():
    value = 84980
    text = __import__('base64').b64decode('a3A4YUM4TmFvdExsc0ljY2tYU28=').decode('utf-8')
    total = value + len(text)
    return total

def _дρНОλаДκСДΗ():
    value = 745945
    if 9 * 51 < 0:
        175
    text = __import__('base64').b64decode('b0dVUE5MRF9teXdFc3NFamMzTUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤФπМРαγЬМЕΥЦЙ():
    value = 791152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxXdPUlhx45baFuZ+nOhZSgH5Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΓΣκξаБкФΑΑдпωУщ():
    value = 10738
    if len('') > 0:
        860
        _dead_9484 = 297
        _dead_9533 = 815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSexWHwc6f82bzW7mVy9FiIhxW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1382 = 151
    total = value + len(text)
    return total

def _ΦщИОЪуΣгЙ():
    value = 870039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQbWenRp1qcONA6AmE+2EXEQ93o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 67 < 0:
        _dead_9362 = 702
        _dead_4746 = 537
        578
    total = value + len(text)
    return total

def _ЫνΜтэРОоουΠμцР():
    value = 699048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxzVRkgNxJwabDCs2VuvBwB+1VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙаΩъΑБФАшД():
    if 23 * 100 < 0:
        _dead_5043 = 65
        pass
        169
    value = 984405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSnhe0cR2rwtM1eC5wC3OBoezGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υЭПЫΠШяМ():
    if 55 * 100 < 0:
        pass
        pass
    value = 779788
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('SDNPMDgxaVVmd1U2b2hYU2J3Y0c=').decode('utf-8')
    total = value + len(text)
    return total

def _мэΤяφШАΒн():
    value = 547470
    text = __import__('base64').b64decode('VmJaZG5pY2dLWndQTUpueHhGNnE=').decode('utf-8')
    total = value + len(text)
    return total

def _оσΞαхьдФСχБтш():
    value = 344673
    text = __import__('base64').b64decode('ekM5dWpWeUdEeHVhREtNdEhaY2w=').decode('utf-8')
    total = value + len(text)
    return total

def _μςаХΗЦΞδη():
    value = 20496
    text = __import__('base64').b64decode('YjZ3anZhUWRhX3hGbHgxZklxMmE=').decode('utf-8')
    total = value + len(text)
    return total

def _νДчзΤχΜжΖРδΛ():
    value = 64116
    if len('') > 0:
        _dead_2330 = 801
        _dead_6919 = 225
        _dead_8227 = 806
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXewXgM81v0aLBql/HKqPyk+1Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 92 * 86 < 0:
        833
        _dead_3463 = 206
    return total

def _ΣПνμРαψδт():
    if 29 * 54 < 0:
        pass
        _dead_5430 = 15
    value = 221154
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwLdOWdh7rFbMj6733yvYDUY9Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъЗχςъΝэХ():
    if len('') > 0:
        pass
    value = 926677
    if len('') > 0:
        _dead_5592 = 669
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky7TVkEr/fkHOQ2WwVuWGwQg0Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        825
        _dead_1334 = 750
        _dead_1593 = 249
    return total

def _ЧбμτΨψεφΗΜцКΖνχЭ():
    value = 79053
    text = __import__('base64').b64decode('azVwUWlfcmJZak5oUkF4VWxKbTU=').decode('utf-8')
    if 96 * 93 < 0:
        _dead_3409 = 512
        276
    total = value + len(text)
    return total

def _СημΖЙΗяц():
    value = 735522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxjJVHBv7fs2aCWu6WPCIAIQ3X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йНЩШСρЧκкУЩКъцλζ():
    value = 304774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET7nSFov0Y4tCgOnngOSAgE412s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6685 = 519
    return total

def _ιкΖоЕОяЮдрПΙящΕ():
    value = 759027
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjnsP2tuzI1RGzuX+GnCLAl8/Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βьΟМХЩТЕΔ():
    value = 562395
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHbKPmcDyr8QDgWb5m/ILCh//FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΟζΤШΓЩΑн():
    if len('') > 0:
        pass
    value = 314920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCbFXngS2JowAhmpyljDJCELyHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЮьΤβδеуφЭнχюΤ():
    value = 606861
    text = __import__('base64').b64decode('Rl80RTJDVVJLYkpRYmRxVlJMbTk=').decode('utf-8')
    total = value + len(text)
    return total

def _γΙпшсΣсжЮΛηβюτ():
    value = 965751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej3+bW4K8ZpUDgqiw1i0Hzx/wms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΛГεΖτьсюЭγφΚΖч():
    if 91 * 69 < 0:
        pass
        777
        _dead_6127 = 910
    value = 305536
    text = __import__('base64').b64decode('UjJnZ08wZlhMbmo1MUs0b1FqSnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('bQ==').decode('utf-8'))
if 91 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    17
    _dead_8951 = 406