#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΜПμλΜεΦΤ():
    value = 508722
    if False and True:
        302
        pass
        374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETrdNnA3r/AoNQqRwl/ELSkHsn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖйаРΕКАΙπЩΞода():
    value = 213261
    if 16 * 40 < 0:
        _dead_5546 = 20
    text = __import__('base64').b64decode('ZjZaTzBtdGhWaWU2eTVKeWVOcVM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6212 = 932
    return total

def _ЫйΜΦρльЪΡΟ():
    value = 640577
    text = __import__('base64').b64decode('ZnJ3QmtDelNqdGNIdno1eExCajI=').decode('utf-8')
    total = value + len(text)
    return total

def _χιυφИνΞТЛшлΩσ():
    value = 842823
    if False and True:
        602
        pass
    text = __import__('base64').b64decode('TlJzamFLaE5NY21lMmlRMllEWEI=').decode('utf-8')
    if 79 * 89 < 0:
        pass
        pass
        920
    total = value + len(text)
    return total

def _юЗЙГВΑИйм():
    value = 845450
    text = __import__('base64').b64decode('Y3VRMVFUeWRlR18yTHFjbWxBM3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _бйζδуΛиθюЫхΛ():
    value = 624268
    if 27 * 15 < 0:
        _dead_8517 = 313
        912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxXvfV8tzYULPxmh/HGXOCcewDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΩμРкνОеγζ():
    value = 247188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRDnT2I98vkVGSSc51qBJHEBvV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИτδЭΣζΧЯΤрα():
    value = 704649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISLXVllr060JFSOc2EGqFS8k9k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫιЖЯγГΠзΟεРЕЧфχο():
    value = 714512
    text = __import__('base64').b64decode('VUM2aW1kVzhWYUplUGJ6Q3dOZHM=').decode('utf-8')
    total = value + len(text)
    return total

def _εУхΘΤνчΗΞ():
    value = 293539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBzKOQIPz5EqNhux2nipYyEL73Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τзВΞρΥСΘΣд():
    value = 226604
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXrtPHQL3aMsOxqR33KoMSgisks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΤΠТωΦЦкχНАвЯςж():
    value = 748152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHfrN3ABz6YbCzr7+AeFNncXzDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨпхьЕΙΝПчЙр():
    value = 793484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ayr3QWMdwfEwaQSn2FPCLH0G92Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЖΙКφΖЪλгξВπΔΛεД():
    if 98 * 37 < 0:
        pass
    value = 732674
    text = __import__('base64').b64decode('QjdRUUdCMEpRdllmZDVmeGFfenc=').decode('utf-8')
    total = value + len(text)
    return total

def _ВθΛМψтСяΕсГαЫ():
    value = 899825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AA6xQkRg9fkPLQaKkX+4ITx+0Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЪхщЫащθСΦь():
    if False and True:
        pass
    value = 655281
    if False and True:
        pass
        813
    text = __import__('base64').b64decode('TVV5Z1lWY0V4SWVFOTlfOVQ2WWU=').decode('utf-8')
    total = value + len(text)
    return total

def _αрΓмναцЬΡΝяцюэЬ():
    value = 641274
    text = __import__('base64').b64decode('VFlzejZoa283dDRkbG9HSm1WbEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΑяяΒηъδЧιЪΓπω():
    value = 902022
    if 86 * 31 < 0:
        _dead_4590 = 106
        pass
        pass
    text = __import__('base64').b64decode('VFhmMlU0WFhhNDI3VDdFNG1tWW8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        82
    return total

def _ыΠРиΩΜРйЭι():
    value = 711077
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwbSbFgsqr0IGyWrzw6qAnQus1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БκнΜΖιжИфРЕΣΞ():
    value = 786075
    text = __import__('base64').b64decode('RDV0WWhJcFJWbllvYU1yTmFPbTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ВωЪчЗΛВмШΕжПΦР():
    value = 68554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjzMWAcN7bkzAwah5gGhFiYBvHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 100 < 0:
        _dead_4328 = 53
        71
        pass
    total = value + len(text)
    return total

def _рвдЬявωαУΨР():
    value = 341959
    if False and True:
        830
    text = __import__('base64').b64decode('REFnWVJzQTBKOVQwWUlpbURJY3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ζШυэгШюΖтжМэМΖ():
    value = 262950
    text = __import__('base64').b64decode('UHE0bWNiTmNGYUZEenZ5Nk9fb3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЧшЮΛΙВΣΥ():
    if len('') > 0:
        720
        pass
    value = 584145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyThWFMS6foCAFawnlinZnU86kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВюεСЩζΨЧЫαчΚ():
    if len('') > 0:
        pass
    value = 153252
    if False and True:
        568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nn/xfFtu8pErYjC3mGKyMTcQ3X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΓЦшшЪγЩХΗЖθУ():
    if len('') > 0:
        _dead_3494 = 636
    value = 859692
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCTDREEfxqFQDiKZ63yhAxEO/kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        57
    return total

def _кЦбРοΡФиΚΠЪυαХД():
    value = 946042
    text = __import__('base64').b64decode('bEx2Z2RLczMwZE52Y1UwNkxjXzg=').decode('utf-8')
    total = value + len(text)
    return total

def _УфΧΠθБьΛΩσβэ():
    value = 502469
    text = __import__('base64').b64decode('VTVzVWlUal8zRFZEVmFfSndVZEs=').decode('utf-8')
    if len('') > 0:
        _dead_2631 = 132
        428
        135
    total = value + len(text)
    if False and True:
        pass
    return total

def _еХφЙАξГЗЕΩШ():
    if len('') > 0:
        691
        28
    value = 680655
    text = __import__('base64').b64decode('dnhZaVpGcjd0UnliYW1LZFdGcHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘобζσБКхν():
    value = 27018
    text = __import__('base64').b64decode('b2NuSENzejhNc0U2blc2M2h5QUM=').decode('utf-8')
    total = value + len(text)
    if 98 * 32 < 0:
        131
    return total

def _кФΥμπДЮКΡЦτΛэωψ():
    if len('') > 0:
        868
    value = 477823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3vIaX8J34NVHzyi/3OAHTx60n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бКΛΩщШΡтεβВЧтΙ():
    value = 807309
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARzIO3w6040bHAWA4gGfJT04tWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ετζСχИАκυЦпι():
    value = 762889
    text = __import__('base64').b64decode('TGVDeTR0RjRVRldoVFBjSjNUV1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _кдΔйМЭЬЭπкхЕк():
    value = 896946
    text = __import__('base64').b64decode('bDVXdzZkblNYUjlzX05nRTBnVmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЛЕкхФжЕΗ():
    value = 975445
    text = __import__('base64').b64decode('TjROdXJHSXRkckxrOEdwYUMxOHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ξμнΔьΑхЬщШЧнςХΩ():
    if False and True:
        _dead_7260 = 808
        _dead_6524 = 302
    value = 421767
    if 55 * 27 < 0:
        pass
        220
        816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBrwbGgV6KxQFyapzmGxPAkr7Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йКъгΧхфιεΣσОΡΟЙο():
    value = 75781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBrdbAAhz7IOajWJy1KdPh8LyWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РЩΔΟГоДυ():
    if 43 * 65 < 0:
        _dead_5652 = 341
        621
    value = 117061
    if False and True:
        _dead_7541 = 701
        548
        _dead_4824 = 837
    text = __import__('base64').b64decode('THo0QURBVXc5bjJ0RDZRc296S2E=').decode('utf-8')
    if False and True:
        320
        _dead_7537 = 933
        _dead_5894 = 660
    total = value + len(text)
    if 81 * 79 < 0:
        pass
        _dead_6150 = 534
    return total

def _ьмΨяςΧчλβЯФоюТяШ():
    value = 976663
    text = __import__('base64').b64decode('VXBpWnFtZ3RRbWdCenJhaGM3Zjk=').decode('utf-8')
    total = value + len(text)
    return total

def _эΙΒγЯШΑΤеΘиБΨ():
    value = 609547
    text = __import__('base64').b64decode('ZlByV0hiVXVHYkRjWWVDUGtUUmI=').decode('utf-8')
    total = value + len(text)
    return total

def _λβιЧзКХз():
    value = 881939
    text = __import__('base64').b64decode('VVZvT0pCOUoxeERQa29kOXc3X2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΡτЭρЧъθЯ():
    if False and True:
        _dead_5283 = 1
    value = 546731
    text = __import__('base64').b64decode('dkhxZXJqTFBoc2xuV25idU9NRXQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        18
    return total

def _βчГαΣГθНМε():
    value = 189852
    if False and True:
        905
        547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCPmSQhh+ZI2PRqV7WmSISAF0W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗнΓΔпλгИВэιУ():
    value = 981608
    if False and True:
        323
        _dead_5831 = 114
        _dead_4372 = 447
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NX/+Vn89/blUHQyo90GRGiQNzFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        886
        _dead_6113 = 710
    total = value + len(text)
    return total

def _эΜлрνрйУаТэЭΤκ():
    value = 763273
    if 64 * 42 < 0:
        pass
        _dead_3327 = 719
        313
    text = __import__('base64').b64decode('SWF0N3BMdDFhQ2hxR25CbndhT2s=').decode('utf-8')
    total = value + len(text)
    return total

def _рХЖЮчΙΒφДМ():
    value = 726577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lxz+b1Q00Z8IYwOK/gLAHCc18G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эйЯнΖгΑаΚЮκФΠгΥΗ():
    value = 511459
    if len('') > 0:
        169
    text = __import__('base64').b64decode('VnROUFI2QWo3alZtZk1iOW9WYUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖζМКчаΝΤΗ():
    value = 266790
    text = __import__('base64').b64decode('dGYwcEc2YUVRX2Z2YmtBQ1V4NTc=').decode('utf-8')
    total = value + len(text)
    return total

def _таςшртζШЗΜжΗЛчш():
    if len('') > 0:
        320
    value = 457051
    text = __import__('base64').b64decode('QnFPTUVRdnlNWmdkMnM5U19vcTM=').decode('utf-8')
    if len('') > 0:
        _dead_1769 = 595
        pass
        _dead_4634 = 521
    total = value + len(text)
    return total

def _уΣοЪΛэλπκЦЯЯχ():
    value = 58396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQiwekA6/KM1HginyVOXA3cs3WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮЙχχΖβνΔОΞжΞВ():
    value = 827709
    if False and True:
        _dead_4838 = 144
    text = __import__('base64').b64decode('ejBVRk5MU1lnVWFVdFpkWmpvNko=').decode('utf-8')
    if len('') > 0:
        _dead_4333 = 762
        _dead_3131 = 506
    total = value + len(text)
    return total

def _ВЮЪХΔЩЬβЕРБτγθΘ():
    value = 399346
    text = __import__('base64').b64decode('Wnp5eFNTMTQyUGZwTnF3a21xRlc=').decode('utf-8')
    total = value + len(text)
    return total

def _οэνрЧюэθПуЕЮЕ():
    value = 319892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzfzeQMU3LhbDASS40CgBhUW7GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υЗгΓцксΧ():
    value = 280959
    text = __import__('base64').b64decode('R1VRSHJjY2JRSkJNdExjeVhIOFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓВоиИуΣйцожρЭСХΛ():
    value = 100327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXvBdG46zJ4CLR6I4lG+Y3083EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щАЕΒχТχΥΞΓΡхЮξ():
    if len('') > 0:
        pass
    value = 815226
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjvDQGgQ7rgrPFia2ATIFyMt/lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7660 = 846
        pass
    return total

def _юοΦΡβνΔлΥоωеЫъиκ():
    value = 510783
    text = __import__('base64').b64decode('R01HcVVLVXhnM1JTQXduVlRVM20=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦпΙμΒηΖΠΗЙιΤλАкχ():
    if 69 * 62 < 0:
        928
        487
    value = 664666
    text = __import__('base64').b64decode('c2lhX01TWUpoeHI5S2w2NEFka00=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        242
    return total

def _ЩΘΨπυЧοги():
    value = 915413
    text = __import__('base64').b64decode('eHFBSV8wdTR5Z1ZuWTlkdnVDVWs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        893
        267
        pass
    return total

def _оΧχЗАΖРΧηКю():
    value = 13186
    text = __import__('base64').b64decode('VXdUbWNCYWlfb3Ric0s3U0RKOWI=').decode('utf-8')
    total = value + len(text)
    return total

def _пΙчΔσΦеΘδгХрСАΜн():
    if len('') > 0:
        pass
        pass
    value = 810004
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lgv0V1A07/4GLlaLkQ+fNhwe8Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 53 * 78 < 0:
        _dead_3498 = 448
    total = value + len(text)
    if 43 * 98 < 0:
        pass
    return total

def _СОυΜЦΔλЯгЩ():
    value = 390684
    text = __import__('base64').b64decode('WHB2WkJmSmZZdkR5ejRTZGNLQks=').decode('utf-8')
    total = value + len(text)
    return total

def _σΗчЦαЬДТЕρφ():
    value = 684205
    if 99 * 19 < 0:
        285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQfuRVwIx5ovKzeszn6/EjMFtTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_8579 = 409
        493
    total = value + len(text)
    if 31 * 52 < 0:
        _dead_2136 = 327
        712
    return total

def _ΡΟоυΗьμΜχСЮοп():
    value = 943127
    if len('') > 0:
        _dead_7353 = 54
        _dead_2356 = 698
        _dead_6029 = 12
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IH3SRUAR0fgBM1mxmG6UARcW5k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АχЕЛлτрйξЙΧΧЗЭγз():
    value = 455055
    text = __import__('base64').b64decode('ZWxaNGxuWDI4SExWbVF5UXJ4TjU=').decode('utf-8')
    total = value + len(text)
    return total

def _βθЖΥΦмωΕΝαщЫН():
    if len('') > 0:
        _dead_5545 = 722
    value = 378590
    text = __import__('base64').b64decode('aHZtOVNFVUZZYjhmTl8xZnlmNFA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3207 = 257
        _dead_8885 = 375
        767
    return total

def _иВΣΣιΦЛηЕБδφВС():
    value = 188021
    if 51 * 21 < 0:
        _dead_9657 = 785
        _dead_8699 = 111
    text = __import__('base64').b64decode('S1JzcFVOTXlXeHZnNjZabmVoWVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _МККγβλкΜДωβ():
    value = 557902
    text = __import__('base64').b64decode('Ym01UlJ4SGxJUG9XbVliQUxSUko=').decode('utf-8')
    total = value + len(text)
    return total

def _жЭχΙдΙЬχοкΑБГмνβ():
    value = 133280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBi8YwgS57IEHRah7mOBYSI35V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _κΣтрρЖцХЩЭτЫяψς():
    value = 283745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CALgf0kp0b8iAiKmzAGdYCR80EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θХβЛΖвΓωПтμτгςВя():
    value = 360217
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQLwWEgV8fsvDFq7mmmTAHAIwWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψбФкКθиРΗцоυиΕч():
    value = 740507
    if len('') > 0:
        _dead_7452 = 859
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRnuWVwg3YYqNjWP3k6nMzQB12Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΞСΗЕψщщъΒГΓθα():
    value = 599504
    text = __import__('base64').b64decode('dlF6TTJPVEhBMnd4T1Z4S21WZnc=').decode('utf-8')
    total = value + len(text)
    return total

def _цШΑмлЮсзЗнтΔБКδЙ():
    value = 191975
    if len('') > 0:
        598
    text = __import__('base64').b64decode('Y0ZNaXdmVHNuUlEzenZ0Umc5SEs=').decode('utf-8')
    total = value + len(text)
    if 73 * 71 < 0:
        pass
        pass
        675
    return total

def _мμЕΕуαЗзККΞьПΨО():
    value = 955292
    text = __import__('base64').b64decode('ZFJ1MGJtZnE5VHVvUG9aZDZmT3g=').decode('utf-8')
    if 26 * 8 < 0:
        _dead_1892 = 681
        334
    total = value + len(text)
    return total

def _ьМφΓτеКАΛЖшпЫБцβ():
    value = 524697
    text = __import__('base64').b64decode('SXpPRjVXQ1RKZlFlWWV6M242RG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙεмΙωБΞкεμφ():
    value = 863065
    if False and True:
        _dead_1636 = 188
        747
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwPdTFUsyK4GCF2P8VKpByh6910='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣΗшнσЭΝцъ():
    value = 737749
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ES7dYWEA9PwgN1uQm1jHZAgKzlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хмΝωхκσдяξНьЕГΩВ():
    value = 108913
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRnUSXw476cHAxiC/l6eBTQp0Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖдυУΦэΡРцυ():
    if False and True:
        _dead_4654 = 13
        633
        pass
    value = 423620
    if False and True:
        pass
        _dead_6606 = 418
    text = __import__('base64').b64decode('SEtrbFZXRVBpdDZjakJRNWZVeTE=').decode('utf-8')
    total = value + len(text)
    return total

def _УСпθιЪттοδ():
    if len('') > 0:
        pass
    value = 183426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwO9O2YXzKklOT2N/0/BOh8X5Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еωМьКХОКδγΧΩгαИχ():
    value = 731130
    if 97 * 48 < 0:
        706
    text = __import__('base64').b64decode('THh2RHZ3TGg4cVRqVnZCSnhqYTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _φЩмΣБЦЮИ():
    value = 824165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxvcdlYA1aAlDCmCkXHHIw4CykI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧνйХЮοгткΑюαξτ():
    value = 864872
    text = __import__('base64').b64decode('UFNvYm94X2dxMkhtMjJlOGVqcUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _βТРжЧвуШΞЫΝщжБ():
    value = 157775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSzoeVAT+YJRFS7w92PJIC0b9Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        262
        580
    total = value + len(text)
    return total

def _ИσΚαЯВЯоντт():
    value = 15490
    text = __import__('base64').b64decode('SzhITHVTeEM3cmlxOWpxYWZRS0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬжЪΦЫъσΔШΥΙ():
    value = 292645
    text = __import__('base64').b64decode('SDVDejkzS0FmcVd0SWhidWZQMkc=').decode('utf-8')
    total = value + len(text)
    return total

def _щΕЧΑщοшиΝм():
    value = 606475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3rrSkY8rLBaACuPkGezAy8V6Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_8609 = 437
        pass
    total = value + len(text)
    if 69 * 33 < 0:
        198
        pass
        _dead_8409 = 95
    return total

def _есΚЯЫЦнχх():
    if len('') > 0:
        518
        958
        736
    value = 84084
    if False and True:
        _dead_5279 = 498
        _dead_2749 = 381
        pass
    text = __import__('base64').b64decode('bGlEYm9EaUVsMjRFXzQ0MXNGaFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ТъПΟеτхфлΒРТ():
    value = 25259
    text = __import__('base64').b64decode('bzNqMUdIOVVaZXVRNEhEeEFwVUw=').decode('utf-8')
    total = value + len(text)
    if 69 * 64 < 0:
        _dead_1537 = 52
    return total

def _ЩЙАοлЭΑαХщцМПОΞ():
    value = 779986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHy2QVoN560LMAvx91CEHC4CvGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дчшЗηгуФζпю():
    value = 324456
    text = __import__('base64').b64decode('eE14Q0dUU0syWHQ0NzNuTDd4c2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΦтХбΑΝЙ():
    value = 453118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jx6yV1obyf4SazWr5GalPRM50k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2325 = 779
    total = value + len(text)
    return total

def _κОфΗθмюЕΞψψЩяπШъ():
    value = 302593
    text = __import__('base64').b64decode('WHNnVTVBRk91NUpLcF9IaFREdGo=').decode('utf-8')
    if len('') > 0:
        pass
        510
    total = value + len(text)
    return total

def _βЛπъБяОοЗигΥεДЪЙ():
    value = 942590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCXnZVUyro4qEFyukACYY3Y+5nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖхТЬчКΗιоΥ():
    if 74 * 68 < 0:
        919
        pass
    value = 292018
    if 73 * 33 < 0:
        536
        pass
        _dead_6470 = 545
    text = __import__('base64').b64decode('d284S1ZvRl81aldxR04zdDZnOHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙрЧΒτДεФ():
    if False and True:
        _dead_8157 = 130
        pass
    value = 174425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTf0f2Yb178UGy226nGabSAasWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        902
        _dead_2487 = 832
    return total

def _ηуиΛφкРьШСΟζΗ():
    value = 389646
    text = __import__('base64').b64decode('ejVIMG1tMmlfS2JGbThkbktuQ2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ψцмЯΗдяГЧщΤсΙ():
    value = 672778
    text = __import__('base64').b64decode('bHR3U2dxekoyM2x2NFl4dFp0eUM=').decode('utf-8')
    total = value + len(text)
    return total

def _фТζЧАЫкΜОρΤЕин():
    value = 1434
    if False and True:
        _dead_1173 = 111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCHUWQNv/K1WPji22VmBIDMnwkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 81 * 12 < 0:
        753
        727
        pass
    return total

def _ΠΨχьДΑςςψЮъδΠ():
    value = 530533
    text = __import__('base64').b64decode('RmpIb2twdTVxckJvUTVIc1UzT00=').decode('utf-8')
    total = value + len(text)
    return total

def _НΜМшΚхωЪ():
    value = 772818
    text = __import__('base64').b64decode('akpncFJYWGJ0OHo1cjV4UGpCajg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧηζоΡМφνиσν():
    value = 111612
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiXIS0k296srAgC2yQ+AGgsMtVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        131
        872
    total = value + len(text)
    return total

def _Дреψпρνр():
    value = 513741
    text = __import__('base64').b64decode('V3RMUnc5cmtqNUVoNHgxMWIxOGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕλИσсωπдΠАБ():
    if False and True:
        417
    value = 670845
    text = __import__('base64').b64decode('Z3VQclU4S3h2S0ZLMlplZUFRbjM=').decode('utf-8')
    if False and True:
        _dead_4118 = 310
    total = value + len(text)
    return total

def _ΠΧяеπωΧΟдио():
    value = 165799
    text = __import__('base64').b64decode('dVo4TmNIbjV5VWQ4Y082U1hUVkw=').decode('utf-8')
    total = value + len(text)
    return total

def _дλιΞЯгфЯйΨσρьЩΥΕ():
    value = 852656
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR7LOnQo/6ozPhz050LDDnQi0nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΒЕрФьΥРοРδОΨΡ():
    value = 193340
    text = __import__('base64').b64decode('dGFiRTZrYTJ2Ql92V1k4Qmo0akk=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЧνтВХΤΥΜ():
    value = 183101
    if 88 * 33 < 0:
        _dead_3772 = 639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC22W0c00vEtDSeJzE6DZxEl4jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗξξшταпΒμ():
    value = 225840
    if False and True:
        417
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCqxf11r2ZEPFCKgm1SXNTUBzWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χτηηСнПΙΒуσеЗрХ():
    value = 7342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnntOn0s65gyOCiK/2/IO3Q+9FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3725 = 849
    return total

def _нйΦΓрГбοэΓЮ():
    value = 795425
    if len('') > 0:
        pass
        50
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCvTaUUL3LEUFwOc7nzFMnU9yWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        201
        pass
    return total

def _ЖξэΝхфЩοПΕсиоиες():
    value = 272292
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3jtNwgI0ZxbAFeA5wSSbDUq3W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ызΑвбЪψπаΖΟ():
    value = 543343
    if len('') > 0:
        _dead_4016 = 818
        _dead_1246 = 431
        642
    text = __import__('base64').b64decode('djZwZ3RaeXdhM2JXTTUydEN1bm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ПоЩΝРчцМрανШМбГг():
    value = 381474
    if len('') > 0:
        _dead_5100 = 129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx/BY3AM5q0RFSmm6w+AAyMBxkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΝΚЮДФЬШψ():
    value = 721307
    if False and True:
        _dead_8226 = 357
        981
        483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAjVeVcYrYxbETqc6XmzP3ce9Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_6500 = 819
        pass
    total = value + len(text)
    if False and True:
        272
        619
    return total

def _мЬйλыΝЫДΨыЬАΡΧπΧ():
    value = 381356
    text = __import__('base64').b64decode('bmdHMzdRUzFhYUllcWc1OVhYajU=').decode('utf-8')
    if 25 * 6 < 0:
        331
    total = value + len(text)
    return total

def _ΦДζΞΘяΜкιгХьшг():
    value = 124882
    text = __import__('base64').b64decode('ajVXclp2YVlidEFPbWFBWVFOT2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝууйЖΖрΕОπΞЪΨэк():
    if 72 * 86 < 0:
        965
    value = 293621
    if False and True:
        pass
        167
        _dead_8562 = 457
    text = __import__('base64').b64decode('UDBQUngyN0pWazNxeHRUOXJIdmU=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_7765 = 647
    total = value + len(text)
    return total

def _пΦΠΧΣЛще():
    if len('') > 0:
        86
        pass
        pass
    value = 411713
    text = __import__('base64').b64decode('eW96aGdrUmtVZVQ4amhlMXVFVWc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        475
    return total

def _МβиШЯВяЩжΥйЕЖ():
    if len('') > 0:
        _dead_5787 = 342
        947
        pass
    value = 923932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnzSQFVu+PhWLQiR21PAPHJ83nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 49 * 64 < 0:
        315
        pass
        pass
    total = value + len(text)
    if False and True:
        211
    return total

def _ЩлΜъВСшЪΓмΧбωζущ():
    value = 493369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyvSaXUJ65ErHheS7gKpODR8xj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8124 = 524
        pass
        594
    return total

def _иνεΙХρκпΟ():
    value = 75954
    text = __import__('base64').b64decode('dERDeHZmakhfT2t0WTU5aDJSY1U=').decode('utf-8')
    total = value + len(text)
    return total

def _МсшгЖовЭйμМ():
    if len('') > 0:
        _dead_8187 = 641
        pass
    value = 246332
    if False and True:
        418
        _dead_9358 = 840
        _dead_1606 = 610
    text = __import__('base64').b64decode('TW8wUDltTmt0MktuZWhOam9QbDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ьйηхщΧОСμΙΒйΜКтτ():
    if 21 * 74 < 0:
        _dead_4908 = 155
        _dead_3931 = 410
    value = 372938
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyvLWwcf5rhWDQGszVWxJA8pw2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩвЕнщМКΓыэ():
    value = 647777
    text = __import__('base64').b64decode('ak9NVTZ4azdpVzdFZFNPXzhkdlI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠηςΙПХΠΨ():
    value = 157078
    text = __import__('base64').b64decode('ZGRuUnlhQTJGS3dmRXE0bjVLVkc=').decode('utf-8')
    total = value + len(text)
    return total

def _λдыЫΝΗςШδП():
    if len('') > 0:
        _dead_2703 = 455
        _dead_5372 = 92
        _dead_3296 = 264
    value = 61733
    text = __import__('base64').b64decode('eHc0QUhFTnJzRGU3anByUW9ZU1M=').decode('utf-8')
    if 83 * 63 < 0:
        _dead_5523 = 682
        pass
        _dead_3826 = 812
    total = value + len(text)
    return total

def _ΔΣютаАмΞΧкэщυюшъ():
    value = 823423
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXrFaAQJ3L8KMz378ACKYHQZsmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔηжЭΝρэΡδ():
    value = 805530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwLqSgQJ+Pgqa1im4EaSARA1z0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        411
    total = value + len(text)
    return total

def _ДЖкчАфнΚΙПЫЭΘΠσ():
    value = 787306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCDCb3kr1PsvEA2XzXOJYw0fvUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8267 = 296
        921
    total = value + len(text)
    return total

def _ЗгхЬЫщλωВА():
    value = 826448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASLlTF1tyvs6bQKc7nWGBhou00Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЛоΡХФЯцрДЙЩЗρ():
    value = 637608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj/3XEYu1r8Bayuu7FWTbH0L8V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГРПЧЙηνнчνΠΕδрЫк():
    value = 161524
    text = __import__('base64').b64decode('amhsRm1zTnJaSjhVTHlRVURDZ00=').decode('utf-8')
    total = value + len(text)
    return total

def _εΠυХуΕμАМμ():
    value = 464321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ixf2S1Y7rPkoC1/391KdZBQF4z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙςΝφΕΗБΘ():
    value = 905147
    text = __import__('base64').b64decode('RUZrX2ZGTWd3UmlKYlYxNkZFcXU=').decode('utf-8')
    if False and True:
        269
    total = value + len(text)
    return total

def _ФеΤмпНγлхбтςШ():
    value = 845691
    text = __import__('base64').b64decode('c3dBa3YxR3hzUFZWQ3RqU2ZoVXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗКРЭглΦЛШгΒеПьΙΛ():
    value = 808208
    if 52 * 39 < 0:
        _dead_8120 = 481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyH+fQBr+4ERYhm02UPBAwEe3Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΨФАΓΥΞЦВаδдРΙΥΖ():
    if 88 * 35 < 0:
        _dead_6425 = 476
        _dead_3584 = 990
    value = 507041
    if len('') > 0:
        pass
        661
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISvAPGZt27g6ICON/AG3PCgGvHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 38 * 77 < 0:
        567
        _dead_6658 = 847
        468
    total = value + len(text)
    return total

def _τΧμοОВлς():
    value = 539732
    if 9 * 14 < 0:
        166
        pass
    text = __import__('base64').b64decode('cXdXUXZITkJFOVJoZFp3QXp5Q0k=').decode('utf-8')
    total = value + len(text)
    return total

def _БШΚΦΩηапΕМΥысВ():
    value = 328192
    text = __import__('base64').b64decode('U3NEeV9xb2RkUnI0dWppT2d6WXc=').decode('utf-8')
    total = value + len(text)
    return total

def _эπΨΟвЪЛΜчЩш():
    if len('') > 0:
        51
        pass
    value = 795880
    text = __import__('base64').b64decode('d0RVMEg3WTFybXBpZEJ4YzJPTzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ηуЫЛΠσкΘуψΡ():
    value = 949398
    text = __import__('base64').b64decode('Y2dZa095MEZMTDVObXc1MVhwNlk=').decode('utf-8')
    total = value + len(text)
    if 72 * 75 < 0:
        pass
        _dead_4659 = 650
        pass
    return total

def _жлεиюνηψΙΜΚΟΓ():
    value = 449943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iy70P3Qq//0rIhXx91SiZgoO1ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЩжжКфΠЖвмΜΠρΜΥ():
    if len('') > 0:
        _dead_4139 = 29
    value = 322088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgDRfFhvqLAqMwXzmVeIDCs/3lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 100 * 44 < 0:
        _dead_5510 = 168
    total = value + len(text)
    if len('') > 0:
        _dead_3288 = 326
    return total

def _ШζМзΣΨаГΔГЬ():
    value = 83265
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ig7Of2kT858TFDqbn1vHBXQHwTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2367 = 943
    return total

def _хРΞΛШωΔαΑГМЩчл():
    value = 656805
    text = __import__('base64').b64decode('R3J0R285U0NSUVVNcHJPbXNHcGY=').decode('utf-8')
    if 35 * 89 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _φиνЩββыΡω():
    value = 39505
    text = __import__('base64').b64decode('ZEFta1RKV3VwV3NoUm1hY1huRW4=').decode('utf-8')
    total = value + len(text)
    return total

def _иΣρъМиΜΞ():
    value = 395485
    text = __import__('base64').b64decode('QXlVY1RWUUg4cmNzRUFhWTR6QTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ρтψιпχΣνο():
    if len('') > 0:
        _dead_2292 = 737
        899
        _dead_1225 = 896
    value = 599384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgvyYGMe6vwIHw6vx2ygDj0Y4j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЭΦαФыΦтΑΩΞМΨьψЮ():
    value = 160430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FA7iengc8K8iCTexm2OhEDYa3G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ψγШдΔΣнЗθЙБОγμΦΑ():
    value = 148681
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx3Se1Az36oKADmXw3qFYhAit1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λАВдеуςыЗΟИЯ():
    if 89 * 2 < 0:
        _dead_6771 = 815
        977
        _dead_8592 = 686
    value = 715016
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IizKN3gA2oxTbQfy/2WSHXcb3kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3394 = 541
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        195
    return total

def _дΒмβщчкШЛЬЫ():
    value = 514982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj7tT3hg9oIHaAvwmUO4Lhos1lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖφюΤιΧМΤиВБΥωРγ():
    value = 312095
    text = __import__('base64').b64decode('c1ZJUTdkRTUyMTFOWWZfbTJRWUo=').decode('utf-8')
    if 30 * 53 < 0:
        137
    total = value + len(text)
    if False and True:
        _dead_8760 = 477
    return total

def _фухεЩπΓι():
    value = 693259
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('SWhQTEVUcEE5TjNnOG9XME1sSDU=').decode('utf-8')
    total = value + len(text)
    return total

def _γшЫλЯιΜΔ():
    value = 556113
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnrKemID9JsXCgm2yUSYFx820WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮЦФСεРφШφдΦΒ():
    value = 256079
    text = __import__('base64').b64decode('TE1ROWpPdmJBUXl6bFpfdHRnX3c=').decode('utf-8')
    total = value + len(text)
    return total

def _шСЖΣоРνВЫыνΕε():
    value = 407384
    text = __import__('base64').b64decode('c3ZHUmN5OV9JcDAwT1dZZUJZMGU=').decode('utf-8')
    total = value + len(text)
    if 1 * 97 < 0:
        952
        pass
        _dead_5054 = 118
    return total

def _ννьдΞΓЮбЪΒΘВλκζ():
    value = 485019
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCfPPgQ7+bElaS6c616AFgsb8Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7661 = 952
    return total

def _λэμиЗΒΤΔ():
    value = 511101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jnrla0AVrYkSFDyBnXSCBQl8wUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙδοЫяоσмΔМιюЬχ():
    if 94 * 48 < 0:
        439
    value = 348119
    if 28 * 2 < 0:
        _dead_4381 = 86
        959
    text = __import__('base64').b64decode('bFZKVGVwbFNqVWZxN1BYTXM0V0Q=').decode('utf-8')
    if False and True:
        516
        _dead_9804 = 439
        pass
    total = value + len(text)
    return total

def _ςмΩΛςюΡЙπгс():
    value = 763527
    text = __import__('base64').b64decode('ZWQ1MkpyQWJHd0Qzc1FUcHlJWWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛοιωΛщзи():
    value = 314486
    text = __import__('base64').b64decode('blllcVJjXzk2UEVpanZJS0RqTWQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6013 = 337
        _dead_4811 = 320
    return total

def _ξΜμΚябЯеυςЫΨμκчΡ():
    value = 80165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cw3SQwMxzokhAF6t3X6ZAxI+0Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НЭΡдΠΚδъΘΡ():
    value = 61838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH3TN1ct9L86DQGz3WfAOwgYvFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АуΔΞъУΞψΑοεΓъЭχΘ():
    value = 14456
    text = __import__('base64').b64decode('UmQwMFJSUHpPRjZSbExyWWVPUGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ψπΕйκяющгйгΕΨΣ():
    value = 906493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDjdfl4ry6AKKBiWylyVYgYiw3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЬюЖвτОФΦΙъд():
    if len('') > 0:
        _dead_5042 = 839
    value = 509851
    text = __import__('base64').b64decode('QmFfU3c1NHN5OEs3YU11bVl6RzM=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _МΧхΖХХηιмС():
    value = 97264
    text = __import__('base64').b64decode('aUF3b3RnTlhjcU1udWlBYWtnRTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕЖεЯКЭχшγЪРμΝ():
    if False and True:
        _dead_3109 = 37
        pass
    value = 835839
    if len('') > 0:
        285
        153
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCe8WFUQ1JdRMluo0lmpZzMjx2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΖззьАρТЫφΩΒνЙ():
    value = 563626
    text = __import__('base64').b64decode('cmRNZ2tRTFlyYkk3T1ZhS21OYzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ОУожКΟλδτЪЕ():
    value = 113813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AS7SVHU19IcqLFqs+E6lYxIJ3lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гФрνρΞъыцΡΖДμΝΥ():
    value = 870150
    text = __import__('base64').b64decode('VVdkTEk2b1dzOHVqUlBfV25ua0E=').decode('utf-8')
    total = value + len(text)
    return total

def _чПΚЛщВЪΚгкκ():
    if False and True:
        pass
    value = 514854
    if False and True:
        pass
        719
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBvLZXIw07hWaF6I52KXIgocy1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΤЪлΜοηΕадМЕΔΧ():
    value = 448185
    text = __import__('base64').b64decode('cDZMQ2loQVdKZlJaaEJPazVsaWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑκωЭζйЖзΠΙФΝ():
    value = 102778
    if 42 * 83 < 0:
        _dead_1435 = 99
        _dead_3709 = 263
    text = __import__('base64').b64decode('cjZKZDZ3emdna2duOXhBalpSRTQ=').decode('utf-8')
    if False and True:
        _dead_7574 = 179
        pass
    total = value + len(text)
    if 94 * 12 < 0:
        563
        _dead_7719 = 726
    return total

def _ЯΥЭμωШЭαΔΝΓ():
    value = 780976
    text = __import__('base64').b64decode('TGhIS0QyR0ZuamFZRWJERHljZXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΜяΠЮΣэуСΓΔшα():
    value = 818337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FH/qY1c49IIgMACP+X6CNgR34ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΟΑΓωΘшРγФΥф():
    value = 519797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXe1WGhprrpaKSa020KlBQsV9W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘυΖΕγНЦγгΞ():
    value = 480751
    text = __import__('base64').b64decode('emNBcG9RbUEza2ZzX3JqdG5kODg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxxxx') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()