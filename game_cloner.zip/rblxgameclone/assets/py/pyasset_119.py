#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ιиЧΒХФцρЩГЙαмс():
    value = 298733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgbgX3wRy54EIieEzWCbPCl6sng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΨЗяОЯΟЧфчψП():
    value = 302015
    if 44 * 74 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3fKSXcVqZs0EwGS6nqjYnMi1VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒβαоμρЙУСИΞφΦνдι():
    value = 352222
    text = __import__('base64').b64decode('QzROcG1jU0xzbEpSelh0V0VCVWk=').decode('utf-8')
    total = value + len(text)
    return total

def _бцСУΒмчвЖи():
    if False and True:
        pass
        _dead_7644 = 875
    value = 143318
    if 40 * 78 < 0:
        356
    text = __import__('base64').b64decode('SGFETW9jQ01GT2xJZ1BKNTU2bmo=').decode('utf-8')
    total = value + len(text)
    return total

def _ГυдТЛΚЬΞи():
    if 40 * 26 < 0:
        pass
    value = 645604
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KibXaF8KzYQbLT2BmliEIRAC3X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫХфЮψжЧяςДВφО():
    value = 314682
    if 22 * 55 < 0:
        826
    text = __import__('base64').b64decode('UFpDX2t4NG8zeFVPWDM2aUpXWTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ωχБοΛΕЕσΓΙχфΖ():
    value = 123693
    text = __import__('base64').b64decode('a3dZSV9mRm44UUEzSlNmNDRkVmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _кωМфЕξΥΖΣΙн():
    if False and True:
        pass
        _dead_5306 = 456
        pass
    value = 941491
    text = __import__('base64').b64decode('QWY4QzlnWHBJTmFNOGY3aXcwbkE=').decode('utf-8')
    if 22 * 15 < 0:
        651
    total = value + len(text)
    if len('') > 0:
        _dead_9156 = 439
        _dead_8266 = 888
        pass
    return total

def _ЖωЯрΟтмλφ():
    value = 235835
    text = __import__('base64').b64decode('c2VEYkk4NkxnMHRYUnhJdDBqRF8=').decode('utf-8')
    if False and True:
        _dead_2374 = 887
        _dead_2115 = 153
    total = value + len(text)
    return total

def _ξΓОПюфГЯэ():
    value = 381300
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyvHV1oOy/wxPSKg8FmeIxAm4X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рРнвπьСъΡБσи():
    value = 481889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQrlY2k376xRIDWS5Xq8Y3EmtEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫчсхΡФСΕρфд():
    value = 541275
    if 17 * 71 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDjHRFg/75tUFQ6smGy2NjE+yGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СордγΩРшΨЫιЯυ():
    if False and True:
        pass
        319
    value = 106188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxnISwlszqIwI1yv4mOlHSwhyWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3852 = 563
        _dead_1322 = 951
    return total

def _фЬγιЮΚТфУΥΝπНВаΕ():
    if False and True:
        585
        9
        pass
    value = 770739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiTwdG4c84EgIgOE/mKdOxEE1Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8303 = 12
    return total

def _υЛйДЮуДНъΗИЕΛ():
    if len('') > 0:
        _dead_3291 = 735
        pass
        _dead_2041 = 829
    value = 50099
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA3bPmJgp4EMAxWA4X+SCw1+0Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮррτбТФΡρΝΟЙΛи():
    value = 194155
    text = __import__('base64').b64decode('WW9nYVd5dGsxT2NwNHhPQ042WXc=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if 16 * 55 < 0:
        43
        _dead_8717 = 873
        pass
    return total

def _цюΗцЙМΠМюτΣ():
    if len('') > 0:
        pass
        _dead_3504 = 801
        _dead_6897 = 823
    value = 165038
    text = __import__('base64').b64decode('Vm1vN3V0RVJVekRfZHdYd2VsZ0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΝγΗКтсЛ():
    value = 317844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAv3SkEJ76dRKSf3nWmoZhw+t3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΞшшЖТΔШΠ():
    value = 656894
    if len('') > 0:
        _dead_8566 = 65
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAfRRUY91q01CiyExneaJhY123Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3995 = 396
    total = value + len(text)
    return total

def _ΛБЧΜжΟΖκ():
    value = 983887
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACXLP1AMyroqGxW0mG+eHDd+7Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΜςΓΦωфЮΒβЭШЛΛΣ():
    value = 442419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQX+emEoy/oQaSem8QK0M3QCyFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡνοнΥбηиΥδτ():
    value = 604127
    text = __import__('base64').b64decode('c3ZETU1kWTJsZnZyUXY0Qk94ZFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ШаэЦΝχΤςз():
    value = 162625
    text = __import__('base64').b64decode('SE80WlRoYmZGcWZuZVUxWXVLTE8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        770
    return total

def _ΙгДΩεтатπСж():
    value = 591891
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXj8Rwcvxp4CCji72FKqBRE27Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮЯшβΗШΟγяГΛΟΦλ():
    value = 647446
    if 23 * 92 < 0:
        969
        pass
    text = __import__('base64').b64decode('UkJJUVU1NWFkdGdyc1JEd0RvTVI=').decode('utf-8')
    if 77 * 5 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЙρбСτЩτρЖнΟυδзУФ():
    if 79 * 59 < 0:
        _dead_8851 = 108
        pass
        938
    value = 900783
    text = __import__('base64').b64decode('QlZGNUFuZDZBTHNMQXVwUGxkTVg=').decode('utf-8')
    total = value + len(text)
    return total

def _νΣуψВТФдЯΘЪуΖь():
    value = 284534
    text = __import__('base64').b64decode('ekczenJ2U0Rqbkh4Ul9JNVJDV1Y=').decode('utf-8')
    total = value + len(text)
    if 13 * 100 < 0:
        pass
        511
        pass
    return total

def _τΘЗμκХΟаиρΖЦ():
    value = 810623
    text = __import__('base64').b64decode('YXJwTDBlX2Y5eldEejZoRk1KU2Q=').decode('utf-8')
    if len('') > 0:
        754
        _dead_6931 = 517
    total = value + len(text)
    return total

def _ЖИσТеЛΓшмЪЯсΨцР():
    value = 197884
    text = __import__('base64').b64decode('eGc5bTh3ZHZrYTg0akxTNUlZWHk=').decode('utf-8')
    total = value + len(text)
    return total

def _яцΡЙΓДяδбмКθ():
    if len('') > 0:
        pass
        pass
    value = 110289
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej/saV5t+qA0FwOwxmKdIRUbx2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 75 * 41 < 0:
        pass
    return total

def _ПФΔεΔБьλ():
    value = 730750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EH3dOV0Sqa8xOBag/2a+H3cuzl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        621
    total = value + len(text)
    return total

def _АεьйξУНΠЪυ():
    value = 411842
    if False and True:
        _dead_6673 = 450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTzXQUkd8JoILy3y8QeaFzYsx2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1558 = 357
        pass
    return total

def _ΦщΩЫσχчцζтτΦсэс():
    value = 613184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjv9ewFprfxUFSqLzFuGMScM91w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΞγЧДΓΔьΑ():
    value = 57153
    text = __import__('base64').b64decode('RnlpbXdNTjJkRnpyV2ZqVHBpUWk=').decode('utf-8')
    total = value + len(text)
    return total

def _зДНбйвΦνРΘ():
    if 70 * 50 < 0:
        761
        717
    value = 359818
    if False and True:
        589
        pass
        612
    text = __import__('base64').b64decode('ZVFJam9lcXphSmlfTzRoWVR2X1c=').decode('utf-8')
    total = value + len(text)
    return total

def _РΥТπΨΗХΒΠТСф():
    value = 78171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCzId2Mj6ZxQFCGq/G+nBzA96Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _исιЩЙШЗΘпПФксЭщ():
    value = 755504
    text = __import__('base64').b64decode('QXVvbkRMS3N1Uktnd28yVThEUV8=').decode('utf-8')
    if len('') > 0:
        478
        _dead_5791 = 143
        pass
    total = value + len(text)
    if 58 * 89 < 0:
        _dead_9197 = 794
        322
    return total

def _μьСятΥТψΞ():
    value = 787755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCjxeHhr1qoGKwH6/Qe5ATQb0UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιхДЗЯЫГъΩ():
    value = 31129
    if len('') > 0:
        pass
        _dead_2154 = 503
        _dead_4254 = 583
    text = __import__('base64').b64decode('Y3FtQ1NvUGtDUXB6TXJRU2tlc2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔжаΝΝςюΟΖБΘыу():
    if 72 * 58 < 0:
        _dead_5284 = 87
        _dead_5774 = 483
        980
    value = 665923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHfxO34N5P02EDqV/mSaLAcczVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        499
    return total

def _βЧюВΔЛδгγпЯΣгг():
    value = 763881
    text = __import__('base64').b64decode('UjNBY0lTVVJ1VzZwQm42VUJaR2M=').decode('utf-8')
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _РκхуХцРзХιбχξШο():
    if False and True:
        983
        pass
    value = 84619
    text = __import__('base64').b64decode('a2VtdlZBUFVMc1gwZ2RxRm5YWGE=').decode('utf-8')
    total = value + len(text)
    return total

def _йЯΝКдЧεЗЗсжΗчψЧ():
    value = 29306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQjDaVUL+KAxPjmLnlu3JAAAtGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜκшρПйбαηтΒцСΠ():
    value = 183515
    text = __import__('base64').b64decode('VEQyNFlYU0N0MDVyQ0o4SElxQzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧλγрΖФЯд():
    value = 858184
    text = __import__('base64').b64decode('aHhiNWw2Sk9RTV94azJuaVQ3RXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧсΦдιнЙчЦΖяβ():
    if len('') > 0:
        _dead_6912 = 784
        _dead_6351 = 500
        381
    value = 714277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyW2TWUy6ac0Pge06wKgLjd9wnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξБьπжрьΧρсСГд():
    value = 974459
    if False and True:
        651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AijpPwRq0a4rGA2wkGa/MnwE1kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыιΕγΚφъωЧμΛЬСц():
    value = 420253
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECjjdGRsxPk6Pxq2y12fIhQC3Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖτкσуШЫυΠΟК():
    value = 725293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQPyR2AK+IcqPheC7GmaCwh3sno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΝЕришΚРХчηΧиоο():
    value = 960055
    text = __import__('base64').b64decode('dkVfYXJLQlVHeFRpQjVISTc4RlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤбэΦШΜλδΝмФιГГΣу():
    if False and True:
        _dead_3170 = 695
    value = 355556
    text = __import__('base64').b64decode('VklMRm1GcjU0c1h2NVFIeFg0NFY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΞχЭЗЬбВЦ():
    value = 733240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQi0On0e2rxSaS2A+UeGOhoqxWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лЪбλυкΛΥЬШАυЪψ():
    if len('') > 0:
        644
        676
    value = 385908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB23RgBsrfpRaQCE2Ea9Zw4a1WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыХДчыоζЪΗАΙьжшΠу():
    value = 833035
    text = __import__('base64').b64decode('bXVpSzJPaVliOGZCZjBqX3c2dUU=').decode('utf-8')
    total = value + len(text)
    if 42 * 62 < 0:
        pass
        884
    return total

def _кЫЭτлРРΘЮбъЙψΑд():
    if False and True:
        pass
        195
        pass
    value = 577763
    text = __import__('base64').b64decode('aV9DTThEWXpRUEduWTlmU0Z2VWw=').decode('utf-8')
    if len('') > 0:
        762
        701
        _dead_7545 = 198
    total = value + len(text)
    return total

def _ΑμйΒκКэВСюя():
    value = 459276
    text = __import__('base64').b64decode('SW9SN0FadW5PUVVKWWxoNjdUNDQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        570
        _dead_1159 = 891
        668
    return total

def _ΧсКшψЬΣΤсТΥЕу():
    if 13 * 98 < 0:
        pass
        _dead_7989 = 58
        _dead_1611 = 608
    value = 539290
    text = __import__('base64').b64decode('aW1pN0Qxakt3WXh4XzdGbkFlSlA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        331
        pass
        114
    return total

def _ΠбΜНЦиБр():
    value = 629762
    text = __import__('base64').b64decode('Q1RzVjNpbUg1TW5WZ05faVhpdGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΔчМΚсжНωτΟА():
    value = 488611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiXMP0Ez06cRMjCbxFqnAAwusT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 94 * 65 < 0:
        448
        _dead_2250 = 303
        _dead_1548 = 469
    return total

def _дРОвБюπфΟБД():
    value = 125275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3jrbAMbxJoOPh+L51CoMjchs1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΩωчЕсвс():
    value = 13831
    text = __import__('base64').b64decode('cU5pYzBJSjk4Wlg4MnJGelJDeDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΛТΨУщΠυПВРΤΟг():
    value = 748726
    if False and True:
        625
        334
        _dead_1054 = 683
    text = __import__('base64').b64decode('SWN5WE4xYVdhTDVkQVdhNnhrQkg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        162
        _dead_7823 = 461
    return total

def _щндалгЖχσШΑΔнм():
    if len('') > 0:
        pass
    value = 160621
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kw7vY2403I4UYgGa2kSqCwIM/GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΧОΟтАБψуηЖδψш():
    value = 913492
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCjRWnwbqJcNEBy75UK5HgQctV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΑУуΒЫЙШЮΣηιЦцπО():
    value = 978905
    text = __import__('base64').b64decode('SHJ2VlBoX1RidzJJd3Z2ZENsdDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _мΧкΕΤΤжэМΑξΑΓФΨ():
    value = 841677
    if 26 * 68 < 0:
        _dead_3902 = 792
        54
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3+1OWUJ95suPSf0w0KhPwMd7js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7661 = 932
    return total

def _ΚΤηСЫфТςψΖΞχ():
    value = 349539
    text = __import__('base64').b64decode('ZzF6WFNzcm9iRnJia2lwNVd2Slg=').decode('utf-8')
    total = value + len(text)
    return total

def _бчРΠЗφΚΔюЪб():
    value = 227690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aw3hZmBh6LsnIl6X/UCpLgYq7E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖУжурмΞЙΟΒ():
    value = 2226
    text = __import__('base64').b64decode('b01pQ1BVNTZWT2J4NWlmUFBhVms=').decode('utf-8')
    total = value + len(text)
    return total

def _льΛтΥюиεшмΩл():
    value = 855544
    text = __import__('base64').b64decode('Tmh1WDN0a3d5WEZwY3Qxd3BiQUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ωКπаερηШОуζбχ():
    if len('') > 0:
        pass
        80
        _dead_4629 = 839
    value = 251659
    if 18 * 87 < 0:
        665
        _dead_6645 = 135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwHlf3Qj1oQbCR2PwWSGGzwHsj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πЪЧПΕΦЛρКΗΛЦУπхж():
    value = 120221
    if False and True:
        pass
        396
        436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NX7CSFU8+awkCgav6lK6Hn187UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΠαютИфλσоΤ():
    value = 942696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn/HaVQ98ftbLl333lKHMCQY41g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 59 < 0:
        972
        pass
    total = value + len(text)
    return total

def _οΗРλΧδЙЩΨΘαΥΛЫΚЫ():
    if len('') > 0:
        pass
        pass
        532
    value = 608539
    if 29 * 30 < 0:
        pass
        264
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lg7jRWc+/4Q2CCSX0gGpYhoV3Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        719
        777
    return total

def _ЮξЕΗДОΣКΑАьΗ():
    value = 717387
    text = __import__('base64').b64decode('ZEdMY3lONXg2Y1Z1cWdrMGxKRWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥвАИГжыанфЛлэб():
    if False and True:
        567
        _dead_8518 = 414
        _dead_1524 = 409
    value = 78724
    if 6 * 66 < 0:
        849
        949
        _dead_8212 = 593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS7BQEIrzv4vbFeS3WKmGXMuy2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΘΔσъФьЯΖЭЯЖΠΞ():
    value = 909890
    if len('') > 0:
        825
        704
        278
    text = __import__('base64').b64decode('SXZFcWI3Tm9SalBMNjNuakw0eks=').decode('utf-8')
    total = value + len(text)
    return total

def _ДМΗБЫХΖв():
    value = 711314
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kj63V3sq0bIgBRvxnXWBIwYsy3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΟфзΔηыφΡм():
    value = 729142
    text = __import__('base64').b64decode('aURndkVISDFoM0k1R2hIYnRyRFg=').decode('utf-8')
    if False and True:
        894
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _гкФМНнсρ():
    value = 840787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyT0Y0ZpyIc8FgqXkXnJIR0o1Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БсπЗιБβыΥωεи():
    if len('') > 0:
        pass
        pass
        pass
    value = 788793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBDle3YDzr0bLgOw5AeHMHAi1Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νЭЬЧΨйзεΠЗЕЮм():
    value = 541659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgznZV4B8IcuHyeL+kORDS130lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςмСпξΩтΓзΑкζК():
    if 68 * 12 < 0:
        62
        894
        _dead_7190 = 829
    value = 19206
    text = __import__('base64').b64decode('V1hnd1B3c3dmMExvN0M3a0ptdl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЖρзлЕМьΨЕиЗ():
    value = 703506
    if len('') > 0:
        14
        163
        pass
    text = __import__('base64').b64decode('STZSaVk3N0tKbnBXVjA4UWJWY0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟφΠюЪκΕЦΤβъ():
    value = 649988
    text = __import__('base64').b64decode('WHl1UlQ3aVZBSGllR1NGUzdRdms=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑпщρюχСδГ():
    value = 568316
    text = __import__('base64').b64decode('TkhQRUN6R21xcVlFaUdUampvQ3Y=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6106 = 372
        pass
    return total

def _ЙΞичкЮΕр():
    value = 496330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwPoO0URzZ41IgOEylnHMAcgs1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΔЮЯθφφЦ():
    value = 827824
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DS6yV1M1+LJVNh6W0AeSJD8dyWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мьΧБМЗμσΘΨУΦюΚυ():
    value = 57793
    text = __import__('base64').b64decode('aDJqVU5sajF3SjdfZklNWFVkTUc=').decode('utf-8')
    total = value + len(text)
    return total

def _акъПбЬШΔХЗΧ():
    if len('') > 0:
        _dead_3835 = 358
    value = 268700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LC3HTGkS76k6bgGZ52ehYDEg3ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 5 < 0:
        _dead_8171 = 513
        pass
        pass
    total = value + len(text)
    return total

def _χЛβДТΥψε():
    value = 47302
    if 45 * 83 < 0:
        969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgfTZHcDxowGEDWM7GKAES4e8E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 39 * 95 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _дЮΒЭиςΒΘнυЯοГюδΨ():
    if 85 * 22 < 0:
        188
        _dead_8605 = 593
        pass
    value = 427922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgnvQ1k+8f0bLSCc52+HGQAL6kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 62 < 0:
        pass
    total = value + len(text)
    return total

def _рΥСЮОфςиОМΓоΦ():
    value = 150447
    text = __import__('base64').b64decode('VFQyXzB2dXUzN2drV184M2FndGE=').decode('utf-8')
    total = value + len(text)
    return total

def _дЭΑКЫнниβъΑхρδ():
    value = 125770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NA6zSXwozI4lbyeF7EeyAQR93mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 40 < 0:
        347
    return total

def _ΝιλнЬпφΓфрвъВжЩА():
    value = 685768
    text = __import__('base64').b64decode('Qk1jaVk4SHlDamlreE1mRmlqUWs=').decode('utf-8')
    total = value + len(text)
    return total

def _кЭИΔιΒаΣφρ():
    if len('') > 0:
        pass
        751
        653
    value = 336678
    text = __import__('base64').b64decode('Qlp5RmNpSkpQd0NrYjZOd0thUWs=').decode('utf-8')
    total = value + len(text)
    return total

def _χΙΦηοЦρц():
    value = 672186
    text = __import__('base64').b64decode('R0RVcFVFMEw1WVZnWUNYSjdGVXg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        220
    return total

def _ΦξфΗОЦДХΜωΟλΠΠиу():
    value = 426831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBned2IT5pIEIC2Z+kejDhI17kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2885 = 795
        758
    total = value + len(text)
    return total

def _ΖуиτтИеКΝцВйыΜ():
    value = 623688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhfTWEg675wNEAuKngW4Mywkx3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 76 * 65 < 0:
        pass
        805
    total = value + len(text)
    if False and True:
        _dead_5974 = 60
        600
        833
    return total

def _Жшулεиог():
    value = 492023
    if False and True:
        pass
        _dead_3895 = 657
        182
    text = __import__('base64').b64decode('WHhKU0ZxeFZycUIzRkVtazYxWVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ДЪτлσЧыЮΨσΑ():
    value = 103457
    text = __import__('base64').b64decode('ckc0Vkl1dkRMZEFuUXh2b3hYcGI=').decode('utf-8')
    total = value + len(text)
    return total

def _θΒэΨЭσΧт():
    if len('') > 0:
        957
        pass
        870
    value = 501634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InnmRns05PwuKhiT5WO6MwN73Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8141 = 562
    return total

def _гБОюΦΜςПπεγЭУХЭω():
    value = 930733
    text = __import__('base64').b64decode('ZGMzUU5UU0luRHZoN2V3b293c24=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣφζτΙьΩРхΥ():
    value = 53168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzjJa1A7154Na1mZ2APHEQ4nykA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гПрзДИшοЕФ():
    value = 759475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MznoTUJq2rIiYj202XW1Px0Hs2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςμτΠьΠПщνΧωΝ():
    value = 728775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXnxRGVozaEFHiG0zmGkFxwdw2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧЫΔβеπгΩωγτ():
    value = 298394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HATWfnQ0qI1XOBy6kAGTBCcbxzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κфйЩнΑКыЯΞΗт():
    value = 208616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERDwOHc/8/kPbQa17VO/InIa4kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОФΩЖΨΑЪωАлΙЛсΛЦΠ():
    value = 842590
    text = __import__('base64').b64decode('UmJTa21sVUkybEtfTFNUN2VnNGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΜчлЗювяηлЛйъв():
    value = 735691
    if len('') > 0:
        _dead_5864 = 139
        pass
        721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSTTQX0S7vwiFBa6/nS0ByAN0mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6292 = 439
    return total

def _ЪлοКбΖΩТΙкΘ():
    if 93 * 30 < 0:
        122
        pass
    value = 180464
    if False and True:
        575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHvGeUhs6qIXCwiK32GaNRIgwX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1667 = 377
    return total

def _νΠЧΟтВβπΧοЧЪДκ():
    if len('') > 0:
        _dead_2692 = 478
        pass
        pass
    value = 665268
    text = __import__('base64').b64decode('cnRXUFM5RGFseFkzd0hkR0ViRVM=').decode('utf-8')
    total = value + len(text)
    return total

def _РйЧЙиПАъДΧΗεЧВΔΦ():
    value = 864027
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn3HOH8Ox608Ii71xkSqPAAu6Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υуЕеΣЛΩшβοЯζД():
    value = 213395
    text = __import__('base64').b64decode('VVl3RDlIS2dSYTlOSVNoTWJkUzc=').decode('utf-8')
    total = value + len(text)
    return total

def _КΥУЗТиСуκЫхΖзΩ():
    value = 231585
    text = __import__('base64').b64decode('QlJXTGI5a3p3Snh2b1MwajJPQW0=').decode('utf-8')
    total = value + len(text)
    return total

def _φΧЛЙΘΣλхпπΦ():
    value = 25172
    text = __import__('base64').b64decode('eXNCSVRWNUk2VFZadjhaeHpHMG8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ФЧηэλΣζТτчυΧШΦιΞ():
    value = 669712
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDjhWUYA/KkJGyCW8gKVBXAiyzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γбитУΩщЭ():
    value = 757446
    text = __import__('base64').b64decode('S1d2d1k4TWEya01QdVltbmJLaUE=').decode('utf-8')
    total = value + len(text)
    if 63 * 6 < 0:
        _dead_5399 = 650
    return total

def _ЫκЖКΗАΚε():
    value = 16004
    text = __import__('base64').b64decode('UUNpekphSzNidnRtaFBnNlAwaEE=').decode('utf-8')
    total = value + len(text)
    return total

def _МчГνжвΩнςΨφ():
    if len('') > 0:
        847
    value = 650273
    if False and True:
        _dead_8604 = 432
        pass
    text = __import__('base64').b64decode('c2g4UkdNam93RWRwYzVyb3lJTDE=').decode('utf-8')
    total = value + len(text)
    return total

def _УΕььфМЦМЛ():
    value = 766755
    text = __import__('base64').b64decode('Q250ZWFWcE5IN2R4RTkxSDRpbGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЭкΡΕйЙЖ():
    if False and True:
        571
        pass
    value = 770304
    text = __import__('base64').b64decode('bE0wMk1RaVREYUtQUWE4QkVKVl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝυУЦЫνΖξЫцрοцтСφ():
    value = 378274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PC3HYUsR8IRTGTnzymaEMCs50Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 66 * 93 < 0:
        _dead_1009 = 807
        pass
        548
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _γяιБμτцυΡщЕΠШа():
    value = 235932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHzNR2gS/fkibxql5mHEbQkW4n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΧкбиΓЬСυБχ():
    value = 373160
    if 70 * 16 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID/KfFkLzr8gNz773AS3PgQCvGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χфЬΟПΥЧиΟεΒФд():
    value = 203222
    if 84 * 38 < 0:
        pass
    text = __import__('base64').b64decode('UHJUYWJLdkNVYVZad0I1R0xUVVQ=').decode('utf-8')
    total = value + len(text)
    if 69 * 100 < 0:
        _dead_5996 = 291
    return total

def _ΡюЬОψαδΩΤΟα():
    value = 506945
    text = __import__('base64').b64decode('YXpkc1RFMkRBeFdZZThObmpKblQ=').decode('utf-8')
    total = value + len(text)
    return total

def _лУНΣяΥхъукЙο():
    value = 341629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD2za1kM8rI5DD6pkA6JGxMCwXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зшψДУгφΥχβ():
    value = 78239
    text = __import__('base64').b64decode('Rnh4VGdGV0RxZXF2c0ZoTjBsYmI=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЙЛтЩцНΝςΕгΝхξз():
    if False and True:
        pass
        pass
    value = 605908
    if False and True:
        493
        pass
    text = __import__('base64').b64decode('R3Z4RjlFM3JZV2VJTHhUNHltczg=').decode('utf-8')
    total = value + len(text)
    return total

def _βωЩΕдЖВΙх():
    value = 543369
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('dG00VFVUbnJ4SXFYQUlmZU5TbGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ъГЫβωИЯГΜф():
    value = 902171
    text = __import__('base64').b64decode('Q2V5OThQQ0xjaWUxRlRGbHhPMEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚεηΝςΜογΥгеιшΣзΞ():
    value = 134756
    text = __import__('base64').b64decode('Q3pMMVFWUjBsUGdCWXFsQ2xpdmk=').decode('utf-8')
    if 41 * 47 < 0:
        _dead_7969 = 931
    total = value + len(text)
    if 63 * 66 < 0:
        pass
        pass
        _dead_3902 = 162
    return total

def _ксνдΩЗВΑмογф():
    value = 832125
    text = __import__('base64').b64decode('WFlKaTM5VWE3UkVwRlBiRnpCMEM=').decode('utf-8')
    if 93 * 83 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΕΥюШТМхУΩΩοЮΕη():
    if 66 * 59 < 0:
        698
    value = 349399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBizfAAQ5KVUGVa3mg+GPSsI/Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 30 < 0:
        pass
        _dead_8798 = 609
    total = value + len(text)
    if 90 * 15 < 0:
        _dead_2014 = 346
        pass
    return total

def _χΙεψщСЕπΚЯкъС():
    value = 407029
    text = __import__('base64').b64decode('Z3hJNF80b0tVbmprbkhjc0VLZHY=').decode('utf-8')
    if len('') > 0:
        858
        _dead_2790 = 288
    total = value + len(text)
    return total

def _ΥрΗяХЬвжугиηЯе():
    value = 498043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAjjfVc65J47EgGS8FqpZ3F8zV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΞдШΗσЭЦЙ():
    value = 479814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCC1NkM/qPEqLiWL/FybEwYe7lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΨΖМЗЬΨЦλДЦΔΚьΡΞ():
    value = 202019
    text = __import__('base64').b64decode('bTlBYnZWV2VJbmYwZjJUX1dwZmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ъМΞκΧςРυπКъλ():
    value = 415882
    if 10 * 67 < 0:
        _dead_2306 = 653
        _dead_8129 = 831
        _dead_4076 = 36
    text = __import__('base64').b64decode('aGxQRDZzWWZUaTd6bVR3VWFmbWc=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 3 * 31 < 0:
        859
    return total

def _ЛмджΧвцЭХχΟΑνΖчΛ():
    value = 259319
    if False and True:
        pass
        859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSTwRlw3qKw3BQSHm2W7HCAYyDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 31 * 21 < 0:
        _dead_6750 = 370
    return total

def _ηчΟМΡσΛμбΖ():
    value = 113738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRbmO1Q/q70SMSb6zF2gDAQ86X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔнρЧΠбφЮ():
    value = 872800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw3HdGca0q1UNTv6m1qRFgAGx2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СуτкИΞδψ():
    value = 959933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwnNSWA0xos1GAWi+3fEHDEl1Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЪΤеλЪяηДΖΨγСФΩф():
    value = 228898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyLsPHcDyfk3OVz75HKXCxQutFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζχνпбЫвк():
    value = 126004
    text = __import__('base64').b64decode('T2o4TUhjWUI5aTlfdVhHYlhxRWU=').decode('utf-8')
    total = value + len(text)
    return total

def _τΟГΣΝСЮε():
    value = 912508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTvFXVAp6fkGE1euwAKJExMl/Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_2710 = 364
    return total

def _ЦуэКψΠВНΜΒЙКΑνФЭ():
    value = 786400
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSnbPHAU0adWCD6PxHOVGAQcwEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫбМΞΦΙбπАъφи():
    value = 315002
    text = __import__('base64').b64decode('bk81QnlmTW5OQThwYlVCTTltWVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭиТЮзΩеςхΛХМκоЧσ():
    value = 698860
    text = __import__('base64').b64decode('TkpWMzNXeE9oNHJuckF0YkRBcDE=').decode('utf-8')
    total = value + len(text)
    return total

def _τΧοΔТςфΧГЧьκωΨщ():
    value = 435928
    text = __import__('base64').b64decode('WVd0VG1rUF9YZ2FSNzR3OFBkWDc=').decode('utf-8')
    total = value + len(text)
    return total

def _яЬΘΖиςυΨн():
    value = 360507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cg7ceEFt0KIEEl2B2FSoEisO3j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЦЦсΝБъχюЕДФΥρΘμ():
    value = 127279
    text = __import__('base64').b64decode('dGtUYk5Wb3BWU254aWY2S3lRV1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ыЙГхоИΤςлфτЛэΟΩ():
    value = 51177
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjXUOl0+9pAVKweR6XuGNSk+3kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6072 = 111
    total = value + len(text)
    return total

def _ЙКищПΨТЦШ():
    value = 959839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQG3T3lrz48AIl+pz3qdOQkd3Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 87 * 59 < 0:
        _dead_9444 = 806
    total = value + len(text)
    return total

def _ЪНΝЧеыθΨЭШд():
    if False and True:
        815
        pass
    value = 382452
    text = __import__('base64').b64decode('SUFnY05JM09yemJCS3N3cWtMZWE=').decode('utf-8')
    if False and True:
        _dead_2943 = 527
        pass
    total = value + len(text)
    return total

def _οЧчпΥНоЦΟΖνχ():
    if 72 * 9 < 0:
        pass
        213
    value = 259606
    if 31 * 79 < 0:
        _dead_6636 = 931
        _dead_7811 = 819
        _dead_4370 = 46
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT/NWXcUzL9WNSGF8U6oYS9/1mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 70 * 87 < 0:
        pass
        498
        22
    return total

def _юВжРΟюаг():
    value = 594269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQDsVmkXxvw3Yh+V2GaHICIa3FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        543
        914
    return total

def _ЧΞδΘωйΕЖтΒαиυ():
    value = 813404
    text = __import__('base64').b64decode('UmlCQzNzUmlUdDlSUDJUWmZDTDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠГΓδЮλнЮπЛжпΕГβ():
    if False and True:
        pass
    value = 341452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB3+d1NpyaA5NAKN63mDDS8B4EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВξЫγЪνσωЗИЯΛζКе():
    value = 636068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxrnY3Vg/6EBMSuCzGC4AScA3ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        851
    return total

def _ΣсΨμЗВймθяμъФЯч():
    value = 437947
    text = __import__('base64').b64decode('bVFTOXg4YjVvVUVqbjZRbGNqS1A=').decode('utf-8')
    if len('') > 0:
        282
    total = value + len(text)
    if False and True:
        _dead_4995 = 882
        _dead_9272 = 135
    return total

def _ЕΓКафηΚмΕ():
    if False and True:
        _dead_2155 = 916
    value = 426940
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXbMfFw8/PgUGwPym2+mJzEQtmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        631
        _dead_7564 = 598
    return total

def _УШΠЫνцЖΘСθΙа():
    value = 977982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQ7sTGMd07gyAz+28AK5LTR/yTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧкνιΧнЧкΒΧШΦОξ():
    value = 861143
    text = __import__('base64').b64decode('ZmxMRmF2aWxoSDgzcnZ4d0owckI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤАзкΣшРΚХΣьιКдΜб():
    value = 267052
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EArzYmAd0P8zBVup+mSYGHMu52s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΕβфΙцебЖКαс():
    value = 281721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EijwVFQDqf8WbheizwHGLDwg/m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΛεκзчгГ():
    value = 305419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MArof11uyI0UHg2SnXjHEzwXtl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        461
        659
        241
    total = value + len(text)
    return total

def _еΥХΨξхΑεейΓινяя():
    value = 900493
    text = __import__('base64').b64decode('VUZ1d2ttRllyTlhwZzZiYUU1ekw=').decode('utf-8')
    total = value + len(text)
    return total

def _уАΕЙэвΛЙсΤМУЫНуθ():
    if 33 * 87 < 0:
        pass
        359
    value = 641620
    text = __import__('base64').b64decode('SG5XV3JIVTNRRTlSN1NfNUxoZVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _зβЯьШЪωιααΣωΕядξ():
    value = 864723
    text = __import__('base64').b64decode('dmVxQVRmdTFCSmR4cWEwdDhkOG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥмЖэйШюлыЩФΙ():
    value = 338192
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTnbSQEo5IUOIiml0mW2ECEE20c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сμЕГбΤοгЭΛσо():
    value = 700116
    text = __import__('base64').b64decode('UHlTdFB4N3JaSlBJOXFQWFlFc00=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦТγΔЯνξλΗΨК():
    value = 560928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSPsO1sP0YQrKliu42CKbHcj11k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГαОСψяηу():
    value = 660265
    text = __import__('base64').b64decode('U3dGeW9oV1hjMkNVVEFrQ3NZcU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜияпιλтДξцхФΤЗ():
    if 13 * 73 < 0:
        648
    value = 613860
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K33UT1gT5r0NCwO6nWyaEx8Es3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΧΞхςвТсиЧя():
    if False and True:
        _dead_2175 = 954
    value = 227399
    if 30 * 67 < 0:
        pass
    text = __import__('base64').b64decode('UUxRYktuM1ZRcndLX01idVJFVE8=').decode('utf-8')
    if 86 * 44 < 0:
        pass
        899
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5709 = 978
    return total

def _ΙιΔΦЙΖбюυΙШσΤ():
    value = 494240
    text = __import__('base64').b64decode('WDFDN0pjZGMzNzJEdElVVERlOHk=').decode('utf-8')
    total = value + len(text)
    return total

def _уΔшфнΝιаψΘС():
    value = 240583
    text = __import__('base64').b64decode('TmRheEhJV1ZsMjR5anVfSWpPVm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЛχТяΟЗмΔτЫЙΙ():
    if 83 * 14 < 0:
        475
        523
        _dead_1820 = 907
    value = 878573
    if len('') > 0:
        _dead_1891 = 706
    text = __import__('base64').b64decode('bF9PWkdmWFdiWnZnZlRRQUkzaTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬсΔУхΛυυ():
    value = 736173
    text = __import__('base64').b64decode('S3d4QWp1T2NxT1JnaVlRSHBleEQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2560 = 853
    return total

def _ζЮΔΚулτΤЬ():
    value = 113645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwvNakcB6qswFxqln1uUYHEf/H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΓчαΤυЦχγ():
    value = 244368
    if False and True:
        _dead_4329 = 201
        863
        _dead_6410 = 293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwLeZFgVyvtWaxeX4ATENgY4w34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1069 = 775
        161
        544
    return total

def _гλЛОΘΕХфЦХ():
    value = 827281
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR78Sgcp0v4LHBiyykKRABoutDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        228
        pass
    total = value + len(text)
    if 17 * 99 < 0:
        _dead_3836 = 155
        _dead_6102 = 284
    return total

def _ΔоЭШЫИπжыΕμ():
    value = 257695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHzFW0Zgx6YEDh6n5QOkNjcJz1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        620
    total = value + len(text)
    if len('') > 0:
        _dead_1504 = 220
        343
    return total

def _ΩьБКОУЙςζлйН():
    value = 750503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwnsZHdpqKQCDAKP8QKJZS4Yw2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фεФΨЭрΩуΞЭбЯщγ():
    value = 465593
    if len('') > 0:
        _dead_5986 = 305
    text = __import__('base64').b64decode('aExpWUluOGpMX2lxeU1LS0FnWEI=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΤΚΞщΑνωшЭΝВхΑσ():
    value = 718187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxzleGY2/awBElm00nO0HQF491Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨμυюдθэЩθГдΕжБ():
    value = 994010
    text = __import__('base64').b64decode('VHE1N2doY24za2Y2Q0JqUXM3UUs=').decode('utf-8')
    total = value + len(text)
    return total

def _γюьэНΠμηκΥμΨЯΒ():
    value = 103116
    text = __import__('base64').b64decode('angzREtXUUdBWnp3clBxUGIxM3E=').decode('utf-8')
    total = value + len(text)
    return total

def _фКЛКΩДωКпτьбФΝн():
    value = 731136
    text = __import__('base64').b64decode('bWxNZlJSRHJLM2NzYVk4TFFucng=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦГшлДрΩцδ():
    value = 160797
    text = __import__('base64').b64decode('UThVbDNRRzY3RlY1N2YzV2hsSEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ιюнаНЗΕΦ():
    value = 337714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX3JXXwW8ZEtYh6L20OJEwQH9n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сзГΔссдЯρЛ():
    value = 580169
    if False and True:
        _dead_1518 = 523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BizGbXMN9qE2NCq0nGCSLC8d6zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_5500 = 743
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if 53 * 99 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 64 * 36 < 0:
    _dead_4049 = 903
    pass
    _dead_2875 = 29