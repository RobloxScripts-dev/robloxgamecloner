#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΕπООкΔнЖлΧΗЬρμПТ():
    value = 217452
    if 67 * 76 < 0:
        330
        _dead_9679 = 18
    text = __import__('base64').b64decode('RzdYbkVEU0E3Mk40VmN2dF9uQlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _δнЪφιοрυβЯνντКюν():
    value = 105867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSXFT0QhxPEBbg6G5GWDMAs2wGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣνΣθΩζкΜΟΨСφь():
    if len('') > 0:
        281
    value = 487743
    if 4 * 91 < 0:
        188
        _dead_7320 = 303
        _dead_4412 = 269
    text = __import__('base64').b64decode('VUdHNEFxWXJPOWpqUHlkSTNEWlk=').decode('utf-8')
    total = value + len(text)
    return total

def _διцθЕИμэБ():
    value = 985841
    text = __import__('base64').b64decode('dzJXd0VWdW5aYWtMTHFwX1RVV1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦБνАιωοδНαψ():
    value = 221892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBbWTFNgqKkiOTyBz2+cCzAK0WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫуфуβьΚОοо():
    value = 836040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NC2xZngN/ZAzFF2y0mKfNhoNsUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εеΠνπΚфЬмρρКΙмюΜ():
    value = 223116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERztPnID6owVEAGF/HrCGy44zjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лРдКиχΥΨιδυ():
    value = 266807
    text = __import__('base64').b64decode('clkzS3hHWEc1ZjdPZTl2VkxnWDM=').decode('utf-8')
    total = value + len(text)
    return total

def _χМЫηбςεщοУцξ():
    value = 649997
    text = __import__('base64').b64decode('eXZ3bUljUno0S1JkdTNDVGMxMXM=').decode('utf-8')
    total = value + len(text)
    return total

def _γΜΗФйуξЕοУξ():
    value = 163259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InjybFoG040SbCmEykyUJRwY83Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κсУυΔΟκуΔφРе():
    value = 272469
    text = __import__('base64').b64decode('cExtdDNfVFl2WEdCSjFKd1N0VHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕρсяΔМлшδф():
    value = 912724
    text = __import__('base64').b64decode('d2duTXJQWkluRml6SkRiWVF3aXY=').decode('utf-8')
    if False and True:
        _dead_4344 = 692
        317
        25
    total = value + len(text)
    return total

def _ηуЛΝжъьЪНХΦХφ():
    value = 112810
    text = __import__('base64').b64decode('Q2lKOGI4ZWNIeGpwV0ZPUjdfd1g=').decode('utf-8')
    total = value + len(text)
    return total

def _рФТЕΠΚРλЖΖιΙ():
    value = 259122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT3gYwQQ1rsEIle73nfBPhw67Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΛУИЙэИХЗΟъДцз():
    value = 129479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyrnV2YI76oVKRmb/kWIYS4ZwmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7932 = 269
        _dead_8534 = 912
    return total

def _ЛЬжКЕнκФКмо():
    value = 509484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Knf2Slkj77pQI1mAmm+xbS8l3mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВМюυЛτΘΝьЫБΜъΨЛγ():
    value = 645291
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRjUdgQ6rfgMDBXy63KiBjwa/V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        542
        pass
    return total

def _ПбΕΜΗΣШΑЕГслψ():
    if len('') > 0:
        pass
    value = 814439
    if 44 * 39 < 0:
        266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRqwe0Bo9v8tFB+HmFiCAj0ltT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τЯυЦΒΝдИ():
    value = 206703
    text = __import__('base64').b64decode('VDllbkVJZzJSMzZiSTdTbGJ2MUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЕΘПвЪΩеγ():
    value = 116741
    if False and True:
        _dead_1578 = 435
        729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwjsXEcT8KpbCCmU3nmgDH0c7H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_4816 = 708
        _dead_2109 = 160
    return total

def _НПΤЭЮшИз():
    value = 96777
    text = __import__('base64').b64decode('dmVfVktybUkyV25tS0RuMnhHN1o=').decode('utf-8')
    total = value + len(text)
    return total

def _γЖКЩηΡршИлВщφΓΔ():
    if False and True:
        pass
    value = 521060
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjXyWGUwzIkEMSClnXqBHRUX1WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αкΞτΗΣюθΛΕмФΝОλМ():
    value = 104489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTrURHAM2asqbyWFxFGkFwYb3GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 29 < 0:
        97
        pass
    return total

def _ΖςэαΨΔηΡтъ():
    value = 781598
    text = __import__('base64').b64decode('cER6M1ZkcUgzYnlrdXV0OENxQ0Q=').decode('utf-8')
    if False and True:
        _dead_4083 = 549
        pass
    total = value + len(text)
    if 75 * 9 < 0:
        619
        pass
    return total

def _σЭχΒΑлΖбεНп():
    value = 845345
    text = __import__('base64').b64decode('TmVwV1pzRldXUTBqRHJ4eldrcHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖрγΡδЗэюφΨηмуХ():
    value = 200168
    text = __import__('base64').b64decode('WXRTZnkzck40S2k2UkNTUjk1MWc=').decode('utf-8')
    total = value + len(text)
    return total

def _УμЖΞЪдмчρГгТхΟЗъ():
    value = 446474
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NirNP1cj/70BEC6Rw2OlBTcIy2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΙΩМхμωЯННЛФ():
    value = 482570
    text = __import__('base64').b64decode('TmJRNmNZWm5YYkx0cWlOOWVhNGc=').decode('utf-8')
    if 25 * 44 < 0:
        pass
        883
    total = value + len(text)
    if False and True:
        _dead_3536 = 338
    return total

def _бЕΦΡФГλиΘΤ():
    value = 765171
    text = __import__('base64').b64decode('QXlBM1lqNHlQeElqTHExaEhsTzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦνюСυФЯтΚ():
    value = 510990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3zoaloa5plQOwW7/UyRMXwt21w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΔαоΙВЯБвЩΝαωЫεэ():
    if 45 * 67 < 0:
        pass
    value = 302869
    text = __import__('base64').b64decode('UFFlcXA1MEZZRXZJYklqb3hjSnk=').decode('utf-8')
    total = value + len(text)
    return total

def _оμδΞπβщΗΟМлкαΜэ():
    if False and True:
        _dead_6548 = 583
        772
        _dead_5592 = 963
    value = 412853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAGyRlIR8P46FADw4FmAAgQX0GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вооеΗωпЗψΖβαΑч():
    if False and True:
        _dead_7307 = 482
    value = 798843
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3m3dHQD5401FBax7gaFPDcFxWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чτοΗΣβιДиεΘДΘ():
    value = 891613
    text = __import__('base64').b64decode('ZUxfS05OcHM0VUZBeEhwcXJGRlI=').decode('utf-8')
    if 7 * 53 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_5950 = 798
    return total

def _ыΨуЩηΠШΝΔККρль():
    if False and True:
        498
        387
    value = 737362
    text = __import__('base64').b64decode('SXdsQWtPZWU0MHNRWjFtS3FIUko=').decode('utf-8')
    total = value + len(text)
    return total

def _иЮΙеδЗсψэМп():
    value = 587225
    text = __import__('base64').b64decode('ZkdWZHNnUkJZMktjUThJVTFYWEg=').decode('utf-8')
    if 32 * 32 < 0:
        _dead_9617 = 757
        161
    total = value + len(text)
    return total

def _ΠχМдΓΨЬЯδΖΛКтκ():
    value = 786441
    if False and True:
        312
        214
    text = __import__('base64').b64decode('cGU5S0lIVVVvb1VTSkl4bWhlTF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΒζЮΤπΥЪγ():
    value = 997867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnbKO1oX5/8kCTCS/gDGMRo+tF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦЭΝУЛЫытЩΤ():
    if False and True:
        _dead_4801 = 740
    value = 301366
    text = __import__('base64').b64decode('eFhTbEVSYUNBX2h4Q3F5RzVCdkc=').decode('utf-8')
    if 46 * 15 < 0:
        604
    total = value + len(text)
    return total

def _ΤжακтщжφΘ():
    if len('') > 0:
        pass
    value = 712875
    text = __import__('base64').b64decode('Wl9QaHZfdGZYNXczQnBZZnlHQmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕМσнюυΡΘшсбΣЪгΥ():
    value = 420332
    text = __import__('base64').b64decode('akFfMmh0QkgxbUdZeXZrTko1Vzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞлωтΠЙΤζоеЭ():
    value = 210393
    text = __import__('base64').b64decode('aUc2d3o1ZnNqVlVoV3NMVmV1SnA=').decode('utf-8')
    total = value + len(text)
    return total

def _βЖЦζΖдΞΣпСмγ():
    value = 935060
    text = __import__('base64').b64decode('ZlBKcTBwVm9IOW1JdkNnSGNFb2Q=').decode('utf-8')
    if False and True:
        505
        203
        pass
    total = value + len(text)
    if 82 * 44 < 0:
        99
    return total

def _ьΛΨяНщΝБЙ():
    if 87 * 10 < 0:
        pass
        pass
        981
    value = 963475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBfFemc99ZpUAiWI+G7BIzwDsWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        364
    return total

def _щΕφШΡмΩмΣЩОμъυТ():
    value = 560635
    text = __import__('base64').b64decode('WG0zeVh4eTRSdXkwU3ltMzNPeTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _θьЫουψΘιΓ():
    value = 544457
    text = __import__('base64').b64decode('TXg3cE04VWlHU3FpVnhOOUQ1cEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑκνыИιΣΟфυρΣΔε():
    if 90 * 92 < 0:
        _dead_9301 = 486
    value = 853841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED/vYls21v5TPCi6mUe2Bgkey0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        897
        352
    return total

def _ωрΧрФιыΒСМ():
    value = 797069
    text = __import__('base64').b64decode('V1BrX0p2RkJERmV6b3NSUnFQc0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪРνΛЩΦΕнΚмЪΡЬαΓΨ():
    value = 239482
    text = __import__('base64').b64decode('Wjc1enNOOXEwdWlqekpHbUd0NEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ζчΛзЮщфК():
    value = 19133
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ND79e2IW5KcgLwe5wAC2AhEl7DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 11 * 3 < 0:
        pass
        970
        pass
    total = value + len(text)
    return total

def _кοшХτΣИΤВФЪ():
    value = 397322
    text = __import__('base64').b64decode('ZGdudEpPdkl1bTdCRXdvUkV3dVU=').decode('utf-8')
    total = value + len(text)
    return total

def _тсЙαΗΑηьцΚрΛМ():
    value = 102740
    text = __import__('base64').b64decode('dVhvY0VrTUxfeHZXY1N6VThuRWY=').decode('utf-8')
    total = value + len(text)
    return total

def _БэзЙзΠЯΚпйΝκΟпж():
    value = 300977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID/APwJqwYM7PSKLyljBGwYZvUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыпξΗпрдчШцξНσщЫ():
    value = 765244
    text = __import__('base64').b64decode('aHhjeHZhVkwwVE82WnZhSXBVaWM=').decode('utf-8')
    total = value + len(text)
    if 21 * 66 < 0:
        _dead_2058 = 466
    return total

def _ЖУФиΚяΕяΠι():
    if len('') > 0:
        pass
        pass
        _dead_3453 = 460
    value = 79619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njz+TARu2bsLKxWy3kTEIgMhs0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_7984 = 57
    total = value + len(text)
    if False and True:
        pass
        191
    return total

def _πаГΠλοΝьнΞрαзУ():
    value = 153474
    if 55 * 56 < 0:
        pass
        552
        pass
    text = __import__('base64').b64decode('aTNHMndScDRaTHJfVzVGV0JhNVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ВЯΚξμЭВπΩΦвпπЗ():
    value = 892213
    if len('') > 0:
        289
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSflXlY11aMmHCa22mOSFi9+40o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        983
        pass
        _dead_3643 = 257
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4720 = 609
        _dead_3235 = 651
    return total

def _ЛЯЛδОηдαωΨЭи():
    value = 924233
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cz3PPmMx34o1ECa04FWgFzIfx0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3983 = 813
        _dead_4333 = 268
    total = value + len(text)
    return total

def _ζΦΨεДΒΒγηДσ():
    value = 870164
    text = __import__('base64').b64decode('Uk85RzdMNkhDZjBSTDIzRVZ1Y00=').decode('utf-8')
    total = value + len(text)
    return total

def _АΣЪαχПξΤкЙΜГΓЦρ():
    value = 709702
    text = __import__('base64').b64decode('cnNaWFV0NjlhemV4Q1lWcEV1RHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠкЖЖΠНЖыΞЦиΑπωу():
    value = 780024
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzzXWWAS2YE8DDiBnGCfNyAh00M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        51
    total = value + len(text)
    return total

def _сегКЩδфλσλμТ():
    value = 212592
    text = __import__('base64').b64decode('R2NkVEVhTXEwT0RYMUFfQVowcUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦЯсШчΟλнΒ():
    value = 486556
    text = __import__('base64').b64decode('emQyRk0yN3BFN0VmSm9YUjljRUQ=').decode('utf-8')
    if 38 * 74 < 0:
        41
        _dead_1239 = 454
        19
    total = value + len(text)
    return total

def _ΑЕйгЧфчЕъν():
    value = 36201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH/NeGRu/7FWAzmHn2m/EHIus1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οцйΒΙкζезΑ():
    value = 82629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgnceFYy0KoFNTCE4HSYAnIs0lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬаλδωΠμΑφνΩ():
    value = 493623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgruOgcRprpbPRiv41W2JjIX7jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мдЩМΨЭЗΞЛ():
    value = 640484
    if False and True:
        pass
        _dead_2959 = 672
        pass
    text = __import__('base64').b64decode('V2Z1d2N1WDB3ajdrX2dpVjVtelM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7213 = 231
    return total

def _бЩΘΣтηαКтуπχЙР():
    if False and True:
        40
        2
    value = 302919
    if 19 * 26 < 0:
        995
        pass
        210
    text = __import__('base64').b64decode('enNTTHEyT1Y5amRoWjloeVB4aVI=').decode('utf-8')
    total = value + len(text)
    return total

def _γβшАтθφιαшГЮΒΛωε():
    if 81 * 68 < 0:
        _dead_1201 = 648
        _dead_1703 = 13
    value = 553968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDjqPmsT+o5QFRqB6QKUNwoe420='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΩчιςΡζδκ():
    value = 671453
    text = __import__('base64').b64decode('V2hjZ0NCamt4UlhLWHlJRl91Ujg=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΦХеΙαΘεойМЮ():
    value = 570607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fj+8aEBs0YwZLQHzzAS8Aiom3jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_4951 = 417
        705
    return total

def _ΛΝЬΧЫыΠМΛГЪ():
    value = 854299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSSwYGUB5IEwEwq28kGiI3c94zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΞМΨчЮчъгЫуА():
    value = 623154
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCPKZkQu0voxGSrz3EGzGT8VvEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑШЫΣΝΞщΚδΝοй():
    value = 812911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQrPZHct/JxTPj+U6gO8PyoctGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        154
        pass
        _dead_6650 = 879
    return total

def _ΗИνθΔΦхΗΘБυΜ():
    if False and True:
        pass
    value = 28063
    text = __import__('base64').b64decode('YlZlcExPVmhCcUtrMXhLQjVJaUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΑзыΒжЪιш():
    value = 898912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAbDbHs/zJgAGRagyQ+fLjACyFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _иΖΣБΑδЯЛ():
    value = 307325
    text = __import__('base64').b64decode('RXhESTFOcWZ2bHk3RzZINFBaM2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ФсцΝфΘтι():
    value = 726155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHrhTQdg+q0NCySEx3q0Ay4Qw0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4832 = 453
        pass
        _dead_3776 = 732
    total = value + len(text)
    if False and True:
        460
    return total

def _уΗΨΖьуΜΩΘ():
    value = 793758
    if len('') > 0:
        pass
        _dead_3157 = 415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiLRfXJs1LEtFSO0zVKCJgggwH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        629
        pass
        587
    total = value + len(text)
    return total

def _аΧвЬΨчυИЧβΤЖюΧн():
    if len('') > 0:
        618
        pass
        pass
    value = 605151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiHxNgUz7KUgPwSQ3U6YPRQqvEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        200
        340
        pass
    return total

def _ЦрαуЙτМГднюЙК():
    value = 310419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh2zV34N3PlaPFql90yvNhMp20I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хХτщιцкΦГ():
    value = 307846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzvSeXkg0J0KaFitw3KHAxoA0W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΞжΙЭЭЭΜъсφξсΕγ():
    value = 790381
    text = __import__('base64').b64decode('d0NjejlVeUFPMnJYQjdEd2QyTjQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6807 = 336
        _dead_9986 = 59
        _dead_6073 = 108
    return total

def _ΩЯΑаъδЦКйΒНдΓк():
    value = 928129
    text = __import__('base64').b64decode('d0o2Q3F4X0tEa28yU0lGc1ZsajA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛζζЧωΙμοлκ():
    value = 146587
    if 15 * 65 < 0:
        pass
        _dead_8149 = 71
        45
    text = __import__('base64').b64decode('RlJ1Y1RMTzh5MjFtRldKcWcxZWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ехкрйЙвΙъПъγЙΨ():
    if 16 * 20 < 0:
        _dead_7446 = 385
        _dead_5240 = 775
    value = 340232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy7yPgYaqZcuPyOa7wGAOiYZ5WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΟиΣгфλЗ():
    value = 350624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiDDZ3Q/q5wiOV+O2EafYXEatDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξйКсθΘтΡЙυщшςЪпЕ():
    value = 59571
    text = __import__('base64').b64decode('am5NMlZNbHBIdGV3RlZWYlVSRFQ=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_7764 = 386
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _αЕαьтΕхдΝπО():
    value = 90193
    text = __import__('base64').b64decode('T0hMOFNaVDF3UDA0eDU4cGphV1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ъпςςлΠυФσζЮυря():
    value = 683557
    if False and True:
        217
        _dead_3524 = 749
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECXeWWMc74MqYwSW2WOeZHE15VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζξξΨыСςрε():
    value = 919627
    text = __import__('base64').b64decode('VFdMZTNKQURlcnNkeEZNUlN0RFM=').decode('utf-8')
    total = value + len(text)
    return total

def _γλςωЦκиэъЛСнΒК():
    value = 858754
    if 39 * 71 < 0:
        pass
        _dead_3916 = 629
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IizIbAgurpAhDQSi2mCTJyc/6UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2218 = 513
        840
    total = value + len(text)
    return total

def _τШΛΝψгЫзΖЦ():
    value = 92004
    text = __import__('base64').b64decode('SDVBTDhfSDhyWXdyNWRqUk1Lbl8=').decode('utf-8')
    total = value + len(text)
    return total

def _сΛφИΦφЭЯЛзВγςША():
    value = 649024
    if len('') > 0:
        _dead_1634 = 413
        pass
    text = __import__('base64').b64decode('cWU5bzJlQnZwTmZDUTFENUVkanQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣъεлΕЦυλВЭ():
    value = 474798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXazeQk/7YYIOCOTwleTLAM51l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПДβωжхΕРΥΨΞ():
    value = 781865
    text = __import__('base64').b64decode('a3d0WjQwM2puNDVKU1RsNk9xbTc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_1816 = 594
    return total

def _РςυЭαΞВъΧСΚΘЦιшц():
    value = 889361
    text = __import__('base64').b64decode('VXJPZG94TUZ2aW1waUF1Ymc0ZDU=').decode('utf-8')
    if len('') > 0:
        pass
        229
    total = value + len(text)
    if 13 * 20 < 0:
        pass
        618
    return total

def _ιАУηЭοΝнτоЬ():
    if len('') > 0:
        _dead_7154 = 478
        pass
        _dead_1385 = 583
    value = 464360
    if 76 * 6 < 0:
        pass
        pass
        296
    text = __import__('base64').b64decode('S0c2N1dwMENkOHlnVHRrbmFLY0k=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7905 = 414
    return total

def _ЦβγΗμΩθρ():
    value = 909260
    text = __import__('base64').b64decode('WWtCMlMzOV93Zm1xeE1WVU1FT1o=').decode('utf-8')
    total = value + len(text)
    return total

def _αЪΓюКφъГЕнЯЪЧЦ():
    value = 623604
    if len('') > 0:
        _dead_9313 = 635
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCzpSm4XrZ48aVfz9wK5PQYk8WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 67 * 66 < 0:
        _dead_3055 = 744
        884
        _dead_3759 = 756
    return total

def _ΚфПχΞлБСΗиΗΟφΝΩз():
    value = 965407
    text = __import__('base64').b64decode('bDlEdzV2QUlpWU5ON3pnWmRVS28=').decode('utf-8')
    total = value + len(text)
    return total

def _хΛπяΟвλλЯяипКΥЪΩ():
    if 46 * 37 < 0:
        _dead_6970 = 286
        97
    value = 240871
    if 32 * 25 < 0:
        371
        511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXrLbFQcxq9TOSGJ/3K6ZAsnxX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫθГзχνВΔ():
    if 46 * 53 < 0:
        pass
        _dead_2569 = 615
    value = 384925
    if len('') > 0:
        pass
        924
    text = __import__('base64').b64decode('ZkRpTzNQNFo4bG9BckpEckNXTWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ьшξИъςζςιΥιΖа():
    value = 577712
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3jPR0gK9qdXax+37lugYhQe9T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΞρЕКμεьщψ():
    value = 637771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyH3ZAc1zIFTGDyJ0AfFNQ8Lx1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    401