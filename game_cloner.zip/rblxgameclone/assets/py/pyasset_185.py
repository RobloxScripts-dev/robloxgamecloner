#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΧюγτПΖеЬшισΞКΞ():
    value = 73946
    text = __import__('base64').b64decode('czRXcnExeDNzdElaWDc2bnRyamQ=').decode('utf-8')
    total = value + len(text)
    return total

def _βζБЪθΦдζγФε():
    value = 441575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQzVS3gb8roRDguG3wLAPyt67Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 88 * 52 < 0:
        350
        pass
        _dead_9452 = 666
    total = value + len(text)
    if False and True:
        857
    return total

def _ЩбЩЮδЙьιбθЭЙпп():
    value = 453076
    text = __import__('base64').b64decode('Q0hPQzdocVVBSW5ZcGJFX1c3dnI=').decode('utf-8')
    if len('') > 0:
        _dead_8676 = 995
        pass
        pass
    total = value + len(text)
    return total

def _КΕдМтЩяξеРΦыνρρ():
    value = 96141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCvMe101xP9UICWV/H2nBAgV1Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚρэлйηПχГ():
    value = 829873
    text = __import__('base64').b64decode('eEdMUTE4ZkdFN09EV003SG1qNkE=').decode('utf-8')
    total = value + len(text)
    return total

def _уηфιθФοюЬδЪЯхеΗС():
    value = 789480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxjrakcB6L4WCCuB3HqVMywL0Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χУКПΕТτφΤΙАπъТΝΗ():
    value = 367290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiK9Z1gI6aJRYiet5VDHLBc250o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТαТθмЦнκПхефШ():
    value = 95642
    text = __import__('base64').b64decode('c1JvenJtTEZCUEtYQjc1NWVybGc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        460
    return total

def _дνЙωсЮθябЕШАгУ():
    value = 227507
    if 67 * 14 < 0:
        _dead_9893 = 88
        _dead_7767 = 230
        _dead_8068 = 65
    text = __import__('base64').b64decode('VExJRldzYmlGbVBIQU9NbGlRaks=').decode('utf-8')
    total = value + len(text)
    if 46 * 79 < 0:
        681
    return total

def _ΡЯчГχμЧΨДΞЯЙθЗ():
    value = 772638
    text = __import__('base64').b64decode('RXdMZXZvWlhOSjZabFdOaFhJRU4=').decode('utf-8')
    total = value + len(text)
    return total

def _наЧεцьΛЧбКβΩω():
    value = 379403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB/xRl44xpkVNBqIz0LEGyYfyEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μнбΗμΟδиΕХΝлжΥяΙ():
    value = 653633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAr2ewUU6JtbOAuQzXeRLTJ57kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4576 = 379
    total = value + len(text)
    if 19 * 7 < 0:
        _dead_6113 = 13
        pass
        1000
    return total

def _кЙхИчхмΗчЯωПФΤΩ():
    value = 924463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KynoUQc4q4MGLCa73wDJGQY50nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φбцψΔШйΛ():
    value = 807069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhvOZ0IIz6Q0Gx+QwWm7LH03yzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сеΖЭЫНВуΤξΛЪок():
    value = 316285
    text = __import__('base64').b64decode('am5QODI0VXUwc2QyTTJnNjlRMEE=').decode('utf-8')
    total = value + len(text)
    return total

def _шжνΞнПэвыδчΞΦШн():
    value = 580658
    text = __import__('base64').b64decode('R1kweTJGOXZYeWQ4M0REWElqcWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕэΨλОΩнстΞЧςΩ():
    value = 91920
    text = __import__('base64').b64decode('YjcxVDlyNnNwYk1zV2kzNzYxc2w=').decode('utf-8')
    if False and True:
        354
        _dead_1345 = 116
        115
    total = value + len(text)
    return total

def _юЖпКЛфбЙΝМСυЙШ():
    value = 374513
    if False and True:
        940
        _dead_2982 = 260
    text = __import__('base64').b64decode('SHZtYm9FNmlsT29aRG55eFVBSkk=').decode('utf-8')
    total = value + len(text)
    if 88 * 31 < 0:
        478
        _dead_4952 = 742
    return total

def _иШгЬΥшΡтπφЗ():
    value = 197330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyH+S0UyyJETMwa3y3+aACc+s3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΝуусΣПМьΥуπз():
    value = 834423
    text = __import__('base64').b64decode('VXFKelZpUFhyRDRRX2xIaU92ZXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩфСτцлмч():
    value = 586079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAzyPXIB1owPAhfyn3W1DDMay3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цЩΗоοΡАПв():
    value = 224755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX3qUXNpp7JXCwO5xH7DMiogxTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 79 * 52 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        687
        605
    return total

def _νλМУъЙτлιьΚτΗ():
    if 2 * 74 < 0:
        95
    value = 505335
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgC8YlZg9PxVCgS2nFS6AyoGwmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1511 = 594
        _dead_1148 = 108
        pass
    total = value + len(text)
    if 13 * 80 < 0:
        pass
        382
        _dead_1361 = 364
    return total

def _γБΗкФШйыςбЦФσА():
    value = 343819
    text = __import__('base64').b64decode('YXFLdG9uMGkySlZ1ODByOVoxSkw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5886 = 59
        _dead_1989 = 800
        792
    return total

def _ΙαЖΗИνбνбηздЬоА():
    if 80 * 32 < 0:
        _dead_1857 = 511
        374
    value = 291279
    if len('') > 0:
        887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3rVa1Ao1v4xPhuc706ZJhomsUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΝЖгуиρпРУБбνΦ():
    value = 400801
    if 2 * 99 < 0:
        pass
        449
        pass
    text = __import__('base64').b64decode('c0JqZXdxRVBlUWg2YjhrN3ZLQ1Y=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        401
        751
    return total

def _θφКςΜЬΜМЬΑ():
    value = 232312
    text = __import__('base64').b64decode('QlRlS2tBdko3OTNWOHdsdVV2SVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΗβМеекβφдΤЮэζΠ():
    value = 903054
    if len('') > 0:
        990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgLhd3wpq68COD+P0Vu/CwwNzmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 89 * 29 < 0:
        50
    return total

def _ФυкЧйжЦхΒΑюяΞρЫ():
    if False and True:
        _dead_6129 = 629
        784
    value = 400064
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzvhdkZrzaISNAvymHuaBwZ5wWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        707
    total = value + len(text)
    return total

def _ρΣБГОΩВжΤΣЭэЦΓιЩ():
    value = 97596
    text = __import__('base64').b64decode('bU9aVGRGN0xtSEhJYVVWSDZwX08=').decode('utf-8')
    total = value + len(text)
    if False and True:
        122
        _dead_4115 = 518
        _dead_7218 = 829
    return total

def _ΓЗЕРгχΞюΤ():
    value = 976411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCm3a0Md+f0EEiz053+CNQABwnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯоГΘαφМΑ():
    value = 391890
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwjtQ0QTrvEMAzi27VfGOyY7w1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦЪфеЧшПЖц():
    value = 877171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx73T2Y8qbICF1362FO4GQEawEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цЯΒФЪσΞЕЩ():
    value = 343111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXbiZ3Is2p5SHAu70QCHOnAZs2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4991 = 256
        976
        285
    total = value + len(text)
    if 3 * 61 < 0:
        _dead_2761 = 456
    return total

def _ЛοΔЬРΓαЛγцΠξρгΕζ():
    value = 323005
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQayflkh3YMiNBas/3KEGR8F21s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щлзБΦОρЭΘΣ():
    value = 880966
    text = __import__('base64').b64decode('bDdHUENYd0ZvM0tISkFhRlRYQjk=').decode('utf-8')
    total = value + len(text)
    return total

def _φЦΝτνζΦкОΘПΠк():
    value = 426474
    if len('') > 0:
        _dead_8843 = 761
        459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQm3R2cpq/4WagWb50TDDRUfw2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 42 * 46 < 0:
        127
        _dead_4994 = 642
    total = value + len(text)
    return total

def _зЫСЦКЯιеλБбХйΩщЖ():
    value = 37422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LizSZUAL/aUEFCSJmwWTHil87lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чгнΟΑПмщШз():
    value = 911004
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgPdYkEyxoszKj6q+EaGMSkIt0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _геЦξгφΡβυχЫ():
    value = 787703
    if 88 * 44 < 0:
        pass
        632
    text = __import__('base64').b64decode('ZmdKR2ZEbVljbWJBWTg1a1hqcVE=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЭΟφΝΦьσЬΥРαΞзη():
    value = 695970
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhvBfQFsyoMbClqg50yKGhc+234='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θххΩтШШШбяЧη():
    value = 260926
    text = __import__('base64').b64decode('bHJxbFpvN0NncXVGb3JEUjJWd2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ПηДΗкчфΑиθΧж():
    if 80 * 30 < 0:
        665
        pass
    value = 412802
    if False and True:
        pass
        _dead_1775 = 841
        759
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHjHPkMV+bAkCgaJ22mgFSgp6WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 8 < 0:
        _dead_9630 = 127
    total = value + len(text)
    return total

def _δξАπΟъΒАΥΒςтТσ():
    value = 638548
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACDxQUUs5p8QHBaO627CAR8Z0Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пТαΨΖмцιЯ():
    if False and True:
        pass
        pass
        981
    value = 578865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSXhW24076oxIyiG8nS8MgIL/ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣъщρтΥЬΗШΧОЙО():
    if 92 * 22 < 0:
        _dead_7692 = 247
    value = 23760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDeyY2hpybIIHQep7ES9ACsQ014='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        266
    return total

def _ОΠжθилδЕοФΡΘиуК():
    value = 213174
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IinKfn8N65kRaybw6X29LTEbwDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κнгАчЩЧРцлйеΤΛЯщ():
    value = 152658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxXNVgg767gBFVmL4GyhBCEJvXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РγДΟΔГξе():
    value = 165416
    if False and True:
        pass
        172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxyxSVsX+JBVbV2uxGK4Og4p6Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΖΚΗНъΝОΗΒΕη():
    value = 760325
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwfqZQUY7J8TMiSF2QCqNz0G7kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5182 = 592
        _dead_5467 = 105
        _dead_8206 = 458
    total = value + len(text)
    if 11 * 16 < 0:
        pass
        pass
    return total

def _РδЦВοΛЭКмЪΦω():
    if len('') > 0:
        _dead_3660 = 899
        248
    value = 247683
    text = __import__('base64').b64decode('Q0R4SWJSdGxkRU9uY3l5a1FmMEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΕОДκлЖΙΠБΞФз():
    if len('') > 0:
        pass
        pass
        _dead_9419 = 930
    value = 46790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3fyVHQ15IBTHD6K+kKSBgsG5ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3070 = 388
    return total

def _оЗςΕьМДδУγΓш():
    value = 503735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgTofFAMpvoiEiqkn0CKByAk4kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 26 * 7 < 0:
        _dead_4005 = 193
        _dead_2019 = 938
        102
    total = value + len(text)
    if False and True:
        _dead_8012 = 43
    return total

def _φΑсΛΦψЗζьжΦ():
    value = 959056
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C37hQl0u9vxXCQWE6lGyHBMn7FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕЯХаΔБνЛΧсЖ():
    if len('') > 0:
        _dead_4260 = 91
    value = 93209
    text = __import__('base64').b64decode('R1EyUmtEV0hUYVVxOTdqeG5iSFc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        48
        33
    return total

def _νЭнΡυлаμНК():
    value = 431177
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxrTVlxv5rgLa1702GSRHioX5TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыуξоφДΤЯЖ():
    value = 699835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXfsQANsybACG1+62H69Gy0Nx0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _быΒΒарШаьнΝщДΛ():
    value = 999227
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQW3YXIA2vAlCFq7mFiUIhc//Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИμΖхДβБφфδ():
    value = 343873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NguzekBt14wEMxm7nUSjYiIE00g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΧСΟεВнΗфФм():
    if 88 * 74 < 0:
        _dead_2405 = 423
    value = 337209
    text = __import__('base64').b64decode('ZUI3SmlqemZKdUpFanREbTljRmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΒЪюжΨПλЕΕШΟμлα():
    if False and True:
        511
        pass
        775
    value = 857956
    if False and True:
        _dead_4877 = 80
        _dead_7100 = 545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwntfAYOp5gzGTqqzG6aDRU/434='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        478
    total = value + len(text)
    if len('') > 0:
        pass
        296
        591
    return total

def _иГηΚεΚшЭчВΙЫ():
    value = 581219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTa0egYK95ABLxWPz3HEPB0I5WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кψиΖηκзИΗЧ():
    value = 482731
    text = __import__('base64').b64decode('TGloVVVxeW1TU1ZibVVKWW9hUmM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4254 = 834
    return total

def _δβКΜζαХςКΘЮΨΣ():
    if 67 * 27 < 0:
        _dead_5746 = 609
        pass
    value = 91685
    text = __import__('base64').b64decode('dVJwZWVIcEgxUkUxTWdCSHRJMU8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7746 = 399
    return total

def _дЙτΛшБмΠШπФξΕΡΚ():
    value = 233253
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAbjN2A+05wJaFmqwEeTHD1812w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΔΚφбжСЖНΨωЕнН():
    value = 506930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC2zSkQQyZsbElubzV/FbHcj3m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        213
    total = value + len(text)
    if 61 * 60 < 0:
        pass
        924
    return total

def _ЪЭΧЦеβЩюЖРρЗжΠУε():
    value = 567298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhC1fl8X1KoiMAKQykGfDjIN4EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 77 * 63 < 0:
        pass
        pass
        497
    total = value + len(text)
    return total

def _КЙБЕЭьВΟπωзБк():
    value = 562251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiX9d3s1qJw2Ax26wHiSITEpy14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ядиВЮжыЯщСΔΙрьλ():
    value = 159421
    text = __import__('base64').b64decode('YjJvcXhIM3FfNFNVYmI1Vko4b3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ХАВФШуΓубΧΚбрχфж():
    value = 411308
    text = __import__('base64').b64decode('UDByS1RaZHlMTVJsMGFVSmxmQ0U=').decode('utf-8')
    if len('') > 0:
        _dead_2008 = 87
        _dead_9025 = 347
    total = value + len(text)
    return total

def _ЮΟьΨнςχЖДωΨΕС():
    value = 312041
    text = __import__('base64').b64decode('dm9RbjlnbDVCZGhUWjBuVms2cWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒвяЫΨсИκСΨςκвΨγ():
    value = 323658
    if 15 * 55 < 0:
        747
        pass
    text = __import__('base64').b64decode('Vzk2Z3JCZlJBQnRuS21EaDliQng=').decode('utf-8')
    total = value + len(text)
    if 50 * 69 < 0:
        892
        pass
        pass
    return total

def _ΘфδуΚηВРΑΟзΨ():
    value = 129021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQi2ZmM6+58CYwyxnWWoBy4V1DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЪЮιфψΘΑЕΔτИА():
    if 5 * 30 < 0:
        725
        369
        pass
    value = 259547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCXLXV8cqvgRKzW3z2O2JnF/w2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яВηΗЭъЦЬΟЪРаψм():
    value = 480825
    if False and True:
        _dead_8458 = 382
        394
    text = __import__('base64').b64decode('a1c1cExtQk5hQm00MUJYVHlhYnc=').decode('utf-8')
    total = value + len(text)
    return total

def _νКГХсΣгΛΨ():
    value = 640236
    if 26 * 91 < 0:
        862
        944
    text = __import__('base64').b64decode('ZHI1UTZmd1JCdm9KU0oyd3lySXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ωвйΡφЮκΚρФрнΟ():
    value = 880596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT7zTGMS9/81Yl7y5Hu7FQ0us30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        83
    total = value + len(text)
    return total

def _ΕХιυезδφΔΛΝΠСΙ():
    value = 526735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBj3WAYq75cbKDuRykLAFhwjsl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΩнцΙВηνΒΚδ():
    value = 151152
    text = __import__('base64').b64decode('ZmVhRkpubTNMR0RmbENkZjhVcG4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        189
    return total

def _ξрσоβΨΣβρΒ():
    value = 345529
    text = __import__('base64').b64decode('Y3U1T1IxVlhNdk9fTGUwVmh4aGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЩаПеιРΤФιЫэгСχΥ():
    value = 836015
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTria2QX3bk3Ez2k4UDDPjIWwFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_1430 = 608
    return total

def _жΥЖРВПπц():
    value = 24727
    text = __import__('base64').b64decode('SWF2cGxLTUNkSU9XSWg4VUdyRE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯшΠЗтШΟг():
    value = 511987
    text = __import__('base64').b64decode('THRWMkZqa0IzRTNzR3B5ckxwN0U=').decode('utf-8')
    if 4 * 54 < 0:
        pass
    total = value + len(text)
    return total

def _хПζΜωЧΗбΣГЮХ():
    if 97 * 58 < 0:
        _dead_4986 = 972
        pass
        657
    value = 938446
    text = __import__('base64').b64decode('cHhBanl5MTFhb2RNeGhYd0F1amc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        237
    return total

def _ЬΡωЬΝβιяΤκγФ():
    value = 397226
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHfmV34g0IksYiSm3XSAEnImw2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑζΞΣΖыΧΓΕΕΦЦ():
    if False and True:
        145
        pass
    value = 31691
    text = __import__('base64').b64decode('dzR3dXAyM0pKY2ZMMGNhUlRhSEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ηЪПбрмйзΞГΕъπи():
    if False and True:
        _dead_5764 = 366
        pass
        pass
    value = 672180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwO8aGRp7L82aA2UwGKnJywoyX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δχηδОημЮЦЛО():
    value = 600354
    text = __import__('base64').b64decode('ZHRkZ1U5Sm03TG0wMGEyOHRHUVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙυγоХυλΛО():
    value = 314022
    text = __import__('base64').b64decode('Yng2aEVvZVBFbG9hb3pLZ3VTQ3k=').decode('utf-8')
    total = value + len(text)
    return total

def _αρшηШХмΖηкΧεпшλδ():
    value = 569367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dy7qXAQ28KQHPSj051imAyEAwkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠгЭФМЙεнξχйиТξ():
    value = 852436
    text = __import__('base64').b64decode('aDJHTVVmVHU4bnFvRzJKZHpBTEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙоχΜΝκцλ():
    value = 420124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhbNa0YYqosmMlf3mES+PA0J/Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НйПаоΑЩтΨф():
    value = 29441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXb2QmYgrZANbwKByUCGEwkN8Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1025 = 101
        pass
    total = value + len(text)
    return total

def _υβЬυЭοЬτΛуННη():
    if 47 * 46 < 0:
        _dead_8748 = 332
    value = 235702
    text = __import__('base64').b64decode('bVQwQVphY1pqdHRoOEg3eGpKXzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ХщЛΝσσμΟυ():
    if 36 * 37 < 0:
        _dead_4440 = 83
        456
        549
    value = 879724
    if len('') > 0:
        752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiTwTAJu3P8QCDW22UzHFnd5zDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        422
        666
    return total

def _ЖЙυςЬМυЗΦЫΘоц():
    if len('') > 0:
        pass
        pass
    value = 875119
    if False and True:
        _dead_4428 = 788
        pass
        626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jif1dlYbwaYxCheZnk+9ATcm100='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4203 = 87
        _dead_7657 = 652
        pass
    return total

def _чФЛщγмιЪΦΝШ():
    if len('') > 0:
        794
        _dead_7675 = 476
    value = 723205
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD7AQkYa+4s0Ph2X8H26LAl4/VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        300
        216
        501
    return total

def _ИЛΚδдэДХйΛЕ():
    value = 286714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiniSmcep51aEhiJ63SUYSEFs0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩгШюЩзиЬгφс():
    value = 913601
    if False and True:
        _dead_7933 = 514
        306
    text = __import__('base64').b64decode('U0R0bjVvYWV3SEFCdl9UMW9DYU0=').decode('utf-8')
    total = value + len(text)
    return total

def _юДвьРВΝЮΞΣΝσбЫ():
    value = 699715
    if False and True:
        370
        _dead_6576 = 960
        pass
    text = __import__('base64').b64decode('Y1VKcUN3dTlrdFUycGRLT1hQT2M=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7326 = 561
    return total

def _ржΡЬЕГЭьγΔш():
    value = 535935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBbzSkVqyaAaHA668lilBT8f40c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        978
        458
        _dead_6942 = 579
    total = value + len(text)
    if False and True:
        pass
        _dead_9493 = 921
        pass
    return total

def _КιΠЗгзеΚΞβдΚΖΚЕм():
    value = 766971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzzLZggs6KAzEQ2c72WGHhwl01g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        490
        322
        _dead_3351 = 56
    return total

def _ЖΩиΘΥХТμНΧΘςЗЧνщ():
    value = 860799
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3b3dlYy64MUND613H+SYQEAzzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪяΔΨдΤΞτУδκуΙХ():
    value = 703046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH7TaXYuyZcINw72z3TEPy999T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жυδΑγпδВυωсрΥσэ():
    value = 67657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCHiN1Ye95IoACiz22WbGxQE0jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φВШьΒΖФρΜΣНБ():
    value = 69639
    text = __import__('base64').b64decode('TG5RUnYwRF9MTjBNVXR5UnF5OEY=').decode('utf-8')
    if False and True:
        587
        pass
    total = value + len(text)
    return total

def _θиААаМΖΣΜυθЧоΚ():
    if False and True:
        749
        pass
        pass
    value = 973523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxW9QWQ78IYVPTWk4g+KOCZ+5lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        847
        822
    return total

def _ЖфΡмΥΘωΦПЕ():
    value = 207807
    text = __import__('base64').b64decode('ZExKOGF3cndJRVNNYWx6WE9VMWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΝкбзмυδУΕАΚюЕ():
    value = 609289
    text = __import__('base64').b64decode('VTdNODhWTFJUV2VBWXlqRXRRMlY=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΘεшыωωιδдхИψБ():
    if len('') > 0:
        555
    value = 411146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH7MXXwP1KwwHQiRzFSJJhca1kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_1770 = 848
    total = value + len(text)
    return total

def _ЧэюρМΧΠКΦΤ():
    value = 480701
    text = __import__('base64').b64decode('UDA2TUdZaVYwNlNzSUsxdWxyX24=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЙΠрΒγινнςЯСъιΩ():
    value = 656166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzjqW1Asrp8mMVa5zEK0PB0c9D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΚΨΧрЛшΒъωоХЗΞΦΧ():
    if 53 * 11 < 0:
        pass
        _dead_2275 = 989
    value = 522686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDzLeGU0r6dSIibyzgfGET87w1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _обνξιζρщЛτдЯО():
    value = 274126
    text = __import__('base64').b64decode('eF83MFI0RzU3S3JlOTl5T19ZeDE=').decode('utf-8')
    total = value + len(text)
    return total

def _сΩιбпвχΛюКχΑГγΔ():
    value = 793656
    text = __import__('base64').b64decode('V0VkQnIwUWpYVmJqcWk2R1V6aFo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _зσΚρσГШψЕБХαΤеСд():
    value = 444031
    if False and True:
        _dead_1699 = 813
        146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgvLZkEp67oUGAGgxW+0bSx5/Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 53 * 10 < 0:
        646
        556
    total = value + len(text)
    return total

def _ΨΧφρΚΜХοΦΕНιс():
    value = 614562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCHmQWJt9f40MCK30V+8BR0M0nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 46 < 0:
        pass
        564
        _dead_7040 = 576
    total = value + len(text)
    return total

def _ЗΥτдφьπΖ():
    value = 519972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AybtZAEP2PxWLDyL4US2FSsu0WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФЗюΜΔηЮΧ():
    if 90 * 81 < 0:
        _dead_2475 = 457
        _dead_2624 = 633
    value = 735387
    text = __import__('base64').b64decode('c2t1TERRRERNRklPWE1EdkdkcHk=').decode('utf-8')
    total = value + len(text)
    if 41 * 67 < 0:
        _dead_3620 = 621
        _dead_1124 = 408
        pass
    return total

def _ъЛΛΖОνЯσσΗт():
    value = 918763
    text = __import__('base64').b64decode('QWVQOFpic1lfbmo5RW41YmptZHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ηшшгхΙОХρдθЛс():
    if 71 * 1 < 0:
        _dead_3721 = 374
    value = 799459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHjDOVlsyI4LEDmX5EWYNwIu0XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        684
    total = value + len(text)
    return total

def _хФΝШУΕчКηЛМЩΠпΛ():
    value = 741943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzzbfF4r+aAlIgaE4XeqHzM90EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _умиυΗυвΙ():
    if 1 * 49 < 0:
        96
        964
    value = 811733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bi30Q3sM0f8GPAOpzGGIBikk22s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 15 * 49 < 0:
        _dead_4052 = 272
    return total

def _ТПΝωΩЭОпщη():
    value = 909499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwbjOgYb8YsnNwKPmWS7PQ9/8ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖсМνΒΑеσΚ():
    if 40 * 43 < 0:
        pass
        pass
    value = 398945
    text = __import__('base64').b64decode('QXh0NE95RkJ4NTFvbWo5N2VoV1U=').decode('utf-8')
    if 53 * 27 < 0:
        pass
        59
    total = value + len(text)
    if 63 * 46 < 0:
        pass
        _dead_1795 = 256
    return total

def _йКЙΠДμΝД():
    value = 721464
    if 3 * 77 < 0:
        _dead_1563 = 491
    text = __import__('base64').b64decode('TmJDR1BCNFp1c0FOM0hCSldPbG0=').decode('utf-8')
    if False and True:
        _dead_8661 = 443
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЕэΝъЯГАΘΕ():
    value = 892918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CD73Pntu3atTFhz7/GWdGiwKskg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 26 * 88 < 0:
        pass
        265
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _яκИЖшΙьСЯБθЙДзм():
    value = 55708
    if False and True:
        pass
    text = __import__('base64').b64decode('YzNaRWJXTGpUa1pSRXlCNnc2Q3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ρщЖΠβЭЪηИЖбα():
    if len('') > 0:
        949
    value = 690058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSvubHIv2v0XHxyG7VShIQ8k1z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψψЬЛτΟιпЩй():
    value = 328396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxjKfV8t2fsJPSe1xUKILCsd7Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еюЖДΚУΕδ():
    value = 201816
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQPIRVguwaQHbx+72WKmPgcLz20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧСКυЧыσηκжεШη():
    value = 14112
    text = __import__('base64').b64decode('alhIeF93NDQwTE9DZEU5QmFlb20=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛеСλрухШбДзо():
    value = 65273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3jNWHQA6P5SayaW+kHGHQ87sGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞыгΩΤιπю():
    value = 257657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FD/Qf1g//YIMbhevkQ66Z3YY5z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        664
        pass
    total = value + len(text)
    return total

def _ЭΓюдирсβνζεΔЭΜЮЩ():
    value = 536353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3v3fHMXyJBRLSui2m6WDC0/vUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тσΞΚуγΩЮкШΕΖ():
    value = 413088
    text = __import__('base64').b64decode('ZXRwSWNMeTN6QWh0dHFjVEN6em0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΕΟИСΨжКΦτВщясΞ():
    value = 457450
    if len('') > 0:
        _dead_4924 = 798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBnQR0Uf0LguLzyG7FWqEzEZ0nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦъпЙИФуΑΙςПΥ():
    value = 597002
    text = __import__('base64').b64decode('b0VTWFNsa1JibGZxb29NRUk5c1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ητКεвЖЦлсэщоΑψгО():
    value = 759210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AintPFs8poI2GFeI72SpNxJ84k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8753 = 515
        pass
    return total

def _СОωΣΣΘφБΕеЭяВтвΤ():
    value = 262467
    text = __import__('base64').b64decode('d0hXbXlkM1FueE5QdnpEd1l5QmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΑзφяσΧХ():
    value = 459405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADjldng7x/o1F1ql72+hBjYc41g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩЮΧБкςЩцОΡиΗяыθ():
    if len('') > 0:
        pass
        862
    value = 912046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjryOX1v2f0NFT+u5FipIAAq8mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 90 * 51 < 0:
        544
        pass
        _dead_9656 = 233
    return total

def _ΔνΒБΥΝНυз():
    if 95 * 96 < 0:
        pass
        _dead_7973 = 76
    value = 631972
    text = __import__('base64').b64decode('QnJKMmFNc0VGdEc3WXY5c3hiREE=').decode('utf-8')
    total = value + len(text)
    return total

def _χъэΚДδΒζмФбγ():
    value = 392879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCbuXAE45ocXFln35lK+OSEisVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 1 * 78 < 0:
        _dead_5583 = 52
        pass
        _dead_4184 = 423
    return total

def _ЙДСεαЙДнγкρяΚХΚЬ():
    value = 176106
    text = __import__('base64').b64decode('a0xrTkJTdzUzc0Y3b0NCb3NLbFY=').decode('utf-8')
    total = value + len(text)
    return total

def _сГетБσХдъροΖп():
    value = 355209
    text = __import__('base64').b64decode('b3NYZzBoVGRwcHFOeFRBYWdwODc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟчлΖαКЭЗюΩМλФбЗ():
    value = 938836
    text = __import__('base64').b64decode('ajJlUjNTWmFmT1Nkak4wTVQ2TGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘξΟτδΛДШЖΩ():
    value = 711763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETvXQwAJyooPCQXy/Q/APDQ+sXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΠыΧиκζЕΩХФψфΔфл():
    value = 836607
    if len('') > 0:
        381
        291
        312
    text = __import__('base64').b64decode('cFdNbGZqUFN2Q2FqcDdhN1NXNkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧοщЪτнδκΝЕΘяЬКЖе():
    value = 609486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRXvbVlo54kUIB/12WbJIykFtmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 78 * 8 < 0:
        613
    return total

def _хσΠΟеВиыОπΙжΚυΤ():
    value = 976283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT/hN0cP/Zc8HCCN3luyP3YEvDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _шΗвλЬΣδВιΓдγщюР():
    if len('') > 0:
        pass
    value = 358457
    if False and True:
        758
        pass
    text = __import__('base64').b64decode('dzF5WFl1MU1YX3hpM1RuWjdiMnY=').decode('utf-8')
    if False and True:
        _dead_7750 = 428
    total = value + len(text)
    return total

def _ΕэΔгъιЭЗФЛцκ():
    value = 199903
    text = __import__('base64').b64decode('SFhYcExsOUZRX3dSaE0zZGR0d3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯнФЧсаЧВ():
    value = 424289
    text = __import__('base64').b64decode('U0Z3QXMyd2l2OWNUck81WkpvdU4=').decode('utf-8')
    total = value + len(text)
    return total

def _сοιγξωэΠСЬюг():
    value = 638264
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBnQdlU20K8xbSismnWxBQQb6Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЪΤΘωбьξЪωχτйνщ():
    value = 571595
    text = __import__('base64').b64decode('b0VBOVhFZEZXcFRMWWRVU2daRko=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΣчΝънΝЯвΖ():
    value = 603229
    text = __import__('base64').b64decode('a3dPY3FLT2dlZnJxZzN4Y1FMX1g=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_3390 = 59
        pass
    total = value + len(text)
    return total

def _жιΕΣбЫΝΜ():
    value = 658918
    text = __import__('base64').b64decode('VjJiVlZrNWMyT29aQnB1dEswclY=').decode('utf-8')
    if 87 * 27 < 0:
        pass
        _dead_2364 = 686
        _dead_5075 = 395
    total = value + len(text)
    return total

def _ЦюИξρЯСΙ():
    if 45 * 3 < 0:
        pass
    value = 929831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwPpelgDxvoREVuEm0yUNy0h7T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛфрСзδΧГнПΡψИ():
    value = 449990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dju3S0gVy4MpOFr03mm2bHI71F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_3949 = 487
        574
    total = value + len(text)
    return total

def _ψЖνРЖЦΨλΝУюьфΡъ():
    value = 483444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx79Qms36oYyODuq5VyFDnY680Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йμАЮΠСξбλетΟ():
    value = 442583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChDsZnst0p8GDx+2xmPJEgIF10Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иσΝΥδΖτшΥΚΡэλ():
    value = 205717
    text = __import__('base64').b64decode('Yjc2ZTFFMnJfak80aWFBcHBOUWs=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΛθΤЩοбШкнρГЕГК():
    value = 331522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg3bR1Qsx48zFD6SnnuVExof73o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βНиζьТχЛсβу():
    value = 531931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgnTaHYg6qksNQD2yWC8BQsLzXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УсьЭΠдыбМδЛюго():
    value = 20735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHmwbQY3yIM7F1ip3WDCZAR8zHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9029 = 102
    return total

def _дГХГпббд():
    value = 896167
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mzj+SHgw/PkXDg6Z0XW4LBQL70k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΠкУБэΧЖнШΠΔЗй():
    if 42 * 50 < 0:
        _dead_4177 = 680
        146
        pass
    value = 267550
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQDGP3wtr4tTbj6h4VSEBAk+x28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μвΩΞюПГΖЛпм():
    value = 121798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhDQWksQxooyNifz90DJMDU5vXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖяΨЛκгдЗцР():
    value = 357443
    text = __import__('base64').b64decode('YnQ1MTVEMWxyUmlfT2N3VVZUMDI=').decode('utf-8')
    total = value + len(text)
    return total

def _УτξΔδЗΛнΔΘыкэ():
    value = 371974
    text = __import__('base64').b64decode('RWpJb184djNHNFBaTF9oemk5WVc=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _υΩΩΠΕЕоЧψщрюοоΔΝ():
    value = 230418
    text = __import__('base64').b64decode('ZUV1Qmo4bklvYkdSeW1LZzBNREk=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΓИХθГχΥбЩЯΣρ():
    value = 864690
    text = __import__('base64').b64decode('Qkt0d01lblN6aWxrYjBnZ3c5Rlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞωяΦэТγΣькγя():
    value = 14437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3bzTwJq66EtFAKp4ViDIAo81Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_3170 = 882
        _dead_2283 = 332
    total = value + len(text)
    return total

def _зШаюΠРюШΞШБш():
    value = 940944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwO1TQYW2/klY1eUng+gC30mz0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νжлЙкжκγВΙрΒШ():
    value = 347925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAX0OnMwyPs0IyKU73KbGBIf8H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5161 = 881
    total = value + len(text)
    if 38 * 18 < 0:
        pass
    return total

def _ΦуΡΥγΚЦНξЗΙДΑΓЛА():
    value = 964294
    text = __import__('base64').b64decode('QUlfbmZraGNNTVdqR1lVMDZHSmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΑЕЪЗЖΩюшЙэ():
    if len('') > 0:
        534
        _dead_1133 = 403
    value = 415683
    text = __import__('base64').b64decode('SF91TmVyTWlPeTIzSXFnMDNhaVU=').decode('utf-8')
    total = value + len(text)
    return total

def _бΤлΝвΝбдХ():
    value = 2895
    text = __import__('base64').b64decode('YVJaNGdzNWQ0RUxjYXRpc3JRQXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣτОгΦδГεНΞщρ():
    value = 858772
    text = __import__('base64').b64decode('clhWcmR6OXpUcXFHUGhNdVNvMkw=').decode('utf-8')
    total = value + len(text)
    return total

def _УυЮγΖУκπнХюКЯнБ():
    value = 891331
    if False and True:
        pass
    text = __import__('base64').b64decode('SDkwMVhxRUF2bkw1QnFuZW54Uzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΙэХэЬщУΦм():
    value = 832118
    text = __import__('base64').b64decode('YUtOMFVyWVFITEw2WEdJeUhNaDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 30 * 46 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    pass
    _dead_9368 = 90
    159