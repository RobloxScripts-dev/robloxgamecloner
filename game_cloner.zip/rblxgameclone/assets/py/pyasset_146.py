#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ρУнзгцЛбшиЕςщьσ():
    value = 441933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQ7WXgAux7pXG1er3kDDIzN98m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 78 * 60 < 0:
        _dead_5229 = 766
        _dead_2391 = 350
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЮγжПπΤВщЪ():
    value = 753154
    text = __import__('base64').b64decode('STZXSk15MkFOM0xIZmpOQTY1M2E=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЖИΤУЛОΝΩυдм():
    value = 468374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgfAeFYa34MOMQj6y3eeESg3z1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖлβΨαРτд():
    value = 659731
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxDqaEY70KpXMSiz/HS4Ox8L/G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 75 * 18 < 0:
        pass
        565
    total = value + len(text)
    return total

def _зΒоьοΧεЯриχΛΩАЭ():
    value = 43947
    text = __import__('base64').b64decode('RG9CMlk4MWptSkRvWGtaOHpNSVo=').decode('utf-8')
    if 11 * 41 < 0:
        54
        892
    total = value + len(text)
    if 88 * 38 < 0:
        _dead_7617 = 814
        31
        pass
    return total

def _ХПчнκЩμМяЭцзПΤ():
    value = 636047
    if len('') > 0:
        pass
        _dead_9789 = 452
    text = __import__('base64').b64decode('bmJrWkk2YWJaYTltZEFETG5aNlQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_1037 = 649
        _dead_5928 = 505
        843
    return total

def _ЧСЧΦЭАЮшжΖΟоУμв():
    value = 717827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky7+S2U28KcTPB+ixmyTIC8Ct2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΧРδьГκтб():
    value = 533644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mw7sWV88xq45HF6HzECCHgQDtVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЗδРЖяСωδγρ():
    value = 512051
    text = __import__('base64').b64decode('azJvd0ZrdkhCMEZuekVxQTdqRGU=').decode('utf-8')
    total = value + len(text)
    return total

def _бηевΙνεЙЫО():
    value = 832696
    text = __import__('base64').b64decode('Z202UW9CYzVPZmx1Q0FtRU1PT0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΙγΡкГНλРΦГ():
    value = 722533
    if False and True:
        116
    text = __import__('base64').b64decode('cHZJamF2SnhjVm5wTlJLZEVjbXA=').decode('utf-8')
    total = value + len(text)
    return total

def _δκΛПτнΡΥ():
    value = 723327
    text = __import__('base64').b64decode('VXdXWWJvQUQ3Y0FydnVEdWhFSHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒУΞγвΕψΜМй():
    value = 805798
    text = __import__('base64').b64decode('V0VVRGtpSlNlR19aN09ReWo1clU=').decode('utf-8')
    if len('') > 0:
        425
    total = value + len(text)
    return total

def _λСнщцНТСТ():
    if len('') > 0:
        _dead_5322 = 999
        602
        _dead_2058 = 704
    value = 332215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAqzZ2Nu15A6FAWo/kPFJjw483g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βлНΕрρЮЦъΜςцмΙЛΠ():
    value = 51716
    text = __import__('base64').b64decode('WEJuWjVMSktQdTA1R01FQU1heEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _δψдьΖωΨРЕΩΜΔξИэ():
    value = 437386
    text = __import__('base64').b64decode('WV83WkdxcHRudldtbVVaaHpjYlY=').decode('utf-8')
    if 26 * 81 < 0:
        159
        472
    total = value + len(text)
    return total

def _ΛфюΕβΛμΓθЪБ():
    value = 227165
    text = __import__('base64').b64decode('b2JUeE1vMjRiYWlJREFDZDBtdWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭНхИСпэырЫθВг():
    if len('') > 0:
        pass
        _dead_1435 = 874
        503
    value = 317456
    text = __import__('base64').b64decode('Y2pkc3hYU2RJTWkzempic1hmUVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑЯУΔοщζШ():
    value = 856376
    text = __import__('base64').b64decode('Z3gydF90UHhxY2ZuUVlPV0tBSlA=').decode('utf-8')
    total = value + len(text)
    return total

def _βлЭΨЖяАЖσДОτЙж():
    if len('') > 0:
        257
        981
    value = 603943
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('dWJDMGd6VUdCaVNTVFFTaFRKaFc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        231
        215
        _dead_9451 = 128
    return total

def _ΤοьаЭφИкчь():
    value = 225969
    text = __import__('base64').b64decode('b3labzRUUlVHM1pyamlWdmZNUk8=').decode('utf-8')
    total = value + len(text)
    return total

def _БсΒШяΜзЬгЦШ():
    if len('') > 0:
        536
        pass
    value = 74758
    text = __import__('base64').b64decode('SEJTRVA5STVNNEswcUV6TnJsWXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΟйθψдлιμΕ():
    value = 821183
    if 33 * 46 < 0:
        pass
        591
        92
    text = __import__('base64').b64decode('ZHlCRGtIdm1uQVlrRGp0bUdsck8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        652
        pass
    return total

def _ЪυΛрΝΨШфъ():
    value = 878287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTbyOn0Q+Zo6Gz2G90yIBRE3zjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пКУлфРфУθМ():
    value = 996264
    text = __import__('base64').b64decode('RHoybjhmR2NONWZ3amFybU1WaVg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4724 = 590
    return total

def _ъЛΑАфцЖЧΘΝδньРΖΙ():
    value = 483051
    if 72 * 12 < 0:
        _dead_2283 = 196
        833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX/sWnQGy4cLGQaL+XyCHQp+9Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СКΠπпΑΣΤΡмЭз():
    value = 96403
    text = __import__('base64').b64decode('VENjb1hMbVBKcGVjejFlU0t6cnE=').decode('utf-8')
    if len('') > 0:
        261
        55
    total = value + len(text)
    return total

def _УΠαСωжгКΕсΩφгΔЛ():
    value = 782072
    text = __import__('base64').b64decode('aGhUTFhaMDY1N1Q3RnZPbkdTTkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΓНζДяЦФоΚзЭл():
    value = 138191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQrnN34o7/5QLib64QaVZyYs3m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΠκνбΕКθ():
    if 18 * 88 < 0:
        925
        963
        289
    value = 502962
    if 32 * 3 < 0:
        963
        933
        720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ayj1VFcu76Q0HV2uxQKUZg8m/lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НКЬСочοΣФсΛτχц():
    value = 715362
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh3XT3kU5LAaLQe150G5GT8N1UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪцτνНΓΔАτλ():
    if len('') > 0:
        pass
        pass
    value = 833984
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXfUPX8V260waAeF8mWnPiEc500='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΣσΧтбэπф():
    value = 823668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KATJN3NpyLsZNwqQ7FSoBhEc0Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГφшААΘоβЪОп():
    value = 826935
    text = __import__('base64').b64decode('Tl9CVHhJaHVTeU5mbHBuR1JGSmU=').decode('utf-8')
    total = value + len(text)
    return total

def _юОξΔφъГωСΠЩВЦΓ():
    value = 2965
    if 31 * 18 < 0:
        921
        576
        pass
    text = __import__('base64').b64decode('V1R3Nld4M29zSUpBMUJacmtfYzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ζЛζОЬσэβΗОμδл():
    value = 176963
    text = __import__('base64').b64decode('R0JROWVBT19lYVVBd19IWHQ2b1o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2304 = 932
        309
        595
    return total

def _ЙΓФξФψхρΓψпЧЭ():
    if False and True:
        pass
        809
    value = 505166
    if 28 * 52 < 0:
        1
        _dead_6711 = 736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnvFdngBq4snAg7x5gO/BS0f3jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6591 = 105
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_6500 = 39
    return total

def _ЖтЖЛШμπупцоаИ():
    if len('') > 0:
        pass
        505
    value = 972488
    if False and True:
        918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDfFbQQh8/EHDCKX8GmHJxMG918='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2048 = 385
        _dead_9731 = 142
    total = value + len(text)
    return total

def _ΙлΘΑвμиБцдΝАбЫНД():
    value = 846160
    text = __import__('base64').b64decode('b3pkZTk5UXY5YWdmX001NXc1SzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔωВΩΦδνΗ():
    value = 3660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyS8ZF1ox/AKFQm6mn6oBAp90WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μημΝωΗЯΧщНуΔжΚ():
    value = 766225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj62V34r/PAmMj2o3m+jGzE/3Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЙεОрφφаΒΓ():
    value = 690980
    text = __import__('base64').b64decode('dFowOUdlRTBzVTVia1hHYTgzSDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗбзмпЕМΨнψдфщ():
    value = 480123
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhXXXXovrbsMbh6Txn6IDXcJs3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χЕЭмхУщνΛ():
    value = 220199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAr+UQYR84kuHQag/Uy0C3IJsz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εдΨΨξиυζΦЗдбθ():
    value = 657053
    if 70 * 31 < 0:
        436
        _dead_7440 = 74
    text = __import__('base64').b64decode('cWdxV3lQYmZZMHVZNjQ0dkUxQ28=').decode('utf-8')
    if len('') > 0:
        783
        10
        645
    total = value + len(text)
    return total

def _ЛЩмЛъРΤΟЭПγДΖΦК():
    if 54 * 69 < 0:
        pass
        _dead_8654 = 743
    value = 476773
    text = __import__('base64').b64decode('SEJpRk5TT3FtY21WUzZncHhUTkk=').decode('utf-8')
    if len('') > 0:
        _dead_3303 = 657
    total = value + len(text)
    return total

def _шΚΣΘΜМрЦ():
    value = 183919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyjjXFVv9qMTFSCV+w+GbBIX63g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦυФκΧΠΕяПЮЙΘгΕа():
    value = 623908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax7yQVwuwf4hbAiS4meZGSkb5Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΟеыХЗЧΕ():
    value = 779429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MArsSVU4r5cQCAaZz2/JPBIi/Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        745
    return total

def _ЙоΟτηКГΙяЯлрφ():
    if len('') > 0:
        _dead_3553 = 187
    value = 349582
    text = __import__('base64').b64decode('d2ZCdkxydktkNDcyMk5jTVNhcXg=').decode('utf-8')
    total = value + len(text)
    if 13 * 7 < 0:
        pass
        399
    return total

def _эΕмМзмιαΩ():
    if False and True:
        pass
        362
    value = 338815
    if 49 * 31 < 0:
        407
        _dead_6397 = 31
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD/UOkgArKcKa1y152a7bSk94zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΤΧТЯржτиαΒАφ():
    value = 383194
    text = __import__('base64').b64decode('aFBDMmUzN1VaQU1uSEM5YmVRMVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑаΝлΤЮТГЛхЗщΟфΗΖ():
    value = 430102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT70dAg6rPtaE12043mWB3x3tW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νсνΧЩПдЛΨΙЦю():
    value = 178968
    text = __import__('base64').b64decode('TnpQQnFiQkFJaThrNnpqWE1lQnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЬщЭеΣκΠχАβ():
    if 20 * 63 < 0:
        _dead_3633 = 790
        pass
        pass
    value = 62986
    text = __import__('base64').b64decode('cTBfRXlUNnEzUWNsQkJwWjk0TDk=').decode('utf-8')
    total = value + len(text)
    if 46 * 28 < 0:
        _dead_2463 = 152
        _dead_9419 = 501
        _dead_8736 = 434
    return total

def _ИρгΓЗШΒηНοχΖКнρП():
    if False and True:
        _dead_2776 = 52
        pass
    value = 630496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAfDPFkq0KIJIBiA3V2WADIK8zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_9713 = 1
        pass
    return total

def _μγΣΦеηΧΠЭу():
    value = 460018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3vgdncX6LwlLz2I5FCREiAOt34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        416
        406
    total = value + len(text)
    if len('') > 0:
        _dead_7755 = 367
        pass
        pass
    return total

def _βРΝεяоΞρΙυГΤВΕς():
    value = 862305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQC2aWMzqaQIDz6BwViXJQ033T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1996 = 792
        145
        268
    return total

def _σЕδαΚТΟиΞиюη():
    value = 623986
    text = __import__('base64').b64decode('U1dLcDJ1ekNpSGdjQjBsQ1NSN1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЮпщМЪчьγ():
    value = 127344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwDnYFcWqY0LIhqk/k/IPgw703Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΣαжеΖШΒοВМΕβУΗт():
    value = 705554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQ22XHBhyqIIbCGM4A6hOicE4XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΘФьУΩΡхсЦ():
    value = 457809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bwu0YVg296sFLTytwFS/LXI2x2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΞэлΑλАЖм():
    value = 761436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSLJOEIY07kXHly73AKoOxEZ1D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4396 = 7
        _dead_5175 = 140
    return total

def _ΛνбчлвЭΓεΖЗοШΑ():
    value = 572501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy7rd0EtzbA7BQ2nkEKlPiAI7Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йвΣνТΘЙΘΞΥΛ():
    value = 607398
    text = __import__('base64').b64decode('RHVQTjNjQ21SMW5zWXJOeUpiV3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ДыюУщνΕИУМЮ():
    if len('') > 0:
        _dead_2607 = 661
        pass
        _dead_2775 = 179
    value = 82498
    text = __import__('base64').b64decode('QkhjeG5rSVVzb3ZZQ2oyZ0liWno=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨБΓΙιШЩъяъΠρΔ():
    value = 57011
    if False and True:
        _dead_3195 = 534
        _dead_6832 = 327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDvnXQg43YAoHiegxFyKbTYcxz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΡΔЕчΕψЛΧцйИНиοшх():
    value = 948046
    if len('') > 0:
        _dead_7036 = 44
        _dead_9713 = 975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By6xXnkc0JkJNByy4AG5GyQn4GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        924
    return total

def _цИОχГЕсЩζПΣЮаЯ():
    value = 173870
    text = __import__('base64').b64decode('aEtFU2hIRW1XVHdDdW85SzlDU0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞфεθЗΤжглр():
    value = 166101
    text = __import__('base64').b64decode('RjV1b0RmOFVSdTl1YlNDengydVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΡьΥΛτГηА():
    value = 641205
    text = __import__('base64').b64decode('bWluRDc2a1hveG9jbVZOQWxKUU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣЦщФΦХаωБХΑ():
    value = 371975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDbHZF8N9aMtAD22nmK+LAkn8kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕρΡрΜЦμЪНΔЫАΜР():
    value = 117443
    if False and True:
        _dead_6047 = 988
        _dead_3409 = 110
        824
    text = __import__('base64').b64decode('aHJVeWJvUlJNUUo5cVN5T25ONXc=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_9175 = 769
    total = value + len(text)
    return total

def _πэυсъΖТΣ():
    value = 888251
    text = __import__('base64').b64decode('ZEM0dFRfSlA3cVM1bmEzWGRBemQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        695
        _dead_3597 = 886
        _dead_2141 = 411
    return total

def _ΚΓКοЫψЫу():
    value = 956585
    text = __import__('base64').b64decode('enJUcVRfWUt0em56TUZVMjBjdVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ξчΧгχΡпτΑтУдсΗ():
    value = 114916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B37eTwAu+bFUCQWbnXKkBzUIt3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8257 = 760
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _λЦГλЬΨЬФъΚ():
    value = 699422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCjKeEsB57oUNQi5+m6aMiF5/Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΣξВΓэЩιОНБβь():
    value = 769285
    text = __import__('base64').b64decode('ZmFUX0dCcVFzTFMxZkhlMVVLSXY=').decode('utf-8')
    total = value + len(text)
    return total

def _δηΞιχоъΠЩΥιΨΣОТ():
    value = 110281
    if 80 * 87 < 0:
        193
        _dead_8720 = 61
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyjBOn8ezvApBSiH/FCWZTQ76jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηкуψψΦнΩ():
    if 79 * 92 < 0:
        _dead_6062 = 469
    value = 393902
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBXma1cs661SbiCb3lOeOXw28GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 20 * 7 < 0:
        _dead_2614 = 419
    return total

def _дгЦςсдΚΒфαΨтρцм():
    value = 891763
    text = __import__('base64').b64decode('Q19zam9kdU9IdmV0YU9UOGtyWlo=').decode('utf-8')
    total = value + len(text)
    return total

def _тНιВБкэюУаЕ():
    value = 829158
    text = __import__('base64').b64decode('STFUenZOc1JsX2g4X25tT00zWUc=').decode('utf-8')
    total = value + len(text)
    return total

def _лκЖψΕЪΖζιнгиЮЙΙΑ():
    value = 314938
    text = __import__('base64').b64decode('VGNUek90WlZ5cF9DSnBmM0E2dkQ=').decode('utf-8')
    if False and True:
        _dead_2304 = 135
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_2919 = 894
        350
    return total

def _ТΥюЕСйλаοЙΜ():
    value = 201391
    if 40 * 40 < 0:
        pass
        823
        954
    text = __import__('base64').b64decode('c0RsZ25oQmNhZGRoZUh3TVNZcGo=').decode('utf-8')
    if 56 * 27 < 0:
        pass
    total = value + len(text)
    return total

def _ЙыЫшςМКЬоΓΥНеΩг():
    value = 275501
    text = __import__('base64').b64decode('aWxiN21GSFFZbTZUaTY4MmdrbUs=').decode('utf-8')
    total = value + len(text)
    return total

def _чвοЗρΤКΖγяО():
    value = 797279
    text = __import__('base64').b64decode('TUZ4b3Z4MXZlckNwemVfcHNSSU8=').decode('utf-8')
    if False and True:
        _dead_6595 = 977
        _dead_6724 = 67
    total = value + len(text)
    return total

def _ΠΒмШχШщьаΩκФэ():
    if False and True:
        3
        696
        _dead_8269 = 8
    value = 217388
    text = __import__('base64').b64decode('RXk2alZCMzUyM0JUOUJIV1FFR00=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΕзьβΛзЪαНпМРрΤ():
    value = 102143
    if len('') > 0:
        59
        _dead_5923 = 613
        _dead_1203 = 843
    text = __import__('base64').b64decode('TVo5V1J5N21fMkJEbUtXNFdNNVA=').decode('utf-8')
    if 63 * 86 < 0:
        pass
    total = value + len(text)
    if 10 * 77 < 0:
        _dead_1561 = 832
        _dead_9076 = 378
        _dead_6850 = 326
    return total

def _НΗЩοшΘκχтЪ():
    value = 722200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHr2QH0A5LkIYxeW8X+oAw5+x3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒалΗпСЧβΠΘьъ():
    if 42 * 23 < 0:
        _dead_4381 = 30
    value = 298556
    text = __import__('base64').b64decode('bHRBZkhmY25pVjFkeU9TVVVWNGs=').decode('utf-8')
    if len('') > 0:
        _dead_8399 = 140
    total = value + len(text)
    return total

def _тτΘηцΧδΨЛАъ():
    value = 561636
    text = __import__('base64').b64decode('Q0JscjdKTVdLMXNia04zMzhkcTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ХсчΙзЭΞвЧρФсУсΣΜ():
    value = 756580
    if False and True:
        _dead_6392 = 274
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSTdeUIc3b0oOT+wzGmHOy8s9Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΗΠβМτυτ():
    if False and True:
        pass
        pass
        pass
    value = 944982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgrzO3875KQvACKE/WynbR8Z8zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6929 = 483
    total = value + len(text)
    if len('') > 0:
        637
        800
    return total

def _кжδΕУπΦшэИчςЧбИ():
    value = 386086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyS3f3lux/AxYyWl+3/DMxU3z18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    if 32 * 13 < 0:
        106
    return total

def _ЦθζθχПψНΤ():
    if False and True:
        _dead_9763 = 75
    value = 446738
    if False and True:
        813
        596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyDvS3cJpv0BPAHw7FOENTwe/Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥшδъВθΕНШωЙЧмΡΕ():
    value = 184849
    if False and True:
        884
        658
        _dead_4711 = 981
    text = __import__('base64').b64decode('SVVTMnVFM1M2UXlXb1g2eHZaajQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ηВХЯшκΩηβΞбΥкο():
    value = 386342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB3GZH4gy4E5O1mO2XmqDScDy1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вζΤОτΗωυкпЫаαηмИ():
    value = 228928
    if False and True:
        974
        _dead_4990 = 349
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQrMf2Ax7JokNi2OzWmGPxob3Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 99 < 0:
        _dead_9702 = 50
        624
    total = value + len(text)
    return total

def _ΧπЛθЖТпξыβй():
    value = 336808
    text = __import__('base64').b64decode('c3F2ckNaSkxkcFJtNENjMUp2cTk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _φΖбБхΚРΣψГ():
    if False and True:
        _dead_5211 = 388
        pass
    value = 878548
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAyyawgU9JAubyf0xluWZgsH1js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φλψйкαтκ():
    value = 893375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ln+9RnQQq4RRMASSwHGpIT8AwU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψьΞΙБγΠач():
    value = 345279
    text = __import__('base64').b64decode('eW9nejNDWjBkdVdrODlmV1pEaHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ПНψωΝЗЭт():
    value = 604786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhCxTWES/7krOTqNw1nFJnE5w28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝгйГфΠуΔΘЙΖΛΥΔψс():
    value = 279288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj2yN0gK9ocBLhmU6n+8NXZ7t14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иТψЛТнΝй():
    value = 731799
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATa2SWst6fkLaRinxwKoYncg134='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4723 = 167
    total = value + len(text)
    return total

def _дΓиЭωмτдρЦτπΞИΕχ():
    if False and True:
        763
        pass
        _dead_5539 = 930
    value = 461069
    text = __import__('base64').b64decode('SzFycjV6RXZua1BEdzNCRWUxWHE=').decode('utf-8')
    if 36 * 18 < 0:
        173
        850
        pass
    total = value + len(text)
    return total

def _шτλΘАтДΠНγΧЪΝ():
    value = 434714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBy3d3sM6q8KODWrnGGHEAM1t10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μεаΦιερνΜлΟМАш():
    value = 649079
    text = __import__('base64').b64decode('QjdKbHJudDR0WGppSHJQeXU5cm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЯЗрСДИчшΓлκО():
    if 41 * 89 < 0:
        _dead_2311 = 158
        pass
        pass
    value = 261022
    text = __import__('base64').b64decode('V2NON2VMWjVxMU9fSUlMdERjOUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ηэцьσΕΙМΥжΙζНΛиШ():
    value = 145939
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgneTAQLq5chDSy07kK9YTYI3Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΑюοξΕшпфЖ():
    value = 870172
    text = __import__('base64').b64decode('T3VQVlQ4ZW5GQW9Gb29lc0tSX1k=').decode('utf-8')
    total = value + len(text)
    return total

def _οхΤТοЕχΤзΦΘРΞц():
    value = 819625
    text = __import__('base64').b64decode('RDNHaHRmNGkydDUzQnNRNlFSWjE=').decode('utf-8')
    total = value + len(text)
    return total

def _υЗУμдενжФΘЫΠλущα():
    value = 713484
    text = __import__('base64').b64decode('S2psZnNjaVNMM3lWc1UyZ20xTG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЯΙμεξкР():
    if False and True:
        pass
    value = 999676
    if False and True:
        666
    text = __import__('base64').b64decode('dTQ1amdTNXBFd0gzaWFwZTFUU0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧшШеБыыьΤΛ():
    if False and True:
        _dead_7863 = 37
        573
        849
    value = 105761
    text = __import__('base64').b64decode('bmI0ODlwUGcxaUFrOXFTRGU0aG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔеаτθЮЧП():
    value = 81163
    text = __import__('base64').b64decode('S1NKcldHeWNDZ09yXzJpcDFJY1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛОЬΗЫПΛХЕωу():
    value = 201933
    text = __import__('base64').b64decode('cFFzX2tZaGg1Uk1xTGYySWgxT3E=').decode('utf-8')
    if len('') > 0:
        pass
        72
    total = value + len(text)
    return total

def _МηЬьΕНνк():
    value = 276311
    text = __import__('base64').b64decode('cWc1WXJ6MXZRcmdaeUNlRFBBanI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒЯЗπьΓДдειΗюκкБ():
    value = 929932
    if 31 * 60 < 0:
        pass
        pass
        _dead_7828 = 756
    text = __import__('base64').b64decode('QUVXWkIxalF5SnRvcjZKOTR3bDM=').decode('utf-8')
    total = value + len(text)
    return total

def _οкМΜыξЖγок():
    value = 392706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS6xaQQw5vszawyJ/n+xBnMWw2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нчτПδΒΠЦσΥΩθЦ():
    if False and True:
        pass
        939
    value = 533971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwT2bHNu1L5VD12Wnga5DQQ23U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩщЭрЧЩφΤΗЗЭπ():
    value = 712117
    text = __import__('base64').b64decode('cHFINFFCaWhPN1o1M1h0RnRTR2E=').decode('utf-8')
    if len('') > 0:
        _dead_5203 = 281
        869
        _dead_5427 = 987
    total = value + len(text)
    return total

def _ЯγаκφШЙгЕмш():
    if False and True:
        85
    value = 7657
    if False and True:
        pass
        _dead_8012 = 978
        pass
    text = __import__('base64').b64decode('emVxazdWSXRkdEFJRVU4STNkd2Y=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_6546 = 173
    return total

def _ЫωРΨглХжφπуΛσюΓι():
    value = 551793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBnORwAwyo9UDzmZ50fEFwgF0kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ужцδБЧНуПΚ():
    value = 938342
    text = __import__('base64').b64decode('UzVzV2VOZUJaUFFWX21SQUluUUw=').decode('utf-8')
    total = value + len(text)
    return total

def _гνΔллПθΝЧЩψшΟηьΗ():
    value = 322070
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhayPAlvrbwObTCn91WdFnJ64Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗжсχΨдβεΑЮνъКбΛ():
    value = 948570
    text = __import__('base64').b64decode('WEY2S3VZNHp1Mmg4TUNycHNCSUo=').decode('utf-8')
    total = value + len(text)
    return total

def _етоЫгεбИΠΖпТДьмю():
    value = 684456
    text = __import__('base64').b64decode('T0FWVG90VTVIMUlFc21ra25WSjM=').decode('utf-8')
    if 85 * 24 < 0:
        _dead_4528 = 319
        _dead_4876 = 602
    total = value + len(text)
    return total

def _СΡШωαяΤУФβΔ():
    value = 876515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxzgNgEb2a5bGBuZw2C7PgYV3X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡГвγЩвΝабΒлаφИ():
    value = 978651
    text = __import__('base64').b64decode('V29BS0c2Y1dpMXhEYUdLcjVQYjg=').decode('utf-8')
    total = value + len(text)
    return total

def _иθΗθηТτΩтεВγ():
    value = 968512
    text = __import__('base64').b64decode('RmNLRVg0aXJyUF9zVV9wNU11ZUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ФιθТСτДρκы():
    if len('') > 0:
        _dead_2255 = 111
        _dead_1962 = 208
    value = 684485
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD2yYQYwyYoGLiCEzXC+PDAg4WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 38 * 64 < 0:
        767
        _dead_3605 = 433
        _dead_5913 = 124
    total = value + len(text)
    return total

def _ΨωЕИвлωρыЭжь():
    value = 472637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD7sQV4yprooPiOr/3WoBnI5s1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вУΓмРЬσαдΨΟиΘЯДψ():
    value = 375897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3m9RQUNyaQlDBaQ8mKpZAwrwUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣΥφЛΨΓΗЮνδ():
    if False and True:
        _dead_2860 = 503
        pass
    value = 552405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxnxbVk95Io5ADe60k65FjYXx14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        40
        _dead_9292 = 835
    total = value + len(text)
    return total

def _ФпЬзшПΦΠГЕ():
    if False and True:
        pass
    value = 575400
    if 70 * 2 < 0:
        pass
        897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBfgW2470IAQLlqm3wC9HA0ds1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗрКфσГЩχΟ():
    value = 127558
    text = __import__('base64').b64decode('aUx5YnQ2R0ZXekFiN1hDRm9EeDM=').decode('utf-8')
    if 16 * 51 < 0:
        574
    total = value + len(text)
    return total

def _ЙШςΑЬъιΖрХτμШ():
    value = 432185
    text = __import__('base64').b64decode('VjExS0gxWm1vOHQ0SjZZalozOGg=').decode('utf-8')
    total = value + len(text)
    if 50 * 81 < 0:
        _dead_9274 = 57
    return total

def _ΕИηκПЛΞЖ():
    value = 859682
    if False and True:
        128
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxDDWQZh64ZaHTy07HuADQ09tVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 23 * 33 < 0:
        762
    return total

def _иЦλρΞμΞΚΜ():
    value = 977800
    if 80 * 25 < 0:
        pass
    text = __import__('base64').b64decode('T3RURzNtSERvOVNpU055Q2xHbXM=').decode('utf-8')
    total = value + len(text)
    return total

def _эйВсФΥомшКойи():
    value = 544403
    text = __import__('base64').b64decode('WEp6Yk1wQ0xUZk5UTEJuQ21PSEI=').decode('utf-8')
    total = value + len(text)
    if 91 * 13 < 0:
        808
    return total

def _ОЩλΠГчΗе():
    value = 580165
    text = __import__('base64').b64decode('QlhaMXNkeG01M2NHaVpkUU1OQTg=').decode('utf-8')
    if False and True:
        _dead_9107 = 316
        312
        _dead_2405 = 359
    total = value + len(text)
    return total

def _ъЗсбмпПГζΝΥШηЩμФ():
    value = 149493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Knj+NnAqwYYIGzes7H2ZYnIWyU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВдУΚΣьтρЯΞ():
    value = 200439
    text = __import__('base64').b64decode('a3R0X1dIYWxiRXFHb01KekNfdXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ьОЕΑиτЭИνи():
    value = 886107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ei3GfEIP3fA3bQmkwkSbDCoo9UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        847
        _dead_1966 = 589
    total = value + len(text)
    return total

def _ΓЕдеςγНςЕΕ():
    value = 854454
    text = __import__('base64').b64decode('eGpSQlFLX2dpdFRFRVkzTDRkdFk=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ωхЦйςнЖТЫщБКυсψ():
    value = 202354
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXm2WwQAzKEuHVianwadIDQY410='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МаΟПΔφЬεв():
    value = 403750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FinjeX4g+6EFaS7zy2PAOHM5s2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сηПΚМЬЧЦЕаι():
    value = 803196
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ai3JSV8J6qcPCFysxUC2HBU+9k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5261 = 225
    total = value + len(text)
    if False and True:
        273
    return total

def _ЖиΨΣζПσТХлΕШыЙ():
    value = 410524
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzyySGER660wPFet6ga+BxV9sEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 84 < 0:
        201
        _dead_2922 = 11
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        461
    return total

def _ηцξйЭЛРΨΤГΑμЮ():
    value = 181912
    text = __import__('base64').b64decode('cE5RNUxzWkdSTGwyZGpVUV9TU1Y=').decode('utf-8')
    if len('') > 0:
        463
    total = value + len(text)
    return total

def _ΧЬвηεЮыл():
    value = 980212
    text = __import__('base64').b64decode('aldhZk5tZW56Q0pWWXh4WEhLcmI=').decode('utf-8')
    total = value + len(text)
    return total

def _юγΔЪφхйσЯРξ():
    if len('') > 0:
        _dead_7235 = 534
        621
        pass
    value = 15338
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH3SZGMc6/BRMFmR5QCUMi4DzkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АνΔψΥΠμχΟГκωх():
    value = 171127
    if len('') > 0:
        985
        493
        _dead_4083 = 999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyPDWXMI65ksIlqg2WyeFy0l71o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        366
        _dead_4651 = 606
        _dead_9321 = 383
    return total

def _КЫΧжпУИρЕфК():
    value = 90820
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxfoSFIG3L4NODf6x32eIBV/4Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ςЭНαχЕуэА():
    value = 773235
    text = __import__('base64').b64decode('WTNzUzhFT3RuQVZKbXFObVpkNWY=').decode('utf-8')
    total = value + len(text)
    return total

def _сиεθаνοЛενЖχВН():
    value = 655124
    if len('') > 0:
        pass
        291
    text = __import__('base64').b64decode('RVFjU0hROTNuanJtYUVBa05sX00=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫУЭЖхщЬβЯΩрРфεдκ():
    value = 810409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT3Cdn0I0ZEvbSuS8E6GOyM3508='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШРвэАгСкМщςЕьоζκ():
    value = 547279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAnMSmIM/YomExaonEObPSQ5/j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΨБЙЯБΑПΓ():
    value = 978873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRDqYXYwxPAqHx+z8GCxByd77Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЦшцηψЬрк():
    value = 836550
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgP+SF4916MCLTq0/0+GHgwq3mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εъИдКдбσΔС():
    value = 112492
    text = __import__('base64').b64decode('T2tUd19PX3NsWXRFdXc3U01zN1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _рЫПΟядрΖΘыХЬоγЗ():
    value = 43386
    text = __import__('base64').b64decode('Q1BGRXpqeFpkRXZQaDdIbWJaNWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛмВΨΛВΖπщРεΡΥθ():
    value = 52517
    if len('') > 0:
        _dead_6400 = 946
        pass
        772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnjgXGQ+y4ksEDD7xQ6/MwN/1mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηαΦβΟμшжаоξΔщΞΦн():
    if 18 * 85 < 0:
        809
        _dead_7003 = 648
        771
    value = 397164
    if len('') > 0:
        4
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PC73QVpv0KYLFVat20/CDTA+60I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        313
    total = value + len(text)
    if False and True:
        217
        265
    return total

def _αΤΧФΝΩТЭЗБлΩхΞ():
    value = 134018
    if False and True:
        733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxjqTFpg2qomFzi1znWxZCgCtH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        287
    total = value + len(text)
    if len('') > 0:
        _dead_2712 = 707
        396
    return total

def _ыΠМТжхЯжβйПωэ():
    value = 947784
    text = __import__('base64').b64decode('eWtzNVVSTzZaQWt1WGw1NHo3bVQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _διмΛШадщ():
    value = 952368
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BguwYwMj+r5XEzfxz2mgAw0nzHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΝΕДνΜΜвжФЕыфъΚ():
    value = 93543
    text = __import__('base64').b64decode('cnZKWkY5MXpGN0tqaGNKZUFqYnE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬДτηβΓцλΟΒМξЪ():
    value = 847190
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQnpOFkr1oNbLVqo43uyMjwZ1kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()