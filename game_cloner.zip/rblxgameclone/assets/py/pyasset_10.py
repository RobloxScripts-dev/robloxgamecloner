#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _сцэΛфφΤДΓнΔοе():
    value = 60188
    text = __import__('base64').b64decode('YVdCeXVuaHM1ZmloQzFka1BuZWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛтЧнΖшшΓЮξЮΠс():
    value = 989593
    text = __import__('base64').b64decode('a1NSOGNOdU5hQ05wcVhTWkRYOTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥХμНΗεΡρФЖβьА():
    value = 808957
    text = __import__('base64').b64decode('UnNDakczNlBZemROSGI0YnZNRlM=').decode('utf-8')
    total = value + len(text)
    return total

def _бКααЦπωл():
    if 3 * 90 < 0:
        _dead_4470 = 271
    value = 656358
    if False and True:
        pass
        540
        244
    text = __import__('base64').b64decode('YW43d1M2MXBJZU1YbGZ4dXpUOUw=').decode('utf-8')
    total = value + len(text)
    return total

def _йНЮΛςЛТэ():
    value = 876630
    text = __import__('base64').b64decode('TWt3cUFUb2ZHVUhmOFBYMEoxd3g=').decode('utf-8')
    if False and True:
        _dead_5554 = 324
    total = value + len(text)
    return total

def _НмΛГуеφαЮрΧξ():
    value = 347284
    text = __import__('base64').b64decode('UDVURUxMQWtXSUpkOGhlU1hiRVI=').decode('utf-8')
    total = value + len(text)
    return total

def _κСкГКшΙΔкГχθκξ():
    value = 657584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwHNeGcR05IUNiaR8lyRACMb80E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΟφαаПЗХРΒщгоЭмΘ():
    value = 601028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTn8XVQYxpdRDgaNwFG4Pj0CsFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РуЙЦΙлτцΓ():
    if 61 * 10 < 0:
        _dead_4838 = 632
    value = 201177
    text = __import__('base64').b64decode('YXRoUFlGNFRicXpVcEowVEJiUkk=').decode('utf-8')
    total = value + len(text)
    if 99 * 48 < 0:
        pass
        _dead_7018 = 470
    return total

def _ОΘяΦпКψР():
    value = 900940
    if 61 * 83 < 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('U3ppWHppMDZreDYzRmxnSjh3NjM=').decode('utf-8')
    total = value + len(text)
    if 36 * 63 < 0:
        _dead_6268 = 320
        _dead_4073 = 399
        _dead_1543 = 312
    return total

def _ЯПНсОфρЧЪь():
    if len('') > 0:
        _dead_1557 = 584
        pass
    value = 509067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX/+XQA6/48FDBay8HynGnY93kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΡνщкФжЮΟуЭΔαу():
    value = 854231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgDXW0gr7INaaheS3lmSLXce9nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΓХЙЮρхΟзуы():
    value = 112290
    if len('') > 0:
        pass
        881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHvAfAIS2bsaFDax2WLABwE/7GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОГЩаΑлΞωеИσлШΟвο():
    if False and True:
        pass
    value = 403666
    text = __import__('base64').b64decode('bzNxa1RwUHBGR3ZLWGlPUzhhS08=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖГΗλяеΛЯЩъαО():
    value = 326130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnzOe2cDzZAbCQWm0UC/NwoGyjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6236 = 897
        432
    total = value + len(text)
    if len('') > 0:
        _dead_5340 = 360
        151
        _dead_9567 = 455
    return total

def _жωмξθΩλγΡ():
    value = 235892
    text = __import__('base64').b64decode('RkFFNWFFeTlGZ3lDTURGZ2NXQjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭщуЖεЬэΔлλΦ():
    value = 907415
    text = __import__('base64').b64decode('RU4wc2trNG14RFBsOTN1X1NWNFc=').decode('utf-8')
    total = value + len(text)
    return total

def _кΜЬΗΘЩРτЕиΔΖ():
    value = 366477
    text = __import__('base64').b64decode('S2JScFRCcE16Z3RxZGFqYTVXcmw=').decode('utf-8')
    total = value + len(text)
    return total

def _фюьιΔΖοаУΤу():
    value = 447665
    if False and True:
        958
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3zcT2QM8/BSOwSNy3mhHh82wXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _φАйСΞАΚαπ():
    value = 358866
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB60N1Qtx4UzK1yB5G7FEgN5sno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _бΧыкΥμΒЮоφсςэсΤи():
    value = 629342
    text = __import__('base64').b64decode('UEd2Q1ppTFRtMk5Gb3FZNUNUemI=').decode('utf-8')
    if False and True:
        _dead_1553 = 141
    total = value + len(text)
    if False and True:
        _dead_8885 = 504
        _dead_9723 = 943
        274
    return total

def _ХμьΠввαΧ():
    value = 708260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA3IWmsfqKsMFQqz+1SFIXEQ0nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 50 < 0:
        145
        _dead_8998 = 568
        pass
    total = value + len(text)
    return total

def _ΜΨΔУЭξтρα():
    if len('') > 0:
        708
        _dead_4834 = 517
    value = 476651
    text = __import__('base64').b64decode('TDk3Njh1ZVBKcEpFdHBJbEFDR08=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _πСшΞВςМюЗАζΡΝ():
    value = 918451
    if False and True:
        2
        _dead_8369 = 714
        473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz/0OEUI5KkuLA6n5g7BDCwHyl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υюТχЯΓюΛΚθъ():
    if len('') > 0:
        pass
        347
    value = 336092
    text = __import__('base64').b64decode('QzZkSnpBaFYwTzB6dFVtaFA3RG4=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _зΩжьψΧΚδΒψКоЪ():
    value = 987896
    text = __import__('base64').b64decode('SGo5RW8xS2Yzd3FmZEpRdjlHbnc=').decode('utf-8')
    total = value + len(text)
    return total

def _υвΤйγβτбΔςхоъεАλ():
    value = 814099
    if False and True:
        983
        pass
    text = __import__('base64').b64decode('c3lHUWJ0cXp1UllHdkJ1ajhrTTc=').decode('utf-8')
    total = value + len(text)
    if 95 * 20 < 0:
        221
        51
    return total

def _оЕΛΤυЪШуπψЗιШτΩ():
    value = 561303
    text = __import__('base64').b64decode('T1F1OXNIYjNqX3h2azhwT0NSVFo=').decode('utf-8')
    total = value + len(text)
    return total

def _γПΦЮбЩоъ():
    if len('') > 0:
        21
        294
    value = 39358
    if len('') > 0:
        811
        pass
        _dead_4702 = 199
    text = __import__('base64').b64decode('bmVWVUl6RUZ2MTZxX2F6ZEhSN2M=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2859 = 729
        413
        _dead_3876 = 590
    return total

def _ЧФЗψΕГЦхЦЗъ():
    value = 303625
    text = __import__('base64').b64decode('bVl1ZUNKbnkxa2FNcEpIM0xPdHA=').decode('utf-8')
    total = value + len(text)
    if 63 * 4 < 0:
        _dead_1250 = 19
        pass
    return total

def _АЪУЪΒПЮпΥΟΑЮ():
    value = 976001
    text = __import__('base64').b64decode('bW9sU3ltdWUxVXpyV0dBZmdmSnE=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6841 = 18
    total = value + len(text)
    return total

def _ΦιЛΞδИдхΤхΤШЯБи():
    if 98 * 98 < 0:
        _dead_5065 = 61
        _dead_3193 = 206
    value = 658084
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ij+zNmke/P8xCDCXy1eXbSMt8mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        654
        449
        454
    return total

def _ΝЬйΤМпΧΣЩβчωΗЯ():
    value = 624840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSjyP34Ox6YAbSms4mOFJ3EBxnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚβЩлВЦΔΟфЩ():
    value = 720960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzrpRUQw1vAmFVuAn1OJYAF+yz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кαусЖрζСЛгЫЭΔμΥ():
    value = 119539
    text = __import__('base64').b64decode('VWJrOGM5TWNpUkdWX3M3S0hfZ20=').decode('utf-8')
    total = value + len(text)
    return total

def _νΦоΔпЩΚъях():
    value = 283520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSzRelNo+6ozbQ6TmQOzMzAYs14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΨΘхфуδоШζЯπу():
    value = 759019
    text = __import__('base64').b64decode('cTlWOE5EYWFQdXNBOGNnREFUdUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗБψξлΞщХΛΘНΛАт():
    if 2 * 44 < 0:
        675
        953
        _dead_4443 = 888
    value = 848073
    text = __import__('base64').b64decode('a2JuVDFrNkdiYzUyUDV3S1Rxd2Y=').decode('utf-8')
    if 3 * 72 < 0:
        898
    total = value + len(text)
    if 20 * 40 < 0:
        pass
        _dead_9696 = 748
        pass
    return total

def _φъЯυюГρмЪДχ():
    value = 751032
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATq9QEYh+KcFKVag6XuDBBZ67UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψъΡЙИФΖΘХЦуОψ():
    value = 206298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTi9O3cf/L5QPB6k5A+WJS1/xUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠЮΣΓψбРΖ():
    value = 383876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX/9e1Rgz4MnbhmP+GaqJgwf9Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СεΩБεχΦςЯСрнм():
    value = 329634
    if len('') > 0:
        360
    text = __import__('base64').b64decode('cU9mMFQ1MElpWjZCYzRKWEdKN0s=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2961 = 364
    return total

def _РΨшΧИΡхαо():
    value = 1549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQ7Ka3Yt9vtbLAjy7HGpbAI+z2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        489
        pass
        pass
    return total

def _πЦχсτφςΟХΝл():
    value = 928434
    text = __import__('base64').b64decode('aUtOMzVQeGVIeUJaZk5CQ2tSaUk=').decode('utf-8')
    total = value + len(text)
    return total

def _кДξухЮДΑРΩцаψЛς():
    value = 684490
    if False and True:
        pass
        _dead_8552 = 862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxvBPkQN2a0rFS625HHJMw9+xWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        682
        745
        pass
    total = value + len(text)
    return total

def _ΦЬдяΚУΑТοЙо():
    value = 833129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwHXSAkV3YYnPSe30gKcJCMlyGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρфЩядйρδ():
    if 14 * 45 < 0:
        pass
        _dead_9111 = 936
        _dead_3460 = 513
    value = 500123
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH/9XkIc0v0nDSfxnE61bCM+90A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1679 = 487
        996
        _dead_6587 = 857
    return total

def _ΤΥΩнχЗφиοΞЯλΞжσ():
    value = 613478
    if 10 * 84 < 0:
        492
        _dead_7921 = 880
        952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj3jZ2Rg35cwKgaP23W+DQR68mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭмκГлΚΕΒчТΨН():
    value = 944477
    text = __import__('base64').b64decode('cHZKVHpwYmIzb1VhMFEyanZlT1I=').decode('utf-8')
    total = value + len(text)
    return total

def _πεЮбργνπРγзμΠ():
    value = 535787
    text = __import__('base64').b64decode('b1V6Q0ZLSHB6SHlyUkE3SjVfZEk=').decode('utf-8')
    if False and True:
        pass
        _dead_2133 = 648
        570
    total = value + len(text)
    if False and True:
        568
    return total

def _ΔуПτιНфкΟΟъοΟ():
    value = 495834
    if 62 * 76 < 0:
        _dead_9478 = 240
        _dead_6762 = 131
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eyj8VAVv96UoDRu2y2KFLBAo5mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОохоаУεлб():
    value = 601101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBn+fwAK2owUDR2JnXjEFSg9sFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЫΘйщΟςМйнΠ():
    value = 930050
    text = __import__('base64').b64decode('TDY2T1hKMHJaanVHYjhOdmRheEY=').decode('utf-8')
    total = value + len(text)
    return total

def _йЖηфкчРпРπυζНхΙэ():
    if 11 * 14 < 0:
        _dead_4171 = 983
        383
        108
    value = 92903
    if False and True:
        _dead_5926 = 309
        pass
        87
    text = __import__('base64').b64decode('c2RtQ3lSTmpiVzZ2UzJrR3dKYkU=').decode('utf-8')
    total = value + len(text)
    return total

def _шПоциоπры():
    value = 818037
    if False and True:
        _dead_3008 = 833
        826
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CivKWlsur/gLCS2Rnl2GOSQ/wWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΞбдЭЬЩъΣЪкθΙчлй():
    value = 349384
    text = __import__('base64').b64decode('R0RkRUM1a09kVXZDaGpkblQxd1A=').decode('utf-8')
    if len('') > 0:
        _dead_2975 = 707
        _dead_1783 = 450
    total = value + len(text)
    return total

def _бэαчηюΨΦВΡΙвγг():
    value = 65638
    text = __import__('base64').b64decode('YTZPNmcyNU16bmo3OVVDZW1TUEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΗаδμНъюπЯΘЖЮΠэМ():
    if len('') > 0:
        pass
        pass
        pass
    value = 200166
    text = __import__('base64').b64decode('TkZZUWhUT3daaFViOEJZYU1HM0E=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _щФВυψγэКщψι():
    value = 66547
    text = __import__('base64').b64decode('TDF1R0JBUjRrdGEzakRnaER3eFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩАЬΜиЮЪАβзΞФт():
    value = 741007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCyxfEsb5JgKNBa26lyBYSYQ6lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гκзΟΜЧХγυμГπΤ():
    value = 721759
    text = __import__('base64').b64decode('QWNDRjBaV0RGUXVQM3k4MVlPQWc=').decode('utf-8')
    total = value + len(text)
    return total

def _гδАφΠГдδΜΨΗΛъ():
    value = 224727
    if 66 * 7 < 0:
        _dead_8308 = 983
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DA79UXQ4zpAzLy6t0mGIC30twEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 30 * 77 < 0:
        pass
        pass
    total = value + len(text)
    if 2 * 68 < 0:
        973
    return total

def _ΕΚΡЙΡΛΠйιзоПнΩГ():
    value = 104757
    text = __import__('base64').b64decode('ZFIxRXQ3WFdYR1o0UW5fWUdUak0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΚХлАцдЖτ():
    value = 441750
    text = __import__('base64').b64decode('dWRVTzNrN0w1R0xCeTlpT3ZuTnM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        504
    return total

def _μДΔМфξΣλ():
    value = 83849
    if False and True:
        _dead_7469 = 492
        _dead_3877 = 21
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAHTNngp7vAUYwry7HySHxwpzXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7537 = 958
        _dead_3190 = 174
    return total

def _ЪςщщяЪыЯшΞи():
    value = 423584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CizwPlRozYMVCQOp42fHC3Yj7XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΗЖЮεйδЭЙЧΜА():
    value = 994954
    if 81 * 11 < 0:
        468
    text = __import__('base64').b64decode('dnZpQUVKUUVqS0VQc1hlQ3ZTejY=').decode('utf-8')
    total = value + len(text)
    return total

def _мЗΚфΡуъУξЙλΡЬъ():
    value = 5821
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('TjdQNDlpUU9rQXd5bGdHSlFTdGs=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _νрЮΚэΛιсФ():
    value = 691973
    text = __import__('base64').b64decode('S2VJbGNxMWd6Z19SaEo5Y1l0Vko=').decode('utf-8')
    total = value + len(text)
    return total

def _МлΓвнИфс():
    value = 279225
    text = __import__('base64').b64decode('d0NFaG02N25OUDlLZjVWM3hTc3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜзψβАΧГεχЛСТН():
    value = 400594
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA72SENrpo4uKhux6VqJJTR202U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щЗВэφэΞЧα():
    value = 744232
    text = __import__('base64').b64decode('cDdnSTd5cjRUaEZyRDR6Q0pNb2E=').decode('utf-8')
    if 76 * 53 < 0:
        948
    total = value + len(text)
    return total

def _НσшΒюςУюθγρλв():
    value = 961786
    text = __import__('base64').b64decode('RW83c3VxNnR5RjJybjNNRXNtRU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤеσΧΩОνКПАη():
    value = 301066
    text = __import__('base64').b64decode('dXRISGpsSXBTMGxNNElFcXlqN2U=').decode('utf-8')
    total = value + len(text)
    return total

def _зГнБюскНчНΜβΤ():
    value = 186463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRqydAQ38vooMD2izFyIMQgj6Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РХдЬΝгьСгПЙΑρфΡ():
    value = 832150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx/jP3wv7b1WPAKb7nipADw91UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιδкДфсΔΡ():
    value = 147365
    text = __import__('base64').b64decode('RzBvVTFYOXFUVXo2OG4zVDRqWUQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΓβΦщΚΙОеЭφ():
    value = 917380
    text = __import__('base64').b64decode('WDJ1M2JkSlprTXBXaWFEbmtFTGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙхΔэгкηоъэЖй():
    value = 552724
    text = __import__('base64').b64decode('bmhDaUt1T25GUjJsV21xRFZkN0E=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8848 = 585
    return total

def _КωςΒοшщπΜΗАΖдЛС():
    value = 284458
    text = __import__('base64').b64decode('WUFhV2MyN21ZQUxQdndKdnpfV3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ШκΘЫιξипчйО():
    value = 534328
    text = __import__('base64').b64decode('V29HdlhIR0JKRERFbWFoUnFsYmc=').decode('utf-8')
    total = value + len(text)
    return total

def _σΥΠФρВЩοДσΛГ():
    value = 417338
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHzbOFowr5sRbFiHwGeHFyp5x2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чяΦПΖЕΕМΝЯπЗЦν():
    value = 78231
    text = __import__('base64').b64decode('UW5LMUdzQmNLa09KeU5zMTg5SEo=').decode('utf-8')
    total = value + len(text)
    if 76 * 77 < 0:
        517
        pass
        _dead_6277 = 560
    return total

def _ЪΕФхксЪЭнФ():
    value = 283010
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDzRNmY3zbwzOxb08WS8JSAg/EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЬАκυχΧм():
    value = 66298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASPvXwk17vgXNiun5AeIDQMG4T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΘγуςΗфгь():
    if len('') > 0:
        _dead_1090 = 78
    value = 70590
    text = __import__('base64').b64decode('VjkxU24zTlpRQzNkdnFQSUZ5RHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _нΞΣаЮΡрЖεОЙГΝΥ():
    value = 772271
    if False and True:
        _dead_1422 = 436
        933
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nje3RlArrpIbAhe1+32cIhcC4kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        699
        pass
        pass
    total = value + len(text)
    return total

def _ВБΓΝеижкΘЯΘσ():
    value = 569761
    text = __import__('base64').b64decode('S3FPNjJCbTY4eUxXUWVqWXJuRkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ъбεлμХНβсЧψНζлΙΨ():
    value = 585134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3jnTV5r+JpQEwuFmX2RIjMB4Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςОξзФпфЮвο():
    if False and True:
        _dead_6874 = 578
        pass
    value = 791977
    text = __import__('base64').b64decode('dl9VZlhMUG1uOEVNR3M1REhFaE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘФВεъγΟьΕΙπγιЖττ():
    value = 958214
    text = __import__('base64').b64decode('eXF0WGZUR05Bb21hMnVJZXdLVmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮийΘшЧАσчΝБйжι():
    if len('') > 0:
        _dead_8621 = 50
    value = 482959
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABrVflIg0LlWIAyHxHWmAxAi9mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2054 = 453
    total = value + len(text)
    return total

def _рτЬаОЬрθμП():
    value = 395848
    if len('') > 0:
        169
        pass
    text = __import__('base64').b64decode('U2hOc1NFQWpQOVBXd1ZHUFlYMkE=').decode('utf-8')
    total = value + len(text)
    return total

def _бтσιηνьβл():
    value = 87188
    text = __import__('base64').b64decode('b1g3Ql9uN3k4Tk5nekhwcHFKZ1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫςσэψηтΒΨΚνΕεΑγ():
    value = 346208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSnib34b/7g2HVb7wEyYBBw5tjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟюАюψΜВЛЮσαЩюЯρВ():
    value = 400880
    if 44 * 44 < 0:
        pass
        884
        503
    text = __import__('base64').b64decode('T0x2OUl5aURFYUIycTRlSHI2TlI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΛσΦιωшΛик():
    if 2 * 67 < 0:
        944
        _dead_4747 = 590
    value = 3845
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDvsW3I8rZ4lDRz6mlukEScAxkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5232 = 135
        _dead_9587 = 620
    total = value + len(text)
    return total

def _сщЧЦдУπмθΧΔδХДΚ():
    value = 471111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3zyX19qy4AuKDWH4EGJI3Q7zEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΥχΞьтхΚОПρЩХД():
    value = 39832
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pz2zOl84wZkbCiT0kGOlOHYitnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эбдУΙЦΦЦЩςпσΖй():
    value = 330124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgrOTGIb9/sSACaOngaTYCQ680Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΓΧЫзΒЖΙγΘ():
    value = 388870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg3vXFwj2Pg7YlaPxAbJEh0743Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СэΞИυЪВΜΓΣПЫиεЧз():
    value = 575312
    text = __import__('base64').b64decode('bHNYTFJVQk9uaEF5bkJIVWF0M2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΥиΓφхжЧΜ():
    value = 323424
    text = __import__('base64').b64decode('TzFobWlyUnV1XzBBY1d3UVFFN2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ТυΩяοκВХνТвχлеБЬ():
    if 66 * 86 < 0:
        pass
        pass
        pass
    value = 77040
    text = __import__('base64').b64decode('dDdTNXRKM1hGUkFOUjZZZGxnRDc=').decode('utf-8')
    total = value + len(text)
    return total

def _жΩЧЙχСщзψЗъ():
    value = 475007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyHQSGIJ54QJECiB61evOnAj0js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖμρГρмХΗρАэ():
    if 52 * 47 < 0:
        pass
        778
    value = 136683
    if 41 * 96 < 0:
        309
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCe0dFkLq79VHSG5y3nGID0Mxmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йШРΓΩжяЬκΔЪИ():
    value = 40360
    text = __import__('base64').b64decode('QjRUVlBsS09CMk5DanA5dDZNeGo=').decode('utf-8')
    total = value + len(text)
    return total

def _θАаΝΤφаЦу():
    value = 83808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jj3gQlc0xIEZO1+26UPJISANtWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        47
    total = value + len(text)
    return total

def _ьφНαьЯзчфΙДοэ():
    value = 889343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh7+fgM/5p1aaT+E2Xm8JnJ71mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НшτΘτΞεйЙреβγΓ():
    value = 276459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAbTWgcQ0Z0CAiSi2k+GEwZ+7WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜслЭЕΦΥΥ():
    if False and True:
        936
        869
        _dead_2978 = 154
    value = 581766
    if 19 * 72 < 0:
        pass
        pass
        _dead_3660 = 938
    text = __import__('base64').b64decode('eXJUQTNxa1hrME02Z29SeVpJNEc=').decode('utf-8')
    if False and True:
        495
        _dead_3268 = 618
        pass
    total = value + len(text)
    return total

def _τψΒζωςΝΗНκπла():
    if 5 * 99 < 0:
        pass
        pass
        _dead_6341 = 931
    value = 638977
    if len('') > 0:
        72
        149
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhDieFsB+4M1YwaK+EaDDiMk0V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цЪЗρлшдσщλΗφΔы():
    if 74 * 65 < 0:
        _dead_2844 = 835
    value = 838737
    if False and True:
        _dead_6057 = 206
        141
        _dead_6815 = 15
    text = __import__('base64').b64decode('RnVGa0lYMjNWbkNjckRWbWF4YjA=').decode('utf-8')
    total = value + len(text)
    if 70 * 4 < 0:
        pass
        _dead_2278 = 995
    return total

def _τпЖΙшЧЗΒιαЭИσ():
    value = 234330
    text = __import__('base64').b64decode('bzg5YUFrZTI2T05IdnFHRmNDY2E=').decode('utf-8')
    total = value + len(text)
    return total

def _сыэФЦГйСн():
    value = 527799
    if False and True:
        _dead_3541 = 991
        _dead_5312 = 870
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHmwdAIQ+fwpbTes4lGKNgcO/GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8096 = 536
        pass
    return total

def _зΘωФсэΣξΓиЮωЦκ():
    value = 363050
    text = __import__('base64').b64decode('VEFTRk53VXhSZ0lyaFFEeThTbHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _фΕГцχΟΦμВтДймΒЙψ():
    if False and True:
        411
    value = 490422
    text = __import__('base64').b64decode('R2tjanlZaWVOTkwzZW9DMVhvMEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΑЕвЛуΣΝσП():
    value = 950597
    if 59 * 83 < 0:
        _dead_3831 = 219
        _dead_3180 = 379
        _dead_7382 = 112
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiSzYXgBzJsqFDuX0lmKJS0sw2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 100 * 82 < 0:
        465
        473
    total = value + len(text)
    return total

def _эмΒТЩъκтБЭΗГЮ():
    value = 764178
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz7JYHBr6qIPAgekmHWzEjUuwTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гδСцΩВФтоЮЭГОУλ():
    value = 849596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjX1eX8N1q4yKxew2XfCOhcj42U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΗцθыθВЗ():
    value = 124960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQDTN3I2xoQQETiry3W5DBAjsG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        250
    return total

def _ЪΞхйИхηгβЗ():
    value = 467866
    if len('') > 0:
        pass
        867
        735
    text = __import__('base64').b64decode('dWJJcGxMdUI5SXN4ZjdKdUNFdXM=').decode('utf-8')
    total = value + len(text)
    if 5 * 56 < 0:
        304
        843
        _dead_6000 = 1000
    return total

def _ЖεАУЕВчЙю():
    value = 919752
    text = __import__('base64').b64decode('Y2RySW1pR2p1TklOQWRwbk01a1k=').decode('utf-8')
    if False and True:
        873
        465
    total = value + len(text)
    return total

def _рΠΟΦеЛδωЕД():
    value = 35453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ljv+fHovzolXYyyM4gayCyYY20g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΖнЦмЙоΤ():
    value = 455386
    text = __import__('base64').b64decode('WmY1RzhLdHMwWTljVUJYbDVqYWg=').decode('utf-8')
    total = value + len(text)
    return total

def _θрΜЦТΦЙХОБΔ():
    value = 330221
    text = __import__('base64').b64decode('ZUJHMEZFc3RXZnZYcktpRHpDX3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _αФΤчτωΞНΧыαΝт():
    value = 165378
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IH/XO1dg2f8tHQ6rx2a3YXUI3X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΦΓΓиМЦуΡ():
    value = 690695
    if len('') > 0:
        674
        93
        pass
    text = __import__('base64').b64decode('d05OR2ZmX05KeGNRTUEzN3J0Q0I=').decode('utf-8')
    if False and True:
        _dead_7791 = 973
        289
    total = value + len(text)
    if 65 * 35 < 0:
        pass
        568
    return total

def _ПпцΗσяшмρъЬ():
    value = 754314
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHbJXXQpp79VCzuW7VCFLg9/62o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙφΔΛζххΔФ():
    value = 507242
    if 48 * 30 < 0:
        601
        _dead_4158 = 15
        341
    text = __import__('base64').b64decode('SGpKOTBJOEpVS3ZKTDJFOG95bDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠМъΤШМЦπсΨΥЧΙθΒ():
    value = 738704
    if False and True:
        _dead_3886 = 961
        _dead_4601 = 458
        _dead_1235 = 178
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQj0TAADz5kVAx+E6lSkBwQ3yz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 28 * 47 < 0:
        pass
        _dead_7969 = 760
    return total

def _ОУЫρЫшЧФАВбйψ():
    if 65 * 15 < 0:
        pass
        404
    value = 468279
    text = __import__('base64').b64decode('RjVYTmNVVW5DREpWZWlzcWN2M3k=').decode('utf-8')
    if len('') > 0:
        85
    total = value + len(text)
    if 68 * 27 < 0:
        _dead_6028 = 347
        _dead_2148 = 842
        pass
    return total

def _ЙζХмРюςκцΖα():
    value = 910272
    text = __import__('base64').b64decode('dVNWOVFrQUpIaUdEZzRxWmh2ckQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖνвхНμΕΚуъ():
    value = 36664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRzpTAEUxIcAHRWu5HqfBHEHtkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αоюцςΡΕΣюφК():
    value = 370503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD62XWQJ8vsMGBWvx3jDNXME0HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        71
        pass
    total = value + len(text)
    return total

def _пВьгТцΘыΡπΕ():
    value = 31148
    text = __import__('base64').b64decode('TzJuX3pJSm1Cd2taeVRvQVpJSGY=').decode('utf-8')
    if False and True:
        pass
        pass
        150
    total = value + len(text)
    return total

def _ΝысЙοΗяθоЦ():
    value = 186771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg61SwAN7LApMAyO+n2pPjMj9Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цвлΨНжΡΕ():
    value = 221931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX3wbUAs8vs3Ywi5y324Jhctxmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΓΡΘБΚΣЬγΥυщε():
    value = 963162
    if 3 * 65 < 0:
        _dead_2372 = 398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSqxV0Uv1448MBiSynK5LhYl/U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 31 * 72 < 0:
        936
        pass
    return total

def _тхйнЯΠжσЛτъХΝМЩΟ():
    value = 463978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgL2TEI92/ombhmV7n62Mg8/0zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зЮЮиаЮΑπлйиσ():
    value = 422644
    text = __import__('base64').b64decode('b1VTaFZzU3FJUzdoSXhxeEdFdDE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЕлАσЯΜΤЙβсгΗМΦςΝ():
    value = 626317
    if 24 * 24 < 0:
        _dead_9245 = 810
        pass
        402
    text = __import__('base64').b64decode('WUd4bm5XdXpoc25EWUcxUE9ObFk=').decode('utf-8')
    if len('') > 0:
        52
        449
        _dead_4717 = 129
    total = value + len(text)
    return total

def _ΙΔгоКΑΔиλДЩыςъ():
    value = 857192
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX3FYWgz6IEaKSCc7HjAZRE+zkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωεфИНΜβΑ():
    if False and True:
        _dead_9549 = 531
        pass
        pass
    value = 924516
    text = __import__('base64').b64decode('UXF6WFdIN2c0S2Y3OE5IaGhfR0o=').decode('utf-8')
    total = value + len(text)
    return total

def _шчΛΨωΧψюυΟΟж():
    value = 993554
    if len('') > 0:
        _dead_5130 = 655
        _dead_8907 = 229
    text = __import__('base64').b64decode('RDdPXzk2dnpIMENvUmdMcTdwRkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝнЗΛайΜэйβομσТк():
    if 15 * 58 < 0:
        _dead_2365 = 641
        763
    value = 46877
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('Z2dUZEpPdzJ3QnpORGNYQmlCMHM=').decode('utf-8')
    total = value + len(text)
    if 51 * 66 < 0:
        _dead_4971 = 849
    return total

def _аммΤιнωΒ():
    value = 991894
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBv+XHkt7KxWNiWXwGK9FgoY9V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αЦθрΩЧΗΝ():
    if False and True:
        _dead_6661 = 112
        940
    value = 435927
    if len('') > 0:
        110
        pass
        258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BALTZENs3YkAMAWA4ETGGH0Lsj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΓхмУΨФψЦφШНδЪш():
    value = 255558
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxfeaWgf/6xbOwKZnXK3IQJ96nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        950
    total = value + len(text)
    return total

def _ГДΝлγоωΒΝχακЛΦ():
    if 62 * 73 < 0:
        pass
        677
        349
    value = 226745
    text = __import__('base64').b64decode('ZWE3TjRpSU16UnJINjJDNHZaSTI=').decode('utf-8')
    if False and True:
        pass
        _dead_9727 = 445
        pass
    total = value + len(text)
    if 1 * 40 < 0:
        pass
    return total

def _ЪφВЧИχоэΙΠкυ():
    value = 36394
    text = __import__('base64').b64decode('aEttVGVfaVkzTFlEbXgwMVEyVzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ОйΚЙВЖλΣ():
    value = 926627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDfiaHwp0o8UOCm0mHqWIS8twn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мЫЪσбρρΝЩЫдкпψц():
    value = 754083
    text = __import__('base64').b64decode('dlB4SUV4SFMzd29mMHBZWFlXa2I=').decode('utf-8')
    total = value + len(text)
    return total

def _уΣНΙΟВДΕн():
    if len('') > 0:
        949
        47
        326
    value = 609034
    if 59 * 4 < 0:
        _dead_6980 = 581
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQHTaWEW3a45CBj7/VWFFjE670w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЫΞσелΤч():
    if 57 * 64 < 0:
        _dead_5124 = 596
        849
        732
    value = 775453
    if 55 * 30 < 0:
        20
        424
    text = __import__('base64').b64decode('SWpwQXp1SWJRVGRzQ0hRVnZtb08=').decode('utf-8')
    total = value + len(text)
    if 24 * 8 < 0:
        _dead_7234 = 180
    return total

def _фζРеВукΘΨΧ():
    value = 267567
    text = __import__('base64').b64decode('RmlfS1hLaHZ4Ynk1QkR2aXA3cjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥбССБиБц():
    value = 307857
    if False and True:
        492
    text = __import__('base64').b64decode('djlHVndEMU50cUtrSEVjQ3FQVFg=').decode('utf-8')
    total = value + len(text)
    return total

def _яГΓЕЭЛΩВΡαщпκ():
    value = 310926
    text = __import__('base64').b64decode('WmQxRU93cGFwT080MjA2Tjh6dTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒцΞФΗΟλΨδΒНЦ():
    value = 550910
    if False and True:
        204
        771
        _dead_6737 = 548
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHrSWnAhxPE7NiSA6VPEYA16yHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()