#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ωοфΠΗΨφδ():
    if False and True:
        pass
        pass
        pass
    value = 245533
    text = __import__('base64').b64decode('UUNtN0xGU1o3ZHVkODJHVm5lWkQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        601
    return total

def _ЪАςζЧξЙЪяБХян():
    value = 974686
    text = __import__('base64').b64decode('ZmtOeUluSEc0am1zZXNxaU15Vno=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒрΤΦЮАΠωтρφгты():
    value = 119015
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDWyZWgNqJgmYgKS3luhYS8lyW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жвЗГЛΣιωЬЮГЯ():
    value = 338384
    if 52 * 88 < 0:
        378
        pass
        439
    text = __import__('base64').b64decode('Z0xkdkxzVHJiUkVwTFVTbHhEeXg=').decode('utf-8')
    if len('') > 0:
        _dead_5744 = 787
    total = value + len(text)
    return total

def _ΝБОЩΧαΤкц():
    value = 207603
    if False and True:
        pass
        608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyXPQHYVrvoCKAy7yXehOQIks2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        735
    return total

def _жЪБСЙуΒЩεΩсδЩ():
    value = 595173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhnNOlVv8oU3FVuqxkaDAB8g/Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗнШщвΡθШЖ():
    value = 316155
    text = __import__('base64').b64decode('WlZjWDB5bE00ZFhhN2NHcVZpN0k=').decode('utf-8')
    total = value + len(text)
    if 61 * 13 < 0:
        _dead_7524 = 67
        pass
        pass
    return total

def _ωκωΜβοΙлтΦо():
    if len('') > 0:
        682
        _dead_1507 = 816
        pass
    value = 622830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzbxdAgh96sbAwKi+WCZOnIewFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4573 = 764
        pass
    return total

def _хξХδΣПпПρчъζьШъΟ():
    value = 437256
    text = __import__('base64').b64decode('aEQwWTR0Q050ejAzaXdvMVRpRUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΥφиΩмΔУ():
    value = 530101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDfBWH4O+YUhACmw72mhZiN27ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 24 < 0:
        308
        811
    total = value + len(text)
    if False and True:
        458
    return total

def _θцкΓΕУγоФ():
    if len('') > 0:
        _dead_4100 = 264
    value = 863908
    if 92 * 54 < 0:
        pass
        _dead_9651 = 557
        _dead_7214 = 561
    text = __import__('base64').b64decode('d1BXMXc5TWo5UFp4RnVUUGJBaHE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        137
    return total

def _εщЖСГБАМлЮ():
    if len('') > 0:
        pass
        _dead_1945 = 627
        376
    value = 254626
    if 5 * 43 < 0:
        373
    text = __import__('base64').b64decode('d2x3SnhwYWRBMExxT1JzNXNzbUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒιЫбтΧЯп():
    value = 262841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR7AV11sqac8Hyyw92SdHSc8szk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_8537 = 661
        _dead_8043 = 45
    total = value + len(text)
    return total

def _ЫзΩиЕхХυΜЭСмМπД():
    value = 709806
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyjVbEBu7boZKRih5FeIYHR763Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 94 < 0:
        _dead_1770 = 322
    total = value + len(text)
    if len('') > 0:
        969
        pass
        963
    return total

def _ХннκηхρΖυΜ():
    value = 902668
    text = __import__('base64').b64decode('cW1WN0NwMkwySWpsSF9XTVdqbDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣиХμπγΕп():
    value = 469467
    text = __import__('base64').b64decode('STBZTDYwRGVweEFwSlhuQjFQYUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ьаТЩдβΛМΔ():
    value = 85074
    if 23 * 100 < 0:
        _dead_5004 = 770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHvFdwlh2446DiKP/nyRZy0F1Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        18
    total = value + len(text)
    return total

def _κчИθЯЧФцνт():
    if 63 * 85 < 0:
        909
        _dead_3095 = 380
        78
    value = 355950
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwzFUQYdzf1RPCaz4wG/ERMm/H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7264 = 852
        923
    total = value + len(text)
    return total

def _ЛδЩσцχαβуУγΘ():
    if 64 * 24 < 0:
        pass
        206
    value = 402206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj21ZmEr8bwzOxeU+3ivGx0o7k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГμΔΓъЩΥΠаζΤпыОйр():
    value = 555495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRjmXgMBqrEAblmZ8lu3DS4F8Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зиСσВРкθΨяАЫЬЖБ():
    if len('') > 0:
        pass
    value = 709168
    text = __import__('base64').b64decode('aVNvcWtxMXJNZHZiMTlncGNHT2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤοшвХаыυχθζИ():
    value = 837042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgbnPUQp7oIQKAml5UG4YxEtwE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        786
    return total

def _НЯεΗгРΥНнΣаУχзЮω():
    value = 118000
    if False and True:
        pass
    text = __import__('base64').b64decode('dGEycDNITWFjRnlGX1hNb00zaFg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        805
        pass
        _dead_6022 = 46
    return total

def _нриЦЩЖξЬΩЬЗдТиМ():
    value = 949143
    text = __import__('base64').b64decode('c1J2bThCVU8zVlBLanB4Q3JDcjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝхгοарΦφΛΥγЬь():
    value = 895905
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LynRSnce+pIBbSO04A6THy0Xz1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьпЕηςΡутβШΘР():
    value = 844746
    if 81 * 45 < 0:
        863
    text = __import__('base64').b64decode('ZUJLY3libjAzVU0zOWt4Zk8xVW0=').decode('utf-8')
    total = value + len(text)
    return total

def _оЙъьЦЛоДτТЕУгε():
    if 14 * 74 < 0:
        pass
        _dead_3980 = 245
        pass
    value = 82185
    text = __import__('base64').b64decode('Z3U2dnlBdkRpT2xLbEwyNnVhdnc=').decode('utf-8')
    total = value + len(text)
    return total

def _БΞРΧεσΟφΑьТΨσΛΧ():
    value = 404271
    text = __import__('base64').b64decode('Q3FmMVhhcXhYaVNDNUhtMmY4N3g=').decode('utf-8')
    total = value + len(text)
    return total

def _θςмΟдйΒηΛЧсйдтΟΠ():
    value = 147051
    text = __import__('base64').b64decode('Zl84S2dEdXVNekYzMTJUMElGWF8=').decode('utf-8')
    if 55 * 12 < 0:
        247
        880
        933
    total = value + len(text)
    return total

def _ΙХоχЯЖεС():
    if False and True:
        pass
    value = 34522
    text = __import__('base64').b64decode('TkJwMXB2UEwyQUpqVU9lUVl4dHE=').decode('utf-8')
    total = value + len(text)
    return total

def _цАΥφξαΤУОδБцы():
    value = 983324
    text = __import__('base64').b64decode('TERqZlF3X0IxbUU5YXExM29WV3o=').decode('utf-8')
    total = value + len(text)
    if 91 * 33 < 0:
        295
    return total

def _жΡΝуКАэрСπНц():
    value = 608157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTvKRH5t6Y4FKgCr6kOZEhw30GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ещΩЦΞСОΞхηЩРωο():
    value = 424755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgbreH0T/L8qOx23wEeKExwm61k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭУρежΧЫЧ():
    value = 482986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAG9bAJvqIkTHFqQxUyvZCYN2z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШδЙΨεδрЯμτΖЩАωλм():
    value = 695225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pze0O1sy3Z80HwiJwAC/JzYj730='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_6634 = 838
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_8156 = 643
        _dead_1143 = 49
        674
    return total

def _ИСΣЫτиЖдΨ():
    if False and True:
        pass
        _dead_9414 = 768
        174
    value = 211523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Inj1f1w22aRVaimu/EeqLB0Zx10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 3 * 60 < 0:
        948
    return total

def _ХГфУРЮЕДшΙбδΘжΘ():
    value = 780105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCbQflgd6vsnbiyJ8WCoDBp90lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩыОЧВТХнцгψШΦ():
    value = 511637
    if 19 * 22 < 0:
        _dead_8416 = 713
        pass
    text = __import__('base64').b64decode('YnpJZ2ZRanZ0c195UVh5RFNlYnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞОτιмиеЮЩх():
    value = 792672
    if len('') > 0:
        504
    text = __import__('base64').b64decode('bVFYN0k5UERyTG1jdmNkak1RYUs=').decode('utf-8')
    total = value + len(text)
    return total

def _τΝΞыκнЮΣαТз():
    value = 391771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChXNYEVu+fEUAyWM/3ChOCB+10I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2023 = 216
        _dead_6909 = 940
    return total

def _уηБИΥЦоеΝΣΛιςр():
    value = 706370
    text = __import__('base64').b64decode('QzZOVTZnTXpDVDg4UGd3YWRtUnE=').decode('utf-8')
    if len('') > 0:
        _dead_3675 = 121
        pass
    total = value + len(text)
    return total

def _χЦуяοψъжΣςЛωуνψ():
    value = 488720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCmwRmIT878pPhyFxG6ELgYC4Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фИъвэшςΓШтТυ():
    value = 285634
    if len('') > 0:
        526
        661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH3Pf2Br66wqHgmAwmzHExchyUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        793
    total = value + len(text)
    return total

def _ОηαπжψτΘχбщЦΞШТВ():
    if 25 * 39 < 0:
        _dead_2520 = 710
        _dead_8176 = 915
        _dead_2774 = 945
    value = 770036
    text = __import__('base64').b64decode('UlNseFFNNWhoVzBGR09Gd0lNOWY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2364 = 363
        _dead_8972 = 167
    return total

def _ядеγжБэπξκ():
    value = 923320
    text = __import__('base64').b64decode('ejVsV044bGhrZjFweWVlaHI5NVk=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_8467 = 902
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _аьρМγЧЖССνμхΗδ():
    value = 228594
    text = __import__('base64').b64decode('VTJCbnczQkF0NEI2b1FndmpPWHA=').decode('utf-8')
    total = value + len(text)
    return total

def _РΙΧθФνЦоАμΚлТ():
    value = 281815
    if 71 * 49 < 0:
        _dead_4506 = 991
    text = __import__('base64').b64decode('YjBwcnB5eFpOSGtuTFp6dlVDNE0=').decode('utf-8')
    total = value + len(text)
    if 8 * 53 < 0:
        pass
        382
    return total

def _βЬОЩТПоУЬЯСΩβнЫ():
    value = 100494
    text = __import__('base64').b64decode('QnhpU2VJVmtXWk8xWWN3OUZZalI=').decode('utf-8')
    if 82 * 100 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _яΜюΩхТΜΝУБ():
    value = 137079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHv0fEcb3fhQCDC6xlOUAxML6zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩхшдЪЮкфωХΙζρФμя():
    value = 153659
    text = __import__('base64').b64decode('b0xrZFE1dDhrcThhZVZfT2QyV0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΑεΗРбιΘгΟРиΜ():
    if False and True:
        pass
        pass
        _dead_3447 = 186
    value = 234739
    if len('') > 0:
        _dead_8542 = 169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCPweGI6waoMECGlyWfIOgB29jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        379
        995
    total = value + len(text)
    return total

def _ωΛпьЕцйОуКДэχ():
    value = 982192
    if 57 * 22 < 0:
        765
        644
    text = __import__('base64').b64decode('eEloOVZpdG5GcTVaSldXOWZrano=').decode('utf-8')
    total = value + len(text)
    if 9 * 65 < 0:
        _dead_8308 = 168
        _dead_3002 = 762
    return total

def _ΤкΧлΩκЗΕ():
    if 96 * 47 < 0:
        _dead_6225 = 613
        pass
    value = 602189
    if len('') > 0:
        pass
        412
        22
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAXITAIyqJpSBQqM416HGQB710w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        464
    total = value + len(text)
    return total

def _ГξфΨлΛΦΞτДΜφпрδ():
    value = 294313
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwDeO1Bux/A1Ki6M/Fi8JD0gzjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        0
        965
    return total

def _щбιвЪΣшХ():
    value = 467255
    if False and True:
        pass
        820
        784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH/yOXtt2acIKSap3WGRISEYtEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7717 = 222
    return total

def _ΦоδеНпЮфиσ():
    value = 20841
    text = __import__('base64').b64decode('R05udk1UR2YxelNTYXljeTBzZnI=').decode('utf-8')
    total = value + len(text)
    return total

def _чАышβλйΩΘпЙнμΑх():
    value = 559507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjXpfl8v6JITEx6amQGpIj0O0GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘПκΥчжχШнΡσ():
    value = 200997
    if False and True:
        718
        139
        pass
    text = __import__('base64').b64decode('QkVNRTJDUVRiMXZ5emc0ZktkQ0I=').decode('utf-8')
    if len('') > 0:
        741
        _dead_6675 = 478
    total = value + len(text)
    if 99 * 72 < 0:
        pass
        _dead_4178 = 390
    return total

def _вЕΓЕτчиΑ():
    value = 875459
    text = __import__('base64').b64decode('TF9UeGg2WDc2RVRzZWJLSHlvTGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨМОμσТΦОЕгΖηАА():
    if 9 * 40 < 0:
        pass
        pass
    value = 539140
    text = __import__('base64').b64decode('SF9KY1JYQXV2ZVoyYW1yUGpmT2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ыЯеуЭσугСЪЕρρГы():
    value = 784879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBzxWXhg1YMCNjWE2lmhMBYn83Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щЛΒщΜЪКеИЬЖсΓ():
    value = 752673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kj69PmQw0L4yPQSo4liXGC0pyjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РсШΜфΓОΝτξЩ():
    if False and True:
        88
        pass
    value = 658797
    if 70 * 37 < 0:
        _dead_4238 = 614
        _dead_5161 = 594
    text = __import__('base64').b64decode('ZG5wWWp3b1ZReVNZM1FwMUNHT3I=').decode('utf-8')
    total = value + len(text)
    return total

def _βншΘλдгΖБещвЩМφΛ():
    value = 499969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AC7TOwcy0bFSElmBnnGoPSQk4z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΑμжγЧςα():
    value = 525253
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyPeQ1YA7qQXb1qPkGCkEix8z0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΑΞψпШцПλλΟлФ():
    value = 196236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCDlW3gdx5kqEQGnw2GvHDYuw2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 29 * 79 < 0:
        pass
        pass
    return total

def _ΥьЬЯпχδΙ():
    value = 952624
    text = __import__('base64').b64decode('Rm5nTVphMnJDU2RBUFhKU3JRNVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫХьΥЗУВюЩ():
    value = 709914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzvXSlwd2owHaxes4nW4YSc580c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΔΘйΨЧτБяδΘжχм():
    value = 364027
    if 93 * 17 < 0:
        99
        _dead_8841 = 462
        pass
    text = __import__('base64').b64decode('SlE1d1BCWFhGcUNQMHVfcngzeVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩХйμΚШηтъ():
    value = 4681
    text = __import__('base64').b64decode('REhKcTlMMzlvMThGQWwybE5Zd2w=').decode('utf-8')
    total = value + len(text)
    return total

def _цΨνΥΡмθΨКЙЫγУОκ():
    value = 458465
    text = __import__('base64').b64decode('Z1NhVFJqX2F2NmpNTlY1bUQzS0I=').decode('utf-8')
    total = value + len(text)
    return total

def _νщανОМЯλΠ():
    value = 685266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjjVWUUa0vswOzy0+3+GDAsawjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7577 = 257
        _dead_1431 = 951
        196
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        498
    return total

def _гФюΩФхσеюЬэолΩ():
    if False and True:
        _dead_4021 = 850
        pass
    value = 716025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCDCXV5vrr0hMDagzXidYQg2wn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧСΧЪпшλП():
    value = 115681
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBXHXkkr5K4BLju18nG2ODA/yjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡЫлОыΑзΡяЗЧψ():
    if len('') > 0:
        809
        383
        644
    value = 594266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgnSakAT8YciawOE72yZFyp74Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЬъУОЗЪТе():
    value = 729097
    text = __import__('base64').b64decode('SHlRRnhYTUVQTDVaNUF2MFI1d1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤμкΩφЬеΟυ():
    value = 399787
    text = __import__('base64').b64decode('SkZTZVlXeTF0a3pmTTZEeVMwVm0=').decode('utf-8')
    total = value + len(text)
    return total

def _κПзеэЖЫЩ():
    value = 56233
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgzjZ18I9YYqayCMnUHIAQkjzWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        432
        pass
    return total

def _еΓййκбЧЬфбλЧ():
    value = 883228
    text = __import__('base64').b64decode('c3pIemJsM1RnckN1bUhCOTRwa1A=').decode('utf-8')
    total = value + len(text)
    if 12 * 23 < 0:
        pass
    return total

def _ΠшδоΚПΞИаЭУНЯΩю():
    value = 587237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhfGSEAtxL4RHQeo/VSTByAM0D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2391 = 456
        pass
    total = value + len(text)
    return total

def _уεБτЧσζЧк():
    value = 272620
    text = __import__('base64').b64decode('emlmOUxTamdYNVZuWmJ1b3k0UUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΟИοтτΙφьςПαчВ():
    value = 88297
    text = __import__('base64').b64decode('TmxRTVpnY2pXWGg5TWE2eGpBa2c=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        406
        pass
        pass
    return total

def _воπИςκгτΘ():
    value = 60452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DADqX3Qy8Y0EbQT0kU7FITUBtmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧδйΛдςуΨΧюАгκΤР():
    value = 258183
    text = __import__('base64').b64decode('QlNfUzJPU3U2N015U2drako3UWQ=').decode('utf-8')
    if 37 * 87 < 0:
        pass
        _dead_3153 = 412
    total = value + len(text)
    return total

def _μЦΤючоΨχФэмИя():
    value = 243642
    text = __import__('base64').b64decode('eUFrZGpIX2tSRDhUUHowalFHNTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _еΥπΒеοЮЯКЬхчхΙΠς():
    value = 797201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az7HXms1z6wJFSC52EaoPSYE/lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЦιяΖΡςμΓУЖоЫФ():
    if 65 * 39 < 0:
        965
        pass
        483
    value = 21442
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQf9TAIQ9LkzCz6N+lyZPSR/0Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        384
    return total

def _хеяΚВЪοΣκэ():
    value = 487709
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz3sSlgv8a82KReMnWOIYXR6zXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤШПЮТЮйΩуΓαхитНЫ():
    value = 490075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECbdVlo+xL0aIg2BnHueMHMIxkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШМвВчэщк():
    value = 950234
    text = __import__('base64').b64decode('bVRCc2tRbHNPWXlTZjRDRGI1ZzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ωЪΠВГГЩфΑуΓΤρШМД():
    value = 767934
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID7jX0coxLghLRqQ/0OeMQgt0G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _езΚРДΩАα():
    value = 613898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD61Zktp0voAFV+G62GvB3waszg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _явλжθАιΔ():
    value = 284719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRnpXUYf06EFMyuazUGWOzM16jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъчСДΔжΓПмЕλПЮΡ():
    value = 588608
    if 49 * 41 < 0:
        530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgLRUXYu+78IEziH3EGTOx8CtnQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        850
    return total

def _ьШφβμсχиσΛя():
    value = 818363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRfDRGdu6KIoDjbx/2O8OnAA0js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЫвчΡλΚΨЦЖ():
    value = 968515
    text = __import__('base64').b64decode('bEVIWVdfeFlLXzlOQ2JseTFiVkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ψξΖΟЮШдРκмδф():
    value = 966696
    text = __import__('base64').b64decode('d3cxNkY1c0xLMFRsbUIxWVVPczg=').decode('utf-8')
    total = value + len(text)
    return total

def _иОψщРβНчдыρВЮг():
    value = 206414
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAz3d14L6Y0FMgalmHyxYHYN8jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гЗжλнпλыοЮДΖо():
    value = 175829
    text = __import__('base64').b64decode('Rk5wQllNUDNacVNnb3c2OU9Ibk0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5899 = 719
        _dead_2561 = 741
        _dead_1251 = 58
    return total

def _КбΠτλпΜωПЙтςα():
    value = 949162
    text = __import__('base64').b64decode('ckdaVFR0ZGFVdU1lMU91cVl6bl8=').decode('utf-8')
    total = value + len(text)
    return total

def _нЮνтвъсКΑΑЧ():
    value = 832090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MR60aAYz6Y9bHCr62kSvOj0Xy2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2919 = 7
        _dead_5586 = 399
    total = value + len(text)
    return total

def _φМΒчφъΡо():
    value = 700634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXbTakYu6L4Qbgy0y2KZE3cYy38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εнυΑФΝΘцШэ():
    value = 280949
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwLSZwMU76QzOTqszACaLQwhtVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 43 * 81 < 0:
        pass
        1
    return total

def _ΙУЯхΩНшхЪюβ():
    value = 824218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzvnflMMzoImCSi3zmKWZSEZs0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜдЛφμΘθТΗПМΟμм():
    if len('') > 0:
        pass
        _dead_9900 = 880
    value = 699767
    text = __import__('base64').b64decode('R0hsb2ppWG4wVmM5eFpkSXFGQmU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        500
        86
    return total

def _иФУМΧоΖпчΥλь():
    value = 904398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dye3fnVrrqwXaB2N+Ve0AH0Z81o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΑМΞнΚκчτ():
    value = 288053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah/Ia0to+JAmKBihz0abFSsQ/Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γχПγПЩЪУа():
    value = 603050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDi2WGJq2K0iNzn3+U6mZyEJ0Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥВΦхβОΛКξ():
    value = 113091
    if 7 * 63 < 0:
        _dead_8473 = 65
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAHRf30e6IFUCl3wnnuYLiQLzVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 73 * 97 < 0:
        _dead_7019 = 38
    return total

def _ыБцΖπξαΗρпШчξн():
    value = 356344
    text = __import__('base64').b64decode('TnhvdjZqUUY2NG1PbVVNYlZOVWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛРХζгνФиΤΕ():
    value = 111010
    text = __import__('base64').b64decode('aFJSZGRLV2lLQ0RwVGpsYnMwbWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΜююмπЙЦЛУΤΛМх():
    value = 693847
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT60ZQNtroBbbzW0yWm5Oi447W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΕΣςςФΑЫЯςщЪΩЖ():
    value = 978589
    text = __import__('base64').b64decode('akV2MnJPeGZOWnRzbkdkVkRUaWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _хνΚЫΑпЙПδИξαДα():
    if False and True:
        _dead_9658 = 678
        359
    value = 515976
    text = __import__('base64').b64decode('VF9GbzNpNjhWRjRPSzdzRnBCU3M=').decode('utf-8')
    total = value + len(text)
    return total

def _хΩΛωΚьбγπξΚξЗЫКΧ():
    if len('') > 0:
        959
    value = 891962
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fze2dn48/IoIPSOr7Xi0HiZ9/Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τчщЛзЧΛΣλЬΨЮ():
    value = 397574
    if False and True:
        pass
        _dead_7910 = 604
    text = __import__('base64').b64decode('RlN4MlN0VnNiVVFCdENzMFpOSWw=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_3227 = 119
    total = value + len(text)
    if False and True:
        78
    return total

def _ΨСяΔжуЫл():
    value = 629915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgbQXkFs5pEnFx2F43eVMyM6vXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иπКΣГсΙзθъΛа():
    value = 592250
    text = __import__('base64').b64decode('YkNSSGwzSHAyOEJpYnpnYUVEV0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖκρθгυэтУνпшЗнЙП():
    value = 88711
    if False and True:
        _dead_8872 = 290
        _dead_6193 = 496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyT1fkU+z44ELRuJ2w+5JTMo8ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 97 * 54 < 0:
        pass
    return total

def _ЯНιЩыЫЫЦ():
    if 15 * 18 < 0:
        667
    value = 803680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRfUPFsG0f4nIliy2VrJJw4cxmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7742 = 692
        _dead_8257 = 15
        pass
    total = value + len(text)
    return total

def _зрфЬεОΜЛЕЩшυχ():
    if 33 * 3 < 0:
        _dead_3250 = 603
        135
        294
    value = 404710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT3VRXtvyZkqNzWS/VO9EDIq80A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΡΘтИЯωФκшΞδ():
    value = 292815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRDHbX0sx5AZFyqn7ESAIXEnyTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΡЯПΠΝпογΕυΘьРт():
    value = 518944
    text = __import__('base64').b64decode('QXFGclQ4T0hXT2t4aG81Z3VGTTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΦВаιРнэЦ():
    if 41 * 1 < 0:
        522
    value = 268565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mzrxa2gV+KAPPA2SmkyfbRIN3Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 73 < 0:
        pass
    total = value + len(text)
    return total

def _ηбИΧУПΩЭψыΡΛ():
    value = 127585
    text = __import__('base64').b64decode('V1JrUjVjRGU0REpEQzZJZ1B1SWY=').decode('utf-8')
    total = value + len(text)
    return total

def _πχэθρСяЙдНΓΧ():
    value = 370112
    if False and True:
        _dead_4546 = 767
        pass
    text = __import__('base64').b64decode('T1haVkYwQkJaMmcxYkFCNFdvSDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧОЗЖКеСуПфυΚΩчш():
    value = 692435
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAb1QwYW9rssEAiV4VWIZxF6sW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΜЫΔсιбЗашОадИюδ():
    value = 209412
    if False and True:
        _dead_7340 = 87
        _dead_3698 = 391
        461
    text = __import__('base64').b64decode('b1VHRXdEOEVZMWVkU2c0OXMwdUo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7128 = 89
        526
        _dead_9962 = 741
    return total

def _ъэЖщΥАΖΑьΧΥзОωж():
    value = 508976
    text = __import__('base64').b64decode('Z3hfQ29KV1NqWU9BcjRTZHhaa3I=').decode('utf-8')
    if False and True:
        582
        155
        604
    total = value + len(text)
    if False and True:
        926
    return total

def _νкυоπУμфы():
    value = 480926
    text = __import__('base64').b64decode('d2U3cTlaaDdEUHZpYzNEX3cxMXM=').decode('utf-8')
    total = value + len(text)
    return total

def _яЦЪЬΛΞЩΚαЮэю():
    value = 792108
    text = __import__('base64').b64decode('bkk0b09FaTk5Rm5NYm9hNGROVm0=').decode('utf-8')
    if 42 * 89 < 0:
        765
    total = value + len(text)
    return total

def _ЯЧнΠЙπгцБАлχм():
    if len('') > 0:
        pass
        _dead_5080 = 112
    value = 949089
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyLWWEQT7IoWFhqs7WXBO3B490o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кЫΚФЖцχАзЕшОЦ():
    if False and True:
        pass
        pass
    value = 977774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyG8Y1Af14Y8FS370kHHDhYp2zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4846 = 999
        _dead_9061 = 621
        _dead_1332 = 498
    total = value + len(text)
    return total

def _ΩωцэΛТζЩчМВο():
    if False and True:
        pass
        126
        pass
    value = 611974
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDXPYmIp2osVNiGB+3mmAhMM/U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫПэХΝвΣТΗΧаκАΥ():
    value = 217399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz/uXVAt8rI8Il6G3XHBOQAb61g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        429
    total = value + len(text)
    return total

def _ОΣжΠδбуΓΡчχΜко():
    value = 372856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzbnemkfqZcNLTWp5VeVOC4K3mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _ъАЧζчОΓΟш():
    value = 470172
    if False and True:
        _dead_6255 = 918
        860
        490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATbFO3lo3JFabQb793fIJyws20s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        246
    total = value + len(text)
    return total

def _ΧЦγюШςРСΠюФθМЗ():
    value = 274352
    if 82 * 17 < 0:
        pass
        _dead_4646 = 41
    text = __import__('base64').b64decode('d1V1QkxLTDJ1dWlnMEdQd3lXNzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΡΔТаУКщтΣФυУз():
    value = 929881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBbQRkAp3aUUPwKU72GlAQc6zDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1610 = 478
        _dead_3888 = 517
        _dead_6935 = 725
    total = value + len(text)
    return total

def _цΥζΘСεасееъξэ():
    value = 655180
    if len('') > 0:
        _dead_5592 = 172
        1
        719
    text = __import__('base64').b64decode('QnFwMTd6MWc0RWJHZlpUdUlicGs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        322
        _dead_5681 = 472
        _dead_2348 = 555
    return total

def _лЖШяΔЕΨцЩтАШЬΔК():
    value = 67810
    if False and True:
        pass
        205
        _dead_3411 = 6
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ7xNkgN7rwGGVf24HnHYzN/tk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1658 = 47
        _dead_6825 = 608
    total = value + len(text)
    return total

def _хэκЛηХЧВςΧΚθΠпΥы():
    if 91 * 94 < 0:
        pass
        826
        _dead_9633 = 338
    value = 239194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCm9S1M9364VCTm0nlOHPCsa73w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6180 = 876
        pass
    return total

def _фΖβκΚлЪАя():
    value = 320018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzzAWmMP05IIaQSu52y7ZS0d6Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΛλПлθΖЭЫхςфЗ():
    if len('') > 0:
        315
        pass
    value = 342774
    text = __import__('base64').b64decode('aHA0WHlVMDBPcFFnaEFQY3c2OVU=').decode('utf-8')
    total = value + len(text)
    return total

def _иЯиБыБзζЦ():
    if False and True:
        pass
        299
        pass
    value = 637421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTvlUVY7+poZAg6a0UCqNg4X1Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цМΗωμъпЛΗЛ():
    value = 899056
    text = __import__('base64').b64decode('aElrZWxhbDhSaVdLSVdzYmRHbVc=').decode('utf-8')
    total = value + len(text)
    return total

def _θМΛуΠфНШДσ():
    value = 575073
    if len('') > 0:
        691
        pass
        653
    text = __import__('base64').b64decode('WHZYdUxFaDRaRnlsOXdvOUdFcng=').decode('utf-8')
    total = value + len(text)
    if 24 * 64 < 0:
        993
        pass
        pass
    return total

def _νЯпπмηРοсτΚ():
    if False and True:
        309
    value = 128215
    if len('') > 0:
        223
        727
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESvrSnop7aAxCDyKxHPFDQcWyl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        3
        pass
    total = value + len(text)
    return total

def _λφΗΖжФлГΤθИοж():
    value = 313404
    text = __import__('base64').b64decode('ZWJSRWFXZUpBWWZ4cE80N1RwT2w=').decode('utf-8')
    total = value + len(text)
    return total

def _КΜйтΕЛσыиыЬΙвг():
    value = 853119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjzQa2YcwaVRYyDw3kWmBjEh3EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πрФΟλЗΜοАσ():
    if False and True:
        844
        _dead_7022 = 297
        pass
    value = 244637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3jDTUsz+J8uPzuSmFGWFg0XvEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        720
        pass
        pass
    total = value + len(text)
    return total

def _чΜдΒρАΨΩωΔΟ():
    value = 340608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCfNfwQvrZ0paTvynG+4FRp61UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠоЩхЛРЕКчЪοЩыщΘ():
    value = 901839
    text = __import__('base64').b64decode('bG1IcEZYQ19Vbzd5RE5XV24yYnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞηππЬΝИΗеΒМμ():
    value = 728497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSjVNwEN1KEMaw6R+gSgLCAb9kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νПфочФΝрκзХКеΟ():
    value = 369032
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('WFNyQ0dxa3RwTDhLRmlqUk0wVXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩиΓЛзСεЯТьΜ():
    value = 788640
    text = __import__('base64').b64decode('bGlicGI0NXVWZzVmUktmNWdJQTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЭоΡчЬΧФρз():
    if False and True:
        pass
        550
    value = 950065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjzgPHxu+60JKFyLy06kLSEOwGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юнЬэзιВφΞЛλтэхН():
    if 45 * 54 < 0:
        262
        908
    value = 679426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3ixZFA7yrEqKxioz2OHJAkQ1lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИшъγЕДπЬΤЦА():
    value = 820887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjrcXnoW5qRVKVqE4EK4FhcY3Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζιШуςЯΝΓΤмΟИгуЩ():
    if False and True:
        _dead_8338 = 185
        _dead_2497 = 525
    value = 748553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRW9dwMb6pgTIyyNmUaUPyM6x0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4149 = 988
        _dead_1851 = 168
        pass
    return total

def _анΞφΒпРΜВЧБКлЛ():
    value = 881824
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBfRZgkjyLIZK1uAzlmBEysM3mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2227 = 748
        pass
    return total

def _ΧΖЮΚθεмΛЖκΧиюςν():
    value = 908578
    text = __import__('base64').b64decode('UDkwV1h5c0Fkbm1qTHBYUFBpU3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΠрчΨεΖШλЩΧЧсп():
    value = 162183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC7pdHk1xrIBEA6ExGXJMXc7zX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бЦуΡΔпΧμ():
    value = 515206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSroaWce7Io2Yy37mXq4bXArzTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КχеεЛчюгΧРηλГ():
    if len('') > 0:
        69
    value = 187173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXy2TVo1x48OMlb74GWpNSMksDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бηψιΨΨοъζΜδΧδ():
    value = 292593
    text = __import__('base64').b64decode('RTdYVTNzaW5Fbm9FZUhEUWlUajg=').decode('utf-8')
    total = value + len(text)
    return total

def _УγςλРΞΙμξΩмδ():
    if len('') > 0:
        365
        _dead_7423 = 134
    value = 923393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHbhR2ZgyqctNVm2mweKGHEf4mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΟВζДгЦДτ():
    value = 785221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgnBO2A97fsJHVqO0FiIGg8X01k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΩщРχΦγнБСрθдΚЧ():
    value = 262730
    text = __import__('base64').b64decode('REFydUxJTlpJNl9MWU5hclg5R18=').decode('utf-8')
    total = value + len(text)
    return total

def _хτъОЮюВФыФ():
    value = 535490
    text = __import__('base64').b64decode('WG5HV3BFbXNQcWFfTFI2MDk0OUU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        778
        837
    return total

def _ΔΚМтΡНпΛТ():
    value = 403330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHnna1I60KQQKTf3xGHIBnYlxno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 75 < 0:
        _dead_3770 = 675
        _dead_7058 = 195
    total = value + len(text)
    return total

def _ФшζмХХΦδΣЪ():
    value = 476807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQXmPAg70ZoWalv30AfGLS4Dz1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_4218 = 423
    return total

def _ФлэЩыШκΦБτ():
    value = 767954
    if 44 * 45 < 0:
        449
        292
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CASyVAVt5vwkHF2R/XvAJD0itnY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        947
    total = value + len(text)
    return total

def _ЕζьΧαχЕυРαъΟйωпВ():
    value = 776113
    text = __import__('base64').b64decode('ZFpQaHN0RUY5ODlYRUZyTnFDUFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ДХΡеχЬιазλΩ():
    value = 150039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDfXZkUR35EvDh6F0kKCIwd+1n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _укπСгμгЖ():
    value = 387042
    text = __import__('base64').b64decode('ZWNEY083WVp2S0d1VUZPbnVST3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _хНнΚυΟΓγ():
    if False and True:
        pass
        642
    value = 821460
    text = __import__('base64').b64decode('VHRuSUZoVmx3MDI5cUVBakV0SE8=').decode('utf-8')
    total = value + len(text)
    return total

def _СшνаςыПΣЬшэъαйР():
    value = 194341
    text = __import__('base64').b64decode('dHNHUjlyVW1HMV9aM3ozcnFCNHM=').decode('utf-8')
    if 13 * 77 < 0:
        _dead_5509 = 743
    total = value + len(text)
    return total

def _еΥпЦЩЛυСПφгЙйи():
    value = 17717
    if len('') > 0:
        355
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih/MWAFt/bwgGVq3kF7HLAx30kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨРЙоеωΚАпλшΛ():
    value = 879662
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxntOXAtrJslGCWp0n2KHgMp6Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6412 = 939
        24
    return total

def _χъυδγχтК():
    if False and True:
        _dead_3557 = 604
    value = 722832
    text = __import__('base64').b64decode('dTJmN01Fc1ZxWVpYSmZzYWM5Z1Q=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9869 = 322
    return total

def _βΖЬНУиакΩЧзΠεм():
    value = 405111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXbOawASqrovHwe6zUeGMBp78z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 16 * 62 < 0:
        885
        pass
    return total

def _заяθΡΟΓνυэцτ():
    if False and True:
        548
        pass
        719
    value = 565935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjfoSHkrzIU8IgmF2nmGGAALzVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 19 * 16 < 0:
        _dead_5203 = 833
        607
        _dead_8098 = 764
    return total

def _ηκАТεяΝμЙΔΧБΘ():
    value = 401595
    if False and True:
        pass
        825
    text = __import__('base64').b64decode('RHBMQzVFRElRcjdfNEw3ekduRl8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        690
        pass
        983
    return total

def _ИМΕΜПхφПεηщоωп():
    value = 193628
    if False and True:
        pass
        pass
        _dead_2242 = 141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiLePlJq+4Y2ahmxz3WjJhwl/XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζθτкηΑωгяРηΚΧт():
    value = 887265
    if False and True:
        pass
        713
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHq3eXQr8Yk5Iz62+GTFEzV70Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥИсΦюδТБСτ():
    value = 634981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECzIOn0draQaFF+N6V2jNgok8lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фλΦτАивЗИΚЖΦншЙΡ():
    value = 432369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHzHQgRs6YIaHAiEzmenICY/61Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УοΘЦмхΡζЦσΝбН():
    if len('') > 0:
        pass
    value = 263889
    text = __import__('base64').b64decode('QlByMkhNS0JUY1JPMWJKbEhvVm4=').decode('utf-8')
    total = value + len(text)
    if 34 * 33 < 0:
        _dead_7331 = 683
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if 19 * 76 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()