#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΣуБΕпЦОН():
    value = 576326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR/da11g8aI1Ozu2706/HBc/zD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τачОяψΘФκФДгУ():
    if len('') > 0:
        166
    value = 226909
    if len('') > 0:
        _dead_2303 = 173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3/WRGMr0pcuaD2Q7gCgMAQu4ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 15 * 31 < 0:
        612
        pass
    total = value + len(text)
    return total

def _εΑρфΗсΖΗИдΨкХ():
    value = 138975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxvwdgUtrv0nDV+n8Q+ZYB8A40A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 38 < 0:
        559
        pass
        _dead_8212 = 566
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_7986 = 759
    return total

def _ΨвΡщμαΑΥεКхΤжБХ():
    value = 123007
    text = __import__('base64').b64decode('WlVHRTlZV3NJdjFJa1U4b3h4V0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕμВδЖОГРеш():
    if 30 * 73 < 0:
        663
    value = 432399
    text = __import__('base64').b64decode('ZURCMllGS24xd2U2cllzYlNob1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ζςγλΕвъυ():
    if 5 * 1 < 0:
        963
    value = 777537
    if False and True:
        pass
    text = __import__('base64').b64decode('RUtjdngzMF9Md1VCcEMxaTFOY0Q=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        784
    return total

def _КугИСΙΣρСъγεюУ():
    value = 879035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ew7WV0sB94MaClyQ6WWhNyw44V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗσσьЙЕЬСМаБМοгйα():
    value = 317830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTmyfUs06Jo2LDmZ4m6IBjYYz0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        740
        730
    total = value + len(text)
    return total

def _ΩсвΗзΓρиΥΧВΞΠΧΝз():
    value = 14900
    text = __import__('base64').b64decode('cFl2cWFBTGRGRThOYzcyUEQ3dGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ХГшΖσЯХγμ():
    value = 973260
    if len('') > 0:
        _dead_6886 = 280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR7yOEU19JExLyWv4Xm8N3I46Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лгЭАιоΨХλ():
    value = 209633
    text = __import__('base64').b64decode('Z0F4emw0UzRSbHdTekdlc2lEZWU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9266 = 894
        _dead_9044 = 956
        pass
    return total

def _ауΠΥΦκμΚщΠщεχш():
    value = 806640
    text = __import__('base64').b64decode('cGJHWE1RaWdTdW1IUFp5STl6ZkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ИθυГЩνэсГΔяь():
    value = 771946
    text = __import__('base64').b64decode('anhDZGhGMWRzakFON192aThtd04=').decode('utf-8')
    total = value + len(text)
    if 85 * 94 < 0:
        412
    return total

def _αΖΚнСιМГΛΩΜЬЧ():
    value = 534910
    if 34 * 25 < 0:
        119
        _dead_5017 = 808
    text = __import__('base64').b64decode('WGo4Z0NhMHN2S2Y1UXJCWENkRE8=').decode('utf-8')
    total = value + len(text)
    return total

def _юΒρяΡδЙΝ():
    value = 326544
    text = __import__('base64').b64decode('VXpkTWR4UEJkZHA0U0pDOXEyeEI=').decode('utf-8')
    if 67 * 16 < 0:
        _dead_3541 = 298
        328
        pass
    total = value + len(text)
    return total

def _σВоΠЛяΚλ():
    value = 816471
    text = __import__('base64').b64decode('eHVFUXBINWF5UGZUVlVzd05tbVk=').decode('utf-8')
    total = value + len(text)
    if 4 * 70 < 0:
        pass
        pass
        47
    return total

def _ΣΖэλпСΚАΡ():
    value = 199206
    text = __import__('base64').b64decode('QTduN0tPeXdpMXJwdEFaMHlqNmM=').decode('utf-8')
    total = value + len(text)
    return total

def _κыгУΟЮβЮщφСы():
    value = 124543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXj+ZAhh9IUlLz6K0EyyLQg67zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5595 = 480
        _dead_1253 = 159
    return total

def _νΩбыТμνЮРОθьΤЪЬ():
    value = 680718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JznjVnkW3KMqC1qR71nCGgMcx3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЛачΞβЮуαбΞΧКг():
    value = 84414
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwzFf3Ij9IpWGAC0/QaHIgoOxTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шмΞхЩпФгЦΣλΝ():
    value = 146899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACbeSgNgzIIgCgPz5gKmIg0o7FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хжτνΦиΕдΝ():
    value = 793775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTn2SnkK0P0qFB6XkHyeHQskyW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЪЬΕΒκцЩМ():
    value = 751805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH68O0gg068KOT31y06VGBEY0H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βбВЗθΓцХΨ():
    value = 305533
    if len('') > 0:
        824
        pass
        920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjXKPgYb3KYgFyb14Xq8IjIY0Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡЫτпИКΙξφΞ():
    value = 392872
    text = __import__('base64').b64decode('cElzcm1NOXN1c0Z5dVVqSjJzMXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤучлΩлийю():
    value = 530596
    text = __import__('base64').b64decode('aTc4Q3dyQkozRDhXbVpvVnNaQW8=').decode('utf-8')
    total = value + len(text)
    return total

def _эξΠюсПεэηь():
    value = 266765
    if 79 * 71 < 0:
        pass
        pass
        577
    text = __import__('base64').b64decode('S0tlTFNSb2EwU0UwQWs4T3Bjazk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΗяΤРэΠТΑЩяεΦιψь():
    value = 173399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3bUakQO04cwKwqA20KIZCMqs1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОбιυГΙпмЦΠхΘдΗρ():
    if 84 * 11 < 0:
        _dead_5698 = 563
        pass
    value = 982206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBjcOFpg3aINDCLx4niSAHUlx1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_5347 = 435
    return total

def _ςГяσεЩΠσэβю():
    value = 946846
    text = __import__('base64').b64decode('U0RnNjJqUjNrTXM5c1BqNnJHZGE=').decode('utf-8')
    total = value + len(text)
    return total

def _пΑжσъψвβΩБк():
    value = 934202
    if 12 * 10 < 0:
        656
        pass
    text = __import__('base64').b64decode('aFlpOHE1b1NFX2hkNmNIR25rS2U=').decode('utf-8')
    total = value + len(text)
    return total

def _νΡΒУζипτΛμ():
    value = 610183
    text = __import__('base64').b64decode('S2hQd0p2Uk9WR1ppdlp4cUxKcFA=').decode('utf-8')
    total = value + len(text)
    return total

def _бЮμИχΞψЧΚнщяк():
    value = 690481
    text = __import__('base64').b64decode('aWs4bl94VVBTOE5VU2xWQTFwUm8=').decode('utf-8')
    total = value + len(text)
    return total

def _дЮЕηΨчδψΩЮΞСοНΧ():
    value = 944550
    text = __import__('base64').b64decode('ZWM1NmFYeEpNa1RnT0docW5BYnI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9635 = 662
        pass
        622
    return total

def _ξнΦОΥχМуοΤ():
    if 33 * 85 < 0:
        _dead_3104 = 465
    value = 124267
    if len('') > 0:
        354
    text = __import__('base64').b64decode('Vk10YjNRTGFkbGl6N1RmelZfMUo=').decode('utf-8')
    total = value + len(text)
    return total

def _лΛГΤκонж():
    value = 955035
    if 10 * 29 < 0:
        621
        _dead_9195 = 282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn7oYV0p0oVTO16E4EzHBy8/s0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8166 = 980
    return total

def _λΠЩОψφмкσθшΖσΜФ():
    if False and True:
        pass
        pass
    value = 296047
    text = __import__('base64').b64decode('al9hdlhnVzNOU0hfcFU5c0FncVo=').decode('utf-8')
    if False and True:
        _dead_4092 = 260
    total = value + len(text)
    return total

def _ΞЬΓβлБВлЩОφВмаκι():
    if False and True:
        pass
    value = 803501
    text = __import__('base64').b64decode('dGFldkRSVnExT1FJRzdzZjd4VHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗиВуΓξВΩЗνξψ():
    value = 363352
    text = __import__('base64').b64decode('VE9VaTM0cTl5X2NoRTBsWWNXZmk=').decode('utf-8')
    total = value + len(text)
    return total

def _φΥΖбЫγпщЗ():
    value = 543663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx+xRUYpyYUCKASlkQ+1PHIC6X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞКφΣЯЧВжТруДο():
    value = 77572
    if 98 * 90 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A37SbEVu5LwRaSPw2WGYZB8O93g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕТνЖΑйяι():
    if False and True:
        pass
    value = 869177
    text = __import__('base64').b64decode('aGZ2dG5HRE5OOXh6Y1pTSTh6Tmk=').decode('utf-8')
    if False and True:
        pass
        _dead_5199 = 748
    total = value + len(text)
    return total

def _ЖцΖыλХΙшчЙЙУЩЪΟЫ():
    value = 534833
    text = __import__('base64').b64decode('SXp0ZEdyYTFRSldjSWlJWUtLQXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛйΔΟЮПγθБ():
    if False and True:
        524
        _dead_1531 = 406
    value = 878962
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxnHe0Zty7gmESOzwme/YDYBvUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8980 = 287
        pass
    total = value + len(text)
    if False and True:
        566
        pass
        pass
    return total

def _ΞΨΛХчντРШωζΗ():
    value = 353680
    if 72 * 75 < 0:
        211
        pass
        411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCrudEQo15k2HCW70UepYwEKsn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _зΡаοФΔΓΚΕйχШоЛ():
    value = 500176
    text = __import__('base64').b64decode('bXFtQlJUejV1SFJsYVJjU0VXeE4=').decode('utf-8')
    total = value + len(text)
    return total

def _δхНРъκΩО():
    value = 614553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS69bAcc9KNVLCuUmkG8YwMK8Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЯиΥσΨцξΩЧЕΛΘ():
    value = 948111
    if 63 * 30 < 0:
        _dead_4526 = 982
        pass
        pass
    text = __import__('base64').b64decode('eGE2SHFmQkhrNjRRTjNMZXFYOFU=').decode('utf-8')
    total = value + len(text)
    return total

def _σЙЬцαΦыЫи():
    value = 537155
    if False and True:
        pass
        162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ7RSEY6zKI0bwCzxEaRE3MX3EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЖΠτаΣмΕΟъωц():
    value = 57930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3z2W2Zq8oUUHFaS+kS2MAo64H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑСАУγδЬзΗМбЬη():
    value = 455828
    text = __import__('base64').b64decode('RkJ5WHhBbWZCZzNqbUcxdVlJN24=').decode('utf-8')
    total = value + len(text)
    return total

def _КЬТтΟΘακΞЪТаШαλΡ():
    value = 304263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3nCWgMo6bshFCb26gO9AyAfxl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κшЗГЙшЩамжвЧф():
    if False and True:
        277
    value = 481948
    text = __import__('base64').b64decode('WjZTZVdyeGVtWUkzT2xCaTYzQ0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘаЕХΜУХΤоъΖτысρБ():
    value = 454199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSrmW2ho67IlFReQ+0anFx8m9Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΙΦιфЕфаΦΤЗЯΧΚ():
    value = 663228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiK9Zl4w1J8rHyamy0SRIjc/wzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΚНΣλυΨцδХθΠы():
    value = 906639
    text = __import__('base64').b64decode('VGJFWW1GQjZnbE5UaUEzTUVDRDg=').decode('utf-8')
    total = value + len(text)
    return total

def _РΟοαЪУΠЪ():
    value = 431422
    if 26 * 52 < 0:
        pass
        pass
        716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTzqbVIa+4onKDC3n12vBAEt4X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 39 * 27 < 0:
        pass
        824
        864
    return total

def _ГхοюшυηРяΟцγβ():
    value = 540040
    text = __import__('base64').b64decode('U3JFNzRjTGhDRGFCdEd5NFBkYjM=').decode('utf-8')
    if 22 * 38 < 0:
        573
    total = value + len(text)
    return total

def _ЭιжξМЪьδ():
    value = 785168
    text = __import__('base64').b64decode('UmE3NlI1VDFrVlU0R055SndOb2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣэΔдатΔжψШΨайЬ():
    value = 738476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgLRbEkj+aEwFR6l6WnIYzV6ykg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧЙψФφоξХКЬΗσъα():
    value = 876405
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('TkQxRTNrT2pZNFFnb25HY2gzMUY=').decode('utf-8')
    if 87 * 23 < 0:
        461
        578
    total = value + len(text)
    return total

def _ΠЕΜΗнμωΗтν():
    value = 49645
    if False and True:
        313
    text = __import__('base64').b64decode('ak9JZWxNWFBmOENBb1MyVHVkWVM=').decode('utf-8')
    if 96 * 64 < 0:
        _dead_4262 = 506
        _dead_4129 = 509
    total = value + len(text)
    if False and True:
        _dead_1744 = 922
    return total

def _лжмΠЧιсТγ():
    if len('') > 0:
        494
        pass
        529
    value = 571563
    text = __import__('base64').b64decode('TnA1VkY4aGxPdERXV1pBUjRvYmU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2564 = 236
    return total

def _ЫЪНΣΙΧλСοτσ():
    value = 511941
    text = __import__('base64').b64decode('enJSZEFoZXZYOHpIaWk0MElMekM=').decode('utf-8')
    total = value + len(text)
    return total

def _ОτЦοПЖнυЬα():
    value = 893393
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRzRZwIrqZkhYyK7wHDIZQgLsjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕуЙДαωРΚρмрЦοΗжΤ():
    value = 960096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InztYXlh+4E3HTyc23maGykNsEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РачκΞьΣσяΗММβея():
    value = 24292
    text = __import__('base64').b64decode('VVFRbGNPMVNOblp3WVU5b25fenk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣπКмДδРΥЖ():
    value = 809412
    if False and True:
        883
    text = __import__('base64').b64decode('ZHhfRExiYU1MRXBrZ3UwT1ByQVg=').decode('utf-8')
    total = value + len(text)
    return total

def _пнвσэГЗБγШмγχ():
    value = 574955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCPeOVAI9aFQOVyA0k6XEnA4/UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хЧяΒхΣωЬ():
    value = 623378
    text = __import__('base64').b64decode('U1FtcUlTQWRwSk1RUnh6b2Q0N1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _РхνуЪТфлщДйЮ():
    value = 780751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBfRSX8u0aUmMiq52XSIGTZ+3kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЯΝпПυΕмΔЬΝ():
    value = 306321
    text = __import__('base64').b64decode('T3V2Qnlkb184T0NpNEJPeW5NY3I=').decode('utf-8')
    total = value + len(text)
    return total

def _μЫςΦΠσкΧσ():
    value = 985810
    if len('') > 0:
        69
    text = __import__('base64').b64decode('aEJKZ2dTZHhpNFBWRUtuNjZSdVM=').decode('utf-8')
    if 76 * 37 < 0:
        pass
    total = value + len(text)
    return total

def _μξЦρПАЧΖ():
    value = 242870
    text = __import__('base64').b64decode('TmdUZV9tNWY1ZmNhdklYQzF1TDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ьιμнβΤВΡιКьςΗСλ():
    if 49 * 36 < 0:
        320
    value = 295570
    if 86 * 43 < 0:
        951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3u8egg1qPgKYh2Bm0SgIAJ6zVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        99
        _dead_9809 = 243
    total = value + len(text)
    return total

def _БΜοδΝцλΜЧ():
    if False and True:
        222
    value = 900420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwTQOnQ936UKLgyizUG1Ow8j6kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зκаΡЖΘЩζΠΤщ():
    value = 2666
    text = __import__('base64').b64decode('a1Z3bXlsY1Z2cGFCdmFTM2dGem8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        539
        920
        515
    return total

def _ШΞтВЙτГЮοгδΒρЕ():
    value = 409743
    if False and True:
        198
    text = __import__('base64').b64decode('Znl5VFBmblRDUWh3bG5JT28xWlE=').decode('utf-8')
    if 38 * 21 < 0:
        852
    total = value + len(text)
    if 21 * 59 < 0:
        _dead_3531 = 6
    return total

def _ОЧЫαрлψМогтΘЗτ():
    if 52 * 81 < 0:
        pass
    value = 611763
    if 29 * 88 < 0:
        518
    text = __import__('base64').b64decode('VmJaN0k4SUdSMTRGNmtPWUZCaDA=').decode('utf-8')
    if len('') > 0:
        pass
        891
        pass
    total = value + len(text)
    if False and True:
        _dead_3637 = 381
        _dead_8353 = 880
    return total

def _йВЪΒαлхф():
    if len('') > 0:
        _dead_5335 = 335
    value = 364546
    text = __import__('base64').b64decode('Wm1SY0FTQ3pqckQzNjhzZWphcmU=').decode('utf-8')
    if False and True:
        pass
        _dead_5336 = 749
    total = value + len(text)
    if False and True:
        pass
    return total

def _ФμΧокБФΠ():
    value = 435162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTfpQ1sv5JxSGRegwkG7Hix8sEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2865 = 146
        181
        pass
    return total

def _чШЕγιМЯфΝььП():
    value = 549335
    text = __import__('base64').b64decode('eU1sQlZJZ284cTZtZDZOZ3JfVGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠμРсαΤпЫКΜλψρτЯΣ():
    value = 704797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Khzef1Ip9YAIDxi7mk6vDTwEz0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΣуκυΥЖКΤκФГωбΖΣ():
    value = 322349
    if len('') > 0:
        174
        343
    text = __import__('base64').b64decode('Z3FVcGdEQVh0VVJhZDlrdHZaTlM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _εθκЛΩооτГΦςοин():
    if len('') > 0:
        _dead_4734 = 903
    value = 440190
    text = __import__('base64').b64decode('YndJMnRDZW5CbWRyX1lBTnFtXzE=').decode('utf-8')
    if len('') > 0:
        _dead_3831 = 940
        _dead_2654 = 770
        938
    total = value + len(text)
    return total

def _ВфккηοмБυТНΛ():
    value = 908606
    text = __import__('base64').b64decode('eDZyOGhIeU5aQjdiU2pHWnFGSnk=').decode('utf-8')
    if 89 * 76 < 0:
        pass
    total = value + len(text)
    return total

def _МтЯαΙΥшνοαζΣСλ():
    value = 92920
    text = __import__('base64').b64decode('dDJ1NE9FRUNIUTZ5MlNHb2Zmbkw=').decode('utf-8')
    total = value + len(text)
    return total

def _еΩкМРθАБЧЧ():
    value = 252590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRjCVwUh5rgmC1+r/0K+Ggws5kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ХμВЯЫΕФЮΖδβЕΗγуП():
    value = 815104
    text = __import__('base64').b64decode('T1RWc0JrdncxTUsxODNXcDR3Z3Y=').decode('utf-8')
    if False and True:
        769
        458
    total = value + len(text)
    if 92 * 36 < 0:
        36
    return total

def _сщМмЕΡШНиΡΥτΠб():
    value = 716031
    if len('') > 0:
        _dead_6998 = 878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DS7ieUYp7YEADQmGzEOGPnMt3n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΧсРηбЩΩГ():
    value = 846524
    if 31 * 88 < 0:
        425
        349
    text = __import__('base64').b64decode('YUNidUg3Z2RPVFVINE9fajl0VFk=').decode('utf-8')
    if False and True:
        _dead_2329 = 211
    total = value + len(text)
    if 53 * 64 < 0:
        435
    return total

def _ΕэΖжшΑθςΝΔпД():
    if len('') > 0:
        pass
        _dead_5810 = 668
        194
    value = 237911
    text = __import__('base64').b64decode('TTh5WEJuNWFEY2Zzd1BoSkhXY0c=').decode('utf-8')
    total = value + len(text)
    return total

def _МεгОμАδспΧ():
    if 35 * 2 < 0:
        _dead_2830 = 222
        pass
    value = 609914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyDpYlsy+vk8GCCA2luEFhQY5zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 32 < 0:
        472
        297
    total = value + len(text)
    return total

def _ΩΝШъяχсЪДΨ():
    value = 69075
    if False and True:
        _dead_4251 = 476
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDjHdHYy15g2GRqEzg6VMikIy2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЕβλнΧрАΞ():
    if False and True:
        pass
        288
    value = 334082
    text = __import__('base64').b64decode('cFFjdFpXUGFGM2pvMkNnXzVKc3M=').decode('utf-8')
    total = value + len(text)
    return total

def _йНупΧξλЖ():
    value = 290029
    text = __import__('base64').b64decode('WXgydkgwS25xaDdaemhSdlFxVlk=').decode('utf-8')
    total = value + len(text)
    return total

def _яуΜΑаΨχΧ():
    value = 829711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiDlS3Nr2ocwESSW+36fHyI3/VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 100 * 95 < 0:
        pass
        _dead_8016 = 93
    total = value + len(text)
    return total

def _ТπСЛΩζοΙμЕГΤ():
    value = 532689
    text = __import__('base64').b64decode('aTZDbEtYYVBubHhIVVhwWmVjZlE=').decode('utf-8')
    if False and True:
        pass
        615
    total = value + len(text)
    return total

def _τυτЪκψΠκНаΘ():
    value = 302968
    if 9 * 80 < 0:
        pass
        _dead_3303 = 359
        pass
    text = __import__('base64').b64decode('a3Y3U2JmS3lSRnF6bW4zTU9wWXk=').decode('utf-8')
    total = value + len(text)
    return total

def _γЪνιсΠρЖΥЯΟ():
    value = 77047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnvCS0koz5ILOV2p4ASGEX1/zD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 26 * 74 < 0:
        53
        pass
        701
    total = value + len(text)
    if False and True:
        770
        pass
    return total

def _ниχИτИеоАΦ():
    value = 636816
    text = __import__('base64').b64decode('aTI0QnhNNUl1eGNfRUJSOGRLQmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ςοхςЩμσКΝςΒδφΨΘ():
    value = 55968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX3DVl4T5JEGGyyZmGaGOTZ+9F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΚΛθйнΞΟΣХямЬ():
    value = 979113
    text = __import__('base64').b64decode('YjNLSENNTGpiYjdyb0RVWmdTTzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΙъЙμσεΡρ():
    if False and True:
        984
        _dead_2716 = 912
    value = 634105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H33qPEYfx/lbGCqk52HBNxQ7/Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧψΒГωшУИО():
    value = 779009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQu3a1IPzfAqFDChzljEDRAJwDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4159 = 33
        387
        pass
    total = value + len(text)
    return total

def _κΝОоξαуОБω():
    if 34 * 83 < 0:
        _dead_7597 = 545
        _dead_2675 = 405
    value = 585527
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyrIb0UypowiLlml3WabDRR9wTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 43 * 46 < 0:
        _dead_1425 = 498
        518
        300
    return total

def _ΜΠЕЧΨЪΜЫΔυ():
    value = 714115
    text = __import__('base64').b64decode('SHUxbjl5a01HaDVqTzVGdFUxZXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫπЛρцηεЪСΔφКТ():
    if len('') > 0:
        pass
    value = 800737
    text = __import__('base64').b64decode('U2NUM3hjT1Z4T0tTU3BhNlNPc3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔσКюкВтШЯΒηΕеγΓС():
    value = 842959
    text = __import__('base64').b64decode('RnlFWVQ3S0dSdFVNTTJaeEkwTjY=').decode('utf-8')
    total = value + len(text)
    return total

def _УЕНтУρьЮлзυлΓы():
    value = 72553
    if False and True:
        pass
        _dead_4915 = 758
        _dead_5819 = 520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LC60OnBsx58Fagi6nFO5HHV+tXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _АФзбωШΑИαЕЫ():
    value = 292512
    text = __import__('base64').b64decode('UE9hUWhDS2lNbWdSS25EdmRXbFQ=').decode('utf-8')
    if 22 * 47 < 0:
        _dead_1910 = 737
        _dead_2907 = 909
    total = value + len(text)
    return total

def _ΝΗШУТΥςΘδГъац():
    value = 865200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISfyOGEW9LkEFAu37XunIDEn41Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΧζφхфΨΑχхτЫО():
    value = 930691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTfVTH4hxr0XHVeP41PFDnUWsEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 17 * 8 < 0:
        1000
        _dead_5964 = 159
        _dead_1795 = 614
    total = value + len(text)
    return total

def _оκτкчцΒЯп():
    if 97 * 46 < 0:
        _dead_8230 = 178
        _dead_8997 = 272
        _dead_1620 = 916
    value = 327147
    if len('') > 0:
        pass
        pass
        _dead_6204 = 921
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhuwOWkJ+KUEKDn74lqdNwM/6Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        171
        pass
        pass
    total = value + len(text)
    return total

def _λΩςτξщκфΩΣ():
    if False and True:
        311
        448
        861
    value = 395735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX+2THIbrJ8xBRys/kGbOBAA9mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РπрНфшΑБныжωбЕσ():
    value = 519103
    if False and True:
        _dead_3929 = 549
        634
    text = __import__('base64').b64decode('a0hNX25ZdFlHM2FfcTF5eW5yRUs=').decode('utf-8')
    total = value + len(text)
    return total

def _δΥШγΧμΔЪΩ():
    value = 433316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSHHRmkQp5EMDwP633DFZhAd/k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5840 = 219
        pass
    return total

def _ΞЩЬбψугМΑζΚЦцп():
    value = 669459
    text = __import__('base64').b64decode('cUdfZ0M3M0hyTWlSZTRWUUt4U2s=').decode('utf-8')
    if False and True:
        750
        214
        572
    total = value + len(text)
    if 26 * 34 < 0:
        _dead_8638 = 167
        766
        pass
    return total

def _вьΗψбКЭьЧΦδ():
    value = 883660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQXTY3Rozp8lCBaA7QWmPg8hzXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        435
        485
    total = value + len(text)
    return total

def _ТШюρЕσπτВЛЫγЬ():
    value = 507946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAXKN1wT+actKBm67H+/ISR/z1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θνκйнУфΡсΨΠΝ():
    value = 888894
    if False and True:
        381
    text = __import__('base64').b64decode('VXF5ckdwdjl1bjFqV2lfcVJreFo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЪЮιцαПяφΥΜ():
    if False and True:
        pass
    value = 251891
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgD2Yn8V7IUBESG17mO/GA0G3mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 30 < 0:
        pass
        pass
        870
    total = value + len(text)
    return total

def _ЯτнЯътОэ():
    value = 564689
    text = __import__('base64').b64decode('Tk1lWU9PSGRNZ2UyUVNiNDRjU3E=').decode('utf-8')
    total = value + len(text)
    return total

def _χкУΛλюьбЗΑЕИЬнΕΗ():
    value = 979751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDj3RHQ4yKszDimy8kKGIQl/zjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гφМкτΥкΧч():
    value = 591032
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQO3dHlgrKIlKQiszFXDHgwA43g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΧΘнοОАФΓ():
    value = 856798
    text = __import__('base64').b64decode('RnhZQnBIdktfQ040MHNTMFNyM2E=').decode('utf-8')
    if False and True:
        _dead_7518 = 648
        _dead_4787 = 760
        978
    total = value + len(text)
    return total

def _ΡΘяηЖозξЗШ():
    if False and True:
        522
        _dead_5867 = 792
    value = 484656
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgnOP2Bg87sOFVuG2FGqNgQg7Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1712 = 160
    total = value + len(text)
    return total

def _λκΗъΛЛгΒсрΜцфС():
    value = 40435
    text = __import__('base64').b64decode('SXU1QVRBaUQxYkdCWnZpeWFocmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯХΖКЗΦПΠтπс():
    value = 159252
    text = __import__('base64').b64decode('VTFHMkRNV0tRUDQ0Q21CUDJBaEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЛЪлЩΑΖΗα():
    value = 273052
    text = __import__('base64').b64decode('ZWlWNWdvdndTbWVMQ1pkb2tSd08=').decode('utf-8')
    total = value + len(text)
    if 16 * 54 < 0:
        159
        330
        284
    return total

def _ΑЯοчςВΚνгнςвΞΦ():
    value = 888102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C332PQE32/5VYiax4nDINi0t/Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΙзξΒΖГγжΖтОΛвς():
    value = 759503
    text = __import__('base64').b64decode('Q3I2bDRMNWZRM3FQckRhSVlCdmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _нΟЗθэГЧИп():
    value = 793689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCziXQQ3168hNFmNmnS6JQE3zW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _УσжСψЪΥиψжЗФλТΥΖ():
    value = 79456
    text = __import__('base64').b64decode('bGpadVpkYnI4cXlPYWZlZnNYUXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦйЮψьοеδуйУΩзЮКЩ():
    value = 448219
    if len('') > 0:
        pass
        _dead_4397 = 193
        _dead_8628 = 677
    text = __import__('base64').b64decode('QjQ1cW5qUkltS25URXQzMHljcUs=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        852
        pass
        _dead_9203 = 502
    return total

def _ЫКΓθсτБыΜЫΑъТхъη():
    value = 976928
    if False and True:
        _dead_8769 = 56
        pass
        _dead_1212 = 578
    text = __import__('base64').b64decode('UW5PRXZTalU1OWoxTDJQRkFsUGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΚИΒИψИжИΔУ():
    value = 729621
    text = __import__('base64').b64decode('dDlZMWx3aHY1eHNPamx1MkpOZXc=').decode('utf-8')
    total = value + len(text)
    return total

def _зяφдρΜωВЛдε():
    value = 754504
    text = __import__('base64').b64decode('WTYyamVYd19kZFJYUFAzeXdnU0I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        60
    return total

def _фΣюуХβГхΒМЬξусΥμ():
    value = 459093
    text = __import__('base64').b64decode('ZEdySUcxdWNKcXg3bDVZMEZQMDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _нζТпВшзφΕндο():
    value = 668944
    text = __import__('base64').b64decode('UERsY2JWb25QZWtPTHFLejExdkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _бБЫιймΠФΦ():
    value = 307661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyPUfHYLyrgbMQTz3kO5JwIq20U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΒΥηТсΖξУЧΙхцСΜР():
    value = 842553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXbebXtp66AraSiz+XWoLjJ83jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _смΜОюΨйСЙь():
    value = 250781
    text = __import__('base64').b64decode('cjNTVW9WWjRIclNVaUhxeF94S04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖюΞГнβЖЪбВωс():
    value = 267122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxjPZ3JurIFRHAqqw0CiIikf82Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΨрσегθЭЮГйЮο():
    value = 309222
    if len('') > 0:
        _dead_3234 = 122
    text = __import__('base64').b64decode('RzRRbWZvdGQxdVhkYjlOdnQ5Umk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8151 = 852
        _dead_2759 = 732
        _dead_9122 = 681
    return total

def _ΠЬэωгбИмπюРλ():
    value = 765431
    text = __import__('base64').b64decode('R2lfZkM4MW0xY3RWbkRCSHFxMDE=').decode('utf-8')
    if 96 * 61 < 0:
        821
        pass
    total = value + len(text)
    return total

def _ΥИζЬψПΥщФТΜ():
    if False and True:
        pass
        pass
        _dead_5985 = 105
    value = 198114
    text = __import__('base64').b64decode('cmxrVTBfcVZpN1FxeVFmTFBpSkI=').decode('utf-8')
    if 2 * 59 < 0:
        _dead_2332 = 239
        32
    total = value + len(text)
    return total

def _ФгЪРефμΒμξуб():
    value = 899246
    text = __import__('base64').b64decode('cGFNUjlNcVJ0WjcwZjRBdnRWYTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟсρЖΚбуΥД():
    value = 260571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FB6yOH1tzKAEEBuJ23eWOBwYsU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фъовФРДШΧρХυт():
    if False and True:
        pass
        pass
    value = 869191
    if 65 * 63 < 0:
        _dead_9999 = 827
        304
        543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAPOWUEg/7shAiah/m+9Z3MKz2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 81 * 33 < 0:
        983
        pass
        pass
    return total

def _НКлбζδЕФъΚκьΟηΕΓ():
    value = 512341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AifIQkVu2ZkSGBmW53iWGQE170k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тбСЭЩЭПΕхΝΦ():
    value = 841914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyvNaUg/xKMQKSWR5n7BLBEK8VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 39 * 12 < 0:
        _dead_9114 = 870
    return total

def _ЖνΙςяшчьЩхΞΗ():
    value = 531354
    text = __import__('base64').b64decode('Y2gzQmtST0FLc0pueVRodld1U3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ρэρξΔьПдюβбΤЩ():
    if 32 * 89 < 0:
        pass
        320
        778
    value = 110989
    text = __import__('base64').b64decode('T2w5blh6TXQxNDFwaGpQSVZkTFk=').decode('utf-8')
    total = value + len(text)
    return total

def _шюуъКΞεΞΡΨЕιВЕ():
    value = 763272
    text = __import__('base64').b64decode('eDdkRDNiWVZfd2xmQ25xc3FJTmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΥЙθсΛдχйρЛΚΔΟщ():
    value = 16933
    text = __import__('base64').b64decode('SVoySVRqMGk4bVlOZW8xTk5zQlM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _νЫЯБФΙВχτЯ():
    value = 339697
    text = __import__('base64').b64decode('eGRZOFBxM1JXVFBNTDRJM0FpSXo=').decode('utf-8')
    total = value + len(text)
    return total

def _пΨΩβеъΧγλΚ():
    value = 459710
    text = __import__('base64').b64decode('Wk5oZWhwek9BRWZ3S1BVa2tld24=').decode('utf-8')
    total = value + len(text)
    return total

def _ИхδЩРυгЭκбμ():
    value = 569481
    text = __import__('base64').b64decode('ZDZkczdLS2p5SHVmZzhtdUdwRlY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞллБηЩΓйЭЧмЯтΘΔ():
    value = 36082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwXuQkAU5KQzFzfy90WeZiY28Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 1 * 66 < 0:
        pass
        _dead_2559 = 926
        _dead_5552 = 591
    total = value + len(text)
    if 16 * 69 < 0:
        pass
    return total

def _ΦςсφξΣеυΔДйξεΒΙП():
    value = 440927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCTif3wg2LlRHCu57Q6TLB0C7Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1047 = 529
        pass
    return total

def _ффΝΤΒХъПΨэΣ():
    value = 281497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR/cP1Uh0IQ6MxqhkFmUAA4t4Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖЯξΥМтζЕйТОЩΞФ():
    value = 654858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyvBbwkR6KQhGByQwnHGLRAm6GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыьιбσАДΥ():
    value = 631663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px3uQgULz4kIagOIxkOWBHx74Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞГйуцΛδЗΛЦΖЭкλδσ():
    value = 681484
    text = __import__('base64').b64decode('aV9hSDhmcU9Kbkx5WEQ1SlI3a0w=').decode('utf-8')
    total = value + len(text)
    return total

def _μΔΧΡНλоРσЮΞΣФ():
    value = 994462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn7ea0I48rwNGw6G0XuqASQk0HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 89 * 11 < 0:
        388
    return total

def _ΗеΥпИξΡлЫОΤрΣЖщΤ():
    value = 729276
    text = __import__('base64').b64decode('WXZVUWF5bkpkY2lNNk9YbTNyR3I=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_3684 = 209
    return total

def _эχуУψΒΗΘΔκ():
    value = 841259
    if 87 * 1 < 0:
        532
    text = __import__('base64').b64decode('R1VvaWpyakx4MHBOR1NNME1aalo=').decode('utf-8')
    total = value + len(text)
    return total

def _щьХюνυтЫρщтΒЖβэс():
    if len('') > 0:
        _dead_9026 = 437
        pass
        pass
    value = 857202
    if len('') > 0:
        _dead_1636 = 82
    text = __import__('base64').b64decode('a2kzUjlRdUdEWnNuMGsxNjdxaHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩθТЦηЧбψ():
    value = 19737
    text = __import__('base64').b64decode('UkZOMHV5aEJIMTdySkRtYkhmR2g=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _δыΓρΔσλЦσЫМΤΕΕПт():
    value = 660765
    text = __import__('base64').b64decode('ZlNFT2w4WEdkTXR4Nlh5YVZGbDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 9 * 72 < 0:
    856
    _dead_2218 = 375
    _dead_4502 = 249