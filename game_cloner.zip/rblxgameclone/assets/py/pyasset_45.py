#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ИюнηТσЙИ():
    if False and True:
        pass
        571
        853
    value = 559092
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyXdQQAIqK0uaBii8WWvODV38Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 4 < 0:
        _dead_3903 = 793
        pass
        _dead_5620 = 688
    total = value + len(text)
    if 25 * 48 < 0:
        _dead_1840 = 479
        _dead_5004 = 725
        pass
    return total

def _шюжΤлΨЯΕХИавΠ():
    if False and True:
        pass
    value = 287861
    text = __import__('base64').b64decode('UWMyekJ0aE1zZ25aRmw2akpoU2I=').decode('utf-8')
    if 46 * 41 < 0:
        842
    total = value + len(text)
    return total

def _ΘФωχΘεΝδ():
    value = 762475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSHAfXQQzLFbGx+J+lWYJBM4wVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        110
    total = value + len(text)
    if False and True:
        pass
    return total

def _βδЕΨъρχΣχνЦ():
    value = 536878
    text = __import__('base64').b64decode('Q2UyZl9YeUpzTURXRTA3eEhMRmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ъΓСгЛИиш():
    value = 598106
    text = __import__('base64').b64decode('ZnRaVFo3OGI2SU4xUTNHUGRKV1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭαчυдзκδβγАΜлЪ():
    value = 766943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Knz+ZwU8qp0pCwuGnwG0MS4H0To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юδΨΚωцΟоΘХ():
    value = 779629
    text = __import__('base64').b64decode('aUJubmFHZW5hVXBadU9xYnlORkI=').decode('utf-8')
    total = value + len(text)
    return total

def _λЕΞΓЮФеПвкυ():
    value = 897472
    if False and True:
        _dead_2239 = 793
        pass
        492
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwTGT1wp+ZgtPziLw1OqBBx613s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βΖВЙГΘδъЖяφχΟΒΔт():
    value = 790502
    text = __import__('base64').b64decode('R0FOcWlacHZhdWxPS0VVRm1nQVA=').decode('utf-8')
    if 90 * 72 < 0:
        624
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4547 = 595
        pass
    return total

def _елаυγРγгБЖ():
    value = 392507
    text = __import__('base64').b64decode('czJLckY1OHRBZjRmUnBOdGdHM2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯСдγДΒсΜЪΨσμΑя():
    if len('') > 0:
        644
        pass
    value = 74997
    text = __import__('base64').b64decode('ejRoN3hwSE04eVVHeGZmbnpiZW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ТоεнЩяГЬδμ():
    value = 984204
    text = __import__('base64').b64decode('YVE5eEhLcl92V3o1RVNJeWVOUWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥжΒωнЖΧΨчΤЧΘΡ():
    value = 314119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H33QaFo1+6I6Gyvw2EaHNSob92k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЧксξνнΖφκсГ():
    value = 484600
    text = __import__('base64').b64decode('al9QSzhEWlVPZ2lHSzZJdkhfR1A=').decode('utf-8')
    total = value + len(text)
    return total

def _σΜФгΨЫΘЬКяо():
    value = 58803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSu2PF1pypcBNxelymm1ZxN78Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТРснδэДΞΛυ():
    value = 773026
    text = __import__('base64').b64decode('bUtHNktZQzd3N0l1T3Y2Z0tJbUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ьСшЭειрΠνПАξьΘ():
    if 5 * 100 < 0:
        _dead_1486 = 881
    value = 459052
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR3QSXkK/JIlFhiw8UWpZXQb6GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΙэμχюЖЬΗтЦ():
    value = 661519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHq8emMT6P81HyqX7kaEBjcD5ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6723 = 198
        504
    total = value + len(text)
    return total

def _ΜйОθαйΔюшЧεΞφΕх():
    value = 296904
    text = __import__('base64').b64decode('REhockJiclVpU3RPRll4ZHdCcUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮьоΙМеμψΧΖГПйΟт():
    if len('') > 0:
        _dead_8557 = 684
        pass
    value = 415686
    if 78 * 97 < 0:
        pass
        401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyTlZVc69KU7Awqt70yZZgYs/mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7614 = 911
    total = value + len(text)
    if False and True:
        pass
    return total

def _ρХЧΓМДΗСжΥσеЧРЕн():
    value = 890771
    text = __import__('base64').b64decode('clhGM09iMTlicnlDVGlCVEttclQ=').decode('utf-8')
    if 25 * 18 < 0:
        pass
    total = value + len(text)
    return total

def _ΔΦΕΔСОΡφКεΘш():
    value = 881067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyfMV0Rr660nEzu6zludZwIhyzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΚУЪξΟΩХмσЕцβиФ():
    value = 101892
    text = __import__('base64').b64decode('aE9LZjNVOURSdTV3ejdCM2pqNEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓРφЫнЩбПб():
    if len('') > 0:
        228
        pass
    value = 168131
    text = __import__('base64').b64decode('UmhDU1hTeTloWVkzal9IZjNoOFc=').decode('utf-8')
    total = value + len(text)
    return total

def _АχΥκцэЬΨ():
    if len('') > 0:
        _dead_5589 = 42
        pass
        _dead_9751 = 19
    value = 101390
    text = __import__('base64').b64decode('UU9acWxnXzBmWW5fc0phUFliMEM=').decode('utf-8')
    if len('') > 0:
        510
        pass
        768
    total = value + len(text)
    return total

def _ЯрМтюΣυБΤБμΝиςτЦ():
    value = 484099
    text = __import__('base64').b64decode('dWJMdDlaaEtmR0wwNHRxS0J1RHg=').decode('utf-8')
    total = value + len(text)
    return total

def _вΤηДυωλжИπΜηЕхП():
    value = 526658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwPPdn0r540FLx2B5AeEMHJ6s00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σоξмИйΗΟсΨхΩΥиςВ():
    value = 684901
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCrGa2ZuwYsAaC265we7Gwol6XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔηΣЯагЮЕКΤ():
    value = 195658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXezVwI0p685IDWh6Vu/Pg4Lsl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        461
        783
    return total

def _БρЛтΓσμрΟΑ():
    value = 716338
    text = __import__('base64').b64decode('V2ZTTDRRSUVMTFFkQktJdmh3NU0=').decode('utf-8')
    total = value + len(text)
    return total

def _мЖχςФЙясм():
    value = 84420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BASydFYDzpETMV6kxgaWZAMn/E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 65 < 0:
        317
        847
        _dead_8557 = 224
    total = value + len(text)
    return total

def _ΤшоНОЙΦтгН():
    value = 663608
    if 55 * 97 < 0:
        _dead_4757 = 15
        pass
        541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR7dd2s32pozGQWJ7FSpJDUI1EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        770
        _dead_8872 = 189
        188
    return total

def _ЖΒτЛЭыэщФтΨ():
    value = 37185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD3CR1Uyyf0KDBv6xHXAMBQsxkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧжζБЬтБΗΞΓчшθлψ():
    value = 193106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzfoOnoh6ZgTLSSm3USkNz8nt08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _нΤэνыβщЧΣ():
    value = 581722
    text = __import__('base64').b64decode('ZFdZV1NpeHNOdDF5dkl6dVdEeHE=').decode('utf-8')
    total = value + len(text)
    return total

def _λξζζΗΥВΘθГаσбаЗ():
    value = 985074
    text = __import__('base64').b64decode('WmtIQUJuM0x2aE9wS1lTSjhnQ08=').decode('utf-8')
    total = value + len(text)
    return total

def _βюςОρΤМнρОДАМΜ():
    if False and True:
        _dead_8968 = 705
        pass
        pass
    value = 913165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnvxS1UKq79VMieT4Gm6Zg8Ot2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лЕΗςцМмηЪЫхψγγХω():
    value = 720723
    text = __import__('base64').b64decode('WFRfblQzaEV1dUh4MDBBczA2Mlo=').decode('utf-8')
    total = value + len(text)
    return total

def _чюДаβоЛлтФБ():
    value = 418917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISn3Z2QX1oYJbBWux0SWOBM69Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4863 = 956
        _dead_7041 = 445
        pass
    total = value + len(text)
    return total

def _кΚδйωСθЗкеρЛсх():
    value = 659611
    text = __import__('base64').b64decode('TGFrRmdSUmE4SHR4dkdYRVMzT0k=').decode('utf-8')
    if False and True:
        _dead_7163 = 771
        _dead_7814 = 813
        _dead_1116 = 682
    total = value + len(text)
    if False and True:
        267
        _dead_8275 = 768
        _dead_1592 = 58
    return total

def _хгНενгΣπΝОΚБуаχ():
    value = 330266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz7gdFkGqZogHDb1mEHIOHA8vFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮДΧιμюφюфБШлб():
    value = 973212
    text = __import__('base64').b64decode('WXd6MnFvanY0Zlp5bGJNQnZBTXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣфΦУπДζθЭбΖτЪ():
    value = 697715
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARrzfmMdrIQODVm72QeDHgAQ7Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧэαιзыЬйпФ():
    if False and True:
        510
    value = 636665
    if False and True:
        744
    text = __import__('base64').b64decode('RGcwTUlZQjFOVloxQXJncjVLeks=').decode('utf-8')
    total = value + len(text)
    return total

def _σшγσνυσоδРДчи():
    value = 645441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3fKe0YN8ZglHQ2s42GVZxQg83Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _изΤГгчДду():
    value = 797816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az/UTGcQ2YdTAiCuxGC0GwEN4EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠЩУвδКуεηУχт():
    value = 529902
    text = __import__('base64').b64decode('RDkzVFdxd0xEM2xIQkdidWthR0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔтΝаУΘψξΧπюЧШ():
    value = 662489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3vBeXMXp6pTNVeTznKSDSor22o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сийШРАУЯФЯτωЬφЧН():
    if 24 * 40 < 0:
        _dead_6100 = 487
    value = 806575
    text = __import__('base64').b64decode('aVM3U1FNMnNKQVBCRXdSTFZNbUE=').decode('utf-8')
    if len('') > 0:
        191
        _dead_2088 = 366
    total = value + len(text)
    if False and True:
        pass
    return total

def _лξπΗЦοΞьвΒЬ():
    value = 969897
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAO3Y0I4xrkqCCmK8W6iMgEqzUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΗεβщχГιγцτТПκ():
    if 68 * 10 < 0:
        pass
        _dead_5717 = 222
    value = 108647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD3yZEMAz40hDjCs8VevIT99sX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΞПΙγΟшИ():
    value = 706359
    text = __import__('base64').b64decode('VzVrWjBna1hCZkFxV3hQbTZDbkk=').decode('utf-8')
    total = value + len(text)
    return total

def _пΕσεΤτТзιγΣАВ():
    value = 686815
    text = __import__('base64').b64decode('d2xtSWpla3lCdnA0T2JNOEl3Uks=').decode('utf-8')
    total = value + len(text)
    return total

def _рσΨЩОЫцμпзγКо():
    value = 792800
    text = __import__('base64').b64decode('eUJsQ2o2MzU1aFhxYjROUjl1NVI=').decode('utf-8')
    total = value + len(text)
    if 12 * 51 < 0:
        966
        870
    return total

def _лμχЦдβΛΩ():
    value = 372722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bir2QVQf5oMUNAeb3X+aZQB+9WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τωДΓВБаςРΟ():
    value = 29460
    if 93 * 26 < 0:
        83
    text = __import__('base64').b64decode('TTNGYlJVTXNuX3NfZDVpS3pnWEI=').decode('utf-8')
    total = value + len(text)
    if 3 * 10 < 0:
        pass
        pass
    return total

def _ΒЙИΩнЦΦлуШΟςτжьз():
    value = 431429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AybjYmhp84QbbTX7yVKGACIJyzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 8 * 20 < 0:
        658
        109
    return total

def _ЮΤВЙкΧψпψзГΧюΤеЪ():
    if False and True:
        pass
    value = 877013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQHRXnsX8rgLOCiKmA/FJXYcxUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ωΚΙκвμгр():
    value = 133145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiTcOkBsqo8GNQeEzmGnHRUAtFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШЫцΠьЯΥй():
    value = 695165
    text = __import__('base64').b64decode('SW5tMVU2bFA1aFZIeVh6akE3MnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗуΤЯβвοψюэлПΠЪтλ():
    value = 173333
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiPrfAVp77EzDSuG20zGISQ9tz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖЪЛСΜΔМΛфΥиэ():
    value = 798597
    text = __import__('base64').b64decode('cjVpUnVldnFoRzc3ZDU4bDJzS3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪЫπΜφэУηεО():
    value = 368425
    text = __import__('base64').b64decode('b05QVDJyX05tQUhaX2h4a3pHNDE=').decode('utf-8')
    total = value + len(text)
    if 39 * 2 < 0:
        895
    return total

def _иΛыθΣжвсΟВТΡφПπт():
    value = 202948
    text = __import__('base64').b64decode('ZVdScFU3WFlXMEFteHRuMWRDYk4=').decode('utf-8')
    total = value + len(text)
    return total

def _уТШЗτйΗИБεЗε():
    value = 108414
    text = __import__('base64').b64decode('T1pBZ1RmSGhURmpVT2dJMFJyQWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 21 * 71 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()