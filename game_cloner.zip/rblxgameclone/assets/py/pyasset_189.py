#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ξВЖЩωхВθПΘЮНКκ():
    value = 742190
    text = __import__('base64').b64decode('R1JQRThESEJwV3I5N01SaFJXYm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΡРωψΑΒЖ():
    if False and True:
        pass
        473
    value = 69275
    if 57 * 74 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAa8fHgWqrwNLiaKmgazFRZ452c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        516
    return total

def _θггчпшηξΞ():
    value = 924641
    text = __import__('base64').b64decode('ZWxNWkwxbGJ2cXRRb3N6THZzd04=').decode('utf-8')
    total = value + len(text)
    if 56 * 29 < 0:
        pass
        pass
    return total

def _ρсРоΣςΘδΡΧоючЯ():
    value = 556607
    if len('') > 0:
        _dead_2282 = 77
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiHpQkkW8Lw1CzCtzESCZwE/xmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠВξφАйΓРВ():
    value = 11459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA3KWHs2x/4KP1yo8USZCyw+8UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 21 * 88 < 0:
        pass
        892
    total = value + len(text)
    if 38 * 51 < 0:
        494
    return total

def _σжимΖбΔлиайνЩθ():
    value = 340340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AS3idgQU9ZE0PFaBnkfDASYctHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒоЧΚВΤспмУкρφфΕВ():
    value = 75907
    if len('') > 0:
        _dead_3882 = 945
        pass
        _dead_5857 = 632
    text = __import__('base64').b64decode('ZzRnTEZOOXFXM0JrUWRvNnlxS0I=').decode('utf-8')
    total = value + len(text)
    if False and True:
        684
    return total

def _пΜτзиДΦφЕΤкЮЙРО():
    value = 754253
    text = __import__('base64').b64decode('ZHVqdU9hdXRzdWdFU0hlejluMEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _елγγΞепНй():
    value = 252547
    if len('') > 0:
        _dead_3886 = 804
        _dead_4881 = 361
        893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjn+Nlw465sCaFmr0GyDFyAg8ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΟАуΗΒмэЮΞδц():
    value = 57743
    text = __import__('base64').b64decode('UEp6SEkyTWhZel9wa3RuQzdKZXM=').decode('utf-8')
    total = value + len(text)
    return total

def _рлυТюшλρΧИσ():
    value = 275633
    text = __import__('base64').b64decode('UjNQZ3NhVl85WkpLUmxiTkpjYVY=').decode('utf-8')
    if False and True:
        351
    total = value + len(text)
    return total

def _УυЙеНбЕОзΒЧφΓ():
    value = 784104
    if 94 * 40 < 0:
        _dead_6330 = 601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dwfdd2A3954hIF6Z8UGjNXwZ3k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8553 = 345
        740
        341
    return total

def _РьДЛВюΩЕЭиΜ():
    if False and True:
        803
        pass
        _dead_4218 = 108
    value = 220577
    if len('') > 0:
        pass
        _dead_8364 = 585
    text = __import__('base64').b64decode('UWF2dWxLRGJQVENGSFkzdG1aUUE=').decode('utf-8')
    total = value + len(text)
    return total

def _λΕпвξцζЧяΔΖяΦЖΩ():
    if 67 * 77 < 0:
        _dead_5890 = 11
        349
    value = 22362
    text = __import__('base64').b64decode('YnlSNHVnNjgyMF9mTXM5RF9SY3U=').decode('utf-8')
    if 51 * 42 < 0:
        _dead_7808 = 394
        pass
    total = value + len(text)
    if 89 * 70 < 0:
        _dead_5808 = 308
        75
        pass
    return total

def _уΚкΦΘЩРгт():
    value = 542786
    text = __import__('base64').b64decode('SzFTcmFvR1hHb0FOSHA4d3JUX2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΞΠСпОлσЪНς():
    value = 769459
    text = __import__('base64').b64decode('TFR6eUZYeWdENlpWeHlNT1d1Wkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ιωЮшЖωΩУгκ():
    value = 42553
    text = __import__('base64').b64decode('YTJEZGszWTJ5WG5sZmFCMEpSTWo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        67
    return total

def _πОмβΒΧΗЛΖΨЮΦуπх():
    value = 145917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBbwWngQqPgALy6h42SiJwA4yWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ывοНνрμщСы():
    value = 348719
    text = __import__('base64').b64decode('a3loeld3eW9Od2Njd0FIRUo5YjA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        799
        _dead_1657 = 284
        pass
    return total

def _мЙσЫΜиМБξЪΦфψуС():
    value = 242579
    text = __import__('base64').b64decode('cGE2dHJfY1ZYd3ZKdnZkNkZpb2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ρОтΙВдпςтФ():
    value = 813707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjvPTwYNzZcZMle0nGPDLSoatVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΣХνρфДюΒζШшκςИ():
    if 89 * 52 < 0:
        594
        pass
    value = 649452
    if 39 * 54 < 0:
        _dead_8245 = 294
        pass
    text = __import__('base64').b64decode('VTQ2eDVSdjZEUXhCYXlPU01tZGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΚψνΖΛκйΟωυ():
    value = 766039
    text = __import__('base64').b64decode('a0xoYnF4aGNxQ2tUOERUQk1iVGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓХΤΒβиκψе():
    value = 84921
    if 33 * 60 < 0:
        577
    text = __import__('base64').b64decode('ZHlxSE9vNjNidnF5VXo2clRCT3E=').decode('utf-8')
    total = value + len(text)
    return total

def _УκТςСЦЯсΝя():
    value = 381076
    text = __import__('base64').b64decode('UkJaemRaM0FXcHZQc3lpRVNNZGY=').decode('utf-8')
    if 23 * 54 < 0:
        pass
    total = value + len(text)
    return total

def _πлЧΑлΣΝΠПξЭνΟ():
    value = 315970
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BijPa1U92KkkGDX6kGTHNT0GxkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πρЫжЮΛΚБЯΩΗЪ():
    value = 207992
    text = __import__('base64').b64decode('UFNtb0E1dGZReTBiX2hEWXFFVkw=').decode('utf-8')
    total = value + len(text)
    return total

def _нлΙοъρΨΠΔΔΚτςΙр():
    value = 463052
    text = __import__('base64').b64decode('R2hjNEJiRG5FSjVYMTRxVTlzaDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖОΤЬфЬυЬэΟδΦЬЧдД():
    value = 397084
    if False and True:
        _dead_8310 = 112
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAbIbUkt67pXMR+yznTFYAcr6lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 17 * 7 < 0:
        931
        238
        pass
    return total

def _τПΤΜФυсςΧςΥΟЛыФ():
    value = 576114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgLJNlQh5KwMMB768mm/My957Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 53 * 4 < 0:
        772
    return total

def _δДΥБЖΛДПэΞэо():
    if False and True:
        pass
        _dead_6982 = 496
    value = 1698
    if False and True:
        _dead_1641 = 645
        586
    text = __import__('base64').b64decode('aGVTakxDbzRnWVBlOFg5emlBUFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ШζΜАйОРьа():
    if False and True:
        _dead_6675 = 457
        343
        pass
    value = 595272
    if len('') > 0:
        _dead_9898 = 258
    text = __import__('base64').b64decode('U2piYUlsYXpwYXZBakJ3eDJTNks=').decode('utf-8')
    if len('') > 0:
        _dead_1186 = 353
        pass
        _dead_6916 = 77
    total = value + len(text)
    return total

def _νсДпΦΔЛщжγъЦИЫεΑ():
    value = 771546
    text = __import__('base64').b64decode('Y1Y5bjBoZk5wWXdyRHo1OWlWTUQ=').decode('utf-8')
    if False and True:
        _dead_5634 = 118
        _dead_8376 = 92
        pass
    total = value + len(text)
    return total

def _УΤΒΖεЯИзпβΘгΘчжθ():
    value = 495441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnbufFQO1Jw7CCC7nEOcMyIqtms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚьэМυяτЦМα():
    value = 909350
    text = __import__('base64').b64decode('WEhoMDh1V3h4VVU3TTNFTGx2QUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙчкΞψВΙнЪСАБхБχ():
    value = 576454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQ7dZ1dsyYAyCgCA3F6BPw8tx0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДЮφБщцвоВυΗΚπΨζ():
    value = 162392
    text = __import__('base64').b64decode('ampyNDhKWEJETG9OOHlMZE9zVko=').decode('utf-8')
    total = value + len(text)
    return total

def _νоΓΝκνΗυх():
    value = 824654
    text = __import__('base64').b64decode('amMxeEtOcFJnNmpnbkNyNHh3dFI=').decode('utf-8')
    total = value + len(text)
    return total

def _фЕЕΓиΥжФωаκу():
    if len('') > 0:
        269
    value = 43539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQLOVEtryqUvPAyk2HfHIygtxV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АкяеуцрΝйКγηл():
    if len('') > 0:
        pass
        pass
        _dead_1419 = 343
    value = 265990
    text = __import__('base64').b64decode('eWdfUWNaU1NIZXVYYVhEWFNBdWs=').decode('utf-8')
    total = value + len(text)
    return total

def _дЧαуЪЭеΠΩΤсиСΨЧ():
    value = 746168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQrjakYyxoM1LguGxWaJCyYLz3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        552
        _dead_4505 = 470
    total = value + len(text)
    return total

def _тθτεъΡэУГ():
    value = 351606
    if False and True:
        37
        _dead_6958 = 202
        _dead_2673 = 951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADryZkMYr7wXFgewwHCgAzI63n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 12 * 52 < 0:
        pass
        _dead_7210 = 622
    return total

def _идчЛΩНуАν():
    value = 399615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AX3SUWg4yrwBYwf63EPGBxwN6T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ογЩζВЖщвШλМаФР():
    value = 651491
    text = __import__('base64').b64decode('a0NGdkJQNGtwdmdLU1JscENMbEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ργфЫтЭκπου():
    if len('') > 0:
        _dead_6430 = 669
    value = 634792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCvBQ0Zv24xXCzf060aANQcQxjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        187
    return total

def _σЬΠшБИωжшо():
    value = 746204
    text = __import__('base64').b64decode('UWJkRzIxcXhzYVp0ZHhjR3l2dE4=').decode('utf-8')
    total = value + len(text)
    return total

def _кζΕЦηФДМοζИЯ():
    value = 805073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBa1QXlgqbEnbCyW/V+1IwQW42o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρжФхΘψωыεθдфэп():
    value = 806390
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDXCaEEo8qAlKDmm6m+YLSA6z1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΥыТαΖФбαδ():
    value = 956168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgTFXwIr/aUwaDqI7m6lHyY89T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥеБСμΑτΘчΠ():
    value = 584055
    if 90 * 27 < 0:
        _dead_9261 = 560
        733
        945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiXhdHsW5p0FIlf3kGecJSkgs14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εигιАеΡΒЭΘζωфνΞл():
    value = 864468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjzeakAMzv4mHyO55UKcEXIb63k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЩИтρμАΔЫΓЪαа():
    if 8 * 12 < 0:
        pass
        313
        _dead_4315 = 952
    value = 666332
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwHlVn4v8oEsLQGN6lGcAQwjsT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЛΠπЖчςπςλбΞΓня():
    value = 251470
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRqwR0UK9IkSYwz74GanEAEk8zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψХΑИτЦлΕЗцУьеδ():
    value = 14441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQqyP1Zh85dUKyaM3kaDOik543c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕвдХбфшююЭΚЭЭΒоч():
    value = 322239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IinBaUABr5AKPl+l73WqFQg6/jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чЭБΕчцτΣΑЗДδμШ():
    value = 693706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxfxbWc+86EZGDm251q4Jg8D9GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6586 = 549
        pass
    total = value + len(text)
    return total

def _шхьщγΨСЦ():
    value = 949027
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQe8WlwJ/LEXFQur+F+6GR0X1Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υХАΝΩΥщжДαΡχВ():
    value = 722244
    text = __import__('base64').b64decode('Wnh0VWRScFpJcThPN19udHdGbXc=').decode('utf-8')
    total = value + len(text)
    return total

def _εζеЬщДИОαμлЗБлβ():
    value = 458122
    text = __import__('base64').b64decode('V3dhTF9qcjdsV0U0VUU3eEZ3blU=').decode('utf-8')
    total = value + len(text)
    return total

def _μяхФΔчΛΟиΝЗУДОэМ():
    if False and True:
        _dead_3231 = 910
        445
        pass
    value = 319634
    if len('') > 0:
        _dead_2212 = 838
    text = __import__('base64').b64decode('VWpxTFl0SmpxZGhYb3ZHRWJwa2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕгΔЯΥΟПΥй():
    value = 210611
    if 18 * 9 < 0:
        636
        _dead_9257 = 632
        _dead_4139 = 438
    text = __import__('base64').b64decode('cnl0NzJQaGd1QUZnaHpXUEhXZVU=').decode('utf-8')
    if 12 * 68 < 0:
        _dead_2986 = 464
        _dead_8527 = 792
        759
    total = value + len(text)
    return total

def _зСэлΔνδκΞеΩ():
    value = 213806
    text = __import__('base64').b64decode('dUpzQnBVMld1eW12M0FFUU9pdXA=').decode('utf-8')
    total = value + len(text)
    if 72 * 5 < 0:
        _dead_6458 = 712
    return total

def _ЯΝйжРВЩсЫщпΗΓΣсШ():
    value = 855247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ezm9dAcO6fEmb1i0/3OfPxYK0DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔИχΨюΡлνя():
    value = 287826
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICHbZQNo+Ps2L1ac2n+hPgwY4mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        996
        569
    return total

def _ИШβЬΝΚмнЖ():
    value = 888476
    text = __import__('base64').b64decode('T1pGUV9fclhhYTcwbmdwcVBkMXM=').decode('utf-8')
    total = value + len(text)
    if 96 * 29 < 0:
        pass
    return total

def _ЫЬΕΒοκеЭ():
    if False and True:
        pass
        pass
        241
    value = 45111
    if len('') > 0:
        658
        819
    text = __import__('base64').b64decode('UEV0ZmtHMWFUTFZKeHZXa0pVRTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ыбиАОνξЕы():
    if 3 * 91 < 0:
        _dead_3955 = 823
        pass
        772
    value = 921454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRfxR2cq3Y8wLlaX60SKGTYM8Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        417
    total = value + len(text)
    return total

def _ΘΞоλуωХэцчΝ():
    if 83 * 32 < 0:
        pass
    value = 264777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSryX3JqzYQNDiim3WmaYjwZtmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВζюОзωЦгλ():
    value = 575469
    text = __import__('base64').b64decode('VlRhUVBQa2hxemJGSTNvcTZCdE0=').decode('utf-8')
    if False and True:
        _dead_1607 = 547
        pass
        _dead_2510 = 889
    total = value + len(text)
    if False and True:
        _dead_7588 = 882
        491
        12
    return total

def _νχмцфζъбωвψΜЮъθГ():
    value = 289727
    text = __import__('base64').b64decode('RHA2NkpIcWNqbkxSRVNmT0JXS1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΟЮЩυεуЖЯцςχ():
    value = 438095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DifVaGY4zpA3IDWWxAfBLBM36U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΛΠΛГДяИτΗтМ():
    value = 936485
    text = __import__('base64').b64decode('TFFBb0xQUm5NdmlKVUREbTlaeEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖεΦлΤЯлЦ():
    value = 992193
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDrlZFgr+4Y7aiSZ7HGzJT0qtkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΟбфηΜΠЗΝЛΘЩд():
    value = 235508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjbFQFU47f0hLFmonmnBFnUH7VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λδхЗγсΖыЧκЩЭΓ():
    value = 304146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXrxSwU19oYAIge3mlqbLHUKxzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υМυΗΝτДφχΛοΠюγπе():
    value = 211924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjXQRVA33bwMKTmg53KAJCQK/WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГцКОΘΔωхΦЦо():
    value = 918915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KATDaGYr1Io6HRqwwWyCBiQkyF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧμΟΞдХМЩεψψτΑ():
    value = 1880
    text = __import__('base64').b64decode('V0Jwd2VoMHBFTlVpWW02VG9jd1A=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _жДΣкαКфκΨжщΩ():
    value = 952689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxW9XGYA76ISNASznlO7DDQktXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞйΣОБυЮΖэΩΞхΦ():
    if False and True:
        790
    value = 97974
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH/9awEx2YcsPyOln0eiACkW22U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΡМЖιΦβтΓ():
    if 62 * 66 < 0:
        _dead_7252 = 278
    value = 293416
    text = __import__('base64').b64decode('eVpoRkprVk9OTXFwQW8wZjZhXzE=').decode('utf-8')
    total = value + len(text)
    return total

def _тτυΔмфЛΖΓ():
    value = 561521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwvuOAEa9fkBEF2q8GLDYTMgs00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кМοфΤтλθХΧщΘЪΘ():
    value = 439726
    text = __import__('base64').b64decode('TUc1YWlNTGxlbEtGWlNWN3JxX3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ГЧчςэδφυπВ():
    value = 858173
    text = __import__('base64').b64decode('ZnhDNjFSU19FSFFJbFhwcnY1Mnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡηОдокκЕбЩΨ():
    value = 958675
    text = __import__('base64').b64decode('TG84aGw5ZEFLUTI4dFV6MWd1Q2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯθуΣЫгКЧ():
    value = 811843
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhnUVHcSxp0wbwn37XC0IiY8sWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟηθΝΚΗΛΑΚппыгψΦν():
    if 97 * 69 < 0:
        777
        84
    value = 827813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCvKWgI+rJcIGRqtkQeKBhw6zlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςФλЯфπСΜтгШЦэΔΦ():
    if 93 * 4 < 0:
        _dead_3093 = 237
        pass
    value = 572474
    text = __import__('base64').b64decode('aFp0cDFkS09qUmhTMlVzV0l1bkQ=').decode('utf-8')
    if 90 * 94 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ьξщмΛοΕЯΣчВΡςυΧ():
    value = 175279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwTlbAUhxv4kFl+Cn0+AZ3Uctj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ьΔΒΞΓДφνЦуш():
    value = 894429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCDBaVAewf8lORXx91WJFwcr0WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        439
    total = value + len(text)
    if len('') > 0:
        503
        453
        pass
    return total

def _ΞтьпβнТНιοдμ():
    value = 578970
    text = __import__('base64').b64decode('TWRCZkQ4cHVFUnVMY0MxSlFWQ0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΘЮАιвЪνΔэ():
    value = 145584
    text = __import__('base64').b64decode('WU1zMTk2c3BRaWZlTXpQNGdQbWo=').decode('utf-8')
    if 41 * 23 < 0:
        _dead_8785 = 327
        _dead_5208 = 367
        899
    total = value + len(text)
    return total

def _ЖЖэВΞнηнтт():
    if False and True:
        _dead_1073 = 766
    value = 8466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwjNYFdrzZ03FzDz7lqiDD994Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 85 * 45 < 0:
        pass
    return total

def _бКьδыыωЙΔΡθλ():
    value = 342122
    text = __import__('base64').b64decode('dWR5SFl2RlpQX3ZhTmRwV1h1bEs=').decode('utf-8')
    total = value + len(text)
    return total

def _фсКωΞΟΗνΙ():
    if False and True:
        211
    value = 824642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LS3MWUAr34Q5OQWtzA63bCAcz2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        509
    total = value + len(text)
    if False and True:
        _dead_7822 = 578
    return total

def _υΥУФβбщΠаΚΘ():
    if len('') > 0:
        pass
        pass
    value = 87205
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy73eVcW0JFVMFaZ4F+7JQsqsFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        41
        567
        _dead_1586 = 498
    return total

def _ДΓΨΣчЪвυДиЛ():
    if 39 * 33 < 0:
        _dead_9217 = 611
        _dead_3373 = 273
        pass
    value = 230656
    text = __import__('base64').b64decode('UkgzMnNobzgyMEFTamFIQnpIc3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _чьροЮΞЫЦ():
    value = 347239
    if len('') > 0:
        511
        pass
    text = __import__('base64').b64decode('UUlPcHFHc255WG9mYmJ6WVB1ZkU=').decode('utf-8')
    if 47 * 30 < 0:
        777
        186
        pass
    total = value + len(text)
    if False and True:
        651
        687
        _dead_5086 = 245
    return total

def _ЗзΡΞΠφчшьςΥ():
    value = 307523
    text = __import__('base64').b64decode('a2NMcHV0ZENNWE9Wa2tLVld0MEM=').decode('utf-8')
    total = value + len(text)
    return total

def _хΤΩхπЛπαΗВтοοΧе():
    value = 793420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jgu2YgBqr7E8MiaO0HO7YCMsyF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЫУУηεθΚΛ():
    value = 890074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjvuWFRry7gXElv3xA+8Ow0W8EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4458 = 707
    return total

def _АωКхβηγХюΧδΨКΕΕ():
    value = 943213
    text = __import__('base64').b64decode('RmxoaHBKUkZjT3lxVGJPUzZvbko=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬФΚрэΚЕЬЕиωω():
    value = 411088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA73amcj+/EObjWh2l6pBBYj0Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нруфΝчρωХΑζ():
    value = 651469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kxe2WVswyrkZMDn7wXW+Zz8k138='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΜΠΓΘнυςΓтмβθеВН():
    if False and True:
        _dead_7920 = 133
        83
    value = 106619
    if 78 * 8 < 0:
        _dead_4994 = 700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgfQaWZg5vwPCxWQ3W/INyMN8Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТэαμФСνΖψз():
    value = 146920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhzURGIP+6pSAz6r0HSxPQonvWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЯгВТψΡψмЙΖсЗГШβ():
    value = 28806
    text = __import__('base64').b64decode('bEZmT1lSUEdrUmtNTFBoWlJIYUU=').decode('utf-8')
    total = value + len(text)
    return total

def _θяНΟыюδЗш():
    if False and True:
        _dead_8290 = 855
    value = 734733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyPLW1UA1rwwNA6Un0elByIn1ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8293 = 50
    return total

def _ХθдΥЛδЧЕ():
    value = 461862
    text = __import__('base64').b64decode('UlUyVlU3dXBKbjV2YjZJTDJRTGs=').decode('utf-8')
    total = value + len(text)
    return total

def _тЕЮвшΠЫхρνжΠСиΘκ():
    value = 528207
    text = __import__('base64').b64decode('Qkt4NWZCQ21WN0o0MVdqYl9FQVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _пΞΨтБТюШХиΩΥБСΒ():
    value = 895349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH3oWgUW2YkBKFaLxUCTIzYh1V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ζЕςясККΖνНяγ():
    value = 795436
    text = __import__('base64').b64decode('UlpZMko2TTQ3dW5pZXNqTnhuWWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗоюдФьаπмΑΒфΟΤΓΡ():
    value = 695549
    text = __import__('base64').b64decode('ZTNLVWdxdThadjdPeEE1QTRqckU=').decode('utf-8')
    if False and True:
        _dead_9019 = 58
    total = value + len(text)
    return total

def _θΔσСΓГψцЙЦцмΤузΖ():
    value = 309384
    text = __import__('base64').b64decode('WDNhdFg4M0xOMWxjYzlZUjVyUTU=').decode('utf-8')
    if False and True:
        pass
        390
        pass
    total = value + len(text)
    if False and True:
        21
        508
    return total

def _улбυжΗπΤζаИСΚ():
    value = 51294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MA33RGA30qsKa1uhz36GBAgnwV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8679 = 513
        _dead_3263 = 757
    total = value + len(text)
    return total

def _ΚΤГΖхγΔЗШЗшФΨχав():
    value = 591683
    text = __import__('base64').b64decode('R0sxeG1tdzBBaXVZYTJRV1NCOUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ъФξЕΩευЬсωь():
    if len('') > 0:
        90
    value = 117365
    text = __import__('base64').b64decode('cHNaRFVtZGhxall2SzRSeTV6RXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘаХхГψλФΚΘλчΚЩ():
    value = 998634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgfzaFMJ1Z03Dyiz+H69bREIs3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яβΘΜпηΜМζψξЧГЙлТ():
    value = 726755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH/BeGUc0qwwPRqn2E63Iwx2xkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΙΨμаνξпΟщΗААБИ():
    value = 713949
    text = __import__('base64').b64decode('ZWVjTFBLUGY4VjdjSzhQS0RmeFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΡыτлИΥΒр():
    value = 818434
    if 87 * 78 < 0:
        pass
        147
        869
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDjPe2U03a4lGDaMmkLCFRwh12M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΚЭΞαΜρкдΦΠςЮХΠλ():
    value = 480224
    text = __import__('base64').b64decode('QzROQjJISHdiQU9JaHZVU3ZhMlU=').decode('utf-8')
    total = value + len(text)
    if 13 * 21 < 0:
        _dead_6143 = 440
    return total

def _чдρэЗОЙΒОγнЫ():
    value = 312623
    if False and True:
        851
        pass
    text = __import__('base64').b64decode('SVdWdDNINXBGNklxZjl3cEQyOXI=').decode('utf-8')
    if len('') > 0:
        408
        469
        839
    total = value + len(text)
    if len('') > 0:
        153
    return total

def _ъΘЛΣδξуψΒ():
    value = 33658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kz33al4SwZoIIzDz3FOBDAc89Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μНРρΠΖΘΚθ():
    value = 739940
    if len('') > 0:
        494
    text = __import__('base64').b64decode('R1E0bGJEUjhjZFpMZjJORW5nRG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤИΦΑвЦβгζнсΙОЛπα():
    value = 57059
    text = __import__('base64').b64decode('Y0JjMXV6eEw2ZmpiSVg0NmIxVmE=').decode('utf-8')
    total = value + len(text)
    return total

def _еΛΦщдЭμΓβшЫи():
    value = 241843
    text = __import__('base64').b64decode('TTZDQXA2Z3haQTYwdG9FYkxka2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝЪАтСЙΙНοйтΨΥШ():
    value = 266387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDXle2YdwZ4rHDm5/0yFBCoJ930='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χДψΩιЩΔт():
    value = 756969
    text = __import__('base64').b64decode('em9fak1QYXkyMjZFb1N6ejhZTkc=').decode('utf-8')
    if False and True:
        755
    total = value + len(text)
    if len('') > 0:
        772
        _dead_6998 = 353
    return total

def _ιДΥοεгЩβжЙχС():
    value = 506393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDmyeFwGr6olCBfw6w6nIQou5j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_7350 = 1
    return total

def _ТЗΗСчηЙΤςαрПτ():
    if 8 * 78 < 0:
        325
        pass
        655
    value = 661561
    if len('') > 0:
        _dead_5578 = 159
    text = __import__('base64').b64decode('WGNObkJHNWtuNTkzdFpJZzQzMVU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3925 = 159
        471
    return total

def _ВБСιΣчрΩ():
    value = 132370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyC1a2Aw8YsROFqV/XvIABQDvDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒНДνРΙдчщΗэ():
    if False and True:
        645
        _dead_8193 = 523
        pass
    value = 332384
    text = __import__('base64').b64decode('bGZNOU56TXl0YkJ5YW1VM21vb2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗшΓГλШξмЗ():
    value = 117943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3z3PkcTx4omChrz3FG8GBMGyXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЗкыъοΚкшΤφ():
    value = 435067
    text = __import__('base64').b64decode('UXdWaUhjRXVoeDhYX2JpUHVqcVI=').decode('utf-8')
    total = value + len(text)
    return total

def _γАыΤеμΧОΨ():
    if 54 * 19 < 0:
        844
        pass
        pass
    value = 976884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADfxeWYwwaUTYgG6m1CjDXYW/ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        219
        168
        237
    return total

def _ψФιлΒΟθИυΗη():
    value = 203579
    text = __import__('base64').b64decode('UDJib3NOUFIzclpVMEpCaXVzaFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ШξΖΛΝζωо():
    value = 603293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAfpS0s+8YpVGzqB4l+4AS560lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 48 * 88 < 0:
        83
    total = value + len(text)
    if len('') > 0:
        _dead_1992 = 551
        522
    return total

def _ГЦΒοВυтξλЯжМзη():
    value = 911882
    text = __import__('base64').b64decode('SEpQczBwR19iMFZCNWNTZ29oZHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΛСФДякшсμΡ():
    value = 517708
    text = __import__('base64').b64decode('cXp2VjRudGRYcWt6YXdaQmNueGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥКΖΖЮσЗτЪοΡиΡπБХ():
    value = 120697
    if False and True:
        pass
        _dead_5885 = 89
    text = __import__('base64').b64decode('dGdydE9xZ2hxVm82TVRYVmRyRTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧаΕжНοΥЛΥ():
    value = 49789
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lhz3dEkyzf8UDDr30luJEgIm82I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СГυΧΑΥЯипбΒмгкв():
    value = 970484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyjyY3Iq/6Q7NwyF/VWzJH0e80M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛγηяцλЩξбξиюпΘХ():
    if 2 * 72 < 0:
        _dead_3069 = 416
        _dead_8141 = 398
        pass
    value = 494786
    if False and True:
        _dead_3184 = 228
        pass
    text = __import__('base64').b64decode('ZWxGalcyeldHTENWSzZHdlR2eWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦιΔΕьЧΗКг():
    if 91 * 15 < 0:
        pass
        pass
    value = 543473
    text = __import__('base64').b64decode('RUdCa1U2cm45M0w5X0FQc2VUbUk=').decode('utf-8')
    total = value + len(text)
    return total

def _гΨςΓсКГγСζ():
    value = 546750
    text = __import__('base64').b64decode('bmp0c1FPRnhRYzU1QTVvanBWcHM=').decode('utf-8')
    total = value + len(text)
    return total

def _сыΩΜюешД():
    value = 248135
    text = __import__('base64').b64decode('RjVHWFNsVHlSdzhsZkJtVFlIazM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        232
        _dead_3599 = 568
        pass
    return total

def _ΜямλψРμьЭπ():
    if 88 * 30 < 0:
        60
        pass
    value = 523385
    if 12 * 71 < 0:
        824
        _dead_8397 = 274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnrWakAQ+JAQFCeJ0W/GHCAq7k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 99 * 55 < 0:
        pass
    total = value + len(text)
    return total

def _φΘλΒяюБоюоЪΞв():
    if False and True:
        _dead_8192 = 447
        _dead_2869 = 671
    value = 593488
    text = __import__('base64').b64decode('eTNKYjZ4MWFZeUZZa0hFajRqQ2Q=').decode('utf-8')
    if False and True:
        _dead_8154 = 979
    total = value + len(text)
    return total

def _ЖЗгуωεэχθΤЮ():
    value = 360055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgDqN3oB9KQyKh2s3QCJZXw2tEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πаοψΘчМυΙθΣдΣ():
    value = 488060
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgL0RGs2/Ls3MCSA7nKpOwY+0n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йνКαБтαъЧζк():
    value = 165899
    if 44 * 9 < 0:
        _dead_1965 = 467
        _dead_4023 = 150
        725
    text = __import__('base64').b64decode('bFpLN0o5bEJ1MnE4OXQ3Rm1hc3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠτΧαсйкΝσШЪΝ():
    value = 955523
    if len('') > 0:
        812
        112
        119
    text = __import__('base64').b64decode('aGs1bkJxVFRrOEMza29tU1NKY1I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        878
    return total

def _ЕЩΙЪχΝβι():
    value = 993658
    text = __import__('base64').b64decode('TUFPX1JSckVOQ2RFV05ydTI0TG0=').decode('utf-8')
    total = value + len(text)
    return total

def _рЩнΥЦετаωλфЧΜ():
    if len('') > 0:
        _dead_6581 = 105
        _dead_9087 = 410
    value = 408322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCSzeAEy55pXFiynmFfHDCcC4Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΣδΠΛУΦщоνιиБ():
    value = 559488
    text = __import__('base64').b64decode('WjRtaDMxcHcwbzBMWEtRWVZkVm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒοπΡτжθΙГ():
    value = 381396
    if False and True:
        232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3+2e24QyZoUNC2SwAC/C3c/zz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЫсНφЖτΩ():
    value = 532740
    if 11 * 51 < 0:
        _dead_3017 = 705
        _dead_5207 = 507
        pass
    text = __import__('base64').b64decode('Q3ByWUhHeXBhTDNhSUczbmZiMkk=').decode('utf-8')
    if len('') > 0:
        _dead_3059 = 712
    total = value + len(text)
    return total

def _ЬψΑσχЦχъ():
    value = 734134
    text = __import__('base64').b64decode('ZkxvYWRqY1NEcTBybHZxdG1RNHA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        217
        658
        _dead_8355 = 437
    return total

def _ЙИМΡФыηхСВμАο():
    if 31 * 60 < 0:
        976
        531
        pass
    value = 168936
    if len('') > 0:
        pass
        803
    text = __import__('base64').b64decode('RlVhdlZwTmNPNWRQeDJCb2M0bDc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6117 = 680
        _dead_9622 = 998
    return total

def _ΗΥЮШΖσЩψРж():
    if False and True:
        _dead_5815 = 911
        _dead_3196 = 683
    value = 647856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXblWVkv3LIzNRWOxF7IY3wA11o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 54 * 39 < 0:
        _dead_4392 = 723
    return total

def _ΜсΒςЛΔζΙуδПσΑ():
    value = 431949
    text = __import__('base64').b64decode('T3JONl9oQl9udTBTYWRkcVlUd3Q=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3319 = 234
    return total

def _кΥΡτтΝщψκ():
    value = 65108
    if len('') > 0:
        388
    text = __import__('base64').b64decode('TG9iNHdXV0doTmVCdXVDRTJYemo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_7582 = 476
        _dead_5030 = 995
    return total

def _оΟбпьзκφКλαжΑл():
    value = 611568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDj3RkEc8ZhVHwn0+XmAEjEdwV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уΨЧВыξаЯ():
    value = 737167
    if 39 * 98 < 0:
        _dead_9565 = 955
    text = __import__('base64').b64decode('UnRXVGliejNINzFRaU1XTDNOUDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _аΔГскЩцγГзыЩΥЧжь():
    value = 295079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyrAZlkp3aYUbD6BnW+VNzMf6n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_5290 = 159
    total = value + len(text)
    if len('') > 0:
        _dead_8651 = 456
        _dead_3764 = 146
    return total

def _ЩιΛвТщеγн():
    value = 568139
    text = __import__('base64').b64decode('VjJORTFBSnc5WTVWaXVyMHZWRUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ηЫεεχшεταТ():
    value = 40231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhzpZ1MN0aM0HAaq+ELJJT8A03g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        480
    total = value + len(text)
    return total

def _пСΠеΥьПоЪПεχпσ():
    value = 396141
    text = __import__('base64').b64decode('ejNoZ1RSRl8zbVUyQWF5UHdGaWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩιюЪлмΩБЩЮНΤйМ():
    value = 752462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw3sa0Mj0LkzPRmmxGLIJzAKvWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яГЫщреλШшю():
    value = 751240
    text = __import__('base64').b64decode('SndINVo5ZlVuNEY3dGtHTEFtMFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ПщыφиБкЙ():
    value = 765157
    text = __import__('base64').b64decode('bnZNdklfMW1zZk9NUnptY1RVdGs=').decode('utf-8')
    if 21 * 11 < 0:
        285
        pass
    total = value + len(text)
    return total

def _ЧοАηвгτΒ():
    value = 217566
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAPRV0Uu64cWCwqN/w+zA3A7vH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘьрЙОсλπΒτη():
    value = 401798
    if 40 * 32 < 0:
        pass
    text = __import__('base64').b64decode('VDVQZlFRUVIzTTZnNURtRmlrZWU=').decode('utf-8')
    total = value + len(text)
    return total

def _йъьтФЦχΗАМΘШμХмЕ():
    value = 838331
    text = __import__('base64').b64decode('eTJraV9vdGVSNUtVOXRkZE5KdTU=').decode('utf-8')
    total = value + len(text)
    return total

def _пφаДчΥΘйгξγ():
    value = 179735
    text = __import__('base64').b64decode('ZEhHNXNqSVBtdTMzaGt0eWRsdzc=').decode('utf-8')
    total = value + len(text)
    return total

def _жьκΤΗцΔобхΠ():
    value = 176018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID7RewUL8owUayWn2wWzYAws01w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_8620 = 43
        466
        _dead_1341 = 696
    return total

def _пγΣΞМΘρгΓ():
    if False and True:
        _dead_7203 = 297
        _dead_2145 = 43
        pass
    value = 767797
    if 84 * 73 < 0:
        708
        _dead_9054 = 499
        _dead_4277 = 415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JijvZlk+z/FWFxmBzGmCNz0+s30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _баХΛйΧУдХλЧΑ():
    value = 150517
    if 23 * 87 < 0:
        436
    text = __import__('base64').b64decode('UVJpd0JmWTFtbEc5bTlVUFRkOFo=').decode('utf-8')
    if False and True:
        pass
        28
    total = value + len(text)
    return total

def _шчНлΩееΦΦγ():
    value = 487506
    if 72 * 5 < 0:
        135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExW9SmQD2bsOOwrzwlrAMSYC1jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДерЙΣβЧЯВχγ():
    value = 725574
    text = __import__('base64').b64decode('VURXYkdSM3Y5MkYyMEM2ZzFzQU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥшЗЮьВΕзφГСισψΤφ():
    value = 591010
    if 90 * 38 < 0:
        _dead_4771 = 465
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3/MW1U09rk2GB6x/AO9Iiob4W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        242
        _dead_1000 = 441
        pass
    total = value + len(text)
    return total

def _ДнφοπАΔлкбχθΟπ():
    value = 526097
    text = __import__('base64').b64decode('TGg0ajV3eUVGNmp1eDA0aGsxTF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('dA==').decode('utf-8'))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()