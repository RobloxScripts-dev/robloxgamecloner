#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΜθГумнмиΣЧμ():
    value = 388167
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQC1QW4v0r8AEii0+XWZCy98yms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΡьКНЕНШΔОγΟΗψбГ():
    value = 72573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQPiSgY2x4JRLj+0z3PEDhEbt2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фηαΜЦЧχяαцТδμβМΕ():
    value = 146228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBzca1oq7JgZaxqt91SHEBd902o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        771
    return total

def _АоЪъюИошД():
    value = 989830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LArjT1cU7Z06Lwaow3K1ExYj/T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΩΚζлΨЙιзσΖыКΔ():
    value = 342026
    text = __import__('base64').b64decode('QkJxNXZqSEFDNUxlcFhXa2JUNXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΘЛΟхψуДЧΡдьобψ():
    value = 484191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCPnamMdq/FXHFyt8HO2ZgkJwkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΖЯЙΧзΘξ():
    if 17 * 61 < 0:
        _dead_2896 = 606
        499
    value = 771376
    if 39 * 43 < 0:
        939
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByqxNmkN9KciFy7zkEyoAjQh7mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        636
        _dead_3022 = 105
        851
    return total

def _АшΜмИΤΠρθΗвξщ():
    value = 3344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn3ee2UvpqwyGFeExVXCDRQf3F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2676 = 710
    return total

def _ВзЯΟΝПЫΓбВΡ():
    value = 962981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCDhelYR/ZxXMAKizwOIZj8G9UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МБьηЯЪΔςЖюкпΖи():
    value = 433823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCCwZ0EApoQtDD23xEOUZAY681Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6727 = 961
    total = value + len(text)
    return total

def _λψτΝΚδНЕ():
    value = 553595
    text = __import__('base64').b64decode('RUhocDlyRnh4RFVSNmZrRlVyNmc=').decode('utf-8')
    total = value + len(text)
    return total

def _БЮπМρрΙδУΩз():
    value = 530451
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCLeS14SqKoLHj2k+FG/IDEHymg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 61 < 0:
        _dead_5590 = 321
    total = value + len(text)
    if len('') > 0:
        814
        653
    return total

def _фςЭЧЙпγαΜΦяШ():
    if 72 * 3 < 0:
        _dead_2368 = 26
    value = 929723
    text = __import__('base64').b64decode('bWd3dVA0YVlxYmtCcGNpcmZPbHk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _АΣЖπΡЧΙй():
    value = 733290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCnmYGM/z4IrEACinQSYISYu9Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 35 * 59 < 0:
        _dead_8854 = 234
        pass
        pass
    return total

def _ЖпΓщСωОэшγΞ():
    value = 688580
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KATvPgkr6IsiAxfw/l2BFnZ7t3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _οеЖпжςлвΞ():
    value = 303915
    text = __import__('base64').b64decode('bDVBbzlxVmwwWkxrRUd6SExISVo=').decode('utf-8')
    total = value + len(text)
    return total

def _βψδЩцρМЩθμьУνЛф():
    if False and True:
        366
    value = 131673
    text = __import__('base64').b64decode('YjRCakVsQVJndWFvOGpRTE9fZmU=').decode('utf-8')
    if False and True:
        _dead_4789 = 367
        460
        _dead_3010 = 745
    total = value + len(text)
    return total

def _νΗΕκЩЩКЫчπг():
    value = 971420
    text = __import__('base64').b64decode('YW1ueXlyUWE2X0VIZGpWQlpoWGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΞΦζзеЩΨαΨЮцθΘыΠ():
    value = 159117
    if len('') > 0:
        _dead_7112 = 439
        pass
        _dead_1441 = 281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LybKZlor7/wnPyKa92aVYD9+7D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬнχиДΕвνбεαНШΒδ():
    value = 300119
    text = __import__('base64').b64decode('Uk13M05hVnRiaDNNNUMxVFlKZ3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _аБβЧжρеΑΣΠЦЗοΖ():
    value = 588474
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHfJQmQ+87kHOV2Ox1DEGHIIslw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟψЧνιлΕжΕσЕΘΖцεЫ():
    value = 168528
    text = __import__('base64').b64decode('ZEJtZlJqajRFN3JCSFl5a2dVbTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ηжДΤνГαΤчмиΔ():
    value = 55831
    if 4 * 100 < 0:
        785
        _dead_8532 = 122
        pass
    text = __import__('base64').b64decode('a29HazlraTNwWlBreGJ1SEd4NEw=').decode('utf-8')
    if len('') > 0:
        _dead_9437 = 438
    total = value + len(text)
    return total

def _ЖζВΡИСМПΕΤМО():
    value = 536556
    if len('') > 0:
        _dead_1064 = 894
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng7OYlNv3Yo1Hjur2Q+5GxEk3kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 55 < 0:
        pass
        2
        713
    total = value + len(text)
    return total

def _зБкΤΝψΚХοατъ():
    value = 722434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBjbXEkNqawGKi2tmkaWGjAt02M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бФвγΧУЯчΩΒт():
    value = 13094
    text = __import__('base64').b64decode('b2RCdEx4TUFKS25TZmxVUmpLREk=').decode('utf-8')
    if len('') > 0:
        _dead_6156 = 58
    total = value + len(text)
    return total

def _ΛЧεфУЩехΠ():
    value = 230109
    text = __import__('base64').b64decode('eVhGY2pzbExrMHQ4RGhDQVY5OWw=').decode('utf-8')
    total = value + len(text)
    return total

def _юЧυΩРЙΞрιΧТрη():
    value = 701247
    text = __import__('base64').b64decode('dzI4TGJfczlpb0YyOXFTOVBMVW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ВчΔВλΗдЫП():
    value = 141533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx/LQ2EX571bPwCS7QexPnEb7lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТбψФβΕуΚΧΑ():
    if len('') > 0:
        _dead_9892 = 559
    value = 647710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSTzXnRp0flTYzr72lKhPis1ymg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        551
    return total

def _ΔмэвМоЦФЯΟгЩЦΧ():
    value = 448118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQTiakMx1I08EQqkx2OhGhAN1Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РвъαвКРΝφчΝσΚΟЩу():
    value = 518433
    text = __import__('base64').b64decode('bVJqUGU5MW5VYmdjTmpZRUVGRHk=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    if 5 * 73 < 0:
        441
        _dead_4796 = 578
        pass
    return total

def _ЗπΔθДаεсρυчиУΤΧ():
    value = 893971
    if 5 * 74 < 0:
        227
        98
        _dead_5924 = 918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz60PEE8/J0oOVmP3US2Dip4wWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τяΘЮыЙзоиξπ():
    if False and True:
        pass
    value = 826823
    if 42 * 80 < 0:
        191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BifcWXkSx7hXFS6xwAWcLjIN9ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5764 = 436
    return total

def _ОθτιЮдЭΧι():
    value = 865687
    text = __import__('base64').b64decode('cE15NUtyS3ZjY0JFNFFqVXJFUm4=').decode('utf-8')
    if False and True:
        438
        pass
    total = value + len(text)
    return total

def _фτδЧЛτпΝβйдοьΙД():
    value = 758923
    text = __import__('base64').b64decode('ZEdnc1kwalpKTFNBUDllV0JtNXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΤΒъΣъΗУΦфЯЩуΛζ():
    value = 520361
    if False and True:
        880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASnJbX848o8COQua3mGDAy8E1Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4119 = 393
        871
    total = value + len(text)
    return total

def _σпжгΙωΟτщΤ():
    value = 721387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx/qQ38y1b8UHAeP7G+nYzUot3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        901
        662
    total = value + len(text)
    return total

def _ΥΔщЭστЖδ():
    value = 916545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX3KPkgt+4Y3CQeV7lyUFi8at2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7775 = 603
        80
    total = value + len(text)
    return total

def _ъаαГйεЦиθЦ():
    value = 849120
    text = __import__('base64').b64decode('VlBoTGppSEhwaDJHU0N1U3Q2Vkk=').decode('utf-8')
    if False and True:
        pass
        _dead_2708 = 830
    total = value + len(text)
    return total

def _ЙζοΤЦΩОфвΩСλ():
    value = 784695
    if len('') > 0:
        _dead_9394 = 690
    text = __import__('base64').b64decode('QjFtaWRoeDZyaFpqM3hUYXlpUDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΝтрΑеъЩяΚΘτШ():
    value = 891995
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwnbeXIg8PgqPCWx4XK2ESo183w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝГξΟбμλЛрйβЮ():
    value = 884932
    text = __import__('base64').b64decode('ck5FY25VSHh5a0J3Y1hUSVFhT1c=').decode('utf-8')
    total = value + len(text)
    return total

def _λαΝцζΛтАΤ():
    value = 435744
    text = __import__('base64').b64decode('cnlSWUFkaG9mZGJxQTRfWTNXQ0c=').decode('utf-8')
    total = value + len(text)
    return total

def _фыЧмЩсξφ():
    value = 367017
    text = __import__('base64').b64decode('WGF4UzFLM1ZzWWpJVkFBQjE5VWg=').decode('utf-8')
    total = value + len(text)
    return total

def _υΠβΡЙнΦЛШυΥΗжлва():
    if False and True:
        941
    value = 987845
    if 62 * 50 < 0:
        773
        _dead_4550 = 448
    text = __import__('base64').b64decode('Undhb2pfWG1uMGxWQVV2S3VXZnM=').decode('utf-8')
    if False and True:
        _dead_2043 = 179
    total = value + len(text)
    return total

def _ВΨоЩмчтХ():
    value = 160667
    if False and True:
        pass
    text = __import__('base64').b64decode('ZDR6RXFlc0kwcW5yQ0ppa3d3UHg=').decode('utf-8')
    total = value + len(text)
    return total

def _δπΕЧеьΝΨξδАс():
    value = 226889
    text = __import__('base64').b64decode('ZktPOGE3QThYN0VIMkRjUTcwTGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΜжυθьждОЧмнΑΗЬπ():
    value = 409675
    text = __import__('base64').b64decode('enNaU2h0eHN4VjJ2aXoyekxfVzU=').decode('utf-8')
    if 61 * 18 < 0:
        pass
    total = value + len(text)
    if 23 * 64 < 0:
        pass
        pass
    return total

def _ЙмщΩаДНПβλ():
    value = 992652
    text = __import__('base64').b64decode('aURYRUtrRDFnTUtTN0NrWFdsdXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ИαЬξσТхΔ():
    value = 742613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQj+O1of6vEFIle05G+/ZXcj71E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 92 < 0:
        pass
        pass
        587
    return total

def _ВθмΨЛΨКХ():
    value = 709481
    text = __import__('base64').b64decode('QXVjV2RvWFRvbzk5WF94MVhGcGY=').decode('utf-8')
    total = value + len(text)
    return total

def _стЫΘρлунΡФй():
    value = 50091
    if False and True:
        824
        507
    text = __import__('base64').b64decode('a1owMmJFNDdCbmFwUzJFUFd3R2Y=').decode('utf-8')
    total = value + len(text)
    if 42 * 14 < 0:
        pass
    return total

def _οαΡПθπΘЗΩΓкуЧг():
    if False and True:
        201
        pass
        294
    value = 866822
    if 46 * 26 < 0:
        _dead_9538 = 134
    text = __import__('base64').b64decode('cE56Ymc5TTNndzRDZEp4TEo2Z0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΦπΓеуНлщвσниАем():
    if 100 * 14 < 0:
        pass
        pass
        pass
    value = 989193
    text = __import__('base64').b64decode('UFdEandkcV9xR3VmMk9mbGRnMUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔιФнΞсЕΞВΙЫΤ():
    value = 636701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS6yRwky5JsGHV6HkF+kEREfyXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓЯЫΥυХШθл():
    if 100 * 59 < 0:
        pass
    value = 789255
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQ3uXVMJ9/BXMBe7nHWkNxoE4TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤИμыСкιНуυ():
    value = 735558
    text = __import__('base64').b64decode('Q1oxYl84bE00RnlzQVd6NXRlNDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ζσφКηρНΑК():
    value = 981923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBCxY1AM765SbQWlnw+1HXci6nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βИοтρΦшΝМЮΟ():
    value = 655059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgjyVlgY0owNPD2S5Wy6bS9+41o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪРУоΤСрМ():
    value = 544201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgnOeXs60IUHawySm1WcPAoX0Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        945
        992
    return total

def _ФШжаСιΔфЖЙΠРДЩ():
    value = 399570
    text = __import__('base64').b64decode('UkVyVkk0cDExazA1dmhHYW9vM0E=').decode('utf-8')
    total = value + len(text)
    return total

def _аΥςНщξщщκТλх():
    value = 436256
    if len('') > 0:
        pass
        259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cgn1Sldg5odQbTiM+ASXHgEM1EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 16 < 0:
        _dead_1264 = 888
        636
        _dead_4314 = 112
    total = value + len(text)
    return total

def _ъйНьυπыΨЮЯΘАыЧοΝ():
    value = 625605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQSwP3Jgy/AqFSWKmFC4IXUL8Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪЧδФδΗшбмβωх():
    value = 967300
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXfnTHgQ/4crNQyR7w6CCzUZ4Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        563
    return total

def _ЯαшΘгЗЦΩуΟβ():
    if False and True:
        _dead_5550 = 603
        _dead_4678 = 58
    value = 462080
    text = __import__('base64').b64decode('ZlhrMmJyNjVLUDhCUms1VUVuSkc=').decode('utf-8')
    if False and True:
        633
        _dead_2652 = 703
    total = value + len(text)
    return total

def _ΞцЭευηуЖΩωЦО():
    value = 454461
    if False and True:
        458
        183
        pass
    text = __import__('base64').b64decode('T0YyQkx3eGNKdHNZMnhtVzZpQVM=').decode('utf-8')
    total = value + len(text)
    if 11 * 10 < 0:
        pass
        _dead_4082 = 111
        132
    return total

def _ΘЛεχЫщΧωкЫбαΚΕ():
    value = 4662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjrKR25q3KBUOyC30AGCExEp9lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9491 = 316
        _dead_7051 = 903
        919
    total = value + len(text)
    return total

def _ЗьуΡγΟиΘΧΧΦщΙъ():
    value = 278420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lw7ibGgK6JI0Ch6H4EehYgYr3n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        538
    total = value + len(text)
    return total

def _аΛΓмκНΞЬφΠΟРъ():
    value = 866915
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('ZkpPUlRfRzJRVk5yYUJ4c2QyRDY=').decode('utf-8')
    total = value + len(text)
    return total

def _вфΗιюпβурф():
    value = 908784
    text = __import__('base64').b64decode('WWhYVWpkbk81WDB5MW50dVN6WFA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6413 = 601
        pass
    return total

def _ΛыфσνλχЪ():
    value = 373965
    if 98 * 38 < 0:
        pass
        _dead_3561 = 646
        pass
    text = __import__('base64').b64decode('b2RJazFLSjRhX1NwSkNKWFkxZVA=').decode('utf-8')
    if len('') > 0:
        55
    total = value + len(text)
    return total

def _αΦγжΕМШкΟЙФлЖΩГ():
    value = 167181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwTFdgcxzLgFAz2z62mmJTM53ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΚиаюυщΥЭщгДюхАЫ():
    value = 521797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FizpRWkXzfoAaSqM8l6ABXEJ1kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨяΞиλЭЬИЮиЪ():
    value = 191809
    text = __import__('base64').b64decode('ZnUyY0J4d3lURzF5aE80UHVUNzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕУβХΖφфΞеιζΩλЦу():
    value = 540391
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR/RTAI4/aBRMDqgxVKEYA0g20o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВρГзжпΕΩЮ():
    value = 164959
    text = __import__('base64').b64decode('eHBaWDlBOU1FcHVweGZUQ2JUYmc=').decode('utf-8')
    total = value + len(text)
    return total

def _Ωюсφφξχνιл():
    value = 112867
    text = __import__('base64').b64decode('R3FNckFyOFRDOW81ZDdCUGUyc0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ГСκЫюГβΠу():
    value = 401322
    text = __import__('base64').b64decode('cVc4b2ZQM2cyT2swZ0dkaHIyQWU=').decode('utf-8')
    if len('') > 0:
        _dead_6832 = 976
    total = value + len(text)
    if False and True:
        879
        _dead_9511 = 719
        pass
    return total

def _νИЭξКΚφДиСЧωЖУм():
    value = 254021
    text = __import__('base64').b64decode('Y3NHb1Q4Rk9MeENfMURwY0R1VUM=').decode('utf-8')
    total = value + len(text)
    return total

def _зпψκБЗцНЩΜЙλκЖΝС():
    value = 29035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDfsekQbr/syCw2i63KcGRQhzj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8543 = 431
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_5412 = 417
        _dead_9354 = 117
        _dead_1986 = 663
    return total

def _ΔΩбЕΧхЯυхШΠγμ():
    if len('') > 0:
        _dead_5535 = 116
    value = 567976
    if 46 * 58 < 0:
        pass
        pass
        _dead_1218 = 689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgzpQUgorL8wMCKa23eJIzI7428='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6498 = 857
    return total

def _АСъΥчΓгацРКογψхИ():
    value = 72383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTXBRnYzy78JaSKqnleEPxM+0Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        962
        _dead_7456 = 926
    total = value + len(text)
    return total

def _ΦЮГΠЬβуΝ():
    value = 521262
    text = __import__('base64').b64decode('YmJDVzRyVzhzcHJPVTRSSzVxTUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΓдЫЩχΔБвΑЦЯп():
    value = 553958
    text = __import__('base64').b64decode('VDIza3hGRVEzSTA2Ym56RGRXeGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛъΜфэшнв():
    value = 169663
    if 73 * 18 < 0:
        _dead_7466 = 948
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRnyQHc3xIQnDlim2nSvZj8W71s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦυΔΑυνККоЖσк():
    value = 671398
    text = __import__('base64').b64decode('YWRkSlRYcUQ3U0h0VWI3cURpZGo=').decode('utf-8')
    total = value + len(text)
    return total

def _УβΠьсПфβ():
    value = 383994
    text = __import__('base64').b64decode('bHkxX28xSkNfSGRkb2dSM2ZQU04=').decode('utf-8')
    total = value + len(text)
    return total

def _эνГЭτБεΧΑΨΤ():
    value = 512141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhv0fFw+x70VAF73ylimM3QD1Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9039 = 651
    return total

def _ФΨΡяΖчΨΧαфΝцΨπ():
    value = 374566
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxnDewU/+bshawmK52WbYA498lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яМревНкЫΕθСЬК():
    value = 850397
    text = __import__('base64').b64decode('WksyMGxPdTlKN1hlR1lZb0ticlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦудοшОΥΠιщκΠχБΤ():
    value = 787254
    text = __import__('base64').b64decode('UllKZ3VTU09OOER1a0xiRzFhS2c=').decode('utf-8')
    total = value + len(text)
    if 62 * 96 < 0:
        _dead_8787 = 366
    return total

def _ΣΗпЦθЛξτοΑΒЛиπθ():
    value = 943264
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQvJP3sc+q0EMhmGxlmlZgYj5jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λъЯРγЮЛФЯνяЯЬ():
    if False and True:
        890
    value = 748153
    if len('') > 0:
        _dead_9866 = 787
    text = __import__('base64').b64decode('T3dDMGpGVmJHRnBFeE4yMXJ0cVU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5753 = 280
        _dead_8125 = 858
        pass
    return total

def _ΜρπуωΚωлμπ():
    if len('') > 0:
        _dead_7325 = 406
        pass
        _dead_9952 = 934
    value = 269020
    if 18 * 95 < 0:
        _dead_9441 = 7
        pass
        pass
    text = __import__('base64').b64decode('cU9XSzNjNTczRWh0akxYbEk5S3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪййЬДΓΒΩΣθЕтоα():
    if len('') > 0:
        196
        699
        112
    value = 857450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njr3XWYy1p40bxem3VK8HyE/wmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 27 < 0:
        640
        pass
        352
    return total

def _ΑωΔΩФбαячУФΧОШхе():
    value = 706095
    if 14 * 27 < 0:
        _dead_2538 = 36
        pass
        pass
    text = __import__('base64').b64decode('TWNDOVpKVDJ6bDdFNVlDMFpuNlI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓφΔΘФПиΝИГмψЗъ():
    value = 78657
    text = __import__('base64').b64decode('blBGSFc1RExEVHZRMDBJdW1BZ04=').decode('utf-8')
    if 1 * 19 < 0:
        843
        445
    total = value + len(text)
    if 92 * 23 < 0:
        _dead_5602 = 699
    return total

def _χпλРιцнΟв():
    value = 239400
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhbwPlo2rbkFKzyq60GkBjML8kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _члПГΩЖτААΩзг():
    value = 511152
    text = __import__('base64').b64decode('a25ZTkxTQ3hkU3NHdkFTbGRJV20=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4544 = 745
        421
    return total

def _жнΤтΧбΡθΩШЙм():
    if len('') > 0:
        857
        _dead_2590 = 190
    value = 895145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQm3SEdt/bgnKl7ykGWvPAAGszs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩшвгΖΞΔШζЮяп():
    value = 998500
    text = __import__('base64').b64decode('YXZ1Q1RDelY1aVYyN0xGMWw4azk=').decode('utf-8')
    if 90 * 71 < 0:
        _dead_7835 = 747
        469
        674
    total = value + len(text)
    return total

def _зσЦхσСъЦГБ():
    value = 667799
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSfmOUk386YEEDCqyQCzIXEu1GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пτПκьБВψРйЧΣΦΖр():
    value = 364030
    text = __import__('base64').b64decode('QV9aSlY3VVpZaVBPN3dfNnJDTlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘшзΦλωэя():
    if len('') > 0:
        _dead_4458 = 411
    value = 659680
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('TElIbTdXMllveWJKMmhuRlcySjM=').decode('utf-8')
    if False and True:
        pass
        _dead_4670 = 14
        286
    total = value + len(text)
    return total

def _ωιΗΖСξеςЛΗфξ():
    value = 606470
    text = __import__('base64').b64decode('clR1TmNMc1VaQ1R4Q2FxMzJuQ0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙеЦКΤΠυжАщΩι():
    if 15 * 92 < 0:
        _dead_2430 = 533
    value = 11838
    text = __import__('base64').b64decode('VURaaXNZQXJTOEhUdXZXemFqcTE=').decode('utf-8')
    if 50 * 30 < 0:
        _dead_7992 = 74
    total = value + len(text)
    return total

def _ЧСжЗιςΟТΘυΞμ():
    value = 300509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cg2zOmAa6IsaDjCckV+dHzY1yHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юОаЙзφΙγТкаΧ():
    if len('') > 0:
        715
        pass
    value = 914511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgvpdF8+rYkNHD6qzHSpInI64js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩяΩΩфьйЧЯя():
    value = 11328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axn9OVsOrLsKFQ2x/me3Fz8fvWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аПΒгЖθΙтЛь():
    value = 730841
    text = __import__('base64').b64decode('ZF95ZWFZcGNPNnhyMjNxSjJPMEs=').decode('utf-8')
    total = value + len(text)
    return total

def _АТЬЦΨКΩзТ():
    value = 10286
    text = __import__('base64').b64decode('emZ6aEU0V2VaYVByN2tJdVA2dkc=').decode('utf-8')
    total = value + len(text)
    return total

def _юйΦтыΡрЮΓЦγΑΡьы():
    value = 473631
    if 31 * 57 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzbnXwgX+fEaM1uZ+EOXPQQ462g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 90 * 7 < 0:
        pass
    return total

def _кΩБΧмэкк():
    value = 551326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axb9aHs6zbsvO1ao/nWvZih6wXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _еаСхЧрИЪядцδ():
    value = 855862
    text = __import__('base64').b64decode('cFlScElMaG5SR1lfdDh5V0wzY3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _СλтбκΙыΦ():
    value = 542982
    text = __import__('base64').b64decode('QUNKTklSUEVoRlZmUzZNU1MwalQ=').decode('utf-8')
    total = value + len(text)
    return total

def _δΝхжАςэШδ():
    value = 571543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDrGN0QVxoYoICywm0eFIHQLz0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑОЭψθКεРς():
    value = 847999
    text = __import__('base64').b64decode('YTJYWDJwT2F4c3dzZ2ZWVHAzQUU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        389
        601
    return total

def _пαξЧζΙВβΤΨЯР():
    if 5 * 54 < 0:
        pass
        162
        pass
    value = 152303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSrSVgkB6IUXHjiR62SYOgA34kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8711 = 610
    return total

def _πпθПΠвςлфзιРф():
    value = 375354
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQOzamcx9PslLwGWn3OjPiQMtEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΨжЭтчСА():
    value = 217549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAu3aWMOwf4xHxmZxWGKHS4nyHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖεхΒгбсζЖΓтΓогеП():
    value = 455637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn3cTWkNqPsHIgOX3mzAHyMb43Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эИТЫЫΜнЙ():
    value = 971827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxrlXUYG2/wuEyOxmH+HARR870Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пОζξυАЬРЕЭБΖр():
    if False and True:
        _dead_1976 = 948
        _dead_6916 = 698
    value = 946756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCjianxv950pahauzlXBNg96yng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иτΘоΝъюЪβπЧψυьс():
    value = 898031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHqzVGYd15AXMA2F+1ikDQcmykk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓιдкЮОΕНО():
    if len('') > 0:
        _dead_4600 = 342
        pass
        519
    value = 605147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FD/se3Qa0YQzOyH1/3ekZTI17WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2149 = 191
    return total

def _υχЙφУШЙΥжЯΜΗ():
    value = 148061
    if 55 * 29 < 0:
        pass
    text = __import__('base64').b64decode('ajM3UzA2WFlwSWk4NXQ1V3E4dzY=').decode('utf-8')
    if 41 * 12 < 0:
        878
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΥΡΙΝыψхВΓΡΕгП():
    value = 238088
    text = __import__('base64').b64decode('SWtvMFgycGxNZTB6VHBSeldQWlk=').decode('utf-8')
    total = value + len(text)
    return total

def _вΒфчнЪГб():
    value = 753637
    if False and True:
        836
        95
    text = __import__('base64').b64decode('UzVSWXhqbXRvYl96aUVoV1JjRDI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _юТВРΔЫςΙЛяπЙЙ():
    value = 354028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSXjVF80354MGFun+1GeOXQN/Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МποАΟгΚюоЭηЭЖ():
    value = 629585
    if len('') > 0:
        _dead_5766 = 368
        410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAvIe1Y/24cSECqP31vDECJ79jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 76 * 17 < 0:
        _dead_6600 = 532
        _dead_1165 = 987
        pass
    return total

def _шЩБДυщзГςкЦцПхыГ():
    value = 322525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwXAa2IS+IIHbwet8HPCGhQZwWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σЧомυКξδιΣЯсΥ():
    value = 435332
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQfpYVgO8akSMC2m43uZOiIY/Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮпчζбКФлλΧ():
    value = 12031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwXhbHYhy4YEbwKR3Q6fEXF8z18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΩβЦаΨΛΤαΕфиλаψ():
    if len('') > 0:
        pass
    value = 788778
    text = __import__('base64').b64decode('Q3AxaFFxWml1QnV1TUxrcFZnSTM=').decode('utf-8')
    total = value + len(text)
    return total

def _щктлСΕЦЩεΧЦуСσП():
    value = 79452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSq9XHNg97gsMCW1kFCDGBJ/zVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΟжДωКУΟвχωД():
    if 83 * 37 < 0:
        pass
        _dead_3836 = 481
    value = 602020
    text = __import__('base64').b64decode('TjNwbjZqNWtkcWpRMG94MW50WGM=').decode('utf-8')
    total = value + len(text)
    return total

def _яРΞγςΟηпζδядκх():
    value = 444372
    text = __import__('base64').b64decode('VkZJT2hQY3lUcGwxREZkUTRWYnU=').decode('utf-8')
    total = value + len(text)
    return total

def _οψΣРжьΩз():
    if False and True:
        82
        pass
    value = 742499
    text = __import__('base64').b64decode('R3BDQjk2cXFuSU53bnlvakY5b1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ъΙщясΡбλгΑЮДψАΗ():
    if 26 * 86 < 0:
        _dead_1754 = 246
    value = 870278
    text = __import__('base64').b64decode('R3dUczI2b0NDRkZhYmFfRzFVdU8=').decode('utf-8')
    total = value + len(text)
    if 55 * 83 < 0:
        pass
        pass
    return total

def _ΚещσаЩηПΔ():
    value = 982802
    text = __import__('base64').b64decode('SWszVE1vMHdRUlZfZk9xaDdKaVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕсМЦщИΩЩχНΣωДЪε():
    value = 75149
    text = __import__('base64').b64decode('Wlo0YUVTZHA5d3VLTzNNRldtOE8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        320
        pass
        869
    return total

def _χγΩчΛйФΦэЙ():
    if len('') > 0:
        _dead_5442 = 4
    value = 549284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz/xY1At7L9RGSug3FyaMyEczko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фдΙмцВΠθδΧΙП():
    value = 860340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDfLZVwO8a4mK1eh3w+nHnEu/Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξчгЛъΑΩγ():
    if len('') > 0:
        pass
    value = 454177
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ixj9Rm46xqwzCj+i+V6XAQQczUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ййТФЗфΧЬθЖаКςφ():
    value = 856037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Agjyb1A+rookKiiT+WG1PTMX/U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 20 * 46 < 0:
        _dead_1637 = 389
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_6977 = 935
    return total

def _нΕРлΔИрМЕЧθШ():
    value = 142347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA3PO2EX0rk1bRmrwXOCLTJ50Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дιςГΜяЬРΘьЮΜкЦ():
    value = 891797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB/vRldh+KUiLz/13XDBFgcfymU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςулЦМЯЙдЧυялςεцξ():
    value = 472409
    text = __import__('base64').b64decode('RnJabUxmTW91OW1tajIxaTJZMlA=').decode('utf-8')
    total = value + len(text)
    return total

def _шЕЗЕГЯПФΕ():
    value = 501680
    text = __import__('base64').b64decode('aEdUNlVwT3BEbGRsVWlJQmxHelM=').decode('utf-8')
    total = value + len(text)
    return total

def _τψужΝΣωΔч():
    value = 304668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwfjYGsGpoUBKzr24EKCEyp+wG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ФπιБΥρЧΞяййπζЧ():
    value = 372043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhXWXgE2zrwWH1eHm2GmNzwO8Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψδлиЮГЧΓЬΑΗЛ():
    value = 96370
    text = __import__('base64').b64decode('djNwUEdJcFc0dXdESjdtc3Z5bWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ηБмюЬΕгжφρсΙ():
    value = 459953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzXlT2Fv64ECFgGummexBjA/xTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХшЬЯθεΨЧαДΦ():
    value = 311407
    text = __import__('base64').b64decode('cmlIUTlQdUpUd0I5ejV0TXZKR3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЕΗΟλπτηтГΨΛ():
    value = 50467
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHncUXAYq4MZBTWrzkycBxMIz3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сδχΣаГιЖпКΣζκχьδ():
    value = 285937
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCnSS3Rp2bk2GTCq7ECEJykg9Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юЯИσΓрΕЬЫτΤщΩ():
    if 1 * 43 < 0:
        pass
    value = 872543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnzAa1ApzI87Fl2z+VeeJRc25kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φμΓжΩБПУаЖЯЯβЗη():
    value = 75382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA3HbAM4x6RSOC2OkV2XZzJ+zlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юυΠξΜыαЙΣΧλчΗЦΑг():
    value = 828953
    text = __import__('base64').b64decode('ejhMX2ZqZ0RLd2NkVUhhOFJJb0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣпΑуИЦЩθчρεуεйΣη():
    value = 76971
    if False and True:
        _dead_8843 = 899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQDmf3Me0qQRFiGyz1PCbHMm5Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        523
    total = value + len(text)
    if len('') > 0:
        447
        _dead_9300 = 866
        pass
    return total

def _ΟΡγτщθЦНσΤнτμοЬΛ():
    value = 485528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg7qPnIv2q4MEC6GxXCoPS8k7GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фкΖЛςРμΓхιψξ():
    value = 678528
    text = __import__('base64').b64decode('aFFodVhTdkVhTTBnbmRxRlhndE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ψйΘεТтЛπфΖωйЖ():
    value = 715222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzfFY2s2qp4uHhv2m2TBInAJymo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ибυдгУΖγУδИνΕ():
    value = 268186
    text = __import__('base64').b64decode('TG5xWWZ5MkZXY2dQRkpzSjVFMk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΙΓφюМьΨφюЮιπ():
    if 33 * 24 < 0:
        pass
        _dead_6723 = 460
    value = 326861
    text = __import__('base64').b64decode('VmxHcVZDQTcwNHM0bWRLb2wzOEY=').decode('utf-8')
    total = value + len(text)
    return total

def _жΗΖтЕГмΡ():
    value = 972203
    if 55 * 45 < 0:
        pass
        298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTzvT2NvppEJDQaU91qTNQl+/Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _дШПςγФΒжΧ():
    value = 41278
    text = __import__('base64').b64decode('VW9tMFZfaG5pM0NvbElkQUo5TzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('IA==').decode('utf-8'))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()