#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ЯΡртИΚδΘκзΔеΓгДΑ():
    value = 549363
    text = __import__('base64').b64decode('dHhQM3dqYm5sdXVxWnRfc0xIekk=').decode('utf-8')
    total = value + len(text)
    if 10 * 37 < 0:
        898
        pass
    return total

def _яЮгьΒνаΒ():
    value = 296305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Li3rOV4+yak6KCSHyVGzFgI+z3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1620 = 712
        pass
    total = value + len(text)
    return total

def _λιуΛКΞτщУα():
    value = 56212
    text = __import__('base64').b64decode('eFVZRXduYlluVFY1dVMxWWU5cUE=').decode('utf-8')
    total = value + len(text)
    return total

def _жхΗйУбЪχθыВοгр():
    value = 832897
    text = __import__('base64').b64decode('VlRxNnJEdWlXNVk3TkxmeUx2YXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ибэζεΒВΔ():
    value = 368186
    text = __import__('base64').b64decode('ZUQwY1JENkd0d1lFVHI5QjBNWGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЯγΨТюЛΦЭпГйБΓΥ():
    if 27 * 32 < 0:
        pass
        pass
        26
    value = 268812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED3UNkkPx6wiODaCnlGRODcCtWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 19 < 0:
        166
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _кЪрΚΝльСхрαΛЦдκ():
    value = 587468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ii3AaHwe8pAvHQGU+0ecGz9/5XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αцмкΖЪьЗВσΙЬИν():
    value = 787245
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lnu2PWhpqqwuFw2iwQOAGCwq3V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыξфкιуъчν():
    if False and True:
        pass
        _dead_1230 = 757
        971
    value = 92470
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('My61fEcJy5w2Cyjyyni4ARAt4zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЛχсαΜшρ():
    value = 602404
    if False and True:
        _dead_6273 = 641
        969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kz/9O0Yt1o8RIhuUwHPIbRYf6Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠαТΟдчнωΔГ():
    value = 473803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwizbUEA87E6Fxiaym+2ATU8xVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _маξСаιэπввЮцмЬδ():
    value = 538340
    if 32 * 56 < 0:
        pass
        _dead_3754 = 593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQ3gaXc0q44sGDysnwe8JCMFxjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        570
        pass
        pass
    return total

def _εΧΔιыβλСТΧЩМ():
    value = 942799
    if len('') > 0:
        _dead_3328 = 126
        pass
        _dead_6792 = 228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChbhWmUJqJwUDB/08H2bLAoNsmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ξНγχΥΣΖоОσ():
    if len('') > 0:
        pass
        416
        pass
    value = 623073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwPjSFAW1oYuaxmy9w+HbC0p5mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _μЙυМψΡνΒд():
    value = 723131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EC7XOkcLqb0pIz+E8V+fFhQj00g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6571 = 102
        866
        pass
    return total

def _сънкβξΑΕ():
    if False and True:
        _dead_7212 = 188
        _dead_5413 = 742
    value = 452000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAnITXUQzI4IMDiR4363AwAHxWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЕΦЙηьДДдΨЯΙΘэм():
    value = 610309
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhDee14z+6QuDV222US6ACY+5WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΛъзЯςЯчλгым():
    if 13 * 80 < 0:
        pass
        pass
        _dead_9654 = 117
    value = 984603
    text = __import__('base64').b64decode('cGRZV0VUTDlxN3pHQ05LTWEwU18=').decode('utf-8')
    if len('') > 0:
        986
        _dead_1519 = 103
        736
    total = value + len(text)
    return total

def _θчΧκпндςвνιΖ():
    value = 658526
    text = __import__('base64').b64decode('a0tIQngzZ1hDb1BvV0laenRaNVQ=').decode('utf-8')
    if False and True:
        964
        pass
        _dead_9633 = 566
    total = value + len(text)
    if 40 * 79 < 0:
        _dead_9259 = 308
        0
    return total

def _ΗΨЩγчτНЯΙдгΩΠжУр():
    value = 145349
    if len('') > 0:
        _dead_8570 = 417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCf+eGI78YknaAis3Xe/OwY51WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 7 * 75 < 0:
        _dead_3164 = 172
        pass
        799
    return total

def _ωдΔΨФМЫЦкьгНαЮ():
    value = 165145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwvCVloKxvoQMCmbkQW+Zjd+9E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑППЮЫξσьэ():
    value = 940232
    text = __import__('base64').b64decode('SHNrU3Vqc2ltM2lJQ3dyOWJ6UE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΗЖεЕкΠΝЬАэК():
    if 88 * 14 < 0:
        pass
    value = 399433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz7RT1trzpoQEhalkHe+DB0X9jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 24 < 0:
        _dead_3272 = 671
        155
        pass
    total = value + len(text)
    return total

def _υГнШΖρОьΜЬΛσЧψ():
    value = 264757
    if len('') > 0:
        pass
        _dead_5924 = 517
        262
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiTpRlMc6ZI6KR31n0exHB04wzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        424
        _dead_3938 = 368
        _dead_8702 = 116
    total = value + len(text)
    return total

def _ДЪЦсΞШШΛ():
    if 55 * 20 < 0:
        81
        _dead_8208 = 527
        pass
    value = 837183
    text = __import__('base64').b64decode('ZG1jMzZSR0hndDBQS1BiQks5eGk=').decode('utf-8')
    total = value + len(text)
    if 5 * 3 < 0:
        450
        141
    return total

def _ξΛΓпчяλхΓΠкб():
    if 47 * 20 < 0:
        504
        992
        527
    value = 56007
    text = __import__('base64').b64decode('VjU5eWlWZjNXWlFzOE8xb2xLM2o=').decode('utf-8')
    if 65 * 8 < 0:
        _dead_8157 = 473
        _dead_7406 = 922
    total = value + len(text)
    return total

def _фТΒУυΩСЛг():
    value = 851472
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESvAd0I/+ZI2BTeQ7g+1YB8twDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рГшжЗЙΑχжуТΤш():
    value = 836620
    text = __import__('base64').b64decode('aDg2MmJPbTB5TUFuVXVaZ3VFNkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _нγнΨлГαψΒхπЬЯΗз():
    value = 502446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSrSQFIhz7sHCiys+l+TLSwmwGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ужэжθРΓЮМюОΤ():
    value = 645707
    if 10 * 28 < 0:
        _dead_7308 = 507
        _dead_3875 = 344
        _dead_9545 = 46
    text = __import__('base64').b64decode('ZFBzVXpGX3dDY0dpMVdtdUlaemc=').decode('utf-8')
    if False and True:
        _dead_5773 = 585
        178
        pass
    total = value + len(text)
    return total

def _ΝЖнъАβУω():
    value = 61275
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz3HPUQv0JsbCymaw1SyGxI7vUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щκубпщмΝυЙу():
    value = 4450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBvnV3UByPBVPTWvznCqLTAHtU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σσрεξЙМΒгΟ():
    value = 97277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDj0V0IWxJdWaw6y8AXHMAYd5Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        597
    return total

def _ЪБчΧкгруφШΖθΜЭ():
    value = 319137
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('UHJzYU5xbTFoUld0UnJPY2xjSEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ТНξкЪилчιлЕюуЖ():
    if len('') > 0:
        956
        522
        550
    value = 635371
    text = __import__('base64').b64decode('WV92bDN0N3FYcEF4RHRmRU1iY1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ψрБмРХсцХчζσцЦν():
    value = 23892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTnBYGcx8Y4ZKQ6swn6gLgsss0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВнΣλзФбβΖχИΡςБЭА():
    value = 290043
    text = __import__('base64').b64decode('dXN5X3A3UnZzWm5OS3luVmxxamU=').decode('utf-8')
    total = value + len(text)
    return total

def _мρрОΨλЦеΣ():
    value = 917896
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBvTZVweraQbPAKIwQ6EbQ8p/UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛОγЦеъкЗΓФЖΒπΜ():
    value = 918399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D36yXUAf8qwbIx335F+UZzIO0z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΕκΝАЫРН():
    value = 896628
    text = __import__('base64').b64decode('UW94UkZaeFFWMlpTa1VSNHdmQ0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠьМгφЪσΡиЙ():
    if len('') > 0:
        pass
        399
        146
    value = 274717
    if 4 * 18 < 0:
        pass
        _dead_6735 = 908
        pass
    text = __import__('base64').b64decode('Z0lhWnVGWlpFb3o5R1QyZUlCY0o=').decode('utf-8')
    if False and True:
        _dead_8278 = 864
    total = value + len(text)
    return total

def _йувςЦзΣβЦЙ():
    value = 709101
    text = __import__('base64').b64decode('QzRmSm43WjF3cTFLazhGUERobFM=').decode('utf-8')
    total = value + len(text)
    return total

def _НαЫаΑξйЫμπуэ():
    value = 393276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aje0X31gyZoQGTy54XKYMBoBt2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юднΨκЗьЖΦ():
    value = 275385
    if False and True:
        pass
    text = __import__('base64').b64decode('U25aUnVRa3A4Y2NuNmFpbDA0VUo=').decode('utf-8')
    total = value + len(text)
    if 42 * 68 < 0:
        _dead_5282 = 268
        pass
        _dead_4356 = 471
    return total

def _вΘбзШαΞδΥΠ():
    value = 57775
    if len('') > 0:
        460
        90
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnbrRFcu34MZMTqG/mzFOw4Fymk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        360
    return total

def _ЖλдΛΓлЕЧЪпΖьЙвпΚ():
    if len('') > 0:
        pass
        643
        _dead_5470 = 757
    value = 968687
    text = __import__('base64').b64decode('cThhRE90ZzBJQmtqRUdjZnpDSTA=').decode('utf-8')
    total = value + len(text)
    if 69 * 4 < 0:
        _dead_1034 = 604
        647
        _dead_9227 = 156
    return total

def _θυыуσгΙЭΤΒξцЙΜσ():
    value = 602611
    if False and True:
        28
        _dead_6503 = 884
        pass
    text = __import__('base64').b64decode('VFlGQ3d3VEc0WlRUc2RlazlUY3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЖХθΓрЫпΦйΩТЭъκο():
    value = 599887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDjoT1Qf+akZMF25xky6OwMi6EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДжχΟυβΥΠУχλΑω():
    value = 722262
    text = __import__('base64').b64decode('VUdKQmlfckN1ZFpxeTBoTXNSS3U=').decode('utf-8')
    if 61 * 50 < 0:
        714
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ОлΙΘηαяΧвж():
    value = 180191
    text = __import__('base64').b64decode('S1dBQ0l6U29tQTZnbjZwa2JVdjc=').decode('utf-8')
    total = value + len(text)
    return total

def _μΔΔичцшЭΞБ():
    value = 431048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cyb1S3Yc36AgLRaX8HjBBwsI51w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        106
    total = value + len(text)
    return total

def _λкРЮУУацΚ():
    value = 332132
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxW9bVQxyKARYgKswWK+ICwr42E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟуρРхТνχн():
    if 51 * 89 < 0:
        74
        pass
    value = 908680
    text = __import__('base64').b64decode('VFpScWpOdmk5VkQxZUxmV0x3QlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦВМСιΙνπНЗы():
    value = 931486
    text = __import__('base64').b64decode('cnZVWnhKRXBfcEhwTjJIUHJaNzU=').decode('utf-8')
    total = value + len(text)
    return total

def _гλЧЙφФηИΨрΝЛΣУ():
    value = 801567
    text = __import__('base64').b64decode('clRsdjRWOTJEaHNoRUY5b1FfZkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЛцπΦЩЧЮΥЧСЮиΚ():
    value = 588722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ij/LRmlvq4wKG1ibn1zFM3Md4lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВБφЭЬруЬ():
    if False and True:
        _dead_6242 = 502
        703
        765
    value = 66968
    if len('') > 0:
        _dead_7142 = 842
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CijCXwkUqKU1NxyU+wO6IyAssXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        337
    total = value + len(text)
    if False and True:
        pass
    return total

def _ТоОйщΙεсжαвДω():
    value = 141273
    text = __import__('base64').b64decode('S1VSMnFVQW1HU0diblhKUVVXMkk=').decode('utf-8')
    if len('') > 0:
        751
        _dead_7804 = 839
        _dead_5837 = 115
    total = value + len(text)
    return total

def _экΟΦμψкΥаΑψΑирΟ():
    if False and True:
        pass
    value = 46278
    text = __import__('base64').b64decode('VkhoV3F2X2pKU3hVNUlERGgxdEY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8989 = 242
        57
    return total

def _пΑЦЫдшΧΥтЦφιΤузэ():
    value = 10599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH7sQkMsrPksGSqv5gfBMxI64FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜТБυИΝΚыРιгμ():
    value = 878086
    text = __import__('base64').b64decode('R1d0QzN3SmlpR05vRmdPOHRDVGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ъΕйЮΥΠЛщΤзЗЩРΚ():
    value = 812085
    text = __import__('base64').b64decode('QlRLTERETkJjTTRnbVJ5eUxyaGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΧΑΤуИеπВИΜΠθХ():
    value = 914971
    text = __import__('base64').b64decode('R2tiSlMzVmJmMlRSSk9ONWdyRGc=').decode('utf-8')
    total = value + len(text)
    return total

def _пΛηΥвιПγЦлνэΕ():
    if len('') > 0:
        _dead_6805 = 145
        pass
    value = 479677
    if 75 * 70 < 0:
        _dead_7391 = 435
    text = __import__('base64').b64decode('Y2VTdTdTenoxM0x4S0p1OXlmSUQ=').decode('utf-8')
    if 63 * 77 < 0:
        pass
        _dead_2636 = 894
    total = value + len(text)
    return total

def _πъВψсяыЧ():
    value = 467501
    text = __import__('base64').b64decode('RUdtNWplRDBVcDdQN0VtY3ZzN0k=').decode('utf-8')
    total = value + len(text)
    if 45 * 11 < 0:
        _dead_7900 = 193
    return total

def _ΜЩЭξРβпжу():
    value = 796762
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiLieGE2zaUGFCHznGGDARQ64kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        123
    return total

def _нАСΚΠжЛФеΩЫΡЭЩα():
    if len('') > 0:
        pass
        _dead_7024 = 556
        _dead_9147 = 792
    value = 44270
    text = __import__('base64').b64decode('S0JpdktVb29ENzJodjB5eldHQko=').decode('utf-8')
    total = value + len(text)
    return total

def _ξбΗЯбΛыХ():
    value = 882414
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA63bEgR86Q2Nxv35AWIBR0etEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΒПπγλйφУ():
    if 49 * 9 < 0:
        791
    value = 218216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3/ua3Qz9JkgCg2Z+g6pI3ci4z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кТσσΝΠυИλДβΧΦψσλ():
    value = 502775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDvcZEE075s0bxWw432BOHEbz1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΞωИαΠмλЫΜ():
    if 45 * 54 < 0:
        308
    value = 711065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fj/gSGcY5o8MYlaLwnyqIwsA7Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΓмкΦъΝωмЛЪΖРщ():
    value = 170153
    text = __import__('base64').b64decode('ZHZiX1VDOTVZdWdUOWljMmhzMU4=').decode('utf-8')
    total = value + len(text)
    return total

def _фοςвЧγЪζπρ():
    value = 120878
    text = __import__('base64').b64decode('TFhfeWFwZkMzTG5EVXpWSWNxY1k=').decode('utf-8')
    total = value + len(text)
    return total

def _хΞΙΜоКеШηξ():
    value = 407771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQTefGU2qP4sHC6n2Fm9DBJ7tnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝнΕΖεфщЦ():
    value = 583072
    if False and True:
        920
    text = __import__('base64').b64decode('bHlpS3V5Rkdua0tyQlVRdVpJYm8=').decode('utf-8')
    total = value + len(text)
    return total

def _тΟщΝΨяЖφΔбΓξαΛοГ():
    value = 803333
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3ewTWAj/aIQEyC6n06pEQx2yn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _збХнΦχθы():
    value = 194892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA7qZUAY1IolDgSH51rDZyh79jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λлδьΗгЪζХχЯαл():
    if len('') > 0:
        484
        _dead_4639 = 246
        pass
    value = 828549
    text = __import__('base64').b64decode('Vkdkb0hIanJ0VXBNcjFGUGR0NjI=').decode('utf-8')
    total = value + len(text)
    return total

def _аΔбλΛΗэΑСΝςю():
    if len('') > 0:
        _dead_7901 = 652
    value = 960493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACnwN1cc+J1UHSGV7lGCHjN991k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςЕсΗбПЛхщλβвК():
    value = 210326
    text = __import__('base64').b64decode('TF9KVnRQS1VBdXR0R283a2cwNHA=').decode('utf-8')
    total = value + len(text)
    return total

def _нЭΒЪнжβορЗовεъς():
    value = 697178
    if len('') > 0:
        923
    text = __import__('base64').b64decode('d1NGOFZlTmc1aWdJRElRc2lOS2Q=').decode('utf-8')
    if 43 * 79 < 0:
        pass
        844
    total = value + len(text)
    return total

def _еьрЦЭΝЪк():
    value = 568246
    text = __import__('base64').b64decode('WmJOV3J0VGZ1S1RHUk1uNVRSZTA=').decode('utf-8')
    total = value + len(text)
    return total

def _аηДеЩΞαΘ():
    value = 857199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCbxPFA084AJMymnxmyGJxw+sWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΦΩнРЪюδЯГΓΝ():
    value = 981278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EH/rWVAKxqswMSKx8QWvYSAf/Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 40 * 13 < 0:
        pass
    return total

def _уρξбΤшЫζЧεЛπ():
    value = 501634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTfPZFo3qvsFAAG22XGUHz0r6Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΗпКЧΧκι():
    if len('') > 0:
        346
        _dead_2023 = 617
    value = 75195
    if 10 * 98 < 0:
        _dead_5605 = 633
    text = __import__('base64').b64decode('YUtMRUFJb1VHREZkaGZNdGk0RnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕтρЙЗЮИыιΙΛТЩΤΧ():
    value = 954606
    text = __import__('base64').b64decode('bjNxSUNMaE90NmZFR0Yyd2NTUjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ζеюцΙтΩЪΟЖΚрΩγγ():
    value = 378285
    text = __import__('base64').b64decode('Q2J6Z0hNeFJPckdGVHNGbkFrd0s=').decode('utf-8')
    total = value + len(text)
    return total

def _жпрανъоз():
    value = 397307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgjgWlg36rssDzen70CbHSkQ02c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 84 * 29 < 0:
        628
    total = value + len(text)
    return total

def _тΨзυγлυуиъзФμлГ():
    value = 175122
    text = __import__('base64').b64decode('c001QUN5dDJqakV5am5LYjdJU3Y=').decode('utf-8')
    if False and True:
        pass
        _dead_6834 = 829
        pass
    total = value + len(text)
    return total

def _ΗнзВΞδδТ():
    value = 310990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwXcYHMh6rI5NQya7WnFLjArwEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        28
        _dead_7643 = 498
        569
    return total

def _хаыοмЪЭΓЭφЮΠ():
    value = 15395
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR/HOWM1q7AgFx60nHuSLg096j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λλЛψΤПΟу():
    if 46 * 79 < 0:
        pass
        753
    value = 34869
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('TWFDX1N2cjVQYUNaOTdldTRKd00=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _пеξьчΨяАγπАПс():
    if False and True:
        161
    value = 654900
    text = __import__('base64').b64decode('dGduV1Z6eWJ6TkdEbnRYNHl1VmU=').decode('utf-8')
    if 32 * 37 < 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_9023 = 365
        771
        987
    return total

def _лηРΑдΞАΥНΧυβчОНο():
    value = 275427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBjTVn09/Kk7KB6P5gOlPXUM4Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        905
        pass
    total = value + len(text)
    return total

def _ИμΝфЬджΞИНц():
    value = 324008
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTbQYHMtq6YuAyG62XSROQl80Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝζεщΣНοΖΠΩγечя():
    if 7 * 91 < 0:
        928
    value = 772988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iyz0dms8zocAbg2AzGKXGXY+s0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыФΧΦЙуЛжтЧТЧ():
    value = 468592
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyDGP2McqoQEEyHz61CSZHcGvDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡπξЮβАΧЪМПщеΥσз():
    value = 454183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mhu8VmNo5L8lAFaT6lKDISMq7D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4697 = 38
    total = value + len(text)
    return total

def _ςдНΛБπΔΘΣЪЭнНЧС():
    value = 50554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgLXQnIhzoEvAz+nmHi5ZxN2wEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οшдξΜШΒуΖдтбм():
    value = 898156
    text = __import__('base64').b64decode('SUI1WUFucDlHTExUSjNTWGRlYTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ωυуΧτЦУхΔь():
    value = 982940
    text = __import__('base64').b64decode('VkE0VDhLNFJDSkxITUdadUd4WGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _υΜйВχЦЭЖьпΥюμηΣΧ():
    if 4 * 85 < 0:
        _dead_8667 = 209
        300
        93
    value = 579033
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHvbbEAR+vorODeVmFmXPyIA1Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 36 < 0:
        855
    total = value + len(text)
    return total

def _ΑФБккρбλ():
    value = 991469
    if False and True:
        202
        _dead_1770 = 800
        pass
    text = __import__('base64').b64decode('Wm9lSkJOYlpCWjdSTkt2Nkl1b2E=').decode('utf-8')
    if 61 * 23 < 0:
        pass
    total = value + len(text)
    return total

def _ηΙψЕтйΚπ():
    value = 323943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSu0Xwg76fBQLDeS7GGKMwR9s2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        976
    total = value + len(text)
    return total

def _АΜсЕφЯИЭΔаχпФ():
    value = 90601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jne8T3oa7ZBbIgXw7H6WCy8sy2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        179
    total = value + len(text)
    return total

def _ΜЦЗδЦψνΜэΓц():
    value = 492559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDfnfHQszr0vOy763n2oLjAH82A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аИЫθпιрΖюςьωγКΥ():
    if len('') > 0:
        _dead_5499 = 221
    value = 846509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnjgTFs0+pIACiOMwQKvPy0VzDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьлСэΠОτшΝΡвζΩςЩы():
    value = 908497
    text = __import__('base64').b64decode('VUVMR1VoNktrbDJyM0NqSl9aTEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕБδΒΛΕλМσφ():
    value = 368241
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBnoYn0s3ZEpHT2N5nmzYQIt538='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4523 = 225
        _dead_5839 = 460
        pass
    return total

def _оэбЩвПζЖ():
    value = 83576
    text = __import__('base64').b64decode('cG9sRzJIZ1FRZENEWmFxcHJmSG0=').decode('utf-8')
    if 57 * 25 < 0:
        373
    total = value + len(text)
    return total

def _фъЩяАлΣΒэ():
    value = 49789
    text = __import__('base64').b64decode('Wm4zU2FSWVlyczNlMGxtR25aREo=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΨΘэьνтЦррΕчοкьΝ():
    value = 681007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyPDNgYT0ZcPaB2qzHmpPhZ80HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        979
        _dead_3393 = 428
        pass
    return total

def _яΟμΔΔзαкОЗЪОΔΦЩ():
    value = 204557
    text = __import__('base64').b64decode('WHhNbV9pWl9HcHVzbjA5blVlcWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛТΧμщпбтИΨГγдЩПφ():
    if False and True:
        3
        pass
    value = 951592
    text = __import__('base64').b64decode('Q2cxZ2dTUUhfcG45WUVxeUIyWXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠпЖщςФΜщгнδΠЫ():
    value = 846530
    text = __import__('base64').b64decode('VlpXbDZYcGNJdHRvSXZ0QllRVGg=').decode('utf-8')
    total = value + len(text)
    return total

def _вΝδτУхβъаЩхЭγΠΟΒ():
    value = 694040
    text = __import__('base64').b64decode('Y3htREM3cWVFRmJpOWtYd2RwOHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΟηЧАТЩИУжЩР():
    value = 955057
    text = __import__('base64').b64decode('eFFSelNiRk1SNDFLZE5INzVsTnA=').decode('utf-8')
    total = value + len(text)
    return total

def _аΖэτΘрΞфοεΦΙтлΞ():
    value = 883143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTzBOGk787whLD2ixXi+MxQptl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жθгΙБэΔΔъψжчЧ():
    value = 341119
    text = __import__('base64').b64decode('T2lnVGU5NXo2OW5iMllTbVcxdUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝьχγьЖιεЙГчПфκβ():
    value = 457717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICi3YG4G7bEgaAqM7niUBSY/vU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖУКΚшΦжτЪΥДю():
    value = 111402
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTfHawQV+40HbRiAy3K+BhQ28T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΙηЪщΦИΛΥХηΖ():
    value = 332369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTrLRVZq9vAnFy6t7G+APSQa9ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΒКΑЙΗΠиеοхυЬЕΓΨ():
    value = 286585
    if len('') > 0:
        _dead_4845 = 619
        _dead_4229 = 878
    text = __import__('base64').b64decode('cjc0Y2l2TVhZQ0NkcUFTMlU4Z0Q=').decode('utf-8')
    total = value + len(text)
    if 66 * 7 < 0:
        970
        816
    return total

def _ПЦγςюιЕЙψфδΛΒ():
    value = 178627
    text = __import__('base64').b64decode('cHRXUHFjYW1BbHVHNzlVVzdwdWE=').decode('utf-8')
    if len('') > 0:
        _dead_5873 = 923
    total = value + len(text)
    if 58 * 6 < 0:
        _dead_5252 = 208
        257
        645
    return total

def _ιнωаШΚΜуИΠЙεπΥγ():
    if False and True:
        822
    value = 655645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA3GWQc/z/gJED6anWObOg089lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7039 = 685
        pass
        458
    total = value + len(text)
    return total

def _ШпΧжΚοφΖαΜшЙυ():
    value = 120526
    text = __import__('base64').b64decode('ZXBwRXJ6YTJrdVczZlV3SVZOUFo=').decode('utf-8')
    total = value + len(text)
    return total

def _КκЛθΣωЪΒΖΝπΓЕωБ():
    value = 542338
    text = __import__('base64').b64decode('Z2lBQVR5d2IzcldtV2R4eHVRY2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _гЪΑЦмЮМц():
    value = 58471
    text = __import__('base64').b64decode('ek9YR2w4ejNuTlcwNHM0ZDFGbDk=').decode('utf-8')
    total = value + len(text)
    return total

def _χБΧХσζΛнασгб():
    value = 79519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQWwfH8Gqa8CCQGF/g6ABHEQ5mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΞГИдДΒъмхСяυйУ():
    value = 473898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCnDen1p5PsTEAiN42WaEBM30lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ясΙЕξζГфε():
    value = 618654
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwKyP3U+6pknOTyy43KWM30n5mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пьΘωρЯπχπΠ():
    value = 55345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBDgf1NopowiAyCb60DBFiMMvUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1244 = 733
        915
        _dead_1770 = 294
    total = value + len(text)
    return total

def _ΙгΦХωЧЮаьεЕЗχфΤВ():
    if len('') > 0:
        132
    value = 472631
    text = __import__('base64').b64decode('dzMwdEhETXZLaU13R0NtYkRMb24=').decode('utf-8')
    total = value + len(text)
    return total

def _μξεВЖщПΤτАнΤ():
    if False and True:
        749
    value = 372278
    text = __import__('base64').b64decode('c3AwQjR5dnBlZmRWVVh0ZTBxMGw=').decode('utf-8')
    total = value + len(text)
    return total

def _φζψгΝνΓχьλΕВ():
    value = 979120
    text = __import__('base64').b64decode('dUN4WU14OHpWZVU4ZlBrY2p6S3c=').decode('utf-8')
    total = value + len(text)
    return total

def _σбГФξλΗУ():
    value = 468139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InbWfHst/fwAAA727QGcIXN7sHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠЧщΗΥδπЪаΖψΩρОн():
    value = 278468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT/2QVUQ3IMCLDqmm2TBMywg9Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИаΡэνσΔйрТеλпΦκф():
    value = 890548
    text = __import__('base64').b64decode('RjFrazJfYzlEQTNEZGJ5WVNlc3g=').decode('utf-8')
    total = value + len(text)
    return total

def _хΒυлФΚΥνМЯЧιΘΝЮΛ():
    value = 797703
    if 57 * 75 < 0:
        pass
    text = __import__('base64').b64decode('b21yZEk4VHk3Rl9aRVdiYWM1dlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮСεεЧЯаΣθЪоυψαк():
    value = 163696
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCTPOlc7//oSID+R6nLFYBYe4ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АκγιΗФМΑΥиэΦχшαу():
    value = 123703
    if False and True:
        pass
    text = __import__('base64').b64decode('a2lxYzVjUnc5QV9qb3p4TjZIRVE=').decode('utf-8')
    total = value + len(text)
    if 53 * 54 < 0:
        197
        534
        pass
    return total

def _οйΒЖДЛзιЬОЙчЬЧΖ():
    value = 714163
    text = __import__('base64').b64decode('c1cwZ2F4SkRzdGxEb1dVcW1vS1Y=').decode('utf-8')
    if len('') > 0:
        153
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ηыТФСΝьΥВγεЬηЛ():
    if 13 * 66 < 0:
        658
        _dead_2184 = 8
        176
    value = 30441
    text = __import__('base64').b64decode('WlBfWDZzTEN4Z0thSWdfQldscDI=').decode('utf-8')
    total = value + len(text)
    return total

def _уΞΓухΑΥшυК():
    if False and True:
        18
        pass
        pass
    value = 520094
    if False and True:
        pass
        pass
        964
    text = __import__('base64').b64decode('RGU4cUJaYWp4Vk83emNPUnVzWWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ъБУΑрΖΨЪтΜИшв():
    value = 264093
    text = __import__('base64').b64decode('UDNTV1V2MDBVMV9sNTRYQTV6Zlk=').decode('utf-8')
    total = value + len(text)
    return total

def _τρьвюшχшэЭ():
    if False and True:
        pass
        _dead_2086 = 631
        _dead_1041 = 282
    value = 449688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQCwS38Izr5UNQaU6mSJPh0X6mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 77 * 21 < 0:
        726
    total = value + len(text)
    if 41 * 6 < 0:
        _dead_5309 = 193
        935
        pass
    return total

def _ТκнрфЖζΦФΞΟ():
    value = 476401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQy1XkUX5rAKM1/7/me2DXYMymg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΕαωΙЖтъαбфЮ():
    value = 769134
    text = __import__('base64').b64decode('RUFaWWpiWnpaS0k1OXVHeTZCdWo=').decode('utf-8')
    if False and True:
        _dead_3444 = 180
    total = value + len(text)
    return total

def _ΕΝМΥлγΘеЙъгΠСГЧ():
    value = 424978
    if len('') > 0:
        pass
        pass
        188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Exj3QAQ894IuPQum6UK9NR187GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кχЫЫиεООκэвЩзЖПθ():
    if 81 * 76 < 0:
        _dead_4074 = 559
    value = 422476
    if len('') > 0:
        pass
        _dead_8222 = 822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHi3N2lv66cXGz+Hw1ypIBA8yGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜκκвщΥΛκЭМΥЖΧжω():
    if 20 * 90 < 0:
        932
        pass
    value = 65135
    text = __import__('base64').b64decode('VkVkSVI3ZzNUcEN5dnBMbFBRQko=').decode('utf-8')
    total = value + len(text)
    return total

def _йλЕОНЛЦγс():
    value = 853649
    text = __import__('base64').b64decode('QjVqYldOUk40R0tFYkJFeEdMcWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕαωмπΗσЛьφ():
    if 72 * 100 < 0:
        318
    value = 367894
    text = __import__('base64').b64decode('dVZlQWxwdFNOUGJxVmNWcmNvRTM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        906
        pass
    return total

def _ΓнξЬσξςμБлΣ():
    value = 430087
    text = __import__('base64').b64decode('am41cTg3QlZnT0FXR01tVUtJRTY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        661
        pass
    return total

def _ΝΧбяΜυЛУЬλ():
    if len('') > 0:
        _dead_1977 = 394
    value = 668131
    if 45 * 51 < 0:
        pass
        _dead_8314 = 571
        254
    text = __import__('base64').b64decode('czV5RHdJdTE0Rmc0c3FuX0ZmclI=').decode('utf-8')
    if len('') > 0:
        _dead_5226 = 150
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ЫΣэБэззθοтЯГτ():
    value = 124664
    text = __import__('base64').b64decode('YVU2dWxqdXpLQmNick83dXk1UEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ДМэОЖжцО():
    value = 486429
    text = __import__('base64').b64decode('eDZCOFhPR0p1c3VGcm1iVVVIX3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЧаЛяКοКГЧНιτн():
    if False and True:
        256
    value = 28340
    text = __import__('base64').b64decode('R1dURmZXY1dJN2NuZEdIc0M4cnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЯΗΚщПЫтцτ():
    value = 121697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3vheFM33Ic2GCf2+3GaYzEA8k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        0
    return total

def _ζРκψνооΟйуОΦσ():
    value = 320749
    text = __import__('base64').b64decode('VG9tdFBUckZ4ZGFWV3NVOEkwSkE=').decode('utf-8')
    if 52 * 3 < 0:
        pass
        986
        pass
    total = value + len(text)
    if False and True:
        pass
        65
        pass
    return total

def _тЦΣεηрποΒμЗВХДКψ():
    value = 937698
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBCzeEcX9blUEiL2zka1DDA84ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θДыЫсюΕЪ():
    value = 739190
    text = __import__('base64').b64decode('Q1NYZm5mMVVfWlhWdk1tb2t1MXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ИυΥπμψьψΜΗ():
    value = 598254
    if 24 * 24 < 0:
        _dead_9207 = 144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiDxR3g8ypA8Ll2bngGGBAcX3m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠσржκДмрКΡ():
    if False and True:
        _dead_3680 = 746
        pass
        pass
    value = 301619
    text = __import__('base64').b64decode('TE94UWExWUM0ZEFYZmVDTHVZUjg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        835
        _dead_9044 = 767
        _dead_9542 = 501
    return total

def _ΓΑФФΗХλСАт():
    value = 485061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz/+T0E0yZhQIDmg42/AJy0jzkk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьъхΞПэЧςЖΛЦιбеΦΗ():
    if len('') > 0:
        288
        pass
        pass
    value = 485585
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCLAXgg3rqotYgqV9323OHQ27F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 57 * 76 < 0:
        529
    return total

def _ΥΩιжЩΣчц():
    if 82 * 73 < 0:
        _dead_1348 = 645
    value = 444021
    text = __import__('base64').b64decode('VWhNdVoxTUs1Mk9CTnVjOGNYY0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΑΧюоΡтПΤψпσ():
    value = 490821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwLrV3Rrx60mOVuZ+VSiP3Y/wEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒММΛЕЮδсο():
    if 32 * 99 < 0:
        819
        _dead_3199 = 744
    value = 292322
    if len('') > 0:
        568
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBvtalQh9fgEPSj7zEGlMA0Ny3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮйΞгΡΘΕψь():
    value = 988869
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQnqPGQK0/svIgL390ygbQl2zGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_2394 = 946
        36
    total = value + len(text)
    return total

def _уΛГбцγφμκΜЭКДτЩ():
    if 54 * 3 < 0:
        352
        _dead_8393 = 240
    value = 804423
    text = __import__('base64').b64decode('VWhzV3NQVV92X1JSVlFhM0RxeVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ξшΠΠγζвмГφλ():
    value = 624087
    if 59 * 61 < 0:
        _dead_9287 = 918
        _dead_9170 = 606
    text = __import__('base64').b64decode('WXlwcWNlcDVzX1NiX1lQU3haQjA=').decode('utf-8')
    total = value + len(text)
    return total

def _чΚАΕЧУЧΞ():
    value = 371445
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHjKYgMa1pouNzqbw36/HCIOwG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФφΗζГдйДпωΡ():
    value = 731660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhvXZXoc1K0VEiyc53uiHwYI7FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΡΛгΕыΠξΔОрмо():
    value = 691899
    text = __import__('base64').b64decode('Qng1TTdwQ0pHalV1NHFQeEJ6aUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΚТΟлΔэФυν():
    value = 192600
    if 8 * 51 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3vHaUkV35FWIjmozFWUMH05sVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σМОЩαРλτжсыθπη():
    value = 400229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQfFZXUg7atbGVqE/XueEQw49Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙРαΛьγтνГςъΑ():
    value = 437283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh32RHI926kFHlyn3X2+GyQ33Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΞюрΝΩъτецДЫЬχ():
    value = 352492
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyrTTGAt8v0lCACy5wXCDR83xkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΖψетχжΕЗμ():
    value = 791825
    text = __import__('base64').b64decode('anMzWHhGTGY2VVV5Vmg2UkdxVGQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7853 = 645
        pass
    return total

def _πμцνΚΑБΠЩЦ():
    value = 17607
    text = __import__('base64').b64decode('THhmM05tVUxOVDVZTFZ5NE5mMUE=').decode('utf-8')
    if len('') > 0:
        174
        _dead_3347 = 105
    total = value + len(text)
    if len('') > 0:
        390
        46
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZA==').decode('utf-8'))
if 42 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    pass