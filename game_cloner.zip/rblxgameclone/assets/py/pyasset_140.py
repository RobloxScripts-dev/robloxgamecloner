#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _μцьУμкчσр():
    if 47 * 7 < 0:
        _dead_2051 = 371
        pass
        741
    value = 469161
    if 47 * 74 < 0:
        405
    text = __import__('base64').b64decode('YjEyUWxzSWdwNTJmZ3FHc3ZOYmo=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΛΙУςΤЪЮГΡΘ():
    value = 435784
    text = __import__('base64').b64decode('T1VCS3FEblN3U1RjOTJTNTRFWDY=').decode('utf-8')
    total = value + len(text)
    return total

def _τКяχβюЖΑсΩ():
    value = 23573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix32fmZu7K07awWb/EafOwY3tFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЛЛЯνУоΡзζΒцЭШΝ():
    value = 953610
    if False and True:
        _dead_4027 = 484
        177
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nxn8YUssrfs3bRinnlecOS9+zXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8336 = 914
        862
        _dead_3568 = 629
    total = value + len(text)
    if len('') > 0:
        pass
        289
    return total

def _χπВΧшΦДψМкЩЙΙОщ():
    if 92 * 21 < 0:
        pass
    value = 113197
    if 21 * 40 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nzrmdl8GrPA5NBeE0nzDJyQJ3Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        554
        293
    total = value + len(text)
    return total

def _фΒΙΣФЮЬЩΟΔЧξ():
    value = 383718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQ31b0Zr/fgVGw6W+G6VLSgIyTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μПОιьζцπλ():
    value = 589917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBm9eHIYyIYsCV/xml+SNj8B9Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        65
    total = value + len(text)
    return total

def _ΜМгаПмАпζДзΧдΥ():
    value = 923288
    text = __import__('base64').b64decode('SGVvME1DcEpuejI3T19zcFBoV18=').decode('utf-8')
    total = value + len(text)
    return total

def _чОжΙоЩрνЛЫΗΙуΞкч():
    if False and True:
        299
        _dead_1409 = 298
        _dead_3754 = 189
    value = 759023
    if 10 * 70 < 0:
        _dead_2786 = 884
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiyzaEEd3JAGAwCz3gevLhQQ/jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΗнАΙΒштΛкΙКуΕ():
    value = 626588
    text = __import__('base64').b64decode('R3lVNGYzZFNENVRyZmE2b1FsS3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЭщзнйνΣςγР():
    value = 829627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DB3HdlYyrv4ZElaO70eXbC06114='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζьЦюπχЖЭΓηχ():
    value = 457018
    if 46 * 43 < 0:
        _dead_1569 = 959
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bz/yPkA47voEaRqr3lOzOXIkz3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гμιΞбсТЦЭАΙ():
    if 76 * 2 < 0:
        116
        618
        _dead_1650 = 184
    value = 382744
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT/PQnsO6/xQaQPx8nC4Fwk3vF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 84 * 47 < 0:
        _dead_2824 = 212
    total = value + len(text)
    return total

def _ΩбгΚЗЬДΒ():
    value = 962838
    text = __import__('base64').b64decode('ZXp2VTZwcnNzWWppV0ZFbllGZjE=').decode('utf-8')
    total = value + len(text)
    return total

def _КЮΛγΣвωΗσΛаΚЙΑΖ():
    if len('') > 0:
        340
        _dead_9762 = 858
    value = 297133
    text = __import__('base64').b64decode('YVBhNl9zVW5oZjY3eGlKSWJtNXg=').decode('utf-8')
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ΙзчιМΨщοшЗΒКУμн():
    value = 660602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzjqenQ+5PkLKwiz20PHEjIt1mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 99 < 0:
        _dead_6274 = 234
        pass
        828
    total = value + len(text)
    return total

def _юБαчЛζлУ():
    value = 747482
    text = __import__('base64').b64decode('TmFnVU1DbUdOaEJIc2ZqZXhneHA=').decode('utf-8')
    total = value + len(text)
    return total

def _υρдΗΕамοδρ():
    if 11 * 35 < 0:
        _dead_6613 = 372
    value = 350769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA3cX0MGqp5VE1/x91+EMnMJ01Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4875 = 985
    return total

def _улΨМСιшνξιЯш():
    if False and True:
        _dead_6958 = 164
        _dead_4786 = 225
        _dead_9409 = 821
    value = 50096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgXQX3sy144gYyCH8AGcAiMKyEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        276
        291
    total = value + len(text)
    return total

def _ΔЦэьфΕιСжσσΦАУТΗ():
    value = 844992
    text = __import__('base64').b64decode('RGl4TTExYjJmMWxCUmZKc0JWVWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤрυБьЮφυГэМЯπЩФ():
    if False and True:
        _dead_7153 = 20
        _dead_5056 = 850
        809
    value = 335401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTjIR3sf57gEAjy3/F7GZDMG4V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        817
    total = value + len(text)
    return total

def _КЖЙЮЬКΗφηя():
    if len('') > 0:
        623
        pass
    value = 759638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxbDO2dpzaJQICCXygGZGDF6214='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 75 * 19 < 0:
        891
    total = value + len(text)
    return total

def _хшΛΜюЖНБΑ():
    value = 205553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxXrfEtgp/EmESj6kWO4IyAMs3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΔκЫнщкгΛУЕлμΤκ():
    value = 584128
    text = __import__('base64').b64decode('YlU1WFNqSXcwamF1WlFpNEFaM2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΗΝЯЫчСοΝМ():
    value = 425213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cjj3UUQ+waU0PwybzWLIBSwjzGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 1 * 7 < 0:
        pass
        pass
        _dead_4678 = 632
    total = value + len(text)
    return total

def _ΣφДβρЯэхΥΒуΟБΒ():
    if False and True:
        371
    value = 84662
    text = __import__('base64').b64decode('ZjR0QUVhOGJqWDFmNE1aenhUc1M=').decode('utf-8')
    if 67 * 53 < 0:
        715
        pass
        333
    total = value + len(text)
    return total

def _σθνцΝΚρрΡΟЦΑ():
    value = 832236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjXASWk/zZ9SABei4k6ELRIX/W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9096 = 906
        pass
        889
    total = value + len(text)
    return total

def _АдΜТσкКфνΦтХχ():
    value = 2998
    text = __import__('base64').b64decode('b2ZGRUxvSDlqVTl1VUdxTldSYUI=').decode('utf-8')
    total = value + len(text)
    return total

def _τВвЦДΕΜлФ():
    value = 813582
    text = __import__('base64').b64decode('RUZCUEJjRDQxYXZGTGdwT3ZaNW0=').decode('utf-8')
    total = value + len(text)
    return total

def _йДνμхΞΣγεцэ():
    value = 85605
    if 23 * 46 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwLKW3UV2YxVKjyGw06CMggBxn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_6637 = 516
        pass
    return total

def _ШНЮθбЙωθчЯАΦ():
    if len('') > 0:
        735
    value = 339733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAO9bHMIpqkEMF6V3Xu5HCQXxTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 11 * 21 < 0:
        pass
    total = value + len(text)
    return total

def _ЗвЧΞΨюпАΛбХλΝх():
    if len('') > 0:
        386
    value = 896529
    text = __import__('base64').b64decode('d196VEZjYVRwWWRoN1JySDYxVHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚУюИφςЛдЯ():
    value = 211549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzvrdAcV/YFbKFqxxGCXYR1/60k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уΗβъΟΘνч():
    value = 434503
    text = __import__('base64').b64decode('eWNuOHkxUDBpNmYyVEk0TVNwYzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚыПγΗΑшΧМрЮИΝХ():
    value = 671583
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHbVPAEQ2K4hLSqQ2Wy7O3Qg3T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΩΛуζЭЗН():
    value = 861054
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQi8aVQQ+P4AOSWXnEHCYg0a4HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κМяЫαψθфν():
    if False and True:
        pass
        566
        _dead_8388 = 50
    value = 728818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('My3uWgc3144VNyuFz0HGIzR/3Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ысфчαπыЩζφМД():
    value = 472557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwPnb1A72qUZAiilymSKJwsr/W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΥъΜЕгςΠКПНΦΙш():
    value = 334858
    text = __import__('base64').b64decode('QkhGYWlxZElYS0NtUmMxdnJmekk=').decode('utf-8')
    total = value + len(text)
    return total

def _τςТыδжЧπμНе():
    value = 639340
    text = __import__('base64').b64decode('QTVhQmZhV0ZjVTVfRmRSUlZ2M0Q=').decode('utf-8')
    total = value + len(text)
    if 12 * 43 < 0:
        219
    return total

def _ЗυУыυΗАΘБαεц():
    value = 944253
    if 71 * 36 < 0:
        pass
    text = __import__('base64').b64decode('ZkdpRUVaVDJkWXdFT3FEbXFMTFo=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        882
        _dead_7510 = 466
        _dead_5181 = 799
    return total

def _ЪзйЯсоΥЪ():
    value = 219914
    text = __import__('base64').b64decode('aGNyOTNtN3pyUVVldG9VSVF1OEk=').decode('utf-8')
    total = value + len(text)
    return total

def _κЬЮЗΘΩцΗГηδоЖкУ():
    value = 626406
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ7tUV0crKwZMDmbzFi5AwwNtFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝуоδψζλУъЬНιШιиΥ():
    if len('') > 0:
        pass
        pass
        pass
    value = 844840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDbPN186qow6LhjzwAOnOj89yl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξйχΖΓКШψхεЦ():
    value = 627313
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXnNZgIV86cTFAC6kGLFLBQLw0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7722 = 220
    total = value + len(text)
    return total

def _ρЭΞΥдлАΔΙт():
    value = 666020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgTxTwER3LE2NTuZywSaHA53tWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΧΦфЭЪОхКΤνэξΓ():
    value = 476324
    text = __import__('base64').b64decode('UjhwbHlZMjVIZ3JkM0FjYkEzSTQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_5061 = 528
        pass
    return total

def _мКюТаΙΞΓα():
    value = 922464
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az7Cf0M85rw5MBr3wnq5LAYH1Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        130
    total = value + len(text)
    return total

def _гνЬжУΡАьΒиц():
    value = 726704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgXmUVgd56ZVAAi0mmOaIBMtzl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_8865 = 986
    return total

def _МьлαЫзπΑыпЬ():
    if len('') > 0:
        pass
        pass
        pass
    value = 984617
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiLVbFxh65IWAiS1/0SWEQp//XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        802
        pass
        697
    return total

def _ΥςфΞτΡлτΙеο():
    if 33 * 38 < 0:
        _dead_7077 = 839
        792
        pass
    value = 885910
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3rXWXoq9YowACGA2U61NXQc/mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        746
        419
    total = value + len(text)
    return total

def _ΟЗНюΡΙπΚ():
    value = 149086
    text = __import__('base64').b64decode('a01IdUNZb1YwdGNhc0tSYkpUanU=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΛΝШкШΔНΛΡνΒεΘΣ():
    value = 883631
    text = __import__('base64').b64decode('WExPMmVZYjlnR0tpNG93N25iNl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦюШйσьκуЛржολя():
    value = 330220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EH7cTQJq+p05FCWX/AOYZwd5yD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΜΩЖМЫΜρςа():
    value = 244088
    if len('') > 0:
        56
        pass
    text = __import__('base64').b64decode('alNMaGIyYmNEOGh0eEZPd1hVeFg=').decode('utf-8')
    if False and True:
        pass
        _dead_9426 = 359
        296
    total = value + len(text)
    return total

def _ЖдЧТУιцЯС():
    value = 67941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LirOS1oc1akwGRmS5wOWFSB+sHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 47 * 4 < 0:
        662
        462
    total = value + len(text)
    return total

def _сэψхΟдЧбгΚпΝφΠ():
    value = 791575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxfqfWAG3b4MAiyhkA6FDDQ4614='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 5 * 35 < 0:
        pass
    return total

def _бвιΣЦχΞΒΥФΞ():
    value = 888443
    text = __import__('base64').b64decode('S3FJTTMyVVkzclk0eFM0d0pzZUE=').decode('utf-8')
    total = value + len(text)
    return total

def _РΥюФуБουΜбΚэΘ():
    value = 721719
    if False and True:
        _dead_8539 = 397
        205
        214
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBy9fnIJ1pxbGR2R8kepMQ8E01s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8447 = 644
        _dead_6479 = 521
    total = value + len(text)
    if False and True:
        pass
        _dead_6914 = 962
    return total

def _ыςΓочЖюЙς():
    value = 192316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnrLWH4j0oAaayiT0EWSLDML4Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤмчЬΞЮΗρλцκгΡΩ():
    value = 431842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC28eQI9raAOMSKy6X/CGAQEw1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 51 * 89 < 0:
        pass
        _dead_3199 = 789
        pass
    return total

def _ыΣφЗΩΜеΥΞψВΣлеЩλ():
    value = 725763
    text = __import__('base64').b64decode('VHdLTHk5OUJtanlCOUNOQzJZam0=').decode('utf-8')
    total = value + len(text)
    return total

def _йктДΚρАючнν():
    value = 15104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCrvOwlo6K1QGS6E61TFIDYZw0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_1831 = 247
    total = value + len(text)
    if False and True:
        pass
        611
        _dead_4000 = 109
    return total

def _ЭΑаНКψνΑκЭΩνΙΤ():
    value = 94410
    if 17 * 26 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiToRwEryKIsKiOunXHAASt/vHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΠиΔΕψΡΤГπйγψΦк():
    value = 184134
    text = __import__('base64').b64decode('bVR4VnNieFphQ2prUmdUYVdTRkM=').decode('utf-8')
    total = value + len(text)
    return total

def _νкθьθκΑΨΣаςПΑσ():
    value = 652996
    text = __import__('base64').b64decode('SWZZS0VTc0lDV2hEbTA3bTdUcGI=').decode('utf-8')
    total = value + len(text)
    return total

def _νзΨμъиΜр():
    value = 527324
    text = __import__('base64').b64decode('elBwbTFacTR5Njh5RE81NTZ4elI=').decode('utf-8')
    total = value + len(text)
    return total

def _эεрЭЯχεδεоэΞκц():
    value = 640962
    text = __import__('base64').b64decode('SEVoNzFDcEluWmdsYVZNUkZuVDY=').decode('utf-8')
    total = value + len(text)
    return total

def _эΥяΦΦΞΗΞΘυгψχЦн():
    value = 444873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M37CPWkU8aVWIjWPn1nCZCwl0WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΒыΙрЫωЖ():
    value = 621266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCXJW2lpz41aAD+522ShHnw7/Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 37 < 0:
        _dead_2643 = 490
        _dead_7435 = 476
    total = value + len(text)
    return total

def _ΥΜЩμΦΤжоюΦЭ():
    value = 398822
    text = __import__('base64').b64decode('VXlMUGVHb3p0bVpCbk1vMEFXUkw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        733
    return total

def _ςςМαμУЫзТΗ():
    value = 821058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nnq9S3ku04EhDCK10EPEYgkC02g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭсРгеθκъΒуπΝΕΗ():
    value = 540089
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhjpWHcv8JIlHTvx72O+Ygw/vG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эРэщεкγΚжχ():
    value = 372293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDbPOmAd07ISYx+F/UXBNTIMwUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τрДВуЭДУξδχЬ():
    value = 334184
    text = __import__('base64').b64decode('RElPcDY4WnVUcUlIdjJQclpjWjk=').decode('utf-8')
    total = value + len(text)
    return total

def _τжоΗΟвОЦΖΒΓτНцрΚ():
    value = 163926
    text = __import__('base64').b64decode('bzRzU0tvSXg5aERuRmN5SXo5QWc=').decode('utf-8')
    total = value + len(text)
    return total

def _СкХсТшеΙΑΕαφкΚ():
    if len('') > 0:
        312
        _dead_4649 = 492
        _dead_3403 = 29
    value = 832750
    if len('') > 0:
        74
        _dead_3044 = 908
        _dead_5974 = 385
    text = __import__('base64').b64decode('RWp3WWZqNThBTUgzSGVpeVBhTUM=').decode('utf-8')
    total = value + len(text)
    if 41 * 47 < 0:
        206
        _dead_6323 = 307
        pass
    return total

def _тКξофθΔлλ():
    value = 668488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSr0dGsdrYwEOVi0zW6xLiQ+61g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩηыуажΣЗ():
    value = 442357
    text = __import__('base64').b64decode('YlAyXzlkOFNla3lwcDNVQl9EeGo=').decode('utf-8')
    total = value + len(text)
    return total

def _καββκзлд():
    value = 127130
    text = __import__('base64').b64decode('THB5dTNkWVN3dFU3dnc4TzUzcGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΔцсЫΘδНЖ():
    value = 470489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3/rVktp6aBQDyqg90y0OHJ35ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΠрЯΕцζИΩЯпσоХΓ():
    value = 544458
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxjmaX0v+6sONC2nn1yyGnU5wnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λНэрЪюБΗ():
    value = 85520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx3IQgke/fAvEjizmWKnDTcW1lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТωζЮζΦΦηγпп():
    if False and True:
        pass
        _dead_9888 = 323
        541
    value = 193180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjjMaGVtx/kiMF+T233IAyghyXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γωЩЯОКиζ():
    value = 7055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXzvZUAprrEaPzr7yn3FHhUnz0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_3045 = 288
        989
    total = value + len(text)
    return total

def _шиμцιанеамЪ():
    value = 686757
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('Q3p2X0RidEpGSGxpM1NCdk85aEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΕпΡΙηрбιиΑ():
    value = 316558
    text = __import__('base64').b64decode('a3VkSkFnMFhXUllDWXVUN1J3Yzk=').decode('utf-8')
    total = value + len(text)
    return total

def _λμжЙфОЗгрξΓΟ():
    value = 440430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwzKO2sz9f07NQaJ6QDENXMG4zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 85 < 0:
        pass
        _dead_2856 = 458
    total = value + len(text)
    return total

def _бъелЛМωΑБщμЫ():
    value = 386823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBDDWGYL64k2AliR0AehZ3V6xUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        31
        956
        _dead_8638 = 262
    total = value + len(text)
    return total

def _ъψιЛфΜζηлЭδьрХΚЛ():
    value = 510593
    if 86 * 6 < 0:
        82
        pass
    text = __import__('base64').b64decode('ZVlIaDBJVzJuQUUwbDd5RFdJRHg=').decode('utf-8')
    total = value + len(text)
    if 17 * 61 < 0:
        293
        _dead_8485 = 983
        663
    return total

def _ΥЬμейУяЗΣΩяЬυЛ():
    if 22 * 67 < 0:
        pass
        889
    value = 276796
    text = __import__('base64').b64decode('aVRaZ0RvNjlpR0RiUWcya196M3E=').decode('utf-8')
    total = value + len(text)
    return total

def _смЙГΑΔАρтτЮ():
    value = 494315
    text = __import__('base64').b64decode('dUh6OGVmMXl3dktjenhCdjRXMlg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΟγлλεЗπΘωые():
    value = 440648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzrGelgM+pcMLgS0n0CaERUny08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чνнλяΨβκιρψα():
    value = 54003
    text = __import__('base64').b64decode('UFNqcjFNWjNEQWdRNjFxQ0ZmVDc=').decode('utf-8')
    if 98 * 23 < 0:
        _dead_3066 = 322
        _dead_8479 = 167
    total = value + len(text)
    return total

def _ЬΘΗЬТЭξψφζУ():
    if 12 * 96 < 0:
        pass
    value = 846671
    text = __import__('base64').b64decode('Y2FmeXU0aXpUNEVvQnNtTDVRRGc=').decode('utf-8')
    total = value + len(text)
    if 14 * 91 < 0:
        437
        pass
    return total

def _αтвШδеΥЕвπ():
    value = 14107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASnUe0JvqqkOCiz77F+IFyp+51c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΒкаΧБЛηΨωю():
    value = 969100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M33yewcL6KMOazCnywPAZR134kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮυЭΔЙОυд():
    if len('') > 0:
        41
        646
        400
    value = 682325
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAjVWAYDzP4iCi6M63fFPxIasUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΒБОЧжкδЦЕюΙΝ():
    value = 12737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz/MVAkQ2IUPIz2H6mWJMiYh6l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡЮλσμхАιΩНΘΛс():
    value = 47517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3rWQXA60/oENT+C+3C4ZBMYz2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъТςΠοКИзжβУρоδх():
    value = 351173
    if 17 * 12 < 0:
        pass
    text = __import__('base64').b64decode('T2RaME9Pa1ltWlE5Q2Q3OTlTX3k=').decode('utf-8')
    total = value + len(text)
    return total

def _κТЬъсЕЗюиЭ():
    value = 967604
    text = __import__('base64').b64decode('RUduYW5wNktVblZvSkRVblRUT0E=').decode('utf-8')
    total = value + len(text)
    return total

def _СшНοАЧШΑВ():
    value = 840890
    if 36 * 77 < 0:
        _dead_2977 = 29
        _dead_5349 = 158
        34
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQv2amQLrK0HOBmHxVWEHQQV0FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔъΡβпОδыξБ():
    value = 129262
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCjqfWJh0I0gMwuM43WZEAQk62g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юУмψхυьΛΡл():
    if 9 * 75 < 0:
        _dead_8121 = 816
    value = 552380
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FA7IfXY6rvsbaTyW3lKvAg4341w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4431 = 548
    total = value + len(text)
    return total

def _τУνкφЯωъц():
    value = 383951
    text = __import__('base64').b64decode('VUhRX2hEU0ROcFRDVWNEWWRQZ28=').decode('utf-8')
    total = value + len(text)
    return total

def _ψιχΒχжΡЭНΖ():
    value = 548044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhX9bHoV3IUtHTec4U6XIgAY1n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2432 = 94
        pass
    total = value + len(text)
    return total

def _ТфуΛκмыбЬрВθЗ():
    value = 188829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACXQYQUe2KkRPi2un3yTFwEm72A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥЬщНЛΤΓδзълЮэΒΧ():
    value = 497871
    text = __import__('base64').b64decode('Z2ZSYkVWcTJvczYyek5SWUdSRXA=').decode('utf-8')
    if 68 * 74 < 0:
        _dead_4861 = 60
        pass
        63
    total = value + len(text)
    return total

def _σТБΖтЙεьΚα():
    value = 682424
    if 8 * 67 < 0:
        _dead_2084 = 628
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTfSeQg3rPA1IBmu33ipEzEGsmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        807
        pass
        pass
    return total

def _ΠтοΝΛΩыΞ():
    if 89 * 25 < 0:
        pass
        543
        _dead_9223 = 251
    value = 901810
    text = __import__('base64').b64decode('aXhaTGVqcWJidXBTbEt3M29jMHk=').decode('utf-8')
    if False and True:
        _dead_4525 = 337
        pass
    total = value + len(text)
    return total

def _рАУαθΒЩЧΞфНлΘлΙс():
    value = 124256
    text = __import__('base64').b64decode('c2I5UFZ5dzZRcDFpZHF2Z2lTX3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭшχςпгηΝЩж():
    value = 957368
    text = __import__('base64').b64decode('aUoyVGVRcE1nWnRwRDhiU2lickM=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6608 = 829
    total = value + len(text)
    return total

def _еЭрλТΟчФаиπνуо():
    value = 370667
    if False and True:
        pass
        _dead_9503 = 919
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwfdO2USz4kEaR2L0HSSAjd2/V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χдчХЯΡΕξШ():
    value = 498906
    text = __import__('base64').b64decode('clpKMDFxelF2ZUFMMXRKRkd4WlM=').decode('utf-8')
    if 27 * 17 < 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_4175 = 781
    return total

def _ЕςъλиΖдΚКФ():
    if 83 * 4 < 0:
        _dead_2329 = 929
    value = 115679
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3vddHpq9Zcta1aM4VmbZQQ711w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТКзΝЙцυы():
    value = 961942
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj7LfHoDxqo0AFeR4U/DBQYmw3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΓдΩεЭпЭнйШΨκзъг():
    if len('') > 0:
        pass
        pass
    value = 718014
    if False and True:
        _dead_1485 = 311
        _dead_9496 = 511
    text = __import__('base64').b64decode('TFUzT185R1h6QnNSVzRmRmg5Y1Y=').decode('utf-8')
    if False and True:
        _dead_1981 = 288
    total = value + len(text)
    return total

def _ΚзυρФпЮΝΨюзТεΤьж():
    value = 281813
    text = __import__('base64').b64decode('U194SzUzRVhWMmZRUGNHaEpycDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤтЕΟХНЧσλνι():
    value = 449993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fxb8eFtu848FIF6Z8XCAYnY5sX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 14 < 0:
        pass
    total = value + len(text)
    return total

def _вΖΡПЬМΛоωδ():
    value = 979337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADm0RkI05psaA1+PxVyUGjcf6UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыρΩьЮИгιУюЦ():
    value = 112818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jia8a0APxrpWEQOX3k+APnJ+wlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НцΥлςηΖγрΖΕОйм():
    value = 21030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSLIRH0e+5FabyKGnFKDNjYm8ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πψХуШЬИФсδ():
    value = 33745
    text = __import__('base64').b64decode('cG1nVExoN3ZnU0J0SldZNEcwME0=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΠКррτνО():
    if len('') > 0:
        pass
    value = 364513
    text = __import__('base64').b64decode('cDdiMHQ0REwyZ3ZwYzhIOWNSSk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЗнΓΗыБпΟЮτ():
    value = 788128
    if len('') > 0:
        _dead_7829 = 924
        pass
        806
    text = __import__('base64').b64decode('WHhhZllrWkM5Q3JVams4WUpGZm0=').decode('utf-8')
    if 80 * 3 < 0:
        _dead_2845 = 53
    total = value + len(text)
    return total

def _σЭЮЩнфВбЮΥςЛЫΝЗ():
    value = 962353
    text = __import__('base64').b64decode('T1hnWnUzUmVaY2VaZzFnVE9wbDE=').decode('utf-8')
    if 45 * 28 < 0:
        361
    total = value + len(text)
    return total

def _εΚΑγδμβмΒирЕШσΝЙ():
    value = 418900
    if len('') > 0:
        _dead_7173 = 218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBXKWl1t35AVIgeq/VWJOw4Gt0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1896 = 337
        _dead_7939 = 0
        pass
    total = value + len(text)
    return total

def _μΒЩЭςшδЛсхчΛЪЬΞ():
    value = 998626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDjSTEMO6f4VPAKykEybHHcf9lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κшΙХЫμТхπ():
    if False and True:
        _dead_4962 = 197
    value = 691395
    if 32 * 99 < 0:
        247
        466
    text = __import__('base64').b64decode('Y0ZKd0U1eWh4X1YwU0JqMzVONEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΠηХЦτωκмъкьПΜ():
    value = 611791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDvIV0Y69poxIinz+QGXJzc1s3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 26 < 0:
        955
    total = value + len(text)
    return total

def _дэвэмяиΣаφ():
    value = 632214
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FB3zSFQW7q0XNleh8FuBbSMb538='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3091 = 717
    return total

def _ЩбыщщΕЕΠΒ():
    if 70 * 5 < 0:
        pass
        _dead_7982 = 38
        _dead_9820 = 265
    value = 310043
    if False and True:
        _dead_1289 = 124
    text = __import__('base64').b64decode('ZW82SV8wOVIzaGdseFo2VVI4NWM=').decode('utf-8')
    total = value + len(text)
    return total

def _эдюЬЦОнβ():
    value = 460975
    text = __import__('base64').b64decode('bXcwcUNBcnp2a1VNVUU1Ul81ZnU=').decode('utf-8')
    total = value + len(text)
    return total

def _нтμяцηйЬπжС():
    value = 104706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSPdUUIv5rlVICO5y1C9HjcotWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙηИсэиьβНοηβРп():
    value = 89333
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J33KXGkO94xTMlm28ASjbTE410s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 45 * 36 < 0:
        _dead_5217 = 387
        pass
        2
    total = value + len(text)
    return total

def _ухМиΡсΗчъчТъ():
    value = 658570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwHpbHUYz6wiCF2LwWaUFScVz3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОψюΡΗζкΚΞх():
    value = 552678
    text = __import__('base64').b64decode('Rl9FVVNJMjhyajB2akRMSlNZOGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛРΚФДΓббБ():
    value = 172535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3btbHkLxJsgFCGRy1DEPSQn/lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 1 * 1 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _шΡξоеΑтИЪЭС():
    value = 517382
    if 28 * 26 < 0:
        pass
        673
        _dead_1338 = 696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwHUfH4X5v0AFlyL2G6xGicV5j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮПджЪмЛΝВшУΙ():
    value = 438710
    if False and True:
        _dead_2566 = 520
        916
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRzWZXIa97oxFDyt4lnHNQ8F7mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        873
    total = value + len(text)
    return total

def _ЙгЪφψЕзθхΧιЭυΒЩ():
    value = 522496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ni63SllorbgIA1iF3FG8M30l9jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГφЫюπλθЗ():
    value = 498879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjzlQGdsrv4CPFyJ7gaTHDUDy08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΡрβΖλыПΜΦ():
    if False and True:
        pass
        _dead_9544 = 81
        _dead_4371 = 852
    value = 763389
    text = __import__('base64').b64decode('bm1iYVNoSzRCNFg4U2RpMXd4UEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙρΟбЦσтлТΞоγ():
    value = 469984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh61eAcW2KsKMRf3y1upPy8cyEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        422
        21
        _dead_4917 = 282
    return total

def _ПζШрЬРЖНΧа():
    value = 311510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQTtYXwMz5w8IjaA53/FHyk/6Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тфυοЯэΗρα():
    if 80 * 89 < 0:
        _dead_8852 = 149
        pass
    value = 967451
    text = __import__('base64').b64decode('Q0xCdnZkamh6M1FfZjhXbGpNS2Y=').decode('utf-8')
    if False and True:
        _dead_6202 = 217
        _dead_5539 = 820
        _dead_9094 = 313
    total = value + len(text)
    return total

def _ЬМЬАэνΠΙЭХΗβΥμ():
    value = 839646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESrpNlho+IcWODe5xw7GBBp5/ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξвеζΓРвσχΣкοювΘΤ():
    value = 761124
    text = __import__('base64').b64decode('cVdva1RhU2hsYWNCYVlsbEJ5M3o=').decode('utf-8')
    total = value + len(text)
    return total

def _МЖЭсτфЬτΖΖялъыи():
    value = 12545
    text = __import__('base64').b64decode('U2F2SVFVTW9uTTZzZHBKOUFfMUk=').decode('utf-8')
    total = value + len(text)
    return total

def _βψьЦВΩЭюψоωе():
    value = 170183
    text = __import__('base64').b64decode('dHNOUDJIUnhMdnhlb1ZIS0IwOTI=').decode('utf-8')
    total = value + len(text)
    return total

def _γВςνКΑδРυйС():
    value = 383627
    text = __import__('base64').b64decode('Um1CckdvRlh0M3ZxRG55UkFNdmY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ηнΚьЯШπбПφωπв():
    value = 66942
    if len('') > 0:
        _dead_9230 = 201
        386
        _dead_3470 = 471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxrwRVY03JAVKBaA0AHBPHYr9Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯξΖЮζΚзгχθТ():
    value = 754823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lnn9NkIM0aIbaSqlw3e9Hhd/4X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚБЗεхЬψзяΠζηκ():
    value = 638077
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxbRS2443L0pCwyX72ymDXMLsj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αЧΞЙψтАпУΥΑΦО():
    value = 138198
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iy3zT0Av9akSCRrznEChHz0ZtGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СχчχсьυδэуΨЮИмю():
    value = 727167
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3iyP0U0+ppSMBek2VqEOicZsTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чχМИДБΙαчκΕ():
    if 2 * 30 < 0:
        _dead_8846 = 437
    value = 606553
    if False and True:
        506
        _dead_9974 = 195
    text = __import__('base64').b64decode('d2pXRGNNT3VJdEZwZkxYUW5fWDE=').decode('utf-8')
    total = value + len(text)
    return total

def _κмωΛОΧοσΠДТнΑ():
    value = 570151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAe3PUlq8fo0bDuQ0nO4AhQLyFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 82 < 0:
        _dead_9381 = 677
        13
        767
    total = value + len(text)
    return total

def _рлфВНнεΔςоХυ():
    value = 449077
    if len('') > 0:
        pass
        pass
        209
    text = __import__('base64').b64decode('eUV1Rnk4NXQ2eXhHalJZZ0ZyMjI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7552 = 101
        908
    return total

def _бэФΕψэХνхшЧдвλα():
    value = 61083
    text = __import__('base64').b64decode('SnB6ZjVoOUJBTDRFa19ZNWk0OWs=').decode('utf-8')
    total = value + len(text)
    return total

def _νЖЛЛЖΗгχГβζШ():
    value = 87920
    if 78 * 76 < 0:
        _dead_9504 = 814
        473
        112
    text = __import__('base64').b64decode('cXRzQU41Znk3RnZnem1sdlNLalE=').decode('utf-8')
    total = value + len(text)
    if 68 * 45 < 0:
        _dead_6708 = 538
        _dead_8719 = 439
    return total

def _еьωυΝЗъτΘтхы():
    value = 44986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITy9Xnk4yY0RbV+JwkGDPTEg8GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςдαβΦκЗιъЭΟиРРцТ():
    value = 123006
    text = __import__('base64').b64decode('bkFlNU9wN0kzNFhYaHpmd2NjNmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩκЛгχРяΓ():
    if len('') > 0:
        _dead_3287 = 541
    value = 18685
    text = __import__('base64').b64decode('RE5NTFRQVXh2WHl4QXF5NExTTVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ςνΩΩΣξΑЗЭΝ():
    value = 392881
    text = __import__('base64').b64decode('ektCUkhrdnI3YkE3RlBCSFNIMzg=').decode('utf-8')
    if False and True:
        _dead_7017 = 228
        _dead_5019 = 361
    total = value + len(text)
    if len('') > 0:
        _dead_5734 = 818
        225
        pass
    return total

def _ΛΣбΦγдψΧшэРΗΛΚΩ():
    value = 890764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSi9XGI02ZIALViS2nmHMiID4js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зьБкΝιΑхΨγμЙ():
    if len('') > 0:
        764
    value = 901766
    text = __import__('base64').b64decode('alRrVmw3UXdOZmwxbmFXWlpVMVM=').decode('utf-8')
    if False and True:
        pass
        6
    total = value + len(text)
    return total

def _эЙощΣμΦЧΤлАк():
    value = 884238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnnhVGcYp7lROBv7m3ODNnB2sUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 2 * 32 < 0:
        162
        130
    return total

def _КΖЮьσрВеζτюΙ():
    if False and True:
        419
        _dead_3294 = 677
        642
    value = 358539
    if 70 * 31 < 0:
        _dead_5861 = 712
        pass
    text = __import__('base64').b64decode('bm9DNTJYTTNVMG5xVWJmT0NZeXA=').decode('utf-8')
    if len('') > 0:
        pass
        872
        108
    total = value + len(text)
    return total

def _ИСχВΨЯдчнβшζχТЛх():
    value = 496876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh7pd1wR6YQ3Aj2n4Q7GF3wJ9WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠцзцщНъюйТ():
    if False and True:
        pass
        87
        _dead_4230 = 273
    value = 960138
    if len('') > 0:
        662
    text = __import__('base64').b64decode('SGZiaFA3ZWtieTB1RFh0NmNZNU4=').decode('utf-8')
    total = value + len(text)
    return total

def _яОЦΥгЖЩΙЫдХ():
    value = 165139
    text = __import__('base64').b64decode('S2ZJa3JEUDJGbFNCbEVaZEhNSkM=').decode('utf-8')
    total = value + len(text)
    return total

def _йыщιзъкЦεЗ():
    value = 453238
    if len('') > 0:
        _dead_7269 = 752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Anu3encM8vkIKSWxmw/GbHIN3Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        633
        pass
        _dead_3583 = 460
    total = value + len(text)
    if len('') > 0:
        179
        363
        pass
    return total

def _ЖтТЧЙфφыыιν():
    value = 447807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhzDYG4U+oMHCCmN0XHGbRJ78DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΕбзΒнΗДыΦφ():
    value = 509894
    text = __import__('base64').b64decode('dzBKcWpxY19sZ3BiaGtTSWhldEs=').decode('utf-8')
    if False and True:
        _dead_5954 = 570
        492
        _dead_5622 = 442
    total = value + len(text)
    return total

def _ЬэзζιяβА():
    if False and True:
        922
    value = 162830
    if False and True:
        320
        794
        61
    text = __import__('base64').b64decode('U2RWUDUweEdoSVYxQ3RMckxjTU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΜδεμНΛвжП():
    if 3 * 28 < 0:
        529
        pass
    value = 345161
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRDgTFcbq7IJGDaq6kO0PHU28mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТОΔΙγνщΣΤФлτδ():
    value = 389852
    text = __import__('base64').b64decode('T21ZNTlLY0g1ZWRyN29wRVhvMng=').decode('utf-8')
    total = value + len(text)
    return total

def _ψэЬВчΜяΗКТЭцΓфΑ():
    if len('') > 0:
        120
    value = 718622
    if 38 * 40 < 0:
        _dead_7494 = 752
    text = __import__('base64').b64decode('dUE5eG8xRDlJX1pvMjNIYnA0S0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬтГЛкσΦсфηΔβξИψ():
    value = 934269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTnLaXMB2acmBSK38UW+ARUO1T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΛАκАΨШςχΦзаы():
    value = 687048
    text = __import__('base64').b64decode('RkFWY2JJenBBMkd4NV80SlpBbDE=').decode('utf-8')
    total = value + len(text)
    return total

def _фΜΠπΓйΛхαуΗЩЭ():
    value = 107827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyHMQnkG7b0qNxmyzQOXZy8dt28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        58
        pass
        564
    return total

def _мдφДгΑχхЯыЙΑΜл():
    value = 568873
    text = __import__('base64').b64decode('aFZmNlpNVElLbVpFRkw1X3BFbU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ГθЪгКωΩεншиМ():
    value = 41571
    text = __import__('base64').b64decode('TndwZU5qbEliYlRxSEp5cDlXWks=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΜУΔчИΡδнξУЕуκз():
    if len('') > 0:
        pass
    value = 283697
    text = __import__('base64').b64decode('aVhMX3dCODhfQWo1YzFVT1BZNUY=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _цΦывЬюрιρΒΣΝцяοο():
    if False and True:
        _dead_3131 = 600
    value = 821391
    if len('') > 0:
        549
        175
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzfNSQYN7Ks1FBiMw2PAOHB41WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 12 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _эОΦгκЦПΠтУдЕνгН():
    value = 812561
    text = __import__('base64').b64decode('TERsUk53a0w1Tjc0V045V2I5cUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧζНУыΒщЯφР():
    value = 246227
    text = __import__('base64').b64decode('dWtvV1RPblBZcjEycjFaakFPSUc=').decode('utf-8')
    if False and True:
        pass
        144
        pass
    total = value + len(text)
    return total

def _АωΒщЦяΤщаэΣФο():
    value = 337577
    text = __import__('base64').b64decode('S1h6cG1FMnUxQmJpOHBoZjc2akc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪСАГОвΦλμ():
    value = 129204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHjTXHcr+qczPACm30+8LXUG1WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БπΗΥΝунσνωΓυΖМб():
    value = 1631
    if 36 * 92 < 0:
        797
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnbqV3wK/KxRLxeRnASqZBUn7n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΞЛЕФпΝдεюΠмЧМ():
    value = 634524
    text = __import__('base64').b64decode('RlExQ0lUZGI4R0hzN3I4S3VCMHU=').decode('utf-8')
    total = value + len(text)
    return total

def _вΝιοЯОζэΙФΙр():
    value = 564426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgbyQX8ozfA6NF6bmAalMCR8/Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8159 = 398
        _dead_5520 = 635
    return total

def _МρβНπΚзмΠВ():
    value = 876076
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRrdegUb+aMhHz2l/gK8AQYJynQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЭэΕФЫЮЩмыУта():
    value = 395053
    text = __import__('base64').b64decode('UjE2RWZGdUlpXzFGMTN5Y0dGdXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖςрπКςШθТ():
    value = 862369
    if len('') > 0:
        883
        284
        260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxjhSlRp6KMZLTaKkFzGH3IM8kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 49 * 34 < 0:
        22
        _dead_7584 = 90
        _dead_8533 = 549
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 69 * 6 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()