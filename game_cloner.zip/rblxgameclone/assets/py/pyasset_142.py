#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _μЖσДΗЦЕΧпД():
    value = 833689
    text = __import__('base64').b64decode('UDV6Tm5LemxkZVhQVDc3SktZQk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΤшΦβЙбдэ():
    value = 665713
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JirrfWY4xP0VETuR8HCbLCE+yl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кγУΜЭэΘΙЕΖα():
    value = 801556
    text = __import__('base64').b64decode('YkNYaEVERXFYNEFXX2RIeTNNalI=').decode('utf-8')
    total = value + len(text)
    return total

def _счΞюхЖОπьЧΒЖΖпβΞ():
    if False and True:
        858
        735
    value = 130987
    text = __import__('base64').b64decode('Ym1uMGN6SUh0RXNtNWl3ZF90UFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ГБчНΧΑΚξакΝд():
    value = 878595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESu8QlcWzJIsLRa73G63AREJ7lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λТлΦщмνΥΖ():
    value = 64049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDX3V0UM6K0BEQOnxQ6bFQci514='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АγПδγΦγйлΔыΓм():
    value = 894584
    text = __import__('base64').b64decode('RnZlN2dxclZ2S1lwV195SlE5R28=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_9688 = 217
        _dead_2401 = 61
        pass
    return total

def _ЧΕСνлΣГΗΠΣЬМΥ():
    value = 589421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bxa3PUcNp4xRCi2NxnvGGgEn920='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιэйЩтιψЮХяЬνКР():
    if False and True:
        _dead_7506 = 28
        900
        864
    value = 564452
    text = __import__('base64').b64decode('WlZlM1J6TTdORk1lUzd5YVN4NHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙНΘЮШацйкζдπΡΗυЫ():
    value = 563944
    text = __import__('base64').b64decode('VDM1YTJ6Qnd1QktXZUFtdTU3YVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΡЛтНтсΖЮОЖνЧτι():
    value = 682922
    text = __import__('base64').b64decode('czZQcW5acHExQ2JyVDhoVEZHcWY=').decode('utf-8')
    total = value + len(text)
    return total

def _РюχθВсΞФЕЦЖΜчι():
    value = 89454
    if len('') > 0:
        pass
        654
        749
    text = __import__('base64').b64decode('QzY3NU9oOElqVk10UUJhMjNPWDY=').decode('utf-8')
    total = value + len(text)
    return total

def _οзΓκЛΨФγΡТбМψτ():
    if len('') > 0:
        _dead_4879 = 699
    value = 875579
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCXKZwc35LgbOCnx2kKWLRU97Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _нСΝВαψθκΑ():
    if 50 * 53 < 0:
        341
        652
        430
    value = 211506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izi1UQlsrJ1Rawu13Aa4Mw0btUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηιнΣоεюΜΒΑΛй():
    value = 831976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxbmX3sTzrABFyP73nS2ZxIF7WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡктΥыМξκΝΦЕ():
    value = 538682
    if False and True:
        pass
    text = __import__('base64').b64decode('QXhDNzRBazdyQzRxaHhEWFdmWUU=').decode('utf-8')
    if False and True:
        pass
        202
        538
    total = value + len(text)
    return total

def _ПθΣЮвκЧиαфЪпЧΓхЫ():
    if len('') > 0:
        329
        114
        621
    value = 496652
    if 39 * 27 < 0:
        616
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHzvOHBhxLo5MAKN2gKCDXMNy1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        679
    return total

def _ьΥбΗρнжΚλЩЙ():
    value = 542294
    text = __import__('base64').b64decode('Z1YxcHdxSDJRUnQ2V3BtdldMdk4=').decode('utf-8')
    total = value + len(text)
    return total

def _νΠеЙιΒωЧпсЯ():
    value = 853395
    text = __import__('base64').b64decode('dTJEa0NNMWV3R01DeFdJeGlUUGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩшЖШПΗοЭρ():
    value = 516192
    text = __import__('base64').b64decode('a3piUFljSmlncFBRZEwzeU92Umc=').decode('utf-8')
    if 37 * 90 < 0:
        _dead_9993 = 874
        447
    total = value + len(text)
    return total

def _БΩΟευыЦЕгΨТяЫΞ():
    if False and True:
        810
    value = 505551
    if 88 * 21 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjX8bHYr3L0XKwSGzW6fYw0ZzXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΥΘΡΑрЕκΥКШБτ():
    value = 64186
    text = __import__('base64').b64decode('S2FXVW5VS3cwTzhCMk95REtJamk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞхмИлэуф():
    if False and True:
        89
        pass
        _dead_1110 = 404
    value = 175083
    if 9 * 94 < 0:
        76
        _dead_9630 = 196
        980
    text = __import__('base64').b64decode('YlZ1Ukk0ejVPb3R6SXBqMWJ3UEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΜуймЗРΠΦпоб():
    value = 882533
    text = __import__('base64').b64decode('TDFuUGl4Wml1RGhaanA2eFRNeGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΣтХΣонΞβΘθРЗ():
    value = 800762
    if False and True:
        _dead_2766 = 14
        _dead_4311 = 326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERa1dgAc2awvEDyWzVCEYRMDwX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 76 * 87 < 0:
        919
        407
        pass
    return total

def _ОЛδΑыΔЯΛЦζΗ():
    if len('') > 0:
        pass
        698
        537
    value = 36452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bz22QwYhz65VMBmg6g+XAQE97jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 47 * 79 < 0:
        _dead_4793 = 738
    return total

def _δНУηсφтнεвΗ():
    value = 757506
    if len('') > 0:
        pass
        _dead_4939 = 235
    text = __import__('base64').b64decode('SlhHMHpXb0VLVHRiTGZYeU9iN3A=').decode('utf-8')
    if False and True:
        941
        124
    total = value + len(text)
    return total

def _иηΝΑАΧσδ():
    value = 243392
    if False and True:
        _dead_6893 = 432
    text = __import__('base64').b64decode('TWs3OE9Cd1B3eVhlaEp6R3dWYmo=').decode('utf-8')
    if 73 * 13 < 0:
        _dead_6962 = 123
    total = value + len(text)
    return total

def _ЕыЛλхχЖλвΡзφцογΑ():
    value = 31273
    text = __import__('base64').b64decode('UWJ2UEdMN0U5bEltc1VMYWc1VHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨЕигΩеζчАΣΜΝТψ():
    value = 593061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAr1Vkc1yIkzLSWy3mW6YHUlxz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЭЗьвΗΨΛеΥΧκаΠκπ():
    if len('') > 0:
        _dead_5970 = 792
    value = 216631
    text = __import__('base64').b64decode('eHNoSFFTOVo0TEl2bENCbE5haTk=').decode('utf-8')
    if 43 * 6 < 0:
        pass
        pass
        57
    total = value + len(text)
    return total

def _ψσωΟψгΣЮοбмθвЩГ():
    value = 367617
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBnOWl4QrrgWORyB32OKbC96sX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 89 * 49 < 0:
        _dead_6473 = 197
        _dead_7929 = 540
        pass
    return total

def _ОΡЫЙИъРΖБΜТγмъΥψ():
    value = 304892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQvKbF4jya0TDj/1mQCyZDca0Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жωΞΜξΧшΝΟΑ():
    value = 895556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR/USH4c/fkBCSSE7nvENgId/Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σξзпυъμωнηШмοζыю():
    value = 94434
    text = __import__('base64').b64decode('al9ScjZSYnJvc3FFZWdETFU1OTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ОЖвНяМфЛΙкЩΤмт():
    value = 404498
    text = __import__('base64').b64decode('dkYzTFZETndxTk5LTnBqN3hvajk=').decode('utf-8')
    total = value + len(text)
    return total

def _ςшΝγΥДхЙйчМΕσνΡ():
    value = 261910
    text = __import__('base64').b64decode('SjlRUVVxeldETzRxSjdVcU9PYWg=').decode('utf-8')
    total = value + len(text)
    if 1 * 33 < 0:
        pass
    return total

def _ΝΔрΨАΧПщι():
    value = 391204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj6zVmk6zPg1NQmoyn/DPHx/7Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νыэЩιВΞσЖη():
    if 47 * 18 < 0:
        662
    value = 25109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgLASmgyyZ5abBuC5F7JHhQJ41s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨκΟчзΨзяω():
    if False and True:
        845
        650
    value = 901671
    text = __import__('base64').b64decode('eGsxd3FMR3hVdlZkOXJPUFVaNGg=').decode('utf-8')
    if len('') > 0:
        798
    total = value + len(text)
    return total

def _ΔЯяШБЩλΜΒЫφ():
    value = 693822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAi1bX1h8a9UNyW70HrEPh8r1mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        29
    total = value + len(text)
    if False and True:
        pass
        _dead_3993 = 946
    return total

def _ΦсΛΙΝξйΤФщИΛγе():
    if len('') > 0:
        489
        789
        pass
    value = 785322
    text = __import__('base64').b64decode('QlF0emxpeDM4cjB4MmpveG11Vzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΔοГυΠΣЫγ():
    value = 533964
    text = __import__('base64').b64decode('VUJWMzR6R1Bac05CRWxkRTN2REQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5042 = 189
        237
    return total

def _ΛоБχВνфςψнγвΟЩ():
    value = 564093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERfSSHw097wFLT2h8We+bSka3no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аоπьΖΞеλЙ():
    value = 713442
    text = __import__('base64').b64decode('VERFWUExQjhvRmpjeGdHb21BaE8=').decode('utf-8')
    total = value + len(text)
    return total

def _χвгθΗкФъΤОяχаКΧЗ():
    if False and True:
        _dead_8190 = 568
        _dead_3221 = 352
    value = 763207
    if False and True:
        454
        _dead_9955 = 753
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix63TXJtqrETG1f1xAGJBTE862g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 38 * 70 < 0:
        _dead_8588 = 305
        472
    return total

def _ШξшβЖΡакεЛыΙ():
    value = 591561
    text = __import__('base64').b64decode('ZHpoZWoySHd6dEt0ZEtaRWcwOXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩсзщЧЭςфкζсМΣи():
    if len('') > 0:
        525
    value = 254694
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyPCSnNsyIBTKiyA7EaIGB8n93Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6148 = 679
    total = value + len(text)
    return total

def _ЙυФψШΝТГЭΚ():
    value = 76179
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBexWHAS8Js2Ng6g8kCREnQOy2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΠЩΙΕйуъеО():
    value = 199602
    if len('') > 0:
        974
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ez7yP24u9v4yAAC2/GzEFgIVsDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬμСЙμφςЪЛс():
    value = 296321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhzFe3Rr3Z8SPRqO7W7FbSY/0kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΩΙУΧАцΛθρзБщΝйΠ():
    if False and True:
        854
        _dead_9239 = 860
        pass
    value = 286753
    if len('') > 0:
        496
    text = __import__('base64').b64decode('RWtORjZpVjExRktXeDRheXZURVc=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_5667 = 606
    total = value + len(text)
    return total

def _οФδΞΤяοΩрΞц():
    value = 228914
    text = __import__('base64').b64decode('aFJtYlJfYVRlT2xLSTVGMTdLWkI=').decode('utf-8')
    if len('') > 0:
        504
        12
    total = value + len(text)
    return total

def _цρЧψнЫТюΨ():
    value = 434525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAXGbV4VzfAnNQyRzWavBHQp1Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мПеТмщΙψΞρ():
    value = 51614
    text = __import__('base64').b64decode('dng5NjJGNEdZdEQ2QmtTVHRtZFY=').decode('utf-8')
    total = value + len(text)
    return total

def _вυΩΦΟΞчθсКи():
    value = 535682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRb+Plpg251XEw2h2wa8DXwesl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оьθсиΚψΖцΔΝΘбЦд():
    if len('') > 0:
        365
        442
        pass
    value = 149615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgKwZWlq74tSHAybmwa6PCk95kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6629 = 903
        _dead_7241 = 160
    total = value + len(text)
    return total

def _вцсψЛэΑητΘГςοнΗо():
    value = 386098
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JySyQkUJ36M5OwOO+wa+JS15sGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΚγσξΘοбыеЛъΩΗшΩ():
    if len('') > 0:
        _dead_1627 = 421
    value = 226684
    text = __import__('base64').b64decode('YkRVeVBFRU9Ba3p2WTEyT2RDYkY=').decode('utf-8')
    total = value + len(text)
    return total

def _чΛьКГδЮщГъ():
    value = 826717
    text = __import__('base64').b64decode('clM5ZXhXUmY5RzlhV1Ztb1I3WVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЧТЭμДψЕИΧ():
    value = 737599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw31b1w+7o4SLlukzHWfDCt78Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6192 = 766
        _dead_4016 = 847
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _чυξаЫρЦКЕСщψτ():
    value = 102740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT3zRAI++7s2Lhz6x27FbXUdsXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λюЛФΓэκТΓςΔζγγΞ():
    value = 697636
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JivUbAY4r4EnCzya8A6qJS97zH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΙюσйΑьλРΕεбЩη():
    value = 577828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgzGdFY8/5AIHQyxy3S6Yi4s4Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йвЦЫφΞκАβκγлйыи():
    value = 768441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyXAZwYv648GHQuNkQ6IMAce6jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иеΖФΓΦΧиΤΖχΛτ():
    if 51 * 8 < 0:
        552
        pass
        _dead_9101 = 898
    value = 369175
    text = __import__('base64').b64decode('a3FMRk45ZEM0dWlCVkYzN0EzcTA=').decode('utf-8')
    total = value + len(text)
    return total

def _юΥаЕςатЧтаа():
    value = 486689
    text = __import__('base64').b64decode('Q2xocmMwOEkzWGRJbmhock1RYU8=').decode('utf-8')
    total = value + len(text)
    return total

def _хΥьЛεВыΥΕΖθчД():
    value = 425980
    if False and True:
        pass
        235
        _dead_2160 = 347
    text = __import__('base64').b64decode('cFJ0QnYxQjUzekU4S0FnWjFIV18=').decode('utf-8')
    total = value + len(text)
    if 44 * 17 < 0:
        pass
        pass
        303
    return total

def _ΤизТβЩΡΡΨθуωΝУВв():
    value = 952848
    text = __import__('base64').b64decode('cUJna0JtWFpUWkpkOGo0ZzY2R0g=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        410
    return total

def _фΖъМςЗχбЮ():
    value = 805187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTrWQFQP55wyOSv2/mW2HD9/3Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        208
        pass
    total = value + len(text)
    return total

def _рчЕЗγЖοчэοχТЬΒΙй():
    value = 961338
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHbLZwAd8JsNEBvy62mHG3Ym91E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 63 < 0:
        pass
        _dead_4448 = 225
    total = value + len(text)
    return total

def _рНючνФчкυьлΑξфзЬ():
    value = 853702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzewX0gb66MuFgaX2GTCGg4kxk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лПΤкΝθαЬλЧоЯ():
    if 89 * 53 < 0:
        _dead_5809 = 385
        73
    value = 120628
    if 16 * 36 < 0:
        pass
    text = __import__('base64').b64decode('R0FXRElBSWlPdFp3M3Uzdm5FR0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒэдΥЫζΥМЫ():
    if False and True:
        pass
        508
    value = 322573
    text = __import__('base64').b64decode('TGhETUN1SHhHN3N5ZG52NXNLXzc=').decode('utf-8')
    if False and True:
        _dead_2673 = 607
    total = value + len(text)
    return total

def _πщБυΟΨγтЬЪНΒРπΛ():
    if len('') > 0:
        pass
    value = 442669
    if 51 * 37 < 0:
        _dead_8028 = 357
        152
        pass
    text = __import__('base64').b64decode('Z2V3VzhFUndCRjd3UkZybjlsaEQ=').decode('utf-8')
    total = value + len(text)
    if 83 * 98 < 0:
        pass
        pass
        pass
    return total

def _сΨйεΒιΔьΘςΒ():
    if len('') > 0:
        _dead_4748 = 739
    value = 522882
    if False and True:
        pass
        798
        _dead_7998 = 630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCDOYAkj1qNVYzWH6gHBBnwss30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιΕзАБЫаςΖΗΚςУΝжΑ():
    if 38 * 81 < 0:
        900
        pass
        pass
    value = 324499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQTjSFhh34QRIFmG6lizHxYG00I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТιсψЩΠΧвПфФЯΩ():
    value = 774014
    if False and True:
        _dead_8653 = 311
    text = __import__('base64').b64decode('bVRtNEQ4NXdMS2hOV0JOSWFydXY=').decode('utf-8')
    total = value + len(text)
    return total

def _щΡΟхοφТΨ():
    value = 191660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQi3bW5q+4MxCFyg31SlNxF5zF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТыОГУжИκЧ():
    value = 875362
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQi3P25g2L5XKw6n3GGxLh8WwFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡхδЕνИΣГζ():
    value = 549528
    text = __import__('base64').b64decode('cVRfSEtsUXR2Rl9Cd29wT0x1ajQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΩΦΖфАяζЧΘЛΛε():
    value = 99576
    text = __import__('base64').b64decode('S2tua0kxZnNzWjI2dk94VFB2Y1g=').decode('utf-8')
    total = value + len(text)
    return total

def _εζЬЗсуДзАюРΗ():
    value = 699293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCriXGMK2I4rDC2Ky3CSNi0/3Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γиΖΧхЩσρΩΑерΑ():
    value = 467555
    text = __import__('base64').b64decode('RXlNNVQ5TVJPMllqY3RmQ0I5b1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟαГμΚМъцИωΖиΛХЛι():
    value = 518890
    text = __import__('base64').b64decode('dmNTU1RUNmRQMHlWUlp6SEppTmU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_4397 = 200
        777
    return total

def _ЕφιрПехθΝъι():
    value = 112101
    text = __import__('base64').b64decode('THdyTXI2UlM5eUZUX1dvZHdFYkI=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _αЯПуωИЛчΦμОЯЩοщЛ():
    value = 999798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCvbXGEb/6c5bT/77FKFAQEc40M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΣзТΒΡΟФАυΩςΝтЦЖ():
    if len('') > 0:
        500
        pass
    value = 159872
    if 91 * 68 < 0:
        pass
        774
        _dead_5158 = 640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By21YXM/0osGHTmQ0mShMykF9EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тяцШДоэЩучьЫ():
    if len('') > 0:
        pass
    value = 236932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwbwOn1v848zDl6E7FCWHS4DwEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УлЬΑЫнσξвπшпаΚΗП():
    value = 87803
    if 89 * 43 < 0:
        pass
        _dead_4879 = 804
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAPVW0Ip5oBUYz+G4nC3Hywk6X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 49 * 29 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ΘЙΩТъфНмγфСЯЦЙЙ():
    if len('') > 0:
        _dead_6282 = 601
    value = 722758
    text = __import__('base64').b64decode('cXhsem5EQzZWM3RlbHZRenZqV28=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘСВуΤγсТΑΝθ():
    value = 601666
    text = __import__('base64').b64decode('ZWt4M3piUnlhdHhlQlFWN1dCbVg=').decode('utf-8')
    total = value + len(text)
    return total

def _νпЗоΡГβчΤΨχι():
    value = 194722
    if 32 * 16 < 0:
        337
        _dead_5053 = 32
        pass
    text = __import__('base64').b64decode('WHY1cmVickdudHpjaGE0NjR5OXA=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        399
        _dead_4304 = 438
    return total

def _ьΟΤΝκχΓотΓ():
    value = 952182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDy1SUBs0KIFGQuEx1iYMD8gz18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _этИйμЪгтрΒкчΙ():
    if False and True:
        pass
        _dead_2578 = 207
    value = 654582
    if len('') > 0:
        _dead_8142 = 475
        _dead_2475 = 5
        140
    text = __import__('base64').b64decode('RURjRzg4Yjg4amd2dlFfT1hCN0c=').decode('utf-8')
    if 6 * 70 < 0:
        _dead_9060 = 592
        pass
        pass
    total = value + len(text)
    return total

def _υξΨΞкшкσωэΔайηΝО():
    value = 579406
    text = __import__('base64').b64decode('S1Z0blFsQUlsV2RCbEREVTBmX0Q=').decode('utf-8')
    total = value + len(text)
    if False and True:
        650
        pass
        _dead_4957 = 507
    return total

def _еЩκΘэяБΛ():
    value = 638106
    text = __import__('base64').b64decode('STltbTB1eGpnRTNjYkk4OXNIaDg=').decode('utf-8')
    total = value + len(text)
    return total

def _СφΨιλщЭΟэД():
    value = 628417
    text = __import__('base64').b64decode('YzFhYW5JYVNQSDBZSlRqS2gwVUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΑЬРδπΙΨоиς():
    value = 697306
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('UTM2QTNjYng5dmhHY2NZN05CbnQ=').decode('utf-8')
    total = value + len(text)
    if 46 * 3 < 0:
        15
        _dead_1625 = 156
    return total

def _υХюрζжΤυЬВЙ():
    value = 187488
    text = __import__('base64').b64decode('dE85WUtwamZZQXhVRjc2MXBXOW4=').decode('utf-8')
    total = value + len(text)
    return total

def _фЪβлΕΗяЭΗЬопдЗ():
    value = 3130
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('QWlhZmNzNzBybWV4X2ZLQ29Id3o=').decode('utf-8')
    if False and True:
        809
    total = value + len(text)
    return total

def _βоЖЩΔБΒλБбТ():
    if len('') > 0:
        762
    value = 926782
    if 61 * 6 < 0:
        pass
        _dead_5322 = 875
    text = __import__('base64').b64decode('a2RValNTU05MYmVJaDcxWnRLZjA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7480 = 466
        pass
    return total

def _НэрЪеΣНяцΑ():
    value = 594407
    text = __import__('base64').b64decode('cm9TWGxTZ1dBamYyUVdHMlV3RkM=').decode('utf-8')
    total = value + len(text)
    return total

def _βМωЦцτмкУζЮ():
    value = 923864
    text = __import__('base64').b64decode('bldLN0J3YzhEUmJhWnk2ZkpFenI=').decode('utf-8')
    total = value + len(text)
    return total

def _уβψрΩσΕφΩьЬΥωя():
    value = 942160
    text = __import__('base64').b64decode('djRZbXRBVEpkT3NnTEEyRUNSNms=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΑТΡЙγжΑХКВ():
    value = 974842
    text = __import__('base64').b64decode('aG9rRUYwY1I1WWUwb2JZY1ozVkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _фλаΖΠΒОοЪ():
    if False and True:
        _dead_3499 = 86
    value = 316011
    if len('') > 0:
        _dead_5838 = 840
        _dead_4178 = 141
    text = __import__('base64').b64decode('ZUZuMWUwRXk5NW1aMUVWbmQwcFU=').decode('utf-8')
    if False and True:
        47
        894
    total = value + len(text)
    if False and True:
        905
        _dead_9507 = 736
        _dead_6741 = 522
    return total

def _τйщйΑΡηιΚΑэ():
    value = 482536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzjnUVQz8PwrCwyQn0GnAXEVx3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УВηкшΒΞе():
    if 39 * 39 < 0:
        pass
        _dead_9504 = 781
    value = 820652
    if 78 * 66 < 0:
        _dead_1782 = 348
        703
        _dead_6354 = 181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQXSaQgc9oUXLAy55WO/GTwN7m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 60 < 0:
        pass
        _dead_2832 = 580
        _dead_1376 = 860
    return total

def _ПЛБТεΨηТσνθ():
    value = 651428
    text = __import__('base64').b64decode('YTA4bmZRaEhNQ2hNY2MzdzRNc1Y=').decode('utf-8')
    if 65 * 33 < 0:
        333
        _dead_6080 = 825
    total = value + len(text)
    return total

def _ΚΖςСиοОπЩΤЗηπй():
    value = 267003
    text = __import__('base64').b64decode('SDRTREVuaVo5d3NhSlNGTXBTenc=').decode('utf-8')
    if False and True:
        _dead_6565 = 180
        682
    total = value + len(text)
    if 49 * 68 < 0:
        787
        pass
    return total

def _νθЭΡΦλψфПКηЙμιεΞ():
    if len('') > 0:
        pass
        pass
        _dead_9455 = 99
    value = 321547
    if len('') > 0:
        280
    text = __import__('base64').b64decode('a0R6OVBLZmRsT2RlalNZMl9IYkY=').decode('utf-8')
    if 50 * 99 < 0:
        pass
    total = value + len(text)
    return total

def _εжоКрЭΨШ():
    value = 559385
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KADlancj3Z4uFCeh5GK/GyMMzmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шБβфеΟэуС():
    value = 250375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ew7UfQBp24FQOyWq5FOiFQl663k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥИьξихηΒазυсиЬэ():
    if 11 * 98 < 0:
        269
    value = 645417
    text = __import__('base64').b64decode('WHJxSEJxOWZYYkpXZXBENFVRMmw=').decode('utf-8')
    total = value + len(text)
    if 36 * 91 < 0:
        pass
        416
        _dead_6268 = 653
    return total

def _чюиβэчжшдмяΠΝхΒ():
    if 59 * 66 < 0:
        pass
        181
        697
    value = 87566
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('cU1ZNU1sUnFtaGgyUkdScHFjM24=').decode('utf-8')
    total = value + len(text)
    if 70 * 40 < 0:
        _dead_8436 = 261
        597
    return total

def _ΘδйпАцВη():
    value = 125257
    text = __import__('base64').b64decode('dGowbkJKd1JUNXhJVTdXS0pyMWg=').decode('utf-8')
    total = value + len(text)
    return total

def _КбОΗБЛКНПъΞ():
    value = 803995
    text = __import__('base64').b64decode('TmE5enIyYUdVNDBMZGhIWHRCRTQ=').decode('utf-8')
    if len('') > 0:
        772
        432
        _dead_9802 = 751
    total = value + len(text)
    return total

def _ζρωЩΘрзБъпμпкддδ():
    value = 166146
    if 7 * 67 < 0:
        778
        pass
    text = __import__('base64').b64decode('c3pJYXREU3g3YVU4NFNGekt4SXE=').decode('utf-8')
    total = value + len(text)
    return total

def _гεБНωИπΧσ():
    if len('') > 0:
        _dead_6194 = 601
        221
        pass
    value = 356765
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhnSNl0L6KRbLzqSkGavYTAl3WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        719
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΓσяаΘйωсьН():
    value = 591597
    if len('') > 0:
        pass
        _dead_3542 = 532
    text = __import__('base64').b64decode('YkZtWEp3RHM2NDdhalNVeFBRcWQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ζΥгхЬиΑСΠ():
    value = 762779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQnbXGlvwYYgCFit7U/JYjcK5zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1145 = 841
        _dead_3388 = 314
    total = value + len(text)
    return total

def _ΚΥνзχЗιрΚΗР():
    if 51 * 76 < 0:
        182
        _dead_3428 = 991
        pass
    value = 886831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCiyaWIA0rg8HzeU2HGHBRo87GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯУфщБЖφЗлоБюΡ():
    value = 369572
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRrlSmVs56cpPQX1/HG7GSgqvV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЧΓШНμΚΣшхλμΨЕ():
    if False and True:
        _dead_9573 = 8
        _dead_7975 = 266
        pass
    value = 231304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyTDSQVpxI4OECOi+XSZEgkLtzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωВτэσЫЗπΡГХΣτ():
    if False and True:
        230
    value = 75397
    text = __import__('base64').b64decode('UmpMVV80cERMbTFNMzAyYTdJSXE=').decode('utf-8')
    total = value + len(text)
    if 69 * 47 < 0:
        303
    return total

def _ΞΣΛНΟФЪΣОπЛΨΑΑгИ():
    if 7 * 61 < 0:
        _dead_8901 = 154
        217
    value = 123478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISLOQUk8yJI3Hxu653WSIHUhtUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φДΤэЙДНуэЧ():
    if False and True:
        _dead_8064 = 911
        85
        537
    value = 733740
    text = __import__('base64').b64decode('Rzd6ajFCVmVrNlN2Rllka3B0RVc=').decode('utf-8')
    if 93 * 30 < 0:
        789
    total = value + len(text)
    return total

def _ЯйΤΡХрЦΛρΚкξ():
    if False and True:
        pass
        pass
    value = 334043
    if False and True:
        _dead_1597 = 76
    text = __import__('base64').b64decode('cldMYllaVkFKQTFzMHFPM1ZZNHM=').decode('utf-8')
    if len('') > 0:
        _dead_1702 = 47
        _dead_3470 = 772
        _dead_2482 = 409
    total = value + len(text)
    return total

def _ρЪуТΞХЛβюУжрπω():
    if False and True:
        _dead_4134 = 122
        77
        354
    value = 27384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXrSQEkQ/YUVHl6u8HeTBHYl82c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςкτСРΓοΦν():
    value = 914359
    text = __import__('base64').b64decode('UXh4cGVNQkdlXzV1RzBpZkVjeko=').decode('utf-8')
    total = value + len(text)
    return total

def _ыνΟΜаШРуμфжЗкЦИΘ():
    if False and True:
        342
    value = 721055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiXIQAVu5qszOyqmnHedOjEdxUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        189
        _dead_9630 = 881
    total = value + len(text)
    return total

def _ΦглΖВБЙΔЭ():
    value = 772146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwHXZ1wQ/I07PFb6+0SbPBx+/VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дδοоЭαБХδЗ():
    value = 721283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiXUb0UVqqQUCSCu6QamY3Ij4W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РψΙξЖΡЗΔАйЖьζςι():
    value = 84690
    text = __import__('base64').b64decode('dW9xZk9pQUNkSGtNOHN3eEJwSGs=').decode('utf-8')
    total = value + len(text)
    return total

def _пДΠΑΧУξЕΛчλлуЯ():
    value = 357009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSDORFIyyKQ5DB+ZnlKDMyIZ0V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2758 = 708
    return total

def _нφКΨΟУЬτБъΒΘνпЬΤ():
    value = 413088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwKzPghvqf4wESHznAfBJCMZ6nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5577 = 830
    return total

def _ΗРНИяБоΘтжФΕКфщМ():
    value = 308664
    if False and True:
        pass
        _dead_9296 = 221
        _dead_7540 = 597
    text = __import__('base64').b64decode('Yk41VjF0MnI2ZUwzZUVIbV9Va1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΕΟхяΘаΥЭΒΡи():
    value = 644528
    if False and True:
        pass
    text = __import__('base64').b64decode('RUJzUDlXU1ZGQ2dab043TE5uV2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞйΕугмΜΜМжΩ():
    value = 575806
    if 86 * 14 < 0:
        pass
    text = __import__('base64').b64decode('a2xqZkRzM3NCd2xkS3MxYUxkaGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒκМшРξΗΥц():
    value = 941034
    text = __import__('base64').b64decode('c00wUHg5SWRyblo3Mlg2OGpsMnE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2723 = 825
        pass
    return total

def _ъρТуτиμфИЮЕт():
    value = 14651
    if 59 * 32 < 0:
        pass
        924
    text = __import__('base64').b64decode('dEtPdUplUldfdDFvTUphYlNOZUU=').decode('utf-8')
    if False and True:
        _dead_9560 = 370
    total = value + len(text)
    if 50 * 8 < 0:
        709
        pass
    return total

def _ЕйΑАτσυξДокςΓ():
    if False and True:
        130
        939
    value = 833997
    if 49 * 16 < 0:
        807
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCq3QkAY36U0awa1wgXFNQx7/kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 41 * 46 < 0:
        pass
    return total

def _сыъΞхнскΘβΧщ():
    value = 582812
    text = __import__('base64').b64decode('RWI1QWJGVEMzeUpBeE8xQUttenQ=').decode('utf-8')
    if 56 * 27 < 0:
        674
        565
        707
    total = value + len(text)
    return total

def _жЕΝУΗцаъН():
    value = 376310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgrJeVNqzbkpMSeB+QKlPnA95V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨαждгρВцющ():
    value = 654752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxjbR0k71JIyHxut+XipHR8C9Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΕξИУДЖПΖβИйТфΓГ():
    value = 632661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('My7BWWVrxLsQPF6b/1m1YAkf/nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΘκбоιЪХΛλσξγГΤΚ():
    if False and True:
        _dead_6537 = 990
    value = 148635
    if False and True:
        874
        465
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXvtXmYX/KMnLTry8Hu6PTQgt00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 91 * 7 < 0:
        644
        pass
        971
    total = value + len(text)
    if False and True:
        262
        _dead_8024 = 573
        _dead_6897 = 466
    return total

def _υэΞОТяищРТ():
    if len('') > 0:
        _dead_8043 = 207
        _dead_7107 = 708
        _dead_3960 = 709
    value = 18030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iy3LVAU125oMbyWwxQXEJgQq5k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        423
        936
    return total

def _ξгΗаъхΑЭгаβЙШ():
    value = 819887
    text = __import__('base64').b64decode('STVydzBfRHdhZFJSWnhMMjI4TFE=').decode('utf-8')
    if False and True:
        _dead_6731 = 949
        _dead_1696 = 35
    total = value + len(text)
    return total

def _лδлЭΒяЯЙдΧχлвχШ():
    value = 571868
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiPPXkQU+LEKKzic8mSDbA1+9VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΧΓгεщКрАΔЩ():
    value = 177735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHf0Zloe8qRUGVarkFedDSkftlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        100
        pass
        _dead_1462 = 774
    total = value + len(text)
    return total

def _ΙеαατΕмχРΛщ():
    value = 225129
    text = __import__('base64').b64decode('aHdyVmJmMl9sSm9kNGR4R2tEOGc=').decode('utf-8')
    total = value + len(text)
    return total

def _δтдМЮμφΩХΓэΓЯνУг():
    value = 616214
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwbuYnowp6YyDAuo+1+SLQ0Xy3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φθΠьησЫхнυт():
    value = 420159
    if len('') > 0:
        _dead_9692 = 494
        191
    text = __import__('base64').b64decode('THdqX2IzMmhXaTNqb0k1UkpVQ1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗйбΡЮφЗхШΜжЪτδι():
    value = 592248
    text = __import__('base64').b64decode('T1BrOTl1OVphaGJGYlVFa0o3TEU=').decode('utf-8')
    total = value + len(text)
    return total

def _πьфΕтЬАβ():
    value = 194179
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IH71RFQg3I1Rax2PnW+FbD0/0Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΑΛπγΠюцБдβАσлыЬ():
    value = 881880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnrBW3A75vkFCieF4WGmGjct9lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙСтТδΣрΗАГξЩтΙиЮ():
    value = 329512
    text = __import__('base64').b64decode('YTBwNGc4NHJMZ0RGN0tfQjJaSW4=').decode('utf-8')
    if len('') > 0:
        609
        pass
        _dead_5942 = 26
    total = value + len(text)
    return total

def _ΤΧюΤγΨΞцмΖΗыЬθШЫ():
    value = 915352
    if 75 * 78 < 0:
        _dead_9178 = 554
        353
        _dead_5676 = 505
    text = __import__('base64').b64decode('VjhQejJzekw5TlBJcTJUNldfX1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _жЩоΑΑюыЗНνыΚΠε():
    value = 14027
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAbOaFc30LkaMAGwwgSAJid98nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζсψлθсξΔπ():
    value = 770629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCHSfgNv2b4NbVqz7HOIESgrxT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХИσΓχυЛРςΝфЗ():
    value = 793999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj38a2If7/0GFQiAwUOGEQ49sHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δеηςбСУЕфът():
    if False and True:
        pass
        565
        54
    value = 981617
    text = __import__('base64').b64decode('dXZHelVGSnV0RkxBb0FMdFdjWUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔювΟшЮуεэ():
    value = 585534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAvbWFsRx5orKwu33XWXIiMG/Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 17 < 0:
        _dead_6377 = 809
        _dead_8995 = 597
    total = value + len(text)
    return total

def _ΒνпδмΕΜОΤΘСο():
    value = 253295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHv9Y2AJ1b0rbBWF/UeFAAEN83s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡЯйΡЩЫеζРцЭΠФАδр():
    value = 362444
    text = __import__('base64').b64decode('blVwRXlscmNfVGJXU1hpTTA2NWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓωХчυΑκЙТ():
    value = 474179
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECbbXnUD67g8CyWv6ke7AAIgzn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 38 < 0:
        _dead_8392 = 110
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5149 = 876
    return total

def _ΕаГΦУпЕънΟзИΡρфЖ():
    value = 26930
    text = __import__('base64').b64decode('eDRzS04yYmpndXdjcVQxeTRyRk0=').decode('utf-8')
    total = value + len(text)
    return total

def _СξκτЛΧЮΦυпХжΠЬ():
    if False and True:
        pass
        pass
        pass
    value = 458472
    text = __import__('base64').b64decode('UEZzNDA1TUFsVWh1MTRTbWxJMm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘБСωΛЮθνΤФп():
    value = 809026
    text = __import__('base64').b64decode('Uk1GUkw2NnhVUmNVZFhOTFhyV0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΨруПсΗпЯ():
    value = 438899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTzJZm485rIIbyz30F65Bix+vU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чжЦΝЩАГИ():
    value = 908218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTbeQ2IqyJwMbVu50XSXHAoiymU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лэαΠДψтΤУΣΡЪ():
    value = 94161
    if len('') > 0:
        65
        915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQPXdAI4r/hVaVr24kS3ARA+w1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΤбЦдонθМ():
    value = 53465
    text = __import__('base64').b64decode('TmJWNXlib0lPeVIycVFYejZCVTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΓЯΚТАΘжθЖΖΡШΛ():
    value = 623412
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InbCQ24Q9Z4QLx6GmFG5ODAN6T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΚиΗκжφζνЭ():
    value = 535890
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cwa1YH0+zJkzFV760kKBOjUQ0m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΞЬΝζΖИζиκЫмдφЙ():
    value = 751520
    text = __import__('base64').b64decode('VXZfN1ZOXzB3R2NOeUR5R2lUeVM=').decode('utf-8')
    total = value + len(text)
    return total

def _δтяЦнЬΩΚ():
    value = 673868
    text = __import__('base64').b64decode('WkhSYXNENHhRa091b0p2MXNiSzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if len('x') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()