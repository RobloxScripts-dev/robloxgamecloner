#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _εμΟЕΘИμгαУяΞЗ():
    value = 369928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jjj+fEto+p0NChuPxg/IExUgyGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΟЖИлаыНЭ():
    value = 419218
    if False and True:
        pass
        _dead_3334 = 864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzXMVHgg0/wPHTfwzFSFDjc59nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3978 = 139
        _dead_7192 = 777
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_4733 = 859
    return total

def _цЬПΡАМЪщκСЩΔΩНΧξ():
    if 66 * 71 < 0:
        737
    value = 972489
    if False and True:
        pass
        314
    text = __import__('base64').b64decode('ZUpMZk5sUWhLZVRYMGE0VFM5Y1U=').decode('utf-8')
    total = value + len(text)
    return total

def _лйΙаЫППуβБВцδ():
    if False and True:
        471
    value = 480749
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRbqfHA1yKoIOAC3nWmmIwQNtl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕГЬСуУΔκιЙΒηю():
    value = 209456
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhfJXnotxrgbESKk4QDGMXEn1jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 88 * 29 < 0:
        _dead_6780 = 683
        _dead_8936 = 949
    total = value + len(text)
    if False and True:
        409
        _dead_4791 = 157
    return total

def _ХΟЕсДЦпф():
    value = 86257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxnXZV8TyYwCMzik3AOJEw478TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Цυρωьρσь():
    value = 233727
    text = __import__('base64').b64decode('WDdVTjBqRUE3eWgxVUg3MHNBSnI=').decode('utf-8')
    total = value + len(text)
    if 69 * 74 < 0:
        pass
        pass
        433
    return total

def _дТвГςΣъΡ():
    value = 161335
    text = __import__('base64').b64decode('bXZDeVdXTl90VVRjcVpEelJ0Qnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΚпЪэЙΛχЛλ():
    value = 208949
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cxi1O3AD+KINbl2E0H+WHTZ23no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΕЦЖΤΒΒдкт():
    value = 175918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADWyVwcX3f81DAWc71y/FiIm3D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 58 < 0:
        _dead_4945 = 500
        pass
    total = value + len(text)
    if 7 * 75 < 0:
        pass
        _dead_3176 = 932
        pass
    return total

def _паГГΡΩτъ():
    value = 621518
    text = __import__('base64').b64decode('Z2pIU0RMNE9KbkZlZDJNMm42OWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΑлдψΜкШΗτΛх():
    value = 296467
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LT3Leno0p50uAAK0432lIicr1Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        261
    return total

def _блνΦЗψвφЖΓоУ():
    if 50 * 36 < 0:
        pass
        pass
    value = 165874
    text = __import__('base64').b64decode('czdMcWV5Y3pOZ3VrOEY3VFhwSHQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5726 = 862
        860
        146
    return total

def _эΕмαцЕшΕΠΧΣЫΚшИа():
    value = 321086
    text = __import__('base64').b64decode('dmVnNnVDUnVsTVBGam9OZTBMaWM=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΙрТРлДοΠ():
    value = 20181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhjWTAQ21rAsEiT7xHukYjcuzzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘшΚψωσъΦΒΖпЫа():
    value = 878398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDX8XUArrY1VMjyCwXSaZx0NwkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦэЛρГкβΙоюυшс():
    value = 388804
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARD2ZHtt94AgLyWNw32CBTEf0Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΥΟщйΤСκ():
    value = 778737
    if 89 * 99 < 0:
        882
    text = __import__('base64').b64decode('aVJodkZLV2R2UFZwZWRTY2E2aFc=').decode('utf-8')
    total = value + len(text)
    return total

def _иλМВΟшωДοхοιΜιе():
    value = 417089
    if 89 * 11 < 0:
        _dead_1822 = 478
        _dead_8778 = 524
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyLAOFQU944UbiWr7Wm/IXwn1mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΛуДЩхμд():
    value = 767291
    text = __import__('base64').b64decode('dU9KWEt1RWNwNjBPWEVobURnTlQ=').decode('utf-8')
    if False and True:
        407
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΟοюγοЛбιαгЖνπЙ():
    value = 357434
    text = __import__('base64').b64decode('aXh3RVFIak44WGtUTzVyZkt6NWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ъДδγψΣλРя():
    if False and True:
        pass
        577
    value = 733750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgDtYFUj1Y4RLQOJ7XmTBCYI8z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮщЙгΚЬΩЙΚЬд():
    value = 265049
    if 56 * 35 < 0:
        _dead_9777 = 444
        873
    text = __import__('base64').b64decode('cVdaM1kyNnROSElBUGo4TWxFV1Y=').decode('utf-8')
    if len('') > 0:
        285
        _dead_4558 = 45
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_9190 = 999
    return total

def _РкΒσгДШЧΒкψфΦЗГ():
    value = 384409
    text = __import__('base64').b64decode('SzVWSFJSWXQ4cEFHY3kxSk5WaWQ=').decode('utf-8')
    if 66 * 100 < 0:
        pass
    total = value + len(text)
    return total

def _сςэДΕыГτсиЬр():
    value = 485905
    if len('') > 0:
        218
    text = __import__('base64').b64decode('RUQ3NEx3dlM2bTF3b2t4eWxnM2U=').decode('utf-8')
    if False and True:
        pass
        _dead_5488 = 992
    total = value + len(text)
    if len('') > 0:
        270
        _dead_2359 = 443
        399
    return total

def _χνохщΚЙΜ():
    if len('') > 0:
        956
    value = 697328
    text = __import__('base64').b64decode('bVhrRmltTDdoRHhVanV1S1A3ZHI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        41
        _dead_2819 = 363
        129
    return total

def _βКсεыενбЧψиьэШт():
    value = 337817
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAvPSWNqqZoqDBXy0HO4JTAq6mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΑзЯΞеБМΘ():
    if False and True:
        pass
    value = 243945
    text = __import__('base64').b64decode('QUFnYkI5cERUMlNqV2l1eEZKT1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΧбъΕшЫЮσ():
    if False and True:
        516
        _dead_1332 = 274
        692
    value = 375212
    if False and True:
        47
        275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzzeS0YP5L4baRa131PBZwF3yGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5925 = 491
        _dead_4209 = 140
    return total

def _ΣИрυлοΠΚпДΛЛС():
    if len('') > 0:
        pass
    value = 487554
    if False and True:
        749
        407
    text = __import__('base64').b64decode('d1dZcVhPNkFVTHZiOTg3U1dPaks=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧэщтОТьωргЛΙ():
    value = 714095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ew3LZFshppwSAz7w50HBOnwd6Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨωЩфμΧχм():
    value = 977693
    text = __import__('base64').b64decode('bDZSZjQxY3JCS21GRVRHTTlraFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩαЖΨвρΚьΑбФ():
    value = 255680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyzXamgNp4QwCF373QK2ORcbsXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лЙΝВъАЪуЗΔюНШУЗ():
    value = 364370
    text = __import__('base64').b64decode('b1ZzSnRTMlBJaVI1alpZVGQ5SmU=').decode('utf-8')
    total = value + len(text)
    return total

def _χπΤжЕгΓсъажθ():
    if 22 * 39 < 0:
        pass
    value = 804325
    text = __import__('base64').b64decode('WlRhcjBmVnJ3dWtXSjVSZkxQVWI=').decode('utf-8')
    total = value + len(text)
    return total

def _БхΘЙςЙΜУτТ():
    value = 576734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQK0XgZsqKoONlv1w2G4OhV37Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОпсцЧΑхΔΟιА():
    value = 728794
    if False and True:
        _dead_7263 = 644
        pass
        pass
    text = __import__('base64').b64decode('R1FNUGpMYkIwV1hyZVAxSHZWWks=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑЗΖУΦБпИ():
    if 38 * 83 < 0:
        pass
        106
    value = 417212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyPbX2Ug+KAaOVyonle4YggB3UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УдУΒЛΑφυΚ():
    value = 247629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQu8XlYe7qIJHyXy7gK/JjwOwlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФъΩкЖЬЛрΙС():
    value = 15732
    text = __import__('base64').b64decode('YmRpUlZ2NkRHbVBwYnNVeURCS3A=').decode('utf-8')
    total = value + len(text)
    return total

def _эδφΝσчΜΤъΤБП():
    value = 264163
    text = __import__('base64').b64decode('bkFUMHZISGVQUzZ3bWExQTlaUVQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        96
        _dead_5676 = 421
        _dead_9295 = 213
    return total

def _ЦμюβΖЕφтПНЬзХЦπП():
    value = 391506
    if len('') > 0:
        pass
        987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwbIREk7yKJbOAPy90OgIB036Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯЖΞрЮгНаΔЩБφςфКп():
    if len('') > 0:
        pass
        649
        575
    value = 572065
    if False and True:
        576
        _dead_8828 = 693
    text = __import__('base64').b64decode('WWFZTjNXSWJMUTBhaWUxc1BDbHM=').decode('utf-8')
    if len('') > 0:
        825
        _dead_9039 = 556
    total = value + len(text)
    return total

def _ΨαοοιΛεξιщΒВМ():
    value = 785690
    text = __import__('base64').b64decode('TldSUENEUVl5cVA5amxiVERTa0M=').decode('utf-8')
    total = value + len(text)
    return total

def _οΦйφΗлηоη():
    value = 835302
    text = __import__('base64').b64decode('ZVZnY3ZiczdlNjB5UU1BVGtmTUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩеΑюδХзГΜчгР():
    if 78 * 2 < 0:
        pass
        596
    value = 86343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HALHY0Qe3/gVDiaKwnHDC3UdtEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦγуΘδΒΝЧоэЧ():
    value = 924659
    if 80 * 40 < 0:
        523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyDcSGE0+Js1HSn35V+YJSYGxUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДλησЖСΤВытж():
    value = 693061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C33xeWEd8qA8HAOX7W7AOCIZ5kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛнζЧωАНтДйΦλбВ():
    value = 716900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyHWQXc2x7wzAlaR7Xq4OicDxzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΛΠΩΦиЯВΖΟгэΥм():
    if len('') > 0:
        pass
        pass
        _dead_6531 = 949
    value = 488181
    if False and True:
        pass
    text = __import__('base64').b64decode('djN1Qm1MSGFqeEN6QnJCbjRtM1I=').decode('utf-8')
    total = value + len(text)
    if 22 * 48 < 0:
        pass
        pass
        pass
    return total

def _νσсκШΥЩпПΑэ():
    value = 902588
    text = __import__('base64').b64decode('Y3F0OTNDY1ZCWGR5WGs0cXlpVEE=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_3327 = 344
        _dead_8177 = 372
    total = value + len(text)
    return total

def _ЯΣрβζχСχΑβФцΞНа():
    if 62 * 49 < 0:
        _dead_1825 = 143
    value = 489772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwD2UQkD5odbPj+5nWCaIzUKzUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξγИюΝςυФбιΗαгМψψ():
    value = 245501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjbOfnlp2Z8nHwa1mFKqGXAL/H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уХшκБОгтсΕбл():
    if False and True:
        779
        pass
        _dead_5934 = 618
    value = 344347
    if len('') > 0:
        778
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAPLWQhh0fo7aA2PzX2BIgo+3j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 42 * 87 < 0:
        pass
    return total

def _ДеνИλΝлИбυΨ():
    value = 745021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fh3hPFUf55wHLTX1x1TAM3cqs08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΧЩЕьЫхДФνХ():
    if 39 * 30 < 0:
        _dead_2622 = 235
    value = 581338
    if len('') > 0:
        pass
        901
        68
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjrCPXIy/7gqNCeJx07DEiwByno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        720
        pass
        _dead_3674 = 719
    return total

def _σΠщПЦьоъцЩщгйф():
    value = 727048
    text = __import__('base64').b64decode('dXN6MFNRMHRkckNna0Z4eG1NZE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ДхΝΩоШлеΜщΘκαуΘН():
    value = 925745
    text = __import__('base64').b64decode('QkhrNXRYRkZOeVJRa0xLSlRzWmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛьκпКфГТΞз():
    value = 386944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng3FOXQw7Pk2CxeN92ynBHR3w3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТвαьΜЕΘЫΡЕ():
    value = 992773
    if 90 * 60 < 0:
        896
    text = __import__('base64').b64decode('VkZ6VlNwZGM4MHAxdVZOd01ycjY=').decode('utf-8')
    if 71 * 52 < 0:
        379
        pass
    total = value + len(text)
    return total

def _ВΡцмХφйгΑ():
    value = 641287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K37rNlQO9olQGzir3nGmBQwAtn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝщρэШτΑжΤΖ():
    value = 889949
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CD3zeUE3r5IRbzWp3G+UHAkd3Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3164 = 983
        _dead_5477 = 221
        pass
    total = value + len(text)
    return total

def _ΟкДΕАΞВтцЗΞ():
    value = 565179
    if len('') > 0:
        341
    text = __import__('base64').b64decode('bGVlOEtBNW5SQ3pkV2NrSUtqYzc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        474
        830
        pass
    return total

def _ЫзПχΒВΑλРяЬвπ():
    value = 259713
    text = __import__('base64').b64decode('VXg3TXZpMjFSZUdoRWNrSHlpVjM=').decode('utf-8')
    total = value + len(text)
    return total

def _нΛЫΙэαΥЩΖКтΙУ():
    value = 510544
    if False and True:
        204
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR3nVH4fz5cnOV2ynAOmGiwF/kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ьυЬтιηΕфцΤяЫχΟ():
    value = 369702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTjgX0Bh2K4IaACknGGSFzV7z1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОυБЭежζΚΗнΕ():
    value = 345566
    text = __import__('base64').b64decode('WmlNSVB4bFFRWXBPWUhLS2lCeGo=').decode('utf-8')
    if False and True:
        pass
        777
        _dead_3701 = 217
    total = value + len(text)
    return total

def _ЯкЦпЬиВΚΓЖАуΓ():
    value = 584642
    text = __import__('base64').b64decode('U0lyMVNEaGtOeW55RFFmTmI5Rjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЗΖЯΝбзγРйΞЖ():
    value = 580151
    text = __import__('base64').b64decode('dzkzc3NRRTJ4bl9CWjFHS2lYd2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΒΧιЭЪΔыЛ():
    value = 390366
    text = __import__('base64').b64decode('b1poVFc3Z192RUtvSTdBUzFLTlI=').decode('utf-8')
    total = value + len(text)
    return total

def _пЫιυΦлУщ():
    value = 517139
    text = __import__('base64').b64decode('cElsNkpvZGI2bVNaX3BPUExSU04=').decode('utf-8')
    total = value + len(text)
    return total

def _δЧДЬуЕπφШ():
    value = 361378
    if 15 * 27 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHf3YXkw5vAWGCyP4gKTNh8Z1Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гИσαгΔωΒЬъърΕ():
    value = 348908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDjzeWMyz6ZQOxqtylqUPnQpzz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 32 < 0:
        pass
    total = value + len(text)
    return total

def _χАΒΔΜψСУРбγЬЬе():
    value = 803361
    text = __import__('base64').b64decode('SEI3ZUt0RERUUmMydHlHRDhfT24=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΥгЮХБиσеΧЙдЬΞО():
    value = 617406
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCi2N2sP5KITHxu15Ue4bTcr51o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ημЕιΚμψΘ():
    value = 662609
    text = __import__('base64').b64decode('a1p1OW1MdTd0YWpqbnJ1SU9hUDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ρоэРмκмЗцЩщнДΖ():
    value = 926020
    if 35 * 29 < 0:
        823
        906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBjrYXI19qIQOTiV5UCaGQEVt2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 2 < 0:
        pass
    total = value + len(text)
    return total

def _ΙβВхЛΦЦΚΑ():
    value = 859695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjXWRG4t7rIuKyz1wASGAXY+6H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δяГйοСηЫΤо():
    value = 840592
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IT6xS0Uy5P0pEl2c6VSIOhcLx3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лжТЯУΥΧнзΤя():
    value = 148546
    text = __import__('base64').b64decode('TlpCWFh6VTlXNGlXbnM5YVlZZzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫьΑΛρйΩФΜюдШΣЛςψ():
    value = 423114
    text = __import__('base64').b64decode('VENhRzNLN2hEN2ZXTUNmR0ljd3g=').decode('utf-8')
    total = value + len(text)
    return total

def _αНхΝςуЫЬοТПВЮΗ():
    value = 118317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx3OPQMq9LAKNReMzHKRESMr60c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КζшШωξрΞвЬΟξр():
    value = 14924
    text = __import__('base64').b64decode('QmZQTXdoM1RoZXhkakxYS0RhRFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _зЙгψРИпνΟх():
    value = 349357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MinVR3Qc3JomICmQ42bHAXYuyX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΔГηςпаЛчεбсθэц():
    if len('') > 0:
        745
        _dead_6684 = 806
        279
    value = 733924
    text = __import__('base64').b64decode('VDJmZ2gwbUdSY25aa29Cc3ljalU=').decode('utf-8')
    if False and True:
        _dead_1224 = 236
    total = value + len(text)
    return total

def _лτгΗрΛСБρ():
    if False and True:
        pass
        141
    value = 55488
    text = __import__('base64').b64decode('ZkpqZF9nQmNMbENlWkJfQlZVMlY=').decode('utf-8')
    if False and True:
        909
    total = value + len(text)
    return total

def _кКΨэзуКЫзκлτ():
    if len('') > 0:
        _dead_1269 = 7
    value = 377265
    if len('') > 0:
        391
        82
        pass
    text = __import__('base64').b64decode('dzhRV19adHFaU2hrcDdpRE42b3M=').decode('utf-8')
    total = value + len(text)
    return total

def _θчсЛьУηΤΖЭНф():
    value = 520084
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHz8aUgP1bgIFQ6t3E+EEggqyj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑдτМιйРХΓΝγΞΦР():
    value = 752932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBC0ekUVro8uBSG0+2KdPQ0ms2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΞβοКβЧй():
    value = 981969
    text = __import__('base64').b64decode('cDBMTldrN19jNGdrVWp0dVdYMGc=').decode('utf-8')
    total = value + len(text)
    return total

def _μΠπΥφΚбαЕЗо():
    value = 809939
    if 44 * 46 < 0:
        37
    text = __import__('base64').b64decode('VmdrcWpJSEVLcW5IdVpMYkFNanE=').decode('utf-8')
    total = value + len(text)
    return total

def _κошХπиЮкπ():
    value = 882364
    if False and True:
        pass
        _dead_3120 = 78
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzfFOgYRy/hUFyeqmmmiAxV71Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ААьЭΙЭВΖξшΤωИΒ():
    value = 544216
    if len('') > 0:
        405
        370
        _dead_5370 = 255
    text = __import__('base64').b64decode('dlhBeVZhSWQ3ZGRhNk9DcGd3VGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΑΖжтБτГΜκйρЛα():
    value = 457777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3rKWWgGz5k2LhmOmni6FnUMwTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шθЗйРλОμτГбΣЬτэО():
    if False and True:
        pass
    value = 56393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiveUWEsx4MFHhWzwWChbAcY4GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2704 = 529
        629
    return total

def _ΨΖΚАξΤφыПнζ():
    if 60 * 67 < 0:
        593
    value = 292428
    text = __import__('base64').b64decode('d1BEUjlLVHhJSU9oOHJYeTVnNVY=').decode('utf-8')
    if 64 * 31 < 0:
        _dead_9973 = 85
        838
        pass
    total = value + len(text)
    return total

def _ГΘьνуФμэАι():
    if False and True:
        483
        218
    value = 195447
    if False and True:
        pass
        _dead_6055 = 862
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiD9SWALxv0SHze731mjNy17/Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3405 = 471
        _dead_4935 = 418
        pass
    total = value + len(text)
    if 96 * 60 < 0:
        _dead_8002 = 130
        _dead_7690 = 879
    return total

def _γЕГЩяιыμΝЯκ():
    value = 340634
    if 99 * 47 < 0:
        _dead_1162 = 528
        pass
    text = __import__('base64').b64decode('RXlYdFJadW1vOWpHSWZxaEJqaHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΧЫσΤтωжγΨεшФ():
    value = 450259
    text = __import__('base64').b64decode('UFZvcXE1S2hwTTJZa0dCWVBkMzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝψΧΘЯюΩιγΖ():
    value = 454207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyXVZUkB0qA5YgOzmH6eJjZ/tHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юΧиψΛЬЩогШ():
    value = 325579
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jg3sSwUBzacpOyeLw165DiEk1DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηεΛςΓяιН():
    value = 365580
    text = __import__('base64').b64decode('Q2Q4RHJseVJlaUJQMFF0NV8zRmo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪξЕДрΧУφГЫ():
    value = 761879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAj2N0Jp6roFDD+Nm0eoJDEA9Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΗцАκμхΥδЭщЗ():
    value = 232352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxzsaFsQ3ZIRAh2z+0e2EAsB4ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УНПКкцчаκПеΖ():
    if len('') > 0:
        767
        605
    value = 601519
    text = __import__('base64').b64decode('TGIyZ0Z3dlQ4Z2NIOVVLSnVpV1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _φςкσΩКьΩфΑс():
    value = 109009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LA7Re2cW0/APHA2Qn3yyDB8580o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9591 = 477
        _dead_1681 = 979
        pass
    total = value + len(text)
    return total

def _оЖΒТωЫΓАэЗРФψЦс():
    value = 218173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kzn1f0Vv0aRSLymQ3lqdPCl75WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЛДνуΩωцγйΗБФТцС():
    value = 851391
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnnWPlxvyaMaDwCXx2mgZiMBt38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9449 = 34
        pass
    total = value + len(text)
    return total

def _ΦΖщЩтЮцБτШΓχХа():
    value = 626173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzbKSgYYxJ9bDC723kaAATc4/Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩυλбΠЯчΤ():
    if len('') > 0:
        pass
    value = 938134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCXIP2URxoUlEAyJ5WehPRcc4Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хМРЩеяАψβφςΒξΣι():
    value = 22430
    text = __import__('base64').b64decode('RFJ4dUZ4a08zNTdwZG1MZURZRW4=').decode('utf-8')
    total = value + len(text)
    return total

def _аΝΓыоиδΛд():
    value = 675566
    text = __import__('base64').b64decode('SlFjVjZ2RkJ5YXVQS2JaS1hLUkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΦσΝВИΛβЧχΝδΧιΥ():
    value = 404450
    text = __import__('base64').b64decode('aTExc2xZVzdzeGFlMjJ4TWc5NjE=').decode('utf-8')
    total = value + len(text)
    return total

def _тОΥβзЫπЪΚДςМ():
    value = 928415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQ7PWGkq9rI1bzuaxH2kFgc521E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эаπμλδицИΘ():
    if 64 * 24 < 0:
        _dead_9278 = 394
    value = 710582
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B378NmESroo0NjCh23iGYnII70k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _σыζΙЙущЛуΠαнНχ():
    value = 193886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ig6xZnIGzv8THAPxn1ySZicH5X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΞмμеΤπсΧλ():
    if False and True:
        _dead_8008 = 885
        _dead_3581 = 672
    value = 671334
    text = __import__('base64').b64decode('eVZGeDRHRkt3eDlNcDAxZEtjQVQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        802
        899
        687
    return total

def _ЙБУШЙΙλΗБШΨοУЬ():
    value = 120402
    if len('') > 0:
        pass
        144
        936
    text = __import__('base64').b64decode('Sl8xc0V5elVDWjU1aTFXUXpBM0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑЧηгДοДз():
    value = 238951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwWyPWcq/f0FDQip8HyXCx036ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΗΗГМтηшзПШЪΛ():
    value = 756431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxnhTAIj1fg1OSSI2F2hIiIEzH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΣΟАΨЖОЯΥСпΨЮЭ():
    value = 883957
    text = __import__('base64').b64decode('bnhfTHJ3WjRYMnRSaXpzc25LdnM=').decode('utf-8')
    if 33 * 44 < 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_3955 = 183
    return total

def _сΚВΝΘΓΙΘςιθфКэ():
    value = 584398
    text = __import__('base64').b64decode('SVhSSXBFTE5YOGk5RTFiUEVGZ18=').decode('utf-8')
    total = value + len(text)
    return total

def _йСЮЛπсφНαЦΝд():
    if 33 * 18 < 0:
        _dead_6942 = 563
        590
        _dead_1396 = 677
    value = 553742
    if False and True:
        622
    text = __import__('base64').b64decode('R0dMOUdtbF80dkFKZ01GQ3FRRTQ=').decode('utf-8')
    if False and True:
        _dead_6703 = 334
        _dead_4715 = 951
    total = value + len(text)
    return total

def _ΜΠлэΔκχГ():
    value = 154499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JynyZlVtq788aR+pkFiRYxwKsk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΞψαΠкσγзθι():
    value = 258408
    if len('') > 0:
        599
        pass
    text = __import__('base64').b64decode('d19YQk5maUlNRG9aZzdGWFZnX2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙειΗζΟΨчАщЦ():
    value = 202274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjjNW1QV5vwEbh7yx2WhLnENxUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ргеЬццЫЖь():
    value = 492009
    if len('') > 0:
        pass
        487
        pass
    text = __import__('base64').b64decode('bU1SbkJZdHBOSXAyUXUwdWFMakM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝзуюгПЫΖμκΠΕρЧφв():
    value = 884830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCnOdlIS/Z0kagOimU6CEgYk2z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 3 < 0:
        pass
    total = value + len(text)
    return total

def _ФщвαРαГμ():
    if False and True:
        _dead_6988 = 575
        736
    value = 366004
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('dEtCbXdPWGxCaUZHNzMxZnA2WW8=').decode('utf-8')
    total = value + len(text)
    if 87 * 93 < 0:
        pass
    return total

def _νπГьССеυЕ():
    value = 958705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwXXZ34G06lWHA6o+2KmIRUO3Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖχжкψмЩЩΦΩ():
    if len('') > 0:
        424
    value = 464314
    if len('') > 0:
        _dead_8839 = 19
        pass
        _dead_9096 = 702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxfsdAk094kuMy2R5QezFQsB9jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 89 * 76 < 0:
        _dead_7539 = 733
        _dead_6379 = 666
    total = value + len(text)
    return total

def _πоъιуΥΔПЪ():
    value = 560969
    if 95 * 17 < 0:
        pass
        896
        _dead_8007 = 481
    text = __import__('base64').b64decode('a2dJZXJOR3VNbVZPVF9tWVlsczk=').decode('utf-8')
    if 27 * 66 < 0:
        pass
    total = value + len(text)
    return total

def _СНТвеаЛбК():
    value = 540170
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3joYmBpyfkCOSWH916/AyYr0V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        89
    return total

def _ΤШαΧΥΕвКγДθчΩζ():
    if 81 * 51 < 0:
        pass
        237
        149
    value = 548937
    text = __import__('base64').b64decode('dTJxZHRrV2NyUHliZmVFdlNic0E=').decode('utf-8')
    total = value + len(text)
    return total

def _бЩκζπΛΤСтΡщΛФΚ():
    value = 733306
    text = __import__('base64').b64decode('STkwQlN0a1J6NkZTQ0d0Tm50THk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΚμьХτΝоκыЬ():
    if len('') > 0:
        _dead_4375 = 535
    value = 153648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn3reFs1r/snMz2i0QO3Mn0i3lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩнΓΞгΞΝт():
    value = 374358
    if len('') > 0:
        158
        _dead_8295 = 382
        _dead_3287 = 505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADXxb2Qb/6ASLQmA2GmCZisLw2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВмςΙΓаΘЧДο():
    value = 681614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KS7jUUhq7YEbPxn13kazIAA1s2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СШоХΝрΒοΜыχЫТя():
    value = 752375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Exryb1Ma+KwNHSil6nfFOAwCzXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чюΕΠЖУПоцΠЭτΦФ():
    value = 848287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBfUTGth+aEmKynx3Q60Ei0E6m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еыεуВРρвΧрУЛΥ():
    value = 208039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDnjQUgT0v8BaDeBynLIITYGxUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8338 = 755
        _dead_2145 = 95
        638
    return total

def _φгЯψχйаЧ():
    value = 601192
    text = __import__('base64').b64decode('UGdaXzJEbUt3eGVoajhOT0tHUGg=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_7717 = 922
        _dead_4786 = 587
    total = value + len(text)
    return total

def _γЩτСЩΨюйЙшμβρПιδ():
    value = 48946
    text = __import__('base64').b64decode('S0E3NnZTX3JGX0NraW1iVTdwaGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ШХοΑиΓЙαПΗτς():
    value = 322670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiTxfF4e6JoGaiKw6QayAQcM42I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПЪβУлςεЬдΘ():
    value = 585785
    text = __import__('base64').b64decode('QlZuMG9uM3JCWmY4QVRodVBTR3I=').decode('utf-8')
    if 78 * 61 < 0:
        4
        382
        _dead_3179 = 927
    total = value + len(text)
    return total

def _ЧοВАΔΦиьиΩЩσйвОп():
    value = 885215
    text = __import__('base64').b64decode('SDR0Y1ZiWmVtWlQxOFROMjZqZ3k=').decode('utf-8')
    total = value + len(text)
    return total

def _фАЭйΟшенНμтм():
    value = 986735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh3HXH0B7awZPDmq5HGTHjIox1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘδπΦКЕЛДчябтΡЙΙ():
    value = 763839
    if len('') > 0:
        34
        pass
        _dead_7818 = 986
    text = __import__('base64').b64decode('QlpmSEZQZ2J4Z25sdUV3Q2xBR1I=').decode('utf-8')
    total = value + len(text)
    return total

def _рΕξθδΥЙξЫΔЛΖ():
    value = 555173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MR7iTHcr7KIbAFyQxkG8HAIFy1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρεьзΓΟшЮжЖх():
    if 37 * 66 < 0:
        _dead_5120 = 623
        951
        612
    value = 156683
    text = __import__('base64').b64decode('VVZLRlY3WU1SNnhOcUhfYVR0ZzY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _АФПТΦΧφКγуβΕιΜ():
    value = 760264
    if False and True:
        341
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzfvXkce1roaChbywHeIIx0lynw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒаОΒыЕΝΔюыΟЗ():
    value = 977479
    text = __import__('base64').b64decode('Yl9vS3VpUWdDWmRyMFZEZDRvNWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЩЪΒγнЬРχюМ():
    value = 982760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgDQWl4Azv8xNDC3zGOZJRYC43Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πиЩσΠωΒЬοβЖζЬнз():
    value = 212595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzjvdFA21I0JCBqn4QSnDQAG0Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ψγξчυξΣιγЫρΨЫян():
    value = 560316
    text = __import__('base64').b64decode('RVpSdTN2S1hFNnNXNUwxcHN3Y2g=').decode('utf-8')
    if len('') > 0:
        _dead_1727 = 681
        _dead_1034 = 820
    total = value + len(text)
    return total

def _ШΕЬψκвΝΣкφмΩ():
    if len('') > 0:
        _dead_2532 = 488
        pass
    value = 763144
    text = __import__('base64').b64decode('cWJ5U1cxT0RQa1AzNXVmQm51U2Y=').decode('utf-8')
    if False and True:
        782
    total = value + len(text)
    if len('') > 0:
        101
        _dead_8643 = 750
    return total

def _ΝΗΓЪΨΒΓΚЙДЛГиΝ():
    value = 807130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EymyZgI92LAVGzCtnVK+ZDYCy1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨκюШεδКχйРζζΓЪю():
    value = 62652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR3zSXc2qpwtbSyx4Wm+bCIO1Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        318
        343
    total = value + len(text)
    return total

def _ΓсΔΖτИфЖумыч():
    if False and True:
        415
        pass
    value = 938894
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAXHY3o725sMOBas2kSiFXMW7WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        653
    return total

def _суДВθБбΚрδμΚΝ():
    if False and True:
        _dead_8216 = 399
        _dead_9415 = 191
    value = 596735
    text = __import__('base64').b64decode('T3FPUUxuMjlER0RZcmdfamJWMUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _еΗψаρЬξΘ():
    value = 578355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByvXWQYuqqU0MSup72eiEwAozFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙФЯАыдΜй():
    value = 427935
    text = __import__('base64').b64decode('Tk96VEswZnRfNFpMWU9rQndWMjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΔХПоыΡТцЛсЦΦг():
    value = 804455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn7PPWALq4U1DxWo/X+2JgsnxW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗРДΧρъφΚΦи():
    value = 319402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDeyfWQep5kKFDX25Wm5OAAM3Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МшРЙЪиνщΒΘ():
    value = 295315
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQzgSVxvzItSDxeO0XPIHTMesX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηКнЯλУςЮΑΥ():
    if 84 * 7 < 0:
        pass
        788
    value = 396158
    text = __import__('base64').b64decode('RGJwU2hXX3NnTkZuWUUzRERkUEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЖΒΝЩΑбξг():
    value = 741183
    text = __import__('base64').b64decode('d2xYZEtqeDNFa1lrdnhqZ2s1UWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΦшЗЦъЮУдгдοъ():
    value = 852123
    if False and True:
        372
        pass
    text = __import__('base64').b64decode('VU1PVzRWMmdTY3kwMFY1WUtzR3A=').decode('utf-8')
    if 18 * 35 < 0:
        pass
        904
    total = value + len(text)
    return total

def _ΥΩЩиххйсДΝхΗΠζ():
    if 2 * 53 < 0:
        pass
        _dead_8367 = 427
    value = 788700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ND/WXQMw55sxIAyRmE+zLD955zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΨкσъςΚΦ():
    value = 43141
    text = __import__('base64').b64decode('TWxnZGVfQnFRXzR6SDRHcFBwM2U=').decode('utf-8')
    total = value + len(text)
    return total

def _инРЙШΨλΝΤ():
    if 19 * 55 < 0:
        pass
    value = 902359
    text = __import__('base64').b64decode('Qm5lRm9BbHBSRDVGRUxmUlZMVHY=').decode('utf-8')
    if False and True:
        650
        pass
    total = value + len(text)
    return total

def _рфЩНЗдзРТэчвиΣдя():
    if len('') > 0:
        727
        pass
        _dead_5733 = 351
    value = 127993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhfWO2Ut1aE1Hwyk7GW5ZHN31X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7562 = 297
        _dead_9073 = 362
    return total

def _сЪρΩΦъчσИяΨНЙ():
    if 88 * 71 < 0:
        pass
        911
    value = 812662
    if False and True:
        _dead_9971 = 166
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D328a24q9rEIbguFy1i1Dj8o2zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 64 * 55 < 0:
        _dead_4953 = 947
        16
        _dead_9785 = 20
    return total

def _зШккюМБθΕυΖХЦюъч():
    value = 269836
    text = __import__('base64').b64decode('RWFmczBaSTNUcTY5aTJJWDg2WEU=').decode('utf-8')
    total = value + len(text)
    return total

def _жδгζΜΧτятЙ():
    value = 225672
    if False and True:
        _dead_5896 = 67
        538
    text = __import__('base64').b64decode('VGJSeVpwOGlwWjVUdExXZ2tYVUU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9326 = 311
        _dead_4554 = 478
        pass
    return total

def _ЖЬςφМКΘΦаΗгΓЖθ():
    value = 105644
    text = __import__('base64').b64decode('SHJWRHJQR2c1aGtqRnFTY1BjcWc=').decode('utf-8')
    total = value + len(text)
    return total

def _οхкΞΜЕШυемжςПСιп():
    value = 237717
    text = __import__('base64').b64decode('TkhSUG1rMmlxeGlyXzJoaTh5WHo=').decode('utf-8')
    total = value + len(text)
    return total

def _δвЬΙтмШЖРαДΝ():
    value = 868182
    if 83 * 16 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzfxTGlux5tQbDyi53fJIwd981k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1522 = 644
        465
        pass
    return total

def _ФпеβοιУтеι():
    value = 176381
    text = __import__('base64').b64decode('bTlTMXpMZzV0MlhiNzRSbm9lVVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΨИйВьсУуДηЪСш():
    value = 788970
    text = __import__('base64').b64decode('TG1DSUN2enpfQ1NRR0xEN1RVT1o=').decode('utf-8')
    total = value + len(text)
    return total

def _υСγрΝцοΥΛЬαбυΜ():
    value = 158499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASXXfWcs3YAnLC7ynl6kYzEb018='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΧβτяωοАΘνЮРθ():
    value = 723409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAP2S1JryfstPAD1+AOcIQke4kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        737
        _dead_4332 = 599
        pass
    total = value + len(text)
    if 86 * 26 < 0:
        pass
        380
    return total

def _θЫΩПтумιАΧъΗ():
    value = 506427
    if len('') > 0:
        29
    text = __import__('base64').b64decode('Z0ZrcVVlM05fbmY0ZVNlVll4OVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΦΛЦсεяΡΥ():
    value = 440461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSL8f1tvraEtLjWh3nyEJAR8xmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чκΔΨФИνХ():
    value = 487057
    text = __import__('base64').b64decode('a3UxalpHTlJnQWtabDZYNnRnM2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΦЭμюοΠχБ():
    value = 629139
    if 78 * 68 < 0:
        _dead_2314 = 13
        567
    text = __import__('base64').b64decode('eFV0X0FUdnFRZjZ3WTdlSnIzV0s=').decode('utf-8')
    total = value + len(text)
    return total

def _χΘΠΛОβръ():
    value = 343327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRm2bH9v8PwLCTWz93uvFnYXxn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _трχΥьдэцтαьτлςε():
    value = 357762
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgvVeWkv+YlVFgqNxAKyLhF57EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑшΕσΥρзерпУΖ():
    value = 169054
    if False and True:
        762
        632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCHba0Ufyqc3LFaHzUK6YBE+zUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖδпжщΒηВΡΣ():
    value = 514972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxXvUVwQ7okULzWm0XS3MiwjxUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('bQ==').decode('utf-8'))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()