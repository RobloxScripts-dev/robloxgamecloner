#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _уΓЛяεσЙшοΤКκРюЙη():
    value = 887249
    text = __import__('base64').b64decode('b2lvRmdXYzlEcE9HUlNnaTRuc04=').decode('utf-8')
    total = value + len(text)
    return total

def _КгатΨщΔЦэи():
    value = 760501
    if 100 * 77 < 0:
        58
        _dead_2312 = 648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgjPfgcRrYIEPwCrn3uHIHI4/mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3294 = 626
        608
        401
    total = value + len(text)
    return total

def _лХγΝькΜΥ():
    value = 542724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTixVFZu5/9bHz6UxVCiFykI0ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6570 = 708
    total = value + len(text)
    return total

def _ΕлЙοΡйЖЛΨ():
    value = 503488
    if 31 * 45 < 0:
        _dead_5074 = 290
        _dead_6991 = 566
    text = __import__('base64').b64decode('VUd4QmRtYWRINVEyRWtqOHlSZHQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        719
        _dead_3469 = 461
        _dead_4380 = 713
    return total

def _ΘгεжьЛΑеАΩλ():
    if len('') > 0:
        _dead_6142 = 138
        pass
        402
    value = 577724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTvIX1gD1ooHLlrz2EO6LSAI8Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3928 = 0
        504
        _dead_2837 = 530
    return total

def _КАяγГоΔммσ():
    value = 667980
    text = __import__('base64').b64decode('UHJnSkdSQ1o3eEN5Mlh4Z0VfbUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑеКЧΔζαЕГξшКи():
    value = 124310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz7xRkgxyKwzaxXwxl6zEBEOzGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛдΒАΨДлΗДΚСЦэДА():
    value = 842573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHbBXgYX/a86aTCWwXrEGnIO3DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜтςζκмГГιΥςΣПΔζР():
    value = 407001
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQTQb0Yo9bxTEx37x0TEIgZ94m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9046 = 741
        _dead_8963 = 863
        pass
    total = value + len(text)
    return total

def _σЩхЭьΞУИΦзъ():
    value = 991058
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSqydAYLy/ArIwuo0Vi5LjQq20k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2119 = 945
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _сΥСЦГоΒжЩТн():
    value = 998199
    if 92 * 59 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnnnOlRr9JAQFBaL/lOvGCoK0WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        738
        pass
        12
    total = value + len(text)
    return total

def _фйΣЖμЩΞмΙ():
    value = 69085
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mnf9Y3Mg7KcgPDmby0KjAnIOtUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 11 < 0:
        pass
        _dead_4606 = 383
    total = value + len(text)
    return total

def _οΚΩΣнΛсдΙЫβ():
    value = 356647
    text = __import__('base64').b64decode('aG03bm14ZDQzZ1E3SDNxZmFUT0M=').decode('utf-8')
    total = value + len(text)
    return total

def _σДвКьΜГА():
    value = 867391
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DijWR3I95446IyyVxgeDJRwctVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓЕθψЫμΕаХтαФъ():
    value = 709559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nxz1WFtsyaMIbTWv6QC+Zw0MwU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΥΩАαИΣяРга():
    value = 135233
    text = __import__('base64').b64decode('ZURPa0ZQWXkxcWtZZmZhdzlIZ0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΒιБшХмЦХЖкΟΒАП():
    value = 768430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBfJfWc62a5UFjmZz3idbCE49WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 47 * 5 < 0:
        485
    return total

def _лЙсФεпΔε():
    value = 136923
    if 20 * 63 < 0:
        pass
        pass
    text = __import__('base64').b64decode('VWlRTnpodmpIdTlVc0ZEczlWOVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪщΞшΗΖИзаМХЛнΞ():
    value = 768767
    text = __import__('base64').b64decode('ZGlZT05sTG5aSjNNc21GV21pTk0=').decode('utf-8')
    total = value + len(text)
    return total

def _δΓБЭΩУΗОжц():
    if len('') > 0:
        pass
        486
    value = 288906
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CinHSkcdyKQxPAe65UGYIwg+8FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΒηеюсзтлЦπΩыαЙУ():
    if False and True:
        188
        pass
        _dead_2377 = 719
    value = 189101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cxj0XEIW0LwPG1/2/kCIIXYg0HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 24 < 0:
        pass
        pass
        _dead_8706 = 731
    total = value + len(text)
    return total

def _ξΨкΦιπΙйРл():
    value = 553886
    text = __import__('base64').b64decode('Q0N5V3I1OWFQVW1TZk5sZ3NxVGY=').decode('utf-8')
    total = value + len(text)
    return total

def _λТΘЗΒКжаλΦθшбΤ():
    value = 944422
    text = __import__('base64').b64decode('V3RRbEhyNXZiTG9JbGpOMDh6cEc=').decode('utf-8')
    total = value + len(text)
    return total

def _АσΥЮΛΘЛΖбГθЖγΙл():
    value = 31096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCq8QEIr35EBaBX0zWG7EHIN/Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1116 = 999
    return total

def _ИΦПзυЯαЖ():
    value = 186207
    text = __import__('base64').b64decode('czhqdzN5dTJsS0ZUOTZGMGhPSUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙБκβяЧΑωρчцРπ():
    value = 535101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRbtZFVqrZlWFweb/VzJPgcM7Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔγЮδζНΥψяж():
    value = 98913
    text = __import__('base64').b64decode('U1pkTWgxc2FVMEZzeWFhbDU0XzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ИИΓυΛЦЗΔрφН():
    value = 828152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw7uPnst+fA2Yl/z2XeSY3cFtlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МЯηΛоЧΛЮьΘж():
    value = 849372
    if False and True:
        pass
        265
    text = __import__('base64').b64decode('WmdubjZNZE82VlJlYjBCX19UV0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЪоτБпρэГЙЮиСΕ():
    value = 135397
    if False and True:
        _dead_9670 = 892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxbWZUcu7qI8Mw2lmk+5CzIO3kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        962
        257
    return total

def _ΧюОтщσиξΧгЕΘβ():
    value = 797769
    text = __import__('base64').b64decode('cmVJRXlvYTJITndxNVczSWdKdGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΧояФΙΚνθςЗμδ():
    if 79 * 95 < 0:
        _dead_8134 = 911
        541
        pass
    value = 365936
    text = __import__('base64').b64decode('QzhOcVUzZ3BTbG1jU1pHdl9vN1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЮЦγΝШЭΖΥбθЪцΓεВ():
    value = 167909
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz/jO3sT5rsFDCuB92OZYiQW8UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΤΩЙпХИДЗрЯКЬ():
    value = 533278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyrObFcA2KcKbQSJ0QSSZTx73Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τБмυПЗьъΓЙσκθΘ():
    value = 353400
    if False and True:
        pass
    text = __import__('base64').b64decode('bXBRMjRueTM3dDRaU09MdlhYdGE=').decode('utf-8')
    if 64 * 29 < 0:
        4
        438
    total = value + len(text)
    return total

def _δыЧьгшЪХιΛЮωЙвηυ():
    value = 980855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTuwemBv9YkyAiX66V6cEDM+6mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьЧарΛΨιΜАхл():
    if len('') > 0:
        pass
    value = 36005
    text = __import__('base64').b64decode('UVgxQ1lRbzNzM1JoV1VnYnlEZFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ψьκЫωАчЩθζаяа():
    value = 671851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHnzaHkwxrkZaD30nn63Nz89wVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МБЦЦΥΒвпωωпΧΑ():
    value = 749521
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyLgawIKrI8pBRrz+kCoYXAc5m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4902 = 430
        891
    total = value + len(text)
    if 86 * 84 < 0:
        _dead_3266 = 742
    return total

def _μШσМеьнмЮΖЙβЯψτ():
    value = 968088
    if len('') > 0:
        pass
        410
    text = __import__('base64').b64decode('R2FSZVdzX29JT21uX044UG45NXQ=').decode('utf-8')
    if 29 * 95 < 0:
        pass
    total = value + len(text)
    return total

def _ΛГΡφΟπΟχЙΜБβя():
    value = 323330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjjcTEA/9r4LDDu1+0eDMCAFtTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζЗΦЩИрΨρоοНВТПιΚ():
    value = 698646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxrhN1Q++p9UGCCM5UaFOhwV3Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щЧТИЖΩБуΞ():
    value = 194497
    text = __import__('base64').b64decode('RGF2SEduMFdaVkVVVWZzSGtrdXg=').decode('utf-8')
    total = value + len(text)
    return total

def _цмвьαЗΠяοэαБп():
    value = 158307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3zqTFkc1boqKAOJ4F+eZhUXwj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒаΞχтЙЙΠЦΓгкжЯЕЙ():
    value = 713576
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('UmM3bGxtdThIbVhqMnFyQ2l4TFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΖΘЦΑΜвжςηШБСчΞξ():
    value = 148453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H37uUVMJ1ZI7NgeqzlPDGxIJ7k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιСιюΦЯηοЛςςэψэι():
    value = 946673
    if 74 * 50 < 0:
        242
        _dead_4771 = 388
    text = __import__('base64').b64decode('TlF0eEUzcnlvSXpQVmxlUlpKME4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        800
        798
    return total

def _ъуςΞЖυΜЫбГξеζ():
    value = 6015
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxXQemVrwZpXKg2A7nSXJhU3vHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δХαοГъωЦЛЙеат():
    value = 658261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhvWZWlh8pApE1iS61WyAncNvTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъйΣуОΩЕмчяЭЮΓΤгΩ():
    value = 46433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3/pP0sB8Z0mKyGikFnGN3EM1UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8102 = 335
        _dead_2815 = 344
    total = value + len(text)
    if False and True:
        pass
        _dead_2752 = 31
        821
    return total

def _φκεφοйеΗΔРеσЗЛЫГ():
    if False and True:
        604
        _dead_7158 = 458
        945
    value = 996266
    if False and True:
        pass
        _dead_7917 = 115
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHi3X3wv77AXElzwzA+zIHML1jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6132 = 762
        619
        965
    total = value + len(text)
    return total

def _ФΘуρεσΩтщΒΝыАπЖ():
    value = 892579
    text = __import__('base64').b64decode('VFNuOHpHTldiWm9ydUpPNE41RWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮцУпχъЯЭςΒдУюΖ():
    if False and True:
        483
        _dead_4752 = 567
        444
    value = 602766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyDUaWg+7bwEMgaAwk+zGyoY0Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΨЧгΟοΑπ():
    value = 442098
    text = __import__('base64').b64decode('Wm04WVg4Zm15aDBweERkQVVCUXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΦКΡΜщνвЛСΜПφ():
    value = 524907
    text = __import__('base64').b64decode('QnhjUGVrSU80aVkxS1BmZkJ1ekI=').decode('utf-8')
    total = value + len(text)
    return total

def _йΣвЙΔИΒΖптиΕжΑΝ():
    value = 305070
    text = __import__('base64').b64decode('a09JQzJuQjVySEt6QzVPc2s1OVY=').decode('utf-8')
    total = value + len(text)
    return total

def _АтСΖсσПζУЭ():
    value = 335668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXjjO3wx5oNQN1y5yWWaJyIY0nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вгΑκνюлэкшЪΘщπи():
    value = 105763
    if 45 * 65 < 0:
        _dead_7766 = 870
    text = __import__('base64').b64decode('dUFlRjdHNjJkQjl4bnNXOWpGSTM=').decode('utf-8')
    total = value + len(text)
    return total

def _оΞΦХεμУАИΠтЛΣΟЯ():
    value = 350526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgrjXG5gzb0uAza6kEWZOxYg0EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΙΣСгΙЫΚ():
    value = 686190
    text = __import__('base64').b64decode('ZnA2OVBDS29WYmJzYWhmdXJfeDc=').decode('utf-8')
    total = value + len(text)
    return total

def _лЙΤыЪУеЪΘХИαрвДν():
    if False and True:
        611
        pass
    value = 35572
    if 64 * 82 < 0:
        481
        280
        59
    text = __import__('base64').b64decode('dG81ZEJzaEMybXFWVDh2UzF0czQ=').decode('utf-8')
    total = value + len(text)
    return total

def _γВксΠΜΨШΔ():
    value = 610785
    text = __import__('base64').b64decode('QVVXekdvWmxla0x6VHFWbXRmOXo=').decode('utf-8')
    total = value + len(text)
    return total

def _йнμνΨЬкоСЩн():
    value = 479258
    text = __import__('base64').b64decode('VVBaZ29SVk9xbHptUHFXNlNaX3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЛΙιΥдФАОπ():
    value = 954415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwXCNnkt8YYUOSW641ylZHAe1GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 46 < 0:
        _dead_4913 = 77
        _dead_4877 = 922
        pass
    total = value + len(text)
    return total

def _юиΞΔоψСРΓКЬкЯ():
    value = 319197
    text = __import__('base64').b64decode('a3dmWDZyaEcxWVpzdjdxQjRJWkk=').decode('utf-8')
    total = value + len(text)
    return total

def _КюωЖΞПΦнМμиЧ():
    value = 551857
    text = __import__('base64').b64decode('Y3NLek1sWFpWcHRHSVlTNDRNd0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓЬнΓΕΓΞЧыЪЕφΦКМω():
    value = 516568
    if len('') > 0:
        402
    text = __import__('base64').b64decode('aTIzX0lFQktIazdMMXFxSVVuYTU=').decode('utf-8')
    if False and True:
        _dead_6347 = 354
        966
        pass
    total = value + len(text)
    return total

def _ξοΤφегЦу():
    value = 693417
    text = __import__('base64').b64decode('R2JFc2ZMcjY3c3dwQmtTYnBXS3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ъςчЫуеЖехрсΘ():
    value = 498780
    text = __import__('base64').b64decode('VTFYR2s5SDVrSUYxT1Z3UTZTZk4=').decode('utf-8')
    total = value + len(text)
    return total

def _яБЪπсψрΠсΙцΩДи():
    if 50 * 73 < 0:
        369
        568
    value = 257726
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx3jPkkMr4skMQqM6lKlJC4f80Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МффΜЕοΕμΗσΣΣяνл():
    if len('') > 0:
        _dead_3548 = 947
        345
    value = 760466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwbpOmc8770oGRi1nHibFyYW6j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αыυЪφХДвξдЮчΦΟΘ():
    value = 694764
    if len('') > 0:
        823
        548
        106
    text = __import__('base64').b64decode('Y3NCTjFXbUlrQUxLaVZSZzNBSDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕЧΖЪЭтνΑ():
    value = 300735
    text = __import__('base64').b64decode('cERWd2Q1Y1pmeFRRRzBjS0F1UkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣнΜщΘжжф():
    value = 735117
    text = __import__('base64').b64decode('T3hpem5TbWlCcFEzQ3Frb1prV1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓлΧΟОΞьφΒЧω():
    if False and True:
        444
    value = 226522
    text = __import__('base64').b64decode('ZE1Cb2xFQ0xkZEVpV2dYQXdBSWM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        601
        _dead_2631 = 922
        823
    return total

def _тЭйШτνИτтЪъНтьΖ():
    value = 805155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB3He0Yq66sUCFiT0kCBPzY+6mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βрΒτβιАγεусБ():
    value = 348198
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxngVmkX/Y9WF1uq50OXGS1+9TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_2912 = 694
    total = value + len(text)
    return total

def _ЕоΡΒФРΖЙφωΕыα():
    value = 92984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnvXRXYOqfg5b1+Lx0OIFwwGtmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ητПΥУμЙбшзЩ():
    value = 71695
    text = __import__('base64').b64decode('WmoxQVFHaEFrdHJpOXlSQWliY1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if 66 * 50 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()