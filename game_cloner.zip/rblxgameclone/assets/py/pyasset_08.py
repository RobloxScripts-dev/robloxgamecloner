#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΧЭδЧΛΩыΠΣщЫ():
    if len('') > 0:
        pass
        pass
    value = 196751
    text = __import__('base64').b64decode('eURRWDhReXM1X2IxdzNMRGlSVU0=').decode('utf-8')
    if False and True:
        _dead_6778 = 863
        _dead_4475 = 630
        831
    total = value + len(text)
    return total

def _ΖчΙжЛΦΣывΩЩй():
    value = 168027
    text = __import__('base64').b64decode('bmpMcHpwdF95Sm55VzdtOEw2czk=').decode('utf-8')
    total = value + len(text)
    return total

def _ВτЮΓΓκΠхΓЙΑЭ():
    value = 377993
    text = __import__('base64').b64decode('aUYwWm9JMDVIenJxeHpKTldNYUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩЭνΦχоЬΥαАкχτΗ():
    value = 934086
    text = __import__('base64').b64decode('ZUloUkRqUHQ2M01PQktSeVpkRTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЧиΤРщΘΔΦТД():
    value = 389675
    text = __import__('base64').b64decode('T0tPbEFycEh0d0pUd3V0dnYwcEw=').decode('utf-8')
    total = value + len(text)
    return total

def _хθΤПΞΑκпΠрП():
    value = 641142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSXiO1MMxJsJICG65kOhGRx5zmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ащγοхбψχйΙъρ():
    if 6 * 6 < 0:
        _dead_5320 = 450
        _dead_2165 = 649
    value = 464806
    text = __import__('base64').b64decode('cmdZUHl4c2VkX0ZLSGI0cjVJeE4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        612
        649
        44
    return total

def _гΔδΟЙΓкзжΖτЯхπ():
    value = 997456
    if 24 * 85 < 0:
        _dead_6258 = 786
        933
        pass
    text = __import__('base64').b64decode('VWttR0hMMDFPM3ljWV96TVJsRWw=').decode('utf-8')
    total = value + len(text)
    return total

def _οгГдχΦΙсσαроΗщш():
    value = 144344
    text = __import__('base64').b64decode('dWFENGdxUDVVa19VbDdqMXMxb3M=').decode('utf-8')
    if False and True:
        _dead_8372 = 17
        pass
        pass
    total = value + len(text)
    return total

def _ЖемΓЬМρς():
    value = 207267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASnmOEsG7JcPGz+hzgaSLHch8nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДиΧВбффΣЦΑХПζ():
    value = 843971
    if False and True:
        pass
        _dead_9301 = 494
        201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhbVdGgg0IAXLDyWkVSXAA0J7lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΣпфлЬрбБтΨнξΙфв():
    value = 41157
    if 28 * 23 < 0:
        _dead_4110 = 101
    text = __import__('base64').b64decode('bHZ1ZGdncjV1THF2NU1zcm5TVHA=').decode('utf-8')
    total = value + len(text)
    return total

def _РΑдсσщΡВс():
    value = 399635
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('cTI5ZlcwYnJYOGxIaVVQV3FMX20=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑуКλЪУЦЪφцЙФ():
    value = 698707
    text = __import__('base64').b64decode('cXVHeDVaQ1NWX3NsS2ljMXI5Yks=').decode('utf-8')
    total = value + len(text)
    return total

def _ыВνεπχТУюВΦΡЭ():
    value = 402375
    if len('') > 0:
        192
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSzbSWAM8bsqEwanxHOYBTd5/H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЖЙΔДПОΜтЩЗць():
    value = 849117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iie1ZEYR9rgxElfx7kCDYDF662I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΚМКηωнΦзБΣυЬМΚ():
    if len('') > 0:
        _dead_5470 = 527
    value = 483239
    if len('') > 0:
        262
        511
    text = __import__('base64').b64decode('Sk01RFJ0WHVleHAyWHQ5X0hxcG8=').decode('utf-8')
    total = value + len(text)
    return total

def _япρагжΓΧςВвςΠУΣе():
    if len('') > 0:
        pass
        pass
        _dead_6219 = 878
    value = 985271
    text = __import__('base64').b64decode('allhM3dNcW5TRjY3NVFueHJxWHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΜΣΒλΟзυΓтηΘн():
    value = 572036
    if 6 * 80 < 0:
        pass
        pass
        _dead_7586 = 757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRDTeF1r96wCIFyUkFnIbQMN8TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 4 * 7 < 0:
        _dead_9152 = 687
        84
    total = value + len(text)
    return total

def _ЬЖЪыЧиθιЬΥφν():
    value = 643750
    if 64 * 44 < 0:
        _dead_3083 = 665
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhvTXn8z5owUbjuZ0l6DbDY6zFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 54 * 88 < 0:
        603
    return total

def _ΣхδΒеψзΔΨЬх():
    value = 457538
    if 30 * 82 < 0:
        _dead_8599 = 12
    text = __import__('base64').b64decode('Q0Z2WXZsbFRNQ3JrNFhDQ3AwMWo=').decode('utf-8')
    if len('') > 0:
        790
        462
    total = value + len(text)
    return total

def _ФсчТΘмΛθеЫБЪΗ():
    value = 781231
    text = __import__('base64').b64decode('V1dPaElfVjNwa1BxUktVY0FFSVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΝαβщрэδΣΧΣα():
    value = 912666
    if 76 * 85 < 0:
        pass
        840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiHiVlJh5v8lblyU4HqTJDIcwz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 22 * 98 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ьΡεЭΡΔΑΞм():
    value = 960061
    if len('') > 0:
        _dead_7962 = 821
    text = __import__('base64').b64decode('a2N5TWoyQVJ4VnRwQ3RQZmQ3enc=').decode('utf-8')
    total = value + len(text)
    return total

def _κΨПКοηβζМ():
    value = 899611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwnrRV095IVVMyT74FyjJycC9UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4052 = 863
    return total

def _βэЩЧВΕκΚемω():
    value = 550610
    text = __import__('base64').b64decode('YVVVb25EeG9MVnh2QWUxcXVvejM=').decode('utf-8')
    total = value + len(text)
    return total

def _шΕЭуГЧЫΜβρЦщгняμ():
    value = 753429
    text = __import__('base64').b64decode('eUVVMnRJN1gycU13dWNrX3pBMGE=').decode('utf-8')
    total = value + len(text)
    return total

def _РБΗтΕηщЙТρБвΩ():
    value = 551580
    text = __import__('base64').b64decode('aUVZdWdVR3ZqN1dVc1BNR0VvbFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΠεИКΝЯЯъΖ():
    value = 63736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw7RagItr60Faj6R2HOcNh8Ezkg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТьΦμКвΚтИηΗСйΟβ():
    value = 928300
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAnXX3QB9q8LGQWbmWmHJ3UNwmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3251 = 254
        pass
        pass
    total = value + len(text)
    if 29 * 71 < 0:
        392
        _dead_2145 = 54
    return total

def _ξЦΣПτРгЩоХВ():
    if 1 * 33 < 0:
        _dead_4437 = 176
        _dead_7423 = 53
        52
    value = 421154
    text = __import__('base64').b64decode('Rks3YWI2SVJkWEhheEZQVnVSMTg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        197
    return total

def _МИρΤЩгκΜσ():
    if False and True:
        pass
        _dead_1318 = 445
    value = 8197
    text = __import__('base64').b64decode('RldzUTRFNzZubHdIVFNrQnpkMHE=').decode('utf-8')
    total = value + len(text)
    return total

def _пζψьзΣγΒтЯт():
    value = 810634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAf3PnQYppoMLjfyyw6TZSk94Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧиφуζхыωАрххгАζ():
    value = 856413
    text = __import__('base64').b64decode('a2V0OUNvZFI1bkNNTTdwMUdJMk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΡοмХΚπУГиωдΕ():
    if 65 * 18 < 0:
        _dead_2643 = 542
        400
        371
    value = 224040
    text = __import__('base64').b64decode('Y3lDdzJBODduc2dIeEJLaGVvazY=').decode('utf-8')
    total = value + len(text)
    return total

def _χЪдЯщИΑθыАбΧΧ():
    value = 352907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MifKan8vx6IgIiKVxnu4PCgb02o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΜΟνδСτЯ():
    value = 753452
    text = __import__('base64').b64decode('anlJdzJMaUJvQjJibUNaeEkzanI=').decode('utf-8')
    total = value + len(text)
    return total

def _цПрςСьуСν():
    value = 133092
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH33WwUP8YkPMwCn3gC1YykXtW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        472
        198
    return total

def _УЛюлΞкшα():
    value = 786124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzrvYkIuz4dVGCui51DJLBAHxkk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жоΜАНΥψБЖσζζΙЧу():
    value = 909714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EALvTEUq1b82aiiW4nG1FQ0Q3X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘρеΡПΨЮΥΠ():
    value = 572995
    if False and True:
        pass
        pass
        _dead_8698 = 948
    text = __import__('base64').b64decode('Y21IUFRTVHFqaVFOZ2hpX3pnczY=').decode('utf-8')
    if 35 * 41 < 0:
        pass
        _dead_9793 = 151
        pass
    total = value + len(text)
    return total

def _ΦЗайυрιΔΚЬςАРθ():
    value = 121249
    text = __import__('base64').b64decode('RnhMMWxjMEJIa3Bub2E5NlY4aGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΨчιсΕΨуятσν():
    value = 906775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh7WXmMUzLE7Py2m/AGeO3N44Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 56 * 1 < 0:
        841
        pass
    return total

def _ΝЗМиΦοξЯλΑдз():
    value = 394757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByrRSlhg9fklHxmPzGyTJiE20Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΑУфАПЫышъФЬц():
    if False and True:
        799
    value = 912794
    text = __import__('base64').b64decode('cHpwUW5uVU5WZW4xYnNGYUN6aEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΨψψΗУΔτжыАртг():
    value = 433530
    text = __import__('base64').b64decode('Um1uWXRPckp5MG94WTdNTDh3c2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙтЦβяΦктдвЗςрэ():
    if 90 * 77 < 0:
        543
        _dead_7779 = 715
        784
    value = 883368
    if 4 * 5 < 0:
        527
    text = __import__('base64').b64decode('VFc5NEFLT3NnZzYyRHBLZ05hWWE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9793 = 283
        _dead_4470 = 275
    return total

def _ткЙπςΞγВπтτЧ():
    value = 784605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ehv2emMVzpApBST093yJCy8u5zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 17 * 13 < 0:
        780
    total = value + len(text)
    return total

def _ξЛЦКсшΖθφФΑРΧи():
    value = 270873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQ3LQ34055dRKDWM+lebNwEIxXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝβκюΨдΕлЯΒΣяЩιМ():
    value = 107126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex7ifVg/7p4ZDBn3mmGWEQ0syzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘВыШФяΞуΡι():
    value = 174195
    text = __import__('base64').b64decode('a1JBUFVGa0FLd0xleng2QUxhTnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΜΙСтШζΛΥмеΒ():
    if len('') > 0:
        684
        _dead_6723 = 113
    value = 896498
    if False and True:
        _dead_1518 = 55
        pass
    text = __import__('base64').b64decode('UmRBMlVJZ3J6RnFXeEVRNDBZV0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ДиГφτΜюσ():
    value = 729141
    if len('') > 0:
        228
        _dead_3532 = 429
    text = __import__('base64').b64decode('U3Q4VEhva2k2NTR2cmVmNHlDUUs=').decode('utf-8')
    if 27 * 53 < 0:
        301
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _нУэЛеπеυЭ():
    value = 141110
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwO1OUhh2/0xI1aq4H+XMSg20D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХσэЯЕчΨмМΕ():
    value = 769839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgL2WwQ22JAvBVax0HSaMh02y0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΗиμΑλΟΗРЩЛτюγ():
    if 100 * 15 < 0:
        349
    value = 860583
    if False and True:
        pass
        _dead_7085 = 703
        _dead_8288 = 975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASGweVAc350HIiWZ91m9NRQr0D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗМЮΟДΚщρБхξΝηκЕπ():
    if False and True:
        _dead_7696 = 462
    value = 586872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTbXYXgz3KQuM12P/XugbDMt1UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        670
        322
        pass
    return total

def _ддыιщуюАчΘБψЯ():
    value = 977136
    if len('') > 0:
        _dead_9777 = 974
        454
        391
    text = __import__('base64').b64decode('bEtmYlY4dzdic1BpZTFmWXJHZHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔξЩΙζΥчнΥПφφХ():
    value = 447834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQTsbVZry6ZQNCGC5k7FPCcmtEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΝεчЛιΞБг():
    if len('') > 0:
        959
        pass
        724
    value = 472666
    if 89 * 7 < 0:
        396
    text = __import__('base64').b64decode('eEZWTHRYTXFoV2ZERTJUSlRlU1I=').decode('utf-8')
    total = value + len(text)
    return total

def _жГЖβεШЖυ():
    value = 608952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH7oTV8jrqc0KVyynmGoN3Z57zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6193 = 483
        _dead_4335 = 422
        _dead_4616 = 51
    total = value + len(text)
    if 65 * 65 < 0:
        _dead_4301 = 366
        512
        209
    return total

def _БфΗδНЯИΒσЭθΥ():
    value = 575843
    text = __import__('base64').b64decode('b1lIb2VFWWFydkU2cmVpWGJvbXE=').decode('utf-8')
    if len('') > 0:
        _dead_9406 = 224
        19
    total = value + len(text)
    if False and True:
        _dead_4595 = 328
    return total

def _ΨЕЩЩΚоΠгСξНяЛП():
    value = 423478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3bLekc4qIkbHACJ/wDDZRp94Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _σπξяσΟОоЩЪ():
    value = 139823
    if len('') > 0:
        386
        _dead_4716 = 22
        pass
    text = __import__('base64').b64decode('SW00NHdTal83X294RmhXVEFLMTA=').decode('utf-8')
    total = value + len(text)
    if 33 * 94 < 0:
        _dead_5049 = 773
        _dead_9411 = 760
        767
    return total

def _ЫΦЗΟШςΞС():
    value = 594923
    text = __import__('base64').b64decode('TWIxSGJDRjB6VGRzM05YeGZMWTU=').decode('utf-8')
    if 84 * 64 < 0:
        714
        pass
    total = value + len(text)
    return total

def _вбрюψΡβв():
    value = 292360
    text = __import__('base64').b64decode('bnR1dFpRX3dyX3B2M3lYTHRKM08=').decode('utf-8')
    if 81 * 76 < 0:
        _dead_2988 = 991
        629
    total = value + len(text)
    return total

def _ζκещвΕΞяΓ():
    if False and True:
        _dead_7708 = 637
        _dead_2512 = 454
    value = 831162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kiy2TAdpyLIVb1eVmVeqZXIH1Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        178
        _dead_3717 = 695
        _dead_6103 = 977
    return total

def _θЪσгУМРэηРσЭЧВсΡ():
    value = 586660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiSzaF8K0pAlAxny0H+HIzUd/E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 90 * 32 < 0:
        pass
        983
    return total

def _αλΨУсοйышЯρΣπШ():
    value = 439482
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD29a1co97wyHBi38GaYBCEptEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝОΛЙцэΛч():
    value = 572333
    if len('') > 0:
        353
    text = __import__('base64').b64decode('WEdsYzBLb2FESnhWNXNmT25UaVg=').decode('utf-8')
    total = value + len(text)
    if 85 * 44 < 0:
        pass
        _dead_1822 = 966
    return total

def _ςЕζжΩαшАтя():
    value = 633328
    if 81 * 73 < 0:
        _dead_7294 = 521
    text = __import__('base64').b64decode('WnRQdUF0NGdMZjNMb2plNHRaY1c=').decode('utf-8')
    if 69 * 20 < 0:
        _dead_1044 = 928
        443
        _dead_1714 = 568
    total = value + len(text)
    return total

def _ΕΖξОНЗШπλчχ():
    value = 75092
    if False and True:
        _dead_4655 = 394
        pass
    text = __import__('base64').b64decode('UFNCQ1RQa1dQQWt6MDFmSFFtWFU=').decode('utf-8')
    if False and True:
        234
    total = value + len(text)
    return total

def _ρдЗЯΓοκυΠлΩо():
    if False and True:
        940
        _dead_1487 = 713
        _dead_7742 = 645
    value = 258501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dyv2PkYxyv0zDF2u4E+bFScE4XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9925 = 166
    return total

def _лМПςнΠΒюΙсоςх():
    value = 256851
    text = __import__('base64').b64decode('bVZKemNvNzZzZGt0WmVyVzVFRDU=').decode('utf-8')
    total = value + len(text)
    return total

def _уйΑΣнπΩЬъαяτ():
    value = 117374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQH2Q1oawbsmCjy66nO6MykD1k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        566
        945
    total = value + len(text)
    if False and True:
        _dead_9895 = 147
        313
    return total

def _лЛΝбημУТψΙЧΦКΣЖ():
    value = 163575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD3ARWAT65cKLyCu0lmiFSp+0XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        370
    total = value + len(text)
    return total

def _ψзΑΞΤΤфчИзк():
    value = 915574
    text = __import__('base64').b64decode('bnlESDZWdmdKMFNFSWFPejNmVXA=').decode('utf-8')
    total = value + len(text)
    if 34 * 18 < 0:
        _dead_9885 = 729
    return total

def _ЯψιгωсΧΖ():
    value = 437070
    if False and True:
        pass
        pass
        _dead_1478 = 829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IADPYgIYz/Enb1yp+QaHIyMF3kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κигτЧЕщД():
    value = 227335
    if len('') > 0:
        250
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTjMO1UT/5wbIha33XCdNSclw2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7075 = 712
    return total

def _ЛяΛРзτпμэы():
    if 74 * 12 < 0:
        _dead_3060 = 318
        pass
        pass
    value = 969480
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('eVpOczRwRjZsMHl5VUhLQ1VwSjc=').decode('utf-8')
    if len('') > 0:
        _dead_3716 = 894
        594
    total = value + len(text)
    return total

def _ΛχκΗΜβщдэшΣ():
    value = 699382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSe1V1IVrv0KHCGy3l+AJyB4wmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        772
        757
    return total

def _πуеΥЩпΤЮποΖ():
    value = 513917
    if 41 * 44 < 0:
        _dead_4998 = 827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQLmYwk08IIWERny/GemG3Ac9kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        0
    return total

def _ρΕуПΥΡыΜК():
    value = 676091
    text = __import__('base64').b64decode('YlJ2R1hoMWF3aEVfZWQzdFFlVl8=').decode('utf-8')
    total = value + len(text)
    return total

def _аΒБбΓТΘοпΨЕ():
    value = 851927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhbbZkY0+7A1LB6n9wWmAyd7wkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пτηХΦВЪΛСνвμХ():
    value = 196880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxroQX4urr4SKDqOn1XGLQJ4zEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΨРΕсκΣкчΩΜпξ():
    if False and True:
        276
    value = 896829
    text = __import__('base64').b64decode('YkRqNUtzcXFxbGthMFBmdjhLSXE=').decode('utf-8')
    total = value + len(text)
    return total

def _МиοΤЬΙωΗοΔ():
    value = 119181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgfhZmMs+JEtPwKszl3EFRA4vUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3665 = 741
        pass
    total = value + len(text)
    if False and True:
        356
        _dead_8521 = 997
    return total

def _ζΒΑЫδΛΡπП():
    if 41 * 89 < 0:
        pass
    value = 474704
    text = __import__('base64').b64decode('bExsSW5KdVV2WHBjMm9CRGNyYm4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _кГнνςцШГЬбξ():
    value = 889103
    text = __import__('base64').b64decode('VmJwbGsyTjZrRTIycGJmM2xkWTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪуδЕЧυωлσШΣжКΝ():
    value = 957066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In7lRVU7qYM6HQqtyQ6bCzM2vD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 19 * 10 < 0:
        _dead_3992 = 625
    return total

def _оУчэтΒоЫбоп():
    value = 863900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgTRY0EG1/xUCSqx2XuALCt451c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6337 = 584
        _dead_8530 = 827
        _dead_6270 = 773
    return total

def _ЗАρыΑзОзΠ():
    value = 381430
    text = __import__('base64').b64decode('WjZqTXN2V0ZhWWtteE9uYnZpUFY=').decode('utf-8')
    if False and True:
        665
    total = value + len(text)
    return total

def _ΝφСдνАадΧыУлк():
    value = 240260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAmwQ3gzp7xSNTa530XILAEGsn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        95
        pass
        pass
    return total

def _πИШЭрΚЫψΜЯК():
    value = 987216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eji9dEMIypIBLV2ImXKhZTw48no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μНрκЮιΚΜΠыЮμы():
    value = 626998
    if False and True:
        _dead_2657 = 436
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj7XS3Rvqp8kAle1mUy/JzY+5no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥфСшкзБЕБтΔΥа():
    value = 349627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB7OP3oO7bwMERWH+1fDAAo96lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1043 = 122
        pass
        928
    total = value + len(text)
    return total

def _ΠΟюзНλкЗМЧчκ():
    value = 903888
    text = __import__('base64').b64decode('TG1ZQXJaTG9yNzl1YmY2YzBaaWE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_9021 = 60
    return total

def _φЖНэДЬμΞттΖи():
    if len('') > 0:
        pass
    value = 935007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBDTPVw46K5UDjmT5g6XOwg14mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛыρдВВгσπЦеζВσс():
    value = 326298
    text = __import__('base64').b64decode('eWhDc3NZZlZyRkZFOGc4c3pRMnQ=').decode('utf-8')
    if 45 * 87 < 0:
        _dead_6629 = 945
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_7199 = 118
        _dead_9175 = 81
    return total

def _ΛМΘбюΠМΟОΘЦУ():
    value = 77990
    if len('') > 0:
        _dead_7476 = 851
        718
    text = __import__('base64').b64decode('RU5lSnJpV1o3dnF5ajM4M0xPdFo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _θΓφЧюГЙΗдΛνυыΝ():
    if len('') > 0:
        _dead_7203 = 103
    value = 387616
    text = __import__('base64').b64decode('a2NPYjdKUHFpX19lMVY3MGF5dFo=').decode('utf-8')
    if 28 * 2 < 0:
        _dead_5506 = 289
    total = value + len(text)
    return total

def _УПЖПγсΥГфВ():
    value = 300031
    if False and True:
        672
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQbcWnAQ/KQxI1ao8XLBGiI792g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _врЗУХпэШмсб():
    value = 84389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQHTbGVo54U1EiCwxmmlIHIhtGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НеКьЗюΙΗςъПящ():
    value = 808429
    text = __import__('base64').b64decode('YW9RRjBuMUR5eTV1NDI5VEJTTTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕРΗΠγКЗτЛяΑо():
    value = 22069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQzJZQcd8q0aCSOi/ELFLXYZtn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зоСмλТςъЗοбрЦсΖ():
    value = 981683
    text = __import__('base64').b64decode('dFc0UEF0RnRMVHBtN0VHVXU1czA=').decode('utf-8')
    if False and True:
        434
        _dead_4121 = 525
        pass
    total = value + len(text)
    return total

def _ΔΔφΝЕΣζБнΞТ():
    if len('') > 0:
        _dead_9535 = 769
        pass
        370
    value = 991062
    text = __import__('base64').b64decode('TU5SYzhCajQ0SnF6ZEpZU3RfdUI=').decode('utf-8')
    if 68 * 86 < 0:
        47
    total = value + len(text)
    return total

def _ЪΨμΠοуЩГИфф():
    value = 864524
    if 5 * 78 < 0:
        462
        _dead_6602 = 187
    text = __import__('base64').b64decode('d2RaWmZmeEtRam5IWFJpdVNRdmo=').decode('utf-8')
    total = value + len(text)
    return total

def _АψштйЧΤас():
    value = 476357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAX0WFMp/5wJMwqb4kOKICoI6G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 4 * 92 < 0:
        389
        pass
    total = value + len(text)
    return total

def _ЦцяЬТэНΖοΗζ():
    value = 504617
    if False and True:
        _dead_7409 = 822
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgTSb2Aq17gkAhmhw2mhDgAi718='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2363 = 483
        pass
        pass
    return total

def _ΖΙЛипΨαИ():
    value = 320227
    if False and True:
        628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cg7CS24P7/g2Nly7+VuVPz92s0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΣςшЖБλОю():
    if len('') > 0:
        _dead_9791 = 854
        _dead_9671 = 695
        30
    value = 380068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRzsXnwRqr0AbTCa+gGTAAM+9X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _каΠЫβκЙаьζΚΣχβ():
    value = 186913
    text = __import__('base64').b64decode('Ql95TnVHN0N1b3pJeWNqT1RVVTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _уъυЬχΡОи():
    value = 442813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nnr+aXVhqp0Gah72wH+ZFj97sD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        339
    return total

def _шфшБсЯУΠΒΙΞ():
    if 72 * 79 < 0:
        281
    value = 546434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByDsP2Yj9KMiMz7yzFCJDnI58G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _оνсСвςаЙГ():
    if len('') > 0:
        195
        pass
        _dead_9564 = 833
    value = 526531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PALRa3UTzZBUNlaJ8UOBMgsZ4kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_9655 = 364
    return total

def _σФθмгηΙΖψОдΝ():
    if len('') > 0:
        _dead_7663 = 316
        _dead_4820 = 623
        40
    value = 191452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSDHfkcAq/wbKTyw3A+cGSt922E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 66 < 0:
        pass
        pass
    total = value + len(text)
    if 47 * 7 < 0:
        804
        179
        pass
    return total

def _кυРУυфμΓЙРΓжр():
    value = 747813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQGydlppzqpXaFinykOjBSYXvFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫρΧгΨрσэуιмψтДм():
    value = 577478
    if False and True:
        pass
    text = __import__('base64').b64decode('ZHhpZnBTUGRmZnJ0c2g1M0llckw=').decode('utf-8')
    if len('') > 0:
        _dead_2276 = 234
        pass
        pass
    total = value + len(text)
    return total

def _деюΔΒЛЦКМ():
    value = 952259
    text = __import__('base64').b64decode('R1AzamtlUEJnV2h2bF83bktId0M=').decode('utf-8')
    if len('') > 0:
        _dead_5539 = 50
        622
    total = value + len(text)
    return total

def _угΟтшУΑщΕэΧφ():
    value = 431414
    text = __import__('base64').b64decode('cWx2eWhEbXdEc2VSMUNBeVpLeXc=').decode('utf-8')
    total = value + len(text)
    return total

def _шчΨФλλмпλПЯΖχ():
    value = 360576
    if len('') > 0:
        pass
        76
    text = __import__('base64').b64decode('VnpoelQ1eThQZGJZX0V6WFJPbVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩРЮЬОчΑзИю():
    value = 35828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzjiWV0prK0XaQmA5EWCBHUDwnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΡУяШРΓСΙ():
    if 52 * 68 < 0:
        _dead_3450 = 187
    value = 996902
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyTpV18t8bIuFRy0+niDEwc68Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΠгοΙпРЬнЭсΔвπΖо():
    value = 670811
    text = __import__('base64').b64decode('VUhzVzdxQWJGTUpyaV8wakxXakM=').decode('utf-8')
    if 4 * 32 < 0:
        pass
    total = value + len(text)
    return total

def _АλΟАЦОβАу():
    value = 979952
    if False and True:
        pass
    text = __import__('base64').b64decode('ZklwbU51SEJLVzkxdkpTNmV3RXc=').decode('utf-8')
    total = value + len(text)
    return total

def _гβΚрωθΓшΧЭД():
    value = 407701
    if len('') > 0:
        pass
        _dead_8419 = 149
    text = __import__('base64').b64decode('UHhyTkdneFNfZjB3RGJOT0JFeG8=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ГКаΤΛΩСΚП():
    value = 925335
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyXNdHNv+aItaVaO8nXEJAol/Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        426
        _dead_5379 = 475
    total = value + len(text)
    return total

def _οΞшЦщξыζ():
    value = 455373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhjURFIM8/hWFB2sxnGUOxwI6zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уΞΡйфшЧеφгкΨρаΩρ():
    value = 353466
    text = __import__('base64').b64decode('bzJCeFhnYzZ5SnlrZEtvRWNHajU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩηЭμΒЫζΟφцыΑЮЬК():
    value = 793635
    text = __import__('base64').b64decode('UHJuYTZMQ1ZsQmg4UjZHQnVKOUs=').decode('utf-8')
    total = value + len(text)
    return total

def _сλщλΒΒςΨχЕΓЩГаюЪ():
    if 3 * 63 < 0:
        135
        286
        pass
    value = 441587
    text = __import__('base64').b64decode('Szdlc1NmYnhZX1dUOTExWkIzeE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓκДΝвсхыμъΖΥ():
    value = 386187
    text = __import__('base64').b64decode('UnhMM0FuRndsaDhJV2g0RHd1QzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ТЧχΞζрΕΠВАο():
    value = 502219
    if len('') > 0:
        265
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh3idno7x4IAPl6UzQSEPgIhsH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭсшФδЙвΝ():
    value = 439503
    text = __import__('base64').b64decode('Y09ZTFZ6bDZ5WWl2MmZvRTZSWTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΞΨкхФцνЪθТπХσ():
    value = 817113
    text = __import__('base64').b64decode('U2tYUFJSV19RdXFvNHFJQ0szcEo=').decode('utf-8')
    total = value + len(text)
    return total

def _чΕοсΦΕЦΞΖрΜыР():
    value = 326333
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAjbRAIx+b4wPxq74WGKNx8r3WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΨкХнΒκШςЙИ():
    value = 607145
    text = __import__('base64').b64decode('Tzl4M3JIVWZqVzRPWmlWblV5UHc=').decode('utf-8')
    total = value + len(text)
    return total

def _φеΟχτιΨΔΣчΟζ():
    value = 271215
    if len('') > 0:
        pass
        _dead_4885 = 57
    text = __import__('base64').b64decode('R0V4UEw1MDhMUVJIWDNlSzVpbDg=').decode('utf-8')
    if len('') > 0:
        _dead_2299 = 320
    total = value + len(text)
    return total

def _ΞыΠыδβΤΛЪн():
    value = 571717
    if False and True:
        138
    text = __import__('base64').b64decode('b254VWJISmowZnRMUUg5bVlGenc=').decode('utf-8')
    total = value + len(text)
    return total

def _РκδЭьЩΑШБΦΤЪ():
    value = 289952
    text = __import__('base64').b64decode('c0trNjlxcmdqUlliZ1U1XzFDekc=').decode('utf-8')
    total = value + len(text)
    return total

def _ТЛдΞРψЦΑчЛВα():
    value = 215161
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAezVlwN7PEQEyWz3gSXZT164nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κнοРςпЦσЙΖмЛ():
    value = 932804
    text = __import__('base64').b64decode('cDVzNUpWYV96eFhIb0R6VzYycDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧХуцΜМψбΞπΗЦФ():
    value = 447742
    text = __import__('base64').b64decode('U2ZEUWRyZ3ZqMTNGTExMUkNkUWU=').decode('utf-8')
    total = value + len(text)
    return total

def _нсМЫχФЩθψΦμн():
    value = 767723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgazW2Ng5ooEaj3w3QLFDSI1wng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 81 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    pass