#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ЯдιдпδциΛъйчιЧχ():
    value = 344933
    text = __import__('base64').b64decode('TXV3NXdncWNmRW02dllfa2VFbFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ШДΤАΜгΤэΛшшМИΧζ():
    if 10 * 36 < 0:
        pass
        568
    value = 519185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn2xeAJh8K9aLgWB/WyjDCYJsjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 44 * 16 < 0:
        125
        pass
    return total

def _σнξρжΚΛЩνΑнεθ():
    if False and True:
        pass
        945
        pass
    value = 331129
    if len('') > 0:
        _dead_7590 = 962
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAPTW0gR8rwpCxaJ+AaoMCd7vEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 81 * 91 < 0:
        212
        _dead_4777 = 695
    return total

def _ΞΓληονйαуΛъцΥЗИе():
    value = 440615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgbjXVgT1p4IPR3z21y3HQM2tUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΙвкΒΕАМΘЩ():
    value = 76433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAH2XHlqzqIuElanmne8Fyh2tGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΩФΖвчΩМΤыЛфнΓιЩ():
    value = 69758
    text = __import__('base64').b64decode('VHE0ZGhNWEdhNF9ZMFNVRGRCeXA=').decode('utf-8')
    total = value + len(text)
    return total

def _γгЗоОΓяΩд():
    value = 172964
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PybDP1g41J0LL1b0yVDGBQopwEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖмНОФШΤΜУλДэк():
    value = 709076
    text = __import__('base64').b64decode('WEN1ampsTnNsM2pLMVRwWFJKQUY=').decode('utf-8')
    if 82 * 93 < 0:
        582
    total = value + len(text)
    return total

def _мωоΔЗкΔпъ():
    value = 325596
    if False and True:
        _dead_5309 = 180
        _dead_7315 = 983
    text = __import__('base64').b64decode('QUM5SGY1MWU2dVAyVE1lMTBoREU=').decode('utf-8')
    total = value + len(text)
    return total

def _МηэиЭкжхΟщ():
    value = 641491
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IznwSWI/+Ls2AAGqwlOXLDA76z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζЕΒУШмьΓжνКψ():
    value = 249506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj7tfFID0ZhXY1/60lOlYjAqxWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пчΔпВАЧКμ():
    value = 200981
    text = __import__('base64').b64decode('SF91QURSXzBlM0FkRUU3OTM3Wmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧИψΧтτΧΦЖ():
    if len('') > 0:
        pass
    value = 913773
    if len('') > 0:
        _dead_3580 = 775
        686
    text = __import__('base64').b64decode('cjc1d3JvU2U4a3A2RHhySDlrQ3M=').decode('utf-8')
    total = value + len(text)
    if 96 * 86 < 0:
        pass
        pass
    return total

def _жΗυЩйδюйбρД():
    value = 455599
    text = __import__('base64').b64decode('ZDExck9KQnJzTW4yZ0JJclZ2WVA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9724 = 97
        pass
    return total

def _ρΝпυΖΜРеОшΨθРх():
    value = 42772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw3RTXMh35kNHCGi0EKXMQ8L5n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βаδωШиΕзΙе():
    value = 287449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ni3nTARu1pcXMQeZ+meCEBEF9Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щДЙψХФШнβ():
    value = 581430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQe2O1cs3YYBYyGTyU7EZ3EG6Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 82 * 40 < 0:
        928
        _dead_4442 = 373
        _dead_7609 = 11
    total = value + len(text)
    return total

def _РΞχмвγωΧбсξς():
    value = 882236
    text = __import__('base64').b64decode('aFZUMHRqY2xBX3RvRmw3U0Jtb0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΚμЩΨυΓΤιε():
    value = 441085
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRj3eHJpzrEaDwyzmVWKJAAE51Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        979
    total = value + len(text)
    return total

def _ЭУΒΒЕυΘαοшσ():
    if len('') > 0:
        405
    value = 494786
    text = __import__('base64').b64decode('b0Q3eHdDQ2JrWWh4NlV0UXQ0dFE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΡщхРуНРΓπщ():
    if len('') > 0:
        pass
        _dead_9765 = 655
        pass
    value = 145131
    text = __import__('base64').b64decode('dnRlUGJETzJlZ2ZRaEx3eHdqdTk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7995 = 210
        312
        pass
    return total

def _ЙхΜщсΨΔЙβρкκз():
    value = 729904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID68e3A32bAtECz30Aa/HwE721w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΩΔцжСщςΥыΣтΙ():
    value = 912546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTzLPVIr0rwlPSyN4XeYZgp79j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηъттмЕЮиъ():
    if 66 * 75 < 0:
        _dead_3512 = 898
        _dead_4650 = 240
        pass
    value = 536386
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az7FPX8G6LhaPCiS+AKjF3cp9X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        693
    return total

def _ЧДъХпкσβΔНйΠЦΑΣ():
    value = 707324
    text = __import__('base64').b64decode('cXZsUVZGa2ZKYTJJZnhueHNmNHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨσПΡβщрτСτуцΣщъ():
    if len('') > 0:
        _dead_5457 = 824
        _dead_7144 = 970
    value = 756707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHv9RWEgrKQiYyiMm1ioGBMpxlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2441 = 279
    total = value + len(text)
    return total

def _αТМХΘΚэβКЮхСω():
    value = 278653
    text = __import__('base64').b64decode('VUR1YktLU1F4RWpBTjhCUUdYRjU=').decode('utf-8')
    if False and True:
        897
        _dead_6326 = 210
        pass
    total = value + len(text)
    return total

def _ЩЮШЙУБсЖбрДУв():
    value = 588412
    text = __import__('base64').b64decode('eWhqcm0xVWp3Nzc5X2F5ZERrR0Y=').decode('utf-8')
    if len('') > 0:
        937
        pass
    total = value + len(text)
    return total

def _гΘшцΑκωΖ():
    value = 115800
    if False and True:
        891
    text = __import__('base64').b64decode('anNrZHpqV3RHc2tBUmUzODQ1dTA=').decode('utf-8')
    total = value + len(text)
    return total

def _СЫХТГЗсυυασλп():
    if 47 * 60 < 0:
        _dead_6987 = 99
        727
        _dead_3923 = 624
    value = 301714
    text = __import__('base64').b64decode('ZmQ2OFJsVTV2M2NITVNJa21mUFU=').decode('utf-8')
    if False and True:
        pass
        _dead_5834 = 133
        105
    total = value + len(text)
    return total

def _ЮПзγоΤуЖτд():
    value = 356805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxnhPgFr77oUBTixkGSVJnYG9TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αдЩюжΘξшмТщЧю():
    value = 818858
    text = __import__('base64').b64decode('U3htNW1iVDNONlNRT3B5U2pvTEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠμЧΚэΓΣμмΞ():
    if False and True:
        914
    value = 904248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTnFYlcp/fABYgWGwgexInN//Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τБрНиψЬζΥчХЛ():
    if len('') > 0:
        _dead_3847 = 387
        pass
    value = 605313
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwfQRUQDwaYNbCyt+H6lJSEM7mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        601
        pass
        pass
    return total

def _йЩЬριцизνпБИг():
    value = 35576
    text = __import__('base64').b64decode('Y0FGSWFGUmZaa2VoR2pyU054WlY=').decode('utf-8')
    total = value + len(text)
    return total

def _яΣЙδзтИИζУσьчВх():
    if False and True:
        _dead_9983 = 824
        587
    value = 527153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyzoSUM89f0RIASr/VmVMRc+/j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 31 < 0:
        168
        _dead_5484 = 535
        726
    return total

def _ПчЫеЛЬИΧчкУτъ():
    value = 814616
    text = __import__('base64').b64decode('UFZUQTdsM2RsU2Noa2E3YVdZakg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9808 = 610
    return total

def _βνΨЭяИЩΛСΝΒНОβ():
    value = 930582
    text = __import__('base64').b64decode('RDhHUXg1eW96anl0SjlPa19FTzQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        304
    return total

def _ρφьτзСфисГЮ():
    value = 465724
    text = __import__('base64').b64decode('QU9XbjdXdUk5dDRCeUpLcTgwWkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΔΞνΔчΚλχλυ():
    value = 821045
    text = __import__('base64').b64decode('U25TSWh5NUZGMXA3WnlPS3UzQnY=').decode('utf-8')
    total = value + len(text)
    return total

def _πφЪζцжАυΝЭΓζБг():
    value = 894144
    text = __import__('base64').b64decode('dTRoTmNhbm5UcEpkeV9HQjZlRnU=').decode('utf-8')
    total = value + len(text)
    return total

def _θПиПοАъΦйвοΠαаΜ():
    value = 461959
    text = __import__('base64').b64decode('Wm5LQVVqN1VxSUxIYWdtS19YWjE=').decode('utf-8')
    total = value + len(text)
    return total

def _υчТбΤЧΥЪЪнэ():
    value = 540883
    if 51 * 97 < 0:
        _dead_9923 = 583
        _dead_1032 = 150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bnnpdn4O8Z4NBQyLz1mBBiMD/lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞюшФζΑъцч():
    if False and True:
        _dead_5106 = 411
        pass
    value = 917609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgXsRnQG96BXDFyN21iyYHEF0Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эшцψеюбλΓΞλΗθΡю():
    value = 448363
    if 53 * 48 < 0:
        pass
    text = __import__('base64').b64decode('Y2NNUEFpU0lMblZDckhxSGJzWmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨυзγτЗξηΕиЙΥ():
    if False and True:
        _dead_1735 = 72
        644
        803
    value = 102838
    text = __import__('base64').b64decode('bVBuTEpwY0J6Uk9ubnROS2diV0M=').decode('utf-8')
    total = value + len(text)
    return total

def _θБЦеъРЖΡ():
    value = 198189
    text = __import__('base64').b64decode('V0NLWU02dWRiU29RSUdKWWd2ZkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _аΦςФσшφяΖнμΧΧИ():
    value = 9511
    text = __import__('base64').b64decode('RlI3UkZkV1NTSFJjMmRjalJiMlg=').decode('utf-8')
    if len('') > 0:
        478
        pass
    total = value + len(text)
    if False and True:
        498
        pass
        pass
    return total

def _ПдГОИсΧΓοфэХσфΖо():
    value = 244560
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB7cPlsb+Z4NEgyMng+VFiED8HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςЦдΨДиДΥЦП():
    value = 182626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mib0XnRhyYAGIDWImX/HGhwbtFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОπУЛчЦωΠЫФХΝ():
    value = 471074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRuyQVho8pkvPVyOmlS4Zi8s0Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХпξсМРΕΒ():
    if False and True:
        _dead_9199 = 449
    value = 832396
    if len('') > 0:
        _dead_2159 = 753
        pass
        pass
    text = __import__('base64').b64decode('c05MWnFZb1NLWlNtUmpaME0zb3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЬκεШсшаРαНя():
    value = 10136
    text = __import__('base64').b64decode('b05DdEVWUUdZYzA4VzhzQnpiWGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _шЙЖАЛΝаЗΠмиκеΒβ():
    value = 84189
    if 59 * 45 < 0:
        _dead_9822 = 479
    text = __import__('base64').b64decode('QUl2MXFaaG9Nck81cmtGenRZd2k=').decode('utf-8')
    total = value + len(text)
    return total

def _СИаэсСθСТ():
    if len('') > 0:
        pass
        pass
    value = 550147
    if 9 * 48 < 0:
        263
        372
    text = __import__('base64').b64decode('bGltRG5UcmNjT0VIOV9aVFFzcVU=').decode('utf-8')
    total = value + len(text)
    return total

def _χεςξЩэδκΝΛаΝδс():
    value = 720033
    text = __import__('base64').b64decode('bHVkZXFjN3M3ekQzc2lLdFgxVmI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬιГΔБфΖζаΔНмΜμЬμ():
    if False and True:
        893
        _dead_5470 = 633
    value = 867004
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgvnXlMo344tCQjy2nGmZSElwXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 15 * 100 < 0:
        _dead_1345 = 255
        839
        pass
    total = value + len(text)
    return total

def _юЗΧηРΩэΧьΔΤΗΖЕХν():
    value = 557900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSrTPgQJrfswFzuF2XKoZyB+9ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 38 * 33 < 0:
        pass
    return total

def _φΦВпъφΠΘМлч():
    value = 603945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCXSVHs48qQaDDmSxlC1IHQAyTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПФяΚχПСгуБыц():
    value = 613713
    if False and True:
        _dead_7502 = 221
        pass
    text = __import__('base64').b64decode('VDdzaEtQSThBQ0NFelVOWE5XWmQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3320 = 616
        355
        _dead_2406 = 475
    return total

def _ЙкМΔМΟΜИыЪΥАΟΒл():
    value = 679975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjyzS2sc6qwJMATz4mfAISI31Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΕχЦмγΛΩАЦ():
    value = 375456
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cw7dN1M+25kRGSeyyV2qGQB57Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _воΑЭЛэВЗ():
    value = 332072
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3rwOWka+qM5GC7y4l2hNS4J1mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тъъπвлГкжлцоκΤ():
    value = 962040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh3yS3kwyv8NLQf24FSyBAgWtFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λсдΥθΚеюФЭΕкΞЧЗψ():
    value = 972945
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AX3vXAI//K8CAluR21WUIDEL02o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        736
        _dead_1742 = 782
        _dead_3183 = 660
    return total

def _лРβκΡμОьπк():
    value = 708423
    text = __import__('base64').b64decode('UXBCcTVDdDN6TmdmTk9MYlJITmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓγσрξбЫМ():
    value = 461949
    text = __import__('base64').b64decode('VmxmdEJsTmQzZHluSVlyWWZhYTY=').decode('utf-8')
    total = value + len(text)
    return total

def _вЧШТΖЖЪзμΩΚ():
    value = 171612
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSHLd10Lq4MRLlurwUGfHz860n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗςцЙЙРтыΜαх():
    value = 913121
    text = __import__('base64').b64decode('akVxc3dfWXNHdjM5anFrbGdSZzU=').decode('utf-8')
    if False and True:
        786
        _dead_2088 = 426
    total = value + len(text)
    return total

def _ΡςΕΨзеЪГι():
    value = 135828
    text = __import__('base64').b64decode('b0pPTHV3aUVoOHZXMjF6aV9rYTM=').decode('utf-8')
    if len('') > 0:
        _dead_4883 = 857
        pass
    total = value + len(text)
    return total

def _АаЮзтцЕтζε():
    value = 136281
    if False and True:
        _dead_9789 = 196
        _dead_1918 = 569
    text = __import__('base64').b64decode('a3NmWkxUcjVLajRSaEFNQUd4bVM=').decode('utf-8')
    total = value + len(text)
    return total

def _вмвγπтМы():
    value = 558928
    if False and True:
        pass
        _dead_9709 = 168
        954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyrsT2MT5L5QED2G7Xy/Pxx26kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пгтσнВχзфо():
    value = 731980
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MALjSFYt3aYmaTyc6XiDGnw90Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΣσЧъИυЛчηшНъΘμ():
    value = 348785
    if False and True:
        _dead_6087 = 375
        _dead_2034 = 17
        pass
    text = __import__('base64').b64decode('cmFkTklhNEM2amJlQWRoTndxclo=').decode('utf-8')
    total = value + len(text)
    return total

def _вτЗΩΦΨχое():
    value = 704173
    text = __import__('base64').b64decode('cHk2R0UwVnRjdkpzMUEwand2VVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔςжΨМχНЧТθйΨςЛ():
    value = 600816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FALOe2E/qfAGYg2r8nWHDC81xmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙоοКзЗΔмаЩДΘМΜГι():
    value = 488330
    if False and True:
        807
        _dead_6367 = 980
    text = __import__('base64').b64decode('VHpST0lXZ0ZJZ0hUQjU3czZVZ28=').decode('utf-8')
    total = value + len(text)
    return total

def _εИьиьЪЩΦΟДγς():
    if False and True:
        pass
    value = 587607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwTLakBs1odSDxX7mQaTNwR7wHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 83 < 0:
        pass
    total = value + len(text)
    return total

def _пчΤУΙшΧЩГβПжΣСЫ():
    value = 902823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3nrQnQMq4M0FySc8AWEPBB28z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6779 = 530
        690
        pass
    return total

def _ΥыΒιριТΚΑ():
    value = 47747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D33rQGdt66Y5CwWb/A+JBSkGyjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘвΚКЫθеΚ():
    value = 10637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhDQWmMP9PkXFwiamkaeCwcV03k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1045 = 581
        _dead_6565 = 711
    return total

def _СЩΘσΣΧИч():
    value = 872117
    text = __import__('base64').b64decode('UnlKM2hfT3hBaDhQX09KUUZDWVE=').decode('utf-8')
    total = value + len(text)
    if 16 * 89 < 0:
        pass
        713
        _dead_7243 = 780
    return total

def _γБзθАТΜЯγζρ():
    value = 987955
    text = __import__('base64').b64decode('bmg2TkVGWmpUUnJrak82eVIwQ0M=').decode('utf-8')
    if 74 * 17 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΙδΥΚЕпλеЫе():
    value = 118421
    if False and True:
        475
    text = __import__('base64').b64decode('UXh3Wmpjb2NqRXp6WmlwcV9jSEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑΑεоΠΜρζμδΖΧъЮл():
    if 21 * 18 < 0:
        834
        pass
        pass
    value = 236891
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhnXTHoY0oVaCRiU+3SkInck5mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        676
    total = value + len(text)
    return total

def _ΜψцΗθσБΚЕεдΧκзО():
    value = 559257
    if False and True:
        _dead_8558 = 37
        632
        _dead_8508 = 93
    text = __import__('base64').b64decode('R25fS2o4SGZaUTZldmppU0w0QXk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        621
    return total

def _ЮοψЬнИψдяКЗ():
    value = 783101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz3vR3Q4p75aFAbx4Xm7Pgwd7Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СмйтШМςΨЯλиФΘшΝΛ():
    value = 571499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxfSO3k87YU8bimC/069ESQq9D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦЙЯΑνЪрονАοДЪмуч():
    if False and True:
        pass
        608
    value = 280753
    text = __import__('base64').b64decode('Q0ViTk9IMzBqZVlYRUFnbmVGNjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣшΧβйΔЕйХ():
    if 25 * 65 < 0:
        _dead_7049 = 373
    value = 454451
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCLQRn1p0/sVCl+123ubEz1380k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _κМаЦεашсζкЯΤЯх():
    if len('') > 0:
        167
        pass
    value = 764421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwaxYwIU0ZkaCyqJ0Aa+GnY19zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        159
        413
    return total

def _ΚшΡэМАШΤРяЕβΖ():
    value = 900699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXjCXFwU0po2DhyzxX29AjEB93Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яσπъМыЭΥσςйУηЗΗζ():
    value = 754422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj+0RWNg+5oXaR2L7gSZPnwh4GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΔψИΑбуπгμжξДед():
    value = 776662
    text = __import__('base64').b64decode('Q2Uzb0ZGbFVMT096Rk5vUEFzdU8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6901 = 844
        pass
    return total

def _РΧΑЯΗРτΓ():
    value = 921499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg69QX1hq4syCwrwxGyeYTwkwGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АуΓπЫъБтчςβЫ():
    value = 651236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiTleXwM/Z4mOxu68ES/GxZ61EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФπΖΟзЖθΣ():
    if 10 * 100 < 0:
        pass
        357
        pass
    value = 82721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD69XQEa/KkwYiGM0FK8HQ0g91k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΒшФпЫЮΔοхШюоБПЛ():
    value = 222130
    text = __import__('base64').b64decode('ckpSb3dhZVNfSUE1MFpxTFFyZEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑФбγтηνΑΦμоЦкяр():
    value = 66584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ew7SNlcS9pkMDBqmmwOWJRcZvGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υхОмЖтγΔ():
    value = 237016
    text = __import__('base64').b64decode('WVVWREpINElRMTZZTWVGdDk5SEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ВеηΡΤωΓΖФСЯωПΟы():
    value = 757623
    if len('') > 0:
        972
    text = __import__('base64').b64decode('d0VlbWl3TGtlRDZ6V2kyTlFIdFA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2677 = 841
    return total

def _ЙαСΠДшΛΘκ():
    value = 305846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MybzQAYr8qA0IFm23lOgYCYD6FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9864 = 933
        pass
        712
    return total

def _ΧЛеξπΘгΓЦγк():
    value = 719339
    text = __import__('base64').b64decode('Um1ybXBpcWsyUGUyc2RrR2JyTVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ацЗεЮйβοЮрйΚЛξН():
    value = 252288
    text = __import__('base64').b64decode('QkxsdHNwMnJ2ZXMybjEyajVpS18=').decode('utf-8')
    total = value + len(text)
    if 49 * 3 < 0:
        723
        317
        12
    return total

def _ЬЫЧуΨЭмзвΦβю():
    value = 354435
    text = __import__('base64').b64decode('d3hZVGxiRUQzNWt3R2U3dUVUaDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙэΤЬЯςНцдΗΘψИДЙо():
    if 91 * 31 < 0:
        _dead_8047 = 115
        pass
        233
    value = 563926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnjRZ0lq6PAPA1uFwleIZSIatXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τжгωюИйΟЙ():
    value = 193131
    text = __import__('base64').b64decode('cXl0ODRuMkFCVnFuek9lWGRsd3c=').decode('utf-8')
    total = value + len(text)
    return total

def _МΩπзΕΕОΚ():
    value = 530978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSPCOX0+04xQaheu+3WnMDd63k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΟрςηΘΞзςΜιКΡфКΠ():
    value = 759507
    text = __import__('base64').b64decode('cVUwT1ViOEhCRVVFX2ptVkIzd00=').decode('utf-8')
    total = value + len(text)
    return total

def _УиυсВΠОΚ():
    if len('') > 0:
        _dead_3322 = 983
        _dead_6698 = 248
    value = 641885
    if 46 * 86 < 0:
        _dead_7415 = 145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ3gSWQb8KshPgH63GedACofvGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 41 * 26 < 0:
        670
        _dead_1838 = 364
        pass
    return total

def _оуΗЫΑЩΡΣэрвПшθ():
    value = 757278
    text = __import__('base64').b64decode('TzV5UVRIb1JZT2dCM05qNE1DSE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΙΚйζцυхВШΚжЦ():
    value = 808030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HX/SbUkpx6sEOwHznkO9ECcpy0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фкЬтЦΘКπ():
    value = 351428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED6zP1wNyP8TMwuMzmCELXY27Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪЕοβЮεγдЫсмЪΗ():
    if False and True:
        pass
        962
    value = 207734
    text = __import__('base64').b64decode('RjFsMk1jUjdVemRaU0hUckdXT00=').decode('utf-8')
    total = value + len(text)
    return total

def _цеИБΨιδΨ():
    value = 578605
    text = __import__('base64').b64decode('SHJ3dkNtNTBrOHJDYUlzTTVMd3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _УβТЧЩОНг():
    value = 637353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CC7oWnouqfknOTqm2g+4IR1/9Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζшςфДоΕΞΝλчРхσЖ():
    value = 417323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HS7BXFo67PlaAD228FGGNxAFtD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _итмцяιΟГКΚ():
    value = 351321
    text = __import__('base64').b64decode('cGloSFBqbWNnZXNhRkR1WHY5YjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ιжΣоДΒХГРΩυ():
    value = 538738
    text = __import__('base64').b64decode('Y3lZaXozRnd3bXY1RFJMZHpFRTI=').decode('utf-8')
    total = value + len(text)
    return total

def _мηΟΩηДζπФ():
    value = 655284
    text = __import__('base64').b64decode('eGR3ZXpfVHNZOWZ6X0cxM29Mdks=').decode('utf-8')
    total = value + len(text)
    return total

def _уΤикΟΗмКΥч():
    value = 22814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHnMV189wYI5FCaAw3WzHBIQ/VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФХЦΞХДθмса():
    value = 888994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRv8PVkt37pSNhWs33ydPhE6ymU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦУъуФяωζЯвΨτйабδ():
    value = 272684
    text = __import__('base64').b64decode('WXRwVHZMOWZ3dE9FeE9TWHRYTWs=').decode('utf-8')
    total = value + len(text)
    return total

def _δкзбкуГρ():
    value = 617383
    text = __import__('base64').b64decode('eFlsM0xTMW5NTm9BSnhvaE1jcUo=').decode('utf-8')
    total = value + len(text)
    return total

def _РςпЪАΤΨυΚΞξПЦЦр():
    value = 273903
    text = __import__('base64').b64decode('ajNHMl9GcnRuQ21SbGNHaGx3bVI=').decode('utf-8')
    total = value + len(text)
    if 68 * 69 < 0:
        _dead_3088 = 254
    return total

def _ъьθсЗЭОοΦ():
    value = 605403
    if 69 * 1 < 0:
        _dead_7488 = 585
    text = __import__('base64').b64decode('VjkwYWV4NVVhVlVZMm1JTG1VVzE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        837
        908
        _dead_7710 = 695
    return total

def _щПεΓρΤτыφюО():
    if False and True:
        134
        pass
        _dead_5511 = 544
    value = 110773
    if False and True:
        476
    text = __import__('base64').b64decode('V3dKQkdONDh2dXJwQUROdmlFN1g=').decode('utf-8')
    total = value + len(text)
    return total

def _шεуΦΕщЮΔχιШпХ():
    value = 58856
    text = __import__('base64').b64decode('aWRIWUttaVRENWJfdzNDdUJZaW8=').decode('utf-8')
    total = value + len(text)
    return total

def _уяЯУΖйоζпМЛξψЖЭН():
    value = 355421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxrDeFQIy4QMAwac60WJEQADtX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖБΕПЛАЕθΧνМπПΞюР():
    value = 652922
    if 9 * 61 < 0:
        pass
        886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXbwO0QI8qoNODi0mE+SLgss7W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3069 = 494
        355
    return total

def _НдιПЯГлФцеΚяеР():
    value = 778244
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgrQdFM98YUAbB31+H6mGCl89z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щθΠьοΓэρΒГψхςЦΝВ():
    value = 106518
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzjHRGEy+4FXFiiW/VGlZnYF/l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑМфΘхкδшζФЯ():
    value = 477793
    text = __import__('base64').b64decode('R2lveUdHb3JuWmVVYmM2dk1aSW0=').decode('utf-8')
    total = value + len(text)
    return total

def _нσςБлТфХ():
    if 60 * 8 < 0:
        314
    value = 893103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH/dZFRq/PsgGFanyl29ZwwL4Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥМγЫзсЦПД():
    value = 745513
    if len('') > 0:
        80
        366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fir3a1gx8Z8maDqU8Vi4ZC0E00w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2973 = 946
        pass
    return total

def _СςАδΓгЕΛДНЭГФ():
    value = 782776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kwi0b2g1zKwrGRiP0EydGTIts2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πκΨЦюεеΣηψЙНжБО():
    value = 22489
    text = __import__('base64').b64decode('dVBvVk5VTmpuUlRsdW81dnVQOHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ФιхТУσΕВ():
    value = 115652
    text = __import__('base64').b64decode('Q0ZZNFFJU2FlaW5pVnZtVkFjQVg=').decode('utf-8')
    if len('') > 0:
        935
        _dead_8572 = 985
        704
    total = value + len(text)
    return total

def _ЖюЭΞпαсψСД():
    value = 915437
    text = __import__('base64').b64decode('SVZxcHpPOHdOTkh6YkpmTWY3VGU=').decode('utf-8')
    total = value + len(text)
    return total

def _φзΛιζΥмПфзΖςΑΩΧ():
    value = 153114
    text = __import__('base64').b64decode('Y2lMQWxWTnJxdklkNHJLdms1QkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮьУтβγСд():
    value = 557998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C37vSwAP2o1UbRqw4A+gGhQa20s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЛБДυМхоцΘОκ():
    value = 639514
    text = __import__('base64').b64decode('ZGdlMnowYXFjYk9LanAxcUt1TEY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        176
        _dead_5450 = 231
    return total

def _ЮЖςΦЬуλθЯ():
    value = 944210
    if False and True:
        pass
        _dead_3568 = 865
    text = __import__('base64').b64decode('RU1sZGJaa2drQlZ5SGpidEpyc3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΗυчяΡτТ():
    if len('') > 0:
        _dead_8124 = 994
        _dead_1319 = 454
    value = 963550
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCDMY1gGr7oVEy2S3Ua8JiAs52E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _наρПζУНе():
    value = 519842
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('T3pPWlNOUE5CUDZpMzVOSmlvMEE=').decode('utf-8')
    total = value + len(text)
    if 45 * 10 < 0:
        _dead_9869 = 684
        pass
    return total

def _ГλИбηжОв():
    value = 337894
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAzoQX4f9JErGC2nxHuWIhImxl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓКΩчШλΩЪεУй():
    value = 279566
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwX2XUM1pokWLgqimX2vEQ0j514='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΦρωζςωМφтЫл():
    value = 14210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxDSbGIO0PwqMAyI/1PILiQJyVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιвлΦзψшьЧч():
    value = 800971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDy1fkU48Kc3LQuo21qIAjF+814='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛυЛтρЛуΠТГξш():
    value = 143311
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D37jXVIR878WDRWA6WWANy8EyF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        424
    total = value + len(text)
    return total

def _ΔΨУЫΤΕαΣН():
    value = 298237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRfBe3Q47ZAXKASG8UeBLXJ683w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9786 = 501
        pass
    total = value + len(text)
    return total

def _ςΑТΓОНЯдыΠιθςЮвΜ():
    value = 444263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBn2fHIV9/Azbib253SoJn0ssk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дДГςθуΟμэЩрιШб():
    value = 228621
    if False and True:
        _dead_2545 = 619
        756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh6xYmEz0IwXblammw/DLSsn7js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 73 < 0:
        pass
        774
    total = value + len(text)
    return total

def _еэШυβчюОοсщбΛΘщв():
    value = 535844
    text = __import__('base64').b64decode('YUxQZHVZTmxrY0FMOGdzSlZ5dlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ТρΩΥШэλжΚΟЗ():
    value = 396989
    text = __import__('base64').b64decode('RGoycGc0czBWOHhKVkZHV0haZHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕнεЮΠΔШкΘтЭ():
    if len('') > 0:
        896
        114
    value = 536779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgTKRXI/8pk7biiK6mzJHgcp9ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖзηфΥςЩьΓПоБΦртε():
    if 69 * 36 < 0:
        pass
    value = 286017
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hyq1a0IWzf4BEwqTx0LAbHQjzlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЛΒΑΞωλЩΕТ():
    value = 77207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCLyOH4Q/ZhSFDCS+wS8FTIfyj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΚЭжκΦΕХΞаъ():
    if len('') > 0:
        _dead_6847 = 221
        309
        pass
    value = 794058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSi1R1orp54KKlyTxwHJEAQbtzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7663 = 183
        pass
        701
    return total

def _ЗΝуиΝэбЩγрξΨαΖъ():
    value = 813470
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwXAXQEBxqYlKCmAyXChYC0j1kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6832 = 584
    total = value + len(text)
    return total

def _κΞγЪφзшυЦ():
    value = 59425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwK2WkMLzI4TKwD23mmhEhF760M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΥЗΤνδμΔ():
    value = 781159
    text = __import__('base64').b64decode('Y3FPN2dGVEZuellZdUd5ZkhXZE0=').decode('utf-8')
    total = value + len(text)
    return total

def _здЮΜЯЖγЮкПΛ():
    value = 639278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjfhSXQ4554zIyiR8FvBESofyEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жЙрйТЕИЧψО():
    value = 124459
    text = __import__('base64').b64decode('RlpXTUdrY3hDZlJEenZHS3ZycFY=').decode('utf-8')
    if False and True:
        pass
        _dead_2815 = 326
    total = value + len(text)
    return total

def _РсτЩЖщЭΓζ():
    if len('') > 0:
        857
    value = 959163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCPbOVdv8IALDAaim1mSHnMFy3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЩфΦΝΗэшφΣχеζλб():
    value = 558985
    text = __import__('base64').b64decode('TW1pa0NTS2oyOFI3SWNBZ2tvTGY=').decode('utf-8')
    if False and True:
        _dead_3405 = 318
        pass
        839
    total = value + len(text)
    if 85 * 27 < 0:
        pass
        _dead_4887 = 706
        _dead_8009 = 222
    return total

def _ОфйεξξΒΟмΗсЧ():
    value = 268002
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiK8N3c9xIM5bAqV417DFjEc7js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1456 = 963
    return total

def _ΕττΨмεΞηцυοаΝΖТ():
    if len('') > 0:
        pass
        pass
    value = 276617
    if False and True:
        pass
        pass
        _dead_6128 = 98
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHewN3obyZdXIhe5z3y1EhR5zGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξιΑαрΡГхηΒЧζ():
    value = 212554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByLFN1NoppxaMCKR0m+iGnEQtGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΦπИζГекЮЛВИρψε():
    value = 285826
    if len('') > 0:
        _dead_8099 = 647
    text = __import__('base64').b64decode('UFlHdGhaRWd0aURrMmJveHpscTY=').decode('utf-8')
    total = value + len(text)
    return total

def _лВгΒθТбшТГρ():
    value = 929092
    text = __import__('base64').b64decode('Y2h2TnVnamZ5cHVBZXp3c3YzTmU=').decode('utf-8')
    total = value + len(text)
    return total

def _λуИЖдΓЧЦΡтμе():
    value = 398616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTnLPQA76YsgHD6V/0OJBXx8x2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮФΞκδПлχΛςвБЩз():
    value = 108881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgnDQWMY2701Exir5kSlLiQcsVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЖФΔΗβйΛφВξцщяь():
    if 81 * 29 < 0:
        pass
        257
    value = 800731
    if len('') > 0:
        420
        515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBizf3cg56YhPjub2mKfYj8+wWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 76 < 0:
        626
        _dead_3582 = 696
    total = value + len(text)
    return total

def _БЭξВЪрбЗ():
    value = 605558
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTzwa1Ab7o0WHAW320OoDisGw14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УфΥΩтюЮНОбψМ():
    if 13 * 11 < 0:
        280
        532
        _dead_1496 = 662
    value = 808793
    if 32 * 12 < 0:
        751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ngu8WwUG6YAFNwL3nwa1ZSIk72o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9122 = 479
        pass
        pass
    total = value + len(text)
    return total

def _πδрПθЮъгχ():
    value = 216806
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L36zSgY7r4wOPFm6z3+kYwsOz1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыξЧЦхыΩΦсΖλю():
    value = 331739
    text = __import__('base64').b64decode('dU9vbExCR0pQaDFzc1JqV0xCQlQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _αСφαρΝБπΧψЮФБ():
    value = 565356
    text = __import__('base64').b64decode('c3VZbGE2VDAyek9ER0FWY2FFejY=').decode('utf-8')
    total = value + len(text)
    return total

def _бντсΕΑΝξю():
    value = 442584
    text = __import__('base64').b64decode('RjU1WXByRnR2cjluRE5uTER3aFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ДЪсΠжΛЫРΣЪ():
    if 64 * 14 < 0:
        pass
    value = 210030
    text = __import__('base64').b64decode('WDF4VGVkODFIZ1BRalpKRUFZTVQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        718
    return total

def _АФΥяМфΒσ():
    value = 939410
    text = __import__('base64').b64decode('TFZFblBDMDFDUVJzc1FqUHRJT2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ςжТΨуФΤιχεЮΡУИр():
    value = 97633
    text = __import__('base64').b64decode('WExLV1ByUnlYY2lkcVdQTU1YYUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΝЦдШсОыи():
    value = 849237
    text = __import__('base64').b64decode('V052aUVuZTZDUFZ1eFVXVUlOa2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ХФтХΣЭЯмεΙΧМςтα():
    if 65 * 94 < 0:
        861
    value = 284491
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P378Vlk0yKoFPgmz0lqHGCY1x0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΩΑзжρΖρиΑыш():
    value = 777484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQPIZXMczv1VNFqv2WeAOnYk3Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦЯΣвσпЧΨвхβЛоΖД():
    if 69 * 86 < 0:
        390
    value = 30521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ER3yaXsr2q0CMTimmHy+ER860EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΖιжЙχЫΕуэЖΣγ():
    value = 844184
    text = __import__('base64').b64decode('RmN6VG80aXExQzFRSE9QZDRhXzY=').decode('utf-8')
    total = value + len(text)
    return total

def _θчΣЗгЮΕоΣИШз():
    value = 297249
    text = __import__('base64').b64decode('THdxZkl5YUJhYmdLamNWMzdRR3o=').decode('utf-8')
    total = value + len(text)
    return total

def _γφΣΚΙрΣьП():
    value = 884852
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQjnRAk4+7wrFF234XGjFxAtxTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZA==').decode('utf-8'))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()