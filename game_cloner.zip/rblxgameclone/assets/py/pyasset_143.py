#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΧЩКΜакγΞшλΘΣЩΛД():
    if len('') > 0:
        _dead_3517 = 881
    value = 401344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB20QHMp5qswNRz1mlTJNXMQvH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧγбΡθψВХЦθуКΠ():
    value = 587584
    if 99 * 55 < 0:
        999
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC78dgIbwbEZbwOw8k+pBy0ezjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _швЛΛвΔπΑκγнοψα():
    value = 298103
    if len('') > 0:
        pass
        450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDblbHIUwYBVHwGxn1fJBj0k808='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5764 = 80
        375
        994
    total = value + len(text)
    if 51 * 37 < 0:
        _dead_4479 = 831
        350
        816
    return total

def _БюΒьрЧЖΒΥΝΥи():
    value = 774688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHrWVkQj3JIXFD+NywKZLjc66jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 64 * 64 < 0:
        184
        648
        pass
    return total

def _ДζДαвλЛЦμ():
    value = 234233
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHizaG471olUNBvz7n6lASd59Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗμЧΝδЧжШющδоФ():
    value = 432856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBjoUXRh6o0wDwvyzXSkOBMiwFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8101 = 132
        398
    total = value + len(text)
    return total

def _λδЖΚвΩхУЩоνмΑЮ():
    value = 106642
    text = __import__('base64').b64decode('djR6dlkxZ1YzdHcyYXcwMkFNU1c=').decode('utf-8')
    total = value + len(text)
    if 5 * 17 < 0:
        pass
        151
        _dead_6123 = 847
    return total

def _БРдъЧνшкΟМиИδгЗ():
    value = 190594
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX/QNkM75qIACAy7z3CcEjYKzU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        685
    total = value + len(text)
    return total

def _ρБУςмΩьь():
    if len('') > 0:
        pass
        321
        426
    value = 333097
    if 16 * 32 < 0:
        _dead_9835 = 159
        _dead_9482 = 662
        964
    text = __import__('base64').b64decode('djJCM28zRTlNSnJGVk14Q1hYaVE=').decode('utf-8')
    if len('') > 0:
        _dead_2612 = 919
        _dead_4224 = 167
        582
    total = value + len(text)
    return total

def _ξχыкхРЙшУаЛ():
    value = 643036
    text = __import__('base64').b64decode('dkEwTnkyak96dUV3UThQa0dLc1Y=').decode('utf-8')
    if len('') > 0:
        _dead_5668 = 878
        _dead_8940 = 787
    total = value + len(text)
    return total

def _шιΒπΠΨγπδη():
    value = 884079
    text = __import__('base64').b64decode('ckc4MXRISWZiYTRYUE9hczhsUjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗШтеεзХиηДτГυ():
    value = 440156
    text = __import__('base64').b64decode('dFE5dzlINDJJMFN5SG51dEdXQzQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_6786 = 544
    return total

def _чΤНЮφБШунЮЕшψзКЕ():
    value = 494260
    text = __import__('base64').b64decode('ZUttQ0tBV3lnTXo5Q3BvcjRYN3I=').decode('utf-8')
    total = value + len(text)
    return total

def _λπΚξыДΒΣСГ():
    if len('') > 0:
        99
    value = 369638
    if len('') > 0:
        491
        _dead_9816 = 547
    text = __import__('base64').b64decode('cGJYUDF1eG4ybko2RjB0M3dRdXY=').decode('utf-8')
    if 43 * 78 < 0:
        _dead_3097 = 197
    total = value + len(text)
    return total

def _мЕэжδиЦЯЭπм():
    value = 154287
    text = __import__('base64').b64decode('RzI3bU83ZENVNVZ1UnpqUjZjRm4=').decode('utf-8')
    total = value + len(text)
    return total

def _уΙдκδΣСщηηятщΞ():
    if 35 * 19 < 0:
        pass
        _dead_5238 = 851
        936
    value = 583276
    if 65 * 69 < 0:
        pass
        _dead_5624 = 207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAG3b3wa66A2CQGv3nGCGycn3Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕэаЗΕоРΛ():
    value = 611193
    text = __import__('base64').b64decode('YzhRS1BOY056V1hFNWF0QkU4ZHA=').decode('utf-8')
    total = value + len(text)
    return total

def _мωохЖжЬЦΟξγτς():
    value = 339131
    if len('') > 0:
        pass
        815
    text = __import__('base64').b64decode('dHdpbEw2QnczME1OVlZESjVrTnE=').decode('utf-8')
    if len('') > 0:
        _dead_7795 = 658
    total = value + len(text)
    return total

def _СфйПцγщΝЧфЕμΝлп():
    value = 165283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTn8RHkJ15gRGBaC632YASYXsEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΠыщЕТβχρΧФЦгΨжΥ():
    value = 991793
    text = __import__('base64').b64decode('S2JTNzZldXVjckpIaV94a0JSTTA=').decode('utf-8')
    total = value + len(text)
    return total

def _εΟУжэеЛФиΟ():
    if len('') > 0:
        _dead_2984 = 110
        _dead_7707 = 469
        26
    value = 637677
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSTGfUI7yKMaMAeU6ga+HnUO/Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 6 * 1 < 0:
        pass
    return total

def _ГσΝКλМьИΖУлХΡ():
    value = 498706
    if False and True:
        557
        110
    text = __import__('base64').b64decode('U3ZqMlgycGhUSEVkdEpvVmxmcEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮжΥυюΞΡбι():
    value = 634867
    text = __import__('base64').b64decode('a08ySTJzc2tWQndPVWJvWFVfMWE=').decode('utf-8')
    total = value + len(text)
    return total

def _σΚыВГΙΖζ():
    value = 145493
    text = __import__('base64').b64decode('Zl9nRUpxZ2daZVhqMk5CSHVHVkM=').decode('utf-8')
    total = value + len(text)
    return total

def _кφЗδПΩзΕЕЯχ():
    value = 363997
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzrMYHgqrPsxNl+W21KxLC4+72M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖсιЗыЦΞБβЯΡцЖьч():
    value = 738159
    text = __import__('base64').b64decode('WE9jSWM0Yk9sTTFmbk53ZzZ6NUc=').decode('utf-8')
    if len('') > 0:
        814
        pass
        pass
    total = value + len(text)
    return total

def _πЛκлαΨЛКНηВυ():
    value = 721175
    if len('') > 0:
        pass
        _dead_6108 = 983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBzTfgY1+rEGAhuCw3SCORcj4UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _κκэΨΘДτгмКМ():
    value = 864303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSO9ekUgr7sBKCqZ3Wa8MCIb5ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λοΚЕбΞьяςуккаюЬ():
    if len('') > 0:
        466
    value = 894835
    text = __import__('base64').b64decode('ZXlvU1d4SlJ6bGJ5OUdGenNBNDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ХРΓяпΣЧЧфспΙσ():
    value = 673133
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('Z0RxaHIyX2VUQnFGN3lWMDJPbzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬбыαХСξΕο():
    if 85 * 86 < 0:
        _dead_3671 = 577
        _dead_8586 = 451
    value = 558607
    if 79 * 33 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fh7tfl0Uy6YVGxeE6lKbZX0s9Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7627 = 581
        _dead_1470 = 736
    return total

def _ъфХξΟьЬΗ():
    if len('') > 0:
        _dead_7413 = 660
        507
    value = 683638
    if 51 * 4 < 0:
        _dead_3349 = 202
        _dead_2735 = 527
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAvBQwQp345VPQqy31qFDjMh9Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3878 = 685
        892
    return total

def _бШδБπΡзΩтγЦяЧ():
    value = 250437
    if False and True:
        724
        648
    text = __import__('base64').b64decode('VXFwdkhnTFRMQjU5X2VOcHFwTmM=').decode('utf-8')
    if False and True:
        pass
        _dead_1021 = 420
        _dead_6294 = 81
    total = value + len(text)
    return total

def _НХШΔΤνωЩрСτςЩΓЫ():
    value = 940145
    if 89 * 77 < 0:
        pass
        _dead_6742 = 419
        _dead_4737 = 989
    text = __import__('base64').b64decode('ejlybnpBZmYyeFFwOGNXcjJ2dUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕЖΥдλЕюρ():
    value = 89009
    text = __import__('base64').b64decode('WHk0WTFTQWpTYUh2RXpuc3Fyekw=').decode('utf-8')
    total = value + len(text)
    return total

def _щкрΚьηУХΟьуЛМ():
    value = 410293
    text = __import__('base64').b64decode('Uk5ldEMxMV9ZalIzQmd5cGVXa04=').decode('utf-8')
    total = value + len(text)
    return total

def _οΩяΦΕПξЯ():
    value = 590001
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgbofnAB7LgoHjyg/XO9ABcqyUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 96 * 78 < 0:
        pass
    total = value + len(text)
    return total

def _ЮπОΙСюΚеΦδΨΟГΠбΤ():
    value = 240770
    if False and True:
        221
        _dead_5366 = 611
    text = __import__('base64').b64decode('Z0lKekVIRW1Gd3c4RmVLNEFta24=').decode('utf-8')
    if False and True:
        _dead_4247 = 272
        613
        pass
    total = value + len(text)
    if False and True:
        _dead_6209 = 629
    return total

def _юσΝοвΒζτνжгЪβук():
    value = 940476
    if len('') > 0:
        551
        _dead_1919 = 732
    text = __import__('base64').b64decode('dnIxVVk4TzQ3cXFQOG56YW1LNDM=').decode('utf-8')
    if False and True:
        _dead_2883 = 549
        pass
    total = value + len(text)
    return total

def _δЖκсΦεвξκ():
    value = 936695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETr0SgIP0bgUb1eT0AOXOiEBvT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕοъЧγΓаψχ():
    value = 508522
    text = __import__('base64').b64decode('UTJpWnZJZW9ZUlRpelU1VVBLaGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ХяςιнβаъΦяχΧΥшΝΧ():
    if 41 * 65 < 0:
        619
        pass
        938
    value = 967755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXrqPAcN0IAwLxaVw2aqIncu52g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _οьЭΒСЛθь():
    value = 384831
    text = __import__('base64').b64decode('dkw5eTFHMmNHdEc1ZEJKN3E0Rzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤαУвЙΘΦГπμ():
    value = 935121
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhbeZGcyq49WNTry23GAOw4A1Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГμНΘπταΝЙδГмиΗδ():
    value = 430335
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MASybUQa/5shPR2Hm1qFBwIXwUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζыхТЯχГЦξη():
    value = 748861
    text = __import__('base64').b64decode('V3kzTFgwN3QySkhacVVERjZubG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ПСЯξΡΛевКУДΠ():
    value = 456481
    text = __import__('base64').b64decode('Rk1NOXBmZVh4QXJfRE9HWTRxU2s=').decode('utf-8')
    total = value + len(text)
    if 19 * 8 < 0:
        pass
    return total

def _ννбЛΡτλΨОй():
    if 66 * 71 < 0:
        _dead_1722 = 149
        _dead_4407 = 537
        pass
    value = 51494
    text = __import__('base64').b64decode('Y3NZZWhXc3owcERnY0hCZk5XU0Y=').decode('utf-8')
    if len('') > 0:
        _dead_9780 = 996
    total = value + len(text)
    return total

def _вμζΥЭХГνШξ():
    value = 485051
    text = __import__('base64').b64decode('Ym10OEpDcXI0TzFrWWhUX3I3WFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓМкοОяшОφκ():
    if 86 * 6 < 0:
        204
        501
    value = 373578
    text = __import__('base64').b64decode('a3VmdjZaZVA1aTVmTVNQcnRYWnM=').decode('utf-8')
    if len('') > 0:
        _dead_6968 = 655
    total = value + len(text)
    return total

def _яцμλΖσΗйМзенЦХИв():
    value = 174633
    text = __import__('base64').b64decode('bmtuVHl6VTFYRkozMnFDbXVGNHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ъΝΖπηНЫЖφИΦГф():
    value = 859304
    if len('') > 0:
        _dead_9504 = 747
        _dead_5576 = 97
        _dead_6123 = 96
    text = __import__('base64').b64decode('VTVaWG15TTRwaDR1eEExRU1Ya1I=').decode('utf-8')
    if len('') > 0:
        _dead_5963 = 153
        _dead_2703 = 207
        64
    total = value + len(text)
    return total

def _зРΞΓμНωξШμИЛ():
    if 97 * 27 < 0:
        _dead_8925 = 527
    value = 324163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3rjfmgxyI4waDaA5HPIPhMOyGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4940 = 797
        _dead_2659 = 68
        931
    return total

def _ΟуцзΥбфмэΖьΟЪП():
    value = 616724
    text = __import__('base64').b64decode('eWNxVGhFUnVVbk1iRkZZMGRXcnE=').decode('utf-8')
    total = value + len(text)
    return total

def _уЬΗνΠГЖΩΖнтПСУ():
    value = 903552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXmxQX80qqAuMxqxy0O1EicOtFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РεзПшдαляαсΟНδ():
    value = 944237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAi1O0JswZ4aOAqL2VOWDgglvUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НяπζΖшΜэваξЛΛςИΗ():
    if False and True:
        437
    value = 589418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bgr+PlIt3fkRYzWkzl6fAQEct0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝςΙШΑыКΨДΘН():
    value = 214823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXfVOH0A55stLwK17XWhCxd7xX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хсвуΒаоЮЯаευоχж():
    value = 119461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiT1XEgY+YUiIjz620ORHHULvFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2635 = 631
        _dead_6574 = 309
        pass
    total = value + len(text)
    if 38 * 92 < 0:
        pass
        pass
        117
    return total

def _τАчΝςГзЬнф():
    value = 685156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjXbb3oc7bA0MiKCyVyVFTYN9Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ювТЧΥВхΥьр():
    value = 350277
    text = __import__('base64').b64decode('RlhzQks4ZlZGSVZYRWlMZ3NFRGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ζμιоГрΠиНХ():
    value = 567321
    text = __import__('base64').b64decode('TnlZbGlKUm12VUJhekVSYlVMNjM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        501
        pass
    return total

def _оЙБщΦΟμнβ():
    value = 269522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQb1PQhs3axWNF+CxHezE3cW92c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΓЕляζАоζΡΣξаΤ():
    value = 598488
    text = __import__('base64').b64decode('clhBOFZDTFZzaVM3M2NPSUluajA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙяΩдρкνЙЫЦщΣΝжΞΙ():
    if len('') > 0:
        pass
        pass
    value = 875131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ln7dfQUe7YMMGCT2wlKkIjN9tHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΕПдκΛабηдςуЦ():
    value = 322008
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxfseXAP2oAuAASb7QaXLDEN/W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЮюΜδЮРΠαχь():
    value = 135136
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('b0ZZMFJTNVZOQWx0MnpidG0xMlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞПψξμЯФεД():
    value = 792079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyvIfEsX7ZsrNhWk0V7FEAkA6jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_1159 = 388
    total = value + len(text)
    if 5 * 84 < 0:
        _dead_6944 = 333
        347
    return total

def _ДъΕλΙьςβγτΕМ():
    if len('') > 0:
        _dead_3405 = 693
        349
    value = 326054
    text = __import__('base64').b64decode('V042RUdROFdwaW52RzlBTnJ6Nlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ТюμΡΘвДлТ():
    value = 298271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXfMeXdq6vEnNAOp/Vm4ITd97D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        49
        978
    total = value + len(text)
    return total

def _уΤριЯцЮИδю():
    value = 134347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjqxaFo764MhLgGO536mZi0QvDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        804
        pass
        390
    return total

def _γнЖμПΩВБгвΚюыж():
    value = 963154
    text = __import__('base64').b64decode('Um9Ud3pLdlVjNFdDMjVMaVE4RzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _φΕσйЫАΤм():
    if 82 * 4 < 0:
        _dead_7056 = 171
    value = 393100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C37hdgkO9aJUDDyK/lG6ASgF/T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5076 = 749
        _dead_7920 = 769
    return total

def _ЬΡοбяΞМдιδβΣУн():
    value = 651792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3rtQnRp9oIVHw2M4kSaZwwE7mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ποΟΕγΑνΤОИэгС():
    value = 30622
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDzrQWETppIhOA773m6fZD0X5jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭзξТЩΩΜПкюΟЛкχУЖ():
    if False and True:
        _dead_5457 = 80
        _dead_8166 = 70
        pass
    value = 726007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDrlZAc79v9VaVix+neBYxcmzVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙεφμνΥδΝτα():
    value = 742397
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw23NwJuqpEZPx2pwwOoJhoN6To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щъчΕоЮУДъЗЖξЧΤгυ():
    value = 189540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH3IN30UzKBXbw6knGKCY3ADz2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9089 = 327
        pass
    total = value + len(text)
    return total

def _бзΨωнЙΥЯкξВ():
    value = 963392
    text = __import__('base64').b64decode('bmZ2dkw5VDFoN2g2cXlHUmI1Umw=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_4362 = 891
    total = value + len(text)
    return total

def _ΖπьρГДζАЖΠб():
    value = 515751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IT/Hb1Ig+54oMQ6522ymIyp252Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 27 * 43 < 0:
        81
        308
        pass
    return total

def _ξМаκΨΕΒоΒхЙн():
    value = 807102
    text = __import__('base64').b64decode('c3NNUUhpQU1DV0lCa3kxcl9CRUM=').decode('utf-8')
    total = value + len(text)
    return total

def _шδтΛНρВΛεπЗΣ():
    value = 341301
    text = __import__('base64').b64decode('bnBzeHVIdEdfMjhLX1NEVWNUdzE=').decode('utf-8')
    if 32 * 34 < 0:
        _dead_7734 = 558
        pass
        pass
    total = value + len(text)
    if 58 * 13 < 0:
        pass
    return total

def _ΚεЮξЦξΩΑ():
    value = 846181
    text = __import__('base64').b64decode('WUs3OVhTaDJqN3NMQVNEbUVBUHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕοтφΜκоπ():
    value = 151954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwDmSn41rbktPBfw2F++BSoHs0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΓкΕΑМΣΩФ():
    value = 86662
    text = __import__('base64').b64decode('WHBjTmdZcHJIVHhGMVhZNzBQd0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЭНУаΒοοЪБδΚ():
    if 13 * 27 < 0:
        pass
        246
        293
    value = 429368
    text = __import__('base64').b64decode('bUt4SGVVZkdWZUR6WDl1T3gzS1U=').decode('utf-8')
    total = value + len(text)
    if 100 * 41 < 0:
        pass
        681
    return total

def _обΜкΣцхΧНЙΛΓЦЦыж():
    value = 768176
    text = __import__('base64').b64decode('VEprdGs1RUtFMEFUd0FnQVFQakw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞξмχШТΜлДвτΖ():
    value = 287195
    text = __import__('base64').b64decode('SkdxTmtjcmRZdFFxQnpfT3JMazU=').decode('utf-8')
    if len('') > 0:
        909
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _нυДχчΒξЮЫΨлЦΙΜИ():
    value = 613653
    text = __import__('base64').b64decode('U1kxMEFGeE1ob1h2cHhRaXpsRUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕτбΩКΣнщХЕР():
    value = 233997
    if len('') > 0:
        197
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P37uTEBq7/sVEBzw7A6YGDcXymo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _уИфпияАγΣж():
    value = 547110
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBbHN1Iy2Lk8aAT7+XS/JTQZwGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьюπлχΝПФ():
    value = 462777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex7+RwMj0YcBPACNx3qAPHQizj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΘωГβИЕдхЬЙ():
    value = 745578
    text = __import__('base64').b64decode('Zjd4N3ZWX1VYMWZva3MwMkpTSmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΓДιδΤΩНαЯЧΑ():
    value = 389941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aju2Z38b5PlXHzyu3V6oBzZ992I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΥщэΞЦЪσьυ():
    value = 697503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBf+T2Qw1KoJaw2T4Fq7GnYe7V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОцΤдΟφΖοаУяу():
    value = 446483
    if len('') > 0:
        431
    text = __import__('base64').b64decode('R3lWM2tqVDBGcXhXcWxZVWtaV0k=').decode('utf-8')
    if False and True:
        _dead_7988 = 812
    total = value + len(text)
    return total

def _ωДαНшгωЪь():
    value = 929242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDzOZHoAr70zEla53UbHIHV21Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 100 * 15 < 0:
        _dead_3908 = 2
        835
        299
    total = value + len(text)
    return total

def _ΞЩΛΗЙЪРςΔЫΚЖοуяξ():
    if len('') > 0:
        pass
    value = 370009
    if 77 * 75 < 0:
        pass
        _dead_4464 = 61
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQW3WHMx658bFCWH/XCgJgJ75mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εямсфτдюЕΣΒй():
    value = 957415
    text = __import__('base64').b64decode('ZE1PUno0djJRUkNpNmVaSUpRMko=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑρΙΦбτЧЕПИ():
    value = 146660
    if False and True:
        170
        _dead_4574 = 374
    text = __import__('base64').b64decode('bWZJOHVYTVJqdHZqUTRpcm0zSTM=').decode('utf-8')
    if False and True:
        _dead_1974 = 901
    total = value + len(text)
    return total

def _рνξΜοиψУ():
    value = 908372
    if False and True:
        823
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECy9R2AM8bkZKgKc5Q+XHCQ11Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 44 * 3 < 0:
        _dead_8842 = 244
        _dead_4654 = 841
    return total

def _τлМπξФМяМοЗИ():
    value = 685473
    text = __import__('base64').b64decode('SVlrOHVWWXREd0taTGlEdko5YWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕσФоЕЯйΖЖтжΤλЦФ():
    value = 310127
    text = __import__('base64').b64decode('eHRDT0FuM1h3cXdUYlhNbnNZSkw=').decode('utf-8')
    total = value + len(text)
    return total

def _иЬьЪΖζЖΦΚ():
    value = 910760
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('TU9qMnZHWkVuN19LWFVmbk1xNWw=').decode('utf-8')
    if 72 * 94 < 0:
        _dead_9554 = 963
        _dead_4196 = 666
    total = value + len(text)
    if 91 * 16 < 0:
        pass
    return total

def _ШλμпЯПаθЭрЧВ():
    if False and True:
        _dead_7150 = 328
    value = 935074
    text = __import__('base64').b64decode('UkgwVU5NZG5lYWN2SU04b0tfd0E=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        735
    return total

def _ΣθДВΖЛοφнΧΙ():
    value = 178707
    if 62 * 91 < 0:
        _dead_8779 = 118
        _dead_4513 = 670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiLnXUcT278iLgSvygOHDSd8yD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ΚТΛКЖкюΨ():
    value = 716414
    text = __import__('base64').b64decode('ZlQ1Z1JDTl96QTRicjNuRmw4Ymk=').decode('utf-8')
    total = value + len(text)
    return total

def _πхПρыεΝΗлΟфИΗ():
    value = 550812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDv0eHVgy/8oHT2l4kKIYBM1t1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞХиΟОЫθИФд():
    value = 441381
    text = __import__('base64').b64decode('aldPSWZNczRLdGJYamJpUVM3TkY=').decode('utf-8')
    total = value + len(text)
    return total

def _λМЮΕΗΝστЩчΧ():
    if len('') > 0:
        516
        500
    value = 498989
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDiwaAQc8L80AgSckHqKZiM5zjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        364
        pass
        736
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_7034 = 389
    return total

def _КТПюоеифΡΖΗМин():
    value = 894109
    text = __import__('base64').b64decode('bkFZaTdqT1BUektmNF9xZll2T0E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        697
    return total

def _щоУΗБιЮыΧΧэФцю():
    value = 265855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhrAfAE78oI3PAy5/Ea9LHwFzVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        706
        86
    total = value + len(text)
    if False and True:
        pass
        689
    return total

def _НШЙРΑΝйцν():
    value = 997747
    if 39 * 10 < 0:
        337
        772
        211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSD+f304q6kmMQ6c3VeVbCQ44X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        103
        732
        _dead_9763 = 676
    total = value + len(text)
    return total

def _ΠΕЛςΑΔазΜΗμ():
    value = 725081
    text = __import__('base64').b64decode('ZkhIZERaUm9zdm05ZDhyV2ZaZTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔюЗΒАвЬНтЩъзΔαФЕ():
    value = 79649
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgLVRH87q/EpLgyNz062LA52wVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        251
    return total

def _кολвсОζνРΘм():
    value = 560792
    if len('') > 0:
        595
        835
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwThY10B04oaMwKUzW+8ZjcN70o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эБцαγнΞАπжКцЛ():
    value = 87298
    if False and True:
        146
        742
        262
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3jQaEg4/JBSaj6U7w6ZbT8WzUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        568
    total = value + len(text)
    return total

def _ПΡюУоγоΠΩШХМ():
    value = 834199
    if len('') > 0:
        80
        pass
        556
    text = __import__('base64').b64decode('WmtIME55c003QWpUbUxXMUxnM3A=').decode('utf-8')
    total = value + len(text)
    if 22 * 13 < 0:
        194
        _dead_4994 = 646
        _dead_6451 = 416
    return total

def _ЗСιΞЬτΔП():
    value = 118385
    text = __import__('base64').b64decode('ZHVnRUgzREYzdjdwYXl4VlZYRWo=').decode('utf-8')
    if 3 * 48 < 0:
        _dead_2710 = 120
        814
    total = value + len(text)
    return total

def _γανБлыΧГ():
    value = 253043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxvvQGcY3P8raA6s2gSSJwwu6X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        510
        57
    return total

def _КЬЮбΨУСφφаМ():
    value = 50667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH3rbAQdqoASDTeb4VioHg0K7jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6165 = 173
    return total

def _ςэШгбУЧЩоβбΦЯл():
    value = 252229
    if len('') > 0:
        _dead_4488 = 504
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy3cW0cS/YsPKC2P51/INjQ/3Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        422
        pass
    total = value + len(text)
    return total

def _πΙΞЬζξФΒуξшУуΖ():
    value = 666640
    text = __import__('base64').b64decode('YmpIN3A0QWhhUFphWnNKc3p3TVc=').decode('utf-8')
    if len('') > 0:
        _dead_9921 = 640
        161
        _dead_4506 = 885
    total = value + len(text)
    return total

def _ХλΝΤбΨфПЩΚΞτΗ():
    value = 167127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MX2wb1kq7qE5MwKa3FKxPi4c0X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙМзгγηхъЪэрМЛЮΚ():
    value = 331513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQXFX1ovrYw2LAiswHGIOgwZvVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠБχцлбэπεοУЩЭ():
    value = 127577
    text = __import__('base64').b64decode('UmxyS01LcEFGX3RtSGJPbXZZWEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ФНРЯЖМХΙΗштЮ():
    value = 200324
    if False and True:
        328
        31
        pass
    text = __import__('base64').b64decode('cjJMWkJMN09qbVprdlJ0clVSM2s=').decode('utf-8')
    if False and True:
        935
    total = value + len(text)
    return total

def _ρλΖχвЯμтьНГλα():
    if len('') > 0:
        _dead_5018 = 475
        410
        _dead_6349 = 456
    value = 883052
    text = __import__('base64').b64decode('a1dHSG9lbG9Wb0ZpTThnRkY4V08=').decode('utf-8')
    total = value + len(text)
    return total

def _ξЬНаφЗπжνωχЫХ():
    value = 606219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pyb3SEIe368LNReO/0K+IHA17k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТйΦΓтΕИцδΥΖМх():
    value = 744375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXfwbH0XrZg7FCT150WfHysj8jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯгффПынф():
    value = 806448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTXdQlgTrKcCKDmSy3jBDgIE6Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΠΨоцψβфКЮуοмАр():
    value = 858075
    text = __import__('base64').b64decode('TmhqTW1FWkFHc2VldTNMbnBaZE8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4148 = 829
    return total

def _ВςηΗΓЛнζиΞζ():
    value = 117068
    text = __import__('base64').b64decode('SG5zbGY2OEtMczZBbkpzQ0dPU2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝйΧфСнКШλхК():
    value = 837766
    text = __import__('base64').b64decode('aWpGYWUybkRXMU96MUo2R0dqNGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _μΒБιΔяψΕ():
    value = 718337
    if False and True:
        _dead_5322 = 251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JArmZGMq0JsrCCGV5n66PRV80F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξНЙшзсгГ():
    if False and True:
        pass
        617
        _dead_8599 = 642
    value = 137862
    if 47 * 19 < 0:
        614
        _dead_4440 = 238
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnvMTwQT26daYiqs/nGYEA8B3jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛЗкиοΠωΜйε():
    value = 283633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQjSOWAK/4YLChupzlqZHwB590s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1644 = 83
        _dead_9193 = 125
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _мυИыХЮλР():
    value = 890504
    if False and True:
        915
        _dead_2753 = 32
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E33BZ1AopqsvOR/12meeJHUGyjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2569 = 243
    return total

def _ыΛзΣζπъфτМ():
    value = 547209
    if 36 * 91 < 0:
        297
        _dead_1738 = 944
        359
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih/wegkV1f4aPDuR2Xi9O3U94l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒμΕЧπОШΓ():
    if len('') > 0:
        _dead_7915 = 47
        _dead_2689 = 861
    value = 723587
    if 51 * 98 < 0:
        pass
    text = __import__('base64').b64decode('akp0cGdUcGZuR3ljbWpKTlZfNzQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        356
        287
        209
    return total

def _йοΒχнМΗбВΝΛ():
    value = 107703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnfNOVQc5qovNwC17AOoMAMHwFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сэΓΙΦΝΦщЙΩιбжΒ():
    value = 362594
    text = __import__('base64').b64decode('SHB4cjFOcjJNQ2Zkd19rRU1SSU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΥτГшαεΡйΒο():
    value = 988171
    if len('') > 0:
        201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyXxYXxv/bgMIFfz2V2CAhQb10g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ИςΧρгΞоЕМζκТЕпА():
    value = 281430
    if False and True:
        pass
        _dead_8015 = 687
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRDiQUUg8IEhECmm/UfJJXcG/lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОШВцδЗΒзξъ():
    value = 16753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhmzTUYx+4Mlbz3yz32gMHQuxX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 46 * 12 < 0:
        228
        145
        pass
    total = value + len(text)
    if 60 * 13 < 0:
        968
    return total

def _ςЙΧыΜδΓςЮн():
    value = 527096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwPJYAMa1qpUBT+35mWqNjIa82c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖφΥαУηυСБΡлЭ():
    value = 719222
    if False and True:
        _dead_1945 = 294
        439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXb8OkgO+4srCFqp5VW1YhU8tjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οфΚΦрРшΤπΝΒΒΞ():
    value = 116157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBexTQYK2/0CCzms/n22IDUfzkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦιχЫУδωОтНφЯ():
    if 17 * 18 < 0:
        pass
        54
    value = 469104
    if 11 * 49 < 0:
        pass
        pass
    text = __import__('base64').b64decode('VlFkcUliRDZOeklGQlpqY0VmdVE=').decode('utf-8')
    total = value + len(text)
    return total

def _чεщРεцНΦЛΧн():
    value = 907829
    text = __import__('base64').b64decode('S3pMeU1xZ0NlSk9iOEtpRTIwVUI=').decode('utf-8')
    total = value + len(text)
    return total

def _зψЯьФЕзлшТЫхгζ():
    value = 490927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhblaVU1rrA8b1yJ7gSKJikZ9Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 22 * 16 < 0:
        199
        pass
    return total

def _САΖΓβиэрУη():
    value = 772288
    text = __import__('base64').b64decode('bVFna1ZqWFhtUzBLZkJnWjJXQ04=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬПΑглЪШМиπΧп():
    value = 709742
    if 39 * 10 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDu0Wl9r9oY6PlyO5GKWMAgF4k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1093 = 625
        _dead_8427 = 724
        pass
    return total

def _зκиΥΒΣκυЩж():
    value = 708663
    text = __import__('base64').b64decode('YlJzNVlnVmFQZ1lrZnpQcU1TTnY=').decode('utf-8')
    total = value + len(text)
    return total

def _αθвΘΝШчОφЫЧцХЩ():
    value = 210137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQvnd0cpzIokHTmRmQWUOSR+yFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3233 = 465
        _dead_2212 = 319
        983
    total = value + len(text)
    return total

def _νЪβЯςОφрАлйΦуΠ():
    value = 76296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAmxY0Uw3aYtD16X/lDJASsfynY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΙрΔнζφΝР():
    value = 700811
    text = __import__('base64').b64decode('eDVJT2FuQ0JSN0VHbGFaUEV6ZGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ИПяШΦбьяЮуΟТлрΒ():
    if 7 * 81 < 0:
        540
    value = 375843
    text = __import__('base64').b64decode('VTdjWFhzaDhZdWp2UEFDYUYyUEI=').decode('utf-8')
    if 92 * 56 < 0:
        pass
    total = value + len(text)
    return total

def _зДтуαъиип():
    value = 882393
    text = __import__('base64').b64decode('VGt3WjhhTzg0XzdBTU1MMHo2Tm4=').decode('utf-8')
    if 54 * 31 < 0:
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΜдθΛβυΥгЬчΣ():
    if len('') > 0:
        188
        pass
        pass
    value = 64534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQjbQ2QY7LtULQeb5Ga/PhQDz1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 53 < 0:
        _dead_3888 = 691
        708
    total = value + len(text)
    return total

def _НΒВдгхθвςΨΑИШкΨλ():
    value = 74907
    if 62 * 55 < 0:
        _dead_5708 = 325
        _dead_3104 = 351
        _dead_4973 = 531
    text = __import__('base64').b64decode('SWxOczV4ZWV5SWU2TmRDN2dpNFA=').decode('utf-8')
    if False and True:
        pass
        872
        pass
    total = value + len(text)
    return total

def _ХдρшзБТΡ():
    value = 67173
    text = __import__('base64').b64decode('RFhXckdBTXVKNXNmbENlc2xGTjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ФьпъТяйкφюс():
    if len('') > 0:
        _dead_6065 = 44
        919
    value = 299869
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3rWUXtg9p0JGTWG0W6AHTID510='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 39 * 31 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        952
    return total

def _ΦΞλЦмψиоЙЛυ():
    value = 773310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAnmZkUg57o8PymPynS5NSEA8F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИтΡδΔьπΔ():
    value = 964205
    text = __import__('base64').b64decode('TmdzcTEzR3EzWW5LZk96WVcyWkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖгΜεΔΦар():
    value = 873701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXbzfVIDqK8LayqTng/JJn0dxn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔрьΕφΟςфМЖψνΣд():
    if 36 * 84 < 0:
        846
        pass
    value = 602405
    if 15 * 43 < 0:
        _dead_2903 = 484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBDsN2Qv27tbLjqS4V21BBAE7Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мβьΑυΜγн():
    value = 989624
    text = __import__('base64').b64decode('YTA0MEVkM3cweFBlUXBaNTZidkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if 80 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()