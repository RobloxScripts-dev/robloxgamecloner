#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _кξκρюЦерблΨН():
    value = 504955
    if len('') > 0:
        _dead_5135 = 86
        _dead_6171 = 778
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETXxSQBprZBTLz6p2FHDYQ9+x28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПμΒЪйфЙΔхраηΧπ():
    value = 439383
    text = __import__('base64').b64decode('TnE2WUVBcVF6VlhZTll2MEFJNXg=').decode('utf-8')
    total = value + len(text)
    return total

def _бюΒπφПΓрΜЗδ():
    value = 105062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT3uPFcV17EBDlynwmCFNzUBskg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κЦЭΩэμωΠΒУ():
    if False and True:
        _dead_1761 = 535
        151
    value = 749360
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw7uNgMryr4qHR+q/GaTLCk2vXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъеχВχтαβдЧцЗбΖ():
    value = 336210
    text = __import__('base64').b64decode('dXRZOU10WVZfdDBEMWNxTENBUXY=').decode('utf-8')
    if False and True:
        991
    total = value + len(text)
    if 65 * 30 < 0:
        pass
        _dead_6838 = 24
    return total

def _пεΣΓΑгУжшψПΚЮ():
    value = 763097
    text = __import__('base64').b64decode('UDdMeWt3U1FHa1FmZnZJdlRodms=').decode('utf-8')
    if False and True:
        _dead_8661 = 921
        892
        pass
    total = value + len(text)
    return total

def _дηхβжщΥХΔ():
    value = 130469
    text = __import__('base64').b64decode('eklQVWF2bHp3SFFlZ2hTNzdMcmY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        687
    return total

def _ЯσШΔКψЬδ():
    value = 410766
    text = __import__('base64').b64decode('aklyV1FQeVYxd1NFOHR1NEtocWk=').decode('utf-8')
    total = value + len(text)
    return total

def _χеθШθЯЪΟ():
    if len('') > 0:
        184
    value = 731846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXnrflNsx501Agygm37FOikb6zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4009 = 570
    total = value + len(text)
    if False and True:
        566
    return total

def _ЧΜΙΕшряρΣΘк():
    value = 43002
    text = __import__('base64').b64decode('VWh2U2U4Q1VHcTRmbXUxN1pHd04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜдзЪΘμЗΜЭΒниФΤшρ():
    value = 90115
    text = __import__('base64').b64decode('ak1hSVIwU1gxd1ZEd3dXWkRNNW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔзхщΖρЛΝΑАΤλΤэв():
    value = 950611
    if len('') > 0:
        _dead_2183 = 348
    text = __import__('base64').b64decode('aTJNQkZhWXZaNkthaWVhNW9VVWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ιПАΞХςΤпНфаЪИΜ():
    value = 150049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhfWdgA6p5gPagmc2VGAYRIitmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1462 = 471
    return total

def _ПηЖВμкмКРьνΤΝδЪ():
    if len('') > 0:
        pass
        _dead_7324 = 491
        pass
    value = 521818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQXlWUIq76YFal2wm2TGECw1yXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        953
        _dead_4151 = 278
        pass
    total = value + len(text)
    return total

def _УьπЦΗЩкν():
    value = 969187
    text = __import__('base64').b64decode('UjZBbkRfOTBUM1RvSUMwN3VZakU=').decode('utf-8')
    total = value + len(text)
    return total

def _зОωиЮяκЫδΥвθГпч():
    value = 421147
    text = __import__('base64').b64decode('THVtdnlpV0RhMm9zTHlwSjZpWmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ХρеСΜлЦΩДПΡνф():
    value = 605636
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dwnlb0Mg2aVTLRe72m+6Fw88w3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪШΟфΙрвΤρЮΚхОЯΔЦ():
    value = 548232
    text = __import__('base64').b64decode('SW1MYVp4S2M4VWJXd2Q1Rk1WR0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΟКΩЖΠГοσΩМ():
    value = 956118
    if False and True:
        pass
        _dead_6084 = 364
        pass
    text = __import__('base64').b64decode('WENSQ0R4R24zc2QyTUxvMWhJMEk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        927
    return total

def _ΒυΤеПмчθьλρьψЩм():
    value = 412668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyPUOksLrIo6DA6O72afNnR27Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        306
    return total

def _ΨЭθπиюΦηпθΧΦГ():
    value = 819034
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MC7IUVkg+aIoKleX0XSaBSAXvGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шιθЮΓΘкв():
    value = 402810
    text = __import__('base64').b64decode('VWtwU1dQa0NIc3FUbGtJTHpPMW4=').decode('utf-8')
    total = value + len(text)
    return total

def _μΩччТλфЩ():
    value = 1629
    text = __import__('base64').b64decode('QVhFYzRGZFd5aVdUVlBQRlY4RXA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖςчЦсйЪоφξυΦΓзуЭ():
    if len('') > 0:
        332
        pass
        _dead_6333 = 712
    value = 31995
    text = __import__('base64').b64decode('elM1NVZpWHF1WTFPcXgxYkk1NFc=').decode('utf-8')
    total = value + len(text)
    return total

def _νятфςλωΔξψςμΔΝу():
    if 66 * 1 < 0:
        pass
        321
        89
    value = 429922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQ7nemYV9YEoNiCXnECvHgp59Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΣρуΟεыΛΣΜΡ():
    value = 376520
    if False and True:
        744
        958
    text = __import__('base64').b64decode('SE1tQVNwWVpldEJJZ3JoOXBLOVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒжξТηуνιЙЦΖЕм():
    if 89 * 77 < 0:
        pass
    value = 878024
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwjjRFkd86UTKT767VynZDwF63g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝэΞΑжοΔыДрΛмχтΗ():
    if 10 * 99 < 0:
        pass
        _dead_4364 = 753
    value = 165526
    text = __import__('base64').b64decode('aGdRYklzaVRYX0lfZzB3NHJsQ2Q=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8734 = 255
        313
    return total

def _ΦгΜыэЬЦρ():
    value = 121037
    text = __import__('base64').b64decode('UG1KUXR4UlpyWTVOSnB2VHljdnQ=').decode('utf-8')
    if len('') > 0:
        pass
        379
    total = value + len(text)
    if 13 * 20 < 0:
        408
        _dead_3866 = 72
        _dead_8171 = 71
    return total

def _ОоκмгΠΠυΦцΦμ():
    if False and True:
        _dead_9803 = 598
        pass
    value = 250902
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxnrXgIq86oWPA302GfIO3AQ6VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9862 = 994
        _dead_5008 = 668
    total = value + len(text)
    return total

def _ТΛζбЪЭιЯ():
    value = 407145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kxv0YGg90608CCecmAWUBxQ2yWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦдЧШПНσШЗσ():
    value = 194876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhXUSEgQ35oEDSOX63ScE3MY0Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        25
        762
    return total

def _ΔЫГΤΛоаΝиΩСЛМ():
    if len('') > 0:
        _dead_3932 = 470
        _dead_4684 = 45
    value = 632556
    text = __import__('base64').b64decode('Zjh2WTBmaUlyb2JQUDlKaVljVHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛщγдψΛΖВξЮи():
    value = 535289
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyngSVce2rsrYgaLzwC4PhQN9F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4867 = 282
        590
    total = value + len(text)
    return total

def _φзИΓоΖмιε():
    if False and True:
        pass
        15
    value = 379191
    if False and True:
        pass
        328
        846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBzoSwky0q8OFSSC8XG6ABwu9H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αλЬРАБъНкоАΨшТФΜ():
    value = 683213
    text = __import__('base64').b64decode('a2ZfSWZzNzlJaFBWaHBWOGNhUHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮгУСлλгιθоΧсθΥ():
    value = 499514
    text = __import__('base64').b64decode('QzFXUDVIUUtVNkE0NUdBNkpGU0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘκЕжхУвйДШΑΝ():
    if 63 * 26 < 0:
        pass
        649
        418
    value = 759848
    text = __import__('base64').b64decode('c3F3T3V3R1B4VEFBemtobzNTeXA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9246 = 915
    return total

def _ыψμоШЗξΒ():
    value = 219822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQyxfkE8zfwiPQO7nleeBXUmy10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΖωκзтψшщπ():
    if 23 * 60 < 0:
        411
    value = 936720
    if len('') > 0:
        978
        _dead_1077 = 46
        955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pxr1WktpyZAKMQWNkEW4Cxp96F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 75 * 100 < 0:
        pass
        pass
        pass
    total = value + len(text)
    if 92 * 95 < 0:
        _dead_5409 = 489
    return total

def _АОΥτЪβфХ():
    value = 496812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj/vYFQe+6kJHRmW3lmEIDIM4XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΛЪΩбΞЗМ():
    value = 694336
    text = __import__('base64').b64decode('TVVYa3RRWXZSVUZuTFN0S3BIMXk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1206 = 304
        424
    return total

def _СМΨоΧδшн():
    value = 993517
    text = __import__('base64').b64decode('Znlva3IyOHl1eklxVTh6QlllaWo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _чΔΖМуΕНοоЗμ():
    value = 898256
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwjhWWIO3/8hDlqqwF+kNxMO5m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΙεЯюμςЗнГ():
    if False and True:
        60
        134
        _dead_4914 = 717
    value = 286261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCyxQkkv0Z0hBSSh8UWlAy4l3mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜМаиВτАπгЙ():
    value = 458373
    if 65 * 8 < 0:
        pass
        pass
        575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSbHRnkc6fgBLjiJymSTPTMm6Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηрιюДомЛΤθ():
    value = 242204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BirDf2IY2rgXPQuOxX+1Onc3sFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σнυъΘδЬΔЗζПΩВХ():
    value = 500955
    if False and True:
        _dead_1761 = 302
        pass
        691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSrxZlho9YApBSf08EG2OQkC3mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        528
        pass
    total = value + len(text)
    return total

def _ЭфΒЭаΩμЦΥΡγΕй():
    value = 148926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSb3YUIJ5K9aAgeA5kC0BgIBxXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        419
        pass
    total = value + len(text)
    return total

def _вэΝЪУтнΖΡζςШυ():
    value = 259394
    if 40 * 51 < 0:
        _dead_4265 = 727
        440
    text = __import__('base64').b64decode('R2xSR0ROVEt6YWVlaE56d3dEX3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣεспыΥΥчΒΑΛ():
    value = 148033
    text = __import__('base64').b64decode('aHFsb08wSDV4VjQ0WXNfYmhRYkk=').decode('utf-8')
    total = value + len(text)
    return total

def _УαыΟΔΗяГφд():
    if False and True:
        152
    value = 75642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxrjWH4M6aFTHDfynVulECIFw0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 66 * 97 < 0:
        971
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _нжХВжτЫαу():
    value = 982783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwDeaXIR2qMmChWQzFmGIjEV72s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠефвхфЙΜЕЯкщЯр():
    value = 555380
    text = __import__('base64').b64decode('ekZ3aHVKRWdOWm9Nc1RBSXBEMDc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9498 = 223
        pass
    return total

def _ЧωхщфΠщЬζφΥЕπеоΟ():
    if False and True:
        923
    value = 199219
    text = __import__('base64').b64decode('SDNCS25IMGVHajF4YkJxOFM5V1Y=').decode('utf-8')
    if len('') > 0:
        309
        _dead_6042 = 915
    total = value + len(text)
    return total

def _ΑΚйцДΝΑσтΥЪΦдΗДΞ():
    value = 952262
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQLQZ3A6/a4JODeV/HeaNhQY8Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜаъΙЮУщнσαщ():
    value = 125271
    if len('') > 0:
        647
        _dead_6339 = 789
    text = __import__('base64').b64decode('bzRQeU42cDJnUEVtMFRyWWIxMDU=').decode('utf-8')
    if False and True:
        _dead_1834 = 435
        439
    total = value + len(text)
    if False and True:
        _dead_8189 = 345
        99
    return total

def _ЗΥТмйτъλиΜΓβΗΟй():
    if len('') > 0:
        _dead_4911 = 785
        _dead_9746 = 448
    value = 442471
    if False and True:
        _dead_6599 = 302
    text = __import__('base64').b64decode('eXZyTzYwMk9OX0VMUFNsM2VJdFY=').decode('utf-8')
    total = value + len(text)
    return total

def _χхЛУβωящьяАЛМПΒо():
    value = 149786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ER3zb0Bq6rIGNCGg2EGXGyQQ9k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕψθΟЬсиивыщΤты():
    value = 983263
    text = __import__('base64').b64decode('UTdsZVlVd3pPZm92R0RxOGZtTXo=').decode('utf-8')
    total = value + len(text)
    return total

def _фΩОГуθЭщфыИ():
    value = 152542
    text = __import__('base64').b64decode('TkU0MklVUzlGc0NobGRKblZWNm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ηξΕМГθщЩΜ():
    value = 134466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDXnfGU46oBbFF2kn26yITwWwHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_6942 = 938
    return total

def _ЬЩфЪЕζжβАψуΑгΓЕ():
    value = 356581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwHueVIP1qNQFBaq6WyZMSQg5UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8290 = 375
        pass
        pass
    total = value + len(text)
    return total

def _σΥклйνΚиΣΨЯПЬл():
    value = 754047
    text = __import__('base64').b64decode('RFBIckZNV0R1anNDZ1dmUUZ1RnE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЯεЬΚЬвΤбЛ():
    if 75 * 64 < 0:
        pass
        668
        pass
    value = 481793
    text = __import__('base64').b64decode('Z0lGb05ZQXlBVm9ienJ5Zzl5akw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5596 = 19
        _dead_8760 = 819
    return total

def _НΞРρΞФχгΝ():
    value = 579520
    if 81 * 70 < 0:
        778
    text = __import__('base64').b64decode('bVR1OWowOE5KQkdud0dudzhFb0g=').decode('utf-8')
    total = value + len(text)
    return total

def _вГΞΩХехн():
    value = 887500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSTjSl070LoJbDyy40aoEjQtwzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘроΠμΛХοлαчЛΕйΒ():
    value = 80287
    text = __import__('base64').b64decode('bXpYVjNtdFZwOXdfX3hwcHNLUGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ФμЯΤБкеЭщШλΣ():
    value = 32587
    text = __import__('base64').b64decode('UjhkWlFGWFoydTJXdHVFU0F1dVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝцАюиςЙЖοπуΑ():
    if len('') > 0:
        _dead_1324 = 194
        pass
    value = 135418
    if False and True:
        pass
        _dead_3829 = 550
        878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx3lP2YBxphUIjCFnFubGiIB808='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κμИцФЗιΔщжκΒдщвп():
    value = 485238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQOwZmc87bk3Ml3y72LGYjw8zlc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СщΚφСαΝκιюдвщтЮы():
    if 86 * 7 < 0:
        pass
        447
    value = 359830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgfXWVMy0o9QCBqNxnK4PA0s4XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δДΩНΡΒΣΚу():
    value = 923804
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSm0SkA7rbsGYy2y5VmRBC8g/X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дйсςкфчμДβ():
    value = 605880
    if len('') > 0:
        pass
        35
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRrDQEJh6aEKEivwmVmdAXQY9UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νωъГЕяππ():
    value = 633545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSDlXwY6yLo3Ah637FO2FhUIwUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        397
        pass
        pass
    total = value + len(text)
    return total

def _ζйχщсφэΦξз():
    if len('') > 0:
        pass
        _dead_5655 = 489
        773
    value = 511860
    if len('') > 0:
        _dead_4508 = 632
        708
    text = __import__('base64').b64decode('eVFFbVAyZzRiSE9ONloxSTZaTFU=').decode('utf-8')
    total = value + len(text)
    return total

def _аВОКРхиШψωюкνЧЕΖ():
    value = 111569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzfGN3tu75kJDlm0xW/BMS8AsGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 90 * 32 < 0:
        pass
        _dead_7282 = 763
        786
    total = value + len(text)
    return total

def _ΚГφмдΚсψд():
    value = 295301
    if False and True:
        pass
        _dead_7309 = 777
    text = __import__('base64').b64decode('TFk0YXVCRXdhQWdNX2ZSMUlYRnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕжцΚЭтВρПЧЬИТηΣ():
    value = 294097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3vwWAEQxqwxLyyLnmWdIAM492M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γВМχНτчИΟстΖ():
    if 77 * 19 < 0:
        451
        630
    value = 500163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JirtegMX8ao6Aya051G0EDM842E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧфдХωыΨЪΓыκТЦх():
    value = 360632
    text = __import__('base64').b64decode('T3l2cWtuN2hCQ0lWZ0tzd3k1SGI=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ηΠЧτξЕΜΧЕΚ():
    value = 592750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR3WV3o8x6wqbjug/kWKLQ0F7Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΟΨипьчιΦΤДХ():
    value = 923488
    if 37 * 51 < 0:
        340
        268
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQPLTUI26/0bAgX093ezPnMQ4Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6798 = 793
    return total

def _хшщГХΖфеЩΛχЗΔт():
    value = 568046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3fHYlc7yblTHQLz3kHAYzEOwlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЛΒΧοнΓτΙΛΚТαΚэ():
    value = 933938
    text = __import__('base64').b64decode('RV9GX0JXX0JaX2pXMzVDWVppYW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣφИσдΘСПΧ():
    if 70 * 1 < 0:
        _dead_8197 = 553
    value = 755224
    if False and True:
        _dead_8022 = 523
        _dead_3105 = 679
        _dead_8032 = 425
    text = __import__('base64').b64decode('R0VFUXN5VEd2a1pEY19VNEF1aVo=').decode('utf-8')
    total = value + len(text)
    if 34 * 52 < 0:
        922
        pass
        _dead_2874 = 654
    return total

def _ΜΤΕаνθζΓΝХъγΙбξ():
    value = 311637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx23fFY7r48MPAP6/lmFPzw1zms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зкχкхгΧфΛА():
    if len('') > 0:
        pass
        pass
        _dead_8591 = 494
    value = 681078
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAHVOmRh54IRMV6H0kGkOwwkw00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4310 = 706
    total = value + len(text)
    return total

def _φΗтЬьфοъ():
    if False and True:
        pass
        _dead_5221 = 916
    value = 638833
    text = __import__('base64').b64decode('ZFV1UGMzM0FwUm9NTHZnWWYxb1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _υРλςшγАЫ():
    value = 428873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDXjSlMyy6AXPl6Sy0CUFxB66z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тλМФσщУФРьпβΒΕц():
    if False and True:
        _dead_7831 = 715
    value = 139973
    text = __import__('base64').b64decode('YTFBUEhTcndZVUZxSnpFSUpIS0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥшτЪЦλБη():
    value = 525792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjfTaGVv6KcgEguU43meLHwG40E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щωжСЦЭΘЪЖф():
    value = 849543
    text = __import__('base64').b64decode('UGRlQjFLeTk0TGtvbUg4ZHZUc1o=').decode('utf-8')
    total = value + len(text)
    return total

def _γШбΜЫфΟσКя():
    value = 741219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASLWewk/xoopLBWP7VGVMQgj01s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρэВЧсдΖУΗн():
    value = 764870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3byXnYz6JEXHh+6/UXCBHA5vUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if 18 * 78 < 0:
        pass
        196
    return total

def _ЬΜΡΣиηΟΟ():
    value = 43922
    text = __import__('base64').b64decode('UWtUWTdoWm1XYXVPZkZKSXhfa1Q=').decode('utf-8')
    if False and True:
        _dead_6502 = 871
        821
    total = value + len(text)
    return total

def _ΨζωкΝОκОП():
    if 76 * 100 < 0:
        _dead_2187 = 100
    value = 218506
    text = __import__('base64').b64decode('aUdDbHRJZEJNTDJwQjFTOWMxUnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ШβМдЛψКюлς():
    value = 302107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fn/WOQkv9YAzPzyu6lXCBwcO1FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8028 = 133
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_1316 = 818
        294
    return total

def _αмйЕΑΩВяΒωвνАн():
    value = 129363
    text = __import__('base64').b64decode('RWpTaTZPbFNqbm02azNFNGwxT2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЛιΞпСΡυЗσ():
    value = 322204
    text = __import__('base64').b64decode('TGZGcGtsYTJBd1FjOXo3V0FlbUY=').decode('utf-8')
    total = value + len(text)
    return total

def _юлФЬηсΖЕиγэζЩφΕ():
    value = 475420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgLWZwY27L4iPCqr8WO9Pjwj4zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΣиΗвοσХΝдν():
    value = 819304
    text = __import__('base64').b64decode('VzlwMlZZcVFfVlczSHpyTGNxcDc=').decode('utf-8')
    total = value + len(text)
    return total

def _длΡοΗЪйЦэЦЪΔσ():
    value = 932102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz/UYXsg0P8UPFab5Q7EMyku4mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΟзΖμЦфсцЕьйаβЛ():
    value = 794057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgLUf3s+0oUOPF+l0Uy9MAR48Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еНяξΞМΞυп():
    value = 317907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAL0YG4155sgIB71/ATAFnY1zXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сЯЯΟьηνΝьп():
    if 67 * 11 < 0:
        568
        pass
        252
    value = 735881
    if len('') > 0:
        37
        pass
        668
    text = __import__('base64').b64decode('YmFGNEpsVUkzd1JyN0NPOVdTTGk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6403 = 517
    return total

def _ЦΩешпΒЮПхЕчΛкзЖ():
    if 51 * 48 < 0:
        _dead_1800 = 13
    value = 517184
    text = __import__('base64').b64decode('R1h1NWpBZTN2aHFwdW5PT2xzZTY=').decode('utf-8')
    total = value + len(text)
    return total

def _кΗДΥДωбСМЩщй():
    if len('') > 0:
        pass
        241
        pass
    value = 813206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3z3PmAYrvo0a1ia+AWWbHADsXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        539
        _dead_3046 = 236
    total = value + len(text)
    return total

def _ВΒазΙуЮнθ():
    value = 536447
    text = __import__('base64').b64decode('aGhxUkdEUW8zNXNlNWlZemoyRG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗСδΩεςФЫΥυ():
    value = 392513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M37AdFMu7IoyHyK3+V+oYhY85mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚиρЩьφЙкΔ():
    if 57 * 8 < 0:
        pass
        194
    value = 690629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx/hZWQS6ZIUIleo7AaeIBcs1jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1826 = 727
        428
    return total

def _ьДЪьЖΠдхТΠЯдΔυ():
    value = 700701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji2zegUP76AKPiCgmXC2GQQa6Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕνРОГЫбПб():
    if len('') > 0:
        145
        890
    value = 387190
    if False and True:
        pass
    text = __import__('base64').b64decode('Ym9WcXoyZzVRampidmlGNERvMVk=').decode('utf-8')
    total = value + len(text)
    return total

def _κπΦеτΤΣЦΦхСЭЦАПЯ():
    value = 664818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAvuewQf1oA7IlatkVmWZB82zT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χЭΧεσЫРЮΔСΙ():
    if 72 * 70 < 0:
        pass
        _dead_9929 = 358
    value = 261469
    if 70 * 41 < 0:
        _dead_9937 = 654
        pass
        234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Byu0alk47LE3GD6pwkygZDM11jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШУωЩеиΩΒΙиВμеПΩ():
    if False and True:
        _dead_8050 = 512
        803
        _dead_7281 = 397
    value = 817649
    if 13 * 75 < 0:
        pass
        850
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB3WdHAQ0poGDS672F/AGwEdzEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _РΗμъдБΘЩΘДуξДа():
    value = 805825
    text = __import__('base64').b64decode('aHhnUWIwRFZpUXF0eFl3VFVrMEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΠЖИΜЩμΕжеЮЮ():
    if 61 * 12 < 0:
        319
        pass
    value = 279288
    text = __import__('base64').b64decode('ajBCSkIyajhWX1dwSGtXMDZsc3E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _уРоγθωτφι():
    if len('') > 0:
        252
    value = 65119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXnoSAAsqLkPExmoz1+XYyEHsXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 62 < 0:
        pass
        pass
        153
    total = value + len(text)
    return total

def _βΑραЦΨΤеТ():
    value = 685809
    text = __import__('base64').b64decode('TVdhaldpb2JSNEdvTUpic1NhSDg=').decode('utf-8')
    total = value + len(text)
    return total

def _СΚКуЩпхиоΡψЖЬВН():
    value = 744946
    text = __import__('base64').b64decode('bW9BejM0MkNhTnd2aWtVS2Y1a04=').decode('utf-8')
    total = value + len(text)
    return total

def _θωςρЭΣьКΦэΖк():
    value = 165184
    text = __import__('base64').b64decode('cHN1R0N3cDZabzQ5S3ExT3NRWmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _рδаыΩΤΨнπСЭΝΧПБМ():
    value = 400369
    text = __import__('base64').b64decode('UF80YUlKbGZQVWd5RExGRzdDT1A=').decode('utf-8')
    total = value + len(text)
    return total

def _игЯлЯγβσвмΒ():
    if False and True:
        pass
        88
        _dead_1375 = 511
    value = 973754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRfhdGQJ9q1QBRWM0XLBICQZ8Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        986
        _dead_1511 = 785
        pass
    total = value + len(text)
    return total

def _πρВуΚщζМбЧЭМшδ():
    value = 749254
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBrXd30TxJEIIwmp/nGaZnUl5VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟйΟΜΖΨъэ():
    value = 203482
    if 89 * 82 < 0:
        106
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCvAaQIe9K4OAjuEkVGEbRct9lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 23 * 31 < 0:
        pass
        pass
    return total

def _ξшΖЪΨСρыΟИγа():
    if len('') > 0:
        455
    value = 182215
    if len('') > 0:
        _dead_3812 = 931
        pass
        _dead_3658 = 784
    text = __import__('base64').b64decode('akRGS2pabXRQR09QeVNocjZRNGs=').decode('utf-8')
    if 39 * 11 < 0:
        111
        574
    total = value + len(text)
    if 94 * 4 < 0:
        62
        pass
    return total

def _ъαΔψЛХтЦΤ():
    value = 710783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXjvRQI7p6QVO1iJngezARwj6Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σβкΗазШЕВЭЬе():
    value = 840178
    text = __import__('base64').b64decode('Rmo1RjRnVUxLM09xbERXTGlVbHE=').decode('utf-8')
    total = value + len(text)
    return total

def _оΡηтΦηОΓШ():
    value = 849468
    text = __import__('base64').b64decode('T1JhVHFreklvVE90anZGUEZXdEw=').decode('utf-8')
    total = value + len(text)
    if 7 * 17 < 0:
        _dead_1151 = 845
    return total

def _ЭСΜдбсΠИКхьΟτ():
    value = 548390
    text = __import__('base64').b64decode('bmVyU3o2amVkSTM3YnJVeXZTNlM=').decode('utf-8')
    total = value + len(text)
    if 23 * 53 < 0:
        _dead_7502 = 276
    return total

def _гМНηЛбβгДγε():
    value = 950048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXm8Zwgv74AgFSqq/HTAOSZ39Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΩλДякΡΞςΣ():
    value = 690824
    text = __import__('base64').b64decode('VHFVS2lQVW5ja3loWjliUGVOV3A=').decode('utf-8')
    total = value + len(text)
    if 22 * 34 < 0:
        222
        644
    return total

def _ζЪκеΟυкΜμΒцРςЯ():
    value = 476760
    text = __import__('base64').b64decode('V0xCVjJCVHBtVGlVbXZuSWtqZWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝθδзΟЕяΘПФАдАоеσ():
    value = 70736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHjMT14g0YwOPB+n8X3CCxUtwEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 17 < 0:
        804
    total = value + len(text)
    return total

def _δэШиΟкΡтЦψяζ():
    if len('') > 0:
        732
        803
        _dead_9275 = 772
    value = 932733
    if len('') > 0:
        825
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ND63XEY22/EHMwqu8UW5Yzc2ykM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тКЙИΡρβр():
    value = 275465
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj7Ke2YfzY40Kj2c4lecFyYn02g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΨкνΤэхпОυЪΝΠУ():
    value = 592609
    if False and True:
        pass
    text = __import__('base64').b64decode('TzJnQWZkUjdZemF5YzlDRXRFdGk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3674 = 104
    return total

def _ΧЗФлΟΡсхФюΞуψжΦо():
    value = 49414
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwaydntgrpIqLVr7kVSnLR8Y908='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γгфΞьιЙщАяξΞРм():
    value = 219289
    text = __import__('base64').b64decode('ZkRHZXMzTldTQ0lJQkx6TTB1N2w=').decode('utf-8')
    if False and True:
        292
    total = value + len(text)
    return total

def _ЭэеЫΓηщΚьΖэьβΔλЧ():
    value = 216392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzXjeFg6r48AKzWX0gWEBiZ5/kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5360 = 335
    return total

def _γπΦЫфβκеΗ():
    value = 615850
    if 95 * 2 < 0:
        pass
    text = __import__('base64').b64decode('Z2JuQTFsT19LMmY5WE9HanNtR0Q=').decode('utf-8')
    if 10 * 33 < 0:
        246
        _dead_1153 = 780
        pass
    total = value + len(text)
    if 7 * 37 < 0:
        pass
        71
        _dead_4324 = 180
    return total

def _νΥЮмΛэΒт():
    value = 807172
    text = __import__('base64').b64decode('S2tZbXBhVDdpYWFXUFp2RVhvWV8=').decode('utf-8')
    if False and True:
        _dead_9576 = 411
    total = value + len(text)
    return total

def _МрИΒхηЧКκΟ():
    value = 457116
    text = __import__('base64').b64decode('enNTY2NhMmZtaF91MWQzMndZUHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙТЬоРЯΙΡиЦйЙκ():
    if len('') > 0:
        pass
    value = 830247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBuxV2EA2aoBHVuX7GzIGwIlvFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шЛдЭθСΔΠΞшаΙИ():
    value = 129844
    text = __import__('base64').b64decode('ZmdfWTFPejU4V2t2dXU2YzZHY3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΝЖГФδуЭ():
    value = 618585
    text = __import__('base64').b64decode('T19nYzgyRTJMcnZ2Q1hPOVdURUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΗЧщфΡЧщнЯΖΘЕθγ():
    value = 942666
    text = __import__('base64').b64decode('bzEzUDNuTGdPMlBmT0VQYl9RZ0w=').decode('utf-8')
    total = value + len(text)
    return total

def _АОζЙэωъЪΧвщу():
    value = 674060
    text = __import__('base64').b64decode('STdNRHdPTEd0TWF5b0VVTVJiQ2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _νрЪыεΞΙНЬ():
    value = 19868
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRa9bGEN8rIGFQOy32zBGyM79lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БбΒХδЩвΥх():
    value = 432988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ay3lfAg49qI5HS367lWSDgwt8Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        137
    total = value + len(text)
    return total

def _ТЙοЖЙУИщΡсБωμΦР():
    value = 993712
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCfueH83zJJUDh+KmEWHGzMV4lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эπПςьχΚПбκТΠХъпΝ():
    value = 517169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyfJYGhhqo5TKAua+FqSZgZ4yHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5327 = 290
        pass
        _dead_2670 = 110
    total = value + len(text)
    return total

def _БεХЙАΞΟκъΕэσλХЬ():
    value = 419821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQjORVoc5pIoMVehnmnHFjco5k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        813
        _dead_6040 = 778
        pass
    total = value + len(text)
    return total

def _гυСβκλЩшАдЛлΔ():
    value = 322339
    text = __import__('base64').b64decode('R0Z3ZDNGSjRJZTlQS1VfaUtGbDI=').decode('utf-8')
    total = value + len(text)
    return total

def _УΗЗАхΤβлнЬονЧЭυλ():
    value = 785596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx/IfWQs5LINNACk20GFFwIf8F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        398
    return total

def _ФУфХпРщγЮθФщЪ():
    value = 237125
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQbBb38N/LEWIi7wmmSKLhU5x1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΖωПОЩλΓμт():
    value = 28695
    text = __import__('base64').b64decode('WGxNNGptNnVFYVh0Njg2bGg5aUg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЩЦРφΑεВьяσжМηЙоТ():
    value = 315416
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IATtZgEMqbkmICKk30eRHBQmw08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟσΥДγΖΜαРеΞоυΩуф():
    value = 13400
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fh/SbGI71o9bbViX0XmZZQEq3kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΚκΗцπχтлοУЩχ():
    value = 446981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICjARFIRrvERLlaw41WbZAoe72o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _деЬДФπΩΖдХш():
    if 6 * 38 < 0:
        _dead_8009 = 554
    value = 601984
    text = __import__('base64').b64decode('ZFBnOGc5UVRYUDlPNUZ1RFJtZHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΜΧЧΔИΩВΒο():
    value = 659474
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQLIXQIz2qE3NB+qnGO+OTc+0Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρМРъАΚλε():
    if len('') > 0:
        _dead_7578 = 485
        pass
        225
    value = 870091
    text = __import__('base64').b64decode('c0pXZ2J6WWFCUFBWZl9ZTXVyelE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙуЙΛйвЖθтκЕηДщ():
    value = 620711
    text = __import__('base64').b64decode('ZkwyR3hsNkxRek1kMl9BYXJ0UGo=').decode('utf-8')
    if 78 * 100 < 0:
        924
        _dead_9382 = 237
    total = value + len(text)
    return total

def _кСПцяТьЮιΘ():
    value = 857260
    text = __import__('base64').b64decode('djJJemliNnRzUjVPMkRpY28xdUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _εшδΡЯСΣЩяЛЬΟνχΦФ():
    value = 89440
    text = __import__('base64').b64decode('eHBoU1F3SnB1R1ZJZ01NcFhwZDM=').decode('utf-8')
    total = value + len(text)
    return total

def _СθΨεατδШУΒъ():
    value = 363958
    if len('') > 0:
        491
        _dead_3252 = 420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn3gRlIexI0qDlay5kaBAQYV9lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 93 < 0:
        _dead_5807 = 923
    return total

def _ΟΓмψΠюβЩρФΚкяХ():
    value = 460198
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyfVQXoLqfExAgCA8kW3N3QZs34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑуШαΗЭφОЫεиηΠуР():
    value = 133416
    text = __import__('base64').b64decode('QmQxS2JWaDExTVlLVW1mUGpia0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣχкМΤΦΙιψдкδλйг():
    value = 547088
    text = __import__('base64').b64decode('eWt2eEtUMWNCZlEzR1liMjVOTzA=').decode('utf-8')
    if len('') > 0:
        _dead_5721 = 67
        291
        921
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7538 = 711
    return total

def _щчЕВбвДзΧР():
    value = 408125
    text = __import__('base64').b64decode('UW1wT0tIZUZmUDVEV3F4WUJfRWg=').decode('utf-8')
    total = value + len(text)
    return total

def _уΝУΘιРζлюΥМπΒРО():
    if len('') > 0:
        68
        _dead_6581 = 546
    value = 936685
    text = __import__('base64').b64decode('WHpnZGlFek5oUW5McWFMemhWZEE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4655 = 504
        _dead_7755 = 566
        723
    return total

def _дΡСэОщΒНЗЙβΦ():
    value = 120071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3v1ZkIs+7sSDSmxnlK1Ywp81z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лыπФфцЯτΠьΦ():
    value = 329277
    if len('') > 0:
        _dead_9345 = 169
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwrAaAUfr74zHy6q+GevFQR+/kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 57 * 49 < 0:
        636
    return total

def _υЖγгСыΞγбΟаПфуΛ():
    value = 451606
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3vId1xrzaJVPyKz/Xi7J3Q6wXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЖΠаИφσςСΕμΜ():
    if len('') > 0:
        762
        _dead_5166 = 625
        _dead_3302 = 696
    value = 139591
    if len('') > 0:
        76
    text = __import__('base64').b64decode('dUd3MWdBWWZ6TFRuQnJjN3U3ZXo=').decode('utf-8')
    if False and True:
        _dead_5539 = 751
        pass
        pass
    total = value + len(text)
    return total

def _фКЖΩωйнЪ():
    value = 433899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETy9SnQP+ZEXHQSLwUWFERQb1Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦρΔВсдаςч():
    if False and True:
        pass
        pass
    value = 579240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwPheUY42r8tDDqV/gPFEicY72I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρДΣΕμЪΝрбПβЕΛ():
    if 33 * 68 < 0:
        _dead_4694 = 700
        372
    value = 675104
    if 50 * 54 < 0:
        pass
        _dead_1301 = 22
        _dead_4072 = 650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BivjOQIt2rIJPVyrn3uzLi42xWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2149 = 878
        pass
    total = value + len(text)
    if False and True:
        975
    return total

def _ΖΧлЙΥΑюзЮИКбΝОч():
    value = 114845
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSLdOmcP1pICAF6E3AWbPAAB61Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βэβΡкωЕйΓ():
    value = 396034
    text = __import__('base64').b64decode('Wjc1YmhFWk12T3ZMcE1wS1FTVnE=').decode('utf-8')
    total = value + len(text)
    return total

def _СαюαРЖеЬθΜлзКΟ():
    if False and True:
        45
    value = 549599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDm3SHYqrq0SbCepw1vDHxY592g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2803 = 171
    total = value + len(text)
    if 90 * 45 < 0:
        253
        _dead_1176 = 139
    return total

def _чъΚΧЬЯαтηΔ():
    if len('') > 0:
        pass
        _dead_2157 = 786
        460
    value = 164894
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnjzalMa7aEALFqWnHuaHBV38UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФрзΖωΓЫγАΝАπ():
    value = 448188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDXAUVoX/bwUKFiK3FCeFXY1/F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иχиЬшΠΞН():
    value = 987991
    text = __import__('base64').b64decode('ZjZlUlc3YXhob01ZNFI3YTNRWUQ=').decode('utf-8')
    if 42 * 47 < 0:
        _dead_7228 = 581
        _dead_4153 = 345
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ηΚВХфφΜХεтщ():
    if len('') > 0:
        609
        _dead_7338 = 176
        _dead_4124 = 855
    value = 275417
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAfHOGA7r4wXHBeh2HKWIyct0E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аυНЗЖЙΚкΥςγ():
    value = 373390
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxjUfnYqzbhVbBmL61ujPBo9ylo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЪТПзЗπв():
    value = 922286
    if False and True:
        60
        pass
    text = __import__('base64').b64decode('RkNpcU5KYTBhU2dsWjJrRTFDaFk=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _иΤхλДфΜΓн():
    value = 454383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwX3QAI9wakbNib2zGCZMSB84mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 29 * 81 < 0:
        210
        _dead_3446 = 571
    return total

def _ДЦηвΝЛююδЧщеδ():
    value = 924839
    text = __import__('base64').b64decode('QktsVnEzVDdhbXpZckxEWVBacTE=').decode('utf-8')
    if len('') > 0:
        890
    total = value + len(text)
    return total

def _мЯОВЪΠюД():
    value = 249719
    text = __import__('base64').b64decode('V1NHenluSGxNTWNad3d1QlVheUs=').decode('utf-8')
    total = value + len(text)
    return total

def _урУнхВςΣщ():
    if len('') > 0:
        pass
        705
    value = 757301
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('STNHY19paGVETTg3Vnhjc0lwS2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝщШщЕΞъКνκγιςь():
    if False and True:
        pass
        991
    value = 284323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATjTbWMQ87wZEw6zyU+ADDUa4Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9836 = 259
        _dead_9488 = 640
        pass
    total = value + len(text)
    return total

def _ОАдΩЛκаБτηΚ():
    value = 794350
    text = __import__('base64').b64decode('UkpKTnJKT25wS0VvUVhMRDZaa08=').decode('utf-8')
    total = value + len(text)
    return total

def _АцъΡβоОшшΔΥοιь():
    value = 227245
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXjwOgkJqqEhNgiakXXBBnAbzDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9044 = 378
    total = value + len(text)
    return total

def _ОιδΡΡβΛΣΘ():
    value = 276240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBvTVmgd0vhSER31xUe5ETAss3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥθθΤЧΔуΕы():
    value = 531735
    if False and True:
        _dead_7258 = 352
    text = __import__('base64').b64decode('aUQ4aFpEaDVTSVg1XzFmZFRxYjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚрΨьжхΣΨξΦф():
    value = 53773
    text = __import__('base64').b64decode('UF90cHhmcnNDSUZGdW5CMGdIZWE=').decode('utf-8')
    total = value + len(text)
    return total

def _чОЫςЮΟэЯδтσЬΙюгρ():
    value = 461601
    text = __import__('base64').b64decode('SnhnT1pHN3d3YlJjZThPemFvM0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑгΓκΚЫνАσσцψА():
    if False and True:
        478
        pass
    value = 15220
    text = __import__('base64').b64decode('d2NRRktpRk9UMWh2bWV1Z2JmUHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 95 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()