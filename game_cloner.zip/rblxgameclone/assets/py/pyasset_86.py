#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _СЬЮнγΗΤщΨΙЗΙπПрΕ():
    value = 543973
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTfRW3o73YUabD728EO6Oid96V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 55 < 0:
        pass
        568
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_5078 = 200
    return total

def _ςιкΦΙСЛСйРЧАξ():
    value = 927876
    text = __import__('base64').b64decode('RzZ6YnoySUxfUE9reHpSR1U3T0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟГТψпΔΙΗΠемЕ():
    value = 468846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQe9P0gT+KUIEiGFnWedPBoo8lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΧΔХКΓΗφдбτ():
    value = 388808
    text = __import__('base64').b64decode('d25QUEdDUDR6SXN1RDNZRGlXdGY=').decode('utf-8')
    if False and True:
        383
    total = value + len(text)
    return total

def _лΛΧхрпεΞ():
    value = 464020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCHze1gK67JXNwWO4l2XbAoY10w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚοвοЦΛτьΗЬΗδКтЙΒ():
    value = 504847
    text = __import__('base64').b64decode('UW1WTzdKWjJpR29kRl9pWXdhdTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ψАωоРГκΞЙхΠλΠУ():
    value = 733048
    text = __import__('base64').b64decode('VHppc1dPTUhKOF9FYVRtMERfRDc=').decode('utf-8')
    total = value + len(text)
    return total

def _θдЕнΚЛбΑ():
    value = 588211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzjBfEEq8PsQMQGUmnO4Ihd/9zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΟΨψΑЪИщТкКη():
    value = 276120
    text = __import__('base64').b64decode('aWEzUlBpRU5FNG9ZeWNpNHN1cmc=').decode('utf-8')
    total = value + len(text)
    return total

def _φδЪщЙαηВуеΖУЭКΣ():
    value = 624469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx3eX1QJ/4wlBRiyyQOhITMr0mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШОМтМПУΗЕ():
    value = 532567
    text = __import__('base64').b64decode('eldlazB0dExfalNGM3R0Sms1a1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _πшцΩβΡигψΙΤЫ():
    value = 782983
    text = __import__('base64').b64decode('amRfdElIcHY4SlJHUHpfTHJPQzc=').decode('utf-8')
    total = value + len(text)
    if 57 * 15 < 0:
        pass
    return total

def _ΜБНЦΕχΑэΜУ():
    value = 705366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CybbYnoN8Z0pIii0wg6lIQwks0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψξβШюνΩΦΗΗп():
    if False and True:
        919
    value = 412550
    text = __import__('base64').b64decode('dEN4eWdzZmE3ekprazJWem5UdnM=').decode('utf-8')
    total = value + len(text)
    return total

def _енππνеχΜΚпч():
    value = 942246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxDCbFUd9bIXAjaOxm+ZLCEE8EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        410
    total = value + len(text)
    return total

def _иκЖВшЖЭюрΛξаκНςΔ():
    value = 817382
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('dmJ0aXd6ZE5IMHRzYnhfTmxCWkg=').decode('utf-8')
    if len('') > 0:
        834
        pass
    total = value + len(text)
    return total

def _σрχДГЗЦо():
    value = 541291
    text = __import__('base64').b64decode('VWg1R0RVX1BFam8ybVFsaHdrVl8=').decode('utf-8')
    total = value + len(text)
    if 98 * 92 < 0:
        _dead_9105 = 455
        pass
    return total

def _ШЪκΚЖΒςЪδеЬНэиΡу():
    value = 84306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAHeZEQ2y/kMLz7w2mC2DD8s3XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩмьΠξΥΜΡο():
    value = 845620
    text = __import__('base64').b64decode('SHJKTkFkUFpBc1BERlRjdjNaS0U=').decode('utf-8')
    total = value + len(text)
    if 100 * 38 < 0:
        pass
    return total

def _ИэΜΔхсЮТΧΣΖΤЕТЮ():
    value = 845770
    text = __import__('base64').b64decode('V2NUVGNRdjBRWjBqVWswUmJSbU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖэΝбШяцΔжΙ():
    value = 796313
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhnyWn0RxrorNgOG+QK+GSsC1mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΑΕЮΟΑЭЙчЕχЮΚЛφ():
    value = 301533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PC3FO1wQppAubwqgmn6SMTAZ4UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дВъЕыыгх():
    value = 984403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSz3XFYuxqEZCSyM2lW/ZRYj6mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аτЯГОχΤцωь():
    value = 786259
    text = __import__('base64').b64decode('RUJpSkQ4cWtKNW9Oa2lFUGZ4TVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ωМξчУнΘοΘЭ():
    value = 548575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQrrfGhp1Z4rIgi50HWCMwg5/WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βрΣΔдйдЗηэЩ():
    if 97 * 23 < 0:
        pass
        744
        740
    value = 770954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRa8eVBg/Y1WOT2zng+hEC4l1VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        951
        346
    total = value + len(text)
    return total

def _еМΩцкυΞшυЫ():
    value = 469199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAPIRV8+0vkIbB+r+EKCAHE4z0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΠμΨзςньΝ():
    if len('') > 0:
        pass
        pass
        pass
    value = 318029
    text = __import__('base64').b64decode('bm5BN21Db0xTczZmUWpqM05QS1I=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        11
    total = value + len(text)
    return total

def _ςχюιαЗЬωбюз():
    value = 326242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhb1a2E96qEkDwqt+WmBLi0h8Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        512
        429
        _dead_6539 = 423
    return total

def _ξξогэьжΛЩгΜψ():
    value = 910198
    text = __import__('base64').b64decode('RElkV20wZHhkRG9JQ0hqaU1KdW0=').decode('utf-8')
    total = value + len(text)
    return total

def _тЮΔξΩΒоΥχ():
    value = 788621
    text = __import__('base64').b64decode('Y1VJbTJ2czdPSWV4TF9nZm1FUzg=').decode('utf-8')
    if 6 * 65 < 0:
        pass
        _dead_8775 = 501
    total = value + len(text)
    if len('') > 0:
        _dead_7920 = 599
    return total

def _ΖλΚδςШЙТЧьΑШκ():
    value = 849787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQfRZWQbqIs3bjmc4VyaIysD4kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΚаюДΗΜДδπζЪ():
    value = 637956
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LC3jYEFv9/kKaRmMw32mOwI90ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωКгыσЗЧОΧ():
    value = 919814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiTwRUIW/5cnHB+lm3iFGisjvVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кςΟγΓыφαиςοБЭАΚЙ():
    if False and True:
        272
        pass
        877
    value = 127604
    text = __import__('base64').b64decode('aFlBT0dtSndmdzVoSVNfZldfal8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯлНьγЮΕШюηАςρωид():
    if 60 * 99 < 0:
        pass
        _dead_3973 = 741
    value = 93466
    if 61 * 67 < 0:
        pass
        _dead_7718 = 584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhCwRH4s8qUZKluB50+TFSYV5l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 78 < 0:
        _dead_2900 = 756
    total = value + len(text)
    if False and True:
        _dead_8942 = 381
    return total

def _оПχюρΧчГЪχΗχ():
    value = 72048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgDiRkYQ5vwiNR6c6QSlPQ823To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΧςΒкΞДшЗ():
    value = 499703
    text = __import__('base64').b64decode('UHJoQzNmclZFWTFWdU9ZWTllNG4=').decode('utf-8')
    total = value + len(text)
    return total

def _РДоУъοхλЧΞГпΟ():
    value = 704185
    if len('') > 0:
        _dead_3104 = 802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDrdSlkt0b8PE1mV/V+INXwu/lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ффРγΡжзΦΞЛΜΡЪΧЧ():
    if len('') > 0:
        _dead_4426 = 456
        pass
        719
    value = 165796
    text = __import__('base64').b64decode('ZTF2Zm05ZkVJQUg3dWpsQmozbk0=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_2922 = 383
        _dead_9324 = 26
    total = value + len(text)
    if 88 * 38 < 0:
        842
        _dead_3711 = 627
        pass
    return total

def _фμΗбкΦχфлεξΕуДЧτ():
    if 51 * 90 < 0:
        543
        pass
        _dead_3048 = 383
    value = 380303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('My3bfUcQqvglGCaPxXS/I3ANsmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΠГЛτΨЮВФщηЙЬ():
    if 6 * 21 < 0:
        368
    value = 321893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnrXSHgX1YY6AB7z5kOSZ3cazl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_8611 = 87
        _dead_3065 = 662
    total = value + len(text)
    return total

def _ΒЦЫΣаΓΤТусб():
    if False and True:
        540
    value = 122097
    text = __import__('base64').b64decode('QlA2SUpHSHVEZEdReTNxNVgzczk=').decode('utf-8')
    if len('') > 0:
        289
        pass
    total = value + len(text)
    return total

def _δμАйαцХШΖσ():
    value = 980103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dy69WHxq6JsCbCSc8WWnGjAKzlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αςфΦПεЙζЗБг():
    value = 858192
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxuzeV87/bE5CCC5zke+GCMjx0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 78 * 38 < 0:
        pass
    total = value + len(text)
    return total

def _эκΥπЫΟкΦεС():
    value = 858416
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyblVwgerZAsIwKc+X2/Ihoe7zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΗνьйΞЩΝысΙβЩΩщ():
    value = 70857
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDzuYFpu1JkuMxiryWWfYgI43k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σуЯЪΦяИэаσФβцΒα():
    if False and True:
        _dead_5290 = 989
        128
    value = 460007
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwrvR10L9bhWKTe130WXHwA4s14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩлЖъэλαΖтχΥωоρ():
    value = 551331
    text = __import__('base64').b64decode('aDZiSTFIV3ZIbEtoRGo4eE1mSUw=').decode('utf-8')
    total = value + len(text)
    return total

def _пншэтхйъзаР():
    value = 863907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ii73Q3g1y4AhagPywA+5ZxUr6F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψπмСβюΤΔΠΝΠι():
    value = 38654
    text = __import__('base64').b64decode('TWhzOFRfWGJKamRpTUJvSXJYTFU=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΡΠЩлВυиТ():
    value = 907237
    if len('') > 0:
        6
        pass
        12
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQPVO3xh7o0lEVeQmHSHGgk6w2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩгРЯβнНяΦς():
    if len('') > 0:
        550
    value = 667394
    if False and True:
        pass
        223
    text = __import__('base64').b64decode('VHUwSlRvbHhfTmNQVmVnYlozM3c=').decode('utf-8')
    total = value + len(text)
    return total

def _УγФжВэШакΟςт():
    value = 210476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PALUdkcoqpxXHFyS71+6FQMstmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        726
        373
        pass
    total = value + len(text)
    return total

def _БТΜΟυΜΡηρ():
    value = 459287
    text = __import__('base64').b64decode('WkZhTUI1X1k4VmpXX19pdmVsQ0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΦΞЧεЛιιтУы():
    if len('') > 0:
        453
    value = 536261
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('T1MySExGSmw4ZmpoMGt6OWl0Mms=').decode('utf-8')
    total = value + len(text)
    return total

def _θчюλЭΝΧζς():
    value = 995760
    if False and True:
        610
    text = __import__('base64').b64decode('VVZmNVZFU2ZYOXNBSng4Rzc1bWc=').decode('utf-8')
    if False and True:
        385
        _dead_2188 = 808
    total = value + len(text)
    return total

def _укΟэтΙМΒβЭΔчзαОΝ():
    value = 493230
    text = __import__('base64').b64decode('V255eVhUNkxmNWtjUTBaZnVnSnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝФЩαКοГпгЕΦЧаРЭ():
    if 81 * 89 < 0:
        pass
        pass
    value = 794238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAPGaUQRx4ItBQmww0SWBD8ox18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒυэξкиμлНзКЫεΛШ():
    value = 835653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyrnVlQe1qU3CT+SmgezCz8W0zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рпгχΑφψθуЪФμΔ():
    value = 461437
    text = __import__('base64').b64decode('Wnc2SXBHMEdqa01xOTVWREpweDc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _мΜπΑζθвΦ():
    value = 851925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABrIdAk774MEKj/z52OBMzMm92U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νЖιтьфКУЕДЦДΚΨΝ():
    value = 293984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBW9enAY9LAvPSavkXqfZDcl92Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        757
    total = value + len(text)
    return total

def _ЪгкАщКьΨЦЕоЦПшΥГ():
    if len('') > 0:
        _dead_6548 = 711
    value = 324309
    if False and True:
        219
        337
        261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwTNfUgax4sCHiey3njJNjEj6WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иъиГроτμЮ():
    value = 688994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQvxXUVh9rxbYjbzzmWmOggZ7Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 30 * 51 < 0:
        pass
    return total

def _ХΗХГкйХпымнΚε():
    value = 530584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAfXX0Ys1I02HAbx0UWREQA70Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΞΚЩьλсдХТ():
    value = 363385
    text = __import__('base64').b64decode('WDRIR25QZVNHN0FtSDlXb2NwRzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕъΩωΣхθε():
    value = 367546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxvtV0sO7rEJLTql50+eEAAXzHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 86 < 0:
        _dead_2222 = 451
        _dead_1791 = 824
        pass
    total = value + len(text)
    return total

def _λыЬеюАСοаГΕУА():
    value = 861588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQbQfVVryasnFArz/Fe2DSAH9mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΓσПЯюКΑ():
    value = 206346
    text = __import__('base64').b64decode('c0d4cmtxVmduRzRIT3NERk5rd3c=').decode('utf-8')
    total = value + len(text)
    return total

def _тκΘзпЪιБОГΟ():
    value = 584259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwPFeWgT2KY5Ih/73X6yEDUdsEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φЕΞΖхвщСσνпд():
    value = 288809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah/COWkX1L9TYwuTxlfGAxcd/Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЗΓЙЯμξαШж():
    value = 88498
    if len('') > 0:
        413
    text = __import__('base64').b64decode('bFZfX2FLZUVpb2lOWEw1TU16bWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥπъωΑΜκΤΘ():
    value = 329487
    text = __import__('base64').b64decode('VHJVdEszejZ5UzVYMktaOEptcTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΧНмпΩюЬσ():
    value = 934455
    if 6 * 22 < 0:
        40
        _dead_9507 = 663
        pass
    text = __import__('base64').b64decode('ZkJGQlBxcmFHTkV5WERjNXRiZTU=').decode('utf-8')
    if False and True:
        _dead_5682 = 439
    total = value + len(text)
    if len('') > 0:
        196
        900
        pass
    return total

def _ΥιчΑоΝριζΥ():
    value = 295452
    text = __import__('base64').b64decode('ZFBSdl9wQ0tFMXhTNl9yZVdCNVc=').decode('utf-8')
    if 12 * 17 < 0:
        _dead_8841 = 844
        _dead_7030 = 863
        _dead_1345 = 506
    total = value + len(text)
    if 3 * 96 < 0:
        874
        pass
        pass
    return total

def _чЯφВγФΦЧαъ():
    value = 211900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQy0RmIszq41BSHxxQaXIyYG9EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЦЦιщмΧψсΘаρΓν():
    value = 818978
    text = __import__('base64').b64decode('aGRpeV9LckpRdmhQTmxEbTQ1a1A=').decode('utf-8')
    if False and True:
        pass
        _dead_6743 = 909
    total = value + len(text)
    return total

def _ЕЦХКЮШюИЩγ():
    value = 706741
    if len('') > 0:
        638
        _dead_3918 = 207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCzvfHo9rrw6C1+o/HWJIzM41Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 65 * 29 < 0:
        _dead_9648 = 373
    total = value + len(text)
    if 47 * 49 < 0:
        301
        pass
    return total

def _МбΒЗιεыΕХΙЙсΚ():
    value = 423033
    text = __import__('base64').b64decode('UTl1dDFFRWlhNXpGYnJfSXFhdTk=').decode('utf-8')
    if 36 * 46 < 0:
        354
        pass
        pass
    total = value + len(text)
    if 99 * 29 < 0:
        727
        457
    return total

def _ЖжΥОЙрЙщЧ():
    value = 482974
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAPpQmYB1KcBFCWJwGDDHi4l9nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        919
        _dead_7041 = 849
        _dead_1158 = 981
    total = value + len(text)
    return total

def _ΡкПлεξФχΕΞЮ():
    value = 810620
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXjcTHcb1vEwFiu0m12bLTcI/k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 100 < 0:
        pass
    total = value + len(text)
    if 75 * 17 < 0:
        _dead_1554 = 479
        934
    return total

def _ΔфψуъκеС():
    value = 837515
    if len('') > 0:
        pass
        _dead_8427 = 179
        713
    text = __import__('base64').b64decode('TVJQVUhYajJ3R05QYlRiTkpIT2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ыεκЩηпφαΒΔ():
    if len('') > 0:
        pass
        _dead_7497 = 653
    value = 50818
    if False and True:
        344
        pass
    text = __import__('base64').b64decode('cWRmQjZ1aDBvdUcxT0poWjJVN1g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_5508 = 571
    return total

def _θΓиτΤξовεЧРμ():
    value = 619014
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IT3tWVxh6asVAwix90SUHRR70H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΣЬпнСКνςуγгδЯΕΑ():
    value = 776577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwnKV0Uc0/0GDVi132aCIzUuwnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _пΑохυШлΣйСцΕαыъщ():
    value = 929327
    if False and True:
        147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwfnSW4a2ZAFPgek+Hu2NnQIsz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        148
    return total

def _ЦдσεЩчυυΩΤЛбс():
    value = 741277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3+yTHYT66UGFRun4F63HHEu/Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΔшγеβшьζΨΔΩОΦх():
    value = 158972
    text = __import__('base64').b64decode('V1hGSG9KVU1OUFptVDAwSUJNVEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΥδсрТЗв():
    value = 450883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDm0YHY++p4lAh+z/F6JISAl7VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЕЦηИмΚΚΛЬΙ():
    if 27 * 55 < 0:
        pass
        pass
        _dead_5880 = 890
    value = 393254
    if False and True:
        _dead_5242 = 881
        26
    text = __import__('base64').b64decode('aDZUNzg2ODIzUHYzWk0wR1RvTmw=').decode('utf-8')
    if 2 * 43 < 0:
        _dead_6669 = 788
    total = value + len(text)
    return total

def _ΔЬсмτРαЬ():
    value = 666489
    text = __import__('base64').b64decode('aGpBaHo3OUJ1ZVdDMWRaazZsSkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ФρПОшгδΛΛюΙрЛю():
    if len('') > 0:
        601
    value = 763513
    if False and True:
        pass
    text = __import__('base64').b64decode('bU9fTjhGUl9lQVJnX21ydUVqcnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΟЗυйβнχАЫΔΡМρУй():
    if 9 * 88 < 0:
        _dead_4950 = 737
        552
    value = 791764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH/BTFs+5oEwCh2PmEe4LiIIykM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПъюΞКэЪЮчЛ():
    value = 223062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAHMOQksrrESEyiUzWKjMhQb5X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦжхЭБйЗКΠΛХ():
    value = 671332
    text = __import__('base64').b64decode('Z25wT3RKandTclpxVktOZmI0RmE=').decode('utf-8')
    total = value + len(text)
    return total

def _агэξχхΥΠЩРкδΟΦ():
    value = 613335
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgvTdEE29KInYh20xFWcHRYWy2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΧΘΧбΖαονеΤ():
    value = 493477
    text = __import__('base64').b64decode('aEUxQmRxelp2MDFCV3F6WDE2NGk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _фΠИэщΛЬУ():
    value = 843112
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCPNa0QS6rECIACx/W7ALSge3Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9059 = 731
    return total

def _чюиЦЧнΔΦ():
    value = 234436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRvzPFkL/aJSOSOBzlzIIyEY9jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 20 * 4 < 0:
        _dead_1424 = 855
        _dead_6598 = 231
    total = value + len(text)
    return total

def _юνονжοяИΦиνπЛ():
    if 59 * 15 < 0:
        546
        _dead_8794 = 622
        _dead_4753 = 831
    value = 450129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAfrbHYezYALHFyywEevBTcJwl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7306 = 564
        pass
    return total

def _рτΥΥЧГПж():
    value = 488758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InrDOAMp8aEWIiav/HDJZCI9sVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΞγΑπшαшλεЬ():
    if 8 * 45 < 0:
        903
        pass
        pass
    value = 919855
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('c0xYam1CaEFrTUpndDhJMlpKVng=').decode('utf-8')
    total = value + len(text)
    if 11 * 19 < 0:
        pass
    return total

def _ΠΘΝЙяОΑι():
    value = 985983
    text = __import__('base64').b64decode('Rk5MTE53d29Fd2V4X0QzbzJYQ3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ФягВгΩυъΖ():
    value = 657316
    text = __import__('base64').b64decode('ekJseDdYb3lDMXpTcnpKd051b2w=').decode('utf-8')
    total = value + len(text)
    return total

def _αρЭгПынσΚΦРλΥΗф():
    if len('') > 0:
        pass
        401
        _dead_7785 = 982
    value = 836076
    if False and True:
        _dead_3481 = 837
        pass
    text = __import__('base64').b64decode('blQ2TG5tMF8xeTR2Z2pxak8wMlQ=').decode('utf-8')
    if 53 * 94 < 0:
        _dead_2065 = 105
        _dead_9932 = 79
        375
    total = value + len(text)
    return total

def _ЕВΜЯωйЦθβеςЪ():
    if 49 * 59 < 0:
        258
        _dead_7710 = 534
    value = 815861
    if len('') > 0:
        850
    text = __import__('base64').b64decode('eElfQVFKQ3VFRGxfazJLaXpfcFk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        925
    return total

def _ОζлЖчшцЧγ():
    value = 919002
    text = __import__('base64').b64decode('eU5paDd0emhEeHlLYlNlT2FTcHM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4259 = 622
        _dead_1071 = 182
        _dead_3795 = 55
    return total

def _ТкВЪЬГΞμтсκэ():
    if 79 * 64 < 0:
        205
        _dead_5751 = 190
        616
    value = 913446
    if len('') > 0:
        442
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyP2e1I3+ftRAweM5V6kJB0Q4Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яЖνЙэλΝТвСКДДвζπ():
    value = 602579
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQjWQUtr14s8IiGo6VKUPCYp/HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        346
    total = value + len(text)
    return total

def _йχиьδешЙμπРЮп():
    value = 315917
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('bEI5eGR2UE1mMmtrSVZTQXBKd1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙхоβΟΧТбу():
    value = 300454
    text = __import__('base64').b64decode('a0lZenhvYzdUT0QxUFBqSkNpa00=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥфΕΞΥλЩжΥмαЭζΛΝΕ():
    value = 510105
    text = __import__('base64').b64decode('Ym9XSUo0ZTRQM3c5Q1FsR0hzM2k=').decode('utf-8')
    total = value + len(text)
    return total

def _уμθЮКЙφю():
    value = 824313
    text = __import__('base64').b64decode('STZ0Mk9kNHFPQWxCZV9yYzJtRXo=').decode('utf-8')
    total = value + len(text)
    return total

def _сЪΦφβБΛИΣωΝ():
    value = 145202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX/0OAQv54Q3PF2g2FmVHwIB6Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сБψΙЪΥχΚФЙ():
    value = 887505
    text = __import__('base64').b64decode('dHdQak9LRV85Qm5Sczk4RWdRV0w=').decode('utf-8')
    if len('') > 0:
        763
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _йуЛωАΧЕЯφТσчц():
    value = 292469
    text = __import__('base64').b64decode('UVVrTEY0VHpyTWZTbWhiSDlSUm0=').decode('utf-8')
    total = value + len(text)
    return total

def _дХоКыГэыЩνдЕ():
    if False and True:
        387
    value = 726389
    if 62 * 85 < 0:
        pass
        657
        _dead_6325 = 668
    text = __import__('base64').b64decode('dUJkeDdaNlZWTzlmQ3dxOUlEVzg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        693
        pass
        pass
    return total

def _ЬзΧцлШдЧяξйΓч():
    value = 784299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICTqO3gjzbwRCTDy2VyWJhwX1no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 86 < 0:
        pass
        535
    total = value + len(text)
    return total

def _οσΗмγγπιЧΝеЦψξ():
    value = 514796
    text = __import__('base64').b64decode('VUxtMkYwZ0Y1ckV5OGs3VzA3Rlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘдΦНПδнЩ():
    value = 531215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxjpVFIIqakQGzypwGOeLQ8G7ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΟХζИΠлΨЗгΟсΓν():
    value = 444353
    text = __import__('base64').b64decode('cUNqalVOdm1jT0Zyb1Aza3FOOHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΜаΘЦптюΕПΕ():
    value = 936338
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB7tUUIO1pc1ahqQxQ63PnY15lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юμГзΨιςШβиΘζισζ():
    if len('') > 0:
        165
        468
    value = 660178
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AD3DY24VqZkyagqA2lCjFQ8o/F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 74 < 0:
        368
    total = value + len(text)
    return total

def _ΤфΟΓлюΜф():
    value = 518315
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISPVX1hgqKEsHz2w53mmZBYb1UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νЕξРЦΛеЧ():
    if 78 * 73 < 0:
        _dead_5570 = 999
        _dead_1982 = 390
        pass
    value = 828294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAvbWF4p5JcNAjiU8HWIOTYVtmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΣФΥЪβщК():
    value = 512536
    text = __import__('base64').b64decode('TzRvRERBeHZMcVVBOXRicE5Samo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞдωюςΧЪχлай():
    value = 489875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InrKanQq6f4QMiaF5WyyEnUo6GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙзρцμЕΒπΨΘ():
    value = 123036
    if False and True:
        123
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgiwPggq7r0nbB212FyXJg4X930='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        427
    return total

def _οЛэКεΝεжрςΒΔЛГк():
    if False and True:
        pass
        _dead_5472 = 5
        pass
    value = 188341
    if False and True:
        pass
        _dead_5464 = 920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCbMfVQa/LIwPD+RzlOvGDd5vFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 62 * 59 < 0:
        926
        _dead_2468 = 410
        _dead_1291 = 549
    total = value + len(text)
    return total

def _ДνυΚαНЩЛх():
    value = 902858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAPndmMR6L1SEVavnQezLSYA0D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цшσζюδμωНлмζБгы():
    value = 832681
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EybKd1MpzJkBOCGg0XiIbTUpyl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЮАσнЗДΚΚβχυдй():
    value = 187347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxrpQUcT7/oAFTuK2nyINXB9y2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡγнΝрфαПдλЪ():
    if 6 * 6 < 0:
        pass
        _dead_2776 = 674
        _dead_5853 = 701
    value = 503526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISrJQFsxprE7AFeUxGOUHXEW0ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        783
    return total

def _ΚΣςхМБлг():
    value = 908660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH+xfmBg3LhQD1uP/HOiLA8r5W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θюΧйδΖЖИпгЬΒлο():
    value = 333295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwHhN0gcr/EwCFeS3EKdAyIo4EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТФΥХιζчьιЗηяκА():
    value = 784073
    text = __import__('base64').b64decode('b3F0VHRZQ3RsQUpLUmo2WUFiWVQ=').decode('utf-8')
    if 68 * 30 < 0:
        pass
        pass
    total = value + len(text)
    if 81 * 67 < 0:
        pass
    return total

def _ΗΞКΖУΧСρэθ():
    value = 449134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgfhR3xo9aAZb1eU61iVLhd7tHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШнΨзπωΘδКεФπΠЙ():
    if False and True:
        _dead_4557 = 168
        pass
        _dead_1477 = 148
    value = 840233
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgbTWXMg9awiEhix/lO+GQl/zGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СρλΩЗςψзβψ():
    value = 659450
    if len('') > 0:
        _dead_3838 = 659
        _dead_4514 = 943
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSbFX3o38aMtAj+5nk6iZSJ57zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 57 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЭЛЯщδφсрлςΜиЬ():
    value = 275201
    if len('') > 0:
        pass
        76
        719
    text = __import__('base64').b64decode('QTVsUEN0QWNyczBBRmRZMk5iTEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΤΔΔжнΧХЕдЗ():
    value = 258577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IT7iYlBg24FQLVeSzAHIAiIBt2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΛЖскΧчоλЧдΧπрδθ():
    value = 163471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyvjSgIY/f4xEwi2xFK2HiMs72g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        178
        708
        _dead_8257 = 441
    return total

def _лФИθΒΖцσЛΖΨХПкω():
    value = 442385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hxe0VnQ32vgALxum/le8Ogwiwn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        277
        _dead_7064 = 41
    return total

def _рЗΘγΕцΞχΧβыКφ():
    value = 919848
    if False and True:
        pass
    text = __import__('base64').b64decode('cHhRaTJRUmJaRXJVbmRBcVJuNko=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        701
    return total

def _шьяииоМΕфКЧЧχГшд():
    value = 932428
    text = __import__('base64').b64decode('dlpFU05leWpoM1pjZHU0Nnk1Z2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛуБεцПЦрβЦЮш():
    if 31 * 37 < 0:
        pass
        737
    value = 676725
    if False and True:
        _dead_6579 = 286
        172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwTXb3lv17osMSWi3EKIJRUK9n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        694
    total = value + len(text)
    return total

def _ΟцφςбШРусыΨΘδ():
    value = 91708
    text = __import__('base64').b64decode('elVDa3JWclduck9zb2JmT2NXVDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚζρΞΨлСЯ():
    value = 769182
    text = __import__('base64').b64decode('UmwxbTRRZVg0VHZwRXZ3OVRsVkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΤκЭτβΧΖкбоЙ():
    if False and True:
        _dead_7040 = 58
        _dead_9392 = 87
        _dead_7642 = 455
    value = 251218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3eyTF0czqUaAAD68Q6/GCs4ykY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚМцΦэςррχΓδК():
    value = 962515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQDbfAdv5L4HMi2XwwK/YAAEvUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝκИγъξЯПщВиГв():
    if 60 * 70 < 0:
        pass
    value = 69382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiT8QkEK8q4ZPCul4nugHnEJ430='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔЕκαОКчχΡΧЧφΓз():
    value = 337376
    text = __import__('base64').b64decode('VUszUERLY3dYdnlFc3ROTzRPQUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЫοеΡβΟТ():
    value = 264120
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3/iZ0Fs+6s1ahqE91q0BR8NzUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        952
        pass
        pass
    return total

def _яΤπЙςщФНЕ():
    value = 721853
    text = __import__('base64').b64decode('YzhYajRrT2xMQjhmTlJZODlEMTg=').decode('utf-8')
    if 24 * 16 < 0:
        pass
        pass
        498
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _МΒтλзщэθωЬхδΟ():
    value = 680090
    text = __import__('base64').b64decode('eWhCb2FobXRnS0hEVlZaX25MMHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜДаКрΤΗηΕчο():
    value = 542756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBzCQmEP1Y4LbC33m1i0NSoJsV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гюДЕщьЖχрЬ():
    value = 599927
    if 76 * 18 < 0:
        pass
        423
    text = __import__('base64').b64decode('QVRHU0lNaHpOTEZpMWdxanBpMWU=').decode('utf-8')
    if 62 * 36 < 0:
        _dead_6882 = 262
    total = value + len(text)
    return total

def _ЛьеъъΛΟЛζΙΣщζфΓΣ():
    value = 706451
    text = __import__('base64').b64decode('UVNaTnh1RGE1Rk9yenU0WHBCRVc=').decode('utf-8')
    total = value + len(text)
    if 12 * 2 < 0:
        554
        pass
        pass
    return total

def _ζЫЦрΞδцйяСρΒΕ():
    value = 231052
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxfFe1gx265WPjCQ0VqKPhZ54GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9278 = 859
        pass
    total = value + len(text)
    if 14 * 32 < 0:
        _dead_4943 = 437
    return total

def _КэЭхэЪξбΙъΝΣ():
    value = 738184
    text = __import__('base64').b64decode('anJDSE01eE5fYUdhNEZYTlU5bnE=').decode('utf-8')
    total = value + len(text)
    return total

def _βΣхКщщμХΚΔЦφ():
    value = 943268
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCn+S1Qe8KdVLif2/FuUBisf5kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςЦэμЯШЩΧзЙΣφМДΠ():
    value = 991539
    text = __import__('base64').b64decode('Ujl4U2FzYnVyazlzbFdldGdPak0=').decode('utf-8')
    total = value + len(text)
    return total

def _υκИΤъмЖжΧзυφ():
    value = 737367
    if 78 * 67 < 0:
        325
    text = __import__('base64').b64decode('R1hIRklsM1NYeFdJV0poVVVPdWc=').decode('utf-8')
    if False and True:
        _dead_8487 = 79
    total = value + len(text)
    return total

def _аμιДΘνΤНЮЫ():
    value = 30418
    text = __import__('base64').b64decode('eUhLakJ2Vjlic1gyZXhJb2l4Qmc=').decode('utf-8')
    total = value + len(text)
    if 28 * 66 < 0:
        pass
        pass
        pass
    return total

def _ΑяΛОΖςΘЙλΞΖщΧДш():
    value = 285915
    text = __import__('base64').b64decode('RVRfUjVuSGY4cnR0dTJjMWNTcDc=').decode('utf-8')
    if 83 * 47 < 0:
        _dead_7815 = 478
        pass
    total = value + len(text)
    return total

def _ФТуФγΛΓЖЙΞпχΨπА():
    value = 624252
    text = __import__('base64').b64decode('amdrMjNXN3VSRGdZV05BbWFrY3U=').decode('utf-8')
    if False and True:
        pass
        _dead_6749 = 519
        _dead_3815 = 675
    total = value + len(text)
    return total

def _ЗШΓЯηБЙКц():
    value = 214753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxvgXVQb2PgaGymi/0aaF3MQtzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΒЙзрζΗβο():
    value = 856099
    text = __import__('base64').b64decode('a2lMVFRCRGdxcmtGY2RvaU9ldzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧиλΠАΚЭШЧΝρΧΓλ():
    value = 185383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXjTXgIy+6NXNDzw2mOpNjN74Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖδΟφξмιΚΥцΞшФ():
    value = 772084
    text = __import__('base64').b64decode('aHd5cGtzTDFFS0ZhQmJEUHpITUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑρкΕДиШх():
    if False and True:
        pass
        pass
    value = 312619
    text = __import__('base64').b64decode('YmZJbXpKak1Wbkw1emRCR1NXMnk=').decode('utf-8')
    total = value + len(text)
    if 53 * 21 < 0:
        pass
        688
        pass
    return total

def _оМшιйνеЮΝвЛШЙУς():
    value = 744459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CznXaHgR//AVYz6M0GzHEyB66W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        717
    return total

def _ΟγΗФВЦωУРηЯλв():
    value = 106955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnnWamIr1ZoLFhys0G+KZgcB1U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΖοΙпΥЮПЪНШИЩωοΠ():
    if 43 * 13 < 0:
        _dead_5976 = 153
        _dead_2675 = 637
        _dead_2197 = 421
    value = 617625
    text = __import__('base64').b64decode('SzRQWjZkQnB3TDVZVmp6ZnJLS24=').decode('utf-8')
    if False and True:
        78
    total = value + len(text)
    return total

def _ХЫΤΖиΧΓлУэЗ():
    if 93 * 91 < 0:
        _dead_1153 = 36
        955
        _dead_5493 = 289
    value = 663774
    text = __import__('base64').b64decode('cnpac3F3aDlYMHhZb3FITzJUbWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ρпκЯшХξшΒыΔЪφ():
    value = 820100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhXlP1oD7JwwHBal5lyeIyEe0Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тщБЮпγνςыρя():
    if len('') > 0:
        242
        pass
        _dead_7638 = 777
    value = 456010
    text = __import__('base64').b64decode('SEc1TW14bm16Mk9VWWsxakdHSEs=').decode('utf-8')
    if len('') > 0:
        _dead_9966 = 489
    total = value + len(text)
    if 66 * 35 < 0:
        668
        pass
        pass
    return total

def _ΙΝΕЖкΑяХхо():
    value = 676070
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiXgdEUz0PoIFjyTylmBHDAV0Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЪΡзлОλЛШΦζΟωП():
    value = 909150
    if False and True:
        316
        pass
    text = __import__('base64').b64decode('SVBjZE1vaWViT0hXSWJ5Ukptc1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ФωδΤЭτΣТБс():
    value = 228397
    text = __import__('base64').b64decode('d2ZhOTlvVFpQSWVveEFIOGlPRm0=').decode('utf-8')
    if 40 * 1 < 0:
        pass
    total = value + len(text)
    return total

def _ΑгΖзкΔХνиρФЗе():
    value = 529478
    text = __import__('base64').b64decode('S0NFcEljb0tPWnlHNTBLNFpwTHY=').decode('utf-8')
    if 74 * 5 < 0:
        _dead_6055 = 95
        _dead_8763 = 333
        _dead_9295 = 996
    total = value + len(text)
    return total

def _КЩэΓΥъЛΡ():
    if len('') > 0:
        135
        _dead_5149 = 159
        376
    value = 474611
    text = __import__('base64').b64decode('Skxfc3ZicWJlUTI0VzJaTzB2bjE=').decode('utf-8')
    if len('') > 0:
        _dead_4551 = 816
        _dead_7998 = 354
    total = value + len(text)
    if 34 * 31 < 0:
        33
        _dead_5897 = 243
    return total

def _хКνжЫЕφΓАΤΝИ():
    value = 761193
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABjmalod6/01OR6c2ka6ARx/vTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςьΑΝΓζДбРРΧйцдςΙ():
    value = 65329
    text = __import__('base64').b64decode('TW5DYkp4TVNWWXhSM0dBT3BtQnY=').decode('utf-8')
    total = value + len(text)
    return total

def _йБΔαθΖЬщоЪВЛΣмх():
    if 31 * 8 < 0:
        _dead_3493 = 706
        pass
        pass
    value = 773748
    text = __import__('base64').b64decode('YWhDT2ZBdmppSkR0YXdLeHZXTHc=').decode('utf-8')
    total = value + len(text)
    return total

def _пЙшνучЗςФΛчАУйЦ():
    value = 139975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hzq8TH1u9I4iLjmq5AKmOBwc82U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _дθкюЗφρΠΖ():
    value = 759431
    if False and True:
        _dead_3358 = 19
    text = __import__('base64').b64decode('R0Q1STJVeGRvNG04NEd3eEVZZjM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_1338 = 685
        _dead_3631 = 714
    return total

def _эзыυЮΧΤьπεηШЬυчС():
    value = 80036
    text = __import__('base64').b64decode('SGZXaGllOFZHMXJSZXhiVjlGSFk=').decode('utf-8')
    total = value + len(text)
    return total

def _хχнЗΕйρΗШ():
    value = 192310
    text = __import__('base64').b64decode('Q3Rwc1pFcm56enJSUDlwams5Umw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟнлЪгΩКИАОωАьИм():
    if 34 * 55 < 0:
        pass
        _dead_7226 = 73
        pass
    value = 830004
    text = __import__('base64').b64decode('YTFoSXR4Z2txRDJ4MGZyY2JXMVo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1053 = 243
        867
        404
    return total

def _хЛΒхЬЯяЖΚγΦ():
    value = 906535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex7AR3YI64YFPRnwmXOyFyR38Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗсЭНαктхлаς():
    if 56 * 95 < 0:
        _dead_6924 = 821
        pass
        598
    value = 80054
    text = __import__('base64').b64decode('VFNod1AwM0hySE1nazI3bFJfX0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _хΝэУЩкПκΕκ():
    value = 47404
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NH/GOWduyPAUOw6xkHi4HCkBszo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1354 = 516
        _dead_6666 = 673
        _dead_9507 = 491
    total = value + len(text)
    return total

def _ςчβΞτΦсβДмабςш():
    value = 327745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSf8Wl9p3L1TNT2X2mDDPx8c8Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОрφхбΟОΛβБΦ():
    if len('') > 0:
        745
        _dead_1822 = 99
        765
    value = 976717
    if len('') > 0:
        818
    text = __import__('base64').b64decode('a1dMV0VXdE9jbWJSQ0NrdlJyam0=').decode('utf-8')
    total = value + len(text)
    return total

def _ХдбиΙΑРιЫΠПφГУЖ():
    value = 664826
    text = __import__('base64').b64decode('QXJ5OWFKc1VLc0dqRDBYTnJlMVA=').decode('utf-8')
    total = value + len(text)
    if 24 * 61 < 0:
        306
        833
    return total

def _чΒШуηχΤΑЫζΨЯμ():
    if False and True:
        _dead_2842 = 251
    value = 235771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwezSkE82JoZDSWN2FvDPnQqzGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эωΙУЯαЫΞБъмνθα():
    value = 114565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAb8TXpgqLI0FyqAywTGYgI8xlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤσАΩВТиΚωо():
    if len('') > 0:
        pass
        553
        26
    value = 784397
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBXWOXwyp/gROC6G7Fm5OjAn1Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 50 < 0:
        pass
    total = value + len(text)
    return total

def _ЬТЮοаωэγΑαλК():
    value = 956677
    text = __import__('base64').b64decode('aW5RZFYyRFlCWXdqZVUwamRGSTk=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        603
        761
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 91 * 7 < 0:
    pass
    _dead_2821 = 55
    _dead_2120 = 684