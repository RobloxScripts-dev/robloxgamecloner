#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ХХΙΟΩшЭГΜ():
    value = 458099
    if 84 * 70 < 0:
        _dead_8245 = 361
        pass
        846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCCxVFQB9JcOFALx72SCNyN+6VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ХОМγφιьдζЬβ():
    value = 696003
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwDMXV8VrrsVODiT+2W+YzQE5Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪсΦΣΖεдТΞбнΛ():
    value = 25392
    text = __import__('base64').b64decode('RGdoTkJnZXNscTdOY0RGNkIya28=').decode('utf-8')
    total = value + len(text)
    return total

def _яаξДсУψкчλ():
    value = 845502
    text = __import__('base64').b64decode('bzBoR1czYTNRcUtRVzdfTFByT04=').decode('utf-8')
    total = value + len(text)
    return total

def _ξδΧΕКυψБЗΒДδбиΛΘ():
    if len('') > 0:
        83
        _dead_1548 = 563
    value = 692448
    text = __import__('base64').b64decode('bTdWNXFER210VnlhZGNjVDliTnE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑδИζΖоθаЗыЪηаΛ():
    if False and True:
        983
        477
        _dead_3231 = 739
    value = 341204
    if len('') > 0:
        125
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSDWe0Ez1ZFRaz630AeVNz8I61g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШβηЖΙВЩΤΞωфщ():
    value = 367082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh28O1Uf+r0taC77x1TDOA0A41Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1576 = 953
    return total

def _ПЗΚмωЦлΜχτΠΞЬ():
    value = 586763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTfSN3oq5rk7F1qH4G/FNgh4wW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩсЖЯμΟъьσХ():
    value = 916994
    text = __import__('base64').b64decode('QXZ6QlJQczJTZGhFeEt0V3FDZU8=').decode('utf-8')
    if len('') > 0:
        62
        pass
    total = value + len(text)
    return total

def _ЖвЧΔιΑлщЩТЬβл():
    value = 303276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ani9dn0S1b9aCgOVzn+1bHci5Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЕГГзфΙθсяΣ():
    if 47 * 94 < 0:
        717
    value = 246022
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PATGbAQvppgVHw2V72yRMnUO7Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 79 * 22 < 0:
        pass
    total = value + len(text)
    return total

def _РΟЬуκΤΒзНθЯΠлι():
    value = 261190
    text = __import__('base64').b64decode('bmFPbkJGeTFUTVVYampfbXBRWVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ьэΟОΚвжΩΥм():
    value = 204618
    text = __import__('base64').b64decode('U1g0U1VQNVFOTGJCWVdzYUk4Sko=').decode('utf-8')
    total = value + len(text)
    return total

def _асйЙΖЧξΥВи():
    value = 935094
    text = __import__('base64').b64decode('clB1RWpNbTc1Tl9QMks0N3FWZkI=').decode('utf-8')
    total = value + len(text)
    return total

def _СфЩΣξОУпχТΘкИтζн():
    value = 234560
    text = __import__('base64').b64decode('YzZqNDd4ckYxa1pHMW14QnlEUkg=').decode('utf-8')
    if False and True:
        222
        _dead_1001 = 627
        396
    total = value + len(text)
    return total

def _эЬЭπμσИЭр():
    value = 169827
    text = __import__('base64').b64decode('Y25kejBwRVRJUmpQWWVUWElvTk8=').decode('utf-8')
    if 87 * 34 < 0:
        545
    total = value + len(text)
    return total

def _ΞсρДцХЪЛδι():
    value = 67435
    if 2 * 65 < 0:
        pass
        700
        960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgfIRkEY+6IoPFiO3WK1AD98x2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тМЕвпЪψφΛр():
    value = 497556
    text = __import__('base64').b64decode('ZE8yRDhodm5yWTlnMHI1aE5lME0=').decode('utf-8')
    total = value + len(text)
    return total

def _абЗеθГнψъпΨχΛ():
    if len('') > 0:
        159
    value = 949742
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxrOWFMJp4JQaib75g+BGj89szo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αмнΣжХиΡωуΘРΘ():
    value = 956720
    text = __import__('base64').b64decode('ZFI4c1l1eTlKRE52dEpzX2FvQ1g=').decode('utf-8')
    total = value + len(text)
    return total

def _оτТрфчиγЯςМпбβИ():
    value = 594035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ihf3YlBrqf8wbjex4XKyDScFwGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πшΟцΞμιλуζΔМШи():
    value = 857163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ihf8S3Ix8P0ObxWh2Ea0FRoc1E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юПοхНΣФλΨСЯςакЩ():
    value = 713770
    text = __import__('base64').b64decode('VklyYW14Qm96YVBZRlhtVV80MDM=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_8590 = 366
    total = value + len(text)
    if False and True:
        406
    return total

def _ΣβНтопвПмθб():
    if 5 * 43 < 0:
        798
    value = 642748
    text = __import__('base64').b64decode('TnpOV1NwRXpWTUJacGxwYURmZ3U=').decode('utf-8')
    if len('') > 0:
        _dead_6706 = 529
        _dead_1192 = 698
        166
    total = value + len(text)
    if 55 * 74 < 0:
        _dead_6556 = 273
        pass
        pass
    return total

def _тРМеΡтφСжЮπ():
    if 84 * 95 < 0:
        24
        _dead_8343 = 649
    value = 363075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyXtY1Qx2KUbAjCNywXDMXch8WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8248 = 189
        515
        pass
    total = value + len(text)
    return total

def _ПσδХТикциΗд():
    value = 390147
    text = __import__('base64').b64decode('VjFJdklIZnFQVFpiNkhxMnozU3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ыцυΚжΖЫСη():
    value = 110413
    text = __import__('base64').b64decode('b25pTzN0clNvTjFsWWl1N2RtQlI=').decode('utf-8')
    if 47 * 81 < 0:
        pass
    total = value + len(text)
    return total

def _ΤхЛЦυοοщЭΡΕднηиъ():
    value = 391131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnfMY1w/6JcSC1+VxWCxIhAq/kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яноЧδОПцοΤξмауа():
    value = 349208
    text = __import__('base64').b64decode('VnczeG5pMmhBYzhJSklmbjRrZ20=').decode('utf-8')
    total = value + len(text)
    return total

def _ХлκδсЩΖε():
    value = 569573
    text = __import__('base64').b64decode('eTQ4VzVGUDNIaGtFM3NiR25sY3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _гтШυΒЯΡЯΩθεэ():
    if False and True:
        pass
        _dead_5672 = 207
        pass
    value = 66755
    text = __import__('base64').b64decode('eWd5MFo0clZDd2lpWEZQVkJqYWs=').decode('utf-8')
    if len('') > 0:
        _dead_8103 = 32
        _dead_8790 = 398
        38
    total = value + len(text)
    return total

def _ΧЩΠεΣςЬлйзσТ():
    value = 53320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCm1bHAs+Y8EHjaNxW6qJS8l3Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        13
        132
    total = value + len(text)
    if len('') > 0:
        _dead_7489 = 718
    return total

def _ЛХПСΕкυквΝΕъ():
    value = 855979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSHqfWkQxJcoCAf6mQC1ZgQ22zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗЪИЧΞΚСοЗΦθΣВΥ():
    value = 393779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nif9UVks2KMyN12m3l6FNRAs91s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔςΥΖθьГКеμαЗЬ():
    value = 158214
    if 44 * 14 < 0:
        792
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz/pa0MR+YMuLVuB7UyoLnAV0n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧюЧτаεЩтж():
    value = 936969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhbAZGgf3YYPPxiz3lfEHxcO0j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξсτТщцихλΓΞψ():
    value = 425390
    if 55 * 36 < 0:
        _dead_3770 = 934
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjjrXQE63KwFNw6x0VOyPBwY0Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эδьиЙуπΝμ():
    value = 164256
    if 34 * 54 < 0:
        513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAKya2s4z6UWKzqE+gDEC30fslk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮημζлхмиψРΩε():
    value = 304799
    text = __import__('base64').b64decode('UjZoWk1iRE5sSE1TdTJIUW53eDc=').decode('utf-8')
    total = value + len(text)
    return total

def _βзδдКβΒлΞ():
    value = 666890
    text = __import__('base64').b64decode('REprQ1R3bVN4eHEzNkI0czNJVHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗξБυСШЬЮΕАРрΔЬ():
    value = 691642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH3uUWU0+YsKHB2F7nWYYTAIwmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 73 < 0:
        644
        pass
    total = value + len(text)
    return total

def _ΨкжΔЯнмωб():
    value = 465321
    if 96 * 36 < 0:
        _dead_7026 = 132
    text = __import__('base64').b64decode('dUs1Rk5OSm93dVhxRjJLeUxOQzI=').decode('utf-8')
    if False and True:
        528
        _dead_9486 = 913
    total = value + len(text)
    if False and True:
        73
        378
        707
    return total

def _нЗΔΚшюχΤщλξЕлбΙ():
    value = 369985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACfvd2Jo5IA6bB6qzwCdCy8nsko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фКЩоцЗπКΔзρφψл():
    value = 672888
    text = __import__('base64').b64decode('ZUwwNzF2ZXl3TDhETnhZN1JSRnA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        972
        926
    return total

def _тΧτΥΦзθАΒτлЫΞ():
    value = 777958
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('TGxBQWZlZUxxUzZYdHN6WWFoN1M=').decode('utf-8')
    total = value + len(text)
    return total

def _вПтΧСΞбВω():
    if len('') > 0:
        _dead_4905 = 309
        _dead_2333 = 789
        607
    value = 295500
    if False and True:
        400
    text = __import__('base64').b64decode('aGwxSWRnU2J6ODZXaW9sWU81bHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ТКΞыжДРоЩжκβ():
    value = 17038
    text = __import__('base64').b64decode('VUQxVlczME50cGNIVDZtcnlXTjU=').decode('utf-8')
    total = value + len(text)
    return total

def _яюРВъМОЯЮρю():
    value = 856780
    text = __import__('base64').b64decode('Y0Q0WjMzdzJYeXduY2EyeHo2UTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥКйΨзωτчΨκПхк():
    value = 631350
    text = __import__('base64').b64decode('SEthYjNyVE1EWFllZzVjY3BkRm4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        931
        pass
        pass
    return total

def _ΛэΞскгшОΙφДФψ():
    value = 803722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETfhRl0W3foybR+Q4lOmJHYKwDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πыбРεУΓιбκЛΗφз():
    value = 300386
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXjpfWQar6laaj30w1eWZTciy2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛАЪкδζΨэышο():
    if len('') > 0:
        67
        693
    value = 405122
    text = __import__('base64').b64decode('d2pBTFJhb01La3V6MlpZaTRTNFA=').decode('utf-8')
    total = value + len(text)
    return total

def _тЬцΣΟνЧθКπЗΧЧζКМ():
    value = 662019
    text = __import__('base64').b64decode('Rl90TWhkc1NNZ0dCTm9ZQVA4NE4=').decode('utf-8')
    total = value + len(text)
    return total

def _кΟьЭйшεшφЯδЖ():
    if 82 * 52 < 0:
        pass
        pass
        pass
    value = 823917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRbRPntr/P4sDhuJ/UK0PjMj5kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΩεξΜУΔξИ():
    value = 24433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD28RXIM6fw3OFi50EaDIAt59EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        312
        pass
        932
    total = value + len(text)
    return total

def _йЕЦоμсПэκрξЮщСΥ():
    value = 219304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnbBaAYJyYM7Cj6X91SSZRA/22I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зЩцфппОРЬЮУ():
    if len('') > 0:
        617
        783
        pass
    value = 451997
    text = __import__('base64').b64decode('U0ZJeXRFTHFBcE9wbWJ1aDVQRG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝпφσэκΑκА():
    value = 94720
    text = __import__('base64').b64decode('Z2sxR0dnWFFiT01jOFNzSDJQTTI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _эφРΒИΕСυквОη():
    if 54 * 13 < 0:
        pass
        _dead_7130 = 158
    value = 508181
    text = __import__('base64').b64decode('cklrNnJRbV9XSG9rM0ZXdENVaEc=').decode('utf-8')
    total = value + len(text)
    if 10 * 36 < 0:
        _dead_7085 = 880
        pass
    return total

def _ΝЯЭытНΜξΛγφОСΦНψ():
    value = 828762
    text = __import__('base64').b64decode('bEhuTVpCdDlrZ1JQUXJKNDhyWFU=').decode('utf-8')
    total = value + len(text)
    return total

def _йЬДЩбивΜα():
    if 80 * 52 < 0:
        _dead_5180 = 114
        890
    value = 285307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CALBN3tqz6APOy6s7nSKBnEe530='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чιФВΦΓωичфЕ():
    value = 110617
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHrdQ18RzpEAPV2x/GOeGDUa5VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 44 * 57 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΧΞγтΖυτГ():
    value = 850400
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChD9bEkgx/APCgqy32bBZQYA41g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟйАρΛХΨНГЦ():
    if False and True:
        394
        pass
        _dead_2105 = 104
    value = 158397
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAG0Ol9twbwPExv20EyZEQckskg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 95 * 32 < 0:
        _dead_5840 = 543
    return total

def _ρΞцкчαβрη():
    value = 792704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hwy9TQgp774EaQGFxXyvNhN7sU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 66 * 3 < 0:
        pass
    total = value + len(text)
    if 32 * 13 < 0:
        pass
    return total

def _ΑшВлεжοщпψЗζ():
    value = 706141
    text = __import__('base64').b64decode('RW9HMWZEOUd3MG55eE9JVUVST20=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЧжыΙщсιЪΛмε():
    value = 890120
    text = __import__('base64').b64decode('T1RJRFQxWEs2bHZfdFNwd3lLdFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _иКψгλюТυ():
    value = 977874
    text = __import__('base64').b64decode('Q3B1WFZBWldhTEpVcVJOMmUwRFE=').decode('utf-8')
    total = value + len(text)
    return total

def _эЪΘхЯфЫζАж():
    value = 55536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH/rXXwo551RbDXx+mKdPHx850I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΟкУРрЛеΔЛχШхШο():
    value = 792866
    if len('') > 0:
        _dead_9471 = 56
    text = __import__('base64').b64decode('TWE0Vmp1eEx3dEdmNE4xdmY4YXI=').decode('utf-8')
    if False and True:
        548
    total = value + len(text)
    return total

def _ΑбНМΤΚΦОбΗΤ():
    value = 326505
    text = __import__('base64').b64decode('RUZGUm1ScVlCVW1jMXQwNkpXTlA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9825 = 717
        pass
    return total

def _τΝΣΥгΓξЪαБ():
    value = 8623
    text = __import__('base64').b64decode('bHI3ckUwQVJESUpGdkdQUGFJY0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠмιυТΥεЦ():
    value = 117946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nxb0W3Jtxo8CNCytzHK7LRMF/Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нτШЧичдИγυяΚ():
    if 12 * 49 < 0:
        pass
    value = 110347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAPhQAEVr7kQOFyInmKTAQQV0XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φгμнхЗФбгйνσЩ():
    if 87 * 29 < 0:
        pass
    value = 181852
    text = __import__('base64').b64decode('ZVlnR1h2RHJkbHFoUXMxZWYyWTc=').decode('utf-8')
    if False and True:
        204
        901
    total = value + len(text)
    return total

def _ΒчΦНЧΕюЖанΡς():
    if 77 * 30 < 0:
        _dead_8370 = 983
        584
        _dead_9246 = 870
    value = 815924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhDFQHQuqvwBCRX3/GOjFg8OskM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        692
        _dead_3333 = 506
        pass
    total = value + len(text)
    return total

def _μшωφρνλЦ():
    if len('') > 0:
        _dead_1963 = 215
    value = 158212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwDCf3IY0IAHbVeE+USfLA8ex0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦФΘшαЯΘАшГхЮξ():
    value = 38695
    if False and True:
        pass
        pass
        _dead_6618 = 3
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRbPf35h9IUbMjaM52+IHxoM4mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        376
    total = value + len(text)
    return total

def _ΩшЪΦДАфЛжςζкΚψθφ():
    value = 108614
    if 46 * 15 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX71fgZp6qNWAyGMznPHFzAI6l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 57 < 0:
        672
        350
    total = value + len(text)
    if 26 * 23 < 0:
        pass
        _dead_6646 = 498
        258
    return total

def _λτсΜЕКΙсуΙΚΑ():
    value = 457252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwziPAYJ8aoFajCwzkDHECYQzGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 6 * 11 < 0:
        _dead_1793 = 524
        465
        326
    return total

def _ьЩνЙΑЕЖΒΘЛ():
    value = 736974
    if 1 * 82 < 0:
        _dead_6631 = 670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICvCZngbzr86Nx2X63mWE3QL/Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6974 = 931
    total = value + len(text)
    if len('') > 0:
        _dead_1507 = 881
    return total

def _шЬΞηкΟмΦцψЗШμΚ():
    value = 361428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICXzWVAs+YYKPh+P6XiXBzMj0k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВПψйРнлСР():
    value = 768406
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lyr8bVktyaoODF+X+FKzBSx3w1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νтЖфЧЩψλЬЯα():
    if len('') > 0:
        pass
    value = 11281
    text = __import__('base64').b64decode('czF4Rk5XUWZWcm5Cd1dldlhNTzI=').decode('utf-8')
    total = value + len(text)
    if 75 * 6 < 0:
        915
        pass
    return total

def _МЮшΑВяЪц():
    value = 340363
    text = __import__('base64').b64decode('a1VqMUFLV3NOQ3J2VjJJaG5VVnQ=').decode('utf-8')
    if 49 * 12 < 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_5101 = 557
    return total

def _ΖЪΡδДαкРψΧГШΓ():
    value = 853943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhfgdEZrrp4UDQaw2Ua5B3wOxmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΚИΙюубΡЙыъΥнЛф():
    value = 108117
    text = __import__('base64').b64decode('U0V6T293Q2tzY3UwY3lDbDVjcnY=').decode('utf-8')
    if 95 * 12 < 0:
        _dead_1151 = 200
        pass
        pass
    total = value + len(text)
    return total

def _δйΕУνΖρаΤξΛЖ():
    value = 438114
    text = __import__('base64').b64decode('eHhMYTAyYTlBTnMydGptdDJsQ2o=').decode('utf-8')
    total = value + len(text)
    return total

def _оВΒΤрΑлΔβВΤЬлεТш():
    value = 257909
    text = __import__('base64').b64decode('bWZfdEYxUUdtVkVvVnc5V3FKVzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΣЬиЖиεл():
    value = 580439
    if len('') > 0:
        671
        pass
        58
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyS3T3kJ7YtRG1eC3ny3Ei0b1no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        112
    return total

def _λесΜъΡючςшσεЮж():
    value = 486431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzzHeXox3YEoai61xQ61EyEAsDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аэхАκТцеЖца():
    if len('') > 0:
        _dead_6967 = 726
        _dead_6159 = 468
    value = 52794
    text = __import__('base64').b64decode('dXlNS1A5Q004cmpYV3lrRzFEYU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕψСΣθΩеНЦ():
    value = 694947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhjuOwIj2YowHB30+EGXOnY20no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βΠХТΠΓврН():
    if 1 * 74 < 0:
        _dead_8650 = 514
    value = 996358
    if len('') > 0:
        766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny72fFAcxrIgFye7+m69bSwItWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 5 * 15 < 0:
        712
        pass
        pass
    total = value + len(text)
    return total

def _СζθδΜшΗВΗβ():
    if 74 * 65 < 0:
        _dead_5096 = 660
        pass
        pass
    value = 820138
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgrOWWs02asMPQLyyw6FBRI563k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΝВАчΣθшΞнΤ():
    value = 664388
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LD21VGVgwYJUbVet4Q6xZyg7534='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΩΘκψςψая():
    if 33 * 2 < 0:
        pass
        740
        _dead_8668 = 165
    value = 760699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgXhb0Q81fk7BQqqyXWxZDcCyGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 93 * 86 < 0:
        pass
        677
    total = value + len(text)
    return total

def _ωνЫОπыηыΒοю():
    value = 881758
    if False and True:
        944
    text = __import__('base64').b64decode('cHRUbXY0ZDZxWkFlQkJjSXFtWHQ=').decode('utf-8')
    if len('') > 0:
        754
    total = value + len(text)
    if False and True:
        79
    return total

def _фΤчЮбЯЫчΥХΩΘьу():
    value = 765369
    text = __import__('base64').b64decode('d2JwZWEycnFjU3kzb2JlcUVjbjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ИδΚδЮцΣυя():
    value = 270483
    if len('') > 0:
        _dead_5800 = 279
        pass
        _dead_9789 = 388
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwjNQUATxvoMPTCE2nqaBjAe1j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕλщШйεЮоνЯЯ():
    value = 747120
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jgu3WmEb6K4PNSL3+FS0EQEFyHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЙеПУбпωЦυкΤ():
    value = 39395
    if len('') > 0:
        _dead_4810 = 494
    text = __import__('base64').b64decode('Sm00NnloZ1RZVkh0OVR6SnFCdTU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        586
        pass
    return total

def _СщжοςλΥды():
    if False and True:
        pass
        424
    value = 9037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwTMXlgwrKcsMQqP0ADHGww883c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_9826 = 580
        _dead_3465 = 693
    total = value + len(text)
    return total

def _ΦКйζКХЧдЩмвВЬ():
    if False and True:
        _dead_4458 = 962
        _dead_6217 = 655
        pass
    value = 697150
    if 33 * 66 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyjLWW4Q6bEVFSSbmnjIBHcqvDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        462
        pass
        pass
    return total

def _чуρЯГОπОβ():
    if len('') > 0:
        _dead_3763 = 569
    value = 281968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhzsaUIx6I5UFyKB+ky5ATEr0kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6889 = 496
        _dead_7863 = 361
    total = value + len(text)
    return total

def _щГСΒφЯχоμБЩΞηмη():
    value = 323736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAm1UX0Gz6MzKi2Pyne0DBAM3V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жНδΟАαΘΧΟЧ():
    value = 561393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LALbeEs7pqQzPRannFegABEF4nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        468
    total = value + len(text)
    return total

def _ЦАтΜПДυхυЦаΘмУкЮ():
    value = 123312
    text = __import__('base64').b64decode('Q2RFS3AyTnBkMzRHbFB3SGVJWFI=').decode('utf-8')
    total = value + len(text)
    return total

def _χЛμΤвНРгΦ():
    value = 32058
    text = __import__('base64').b64decode('a1JuRU9veU9Ya0pCSmJTMUFubzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ПθудщΗЭоΛщΔ():
    value = 612959
    text = __import__('base64').b64decode('aElLT21QZkNwYTlXaHlWaWlkZTg=').decode('utf-8')
    total = value + len(text)
    return total

def _σсгνΓχΖпхшΦф():
    value = 538650
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('anNtM3JwQklBeUN1U2c4cGJ0U2k=').decode('utf-8')
    total = value + len(text)
    return total

def _еЖεцчМТКПΘбфпΥλΩ():
    value = 412193
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgnbRHkI6oEGHCzy21KBLiQu02Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оГΞыΠсцΥ():
    if False and True:
        256
        971
        _dead_5363 = 64
    value = 384000
    if len('') > 0:
        613
    text = __import__('base64').b64decode('b3ptclJoSHNBa1VKa0tPdDVUUGw=').decode('utf-8')
    total = value + len(text)
    return total

def _БВЭΘбΑγΞдЖрΘΙЕπΙ():
    if 88 * 97 < 0:
        132
        _dead_2645 = 339
    value = 151859
    text = __import__('base64').b64decode('WXJhalU2NkE2MWw2NWtTQjVfWlc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _вбψПςγНЯΜρл():
    if False and True:
        _dead_9816 = 934
        671
        635
    value = 267381
    text = __import__('base64').b64decode('WWt1eU8wSk1ESlFTbWhVU1lMYm4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        746
    return total

def _йοτктЕхτюДпэц():
    value = 175502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyLTXF1v+fElajCw8G+GYyAB7Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γСяНςθΟЪпАΝПΤщс():
    value = 744192
    if 13 * 98 < 0:
        9
    text = __import__('base64').b64decode('RjNweWdXS3VCbkQ4UmxVMG9OOUE=').decode('utf-8')
    total = value + len(text)
    return total

def _тпβШΑΒθдο():
    if False and True:
        pass
        _dead_9169 = 65
    value = 963833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KS3MY1guwbAuKCGWmwGzHggbyTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΑМΟναХКΦФЛξЙ():
    value = 32650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FA3gWHYP+f8rDVamnnunHyR5s3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 97 < 0:
        pass
    total = value + len(text)
    return total

def _кΟнΘΕφпΖΛсδαяΣ():
    value = 474833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jzy1anU8/4YXFz6zw1ybEyEB3FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        696
        _dead_9513 = 565
        _dead_9416 = 930
    return total

def _гЪΚξΛЪаΩοЩМЪя():
    value = 958651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiDrSgEX+40wKViHw2OnLBEgxzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        609
        _dead_5946 = 284
    total = value + len(text)
    return total

def _υφоπФΔΞаσηС():
    value = 234239
    if 23 * 44 < 0:
        pass
    text = __import__('base64').b64decode('cFpET0ZRYWNPcU43MWJpam5rUVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗБЙщТΗЬВДψмЫΕ():
    value = 171090
    text = __import__('base64').b64decode('RmE1UFZDeGRJX2RkMm5ndVZSTmc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        596
    return total

def _чЮоθπХгδ():
    value = 477834
    text = __import__('base64').b64decode('ZmVBWnRuQU10YUJrSmcyVXhGRjg=').decode('utf-8')
    total = value + len(text)
    return total

def _οεщАЯтПУΣΩД():
    value = 525315
    text = __import__('base64').b64decode('UHE4aVpOS3NHd0owVTlKUW1rWjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΒΜχΓхЩτв():
    value = 733732
    text = __import__('base64').b64decode('UW9Fb29DSk90b0VEZTZaWjF0ZW0=').decode('utf-8')
    if 94 * 53 < 0:
        _dead_5008 = 485
    total = value + len(text)
    return total

def _ьθΛгЩвМωυм():
    value = 661327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITaxRW4S6K02Hgyl4F/HOSMWyD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нТΙЛоιιΩΑΗζб():
    value = 883505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTzwOVY2rb9UOCaM53GDBSB4w0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΗΡΣχЧкб():
    value = 729468
    text = __import__('base64').b64decode('dnoyX0NjWFdzWnRjbmhKbDN2eTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫВэбфЦΟΖгьЮшп():
    value = 420638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzjSRERs0Z8oEAa0nXOqIx0V50k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛξНΟШсЧрикюсΡκςΒ():
    value = 446433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn3UaWYPwbsBYl+My3WnLRwW7ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΧэΦКщΣТΟ():
    if len('') > 0:
        _dead_1561 = 770
        _dead_1050 = 802
    value = 653540
    text = __import__('base64').b64decode('bVZrbmoxZGt6cHFrYkNNbG1PQlY=').decode('utf-8')
    total = value + len(text)
    return total

def _щψΘТызЮβΟЬижνыюи():
    value = 722111
    text = __import__('base64').b64decode('bGd6R21uNFoyUnp5UzVGanRnVmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ρμаеΒНαпаЭ():
    value = 903537
    text = __import__('base64').b64decode('TFdPNG9MakdkUlhzVWx6TkZIZ3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙкΥΑТПЦΧзьШμЕΖ():
    value = 937401
    if False and True:
        _dead_3276 = 850
    text = __import__('base64').b64decode('QkxON195TU4xbWNqallBQTlHdGI=').decode('utf-8')
    total = value + len(text)
    return total

def _РОЮΔрыψοΗ():
    value = 54290
    text = __import__('base64').b64decode('R1g0VWx2THhwQklKWXZ6b0pwdTY=').decode('utf-8')
    if 77 * 71 < 0:
        944
        _dead_3867 = 412
        _dead_6425 = 194
    total = value + len(text)
    return total

def _фЩрΞэузΧсΒβ():
    value = 595702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwfSR3oI7bwINz2A51unMz8G7XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЬлФбΓнрЕдчв():
    value = 664046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FArTQgFt1pkKGA2cmG62PQoB8l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΡΕГΝУтв():
    value = 48802
    if len('') > 0:
        pass
        _dead_6371 = 652
        382
    text = __import__('base64').b64decode('WEhPNHRLdHFXUHNjWElIS0ZuU2U=').decode('utf-8')
    if False and True:
        81
        665
    total = value + len(text)
    return total

def _ΨЪυТΝБΛПлκΘШΞς():
    value = 321559
    if False and True:
        _dead_7367 = 868
        160
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mi7iV3AL+bwyAB664nDEOXEXs0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4054 = 17
        _dead_7492 = 705
    total = value + len(text)
    if 72 * 67 < 0:
        pass
        _dead_5293 = 96
        _dead_1261 = 743
    return total

def _δεΩΓэΥгыапЖЙμй():
    value = 796603
    text = __import__('base64').b64decode('VDl1UzQyR1FaYWhaYUY0czV3eUE=').decode('utf-8')
    total = value + len(text)
    if 2 * 23 < 0:
        _dead_4032 = 306
        567
        215
    return total

def _цРиЙКДτΨΦЦν():
    if 19 * 58 < 0:
        588
        _dead_1873 = 163
        589
    value = 653361
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz3iaWsyp7ELagG66wK8Yg586zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 74 * 72 < 0:
        pass
        _dead_6230 = 482
    total = value + len(text)
    return total

def _σВοеоΡπЦκΣЙН():
    value = 851571
    if len('') > 0:
        _dead_1653 = 206
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwjtQGdr57k1Oy2XwVfHPBIJ7jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 2 < 0:
        81
    total = value + len(text)
    if False and True:
        pass
    return total

def _ПсГфΞπчα():
    value = 116708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQDIVFUd8aUIaBiA52mRBXQH7Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рмЪΝУВξиΣφ():
    value = 397339
    text = __import__('base64').b64decode('UXc4V2xvOEtHemMzRDhubVNBdW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΛПВуЮюОЙРзΣЙ():
    if len('') > 0:
        _dead_5549 = 678
        277
    value = 643853
    if False and True:
        pass
        _dead_8587 = 479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnrtVggQxIYTHFuGxACVMXY3zEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 69 * 94 < 0:
        202
        _dead_5220 = 294
    total = value + len(text)
    return total

def _ЗΞЫξβцΚθЯкΞΕ():
    value = 16870
    if len('') > 0:
        625
        pass
        _dead_7492 = 991
    text = __import__('base64').b64decode('cFd1bUVQVEllYnBTNE5ld3Bkc1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛхυЙцγΥπφВΦуςу():
    if 89 * 24 < 0:
        _dead_2673 = 712
        693
        pass
    value = 447750
    text = __import__('base64').b64decode('ZjdiejN6cWh1OTM0dzlkdlZSQkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗлΤΙВиΛБъ():
    value = 206928
    if False and True:
        265
        165
        pass
    text = __import__('base64').b64decode('VzJRUkJSaUFnYTdOOU5JazNqdVE=').decode('utf-8')
    total = value + len(text)
    return total

def _БИбρεрΘЬτЙδθρзκψ():
    value = 173772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwC3RwgUwb8oKCiV0Fu+I3MAzU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1540 = 132
        350
        pass
    total = value + len(text)
    return total

def _ОъБлΞАΖНοΠЕчч():
    value = 846608
    text = __import__('base64').b64decode('bWpCVU95ZEVxMnR2OG1YeTQ2aEE=').decode('utf-8')
    if len('') > 0:
        _dead_3692 = 557
        _dead_6911 = 850
        _dead_8877 = 220
    total = value + len(text)
    if 37 * 98 < 0:
        pass
        947
        982
    return total

def _ηΞпζжЛΨкωφλапКνц():
    value = 61603
    text = __import__('base64').b64decode('eDNxZ09jZlA4TEt0TE5zOUtnQUI=').decode('utf-8')
    if 29 * 94 < 0:
        pass
        pass
        348
    total = value + len(text)
    if False and True:
        pass
        _dead_1940 = 38
        pass
    return total

def _зΧцоτКНгзΟъИЫΝζε():
    value = 319391
    text = __import__('base64').b64decode('amxZSDFBNDJxNVhUQkdWNTBBbnM=').decode('utf-8')
    total = value + len(text)
    return total

def _цИмΡлЛрΑНΑ():
    value = 878608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwbPNnYBr6BULS2qzlSpDjEH6UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7238 = 253
    total = value + len(text)
    if len('') > 0:
        _dead_7715 = 174
        pass
        573
    return total

def _σчΟшΣЫиπШχПТΟ():
    value = 8740
    text = __import__('base64').b64decode('R2JVRXVpNDdDZTVPOUZyczczY3M=').decode('utf-8')
    total = value + len(text)
    return total

def _δЬЮΟИΤκфΟыУ():
    value = 423576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx7KfVhuqolSPS60+26VOCkdsGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РщтЦΗτЛШΦιЬыΜК():
    value = 243748
    text = __import__('base64').b64decode('a2VjZ1Fhc29xUkJoS1dHZmpxYWo=').decode('utf-8')
    total = value + len(text)
    return total

def _бжΥВоτБъΘΗεδН():
    value = 713306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExnNP3AI9KwCICi18necLiAmy2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        878
    total = value + len(text)
    return total

def _υбУΛПТΣΑсзΔЯΛ():
    if len('') > 0:
        _dead_4302 = 484
        pass
    value = 967972
    text = __import__('base64').b64decode('RXQ2YXdjOXIzNUIzZkk1Y1R2dXk=').decode('utf-8')
    if len('') > 0:
        _dead_7739 = 514
    total = value + len(text)
    return total

def _лВΠтδΧтЭπиГ():
    if len('') > 0:
        44
        pass
    value = 134511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn7jPmkozJosMzCQxWKKBTEt7ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_7430 = 780
    return total

def _μЗξЖαλΒЗοш():
    if 87 * 75 < 0:
        _dead_8751 = 714
        _dead_1981 = 487
    value = 459938
    text = __import__('base64').b64decode('bTdZTEFKRWUyRHhiWExyTmM0ZlI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6538 = 917
        _dead_3912 = 462
        pass
    return total

def _ВαРμγИЫжоКσс():
    value = 520602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiizbwAGqY86HSSayWKdZ3Ig63k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 79 < 0:
        _dead_9008 = 51
    total = value + len(text)
    return total

def _ΤИсΥшЧСвεЖΥ():
    value = 363743
    if False and True:
        _dead_7628 = 456
        pass
        302
    text = __import__('base64').b64decode('a2pabjZST1l0VkxZVE1EYlliYnM=').decode('utf-8')
    if False and True:
        pass
        303
    total = value + len(text)
    return total

def _ЦуэΤОмЪшмμбкю():
    value = 716644
    text = __import__('base64').b64decode('ZUt2clVhWVdfeGkxMG5LWWdlMzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧХХЙяιΣЛωыΧаа():
    value = 502163
    if False and True:
        _dead_5388 = 891
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HX73ewQU65k6Lyn38XS/IR0C62A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔУΥСδцЙР():
    value = 342656
    if False and True:
        89
        pass
    text = __import__('base64').b64decode('aE1mRkpYeW54bGR2d09wY2hyMWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔБшХТωπК():
    value = 720828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHv+V3wQ/YQXNQGK3wWGJiYK7T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛОΤкнχΛУΦΥ():
    if False and True:
        _dead_4573 = 822
        482
        _dead_2313 = 376
    value = 917367
    text = __import__('base64').b64decode('bGQza3BDVE9Gb3FZRDdWZVpZNjM=').decode('utf-8')
    total = value + len(text)
    return total

def _тХΘκОΦаЖΚТ():
    value = 203822
    if 11 * 75 < 0:
        _dead_9078 = 549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnfhaVMR6okBFy2E30WHZzck9VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2819 = 393
        868
        pass
    total = value + len(text)
    return total

def _ιυψΩΣРΟλщхΓхЛΝНμ():
    value = 461685
    text = __import__('base64').b64decode('dDB1Y3o2bEFJSWZNR25YcGRfTUc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _δШрПщиπЫЬЫРγε():
    value = 280754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXqxUWEV0ZgMEQSR+UOaMAID5Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖРЛмОАΙцОξμΦΣυЛ():
    value = 227772
    text = __import__('base64').b64decode('ZTlvQldqZm85alhXTGhHX0FEYWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΙьИθΜоΟΚЩλλ():
    value = 443233
    text = __import__('base64').b64decode('UEZKc3pTZWJqTmJwZlhzMF8ycEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ИыЩмтъйγΝΓНЮΘВ():
    value = 992592
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AA79WkYO6I4TAlauykzBYws4y0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9801 = 284
        _dead_6272 = 669
    return total

def _ΔТΡэΥΝъбψ():
    if len('') > 0:
        388
    value = 377043
    if len('') > 0:
        pass
        _dead_5760 = 723
        _dead_8016 = 86
    text = __import__('base64').b64decode('cW1WVGh4Z0hwa1VLM1N2ZWJIcEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭюЩяΚκЯιζШΛРшФр():
    value = 181244
    if False and True:
        _dead_4292 = 405
        _dead_2742 = 477
        926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By6ySgcax6k0KS23kH2cFzY1skk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АγеУΠбρЮα():
    if False and True:
        pass
        pass
        pass
    value = 516800
    text = __import__('base64').b64decode('RGZtZ3BPUmt2QkwwMWU1ZGhiZ0Q=').decode('utf-8')
    if len('') > 0:
        399
    total = value + len(text)
    return total

def _δΣСъщβщΚгыг():
    value = 856006
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDbCZFxv0rFXaD2l4H2mPH0Z51g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _пЫΕбфцЖШоАμЙς():
    value = 440481
    text = __import__('base64').b64decode('dzNMVE9pTXhwbHRtZmowNXg1MU0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8841 = 686
        _dead_4444 = 876
        pass
    return total

def _ЪΟЩПоΝДМΗΜπ():
    value = 35438
    text = __import__('base64').b64decode('YTdxRUpPb1hKdnEzWjBfV240Y1M=').decode('utf-8')
    total = value + len(text)
    return total

def _θυЦαлΣаЫωΔΩ():
    value = 230365
    if len('') > 0:
        pass
        789
        367
    text = __import__('base64').b64decode('RUhNcmRMSnE2Y3NKMXd2dFg0Zm4=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _κΛΛэΒνОγ():
    if len('') > 0:
        pass
        _dead_1076 = 490
        778
    value = 16541
    if 17 * 56 < 0:
        632
        748
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3ixYlxs9aAnYyr322G0FwsV0E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _εНδяΥΤФиюκБκ():
    if False and True:
        900
    value = 976428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHeyen0OwalRMQmAm1OGIHIYsDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        59
    return total

def _АΚвРъΜΥΦ():
    value = 368846
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('bUhsamswZXlXNFdxSjZRWXYwbkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔйШΗΠΗαΛ():
    if len('') > 0:
        225
        321
    value = 723110
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('QkVnN1ZOR3dQVWVZb1pyZkFMZ1U=').decode('utf-8')
    total = value + len(text)
    if False and True:
        239
        _dead_8774 = 361
        pass
    return total

def _ΦψмΘςΑτгпη():
    value = 858047
    if 87 * 9 < 0:
        pass
        _dead_1076 = 975
        418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyvXbGkQ1bpTDySX+GyKPwZ53Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йьЛЧπтцъ():
    value = 779649
    text = __import__('base64').b64decode('a2NwMUhLeU9CVzZMbWlDeTF5ZFI=').decode('utf-8')
    total = value + len(text)
    if 33 * 61 < 0:
        pass
        _dead_8236 = 249
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()