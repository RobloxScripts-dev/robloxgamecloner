#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _υзφАПΡюАЖЫθβφΘь():
    value = 561179
    text = __import__('base64').b64decode('VmdVMXN1OGJGa1VUbUM2V0NTbEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ИютяАΓФБΟΠ():
    value = 7709
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FADhWwkpxokoMVenmXWTFxx3zm8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωУΓΩсщΜΩюζоΦгиΒ():
    value = 706384
    text = __import__('base64').b64decode('WFFzMUw4amFRZXpMaGlIWHhLb2E=').decode('utf-8')
    total = value + len(text)
    return total

def _φψДρШΤνΔЯУΛюпΔσ():
    value = 25533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lgyyf0UBz6cENCCP/gCFGDQas14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 73 * 93 < 0:
        pass
        _dead_6970 = 373
        659
    return total

def _οФиЖюФΝЪωπцЯяζц():
    value = 812734
    if len('') > 0:
        197
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgbofV8U9K0LbTWynQ+YMSMX53g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗςшΕСЙаЪ():
    value = 183695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cz3TOEYI84wHNhuIx0+lPRUn61Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 80 * 54 < 0:
        pass
    return total

def _шббΔТΞΝψΛмпγΡ():
    value = 88523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBXmVGFp86AQCx6a2VW2DQcO6lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οσюΨФΣΖтЗθ():
    if False and True:
        _dead_1086 = 176
        _dead_5824 = 317
        pass
    value = 879204
    text = __import__('base64').b64decode('TjlZOG5EbzFBYjR4ZFc5YWV5eE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪθЩЕГоЫμйσ():
    value = 245411
    text = __import__('base64').b64decode('TEtwYnpwYWxQZTVRWTdoeG9oU0o=').decode('utf-8')
    if False and True:
        _dead_4246 = 328
        pass
        _dead_8543 = 384
    total = value + len(text)
    return total

def _ΙнщИГЪЪгЪЧЬвЯбв():
    if False and True:
        pass
    value = 870911
    if False and True:
        312
        _dead_9356 = 333
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH/PYAMJ0aUmNw2V5X+zNwgAtGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΧТНиΚЦΨцΡ():
    value = 120754
    text = __import__('base64').b64decode('amVwMmhkTHAwQl9sTW9SMHBwOHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _РοЖχγΠΙжщяГ():
    value = 51118
    if len('') > 0:
        pass
        _dead_5039 = 641
    text = __import__('base64').b64decode('ZkROMjZyVE1nWHY5Y3p4cXk5bjM=').decode('utf-8')
    total = value + len(text)
    return total

def _τΡПΞνΤыСμюα():
    if False and True:
        pass
        _dead_3726 = 451
    value = 407583
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCf+e1gs159VPjyH7kKcAjU54F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        540
    return total

def _ЫУОйΙшιнλ():
    value = 210918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwzLaVwQ3YRaCDiQ8gSYISIDtEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 82 * 90 < 0:
        _dead_9564 = 998
        _dead_3712 = 111
        _dead_7328 = 687
    return total

def _ПΞΓΘδВУΗ():
    value = 674007
    if False and True:
        453
    text = __import__('base64').b64decode('T3F2ZjJubGJkZlA3RnUzZUJzN3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕνУнсθГжэЮЭСгΚ():
    if len('') > 0:
        _dead_7547 = 651
    value = 425062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy3WbAYp7v9RIBq0z0KIGzY74zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зЖыДλТэδНрнеЖ():
    if len('') > 0:
        89
    value = 488714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3nMa14A2b8rBT7xyU+ZLA4Q3EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τζииТзΗΒΑишκы():
    value = 961442
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Py3bT14+p/08aS6Hy1HCDj8gyV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        948
        395
        889
    total = value + len(text)
    return total

def _νΑЯтЦЙЧΛ():
    value = 331248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwTxb1wrzYUBMQaFmAexJwIr618='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υъумωЩцЯъМλλΡпгэ():
    if 42 * 91 < 0:
        pass
        677
        847
    value = 123035
    if len('') > 0:
        _dead_9805 = 463
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBn+OFQQ6/haKwCP/USiFnB550w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θРЬχзΣВчыσξМ():
    value = 323294
    text = __import__('base64').b64decode('VzY0aGpiTElDRkJpZldNR2VFcnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥгυλеΚφιаЫТΦчτ():
    value = 938017
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwH9awAr1vkPCCzz/3PHJ3c17lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 55 * 62 < 0:
        pass
    total = value + len(text)
    return total

def _ЙκηθнεИΜыρςχΑыΞ():
    if 21 * 37 < 0:
        _dead_4247 = 288
    value = 529098
    text = __import__('base64').b64decode('U3dualBBQlM0dmd3NlVYakhjNE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ухΟюМрΕыΛυк():
    value = 881303
    if len('') > 0:
        _dead_4059 = 554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D33MPVoL0YA6CiPww3qnJCcY61w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЖэΣξφТХΨпτυ():
    value = 79816
    text = __import__('base64').b64decode('cFVVb21wMk50YWRZZ1M4RWhDU04=').decode('utf-8')
    total = value + len(text)
    return total

def _ОτΜкЮΠАιяσжΗωΟз():
    value = 589275
    text = __import__('base64').b64decode('TnY2SGJMT0FyV2xPcVJfUXZrZlk=').decode('utf-8')
    total = value + len(text)
    return total

def _АιГБΘΣΛГДШ():
    if len('') > 0:
        pass
        890
    value = 553556
    text = __import__('base64').b64decode('Z2VQSUZRODk0SDJuMnJkNjNseWU=').decode('utf-8')
    total = value + len(text)
    return total

def _φρауБЛΞеΔДΖуΛη():
    value = 27085
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjjhO1wcz6AzKhWH6gOdLAE8w0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 8 < 0:
        498
        pass
        879
    return total

def _μоевιЭβиΗΧΒ():
    value = 639266
    if False and True:
        _dead_9613 = 459
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCjbWHVqpp8ACD332UakBXA50lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 65 * 18 < 0:
        695
    total = value + len(text)
    return total

def _ΦрφλαωКЛаζчСΧρШ():
    value = 413647
    text = __import__('base64').b64decode('RGR1UjdRV0FaR25XOTkxS2EyX0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘииПНмΜςЕΖΡАюЗ():
    value = 968953
    text = __import__('base64').b64decode('eUVmVEZaWmJIa0JQT3BJdGlQWmY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        16
        pass
        818
    return total

def _ЧлЧΦЫцςфω():
    value = 64385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB60OHQ2qpIuGz6ynnvADSA4/Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _лЩχΔΗΧςωΚбΟ():
    value = 951211
    text = __import__('base64').b64decode('eGQzY2d3aHNXVGpFQm1UMUdqY3M=').decode('utf-8')
    total = value + len(text)
    if 1 * 86 < 0:
        pass
    return total

def _ДΗфΞΝПббруГΜσ():
    value = 889447
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx2xOXJprZk6IjyVmXGGFnM1y1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыеεКΑеЯш():
    value = 299803
    if False and True:
        785
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw3dPWMy+YI0HCCJ5FyWHxof22s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _κАкОοВισЕхМк():
    value = 744818
    text = __import__('base64').b64decode('ZnpkVnBuSUI0NzNVTEJXY3FPSHg=').decode('utf-8')
    total = value + len(text)
    return total

def _иУчтьЕΥсλδ():
    value = 212758
    text = __import__('base64').b64decode('VlNER3UzcXhybmpoZ0Vsb28zam0=').decode('utf-8')
    if 73 * 50 < 0:
        pass
    total = value + len(text)
    return total

def _ΨуФξъιЫДдΙΜΔЪ():
    value = 320328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh7qPVAdyKoiCB+zxQ6CDDYX214='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьзΧЪγοэζ():
    value = 256532
    if 72 * 90 < 0:
        20
        _dead_2749 = 66
        _dead_6668 = 567
    text = __import__('base64').b64decode('Y2hucU5jZTRvWVZnUUNZaHJseGg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9016 = 815
        183
    return total

def _τρощьТΒЖΙнΩ():
    value = 664965
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAnhTQQ8+JgODw608XuDOTwL6Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9559 = 154
        834
        249
    total = value + len(text)
    if 82 * 52 < 0:
        pass
        pass
        pass
    return total

def _ЩΗэθΙΟκаРΩЭ():
    if False and True:
        _dead_6720 = 405
    value = 804943
    text = __import__('base64').b64decode('cHpURHdTQkh0UjZUR3kxa2dtcE4=').decode('utf-8')
    total = value + len(text)
    return total

def _βцЩМΚαюДφσЮμЩςб():
    value = 911684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQrPfAY66rowDw2imFyRICM+9m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фзρζετшУяэч():
    if False and True:
        pass
    value = 885665
    if 12 * 84 < 0:
        pass
        162
        246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSP9PEEg7KUtHij7nwSJHQg+wk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        342
    total = value + len(text)
    return total

def _ΖШφΨУеьЩΧбНйз():
    if len('') > 0:
        _dead_4157 = 45
    value = 546621
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxfKfng825suMyWhzlLJEg8qvGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 90 * 64 < 0:
        607
        _dead_4455 = 722
    total = value + len(text)
    return total

def _ΥεжЧиЪυИφбХЮ():
    value = 444027
    if 82 * 64 < 0:
        _dead_8990 = 433
    text = __import__('base64').b64decode('eFduWnZ0bHNIMldNd1ZlVHlTZkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨεпьгΑтκΧΚπРУЗрΟ():
    value = 566406
    if False and True:
        pass
        pass
        _dead_5263 = 464
    text = __import__('base64').b64decode('encxdzZCM3E2d1U4VEZtRVBVNTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΑΑВΚшΚйЗАΛ():
    value = 985165
    if 31 * 31 < 0:
        _dead_4046 = 642
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRDwTUEa/6YvLArw4HWqEQgc3lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        478
        _dead_5716 = 255
        150
    return total

def _φΩΚИξКАωςΦΞэсеΒД():
    value = 703093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChfBfHUy3b8vbh+L7X+VMx0t73c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        954
        _dead_4335 = 553
    return total

def _ЯσсβТрЬюЪЕ():
    if len('') > 0:
        pass
        745
        _dead_3336 = 951
    value = 398330
    if 32 * 98 < 0:
        878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSPMamtt7bsnMwKz/HuZNz81skI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 22 < 0:
        371
        _dead_6352 = 266
    total = value + len(text)
    return total

def _РГΠυъМдΥЬΣЦиγ():
    if 74 * 46 < 0:
        _dead_4750 = 580
        pass
    value = 969885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjvTX1od1aMgOFiTzGKyATUe41E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 58 * 94 < 0:
        _dead_5529 = 370
        pass
    return total

def _ЕνмХΚΑΠγЭξ():
    value = 75187
    text = __import__('base64').b64decode('TzB3V0ZGYXRtYXBZRDdpSnQ3X24=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪтΠΕЫογΧГΕΡθ():
    value = 747365
    text = __import__('base64').b64decode('aFJsUm54TTFVSmpXTmZrcW1lR1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΚΣжоυΖЭΞБпшυЖе():
    value = 93237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ii3PbwkR2b0SKjf68U6lZhc96jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯκарΧвюπΩП():
    value = 811223
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxnPdgdv26EtMA2g+GHGOyAZ1XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΓЗыМУщЦ():
    value = 995156
    if len('') > 0:
        _dead_3781 = 448
        _dead_2017 = 902
        276
    text = __import__('base64').b64decode('UjNnZTI0VWF6M29CQUNZU3FvNEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ηШΩΖэгьφΠХΧβΟΣ():
    value = 766406
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('U2hrUV9iM3ZWbjBqcDhGcUpKTGo=').decode('utf-8')
    if 53 * 76 < 0:
        _dead_7481 = 403
        660
        711
    total = value + len(text)
    return total

def _ηФйΗρυюКΑжλ():
    if len('') > 0:
        pass
        pass
        pass
    value = 653984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kxm1O0Ax67oGDSms3wSaJyYF4Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τИкцъΔуеЮ():
    value = 891011
    text = __import__('base64').b64decode('RVIxYVNhcFFmT3JuZlVPNWZjdFA=').decode('utf-8')
    total = value + len(text)
    return total

def _кччΘафцΛεφφЕОхΟм():
    value = 731788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MC2wfEEAy/gXCTr04Q6dGyIM/DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜрЕрЪΓЗφΔзкη():
    value = 343716
    text = __import__('base64').b64decode('TFpDSTNPWHFkZVdYdE5xMXRsQ0k=').decode('utf-8')
    total = value + len(text)
    return total

def _БΛεγАдρяВвлθ():
    value = 34135
    text = __import__('base64').b64decode('VlROYkdsWHd3cE9BZUJBX2FmQTI=').decode('utf-8')
    total = value + len(text)
    return total

def _щнεΞЛсδшεВιмΨ():
    if False and True:
        _dead_9225 = 922
        508
    value = 879363
    if False and True:
        _dead_6539 = 312
        _dead_3125 = 412
        _dead_3730 = 884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dgu9fHYu3YchazW2xwWHAHc8s1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыОλΘмνυΛηΛьрауШ():
    if 27 * 81 < 0:
        _dead_5967 = 373
        pass
    value = 15637
    text = __import__('base64').b64decode('SlI1RmlCZk5zSWRCWmgxQnpDYzA=').decode('utf-8')
    if False and True:
        _dead_9372 = 206
        pass
        _dead_5578 = 753
    total = value + len(text)
    return total

def _БДΩЯδЫуЖоЩβфЧ():
    value = 719580
    if False and True:
        487
        _dead_6266 = 575
    text = __import__('base64').b64decode('c1VxeExYbGZxUTZMZV9RMmFUV1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΑЛΣгЪоЫЕв():
    if 94 * 52 < 0:
        _dead_5173 = 486
        pass
    value = 479345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EznbXggU9L48NwuImVzGESs+8lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_4220 = 599
        _dead_4639 = 61
    total = value + len(text)
    return total

def _ΛΜмЮНЬукШйнлΞ():
    value = 401574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgXvXn8WxPAZKhiIw2CcMTAjvV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        912
    total = value + len(text)
    return total

def _ςМТфЮжΨκΑиЛщьΟΜ():
    value = 146367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgzDPVQD3IMqHz2V8WzINi0f02I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψшлΔНиаЭ():
    value = 616346
    if 70 * 99 < 0:
        _dead_1884 = 418
    text = __import__('base64').b64decode('dmE1bTd0Tkh2YWV0UldoZThsUXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ВБΔМςΠоζИηξк():
    if False and True:
        _dead_5672 = 606
    value = 759797
    if False and True:
        223
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhXdVGIjyp0SaRv7wg6JBzI3zFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        736
        _dead_3440 = 764
        pass
    total = value + len(text)
    return total

def _ΟОзДцпΩирςπΑА():
    value = 783632
    text = __import__('base64').b64decode('eXFhS0ZZN1dBWHpLSHNsdWdzYnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕнерΥδΧкαВ():
    value = 446112
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR/BRXkX36dTbhnx+m+FBjQG5UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4973 = 928
        pass
        755
    total = value + len(text)
    return total

def _ЮЫΒХБυλεДΡьАφ():
    if 90 * 97 < 0:
        138
        pass
    value = 86841
    if False and True:
        8
        pass
        pass
    text = __import__('base64').b64decode('VF90TjJmOEJHZW1LYkhlcjB4N3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЯЧαШλтбμξЪтθ():
    value = 754102
    if 66 * 19 < 0:
        _dead_5377 = 625
        _dead_8380 = 308
    text = __import__('base64').b64decode('c19fYXZ0MTJGNlpmVEkzZHFRTHo=').decode('utf-8')
    if False and True:
        _dead_3165 = 999
        596
        901
    total = value + len(text)
    if False and True:
        pass
        23
    return total

def _υЗгοτИАΨжЧ():
    value = 30724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBaxN3kz6bgRKR+3zl6RNTUMsVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 84 * 59 < 0:
        pass
        pass
        70
    return total

def _ΕтхΠΛΦεфВтЬьЫЗа():
    value = 801158
    if len('') > 0:
        566
        797
        _dead_1266 = 104
    text = __import__('base64').b64decode('REFjZ1I4cFdMajVsYkswU1FFdDU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣνιρиΔБяδρЙ():
    if len('') > 0:
        _dead_9761 = 659
        _dead_2166 = 831
        _dead_9550 = 424
    value = 941494
    text = __import__('base64').b64decode('VjFMUVA3RjJmdkRFNzZyVjBQeVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _βДъДЬкЬъвЗ():
    value = 351013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAKwYXZqyoInFV+pwVGFZAwQ4Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        751
        523
    total = value + len(text)
    return total

def _ПеЕЕЙЦΓβξДлвΞςпγ():
    if len('') > 0:
        321
        2
        pass
    value = 187640
    text = __import__('base64').b64decode('bl9UcEhrU2tDSEJWanNoenNBeEk=').decode('utf-8')
    total = value + len(text)
    if 25 * 26 < 0:
        _dead_9370 = 58
        _dead_9213 = 813
        662
    return total

def _ΕκΩцфгδΔ():
    value = 616259
    text = __import__('base64').b64decode('RGtoV3M5Qk5RT29yWllDRTYzNmI=').decode('utf-8')
    total = value + len(text)
    return total

def _δΚηтЬβхычУ():
    value = 949495
    text = __import__('base64').b64decode('ekVsZUhnb28yd0l5R0taTDlva3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _оТΣΔΛΘЕЗгЭЩщΘΜ():
    if False and True:
        95
        _dead_9653 = 693
        pass
    value = 945997
    text = __import__('base64').b64decode('QVQ4NzAwOHNwQ2RDSDNlZGY0d2E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5803 = 293
        496
        246
    return total

def _ΜЕЖЖаλΘыеΧΖнжцΘЗ():
    value = 891202
    if False and True:
        720
        pass
        _dead_6722 = 688
    text = __import__('base64').b64decode('TzJJX3VhX2hYZXVOREFEekJweWQ=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _мЗвςκхТЛ():
    value = 886697
    if False and True:
        76
        _dead_6924 = 12
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jw7OO1kU24MWaTWH4WSyFQQk7Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9657 = 603
    return total

def _цΖвΝЕПΤИΡюцπ():
    if False and True:
        _dead_9427 = 35
        _dead_8234 = 37
    value = 814797
    if False and True:
        pass
    text = __import__('base64').b64decode('d1dESGZKeDlZbjlMVFkzQ21JZVg=').decode('utf-8')
    if 93 * 26 < 0:
        72
        pass
        _dead_2615 = 261
    total = value + len(text)
    return total

def _КЬΝФОΣзΖγЭ():
    value = 768479
    text = __import__('base64').b64decode('VTR1SDhhMTZpUjdieUJ6Tlc1MUw=').decode('utf-8')
    total = value + len(text)
    return total

def _аδπчУσαπλнРσю():
    value = 125698
    text = __import__('base64').b64decode('Y2VOalIzQVVjQW02V2k3Z1Qyb3A=').decode('utf-8')
    total = value + len(text)
    return total

def _сШφхςνяεЬПО():
    if 74 * 26 < 0:
        _dead_7731 = 653
        pass
    value = 578903
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQrXW1YD8fswHiW38EeJZS18sGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        126
        pass
    return total

def _ЛдΤΓВνεиΓοΜПь():
    value = 81284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh/dSEMe0PtRFwKzx3ioGxEY5UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 22 * 89 < 0:
        pass
        596
        _dead_4637 = 932
    total = value + len(text)
    if 84 * 83 < 0:
        _dead_3549 = 944
        203
    return total

def _ΡТΔвπηφβΦЩ():
    value = 228297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CR7gZUU6rJ4ZYhau/w+yMQZ/6kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΡΚЙИдьэλфО():
    value = 515319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyfxOwIB1f4NIhqL72C6FwIbw2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГςпУеоθпкΧΕφδ():
    value = 329725
    text = __import__('base64').b64decode('WUJ2U1ZsbGRYMl80TGZuMjM0RHM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1181 = 93
    return total

def _ΟДθьйΤΟюЭΡС():
    value = 414479
    if len('') > 0:
        595
        771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By7zYXMIz4UHYj+oxmCDBSEN1V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 43 < 0:
        17
        pass
        546
    return total

def _игЯььΞкφгΞлз():
    value = 298960
    text = __import__('base64').b64decode('SzVoRXRQSGRkSloxM1Fsb2hLNUk=').decode('utf-8')
    if 22 * 93 < 0:
        _dead_5608 = 517
    total = value + len(text)
    if len('') > 0:
        863
        pass
        pass
    return total

def _ыτТΠХЙнЧм():
    value = 956362
    text = __import__('base64').b64decode('SkdGUjgxaVlmemNTejhVZEtma3E=').decode('utf-8')
    total = value + len(text)
    return total

def _μΗъΩбьФΣγκΝ():
    value = 414345
    text = __import__('base64').b64decode('Z2s1cG92emMxVWw4dHlOVm80Xzk=').decode('utf-8')
    if 88 * 60 < 0:
        _dead_1683 = 182
    total = value + len(text)
    return total

def _ВУσйЖΝεΨ():
    value = 907707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwX3OGIWxPoLORiSwW/BYAgKxXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςπИцΧЦЧВоμГ():
    value = 37499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwHRTXQtrqUEFByS60OlICAX6nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хιΔФВτγνΗэρБЯθχ():
    if len('') > 0:
        402
    value = 526860
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTv3RlsxyaEOYgSCxEW9OnA9t30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χЗЫтЪΧБдЦХΜч():
    value = 842604
    text = __import__('base64').b64decode('SExGWWxRajd4bXdRdmI3ZVVDdzA=').decode('utf-8')
    if False and True:
        45
        722
        _dead_2147 = 761
    total = value + len(text)
    return total

def _εΣΥБЧηьмΒицΚРξνΓ():
    value = 237406
    text = __import__('base64').b64decode('bjA2Z1F0TmdUMlE5am1RV1h0b3o=').decode('utf-8')
    if len('') > 0:
        454
        44
    total = value + len(text)
    if len('') > 0:
        pass
        448
    return total

def _ηЯβΑЧσФεьжЪТΞΤр():
    value = 229234
    text = __import__('base64').b64decode('eDA0UmN1djAyaXlJS3R5ZjN3RkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑαПτЪРрωΤХυ():
    value = 910487
    text = __import__('base64').b64decode('R3dNZ1paUnV2bVUyRk9ZdUNBT0w=').decode('utf-8')
    total = value + len(text)
    return total

def _иДШψβκХуЗφйЙ():
    value = 112634
    text = __import__('base64').b64decode('cmNUYVVtdjZQMGswclpEMkFZdjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙявЬьψнъ():
    value = 736901
    text = __import__('base64').b64decode('SjN5dDNmVV9QM1lGQjlNbDgzM20=').decode('utf-8')
    total = value + len(text)
    if False and True:
        801
        _dead_6856 = 536
    return total

def _хэιЦφΡхЖθνοΠЮυ():
    value = 988884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhjseFwGxpcXFVimwGfGBT8t4n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эλЧЯГвΜГПκΕ():
    value = 526747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQDIO1Qw3aQUbVqs8VWAOTQh0ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НψΠШρчАΝгГЬг():
    value = 173775
    text = __import__('base64').b64decode('RzBDXzJsakxKUjIwaGV0b09sUG8=').decode('utf-8')
    if 3 * 64 < 0:
        pass
        pass
    total = value + len(text)
    if 3 * 87 < 0:
        _dead_2756 = 529
    return total

def _ыОψэΙτΨВμВС():
    value = 955746
    if False and True:
        _dead_3195 = 833
        _dead_8640 = 822
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQjmRFtvyrw7MDW5w2elFXx6wzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        315
        _dead_2493 = 771
        762
    return total

def _ПΣлδЯжЬАЫΡФГΩ():
    if False and True:
        pass
    value = 261166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3/lWQZs9r4nPlf3m1SZLho29Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 23 * 25 < 0:
        771
        169
        pass
    total = value + len(text)
    return total

def _ξξАидωзγΨъακхн():
    value = 440456
    text = __import__('base64').b64decode('Zlp5Ql9RQVhnV2pXRjZraWllQU0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2562 = 585
        932
        _dead_9754 = 350
    return total

def _ΙΣΜУЛйшΕОх():
    value = 321516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwrpTFA/0ow0Azqv+GWdGzQhzGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 6 * 23 < 0:
        pass
        pass
    return total

def _φцЭиНЩаδΘΩ():
    value = 760152
    text = __import__('base64').b64decode('aHJtSnRocTZiVThzYmdzcXpVOEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦцχУЪβΧγщБцЬб():
    value = 182351
    text = __import__('base64').b64decode('a3ZRUWhBdWdpSlcwd0JQeW9XRWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟБΩхШяБюΗт():
    value = 492487
    text = __import__('base64').b64decode('WmNKTURhMHdyU0ZsM3hWakxCSTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΧоΙмΑτИ():
    value = 847024
    text = __import__('base64').b64decode('ZDB4bFpEU25aeE9PR2ZpbVdkWmg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6211 = 697
        _dead_2622 = 353
    return total

def _РχβαρбΛТЫΙНЕΗфΡб():
    value = 492871
    text = __import__('base64').b64decode('YUhpNmlSWXR5TF9BbHp4cUI1TjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘицФΓАΥχγщФ():
    if False and True:
        pass
        851
    value = 750201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAf3fQU184E8aAKC7nTAHjYu4Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠЖаγσьзιΧЬψврψΔ():
    value = 684945
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('YlVCYUJMN3k0VFhiNlJyUFJOckQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΩДΥξВыΣκΩκтЬшСНы():
    value = 9368
    text = __import__('base64').b64decode('cDBQZXhSZG1kNko2NFVGa1hqUWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖктЯиэΡэуΜ():
    value = 440670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxDoWHcd0J4XPiWs71uZJg958zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эαЫτςτЧηцΓ():
    value = 836537
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzjMUXAI84oXLVun7GmePBMa5mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7280 = 567
        pass
    total = value + len(text)
    return total

def _ыΑΚфΧшΧМсПВ():
    value = 171129
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSz0TEYt6f05ax+GxkyiFgEC4Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        699
        _dead_1807 = 530
    return total

def _шкОΟЗЪуρ():
    value = 594035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRvmPngLybsWKh6zzVGkGDAuxVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1498 = 400
        _dead_1870 = 863
    total = value + len(text)
    return total

def _ГμщλЖξьΧΛурγ():
    value = 44294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAXXYHQLyacmPTiz/3unIgEF8Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωθΧеΚΩαЬ():
    value = 475780
    text = __import__('base64').b64decode('cm45ZTFjZGJZRHI5RzNLbkNZSnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _θЯнГεЖЧΔψыоЩΑ():
    if 67 * 100 < 0:
        _dead_8935 = 51
    value = 106765
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCDmZksaxoY3Yget7XiJBCo/0zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГТьρЩΗсλΝθχШ():
    value = 102720
    if False and True:
        661
    text = __import__('base64').b64decode('TVI5WnFFWVY0d2ZBTXRhcTc5dE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘбβοДВчяΗкМςΑФ():
    value = 546554
    text = __import__('base64').b64decode('VVU0a3p4d2k2UGRBUVdKVlVGZ1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓЬΝлΗΓюΦςулднъ():
    value = 827784
    text = __import__('base64').b64decode('TzYzbWN5Vk5RVHEzWjZnYlhidXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΠъπЛЩΥρ():
    value = 384813
    if 88 * 54 < 0:
        620
    text = __import__('base64').b64decode('Ym42N1V2NFBFM25WVDRKTVRxQU8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        137
        _dead_2990 = 318
        _dead_4856 = 433
    return total

def _ΓДрСгρОΜвУц():
    value = 174275
    text = __import__('base64').b64decode('UGJjRkVibVhxc3ZGZURMRG8xd1g=').decode('utf-8')
    total = value + len(text)
    return total

def _уФеκЙТΥВ():
    value = 250787
    if False and True:
        pass
        824
    text = __import__('base64').b64decode('cE81RTFYclFTUTFGRHJ5Ukhlajg=').decode('utf-8')
    total = value + len(text)
    if 11 * 78 < 0:
        pass
        _dead_5091 = 307
    return total

def _ЬсГУΗςтэОФгвЖΣΜ():
    value = 860788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj61SFhswZIRFV25zgSjA3UdwX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 30 * 66 < 0:
        781
        315
    total = value + len(text)
    return total

def _аΞжшгЕφЩθχЖК():
    value = 945249
    text = __import__('base64').b64decode('aXY0a1VCWVpWOWpCbnFrZjZWcUc=').decode('utf-8')
    total = value + len(text)
    return total

def _цγуΣΨЙΑакΔхб():
    value = 858072
    if len('') > 0:
        pass
        628
        pass
    text = __import__('base64').b64decode('VW95SE1LcHoxWExuWGNsVXdPNUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЮХΘΠЪΣзНΔ():
    value = 469594
    text = __import__('base64').b64decode('QmMyZTc3NXZSTDdSaUtGRmZUQzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЗΗдЙφРЕξСΞцбЯ():
    value = 530319
    text = __import__('base64').b64decode('S3hwalJRMEdyY2hWRldCNW1aNWY=').decode('utf-8')
    if len('') > 0:
        973
        _dead_8432 = 541
        _dead_1083 = 305
    total = value + len(text)
    return total

def _ЙοχЦσЮчΝΧ():
    value = 693758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRu8Z18Gq6sgYh+n5E6jEwwC1VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψбБΩВξδДфΙМЖ():
    value = 847295
    text = __import__('base64').b64decode('UzJEbFdpY3FIdXNtTnJ2TXdSNlA=').decode('utf-8')
    if 55 * 52 < 0:
        459
    total = value + len(text)
    return total

def _ΨΔРнцнΠлкз():
    value = 276717
    text = __import__('base64').b64decode('dGhZNkJfTHI1dkVhOVU1NWg4WWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΖΧъЖХνФβУψωВδ():
    if 62 * 64 < 0:
        pass
        pass
    value = 631303
    if len('') > 0:
        _dead_8458 = 317
        877
    text = __import__('base64').b64decode('dDJ5d2pualh4OE14S3cxUVVZd1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ωоюΝХβцЯΤЭЪρ():
    value = 156642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhbpPmMc+oc2KDeW70e6EHwp8T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 43 * 63 < 0:
        915
        pass
        680
    return total

def _ЖВЯΩфБясηъЭн():
    if False and True:
        183
    value = 35110
    if len('') > 0:
        214
        857
        907
    text = __import__('base64').b64decode('YzFkT0d0U1JHV0VCV1MzalNCaHg=').decode('utf-8')
    if len('') > 0:
        _dead_1714 = 950
        pass
        _dead_9516 = 931
    total = value + len(text)
    return total

def _ЩγθκКГΙηΒвшЭυлЦ():
    value = 86140
    text = __import__('base64').b64decode('Uk1qR1FjcU5aZk84WnFaUWphN2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ιбШЯΖαСζрЩуΓРΗБК():
    value = 827757
    if 13 * 31 < 0:
        _dead_9166 = 625
    text = __import__('base64').b64decode('YVoxSW1qdklKSm11cU1kcmp0N0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ξЩИΘвЫπб():
    value = 345866
    text = __import__('base64').b64decode('ZFVnUGpGbVdEQVRleE0yRE5MbjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ρЭДΨΜнЖчМпΝчхвπβ():
    value = 767368
    text = __import__('base64').b64decode('bzJ5TlpYcjRkYUNRN1MwelpuUlU=').decode('utf-8')
    total = value + len(text)
    return total

def _аАΩΗТяЩИ():
    value = 826147
    text = __import__('base64').b64decode('aW5vX1Rldkl5Wk9fcTJFYUlHWTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЫОδΧЙμςОЬ():
    value = 275745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXz3WmkQ9bEPCjas4XiRPj88wm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 86 * 72 < 0:
        356
        pass
    return total

def _ΡРПυПιфнξΟКα():
    value = 802986
    text = __import__('base64').b64decode('dWd3aVZmYkNrcGdHeHZFcm1feUM=').decode('utf-8')
    if 5 * 38 < 0:
        779
        pass
    total = value + len(text)
    return total

def _иυююКλΑЪχрМИщяο():
    value = 581975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQjPZWYKq7gSPS207F68OzIp/EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛищФДσАЫΝνπ():
    value = 947641
    text = __import__('base64').b64decode('Z0x4Y0FkV1hTekM4b0JpUHJ6Y0k=').decode('utf-8')
    if len('') > 0:
        _dead_9772 = 524
        pass
        768
    total = value + len(text)
    return total

def _σдбчνпйшΣ():
    value = 294770
    if False and True:
        _dead_9844 = 102
        _dead_1570 = 803
        825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgzCeAAKyf01Mx3x/wO9PREls1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9053 = 706
        655
    return total

def _ΥΧΟФΡфЬБкСΩρυя():
    if len('') > 0:
        _dead_1313 = 610
    value = 445055
    text = __import__('base64').b64decode('RnpDY3ZvSDlMOTRieWxneHU5WFI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_1015 = 248
    return total

def _апψлмκΚхИςсЩΤо():
    value = 893713
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M33HV2kS9YILLyOv5liKBCY+3kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζεФАΥΦмЭιгΙо():
    value = 72860
    text = __import__('base64').b64decode('WjV6Nnc5Z0RTUFY5WHg0QTlLNUc=').decode('utf-8')
    total = value + len(text)
    return total

def _мΕΜБщуΨаχБξΥΣэΖ():
    value = 801906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3boOm4N97I5EjCGwV6qHhQlyT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗхΩВУШцΡиΚЙεΡъΣ():
    value = 947071
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('b2VDRDQzdUNEemROaFlsOFhHak0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΛЕКыхялхχ():
    value = 458738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ki3rOlkD0osiNhiT0HrEYyc6wUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖэПЯызμΥьъ():
    value = 60162
    if 45 * 63 < 0:
        _dead_5596 = 481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTXmYksJ7r8NLCKP4Wa4Lih27UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5061 = 700
        655
    return total

def _ομζдВОΟαЮШПьУ():
    value = 466230
    text = __import__('base64').b64decode('dzdlRE04WUNMWnRnUnBNZ2VNZkw=').decode('utf-8')
    total = value + len(text)
    return total

def _лБαбΜтυьαναΔΑ():
    value = 706548
    if 19 * 65 < 0:
        818
        828
        _dead_8502 = 997
    text = __import__('base64').b64decode('eVlJd1cybEJHa3NMbzJhdVlhUWI=').decode('utf-8')
    total = value + len(text)
    if 2 * 27 < 0:
        522
        _dead_5664 = 538
        _dead_7284 = 6
    return total

def _чΣλуπлφюъΓΞ():
    if len('') > 0:
        _dead_6515 = 47
        pass
        pass
    value = 372149
    text = __import__('base64').b64decode('clhoWHp4cHdMZkp1TlhQVDZIWlo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        167
    return total

def _πΛЛэйβсЫμЧОЕЩ():
    value = 266300
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICTBZ0Iv+Lw1I1m1mU6zBg8M7mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пωηψЩΘΦδышЩΕПπ():
    value = 627798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAXRf11h//8IKASuzVKhPnUeynk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗтνПРσЖΟШ():
    value = 648653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxjQTWM82IMWAh6T7HiVGDYc0Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПУσΡнЖψыφλρ():
    value = 983855
    text = __import__('base64').b64decode('amRaS2RVZUFkc2tNdEhDWkRZN2U=').decode('utf-8')
    if len('') > 0:
        pass
        49
    total = value + len(text)
    return total

def _рылбιшКЕμДТεЯΧ():
    value = 525404
    text = __import__('base64').b64decode('THR2Ykk3UmFLVmZROGZNZUs1WFI=').decode('utf-8')
    total = value + len(text)
    return total

def _нχДРνоηΓΔЖИΡлАКп():
    value = 629072
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjzLW3Qepvkbagqp0WSIMD8sw28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТβΧΠъΓΚЮ():
    value = 797555
    text = __import__('base64').b64decode('Z2xWZENrZVRpSVdWZzJrNXBjSkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЕЬкНэСЬчςс():
    if len('') > 0:
        pass
        _dead_4248 = 76
    value = 201096
    text = __import__('base64').b64decode('UWlJdDYzQnV2WGFicVJ0djNXZ20=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        496
    return total

def _ξΑΩЙоЕζЦа():
    value = 170242
    text = __import__('base64').b64decode('Q2dpdmdSXzFzZnBCUUpYUE9sbE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕчΤΔοχСХыцΝψдΥйγ():
    value = 661229
    text = __import__('base64').b64decode('dVh2NnBjZHVmRE4wVVBTRzNfclo=').decode('utf-8')
    total = value + len(text)
    return total

def _лЦΔηΜДУУΙςΦр():
    value = 254815
    if False and True:
        738
        pass
        _dead_2498 = 764
    text = __import__('base64').b64decode('Yno1T0p3UnpPcE5fVlBBNVRPM3A=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8171 = 376
    return total

def _λГΑξφфΚΖ():
    value = 991398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy23TFlp+P8NGDf2+leabCEAwEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛУψΟωλΜΤЬОИΜωΡ():
    if len('') > 0:
        515
        863
    value = 569754
    if False and True:
        _dead_2475 = 645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FA7sY10fp7sCEDy68m+XYCwn6X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 17 * 29 < 0:
        pass
        818
        843
    total = value + len(text)
    return total

def _ЧкЩΥψΓуΖЮτГЕыИЭ():
    value = 23306
    if False and True:
        749
        _dead_4504 = 184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISbVWXgP8/guYimW5kKaE3IM6zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _оКхνуζδξφШЦнп():
    value = 2695
    text = __import__('base64').b64decode('a2cyMnAyREZRWGRWamdxS0FtbkU=').decode('utf-8')
    if len('') > 0:
        148
        807
        pass
    total = value + len(text)
    if 55 * 40 < 0:
        967
    return total

def _ψμЩφЙкςГΛ():
    value = 70241
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQ71eG4frfoyO1uk2wW+OQIM8no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гкиьΛмΩшеχлмЭгФя():
    value = 148214
    text = __import__('base64').b64decode('WWtHcUY4RU01cWhUVzlpajBGUl8=').decode('utf-8')
    total = value + len(text)
    return total

def _кЧςυΒжЕюус():
    value = 399439
    if False and True:
        pass
    text = __import__('base64').b64decode('dFduRFdqMlZCZ3V0V1M2cmI3UWQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3552 = 255
        939
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()