#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _зΟΟМΨЭΓъдΣаιπΧэ():
    if len('') > 0:
        pass
        _dead_5690 = 577
    value = 94246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DifiQUcJrIwZGwf08l+jPT9+52M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χкАФфАκΝХяюпъчΒΡ():
    if False and True:
        195
        pass
    value = 679833
    if 74 * 39 < 0:
        843
    text = __import__('base64').b64decode('d1BUZDdHNnF5aTZyVHpsbThGSkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _МΔаπхρМРЧγхърто():
    value = 598065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzrJSX837YEbKFaW5liSEDIbxz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕхΥЕзΘΣλМнСγЪφ():
    value = 325547
    text = __import__('base64').b64decode('c3pZSVY3TzZfdTJNRGk1SmtSS2g=').decode('utf-8')
    if len('') > 0:
        _dead_9519 = 581
        145
        _dead_5607 = 321
    total = value + len(text)
    return total

def _ΦΕΖТкЖКЪфπγαвθππ():
    value = 612569
    text = __import__('base64').b64decode('bHBqV0ZXeVRfaWZVOXo2bHM4OE0=').decode('utf-8')
    total = value + len(text)
    return total

def _дωЬЬψХдэАΡΥγю():
    value = 770414
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjbqbHIe9YxaCD63+UOINQsQw1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γδЭРмкθΖсуΞξΤφЫ():
    value = 681288
    text = __import__('base64').b64decode('QURPdUNnNHdGUHNFMFl6ZEhZTGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ПХНΡψЯЕзΜΔ():
    value = 248242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH3wRGEG2Lg3NCyq/FTFEQ597z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟзΥБКсωψюл():
    value = 111324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETfUTX1o1YAGO1yp+VeeLQkL9Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БМψеЮуяΦпЩвщ():
    value = 252619
    text = __import__('base64').b64decode('RkwzUkNQUmRhRlZUNjZtUWtVTm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖПτГЗчΞЖжμσκΜχπй():
    value = 371890
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AA7OfV4V2K4lElawkGTGbAx20EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΘаμΒЬТБы():
    value = 207062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ijb3XVcBybsoIwuS5wWHBysmxUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΩΜРΧЦυΕπйΒАкФДЖ():
    value = 566775
    if False and True:
        pass
        _dead_8640 = 955
    text = __import__('base64').b64decode('c3FKVXdfX0Q3VTJ3N2dQY3h1cnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΙλΜΓМъΔ():
    value = 69169
    text = __import__('base64').b64decode('bm9NaFlqYXFEdVRycEE4NkhGemE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5334 = 698
        pass
    return total

def _хШΚΞжΟИдчк():
    value = 118231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LC3FYm4BrJgIbTmn50GgJwo1zlc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λыУтρпξζняΛшВЗΤ():
    value = 323728
    text = __import__('base64').b64decode('QzlzMGZwcGF6dG5feWRnSWdjZkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ыНБпдАαΤоΛю():
    value = 479237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhbxflkj7PFXHieUxUWeJ3Mjynk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΓыЮкΠцΨ():
    value = 874682
    text = __import__('base64').b64decode('YUsza0tFTm5ReUxsN1NScDZwemg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4725 = 781
    return total

def _кΓРФЗτьШΚΤкΙΦ():
    value = 457528
    if False and True:
        939
        _dead_6618 = 27
        pass
    text = __import__('base64').b64decode('bGtLN3NIeXdodXB6ZGJEWFcwa0U=').decode('utf-8')
    if 38 * 26 < 0:
        106
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ηΨзмгΣΦз():
    value = 561569
    if 63 * 12 < 0:
        _dead_5238 = 399
        _dead_3956 = 83
        530
    text = __import__('base64').b64decode('ZUtWQ3FrYkNkX1pCMnpMckltbFE=').decode('utf-8')
    if False and True:
        _dead_9620 = 651
        pass
        193
    total = value + len(text)
    return total

def _еφУИяпДΑцМΓΠΜ():
    value = 211627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH3TNnIMrb08PliOnVi5Fi943Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 95 * 21 < 0:
        624
        343
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЛХσΣЙПΠωκςΖ():
    value = 739277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mjb+dl0416Y0PwW13WXDJzcXzjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щшιξИτπщфμЙΝКЛ():
    if False and True:
        pass
        _dead_3016 = 800
        pass
    value = 111356
    text = __import__('base64').b64decode('a2F0aDlDREk3NmdLVFM0U2hnR04=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        254
    return total

def _зпНκΚБεΝэгΟιоЬΑ():
    if len('') > 0:
        188
        632
    value = 503135
    text = __import__('base64').b64decode('RGdadUN6RGxRV1lHWmZJSmQyMVU=').decode('utf-8')
    if len('') > 0:
        16
        _dead_8619 = 444
    total = value + len(text)
    return total

def _πΨΙяМμπчγКайι():
    if 52 * 68 < 0:
        567
        245
        pass
    value = 789677
    if len('') > 0:
        pass
        _dead_7978 = 45
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjr0ZmIRrLkJCVeu4lufEHQYwlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 55 * 73 < 0:
        pass
        926
        _dead_5829 = 786
    return total

def _уΔЯεВАωтВпйθφΚην():
    value = 472673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IALFd3Jg3LkBAjic/FefYC8VykY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4992 = 210
    total = value + len(text)
    if 6 * 43 < 0:
        pass
        61
    return total

def _юΧБяΑЯΦшЮ():
    value = 406470
    text = __import__('base64').b64decode('YkR2N0tDZ3ZXRDJTb2VpWHY0eEE=').decode('utf-8')
    total = value + len(text)
    return total

def _σаρМвХΒцщΙжпψπΠ():
    value = 96901
    if len('') > 0:
        289
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA71VFYGy74oOzyn+F+DHnw3zGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4880 = 644
    total = value + len(text)
    return total

def _жхπжαЦюЗ():
    value = 72296
    text = __import__('base64').b64decode('TDVEdlRDcVZpdEhOeV9GUV90YU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗαФкЛΨйИБγФ():
    value = 748727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiXMXWMbz7IHGwKFw12gFxQN0kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9312 = 293
    total = value + len(text)
    return total

def _цЪнцЦιЛΣΖαЩ():
    value = 170906
    text = __import__('base64').b64decode('YnN0YXZ3bmZuaWViRGszSzQ3Y0Y=').decode('utf-8')
    total = value + len(text)
    if 33 * 82 < 0:
        pass
        pass
        _dead_4801 = 506
    return total

def _ΑΔЙлΓΕНэΔфδфμЩ():
    if len('') > 0:
        pass
        pass
        pass
    value = 359018
    text = __import__('base64').b64decode('bUs1XzRnWkNWYWtEdTdua2JQcDY=').decode('utf-8')
    total = value + len(text)
    return total

def _νяЗцΚδайоΓη():
    if len('') > 0:
        613
        _dead_3762 = 102
        pass
    value = 162426
    text = __import__('base64').b64decode('RXF3Q3NOTVpJZzZHYUJtbUFYbzM=').decode('utf-8')
    if len('') > 0:
        _dead_8075 = 825
        367
    total = value + len(text)
    if len('') > 0:
        137
    return total

def _бπψσНζМωΛСκлΔξуν():
    value = 333458
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyfIOnJppqcEbz/wwF/FID0WykQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΩИРΚаιδΣΛ():
    value = 591228
    text = __import__('base64').b64decode('ZWN5WWg2cnpZUXRwT0h6eUJWRmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΡВΘΙюЩфιфвεЫЭБ():
    value = 736611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwnsYEsRx7gQORuE/1ScECoatkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НщвыΨЙκСм():
    value = 727575
    text = __import__('base64').b64decode('R1FpcktZT0p1UTVicG5uNTVITFY=').decode('utf-8')
    total = value + len(text)
    return total

def _οтΔΡюςμТЯВΞЕНОЯ():
    value = 124950
    if False and True:
        pass
        _dead_2872 = 596
        pass
    text = __import__('base64').b64decode('S0hOekZJOTAzY1FGMFk4aVY2a3c=').decode('utf-8')
    if False and True:
        _dead_3790 = 329
        _dead_6851 = 880
    total = value + len(text)
    if len('') > 0:
        _dead_6224 = 211
        _dead_3546 = 976
    return total

def _ΩΕТσοчЪΟъялΕДηΓИ():
    if len('') > 0:
        292
        _dead_5346 = 925
        _dead_8495 = 904
    value = 419257
    text = __import__('base64').b64decode('bGxWdXRZMUJWVEtlNGlINDNoU3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ьεдПВжЗτЩЕΗψτω():
    value = 365568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PALwSwVrrf0ZLSaUzXCKbQA1yEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βγПΔнбαоηΞΚрЭ():
    value = 133043
    if len('') > 0:
        pass
        pass
        645
    text = __import__('base64').b64decode('ZUdzdzUybmNvOXZGU0c4b3RLbF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧзΚзΒΥΡФχППфсΟЬ():
    value = 364556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxfBOAIp9JkvGFuq7mmAOQcrxUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮипеεζьΕΩ():
    value = 131999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxfWeVUr26MKPQWGkW+DHwgg02E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЛηυтξΚΨ():
    value = 206151
    if 78 * 57 < 0:
        _dead_7671 = 498
        _dead_1433 = 72
        pass
    text = __import__('base64').b64decode('SE90YTg0cUNoYk9hVk4wellwMWY=').decode('utf-8')
    if 58 * 20 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _фАπлΜгЬΕ():
    value = 361713
    if 66 * 66 < 0:
        pass
    text = __import__('base64').b64decode('RklIVElwM1dvTkZLSkx0VUJYSFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘфιРΒжщδФΒωбыВΕЭ():
    value = 823962
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQbmXEsuyr8baxm1zkKFAyEDsEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дИНяνчςΘпΖΥΝсЙ():
    value = 124526
    text = __import__('base64').b64decode('c0EyMEtiZEVUSDAxUGNXdHFqcTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΛнШιЬРΒΨбΦвΖ():
    value = 997371
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBbmN2A//6k5HB6V5w+7YQM66kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωιЪиьФПφйМ():
    value = 231999
    text = __import__('base64').b64decode('VEl5a0ZXYUJhTlhudkV4QWRQano=').decode('utf-8')
    total = value + len(text)
    return total

def _ωщυееςΡпΜдЫ():
    value = 264557
    if 72 * 84 < 0:
        pass
        539
    text = __import__('base64').b64decode('UGVPb19Hdl9QYk9SZ0o3cERfM3M=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_6837 = 788
    return total

def _μяγуΒнВΨэκαН():
    value = 167682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HATtNwk79K4UNlq33GfIAAAm7FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΑВНъΜλюнОИЛЗ():
    if len('') > 0:
        _dead_8970 = 521
    value = 909582
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAjpOHU18LkoNj/3kAGSJRR4z3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        71
        _dead_6289 = 537
    total = value + len(text)
    return total

def _λйοЙΩξЪфЯΝ():
    value = 474703
    if False and True:
        886
        _dead_1759 = 999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBz1QGUXwfs0aSmqxXSFLAMlx3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζπМкΙψТРЫΛИ():
    value = 956126
    if False and True:
        _dead_2926 = 930
    text = __import__('base64').b64decode('UG1CbWZHM3ZIZDc0RmVYVjlMajQ=').decode('utf-8')
    total = value + len(text)
    return total

def _υΦΞКσЖΝλ():
    if 26 * 80 < 0:
        pass
    value = 589773
    text = __import__('base64').b64decode('ZGVLdXZ4TThvMURMNVhQZ0JVOTI=').decode('utf-8')
    total = value + len(text)
    return total

def _вρГΑмХτφЪ():
    value = 658550
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQb1Y0UGwackbRWSx3GIEXEKxzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 99 < 0:
        _dead_5026 = 861
        _dead_8588 = 457
    return total

def _κуОбЦЮВнΗЪ():
    value = 210614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En7VW1Mzq4AFCTeiwVjHORYJ4jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9813 = 227
        403
        pass
    return total

def _ψМЮВХΞлλЯ():
    value = 78252
    text = __import__('base64').b64decode('UEtNRkhtQThmWGFoM0hvSHF3aEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΘфχЖдθфШреЦΟкСΡ():
    value = 324756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQLbREMa8q4EL1iH+FO3Hit9xTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МКοшΥκэъмКЪрчφγ():
    if len('') > 0:
        84
        _dead_1104 = 151
    value = 338393
    text = __import__('base64').b64decode('UkdJVHdFdzZ0dGpNWDBsRXhlZG0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7570 = 716
        _dead_4419 = 312
    return total

def _εЕчцУΔдΦиτуЫв():
    value = 549862
    text = __import__('base64').b64decode('SlZrNXFSVjluNWY4cDFiWEswMmg=').decode('utf-8')
    total = value + len(text)
    return total

def _χЫβЛУТΛИΑωУу():
    value = 481704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCjVOWVvpq0FOzaLxF2DHR95sFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σγΓбξЦΑφμεΦ():
    value = 931215
    text = __import__('base64').b64decode('cjUxNVB5a3QwbmFoMG1ZbnRuUmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _αХΘψαΤРкцОЧ():
    value = 317715
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzfLOQAd8p0VNCmb7GKqJiw/8Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яГαдКΘйαΤцы():
    value = 664256
    text = __import__('base64').b64decode('TzNCYU1NRjQ3SDNTbnNaa0lfX2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ζюИΩΟΤекΓχбы():
    value = 416541
    if 69 * 23 < 0:
        314
        607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxfmR0kTxvwCND+czn7EYC8f7Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        100
        _dead_3649 = 754
        _dead_7705 = 443
    total = value + len(text)
    return total

def _ЛБΠьЙтΞκк():
    value = 655502
    text = __import__('base64').b64decode('VlFocEdsY25LWmxRX0p2SXR1ak4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΠΝЕΔΠυχχБζαΗΒ():
    if False and True:
        _dead_5005 = 825
        _dead_6556 = 59
        _dead_6059 = 937
    value = 41256
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyTzO2Me+6QbHliq8n2JNg98514='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 16 * 89 < 0:
        376
        565
    return total

def _чδхΑИСμαйхΘΧΤЪ():
    value = 323303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NH7rR0cT9J88EwWH51fCMBF9zUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йαΓЪψЫЗΥΣЦъΣΠыςΘ():
    value = 154435
    text = __import__('base64').b64decode('WjMzbEtBVjZ4QnI1NWxsZm5RQjM=').decode('utf-8')
    total = value + len(text)
    return total

def _κхйγяВΕЫфеΚЧЕΥΥθ():
    value = 99603
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('Z3RCQUdhMWdHa2piMHZ4bE1mREc=').decode('utf-8')
    total = value + len(text)
    return total

def _ψедЖОгууЫΩчЭμ():
    value = 536188
    text = __import__('base64').b64decode('ZEZ5M3FoTjVFclBYenpNeXR4VjM=').decode('utf-8')
    total = value + len(text)
    return total

def _щкУτΕηΥЛъΛΙаκКμ():
    value = 611140
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwbofWUYzqtQOxmMz3S1Yip6yjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦШΙЪΝοχΥтΤχοоΛ():
    value = 530416
    if len('') > 0:
        _dead_4885 = 769
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQjxPHY87bEJCTWA4ni8LA53/kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖдεςΤΟцСΛδρ():
    if 92 * 19 < 0:
        _dead_3726 = 769
        pass
    value = 146087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISWwXldo7PEJAwS32gKeI3cbsmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цфНσΜΙФУχнЭцχ():
    value = 102289
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pzi0Ymc2yoUybSK3nmeAPRoD5m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΟЕΑξЛψΛвпЮб():
    value = 509832
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy3tYFtr+Z8GLwS5+gOvGC0A0lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪмμΦγΨЛνβОΥ():
    value = 132028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSPFOmc4zosGPxmR33eTMD0L1zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5582 = 729
        885
        _dead_2935 = 561
    total = value + len(text)
    return total

def _ΟИψвыЭκΩΠ():
    value = 912541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHvpZWAPq4E5BQK7mHiaZise/UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΝгКΓΤΞρΜИγωδΥ():
    value = 380260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwTuNnYd7a8xNwOO3UKUICp5t1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гюσФμМιеМΓΗ():
    value = 179220
    text = __import__('base64').b64decode('YkVzQkdvVmlpWkRiT1NMTkI4MXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ηθΧфЖгσσЛЩТпΡю():
    if 38 * 43 < 0:
        pass
        pass
        17
    value = 436028
    if len('') > 0:
        362
        941
        _dead_1636 = 974
    text = __import__('base64').b64decode('TFpvUlZnb09lOFR3b2dXRjB4S0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗεщΙУδювΡιиΝъ():
    if False and True:
        pass
        199
    value = 118865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB7FS1kD9PxVaiyg8G+/Dis1zWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 29 < 0:
        _dead_7655 = 845
        28
        pass
    total = value + len(text)
    return total

def _НЛкФХЗеЫМбΝЪФоΗ():
    value = 82364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECbte0M29LISFRmlwV60Ej0322I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧъοβΗЪιв():
    value = 621979
    if len('') > 0:
        pass
        _dead_1211 = 863
        pass
    text = __import__('base64').b64decode('TlJlQVlxRmREZWRJY1plOHpPQkM=').decode('utf-8')
    total = value + len(text)
    if 74 * 88 < 0:
        _dead_6383 = 402
        505
        _dead_6222 = 214
    return total

def _ΨδмФПВХятΟД():
    value = 850875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwLRR0Mj754TMguMzFKoNggp0nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓмЮΨΔТЭΞαΧΞΒПЯΑη():
    value = 854895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAbhTXoY6/wbGD32w2aXOCs5/U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΔνЩΡпэФ():
    value = 841415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB/TP0tg14EHMCb32XGbN3cE3WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧЭяЕБгδМСμλοгГ():
    if len('') > 0:
        _dead_4916 = 686
        _dead_2135 = 107
        pass
    value = 592168
    text = __import__('base64').b64decode('V0ZHeTl2XzdRUmY3SzlPc2JUMk4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4751 = 895
        _dead_2631 = 12
    return total

def _ΧчЮκфнкэфΔВΚσδζ():
    value = 682142
    text = __import__('base64').b64decode('Wl94Z2d6dTIzNzZWbXlDM3dfN1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫаΚрΙΚмЯф():
    value = 159513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHfWVlwv3KkOGD6x2kS7ETwksTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αйΠэτТсκОн():
    value = 788203
    if False and True:
        182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3+2XgAa9rEOMwKZzWygBxE1zls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΠΘΧпΗВымУайоπх():
    value = 999792
    if False and True:
        pass
        _dead_9629 = 893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhrGakht9bgqMzeXxmmDMzED7Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 66 < 0:
        _dead_5377 = 988
        pass
        428
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_8686 = 965
    return total

def _ВψчΣЬЭОЩΦЕдΧ():
    value = 191560
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTrVQwE4xqEtYwyAzV+5LSw4yDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        402
    total = value + len(text)
    return total

def _ΕΚПЕЬЙΓд():
    value = 303634
    text = __import__('base64').b64decode('UmQ0a05Xem04NHUyQkt2ek9DSU8=').decode('utf-8')
    if 78 * 58 < 0:
        pass
        562
        _dead_7658 = 663
    total = value + len(text)
    return total

def _ΥΧОЩρЦζдБФ():
    value = 157476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHa2OVcGzfkzNQaImHy1Hy4isjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иМςНΡцΤΒЪΘΖгπΜк():
    if 61 * 86 < 0:
        pass
        759
    value = 663030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBfjW3Ju1vohGRb6mFzGAnV+43o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εкоπυйЗσΚοьяΕй():
    value = 187736
    text = __import__('base64').b64decode('cmZpWFpwRExmaDcwR2NXODZQTWg=').decode('utf-8')
    if 45 * 6 < 0:
        810
        _dead_7488 = 958
    total = value + len(text)
    return total

def _γюΖμъξпЗдΙчφюбυъ():
    value = 29098
    if len('') > 0:
        pass
        620
        pass
    text = __import__('base64').b64decode('ckY1dko2eFI3NU1ja2RTTGUwYzY=').decode('utf-8')
    total = value + len(text)
    return total

def _КЕσвбδΓΨчλ():
    value = 692674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECjDP30r8JlUDhaHxUaWDQ8g238='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        247
    total = value + len(text)
    if False and True:
        774
        _dead_1143 = 977
    return total

def _ИγоУсψεκΠ():
    value = 65980
    if 67 * 3 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgjtSgFu751UGzyB/A+nPnAstU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑаΖХкΠМΑβνιλ():
    if len('') > 0:
        pass
        _dead_4642 = 197
        pass
    value = 675753
    if False and True:
        922
        pass
        _dead_3102 = 705
    text = __import__('base64').b64decode('cEZKV3IwdEVYTlN6amVLRk5CN0Q=').decode('utf-8')
    if len('') > 0:
        _dead_4701 = 879
    total = value + len(text)
    if len('') > 0:
        158
        pass
    return total

def _ЧНТЭСщрπυфлЛφη():
    value = 861459
    text = __import__('base64').b64decode('bHUwemtDWUVWNUxhRkxiN0hmMFc=').decode('utf-8')
    total = value + len(text)
    return total

def _рΘΚΜвПΜωЗΗЮλ():
    if 52 * 69 < 0:
        pass
        _dead_4300 = 278
    value = 138140
    text = __import__('base64').b64decode('SmRsVzhZWVJJTnduWGdpeVpBMHM=').decode('utf-8')
    if 32 * 25 < 0:
        37
        pass
        322
    total = value + len(text)
    return total

def _УнЭЮΔОΗΗаΡΝΞЬαЦΟ():
    value = 888416
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzbLOGIw9qsQACOJnHqnFzV50Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΣСγкцΛΕКεΦΝ():
    if False and True:
        428
        pass
    value = 260307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgC0S3IGyqwqLz6Sw3TFPS4QyWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        311
        pass
    return total

def _ЩΜΛНΩзТЩθЫЕσ():
    value = 606884
    if 72 * 88 < 0:
        745
        pass
        260
    text = __import__('base64').b64decode('cVR0QW0zcnkwUkk0b3hEcThqM3c=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        53
        524
    return total

def _яДΜЦьΑЕцЕΠΙЮюЖ():
    value = 142466
    text = __import__('base64').b64decode('UHJLaGpld2FSZXBYVFN5eVBpaTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡХъруЯσΩ():
    value = 892579
    text = __import__('base64').b64decode('RjZRRTJPek9fODl0MnlrUl9QV1E=').decode('utf-8')
    total = value + len(text)
    return total

def _δеВтКрνЭ():
    if False and True:
        _dead_3655 = 214
        pass
    value = 137190
    text = __import__('base64').b64decode('aFJIWGpncmVENnJXM3ZiTEd6b24=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4832 = 754
    return total

def _ГВИшηрκдПЖРЬΘбБθ():
    if len('') > 0:
        pass
        791
    value = 967123
    text = __import__('base64').b64decode('emJWMmxoYlFBa1lnRW1yMHdVS3c=').decode('utf-8')
    total = value + len(text)
    return total

def _АъбшТψΟБτь():
    value = 353022
    text = __import__('base64').b64decode('bjJlRlBDYklwaTZCdVM5N0xfSjU=').decode('utf-8')
    if False and True:
        pass
        931
    total = value + len(text)
    return total

def _чЖпνЩвсμ():
    if len('') > 0:
        869
    value = 101826
    text = __import__('base64').b64decode('WjJfUW12bFptanJVcVpfVldybko=').decode('utf-8')
    total = value + len(text)
    if False and True:
        924
        pass
        pass
    return total

def _ΑоИτйВЧлЮηλУЩ():
    value = 533450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JifgZwccrbwTAim6xWnBJhEI6m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НθЖьЫΒжТαЬшοюзр():
    value = 75039
    text = __import__('base64').b64decode('b1JfbzliNkdudkVUZ3IzN0JOMHE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9905 = 191
    return total

def _ΗΔЪΧςταΗщзю():
    if len('') > 0:
        _dead_6878 = 84
        pass
        _dead_2720 = 584
    value = 754188
    if len('') > 0:
        pass
        pass
        537
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BineRgAS0pkFGVeh2wPBHBMJ5lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        911
    total = value + len(text)
    return total

def _лΟΛοφАΠμЦьце():
    value = 4571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzizdwkS8K5Xa12Fm3LBIAM8sk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЕμΑыфΦИГШ():
    value = 183640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MynWSlMwp58gbDuCmV6DOAIdtGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΦПЪΒИξиЛΜИВЪбГω():
    value = 761065
    text = __import__('base64').b64decode('cjZyNDAzWkx5TWNLNmx2NUJqVHc=').decode('utf-8')
    total = value + len(text)
    return total

def _зЖρЬРυζУдъФЮΥ():
    value = 990562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj3zZG4z8I40EVaK21mXBQYuwWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        513
        _dead_5689 = 683
    total = value + len(text)
    if 18 * 15 < 0:
        pass
        _dead_5172 = 258
        472
    return total

def _βЭζВеЦΓЙтлΤыРьИ():
    value = 460719
    if 89 * 77 < 0:
        864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB7+Y1Me8pcxFluNmwaKMDAI6jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        647
    total = value + len(text)
    if 14 * 31 < 0:
        803
        pass
        pass
    return total

def _ΒΝλБξμюфΔЧοз():
    value = 92879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDjoZWY/9fwta1e1mHivPBc56GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖзШΒбмЗЕειЕх():
    if 51 * 40 < 0:
        pass
        _dead_6626 = 928
        _dead_2567 = 287
    value = 262893
    if False and True:
        642
    text = __import__('base64').b64decode('SlVFeUpzMjdUM1BISlk3cHhtMng=').decode('utf-8')
    total = value + len(text)
    return total

def _лξЙνТднκТ():
    value = 397265
    text = __import__('base64').b64decode('TUtkdnhrN3dFMXpkNVNsaEk3cVA=').decode('utf-8')
    total = value + len(text)
    return total

def _θИнΞσяηГЬЕςИΘΕΒП():
    value = 753466
    text = __import__('base64').b64decode('ZGJEQkh1NEc3RV9ReXhCY2VUbkg=').decode('utf-8')
    if 78 * 4 < 0:
        _dead_7185 = 747
        _dead_3127 = 142
        pass
    total = value + len(text)
    return total

def _δοЩЗΓЫЕνСдβαуЩ():
    if len('') > 0:
        214
    value = 982301
    text = __import__('base64').b64decode('VWRzNE1jRE92bGd5cFZCOXhWd1I=').decode('utf-8')
    total = value + len(text)
    return total

def _МΦηβЙРωτЦΞβРы():
    value = 714564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LA71SHNu/K0nAybw2kanGDce/Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _λмгРЕЕςοНьφ():
    value = 417489
    text = __import__('base64').b64decode('cmdjMmlMQU1JVUhSWTEyUzFMekQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒθВΣцπφзяδЦΒбΘЪ():
    value = 467996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQThO3cy5IkzHha15GDIFREQ6WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЕСЗъЫΙсТΙч():
    if 95 * 65 < 0:
        _dead_3006 = 389
        pass
        _dead_9506 = 864
    value = 991096
    text = __import__('base64').b64decode('TGJZZUpoX0pCTjF2anNIaEN6OE0=').decode('utf-8')
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ЗзРξΗЫγΟθГνφΧзξп():
    value = 446245
    text = __import__('base64').b64decode('SkpKSXZRdWlLTWxaTEZwUWJYS3M=').decode('utf-8')
    total = value + len(text)
    return total

def _фгαАρОвΓФЮΩΞЧДΛЗ():
    value = 887776
    text = __import__('base64').b64decode('QjNfVnJlNlZYcm05NHg4eDlMQV8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝοымΧюδοΨ():
    value = 909025
    if len('') > 0:
        550
        690
    text = __import__('base64').b64decode('bmp6Q1VUWWRjWmFPb05ER3NHNDE=').decode('utf-8')
    total = value + len(text)
    return total

def _βПмЖδζэΡιЕЛξиγΖю():
    value = 634051
    text = __import__('base64').b64decode('dTJVNG5XQU9rQlBQb3VLamtscWE=').decode('utf-8')
    total = value + len(text)
    return total

def _хъπБХжπΓи():
    if 84 * 38 < 0:
        pass
        _dead_9007 = 110
    value = 317803
    if 50 * 35 < 0:
        225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwXCW0A9064KGRWHxFqgIwAE01c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κфьхΥОыξЖμΘЦΦиλ():
    if False and True:
        _dead_3140 = 495
        _dead_3483 = 186
    value = 424317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnfbOGAW9oETGTqPn2avZDd21z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _глΦκАшЫΣШρΚъ():
    value = 891886
    text = __import__('base64').b64decode('WTNiWENWTXZJdnB5ZnZIdVJxMU0=').decode('utf-8')
    total = value + len(text)
    return total

def _пвусаЕζхеаЮφФΔΘ():
    value = 986401
    text = __import__('base64').b64decode('UjdDZDNSeEZUN3NETlFJWllsYWU=').decode('utf-8')
    total = value + len(text)
    return total

def _рξгЯЫπΚιВΜ():
    if 52 * 24 < 0:
        _dead_7483 = 659
        _dead_7407 = 484
    value = 975757
    text = __import__('base64').b64decode('R2M0Umk1U0FIaTNzU2VUdDZsZTI=').decode('utf-8')
    total = value + len(text)
    return total

def _СснАЮΞдΨДбξ():
    value = 370087
    text = __import__('base64').b64decode('ZXZONjJoTnc4a1FqbDBqcTRpVzU=').decode('utf-8')
    if False and True:
        _dead_5968 = 822
    total = value + len(text)
    return total

def _рМршΔмΦΖхЮκΨλΑμз():
    value = 928104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRfDXWc8q6AVIwG0yg/AEiAct1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 11 * 51 < 0:
        308
    total = value + len(text)
    return total

def _ПтαЧГбРΩβΘΖοο():
    value = 384986
    text = __import__('base64').b64decode('TnZJSzNQbUdlSF9MbEZIUTU4NVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖИΙΦΨИАИЗЬΓюМΚ():
    value = 778254
    if len('') > 0:
        pass
        _dead_3804 = 727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FALLPEcV14YbCzeuwnu0LCQpzWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΕΝПΦΘγπЦφΥаУ():
    value = 637034
    if 10 * 26 < 0:
        210
        600
        pass
    text = __import__('base64').b64decode('dUVadVNOSXdpOWhLVEZsUHlMMDk=').decode('utf-8')
    total = value + len(text)
    if 66 * 54 < 0:
        pass
        _dead_8768 = 802
        _dead_8357 = 145
    return total

def _ΖылΩΑяЧЯДΥΛнνΚ():
    value = 808084
    text = __import__('base64').b64decode('bGNRamk3U2I1SHRJTjZuRWFVTlI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩοХΖСТкПΤΞζ():
    value = 430783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX/JPl8D9YMqaCCg5E6FPT987W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔЭхЕψМτдв():
    value = 164001
    text = __import__('base64').b64decode('eTZiQWhPSU40Z01pTE9QZXRtRXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗоβйБчΝΤшПЮυБЛ():
    value = 303557
    text = __import__('base64').b64decode('SFkyazJNdnhoenljaWhFS1VNV1E=').decode('utf-8')
    total = value + len(text)
    return total

def _γыОΕсΗПдьюЛвΔΣьл():
    value = 45460
    text = __import__('base64').b64decode('Q1BYM3V0eUJkU3J6Xzg5cnVlQ1M=').decode('utf-8')
    total = value + len(text)
    if 40 * 76 < 0:
        _dead_8624 = 710
        349
    return total

def _эЫενζМТиДиιΒΨΒ():
    value = 15103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mia2ZmYcx5cHMSuO4wa2FikH82M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        579
    total = value + len(text)
    return total

def _ТΩΦЭЮΩοΟВΜ():
    value = 10626
    text = __import__('base64').b64decode('VloyZlVjUnBZQU5jaVZPYnQyQ3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΘЙΟиЭνЮΛΗЗΡЭъ():
    value = 947282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dhz2QUI66b0TFAv140W3PCgHwWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 89 * 68 < 0:
        _dead_1792 = 680
        444
        _dead_6172 = 363
    total = value + len(text)
    if False and True:
        986
    return total

def _ПщΟЬюΙφζΨμэ():
    value = 211251
    text = __import__('base64').b64decode('aXpWSGRTd1FXeUtyWW9YdXFNdEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧигМσγΝΥшАЕМотЛц():
    value = 316328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAHhfgg+z49VFTy24gXBEwYJtkk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РцεςΠΣΜγъИκУΙ():
    value = 144242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiPmOgAw+5IvNDanx2yXHXEK1nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛмθьоΧΛκиεκΓ():
    value = 883915
    if False and True:
        803
        _dead_8288 = 595
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAj0QXY87YAyEFeOnV67Zhok3Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λвчςχΜεθΚΚ():
    value = 264127
    text = __import__('base64').b64decode('ZFllYU1CbDRmRE5pWmZidmpqTkw=').decode('utf-8')
    total = value + len(text)
    return total

def _СΚАξΩЕЛОЫХБβρβ():
    value = 930542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhjnfVo8+6pRNRunxUexOyYY3lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бСΘΜθНΞЬβБΠх():
    value = 224578
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ejz0YmMa3IIuOyfw0lS9JgQf/U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5017 = 621
        pass
    total = value + len(text)
    return total

def _ХΨЧχяАΣιьΟΒΜΖО():
    value = 839892
    text = __import__('base64').b64decode('ZU9wSXpIUHFFMVpKYUs4YUJVZGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΧщΙуΩЧФКыфДг():
    value = 905510
    text = __import__('base64').b64decode('aERZOV93b2xlTFNVakd5eTVyRUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ОСψХЮΗΒΤΕ():
    value = 818040
    text = __import__('base64').b64decode('aU5UOGExZmhoQUtFV3hxSEJLazE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧюΙМΨΑιХ():
    value = 188803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAboTAJrxIIRaT+inASRbBx67GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υДιηуЖΙΞΧлΟαл():
    value = 908779
    text = __import__('base64').b64decode('cFhHYnBUbnA1bFFXYjkwb0dFWjY=').decode('utf-8')
    if False and True:
        871
        857
    total = value + len(text)
    return total

def _ЦΞРБЗмΩгШн():
    value = 944407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgjhX18qq783FwOXkQSBHRIn5kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΗΕΘюапЖ():
    value = 35020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXfONmFoqacwYzqM0k+fDg41034='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖπШαβеνωВΛСζЬзсΤ():
    value = 824675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz3gQV0s27k3AxWM5X/CZyYls2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εσчИжштΞчэ():
    value = 856869
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KizoXHJg3K46YhiV+UTJHxA790A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        724
        957
        _dead_5995 = 603
    total = value + len(text)
    return total

def _ωΥбΒΒаеТдУοлщεЛЫ():
    value = 855386
    if False and True:
        _dead_8987 = 293
        19
    text = __import__('base64').b64decode('SG5RTXNWMG15azNJR2JtXzRsZ2Y=').decode('utf-8')
    total = value + len(text)
    if False and True:
        59
    return total

def _чΦЖБчнσьаО():
    if len('') > 0:
        pass
        477
        821
    value = 659977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnrjSVsR+P8uLlun3nO2Ew0Z3T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьφОΔοУδсИρΨЫ():
    if 7 * 67 < 0:
        pass
    value = 434170
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATjzX3Ipx68obl73+3yGJCo70F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шыгЕΦηимнι():
    value = 189859
    if False and True:
        _dead_1440 = 136
        pass
        74
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSfcaXYv960RIhyCnlLBMHMZtD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 1 < 0:
        _dead_8575 = 607
    total = value + len(text)
    return total

def _ΗγчαТшξκУ():
    value = 549239
    if False and True:
        745
    text = __import__('base64').b64decode('YzdKcXlfOUVUaG12MkR1MFhGWjU=').decode('utf-8')
    if 6 * 89 < 0:
        443
        819
    total = value + len(text)
    return total

def _окНлπЦЗλШуу():
    value = 208323
    text = __import__('base64').b64decode('cGNSVzBjYVpaRWFLSXpwZ2NGUG8=').decode('utf-8')
    if False and True:
        988
    total = value + len(text)
    return total

def _ΗбθПутзοЛ():
    value = 718094
    if 43 * 57 < 0:
        pass
        _dead_1165 = 123
        _dead_6257 = 450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg3SRAkt9a8iIDf03A+RYBUt6jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9638 = 382
        pass
        111
    total = value + len(text)
    if 98 * 77 < 0:
        _dead_5463 = 936
        pass
        234
    return total

def _ΟЬсмБсБот():
    value = 819567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT3URAkjxPoPOACEzXiKHQM5t18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οДмκИуΧхτ():
    value = 354515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCbSZX1p1ZgONj+i7memJjUEsEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЬςΣΡыкДΨΟΗ():
    value = 562870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT3tQnAP2K0WCxuG6kS6GSk8wmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _гΖИЕЭЖβЩΙφ():
    value = 799317
    if 27 * 9 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ahrxe0IO1/AsCAr35Xu/PXYW/l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯсцμгκτγΚαΨΜ():
    value = 720885
    text = __import__('base64').b64decode('Qm1UaFhtcGU1U0JrWXF1cnR5ck0=').decode('utf-8')
    total = value + len(text)
    return total

def _ХχЯзΚЯНИМΟИеββ():
    value = 311568
    text = __import__('base64').b64decode('eU5ac0tMRWlJX0xWNW15MnZWeEM=').decode('utf-8')
    total = value + len(text)
    return total

def _сΗХНΧАΥΧф():
    value = 414745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCjcaUs4wbkIaSewx2WcNQ8OsGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΒЫΖΤБрχ():
    if False and True:
        _dead_9398 = 690
        717
    value = 899753
    if len('') > 0:
        pass
        480
        665
    text = __import__('base64').b64decode('bmk4Q0NLOG5zSzZxdnJtSEhRWFY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_8139 = 786
        _dead_5845 = 92
    return total

def _ΒПΑуΗффЖΛθΠΑЯΡ():
    value = 853109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwKySmYDpp0ROTmPzFO5ZgJ84kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МоЕθныли():
    value = 671834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHvjfVIhrIcNKRqTyUOVBgB/20E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СФсτюЙβτЛ():
    value = 772484
    text = __import__('base64').b64decode('WjJLTEZqZE9MZndDUEJ1MmMwWFo=').decode('utf-8')
    total = value + len(text)
    return total

def _юυκφσышчΛпцИъΚσ():
    value = 169582
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT3sSnVu364BKCX7mEWnNwR63Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        991
        pass
        _dead_9044 = 671
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        915
    return total

def _θбРωюΝбθщТχВΣσΚ():
    if len('') > 0:
        _dead_2516 = 754
        pass
    value = 882247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQfFX3oKxIcFLCeg6kHCNX1/62w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 26 * 83 < 0:
        _dead_2007 = 68
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8016 = 617
    return total

def _ΔФяφεαчΜКГуωююΧЭ():
    value = 283972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB3tV3sM7JJWOS326neSMzMa9Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_9503 = 229
    return total

def _ληΚйркδЧ():
    value = 668706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiLtN2Q+yrFUYl+L+3mSHHQ74To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        118
    return total

def _ΥθΓχЮКργДρσ():
    value = 6058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXy1bHYr5LIVDRui5g+vLC97yk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТюНтΔрβΔэйΦ():
    value = 760586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRnJRnsWrodXGF6g5n+oGxIjzUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЦεмγЦОκфθγьδ():
    value = 676670
    text = __import__('base64').b64decode('c3lGMFhrWjNTdkJFclpHd25kR3Q=').decode('utf-8')
    if 77 * 38 < 0:
        _dead_2081 = 814
        230
        _dead_2342 = 807
    total = value + len(text)
    return total

def _ΖτРПуКΦхΙсюΟЭςΗО():
    if 29 * 83 < 0:
        736
        809
    value = 2699
    if 97 * 38 < 0:
        pass
        pass
    text = __import__('base64').b64decode('WFl4aTZkajdMVGU4RXhiTWVIQ0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΞяПябзΕлΑθτΔ():
    value = 38576
    if len('') > 0:
        pass
        _dead_3614 = 848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXvzVloT1r85Djui/0GZGAoj0nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΡЭУВПχЕ():
    value = 918431
    text = __import__('base64').b64decode('U2MwQzI4aU1RQ0pxT1lsV3BDRGg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        822
        pass
        _dead_8725 = 226
    return total

def _КъзΖΗΟзущΣЮτснЦΜ():
    value = 557870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB7oNl9h7vEXKRqV+GmvEx98x2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞЮАσЙщθхРЧΕзЙщΡ():
    value = 543141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwL3XVch+qUkbym07FnAMA0Wxnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЦνЙщЦгΙΗ():
    value = 529511
    text = __import__('base64').b64decode('cjdMZUc5SzBwWGVndWtfMUYxM18=').decode('utf-8')
    total = value + len(text)
    return total

def _УЫрЮкοЕРучШЭΓ():
    value = 153541
    if False and True:
        106
        pass
        997
    text = __import__('base64').b64decode('cXB0azR6RFBjbG5RTEg4aTdxWXk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5283 = 799
        pass
    return total

def _иΙЮδεюЮφчнжτΚБΞс():
    value = 265224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCDnV14LxL8yEiOOzXDCZCA2yEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сσЪπςаΡδχ():
    if len('') > 0:
        119
        _dead_6972 = 688
    value = 604848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3jFS1Q1yZdRExjw2kCEbH0f4mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6003 = 166
    total = value + len(text)
    return total

def _шЗжγЩфζλμγмжвб():
    if len('') > 0:
        pass
        _dead_5299 = 42
    value = 91657
    text = __import__('base64').b64decode('aGIySDNoZV9TT0E2NGY4Qm1Oa2M=').decode('utf-8')
    if False and True:
        818
        pass
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        _dead_6030 = 164
        755
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 67 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    pass
    _dead_4745 = 424