#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _βЭΓΨΚΗРищΗθΦαΦμи():
    value = 644961
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQrMQX4Y/bIuYz/67XeKLgYI4Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8070 = 797
        _dead_2597 = 379
        _dead_8191 = 175
    total = value + len(text)
    return total

def _ΤкеДгШΒΩΗХΣт():
    value = 494120
    text = __import__('base64').b64decode('VW1rd1VYRExLN0VfZFNFcVUwNU4=').decode('utf-8')
    total = value + len(text)
    return total

def _αΜюβψэσΩБЕьлε():
    if False and True:
        _dead_5604 = 622
        7
    value = 511822
    if 38 * 29 < 0:
        pass
        323
        _dead_9516 = 192
    text = __import__('base64').b64decode('bnVKczAxdDlqbndqaHhmdndRc3I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        946
    return total

def _ФтвΤχнэцъпняΥбН():
    value = 615239
    text = __import__('base64').b64decode('SGpJVjdDemJscFRWZlBMMTBnaUc=').decode('utf-8')
    total = value + len(text)
    return total

def _рΓМофΟπТε():
    value = 403190
    if 92 * 22 < 0:
        pass
        _dead_7210 = 295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAqzPwZs6a1VEDakxnqEJQoky3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χψЫиχэξОХЙ():
    value = 128861
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQL+TWEtyKAFAgeM+Ua4Hg0uvGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шЪЦкΠΣΘыХΒσΓτл():
    value = 257261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITrMYEIP+acpKQ2nxUbJYiwp0Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7505 = 83
    return total

def _μпЭЦγърТΚаямозЖЭ():
    value = 785363
    text = __import__('base64').b64decode('VEo1WEhWNWJLN2Z1OUtwZF9tQjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _жΗβΛΖΑЙΝΡШТыУЩ():
    value = 129429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H37DVnYz1fk7AiO75GCDDTE/3Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кчаЮбЖΜЪУνжЛδЙΛЮ():
    value = 897200
    text = __import__('base64').b64decode('R0toaWw1ZGpueXdOM0pOaVhoWTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨъСξγΝяггκвΞσΦΡ():
    if len('') > 0:
        _dead_9167 = 73
        pass
    value = 171667
    if len('') > 0:
        169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAO2RnQVxJEACFevm36pbAsI0Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΓМДОθжмлωγБ():
    value = 458310
    text = __import__('base64').b64decode('V1BrUlJHVFlPc1oyano3V3NUMmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ρниθфЩЙЫЭ():
    value = 843829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyfFWEI3wa8TLiGiw12pDTQL1zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬδШюлςΣдшОМ():
    value = 14102
    text = __import__('base64').b64decode('cWZwNlBvMGY4cDVxTEhncEtpZDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖζδрΑΗΑчПзπиΓюТН():
    value = 721725
    text = __import__('base64').b64decode('Q3JrdGUxQURRd3ZhMUc3RDMzMWU=').decode('utf-8')
    total = value + len(text)
    if 65 * 44 < 0:
        _dead_7285 = 209
        212
        635
    return total

def _ΟΛЖббχθμЪхδλ():
    value = 729702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR/jPlNtp/sgDB7w7n6IG3F7tU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8514 = 235
        933
    total = value + len(text)
    return total

def _υфΕБъюΜφи():
    value = 693051
    text = __import__('base64').b64decode('QkdqRkpNWm8yTDdrSENrSWJmU1o=').decode('utf-8')
    if 99 * 54 < 0:
        779
        pass
        848
    total = value + len(text)
    return total

def _ωНХЧАщЩυΔΓΖΧΙΛФ():
    value = 863655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQO1OGgb+qwnMDeC3Q6HMnwmvDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        227
        681
        315
    return total

def _ρζКЖабЯМοиЕ():
    value = 323553
    text = __import__('base64').b64decode('ejRHalFOUjg3RW1acnA0ajB0alI=').decode('utf-8')
    total = value + len(text)
    return total

def _ыЖэΙчеφςаеοЯбкрΩ():
    value = 629105
    if False and True:
        pass
        _dead_4820 = 225
    text = __import__('base64').b64decode('UFBaeDZLN3FPZFdHRlVOWk9fVlg=').decode('utf-8')
    total = value + len(text)
    if 64 * 94 < 0:
        _dead_2843 = 391
    return total

def _ΝβψсУвΜΞχАΙΙξ():
    value = 381482
    if False and True:
        342
        _dead_8098 = 855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjexdFsNxqopAFew7wWmYAIszH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        192
    total = value + len(text)
    if False and True:
        855
        pass
    return total

def _ΕΘЗэξαВΤςТ():
    if False and True:
        _dead_7090 = 712
    value = 989820
    text = __import__('base64').b64decode('Q3l1bXN3YVNmQnRhUzhfcEQyM0c=').decode('utf-8')
    if False and True:
        pass
        _dead_3854 = 139
        pass
    total = value + len(text)
    return total

def _ОΓκДΧСЩЕГΚδтΖΖВ():
    value = 963143
    text = __import__('base64').b64decode('dGF0MUFpd215eHZIemI4VFJBT2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩτΜζΗΑКпЩАПЧΦЩцα():
    value = 273302
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASr0VnYpp6VTHFzynG6BZxB+5jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3612 = 250
        805
        pass
    total = value + len(text)
    return total

def _ЪяΛЮκΥΦмЙШπъПΝХч():
    value = 286939
    if len('') > 0:
        pass
        pass
        696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FATgbQAozKIbFgmCnH+/O3B2wVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4369 = 880
        _dead_8832 = 938
    total = value + len(text)
    return total

def _схТОздΡΗЬЩυбΕг():
    value = 587093
    text = __import__('base64').b64decode('QXFETDRkMXB4UEdsQm16Mml0cnU=').decode('utf-8')
    total = value + len(text)
    return total

def _θцвзццΤббςλζ():
    value = 80076
    text = __import__('base64').b64decode('WXBCaERKNEV6RnZSbDR2MG1hYWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΓЮурσюУЦΨ():
    value = 903045
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHnlbFgcx6IUPTeVn1WyPHAC0EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3066 = 492
    return total

def _ΟμЭΛжεеЮхΛε():
    value = 208389
    if False and True:
        pass
        _dead_4355 = 915
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETX8eW4984UWFy6UxUalNw1+9ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        995
        _dead_3683 = 623
        542
    total = value + len(text)
    return total

def _БъЖρваюΠЕМνα():
    value = 300061
    text = __import__('base64').b64decode('Wlk2V0VTRVRYOHhxaGhsaUpYank=').decode('utf-8')
    if 64 * 72 < 0:
        _dead_3253 = 611
        pass
    total = value + len(text)
    return total

def _БтКξЯτΣЩНтυЧΩγМП():
    if len('') > 0:
        pass
    value = 227012
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxnPN0Yu5qY0Hz3y52OeYAQoszg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        70
        332
        _dead_5059 = 893
    total = value + len(text)
    return total

def _аБзШςβΕэαιтτцЕΥ():
    if False and True:
        302
        _dead_7127 = 167
    value = 247878
    text = __import__('base64').b64decode('REFIdk5rRF9UYUNqbXdlOXVQZzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦЛοоκхΝΑлэмДΤчЫЕ():
    value = 991247
    text = __import__('base64').b64decode('VThLb2tHSnpicDhWTGJqNVJSWHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭЕΗΘχЕЧΔΨяΥяо():
    value = 841815
    text = __import__('base64').b64decode('cUszZGFQUzVPOHZhUFBUSm9SejE=').decode('utf-8')
    total = value + len(text)
    return total

def _αλбΜΖΤЫТж():
    if len('') > 0:
        272
        775
        _dead_3216 = 672
    value = 658331
    text = __import__('base64').b64decode('ZVdXRTY3MXVmQmF4YkRZWnhSeTM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1092 = 910
    return total

def _цξчχιеХцЩ():
    value = 543115
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dy7tekQY8IIJKCuhzXOYDDQj70Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ьπΞуяΣΒшΞΗгΝρуЖН():
    value = 717522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT+3SVoA/bAIMwvykVOfMy4kyj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψнЪηΖлτлцсаΚПНн():
    value = 280499
    if len('') > 0:
        pass
        _dead_6140 = 306
        738
    text = __import__('base64').b64decode('U2hqeGlRV3o3SmYwRGhYNjJ0X1o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        791
        pass
        366
    return total

def _ΞШДΜвλоЙЪнЯ():
    value = 558806
    text = __import__('base64').b64decode('cThaU3k3ZUdtNEFQUWgyenF0cGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘшΟъΤиАщΔνΛбΔβ():
    value = 744191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECS3OHQtz/4sNieX0UCaOhMf7mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эЗЯБνΦЦΑТολЖλОΡ():
    value = 941178
    if len('') > 0:
        pass
        170
        _dead_9646 = 514
    text = __import__('base64').b64decode('QW1CVHNYdmlGT2Vfdk14ZGpYZ0k=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        362
    return total

def _жτΔΥΨΨстРΠθж():
    value = 365751
    if False and True:
        986
        _dead_9349 = 946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQ7wPWUWzqULMCSl5nCGGg4Z6TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψξщГΑгΟишπыξВьлК():
    value = 161151
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('ZWsxaW5vT0dQZFBfX1VlTWR1Zmc=').decode('utf-8')
    if 62 * 25 < 0:
        545
        _dead_6202 = 671
        pass
    total = value + len(text)
    return total

def _ξЪτшΟУπщнк():
    value = 981678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CR7yRUgP74lWLlaywXC6YgMht0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪХПσΑХИΕλдγНт():
    value = 987041
    text = __import__('base64').b64decode('VTkxcFRqalRDd0VZOXBoenFwTWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΨМрхΝуТхГЯ():
    value = 839213
    text = __import__('base64').b64decode('akF3MUNOU1VBUHNNTE5YeXN6b2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙчμτνσГТгΔШсЧλц():
    if len('') > 0:
        _dead_5190 = 813
        pass
        pass
    value = 102245
    text = __import__('base64').b64decode('eklOOUNZRktkSXVNYWpocW42MzY=').decode('utf-8')
    total = value + len(text)
    if 26 * 74 < 0:
        pass
        413
        pass
    return total

def _ЦζδГΣСχЕνωыЭЛ():
    value = 760634
    if len('') > 0:
        142
    text = __import__('base64').b64decode('VlpLblRzX1J4ZU9JbWF4WFZvSzM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        282
    return total

def _огРЗθЫρЙνηкΓ():
    value = 797419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyvcOFIDwZsyHVqTxnGfGw8OvWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λεЭπМгйНЮΥОΠΗΙ():
    value = 930915
    text = __import__('base64').b64decode('YVFSWG1xbFFjT21nb09WWUgzdzA=').decode('utf-8')
    total = value + len(text)
    return total

def _θΞЭРλФсС():
    value = 215582
    if len('') > 0:
        739
        129
    text = __import__('base64').b64decode('RlFnM19tc2JxUlRiaXJKYXRsV2k=').decode('utf-8')
    total = value + len(text)
    return total

def _фσΩΩыΤπФΘΟεЗ():
    if 71 * 62 < 0:
        219
    value = 445985
    text = __import__('base64').b64decode('SkF0emM4XzNyUThGU1B3WGVOYnk=').decode('utf-8')
    total = value + len(text)
    if 68 * 16 < 0:
        3
    return total

def _шβΚΧЦΡЬПΘκ():
    value = 421449
    if 89 * 73 < 0:
        pass
        pass
    text = __import__('base64').b64decode('dWRMVWoyRGViQlZCekM5WWVsWUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _хиΞтγεЪΕΤнхАК():
    value = 603108
    text = __import__('base64').b64decode('VjJEOE0za0NiX21VWFVKeEVLZ1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _КΤКЙμкΕКГΟФгΜЙ():
    value = 106117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiHubXwp0osgIxyqxFW5OxI41j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΨЧЭαЗΣпкνЯΣХлО():
    value = 406573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxDIewguro0QHiOy6nGBF3cm80s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΕΛЫξΡлЗ():
    value = 267268
    text = __import__('base64').b64decode('b0tyVHVURlV2S3RmbVFkdXZ5WGk=').decode('utf-8')
    total = value + len(text)
    return total

def _кΠΡГЫΧςЧΝЭЛЧЯБуυ():
    value = 176404
    text = __import__('base64').b64decode('ZHFObEJtd182U0dEZkZQRWwzQ3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ψаΩΩΜмЪχΜ():
    value = 875173
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('cjRBWGZra1JjQ1dGTmprWDN2Ulc=').decode('utf-8')
    if len('') > 0:
        _dead_4648 = 643
        _dead_7831 = 150
    total = value + len(text)
    return total

def _ΧГδΒЫΚИоЙγΒяυ():
    value = 693850
    text = __import__('base64').b64decode('S1hKTHNha1l0a0NuS3dsNDVNczA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        779
        _dead_3165 = 717
    return total

def _ЫСядδбΤеφΨЖχ():
    value = 956539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESrTOUsS0Y4VBVm0kHWyGBEn4k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠвХωКзВЦъиХΑηмΡ():
    value = 45411
    if False and True:
        pass
        161
        pass
    text = __import__('base64').b64decode('c09OOUFndTZwdXZjaEFQSDFrOE8=').decode('utf-8')
    if 82 * 78 < 0:
        _dead_8632 = 542
        251
        _dead_7643 = 576
    total = value + len(text)
    return total

def _ΔσъбΝжЙΓζгΥьΡУчо():
    value = 242116
    text = __import__('base64').b64decode('RHZTbGJVeFgwYm0xOEpyN0E2QXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΞкцпюрΟЪηояηХ():
    value = 757691
    text = __import__('base64').b64decode('UEFsNTR2dlBYc1MxZjBQdjlINkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΦψσЕщнзΥомκШωЛς():
    value = 658623
    if False and True:
        _dead_9233 = 812
        636
        85
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej/Se0kh7aEEaFqywV+xIHY5yTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΘξΙΘκже():
    if len('') > 0:
        _dead_6069 = 48
        417
    value = 625809
    text = __import__('base64').b64decode('V3V5V0djMEJMcnJMM1RRUnU4cEE=').decode('utf-8')
    total = value + len(text)
    return total

def _οЯΑоΤвзΨηФсДΖτ():
    if 14 * 14 < 0:
        pass
        194
    value = 624283
    text = __import__('base64').b64decode('clRGSDBvTUQ5SnBmZWdaMldadHc=').decode('utf-8')
    total = value + len(text)
    if 58 * 35 < 0:
        _dead_2996 = 0
        _dead_1407 = 55
        pass
    return total

def _ΠεθΜИяЛАДя():
    value = 66829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQG2SFY2po0vFRqL2WKbPSA8/jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χЫэωЧНеΞЛΒ():
    value = 635828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHr9S1cM9b4AYyjxwgfGbQA88Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΥЕςΒеΝΠΒΙб():
    if len('') > 0:
        _dead_8145 = 603
    value = 723452
    if False and True:
        291
        _dead_5636 = 83
        _dead_1048 = 673
    text = __import__('base64').b64decode('bFFIRWlBUk1ST3pfYk5wNTk0MEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЗφΖΥΥφдгω():
    value = 20917
    text = __import__('base64').b64decode('TFd3clNSRmg0cjRyYm81OVNTR0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЧАξΞЩσπΗаЧλчΘΗ():
    value = 774205
    text = __import__('base64').b64decode('eFFDS05LVHJ1Q19Qc2R4c0U5bW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒИΧΔшηКяΥЕ():
    if False and True:
        pass
        _dead_6722 = 471
    value = 949714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In7gQnk83ZkbbCCxkQeJPR8tzHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮЦξΕзτУγЛ():
    if False and True:
        pass
        pass
    value = 134949
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhzhN0EXx6oaNgGE92fHMScQ7UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7695 = 37
        28
    return total

def _οШςΗькμραчΗ():
    value = 160712
    if 14 * 33 < 0:
        _dead_1260 = 649
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NibpY3kS7aMRMCeG22ydNzQNtHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΕйνЦФЭЪψдчПσ():
    value = 190856
    text = __import__('base64').b64decode('dzRZTFlPelh3OXRLTG9ITnhQaHk=').decode('utf-8')
    total = value + len(text)
    return total

def _оλГйЩчХΞшЮΗΩыΕ():
    value = 208744
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgjtXgMS8JAgHiyv72afDQ4pw3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3193 = 701
        _dead_5263 = 925
        243
    return total

def _юХΓЗΓюКς():
    value = 605277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDbzZnM6zaE6BT6o/1iBMiYD8UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЦпГΠΠσКЭΩУιζψ():
    if False and True:
        pass
        112
    value = 606942
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FH33PgA6rZAwCSaC4EWhETEf3Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        279
        651
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΤБФΠГэгзα():
    value = 65132
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NA72OV4x/bIzGxauygehOi927To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΝΑΙЪЯЮΜОνΩ():
    value = 763849
    if 83 * 16 < 0:
        746
        pass
        405
    text = __import__('base64').b64decode('aFphYkRHdVdJeFlUY0pJT09DcXY=').decode('utf-8')
    if 98 * 33 < 0:
        848
        _dead_9221 = 641
        pass
    total = value + len(text)
    if False and True:
        pass
        350
        _dead_5981 = 652
    return total

def _СτιдСφΝжП():
    value = 912280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRC2fAls5IAhGS2Hx36JZwd/4Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 80 * 23 < 0:
        _dead_8602 = 624
        405
    return total

def _хΕαАнзΨΟψгΘφΣΑ():
    if False and True:
        _dead_9866 = 731
        _dead_7080 = 140
        pass
    value = 255642
    if len('') > 0:
        _dead_2902 = 74
        pass
    text = __import__('base64').b64decode('TUpCMUxtb1pyS1Z1N1NVU1Q3cVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ХЮУΖЮйГιΕΨШВκЪВ():
    value = 526358
    text = __import__('base64').b64decode('bGJmODNFSkN0MzhpTHJtVkxJY2U=').decode('utf-8')
    total = value + len(text)
    return total

def _БОαаπнаЬζδ():
    value = 958206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTbHSEEXxpIULhWinVuAMDA1ykI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3747 = 968
        _dead_9703 = 328
    total = value + len(text)
    if 85 * 11 < 0:
        _dead_6070 = 835
    return total

def _δеκυπςйЧ():
    value = 34549
    text = __import__('base64').b64decode('eDBlc0o4U1Zma1pNdzhfa2xreHA=').decode('utf-8')
    total = value + len(text)
    return total

def _БянЕπΙШζ():
    value = 441506
    text = __import__('base64').b64decode('YU9kZjNLbEM3emIzczdlQVFWVGY=').decode('utf-8')
    total = value + len(text)
    return total

def _оδΤψΦфОсЩ():
    value = 366659
    text = __import__('base64').b64decode('SnY2U21rY0Q4T0tqdFdBYUQwbEc=').decode('utf-8')
    total = value + len(text)
    return total

def _γκХЦХχФΘЪ():
    if 11 * 60 < 0:
        296
        pass
        167
    value = 152523
    text = __import__('base64').b64decode('b01MNWlNZ2R0RW9lS0N5aEFEZmo=').decode('utf-8')
    total = value + len(text)
    return total

def _УзκднШφΔИ():
    value = 932778
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDbCVn449b0MAlqq+lK0NwIl/FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 17 < 0:
        142
        _dead_4471 = 441
    total = value + len(text)
    return total

def _гФΓΞΟБЖв():
    value = 960045
    text = __import__('base64').b64decode('Q3pwb3dESFB0TnJ1bmlFVWlvM0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ввΧВλГшЮВΧ():
    value = 831570
    text = __import__('base64').b64decode('RFNJd2RlWWNoVU5ndXFHSTF1ZzM=').decode('utf-8')
    total = value + len(text)
    return total

def _эЮЭйТЯфкΙЛιΜ():
    value = 965883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRm2W1w6r4kEMD22/majJ3AfzGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΙΘйΥоΤγΤфΙйΧкω():
    value = 533811
    if 99 * 12 < 0:
        415
        873
        885
    text = __import__('base64').b64decode('UDhXZG80SWlYd2dQckxxd01VYm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗαΕЧПςΤкαхθ():
    value = 304154
    text = __import__('base64').b64decode('VHZOeHhKYzh0UWhQY2FSZTJ2MHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΡЫΓνмкχνЭЯ():
    value = 293731
    text = __import__('base64').b64decode('S2g1VklfQTlYOG9sYnI3bEVNRGM=').decode('utf-8')
    if len('') > 0:
        _dead_1916 = 274
        395
    total = value + len(text)
    return total

def _ЕкΔрЭΟйоМιс():
    value = 140972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiuyZGcg5/AKPh+v/0aDEw1+8z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΝΚΕΖяыЬζ():
    value = 632212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwzOOwc/7J8xKyCTz2+8BxA81HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦщΡХьпкНющЯФуΩп():
    value = 67565
    text = __import__('base64').b64decode('WTFUeEpaTTU2MUFuZkVlbWZyTFI=').decode('utf-8')
    total = value + len(text)
    return total

def _шСνЪЖвΘъΖФСиΕщβ():
    value = 423843
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXn2ZF4w2p0VD16y2FC8Excsw2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δСкчИΞзφχ():
    if False and True:
        pass
        pass
    value = 627673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz3LS2cY9/wtO1mG8EapZj0rvUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 84 * 97 < 0:
        pass
        _dead_7803 = 710
        _dead_8952 = 89
    return total

def _ЕΓκоаЗδэЪчыυДЯО():
    value = 146218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3nmeWkj/IsZPxev43C3BB0ZtE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εмΗАψАΠЪ():
    value = 396541
    if len('') > 0:
        _dead_3055 = 636
        _dead_3107 = 343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjW0Oghu8YkFFz6OnlS2BncVt2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2107 = 373
        182
    total = value + len(text)
    if False and True:
        487
        pass
        pass
    return total

def _ъΣΛЙБςэыΒщσχυОбУ():
    value = 711040
    if False and True:
        _dead_8926 = 573
        165
    text = __import__('base64').b64decode('bGhONmhSUV8xZXB1X0RQeFFOTUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕγπяΡπШЩудЙнГΠУЫ():
    if False and True:
        pass
        pass
        pass
    value = 375693
    text = __import__('base64').b64decode('ZklGeUdORFhNb0F4MVg4REdOX3Q=').decode('utf-8')
    if len('') > 0:
        790
        _dead_3440 = 593
        pass
    total = value + len(text)
    return total

def _ПΝУανЩΚδφчΟθεχк():
    value = 383293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mjz1WGUq0KM2MzehmVLCHnwdvW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΘвЖΦΡΧΙЯуΘаχСж():
    value = 781731
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRXQPVJu5JIHKAfwwVqxZyMrt08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чХΒЧθΡШвЭαγ():
    value = 280468
    text = __import__('base64').b64decode('eXNtY1NtaGQ3dkZWUVhYU1Ywdzc=').decode('utf-8')
    total = value + len(text)
    return total

def _αψШгΘΖНыъρкφ():
    value = 95129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JirSW0Mx7KcnGS2l2HPCIH0GvVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        39
        pass
    return total

def _ВЪъТΝпАψ():
    value = 477723
    text = __import__('base64').b64decode('S0EyOTZfWFQ4RVdfeXQ4bWVVRWw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _цуΙЗйΜЩЮюЗнΟУЮΕ():
    value = 106503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxDBRX4Y/b07OyST63G1Mggl238='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςйЖΓщЬжΧ():
    if 3 * 71 < 0:
        _dead_3630 = 535
        677
        pass
    value = 550228
    text = __import__('base64').b64decode('ZzNFTm5sWjFNanYxY0FQemlmNEg=').decode('utf-8')
    total = value + len(text)
    if 70 * 62 < 0:
        pass
        pass
        935
    return total

def _ЕφЖΞоμЧξ():
    value = 874281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQjiXVwDy6oXPgSuxVvADDwc/lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЦЕφΖΑъбμ():
    if False and True:
        _dead_6586 = 145
        433
    value = 828794
    text = __import__('base64').b64decode('eG1idTF6SFZwdVMyR3ZyOUNuTEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _φνδΚζВЪуΟвΤφэΔ():
    value = 411272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzjFYwFsp6MnHT6F5U6nMzV292I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9977 = 282
        645
        pass
    return total

def _рπИοЯυРκΗД():
    if len('') > 0:
        pass
        _dead_1649 = 120
        461
    value = 630175
    text = __import__('base64').b64decode('Z2xIb1BIdEFaQ1ZBUkFScDlvRXA=').decode('utf-8')
    if False and True:
        pass
        717
    total = value + len(text)
    return total

def _зΠΥμЭвΣЬνΒ():
    value = 577429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyTFPFMy2qAxHCWC60agIzUh5kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1151 = 20
        pass
        306
    total = value + len(text)
    if 67 * 71 < 0:
        pass
        pass
    return total

def _РПδОЦΦмΦыдιΟΜΧλъ():
    value = 378340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhXQfQcG9LBbHSKG/EW+ORMe13c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_5359 = 893
        _dead_9357 = 983
    total = value + len(text)
    if False and True:
        _dead_8399 = 815
        _dead_2976 = 835
    return total

def _ЕХδЖеДΣЮΒδЙεζъЦ():
    value = 664187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSHuflsp2rEaHwmo0gSJG3wO5z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юθВΜтГжα():
    value = 68502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS3eanM97/AvHSybxGafLRoK3kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уχφбΧвΘзУΠПΜλАΜ():
    value = 995957
    text = __import__('base64').b64decode('UHdrZ1NhQzFxcmpKNEpIcFJfWEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ψДаΙΓκрьФШВΕ():
    value = 644581
    text = __import__('base64').b64decode('VFpmeTVYeUxrc01jUDhGVVlHSGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ВчРчХгОдРоΘφ():
    value = 445461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS6xels9+ZEBNzDxmAaFMnMD6X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΨθШЗкЙРοΣБТуλ():
    value = 919998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwreN1IPwb8pY1uN/wS9LjIl82o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λМгρΛνЯψμПоΙшΡ():
    if False and True:
        748
        70
        pass
    value = 168668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTa8encc/bELMSau/nmzLHUZ/k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙНΙдМΨяΙ():
    if len('') > 0:
        _dead_7496 = 692
        _dead_5819 = 936
        91
    value = 253680
    text = __import__('base64').b64decode('T0h1TW0xWWhkX044a2ZTS0FqSXY=').decode('utf-8')
    total = value + len(text)
    return total

def _тЗйΩβцΥНшηцжнЕ():
    if len('') > 0:
        _dead_2180 = 292
        579
        pass
    value = 888014
    text = __import__('base64').b64decode('dFRVYk1BRFhRSUNlWWdES29rRUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤжСылДЖнιтΝτΚλП():
    if len('') > 0:
        pass
    value = 850125
    if False and True:
        49
        _dead_1871 = 177
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyXUOFMdzLhRNgac2FKYM3Eq0Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_3621 = 809
    return total

def _ЧπНаΔьΚΤН():
    value = 5302
    text = __import__('base64').b64decode('SE9RelFScnh2ZzRhM2R6WFI3a3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ШяΣυаΩДρьбуЫа():
    value = 334638
    text = __import__('base64').b64decode('UXNWVU9KZmZucG1GdEdGdHNrYkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ρгЗΖтЭтΗЫяВЛ():
    value = 920330
    text = __import__('base64').b64decode('TjY1Ym9SWmZyOVp4ZWFUTngxNk8=').decode('utf-8')
    if 67 * 26 < 0:
        376
        _dead_7268 = 596
        pass
    total = value + len(text)
    return total

def _ЪВΒЩγьιЭΛ():
    value = 262360
    text = __import__('base64').b64decode('RmJ2RHFYQklQYm8xUmRsdF9wb3I=').decode('utf-8')
    total = value + len(text)
    return total

def _щηщΛξыΒН():
    value = 660862
    text = __import__('base64').b64decode('TFdBbFRwMlNUZWRaQlY4NVhHaHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΒГΙΝΡΦιоЖыцф():
    value = 647140
    if len('') > 0:
        869
        _dead_3190 = 438
        366
    text = __import__('base64').b64decode('ZXR6XzdtanM5a2dZTFp1TWtQTnM=').decode('utf-8')
    total = value + len(text)
    return total

def _οбυΥρСΨЕЬЫ():
    value = 256831
    if len('') > 0:
        _dead_8100 = 957
        _dead_1181 = 695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH33Q1Y96JgPGB2q2WeWIhQE81g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НчмШΣУэШЗξ():
    value = 941455
    text = __import__('base64').b64decode('WTdja0p4RjNJNm55YVlIUzBaX3U=').decode('utf-8')
    total = value + len(text)
    return total

def _юΠБΛλГСЯТн():
    value = 262002
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxjHQ3ch+4tTOC2tznu9MgQI1EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТУшιΟΩХж():
    value = 883493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhzQWEcAz4YoCTqP3ATEHAl6zUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИЕЦαНнЯеταАч():
    if 8 * 89 < 0:
        pass
        _dead_4540 = 417
        _dead_7997 = 782
    value = 291783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjreOWkxy6AhFif3wXKAGSwowGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 13 * 5 < 0:
        _dead_5041 = 178
        pass
    return total

def _ΝвΙΜБΣЬяфЦФкΦυиπ():
    value = 661440
    if 27 * 98 < 0:
        _dead_4792 = 445
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Diz3X1M97rsVKD3x432BMSg641E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        938
    total = value + len(text)
    return total

def _ИТрθЩщьН():
    value = 74676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQ7UNwMYyrsZLi3w+lmHEyZ26jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 91 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΜεНЧиСοδНсйзЯς():
    if 27 * 65 < 0:
        447
        _dead_9115 = 884
    value = 608848
    text = __import__('base64').b64decode('bjVBUFdRNnpsYVFwUm9TakFPQ2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠХθБДΕпЯ():
    if False and True:
        pass
        669
        _dead_2517 = 891
    value = 194191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCvLSGcS/J8oLg2y7mmiPDEEzUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЙκΞτНБοдθΩшМσ():
    value = 320005
    text = __import__('base64').b64decode('ZklGRHZlYTFTUjdNWE54V3RCYnE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΚСντΦΨИпФβ():
    value = 668369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTvgSwchzYUrCB+Px1GSDnw43Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΛΙΣцьεТαιΨεиСΝ():
    value = 426251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCXlQHYb9pAzazyV3wTFOyB48WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мνλьЙΝКΟЙεΒДφ():
    value = 376961
    text = __import__('base64').b64decode('ZGJPZE1lb2hrMmtkamJmMnFfVHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝλжлΝЭыζпФΞЧйФФ():
    value = 324474
    text = __import__('base64').b64decode('VThCaFFxb2M0TzAwZDFzcGpTX1k=').decode('utf-8')
    if len('') > 0:
        _dead_3253 = 330
    total = value + len(text)
    return total

def _ρиэЫπγйжξШ():
    if 65 * 14 < 0:
        pass
        4
    value = 483156
    text = __import__('base64').b64decode('ZE5Qc004Ujl5Y2U1YmFuSE52NWQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        620
        pass
        _dead_5149 = 47
    return total

def _жΩμЛЬздО():
    value = 927745
    if len('') > 0:
        978
    text = __import__('base64').b64decode('eEE5dmxJMTJHU1JzNm1ha1lDX1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЗЗУΕхИκАКП():
    value = 585263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dhvzd2UP3aosEgiVzAWxYCk3zFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        517
    return total

def _РΧΛКЦЛΓРΞ():
    value = 344532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnjLd2MS1asQaDqI6kSbYDMqxmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤμпПΦВЮШВоАщ():
    value = 876763
    text = __import__('base64').b64decode('WjhEVDdZYjFLQjhDUTRFcDlmQ3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖκсβΛΙφжнЫчγшΩΝο():
    value = 932898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQDKVEQbzY4pOzaA8AGmORwt3n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩισООзΥΓКфΔΜβЫΤξ():
    if False and True:
        894
        pass
    value = 790377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KifzSAVs/LEpKzuv7XqIAxIg5Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξιΧςыπюГо():
    value = 260194
    text = __import__('base64').b64decode('Vmh3dld1Sm5BS1BwZmhEbDNlVWo=').decode('utf-8')
    total = value + len(text)
    return total

def _λТрΙКПΙхΔР():
    value = 662832
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDW9T2cOqZoWMlyS2lC5EBcp1ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΥΟаОκψι():
    value = 483614
    text = __import__('base64').b64decode('TDVZbUNqRmlEeTQ2U1JMNnZpcEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣωптШППЦσжΡцΛ():
    value = 5229
    text = __import__('base64').b64decode('dUdKTDlNMW93MUt3M0tyTm43Z2s=').decode('utf-8')
    if False and True:
        385
        529
        _dead_5591 = 997
    total = value + len(text)
    return total

def _λюяΚΕΗНδτ():
    if len('') > 0:
        _dead_5285 = 838
    value = 602487
    text = __import__('base64').b64decode('aWRQVnh4MWw2R0U3RUpqZklQSGk=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4876 = 302
        pass
    total = value + len(text)
    return total

def _ΥΣνчδζразНф():
    if 56 * 83 < 0:
        pass
        145
        pass
    value = 400898
    text = __import__('base64').b64decode('dmtmcDAyakVjMjZHZzJ6c3pTaHQ=').decode('utf-8')
    if False and True:
        _dead_7878 = 65
        pass
    total = value + len(text)
    return total

def _шφΙκφΔоОМкЙЫ():
    value = 838464
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyPwYkEv7roMLCWlznClPhEuw1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2584 = 688
    return total

def _лΧЪΖеΓΘПмСЗΔΠлдο():
    value = 158194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjnVSkhqrLIKNFa7zAaxJxYQ7Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 61 * 88 < 0:
        pass
    return total

def _ПΤυэАСρσΕХΔъЮх():
    value = 511372
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiDmRFIexKkMag6K8Ea/bSs+0Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йνЧЩЙУныνωωφЕ():
    value = 740798
    if False and True:
        _dead_4826 = 932
    text = __import__('base64').b64decode('cnQ3bWJYQjY2QXEwcnQzbU9TZkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔβЛОΖοΙуΞΓγξ():
    if len('') > 0:
        _dead_6661 = 284
        _dead_7286 = 652
    value = 194231
    if len('') > 0:
        _dead_8198 = 693
        pass
    text = __import__('base64').b64decode('RGE1SlN4Y3lhZ3htZVpKdzI5ZlE=').decode('utf-8')
    total = value + len(text)
    if 50 * 13 < 0:
        90
        _dead_8195 = 9
        _dead_2068 = 886
    return total

def _юыджΟсνσΤΦ():
    value = 277714
    text = __import__('base64').b64decode('TFRPTGo2ZlhHM3hjWWw4aGl0SW4=').decode('utf-8')
    if 64 * 57 < 0:
        877
        202
        _dead_7547 = 147
    total = value + len(text)
    return total

def _фχдюδΘφуκμχ():
    value = 37907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KznxeVUarK0wLAu1/FS6OnMrvVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЛЩбЯнцяΟмх():
    value = 973018
    if len('') > 0:
        804
        _dead_5777 = 190
        93
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3jFXVQRzvAWEwWK4Wa6GjUf51s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2884 = 703
        695
        _dead_8883 = 524
    total = value + len(text)
    return total

def _БГяλυьзлΜшт():
    value = 596690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQjQO1YrzqkZKCG5wwWnHSooz0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 95 * 98 < 0:
        912
        74
        pass
    total = value + len(text)
    return total

def _ξΕхμΨΓьθΜНηчЗ():
    value = 689251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nyq0XHU76v00LgCkwUfCJjw7tGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΙμΑμХОγ():
    value = 286697
    text = __import__('base64').b64decode('dVVSZTVxUE5ORXNiVlc2dkhFZko=').decode('utf-8')
    if False and True:
        pass
        567
    total = value + len(text)
    return total

def _ДрσЫяΝрωЦС():
    value = 863519
    if 96 * 47 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSPBRkNv6fAVHwy20GWmJBp/w34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΕΞЧкжМьΧ():
    value = 256336
    text = __import__('base64').b64decode('R004M25TbHhud2lDMlBNODBsbG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖмЯκШТюχ():
    value = 572410
    text = __import__('base64').b64decode('anNwSHN2VHlFUjVxZEFfSGNuQzM=').decode('utf-8')
    total = value + len(text)
    return total

def _улырКЛЯφκяεΖгΤл():
    value = 760802
    text = __import__('base64').b64decode('YW1abnY0NDFIQktzdVB4N2NUVko=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6792 = 625
    return total

def _λφрсΕЩψфΛΜЭъЖ():
    value = 165912
    if len('') > 0:
        26
        741
        203
    text = __import__('base64').b64decode('T0FyYVFvZDZmTHMzSVYwOENmbGc=').decode('utf-8')
    if 16 * 56 < 0:
        _dead_4451 = 952
        _dead_5891 = 395
        _dead_9469 = 652
    total = value + len(text)
    if 52 * 50 < 0:
        _dead_9501 = 184
    return total

def _ΙΩιлхεйΖОυжιςНΦС():
    value = 19739
    text = __import__('base64').b64decode('dTBYRTMxZF9JZzV0eXdCMmZkdVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΖДюТΕлЮщю():
    value = 456134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj39PGM6qYMNKDC52mG0IA8L820='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _афΨΞδШΜΩΡчйПе():
    value = 735935
    if False and True:
        pass
        _dead_3260 = 424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiPpbHMg8qwWPSiG7ACJMAZ7sFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        538
    total = value + len(text)
    if False and True:
        612
    return total

def _фДЧъπтэлЧкЗРρΛΟй():
    value = 787983
    text = __import__('base64').b64decode('d3BsUndhN1UyTFhrYkszYzdYRGo=').decode('utf-8')
    if len('') > 0:
        _dead_5373 = 115
        pass
        _dead_8440 = 562
    total = value + len(text)
    if 10 * 58 < 0:
        _dead_7151 = 477
        617
        pass
    return total

def _εЪπЙΨξнЗνЕ():
    value = 753374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByO3OgUg7YkyNTiLylq1ZioW81Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        362
        pass
        pass
    total = value + len(text)
    return total

def _кВτΖЬВИОИΚβΙ():
    value = 33117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgjmW3gawZAKLFiswQWxICwo0Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭАχξχПτЗУнъΝΣиш():
    if 65 * 73 < 0:
        936
    value = 733769
    text = __import__('base64').b64decode('cE9HUm4wUXRRdTgzX1NLbHZQTlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ияκΙζЫМΙОГРйψΝ():
    value = 637038
    text = __import__('base64').b64decode('SUpGSGF6SFVnWXlPaHVvQkpZOVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('IA==').decode('utf-8'))
if 94 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()