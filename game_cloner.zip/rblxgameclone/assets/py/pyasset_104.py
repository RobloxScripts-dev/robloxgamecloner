#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _уРΘΣЫΓпнΨЮ():
    value = 459327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARr0emkG85oANQq7zFyjLnIpz2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6711 = 111
        _dead_8934 = 351
    total = value + len(text)
    return total

def _ΝπΣΙΛфοθΞ():
    value = 588289
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR20SG4f05sSal2K/2CKYgkmy2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        841
        _dead_5287 = 391
    total = value + len(text)
    return total

def _λΥξгАьЮΟΒсδтζц():
    value = 933417
    if len('') > 0:
        _dead_9391 = 205
    text = __import__('base64').b64decode('T0ZibUFLUlJWVFRWSUxuUEMzVlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΕЬычδΕнΘЬυшЯцВ():
    value = 698734
    text = __import__('base64').b64decode('ZWFCd2ZqM0dKNTV6Y1pFRjdpRzE=').decode('utf-8')
    total = value + len(text)
    return total

def _σςжМΕλΧВКΥэχπд():
    value = 595591
    text = __import__('base64').b64decode('ZXVqS3NSN09CazE4QUlIVmR6MVc=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _χυврфμаΝθξΨХ():
    value = 893762
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjvQOWtqq7kmbQOVnnmkPCIDvTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σμΓΤΜυΚЗξυкФΡβ():
    value = 786663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAfnZGUerYo5IimKxFjEZ3d9tX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρωБγШΓαχТхИЭ():
    value = 979475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An/CVgYI/J03MgHy8A/HOXEW1zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΩμЯцδВΟтфψе():
    value = 178082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgjrZ1Ae76I7Ajqm3meXJQsG6lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щιшцвХωЭкАНп():
    value = 577791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyTedGJv8KE7Ai2W3VSILX07wG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 43 < 0:
        _dead_9979 = 825
    total = value + len(text)
    return total

def _сΚζωбχСЙЫТюЛеГΟ():
    value = 92845
    text = __import__('base64').b64decode('UE40Q3ZfRW9ZRTdVNHNfSmhSQXk=').decode('utf-8')
    total = value + len(text)
    if 73 * 30 < 0:
        pass
    return total

def _ΑΡРπШΦЯйνШ():
    if 50 * 50 < 0:
        pass
        896
    value = 707969
    text = __import__('base64').b64decode('RVRlaGFzc1JrVFNMQ3RRQUpCbUU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8338 = 933
        _dead_8664 = 189
        348
    return total

def _ЭψтЖΠЖκцΛвг():
    value = 822164
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxfQV304+YFRbCi30XK3ETcp5Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        760
        _dead_6038 = 142
    total = value + len(text)
    return total

def _лКтраСфΧοΦ():
    if False and True:
        _dead_4878 = 553
    value = 993672
    if len('') > 0:
        605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzvVdGkS7oEuMBa5nkGaHjwt/E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΤζΨΟИщΨнКЯαкДοП():
    if 56 * 72 < 0:
        pass
    value = 849615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyXMeHhh5K0WBVip3n7CNyAh3mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        141
        pass
    return total

def _ιΣфιΘВЮэМшΣΙΘΩРю():
    if 73 * 83 < 0:
        pass
    value = 972485
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3zBfm4K0aIqLiWkzXzHHBor1no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нрςАζβЙπОР():
    value = 382736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgX3Q3wGxK8HNgmAwwXFNxAb8m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 89 * 56 < 0:
        pass
    total = value + len(text)
    return total

def _ΗТМωΤлЦУф():
    if False and True:
        _dead_3368 = 937
    value = 335523
    text = __import__('base64').b64decode('a3o2TG9yTUNPWGx3enlPWGZ3Z2w=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_8769 = 728
        pass
        _dead_7553 = 443
    return total

def _ЙΣβαμΠхЮЗюμэτз():
    value = 89112
    text = __import__('base64').b64decode('cmFfY09yTV9pM0lkc084b20xcHQ=').decode('utf-8')
    if 78 * 64 < 0:
        973
        _dead_3098 = 665
    total = value + len(text)
    if False and True:
        551
        _dead_1906 = 765
    return total

def _ωЪЩιОεΒюλΓνΑПЩ():
    value = 230426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAK2VHxozpcbP160432qIHcl/Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВэφьгЮмηΔΕЗΜΡυΔЭ():
    if 11 * 27 < 0:
        930
    value = 695587
    if False and True:
        _dead_1153 = 851
        pass
        _dead_4049 = 723
    text = __import__('base64').b64decode('UmhCSUZiZGt3VDFSZUVNcElrd3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩшцυΣΧβγ():
    value = 372211
    if len('') > 0:
        _dead_7893 = 215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjrzR2Ej9r4AMT2hznubDgwk9UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        585
        pass
        606
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _щрфЦηВкПлцШЬΛΧ():
    value = 934462
    text = __import__('base64').b64decode('TWkzb2RteVFQVU5aQmRWTlNaX1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _еПφΝЛзмсιχ():
    value = 87536
    if len('') > 0:
        _dead_5803 = 793
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix3AeQUp/JEtLSz17XG+JwAEzHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9526 = 918
        715
    total = value + len(text)
    return total

def _жсгШΚτуОЪ():
    value = 836207
    text = __import__('base64').b64decode('SE84dnNmN3pfbFZwSllVVURWblY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝЗБвΝбζЪοНκ():
    value = 801848
    text = __import__('base64').b64decode('YklDa255ZVJ6TVdoVHhnTk1ZZ3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЧжυΗΕΓпτ():
    value = 351584
    if 76 * 43 < 0:
        pass
        _dead_7719 = 142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXv8QV0614A1NjuxzHy0LT066WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        661
    total = value + len(text)
    return total

def _ΝлπтЖЯιЪΜпффςц():
    value = 730126
    if False and True:
        585
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwHNOEkqyr0Falqg8Wm6GAl/3l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩрΡχΤлλъΨНΤытлфΔ():
    value = 991157
    text = __import__('base64').b64decode('aGhIYjU5T3BORHVjRWRNZUlLUDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΨγАηфιъυхФтΔΤΡЙ():
    if False and True:
        _dead_7033 = 602
        387
        573
    value = 225140
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSHJRX4vzb9bCxb16W6vEQ8Lz2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 8 * 40 < 0:
        pass
        pass
        991
    return total

def _ΔηЫυгνζбХΖροι():
    value = 546558
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRrrX0MO/7AuHBm2ngWyAhwd8Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЫχΕτμγе():
    value = 279131
    if len('') > 0:
        _dead_8404 = 444
        _dead_7076 = 358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjfTaQIh8aoGOSqhxlDIJwM44mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪнМβηИьΩΥЯΚВΖрЭЕ():
    value = 941603
    if 1 * 26 < 0:
        pass
        _dead_1456 = 437
        pass
    text = __import__('base64').b64decode('dV9mRGk1M05zMm9rSWQ2Rmo4NlU=').decode('utf-8')
    total = value + len(text)
    return total

def _мτЭΣщШαΡЮμГ():
    if 81 * 32 < 0:
        _dead_8584 = 113
        579
        _dead_5425 = 299
    value = 197894
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjrsWnsY/48oOQv23w+GOgMgxj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖвββьДΥκΖШΡΔц():
    value = 415933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSCyYkEeqaIJHV2a51CXIQctxmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        766
    return total

def _уΤΕΒЩюфηνслΑ():
    if False and True:
        pass
        906
        667
    value = 161638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDzrVwIh/PoECSv0/nKjMn0V4VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αмΑπΟΚщЪΖФλΘ():
    value = 622385
    text = __import__('base64').b64decode('c183bXFkaThEcnNlTll5R2VaQmo=').decode('utf-8')
    if 40 * 13 < 0:
        _dead_4358 = 948
    total = value + len(text)
    if 12 * 81 < 0:
        716
    return total

def _ςΘншЬλЮΦΩЮдЪσ():
    value = 399600
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHzVSXpqpooODSis6lKJHXYdwGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 58 < 0:
        515
    total = value + len(text)
    return total

def _ЪиТлпΝθΟ():
    if len('') > 0:
        _dead_6624 = 279
        pass
    value = 456091
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAbXVlYIzK0vN1+U3WmmBwM24H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓρоΓηκРз():
    if 38 * 89 < 0:
        142
    value = 653709
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSK1O2cd/Yc5aySG42zBYXcht2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3372 = 13
        _dead_7133 = 949
        _dead_5310 = 552
    return total

def _ъΗЭЬоΞУδыκΛу():
    value = 31497
    if False and True:
        137
        _dead_4820 = 979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hzr8WGFu/bg8BV+lmWfIbH050Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6921 = 944
        _dead_6309 = 747
        pass
    return total

def _УжбрбВЭБеΞΑЕΚСΒ():
    value = 765888
    text = __import__('base64').b64decode('UE5BX1R3ckNXTXNXWGhLdkc1R0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ωхяΝιлвтΣдыФ():
    value = 32595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSjdWWQX66MMKxyznnDEYHEE4k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΧбюΙΕΣγςкрСОйΒΣ():
    value = 992697
    if False and True:
        _dead_3603 = 429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD3gWUEV5JwPIAP3kFq9AhUN1kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΚιΘщвУφоκΥ():
    value = 598324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAPTf3Ye96YGACKs2gKxICgJ138='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΞЕЗΣКΖΗΨθ():
    if len('') > 0:
        _dead_3895 = 705
    value = 339414
    if len('') > 0:
        832
        _dead_3475 = 728
        _dead_6315 = 299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgfXW2Nr0IQ7DDyknmDCYgYYt00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        203
    total = value + len(text)
    return total

def _ΡδрЯюТаΜЫФэм():
    value = 403843
    if 16 * 81 < 0:
        _dead_6156 = 106
    text = __import__('base64').b64decode('bWt4UnlnRVpyWFkyUEg0RnBjSXg=').decode('utf-8')
    if False and True:
        596
        952
    total = value + len(text)
    if len('') > 0:
        _dead_1899 = 490
        pass
    return total

def _уьηкψΑΠΚаνс():
    if False and True:
        549
        pass
        77
    value = 793786
    if False and True:
        512
        568
    text = __import__('base64').b64decode('YnlNRl9VdUtZUGFxUXR6R05Hdkc=').decode('utf-8')
    if 3 * 36 < 0:
        284
        333
        614
    total = value + len(text)
    return total

def _мпΙρОДνи():
    if 72 * 93 < 0:
        _dead_3426 = 856
        pass
        482
    value = 162861
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECfKSGc21qoyLwiK+2LFFSQ7/kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αНηЙУАΧΜНσοеΞаπн():
    if 38 * 84 < 0:
        pass
    value = 180022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kgz+fkEUwZcmLyy00FTGDgkdxmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ηΧшξΖпΧсгνЯиΛχТд():
    value = 49993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji30SHwg2/oPDiyP4XqyNT8VwmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гЯΚΧгοιΘЧω():
    value = 836752
    if False and True:
        _dead_4009 = 502
        _dead_2696 = 914
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBvrXn9vp4EaPC6a8FSqIHcNyUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λλΧяыкЭт():
    value = 382082
    text = __import__('base64').b64decode('bGp4Rmd5RHJjRHBLYjltelB3Wno=').decode('utf-8')
    total = value + len(text)
    return total

def _СЩγЗμюАЖЬоΡТМ():
    value = 528660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESjVaXhrrKAiNF6K3FCiMyg6zUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_1357 = 953
    total = value + len(text)
    if 55 * 52 < 0:
        pass
        661
        449
    return total

def _чЩΧуΓΓиоΥд():
    value = 514660
    text = __import__('base64').b64decode('Y1NERjFGQWJXbUxMQlBYcUo0WXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠμιΦιοπτξяжΛΞ():
    value = 120293
    text = __import__('base64').b64decode('ckRMc3EwOE9hWGNfdnkzaUNCUko=').decode('utf-8')
    total = value + len(text)
    return total

def _чЯшΖηαεеьФЙ():
    value = 634815
    text = __import__('base64').b64decode('UjFQMGw0Mmk0VmllbEtoQ2U0b2k=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _зλЖсжЮληκΛУв():
    if False and True:
        153
        _dead_5919 = 401
    value = 47929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBW0ekY40aFbEyv20gCGIAkGy2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        458
    total = value + len(text)
    return total

def _ΜΣкζжРπΔыμЖяΤ():
    if len('') > 0:
        pass
    value = 290602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxzKV3tu37wMAC2TmlGlHnEmt2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 42 < 0:
        122
        _dead_7088 = 385
    total = value + len(text)
    return total

def _αΕЩеΙρςа():
    value = 328942
    if False and True:
        _dead_6727 = 336
        898
    text = __import__('base64').b64decode('d09aQVNKMXhYZTZ0Z0lOeGlIcTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭсчъΤкХχчЦ():
    value = 62076
    text = __import__('base64').b64decode('TE5VMDU1OHZqRFRYbVlKeFlTaUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝиπγффорΖΑ():
    value = 95081
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgXMUVwa0LJTHD+G7H2CEBcB0jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖцЪΗЫυрйβεНνхвЯ():
    if len('') > 0:
        645
        pass
    value = 598143
    if 42 * 1 < 0:
        pass
    text = __import__('base64').b64decode('QzUxdkZ3N3FGWjJER2lKMkhYX0c=').decode('utf-8')
    total = value + len(text)
    return total

def _υХЕЯНцФιЛψЪр():
    value = 106673
    if len('') > 0:
        966
        _dead_2983 = 413
        _dead_9334 = 588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXa8PnIz1/8XaAWc7QKDFgQ+/lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6257 = 640
        56
    return total

def _ЯνМοΖПбВШвчφаΞ():
    value = 620839
    text = __import__('base64').b64decode('UUNRcldYdVN5ZkZ5bkRQQ2JZQnU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _чπюКСДЭБΜρωь():
    value = 12685
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px/QVAIy14kZMCKBz1yWOBw3t3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        124
    return total

def _уιχбηλΤτкδБмΘΜΚΔ():
    value = 748747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwDyZn0o9f0Naj2Ux2XADDMY4Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒРщСяγЮЪФΗыοДАΕ():
    if len('') > 0:
        _dead_1456 = 962
        827
        _dead_4846 = 661
    value = 261941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQrqXUIjqfFbHRa13FPJMAMp8zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σхνыЛСшыΗЫ():
    value = 748164
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HA22eEMD7q4kAzeIwgWhDil9ynQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 72 * 45 < 0:
        _dead_8136 = 250
        986
        pass
    return total

def _γορΠаюΝабΑωμеεΟι():
    if 97 * 82 < 0:
        _dead_1241 = 560
        _dead_6771 = 844
    value = 914530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dyn0YQg/7LBRKV/w0lG2F3EHx3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪЫοΕДкЖлςχ():
    value = 201248
    if 32 * 30 < 0:
        59
        pass
        931
    text = __import__('base64').b64decode('ZVUxRE9JRU9rWlFUaExnN1Vab0c=').decode('utf-8')
    total = value + len(text)
    return total

def _шΒХбаΣβФπσΟ():
    value = 7959
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dz7ASWkSqpEpNRuQ6k6gbQk982Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΞΖНиООΣшШйΧΡ():
    value = 912246
    text = __import__('base64').b64decode('bFpBeGlkMFhPMGVURHdQN21TTzQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2633 = 140
    return total

def _δАчяпЛΠΨ():
    value = 350410
    if len('') > 0:
        _dead_6856 = 426
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EATxVwgb/bkkCR+0xQW9AhU/7Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юДфΟΔРчРΠ():
    value = 332052
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSzBOXQzro5XGFzz3gebFhYAtF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эУыθξЩзΘΜξρρМ():
    value = 982240
    if False and True:
        _dead_3865 = 305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBDPXGIgrJ8sPQ762XGUGA16wmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _деЬΣйАжΚΤКЮНЩ():
    if len('') > 0:
        _dead_3139 = 118
    value = 694439
    if 94 * 30 < 0:
        pass
        _dead_3269 = 783
    text = __import__('base64').b64decode('WHppWFZhd3p6cmVhSkdfM01weEM=').decode('utf-8')
    total = value + len(text)
    return total

def _хЭοχΖΚртЖ():
    if 68 * 10 < 0:
        pass
        496
        pass
    value = 478995
    text = __import__('base64').b64decode('Rlphbm5JVERaaTJDNF9IWnhyWjc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7318 = 481
    return total

def _ПхνЩΞяъЙ():
    value = 646739
    text = __import__('base64').b64decode('czVuYmFBdENpTGZPb2ZKWUk2aG4=').decode('utf-8')
    if False and True:
        917
    total = value + len(text)
    return total

def _тДβΒΣПΧΞШυΡαε():
    if False and True:
        pass
        pass
        725
    value = 223569
    text = __import__('base64').b64decode('d0JUQjczOU96R0M0S0JHSVAxNFA=').decode('utf-8')
    total = value + len(text)
    return total

def _πсξфΚдΓЪБШЦΜ():
    value = 132049
    text = __import__('base64').b64decode('dk9tODE0QkM2SXRrTnhoVGlJNTg=').decode('utf-8')
    if False and True:
        594
        _dead_7202 = 243
        _dead_3408 = 889
    total = value + len(text)
    return total

def _εРНУпхжА():
    if False and True:
        595
        _dead_8866 = 681
        866
    value = 278222
    if 42 * 76 < 0:
        pass
    text = __import__('base64').b64decode('ZWV4Q1hPNnZsMVNaeTNJQ1NZYTg=').decode('utf-8')
    if 15 * 48 < 0:
        pass
        _dead_2146 = 466
    total = value + len(text)
    if len('') > 0:
        278
    return total

def _щЦψЕыЭЗХτвββЩУы():
    if 79 * 51 < 0:
        464
        569
        685
    value = 765061
    if False and True:
        _dead_6337 = 948
        789
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAO9SXs41IQvaF6Azka2DA8q3EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 87 * 6 < 0:
        535
    total = value + len(text)
    return total

def _ΒδЬШΟΓΜЭуИωячЖмт():
    value = 102546
    if False and True:
        _dead_5387 = 792
        _dead_6198 = 447
        365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCvtd2Yj+5kNMlqvzn22NR12x2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЗНЕХНΨдΖβγ():
    value = 558313
    text = __import__('base64').b64decode('b0NSNTBIX0R2OVRlNnRCTDJpQ1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΥмΘΤЙΞγβφшЦэЫ():
    value = 8201
    if len('') > 0:
        463
        _dead_4818 = 856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBDLelYVxL82YzWUnEylbHM2x1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 3 * 52 < 0:
        pass
    return total

def _γΩФΥъΕьбвΦζΧкΟрщ():
    if 64 * 85 < 0:
        _dead_1219 = 969
        _dead_9735 = 848
        532
    value = 564839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjrWRmQB8rBSOF6GnGyaEQEr92Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 48 * 26 < 0:
        pass
        _dead_7091 = 569
    return total

def _оЪΣыεяρЦ():
    value = 910220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjXBdAYB85oUFFutzlK1ZiQAwmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЕХγθКЕψτΤΥΚ():
    value = 54242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzvLdmER1KobFV3x+m+xNX0A1D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΧчщΛБЦфИГД():
    value = 435568
    if False and True:
        255
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCLuamE+0/wgCSKg0VeyPhMLxVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψζяΩБуΖеуынТюпу():
    value = 236186
    text = __import__('base64').b64decode('eHppbFBiR3J3Qkdmd0h2MWVIUDg=').decode('utf-8')
    if len('') > 0:
        209
        _dead_3535 = 400
    total = value + len(text)
    return total

def _ΔлЗθЮΞΔπφΖа():
    value = 313364
    text = __import__('base64').b64decode('WWkxb1R4X0N3RFRfQUhRR3ZvdUI=').decode('utf-8')
    total = value + len(text)
    return total

def _КквЫφрΤЬиξσΤб():
    value = 647293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy3jSXAY55ILaRi72U/HAikNxkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξωсΝπжЗξυΔухЗшч():
    if 25 * 16 < 0:
        _dead_1125 = 946
        _dead_4409 = 223
    value = 770533
    if len('') > 0:
        _dead_6413 = 938
    text = __import__('base64').b64decode('aDR5T3RZbnprYjZVS3g4NENralA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑΒφηФсΠПΖЩЫ():
    value = 573173
    text = __import__('base64').b64decode('dElWWWlaMlEzaWlNN1dtcFlmZVE=').decode('utf-8')
    total = value + len(text)
    return total

def _αЬρεΤρΨюΖβκΑΡ():
    value = 359736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lzz1PEVs6roRaiurn2LEHncQ1U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сБЦЕσλΠκαФυйТКйл():
    value = 170557
    text = __import__('base64').b64decode('enZ0VzhOaTZWODZLSE5tNEVRdXY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4880 = 356
        789
    return total

def _ξюЯΜСΙлδνθυФαб():
    value = 700466
    text = __import__('base64').b64decode('WXc3ZWVFSWpTSVRrZkdnYmlsVmg=').decode('utf-8')
    total = value + len(text)
    return total

def _фхшЪжβшвΚθзΠν():
    value = 601494
    text = __import__('base64').b64decode('YnJtMlZTaUpsNFpDX0o2VWFNMXY=').decode('utf-8')
    if 81 * 18 < 0:
        243
        _dead_7114 = 273
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_7916 = 892
    return total

def _βтазвЮΦζцГο():
    value = 479951
    text = __import__('base64').b64decode('VjBMNFRrRldvZEFRcG84UUVubVQ=').decode('utf-8')
    if len('') > 0:
        _dead_7571 = 825
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_5723 = 816
        450
    return total

def _ΝγщмЮнфφΠЭ():
    if len('') > 0:
        437
    value = 727090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En7eRwQ/76MHLT+R8UCcJTR73kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛртрρбяьвΟ():
    if len('') > 0:
        _dead_4030 = 452
        _dead_9873 = 707
        pass
    value = 762458
    if 38 * 28 < 0:
        336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiblRQUap70ubg6M43qdLQ4r1kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠНгМэΞΚΨзΒωψЯИγ():
    value = 46679
    if 43 * 23 < 0:
        pass
    text = __import__('base64').b64decode('VFFGWU15aVlYYUNxcjJXbGVtbE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣдηηΝΥλσБ():
    value = 123508
    text = __import__('base64').b64decode('YXBhaDNkVTZqMTNIUDh6VllVZmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΝλОΗΜςΑ():
    value = 52276
    text = __import__('base64').b64decode('SWtGYTh2X2xydHI4Wjh5dDNlT0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧεЯИЧσΦш():
    value = 511851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jjz9dF8Bp5cvAwOr4wS8ZyMdwVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΞВшΔΧЫПδЭΣУ():
    value = 862879
    text = __import__('base64').b64decode('bkZIdGhjQnFiX2JUZThBS2FYeGI=').decode('utf-8')
    total = value + len(text)
    return total

def _РОАщсРЙЮЙЦΜΡ():
    value = 809757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXvnTXoY9vsiYiiO6lGaBxAA1no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        248
        932
    total = value + len(text)
    return total

def _ЪρЙнεвъΜΟλΨα():
    value = 883738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyXWb0M6154pMiqa2kOdMi4iwEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йεΖзЕедцΙΤ():
    value = 56738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhvLVgUQ7ZkOAx+l9wS8ZXM9sF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βДжХИыξδы():
    value = 220534
    text = __import__('base64').b64decode('Z2FJVE9XSHc4ZFNSZDFNUzlIZWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΓκΩсΠωик():
    value = 658648
    if len('') > 0:
        975
        _dead_6679 = 717
        528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB3CNnMTzJkwAza3yXyKMAgZ9EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7245 = 508
        pass
        _dead_1528 = 672
    total = value + len(text)
    return total

def _ЮЕКОеЗΒΕбпцζΝ():
    value = 960199
    if 32 * 47 < 0:
        105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3vMenwhy/o5bTiHzUaqPhYfwzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩζγлМΘΨρ():
    value = 7130
    if len('') > 0:
        _dead_4164 = 833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSD2X18/65IbLDWAxAKcPRMW9l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 3 * 37 < 0:
        769
        650
    return total

def _ФЮЫВΤггΩОлΖеюЛηН():
    value = 246809
    text = __import__('base64').b64decode('WG8wcXhiRnVxWXlQTzNyZ2hZSmM=').decode('utf-8')
    total = value + len(text)
    return total

def _щхкАгφπνζΑдС():
    value = 286171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwDvSl8gpo9aDDqQ8HueESgH4H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _αΦДγУЗщЮιξгд():
    if False and True:
        pass
    value = 160545
    if 81 * 48 < 0:
        pass
        624
    text = __import__('base64').b64decode('bTRPZ3FQVWZXUkhRcnJNbkJNbjE=').decode('utf-8')
    total = value + len(text)
    return total

def _еИλΟΔΡΦДβφСДпшШβ():
    value = 510696
    text = __import__('base64').b64decode('U2EwOFRWVk1Sd3MzeEY1WWlrODk=').decode('utf-8')
    total = value + len(text)
    return total

def _ψШПцλМνИХнζωЯшЖ():
    value = 20821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxvmSXg/qKczbgCJzVSvYjEFxlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бйμηсρςω():
    value = 26432
    text = __import__('base64').b64decode('TDBid3BoRDBwWmp0WW5yc0JLZ0c=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3303 = 647
        _dead_7671 = 82
        _dead_2211 = 915
    return total

def _хпЭθчοОΥхчΗСЗ():
    value = 861803
    text = __import__('base64').b64decode('cTBoUmVBd2psVjRmTkV4ZFlYeEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΓфЫβΔеζьвЩ():
    value = 746312
    if len('') > 0:
        _dead_1548 = 920
        _dead_7225 = 368
        533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn3KXEco6aQVAx6W32SYB3Q750I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        429
    return total

def _рεεΤоθпАЧ():
    value = 87625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxftf1QNyJoZDVuT5GmUERMnsVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъщлιзεεРЛЩ():
    if 82 * 68 < 0:
        _dead_4938 = 50
        571
        pass
    value = 170746
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy7bakYMpqoSHgm0z06xBgEAsF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 95 * 3 < 0:
        299
    total = value + len(text)
    return total

def _ΝиΨиЯψΗО():
    value = 329937
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnjsZUIL8aQZDSKR8VfDOTQ+8Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔпχТиГυΡкΛкθЫδУ():
    if False and True:
        134
        _dead_6094 = 348
    value = 251095
    text = __import__('base64').b64decode('ZlJCQ0M4R3JoMlB3WmJSaUl4Rkg=').decode('utf-8')
    total = value + len(text)
    if 30 * 16 < 0:
        _dead_3966 = 109
    return total

def _шΖκДφΖзФΙΥАωф():
    value = 809621
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDX1PHwO8vg3LAm3mV7BYyscwmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗωТБРкщΧтφαχФэЦ():
    value = 937498
    text = __import__('base64').b64decode('YkpBbGZMakpUUjZybWZjN3I1d2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖχШУзΒЬФψаГαЮ():
    if False and True:
        499
    value = 155787
    text = __import__('base64').b64decode('VGFDMWc0X2JIMXNKaWtBdU1RTTE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        498
        981
    return total

def _ηεΙчΝΜВΩαШβзЬ():
    value = 783900
    text = __import__('base64').b64decode('V002TWR0WTR2XzhDUTRWTlRlMFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ыФΤβΛκаΥΝαБКуπ():
    value = 397633
    text = __import__('base64').b64decode('Vzd1emVDWUpLS0VfV2hJM25IQkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _δΧЕЬЭКзЛфЫх():
    value = 877792
    text = __import__('base64').b64decode('SmdVNDI1OEFUUmtrNnJPOERjNXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦфВΨΤГκμккмχβй():
    value = 197805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT+wQ0Uyy6A2LSaQyWSBFwQk7TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6748 = 931
    return total

def _кдβπрЦΚСЕ():
    value = 155660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDvcWGgTyfszHSmP+WCkJQ8s4Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖρтΛогЕгЬГэΛпэЛ():
    value = 510315
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAzNW0IV5IU6LTyRy17JJC8Z21k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 77 < 0:
        _dead_4907 = 800
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_7548 = 680
        _dead_5628 = 833
        _dead_2866 = 50
    return total

def _ΚПΟКШЦИΘдσσЯГКД():
    value = 72356
    text = __import__('base64').b64decode('WUFWTF93Tl9HRl9CQzZFS01iOXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗιΗЭИιγафηШФ():
    if len('') > 0:
        294
        pass
        pass
    value = 459343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQH9WG49/LoEbjyl2w6BBCIh6Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        599
        267
    total = value + len(text)
    return total

def _БЧΧΛδпрЩςлуΖБрΔ():
    value = 405031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAS1R1sK7aEuNRqK6Q61ZBEp7V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИуΩгλψчсее():
    value = 159948
    text = __import__('base64').b64decode('a28wWGtha1JMRHB0RjFZTTJFb3I=').decode('utf-8')
    total = value + len(text)
    return total

def _цΣςΜвЛοτзТ():
    value = 368924
    text = __import__('base64').b64decode('YXdMTVVUdDVTTk9waGZlc3VpX28=').decode('utf-8')
    total = value + len(text)
    return total

def _ВρΔεжрΓеВгоχυР():
    if len('') > 0:
        _dead_5409 = 844
    value = 79496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzfHalRv2ZhVLlaF3HnBBDwd/UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        620
        294
    return total

def _вНКЗУУΩФλЧдιКЗ():
    value = 284202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhDhVl875rgACl6QwwbEP3Y5wF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щοΙΒжАΛюΨΞУνочЭ():
    value = 611415
    text = __import__('base64').b64decode('cFA2MHlNTlg1TmlEeFNrR0dTOXY=').decode('utf-8')
    total = value + len(text)
    return total

def _фχΤθΓбМЪкЛΟЫ():
    value = 520412
    text = __import__('base64').b64decode('aXc2b2hZbHdEVEFrdVdIS05KNlE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        479
    return total

def _ΙЪЗчΡуΚΡЪ():
    if False and True:
        _dead_8591 = 2
        pass
    value = 779408
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HA7bZmEB24oZECOg8QSIPzB48nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        941
    total = value + len(text)
    return total

def _ШлΔяъЩλΒэσΠΠю():
    value = 338329
    text = __import__('base64').b64decode('ZDRTenZnMnFSUjFBVGZrTXlzTHA=').decode('utf-8')
    total = value + len(text)
    return total

def _νΨЫЪΧгΚλΣШлщ():
    value = 234938
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCfOaQkO8/9SPhqO+Gm8DQx8vWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 55 * 14 < 0:
        pass
        808
    total = value + len(text)
    return total

def _ШВΓЭαрςУЧΛбεиγоо():
    if False and True:
        pass
    value = 149573
    text = __import__('base64').b64decode('bUtLbGJTd3V1R0c3VmRKSEhFeDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΣσВΓνМзщΨδнб():
    value = 326709
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC3wfl1o0L8TDVyA2VKYFzJ9vDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЖЩσяоСΧΧют():
    value = 627911
    text = __import__('base64').b64decode('aUpacEh1WVBOM3NpUjRVeUZWbUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ПρъωπωХШи():
    value = 487200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwK3RmUc+YRTNQ6G2XqHBS8l/WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧκмгВййρΤτДαс():
    value = 960716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAewW2kL1IE8D1qzyQa2YRwm3UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кИψΜвςδεмКθткΑ():
    if 84 * 20 < 0:
        pass
        _dead_9248 = 444
        _dead_5580 = 860
    value = 434281
    text = __import__('base64').b64decode('djRfNGh1Sm5BcTNTYWZZVW0ycWU=').decode('utf-8')
    if 58 * 94 < 0:
        635
        368
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_3940 = 20
    return total

def _пζнЕφοψдВШлΤΝ():
    value = 729544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyC3aHAc+40CDFzwkEzCGnMo4lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВχесдНЭИФπ():
    if len('') > 0:
        pass
        _dead_7757 = 742
        pass
    value = 774689
    if False and True:
        873
        _dead_9727 = 175
        781
    text = __import__('base64').b64decode('dUlZb2NESDQ2Y28ya2hZZTluTXM=').decode('utf-8')
    if len('') > 0:
        285
        _dead_4745 = 614
    total = value + len(text)
    return total

def _чθΜсЖχςФтΓΥ():
    value = 194993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQbpRWEwyaEiMAqCkAbFAi8Qwmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛзнτγЯИθьο():
    value = 686674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EALhOWgj86Y3ay2W0XqoPhwa02k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭНχΦναЧМг():
    if 96 * 85 < 0:
        422
        417
    value = 577378
    if False and True:
        _dead_9188 = 712
        pass
        63
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjbBfQA8/5sCHACk/ECWAHId70g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        903
    return total

def _ВεЩμУЬξИХΓе():
    if len('') > 0:
        _dead_2307 = 827
    value = 529205
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQmzRXoPx7IuPQH2/XCpHS9+628='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        584
        pass
        pass
    total = value + len(text)
    if False and True:
        53
    return total

def _ΚΜКюΧЖсεΣцтУ():
    value = 532657
    if 35 * 54 < 0:
        _dead_7561 = 480
        _dead_7656 = 784
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjjbOkMA2KcZawucmV/JNTcoxVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХχБЮυρΜΛΣ():
    if 93 * 70 < 0:
        pass
    value = 838630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxnuWQYv9qELah+I/UabPCEY81s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕμчλШруШщαэφРΦ():
    value = 96501
    text = __import__('base64').b64decode('aW5lRFdQU3VZenh0bXU5NTllZ1k=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΦΕуУшΚΜπΨ():
    value = 676199
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjfVY3wq/J0KLQD6m3WGIxQlx28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДАЧωаДκпаΔч():
    value = 841530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K370Y2AP6P07bxeG9wOhIXY383c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2490 = 788
        pass
        pass
    return total

def _ДεЬХЖρХъτσЮπТ():
    value = 67307
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('TXVOeUpqY0JwVE1ZRVlsM2lIOFk=').decode('utf-8')
    total = value + len(text)
    return total

def _АрΚЧЬсΔзЖ():
    value = 721294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn7zR0k76awmOQu25E+DIyEssz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 74 < 0:
        _dead_8325 = 126
    total = value + len(text)
    return total

def _ΨйВЫшыДΝДзшξυ():
    if len('') > 0:
        28
    value = 69779
    if 82 * 14 < 0:
        _dead_7862 = 933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHrAQX072IE1Iy3y0FODPn091Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        705
        653
    total = value + len(text)
    return total

def _ιюυХωΒОъμУΑсиЖ():
    value = 438517
    if False and True:
        pass
        pass
        pass
    text = __import__('base64').b64decode('eHFUVFlvdFByV0k1N0lITWMwNG8=').decode('utf-8')
    if False and True:
        568
    total = value + len(text)
    return total

def _ΨцЕЦаΥЯδК():
    value = 735575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ig7xWwJg1JwTNCaW43exYDV/xj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙжЩзэΒφЭδιКМΜф():
    value = 390664
    if 92 * 98 < 0:
        547
        592
        _dead_2739 = 666
    text = __import__('base64').b64decode('RG5ndzVISGQxb3ZZZ1JUYmJ1d2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΚРгΕθηвагДτ():
    if False and True:
        69
    value = 618993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwCyd2QQ/78tPQuNkHizID8/9GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦβеηΞικзШνзгБΩ():
    value = 685752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pxj0Rnw06ItXGSaa5lSbGjd54W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υСτωХЧΦнΛАΘσφΗфβ():
    value = 588575
    text = __import__('base64').b64decode('aWtGNnd0WlJzbzZ4TzZvc1QxNzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕпАХсΓиыОШ():
    value = 591360
    text = __import__('base64').b64decode('bEtpX1N2ZUtVa25LVjYya3h5TV8=').decode('utf-8')
    total = value + len(text)
    return total

def _γЯХΛυιжъΡΛΟξФΣбэ():
    value = 102241
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACnjXFAc+oMIKl23z3OcAxENx3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГхШωБюЯΧфдκхаа():
    value = 208941
    if False and True:
        515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAe0XXQxq71THR7z5FyjAiss/W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙτФбΣпςЗЮл():
    if len('') > 0:
        _dead_9958 = 18
        _dead_6052 = 674
    value = 143352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwXnR0dt+4MHMFuB4HCTPy8s3Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КюΡуРζщщФχβсхΕΑλ():
    if 50 * 72 < 0:
        pass
    value = 861549
    text = __import__('base64').b64decode('ZFpxNk1EOGpVQ3RWbHliOURoS0s=').decode('utf-8')
    total = value + len(text)
    return total

def _κьΕьγτζЯΒшшьΡлцц():
    value = 760640
    text = __import__('base64').b64decode('Z1E5aU1pcFJRNXRybkRuT3VkeEY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8929 = 326
        pass
    return total

def _ююνβТХУцъУΜ():
    value = 866130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB78ZFgr64cgbhyG0FG7Ezx+7U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3635 = 120
    total = value + len(text)
    return total

def _эШлυΘЙдηоΤ():
    if False and True:
        pass
        166
        _dead_7177 = 254
    value = 897063
    text = __import__('base64').b64decode('ZWhaRFp6ZWxlelNWanhvdjZwbVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨуФБΟОыЛБ():
    if 49 * 19 < 0:
        319
        _dead_2949 = 836
        _dead_3140 = 825
    value = 368721
    if len('') > 0:
        pass
        _dead_8523 = 507
    text = __import__('base64').b64decode('d3RhUmlxQlYzZlF1RktPRWp5WmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ерьаΜοШцΨΝЙΜΨй():
    if 65 * 74 < 0:
        318
        pass
    value = 632711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH7iYF8gp4kgFDau2WCdJjIDsj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        234
        632
    return total

def _ωζιΔЙΙτи():
    value = 306052
    text = __import__('base64').b64decode('ZTZ0UGdoOFpkZGZKaHdESlFmQmg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        212
        315
    return total

def _ΠгсφКкСλДГЮ():
    value = 449570
    text = __import__('base64').b64decode('VnRubnhvRnY1WmFSRXdPZDR0TW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ιбвЯМΣηΠγΡшгЗОχ():
    value = 84029
    if len('') > 0:
        _dead_4841 = 489
        _dead_4479 = 74
    text = __import__('base64').b64decode('ZkVoQWlGZlZMSHZZc0UzZDRHYUM=').decode('utf-8')
    if 82 * 47 < 0:
        855
        _dead_4823 = 570
        _dead_4200 = 976
    total = value + len(text)
    if False and True:
        pass
        759
        424
    return total

def _ΥπΜΓΡιСНКνΙ():
    value = 163465
    if 89 * 13 < 0:
        pass
        846
        _dead_4372 = 647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh/pOkEc954QDi6G3WO2GHd8/GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝТшЕиαωЙσΛпβчΤЖ():
    value = 46371
    text = __import__('base64').b64decode('ajl1bkttVFpkSkxBQWtUUVJEdlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΟЩοйΖВАЩжΦαΩΡηξ():
    value = 839388
    text = __import__('base64').b64decode('S1VheEJ0WUxKWUw3alRyZ3picEo=').decode('utf-8')
    total = value + len(text)
    if 24 * 86 < 0:
        720
        pass
        218
    return total

def _жΚоФмυεΠчцФγο():
    value = 232028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBjTVksS3awabAWgyXeyEH0E4Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚηЫΜыψξзΛхРэοп():
    value = 867821
    if len('') > 0:
        781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSryQGI4yr5aIimuw36UJwsQ02E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨГΦцЭЩΝφЖΞйΛΒьЕ():
    if len('') > 0:
        pass
        287
    value = 219296
    text = __import__('base64').b64decode('Uk1vU1d2RTNMUmVCNUc4SXZBTDE=').decode('utf-8')
    total = value + len(text)
    return total

def _λоΞЗΚηКΨШяνфСфД():
    value = 550529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQWxO3QD75wNEBit/keiA3EY7Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨνФφЦЖγΤРВОМВ():
    if 15 * 43 < 0:
        pass
        pass
        pass
    value = 74744
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA7AVkkc9KYQaCiiyn+BISYj0F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4960 = 215
    return total

def _яХκМΖвσРαΨ():
    if False and True:
        594
        pass
    value = 167224
    if len('') > 0:
        _dead_8781 = 402
    text = __import__('base64').b64decode('UDdjM1hmQktXUGMwNEJUa1VVblI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥбγЯΩТЛυщБ():
    value = 887566
    text = __import__('base64').b64decode('UlNib0dUMDRfcl9vOUpBMnprVVM=').decode('utf-8')
    total = value + len(text)
    return total

def _бнШΔΔΥПзЩЪψд():
    value = 248223
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nhe1ZVUp64RTCCOgwXCZGXw780c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7987 = 868
        728
    total = value + len(text)
    return total

def _КпЪΣтβыв():
    value = 442670
    if False and True:
        _dead_4863 = 617
        _dead_2968 = 34
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXzpV2gM1JIPKh+H8FiVDjY69T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        409
        _dead_9743 = 489
    total = value + len(text)
    return total

def _жШΚρΩбУИ():
    value = 645546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSTqV0Qa3IlbbAGKzmOAPg55y2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 94 * 88 < 0:
        78
    return total

def _КБΠОΠсθЪωПДΗ():
    if len('') > 0:
        641
        pass
    value = 418738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRrpZ3UuwfEaLSytxwSJZH0182o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        128
    total = value + len(text)
    if len('') > 0:
        839
    return total

def _αЙοцСΤШιΞΛРПψу():
    value = 543217
    if len('') > 0:
        pass
        977
    text = __import__('base64').b64decode('R0hXNzdZcTVJQXJWSVRScVRTbVM=').decode('utf-8')
    if len('') > 0:
        pass
        351
        _dead_4518 = 154
    total = value + len(text)
    return total

def _ιНцξдκбφτμДεы():
    if 17 * 39 < 0:
        _dead_4035 = 105
    value = 140389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgXOaQYIwY0XMwK0n1qWMhwl7Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ЦНмццΨтЮΗλ():
    if False and True:
        907
        958
        pass
    value = 861820
    if 7 * 76 < 0:
        852
        34
    text = __import__('base64').b64decode('RldqVnVzN2h2VlRlakltektWV2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖоЯσчьжЬШ():
    value = 427580
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('UVRySkNmM3dpMTVtSXMwZDRzT2M=').decode('utf-8')
    if 22 * 32 < 0:
        430
        _dead_7444 = 709
        _dead_4292 = 583
    total = value + len(text)
    if False and True:
        811
    return total

def _ιвΜхШΚΤПЯЧζδеΙЬ():
    value = 612505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAvJTAIPzJ8QPTq5+mOmMxco1TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сЛРυχτсεУЗ():
    if False and True:
        346
    value = 965017
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRfAb1Br954UP1jx736xY3Mcz3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΠфΩПУыαПпшИкй():
    value = 807443
    text = __import__('base64').b64decode('SUlmVHNlUWdpT3pkSEh3VkhSTVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩТΨΚЪηΑαζЫаьπ():
    value = 506822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ6yQVA+9Po1Iiyl/2TCN3Im4GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6855 = 13
        533
    total = value + len(text)
    return total

def _ИРЬЖББΞэлжЕ():
    value = 973342
    if len('') > 0:
        43
    text = __import__('base64').b64decode('T3hhaVpQZG1JOExGSmI3QVAwcjU=').decode('utf-8')
    total = value + len(text)
    return total

def _СΔлуΗΛБЩΧр():
    value = 165242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRDtYmsP8LgUPCeXn2e9Eg5211k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('bQ==').decode('utf-8'))
if 21 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    438