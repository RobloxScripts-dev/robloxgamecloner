#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΡъΛЖЖΥφκΖлжцЯьИ():
    value = 896684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHvrSloArLkSGCe02kCzBxYD0n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПпβЫЫτΔГ():
    value = 938981
    text = __import__('base64').b64decode('aU9aQ0dHUGlfWFNPQzF3ZTdHN3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ιШρΖбψΗΣЖИ():
    value = 123399
    text = __import__('base64').b64decode('WnN3a0JqMG80U3V1bEVtT0NLZ1A=').decode('utf-8')
    total = value + len(text)
    return total

def _υъВцЖИцтчΦздИροп():
    value = 561492
    if False and True:
        498
        pass
        pass
    text = __import__('base64').b64decode('aV9SbnY1UmZqZlBjRWJOWFdTTXY=').decode('utf-8')
    if 63 * 50 < 0:
        _dead_1542 = 514
        _dead_8861 = 87
    total = value + len(text)
    return total

def _шοСНΙИρΤсО():
    value = 970792
    text = __import__('base64').b64decode('TlhZOENwT3VZWjJmVkMyYXh4T08=').decode('utf-8')
    total = value + len(text)
    return total

def _τчΕъяТЬδ():
    value = 198321
    text = __import__('base64').b64decode('U1NqeXJiNV83TUxUMXBkSkxNa3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ШнсЪлСрΜΝΩΨпь():
    if 43 * 22 < 0:
        251
        _dead_4282 = 514
        pass
    value = 95374
    if len('') > 0:
        193
        pass
        969
    text = __import__('base64').b64decode('aTlpVjdKNllFTm9Bc19lZzdlSEE=').decode('utf-8')
    if 92 * 45 < 0:
        pass
        pass
    total = value + len(text)
    if 92 * 6 < 0:
        _dead_1547 = 431
        pass
        pass
    return total

def _σжБΡλмβΣΝэΠΜ():
    value = 910546
    if 90 * 51 < 0:
        pass
        pass
        _dead_5354 = 712
    text = __import__('base64').b64decode('d1lMWG1MYV9NRHlWcm5wNlVuNng=').decode('utf-8')
    if 23 * 1 < 0:
        196
        pass
        _dead_6219 = 166
    total = value + len(text)
    return total

def _ОψТбпшсаа():
    value = 914405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR/QdlkSyaExFyOP8UTCBQgMy30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИхКПцфДЬыΣРΟφξΕю():
    value = 315840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCvoeVor7pg6HCSQznLFMnw552c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝюΓΨГΠбι():
    value = 133959
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR/3NkAyr6kobxyswwOEOhA/8GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        537
        pass
    return total

def _щРΔБΘФχμΒΛκЙ():
    value = 440705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERvRSGIXx4EUECeknlqhJjZ8xTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θуоξЭЭщвжβсГвΟυ():
    value = 856730
    text = __import__('base64').b64decode('QWJfRU05eTJRT2lLRlZ6M2RGeDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬпЛιΩАΨΥвЖ():
    if 82 * 51 < 0:
        694
    value = 498227
    text = __import__('base64').b64decode('VUp4TXNJcGRtQlZWVkRvZFJCV0g=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ыΣушдΟхΑ():
    value = 596471
    text = __import__('base64').b64decode('TmhxOURGa1ZrUTRSRFZua2ozNUs=').decode('utf-8')
    total = value + len(text)
    if 90 * 37 < 0:
        _dead_2418 = 965
        _dead_7259 = 526
    return total

def _удЙΚжΛρъТбθθ():
    if 25 * 95 < 0:
        272
    value = 949360
    if 12 * 56 < 0:
        _dead_6291 = 606
    text = __import__('base64').b64decode('TThMc1RBbkVCSlEyRTlMUUVLV1U=').decode('utf-8')
    if False and True:
        223
        263
    total = value + len(text)
    return total

def _ояΟοιΦЧβсю():
    value = 443635
    if 31 * 21 < 0:
        939
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD29bHoq8qMOCFj72EWyIBUVslY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζΥωИЪΖΦХДΡ():
    value = 385488
    text = __import__('base64').b64decode('TnpYbm8xWUg1RDNUNkFlM3Y4TFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦДхςΟΥбаЙВ():
    value = 607328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCfCV0Qe1oYmHwO2+wbCPgI+01s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΙΕжΞπзАнιыΤ():
    value = 38040
    if False and True:
        _dead_1586 = 953
        127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSTePUg924Q5HFqo3levMhci5UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        300
        pass
        _dead_6066 = 983
    total = value + len(text)
    if False and True:
        499
        566
    return total

def _ΦАαΤКШсιяТ():
    value = 797946
    text = __import__('base64').b64decode('ZlRTcThNR01oaFc2X3FPdlYzWUs=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΒЪВИΩбслуРбящ():
    if 34 * 96 < 0:
        pass
    value = 811260
    text = __import__('base64').b64decode('YnM1R2pJN0N0eW94aFVNdFE3TWk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6927 = 977
        _dead_1237 = 765
    return total

def _ьгМΣЮЮрβДνСΓеη():
    if False and True:
        387
    value = 653725
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQTRRgAW9pxWCxyLwGmHN3I99EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8508 = 5
    return total

def _тюυргпΑΥц():
    value = 729271
    text = __import__('base64').b64decode('YlMwVW1CS3BEcUMwVFJfeDhPNk4=').decode('utf-8')
    total = value + len(text)
    return total

def _хьθπркяκδЙΟдυρΡ():
    value = 836289
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDrjaFII950nY1eZmQSxNh010F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 11 * 27 < 0:
        _dead_6353 = 547
        _dead_7584 = 969
        681
    total = value + len(text)
    return total

def _δΑщфМμΘВΡЩδκжЧβП():
    value = 170901
    text = __import__('base64').b64decode('cGExeHp2QktIZnp2d1dSSGhnX0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΠжпεΑшДлШ():
    value = 160132
    text = __import__('base64').b64decode('T25wZjRFY09XS3pfeERTcXFoNEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ИδвомΧδΑмЪε():
    value = 43744
    text = __import__('base64').b64decode('S3NJenp3X0lvY1hoT1pZRjdwWDg=').decode('utf-8')
    total = value + len(text)
    return total

def _Βςогπφδχ():
    value = 744618
    text = __import__('base64').b64decode('RTFzVGJuMkFJRHZwNzVieUlRRHg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6952 = 990
    return total

def _ΒФъцгСкЬψΖυтЧ():
    value = 785729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzrsX1tg858ODzyM8Vy3Ywh5yUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 45 * 69 < 0:
        984
        _dead_3538 = 141
    return total

def _τфΑлωΓТЛА():
    value = 738666
    text = __import__('base64').b64decode('WGlBRFZCVXhnam81ejBJM3NEZks=').decode('utf-8')
    total = value + len(text)
    return total

def _τЙΠМгξынюБТ():
    value = 957835
    text = __import__('base64').b64decode('dUNRVEFZZXlEekxJT1lqZUFlTDc=').decode('utf-8')
    if len('') > 0:
        _dead_8326 = 353
        406
    total = value + len(text)
    if False and True:
        pass
        _dead_3420 = 723
    return total

def _лЖβΚΘΞМКμюяΠ():
    if 50 * 68 < 0:
        pass
        _dead_2945 = 769
    value = 976010
    if False and True:
        _dead_1426 = 506
    text = __import__('base64').b64decode('UkhsN3R2UzdfUElaMmNjeWtQdUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩνгРιЫιЙΙРα():
    value = 850444
    text = __import__('base64').b64decode('ek1uZEdaQzlZZlBNMUwweDh5OXc=').decode('utf-8')
    total = value + len(text)
    return total

def _уΗЙжδЖюξδШЖιΠгТИ():
    value = 206956
    text = __import__('base64').b64decode('WDV1WTZfNWUxem5CeTNLbDRpU1c=').decode('utf-8')
    total = value + len(text)
    return total

def _иЯЗйЧЯЫΚзν():
    if False and True:
        pass
        _dead_4197 = 576
        _dead_8611 = 873
    value = 708000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz/BVGFh77k6YxjynW+hFgo/tWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жШЭвζЮφФьэβХЗл():
    value = 849980
    if 38 * 91 < 0:
        _dead_8704 = 378
        707
    text = __import__('base64').b64decode('SnhrZ0E1cFl3N08xV3FtemlnWm8=').decode('utf-8')
    total = value + len(text)
    return total

def _бμэεΑэΠХвлυμп():
    if False and True:
        _dead_9869 = 906
    value = 865765
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRzsaGYz04EXbwKC/APEZQsD11g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8073 = 693
        218
    total = value + len(text)
    return total

def _νЛΥаиΒτΟЙЭюΣЕ():
    if len('') > 0:
        _dead_1276 = 202
        _dead_1894 = 792
        _dead_4968 = 620
    value = 652996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgLsWmdp/6c1OTaWxFu3GnQexTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        80
    total = value + len(text)
    return total

def _тΤβыκшΛεйуТнΧУо():
    value = 114363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXj+bAQQ17ESNCGkmUOmHxY550I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΙНРкπξЭΧνПχНИЪβ():
    value = 458019
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiiwXVk96KQQMheKzgeHMgYW8Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ькΣΛматЬνэкυЧ():
    value = 525869
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EADlTwEc7qc3KzCc+G68BQIO8zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΛΩЮΚσΠАЦлΛψю():
    value = 126671
    text = __import__('base64').b64decode('cmY0ckgzV0k3ekxwdlZWZGpaSl8=').decode('utf-8')
    if False and True:
        _dead_9941 = 880
        97
        pass
    total = value + len(text)
    return total

def _УτμΕзσШγКΣ():
    value = 20234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhfjYlY/zoEsMheU4lmCLDd2tWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζЖЬφЗЭΧжДγыЪю():
    value = 46499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ES3AYEMW8LgoMiSN2lixZywE3UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 8 * 56 < 0:
        pass
        503
    return total

def _чΔШНяЪχЬОЙ():
    value = 669096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxXJQ1Zrx4YSNiuZ22a1MgN57Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НЙКΓЦТчΡΨΛяйοыΝΛ():
    value = 931010
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESixT3kwq4dbHzup2HqfMR02t00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟвΓЙшзЭЗжедΟ():
    value = 793960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiP3Y0cO0Lk0Mz704gW5Exw2yV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙьОЪζТφх():
    value = 854990
    text = __import__('base64').b64decode('QzhuendJU1p4ejdfdWF2OUdDMFI=').decode('utf-8')
    total = value + len(text)
    return total

def _εΕυλρЬжчЖ():
    value = 676822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCrSXVM1qKYVBRygn36gPjQG8VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        141
        841
        742
    total = value + len(text)
    return total

def _МρУΥΑыΨΓцψюоМЭ():
    value = 508446
    text = __import__('base64').b64decode('ZzVkOU9VNDZkcWZBbVFFNTFkVzI=').decode('utf-8')
    total = value + len(text)
    return total

def _дΓоЛΖοΡωδаα():
    if False and True:
        720
        pass
    value = 784267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyfHN2Aj66cNDzaky0abDDcu910='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        645
        pass
        843
    total = value + len(text)
    if len('') > 0:
        980
    return total

def _тμΗпЕмЕВξεΑБσхГ():
    value = 647919
    if False and True:
        _dead_2220 = 366
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSnTVFMh7fhVCDWqmAPIJBUM5j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬАσИοЦЯγ():
    value = 949114
    text = __import__('base64').b64decode('bXZPQ29wYTRnZU9sTElnSFdiTXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΒбΣμγшχΜΝθюзо():
    if 6 * 7 < 0:
        468
        _dead_3859 = 762
    value = 983890
    if 46 * 12 < 0:
        _dead_2079 = 620
        pass
        _dead_6039 = 740
    text = __import__('base64').b64decode('VDF0dUNCMGlqdVVuWXdHQlJCTlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫζбσρцЭрμПШΣ():
    value = 549364
    if 19 * 92 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByrzawEaxrAJAgWGz0GEOxEe51c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8641 = 543
    return total

def _ЪΖЫрМαΔΣоТΝΤ():
    value = 259524
    text = __import__('base64').b64decode('Tk45VnNLcm1yUVc5YlM0azJoaG4=').decode('utf-8')
    total = value + len(text)
    return total

def _κюШбΕвСκОεΖ():
    value = 962930
    text = __import__('base64').b64decode('T1RadmNpNnQ2VHhJOE9DYnlqU1Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1763 = 192
    return total

def _ΒλΣЖКΧадУФБГ():
    value = 65194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MijgVnkwx6kIAFqtwUGXFSsK22g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЮБЬμβЮХχΓ():
    value = 686893
    text = __import__('base64').b64decode('dnhkU1pKd2R3SzdOMUVRaTVGWkg=').decode('utf-8')
    total = value + len(text)
    return total

def _жНгγЭУзбу():
    value = 594074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS61f18R1LIvA1v7/gCiGBR27zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГбΧΗτΑъΠ():
    value = 178659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQTvRn0x3585ajupzHqebTAA6Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 96 * 66 < 0:
        _dead_2097 = 194
    return total

def _зВΤχεΘχо():
    value = 259508
    text = __import__('base64').b64decode('SXI0bjBFa2I2bHl4V1RQcmV0VFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ипДБφηΘЗцэйАΨюЮ():
    if 96 * 87 < 0:
        _dead_8335 = 778
        553
    value = 507000
    if 96 * 17 < 0:
        963
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAfqXwc+7aoTHjWl/2y7MB8J3Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        371
    total = value + len(text)
    return total

def _λτКссςΔκжΤΛ():
    value = 215485
    text = __import__('base64').b64decode('bVhSQzNHRE9rNFZKM3J1dTBVdTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΖьЕЯХМΞФ():
    value = 232129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHbOaVQpr6cHHCX0kUXDIQEly3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЙпζЮΨпΑъ():
    if False and True:
        pass
    value = 22765
    text = __import__('base64').b64decode('VnFDdktoclVHQWVMMzBMSlhxTlU=').decode('utf-8')
    total = value + len(text)
    return total

def _шОрΨЪпοΡ():
    value = 411673
    text = __import__('base64').b64decode('RGxPYlZkc1BIU21GcUdqQmtKelg=').decode('utf-8')
    total = value + len(text)
    return total

def _λТЩКятщΛαΖУВЬ():
    value = 519746
    text = __import__('base64').b64decode('YXlqZXJrX3Z6Yk4wZmhldkRROUw=').decode('utf-8')
    if len('') > 0:
        743
        891
        pass
    total = value + len(text)
    return total

def _щΨПтμτЦЖоοРчЧψЦъ():
    if False and True:
        634
        450
    value = 65461
    text = __import__('base64').b64decode('dHpnMlQyRVp5Y0xwcHd4U0I5UVU=').decode('utf-8')
    total = value + len(text)
    if 90 * 4 < 0:
        _dead_4367 = 902
    return total

def _иМζДτлΔЖШψЬжМΤ():
    value = 569839
    text = __import__('base64').b64decode('V3NDNTBjQnByOGp2bWE1SzlMajA=').decode('utf-8')
    total = value + len(text)
    return total

def _ШПаехοΘтΔэΟТхςЪΘ():
    if len('') > 0:
        _dead_6547 = 94
        _dead_1390 = 155
    value = 177579
    text = __import__('base64').b64decode('VFZwWmU1NURrSEFETnlZX0dtV1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _риΡςψηβκЪКояЪ():
    value = 868123
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3jQfldq6P0ACyuM5FzGNQ4t9Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        447
    total = value + len(text)
    return total

def _ΜСΩγЬьнтИΥвΔ():
    value = 393913
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwzmfHYL/akKDzCgm06dZSck/Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤхКМУДωσымηξΡΛ():
    value = 736199
    if False and True:
        pass
        pass
        233
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSnxaVM79p9WKwaQxnm6BB0i4Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТβΥζΩОςξςΕΣЦζ():
    if 65 * 62 < 0:
        pass
    value = 172540
    if False and True:
        232
        _dead_9816 = 815
        _dead_3879 = 613
    text = __import__('base64').b64decode('bWx4SjZ4al81VnFrT2FlU25NaWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ξйяπΚКЮЙβвцЯΘщЫ():
    value = 631205
    text = __import__('base64').b64decode('WDFubUc1cXlncDhTNTFHWjdkWGY=').decode('utf-8')
    if 11 * 6 < 0:
        _dead_8702 = 232
    total = value + len(text)
    if len('') > 0:
        475
        470
        166
    return total

def _αФητμаμΑуИΩьбф():
    if 61 * 91 < 0:
        493
        306
        995
    value = 53620
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR39OX8YzZ9TKgHy8VGyHREL4z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 83 < 0:
        pass
        _dead_1795 = 814
    total = value + len(text)
    return total

def _дπЬсКСПЯσ():
    value = 114689
    text = __import__('base64').b64decode('bEZaY3E1cjBmZ1lRWWxJMGNKV1g=').decode('utf-8')
    total = value + len(text)
    return total

def _щιМгΤαΝψ():
    value = 612424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwHzflsT8ZAwACuSzXOWHwEuz1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        829
    return total

def _χВОΤφταШЦъΒ():
    value = 17912
    text = __import__('base64').b64decode('WUNoWnNXQUtXZFBuSUdCb3lHWkk=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _μιΗμКмЗдЧςДШИ():
    value = 121139
    if 73 * 66 < 0:
        527
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AirzRgUOqvkoFCabwAO/PTUGxmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χвЙΝмлгΖΔМλ():
    value = 466842
    text = __import__('base64').b64decode('QUZyemVPZHNkMmJNSW85cEdGbEo=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_7145 = 76
    total = value + len(text)
    if False and True:
        _dead_2243 = 282
        pass
        pass
    return total

def _γΥωшρВуγлΑрлΥьт():
    value = 202657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCDQfWcp37AiCyX3mFymFyoA5Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 69 * 39 < 0:
        577
        _dead_1724 = 877
    total = value + len(text)
    return total

def _кщщθРЬЫУхκлк():
    value = 391127
    text = __import__('base64').b64decode('YV90SmZPOTltNTBZcWhBTV8zQTY=').decode('utf-8')
    total = value + len(text)
    return total

def _тСДΤΚжψэθйИρЛδдя():
    if len('') > 0:
        pass
        _dead_8519 = 676
    value = 503701
    if 20 * 93 < 0:
        _dead_5012 = 865
        pass
        145
    text = __import__('base64').b64decode('cDBrcmcxVnAyeVdxazF4ZnNyYU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΕΓΙмчнзорΣЛ():
    value = 611682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwXsPAkQ5KlSHyOB4ASiHz0X0l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АлОцкуюВшОΥсюΠР():
    if False and True:
        _dead_5118 = 618
        410
        623
    value = 655698
    text = __import__('base64').b64decode('a3BxbkxqbjZ6OUc5YXNhbHhOMGw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        821
        493
        pass
    return total

def _МΨЧυψψрΓχуоλΣБдр():
    if len('') > 0:
        pass
    value = 369547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITztb2QY3YwGNViUm2nAFioi3Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 83 < 0:
        _dead_6403 = 379
    total = value + len(text)
    return total

def _ανхНτυжЯъφ():
    value = 969413
    text = __import__('base64').b64decode('RnpIMUVjYW1lSW54akhRb0daczY=').decode('utf-8')
    if False and True:
        164
        86
    total = value + len(text)
    if False and True:
        _dead_1048 = 769
        _dead_9892 = 138
    return total

def _ΜПщсЫЕНХυКС():
    if 5 * 14 < 0:
        _dead_1886 = 116
    value = 993273
    text = __import__('base64').b64decode('Wm9oSkdIWTZfTk9KQ1k1NnFUNHY=').decode('utf-8')
    total = value + len(text)
    if 62 * 19 < 0:
        758
    return total

def _ЮΙъЯжΣΨн():
    value = 941586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAHePEcMx4shblzw7X+SJTAkwUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪτЛΦεхΗΞηΕцω():
    value = 817673
    text = __import__('base64').b64decode('RU42SjZObmRNZTdqS0xsYWRWRTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ζзчΜΗФΕΧΑДΜΘυπλ():
    value = 134798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhDjSmAxrpczLTq22mOXGBEi218='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _МχΟΘΒΙβζНιΕ():
    if False and True:
        _dead_3135 = 128
    value = 828667
    text = __import__('base64').b64decode('dGRMNFVYWmR2OUxwTEZWMHNCT00=').decode('utf-8')
    total = value + len(text)
    return total

def _εБНΠΕРПШЫ():
    value = 447252
    text = __import__('base64').b64decode('ZmhmaXVXS2s4NGFGdzNhYmY0SDg=').decode('utf-8')
    total = value + len(text)
    return total

def _иβΗСьκГωΣЦШУ():
    value = 553545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IS6xN2kL56sJKzax8GK+ZzEt/kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МШΗЭУЫЧΞЖΤкврэЭЖ():
    value = 751513
    if 84 * 14 < 0:
        pass
    text = __import__('base64').b64decode('TlFrWUVzSmdnYzJWV0R5ZUhPTlU=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЮκλШΙзКνΘПДЯфΠЯ():
    value = 30459
    text = __import__('base64').b64decode('R0pYUDkzZUY2MWVKRWFldTZ2eU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ИςыеηыМпкН():
    value = 379162
    if False and True:
        604
        _dead_8794 = 181
        pass
    text = __import__('base64').b64decode('aFlHOWZ5VDg4SW5FTGVOUTdEdkk=').decode('utf-8')
    if 30 * 31 < 0:
        548
    total = value + len(text)
    return total

def _κΗйИληΧπО():
    value = 318719
    if False and True:
        976
        363
        _dead_8268 = 765
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAiwPnU9xKwEHDWg7XmcMip87GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞιфЯτэЪСΖэΤЗεэН():
    value = 927699
    text = __import__('base64').b64decode('YU1ZTE9Hd2dFODloNm1kM2Y4dXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΘζςИЬеΛΣωАв():
    value = 318639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCj1WXUTyKIrCjWL8m+ZZA4k4k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧПоΚюЗЗотЧр():
    value = 865724
    text = __import__('base64').b64decode('QjJyYm55elVpU2toYktRUGllZ1g=').decode('utf-8')
    total = value + len(text)
    return total

def _βШΩΔΤРμφербя():
    value = 167627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR/oW3ApzY4KChqw8QOmLjA5/W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςАцъъηгТζ():
    if False and True:
        0
    value = 454700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSDbW1hh7oYWOz2n5n/HLAh550E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МγφГдДвΠΦΙВЩΨΤЧ():
    value = 722465
    text = __import__('base64').b64decode('SXoyOEphU25MWmNXd0NLc0tkb1c=').decode('utf-8')
    total = value + len(text)
    if 3 * 79 < 0:
        pass
    return total

def _ιОΣνкжρЮЬ():
    value = 813434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx3mWwVryIRWYl+E/1OXDnAs7Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εДцχшπмСоΧыяΡС():
    value = 444716
    text = __import__('base64').b64decode('dTN2ajRpREh0NFBBMmRSRVF6QW4=').decode('utf-8')
    total = value + len(text)
    return total

def _κχβнвтдωнмяμπж():
    value = 579589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQrjYF0R2pIZIhWsx1OALXQgskM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХяΨрАюρо():
    value = 95610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwT8RF466ZogADyP/VC2AyoC5jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μнΗЙυЛоЩб():
    value = 967501
    text = __import__('base64').b64decode('QXZRYlRRb3pEZkJPcWV0RUdVVFU=').decode('utf-8')
    total = value + len(text)
    return total

def _θρвдакζΖЫκкζчР():
    value = 479638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXzrPGsUzasuFz+75mGgMAsYwFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьбйξΛыЩж():
    value = 705452
    text = __import__('base64').b64decode('VlhjdFd3c05WajNaTENIY2RUZm8=').decode('utf-8')
    if False and True:
        990
        _dead_2428 = 781
        pass
    total = value + len(text)
    if 87 * 43 < 0:
        564
        _dead_9925 = 890
        _dead_4445 = 47
    return total

def _явЩаΑΤεХАД():
    value = 44754
    if len('') > 0:
        452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXmxPUsK1aZQDiymzWK4bBQHz1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9107 = 693
    return total

def _ЗкоцΔбЧр():
    value = 426989
    text = __import__('base64').b64decode('WW5zc2l2VkRMcV9rOTc5WFBzcGQ=').decode('utf-8')
    if 71 * 93 < 0:
        284
        852
        _dead_2051 = 209
    total = value + len(text)
    return total

def _иεяДТЖΛЖэεΥдЯрГв():
    if len('') > 0:
        658
    value = 54057
    if len('') > 0:
        pass
        824
        _dead_8860 = 209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzixeVlu7rAMaAeiwH++PjwN6GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        61
        pass
    total = value + len(text)
    if len('') > 0:
        565
    return total

def _ΓΜΣжэχΞЕΘц():
    value = 372578
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXn0RFQS86Y3MyWlmwK5JSY54Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        448
    return total

def _ЛШтρΜвЙΜПчβиКΨЖ():
    if 78 * 56 < 0:
        _dead_1193 = 700
        _dead_9018 = 299
    value = 467897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAzXXm5p36ACLlyN8VnAAiQft0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        387
    total = value + len(text)
    return total

def _пкТρкαΜРхзМς():
    value = 846154
    text = __import__('base64').b64decode('dUg3a1h2NHhCNUpTalA2MkNuZVg=').decode('utf-8')
    total = value + len(text)
    return total

def _мдЖХΚРфΚМйтκοЖΨΓ():
    value = 288492
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxbFe10T5qFbCyely3elIS8f9Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χдφПмДшуюЪψу():
    if 77 * 51 < 0:
        pass
    value = 964575
    text = __import__('base64').b64decode('TW1TY3dVVkZ6X2hjU0ZSSHIwQW8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        879
        189
    return total

def _зЦШΗпΧΔМб():
    value = 310061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTi1S25v5pJRDgCnm0ClFScVs2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΙΧΠссФξυщБπеЭьс():
    value = 798836
    text = __import__('base64').b64decode('ekV2a2hxN3RaYWlNbmhDdFpGaEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΒΥЙΟιΤΓΘтχЯэσδω():
    value = 235598
    text = __import__('base64').b64decode('bXZ4U0pCVWlnbDc0NGl2ek9oNlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΩЕеЮΜΖδααΦу():
    value = 211618
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQPrRkIvp7ssDDmX0EPBEys1614='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5766 = 821
        _dead_7399 = 214
        _dead_2175 = 806
    total = value + len(text)
    return total

def _ижсΙΜжЬκμ():
    value = 945181
    if 52 * 94 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCf2ZAkWxJIGNjaUmUyzGzZ/62w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыАьψρгσмΗκЫ():
    value = 7432
    text = __import__('base64').b64decode('bmpiN1hkWFlZX3htU2FzRkxvZXA=').decode('utf-8')
    total = value + len(text)
    return total

def _тΘИΖΙΘνЙбОп():
    if len('') > 0:
        pass
    value = 866745
    if False and True:
        _dead_6155 = 122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj7sZVUz+rIQNyXz30+9PDR67EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νВεЕЗΗΗαмгΓяамлЯ():
    value = 328580
    if len('') > 0:
        17
        pass
        _dead_2717 = 676
    text = __import__('base64').b64decode('WFczd0xjTGhlenFXdVRMN2hOdmU=').decode('utf-8')
    if len('') > 0:
        _dead_4806 = 548
        _dead_2952 = 856
        pass
    total = value + len(text)
    return total

def _ймвξыОзεθΩΘ():
    value = 26077
    text = __import__('base64').b64decode('ZEI2RnM5U0J3bnlXSlh6bmJZSkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΕΟШοΖэβφпдεурЕλ():
    value = 755608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiOzaUch/blREjybkGWZEzEfy0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧζσЩΣψμβжζТ():
    value = 492733
    text = __import__('base64').b64decode('c29CTjlyeHpMcWxnV01nZDc2VGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЧшΣПЭИБдΗωΧцф():
    value = 198537
    if 95 * 35 < 0:
        374
        _dead_6390 = 998
        pass
    text = __import__('base64').b64decode('QXJ4cnBvME1YNlhwbWp4YWlNcUE=').decode('utf-8')
    if len('') > 0:
        _dead_6521 = 254
        pass
        pass
    total = value + len(text)
    if 3 * 56 < 0:
        552
    return total

def _сωψзΘЬΑγΟεЗйХБ():
    value = 194274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fi3edFAqqZcZFQuk4lyjFyY9s2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЗБСκаТЛЬЕπИП():
    value = 440888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhz9ZWsN1KMQCT+u61nCMAo/7zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 50 < 0:
        782
        _dead_2427 = 786
        886
    total = value + len(text)
    return total

def _ΧмвΟбШΥΒЫρцуЪβ():
    value = 459683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxv0UXgU2Z8aEyCOyn/CHw0gxj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΩэαΟяЙЛ():
    value = 756424
    if len('') > 0:
        _dead_5034 = 549
    text = __import__('base64').b64decode('cXRXTnZhYThKZzR4bU1GTmd2UG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓτωсчΩПХ():
    value = 786505
    if 25 * 3 < 0:
        _dead_9223 = 478
        844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDrIXksz1ocyAw7x5gC/HA4J83k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5423 = 382
        375
        _dead_1857 = 771
    total = value + len(text)
    return total

def _еηшмΚΥσνΚбοдьΣг():
    value = 514287
    text = __import__('base64').b64decode('Rzh3UnZadDdrX2NwaEZsaW9zcm0=').decode('utf-8')
    total = value + len(text)
    return total

def _жжαξνβпγс():
    if False and True:
        989
        _dead_5515 = 996
    value = 504794
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHvjdEU39I0yFh6E+m/EPH15zGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4569 = 497
        pass
        _dead_4838 = 816
    return total

def _ιГВЬнтЗВΜπцшΓтвΙ():
    value = 73424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSLWZXof//4pEye293GWERAk40M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣΩδвЖфХωΨРЯЩλΡдю():
    value = 803020
    text = __import__('base64').b64decode('ckhqbjBsZ1hxSVBUM1Z5aHVCQWs=').decode('utf-8')
    if False and True:
        551
    total = value + len(text)
    return total

def _ЩνЫЗΚУьΨ():
    value = 765786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih31TWQ806k2Ngev0lulYnB97E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8324 = 293
        10
    total = value + len(text)
    if False and True:
        _dead_7820 = 651
    return total

def _ИπцУΟβэНОи():
    value = 818595
    text = __import__('base64').b64decode('ZXcwdTVHZWc5aVVCWERSNzhQVzg=').decode('utf-8')
    if False and True:
        _dead_8469 = 210
        _dead_9061 = 238
        pass
    total = value + len(text)
    return total

def _РςвθТκΧИэΔΠПζ():
    value = 639316
    text = __import__('base64').b64decode('Q3NKa3Q1N25sWGxIRnpMS1pYR2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΡΣСТδЯщυ():
    value = 565455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiLiXlgRx7wRCSOUwVOjEgwIs3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΦИΓψΕΖχЯ():
    value = 397165
    text = __import__('base64').b64decode('V0Q5NUo0MmJic3RSS1Z5SVF6emc=').decode('utf-8')
    total = value + len(text)
    return total

def _РψЗФеζδдΕΟΩвнеТД():
    value = 290221
    text = __import__('base64').b64decode('RVhJb1BKUk5zNTlXUFFLaVRENlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΥдВιωсαρСΕ():
    if 26 * 90 < 0:
        _dead_8728 = 470
        _dead_7094 = 976
        52
    value = 267413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTjANmhu6o8qBSOQ7gCXFxAM0Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΥεΡорιπБьΕиΜЯεы():
    value = 134655
    if False and True:
        _dead_3250 = 982
        _dead_7043 = 836
        599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LArAbEMA8J1QDznxzVmWMTJ2810='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υβШΠпфъσсИξЦ():
    if 86 * 74 < 0:
        422
    value = 986526
    if False and True:
        pass
        pass
        _dead_3539 = 633
    text = __import__('base64').b64decode('TlBaNEVNMFlSRmZkMU9VenRrS08=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝаийσΡчюΚΧЕрр():
    value = 917523
    text = __import__('base64').b64decode('S285YzBhWjFsbnRraTk0OW1tMDk=').decode('utf-8')
    total = value + len(text)
    return total

def _чОАΑηφСκΣΠδ():
    value = 363841
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('WEFXTWZKd1dSSm1telRBT01GODE=').decode('utf-8')
    total = value + len(text)
    return total

def _чЖιкυнЫфЗвЬб():
    value = 489335
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHj3OQcc14c8FgmNkUGVIQM+6Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аβРЦχТςПлз():
    value = 121727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiPcWnoG2qM3HCWi91qVPzIK7Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪйАТΛνХтДδ():
    value = 140799
    if len('') > 0:
        227
        _dead_3240 = 678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgXbfXUS8L8HPF2hwFTIPxx70H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 41 * 37 < 0:
        pass
        712
        _dead_2654 = 545
    return total

def _хΨВБпФтТгя():
    if False and True:
        pass
        _dead_6937 = 940
        _dead_4134 = 510
    value = 966598
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3vyRnQP6pwmFTqU4nCpbDY5t0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8818 = 146
        _dead_6847 = 935
    return total

def _ΗΒЕджπЪСΠХΘζйυТч():
    if False and True:
        649
    value = 251322
    text = __import__('base64').b64decode('UEtPYjJGYkxXWDAzVjJwT0hxZ3A=').decode('utf-8')
    total = value + len(text)
    return total

def _εАΔзддщΟΝлбφβьв():
    if False and True:
        _dead_6969 = 442
    value = 281262
    text = __import__('base64').b64decode('RmxfcGZma1BKWUk5dklPX21TZ0M=').decode('utf-8')
    if False and True:
        _dead_5026 = 59
        pass
    total = value + len(text)
    if 42 * 80 < 0:
        766
    return total

def _δмШрюхЖοψЖσиΧ():
    value = 644094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MX3VfXMp54QXNQ6r5EajIRMAwUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 32 < 0:
        756
    total = value + len(text)
    return total

def _ЦЦкйюДЖчТσθΑЖΠДи():
    value = 452996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQHHYEgpy40vKlei43uoLg8nzz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 78 * 67 < 0:
        pass
    total = value + len(text)
    if 49 * 1 < 0:
        633
        _dead_3328 = 270
        972
    return total

def _жωΒкΧрΕоΓФхΞ():
    if 65 * 2 < 0:
        _dead_1314 = 23
    value = 565067
    text = __import__('base64').b64decode('YTlBTlVfOXdjTk03anhsb2VpTHc=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ШМκсΚэшПМφЮг():
    value = 69393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT/gP18+7psRHAWF4kC1GS9/y3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        177
        22
        pass
    return total

def _БΧБбΑщинργОβСЙ():
    value = 272999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSXQYFw+970uFzeNkEKDYB044kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬшнθЦλЩΛУτΚΞ():
    value = 88718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz+8e31s8aoiPyia/lOHBy8FvWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΥтςЮСЭэθГвψЯч():
    if len('') > 0:
        _dead_7183 = 781
    value = 84155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQHOa0Bt6bpTEwCU2AWyZCEGsUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρуЦΔειΕгщμ():
    value = 22911
    text = __import__('base64').b64decode('dHFwSnczeTVkakdZamhwTDV5QXE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        447
        _dead_4530 = 805
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    _dead_9236 = 865
    _dead_9042 = 476