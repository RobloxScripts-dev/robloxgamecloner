#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ЙЯТΡΚΞΒμΚΓΚЭщ():
    value = 429886
    text = __import__('base64').b64decode('SHVXcnFoNFFjRUVRT2tFSkU1TjE=').decode('utf-8')
    if False and True:
        423
    total = value + len(text)
    if False and True:
        pass
        _dead_6634 = 858
        846
    return total

def _ОйЩτнЦДНΙъ():
    value = 230040
    text = __import__('base64').b64decode('bTJ2VklaOEdsRnlLejk2eVlHbEw=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _φΖкпясНБΧФΝкСЮК():
    value = 918157
    if len('') > 0:
        73
    text = __import__('base64').b64decode('YjhBYTNWRFhkeW1TY1hkTm1mUjc=').decode('utf-8')
    if 72 * 41 < 0:
        667
        _dead_5941 = 774
        _dead_1994 = 234
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2449 = 761
    return total

def _ΔςКγχЛпвмΚΖΙ():
    value = 504950
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhjAN1wQ2oYPFCKk7gS5MiY+wDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чяιζχπΔмГАμχоч():
    value = 758889
    if len('') > 0:
        pass
        655
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgnAPHM/pp9VHR+K3lPENT0p73k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9691 = 929
        _dead_8280 = 293
    total = value + len(text)
    return total

def _ИжπΞβμсАΟАб():
    value = 599976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBizX30+zr0lFCn16mOYZQA5z0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯμоАжЙщφκτιь():
    value = 64427
    text = __import__('base64').b64decode('bVVObmZRQXRTUWhFRWQ3WERDSVo=').decode('utf-8')
    total = value + len(text)
    return total

def _σωοΑеЬΥΤθмк():
    value = 944139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCbKPwUXyYw5aCTz8XrHH3M4wHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξеВΘхЮξЩΙрЯ():
    value = 998778
    if 87 * 38 < 0:
        _dead_2796 = 534
        _dead_1988 = 335
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnjrW2gLxPtSNByn93yBNj0L5Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_9449 = 379
    return total

def _ъыЩдЗΓξЩЖЦС():
    if 87 * 37 < 0:
        pass
        261
        _dead_1474 = 642
    value = 350797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj+8Z2AM6aIkKBu55AeBPXIbw0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηУΙοрчбЙυΡлЧΤф():
    value = 913132
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjrTW2cI14MKCT+b2nq0ASwHwHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шπχбБοЮЫРγδΨ():
    value = 347659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JinPQkE4ypgsNgTz5FrAPCkXyUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θНСεиΦфΙηпΦΛΨт():
    if len('') > 0:
        pass
    value = 92736
    text = __import__('base64').b64decode('VUNqbW5TVHBtdEZrbGlVSU14X0Y=').decode('utf-8')
    if 23 * 34 < 0:
        523
    total = value + len(text)
    return total

def _ΞΔιюβМβΖΚъЗьйк():
    value = 690688
    text = __import__('base64').b64decode('aGpMQk5uX3VMQ1NIWWV3bDN1WGI=').decode('utf-8')
    total = value + len(text)
    return total

def _БъжωΩκмЯдΣ():
    value = 427433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAnBWV4fqpkTHymv21DGBh0btmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 90 * 44 < 0:
        738
    total = value + len(text)
    return total

def _НΘьпхΡδξ():
    value = 713955
    if 56 * 78 < 0:
        _dead_8412 = 359
        _dead_1658 = 92
        _dead_4060 = 137
    text = __import__('base64').b64decode('RFZjdmFxNGNlcjM1WXNhM0FuazY=').decode('utf-8')
    total = value + len(text)
    if 24 * 87 < 0:
        pass
        42
    return total

def _дΝΥΨΒζхмзИШлεИδ():
    if len('') > 0:
        pass
        _dead_4125 = 482
    value = 270695
    if 34 * 47 < 0:
        pass
        _dead_1241 = 326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwDMO3Q6r/EREV2r/wWDBDMCtXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩцκЬЪβΡц():
    value = 510525
    if 80 * 75 < 0:
        _dead_6194 = 965
        _dead_3396 = 811
    text = __import__('base64').b64decode('c1pKT2NRQUhrVlJwR2NCNTliMHQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6284 = 631
    return total

def _ЛЯτУУΒгТЯБ():
    value = 119129
    if False and True:
        pass
        _dead_1606 = 656
        _dead_8124 = 574
    text = __import__('base64').b64decode('SFhWbVliUmEyRjJUUEdsVFNUSW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ξСΥКΖρψΜЬиьЖζфС():
    value = 543836
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwG3W1UrzaJXbB6ozV24MCp+9Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓУВиςωЦуВ():
    value = 104247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjbKXAco+p0XCRuK+1rBMxJ611Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥюΒсШЯкшюΞζθВςБд():
    value = 329404
    text = __import__('base64').b64decode('WDhPeHppeGhfWGFkY1d3TG55WmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _згΘτЯхвдΨπ():
    value = 589127
    text = __import__('base64').b64decode('VFE4NDZtcHRZaTExa1VkRXQwZTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΓξЗЧηХкЖΓξЫκς():
    value = 174170
    text = __import__('base64').b64decode('SGpmd09IYWNUclJVRVp6RFJ5cU8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ьцУΝΘγШВИΑΚм():
    if 18 * 36 < 0:
        797
        pass
    value = 292429
    text = __import__('base64').b64decode('a0EyS3RMclFnVmdydlFaTmV3OUw=').decode('utf-8')
    if 3 * 3 < 0:
        pass
        _dead_8361 = 886
    total = value + len(text)
    return total

def _ιЛТтДПЛрЬфζаτδЮΖ():
    value = 258638
    text = __import__('base64').b64decode('WnFxZDVMV1ZzZkJMb0pwNTR0OWk=').decode('utf-8')
    total = value + len(text)
    return total

def _лМовъςΙκΥсκ():
    value = 971192
    text = __import__('base64').b64decode('b3NTVXRzcDJFX3Z1aXlkbHRMV2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _АХΝΟФΧδΞЧщςγζ():
    value = 485399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyHwd3Mc5PAzbwyR4WSjNnQa4ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σТρЖΨрАЭДльВΡ():
    value = 647664
    text = __import__('base64').b64decode('Z3pMTjhzWTg3dlRPeXhoYTBpc3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ιМЦκΨуΣΤιΟθΛιχтΗ():
    if len('') > 0:
        pass
        pass
    value = 93224
    text = __import__('base64').b64decode('dXBEellNbExFU2x1Vkt1ZndfaU8=').decode('utf-8')
    if len('') > 0:
        _dead_5161 = 685
        529
        439
    total = value + len(text)
    return total

def _чыМЮкщтдСνнЯΩЛ():
    value = 327624
    text = __import__('base64').b64decode('eE1sOFd3eU9sRDRMMUpzdThlZUI=').decode('utf-8')
    if len('') > 0:
        _dead_9008 = 251
        _dead_4147 = 624
        872
    total = value + len(text)
    return total

def _ΣΧγΧоτФлв():
    value = 282027
    text = __import__('base64').b64decode('b3p4NmVMckExRm5PcThsTDlOT2I=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2257 = 13
        _dead_1827 = 852
        _dead_5956 = 184
    return total

def _ЮЧλθκνОаЖФθηΛюΘ():
    if len('') > 0:
        _dead_8499 = 136
        291
        557
    value = 935260
    if False and True:
        _dead_4933 = 769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCX0T3c20IwxHxew/ni8JT0Ntng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 78 < 0:
        444
        270
        308
    total = value + len(text)
    return total

def _ИΚьηοХзΕβзывРΜ():
    value = 115093
    if len('') > 0:
        _dead_2013 = 326
        _dead_8517 = 65
        760
    text = __import__('base64').b64decode('VWlWckhyc1FDYm1sWHJKZ3ZLQlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭπΦςЦДТУεщρΣжЗжМ():
    value = 123639
    if len('') > 0:
        826
        pass
    text = __import__('base64').b64decode('elBPSF9xXzlQOXRiSF9ldENSZ2U=').decode('utf-8')
    if len('') > 0:
        _dead_7577 = 768
    total = value + len(text)
    return total

def _оОΘТщμцτρΟдСΞτЭ():
    value = 906506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAXRdFgB2pI1HSGnmWPEZBYJ/Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 39 < 0:
        _dead_2923 = 199
    total = value + len(text)
    return total

def _РьΘΤΝяωфщσкΓмИЬы():
    value = 825798
    text = __import__('base64').b64decode('VThOa0Z2czRYd3QzM3JxZG5jWGY=').decode('utf-8')
    total = value + len(text)
    return total

def _КΜυХякυΠΨ():
    value = 633841
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQzSXWNu+rg1Hxr0kUeUPSEE22k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 20 * 97 < 0:
        _dead_8409 = 826
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _жψΒрШεЪΗ():
    if 2 * 84 < 0:
        _dead_4959 = 890
        575
    value = 375399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KC7jSVwBqY5SACKGww6TPi0/9ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 95 * 14 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ьΜхнτтИЙ():
    value = 928359
    if len('') > 0:
        427
        pass
    text = __import__('base64').b64decode('TXY0TkpPQnRKekR1THFCdmMzME4=').decode('utf-8')
    total = value + len(text)
    if 50 * 100 < 0:
        _dead_1071 = 162
    return total

def _οΞςρъЭΤЛЩжШЪΕэО():
    value = 721444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3f9Qggt75gtAwi6wHeWAQIJ0Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2364 = 350
        866
    total = value + len(text)
    return total

def _ΨλкЩъЯтξΚ():
    value = 340920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CD7RQVoO6KQNPl+G50OiESQm7Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Θωπσзωμгь():
    value = 647774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyvgVEQPpv8BLBv22kWgZBo81Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 52 * 75 < 0:
        pass
        26
    return total

def _τЭдИΖΚнпφκЧммъ():
    if 43 * 70 < 0:
        pass
        pass
        pass
    value = 855366
    text = __import__('base64').b64decode('bnJQbTY4U2p1S0YyWk9OR1RScjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _πΚΚζКΞФЧΡшχш():
    value = 296495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyLwZnwAxvpRbQj1w2+4bS8Lz14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УИψРаСΦωΜкУΡΡлНα():
    value = 987877
    text = __import__('base64').b64decode('RGNLdHdJbkU4QllaV2RuNkdvRk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΖβоЖΤЕΑ():
    if 62 * 29 < 0:
        pass
    value = 570398
    if False and True:
        681
    text = __import__('base64').b64decode('aGVuYmdfS2VPT0NoN2dCbldPSVU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        163
    return total

def _ωοУΙΣнΑβгПΖΓ():
    if len('') > 0:
        97
        363
    value = 588242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBywYkcJ1YsLGx6RzFKSAwsst0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 26 < 0:
        730
    total = value + len(text)
    return total

def _ΣъСρЦгоΓγΛс():
    value = 705584
    if 28 * 86 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgXTRnwQ545QMCGGmAavDiskx0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФисУιΑΣξνъΡΦУ():
    value = 449356
    text = __import__('base64').b64decode('eHE1OUhGSHhsRDZNZHVqeTlTbUs=').decode('utf-8')
    total = value + len(text)
    return total

def _йШΑдспФΦЦ():
    value = 614408
    text = __import__('base64').b64decode('a25nU1Ezb0dEVDJ2eXlqZkZDSVE=').decode('utf-8')
    total = value + len(text)
    return total

def _шθэпцΖЭβι():
    value = 996965
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSnFe0Bs1Zw3EQmgnVObGTU94zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сКЦΑΩζэαТΔηξЕ():
    value = 286820
    if len('') > 0:
        pass
        pass
        _dead_6953 = 689
    text = __import__('base64').b64decode('bTU3MFo2TURpTXBXSlVSbVc1Z1E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _ΞΨЭНГΘщдЮ():
    value = 577580
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjnTV0U1xr0NNDD38X6jLH0kx2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΟнψАиΔξΚДсΦшэ():
    value = 721969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDWwTWg03asmECH6wUO+YRI1skQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡοΟΩΕъΒзΙОΚαМΞС():
    value = 919175
    text = __import__('base64').b64decode('UzhyeEhXbE80Tk42NHhOZWkzRV8=').decode('utf-8')
    total = value + len(text)
    return total

def _цЫцΧяфнывГвεΚ():
    value = 982999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj7+d1Av6foWaDC6xHyDBjEu/n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        792
        945
    total = value + len(text)
    return total

def _ψθρΟΚлΣИ():
    if len('') > 0:
        pass
    value = 497433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw7QaUEKqbwgEj+M+kypIxN26mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЧБξΨэшΣтΘЩιЦθ():
    value = 242516
    text = __import__('base64').b64decode('U3hQemlHcHdWcXN6bzB2R3lJRUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘζАЮωΔЧуб():
    value = 487784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB7hWlQt+f0MLV+ynEWZERp28mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πсЙЖЛуΝΚЦАΛΝΧЪ():
    value = 231206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAb1NkAs1PEKaCqu3k+DZAQA4Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥНαδΚЮΠΤДΔρεΙ():
    value = 429030
    if False and True:
        0
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lzb+NmgwxqUqEQWFmASKGj8O3Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        62
        773
        _dead_3606 = 421
    total = value + len(text)
    if False and True:
        _dead_2303 = 413
    return total

def _аεФУδΡОшОъ():
    value = 35704
    if False and True:
        _dead_1455 = 648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhfgX11ryvoVFB2M90HIIhF850k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        546
    total = value + len(text)
    return total

def _ИΜуηБДРБυфпЕΧ():
    value = 539507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D32zS15gwf0UPCCXzwSiLjIX7Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нцЧьЛκςУτΥсКБ():
    value = 323492
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dyi1WXIUrZ4qIj2H9wCEIAcm9m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        63
        851
        966
    total = value + len(text)
    if 51 * 48 < 0:
        pass
        938
        _dead_5334 = 658
    return total

def _аΟобрεβжΤБ():
    value = 547406
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXr8SGQO1KAWIzeG7E+XYgd89FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζчΒΘЯγιмΨтλФую():
    value = 551666
    if False and True:
        680
    text = __import__('base64').b64decode('ZklLMnAzS01Wd0ptaTJnZVJLN2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЧδωьэЬΓВуΖГηΗΑ():
    if len('') > 0:
        pass
        815
        _dead_2422 = 672
    value = 366838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARbxT3gu8ZglADWR/GyJYRwr/Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7825 = 219
        pass
        44
    total = value + len(text)
    return total

def _ωБЩатжюочζЩαΜцΣ():
    value = 444642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSSyWFIGx78zNlv791y7JXEbxXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РХфωσкΧπйЪ():
    value = 513592
    text = __import__('base64').b64decode('aHZ0ME9iRFp4U2pMaElxNkZCRE8=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΑФжЬρЕРЖБфШδ():
    value = 770290
    text = __import__('base64').b64decode('Yk5mZlVPR0l2S3RIN0V4bHR5WXE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1130 = 579
        _dead_1383 = 51
        pass
    return total

def _μхΝπлΕьрΥ():
    if 68 * 68 < 0:
        366
    value = 962850
    text = __import__('base64').b64decode('TGZtMXBMVUxnZGl4UXRDUkd3OFU=').decode('utf-8')
    total = value + len(text)
    return total

def _БΟΖιιчΧхκΠ():
    value = 120434
    text = __import__('base64').b64decode('WXJKdGNrWFoyVEVMajVxdGFRZFc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЪτФзΔΞмбпГΝЧ():
    value = 405216
    text = __import__('base64').b64decode('T19ucHVOU3NXM2ZtM0xlQjl2aTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΓъУЪМεЭЮΛЕРуеч():
    value = 520193
    if len('') > 0:
        829
        _dead_4413 = 493
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiHFeQYRqYYTHFuP+nCqGSMBs0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞпιшКвуδЦй():
    value = 549048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnjdTW4d5PkpKAiyyn+zY3ch6FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πрУютСвυΘΟНφО():
    value = 213387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NC3cOkUywblVDTaR0kGDHBoiwn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АНъАΑΛОа():
    value = 254781
    text = __import__('base64').b64decode('WkUxZ01ZbzBRNFZZOWloQVFpVlI=').decode('utf-8')
    if len('') > 0:
        _dead_5774 = 531
        537
        pass
    total = value + len(text)
    return total

def _αиΨεцРΟюб():
    value = 720385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnfAVnkM0YQqP1qc5mSiHSIK7zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λсЗβЮΤЛφНπψΗ():
    value = 624900
    text = __import__('base64').b64decode('S2h1N0Zmc0E5eDRtS25fS2NpUkk=').decode('utf-8')
    total = value + len(text)
    return total

def _цйφХУλЮяЛΩΙыЗЫИс():
    if 24 * 12 < 0:
        546
    value = 695934
    text = __import__('base64').b64decode('UjlpQlBaN3R3TEltdHk1MTd5MnE=').decode('utf-8')
    if False and True:
        _dead_2401 = 32
    total = value + len(text)
    return total

def _РфЩДΟζЙтΨЛВιΚд():
    value = 931810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCXRbQcS//FbPAOWzlG1Yyw8wUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖтσΑΑΤΞюλΠФ():
    value = 875649
    text = __import__('base64').b64decode('TjJKMGU2SXc3VWo4T1JzaGpIYVY=').decode('utf-8')
    total = value + len(text)
    return total

def _бжΕскΗΕУк():
    value = 872331
    if len('') > 0:
        625
        354
    text = __import__('base64').b64decode('b1hXVTRfalJjaGpybGIwUDRKZ2s=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4154 = 357
        245
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _АхеИлΧτΤ():
    value = 717170
    if 22 * 7 < 0:
        pass
        138
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAfbSFYYz5EJFhqxyXKqAQkG0UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ткБΤΓвτΑ():
    value = 829598
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LT/mZGI2+IpTMyjx/36SPAMi62I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪфΘкΤХζцλШББычж():
    value = 675886
    text = __import__('base64').b64decode('SWEzX2xFU0pHMHRyaWNzbkd2Njk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_6011 = 592
        437
    return total

def _щΡЖЬχθЕΦЯэ():
    value = 772979
    text = __import__('base64').b64decode('Y1J5SW9feVQ1bENQRmc3NzJ6QlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЖπрΨκουъйсΥ():
    value = 380690
    if False and True:
        pass
        pass
        pass
    text = __import__('base64').b64decode('ejlpWXRQdDNLbGcxakl3ZnlXUmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _меЖΜφεЖΕГйΤΞΩпЬС():
    value = 136402
    text = __import__('base64').b64decode('SW1nR2xwRWNYa21JenNxV0RtUlY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗЖΖУΩΝиюΓпηпЦμΟς():
    value = 266879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3vgTX5uqaA0MQ2GxGCROREpzVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κπПЬгωχνЮτЛСεθо():
    if 88 * 79 < 0:
        174
    value = 45508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAb2SwAxqp4TCTml4X2CYwsLsWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙШγНΤызИУШ():
    value = 140311
    if False and True:
        706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHrLN2Vv2acgGxyHxg+jPnQ9wEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        787
        339
    return total

def _ΒψДиЯΑθνоζ():
    value = 989177
    if len('') > 0:
        379
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBzvPAQhra1QAx6c2XK4GC8jvGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еРЬΞλтШπЦνмЮЩЫυ():
    if len('') > 0:
        pass
        788
    value = 74296
    if 22 * 93 < 0:
        _dead_5047 = 234
    text = __import__('base64').b64decode('czNPOUF0QjR2c3ltSm1pMEJWejA=').decode('utf-8')
    if len('') > 0:
        _dead_2843 = 163
        pass
    total = value + len(text)
    return total

def _ζСшЛΝФЕθЩψРζαΦЫ():
    value = 345567
    text = __import__('base64').b64decode('c1lpNmp6a2daNnE0Z1VkM3VGbG4=').decode('utf-8')
    if len('') > 0:
        pass
        37
        pass
    total = value + len(text)
    return total

def _хиХΕξΗΓВωэШυш():
    value = 258040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3nsaFcd6YsEaSGK4GyqZXM4tDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΧфеχЛυцйЮΙХγГ():
    if len('') > 0:
        _dead_5702 = 409
    value = 866876
    text = __import__('base64').b64decode('bmFhdVNYOEw0WDZOX202X1h0enQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ζШЕщεПщэμιΧУьςгЛ():
    value = 256065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChfTVn8BzIEZFgismX7JDHc34jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤТвοΟνχζй():
    if len('') > 0:
        625
        388
    value = 739868
    text = __import__('base64').b64decode('SGFEZFV6Z2ZsdzZRQnd1TkRkdV8=').decode('utf-8')
    if len('') > 0:
        _dead_5132 = 23
    total = value + len(text)
    return total

def _уΩмЮбяйΨρε():
    value = 873495
    text = __import__('base64').b64decode('eTFZaXMxQ2hJd0Y4Z3FTRDJ4dUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠюμΡфνьЕЮΛПЭзΖЖх():
    value = 471347
    if 32 * 100 < 0:
        577
        pass
        532
    text = __import__('base64').b64decode('YVF0VHA0TEhVVktyR3MzWmRpX0E=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΖУЫВξиτεИχΔЪσξсΞ():
    value = 193760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HynlQEVv+LgMGxn2wEWSPg4+7k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘτΣчωБДлΠнжλтψШ():
    if len('') > 0:
        _dead_4999 = 48
        913
    value = 527648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhXlfQgU7psqOFaCxXWpZzwX/Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чζЬνАбυΨРЮΝоΜ():
    value = 960424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDjWY0IW3Io0PFeczFOjOC8twUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХπлЮΨΧГΔыЗФνΡм():
    value = 974133
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MX7FQXcP+5oIDwuL/WCHFgAo7EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _АΥцгΔΑЫΒγРВЯвнъ():
    value = 155613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg7QWUIzra8HEg2EkX6BHXUs4Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УζЙΖΣэЗтππ():
    if len('') > 0:
        439
        pass
        955
    value = 193438
    text = __import__('base64').b64decode('bzJJak9NeDl1eFZLU0N6WkoyZVM=').decode('utf-8')
    total = value + len(text)
    return total

def _σηрэчΔЩΣΣмΞФ():
    value = 234574
    if len('') > 0:
        _dead_3920 = 791
        _dead_3276 = 118
        pass
    text = __import__('base64').b64decode('T3NhWXlFTVJremJYc3pIbFJPbnI=').decode('utf-8')
    if len('') > 0:
        pass
        540
    total = value + len(text)
    if 84 * 11 < 0:
        pass
        198
        pass
    return total

def _φЙΗΦПΠνυΤΗУДМя():
    value = 283701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRqwQWUh8oItGymA526gDSB63mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЙхпцвμоπγοιу():
    value = 749802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dw38Z2I65IE2FS2l52W8Yho71FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 41 * 32 < 0:
        575
        _dead_7857 = 758
    return total

def _тιυΤцψГΝуΒΓΘя():
    if len('') > 0:
        pass
        pass
        _dead_2716 = 833
    value = 138585
    if 50 * 47 < 0:
        pass
        _dead_7249 = 224
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwfCVmQT2LwobDiQmA6ELgZ48j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЬΠФλлεΤТг():
    value = 355342
    text = __import__('base64').b64decode('VHJ4bkk0aHBfUjZtSWlQbzMwVms=').decode('utf-8')
    total = value + len(text)
    return total

def _НЩСеПσΥАснΥλΘеΥо():
    value = 853066
    text = __import__('base64').b64decode('VGx3bkFzUWpDVEEwTURFalI3V2k=').decode('utf-8')
    if False and True:
        _dead_6770 = 426
        pass
        961
    total = value + len(text)
    return total

def _уйζΗлιИηωГлνЪχ():
    value = 56243
    text = __import__('base64').b64decode('a2JTNXRNVTVQQzZGR2RNclpvOW4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _оθСΩГКβοΣЧОеτΩ():
    value = 883289
    if 29 * 12 < 0:
        850
    text = __import__('base64').b64decode('RFFyV3M1N2tENUN1S2FHWHNZcEw=').decode('utf-8')
    total = value + len(text)
    if 95 * 99 < 0:
        _dead_8125 = 773
        _dead_2702 = 900
        pass
    return total

def _юτΞЪεςφβρθнΔΛςΜψ():
    value = 51593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRW3a1Zsyr8pFCWgnQbHOz077l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЛζΧΒΛВчυУаяК():
    value = 830522
    text = __import__('base64').b64decode('bU5kOUZQNkhiejh1MnNYSWRnazE=').decode('utf-8')
    total = value + len(text)
    return total

def _лΩХΘΕηдУνп():
    value = 23151
    text = __import__('base64').b64decode('WmN1WDllS3JoUVRJQjltNlJweGs=').decode('utf-8')
    total = value + len(text)
    return total

def _θЩΛΔΡΕМъθрΜδη():
    value = 302250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTvwXG5p0aY2aD2A/niVNRYMtUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иννΨΙРΗΝλяЬаωφМο():
    value = 831376
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzzqYkE2z/s8LQ2V8niXAi93zF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΛЬδΙыВЕЯΠЖ():
    value = 73778
    text = __import__('base64').b64decode('bG82VXdSRTBBTHlwOG92WGVjZDk=').decode('utf-8')
    total = value + len(text)
    return total

def _яβлαΞШдιлλПι():
    value = 329658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSrwfUcp5PkvM1mr2XyYHXAY508='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йАΦςЯяΙЩμЭκΨ():
    value = 99300
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CA3nUXsg3fwABSb3mF+bP3Io7k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βмΦξΕωσЬФыΝΙαμΛ():
    value = 1089
    if 92 * 66 < 0:
        923
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQ3iO0ca6KU3Cx6n4A7CGCl/vHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΛΛдΖНοЕκиО():
    if len('') > 0:
        _dead_8212 = 128
        _dead_7813 = 147
    value = 316388
    text = __import__('base64').b64decode('V1Rsd2d0ODJqVkZyN1k5dUwwUEU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5398 = 212
        pass
        738
    return total

def _зюχтψπγωξшЭΣφе():
    value = 340807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dnn3egANr7BQECvzmn7FJhEJvVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΒФχληПыιΓ():
    value = 24129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In7oRmY+6q4EbiqWmgSqFxY6zX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        759
    total = value + len(text)
    return total

def _ΝВБВΣСцЯйζΠ():
    value = 67762
    if 85 * 11 < 0:
        351
        703
        _dead_6661 = 218
    text = __import__('base64').b64decode('THp4dDRNZ3g1cWNKRjZzYW5LcjY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _вχоηЭйаυХζоεΤХΑλ():
    value = 125633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDvgQWsLqPFSaVn73G6HMwgi3UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 41 < 0:
        _dead_7210 = 436
        _dead_5840 = 657
    total = value + len(text)
    if False and True:
        _dead_7113 = 743
        _dead_4058 = 805
    return total

def _реοхιЮяниЭΒΓщ():
    value = 641774
    if False and True:
        pass
        467
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgnxSXk7xrwiIyOO5EGKGB93wkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3782 = 368
        798
    total = value + len(text)
    return total

def _ΗΑζЦуγлΑωζΡΗж():
    value = 588674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Anf+a2EW+Z5aHT+0mG6eFzMcx3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬАвυкοПФМψМи():
    value = 882599
    text = __import__('base64').b64decode('SUVSUzA3dE90aExvV2NIaXNJMl8=').decode('utf-8')
    total = value + len(text)
    return total

def _УЕиοΡωЦзКΓΠъМ():
    value = 148377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRzhSnQw17giPi2Q6gKHLjwi20I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΨлчηΝОШсЕ():
    if False and True:
        _dead_1630 = 172
        pass
    value = 378397
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3nyb10o6qEoPiOL5GSRCwEc9Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 3 * 71 < 0:
        _dead_1617 = 372
    return total

def _ъζΤотπΓКυМеюς():
    value = 994211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh7eaEBv6p4UGFyO0kOaIjUCtU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        949
        pass
        297
    total = value + len(text)
    return total

def _θЗмЕсΒΝьАЗ():
    value = 341789
    text = __import__('base64').b64decode('dlFPM3RMUkE1X1VveEJ5UzV5aF8=').decode('utf-8')
    total = value + len(text)
    return total

def _уювжωΦшΔΕэС():
    value = 75615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgjXbQQj3IshbR6gz2CAFwc8/UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 26 * 24 < 0:
        781
        pass
    return total

def _дΣОУщσгБδ():
    value = 486643
    text = __import__('base64').b64decode('ZFJfMzhTbGdkQlhVSXhMam1nV3k=').decode('utf-8')
    if False and True:
        _dead_8755 = 793
        _dead_9140 = 216
    total = value + len(text)
    return total

def _ткгеΦΗэЙВιчЕΝ():
    value = 168065
    text = __import__('base64').b64decode('YW1CY2U2Tk1oamtZY3R6b05FY0E=').decode('utf-8')
    total = value + len(text)
    return total

def _κрХζΥαΙеςΛ():
    value = 385405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3yyQ0g/5oYnOVj3zH7HYTEcvT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 16 * 40 < 0:
        _dead_9199 = 550
        pass
        _dead_4374 = 764
    total = value + len(text)
    return total

def _μрΦЧυЕрфСψАΨ():
    value = 728936
    text = __import__('base64').b64decode('aWVrMWRjYUZ2ZmEzWEJsZXZpY1g=').decode('utf-8')
    if False and True:
        _dead_9487 = 337
        334
        978
    total = value + len(text)
    return total

def _цτΝеРΤтΥΔКρУ():
    value = 300855
    text = __import__('base64').b64decode('YXpCMXVuZURvaE1iTVV5VGVRaW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘьσκчλГωΛΔ():
    value = 108145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAnGWXIg1aJVaT+l5GmCGi0qsms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чαХгтΜцДШжцθΖэΦЩ():
    value = 745983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzqyZEEg2vsvF1+S8FqKHhwWxkk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5342 = 72
        _dead_1123 = 919
    return total

def _ΙΥπмφСΓуυΩσκ():
    value = 183624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx3bbURhxoY5Pymy4He2Mj0I5T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пПжΚοςοЕΦф():
    value = 460729
    text = __import__('base64').b64decode('TDN5UXg4dzFNajQwQTFLTU9EYmE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9030 = 507
        729
        815
    return total

def _эΛΜΘйβйЙщр():
    value = 653113
    if 79 * 73 < 0:
        _dead_5582 = 608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABX3Y3Bg7a4WLVan3VOJGQ8Js1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        339
    return total

def _РΔΛψΦΩхшз():
    value = 380229
    text = __import__('base64').b64decode('RXIxeWJXblhPMTd5dHBQS3JMWnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΧωοτйЖΕК():
    value = 156025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCixNkA264MiKzevkWykMxIG5VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГАοΨχβгАъΘΚωжг():
    value = 218055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRb1eUdo0KVTExmv30WRIQd/s0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьοЫНЖлвэυ():
    if 24 * 26 < 0:
        pass
        _dead_1530 = 918
        _dead_1083 = 502
    value = 516726
    if len('') > 0:
        _dead_5992 = 918
        _dead_5270 = 816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwHdbHRg86QKKw6L3UPIGiMD1Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧрЩбаΡЖβСЩ():
    value = 804954
    if 15 * 1 < 0:
        182
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hwv8SwFuqP0yHhf071+FPXAW000='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧоηфоΣυΑ():
    value = 851931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3zHRHwvrqYzHQHx0lXEJnIi3Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΖЬЮСгΥΑζкΣ():
    value = 827263
    text = __import__('base64').b64decode('Z3pzbjI4emhmSXBmdDRMVnJVSjA=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 53 * 53 < 0:
        _dead_7543 = 585
        _dead_8547 = 279
        549
    return total

def _ΖдзЫЪΝАΣЩδεв():
    value = 373859
    text = __import__('base64').b64decode('SjRSRGQ0Ul9qUXJzb2Z0MFU1d1I=').decode('utf-8')
    if len('') > 0:
        588
        115
    total = value + len(text)
    return total

def _ЧααΒΥСΘΛνΤЯ():
    value = 286457
    text = __import__('base64').b64decode('R1MwNUJEemJGY3RZRFlnRURRNkw=').decode('utf-8')
    total = value + len(text)
    return total

def _НΜςΘуАρΤю():
    value = 727390
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KynQOHkq7rgyMRiO/3+8G3x57kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НρшгεЦΧшУ():
    value = 492173
    text = __import__('base64').b64decode('Z2NKWmRtMTlFR0FXQ19zUHJsT1A=').decode('utf-8')
    total = value + len(text)
    return total

def _шЫюΛсчΙχТтйΞθ():
    value = 129705
    text = __import__('base64').b64decode('WGw2UnJWc2NTNzNQdkN6WnZkVHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _δэУгкΠьтК():
    value = 292187
    if False and True:
        _dead_8350 = 315
        _dead_3961 = 362
        pass
    text = __import__('base64').b64decode('ejlDeUp6NUkyb01PdnNhX0tVYUE=').decode('utf-8')
    total = value + len(text)
    return total

def _αχйэΔΩοТННтЫг():
    value = 43385
    text = __import__('base64').b64decode('bldpVVNONjFNc1VKM0kzbkRtM2k=').decode('utf-8')
    total = value + len(text)
    return total

def _тчΙπΚТьэσΜζιοьщΙ():
    value = 716192
    text = __import__('base64').b64decode('VmVQQ2o0NlpYbGZSQnVpZHAxMU4=').decode('utf-8')
    total = value + len(text)
    return total

def _иИдуγΡгΨюурьЗЕП():
    value = 925061
    text = __import__('base64').b64decode('aWhiRlVoQTJjZ1BZTlIzdWEzblU=').decode('utf-8')
    total = value + len(text)
    return total

def _иυРαФΨφΒнρяЬаπθ():
    value = 764558
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih7hNgQNr40CbhWVxE+gIn0t8U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 78 * 35 < 0:
        805
        pass
        _dead_6725 = 17
    total = value + len(text)
    return total

def _ТбυбΞМρЭς():
    if len('') > 0:
        261
        19
        pass
    value = 475987
    text = __import__('base64').b64decode('WjhyaEJvVllLT1VoR3IyWWJBOHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЧВΣЖΡчΟШЙς():
    value = 878502
    text = __import__('base64').b64decode('Q3hROERuckZvTTJuYmNZeG1jdVU=').decode('utf-8')
    total = value + len(text)
    return total

def _яνΡвФаиаыΝΒ():
    if 41 * 10 < 0:
        396
    value = 931932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fzu2aWFp9I4vYlaNwn6YAwc2w18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3235 = 423
    total = value + len(text)
    if 73 * 70 < 0:
        _dead_3325 = 803
        pass
    return total

def _καΝСΡΟΚΩх():
    value = 299074
    text = __import__('base64').b64decode('ZmprM0NxSVVfRWt2Q1pwcTR4Y3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘяЬΟзηжκйΩς():
    value = 450972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHnCRQI2/ZAsHl2hw3TJGyE1tWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 55 * 42 < 0:
        454
        767
    return total

def _σЛβλДэΓхПРспΟЯБР():
    if False and True:
        _dead_1383 = 595
        81
    value = 374999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky7iPXsv+JdRFz3w/U+nZy04snY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 12 * 17 < 0:
        _dead_9136 = 700
    return total

def _ИξдтηЪВУыЛΔΚ():
    value = 528571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyLjRwQM2Yc1PCCU5n+pJDEN0Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нщлξЖφςЯωТЖП():
    value = 756665
    if False and True:
        764
        _dead_5932 = 24
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyHoX0MY6ZwnMwugnXXFHXIE7js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        686
    total = value + len(text)
    return total

def _шσИлжюΥПЫкЯΜьщν():
    value = 232011
    text = __import__('base64').b64decode('U19rdExmWnhKc19RSVQwcURNdXY=').decode('utf-8')
    total = value + len(text)
    return total

def _оιДΖΘхкжеЭ():
    value = 380798
    if 44 * 38 < 0:
        419
        _dead_3310 = 884
        pass
    text = __import__('base64').b64decode('bFFCaFQ5ZGNEU2FyNXdvWUdHaHA=').decode('utf-8')
    if 52 * 35 < 0:
        _dead_2280 = 423
    total = value + len(text)
    return total

def _ηтЛШШнΕΨЕΓΤ():
    value = 333230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRi9bF1r9JcSAjaQ6nyzZhw961k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХлΨΠιМρЭжΑ():
    if 69 * 3 < 0:
        492
        _dead_3832 = 494
        68
    value = 34648
    text = __import__('base64').b64decode('WTY4MllCVW9yeEd4TEpmbDlsVWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЙτМЫжΙΠΧ():
    value = 686067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRXWYGAt05AaLQOJz0OGPRw492c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        445
        _dead_4385 = 201
        pass
    total = value + len(text)
    return total

def _φυζПβДкзξмΧЦЛΝ():
    value = 172910
    if 97 * 16 < 0:
        pass
        _dead_4884 = 158
    text = __import__('base64').b64decode('bXFqQjR2R1B3cXFmMnhZMDM2UkQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _χςфΔξιКРΝοЦεЙΕ():
    value = 36568
    if 19 * 27 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBjHPEU82qIVPAW5zX62MDJ36EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪμюτсйιЦιЯЙЮ():
    value = 862959
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXfbakkIp6AXICC3wUWcPC4E010='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бжфζСЛъюЧъ():
    value = 645716
    text = __import__('base64').b64decode('aWo5bHdnTDlPa2poR05hQ1IzSU0=').decode('utf-8')
    if 93 * 58 < 0:
        392
    total = value + len(text)
    if False and True:
        pass
        _dead_2775 = 87
    return total

def _ФΚηομΘΧГвнТрΗ():
    if len('') > 0:
        862
        pass
    value = 648521
    text = __import__('base64').b64decode('bjd4X3VLVGVLWERVckxSdVFORWc=').decode('utf-8')
    total = value + len(text)
    return total

def _эηГптΙΥЮк():
    value = 606438
    if 92 * 22 < 0:
        _dead_4675 = 828
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AR72bUcz57sQPiul7mCyDQcJ8FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 45 * 13 < 0:
        156
    return total

def _ЭΜзζуβТхщυ():
    value = 733246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSHtWFg9+o0IKyuvnXCKYXwbslo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        888
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΙЮιБПοΟХпΩдИж():
    value = 191590
    if 90 * 13 < 0:
        pass
        675
    text = __import__('base64').b64decode('QkR1bGlFNHc5VUlZSUhEUnRIdFU=').decode('utf-8')
    if len('') > 0:
        559
    total = value + len(text)
    return total

def _ιэвэΕиЕΜдδδЭγЗΜ():
    value = 324298
    text = __import__('base64').b64decode('cG9fb0hjSHlfNHkzeU9la25CNHo=').decode('utf-8')
    total = value + len(text)
    return total

def _φηФчумьрЦΔЛк():
    value = 399117
    if False and True:
        pass
        _dead_9129 = 542
    text = __import__('base64').b64decode('VU5tNV9ScHR5Q045SHU4MkJJY0Y=').decode('utf-8')
    total = value + len(text)
    if 18 * 5 < 0:
        489
        _dead_3400 = 172
        pass
    return total

def _βэΞретЖэжЕиэпШшВ():
    value = 103874
    if len('') > 0:
        425
        pass
        _dead_9218 = 869
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRu1OAgB/K4qI1mw51GYEgY9sGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςАдΠиΗωКπМпэθцРм():
    if len('') > 0:
        pass
    value = 383820
    if False and True:
        _dead_7011 = 495
    text = __import__('base64').b64decode('RVMwYXRZTjV0bHNhMm9jSDJiTGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _οфрΚαйтЮτΤШнΙкο():
    value = 885346
    text = __import__('base64').b64decode('VlpsZDVjOEt2ZFQzN211T0hPTjA=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ИецΒлΦФнζВΗηΑЭД():
    value = 645092
    text = __import__('base64').b64decode('Z1dZTWV0WUpaWjN0clJsN0hZc00=').decode('utf-8')
    total = value + len(text)
    return total

def _дЩτуΗκСтхуΑ():
    value = 796799
    text = __import__('base64').b64decode('U1NWNXNMTVFrUTdFU2NMcE1hZzc=').decode('utf-8')
    total = value + len(text)
    return total

def _бΜΑоУцΓУиαБгПκЧ():
    value = 588535
    text = __import__('base64').b64decode('UTFfUGY3c0pxeW14cnNHdXNSUTM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        943
    return total

def _ΖняЛαФЯρωΩчДтфкФ():
    value = 60640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB3KSgYDqvs2aQyN5EWHOQoL4EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()