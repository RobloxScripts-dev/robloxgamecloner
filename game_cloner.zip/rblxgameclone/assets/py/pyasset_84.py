#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ЗндςΔΣΚкСФЙн():
    value = 966555
    text = __import__('base64').b64decode('RzRyd0xmX0R3YWVXdHVERVlKSWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _οехаиоΡΤυоδкзΣлр():
    if 42 * 44 < 0:
        pass
        _dead_4306 = 328
    value = 448018
    if len('') > 0:
        633
        pass
        pass
    text = __import__('base64').b64decode('dlZBbjlUSExxSjRrcmpJa2xXNG8=').decode('utf-8')
    if False and True:
        251
    total = value + len(text)
    if False and True:
        _dead_2043 = 621
        pass
        pass
    return total

def _ДЫημςЬΜХΖЪεЧφх():
    value = 503719
    if False and True:
        _dead_4918 = 353
        _dead_7681 = 81
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CATVQHY2zPsZPAWz8QSYH3MI7ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 2 * 82 < 0:
        973
        pass
    return total

def _ΝτсЪγДЬюкΟνБςΣσ():
    value = 592669
    if len('') > 0:
        _dead_3115 = 548
        963
        _dead_4428 = 764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ER+zXWUur50lIAyqxlrIFyMcykQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ψΕΞΘΛКНΔАЭΩημш():
    value = 979789
    text = __import__('base64').b64decode('YW11ZVowMmJTbEFvVG41ekVfSDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _УМςЬьтлωлςючя():
    value = 21483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnjLSgQt2P0NNRqb2FrIZn0lwls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΠхΘμΨΘιФ():
    value = 155898
    text = __import__('base64').b64decode('ZXZOeGc5el9vMjEyMnp4YXZJXzQ=').decode('utf-8')
    total = value + len(text)
    if 82 * 52 < 0:
        pass
        88
        pass
    return total

def _θФΨΠьΦξЦλеΖρЮ():
    value = 169437
    text = __import__('base64').b64decode('dFIxdTdhMVRlZUlMRFBaR0p6bEY=').decode('utf-8')
    total = value + len(text)
    return total

def _жΗнΩзыλρмκэ():
    value = 729021
    text = __import__('base64').b64decode('TVp5eGlSZUlqOFc0dlRzTnp6cHM=').decode('utf-8')
    total = value + len(text)
    return total

def _дЬσвΜнΠΒюβ():
    value = 471171
    text = __import__('base64').b64decode('Rlhnb1E4UDFlQkkzVlZJWWJUd0I=').decode('utf-8')
    total = value + len(text)
    return total

def _υЫВΑБξтнιΠξ():
    value = 363342
    text = __import__('base64').b64decode('ZGcxV3dJTllTbEtyX1J5RlR4bjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΜЕяΖδΔν():
    value = 331994
    if False and True:
        707
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAbiPEkw0vlaOzCrnUaIJDwb4VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        567
        pass
        _dead_1403 = 818
    total = value + len(text)
    return total

def _βИЮДеΕΧтΑпКч():
    value = 169513
    if False and True:
        pass
        214
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBjGfWgJyrsFOwGo6Q+3LHEm910='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9595 = 49
    total = value + len(text)
    return total

def _γΗΕВЛГдμΞιρΔдМЦα():
    value = 186361
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH3yPFk/3Z4CGS37x0GXbAJ/7VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        336
        _dead_8917 = 738
    return total

def _ΨКяЖΩЬЕΣς():
    value = 895497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lgb1OnRt+/4sI176xXypDggO/mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТэыЮΛθгтзξ():
    value = 198415
    text = __import__('base64').b64decode('em5obmVJdF8xcW1WQjRCcEVDcHg=').decode('utf-8')
    total = value + len(text)
    return total

def _дδхΡκПЦΖοΙς():
    if False and True:
        _dead_5833 = 831
        pass
    value = 984369
    if len('') > 0:
        643
        pass
        _dead_1763 = 130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwHQYHc72KVSDiL3/nvFNR8n80Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7872 = 972
        _dead_7149 = 657
    total = value + len(text)
    if 20 * 1 < 0:
        _dead_6213 = 270
        810
    return total

def _πЭуоΤлъεΔПσ():
    value = 474682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwHnX3Ix9v1QbV250HS1YQkX5X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 98 * 88 < 0:
        _dead_4317 = 100
        62
    return total

def _йΡИРΕбФΝЩУЪ():
    value = 289815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Liu0XFxspqA2Alew+1CWCwgm3H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чβьоΟΛΥгξъ():
    value = 705366
    if False and True:
        54
        _dead_3680 = 62
        _dead_3954 = 526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiTuYEYD9KYAIyb08nuiOjEkw0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьЫЧАΣшεΑ():
    value = 376900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQzDeGs+z5o6CRWk0UW0ZncF9HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бκυοзΙАФσ():
    value = 663448
    text = __import__('base64').b64decode('ZXUxRU1vYjF5b1pWUTl5SUN3Wm0=').decode('utf-8')
    total = value + len(text)
    return total

def _нИΛюπЮκψъζдъχΚ():
    value = 982153
    if False and True:
        pass
        _dead_9414 = 789
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR7iXWRgzbAIMDaRwWfIP3J+62w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аχιЛсвΗΔ():
    if False and True:
        _dead_8805 = 384
        690
    value = 808253
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQjdV1od7pJVL1zy3A6dPjYM7HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 51 * 51 < 0:
        pass
        pass
        214
    return total

def _ЖичЛЙΘЛΠχΡπς():
    value = 256646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCSwYmAV+Iwqb16vzESXGxIh/j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νМСГνЬδιθΓ():
    value = 222781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXnvR1Iv77tRHSaA/nqSBCstxno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηШбОЙеУкΦαуΩ():
    value = 533314
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSfmfQU/6asADV/yx2eXIisK9ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΘлмОХτμеδ():
    if 87 * 78 < 0:
        _dead_8016 = 285
        _dead_7306 = 500
    value = 59197
    text = __import__('base64').b64decode('Ul9Bam1ienB0NVhSRkhKTV9oR24=').decode('utf-8')
    if 3 * 6 < 0:
        782
        _dead_3074 = 971
    total = value + len(text)
    return total

def _ΤφЯдζПжжΓΘбЗэ():
    value = 172798
    text = __import__('base64').b64decode('WWtxZURXY2lRNXlNRzJHbmxOM3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕжψКЭфыβ():
    value = 982284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH3PUVcX96AhNC2KwG+WADciyWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νгпьκρΥйρУтхβЫ():
    value = 280481
    text = __import__('base64').b64decode('aXpIZkxzZ2xGc2tWR210emNEZnc=').decode('utf-8')
    if 61 * 93 < 0:
        _dead_9515 = 739
        pass
    total = value + len(text)
    return total

def _ФμσЪВΥΗСю():
    value = 855328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgWwWWEhyL4aHiGI4gGpAHYp4Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧοΠАΓйΒулАθ():
    value = 166306
    if len('') > 0:
        _dead_7381 = 423
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iw7NWXs0354ULRWo5VvEYXEVz2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭρлψчЩΒКЛβΥφ():
    value = 544182
    text = __import__('base64').b64decode('bzVTQkpNX3lZWWVTXzM5dmZ3QXI=').decode('utf-8')
    total = value + len(text)
    return total

def _шΨРψΤгФАСерΞГ():
    if False and True:
        93
        pass
        _dead_2132 = 964
    value = 158895
    text = __import__('base64').b64decode('czBJSDRMeDZMcGxIZjJsZ2d4cHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣРΝЫжАθЫЙΚαО():
    value = 101327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En/MfXMprYEzNVeJ7XiWNjcZsHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔеΠчиσйΡΛΠЖΑΝ():
    value = 786887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cjv0QFQL+v0aGSj35G+fEzICtEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыπαлΒθиθ():
    value = 311825
    text = __import__('base64').b64decode('c0FwNU5YWWxDUk91VlV1M21PT0w=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _оцΙξβиоУЯС():
    value = 963603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyezV10YqaIMDxWnmFOVYgwr/Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΟМβбδιН():
    if len('') > 0:
        924
        _dead_6796 = 939
    value = 476111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSz2PnAs2PkzCQqInV+VOiY15Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΓАΩЭΩοЕЫОρΟΞΨ():
    if 66 * 53 < 0:
        pass
        585
        620
    value = 185594
    text = __import__('base64').b64decode('d0pLUllHMFlYV1Q5UjBZSVJDZHA=').decode('utf-8')
    total = value + len(text)
    return total

def _кλξΨυИИв():
    value = 497332
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgbcW3wG24EhLCeB3V+KZgwI3V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χЪпΣрιХМΘсΙЗШ():
    value = 937390
    text = __import__('base64').b64decode('TmREWHFaZWhSVHFBZXpheXpMOWQ=').decode('utf-8')
    total = value + len(text)
    if 58 * 53 < 0:
        pass
        pass
    return total

def _ζΗЩэЛыοШлЦΚ():
    value = 106768
    text = __import__('base64').b64decode('aHVkNWhRajFjOGIxSUlrTDU1dk8=').decode('utf-8')
    total = value + len(text)
    return total

def _МГыьΤαтωС():
    value = 281157
    if 55 * 5 < 0:
        893
        173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACGwbFkv75tTIif27geVHXQK4Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4519 = 532
        _dead_6943 = 583
        _dead_5342 = 65
    total = value + len(text)
    if 95 * 33 < 0:
        pass
    return total

def _ΒМΝξяιΗЕΒбРпУЙι():
    value = 434271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCfcQnsG54kgCAmcm32CJHc19V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωкшзсЕУξζФый():
    value = 243980
    text = __import__('base64').b64decode('TE1kN0RseFFBVldva0xQakljQlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛσъьрφδеъъΚш():
    value = 231632
    text = __import__('base64').b64decode('Unl5ZXpXS21Jak9NaFJxUzY3cWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΙЪРκлΝяζЛЕχτΒт():
    value = 436601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwK1XXgD85EVHRqt31qlHhAJzUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4721 = 865
        pass
        430
    total = value + len(text)
    if 34 * 6 < 0:
        _dead_9532 = 802
    return total

def _υйГЫЦτФАΧσο():
    value = 831086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhbxUWQNrIQNF1yz4G6iJwYq9zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭГЭЯΥλржπΛюхρюа():
    value = 117966
    text = __import__('base64').b64decode('QnRiZTl2YXdGSTZ5cnZFN3VXQjA=').decode('utf-8')
    total = value + len(text)
    return total

def _РчΦΦЖιщкР():
    value = 283563
    text = __import__('base64').b64decode('a1l5MnlPX3pCWjQ0WXQxUDJuZEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗтΓЕρлζрыИ():
    value = 145098
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCvMaUQQyaYUHwer8XiaNQ9902c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πηзΡΟТшщо():
    value = 282785
    text = __import__('base64').b64decode('TmJwTkdXaFExQlBFcTlCSXdiaVk=').decode('utf-8')
    total = value + len(text)
    return total

def _зКУωлПΚιмыιΑ():
    value = 980089
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhvKfnMU+/87IyGMx0WbZz8hyHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΚβАΜнΜγЭμЙ():
    if len('') > 0:
        _dead_7120 = 672
    value = 92688
    text = __import__('base64').b64decode('UlltTU1wMDk5ZEdSSjBleWxyd2Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        165
    return total

def _ςΘΘΖοНΛΦδ():
    value = 969025
    text = __import__('base64').b64decode('SDdMZHB6eHhqeGFqYUprdmQ0VWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ωыРнΤИβЗТВεξзΤАΕ():
    if len('') > 0:
        pass
        pass
        711
    value = 893544
    text = __import__('base64').b64decode('anhlSmxpZV9mbFROdTZMOEt2bVo=').decode('utf-8')
    total = value + len(text)
    if 38 * 81 < 0:
        992
    return total

def _θрΡδΧЗеο():
    value = 403709
    if len('') > 0:
        500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHm3RWEM9ZcIMjWI5UKHACsB7V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_2445 = 174
    return total

def _βφЮζЧЮΕчΥζзЦψМ():
    value = 454211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzrBQlAgq5s6a1qh2w+8bD0Y82U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΓζГСяЛьΘАг():
    if False and True:
        _dead_9288 = 775
    value = 267941
    if len('') > 0:
        641
        _dead_5531 = 181
        91
    text = __import__('base64').b64decode('a2NoeG9CdXJHU3AzZjZ2TFI3TEU=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _φγЫνсФэнфΜьПЩ():
    if 30 * 17 < 0:
        73
    value = 43275
    text = __import__('base64').b64decode('Zl94QlhmOUEzXzhPVGdoa1RzdjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΝβσΚСΒεиδ():
    value = 956851
    if 53 * 25 < 0:
        _dead_2438 = 42
    text = __import__('base64').b64decode('a1lIbF96NGJOUzhSb2JUYjEzdGI=').decode('utf-8')
    if False and True:
        337
        pass
    total = value + len(text)
    return total

def _ΖЕΡΜцМΝΞΜмθω():
    value = 776972
    text = __import__('base64').b64decode('dFg0elhjRGlrVmpJR3J5TEFkWDI=').decode('utf-8')
    total = value + len(text)
    return total

def _υбкИчПбσйТΧΟЫйΦ():
    value = 62125
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwOyfFQ8qI4mKSuo30a5JxY6w1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηθΦЕΒΟψςля():
    value = 430891
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExDLeQID/45TKBiKwFSHEit64mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΖДΓΡПеωЮх():
    value = 574133
    text = __import__('base64').b64decode('ZUV4TVY3TU5xWHY1UU9iQWFEWTM=').decode('utf-8')
    if False and True:
        pass
        975
        _dead_2219 = 519
    total = value + len(text)
    return total

def _ΕЬκЙδοЛхККτΡ():
    value = 68290
    text = __import__('base64').b64decode('ZE5abGdYaXJ0RV9FMThybnQ0Zjk=').decode('utf-8')
    total = value + len(text)
    return total

def _БСτфтГχхПхΦРмσχА():
    if False and True:
        pass
    value = 790963
    text = __import__('base64').b64decode('T1RES0NFQmxnQWxJaTZsYzdqZXU=').decode('utf-8')
    if False and True:
        _dead_1877 = 882
        pass
    total = value + len(text)
    return total

def _ВζЪαΛлЛΘπζьгЩмГω():
    value = 411057
    text = __import__('base64').b64decode('djNkQkVCU2J4Vmt3d2pTdmswb1o=').decode('utf-8')
    if len('') > 0:
        _dead_7696 = 15
        _dead_3641 = 331
    total = value + len(text)
    return total

def _ΣПДφχΥЖΔыψМхΔ():
    if len('') > 0:
        pass
    value = 907252
    if 32 * 61 < 0:
        pass
        _dead_8271 = 659
        _dead_8988 = 963
    text = __import__('base64').b64decode('UGl1ZEVueDNrZ21HT3dBRUlUeUI=').decode('utf-8')
    total = value + len(text)
    return total

def _сдδζюΞσΕταω():
    if len('') > 0:
        pass
        660
    value = 548300
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiXsRH0U9PAoY1mo6l+UbAI95lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κщуТнрЫЬнчΖВ():
    value = 424987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXfgYQgp9/sQNwCqmgLJOTQVsFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛВзειΤρηЩвщ():
    if 95 * 22 < 0:
        640
    value = 810111
    if 48 * 18 < 0:
        _dead_6802 = 357
    text = __import__('base64').b64decode('RGxWc2Rnc2JMOFU0eU5jbzBZWkU=').decode('utf-8')
    if 70 * 89 < 0:
        968
        978
    total = value + len(text)
    return total

def _ΖВΝяНЖΧπшл():
    value = 507885
    if 61 * 12 < 0:
        _dead_2287 = 58
        _dead_8683 = 994
    text = __import__('base64').b64decode('eDlGWXR6QmJnYXpaRnNsbE94Y04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠфΙУιхСЪυхγςονБ():
    value = 563134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwfjP0Y99YoXEln23APJOHAKyk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΖΧЩΣдЫЩтΞвδЗЩΡ():
    value = 844495
    if len('') > 0:
        440
        946
        _dead_5634 = 274
    text = __import__('base64').b64decode('bDZiRXRFcUZWd1JLTGdmOVJPTUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _цδРЬяαэΕСоКВς():
    value = 537392
    if len('') > 0:
        695
        pass
        188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQrxYAgpwbolMFaTww6qBCM7/Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЫЙвпРъχςΛγσэ():
    value = 424550
    if False and True:
        _dead_9587 = 90
        _dead_8148 = 450
        328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgHDRloO9fESNSm34kaDOxE2xV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΑуαΑЖЗФсΛЪХΓΜ():
    value = 184988
    text = __import__('base64').b64decode('TnZyTDB4NWFWUVBIODBPbWlkWms=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8078 = 648
    return total

def _ЭыΧЛфοηЛъХБк():
    if len('') > 0:
        pass
    value = 230090
    if False and True:
        pass
        362
        736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjbLd0cz6KoZNgiawXmqBR0j21s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УэΧЛυΣΥДνхτн():
    value = 543937
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwDNaWMsyqw7PAG1+FugAnR80T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φПтЩτьъΔΨЭЩγ():
    value = 464971
    if 63 * 40 < 0:
        pass
    text = __import__('base64').b64decode('cDdIWTBmZjREeXpOX3pzRmJSVlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ςδΖπИΞΞщаДΨΣшНы():
    value = 133179
    if len('') > 0:
        814
        _dead_2112 = 64
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj/mPVwAp/8NYx6b0mTBPxd+s0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΡΠΠриЮΧМДνЩξнЗв():
    value = 324566
    text = __import__('base64').b64decode('eF9OaDRaOUFvRXlDTjBXdWpiQ3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖхлмЛХλρΛщъЗг():
    value = 608984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATvqZ1497KMAKQWhnlSoFxUBwT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΖТаПλΚюьΥ():
    value = 961484
    text = __import__('base64').b64decode('dnNUQUZaRVNobkxZMlNqOGsxNWM=').decode('utf-8')
    total = value + len(text)
    return total

def _кφθТψμπюЪг():
    value = 673107
    text = __import__('base64').b64decode('TlE3azdWSl95UmRFTXl1QWNvUlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _фрθΜъΧЙЪЯφщЫРшц():
    value = 739522
    if False and True:
        _dead_2160 = 215
        514
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRrlZW4b0b1aAlex3EC5DCsu02U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΓАкνпσЬχηЙП():
    if 73 * 33 < 0:
        _dead_4596 = 514
        pass
    value = 848126
    text = __import__('base64').b64decode('UGVKdmdsOVFIdzlMb2tfUnFrZ2U=').decode('utf-8')
    total = value + len(text)
    return total

def _пктΟВΗбМХж():
    value = 656743
    text = __import__('base64').b64decode('bEw2X01JbUV1ZmtMUGlzNmhNVk8=').decode('utf-8')
    total = value + len(text)
    return total

def _γжыΟΩщВзΞЬ():
    value = 567392
    text = __import__('base64').b64decode('SWRDU19ydkFvOFFpSkhxRlZwcWc=').decode('utf-8')
    total = value + len(text)
    return total

def _зйЧЯгнрЕφи():
    if 47 * 60 < 0:
        527
    value = 357525
    text = __import__('base64').b64decode('ejVIS3JhbWxiQk5LVDNaVkpmWkY=').decode('utf-8')
    if False and True:
        pass
        _dead_9652 = 659
        pass
    total = value + len(text)
    return total

def _ζΔιОΧΚςаххΦзοΧπΓ():
    value = 858662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXu3XWJp2oM6PSWLmgexEwsByF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 81 * 71 < 0:
        141
        388
        _dead_5615 = 916
    return total

def _РΑсМВЮΧЦΑΜвЫηΘ():
    value = 711506
    text = __import__('base64').b64decode('djE1NGN6dWw5ODlNNFZmdXV4cF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ИфЪшыЕаγпζЙюИнб():
    value = 660311
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASnBaVNhxr42PgqoylmpFTIgtT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΗужΓШЦФхыςΛΗ():
    value = 311126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAjLWHIe/KE1blyo2k++ECh6wmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8029 = 552
    total = value + len(text)
    return total

def _ΥйКъΜυλΚΞΟИЦэωъР():
    value = 740222
    text = __import__('base64').b64decode('bHV4T1FIUFBYQ2VoYThMbkZSSTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒαэγэщΨΥС():
    value = 103645
    if len('') > 0:
        433
        _dead_5565 = 239
    text = __import__('base64').b64decode('VlBHdU1MWG1UQkhVa0NWbFBjbUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪЪθеΓфъейα():
    value = 644722
    text = __import__('base64').b64decode('ZzVOUXg3WWZSZDAzSFR5dnVwS1Q=').decode('utf-8')
    if len('') > 0:
        _dead_9052 = 282
        204
    total = value + len(text)
    if len('') > 0:
        74
    return total

def _ьογλσθуЪοηυ():
    if 77 * 96 < 0:
        pass
    value = 422638
    text = __import__('base64').b64decode('SDNZZ2ZObHN4cDk3NDVSTjJtaGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗыΛщКьЗгΝ():
    value = 372998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSTUZQU90IkkHBeXzWS0OTI97D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψфмЧνΜЙПЪτНЗεфЩ():
    if 42 * 65 < 0:
        960
        837
        pass
    value = 231857
    if 21 * 85 < 0:
        _dead_3550 = 738
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCy8eGQuzK1aPCab+FjFASp9wjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЩΨЗЩзτОΓΤβ():
    value = 874482
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQL2N0I0+II3aA6o2A+mZDR3zWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        110
        918
        _dead_3218 = 461
    total = value + len(text)
    if 2 * 75 < 0:
        pass
    return total

def _ΖКХΨцЯцςЮвζбΞЮлс():
    value = 894611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzjyWHNsraQZKwiv5wC4YAwi4nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _нкмКυйΕХ():
    if 72 * 11 < 0:
        132
        798
    value = 90057
    text = __import__('base64').b64decode('d0o3R1VqcGlGbjhwVWJJNTBPd1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛжβЧεЖШΡяβζоз():
    value = 630505
    text = __import__('base64').b64decode('Q3h3eDRjQnlkZ0pJbXducU9xNXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _щφΨΥιДςвΔΔ():
    value = 403871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDvDalYDy/5VORq6zUSVNhZ49ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фаМДΧΙΧЧКΜ():
    value = 869091
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnyyUXgy95EsOQyi+FOlITUl9EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φпаσКсЦФΖЙБШκ():
    value = 912938
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCPFfXxt0LAuKS2g7XyzOy8n4D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        414
    return total

def _мπвЩμЯзΣηсоοЪаγς():
    value = 95875
    if False and True:
        _dead_3246 = 355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InnrT0Rgzf47a1eA8mTJFRN34Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 22 < 0:
        pass
        pass
        182
    total = value + len(text)
    return total

def _ΤΝаВφπΡΔΛ():
    value = 582431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyjXTHMW84oVMymNy2KmOyENymk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φОЪеζρжθъΘаБυ():
    value = 679440
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQjCTV9rqPoqFxir/UWWHxcG1Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞЩЕΘЧμθх():
    value = 620702
    text = __import__('base64').b64decode('dVk2WWJGc19tUURaVHhyWk1KQmI=').decode('utf-8')
    total = value + len(text)
    return total

def _ВεεгλщαΝвψЪЫм():
    if False and True:
        _dead_3972 = 379
        _dead_1970 = 188
    value = 300955
    if 81 * 3 < 0:
        785
        pass
    text = __import__('base64').b64decode('bHVJOXZXUExMZzZQNXlHTHV5VXM=').decode('utf-8')
    total = value + len(text)
    return total

def _οφΝЬμДΧξ():
    value = 97152
    text = __import__('base64').b64decode('UVlHcFA3NVpWQlZtaG9udFdMZmI=').decode('utf-8')
    if 60 * 40 < 0:
        210
        pass
        pass
    total = value + len(text)
    return total

def _κНушΖЬЯΕοιζВυχΔ():
    value = 105999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LA60aFkJy4QpBQ2O6w+FMRcA1Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑхЯЖΠЩτΕУаеТъσР():
    value = 564881
    text = __import__('base64').b64decode('WVg5bE5wMGdjZ2xucmlvbTNlVGE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        434
    return total

def _ΞЪзФΒρηэ():
    value = 518947
    if 33 * 40 < 0:
        14
        _dead_1071 = 269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E360RX9hx7ASNA72/lqiJjAHtVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2597 = 146
        _dead_7920 = 358
    return total

def _бжΟЬαуСβЬгκТοюЖ():
    value = 708933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACv9fwUD8K4uGAq10FnFHwwEt2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДйДЛихΛц():
    if len('') > 0:
        pass
        433
    value = 456627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NA7sTH8R/6cUa16MxAScOQk+7H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СхцВтШνυрлУуЫξчΛ():
    value = 93445
    if False and True:
        pass
        244
    text = __import__('base64').b64decode('U3RkamVhZDZCeUNuaDFBa1F0dFM=').decode('utf-8')
    total = value + len(text)
    if 9 * 59 < 0:
        654
    return total

def _θхиωΠγςМΙшτЙк():
    if len('') > 0:
        pass
    value = 316666
    text = __import__('base64').b64decode('aE9TMHRkeDNJbkxiVjFGNzU1WTM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5244 = 807
        19
        pass
    return total

def _жСцΥЬЦΦεЫδЧрен():
    value = 291094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxDQd2sJ1pEQb1i333CJNwsa0Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юςΚэЙАΝπвВшюнБВ():
    value = 473400
    text = __import__('base64').b64decode('Zm1aSkthdEhwM1ZsYkpoYmN4akE=').decode('utf-8')
    total = value + len(text)
    return total

def _БАаШЯцПΑΨЕΡМο():
    value = 331793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCX3bFkD+Jo3NSuR31q1PBIi03c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ψβццълμρЬΩψ():
    if 22 * 61 < 0:
        _dead_4077 = 226
        pass
        pass
    value = 145120
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiHGOmED0rw5AwC37WSlJgMX91Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 49 < 0:
        665
        309
        pass
    total = value + len(text)
    return total

def _ЪГъΑПΒЙХΤЩπСв():
    value = 735760
    if False and True:
        308
    text = __import__('base64').b64decode('cnNpZTZwTmpqNHp5MDZ5RkhDX0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨαεхΑЭБξ():
    value = 816797
    text = __import__('base64').b64decode('dFhUaEhLSWdacFZKVGJkZlNQNlY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        290
        _dead_1535 = 981
    return total

def _ψςΡянЫОГОТυн():
    value = 394261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjnKSWQt2/xUMxyUm2e/bDUEw0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ъЮνУАцВЫΡ():
    value = 421559
    text = __import__('base64').b64decode('RElvZGwwSUpicFpuV2tGc0NRWHk=').decode('utf-8')
    total = value + len(text)
    return total

def _взХеΡзкΓЦуИ():
    value = 871611
    text = __import__('base64').b64decode('eGU5ZXRIajBUMXR5SG9ERjBQUXI=').decode('utf-8')
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        757
    return total

def _цгыΚМφъΩвΚτιΓ():
    value = 466527
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRrcP1sNqac8HByUxFSAZCQH0n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τфЧωбОГЬΔθ():
    value = 595061
    text = __import__('base64').b64decode('QTcza1Fmbll4NDF0ZThHdWlIMzI=').decode('utf-8')
    if len('') > 0:
        pass
        135
    total = value + len(text)
    return total

def _ΟъΖγЭИΔΝιцЩ():
    value = 373510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgfjS0AL0YoGHjCKwWKDIT996V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3671 = 467
    return total

def _ωιυВлλъΛм():
    value = 418324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwG1QF4rxIcuHhm6/U+cGhd23lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λроГεшэβчδцΩμΟ():
    value = 12196
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAzXSUs3+vsNBVqI/EKGY30820o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аяΛСΚΣЙλΡΠΨГм():
    value = 944979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTv3VF0q8L0WKjiJ5W+WHTwE/js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βБΥфΗΓγЛКЗЕ():
    value = 310261
    text = __import__('base64').b64decode('T2NKdGM2VWpoNDdTdTdpX004aG4=').decode('utf-8')
    total = value + len(text)
    return total

def _яКθΣБУыΩμφεрΖК():
    value = 721185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAPSSGgTrqY7HwOO2QLJIQ4jyj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОτЭКδьΝдНтεЯξιн():
    value = 300365
    text = __import__('base64').b64decode('ZHBnZ0pKM1R4Y1g0ekN1TWhlREI=').decode('utf-8')
    total = value + len(text)
    return total

def _хιИТЯΨРРЫупθ():
    value = 306999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhXWe1Js9YsoHgD1zU7IOncVtEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕъАγаВчяΦЯЧнАΓЧ():
    value = 809790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgTnPFktrqI3NyKF5FqxGSEo230='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αМχэбκσлΓЦΛтιч():
    value = 948194
    text = __import__('base64').b64decode('UDdFdXNiZmx5RFZhZlBaMFA1Q3U=').decode('utf-8')
    total = value + len(text)
    return total

def _φЦΠδθΙβψ():
    if 76 * 9 < 0:
        _dead_5644 = 239
        197
        _dead_9299 = 983
    value = 255405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhjtP2IS9ZdTbxat6XykGDZ9/nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ехΙыъЙξзΒЪμ():
    if len('') > 0:
        pass
        316
    value = 401478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyjrRnsY5I4SGCyG9wWhEzM49Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2341 = 6
    return total

def _ЕΨΟМΖυΑκеΓбжЗэΨ():
    value = 526261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiLQQW4r7KUJFF313XGvYxQXwmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 54 < 0:
        _dead_4214 = 333
        633
        134
    total = value + len(text)
    if False and True:
        pass
    return total

def _υЧκΛАзюТ():
    value = 561599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARb8Pl9t3Yw6EA2E/36dGHcp5n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΧжθΧСцΦΖΟк():
    if 52 * 84 < 0:
        pass
        696
    value = 33877
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En/ITEYwrqczKBeFy0GSYTQf22M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6064 = 315
        _dead_2678 = 759
    total = value + len(text)
    return total

def _УсчηΣжрЫыΝ():
    value = 683431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh62QX0G7ZgZFRW3/HihGRo/8F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜРЪтФφСασцκεΝП():
    value = 547748
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kj/9Xmkv66RTPC2PnUWmCxB74Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зДРЗОэαйΒГω():
    value = 49785
    if len('') > 0:
        _dead_7048 = 417
        _dead_2897 = 166
        pass
    text = __import__('base64').b64decode('aTR4TTRzbEJQMXJURV9FM284SzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒБькοΞевΠψю():
    value = 543136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTrTfncG04QCMzet3GmXPnEJ0GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΒςθючЭэКЛ():
    value = 337475
    text = __import__('base64').b64decode('dzd4bDBFekdaRzRJZ0RSQlVMVWg=').decode('utf-8')
    total = value + len(text)
    return total

def _νψΓчНйгΙМΔΟΒ():
    if False and True:
        453
        526
        pass
    value = 595474
    if False and True:
        pass
    text = __import__('base64').b64decode('eG5XMml0OGRjMmN4ODdkWFBzMXM=').decode('utf-8')
    if len('') > 0:
        65
        pass
    total = value + len(text)
    if 100 * 80 < 0:
        _dead_9888 = 851
        551
    return total

def _нРТΔΓΤΜЮыкЖ():
    value = 660251
    text = __import__('base64').b64decode('UWZRdnhQeDlXcXl2NEl1TFBETmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _кψΨθρλЦΗыαОΜ():
    value = 140745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LADLTVMu5JE7YyqhzFmjBTwhyH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 75 * 64 < 0:
        pass
        _dead_7531 = 839
        _dead_3678 = 345
    return total

def _ΤаΜозЩЫлюτБУнхθΓ():
    if len('') > 0:
        _dead_8708 = 992
        pass
        pass
    value = 96420
    if 64 * 45 < 0:
        17
        855
        pass
    text = __import__('base64').b64decode('R2tmX2dzM1JVQjgwZlloZUhPdGc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΠсμэКчδΥЮξξ():
    value = 52002
    text = __import__('base64').b64decode('RW5fUHR1VEp4UV8yTkUyekFVQTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ГыπЩЮυΤΘЪтПЩξМΑ():
    if 30 * 54 < 0:
        pass
    value = 413589
    text = __import__('base64').b64decode('SDNKbVpfcmV0b1g4WVNOdUo4MVo=').decode('utf-8')
    if 69 * 22 < 0:
        834
    total = value + len(text)
    if len('') > 0:
        _dead_2652 = 750
        pass
        _dead_5300 = 548
    return total

def _ЩζДСΝηэяΨ():
    if len('') > 0:
        pass
        383
        261
    value = 367578
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSrdW3w07rlQYzyVxg6xNXwr/j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΙъЩмНрФхνхьяΥκЧ():
    value = 419838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hwy3aHMu1YYXbzuQ/lzCMwQY6D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 7 < 0:
        _dead_6538 = 318
        327
    total = value + len(text)
    if False and True:
        479
        pass
    return total

def _ΤΞздЕδУЯρνΣΣоЬΙ():
    if False and True:
        _dead_4441 = 219
        419
    value = 165284
    if False and True:
        _dead_5387 = 276
    text = __import__('base64').b64decode('azhiMmd3QkNJWjVKM1RNQVlpREo=').decode('utf-8')
    total = value + len(text)
    return total

def _йΔЙΝςХπЯΥы():
    value = 982951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ez/sOHIL345aYi2i2wa3Ig8EwT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        473
        pass
        _dead_2413 = 816
    return total

def _ЫкйцШЕςΣьАιΕξΨθΙ():
    value = 330444
    text = __import__('base64').b64decode('QnUxVEZhUTFjSDNfRFVjNzFxMEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩзςГоΕЖюФУМΦΕχ():
    value = 902009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATbcTUQ38b9bAy6C/1KyBgJ3xnQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДАβуИαιΠДрΕΙΝθ():
    value = 921604
    text = __import__('base64').b64decode('a1VtTWtfRVV4ck9oT3NLdDJUdDE=').decode('utf-8')
    total = value + len(text)
    return total

def _тоыЮяЖΑдЫВηМι():
    value = 117414
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA3mRHMgx/1RECKUngSkBggDt0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 63 * 38 < 0:
        192
        pass
    total = value + len(text)
    return total

def _бнψΟδΧПЫсгЫιεРы():
    value = 371689
    text = __import__('base64').b64decode('TXVRbjZmSmtobU9NeFJGbmVIMEk=').decode('utf-8')
    if len('') > 0:
        142
        pass
    total = value + len(text)
    return total

def _рλЙфЖυΟΘю():
    value = 753642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABrWPwE86oszGAC7wHKXDAsltkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕпГιеοюЛПυ():
    value = 491229
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAy0Swc10PoAFjWpm3ucBSA1s2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4848 = 574
        _dead_7913 = 897
    return total

def _τжΒεСЮшΑΩпЖдР():
    value = 660639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HADcemc027kGBTqR3E+6IAA550s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мμЛПνχСκЗИДΝЖОΡн():
    value = 663339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjnQfQlh1I8rCwepkWaXYgh74kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 80 * 22 < 0:
        pass
        _dead_8082 = 497
    total = value + len(text)
    if 74 * 77 < 0:
        _dead_5724 = 585
        559
        73
    return total

def _ΡЩГζЖΓнЕОУ():
    value = 376321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By3CWwAd76k2FR2vzQe5Fw179D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 84 * 72 < 0:
        42
        32
        pass
    total = value + len(text)
    return total

def _ПυКЦΧмЕαдЬλЦφба():
    value = 912730
    text = __import__('base64').b64decode('R3JCVmJZaUtmcDdraVNWcU5HcUw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        555
    return total

def _αнфяИσЦΖСεД():
    value = 106367
    if 12 * 47 < 0:
        448
        473
    text = __import__('base64').b64decode('YjRyeUpSNE5RdFYzdkZlYmZsOUk=').decode('utf-8')
    if False and True:
        _dead_9560 = 532
        _dead_9845 = 461
    total = value + len(text)
    return total

def _ΕΕгЪξСσηВφΨеР():
    value = 721805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDrlNmEtzYMEGTWuwwSRYBEuzUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΗξЦшЦЛρцыθД():
    if False and True:
        _dead_7495 = 849
        _dead_2858 = 182
    value = 360487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH3qVAE48L0TMBn092SCHyMd9zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оуСЧнГηκСοщ():
    if 99 * 35 < 0:
        316
        348
        pass
    value = 383574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jnq2YGkJ1LEgKwCcwUSkHicrzkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зжойШшΕα():
    value = 87149
    if len('') > 0:
        _dead_3758 = 317
        pass
        622
    text = __import__('base64').b64decode('dzZYTXphZU1JYjhkOWVzaVJCY24=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        172
    return total

def _кБвΚΡαюπμ():
    value = 10734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECLDNlNqrKYvCR+5zAa8EBN+wVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИОμЫЙΔДΖтχз():
    value = 334334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fxqwe3Uor5skagaumwe4JiMA500='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        743
        _dead_5447 = 52
        pass
    total = value + len(text)
    return total

def _ΧЦЛтφШпΡΥжауΣ():
    value = 735819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3bVfGYUr7Ibayf33Vm3ZXJ36Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шμςιΛΓхЯПπΠЩжΟ():
    value = 435732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXj+fkFhya4lHQW78E6yDDUb/Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 70 * 2 < 0:
        871
        pass
    return total

def _ЧЯХξЦΤлιьПГ():
    value = 723770
    if 28 * 99 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgjOXEAK/b4NCieqkFCVZnMq/Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рхзτчΒюδчχο():
    if len('') > 0:
        _dead_4303 = 505
        pass
        216
    value = 879402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTf9PXUa3/ozHh6q+3OFHg16y0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        468
        _dead_9486 = 874
    return total

def _лΤэцθΚэЪЭчβ():
    value = 122214
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBrVe0cr3ZIyLlqRkAWHEHQp20g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7666 = 434
    total = value + len(text)
    if 52 * 69 < 0:
        577
        759
    return total

def _аΒАцγκеВξ():
    value = 154806
    text = __import__('base64').b64decode('TlB4RE1taXVDWVJUMWFfeXRWRkM=').decode('utf-8')
    total = value + len(text)
    return total

def _зМРМσζθΕЗКхΘМКгС():
    value = 464821
    text = __import__('base64').b64decode('VUJRMXdZSGFGSUhDZkJZeWQxa2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖρмчаΙΜΖΥΚΘГсТγΣ():
    value = 818807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyDNXXADprxRFCWg2HqKNix7vHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖЪВаЬνυсиυЛЖφΡ():
    value = 259444
    text = __import__('base64').b64decode('bkdOanJRY0loZmZQWGxXa05QdmY=').decode('utf-8')
    if len('') > 0:
        _dead_5354 = 651
        _dead_6557 = 78
        _dead_7544 = 150
    total = value + len(text)
    return total

def _аψЖυηюЦЧФτΝПΜ():
    value = 656679
    if 24 * 36 < 0:
        pass
        _dead_7735 = 783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXrybGIN55ozbiqLkUW7Ih8tsHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯЖжλΖУХΓσψп():
    value = 176587
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwzrQQYg7vEVOzqtmUfHMzwZz1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6436 = 355
        _dead_2005 = 171
        _dead_3894 = 902
    total = value + len(text)
    return total

def _αноιГюфΧγиφъ():
    value = 190402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EALtTWY/+p5VMCP77VypZjEK3Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _УмφχΛшЭφсМееН():
    value = 113462
    if 14 * 87 < 0:
        _dead_5724 = 917
        pass
        _dead_4519 = 591
    text = __import__('base64').b64decode('elYyclM4UG1OZ3B0bDhjMDVJWEE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        40
    return total

def _χςφθωсШгαЦΒλ():
    value = 795720
    text = __import__('base64').b64decode('bEJsemxtSFdxQmRXR1lDZkhGNFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫςΟψΠΧκдщШЗπ():
    if len('') > 0:
        963
    value = 350448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjvRRWMb5qQZMjiP5lWVAgB4sEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 13 * 88 < 0:
        _dead_4171 = 648
        pass
        198
    return total

def _МЛуЧючκфραΣΟβ():
    value = 608914
    if 35 * 44 < 0:
        pass
        pass
    text = __import__('base64').b64decode('ZVM2YmJqcGRubnhYa1hTY2ZBaGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΕкΒκллыхψΔυΥ():
    value = 241065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ihe1RngN1qclPST3ygKeByAf4Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψсяРεΚяΝшκσθбДО():
    value = 555929
    text = __import__('base64').b64decode('RXNPclU5UF9OWTlncUx2Yk1SbVg=').decode('utf-8')
    total = value + len(text)
    return total

def _илжгРЬбγИΤΨκ():
    value = 904595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kgq8d0sf9P48FSSG+Uy9YHM+70k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юΙщοъςиюΦн():
    value = 88593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxC3XwYV14IzI1u14n7ABgR8ynw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νтЗКаφЕεнτфг():
    value = 306773
    if 95 * 44 < 0:
        pass
        pass
    text = __import__('base64').b64decode('WnptcjJaTkU0SEFldHZXeUUxeEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _вΠνтΙаφыΟзХΨθΦа():
    value = 281905
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSa8OHAu9pcbLg3w8H+dYQEKwn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыοΛяХбоВ():
    value = 667202
    text = __import__('base64').b64decode('QVdleEc1Z01LNE5SWkNWdlMzVDA=').decode('utf-8')
    total = value + len(text)
    return total

def _πЫРСыДЭφΡΜбξ():
    value = 484427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyPeQ38I7p0FPB2tkV+UBgAmzVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 73 * 98 < 0:
        _dead_9956 = 861
        pass
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('IA==').decode('utf-8'))
if len('xxxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 76 * 23 < 0:
    pass
    545
    pass