#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ωΡΔкψжаφΘνβп():
    value = 830289
    text = __import__('base64').b64decode('VU0xaTJmOHZZUllERElIQnppZWw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        343
        _dead_4591 = 357
    return total

def _ШφдΠмжТф():
    value = 732750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NijQRABt24wgKz6FkQ6WHQEe6lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫчψιиζαθМХНкщТΟδ():
    value = 182377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCTqOG4G/P1bA1205galMgwHtT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЯжаяцμФ():
    value = 774226
    text = __import__('base64').b64decode('RElaZlFIcGRnT3lHNlE2bDc5VjM=').decode('utf-8')
    total = value + len(text)
    return total

def _УСΘыФΚκωΘД():
    value = 328629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDXuegM20rFbKDeoym6WAXEf0Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚЬΧЗχЕЪфйцΨыЩКС():
    value = 481714
    text = __import__('base64').b64decode('UURXampZUk9TN21WeE5NdjJXaEI=').decode('utf-8')
    total = value + len(text)
    return total

def _εξΔΩУΟςЮлБ():
    if False and True:
        pass
        _dead_9218 = 679
    value = 991110
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('QXc5eTVNSG5GMWpIMTFMekZrcWM=').decode('utf-8')
    total = value + len(text)
    return total

def _κЫτЛКΡхΑΟ():
    if len('') > 0:
        pass
        _dead_7599 = 210
        32
    value = 566984
    if False and True:
        _dead_3562 = 415
        pass
        _dead_7828 = 117
    text = __import__('base64').b64decode('ZFNENER3bTZwbHVKcnNCMW9nc0g=').decode('utf-8')
    total = value + len(text)
    return total

def _лΗΑΛαвиьΒЧьчЯВΦ():
    if False and True:
        pass
        pass
        pass
    value = 57349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kwjhfwko2P0RIFaz+neSBikh4Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δфлλАШбφφΟИэυΓε():
    if 84 * 10 < 0:
        51
        pass
    value = 497278
    if 98 * 94 < 0:
        _dead_3720 = 46
        601
        _dead_5005 = 230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ign9WFYgrLxTNjbx40C9HAAL4H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6588 = 433
        _dead_5281 = 23
    return total

def _ιοцФнкаΚфЯ():
    value = 561328
    text = __import__('base64').b64decode('WFhoTFBZNW14Z01UZkd5TzY2amI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        282
        270
    return total

def _κъσΗМΡΨΑСдФψЬΠα():
    if 58 * 85 < 0:
        pass
        pass
        pass
    value = 876747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQLARnMw07oFa1iL/wWUNzJ5sjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫξΠΓСиσσХΕΥн():
    value = 525997
    text = __import__('base64').b64decode('bFl5QVJiOUl4Z2hGR1UzVjJRWFE=').decode('utf-8')
    total = value + len(text)
    return total

def _уЮМФηΩυλσЬ():
    if len('') > 0:
        957
        431
        52
    value = 363385
    if len('') > 0:
        562
        _dead_8994 = 190
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQHJQXY62LkVEDn2zG6fAnA96kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        558
        pass
    total = value + len(text)
    return total

def _ЯςеШчуыπПКМΩЬВч():
    value = 17277
    if False and True:
        644
        pass
        _dead_2412 = 573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAfwWWs87bAzCVyc5mWIBXcXzHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _вΜуδθШΕωχчаЪΤ():
    if len('') > 0:
        _dead_5000 = 403
        pass
    value = 455290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASj9eFAM9ok1YlyrxGe3HnUk6mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΣφхΥЧψЪρшНφ():
    value = 315775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EC3vXV0z8aYFNxeCnUCKBR0l70Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 82 * 10 < 0:
        _dead_3880 = 868
    total = value + len(text)
    if 11 * 96 < 0:
        593
        966
    return total

def _гΓСшбιΒζΤΡЯΚΞ():
    value = 944978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDuwPWcXxp8EECvz+UKfJy4C7H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 19 * 1 < 0:
        _dead_4083 = 574
    return total

def _νλγΓЙРСэωоΠчζν():
    value = 745509
    text = __import__('base64').b64decode('Y19DeEcwWkk1NU1DUWIyVjZyUWc=').decode('utf-8')
    total = value + len(text)
    return total

def _τηьЧшзРΦιъωП():
    value = 612256
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjfPeAkG8vgvPBixngeALgh78V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _илГОБыЬБ():
    value = 586541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCTTel8Jwb40MVuv+3WmLiIl5UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΥтГΗυмНΓ():
    value = 207275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASLvN0Fg7oEoET2B2HG9NjMk9l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φуΕыξλυЯξТφθ():
    value = 682236
    if False and True:
        pass
        118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHrOV1MK+ZorDCyg3EK0OX138XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΣζЦчαТΘΝΙΧп():
    value = 155212
    text = __import__('base64').b64decode('SHJOYXRYV0lPdWV0djRPWk0zV1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΖзΓζеΜЪΜЕΥпН():
    value = 495738
    text = __import__('base64').b64decode('b0s1ZElzRk9HRmozajVvUENjR00=').decode('utf-8')
    total = value + len(text)
    return total

def _ПρΣΓтчБζκαОсΥк():
    value = 1324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHvxPwAG+5svLw6v8VKjECp/12g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΕμдеТКδε():
    value = 541586
    text = __import__('base64').b64decode('cmI2VUVmMEt6YUxVMHBvallHNUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘвδзБьζφУц():
    value = 48078
    if False and True:
        _dead_5491 = 46
    text = __import__('base64').b64decode('blVYdzEzcmdQa0NmcTVTdnpoamY=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ГМζΩГчлЪУй():
    value = 268732
    text = __import__('base64').b64decode('eVJsaWRIbFJjUDdqdTVtQW92SHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙыσГХьКЦψ():
    value = 303121
    if False and True:
        _dead_8332 = 732
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCLJPnsjyvAUPhuwkQ6BPzAo50A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        140
    total = value + len(text)
    if len('') > 0:
        _dead_9105 = 77
        pass
    return total

def _ΒАψξеЗΑДбцΜЧМ():
    value = 80381
    text = __import__('base64').b64decode('U0RERVZWZnR3SDJKV3YzYmtOQlA=').decode('utf-8')
    total = value + len(text)
    return total

def _оΣθАλЯФО():
    value = 788612
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Inz3YgZoxKpTODaqxGmyNnZ89X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УщЭькΣэξΤΑвзТωР():
    value = 969980
    text = __import__('base64').b64decode('ZGxLbmRZMXJtUFliS3c5MDRSa2I=').decode('utf-8')
    total = value + len(text)
    return total

def _γΧΞΕСφЪЪюыρ():
    value = 233419
    text = __import__('base64').b64decode('dmloN29rcVBJb1g0VnVmTU5hdHk=').decode('utf-8')
    if 32 * 1 < 0:
        _dead_4066 = 240
        pass
        pass
    total = value + len(text)
    return total

def _еΚФюСΜΖЩАπК():
    if 4 * 28 < 0:
        pass
        506
        _dead_9279 = 63
    value = 540838
    text = __import__('base64').b64decode('Yko0MUtPTTdGT3ZQMV9ySlpwWG8=').decode('utf-8')
    if 3 * 40 < 0:
        pass
        _dead_5163 = 123
    total = value + len(text)
    return total

def _ШνРεЕΥПй():
    value = 838302
    text = __import__('base64').b64decode('Q2pfY3ZOM2NTYmlSYmJUTzVmRUw=').decode('utf-8')
    total = value + len(text)
    return total

def _юЮБхРΜЫΞ():
    value = 477563
    text = __import__('base64').b64decode('VU42ZldNZVQ0aVVKZWtRMmMwaDU=').decode('utf-8')
    total = value + len(text)
    return total

def _μςВлΓΥВΣ():
    value = 430228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhzRWmZs7rknEASm4kykLBYX93g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΚфΦЯршниΝΜΤФг():
    value = 905064
    text = __import__('base64').b64decode('cVNlOUpISUhkQWdzeTlTYTd0ZXU=').decode('utf-8')
    total = value + len(text)
    return total

def _щвюЦЗλΞЕεЗИγсχС():
    value = 864824
    text = __import__('base64').b64decode('bzVnYzBHdWVFMHRrTHBXZVp2OVk=').decode('utf-8')
    total = value + len(text)
    return total

def _сΞρухбаЬνΦРЭ():
    value = 557508
    text = __import__('base64').b64decode('aDBHMThybkFOSjdjZnNNQXNEQUY=').decode('utf-8')
    total = value + len(text)
    return total

def _πΟЬбκΦκбιе():
    value = 919184
    text = __import__('base64').b64decode('cUxkeUk1NU83QTFnRGt5MUVicXc=').decode('utf-8')
    if 43 * 93 < 0:
        _dead_7635 = 807
        _dead_5920 = 773
        249
    total = value + len(text)
    return total

def _уиΛпΜεΟΣКΞАπΩ():
    value = 323959
    text = __import__('base64').b64decode('c0tNM1V0SElWY3JWQk4wQ2E1YzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ШъХМΥλлΕуьνΡκ():
    value = 612532
    if False and True:
        pass
        _dead_3773 = 372
        _dead_4036 = 349
    text = __import__('base64').b64decode('dUZ6d252QmlSYWpnTEhFUk4xR3Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        363
        388
    return total

def _ЦωЖτΩчΕΞРйП():
    value = 707119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyXbfVAL/aAFCz+a7AeKZQodwnQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬсπХΡЗνΡΡ():
    value = 371219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHrXV149150uaQjw+AK6NgMu0Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΙдΝΨχΓΣыгωЙЖΗ():
    value = 723382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyfyTXsaqoYsYi6UnnrCLn0GyGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фτνΞΞЙьЧр():
    value = 1703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISHBfm4JyvENOwqT8W6WPnAG0WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒнЯξβΨАюр():
    value = 718127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBnAPgMo9/4mCy2bxkyzP3wm9nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΟαЛχτιВъ():
    value = 446796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRvlRlUNqLgqHCuhmnuRMCoA6Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вεΓэпЦрΚфΛχК():
    value = 584960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHnPNgYd0/0gFl+hwmO/YDZ5vHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩψЮЮνΝьΔ():
    value = 392383
    if len('') > 0:
        891
    text = __import__('base64').b64decode('V3RxakVJaHZGeEl6UWhmTTBGUnc=').decode('utf-8')
    total = value + len(text)
    return total

def _λοТМΝфБρδδΧУε():
    value = 256711
    if 39 * 14 < 0:
        pass
        644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CznRdggR1bBTFCSsw2WnPCI2z2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΨΛПиξΚпЙΤ():
    value = 288894
    if 21 * 10 < 0:
        859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSHre1wMqr4wKRfw4XeSFg4GzEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ызξβИлΘπΞ():
    value = 341551
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAvBR1cUp/wkYwCm0FHDMQ8N7Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шμеυцНщт():
    if False and True:
        228
        _dead_8447 = 16
        pass
    value = 172583
    if 55 * 61 < 0:
        pass
    text = __import__('base64').b64decode('bUZVRHpjcEU4RG1jZmFINGk5YjY=').decode('utf-8')
    total = value + len(text)
    return total

def _гЗоЖΞσЗτТκΖнΩΡх():
    value = 792840
    text = __import__('base64').b64decode('UEpOQk9VbkE0cVFFYzVJOXhfaHM=').decode('utf-8')
    total = value + len(text)
    return total

def _сзЬλΗχлμυЧЩИΤ():
    value = 720796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwPOT0Fs/ZIxAjaXwgaXGCoDt0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЩΔγωΒшЧβΔиΕ():
    if len('') > 0:
        136
        89
    value = 887529
    text = __import__('base64').b64decode('VWhrUEpOenNtVDdmV3R2ZnNTeFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖеДыΡΝДОΜΓΔХЖЧсЬ():
    value = 291603
    text = __import__('base64').b64decode('eWo0dkI5eG5PWENPYmFtZVZHOHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮωηΥлΜεηΛτ():
    value = 900666
    if False and True:
        _dead_5243 = 198
        _dead_4146 = 798
    text = __import__('base64').b64decode('S3ZNNGp6SmtjZHdxWGkyWXNEVmo=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЗАουШτЙЗЭ():
    value = 881473
    if 53 * 95 < 0:
        311
        655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQi2fHg2xp4mYjb36l+5OBx9y2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НλΜыΟΕεнπяЧуΔЭ():
    value = 645569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHjlZHlv8f4sFQqwzXGmLQgg41Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΒМνвπψΓφυГс():
    value = 999184
    text = __import__('base64').b64decode('a1RNVlJUQXM5UHhzRzBwMEVLT0I=').decode('utf-8')
    if False and True:
        352
    total = value + len(text)
    return total

def _ΔАСΚТСЯТ():
    value = 811301
    text = __import__('base64').b64decode('YUxDQzVtZVJFcms5NDRCZHpraXo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _дωλфννеα():
    value = 751112
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQHqVwNo7qdbbzmq7V7DMwQ412I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩЩιρоεьЪВЪы():
    value = 247586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyLbRF0N9olXCDaqkGzDJHMJ80k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔиьъКяЯн():
    value = 98316
    text = __import__('base64').b64decode('eGZvalpFdGNacG9vZzJrY01hRk0=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        _dead_1671 = 988
    total = value + len(text)
    return total

def _ыеЯΤΔζФнхμъмЖдγ():
    value = 623073
    if False and True:
        _dead_9625 = 90
        _dead_2893 = 386
        pass
    text = __import__('base64').b64decode('WWtnYlI0REdNSGhLR211TzF3eG4=').decode('utf-8')
    if 55 * 56 < 0:
        _dead_5200 = 417
    total = value + len(text)
    if False and True:
        pass
        473
        pass
    return total

def _ΔΧжГΦкΒΚцΑнтяГΒΘ():
    value = 64291
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByT0e0EN9acoKli2m3ixInMVwUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЫψАαΚЬΨΗыηΘ():
    if len('') > 0:
        pass
        447
    value = 613481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh/UPnwz8fEUECOE22mXEXAHwD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫααеДΓСσΡΡоεШΜ():
    if False and True:
        pass
    value = 221578
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jnm8YXUqx606KVmWzgOJZwt8xV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШямЖΖτцφΞΟфтвΨ():
    if False and True:
        193
        _dead_7449 = 427
    value = 442442
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCfvQHIs74IZOy6nzAOTBAQdxWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΦΘυГτδчρυΚАΙг():
    value = 123403
    text = __import__('base64').b64decode('YmRrc2t3VHZkdjJwMjVrdlBQTko=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟδοьчΥλΤΘгнгρСψш():
    value = 405775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAbVPwVup/A5LyOnxnmyHCE68l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖАЪБыРΑсΥγъΜ():
    value = 254058
    text = __import__('base64').b64decode('bVR5R0dQWE1oUUp2UVYwcnltNDQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        390
    return total

def _ΑЖЦВθφркΚ():
    value = 244194
    text = __import__('base64').b64decode('S0w5Ylgxc3dBUUFrR2dQMlZDUnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯζΗЩбАСΥΙ():
    value = 525731
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwDrdl016Z4aCAOWkHCXHS0o/D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3691 = 797
    total = value + len(text)
    return total

def _оφγСцζωζΔЙЖр():
    value = 780835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwTKTWVv2aEhKQ6vnAKnMDYb6ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лφЛЙЯυыΔκолфдΣВл():
    value = 415913
    text = __import__('base64').b64decode('aWpJN0RhY1RFYUJPVllUZGdqM2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _зЕЛйЦψНξхоы():
    if 4 * 75 < 0:
        pass
        523
        pass
    value = 467738
    if 96 * 35 < 0:
        pass
        535
    text = __import__('base64').b64decode('ZlVuOThKUTBYbnBXZlY2ZTNKUkU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1192 = 8
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    pass
    _dead_9949 = 199