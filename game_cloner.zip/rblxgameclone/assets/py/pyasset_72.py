#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ςβХΑΑзΚЙθуЕςφ():
    value = 188607
    text = __import__('base64').b64decode('WXBva0JGdTJzY2tha2xpSl9MRFk=').decode('utf-8')
    total = value + len(text)
    return total

def _λМЕтРППСЦ():
    value = 429568
    text = __import__('base64').b64decode('cU9fT2RjeFh6ZDlGMmRMOHB3MEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ДфаοПрйχνщ():
    value = 811595
    text = __import__('base64').b64decode('QTBDZEFucnB0N2pYVkxmOXhUeGs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        337
        pass
        878
    return total

def _ЙЗΨГΦАΦяΩ():
    value = 963480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwjuRGsR87sXLluH3FKaHCM380E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЪРьЧбΨКλ():
    value = 785258
    if 12 * 94 < 0:
        584
        897
        _dead_7861 = 388
    text = __import__('base64').b64decode('RGtBNGdwRllBS0h0dzVwWlpSaWg=').decode('utf-8')
    total = value + len(text)
    return total

def _фΥΜΔΜΟЙζЛзΖВкηΚΥ():
    value = 302389
    if len('') > 0:
        777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eny2e0Iw9vpRICf3+XzCbA0E/T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 55 * 23 < 0:
        pass
        46
        _dead_4124 = 191
    return total

def _χΣΙΓТлΥаςЙξγΝЮΒы():
    value = 202043
    text = __import__('base64').b64decode('ZU03V21CbUt6M3lKWnFlaHZRZUU=').decode('utf-8')
    if 94 * 1 < 0:
        641
        785
    total = value + len(text)
    if 17 * 98 < 0:
        418
    return total

def _ЬΧΔлОςФΨξГ():
    if False and True:
        _dead_4134 = 993
        96
    value = 151789
    if 40 * 76 < 0:
        _dead_9669 = 355
        pass
        819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT7pNgY4qaU1MDeuymyVNyJ85W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σжбчΛЪεфеХв():
    if len('') > 0:
        pass
        226
        pass
    value = 205501
    text = __import__('base64').b64decode('ckRQU1FkTDFmSXBjVFM3SnlyRWI=').decode('utf-8')
    total = value + len(text)
    return total

def _быДщЖΦВξψЛжθчУΥД():
    value = 593105
    text = __import__('base64').b64decode('dG1ldm9lRjBlTDJWVGtzZVI2Q2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟγςσуΗΝЗΑлтШАХыλ():
    value = 353289
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXezZXJrppdRPASc5nGIAjUf5Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τиςκФΕгЯε():
    value = 734883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCT8R24T0qEEFwCi3WC3ZCkB930='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 7 * 80 < 0:
        809
    return total

def _γοьχπτпΖζ():
    value = 355105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwHiel5vwZARPgOwkXy4FREl4jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 67 < 0:
        pass
        77
        327
    total = value + len(text)
    return total

def _ξоЭсΞгГΑвЪΕΟηΔ():
    if False and True:
        521
        _dead_6246 = 860
        765
    value = 71963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXzpewYdz7IkCCKu/ETBZwMM/EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΧΚщЮУсОΤйηθЦθ():
    value = 293017
    text = __import__('base64').b64decode('S2ZoR2lTcHRRZ1VWRWZKY292N08=').decode('utf-8')
    total = value + len(text)
    return total

def _πВгюΙιсТЕцΚхЧςΑ():
    value = 606152
    text = __import__('base64').b64decode('ZEl1dWk4UU1tZ0tlcU1JT0NDQ2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭНΕωлΒΔгτ():
    value = 496391
    text = __import__('base64').b64decode('WlJJc1JaZklYaDdfTlV4T2NyMFg=').decode('utf-8')
    total = value + len(text)
    return total

def _δΒεпгηηЬйчТωяΝρ():
    value = 279029
    text = __import__('base64').b64decode('bUNOZmRUTU5Bamkya0l4VFJkSTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭзиуτрснЗωЦΣ():
    value = 754775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQTgRwA72oxaYwyLzVq8YDQB4Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βαΠΕХΣмΗЩУЙЪοьз():
    value = 410602
    if len('') > 0:
        _dead_6360 = 917
        pass
        225
    text = __import__('base64').b64decode('bERJeUFHUUZJYzBHZGwxZXVLTHA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        590
        pass
        pass
    return total

def _ςЖюβХΗеγЮυ():
    if 53 * 87 < 0:
        383
        42
    value = 7039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fg3MWHwvyYoFCx737EWJNyAO4nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        488
        134
        _dead_5503 = 905
    return total

def _βуγκγΡεΨФа():
    value = 18590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSbwVgEt2oIzaVf76ka5DSQfzFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 58 * 75 < 0:
        _dead_6629 = 896
    return total

def _οφδЧЮбкΨΛο():
    value = 25288
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSDJOlJoqf03bgiMy12HPywdtXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4860 = 177
        pass
        523
    total = value + len(text)
    return total

def _ИоΥгяНВΙЩцΩэ():
    value = 715879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICjrXlc7qL1XF1it4VOnECYQs30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΣдъАДξθφΝνуψξА():
    value = 435813
    text = __import__('base64').b64decode('TkNuOGxZelZnWE9jX0ptQ3h2Wm8=').decode('utf-8')
    total = value + len(text)
    return total

def _лтΕωщЗκΘνθρΜΗ():
    value = 889898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSW2YWUI8Y4LLDu06Wy5Oyg1xzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кξιΓНМдΞзΔчΨ():
    value = 437795
    text = __import__('base64').b64decode('djZwc3M3OWVvWnVJMFNmcENyNzI=').decode('utf-8')
    total = value + len(text)
    return total

def _эРμАЫΣНω():
    if len('') > 0:
        pass
        699
        _dead_3021 = 675
    value = 894790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHbjaQNq0v4sbzm65VPDPQB33W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΑРмШэВΥАТЙΓх():
    if False and True:
        _dead_9921 = 562
        pass
        _dead_8115 = 404
    value = 138345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCftQWkY+5oibTWN3UagPQc6/H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΤΥвАχОшжТδфэΘц():
    value = 259017
    if len('') > 0:
        _dead_4173 = 711
    text = __import__('base64').b64decode('Tk5vNHVsQzlVcHg0MHVPQUluM2E=').decode('utf-8')
    total = value + len(text)
    if 2 * 9 < 0:
        pass
    return total

def _ΒδЩΜΡЮРΩκ():
    value = 956885
    text = __import__('base64').b64decode('RUh6dkFCcUw1YjdkUGplRWhCVFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΒУΖсфдеΒ():
    if 67 * 82 < 0:
        949
    value = 274375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhbVQwdq9bIoFQahy0+8EhIe6Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ядΑБирЙцτ():
    if False and True:
        pass
        pass
    value = 578676
    if len('') > 0:
        _dead_5345 = 90
        184
        166
    text = __import__('base64').b64decode('cDF6M005NkFoVWpCSHVEd094NW4=').decode('utf-8')
    total = value + len(text)
    return total

def _МРΓОоХьНл():
    value = 976898
    text = __import__('base64').b64decode('RG5BSENJMDhLTzU5UDVfSjdna3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙτиΟГΨυεлКЙΜаК():
    value = 238346
    if 73 * 100 < 0:
        _dead_2172 = 682
        _dead_6026 = 809
        _dead_4623 = 497
    text = __import__('base64').b64decode('TlJwSF8xMFN5ZUtxSEltMW80bl8=').decode('utf-8')
    if False and True:
        _dead_8888 = 669
        pass
    total = value + len(text)
    return total

def _рλΧНТчΩдφРчйΨаМΡ():
    value = 712152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICncNn9p//80Nwfy2lehFwEb4Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φЗΓΤпθμк():
    value = 323449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax33Olwc67JUAlqb2XGTPDQ44UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зωжγβЙшс():
    value = 182639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jgr1f2Mj9fk2LlqB0mmaHjx24zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 19 * 24 < 0:
        pass
        _dead_1823 = 827
    total = value + len(text)
    return total

def _κизαТШμЕСжНЩЛΨф():
    value = 666354
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHnHRWAzqfs8Pja75HeKYhUYs1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        743
    total = value + len(text)
    if False and True:
        660
        960
    return total

def _ΑиψшχаξΒΖСηЧФЩΘ():
    value = 980812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAnoWAMR2IcnYh6E3lymMz8kwDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЭпЬзеРИцИΖ():
    value = 290179
    text = __import__('base64').b64decode('VUROcTFXalhGT3J1WnpiMkRaMVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥЬыСХιЧзΝγ():
    value = 269500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiTMaQMM1/kZOSK78VyaYhcm4kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛБъνмψхΓ():
    if 79 * 58 < 0:
        645
    value = 300494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxfNTGJur/0yNAyEzWDGGxIQ0UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        144
        _dead_4121 = 617
        47
    total = value + len(text)
    if 78 * 93 < 0:
        586
        579
    return total

def _ЪуΦΒбКρβгыЦХР():
    value = 643253
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR3BQQkeprsZHCib3FPHPzA51k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θДоΠψлЮΩОς():
    value = 740080
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx29dEg91YkJDCCtwFvHFTUez0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МоφΛЕΕемщц():
    value = 87223
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cii9QEIj/4sNalmTzl6ZNxx/ykg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛзΥАφΥяПЖбФσФ():
    value = 376215
    text = __import__('base64').b64decode('S3lnUXV2ZTNnSWN4WXhCSGpKSFA=').decode('utf-8')
    total = value + len(text)
    return total

def _кХφаКкъЬП():
    value = 10498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgXCX1IMzPsRPzaF8FW8Pw8N6T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΤβШνψΟжоГт():
    if False and True:
        955
        806
    value = 670665
    if 69 * 44 < 0:
        34
        _dead_7657 = 589
        778
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA7TQltgp6IJER728n/HEjwZ534='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2799 = 166
        208
        4
    total = value + len(text)
    return total

def _ЫρΡοΑМбкЫбΧΖυтΕ():
    value = 332244
    text = __import__('base64').b64decode('cmpacFY0YzF3dEVVeHJpM05lVTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΨъνцЕωΦЖψвΝχ():
    value = 625243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHqzaEcx7akWbyD7xQW7H3V2z1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΧЖΧЧГКΣλΖПвЕ():
    value = 379235
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MinpSkAO1Kc1LQ6ZwkS5BAB3tWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡыгζεΩЯлΑпОЪζ():
    value = 637571
    text = __import__('base64').b64decode('ZENzQmV3NzFEYjFQeko4TkZkMVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ъШβЯλνБюφ():
    value = 32329
    text = __import__('base64').b64decode('ZnpDX1daOTVGa2ZKaGs3YldFQ28=').decode('utf-8')
    total = value + len(text)
    if 9 * 73 < 0:
        31
        _dead_4961 = 77
    return total

def _ΕονафχПЬγЦ():
    if 64 * 91 < 0:
        pass
        100
        _dead_4224 = 915
    value = 392228
    text = __import__('base64').b64decode('UVhteG9FdTJad0VPTWRwWWt3c3U=').decode('utf-8')
    total = value + len(text)
    return total

def _БеЫΟΩГΝю():
    value = 163153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQjDV2IU8qdbPxWHwHWAEyEVyUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нЬаαΒэβПΣрВμΛАБм():
    value = 56682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX7POkEd66EEESaN636FYA8OzTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯζλΨшΚзч():
    value = 252978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAS0ZwYp9fAhMjeEz3WCPjYq0Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _НθДθΝΨЙоθΛЧΛЬ():
    value = 161079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy7WXGYPwaMMFFz25XKZITF+t2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΜзΣчбпψΧΔΒξςηΟΩ():
    value = 753868
    text = __import__('base64').b64decode('SG8zMWRzdjhTTjZUOTdvRVVyV0s=').decode('utf-8')
    total = value + len(text)
    return total

def _εВΒωнЖьЕИβΨХι():
    value = 948384
    text = __import__('base64').b64decode('SjJPVTBBTTFQMUhnMjZpUG5EeEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ФВеΜцяУЧΘ():
    if len('') > 0:
        pass
        _dead_9194 = 641
        _dead_7497 = 554
    value = 540179
    text = __import__('base64').b64decode('R19JYjBxTHdESDhUV2lmX1dwM0E=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        235
        pass
    return total

def _νпНΜκЩБθξЯе():
    value = 854833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KynUdmRu9a4EDweHwQTCEgw40kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ххТЙюЙАνςχв():
    value = 891784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxfJRgkQyokmLxqt/VCdNwgo42U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        209
        pass
    total = value + len(text)
    return total

def _φбκяΙμЮПфшΟ():
    value = 923403
    if 47 * 57 < 0:
        _dead_1664 = 440
        754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cx/VT3xq2rxRbBmhkAPEJTQb5UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΓνΥοдΣЯЕξ():
    if False and True:
        318
    value = 104350
    text = __import__('base64').b64decode('a1lmWlZmR1dGVjFXSXJ1S1Q1c3I=').decode('utf-8')
    if False and True:
        _dead_2557 = 808
        pass
        pass
    total = value + len(text)
    if 99 * 8 < 0:
        _dead_4244 = 601
        pass
        pass
    return total

def _УΓЯОыГτξΞМКΔлτъу():
    value = 381895
    text = __import__('base64').b64decode('dXpUalBnQlFhUFh2UDdSUW9DMEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑТΠβкΒВξнЪ():
    value = 185771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxuxT3Vt14smbVn6xG6fAS0EymA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жЕΟΧциΕΩοθОРθгчΦ():
    value = 217418
    if 45 * 15 < 0:
        562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT/oQ2sDxphbCgz3zQDAbTwl7UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩφЗΠπφδгЕУЭεбΧь():
    if False and True:
        pass
        490
        728
    value = 87396
    text = __import__('base64').b64decode('eDNlVzRUTzlWc3F0d2dzYXpUTTU=').decode('utf-8')
    total = value + len(text)
    return total

def _цΙЬчΒЙζжЧσΕ():
    value = 192070
    text = __import__('base64').b64decode('Q0RkU2QwMmcyVHJRVjlKSG5EZ08=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΟьВΤжЪшΜЖН():
    value = 279667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADX+OWg23JISBSjy/Xu9YAAC6mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΚτЕΨΑιЬБλΦΣΝψрν():
    value = 884556
    text = __import__('base64').b64decode('UnpGbm14VEhOcjdrbjBZeDRHRjM=').decode('utf-8')
    if False and True:
        _dead_1272 = 973
        788
    total = value + len(text)
    if len('') > 0:
        855
        pass
        pass
    return total

def _ПЩУбοΙбЙΓХизтш():
    value = 54457
    text = __import__('base64').b64decode('ZjBnbHdNQzZfZFBVSkpWYllvdnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _пΜνЯΑυΨНμАПуΦ():
    value = 962420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAy8fm5prY0UP1y3x2/GYz0J9Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хшδрНγЬцΟΖζΔвКАу():
    value = 631034
    text = __import__('base64').b64decode('SHpNUG5iNDFUa3A3amNmNDhTeXc=').decode('utf-8')
    if 24 * 99 < 0:
        _dead_7435 = 77
    total = value + len(text)
    return total

def _кξΞψρνпсжТпа():
    if len('') > 0:
        _dead_2383 = 246
        _dead_9049 = 892
    value = 686403
    if 43 * 80 < 0:
        pass
        565
    text = __import__('base64').b64decode('ZFExWDlEWE9Sb1NDbWF0YzV3Tjk=').decode('utf-8')
    if 8 * 8 < 0:
        596
    total = value + len(text)
    return total

def _ТШрυъДσΗрε():
    if len('') > 0:
        125
        _dead_6905 = 566
    value = 686570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDriPQAYx/hWMQGixnyyLScL22o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6965 = 768
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        845
    return total

def _χнДЭχзΒи():
    value = 267606
    if 94 * 53 < 0:
        _dead_2093 = 441
        _dead_4585 = 216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDXKWAc11awRLhyWzlvFY3c87lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йкябκΦяЗγЯΧТЯэ():
    value = 420304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By7UaAcW6/0hNiGW5m+CHwIj20E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яНТВΟюЧИ():
    value = 107100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHq1eEc82ps3MF3651eXICB5z1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΖΡсζΞψΣр():
    value = 767687
    text = __import__('base64').b64decode('YWlBWnFyb2ZFZ2hnYl9QenFIR0I=').decode('utf-8')
    total = value + len(text)
    return total

def _κΗцДЗνλΣχуΧ():
    value = 852438
    text = __import__('base64').b64decode('TUV1eVZJNmg5WHNYbHY0SlhXQjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩаυΕφξПΜРЦλЭηβΤб():
    value = 9099
    if len('') > 0:
        _dead_7792 = 515
        847
    text = __import__('base64').b64decode('T29HRG9vY2luMXdiYXJqdDNlVHE=').decode('utf-8')
    total = value + len(text)
    return total

def _лσΛпЮχНΙпНΧΧф():
    value = 513707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AifKQVsp8ocWGwGi3QexLXY61G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξТЙΣΩЩътяМΝзХ():
    value = 251858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz/UWHkx+70HMliC5kSKGykq4m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑυЭχфΔАыаоδсфχΡШ():
    if False and True:
        931
    value = 971930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXnXXHRo15kVPgWOyUadIn0K/Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 94 < 0:
        _dead_4114 = 45
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_8313 = 582
    return total

def _ΡюφвЫΒλδщВΡьвлКУ():
    value = 499150
    if False and True:
        pass
        731
    text = __import__('base64').b64decode('anBvNDdsb01VQVhpQ2xVeTFJUTM=').decode('utf-8')
    if len('') > 0:
        187
    total = value + len(text)
    return total

def _РлцоБγИЮВлга():
    value = 756945
    text = __import__('base64').b64decode('d2Q3RnJPUDk0eHlqUUF3UTJfd1Q=').decode('utf-8')
    total = value + len(text)
    if 14 * 64 < 0:
        _dead_4309 = 52
    return total

def _γЯΤТфДΞεξ():
    if len('') > 0:
        504
        pass
    value = 748106
    if False and True:
        _dead_9035 = 469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECzhf3gr1Z07CDiw/kSqYxEa7lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХНΨфЪυЦЙЦЯΤсΦψζх():
    value = 844090
    if False and True:
        pass
        _dead_7787 = 821
        151
    text = __import__('base64').b64decode('SzhyWXFfd1dUN2N0QmRoT09Eczc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        390
        _dead_7937 = 162
    return total

def _ψΞЧЪШаЛзЪЬЦ():
    if 13 * 48 < 0:
        _dead_3634 = 527
    value = 355236
    if 49 * 28 < 0:
        733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyayQkMVz7hXHDit3VvEICIjyVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 67 * 54 < 0:
        656
        458
        pass
    return total

def _ΒθΠДξΤνΞΙхфе():
    value = 397273
    text = __import__('base64').b64decode('WUVOZDFRejI3eExBX09OYmtRZkU=').decode('utf-8')
    total = value + len(text)
    return total

def _γеюпΑяςΖчΨΡУαэΙω():
    if len('') > 0:
        _dead_9459 = 212
    value = 198772
    text = __import__('base64').b64decode('WVk0QW1uWU5vT2VOdGZNNDdNckM=').decode('utf-8')
    total = value + len(text)
    return total

def _хχдΦΙΘΠΤьеξк():
    value = 530902
    if len('') > 0:
        64
    text = __import__('base64').b64decode('Q3E5b2NBWTdlZUtDajg4MjFlT3U=').decode('utf-8')
    if False and True:
        244
        pass
    total = value + len(text)
    return total

def _всψжχΘьΗ():
    value = 658034
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAXKVFks86oQDwqBmX3AJH0G6Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦъβрбГЕЭΠνГ():
    value = 485411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgrlYGsbqaE6Mx2F0EyVCyQ962w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НФЩыεγМзжйле():
    value = 979280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQToSkMD+IYkFA6r8nTJGzQb02g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦщчПнΤτиαкηеΜ():
    value = 909436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwHlY34h7Zw3Lz2i62mWIisC4GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЩΤΓксαιλ():
    value = 778141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EH7BaX0xxv4Wa1vx8VqpPhQFyW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2663 = 357
        _dead_7098 = 400
    total = value + len(text)
    return total

def _юχцЫЮзКПоφι():
    value = 142716
    text = __import__('base64').b64decode('RUxKMnRVcUZSZzFCb1pzT1F0a28=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗηяκуИльζΖйд():
    if 4 * 3 < 0:
        _dead_8757 = 733
    value = 589960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzmxNksB9JguEx+J5FCHZgcF7mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зцсγшщЖηΑεЯхσЮ():
    value = 861735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhDtSwIQ8oE7GB2En2WeLAc+0Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΩнвΙщВАЫπнΨΙ():
    value = 991711
    if 24 * 56 < 0:
        _dead_8318 = 436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgDBXGgA+pEqEyqrxUG+DQgh514='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 91 * 98 < 0:
        567
        417
    total = value + len(text)
    return total

def _ξмΤηξКУΒΒΠΙфΤЭΝэ():
    if 7 * 91 < 0:
        785
    value = 550864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRvyR0ho2ZEXFF2Oml2DBzB55Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        301
    total = value + len(text)
    return total

def _чтНУΨΑибμυΛС():
    value = 311577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EizqTVkh6qMoGCGhmFuAOCx/9Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΤГΗηПΖιΒΡэфИ():
    value = 709122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHj+S2k89IkxOz2nmVXIMgMF/Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΡЪюЙчΟжβλАΨПΗζΩ():
    value = 450897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTbuOkUd/YkaDimLxUOJPSon1jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΣΔρОΞΙγδιгоξтςн():
    if 65 * 88 < 0:
        _dead_1736 = 281
        pass
        32
    value = 55909
    text = __import__('base64').b64decode('cHJNMHpYSGpseTBwMHhmbExpeWw=').decode('utf-8')
    total = value + len(text)
    return total

def _оШξБυеоΔфΜΧЯ():
    value = 344332
    text = __import__('base64').b64decode('eFV0Z3JQeXJuM2IwSG1xNkcyTzM=').decode('utf-8')
    total = value + len(text)
    return total

def _вΗыΒюΕцИЙРφХΦξСο():
    value = 317941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwXnb1gy06onAjv6kVubI3d44EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΗΗΟΙТсТοΧζ():
    value = 178553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MR/xaGk914EyBRiw43HEEyx39WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΛγΕΜьΖХаЭΣΥрΔБ():
    value = 169216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTXGbFMt+oYTAiPyzQWkG3N95lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δεЭρАΚАНстш():
    value = 759866
    if len('') > 0:
        pass
        _dead_5424 = 996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyfMXkFo2b8BA1qT41jDBCQdw1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 37 * 62 < 0:
        _dead_4231 = 731
    return total

def _фςХЯΙхзΧфуЗΣБεΠ():
    if 22 * 71 < 0:
        970
        pass
    value = 652919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kz7zZl0Yq7lTERjx5Q+iBy8A010='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 24 * 36 < 0:
        _dead_4490 = 824
        845
        pass
    return total

def _ЩкΦьгузЛФпΜсη():
    value = 674905
    text = __import__('base64').b64decode('aWljSnd5Q1JxaFllTjRESDhlT2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡγΠЗΝτςΜъГυСДη():
    value = 883584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnnhWmEX5K0oMBf6+Wa4Fgog6l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хЪЬβшΡалΚ():
    value = 354806
    if 100 * 78 < 0:
        _dead_7421 = 140
        pass
        pass
    text = __import__('base64').b64decode('YV93b0RvTlc2RjdrbTJwc2pBa2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ξОΤпбЖΓсβщРПлα():
    value = 772888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CS7jeAAazPg6A1yrkGGDGRMctTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 99 * 77 < 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _пЗьΗЧΗЬпт():
    if False and True:
        pass
    value = 198701
    if 79 * 24 < 0:
        pass
        _dead_7182 = 463
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J371Qm4Yy6woOz377kbADisn4Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 96 * 71 < 0:
        142
        pass
        424
    return total

def _ЭΑΟщЦрнФυΩЛС():
    value = 336371
    text = __import__('base64').b64decode('Y2lHM2VmZGpxaHJldk5hVzlyWkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘОφυвαΗХςлτДΟйа():
    value = 769805
    text = __import__('base64').b64decode('WVE3SElldnhSSk54b2JsMVhFNU0=').decode('utf-8')
    total = value + len(text)
    if 70 * 87 < 0:
        40
        138
    return total

def _κΠРτжЯЮοΜЛМπщн():
    value = 359530
    if 58 * 96 < 0:
        pass
        267
        76
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAfWP34g154UDjb22GSKBHY5y0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нКбρтеЖαЮЙΩΚ():
    if len('') > 0:
        _dead_7001 = 870
        pass
    value = 401624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQHbRVIB0ZEbGAbw517BZyd93Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _паΛНπΕшЮ():
    value = 794693
    text = __import__('base64').b64decode('YjRUYURBTWc3d29TUmgwenZuVEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ωмрйχпяΞΒνΑх():
    if 1 * 57 < 0:
        _dead_4845 = 289
    value = 672619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXzOeUts+qMJDiqs+QSGHycX3Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΘθΞЖГЕΑφμΧцБпср():
    value = 169361
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px/+bEYorqYGF16k7meIGScL1mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4851 = 780
        pass
        _dead_5374 = 590
    total = value + len(text)
    return total

def _аыГΥПπДъбЪΟШаβпи():
    value = 403976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXzqNwQ0/IszDB+nmgehGQQA70E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _снΣсΓΒЗπφппТКл():
    value = 435861
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSXneGZpq75QDhby8HWjFi4qtzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛЩчΒКШτиТζθ():
    value = 266538
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3/SQAkurKlUMg637UK1OhE1sGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΘДΗΦхеЛιЯАбεВыω():
    value = 239097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzreQXo2xpwbaVzy/neYAHU9vEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зιПςзΒжЫЙΤЭΖФ():
    if len('') > 0:
        _dead_2690 = 525
    value = 672630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyTyTX4J8o8hbDeN4FCqMHN99FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 17 * 50 < 0:
        781
        663
    return total

def _ЬφωтτΩΣхДΠΟцπ():
    value = 460297
    text = __import__('base64').b64decode('bFppcWhfQXNCQ3VUWWswTngxcVg=').decode('utf-8')
    total = value + len(text)
    return total

def _дξИЬьзμΒчЩαЭН():
    if len('') > 0:
        _dead_7405 = 247
        _dead_4945 = 36
    value = 710412
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHqzRgNs3YsGDziI3H/GYH0B51k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΤгАηβУкζР():
    value = 154871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT68N3gQ2KpQCjaG2lShDBwW6WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    if 59 * 6 < 0:
        303
        pass
    return total

def _ЦυуΨμэΞшоЙλΧЭД():
    if 18 * 80 < 0:
        _dead_8060 = 801
    value = 817996
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyLuNwEy56xSDCab/w6TLT0F1m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        871
    return total

def _εЩυΣΝβооякω():
    value = 53927
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('Z3JnVGo4UTQ1ZVN1XzROaElCV2w=').decode('utf-8')
    total = value + len(text)
    if False and True:
        664
        786
        pass
    return total

def _РщΑЧОΙлщК():
    if 60 * 42 < 0:
        _dead_5971 = 587
        _dead_7971 = 376
    value = 337506
    text = __import__('base64').b64decode('Q2oxYjJzUTN0Ymp4M003WkF4Rmw=').decode('utf-8')
    total = value + len(text)
    return total

def _УΗκΘбЦφаХЗчЩ():
    value = 336888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQjOXXMD6bg2Lz2G+HuiYg8f1jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _члαРЯвσзαЬД():
    if False and True:
        pass
    value = 955197
    if False and True:
        pass
        213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ihf9VnUz1ZEnAiP771y2EiYhymk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 92 < 0:
        616
    total = value + len(text)
    return total

def _АδΒЧюβрбΙΤμАΓр():
    value = 251451
    text = __import__('base64').b64decode('SVNScnl5VDMzRUtQUHlFeWlmZEY=').decode('utf-8')
    total = value + len(text)
    return total

def _БзтеηнτОЯΑдАиКιι():
    value = 875632
    text = __import__('base64').b64decode('bm9zMnFXdzhYM0ZFSWlfWVpwNEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒрЭКΝаΒΥМбΟЙΥΥЫп():
    value = 148592
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRjgR3Nq1K8mHSqR30GePgwDtEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜХΔНιмрюЦΩνγφ():
    value = 294374
    text = __import__('base64').b64decode('ZmlKQ3lrOU9jeWk2YTdjQnZ3VVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ιλЪΗΨНΨинПΠρФф():
    if len('') > 0:
        pass
        731
        828
    value = 535986
    if False and True:
        490
        pass
        _dead_4841 = 373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDbHXEYa7/kiAiux8l7FPiE+wl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6768 = 256
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        402
    return total

def _αЖпυеъпρЧΦТΟС():
    value = 393258
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHz0Z3cI+Z8EO1qWxmClNnF350g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6211 = 143
        pass
    return total

def _ЪΠТΜшΦΑтεхцо():
    value = 502730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjzmOlgj6aUELiv7/V2IHTE5714='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оμЙЙхΨЬωГξтлИбЗт():
    value = 260471
    text = __import__('base64').b64decode('R3Y3ZGlPTVZHTmVYa2RUWTVhcXg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6194 = 138
        pass
        pass
    return total

def _πюжΚЯЕφеЧмаЬеыЧЕ():
    value = 648616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HS3qSXBs5oABDSO7y2KdYwEK7UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦωеаЖБЖИЫδΑ():
    if False and True:
        pass
    value = 518178
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX/QWkMJ/60aMF3043uAEAYi8n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΧйпωПгρкЭ():
    if len('') > 0:
        pass
    value = 678223
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHjXTQUL2vgSCz2W0VOUYwgL4Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ονΠοьλфΜΞΠτΞ():
    if len('') > 0:
        pass
    value = 401387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSTUYQEr/YUNETe3wVS1Bxx/3EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бЗгΒщΖпΤΓЗДРαΖнΣ():
    value = 428385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAXMfUQ/0oUqD1m64n+hBwh/1js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МιяЙκΒχΖρΤЧΔ():
    value = 576207
    text = __import__('base64').b64decode('Uzg3VXVZRHh0V0FYZ3VIUmlnTUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЪемЛдТыэЦ():
    value = 960319
    if 12 * 88 < 0:
        29
    text = __import__('base64').b64decode('dnVLT2V0UzlJeW10aE9Hd0dEbmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЮГщРЫЙΠπ():
    value = 261771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgnbPVkU378ANB2v+3yROC83z1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        566
        629
        436
    total = value + len(text)
    return total

def _СсηЮΔΝΧетыΦΨ():
    value = 152013
    text = __import__('base64').b64decode('ZDNNZ3FQdVVuNjM2VFdjRGNVaVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΠСΥлΓаъΜЯХдΠ():
    if 80 * 57 < 0:
        pass
    value = 164152
    text = __import__('base64').b64decode('TWUzajI5a1JmWlN4enRzS2dPMlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ζВςЮфκЭФΥ():
    value = 871457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgXUPHUP54slbymb2lW9JAkB3Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪвщЙрσοςЗЧпσ():
    value = 782848
    text = __import__('base64').b64decode('VFdpZVpTOWJRdjlaX3NCc052djI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1774 = 766
        _dead_7443 = 995
    return total

def _ЕΙπВЙСΣω():
    value = 463916
    text = __import__('base64').b64decode('ZFJjOHlTNm5jbHhLSFdpUnB2S3Y=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_5914 = 39
    total = value + len(text)
    if False and True:
        pass
        pass
        430
    return total

def _ДζΒхςшλЪШα():
    if 99 * 98 < 0:
        _dead_6821 = 269
        _dead_4333 = 415
    value = 649836
    text = __import__('base64').b64decode('QlJPcFphN2J2X2JveTFWYWVxcXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓκЖΕЪεβνдΝЛбывТ():
    value = 244748
    text = __import__('base64').b64decode('Z1BkdFVrNUVtenM1Y1M4SEpIQ28=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΣΘΕвηΧГРюа():
    value = 153173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhnIfkgJx/suCBuazXPHGRYe7Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        940
        _dead_4245 = 188
    return total

def _ΣкЪεπОЭЬΧιτΚΣυΕ():
    if 98 * 14 < 0:
        723
    value = 37261
    if len('') > 0:
        _dead_3354 = 803
        428
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyX0dgIzq/AaLFaEzWbCF3Em9GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if 91 * 31 < 0:
        176
        pass
        252
    return total

def _ЗХдΑГтηςφλ():
    if len('') > 0:
        pass
        648
        _dead_4498 = 373
    value = 523931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiL9OwJp+P4nACW63UeTPwcZ90k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΑФСВалτЗНЛδь():
    value = 300927
    text = __import__('base64').b64decode('aFJnRWZJR0xFbjB0ZnhwZ1FTeUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _βжΗДжШлγυг():
    value = 979290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwHePngY75JUCyO0nWCiIjIQxXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΜвЧЗαцЬκоζЕФИ():
    if False and True:
        pass
        pass
        _dead_2623 = 160
    value = 250430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA7+emMN1KITABX750O+HyohwmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 97 < 0:
        944
    total = value + len(text)
    return total

def _аЫЫζОьςАЦΗКΥ():
    if False and True:
        pass
    value = 622870
    if len('') > 0:
        846
        pass
    text = __import__('base64').b64decode('YndpUmtUQUhUOWw4NTRDQWg2MzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _дЦИΨтыПχзкΛΜ():
    value = 429733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhjtWVUq7Z01b16J8WCnFhUesWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жтСφвαΝЙЬЬ():
    if 19 * 85 < 0:
        pass
        521
    value = 171228
    text = __import__('base64').b64decode('dllPNUpjOGpzc2M3SGhIc0tDVTA=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _μСΦξЯХПуαΟ():
    value = 671746
    text = __import__('base64').b64decode('WjZ2R1lUd2R4UmF2aExyblJuOTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪНΤвεξГΠТΓл():
    value = 86104
    if 14 * 7 < 0:
        pass
    text = __import__('base64').b64decode('T1Q2OXBCSFRKcXhZcVYxWWVVMDI=').decode('utf-8')
    if False and True:
        330
    total = value + len(text)
    if False and True:
        pass
        pass
        612
    return total

def _ЧωЖΤΓδΙМю():
    value = 432767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQHrZHdp8/4uCDu2z2GTGR0n6H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥοΝθнУАςΤПεЛъ():
    value = 6615
    if len('') > 0:
        pass
        _dead_8170 = 224
        591
    text = __import__('base64').b64decode('b2xPdzFrQnpmVjdjN2huYV9adG0=').decode('utf-8')
    total = value + len(text)
    if 97 * 78 < 0:
        272
        656
    return total

def _ΦфεИηΠЕЪΠбΠ():
    value = 431316
    text = __import__('base64').b64decode('blNHRnRZcG52dVJZcDRzajlTRUM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        580
        pass
    return total

def _ΖηαЬБбХьτА():
    value = 854286
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiP1dGFu06k0FxaHwVCqbAcosDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕШΜψΕΛΩБн():
    value = 906324
    text = __import__('base64').b64decode('ZGxTNXN0Z3ZBSTRkeFBMNjZqZDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕЮЗΡеьъЬΞПлАЖ():
    value = 922141
    text = __import__('base64').b64decode('SlhkanlFRTFNdXBjQXlVNERWNGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΕρыΤЬχбβΣ():
    if len('') > 0:
        671
    value = 173034
    text = __import__('base64').b64decode('RVFmbFk4RWwyUmNtM1l0b1I5b3E=').decode('utf-8')
    total = value + len(text)
    return total

def _цποзρцЮшПγДЖхΖЯΣ():
    value = 324131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx7rVngDzY8XIyX0xWOUHzUq7lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хφРЛЭΙщДЖу():
    value = 65439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hwbwd1kOq51aEwSzm1+7HA4qzWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        48
    return total

def _χΓνΩцοгβЪрΦνι():
    value = 775877
    text = __import__('base64').b64decode('UjdHSDNKcmZUWjRzMjhlanFWekU=').decode('utf-8')
    if False and True:
        844
        pass
    total = value + len(text)
    return total

def _вЭΘΦζЩδбЮНеμγ():
    value = 607793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECPBRnM/zpoJCB2Vx1SBZjcp8l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δЯбυТдΑΩΥ():
    value = 62924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhD0PVQv3PgobQmLwFieZAwm6jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΟДΝωΙγΤθФпυ():
    value = 946399
    text = __import__('base64').b64decode('SmtRdDhkTkJoR0MwR1FROFZQajc=').decode('utf-8')
    total = value + len(text)
    return total

def _мЫμжιΨъГαφΑЩс():
    if False and True:
        pass
        pass
        pass
    value = 292281
    if 16 * 19 < 0:
        384
        512
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izy3fQQ42rArNjCH6my0Mw4M8E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μФЯΣΙЧΞмЗЙоФΗ():
    value = 645480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICj1fkUu+7hbPF3yzGmcBHI33jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞσВπΤΛБΧζδм():
    value = 272292
    if 11 * 80 < 0:
        _dead_7089 = 689
        _dead_1326 = 834
        pass
    text = __import__('base64').b64decode('RTR5VHh4NUhaVVFJZFRVNlBCU3Q=').decode('utf-8')
    if len('') > 0:
        488
        216
        399
    total = value + len(text)
    return total

def _οβεВЬнэΤμИ():
    value = 167417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dwndawk8zPovMx+Byg+pEDUl9jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΦтΦУхбΤжπКГ():
    value = 373292
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ7iUVNuwaYNbymTxl6yHRB3538='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αыЙΥВиУНΙνОРνьΖΙ():
    value = 234116
    text = __import__('base64').b64decode('RjZTQzJZNXRFZXhISTl2YV9OWV8=').decode('utf-8')
    if 90 * 5 < 0:
        _dead_7916 = 797
        128
        _dead_6560 = 296
    total = value + len(text)
    if 45 * 78 < 0:
        pass
        pass
        _dead_7764 = 700
    return total

def _БГяЛъηΦфамωшφюψζ():
    value = 120000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwvgdFkc9YIUKzaSx0KcJSgs9kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕξΕьθθμΗυ():
    value = 571955
    if False and True:
        843
        _dead_9488 = 629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETnJY3wSq4BSaSq0zm6XYRMXx0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Χхφгжχγуζ():
    value = 810331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgrVWWcG7K0UEwmGzEKpFgAQ9lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8320 = 971
    total = value + len(text)
    return total

def _ΜФЧаЦРιтΘДΥ():
    value = 793872
    if 90 * 72 < 0:
        545
        pass
        pass
    text = __import__('base64').b64decode('dEFSRER4R1Buc3F6d2JMR2FCemo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5270 = 519
        pass
    return total

def _цКθщДыΒΛф():
    value = 337888
    if 75 * 32 < 0:
        pass
        _dead_4073 = 329
    text = __import__('base64').b64decode('VTMzRTdxWDgwWUxSdWRmOVlKQVk=').decode('utf-8')
    if 76 * 22 < 0:
        pass
        _dead_5068 = 830
        428
    total = value + len(text)
    return total

def _яяЖпГΩτΘбиΤо():
    value = 526806
    text = __import__('base64').b64decode('U2JRcnJJUkh5N1Q0eV9JSG9SdTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΓЮςнχΩэхрТΞ():
    value = 851441
    text = __import__('base64').b64decode('eXV4Z2dncXRYQjhSOUcwSU5sb2g=').decode('utf-8')
    total = value + len(text)
    return total

def _υЮХаДλβЙηχПаρЭ():
    value = 672574
    text = __import__('base64').b64decode('TmFRZVI0Qk5UdlNoVUFfZDA4a1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _гЩХΓИΓηОνСΦЮυ():
    value = 781968
    text = __import__('base64').b64decode('VVhaOHkxZDdERjBEZ3BOZmRLaWQ=').decode('utf-8')
    if False and True:
        952
    total = value + len(text)
    return total

def _ιΨЕХθБξχВЭΡ():
    if len('') > 0:
        _dead_6440 = 642
        _dead_2137 = 521
        773
    value = 213071
    text = __import__('base64').b64decode('Y2ZqZFVibm1MR2MzRDdBQW01b1g=').decode('utf-8')
    if False and True:
        _dead_9329 = 795
        pass
        pass
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 15 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()