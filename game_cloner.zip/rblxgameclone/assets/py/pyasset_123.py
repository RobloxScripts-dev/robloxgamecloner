#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ЯκиφмТΗвбчПйΧΧ():
    if len('') > 0:
        557
        410
        _dead_8861 = 574
    value = 969382
    text = __import__('base64').b64decode('eWZTdlNsU0t1MGUyeFB4ZHYyZEQ=').decode('utf-8')
    if 3 * 32 < 0:
        pass
    total = value + len(text)
    return total

def _лЕзψρюхζу():
    value = 208665
    text = __import__('base64').b64decode('cVVhOGFJcHQySnJVUk95MHBoQmc=').decode('utf-8')
    total = value + len(text)
    if 22 * 43 < 0:
        pass
        pass
    return total

def _ЛСОРНβьςжчаЮтбγ():
    if False and True:
        _dead_3123 = 26
    value = 371565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjnDR2Jo5vwiY1z0x1emJik2w3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЪЙβηΜχεНА():
    if 40 * 82 < 0:
        39
    value = 697324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxfPSkcLxr5TNj+F32CYIjcL/Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 93 * 67 < 0:
        5
    total = value + len(text)
    if False and True:
        _dead_9200 = 264
    return total

def _ΨхΣЛщΘЬян():
    value = 51635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH+yTAlt264nMwGr7geSJ3Z8sX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νγяςЩΞθщКЧУ():
    value = 210887
    text = __import__('base64').b64decode('RFE2NnM4VktVQTR0ak1Gb2xPTEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟнΗξЧΜдθэΚΥΥ():
    value = 437996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX/JTQBu760TEDaZ3kK+BRwsvG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩРΜпГςΗυΛГО():
    value = 393717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHzlY3g97acwCRn3+XqoGDA+t2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЯщкΨωΧНιэлη():
    value = 997081
    text = __import__('base64').b64decode('T185RFpRQzJmaDl2ZkVlM1ZYUlg=').decode('utf-8')
    if False and True:
        pass
        _dead_6451 = 921
    total = value + len(text)
    return total

def _βцЙЖцЗКщЗ():
    if False and True:
        pass
        672
        _dead_8659 = 297
    value = 819505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQjJeVQOrZwzHgugw1K4Ag8e80M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖЬΨЪПΧЖΨФЖУ():
    if len('') > 0:
        pass
        247
        _dead_4172 = 485
    value = 216326
    if 10 * 91 < 0:
        _dead_5863 = 733
    text = __import__('base64').b64decode('UG1CSFo1MjQ0emx4MzJEZXA3QUU=').decode('utf-8')
    if 29 * 26 < 0:
        501
        466
    total = value + len(text)
    if 55 * 45 < 0:
        589
    return total

def _εсΞμξΠθΘК():
    value = 901199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCfdOVsb7JcOMjuA+3ynFgh9y3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        11
    return total

def _ЙФΧΒюΨΞξШθэчЕ():
    if False and True:
        424
        _dead_4800 = 627
        _dead_8388 = 999
    value = 404168
    text = __import__('base64').b64decode('TW1aWG1BNHZoVnI2WVhOZ3VScUU=').decode('utf-8')
    total = value + len(text)
    if 61 * 88 < 0:
        _dead_3424 = 938
    return total

def _φхсшΨΥЧПκжΞΗΟф():
    value = 805431
    if len('') > 0:
        _dead_4107 = 733
        684
    text = __import__('base64').b64decode('SEMyY01sOW01bFM0RWFMb0tQb0I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        801
    return total

def _БщЩТκΔрХΖсμтбюзр():
    value = 672594
    text = __import__('base64').b64decode('TVhjNkNDUGZJRTh4QWtabkxjTk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕЫΔψПьОЗΟ():
    value = 745628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj/SVmYAxKpSAim1wmKRYQ4FtU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _δБяΒбΙΚκνмκΔσг():
    value = 45358
    text = __import__('base64').b64decode('T2JoZGRhbWpiQm10TVEwa3dVVUM=').decode('utf-8')
    total = value + len(text)
    return total

def _хξΛбмбΝчΧрσКЛеΥ():
    value = 55032
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCHcSUgq2pEyFQut0ECYMywu0XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧъгЖбΚоЗδХпΗчБΛ():
    value = 857461
    if 54 * 74 < 0:
        412
        _dead_2888 = 482
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiLebWQo04oxAh6k8XS3HHMcsl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΧрδψЩМωТηнц():
    value = 317542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwzUO0Mg8L0LHQaByU+gZ3MM4mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 65 * 17 < 0:
        _dead_2131 = 548
        pass
        _dead_9862 = 389
    return total

def _ВΩγΒΦΔЧмεΙηкъиΟ():
    value = 983850
    text = __import__('base64').b64decode('QkVtbFBZRUVaWW9kSThVWTVjcXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΓΟооΑТМ():
    value = 829009
    if False and True:
        pass
        144
    text = __import__('base64').b64decode('V3dtVWt3dUlvc2QwWFR3NGtuekk=').decode('utf-8')
    total = value + len(text)
    return total

def _υΩоЙΦΗЭχУЪεИΩЫ():
    if len('') > 0:
        _dead_6110 = 13
    value = 742494
    text = __import__('base64').b64decode('SVl0QnBpZVZhZW5rTGE2QWRPOVc=').decode('utf-8')
    if False and True:
        _dead_7064 = 534
    total = value + len(text)
    return total

def _ИαюχЩωιсФяПД():
    value = 350021
    if 96 * 13 < 0:
        433
    text = __import__('base64').b64decode('eU9iY3gzNXRuODNUY3NyWVQxeXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚМчАБЙλЮ():
    value = 39172
    text = __import__('base64').b64decode('RjNHUTN3Vlh0OTBkckxERkRrWVg=').decode('utf-8')
    if len('') > 0:
        _dead_7308 = 455
        531
    total = value + len(text)
    return total

def _аОδтπωБзНВξ():
    value = 243416
    if len('') > 0:
        _dead_7752 = 364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwzUaQQ29IkCaVqW312iIxIC92A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МсΖЮзψΚΚйκΙ():
    value = 917443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3fOVn8Az/8LHjyo/U7ABjQ34jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗηΚΘЬэΖψм():
    value = 821095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDzKQl8Q1qkxEx267n2eDAIXyDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕчΕзθэрΝΖяΕк():
    value = 573755
    text = __import__('base64').b64decode('bmxkcm03TUd6d252RGt4cXN0UUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕХοпЕΘΝΝχцβЮвКι():
    value = 521867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR7NSGkuqv0JKDyO2ACYLgwI5jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РλФлβκвοαερЪЕй():
    value = 651987
    text = __import__('base64').b64decode('aV9jNUM5OXIySGRkRWZCX2JFT0E=').decode('utf-8')
    total = value + len(text)
    return total

def _яыΟПсβЛкЮΦ():
    value = 262355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCjIQ3c15IMpa1z15gW6AQ0XtGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6509 = 735
        _dead_9922 = 813
        pass
    return total

def _кЖчφΘКБМΙггψΥγ():
    value = 54494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABfGb0QRzvBaCwa57E+8AxI4230='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨмСИэеζлηδкЬЗБς():
    value = 585515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET6wOwFox7gyLguSmUyaBiYCyH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УδσΦхΓЗΦйш():
    if len('') > 0:
        768
        _dead_1564 = 158
        _dead_6542 = 719
    value = 4085
    text = __import__('base64').b64decode('R2oyamhhbDNIb0NIVzk1XzFHRGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞтчлΘΕЦΥΦж():
    value = 554513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjfTZn5h36IuAjin50XEJHB+1Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_4950 = 786
    total = value + len(text)
    if False and True:
        _dead_4270 = 612
    return total

def _ΗЕФΛΛШьЯЫπ():
    value = 14101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICTgWXwR/4EbbBmpnHOCJSQt6UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        306
        _dead_9171 = 775
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ыъХВЗАτлПΣЦ():
    value = 981873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ki7bR0Yh6oMyBQz73VyVYyd91Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΜЖдΠгЖУθъεΨЛ():
    value = 173506
    text = __import__('base64').b64decode('anNqY0NtZ0VuczR2N2JZNTNKaUc=').decode('utf-8')
    total = value + len(text)
    return total

def _гкЯШЪΛПхдЫфμшΣ():
    value = 448531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDe1emBh7Po5bSaAynmhJSAovTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цЭχчΑωдЖЙлмВ():
    value = 310459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB39N3s39PFVOQuqyQ+cAA833Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 46 < 0:
        _dead_7965 = 251
        pass
        _dead_9963 = 933
    total = value + len(text)
    return total

def _νэВиωΟСсгРУяЛэух():
    value = 441955
    text = __import__('base64').b64decode('Wm5WTURPVkJLelgxa2NvMmhZMEI=').decode('utf-8')
    total = value + len(text)
    return total

def _υфяΤηХКΖШЬγΓα():
    value = 354479
    text = __import__('base64').b64decode('d2dlVjQyUkM0eElfOHBjMUQyMU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЙасΓΤЖь():
    value = 196151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyXgbX5uppg2DVmo6XiTOhMY7WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЩиξΞАиУГлИо():
    value = 799040
    text = __import__('base64').b64decode('Wkh0cGpkTE5zRHg1R1VuRjV4b1o=').decode('utf-8')
    total = value + len(text)
    return total

def _еСβΗρИьοτυЙΩЩ():
    value = 405293
    if 80 * 39 < 0:
        75
        pass
    text = __import__('base64').b64decode('YkwzWlBJVUJhcHd3b2RJeVg1TjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭЪιйδжТрМРΝБтРφ():
    value = 276550
    if len('') > 0:
        _dead_7790 = 676
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSfSZgAM5L07GQum/A7BMDAExW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьβщΜСΝжЛхрωВшйьΨ():
    value = 347707
    text = __import__('base64').b64decode('RDYxdU1vN0k1eDZfcmlEX2VHV1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЩΟπσΨдЭГΣφΤД():
    if 58 * 8 < 0:
        359
    value = 378076
    text = __import__('base64').b64decode('cW1EOFRwSXR2UGVCU252X1k3NGU=').decode('utf-8')
    if False and True:
        _dead_9540 = 387
    total = value + len(text)
    return total

def _ΧЙМκлωМφтΑπЮΤ():
    value = 206748
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhzrPGs/248wKyiykV2UZQcc5l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧтщНФФУрΖφЛΝ():
    value = 323339
    text = __import__('base64').b64decode('SkdMVVhudFVIdXZVWUNOVkFaSnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΝЫИфэФтЖΘΠςъхдв():
    if len('') > 0:
        733
        35
    value = 543105
    if False and True:
        pass
        439
    text = __import__('base64').b64decode('WXhzR1R5Z1JsWmhINUlYMkFvZjY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _акκσΞкΛТδохεПу():
    value = 84192
    text = __import__('base64').b64decode('a2I3NEhWN1RwWWVqb3pleU5iUUI=').decode('utf-8')
    total = value + len(text)
    return total

def _тωЗСσЭоЧ():
    value = 844679
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxrqfXkY+KAWOzWUzEeBARZ30jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΩсξΟгΥμνΡΗ():
    value = 604614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB/eXH806YEtNQqI/WSeHR088mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΗцетΒςψντςχКΜРс():
    value = 198992
    text = __import__('base64').b64decode('SVJFV0h6R3JPQ1V0dDdDclFpZ2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЧπЬьжχζΣв():
    if 66 * 12 < 0:
        pass
        _dead_4150 = 612
        pass
    value = 720865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBq8f2ks+PsvKRyC3EazOTIq5jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤофλЬΠТκχК():
    if 38 * 93 < 0:
        _dead_7976 = 688
    value = 98483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSjOW14/+v9QAB+X2EOFAXR94UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 46 * 45 < 0:
        pass
        pass
    return total

def _ЗБяНыЛЫспт():
    value = 36588
    text = __import__('base64').b64decode('RGpXNUdvQXNWamEwUmZYUG1oZVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩгпЪьТоПωΛмΖхоЮ():
    value = 205906
    if len('') > 0:
        921
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx32SwYe/7EvFCWF3F2UMAkh3kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        714
        _dead_7155 = 219
    return total

def _ΡЩΨσмьТсл():
    if False and True:
        277
    value = 255813
    text = __import__('base64').b64decode('QW5uSk5WbU53UEx0NkxjdkxkcDE=').decode('utf-8')
    if False and True:
        145
        _dead_9565 = 433
    total = value + len(text)
    return total

def _лЭНθΗκΘνжГνрοЫхΘ():
    if False and True:
        975
    value = 622889
    if 45 * 71 < 0:
        pass
        pass
        691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR+9Z1kh2Iw3bgyQ0A+eYRV96Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΑСшСрηцаеЗрαТс():
    value = 49325
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiXAfmdp+7tTFBm6/Fu6Ii8fz1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΒЪЧияпъ():
    value = 517368
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSPhPWg+zIoCDCf7yQaaIHU9yzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗμλТξрРψκΦУхЗоΔ():
    value = 847760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQ3rOl4hqpIQMluG6niKYhYq9UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9274 = 335
    total = value + len(text)
    return total

def _ΦΓЧьζΡδςΜИΞνНΦΩ():
    value = 27978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyfMPUMq/6YGPVrx4m61Yh891DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΤЧЭΩΤшд():
    if False and True:
        _dead_7388 = 515
        pass
    value = 201712
    text = __import__('base64').b64decode('UllONVZ2YXVLY2xjaE5PY0lZc1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞеΒцλыЖγΕπйαьшΛ():
    value = 920063
    text = __import__('base64').b64decode('VF9IdVBuMG94eXhCX2MyVzJaTXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕИΔяδЦыθЭУоΠюу():
    value = 382354
    if 48 * 44 < 0:
        pass
        _dead_4342 = 210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQLoZmUsx/o3MiyExEyfDSoF218='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣУНпΧΗЫЩΟξοЗПζУ():
    if len('') > 0:
        932
        736
    value = 296632
    text = __import__('base64').b64decode('Y0tkWHFSWlVCaFFsOUxPNzB5RXA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        121
        pass
    return total

def _ΛΠαςачΧсΖΟφβЩ():
    value = 602334
    text = __import__('base64').b64decode('SXRFYnBJODBqMThJbm5ENjd2RVA=').decode('utf-8')
    total = value + len(text)
    return total

def _дЙιΡБяπцКээ():
    value = 493817
    text = __import__('base64').b64decode('Vm5VMGpXWlR4MTRjcjd3R1A0Sks=').decode('utf-8')
    if len('') > 0:
        828
        _dead_3280 = 285
    total = value + len(text)
    return total

def _νζπюйιЭΖуЖ():
    value = 601859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB3uQ3YL7qdaHDWR7UOgZXYWymk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7420 = 186
    return total

def _щΨзРйНМΓσυΛй():
    if False and True:
        129
        pass
    value = 158613
    text = __import__('base64').b64decode('Z0VacnRtM0RHb1JBS1ZmQWx1SVM=').decode('utf-8')
    total = value + len(text)
    return total

def _яχΧрεΓΖΜηйЫЗ():
    if False and True:
        747
        _dead_7278 = 488
    value = 963607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHzsTFQpzZsLLDzw8nuZDiso0H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΒзυЬАгΩПΤъ():
    value = 977420
    if 59 * 74 < 0:
        _dead_1640 = 676
    text = __import__('base64').b64decode('a2NyZ1l4X0habE0yR19tc19vRUg=').decode('utf-8')
    if False and True:
        355
        _dead_4349 = 603
    total = value + len(text)
    return total

def _εΘЩυφлЪΣЙΛбСγЦ():
    value = 945951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSfXVlRh7q81HCuL0HyiYXR93l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζЬζьНΒρяыАЫФδΜД():
    value = 122442
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lgj+SX8O9IMiNy6RnwWdJXB97Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 17 < 0:
        41
    total = value + len(text)
    return total

def _μПΥΒЛψкЭΥΝΣυбθτ():
    value = 527550
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj3TbEBqyaFbAF6LwwabES4cwD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъгьΧэщЯьΔΨΦУ():
    value = 474698
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HS7VVkIo/awsEAWx2k/AZiQL11c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιкРлΛЙяΒшдсхН():
    value = 814940
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSP0elcW9qMgLxWm2HKmBBYe4UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рυΙπТдялνЛЩюΛЛΞ():
    value = 293490
    if 62 * 4 < 0:
        pass
        133
        _dead_1642 = 233
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwjBbGINzp0JMCWp5FqXIjx45Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓШΟхφХИЛсО():
    value = 520407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR3mTQFvqbkgBQSbkW/CIgl20Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_3854 = 709
    return total

def _рЧШиАΛхиξΕκВ():
    value = 773528
    text = __import__('base64').b64decode('b0dhZG12bzBrT3hKeHM3TlRxdjY=').decode('utf-8')
    total = value + len(text)
    return total

def _КγμσЯΓδΓэωБΦ():
    if len('') > 0:
        823
    value = 673665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhvMTWE/2aYTazekxXmdFxo6xWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9756 = 966
    total = value + len(text)
    return total

def _бπσθΩвМωАГяρ():
    value = 895841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXv1VmM0rpwmMSWJzUWaATJ/zWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟвхЦЗγмл():
    value = 709555
    if len('') > 0:
        794
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAnrekYax40pAzuE0VeWDnEl/Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 54 < 0:
        pass
        _dead_3447 = 809
    total = value + len(text)
    if 40 * 69 < 0:
        536
    return total

def _ξпшδψτЗи():
    if len('') > 0:
        855
        147
        997
    value = 97552
    text = __import__('base64').b64decode('RHIyOHhVMnYzaktVczlUVW5CS0E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        561
        pass
        pass
    return total

def _ЧЙΘВΣωмШмΕε():
    if 48 * 98 < 0:
        _dead_2868 = 57
        pass
        271
    value = 990858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISDuWEEazp8kNSbw7Ae5YwQD7WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙШΘΕЭΖεг():
    if False and True:
        92
        _dead_5505 = 470
    value = 698722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgzreX8c3f8MF16J8lqxYC936F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩαойЛηнφυ():
    value = 680180
    text = __import__('base64').b64decode('aTdBZEd3dWxGZVBzYzVBVDR6SzA=').decode('utf-8')
    total = value + len(text)
    if 52 * 94 < 0:
        pass
    return total

def _ЪθНοьфКнβγΑуλбиИ():
    value = 560912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR+9ZVtg+ptaI16vxWyqEnI/wFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лиψчΧΤГЯη():
    value = 859558
    if False and True:
        652
        _dead_2022 = 326
        543
    text = __import__('base64').b64decode('Y2Nsd2tWM0RnM01IeG9ETDlueFA=').decode('utf-8')
    total = value + len(text)
    return total

def _πюεψЭΟЙλ():
    value = 941445
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAv+XX4Az68RPxqN3VWUEwIL3Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪКНБхρλЮЙагΚж():
    value = 341135
    text = __import__('base64').b64decode('VDZTSmtjWmZhVjd4YjU4TGZjclg=').decode('utf-8')
    total = value + len(text)
    return total

def _τΜАΡΑЖφЮεγпчςкΩ():
    value = 86093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ezn2eEQW//0IHAf60X29OhJ64EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 20 * 92 < 0:
        100
    return total

def _ИΧШΒΝλσςЫ():
    value = 400544
    text = __import__('base64').b64decode('bFNDOXNvRExVR3lrZDZLVFVGbXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΚОΖνЛлсι():
    value = 199786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxnDYmsy5qNTPRiuxF+2Dhw5zzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χПχωвοАщΖ():
    if len('') > 0:
        pass
        pass
        _dead_1201 = 587
    value = 824382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT/3aGgc84ApAxmw7GGeExMusj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κМЧΟθуфΝβτЫТ():
    value = 360241
    if False and True:
        pass
        _dead_2933 = 647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyrbXl4wz64uK16PnmKpOyx593o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        849
    total = value + len(text)
    return total

def _ΦεθИΝТβэπ():
    value = 475357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXq9Q30r/6cpOVeG/Q6nIBENyWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИБηЕτЧЧЛαпЗНφΛΞχ():
    value = 840242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHrOb30V6KQnKCOv92WAPCZ3w0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 46 < 0:
        pass
    total = value + len(text)
    return total

def _ΤшИЯιΑνν():
    value = 333530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah/9Yggtqp1TKwKnmV6TIX0q0Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 18 * 36 < 0:
        _dead_6739 = 674
        _dead_1580 = 884
        586
    total = value + len(text)
    if len('') > 0:
        634
    return total

def _УδЦυЦтМΞрςΦтъ():
    value = 487530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRbUfEFgyYo5bSv3+HeWPyI/wHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εКжврШρСЕИοΖТЖЗ():
    if 40 * 61 < 0:
        843
    value = 993567
    text = __import__('base64').b64decode('dmVfQzlYaTgzcUVHaUF6YWJKRXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞШИЭюЮωζ():
    value = 793660
    text = __import__('base64').b64decode('U1pDWkhoZzRIS1VYSDliOWJXQXQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        120
        _dead_6362 = 703
    return total

def _ΦШσΡкΥЩдΧсфΔ():
    value = 906234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MznWeloMrblREDym8lyaMiQn8Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        792
        351
        _dead_8410 = 971
    total = value + len(text)
    if len('') > 0:
        848
        _dead_7045 = 94
        _dead_3418 = 517
    return total

def _НЙЫдкγΝψοΟΤшΡЪΑΠ():
    value = 105315
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyqwYUMe6pshKjaWn3fJHTY+sD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΩЩΤГэΡχСФпσΡгΧп():
    if 73 * 88 < 0:
        pass
        _dead_3796 = 349
        136
    value = 444580
    if 52 * 15 < 0:
        pass
        219
    text = __import__('base64').b64decode('UjhIUWY0dTdTRmVZOXZzNlh6T2o=').decode('utf-8')
    total = value + len(text)
    return total

def _чпЭъЛμЕпМсычΡ():
    value = 971850
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eha3O1oWr5g0CAuk+Q6zOgEB21E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДяΤЧΟюЬо():
    if False and True:
        _dead_2407 = 429
    value = 871367
    text = __import__('base64').b64decode('bGs4OWVGZTU0SnJYeUtoMjhkV1k=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 75 * 97 < 0:
        372
        pass
    return total

def _ЫмхΝυопЯ():
    value = 883259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyHWdGY6zbsQPgGW/FyJJQx5/W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФВнБΣЬвΕ():
    if len('') > 0:
        pass
        914
    value = 857155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHbbXFwdrr8kYieRzAW/Lgwf9kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йМΚγςνεШρуЦ():
    if False and True:
        710
    value = 874679
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQH1SHwoyqUuF1eM+g+SI3F8tD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΞΨυРйΦы():
    value = 997797
    text = __import__('base64').b64decode('WDByVTVWaTdPejA0bjlvcnN2Yzg=').decode('utf-8')
    total = value + len(text)
    return total

def _κΟфιХвЖδο():
    value = 65640
    text = __import__('base64').b64decode('TlVFbzhNNUNvQTE0QUhBSnU2Qjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣЮМрΟψуфΕλВ():
    if len('') > 0:
        789
        227
        _dead_2818 = 249
    value = 179953
    text = __import__('base64').b64decode('UjJCZkY0Q1ZxS0VCUXlNMk1hQ08=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_4624 = 317
        510
    return total

def _ιΨΧΖΕигьВεЮςΔ():
    if 55 * 50 < 0:
        329
        pass
    value = 441948
    text = __import__('base64').b64decode('U19UbnhRZnhrdDI3Z3Y5MUpmYW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ИσΑзЯδωМИ():
    value = 538038
    text = __import__('base64').b64decode('UlBMbmpsZ05xaUxZMFVBZl9vekQ=').decode('utf-8')
    total = value + len(text)
    return total

def _мΚЪКиРГεηЬНвφдР():
    if len('') > 0:
        43
        724
        pass
    value = 663076
    if len('') > 0:
        175
        pass
    text = __import__('base64').b64decode('YVU5WVVmWG1TSkVmR0thakFZSlc=').decode('utf-8')
    total = value + len(text)
    return total

def _аФиЧимрР():
    value = 587990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTzrOQMU9YE0HgOF3k6TLiJ3x2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 19 < 0:
        _dead_2839 = 806
        pass
        pass
    total = value + len(text)
    return total

def _ФлςиΞаΘωρьжююл():
    if len('') > 0:
        _dead_8403 = 229
    value = 787264
    text = __import__('base64').b64decode('ZXd3Z1hiNHVWWGhKODBHUmdJekQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΒυыΘΒКЛΕΝщ():
    value = 92204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyD3WgQ67PBTNxqH7FfEMzMa4T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡсψΨцЮΠНиΠФεΜкΙ():
    value = 618768
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwHrf30I8owxDx+p4lSCOD8Z6kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _аДΠЫШΨжΤ():
    value = 524320
    text = __import__('base64').b64decode('TTRqVnp1bGtqNV9vQVUzZ0hfQU8=').decode('utf-8')
    total = value + len(text)
    return total

def _еΘΚΒΨаЧМПЦτΒΖн():
    value = 239978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRvcQUdp0a4yHliO2VihOSYJslc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤкГεЦЦюл():
    value = 526298
    if 50 * 97 < 0:
        16
        pass
        _dead_4584 = 769
    text = __import__('base64').b64decode('d0JmMG5RUWdTbHc3Ylo3ZnplWG0=').decode('utf-8')
    total = value + len(text)
    if 20 * 24 < 0:
        388
        _dead_5166 = 622
    return total

def _АъЫχρВνиΛκκЦхэфψ():
    if False and True:
        pass
    value = 426249
    text = __import__('base64').b64decode('UmZ4VG9LSElhbTU3Y2xUVm5EMmY=').decode('utf-8')
    total = value + len(text)
    if 11 * 25 < 0:
        pass
        pass
        pass
    return total

def _ахТБγяэχКΖΘиЦφ():
    value = 460062
    text = __import__('base64').b64decode('ZktROFJXRlY2eFlRQkpCTVQ5b3Q=').decode('utf-8')
    total = value + len(text)
    if 13 * 37 < 0:
        260
        pass
        pass
    return total

def _ΚьμеЧΒσΗμΚλЖДβ():
    value = 575137
    if len('') > 0:
        _dead_3738 = 213
    text = __import__('base64').b64decode('dVFSZVJBTjEyak82Mko0NjNsNGo=').decode('utf-8')
    total = value + len(text)
    return total

def _йΦзюПΜвеΟΠаЕΙкΨ():
    value = 823889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCfDWVwV3aFWbgSgnVGcMDA45Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2517 = 98
        _dead_3870 = 214
    total = value + len(text)
    return total

def _ΓπχεκйЯэимΗ():
    value = 79439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCDAa1gw8Zs6PT+a0GmqZBYHsmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 47 * 33 < 0:
        _dead_1430 = 649
        pass
        pass
    total = value + len(text)
    if 73 * 38 < 0:
        859
        739
        _dead_7197 = 364
    return total

def _фуъηζВζμА():
    value = 196763
    text = __import__('base64').b64decode('SmZJMExaMEpvWVNxRGlaeWh1alI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΦтβτтТМчφюЖ():
    value = 209974
    text = __import__('base64').b64decode('SGVzNWFtT2RJX3c1X2xMZG5ZdjY=').decode('utf-8')
    if 38 * 35 < 0:
        959
        848
    total = value + len(text)
    return total

def _чШфлбκАΒо():
    value = 915779
    text = __import__('base64').b64decode('RzY1UjdPZ1lLT2Mxd19XdlNObU4=').decode('utf-8')
    total = value + len(text)
    return total

def _цЮθοηЫΗВСпμгрη():
    value = 15995
    text = __import__('base64').b64decode('T3Z4VHpOOGdtRlpiQlF6YWZKU3g=').decode('utf-8')
    if 69 * 61 < 0:
        851
        242
    total = value + len(text)
    return total

def _ЩΧΖΓцΧΖελςУйαД():
    value = 418327
    text = __import__('base64').b64decode('VGlNeTNvS0czcElzeTF0WFNwN2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΖКщэψТθфэΓςЩЧΛθ():
    value = 953220
    text = __import__('base64').b64decode('eVlZRmQ2OFkwZkJpbjRVYXczUnE=').decode('utf-8')
    if False and True:
        447
    total = value + len(text)
    if False and True:
        204
        pass
    return total

def _ΚКшκηзви():
    value = 479643
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCriWHho0rxXDyebwACWNwsczF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 35 * 33 < 0:
        941
        479
    return total

def _φуыΗсΓБαξсΤτЫΗ():
    value = 809404
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQTnXXQzqrgLNQKH5waaHA463X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пнΦΤΟυΑсЧωΨ():
    value = 610578
    text = __import__('base64').b64decode('Sl85N2xsUEJSdGRLRkpWZ3k1QzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬκБГΩβИξГыμ():
    value = 700677
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxzcY3s8z7AODz6B7kKKLi0M8j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εαПΟЖКπыкς():
    value = 68722
    text = __import__('base64').b64decode('ejVlUlptWmFUc3pfaHhaYzg3a2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ыιоЙъοЖбш():
    value = 502843
    text = __import__('base64').b64decode('SjVqMjBmWUFQRnZ5ZDluTE1pSFY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8645 = 373
    return total

def _ΤыаλФΗфτΒЯΔКЩа():
    value = 954834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSnXY1do9I45LTyJ7nTEbHM8sms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        0
        180
        pass
    return total

def _ЭщОНХЬιЪФωбηмЗΖλ():
    value = 752337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhbFeQQGx4UAbh6W73yqbAEhyVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2828 = 722
        pass
        _dead_7408 = 780
    total = value + len(text)
    if len('') > 0:
        _dead_3061 = 435
    return total

def _ΚζвλиλДΥн():
    if False and True:
        _dead_1615 = 317
        pass
    value = 582991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EC3bNkE+3Kc3PyGWx369PHN+xlc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρцКдПЙеРъΩТТчЖ():
    if False and True:
        128
        _dead_5008 = 854
    value = 271759
    text = __import__('base64').b64decode('Rnlhcm1Id2dTaVl5NzYwQ1lXOFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЭычτΔЗκФГΚТΦυШЫ():
    value = 455395
    if len('') > 0:
        453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgjhQ0cI/bgCL127y0CKOBYM3V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΓιцУЮρΝИΨФλν():
    value = 912180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHzRPUEG0JwGLCixxkPJGyM68kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЯЧσЫЦΣΕНл():
    value = 57409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LT3AeF8L5qcbNinzkUGkC3M/wn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιоКΔЬςЩΡΑЙЪφΠш():
    value = 355706
    if 29 * 2 < 0:
        651
    text = __import__('base64').b64decode('ZGdCZXNCWHE1N18xRndFejlEa0I=').decode('utf-8')
    total = value + len(text)
    return total

def _кцнмдЗЛωЗь():
    value = 737745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAfPZEEa2b8SO1/z5U/AP3c4w1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦδθруБвБЧβъ():
    value = 976417
    text = __import__('base64').b64decode('Z25uVUlNTHU3WWhMTEQyUzB2OU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ξдОΗРεωχЩЕИщшΤθ():
    value = 594306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiO2Y1gyp/oVERiL5n+BbR08w14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ныхЫчЛΤЪΜзυεΟΑдн():
    if False and True:
        pass
        _dead_9588 = 573
        _dead_2617 = 314
    value = 321646
    if 39 * 50 < 0:
        _dead_8644 = 204
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzjcP2EarJ4ObAyh+E+4HQ078Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 9 * 61 < 0:
        pass
    total = value + len(text)
    return total

def _θτуВβРбΡΧηΠЩьЫКг():
    value = 381691
    text = __import__('base64').b64decode('ejdKT2I1MktjZ2JtbVp0N1RrOFg=').decode('utf-8')
    total = value + len(text)
    return total

def _оδцβΙΚмΧМΨ():
    value = 980920
    text = __import__('base64').b64decode('V01vSG9wZFd5ODZRUW9KRUdSbWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΩпхоΗЧαэОвΛфЛξз():
    value = 225476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCzPem5h6P8haV76mnOfbBUf92E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нДΑжξΧηЭЖΕΔИβΟе():
    value = 924448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LivcZ34+yLEqKQmL0A61Yz0Gx1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αβκκыВμпκйОгсЩλ():
    value = 535301
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyvedH0u7IkNLiCH+HG1Pik5wGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зТΙωξцιΚΔ():
    value = 502606
    text = __import__('base64').b64decode('Y2FxcUxGTzI4OWZubVJwZDVIWEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _φΜепΥΛМИАΞΥη():
    value = 802361
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRneVGlr96YbDFqH/kO0ISA85zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΓΙЯГКЕσγΠξ():
    value = 605754
    if len('') > 0:
        _dead_6006 = 218
        _dead_2803 = 44
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAzGQAApyZIuEDWk+ke6PhI5tkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΑΔФъуфζΛыρТψΟ():
    value = 597580
    text = __import__('base64').b64decode('bkpLTlZlS1Ftd3dka014QlVsQlY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟαшθγЕΧΒΕхΜН():
    value = 133070
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCX+PAUu/IFbOBmv2nXEPiwAxzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛсФжΓΙшеЭЭТΧχжγΩ():
    value = 938266
    if 39 * 56 < 0:
        _dead_7848 = 876
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx7JRgNv/IoiPwqSz3jCBC4681Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΜсΟεЩγχАМцЫγμзл():
    value = 914934
    if False and True:
        320
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASHHZl0vrY8kKBzz32mzbBI5y2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3963 = 938
    return total

def _ЦбДΦωμюΚБεН():
    value = 562944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDizb0E78pcIPSnyzmCCBQYYskQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _тοсφЮРКωΡЪЦαрφЖ():
    value = 458107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCP2Vksgyf8HOCiE51K9YhIu0jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κχσфчЪЗγьлЫ():
    if 33 * 37 < 0:
        _dead_2567 = 464
        438
    value = 604843
    if len('') > 0:
        922
    text = __import__('base64').b64decode('Qzd2VWN1d3phOVNtREJlbWx0bzk=').decode('utf-8')
    total = value + len(text)
    return total

def _мсШгγэΗжλтΝлуэм():
    value = 117310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnzVa2UG7aMTCVaU70aZHjwJs0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 22 * 14 < 0:
        _dead_4601 = 710
        pass
        864
    return total

def _ΚСχртΟщΡзжβиФαщ():
    value = 906268
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KS2xOGQ1zacIKlen7n++AwgE6mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΩКЕЫυкыйПξςД():
    value = 45394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx/rXllp56I1aDCO+2+jN3wpsDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5044 = 185
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        929
    return total

def _ξνеАςАμΙзΙΘ():
    value = 460425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pz3jPkk71YIpMyW26nWJLBIhyUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бЪвΕΙгΖкЙМууоαЕ():
    value = 891164
    text = __import__('base64').b64decode('SVFZaU1RSHd6Q3p4eEdjNXE3VGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _νЙоюΔЦжЯуоζ():
    if False and True:
        pass
    value = 60254
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSD9S14xqPtVPxX6/WG8EzQXw2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оτЦΩρГνηЖΤΦ():
    if False and True:
        pass
    value = 985576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRvoOH4x3ZEkGVr67Ve3AyY50mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νяъΚΗПρшζВГφπζ():
    value = 743403
    text = __import__('base64').b64decode('bHE5VHd1QjUwdjFHZWl4dG9mQ08=').decode('utf-8')
    total = value + len(text)
    return total

def _ПнψЫςВΘΗςΣГΖГЕеЫ():
    if 45 * 16 < 0:
        _dead_1401 = 145
        pass
        pass
    value = 969691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyL8YgIbx/01CT2mnWmSIy0YwmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пχДγЛΩаΑЗΜοδκ():
    value = 627051
    text = __import__('base64').b64decode('cnJxcmx6TklhVHYyTGJHc2NQRFY=').decode('utf-8')
    total = value + len(text)
    return total

def _λЯλνПЖηЭа():
    value = 54140
    text = __import__('base64').b64decode('cmxFN0lIRXlWN01LWG1JNVVGSVE=').decode('utf-8')
    if False and True:
        _dead_2259 = 754
    total = value + len(text)
    return total

def _рсИЗуяеМАТ():
    value = 237023
    text = __import__('base64').b64decode('T1hXU2tMeUMyUUZFTUZjcWxSWVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠοπунΑАбэКθΑλЪВ():
    if False and True:
        pass
    value = 817264
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB7veUJu2/whIyyJ5XmiIHR//Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        726
        _dead_3713 = 164
        418
    total = value + len(text)
    if len('') > 0:
        _dead_5627 = 128
        326
    return total

def _МщВЮιдэιЪбΛ():
    value = 352000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECDqRUcfyb8UHSTwzXmkEjx+vGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шщγΩοσГПΕΥча():
    value = 2115
    text = __import__('base64').b64decode('RkZfODF0b20xaUJmYURWcFlYUWw=').decode('utf-8')
    total = value + len(text)
    return total

def _АпЙЙβжЙРЧццδΘΔеЗ():
    value = 604068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AS3vVmQw24kGFTuE2wejJC175jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤπшηςδлтПШДгЩζк():
    if False and True:
        716
        pass
        1000
    value = 863155
    if False and True:
        pass
        0
        _dead_4912 = 15
    text = __import__('base64').b64decode('Z2RfSWZQS0s3SGRub2EzcDI3cTg=').decode('utf-8')
    total = value + len(text)
    if 77 * 97 < 0:
        _dead_6412 = 650
        pass
        pass
    return total

def _бψΨТΩομЯΘαπт():
    value = 187020
    text = __import__('base64').b64decode('cnFxNTFtam4zdHhzRW9Xem9nQ20=').decode('utf-8')
    total = value + len(text)
    return total

def _ζβхюБаπρθВεыФλπ():
    value = 773037
    if 39 * 17 < 0:
        pass
        140
    text = __import__('base64').b64decode('eVA0SEU1ZDZtVzRrc0M2czRlRzg=').decode('utf-8')
    total = value + len(text)
    return total

def _КΘΙτрφΨВρΗμТч():
    value = 284347
    text = __import__('base64').b64decode('ZFFxeTdDekNsMkhRNTNGQWU4Znc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΟΓСЖαχТЬЦμΙνФΒ():
    value = 424990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSjte1BrrJIIGwqs+my1BD0qvV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вЭηдΤорςτπω():
    value = 196044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxzif1QA0qpaHwD2n3q2Mj0h4zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъςΤоЙΘνж():
    value = 43777
    text = __import__('base64').b64decode('V1NaQXdOejZJajJPajN1OWdJUlc=').decode('utf-8')
    total = value + len(text)
    return total

def _уλяЬъбЖζνςορуТτл():
    value = 872095
    text = __import__('base64').b64decode('RGROdWFwNGFKZmd0c2ZPM21yX0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡψΖвΥсЬдΔΜΒ():
    value = 935826
    text = __import__('base64').b64decode('ajdpbmVneTBweUtDc1poNF84bHU=').decode('utf-8')
    total = value + len(text)
    return total

def _τИППЫХшΖнΙАЮиΒΞЧ():
    if 25 * 19 < 0:
        _dead_5607 = 628
        _dead_4148 = 207
    value = 443109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxX9YHc23btTHFeEmXGXEAh5z2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()