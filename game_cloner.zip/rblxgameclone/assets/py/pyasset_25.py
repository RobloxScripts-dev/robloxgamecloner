#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΙъοЯтжБΜΜис():
    value = 356444
    if 76 * 33 < 0:
        _dead_5867 = 50
    text = __import__('base64').b64decode('a01DWXltdGlvSmV4S0hJUDl0QnY=').decode('utf-8')
    if False and True:
        560
        943
    total = value + len(text)
    return total

def _ΔБДΚΣАΑΛнВΑλьеυΡ():
    value = 922393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px7GZ34f0pELHAiMywHJFRM+yWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2715 = 292
    total = value + len(text)
    return total

def _зАЕνδиЮпФМχЧΓ():
    value = 781348
    text = __import__('base64').b64decode('bEU1WnFocGExMDJLUG83TFVFUTE=').decode('utf-8')
    total = value + len(text)
    return total

def _СнАйξψΦеψУψпΞЕΠц():
    if False and True:
        _dead_4427 = 380
        _dead_8328 = 844
    value = 732528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzbeO1YP6Y4TLSKim0WpCwoit2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 66 * 31 < 0:
        pass
        289
        pass
    return total

def _КδφквΝФУЕΙСоиТζЕ():
    value = 306335
    text = __import__('base64').b64decode('eE9BVmFDdEQzNEY1UDlJUHBWUzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΤφачβΕЩЕωЧΝЛЩ():
    if len('') > 0:
        pass
        pass
        pass
    value = 366765
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB32S3kh1flXDSuHxFuVFzwO/T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7292 = 629
        pass
    total = value + len(text)
    return total

def _гвБсшлЪпςьоΠиυл():
    value = 393739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cjz3T0I/7LwQACuCyUfGDBwowj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔγαηтιΑмΦржы():
    if 48 * 66 < 0:
        33
    value = 88559
    text = __import__('base64').b64decode('QVhhZFVtZERiT291RExlWTJJcnc=').decode('utf-8')
    if len('') > 0:
        260
        pass
    total = value + len(text)
    return total

def _ДδηλσвшΕοШ():
    value = 695365
    if False and True:
        pass
        _dead_7814 = 693
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgXeYFwyq60MCFml7EeBB3YatU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 23 * 73 < 0:
        _dead_4106 = 73
        _dead_8690 = 768
    total = value + len(text)
    return total

def _ЭъТζΒλнΛЙшεбΟ():
    value = 345920
    text = __import__('base64').b64decode('eHFyUTVOa09kOFhuZG9Veld1RXk=').decode('utf-8')
    total = value + len(text)
    return total

def _μΨΚθнΤΡЩω():
    value = 774853
    if False and True:
        _dead_3181 = 877
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiT1a3oAxIMXKxWbn3WSGzcY0lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 75 * 26 < 0:
        _dead_8965 = 986
    return total

def _ΨЙСЧШЯΙεп():
    value = 563894
    text = __import__('base64').b64decode('SXhrSWRsNFk2WEtKbE5xdnFvd2w=').decode('utf-8')
    if 31 * 4 < 0:
        630
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2922 = 57
        pass
    return total

def _οδηпгшΩσэж():
    value = 621485
    text = __import__('base64').b64decode('UDlEUERiVkJBcFF5RWJsdkNsQ2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝеЖΜЪνЦЦЧΔо():
    if 70 * 65 < 0:
        478
        _dead_4488 = 529
    value = 398219
    text = __import__('base64').b64decode('eUNnbTdVeU5GTGFJTG1Vb056RHg=').decode('utf-8')
    if 52 * 68 < 0:
        pass
    total = value + len(text)
    return total

def _чυЗπлΑгхγИдΖьЙъ():
    value = 638059
    if 33 * 65 < 0:
        872
        pass
        _dead_5424 = 234
    text = __import__('base64').b64decode('WVhCYk1iT0VwanBhSHk4SHQ5bmU=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_3193 = 789
        749
    total = value + len(text)
    return total

def _ΣΒжсβржσβ():
    value = 358155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwrIS1YK0r4hNQiX8Fi2EQE2zkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΥыНЛнκΜΞбмТβЭ():
    if 8 * 9 < 0:
        _dead_2860 = 862
        _dead_4958 = 51
        pass
    value = 142240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSDyZwQxrZEHbgak31qhEBAjy2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑгςДЫςутΖЮжХ():
    value = 298747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzbKOlc864UZLyOpywfFBDEK1Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЪμМΖΜОеЖлУθХΠγг():
    value = 39049
    text = __import__('base64').b64decode('TW8wb1FRaGdwYnY3RVBRaFVhanM=').decode('utf-8')
    total = value + len(text)
    return total

def _дфхκνΗΡСэтКФф():
    value = 366342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgDsXVsvpr8tPiuQ0Q6GFTQhx3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΛФгςΒЩθюЬω():
    value = 262782
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw7IbwAIxrE0MRyIzwGUNTwu81w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟτгрзΛΤΑаВ():
    if False and True:
        84
        pass
    value = 293883
    text = __import__('base64').b64decode('QkdvWVg5YVRPUmRfQzUyRXdNbkk=').decode('utf-8')
    total = value + len(text)
    if 10 * 5 < 0:
        882
        _dead_5316 = 429
    return total

def _ЭШΓшдАЪбυ():
    value = 65203
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh73Vggx2aM1GxaExWDGYggJwkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 45 * 95 < 0:
        141
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_2522 = 840
        352
    return total

def _аДднбМχН():
    value = 606290
    if False and True:
        _dead_8668 = 757
        267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDfpOlg01PsyHl6kxF6HBBID9T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        675
    total = value + len(text)
    if 59 * 85 < 0:
        390
        695
    return total

def _ΖквΧΤРЮМдΚηжЩГщв():
    value = 942249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NX/qfAg9zq4yAx6m6QXJAyML5n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФθТθчнЭоИк():
    value = 807456
    if False and True:
        _dead_9277 = 552
        _dead_9612 = 25
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgD0XgUazPkwERm5/GeWYxAK/Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 28 * 74 < 0:
        pass
    total = value + len(text)
    if False and True:
        37
    return total

def _θοΩСΤуяЗвγΞμΙ():
    if len('') > 0:
        _dead_7300 = 846
    value = 777213
    text = __import__('base64').b64decode('cklKMmt2STNzWFI0UjNFVEEyOUU=').decode('utf-8')
    total = value + len(text)
    if 36 * 13 < 0:
        pass
        pass
    return total

def _мОЙаΠХβαΤркΗΘсΖН():
    value = 834192
    if 23 * 42 < 0:
        pass
        475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgHrXW4YrplTEh2nyW/DYnZ53Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΖαξэнЬЩцТЕΕДаΦш():
    value = 424661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzrjQggL34AODSj3nlCcFyl63UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йψαДЙσаβНЧпзвтА():
    value = 887166
    text = __import__('base64').b64decode('TjRmRDJPZHhJT0s3c0l1dlpLZDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗκдГЯвРЧтпьКΛАΔ():
    value = 21584
    if len('') > 0:
        _dead_3077 = 171
        _dead_8037 = 858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgbLfQVtx64mLwer4mO+bCMi9EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йπПЩФэВСАКς():
    value = 275766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH7ca0Mbq4YbKDip2WWCEBcL82g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪзЧкκэмММΔμΤоΣ():
    value = 621497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MX/8YH4j0oQZPAeh2WC6DHUItGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιйЯЦщюδχχмΨЛ():
    value = 949389
    text = __import__('base64').b64decode('QlRZN09VSjZKWm5WTDBpN3V3eEw=').decode('utf-8')
    total = value + len(text)
    return total

def _χАСХЮФωиΟβηяαоη():
    value = 119622
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAH3SQNuzPoQCCj3zUahDXUb1WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7290 = 230
        _dead_9564 = 564
        512
    total = value + len(text)
    if False and True:
        pass
        _dead_7742 = 751
        pass
    return total

def _гСρРЮςνщдОΣПЫЯθ():
    value = 402250
    text = __import__('base64').b64decode('cjQ0czBFTHo1UXZkQ3h4dGJHdEo=').decode('utf-8')
    total = value + len(text)
    return total

def _μβΕτСНхнΖΦΔФικчх():
    value = 477506
    text = __import__('base64').b64decode('SXJiZlNVaGtUTHlNeTBycEdoVlM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4294 = 514
    return total

def _ФКμзхфФМΔуχΛβлМ():
    value = 729517
    text = __import__('base64').b64decode('SmkxOUFSVFZoS3pkaFpLcTBBcWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡИΓйГнгΦχтТ():
    value = 594371
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyXQVkYY1P4BFQaw7n+7bAsg/D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗдЭччξΟδэе():
    value = 172402
    if False and True:
        pass
        336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTvNVwQQxpwHPQWH6lqWYT8DwnQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5360 = 13
        _dead_2226 = 377
        pass
    total = value + len(text)
    return total

def _кδΜЗνααΗфдΘыБ():
    value = 773557
    if 47 * 23 < 0:
        943
        _dead_8809 = 403
    text = __import__('base64').b64decode('cWpqM2tacVlybDA0dHJrSFgwSmg=').decode('utf-8')
    total = value + len(text)
    return total

def _κКЙркеΤх():
    if len('') > 0:
        _dead_9178 = 341
    value = 897590
    text = __import__('base64').b64decode('TTlRMjdmMmlMY24wREs4ZVNhM0U=').decode('utf-8')
    if False and True:
        pass
        50
    total = value + len(text)
    return total

def _ЗπιэΝЙΞхΡ():
    value = 88053
    text = __import__('base64').b64decode('dWtGaUtRR3JWVnRJZzVkWDZSZ0E=').decode('utf-8')
    total = value + len(text)
    return total

def _цкЪеРЛπъυЕБУпБ():
    value = 535818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgXeRVUf65AIDVuPwkajYHwO9lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤκхМФτυΙфЧΛоγП():
    if False and True:
        _dead_9509 = 202
        _dead_7748 = 636
    value = 855643
    text = __import__('base64').b64decode('bFowWHI5Z3g0eUtjejJfdEJzWVk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЗψΓтШКΝЮηωπΚ():
    if len('') > 0:
        pass
    value = 678457
    if 55 * 56 < 0:
        _dead_8734 = 530
        142
    text = __import__('base64').b64decode('aHliY1NZeHdEMGxzajJxbFE4dmk=').decode('utf-8')
    if False and True:
        pass
        _dead_2517 = 117
    total = value + len(text)
    return total

def _ВсАЦμЫмΜΘΟ():
    value = 963703
    text = __import__('base64').b64decode('eUVabnVhMkxETExJbXpjcTRoM1Q=').decode('utf-8')
    if len('') > 0:
        pass
        552
        pass
    total = value + len(text)
    return total

def _ЛзлИюχвκНяыζПН():
    value = 622700
    text = __import__('base64').b64decode('aDZfd3ZXd3Nkd3BSclE2c2xmREs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9021 = 943
        pass
    return total

def _ΤΙδΗЗΞяΛъжζКбС():
    value = 711053
    text = __import__('base64').b64decode('WF81QlhvNGM4WmNHZER1bE5POWM=').decode('utf-8')
    if len('') > 0:
        _dead_8138 = 236
    total = value + len(text)
    return total

def _ΖηШχюЩмςе():
    value = 72389
    text = __import__('base64').b64decode('Q0xFV1JfREJ6T0hPUTZhWk5UY2o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1438 = 843
        210
        pass
    return total

def _ΞмΣГΝЧЧЭЬΑ():
    value = 202070
    if 13 * 52 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyLKWFYuq5o8DByGkG+IHnUh/lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лсηπφΗΑжьТνΘЗΛΥ():
    value = 994351
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXzTWF8PwYdbM1qOw3iSGyIQxmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЛΘдχЯΖχ():
    value = 596131
    text = __import__('base64').b64decode('VWUyR2swUUdIWGMwYVdkM3A0aDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΛэмωЙгРρч():
    value = 245635
    text = __import__('base64').b64decode('QTQyQ2h6cnJvTUg4WnRwdW5wanY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤФЪгΙятъыμζΠЦМπ():
    value = 118295
    if 2 * 82 < 0:
        pass
    text = __import__('base64').b64decode('WkpvWWZPSTFHc0l2aVhnVE02YmI=').decode('utf-8')
    total = value + len(text)
    return total

def _Κсυσηюηβш():
    value = 402001
    text = __import__('base64').b64decode('VWNHd2F3SDIyT2p2MHk0cnp3ZzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥлΝчμβυжЯЭъρтЯ():
    if 14 * 80 < 0:
        965
        pass
    value = 949417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCX+eFJr0KcQBTvx/X7GHhx54W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8959 = 57
        pass
        894
    total = value + len(text)
    if False and True:
        pass
    return total

def _меμЧηдΨЪЪСмЩЙ():
    value = 237107
    text = __import__('base64').b64decode('cUJGQ2pvaE1ibW5CWGx4dVdOenM=').decode('utf-8')
    if False and True:
        664
        pass
    total = value + len(text)
    return total

def _θъβтеДХзΣщυζφоζу():
    value = 400261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDbhW3tv94YuaCH38mnDB3Ue400='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΦЙιгΓαЧΟФаУяτз():
    value = 534040
    text = __import__('base64').b64decode('bmNrQ1B2TVptYjZBd1h0QXBkUFU=').decode('utf-8')
    total = value + len(text)
    return total

def _оδΕУΠανςΘрмΦυа():
    if len('') > 0:
        _dead_7741 = 878
    value = 59556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Awf9QgJhq/0CFQaR2F2zZDQZ23w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мЫПИкЭРюлЧ():
    value = 732907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSnVa3kU2qBaOwSl6wCGFyM+vF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъχзкΣσыΔΝΡн():
    if False and True:
        pass
    value = 150395
    if len('') > 0:
        68
    text = __import__('base64').b64decode('eGUxQUthSVhRYXV6Rzd2UzIxUkU=').decode('utf-8')
    total = value + len(text)
    return total

def _δЙιедςυЭυЯф():
    value = 539701
    text = __import__('base64').b64decode('bFhIMnFpWE1SVWw1YjhVclg0VjA=').decode('utf-8')
    total = value + len(text)
    return total

def _яωВштοЯа():
    value = 936589
    text = __import__('base64').b64decode('WmtZVVBZY3ZCcml5aFZlMjZHNUE=').decode('utf-8')
    total = value + len(text)
    return total

def _γЩДЖΔВΛаЪдпсЕκт():
    value = 596673
    text = __import__('base64').b64decode('TnBhN0VxYmFRbDdnb3c2bDhBTlk=').decode('utf-8')
    if 37 * 99 < 0:
        pass
        pass
        709
    total = value + len(text)
    return total

def _ВдΑΓВЫΣЧ():
    if 88 * 25 < 0:
        93
        _dead_6681 = 694
    value = 618609
    text = __import__('base64').b64decode('cHpNV0c5aF9oaWxTY053UThIS0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯХΟхΔτМэЧЭ():
    if len('') > 0:
        _dead_4205 = 468
        _dead_9502 = 895
    value = 546322
    if False and True:
        _dead_4944 = 59
        856
        355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jwmze1Mj37wTbyaLxHGqLT1+9z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χВΖявδбШУ():
    value = 673128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQe1T3w157EIGSCz23S/HnUZzX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЦΕπхснляΑ():
    value = 133670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwDUOlIs8KQuPQKk8UWoBSYI60w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЛЮςиφΖЩΓЩм():
    if len('') > 0:
        808
    value = 790889
    if 21 * 58 < 0:
        pass
    text = __import__('base64').b64decode('elBubkFXQ0xpb0JRNGx6RWZEcHo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4693 = 147
        _dead_4226 = 251
    return total

def _ОЙчиЖВιΠΩσИηАω():
    value = 309929
    if False and True:
        pass
        570
    text = __import__('base64').b64decode('U1JzejV3X1lmN09SeHk2cmxuSl8=').decode('utf-8')
    if 6 * 58 < 0:
        754
        _dead_2050 = 528
        _dead_3111 = 816
    total = value + len(text)
    return total

def _БАятЧмпгοДизΘ():
    if 95 * 49 < 0:
        479
        996
    value = 244236
    text = __import__('base64').b64decode('TnBSR1RUM3dYckxsNjBZbHI1ZWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ГЦДςЮтςЫЗλΨξЯХ():
    value = 992876
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('TTZadzBLS1pkNFczOXdZM2xwTDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔξцуΚΝЗцыΘгΣ():
    value = 216092
    text = __import__('base64').b64decode('ekU0WFRRSTgyZFRYTzM4dUNfcEM=').decode('utf-8')
    if 91 * 70 < 0:
        pass
        271
        998
    total = value + len(text)
    return total

def _ЙκцмиγΘЫР():
    value = 293311
    text = __import__('base64').b64decode('RmJVb0Y5SUk4Wl9KeEw5SDJ5Nkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨрянΕΘΞЦΑ():
    if False and True:
        309
        _dead_4225 = 712
    value = 324093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyjUXHIw87EvNQ6zn2afByIs6Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗНчΤΔΨБΣЛθ():
    value = 817757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ljq3P0YJr5kJKln77AG2ZC4851g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧнЕοДоαЙОщΔΘ():
    if 62 * 58 < 0:
        pass
        pass
        _dead_4872 = 104
    value = 96259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISvjYwM735sIaAyl4l+7NnUpymw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚхпШρУШЮПεκщΖБаΖ():
    value = 71038
    text = __import__('base64').b64decode('VE9YZ2JXWm9hZ0lBUVVSUm5vYnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _φΧеЗьΠΨХГλΨ():
    value = 919072
    if False and True:
        pass
        692
        _dead_7194 = 712
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ER3WeX862aUAbVutmV+VJ3MjwFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        779
        128
    return total

def _ςиΒκηωΟафΨΤΕо():
    if len('') > 0:
        _dead_9696 = 791
    value = 416680
    if len('') > 0:
        pass
        436
        _dead_3407 = 357
    text = __import__('base64').b64decode('RkhuYjZQVEhmcWhET0FQRnVtMlQ=').decode('utf-8')
    total = value + len(text)
    if 68 * 40 < 0:
        pass
        _dead_4844 = 749
    return total

def _ΒΒлТξοΖфΞкψчΚ():
    value = 34251
    text = __import__('base64').b64decode('VmljOUVabFB0Vk94bXNFa0Vzd3o=').decode('utf-8')
    total = value + len(text)
    if 97 * 88 < 0:
        pass
        352
        pass
    return total

def _ωЪΩΔΟрΓБνу():
    value = 469307
    if 38 * 23 < 0:
        _dead_7507 = 722
        743
        pass
    text = __import__('base64').b64decode('SnE1MUxLTlVTYlpncXVuV2tlYms=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4251 = 829
    total = value + len(text)
    return total

def _ЯюνСЖЫКоζщВа():
    value = 193057
    text = __import__('base64').b64decode('TkRmMkJscENESDc1eGhTYVIzaXM=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if 81 * 41 < 0:
        _dead_8071 = 487
        344
        920
    return total

def _жЯοсСЪεяьМюь():
    value = 360280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwfTO2ctwbALbRWK+wC4ZQYGvFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        535
        521
    return total

def _лλΙωезιзьдю():
    value = 550072
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lw7xTEVoyZEWaTv240y8bRx7sGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩхΙдЖцГΠΛуНИΦз():
    value = 958585
    text = __import__('base64').b64decode('ZWlsYXdRZlBvZ21wbzdrbXFnOUU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6267 = 843
        205
        137
    return total

def _ΥиλфбцΛЗВОШлΒξЗг():
    value = 447684
    text = __import__('base64').b64decode('UGljRU8xNm1aWE12MnM3eHZUUmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _щΞΡορυΧΨΔΖмЙЮцψ():
    value = 492071
    if 67 * 88 < 0:
        519
        _dead_8814 = 657
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CirJUVMpy48QNReZ61KjIScFsTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        789
        213
        555
    return total

def _ЫБΠЦΙтеΤΞЮΔΒоэΡΞ():
    value = 672556
    text = __import__('base64').b64decode('Q1lVNTFCMVpuZVVjdWFWNmxSVGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓПДλКφεьΞКжρζг():
    value = 690454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3bgd2Y6yZ0gExj640OpbSgOwVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хюнρΚЕьр():
    value = 781338
    text = __import__('base64').b64decode('eVNRNVE1ODdpUUQwcm1wVEZMdzE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        324
        308
        _dead_4316 = 640
    return total

def _МдτТОВЭА():
    if 11 * 88 < 0:
        _dead_6073 = 208
        _dead_6999 = 917
    value = 126598
    if len('') > 0:
        514
        283
    text = __import__('base64').b64decode('SmtHNWd5dTI2NWs1cExJYXRKVEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗэΚΑΑΤεКΔΡ():
    value = 469212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxXRSnpt54UgFzzx2WO6OCkgt0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 19 < 0:
        572
    total = value + len(text)
    if False and True:
        pass
        _dead_4989 = 453
        914
    return total

def _нРаъνЕΝТΘКΑΠВξ():
    value = 906763
    if len('') > 0:
        pass
        _dead_7935 = 611
        pass
    text = __import__('base64').b64decode('eVVuUGpHazdCMFZwWHVONUljZkM=').decode('utf-8')
    if False and True:
        641
        pass
    total = value + len(text)
    return total

def _μщβошСнεΖЮюοп():
    value = 717628
    text = __import__('base64').b64decode('anRwUVBDbjRUcFlBOXhlZEI0bEc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8868 = 749
    return total

def _ДЛοЩπυэйΔОπΧзн():
    if False and True:
        pass
        _dead_1605 = 444
        pass
    value = 493276
    if False and True:
        993
        _dead_6622 = 416
        697
    text = __import__('base64').b64decode('bmk1cGhvaGdjSTZseEliQU9sMFY=').decode('utf-8')
    total = value + len(text)
    return total

def _йθНЕΒλΣβΔФεЬТλγ():
    value = 859703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAzcQWJo7pE1EQSB8AbDJCMj72w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 49 * 16 < 0:
        _dead_1262 = 146
        _dead_3911 = 762
        350
    return total

def _ХΠΖιЗΠωΣВНвМфКΣ():
    value = 717633
    if len('') > 0:
        pass
        962
        pass
    text = __import__('base64').b64decode('aEdPMXhSbW04M19KYnNMZ0d3ZGg=').decode('utf-8')
    if False and True:
        _dead_7895 = 272
    total = value + len(text)
    if len('') > 0:
        _dead_3797 = 846
    return total

def _пΒжτνМЮψиζΚ():
    value = 394120
    text = __import__('base64').b64decode('V0FvZmdLc3hUeDJVS3dTMzU1blU=').decode('utf-8')
    total = value + len(text)
    return total

def _ШοбсцΖеβΚμЗцР():
    value = 200840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ey7dfGZh7Js7awb75UfFAX0+9Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 9 < 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        534
        pass
        673
    return total

def _зиЭνΑΥгμКФАкπ():
    value = 740279
    if False and True:
        _dead_1205 = 568
        pass
    text = __import__('base64').b64decode('bHdzb3YxdkhsNUsxRXlyWlpfc20=').decode('utf-8')
    total = value + len(text)
    return total

def _κпБΧλκЩΚСΖν():
    value = 748859
    if len('') > 0:
        _dead_1544 = 50
        _dead_3192 = 116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fyzhb3oz+4IaLl2H2g7EGj836z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4147 = 636
        pass
        108
    return total

def _ψαтΩлоГβΚ():
    value = 130339
    text = __import__('base64').b64decode('U2MzMGJ6QVdzUlVmZ1luZXdSOVo=').decode('utf-8')
    total = value + len(text)
    return total

def _λмдωΑαΞсю():
    value = 423171
    text = __import__('base64').b64decode('a3U3SFZlVHBqRTlQZVZMQklkZ3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙзфΠЖМНΠфΣΔ():
    value = 209304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzziVlhu66EPNgCwmliIBiY+22o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 14 * 72 < 0:
        415
        103
    return total

def _οцλХχуΔσУδΟβпТк():
    value = 589398
    text = __import__('base64').b64decode('dmlHUUdHSEt0bUtxZHNkeTAzZHE=').decode('utf-8')
    total = value + len(text)
    return total

def _яΦχЯВΑεωЙ():
    if False and True:
        469
        pass
        pass
    value = 143848
    if 58 * 87 < 0:
        _dead_5779 = 910
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyfTeF0887FTADqUw2OcZHMEtkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('cg==').decode('utf-8'))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 58 * 37 < 0:
    286
    pass