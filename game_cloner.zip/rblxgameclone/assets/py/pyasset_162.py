#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ЭЩтуГОτκΧεэьΟηа():
    value = 292044
    text = __import__('base64').b64decode('amdIWG9JT0pXMTI2WW5lMUR6WlI=').decode('utf-8')
    if False and True:
        _dead_6220 = 678
        376
        113
    total = value + len(text)
    return total

def _ВΒщвщΣΓцЙеКцз():
    value = 615015
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISv9aG4j8J0FF1mKkATALBE802E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_1484 = 313
    total = value + len(text)
    return total

def _пшЛςΡыΓвλИЪ():
    value = 518965
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCn3aWIa75AbCwqk0FSkIT8XyT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        719
        _dead_5787 = 952
        _dead_4716 = 24
    total = value + len(text)
    return total

def _οыΖцьШрЩΓЪΧ():
    value = 677701
    text = __import__('base64').b64decode('bTV4WmNlcmx6SDU4eE03aFoxb2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _аДИБЫЖςЯΝХн():
    value = 857627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQjgYmUd0IEpKg6S93yEFwo463Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙшДОЕπσлЙфЬζюоИ():
    if False and True:
        _dead_5867 = 658
        pass
    value = 802400
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwO0YVJtzIEzFx3023/JGnIu9UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 9 * 71 < 0:
        pass
        _dead_9622 = 972
    return total

def _АДыρβэξУЦЯыπΜ():
    if False and True:
        pass
        _dead_2911 = 971
    value = 981084
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aim2Q3gsq6JaKBi1kFybHQwXvFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПуΕММВзгаВδλΞΙ():
    value = 819952
    text = __import__('base64').b64decode('aGp6dzUxNGZRYXgyZzhQWXZBMVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭчТжВяЛΙЛΚРмД():
    value = 455084
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BibOQ3I3p5pVEAOHmwWDC3cq6Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СсαΦμфΕθийχρ():
    value = 434053
    text = __import__('base64').b64decode('bVJRVFNrUjV3SExEaU44ZjVJMl8=').decode('utf-8')
    total = value + len(text)
    return total

def _йΓУьяШчθΝЯ():
    value = 899673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nyy1bENp1p0ZIxux0l20Mw0Y/U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        732
    return total

def _ΒΓТμΨужξМεθЛΘйΗ():
    value = 391803
    text = __import__('base64').b64decode('ZWFzSGhiZmduQ0lQTmg4M3VzZlM=').decode('utf-8')
    if len('') > 0:
        pass
        245
        593
    total = value + len(text)
    return total

def _υЕэπμДдКΘаЩ():
    value = 63479
    text = __import__('base64').b64decode('T2kyUERiWjA5V0hIcWFWRFA3eHQ=').decode('utf-8')
    if False and True:
        759
        109
        _dead_2658 = 911
    total = value + len(text)
    if False and True:
        _dead_4025 = 630
        451
        _dead_6981 = 926
    return total

def _νЭχΧюδШΒ():
    value = 555393
    text = __import__('base64').b64decode('S0d1M1hsV1dDRWdEZDFoV0hIUGc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5373 = 781
        _dead_6524 = 914
    return total

def _ЕεΨΠхарЭпГпГЕ():
    value = 349094
    text = __import__('base64').b64decode('QUFJZ0VsY0lRbllZbFFiQ0xvVzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΞХκрГκΣШΞиθγΔЭч():
    value = 227043
    text = __import__('base64').b64decode('cmw1bjdjcUk0VmczaTZ0RTI4WFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒЩжддβΔМрΘ():
    value = 273958
    text = __import__('base64').b64decode('VHlMaERJa0lDdDlDQ1JoUEdpSUc=').decode('utf-8')
    if 91 * 15 < 0:
        _dead_1454 = 682
    total = value + len(text)
    return total

def _ьΖпΒσσСЮΥθжκЬ():
    value = 3990
    text = __import__('base64').b64decode('d2c0bk9iamZ6YU96YVlNUE5iMXU=').decode('utf-8')
    if 32 * 73 < 0:
        pass
    total = value + len(text)
    return total

def _ФрδΕЮαθνΟУΑвфсμλ():
    value = 452269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHnVVgMTppkNNSiP8XGyPig3xkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        467
        _dead_7347 = 506
    total = value + len(text)
    return total

def _ЦКЪιΘνашКЧГЫыΓ():
    value = 348208
    text = __import__('base64').b64decode('ZWNweENQWTdvb1l1MGxKZzZZcnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗυЖΔΟгеаΑΙн():
    value = 87560
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXjhfEka6f8lKyiS51GmBhF+s0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΤЭυщЦγЛЕ():
    value = 232526
    if 98 * 83 < 0:
        pass
        pass
    text = __import__('base64').b64decode('UWNmNEh1VzhPYmp5SVAxNmRScXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ХТΠΙΛΥЙЧλЖМαУшГΡ():
    value = 387145
    if 8 * 75 < 0:
        _dead_6197 = 308
    text = __import__('base64').b64decode('QXJLVkxGUERodzNPbUpMY2lPTG8=').decode('utf-8')
    total = value + len(text)
    if 29 * 87 < 0:
        681
    return total

def _ЙяБэСмДУОы():
    value = 805362
    if len('') > 0:
        538
        547
        _dead_2399 = 379
    text = __import__('base64').b64decode('SlpkQ3kxODZXSTlJS0tGa0MwRkk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2586 = 822
        pass
        _dead_9695 = 508
    return total

def _ηТьЙЪЩиЕφиοж():
    value = 800080
    if len('') > 0:
        _dead_6150 = 635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHb+PAYh1a4VFxeO/k6XOx8s8UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        78
        455
    return total

def _θκнΠЕЕοΣАщЗй():
    value = 60472
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH3cXEE9ra8lCifz8myvAHUO0Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФλОнΛбΦδψδрсυλзη():
    value = 76603
    if 91 * 68 < 0:
        345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB/vN1s414Q6CCKw0Ue8JzwW4GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЕЭйЭЯΑШΣΑιЙрΓ():
    value = 457474
    text = __import__('base64').b64decode('Zm84bVZhOGtQRG5Qbno1Q2VLYmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ωЩЪΘΡдичθгΑю():
    value = 272210
    if False and True:
        pass
        127
        920
    text = __import__('base64').b64decode('TXdNNXFfRFNBQWRDdU9wTE9xM08=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜНσИζΜЮδяΟНς():
    if False and True:
        187
        _dead_4482 = 404
        _dead_9442 = 914
    value = 787984
    if 51 * 52 < 0:
        521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXe8QEUh66IbGyKx/2nCHwoj4Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8404 = 912
        579
        262
    total = value + len(text)
    return total

def _НХвΒвΦЧυΙΡЩξ():
    value = 749118
    if False and True:
        pass
        _dead_9282 = 660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex3dS1Ig9oI6AAq6xX+iIxUDsDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФУВйЩГлЧΩσ():
    value = 38998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCbyTHcr7qEtCwyvwAKqbSh67l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        323
        pass
    total = value + len(text)
    if 70 * 21 < 0:
        pass
        782
        _dead_2314 = 729
    return total

def _ΛлгЗЩрΟξκΝΒМΖτΥ():
    value = 337377
    text = __import__('base64').b64decode('QTNjUmtmb1ZVd1R5ZjhJaURqdWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗмξωΠΧсΗдПюφρτκ():
    value = 348806
    text = __import__('base64').b64decode('REtiX05BRXNlbVY0SlVVUjdoMTA=').decode('utf-8')
    if 67 * 72 < 0:
        pass
        145
        pass
    total = value + len(text)
    return total

def _чоλΟΓЖγУАьфνΟЬй():
    value = 542619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT7ASUgYzPsQMD+kn1ueLgkFy0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚψЕθΥФΖφмтΝЮЬп():
    value = 852842
    if len('') > 0:
        _dead_5021 = 159
        _dead_3828 = 859
    text = __import__('base64').b64decode('QmJvbFhsb2NLRXZqY2diRWNwclI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙгВЕчЫκУΖиб():
    value = 614476
    text = __import__('base64').b64decode('bFUwSGpYNzV0bUlVNndqNjBoZDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯвЭвЮЗчВωθΧ():
    value = 765653
    if False and True:
        519
        388
        _dead_3421 = 389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyLAP0Bty/EHBVaUxkWCOyAp0T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λклеςηΧΩουΨЛэгКΜ():
    value = 166651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxnWWXYp+PwsLiSr0X+hIHcu/mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЧлБΥцдРΗвΤл():
    value = 511133
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyPdOHwrzYcWHQyU3nrFGR0e6zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΠιθΚВэαΟЧρΞЮΑ():
    value = 596495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyzHYgMJrfw0OSeg2HCTFyh97U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΙеΑθζδЦΦΖ():
    value = 203384
    text = __import__('base64').b64decode('TXVCM1ZaOXA4NkVha3BvR2pBU0s=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        913
        _dead_5260 = 249
    return total

def _МσΦΨηχΘСлдΙЕ():
    value = 304461
    text = __import__('base64').b64decode('ZjZodTRZODhaU3RVbEhvY3ZpZ3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜЛкпγЕнΓΙγΟрчя():
    value = 580512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDnbaX9gp4oXYxulmlWhNTUmzFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШКξθΔνцыЖΣ():
    value = 520301
    text = __import__('base64').b64decode('ZHI3M1ppV0ducXVwRjdsTklobTk=').decode('utf-8')
    if len('') > 0:
        _dead_2182 = 277
        906
        pass
    total = value + len(text)
    return total

def _ΛВςεΩσΕВУπκЮ():
    if len('') > 0:
        502
    value = 995186
    text = __import__('base64').b64decode('eV9Gb2dsSktiVk5SRDRYdHc3dTI=').decode('utf-8')
    total = value + len(text)
    return total

def _вΔЯσакΚыЗЭфΧς():
    if 46 * 3 < 0:
        31
        pass
        _dead_5032 = 276
    value = 415771
    text = __import__('base64').b64decode('d0N1UFpoTUZCXzlENjZGeHpVVU4=').decode('utf-8')
    if len('') > 0:
        _dead_6227 = 747
        365
        pass
    total = value + len(text)
    return total

def _сΞюАчФУΣоκ():
    value = 511361
    text = __import__('base64').b64decode('Yk9qWndfNDBMTDllVnJjQzVLc0g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        315
        404
        _dead_3567 = 164
    return total

def _ПхжючΕφδ():
    value = 921245
    text = __import__('base64').b64decode('TGIweDU4YXZYRGhHZ24wek1yMkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΚЮнЬэАмβΝьп():
    value = 567788
    text = __import__('base64').b64decode('Sl9wczBiU1p5bDViZ2hyTE9qTTQ=').decode('utf-8')
    if len('') > 0:
        _dead_8264 = 847
        941
        _dead_9659 = 574
    total = value + len(text)
    if False and True:
        792
        15
        _dead_3321 = 908
    return total

def _жψΔοΤЗεЖяоЪшХО():
    value = 524926
    if False and True:
        pass
        542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAT1Wnw16P81GxeN2AfIMQkfxVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΜβΜΓзСΛмΝШΙΠ():
    value = 650745
    if 83 * 72 < 0:
        _dead_2803 = 953
        385
        _dead_2253 = 241
    text = __import__('base64').b64decode('Z2IycUlhV1JLcDBHT21QMGZubjQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4523 = 184
        pass
        _dead_4242 = 964
    return total

def _КΗБηЫрαшδяμμξ():
    value = 456766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAjod1YurIooEFyu7F3DLjEVsT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝЯΩКΨΡυω():
    value = 203573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgLjUQY92PsaPiCw2neIYwEIw3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СхΓЬйюΠΒЛкδФТШАΜ():
    value = 22824
    text = __import__('base64').b64decode('RktJeklFbFE1YTdiQjlLOWl5YnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _δВγБЛЬГФΛэχыβ():
    value = 699927
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBzleHpq9/krMwP18ga5FwwKskg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нψΝЫωХэΞΒмφЫΙωзХ():
    value = 680835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NizXPQUYyIw5MTqA226fDXwJ1Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 29 * 73 < 0:
        pass
        pass
    return total

def _ВчЖΧΨСАШЕъΕадФэη():
    value = 559402
    text = __import__('base64').b64decode('T3I0NkZxUzVJNDI0T0pNQko0N2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΦΥшФΝЛвΜЛуωЬΠ():
    value = 226149
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRW2PXIv0J8UDwmJ0H2/IzJ56Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φПχОΛиΓГяΘРТ():
    value = 108138
    text = __import__('base64').b64decode('Z051WXdmRWJDM3cxMFBlQ3Zkeks=').decode('utf-8')
    total = value + len(text)
    return total

def _уЮеЫУΥΡжщЭωэσ():
    value = 42111
    text = __import__('base64').b64decode('QU5hOVlCMTdxTDFKM0dlQUZmbDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _гЧБηьЧебХО():
    value = 289645
    if 90 * 57 < 0:
        _dead_4765 = 796
        555
    text = __import__('base64').b64decode('dmtVbHc0Y2RKV1p6bDJRelB3VWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ИЮтМυыЛΜΑψμяГ():
    value = 583590
    text = __import__('base64').b64decode('UjlyU0JGZnZpR2Z2b0lqeHdYYnE=').decode('utf-8')
    total = value + len(text)
    return total

def _ανОΜиΑНЛжΣЗ():
    value = 660228
    text = __import__('base64').b64decode('cnJ6a1ZTcjczWkZnMU9Vcno2blk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔЛьДнрΜц():
    value = 242445
    if False and True:
        162
    text = __import__('base64').b64decode('Y1FYb1BDNUhWUVFOY0RReVEyQnA=').decode('utf-8')
    total = value + len(text)
    if 80 * 78 < 0:
        pass
        58
        pass
    return total

def _ЦσΑζэδЖΔюэ():
    if len('') > 0:
        pass
        _dead_2053 = 170
        pass
    value = 903096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHrmWVY76LwmFgua+ge8ZQwXyEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        520
    total = value + len(text)
    return total

def _ΠΧяΗζцкВЫΓΛδ():
    value = 520448
    text = __import__('base64').b64decode('VXpkX3VFVk5ZNzVkNnRjYTRFYXk=').decode('utf-8')
    if 63 * 63 < 0:
        336
        _dead_8616 = 637
        pass
    total = value + len(text)
    return total

def _κξθΞуЪεЦ():
    value = 22964
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR28Z1A4wb88MRW5zGeSYncu3D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьяхСмЯЙδ():
    value = 38316
    text = __import__('base64').b64decode('aDJMcU5TTWNDS2hCMnRVaWxhN0s=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        274
        _dead_5698 = 893
        _dead_8119 = 866
    return total

def _ρΨοΩйЖςζВφфоцαы():
    value = 117582
    text = __import__('base64').b64decode('QVJScklFRXdMaG5zT3l2NExaQU8=').decode('utf-8')
    total = value + len(text)
    return total

def _νпгΡврΩЙχβТПΧ():
    value = 474533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgXeRnIc17k8aQWKzHOiZCcOyng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сжеиъЪмгкТμВчρΞы():
    if False and True:
        pass
        pass
        _dead_2358 = 933
    value = 256400
    text = __import__('base64').b64decode('YklWMUlwZXplRlFRRDExcGh6clA=').decode('utf-8')
    if len('') > 0:
        302
        pass
    total = value + len(text)
    return total

def _кιШΙШΡДλΡνπЦε():
    if len('') > 0:
        838
    value = 608337
    text = __import__('base64').b64decode('Um1zMkVKVjY4Q25ueEVaUnM3aUo=').decode('utf-8')
    total = value + len(text)
    return total

def _υιщщεЪыМ():
    if len('') > 0:
        _dead_1525 = 103
        _dead_5767 = 182
        _dead_8760 = 452
    value = 585939
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHfFWwYr6L8pMQCq3X/GbCwl4Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜυвъокΟжФд():
    value = 4273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXfKb0cA7I8Ebwvz8lqlPRQt6Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΥΒЛйκзрΧ():
    if len('') > 0:
        pass
        _dead_9699 = 790
    value = 706149
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mhf8dmg/6I8vajy293yGDXF7xn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘχνеаΡЬХЕпЦыΔθ():
    value = 312033
    text = __import__('base64').b64decode('d3JuWUhrcV9zN3dGdllOMHltMFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ьоΡоЛТΓсгДπ():
    value = 628535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Li7ROAdg6KAzbQuJ+EyEAh8D7Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗнКМюяιьЯοΔ():
    value = 893328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSLiOkkfxPgSKj6MwVW4IycW5Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СШГφεΑбЗΗМ():
    value = 227342
    text = __import__('base64').b64decode('TXRzb2RNZ2I2OWxRWXJWMWZ0Rmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ВχμипΗЙНыдкΕΒζщ():
    if len('') > 0:
        _dead_8197 = 297
        pass
        pass
    value = 741487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwrOUVMU6apSMiek4QKUAiIcsnQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2372 = 638
    return total

def _фτдсΔЮЩμнΝΖьιм():
    value = 796046
    text = __import__('base64').b64decode('S0dYd2hZM0FMc2NFYml0cG85TDc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        288
        119
    return total

def _КюЪФπзΗΟΤτΚΤ():
    value = 854844
    text = __import__('base64').b64decode('eTJxR180a0xUQTNIbXczQWdoRlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯψЦПθЗЦπЮδ():
    value = 838063
    if False and True:
        848
    text = __import__('base64').b64decode('QVdSc01UYWJNUDlRYnFyTFZRal8=').decode('utf-8')
    total = value + len(text)
    return total

def _еБбыΔΚЙЕιιъο():
    if 84 * 51 < 0:
        808
    value = 697139
    text = __import__('base64').b64decode('YUFMc09nbmxUTXRaZTNFcDdIUlg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟТσЭямШмоССΨЭ():
    value = 79769
    text = __import__('base64').b64decode('U0RhSWRFRFRWZWZFaE52SmVBZlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ыдфрυΖДЫμза():
    value = 125684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F332SV8p94U0NSqo0lqxOHE2zjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5742 = 4
        _dead_3207 = 80
    return total

def _зηбУДфлΕκ():
    value = 236817
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwryQGAK9P4SAger42CDLBUZyEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΤЬΚхΡэοωПρδв():
    value = 5157
    text = __import__('base64').b64decode('d0g2cWdoMmhadG83ejBlNXNoWU4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        691
    return total

def _ξυπБЭБΙъюΠ():
    if False and True:
        _dead_6298 = 698
        262
    value = 251010
    text = __import__('base64').b64decode('cW45dDdxWXl2NzJPTklRU3RDM0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡλΧНθбκΙΨЫΘпЙПе():
    value = 597434
    if len('') > 0:
        _dead_7033 = 738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjzAR2Iv1qAuLSW08QWpBz8f1mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_2575 = 402
        _dead_7947 = 217
    total = value + len(text)
    if len('') > 0:
        320
        _dead_2145 = 460
        pass
    return total

def _ΒаОвΥэЫΒςΣ():
    value = 470616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3fTR2kV77oGPDaNkFihDSMWx2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        806
    total = value + len(text)
    return total

def _ΗНΣαУЩΑфыГФънωАσ():
    value = 885399
    text = __import__('base64').b64decode('V0NFQzgyT0lPclNEZzAweDZCQ2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ККзкκчΧЗΣυχθξ():
    value = 397463
    if len('') > 0:
        356
    text = __import__('base64').b64decode('ckUwb1BkMGhLT3U0WFVmRlAzYmE=').decode('utf-8')
    total = value + len(text)
    return total

def _НФμДψБеПΒВй():
    value = 792795
    text = __import__('base64').b64decode('T2ZaN1lOR2h4M3NhdlZMeTBiQ0M=').decode('utf-8')
    if False and True:
        _dead_2110 = 677
        829
        922
    total = value + len(text)
    if len('') > 0:
        2
    return total

def _зΔΤВАγыΙЖππ():
    if 68 * 69 < 0:
        _dead_1879 = 590
        pass
    value = 152761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy7xSwMD6bAOFwb3+luVFyk71Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 44 * 19 < 0:
        398
    return total

def _αкдъВχΣΩдΞвЙйьЦА():
    value = 615392
    text = __import__('base64').b64decode('T1FHMW5rSWY1MGlJWHdOREtNSkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΥШМΤлΥХрИΩρζχЕи():
    if False and True:
        270
    value = 17038
    if len('') > 0:
        62
        788
    text = __import__('base64').b64decode('aWhzWGpwY1dJR1QyaUxjZktzSzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΞΟσφΓХЛρиασрш():
    value = 702695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyDzZgM12PEkaSzz4HOVGDAG4mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЭΒΒэЛГъьДы():
    value = 670197
    text = __import__('base64').b64decode('b09qOWVvR2lUZW5XN3NwX3dUVHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _еФΡΛТЯΑΦ():
    value = 29798
    if False and True:
        209
        363
        870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB/LXnco0JIuKQeAygTHOX0d0zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щπΘЕγиъΣЖ():
    value = 420253
    text = __import__('base64').b64decode('V0RuYjBDcWhmMXVzNEtMeWtxX0g=').decode('utf-8')
    total = value + len(text)
    return total

def _зЪЖДРХкбαΡμ():
    value = 870150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhXXQFMU16UuDTmAyQG6FiQfxWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 20 * 78 < 0:
        _dead_9455 = 737
        490
    total = value + len(text)
    return total

def _кΦоδψФюИβΗ():
    value = 867744
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjrxT24w+JEECl6x4HiTBiQn/Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        572
        40
        pass
    return total

def _αеτоЭГνЛЫнхкΜχΣЖ():
    if len('') > 0:
        _dead_1287 = 141
    value = 994038
    text = __import__('base64').b64decode('czlOTml6TG9QMGI5M2o5aFlTQUM=').decode('utf-8')
    total = value + len(text)
    return total

def _υιъЬσыΕθрιРπ():
    value = 975950
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHnOa3Ub2qIoFwqV20yyHSR87Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1180 = 675
    return total

def _ЛСГςХАью():
    value = 973462
    text = __import__('base64').b64decode('T2J3R1gwa0tZNEZGTlRWWDRHbTA=').decode('utf-8')
    total = value + len(text)
    return total

def _κэДХΟАЙΦДΓ():
    value = 864112
    if 72 * 65 < 0:
        711
    text = __import__('base64').b64decode('Z3p0bmlQTFBDV2RMREVvbDB0cUM=').decode('utf-8')
    if 56 * 73 < 0:
        587
        644
    total = value + len(text)
    if 7 * 13 < 0:
        395
    return total

def _θаЭΛσлΚнЫыκЧэΚμ():
    value = 717002
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRu8OwIg3JwZKDC041WIMhAKzGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫъУνяΒфο():
    value = 409063
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kje9OVdhrL9VEACy2U6INnQ622Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьаАдψκΛгъВвτоВрφ():
    if len('') > 0:
        _dead_2542 = 240
        pass
    value = 192042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjzWYVRgxJ1XOVn3m0+nYg4f8zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        739
        351
    total = value + len(text)
    return total

def _ЦТαКαьΒτиНвл():
    value = 159966
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgX3fkIT/L8bOy6ZnGycISQ/wTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 96 * 68 < 0:
        406
    return total

def _бЬШрΗЙηΘо():
    if len('') > 0:
        pass
        684
        pass
    value = 876568
    text = __import__('base64').b64decode('bU1fRDFJS1N1YW9KQklZNnVWbFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ахиΗрхΚбФлζРС():
    value = 34563
    text = __import__('base64').b64decode('WGZPUFVaMkhtYjNsbHAydVNQMm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ПоЪХΜЕΗπΩαо():
    if False and True:
        _dead_3735 = 601
        _dead_3033 = 241
    value = 209570
    text = __import__('base64').b64decode('RVRrbkJTOGM1M3JDcGwySTB0dzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛаΧΦΨМΨУΡΛθ():
    if False and True:
        pass
        642
        _dead_9963 = 500
    value = 164686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSTwO0YzwZ9RPl6ExVypEA8m1H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 12 < 0:
        273
        747
        309
    total = value + len(text)
    return total

def _ΣΥΒΞΤяμΙΞЧαЧ():
    value = 916037
    text = __import__('base64').b64decode('eUZ3VUxnelppZE1ROWhCSGg2WWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _СηЗСλййлΞЗЮΘА():
    value = 105757
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('REpmN2FtVW1kbVRqbTdCRHh1TnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣλЦЫНоЧеνъБπθЗИτ():
    value = 132176
    text = __import__('base64').b64decode('SlZuR3FXWTZrTjJFNEFhXzNGbDU=').decode('utf-8')
    total = value + len(text)
    return total

def _кοиΕΕΥχмцъΑΧб():
    value = 523052
    text = __import__('base64').b64decode('V3VPOUs0eEhDVEhxMUIxNkJuTnc=').decode('utf-8')
    total = value + len(text)
    return total

def _хυςУХΔЗΟ():
    value = 441494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQTCPHoL7f8KMT2nmHy6JHx2/n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οφЪΤцщΨЦУЦцιИУ():
    value = 409181
    if len('') > 0:
        _dead_1223 = 212
        _dead_5886 = 372
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQLvYmgV6IY6Ijma+HOEEzQ29D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΔцεБСшЪЫЦωξ():
    value = 439700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxjbfmMq0vgCFgq77UC0Lgcb42E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_5322 = 981
    return total

def _πζЕЦΑХвΦМιΦ():
    if len('') > 0:
        pass
        pass
        _dead_6387 = 857
    value = 648568
    text = __import__('base64').b64decode('Vmg3YnBDOHNwckI1bW1HUHRFZzI=').decode('utf-8')
    total = value + len(text)
    return total

def _щСΜъЮикжΖНακσаξ():
    value = 465011
    text = __import__('base64').b64decode('V09rM2ZPNnVtR0F0cU9YNTRtZ1I=').decode('utf-8')
    total = value + len(text)
    return total

def _НъΧΗБΛлШβЕνσΘΧж():
    value = 918341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgXuZAQh14Albwyq0WeTDRA88jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 62 * 11 < 0:
        _dead_9538 = 31
        840
        232
    return total

def _ΦНЯРэугΕ():
    value = 620718
    text = __import__('base64').b64decode('TkxYQ05FTzVocWE5M1VEWXI5b18=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        543
    return total

def _цШЛкбπςοСБфЪЫЯЕ():
    value = 273713
    if False and True:
        pass
        122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxjKdGBoxKc8NQqc0F60FTQq60M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 64 * 84 < 0:
        388
        972
    total = value + len(text)
    return total

def _ΨιтАΥζсΤюζЬДамвс():
    value = 59580
    text = __import__('base64').b64decode('S0R6cm4yZHozc0huY0htNXRIZjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒКθГηЩЖΦуδΞφЬ():
    value = 782628
    text = __import__('base64').b64decode('TWZaanFSS2tFYk1sMHBHNHpHT0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝωΖзхΚАω():
    value = 104414
    if 67 * 60 < 0:
        590
        _dead_4312 = 336
    text = __import__('base64').b64decode('TzlQc3dISVljZ3VFZGRFdklRX0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ζЯВЖййΑРбψξэ():
    value = 197491
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Di7AZXcSqp4tNBmq/U6EPAoaxm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1139 = 286
        _dead_9520 = 863
        pass
    return total

def _ΔκρнξРДεмиБ():
    value = 362028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQHeSlhs8IsECgy16gavOyYE0jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κгПцТЧЧцЦИнНяЮЭф():
    value = 837920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSXeQEQy+bwLNDqG+H+yJw8st3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΛгХыΠρЭΙьυεΟЕιй():
    value = 685144
    text = __import__('base64').b64decode('WENIRkNPQmYxb2RnSm1YME9lUGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЬЪΡιΚчψаЩмΕэАЗп():
    value = 175102
    text = __import__('base64').b64decode('bFJXNFp4ZXpPVHFVa3hSRXRmeEE=').decode('utf-8')
    if 33 * 78 < 0:
        854
        pass
    total = value + len(text)
    return total

def _φчΒшσΙΡАюωЩИфЭ():
    if len('') > 0:
        pass
        _dead_2787 = 599
        79
    value = 50057
    text = __import__('base64').b64decode('TmNMdkxtb1c2YVJ3N0Z6aFdrelA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥщΔΞΧЬυрВΤΑжι():
    value = 31994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTjwTF8v16sOPguCyVyHAw4t7Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хχσбΦжσΩχΙΞМюиΤ():
    value = 725601
    text = __import__('base64').b64decode('aXg5MDlwbzYydFZEdm5XbFJGTmg=').decode('utf-8')
    total = value + len(text)
    return total

def _йΓщεкΨНη():
    value = 506022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyzUQwEd0KA7IhWQ8gLJEnwr8zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΦЛιЗΕМЛΦ():
    if len('') > 0:
        886
    value = 970802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCTQalUB66E3ayKx732zZA57s1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 13 * 34 < 0:
        _dead_5995 = 757
        pass
        712
    return total

def _ФΝСΙмЖΝΚуπΓ():
    value = 278941
    if len('') > 0:
        _dead_5955 = 367
    text = __import__('base64').b64decode('dHRMN0hmNDJwNzdVV0pLZld3YUg=').decode('utf-8')
    total = value + len(text)
    return total

def _жеТЮЫДпΘУаΓЫД():
    if False and True:
        41
    value = 86079
    if len('') > 0:
        _dead_1406 = 141
        970
        _dead_4670 = 116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT/gV3MK7v4HPgq143PGJRY7sWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κМрσΝрвΞГюυ():
    value = 887430
    if len('') > 0:
        912
        _dead_9219 = 605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LybDOkds07oHDA6H5m6KHicQyW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪяъНΧμЕΩйΞЗТ():
    value = 876754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CijPVgMy+qorDSXxn0aTMDcItEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦглΕОτЮГОΞЛйΗε():
    value = 43129
    text = __import__('base64').b64decode('Wkk0ZnlBTWdIUUh4NWM1a1J1dzA=').decode('utf-8')
    total = value + len(text)
    return total

def _фЭдлЯεХфуΛγΜπ():
    if False and True:
        925
        _dead_5903 = 207
    value = 663296
    if len('') > 0:
        pass
        991
        136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bza9RUcJyqlRND2E7EyqG3Z67Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 91 * 89 < 0:
        729
        2
    total = value + len(text)
    return total

def _СЩιΓτβΣоЕΞоΤρ():
    value = 702866
    text = __import__('base64').b64decode('REtFVEhobU9vZWxFTzd2aUQ2YnQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4440 = 147
    return total

def _чτοΒЦψαЦΓχЧ():
    value = 122309
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECLNNnkexvgVHDisxWOIFTQm3VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аρδσбλзЪ():
    value = 285446
    text = __import__('base64').b64decode('b1Vhd2E3SHpvVlZlSVVWczRyanA=').decode('utf-8')
    if len('') > 0:
        1000
        pass
        158
    total = value + len(text)
    return total

def _шрκШйШняΖфФщω():
    value = 154528
    text = __import__('base64').b64decode('VDNDdlB3bkJlYkpHMmtSV3JMNFE=').decode('utf-8')
    total = value + len(text)
    return total

def _прЗζοсΞΨЭΘωΠЮНп():
    value = 493437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnrnOEQ3xplSGCCU3mKAHgkLzDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΡчΕмъθΨΟ():
    value = 965342
    if 61 * 23 < 0:
        pass
        _dead_7754 = 921
    text = __import__('base64').b64decode('VEVzYjhHY094QjVxSzcwTWs2ZDU=').decode('utf-8')
    total = value + len(text)
    return total

def _уьΕЦлξвκОεУ():
    if False and True:
        158
    value = 183240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjvrYkcy7q8WDhav7lmEFTEY5nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _вπТмΡъгΜ():
    if len('') > 0:
        _dead_8770 = 237
    value = 408020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRbdOwY12/tSLSim4EHELCkpw0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 57 * 99 < 0:
        _dead_5448 = 543
    return total

def _νМΜΤуЪуΧΥТαвΤΝ():
    if len('') > 0:
        563
    value = 878399
    if 64 * 19 < 0:
        pass
        pass
    text = __import__('base64').b64decode('YTMyN0hjT2hLVG13b3JjZjlJa24=').decode('utf-8')
    total = value + len(text)
    return total

def _ГγГУКδΨλ():
    value = 510315
    text = __import__('base64').b64decode('SjgyU3FnYTFRU3hrNFVkVXpEajc=').decode('utf-8')
    total = value + len(text)
    return total

def _юςШΕδфпФΑΣ():
    if 100 * 14 < 0:
        pass
        547
    value = 25063
    text = __import__('base64').b64decode('b1hTUUZ1ZW9rYmoxelhGdzZZQ1k=').decode('utf-8')
    total = value + len(text)
    return total

def _шЫνλшкρд():
    value = 837539
    text = __import__('base64').b64decode('T29QZV9SS2ZURWFYc0RPYlQ2NVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЮЦдИжаШшуэσсРцΟ():
    value = 658581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgDTZ0Yh2rFQPCKC2HzGJCY1w2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шсΨДЕυΨζ():
    value = 591048
    if False and True:
        _dead_3349 = 924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXm3e3IX3Isibw6N/VzEPnMh81w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬЫЪξаΥνШПΙφЭГдΥ():
    value = 126039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EH7qX1JryLkJGyGLkUC0OSYp5mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δαΟПтДΡещρКΕл():
    value = 281336
    if 40 * 17 < 0:
        856
        926
        _dead_3967 = 436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EivyPVAcqa0KPyqb2AOZHxM/4mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 75 * 50 < 0:
        149
        _dead_2947 = 315
    total = value + len(text)
    return total

def _αΒщλνиηХФя():
    value = 118890
    if len('') > 0:
        549
        pass
        342
    text = __import__('base64').b64decode('QzNVNzd2ZHBtZWJIb3RSOUxXSTM=').decode('utf-8')
    total = value + len(text)
    return total

def _πЪдйηшбК():
    value = 281102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxfyO1cT0oEbbguN4gWVLCof/X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΥΓЙвЦББРΩιсПъШσ():
    value = 696175
    text = __import__('base64').b64decode('eEVJT3lYVzUyUzZ3aFZIVW1IUm4=').decode('utf-8')
    total = value + len(text)
    return total

def _НРХхЦΞΡсшκыβΒυя():
    value = 252907
    if 21 * 10 < 0:
        _dead_6528 = 474
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB/IQQBhzqQRMSSz2A+fZg560j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _щГГνэЬсщн():
    if len('') > 0:
        666
        _dead_1079 = 7
        pass
    value = 93399
    if 61 * 58 < 0:
        _dead_7404 = 850
        _dead_1743 = 407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACe1bHso0fEnIhv65FCIETcq51k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫчфУВщΥΞοβДΡЧρφ():
    value = 378911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwH0SHI4rps7BQuw52HJOyQb53Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8586 = 146
    total = value + len(text)
    return total

def _эцΛншШμыХНωыУ():
    value = 366610
    text = __import__('base64').b64decode('cjN2Y1hJSzNZdlh3Z1dBYU1jdF8=').decode('utf-8')
    if len('') > 0:
        _dead_1215 = 915
        _dead_6766 = 385
    total = value + len(text)
    if False and True:
        _dead_9350 = 42
    return total

def _τдшΩΩфгΕΖЮпвεΟ():
    value = 57561
    text = __import__('base64').b64decode('TG9YVHUyYnQ0UEtFZmRkVFM1bDA=').decode('utf-8')
    total = value + len(text)
    return total

def _лδΡНЩТУΓΡк():
    value = 101423
    if False and True:
        _dead_7866 = 109
        589
        _dead_2970 = 90
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESmyPwY87qlVKzD292KTBw0FzUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5083 = 231
    total = value + len(text)
    return total

def _ЪΠΑкюЖЦХЬыыΘМУ():
    if False and True:
        174
        477
    value = 707042
    if len('') > 0:
        _dead_5256 = 371
        923
    text = __import__('base64').b64decode('TVdtN0tvdEd3UGJtTmlETFNsWkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ρρЛьСΙтΑπ():
    value = 83149
    text = __import__('base64').b64decode('bTcxQTNUc09acW5vcFR6YVBvMWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΦгхζζэосΙФЙИ():
    value = 584009
    text = __import__('base64').b64decode('aEowVGF4VEVwakk2dzR2NG1ZWDU=').decode('utf-8')
    total = value + len(text)
    return total

def _шΓαъθΓΔΔκмΦзЬыκ():
    value = 790680
    if False and True:
        pass
    text = __import__('base64').b64decode('VE50U2xIM05vN21VMzh2ckx6VFE=').decode('utf-8')
    if len('') > 0:
        _dead_7648 = 595
        301
        pass
    total = value + len(text)
    return total

def _ΖНυбΛΙэмХΗь():
    value = 135977
    text = __import__('base64').b64decode('ejhMRVBfTXJMQzZwSER6R0VUWkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣъГМЗхΕαπбНз():
    value = 193625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kw7tQ1Bv5rxVOzyz0QTBNjE50Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПГΔκФфΓΓЛюМШтъ():
    value = 531838
    text = __import__('base64').b64decode('S0doSnhqd1o2ajBwN3M5Z3pNWXo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2861 = 178
    return total

def _ЪΤΜицпΔЦЗЙхЪ():
    value = 55753
    text = __import__('base64').b64decode('bzRRQnRxblV5cUs0WUZiMEVBZlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ПιЬшΙψΑΛзКω():
    value = 625187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQj8QkA40vkAMzur+UCYIRQLyzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΜЬрКьАрΘМιЬтθюτ():
    value = 904486
    if len('') > 0:
        595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fi39d2kvq70MEjmA8V+xJi0Q3D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωБωЖΖШθоΖдΠэ():
    if False and True:
        _dead_9878 = 167
    value = 82926
    text = __import__('base64').b64decode('Z0hFdzJsWHJSa25xeURyaXkyUlg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2473 = 434
        435
    return total

def _ΑшηъХΖУΑбеОψЬУ():
    value = 972998
    text = __import__('base64').b64decode('U1NteUU3N2JYVFZJUHFSUTRCUVg=').decode('utf-8')
    if 92 * 36 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _УηЦΑаЦшυρцЮыΨХк():
    value = 454155
    text = __import__('base64').b64decode('SGdqRkpEUDQ5Wl8xcE54d09IaHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝиеΙчрζЦЯрγπΖГφр():
    if False and True:
        pass
    value = 983869
    if False and True:
        787
        274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQXmWAAx+botETCu7kaqACIltWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χθЗΗсΞΑРФТяδ():
    if 18 * 67 < 0:
        _dead_8901 = 788
        _dead_2585 = 553
        _dead_5690 = 537
    value = 805682
    if False and True:
        232
    text = __import__('base64').b64decode('b3ZRaU9uUjFobmE0QTNqcGZKVXg=').decode('utf-8')
    if False and True:
        pass
        161
    total = value + len(text)
    if 14 * 25 < 0:
        10
        49
        583
    return total

def _ΦΞАθЗΕъИиыγЪΥНГ():
    value = 38994
    text = __import__('base64').b64decode('TUpvM0tCalZNeXpXbG1IYXRFclM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΤЪХЮρшбфχπΩΩН():
    value = 981347
    if False and True:
        _dead_2624 = 525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxvVfQRqqZcgPFmE0WO4EgR4sHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЪΟωΟετΟУφгЦΘдΖ():
    if False and True:
        _dead_2986 = 566
    value = 648301
    if 46 * 33 < 0:
        _dead_2756 = 43
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDfiR3kK1roSPxXx4nCFC3Z23V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣΕΓΙУЬψΒХЦ():
    value = 506339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyPWe0ES9/AZLjmN0lCfEDY5/l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6510 = 635
        528
        _dead_1878 = 819
    total = value + len(text)
    return total

def _ъЙьΥЛсΞΩο():
    value = 609668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HznsXGstp5cQPyHymXvFZCIc0U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζкΟυмΠйООΜъЫωΕΠ():
    value = 699607
    text = __import__('base64').b64decode('QmFvTDhvQXA1aHNaZFcydTV2cTg=').decode('utf-8')
    total = value + len(text)
    return total

def _чΨχЛшΙτεЕйЩфΡШЗЬ():
    value = 277485
    text = __import__('base64').b64decode('elZ1OUs5RFhTS1kyQUtYNnpKVmI=').decode('utf-8')
    if len('') > 0:
        _dead_8392 = 488
        374
    total = value + len(text)
    if 11 * 49 < 0:
        546
        pass
        pass
    return total

def _ΦΑфЬΝΩΚΡЬиυцΛфъъ():
    if 79 * 19 < 0:
        _dead_7364 = 155
        pass
        pass
    value = 203215
    text = __import__('base64').b64decode('a3ljUXMwdXhWdTNMWEN5Rmh3N3c=').decode('utf-8')
    if False and True:
        pass
        372
        _dead_9040 = 494
    total = value + len(text)
    if 56 * 99 < 0:
        _dead_1249 = 254
        723
    return total

def _ριМЭρΦжωγΨΝ():
    if 77 * 58 < 0:
        _dead_2473 = 325
    value = 836611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxnQbXQg854Taxuyz2GfIyYozUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦγΩШЮвкΒБУГВлφ():
    value = 416903
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgrUW2ETyb8UDT2N3VeJESkk4F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μνΓΩδлШФτржзат():
    value = 380600
    text = __import__('base64').b64decode('S3lKQVRlWG01TENKc044dWQ2VXo=').decode('utf-8')
    total = value + len(text)
    return total

def _СпПυΨиЙО():
    if 25 * 11 < 0:
        pass
        839
        pass
    value = 547145
    text = __import__('base64').b64decode('b3ZPRHdxZFk5TWVzc1NLTXpyQ1k=').decode('utf-8')
    if False and True:
        _dead_4743 = 976
        pass
        pass
    total = value + len(text)
    return total

def _еъмвСасАιΗΣаэ():
    value = 32952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3nMPgks/68naASm5nCGYDIJ/Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КнρШпЗмΙХЮЗЭХ():
    value = 308352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCq8QAI68qICIBq67VfAMnEV8kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δзΙДТΤСсч():
    value = 771670
    if False and True:
        _dead_7715 = 464
        _dead_9382 = 433
        _dead_8548 = 766
    text = __import__('base64').b64decode('UDZFSUZrR3A4Y2NfWENEbExMY2s=').decode('utf-8')
    total = value + len(text)
    return total

def _φξιИЖβοΔЛО():
    value = 963079
    text = __import__('base64').b64decode('WjhDcGVpd3c3bXFlRWUxSnlwMVg=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6677 = 907
    total = value + len(text)
    if False and True:
        _dead_8946 = 679
    return total

def _ЮПОαибσΕщΠСυ():
    value = 131533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECrrZX0GzL88GAaJ+VvIEXMNwms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πφЗΘкБЗЧΛиКΘ():
    value = 241262
    text = __import__('base64').b64decode('aTlSaExnSVpDVlhZZlpCa1RhN0c=').decode('utf-8')
    total = value + len(text)
    if 18 * 62 < 0:
        350
        754
    return total

def _ΣШЬΛΟСμяΦИЪ():
    if len('') > 0:
        453
        _dead_2921 = 71
    value = 948326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiHiRWg80oAgNy2kw0SzPDImsU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        189
    total = value + len(text)
    if len('') > 0:
        _dead_9921 = 953
    return total

def _ХΙвВЪчЩΑ():
    value = 745009
    text = __import__('base64').b64decode('bXRiRUVXUDFfdTFqM293bk1BbTU=').decode('utf-8')
    total = value + len(text)
    return total

def _οСЫΜσяπтВΛ():
    if False and True:
        _dead_3407 = 203
        260
    value = 506338
    text = __import__('base64').b64decode('WGFrZFRVaHczYXE2VDIwTGZ0N3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯщзΒЙшвΩηЫЙНЪ():
    value = 732477
    if False and True:
        pass
        46
    text = __import__('base64').b64decode('dXpVVzBtSmZuSnprUmVqTUh1cm0=').decode('utf-8')
    if 45 * 51 < 0:
        _dead_1942 = 727
        _dead_6336 = 391
    total = value + len(text)
    if False and True:
        _dead_5053 = 411
        _dead_5526 = 101
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 71 * 43 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    pass
    pass