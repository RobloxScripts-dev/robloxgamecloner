#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _блζЧиКΟВΗ():
    value = 875381
    text = __import__('base64').b64decode('TGk4cGxGQXd4OEhJZ2RqRFQ2ZVg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3335 = 63
        _dead_1024 = 258
    return total

def _БАЬрτяνγ():
    if False and True:
        _dead_9886 = 592
    value = 453512
    if 26 * 65 < 0:
        pass
        _dead_5574 = 917
        911
    text = __import__('base64').b64decode('SGtfckVjcVpoMmRZaUxwRmhLZGw=').decode('utf-8')
    total = value + len(text)
    return total

def _χΧοЗεμЯъ():
    value = 577385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgWwbQc73YUSDAPznwGpNy4H5XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΑυоΒНозΘлЛΣеЭς():
    value = 138527
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('dkVHQlNBNTFsNnpNMVlQSE5kYjk=').decode('utf-8')
    if False and True:
        376
    total = value + len(text)
    return total

def _νРΠбнτобЗОΙ():
    if 43 * 15 < 0:
        pass
    value = 79368
    text = __import__('base64').b64decode('eVVJdU91YTM3MmZpbHpFMGhVdmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _вьддыЩΗΣРΨ():
    value = 396880
    text = __import__('base64').b64decode('T3NNNHpoRWlzUG5vM2xhY1NjdDk=').decode('utf-8')
    total = value + len(text)
    return total

def _θПРΣЛЛлУДуЩΙΥяξΓ():
    value = 891063
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASe3SVQe3f0tMxmR60bIOxQ4530='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧфωΙΣΙашЛιэπЧфЯ():
    value = 168911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHuwS31hq/0BHxik+n+lNR0J1H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗτЕЧπμΗЕΛψбР():
    value = 938587
    text = __import__('base64').b64decode('YkU1bWVEdHFjbWtYRnpoX0l1bV8=').decode('utf-8')
    total = value + len(text)
    return total

def _θЫΔοφΡХУθςΘЗςэЕ():
    value = 933780
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyjVTEgzrIMqHju64128ZDAa5kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 36 * 66 < 0:
        _dead_7445 = 863
        pass
        _dead_3046 = 183
    total = value + len(text)
    return total

def _МδχΚΕкσхИ():
    if len('') > 0:
        pass
    value = 486738
    text = __import__('base64').b64decode('TTV6ZVgzUVVaUmlNUm9hdmJKMHk=').decode('utf-8')
    if len('') > 0:
        276
        938
    total = value + len(text)
    return total

def _смΒаВГГЕЖшΟ():
    value = 553257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex3oOXMQ6Z0kPVua7nXBNi0o9nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΩθΡαыκж():
    value = 236974
    if 12 * 88 < 0:
        951
        285
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCfzY0QD1bwSKy20xECCHh8B9Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΛЮΗУашξИчПЮΟ():
    value = 994394
    text = __import__('base64').b64decode('bnI1RXc0a2dpbUhEOW5Xbk9FMFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩьξΓρТтЙллаыСΖ():
    value = 933001
    text = __import__('base64').b64decode('TmpCdzl5R2d0RWdZYjVJYTZ6WGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ФнщАΗцВкнζмΞПςΟ():
    value = 477857
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzXwOWlp6v8XAxj7/2THAyYG4jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эбгОΥρГЮщΟΗбΟΨΕ():
    value = 972658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwjlOW4J2fEiKAuImlu2PAt8wmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        834
        pass
    return total

def _γбЧыМЦПβΥаΖТυМНε():
    value = 808538
    text = __import__('base64').b64decode('UXJRcHptRlhtOUdITUliVlh3ZWM=').decode('utf-8')
    total = value + len(text)
    if 33 * 85 < 0:
        241
        pass
    return total

def _ПΤτДАΨΣΕлχΒζς():
    value = 371998
    text = __import__('base64').b64decode('eHhQTG1zWEpjSm1BdHdaem5rYzg=').decode('utf-8')
    total = value + len(text)
    return total

def _юАСАыμАМлГхАΤвНй():
    value = 887282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICzuZG5g8LIyNSSl70GUGhoZylY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γЙΕОГΗΝхХцГ():
    if len('') > 0:
        754
        _dead_5092 = 370
        pass
    value = 639622
    text = __import__('base64').b64decode('a0NXMDNfbG5yZ0RRejR6Znp0ZlU=').decode('utf-8')
    total = value + len(text)
    return total

def _κΓхχΝъγЯκРлλн():
    value = 602805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj7iOUky34RTNyKq+2ChO3R/9z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭБлΡΡωОΔЫσгΧЙЯΘτ():
    value = 207524
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ei30bX4u+7BXDDaQxFyaASAs/D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ишРрХςчУΡПΟХΜФ():
    value = 972365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgXSOUQQroYGbxu32HS4Piwg4UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЮАкκьΦιЮΧΜЧ():
    value = 452641
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRjSRHUG/YkALQSL/wWSDhIa3DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 22 * 92 < 0:
        116
        _dead_9830 = 690
        _dead_3974 = 275
    total = value + len(text)
    if len('') > 0:
        _dead_8159 = 608
        674
        _dead_8900 = 780
    return total

def _ХйюφтеωДюπΚх():
    value = 563373
    text = __import__('base64').b64decode('RjNTZ2ZmOFdZMEtyWDk5RjJYdHY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7904 = 932
        _dead_7155 = 565
    return total

def _ΞВΗЦκΔδΛОэрМθэπ():
    value = 783546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiP0b0sSy4oHNiaO2nDBBxx6yX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 14 < 0:
        _dead_4736 = 710
        _dead_9000 = 242
        _dead_2279 = 904
    total = value + len(text)
    if len('') > 0:
        _dead_8499 = 576
    return total

def _АλνИξеΖМЫБСχю():
    if len('') > 0:
        257
        _dead_8622 = 951
    value = 9570
    text = __import__('base64').b64decode('WUJVcURaMzZYWlZ0YjdpdFliQTU=').decode('utf-8')
    if 12 * 20 < 0:
        _dead_5899 = 851
        645
    total = value + len(text)
    return total

def _ЭφττЪψъΩ():
    if len('') > 0:
        pass
    value = 6736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgDbb1UOrbg8bxagwlO1YwQe7Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОλνξΑΤоωтЪδ():
    if 30 * 75 < 0:
        _dead_8589 = 417
        pass
    value = 824575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CATOeVAIyaEPMVq0zQSVFzZ46H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 72 * 28 < 0:
        pass
    return total

def _νΣеЦεОЯхтАуЩ():
    value = 866743
    if len('') > 0:
        193
        pass
    text = __import__('base64').b64decode('b1pPXzFydGZDT0p3Y0l3MmY5VnM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        686
    return total

def _тΟΙфдФЭЩΡΣБДуЯХκ():
    if 18 * 41 < 0:
        _dead_7914 = 441
        389
        pass
    value = 574564
    text = __import__('base64').b64decode('YzBRblI1M2N0aXdzSjdDR2pFX3M=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5744 = 695
        891
        266
    return total

def _ЙΠψΝкξΜТзРΖ():
    value = 806341
    text = __import__('base64').b64decode('T2w1eGlFa3N2Rk5aODNDNDlKT2o=').decode('utf-8')
    total = value + len(text)
    return total

def _γμΜλθИюг():
    value = 249920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyvRRlYh3YM2DF6sy1GhIzx+23c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        904
        _dead_2636 = 325
        pass
    total = value + len(text)
    return total

def _δщΩцΜъρΘЙЭмцшаΦΙ():
    if 5 * 50 < 0:
        _dead_8107 = 738
    value = 236697
    text = __import__('base64').b64decode('ZEZjVFpVckJQTUtOdVRuRWhjTWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪСэжψАαл():
    value = 621150
    if len('') > 0:
        575
    text = __import__('base64').b64decode('dEdBdm95dEVMcEp5VnppY1ppRlk=').decode('utf-8')
    if False and True:
        38
        _dead_6857 = 648
        pass
    total = value + len(text)
    if False and True:
        _dead_2974 = 78
        _dead_7489 = 518
        _dead_3815 = 206
    return total

def _пΨЗСπНсτМЬ():
    value = 223840
    text = __import__('base64').b64decode('Q3AwWW9lVm55OVFvQmtNNWhQckQ=').decode('utf-8')
    total = value + len(text)
    return total

def _гΓρΠШхσРгБγΖΔс():
    if 3 * 11 < 0:
        pass
        _dead_1162 = 434
    value = 569250
    text = __import__('base64').b64decode('UzQ3bFdtZlFrM1Iwbzg0Wk9XZ3E=').decode('utf-8')
    if False and True:
        pass
        230
    total = value + len(text)
    return total

def _ъыτοыоΧΠξнЙΩКγ():
    if len('') > 0:
        975
        _dead_9420 = 25
    value = 465707
    text = __import__('base64').b64decode('WmpCM01UcTY2YzFGWTBvSGQwVG4=').decode('utf-8')
    if False and True:
        _dead_7935 = 935
        332
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЯэШΡςсΡмЮЗУ():
    if 17 * 86 < 0:
        pass
        pass
        pass
    value = 315142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyTTUXkuwbw5Px/w+W6WGBV20Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 22 < 0:
        _dead_2273 = 748
        _dead_3149 = 726
    total = value + len(text)
    return total

def _КιΣцγμΕΓп():
    value = 957558
    text = __import__('base64').b64decode('TldKUnJLZTIwYzgycjlmR3d1Z2Y=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        305
        _dead_4523 = 516
        pass
    return total

def _чΜααΟΔΖφНлΡζЗ():
    if len('') > 0:
        pass
    value = 666772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgrbSAcPp4U6aTmI7GyRP3wE6nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _лрυΝςТβзΧ():
    value = 630636
    text = __import__('base64').b64decode('cjdtYm1ob0ZvYnpxWWNBZHhlRkE=').decode('utf-8')
    total = value + len(text)
    if 41 * 98 < 0:
        680
    return total

def _ЯсλЖςхУВМиЬ():
    if 76 * 62 < 0:
        491
        453
    value = 429612
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzzQSWY7wa9baziF0ATGMwMCyEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИСχцьΠΥеу():
    value = 271762
    if len('') > 0:
        _dead_4419 = 270
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET/pb1gozf0XDCSV3FCKYBQr8Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6046 = 671
        pass
    total = value + len(text)
    return total

def _ЧμΞυρнΝКОμоΤГтωΧ():
    value = 261381
    if False and True:
        _dead_2722 = 525
        _dead_3121 = 586
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxzxYHk9rpg2CR6x7keVZw84t2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 72 * 6 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _эъМΛцеЫчςβΟΑКθΤτ():
    value = 561799
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxvpVkkJ8IUtDgqHymKmAQwF7jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣчЯТшρΧгя():
    value = 164163
    text = __import__('base64').b64decode('Q0RCeFlMR3REelJZN1o2YlRXUDI=').decode('utf-8')
    if False and True:
        562
        672
        _dead_5604 = 696
    total = value + len(text)
    if False and True:
        252
        pass
        _dead_3742 = 774
    return total

def _СфЭЫΜπЖКιПЮЪ():
    if False and True:
        pass
    value = 418194
    if len('') > 0:
        709
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAvWWEU7rKYCPgCp5gegYwQjyVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θирψδΒΖιΤ():
    value = 741330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBbjbwAd7v4yEziQ+gCqFjQo0kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙЮХмΟЧуаοκФΖб():
    value = 847752
    text = __import__('base64').b64decode('aTBMVG4xdmEydV9KQkxpdmtseDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΕЩхβξФГЫоΕγКη():
    value = 372554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRvLO3gU1Y0sKiGgmFiXGhMp4EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓьЗθбРεЕоУς():
    if len('') > 0:
        432
        pass
    value = 321915
    text = __import__('base64').b64decode('WGgwZWEyMExwRDFmeFlIMnJYS2Q=').decode('utf-8')
    if False and True:
        _dead_2198 = 754
        225
    total = value + len(text)
    if False and True:
        pass
        267
        498
    return total

def _аΣζΥуΑЬДЕЪκπΩΔч():
    if False and True:
        943
    value = 363577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnfBd1Ao8K43DwGIx1epZiwMxUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 94 * 79 < 0:
        388
        pass
        134
    return total

def _χονЯбΚΨуιЩψι():
    value = 618893
    if 6 * 40 < 0:
        981
    text = __import__('base64').b64decode('YXBxdkFSUE9TbUlaQVhYNl9hMlc=').decode('utf-8')
    total = value + len(text)
    return total

def _эνЧΟсАκШЧψзОδф():
    value = 498709
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCPNTAgNq/1XGyanzHfDIgc9vFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩνйюΠΚβМλ():
    value = 829487
    if False and True:
        pass
    text = __import__('base64').b64decode('UHhEeExReFJ2Z1hIdzg5Q3I5bFk=').decode('utf-8')
    if len('') > 0:
        _dead_8464 = 885
    total = value + len(text)
    return total

def _ΚβыхλеМΕДтιЕзρВы():
    value = 502452
    text = __import__('base64').b64decode('a1ZnT013Q2E2QTYzYnRVQURTbnY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6830 = 327
        145
        _dead_5672 = 522
    return total

def _вЕρАШоОиσΤНΖмЫщ():
    value = 568662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiDpbGM4r/AgCSym3U/DPQYtwGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТпДΩОрЮБХКнп():
    value = 246814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBqzO34y67EwECubyWe0E3IZzj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘКωАвθлΤФЫΥαψун():
    if False and True:
        pass
        907
        765
    value = 1390
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSHqYHprrK5WKDqRmWmGLQYe1Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9728 = 584
        661
    total = value + len(text)
    if len('') > 0:
        pass
        284
    return total

def _θэЧψхΑГβФКβΕ():
    value = 331799
    if 54 * 38 < 0:
        _dead_2762 = 927
        pass
    text = __import__('base64').b64decode('c0diUkFvT2pRZmxRZ2NxZDhQZUw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2735 = 368
    return total

def _ΞТчΘηэΖИк():
    value = 653032
    if 23 * 68 < 0:
        _dead_9203 = 513
        _dead_6217 = 565
    text = __import__('base64').b64decode('T1JqMVBZQUVFMG8waWhna01Id3c=').decode('utf-8')
    total = value + len(text)
    return total

def _αΗξцςНΤΥΜЦыτ():
    value = 456239
    if False and True:
        _dead_1241 = 83
        _dead_9523 = 604
        216
    text = __import__('base64').b64decode('aVdCX2dkVzJBSW5ob29qbE5qS0I=').decode('utf-8')
    total = value + len(text)
    if 66 * 84 < 0:
        pass
    return total

def _ΩΔгаΣΧιΡγОΦЬюΣ():
    value = 611717
    text = __import__('base64').b64decode('UE5JeXpaNFZEbGc4WHFVdWhVaVA=').decode('utf-8')
    total = value + len(text)
    return total

def _шуСсΑАΖεΕ():
    value = 204025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQHvTXBqxoFaYyCmzwaECyk1yXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦжρбτΜэΝскйфΗБψξ():
    value = 290837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH23P3I7zaAmHwD0m17HLgEfslQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓЯξΛΤηзвφ():
    value = 110436
    text = __import__('base64').b64decode('TG8yZ09jYTdCNTljaWxpRDYwODY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧОЦЩΔоЯνκитюΦи():
    value = 820476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgHrfHoux4ICEyu3w0/HbQE372Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШкΒъοхЗмΕΤР():
    if 61 * 11 < 0:
        pass
    value = 8304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhvURWQ0yf8WPAWBwgayGH13/ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _йхгыХцЛΑ():
    value = 147243
    text = __import__('base64').b64decode('eU1mUGNRcHVPMVptZjBaT0R1UTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪйЩοТнΦЕΚЮΣЩπпЮκ():
    value = 230970
    text = __import__('base64').b64decode('Y3d0b19LOVAxaDNzeEdrNE5nQnk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ШшζΥэщЮνфьо():
    value = 297572
    text = __import__('base64').b64decode('V0xRaUxBbDRGUWNwQm5NRk5FWVk=').decode('utf-8')
    total = value + len(text)
    return total

def _φωΠНΡΓαΝχΟыКΖЦа():
    value = 920160
    text = __import__('base64').b64decode('TU55QXd5YThmeF9FbkFqdTcwdmo=').decode('utf-8')
    total = value + len(text)
    return total

def _асΩЬΛЕβДυЧλ():
    value = 593834
    text = __import__('base64').b64decode('clJPdGs0Rm5Eam84ZVVIa3haRU4=').decode('utf-8')
    total = value + len(text)
    return total

def _МЖλτАжуюРΟΗлΨι():
    if len('') > 0:
        _dead_4529 = 827
        _dead_7100 = 610
    value = 160071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS39PgBr0aYZaAzw41uSNnUtwF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еЯΜРщΗΙщСЮгЕΡσХ():
    if False and True:
        _dead_7099 = 141
    value = 662203
    text = __import__('base64').b64decode('bmlZcTVqU0NsbWRFV28wVHJ3UkE=').decode('utf-8')
    total = value + len(text)
    return total

def _φяΝμъЬяДΕΗΜΖ():
    value = 791871
    text = __import__('base64').b64decode('dmQ2YjFvMmNWRnExVjNoS1AxbFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ρЩβΘΨМΤφЬЩ():
    if False and True:
        _dead_3783 = 890
    value = 947685
    text = __import__('base64').b64decode('TFVwSXp2c0FKSVZRTEw1b3ZqTmU=').decode('utf-8')
    if 41 * 7 < 0:
        _dead_6299 = 117
    total = value + len(text)
    if 47 * 14 < 0:
        _dead_8186 = 901
    return total

def _рιбПБНτЬЧЪЮц():
    value = 901800
    if len('') > 0:
        pass
        pass
        926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHf0fFQN+/otLAKl/nWVOCoZ1Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГМаεцГуА():
    value = 502074
    text = __import__('base64').b64decode('QXEwaElXZmdPaV9UbGMwQTY3dW4=').decode('utf-8')
    total = value + len(text)
    return total

def _гтКвσпΨΨθвЛпΑЫ():
    if 17 * 98 < 0:
        _dead_2717 = 760
    value = 680456
    text = __import__('base64').b64decode('aHFBYlNCYXdhZlpob2wxWTVudjE=').decode('utf-8')
    if False and True:
        743
        689
        pass
    total = value + len(text)
    return total

def _эЪъδКЕбΤυοОφклР():
    if False and True:
        _dead_7486 = 134
        _dead_6218 = 44
        _dead_7100 = 409
    value = 353789
    text = __import__('base64').b64decode('bkwxQWZsZFFyNTJVR29CNDV1bXg=').decode('utf-8')
    total = value + len(text)
    return total

def _эτхκчΞΧδΜΠψт():
    if len('') > 0:
        827
        743
    value = 64357
    text = __import__('base64').b64decode('ZEFmS0dhYWZYWlF2UTR0aXZwUFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΟГαяΞжэΙлцьΝ():
    value = 191040
    text = __import__('base64').b64decode('WHhZNW5YMUM4ODRpdlJVNlB5SWY=').decode('utf-8')
    total = value + len(text)
    return total

def _зсйКЛБΧрςΗσχнψ():
    if 63 * 98 < 0:
        109
    value = 762324
    if len('') > 0:
        _dead_7972 = 99
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DySyV10/7JITDT2C8kSZFSAp/mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тУЫЙΖЕΝвжзηэΓιН():
    value = 174331
    text = __import__('base64').b64decode('RVdXZ0txUk5ZdUhDQ2xxTUZ1aXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ρτНКМюжηΣσЬ():
    value = 800343
    text = __import__('base64').b64decode('RjNFVUNBVmJJTWt6djVBR3BGNmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ДбойΦИЫыЧш():
    value = 820060
    if len('') > 0:
        pass
        pass
        589
    text = __import__('base64').b64decode('Y2ljMUZMZ3hXVEJrajBWVXlkYWg=').decode('utf-8')
    if len('') > 0:
        _dead_3887 = 703
        _dead_6905 = 744
    total = value + len(text)
    return total

def _νηлΚУяνΣ():
    value = 828418
    text = __import__('base64').b64decode('TGlCeVVRUXlCT3MyeHM2RmVOSW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘИΛАаπΙР():
    value = 672734
    text = __import__('base64').b64decode('YjUwMXBaZzRJaThFcG1VbFhWQ1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΤκгΑΘюлхθξиОφП():
    if len('') > 0:
        pass
    value = 397164
    text = __import__('base64').b64decode('bDVCT2lGWl9ZQVFva2pmRzF6dTY=').decode('utf-8')
    if False and True:
        pass
        258
    total = value + len(text)
    if len('') > 0:
        _dead_1192 = 352
        _dead_2616 = 135
    return total

def _ΑΤдЛбλυφθ():
    if len('') > 0:
        pass
        349
        pass
    value = 280070
    text = __import__('base64').b64decode('S0NlSG9UM0RQeVdwbTZXcWNkN2o=').decode('utf-8')
    if 75 * 71 < 0:
        pass
        _dead_2080 = 484
        901
    total = value + len(text)
    return total

def _ПтБЯХДΑыπ():
    if 57 * 54 < 0:
        151
    value = 762997
    if 60 * 34 < 0:
        _dead_4048 = 260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC79T1cu84dWDwGEwVvAH3Ae8kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οиэЗθμπБθЧΟωпνТ():
    value = 490450
    text = __import__('base64').b64decode('ZERkdVZKTF9tWnNBazI5VHlGZ1Q=').decode('utf-8')
    if 12 * 43 < 0:
        _dead_7999 = 80
        63
        11
    total = value + len(text)
    return total

def _ЙГμΠЧыπСЗэ():
    value = 247181
    text = __import__('base64').b64decode('UjRqcnBKeHJTd2psRzVRcmcxRlE=').decode('utf-8')
    total = value + len(text)
    return total

def _юЧσιΚлЬεвΙΛΖк():
    value = 228030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3jQWQcu9qEsBSiJ8WfEbB0t1H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΡΚρыЫΒΙЩ():
    value = 4081
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgzAPEIQ2pAZM12pxk6pBD8o/EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫРЗфбηЬЛч():
    value = 388814
    if len('') > 0:
        _dead_7075 = 113
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAzXV2Y9yPggESCowXTIMB0F7Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ОВΑπкηнωЭΠ():
    value = 131444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxrxVHkwqqEwDx22xHGyLhcL9jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЙлτρШцΓщсδэр():
    value = 441796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAHnfWUqzosVGxu10mGRAQp30GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙУλщДнЫΜМОзφку():
    value = 316868
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQ29WkgK+61SahX6wGWhJC4m0Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        148
        _dead_3839 = 788
    total = value + len(text)
    if 67 * 36 < 0:
        pass
    return total

def _ΒηЗОφМγвκΒшΝ():
    value = 325651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAXIW1Ax76oBNTCEwlm/JQwZyHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШхκΜΙжΜυйл():
    value = 782044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyG2RVgpro0GDxuZ5GO+BCkss30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЖΞΛднГШτΖзГлвςφ():
    value = 584481
    text = __import__('base64').b64decode('dVhOckRhV1YwT2NGN2pVb0s0QUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ИъРΣΩЧλък():
    if False and True:
        353
        pass
        _dead_6029 = 51
    value = 684200
    text = __import__('base64').b64decode('cnBZYlNQV2tFdUhjTmd4U0pWM2g=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        777
    return total

def _πякЗτΗшΜΝъγИл():
    value = 443577
    text = __import__('base64').b64decode('ZlFvR0dmTGFEQmpncE9teU9oMHI=').decode('utf-8')
    total = value + len(text)
    return total

def _θхлУмЖηΦ():
    value = 625826
    text = __import__('base64').b64decode('TEdHd3I5Z1FtamMxQ1R5UmtMZHA=').decode('utf-8')
    total = value + len(text)
    return total

def _уΔОεщпΨЫНοЩКЖΙцЦ():
    value = 897652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyLjfUce3Z41KgGvzAa8GSs5wV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АиТЪδΙбΠЙΗ():
    value = 714226
    text = __import__('base64').b64decode('ZWhOZ25rSEV6RHhWb0loQmo3akM=').decode('utf-8')
    if len('') > 0:
        _dead_1390 = 546
        pass
    total = value + len(text)
    if 72 * 62 < 0:
        pass
        356
        867
    return total

def _ΔЫαхжЗПΕφΘЮ():
    value = 303013
    text = __import__('base64').b64decode('V1VEN3dqT0lRZEZYWHp4SlJCY3E=').decode('utf-8')
    total = value + len(text)
    return total

def _РΓЖюмΨβСлΚΨτЛъ():
    if 92 * 65 < 0:
        pass
        _dead_1681 = 729
    value = 442901
    text = __import__('base64').b64decode('c2hpQnlvR2FmWFE4Y0hoTnBTTVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ταАμдвнш():
    value = 649993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dyn1VHNu0Y07Pyyu92CIFjB6wTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        28
    return total

def _ΠюмПΕИЧΨЦЕ():
    value = 18474
    text = __import__('base64').b64decode('enJLY2I5MzJXZ0xpSl9RTXJsdVM=').decode('utf-8')
    total = value + len(text)
    return total

def _σΜΛОдΟЮРС():
    value = 594359
    if False and True:
        _dead_1691 = 922
    text = __import__('base64').b64decode('SlJiTWRvZ3g0Z2VBOHRENzZkTGM=').decode('utf-8')
    if 6 * 82 < 0:
        _dead_3816 = 748
        602
        835
    total = value + len(text)
    return total

def _ΔуЖЮζЯΣγпω():
    if len('') > 0:
        890
        pass
    value = 739006
    text = __import__('base64').b64decode('aXNJbGw4MUpCaHFxdHZIM0NuOGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΔКБχΒΨвετθФШ():
    value = 769266
    text = __import__('base64').b64decode('amNrRzBNV3lnRlpocFBhOFJqX2Y=').decode('utf-8')
    if False and True:
        109
    total = value + len(text)
    return total

def _ЕиХОЮφПυκ():
    if 21 * 40 < 0:
        _dead_7740 = 938
        _dead_7422 = 790
        _dead_8406 = 196
    value = 926043
    if len('') > 0:
        427
        215
    text = __import__('base64').b64decode('b3ZqVGNyNDQyNUdwRXdPR3Q5YVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΑΡΔΥьΛйКχι():
    value = 939170
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADu9OV0v/KMkPwu3wHSkPDwkzjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цЮΖχжЕгшУΝтθуεъ():
    value = 719579
    text = __import__('base64').b64decode('dDI1OFV3dVJPV3JreW5ET3pyTE0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _еОσΗΔΩэΖй():
    value = 223403
    text = __import__('base64').b64decode('b3VYNzB1bVFzZWJweEdTZkpRUVA=').decode('utf-8')
    total = value + len(text)
    if 22 * 77 < 0:
        _dead_6065 = 595
        pass
        450
    return total

def _УЩтμγΔθΣАΜ():
    value = 940728
    if 9 * 56 < 0:
        690
    text = __import__('base64').b64decode('akFHMWpneEVMRWlyMWhBblFKdUw=').decode('utf-8')
    if False and True:
        _dead_6192 = 824
    total = value + len(text)
    return total

def _ΝНТшнηχΚб():
    value = 863447
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax/CSGkx25hQBSOk+lWHNRIk72k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρюЙЬΞМхссВЕзΡΡΡН():
    value = 664921
    if len('') > 0:
        _dead_8306 = 458
    text = __import__('base64').b64decode('ZVl5cE4xcVFibmU0enRtNFlPc2w=').decode('utf-8')
    if len('') > 0:
        _dead_7323 = 103
        _dead_4683 = 325
    total = value + len(text)
    if 44 * 95 < 0:
        pass
        410
        pass
    return total

def _ЩСЪζЛПμΚИенФзь():
    value = 126936
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgrOSgAa5oUJNl6ZkVjBGzQBsm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЭФλψгωнжбЮγКΧθ():
    value = 931446
    text = __import__('base64').b64decode('UjB0MVBEbjh6d2dYOXU0ZWtRYjc=').decode('utf-8')
    total = value + len(text)
    return total

def _φΔεлшτШдзγφΥОψк():
    value = 296252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyT9RXksxP4rFV/763q4DgJ8/Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        583
        pass
    total = value + len(text)
    return total

def _ΦςчεγэΞБτΘшρΒφ():
    if len('') > 0:
        pass
    value = 403495
    if False and True:
        _dead_5751 = 81
        pass
    text = __import__('base64').b64decode('WGV1QUIwTG1UREU0SlI4c0h5Y2c=').decode('utf-8')
    if len('') > 0:
        632
    total = value + len(text)
    if len('') > 0:
        217
        367
        255
    return total

def _ПρъΔОЭТБΘбаΨибСΡ():
    value = 883756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pxu0YnMU9oMtPRuqz0KxFjIl1jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9555 = 48
    total = value + len(text)
    return total

def _ΝтΞШνеяρвθηЕΡь():
    value = 489544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDrJSms8zJ8CHTC7/FWZOS4ts0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        965
    total = value + len(text)
    return total

def _ЖчГυΓГιьоΛНς():
    value = 374501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABXFP0UO37wHEAK0nEfCGxcczjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХэδХфΚΜΣΤЗδωнЫξп():
    if False and True:
        _dead_7505 = 165
        pass
        805
    value = 429879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En3CfmQXrfs6Fxmmmm+7PTAZ7Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 21 * 6 < 0:
        pass
        pass
        651
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _τюηЬЫфрΙλирβ():
    value = 463671
    if len('') > 0:
        328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwD1Onoq56lQOVyN5A+mYHQkwHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъжРНωъщηИ():
    value = 396521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnbVekMv2KkkYl2gyXG2LAcstkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фмсλЫсПЗЛζЬ():
    value = 733364
    text = __import__('base64').b64decode('YnN3ZDR6a3c1Mlo0QjhlRWRQSno=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЦΩβΨСΨьЗνГωОо():
    value = 778893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDbsVmAv/IIsOwSA0AWoPnU6wUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _οуΤыщаТΗНгЫΒЭу():
    if False and True:
        83
        _dead_3004 = 942
    value = 204088
    if 8 * 72 < 0:
        pass
        _dead_8519 = 511
    text = __import__('base64').b64decode('Z3A4cl82Y1U0alpUcW1VSlZ5OHM=').decode('utf-8')
    total = value + len(text)
    return total

def _υΤЯβБАдψбРаρ():
    value = 422144
    if len('') > 0:
        pass
        517
        469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHuxTGk33I0tKxiP2WW9Px8c6UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тщΡМЭыСξфΣΧЪШЗο():
    value = 723925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz+9UWA/qqFWCQv38VKTFid8yj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нчбцфнАфΟΖйкωι():
    value = 696153
    text = __import__('base64').b64decode('V2ZUT0pPYnFwQks0eks1aTMxMXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ГЗςЗδΠсЬВ():
    value = 513463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQDLfEUKqY4BHAaXy3eCMC8JzmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΞΦНοΕΖИΩУγφа():
    value = 106425
    text = __import__('base64').b64decode('Q0thbW9rd2hrbWFla1hLRVd1ZGo=').decode('utf-8')
    total = value + len(text)
    return total

def _рνΩΘθΨΥбΛФУЯω():
    value = 34499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABjAf3Ap/fkKKzaV4FjBHQAksj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ςЕφЯяЫΠСΣыЛВВАδН():
    value = 568979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAbRSWcI+LA3bV6T4VylDA14sDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        347
    total = value + len(text)
    return total

def _ΕΖаνгςлΗνгεвЛΘΔй():
    value = 209003
    text = __import__('base64').b64decode('TmJ1VVZmOUZpQlAxeURmSEs1bnA=').decode('utf-8')
    if False and True:
        999
    total = value + len(text)
    return total

def _ΙАЯЗпΟЮсΓЙуСφОа():
    value = 852796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyPyamJh6LtRAj+k6XOzYnECvDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хоξΞсΑτЮΦЕΞСκЙξ():
    if False and True:
        _dead_4773 = 629
        _dead_5568 = 457
    value = 997683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBnDbEIs0LwgbwCs+0WqNXEM7WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _етКκцбРшОшгХ():
    value = 972193
    text = __import__('base64').b64decode('RWdtM1hnTWF0UEc3Y2ppdEpxV3U=').decode('utf-8')
    total = value + len(text)
    return total

def _РΡЮΥрνΛОлΦпΕΕωПζ():
    value = 85879
    text = __import__('base64').b64decode('RmJxZl9NRk1FbGd0WXJIcDJ5bGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ωюЪтζдВяΩКэФΚьεΙ():
    value = 16387
    text = __import__('base64').b64decode('cDJTNkpWdmNZV1hRaHhSX2VNNGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ιЗЕδюΚИцΣХζзπЗЖ():
    if 68 * 43 < 0:
        _dead_4852 = 564
        _dead_4505 = 969
    value = 632672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fwb+ZgJr9o9RPiyr41WYAT0K8n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕыфРωΡψПЬИЛΜ():
    value = 422736
    if False and True:
        _dead_4859 = 932
    text = __import__('base64').b64decode('WHRHME9vTnJvSTVoSGRvSEZvazM=').decode('utf-8')
    total = value + len(text)
    return total

def _ГйиΤъπΠуХШГГЖμбΙ():
    value = 696773
    if len('') > 0:
        _dead_9463 = 740
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiPJWQNsp5IbDCGI61eSIiE/7W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 87 * 38 < 0:
        pass
    return total

def _ΠΕΑЖоιЩЭΘя():
    if False and True:
        pass
    value = 212599
    text = __import__('base64').b64decode('elNteldXenNXeWxQcHZBb0k1eEo=').decode('utf-8')
    total = value + len(text)
    return total

def _зБαΞδνΥμΟбЩ():
    value = 360783
    if False and True:
        921
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxXUfFxsz7IPFR6uynuRZiE5/UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УηтЩΧЛийΛ():
    if 40 * 64 < 0:
        _dead_8110 = 782
        _dead_2043 = 195
    value = 180686
    if len('') > 0:
        492
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj7LVF8r/IoxY1yGnkLHMnUC9Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гШФОαХнЯУ():
    if 97 * 90 < 0:
        _dead_5508 = 917
        pass
        pass
    value = 776002
    text = __import__('base64').b64decode('TTJBYUl6djlLSHk2SVNCZkhvaGc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1504 = 384
    return total

def _ГъΡωмΞЛьСсБ():
    value = 971769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQiwOXss25wQbF6M6XeBJzIFvV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫВпЕНкярх():
    value = 444360
    text = __import__('base64').b64decode('QVZ3MGRPdkt2SmNsUko3VmN1Z3E=').decode('utf-8')
    total = value + len(text)
    return total

def _чЩσΛΑηдчжшΣΜмΘж():
    if 72 * 29 < 0:
        _dead_6700 = 353
    value = 10418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAz0aHw//4pUNgiR+2m1Mg8Hw2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        112
    total = value + len(text)
    return total

def _ЫяпБСΒепгСХΨδ():
    value = 777042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnbNbV872foQOwWBzmmBISkDz0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 45 * 42 < 0:
        pass
    total = value + len(text)
    return total

def _υВΣΙΙЦьЩωщΧЬй():
    value = 814851
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCvtZAA67vsHExiT5XW6Lhw18nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жЬыЧеλшЧЖиЕзλшπλ():
    value = 112403
    text = __import__('base64').b64decode('Yld1S2x5aTdneEFfNXNBSDREYlI=').decode('utf-8')
    total = value + len(text)
    return total

def _νцЗσРъΞΤυωф():
    value = 522967
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiCxXGkD/IVSPjmQ4FSfBRcr5W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        186
    total = value + len(text)
    return total

def _дырΜτщкРъыδ():
    value = 327112
    text = __import__('base64').b64decode('em43d3VtaFhzWXhXMUpLX2ZPVGo=').decode('utf-8')
    total = value + len(text)
    if 29 * 74 < 0:
        294
        _dead_8231 = 574
    return total

def _ΘΨΔΑСχЧΟЕя():
    if False and True:
        pass
        _dead_1950 = 251
    value = 998235
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg3TUUIv2b9QDQj15Vi6H3wg9Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РЫπБИΜВГуΥЭщ():
    value = 458590
    text = __import__('base64').b64decode('Qm1WTU1CdW9KTkVtX3VSZHM2eUc=').decode('utf-8')
    total = value + len(text)
    return total

def _МρτаЛτМяИ():
    value = 954411
    text = __import__('base64').b64decode('WHlpZlhwN09KSkIxX0JacEtPblM=').decode('utf-8')
    total = value + len(text)
    return total

def _юΥфЫтμρЭк():
    value = 624666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjvbZ38L/a0zP1um+GSHGgMB4WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νμΩςГОИδФ():
    value = 939321
    if len('') > 0:
        595
        365
    text = __import__('base64').b64decode('RDZaSjZGZ3FNbGNCeGtEaTdGSHc=').decode('utf-8')
    if 78 * 39 < 0:
        663
        _dead_7360 = 401
        740
    total = value + len(text)
    return total

def _оΘΔωйоЮΛтΗΨοЖρΠ():
    value = 441475
    text = __import__('base64').b64decode('TUtJSGRuaUZwNzl4WFY1bVlQTlU=').decode('utf-8')
    total = value + len(text)
    return total

def _θУясΒυΒΔψжΙ():
    value = 567423
    if len('') > 0:
        _dead_8944 = 112
    text = __import__('base64').b64decode('QWhLZ1k1MXl0b2pjV2U4b2tTWHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ФеηΟΖεΚχТыΧοοВΙ():
    value = 27665
    text = __import__('base64').b64decode('ak5Qa3B3NUlLY3Z5WFJSS1lMSnk=').decode('utf-8')
    total = value + len(text)
    return total

def _νЦΝЬДеЖршΤтАΟЮ():
    value = 36354
    text = __import__('base64').b64decode('dW9NZTBOb2hjbGJ4MnNMelVnaTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΞΥοΧчцΞ():
    value = 484085
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXvRQFgy05EyFQyw6UDAISwN/kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΖЩЭρЖмгΨσΧ():
    value = 868954
    text = __import__('base64').b64decode('YmJUWmJ4MnB2VVhmMTdyNGVmaDg=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 42 * 46 < 0:
        402
        pass
    return total

def _РЮΩфιТЭнιштх():
    if 98 * 76 < 0:
        pass
    value = 341588
    text = __import__('base64').b64decode('UjhvV2cyRzE2aTExV2lvc1RKRW8=').decode('utf-8')
    if len('') > 0:
        47
        pass
        pass
    total = value + len(text)
    return total

def _ОчΗЗюρΣюЬα():
    if len('') > 0:
        435
    value = 308661
    text = __import__('base64').b64decode('ajJtSUZuQXlneW1EY2xCNTNxYm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗνΕΑжωωωЗβФτЬι():
    if 72 * 91 < 0:
        991
    value = 327120
    if 95 * 89 < 0:
        _dead_8484 = 121
        202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXfLfloYqPsoHRf0/kO5JC8izk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щяшщЫНРφшΝχ():
    value = 260017
    text = __import__('base64').b64decode('UEhOelUwR09Zd2NfRG5EeHBTdFE=').decode('utf-8')
    total = value + len(text)
    return total

def _чεΧωФБэЙди():
    value = 885513
    text = __import__('base64').b64decode('ekxEVkhuc0xtX25wNHdTTGFrbnc=').decode('utf-8')
    if False and True:
        _dead_4707 = 561
    total = value + len(text)
    return total

def _αЫтНΡЕЛΙНΣАъρЗι():
    value = 793656
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyjmR3Yx86ovFlmG2Ae4OTwI7kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_6848 = 891
    return total

def _ЛМςХфΡмΙкЬККΑЙмЕ():
    value = 394266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3zBRGhtyLw3MyOv+mSJLRAf3Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟЬцБΘзΡРЕ():
    value = 405108
    if len('') > 0:
        _dead_6293 = 489
        pass
        _dead_9364 = 392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDzMfmttppIEHAy27kaEACZ79lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юшАψαγχθи():
    value = 190741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAn+SH0LwZwVID+13FqeDj826G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒсПςХЪутΦтΩЪΚч():
    if len('') > 0:
        329
        _dead_2366 = 817
    value = 243428
    if False and True:
        pass
        _dead_7550 = 1000
        pass
    text = __import__('base64').b64decode('RDJtRzBkNklKNVZ2NTVDaFU3U2E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3181 = 435
        _dead_6811 = 84
        497
    return total

def _ΑΒнρΖΨΘЩΜюΤ():
    value = 345446
    text = __import__('base64').b64decode('aHR4VWdSWmpTZGpsRFl4SHlHTUo=').decode('utf-8')
    if False and True:
        903
        pass
        _dead_9765 = 425
    total = value + len(text)
    return total

def _οЫяΔΒςЕΒΩΨГ():
    value = 358175
    text = __import__('base64').b64decode('SHlBbVRyMzcxejhya2d0WFBWOVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        pass
        _dead_6064 = 964
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()