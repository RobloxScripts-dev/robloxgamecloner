#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _КΤгЯΧωκχρΤδЙйП():
    if 19 * 13 < 0:
        _dead_5660 = 531
        pass
    value = 724582
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg7BbwUj9aIOFS3w4Ea5YQcG3Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чαтπΤΔмпию():
    value = 86158
    text = __import__('base64').b64decode('c016b3hjXzYwVlJVeU9helFiZXI=').decode('utf-8')
    total = value + len(text)
    return total

def _щтγГΖоΛлΞγΔгцяνσ():
    value = 712599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxzxRWgXrqYmKgSwyV25IRYl0EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЗпиΟмцЪЯπбζν():
    value = 245357
    text = __import__('base64').b64decode('STB1V1pPNWtzTDEyS1luN2lhT2o=').decode('utf-8')
    if len('') > 0:
        123
    total = value + len(text)
    return total

def _БΘμαΤГβΡΗ():
    value = 608752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwzzOFwtwYYbHgKBwFijGzQ+80s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТвяощιαокЪРλ():
    value = 492687
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBDTX3Zpqoo5FjqV63WTAHwHz0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΖωЯзνΛу():
    value = 656160
    text = __import__('base64').b64decode('UXdMVGREQUlWczBPanlSdmtaZlo=').decode('utf-8')
    total = value + len(text)
    if 19 * 90 < 0:
        _dead_4805 = 187
        pass
    return total

def _ΚΨΘдτЪФЖшхΣ():
    if len('') > 0:
        _dead_2531 = 979
        _dead_3196 = 817
        550
    value = 966047
    text = __import__('base64').b64decode('RFgwNktQSGo2TWZiZ2NHOEtNZzg=').decode('utf-8')
    if 68 * 27 < 0:
        166
        pass
    total = value + len(text)
    return total

def _усΔошΨдл():
    value = 686785
    if 84 * 76 < 0:
        pass
        _dead_4773 = 563
    text = __import__('base64').b64decode('dkFHQjNJNHBIUWNkdFp3NjJaaXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ДЖРσΗыяСХΖГКτ():
    value = 963764
    text = __import__('base64').b64decode('YzF4UHNpcU5UUGllOFB6Tmd1UEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟαγЕыФпЦьςΑΕλψЮα():
    value = 176293
    text = __import__('base64').b64decode('d2VKbDhwRGFQZHI1SU1VZ1Y2Mko=').decode('utf-8')
    total = value + len(text)
    return total

def _МыΝЧОξΛшщИΜχΘΚ():
    value = 435611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACeySkUY34taHA2B/3WCHi096EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΤΕЦтуαжуΤАбЧω():
    value = 560990
    if len('') > 0:
        _dead_9763 = 946
        _dead_1939 = 536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCzwSlpp/awNbgGhw32lPjQ612g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΨшачΥιз():
    if 37 * 23 < 0:
        95
        535
        473
    value = 992175
    if 73 * 63 < 0:
        _dead_7332 = 8
        pass
        pass
    text = __import__('base64').b64decode('aEExSkNzQ0xjT1lSNE9TWUpXYmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЦνΧΖСяь():
    if False and True:
        _dead_8277 = 47
        464
    value = 559599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fj/DPmIbrbkQNTaT5QCTJwl9zn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УБлΑдΑγСуξБυАЖУА():
    value = 977876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQnSQksTrP0FPRqu5kygNSk7tEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΨБπΤυΑъιωОΩдν():
    value = 288002
    text = __import__('base64').b64decode('aVpReWZEWjQ0eDFDZmpJcUlKX0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _спХЮкΗвδ():
    value = 899846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRu3d0sKqJ4kPQ6s0UCbHXUEtXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЧэΞлξΩОθΜ():
    if len('') > 0:
        415
        _dead_7803 = 528
        491
    value = 462874
    text = __import__('base64').b64decode('ekJ2SDg1Z1BITnBacUYyUGdpWnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛъшκλВΩξИΣοΟ():
    value = 97801
    text = __import__('base64').b64decode('cHpra2M3SXBzMDFLckN0c3E1MWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЪδТЙΗφт():
    value = 88315
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh/wO34916YVKFaQm0yaZAwj/Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΑХΤρШψопβуοПπ():
    value = 686306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX3lbVI05pxbDSCO9wTEHHEI814='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΑяяΔλΟаηЮΘωииχД():
    if False and True:
        _dead_5837 = 993
        pass
        _dead_7092 = 387
    value = 549496
    if 70 * 30 < 0:
        215
        _dead_3055 = 828
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTXAfEYf56osCSeu70eXYzJ83Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 98 < 0:
        pass
        _dead_7913 = 563
        145
    return total

def _лθЮπΟΦχιнХζбΣгЭг():
    value = 910284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bj3pZQAurKc2Fjiy8F6KEiMlzWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΨюКΖЦЫЭπбΞмΘЮЩε():
    value = 658443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgHWSmRo7LgQKRj3zE+4O3E5xlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪжтλΨζфΔфВ():
    value = 818795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhvoP3g664AoOD+X7UWUZBc1wUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υДΜЖΤЭНдλ():
    value = 336764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADfHf0Adza8wKgqZ3VSUOQEE61g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χюфшзВжЩхЦε():
    if False and True:
        pass
        pass
    value = 270122
    text = __import__('base64').b64decode('eTZpUnh4am9lMHhEa29qTWx6OXU=').decode('utf-8')
    if 98 * 38 < 0:
        304
        _dead_6330 = 191
    total = value + len(text)
    return total

def _ъψΙχΖЖКΞξ():
    value = 50736
    text = __import__('base64').b64decode('cWMwclBvSjRKam82dzV3cV9JdFM=').decode('utf-8')
    total = value + len(text)
    return total

def _уθΤφЛнйοЖ():
    value = 245500
    text = __import__('base64').b64decode('V3p5azUyWExmekxoOUo2MmdQOVA=').decode('utf-8')
    total = value + len(text)
    if 94 * 18 < 0:
        _dead_3177 = 407
        534
        _dead_6369 = 205
    return total

def _КΛςэмλτνдΒβзХн():
    value = 759535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bifva1w82rkxFT663X+IBykYt1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эТЪлΒШяΓр():
    value = 168465
    text = __import__('base64').b64decode('ZEZtRE1haENJcDNaS3g5aDdGRGE=').decode('utf-8')
    total = value + len(text)
    return total

def _вΣтФсΨΙοζσ():
    if len('') > 0:
        _dead_1533 = 729
    value = 383168
    text = __import__('base64').b64decode('R1RkNUtxaHp2VDJSR0huaGZQdzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓЖэμΓегТЪΝη():
    value = 552489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3/eeXQpwZcNAD+PzGKBGzd+9Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖЕЦыЧφюУТДΘЖмв():
    value = 944338
    if 65 * 1 < 0:
        108
        _dead_8647 = 24
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICrwQVNrqZ8JLDm77WOzZgB6/mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρζξипψτЪεЛδвρыΡХ():
    value = 693326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyzrYnYR8YdVNT/04mW8J3Q9vDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙщДхКδΓьε():
    value = 767523
    text = __import__('base64').b64decode('WWE4TVlrTkR3TWVGY3YxQktZcjk=').decode('utf-8')
    total = value + len(text)
    return total

def _хепЮХЬфψ():
    value = 823271
    text = __import__('base64').b64decode('SzA2c1Z6YThVVWlPTThjQWpiYUI=').decode('utf-8')
    total = value + len(text)
    return total

def _κяΑАωчθΓеыГΥгПхо():
    value = 316424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IS3CPVNoy40bFzmi8keaIx0Y12s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЩЙцЖρολНφ():
    value = 33968
    text = __import__('base64').b64decode('UVBZTVdTaDVpZGZORXJ3RllidnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧфДνЬДюю():
    value = 274409
    text = __import__('base64').b64decode('dEVTRGt6QjB2ZmRqenJVS0REQkM=').decode('utf-8')
    total = value + len(text)
    return total

def _κΦАпВΛΕШиΦЮэθцЗ():
    value = 618899
    text = __import__('base64').b64decode('WEltbnJyb1ViQXZ2djZLSUNmMm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ИэвιπЕТψφΤυΔΣ():
    value = 507425
    if False and True:
        pass
        _dead_6104 = 116
    text = __import__('base64').b64decode('VWZuV0s2NnBPTWNDZnBWZEZnakY=').decode('utf-8')
    total = value + len(text)
    return total

def _гεΞΥифмСБΨψΥΑεΞ():
    value = 26704
    if len('') > 0:
        pass
        865
        pass
    text = __import__('base64').b64decode('amFQNjBoSXdaSWp5SG4zQXBjVm8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        645
        pass
        462
    return total

def _ψхсθΚукΛοзСΓРЯЪΛ():
    if False and True:
        739
        150
        914
    value = 860186
    if 12 * 72 < 0:
        156
        887
        751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHjjPmIo6Iw6HFyIznCRIXMg0kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЧРГυΛσюΤΑ():
    value = 476165
    text = __import__('base64').b64decode('YUFESmtRcG80M0FueUJJTlU0UTc=').decode('utf-8')
    if len('') > 0:
        _dead_1171 = 504
    total = value + len(text)
    if 35 * 51 < 0:
        _dead_2242 = 556
        82
        pass
    return total

def _ЯесьξйИΜуΕФΨЖМδ():
    value = 243253
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax3henMo9ZwwFBWQxweFJwcA3WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХшйДπАεοюА():
    value = 662014
    text = __import__('base64').b64decode('R3BNYzNMMlFIbVlmNmZrSnFqa1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓγаргθПγΖШ():
    value = 463197
    text = __import__('base64').b64decode('UW9URVB5eFFGTGE2cm9Sckg2Z08=').decode('utf-8')
    total = value + len(text)
    return total

def _УΟЛЭσΔΧΟΠчΒъ():
    value = 903403
    text = __import__('base64').b64decode('cm1nNGIya2VsZFpMd19CSXZyQmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ДτЧΔβηΞарπкκΨ():
    value = 736232
    text = __import__('base64').b64decode('czdzc01zdFVNZWxGNXloelZVOHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨВλТъМгΘЧуТн():
    value = 956297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyLLN0MPrJEuFVaVmHO8YQME414='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7307 = 70
        _dead_4330 = 567
        _dead_6793 = 645
    total = value + len(text)
    if 100 * 88 < 0:
        _dead_6914 = 824
        239
        407
    return total

def _НкΛзκИςЭШθп():
    value = 787701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwfiOAc80rshO1el8QO4Bw056lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        945
    total = value + len(text)
    return total

def _ςΦΜэЛлРЩШΛ():
    value = 636578
    text = __import__('base64').b64decode('aXdPOGlKS2JkRHVoMnRCOWdUUnU=').decode('utf-8')
    total = value + len(text)
    return total

def _цгυьОКΦαч():
    value = 380947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX6yOmMo1p4VFTCKn2yEZiMYyms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δИθφΜХЯπΒШК():
    if len('') > 0:
        _dead_2478 = 510
        pass
        _dead_4633 = 206
    value = 990129
    text = __import__('base64').b64decode('eGxLdmo5UmRORW9pZEM0WUlDZm0=').decode('utf-8')
    total = value + len(text)
    return total

def _яСΤАξςЬдΘмЦ():
    value = 711645
    if 7 * 99 < 0:
        960
        102
        _dead_8331 = 597
    text = __import__('base64').b64decode('bnJwYW94dDhDdXJYbFBRZUs2dzE=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЗЙΝΝсχъГθГ():
    value = 512094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESnbYwYu6L4gGx+z+lixADN5yWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓτκΚλΔЙЫθΑζГΕМ():
    value = 872286
    if False and True:
        _dead_1622 = 356
        _dead_2813 = 500
        _dead_9811 = 265
    text = __import__('base64').b64decode('VmNzQmVXZDhoZTB3NzZxSGw1U1A=').decode('utf-8')
    total = value + len(text)
    return total

def _МζнζΛοΜъοВнИьΥТ():
    value = 185805
    text = __import__('base64').b64decode('VUNRRGtMWlhyeDRabFlwV0pTbUw=').decode('utf-8')
    total = value + len(text)
    return total

def _дΑГЕДσΨЖ():
    if len('') > 0:
        pass
    value = 187152
    text = __import__('base64').b64decode('eFlxY3VFb2NuRGxlak5paG9Sc2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _кμБрΡΜяΝуЗо():
    value = 76282
    text = __import__('base64').b64decode('TnpZdzNPbjhOY196bzBKaGtrWmc=').decode('utf-8')
    if False and True:
        _dead_7402 = 188
        pass
        pass
    total = value + len(text)
    return total

def _шνΘνΤЖЬБρχу():
    if False and True:
        pass
        _dead_7694 = 21
    value = 988488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHnJSEAX7pshOV6Zz2GzHQkh6UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γДчЫМβнΥζы():
    value = 364501
    text = __import__('base64').b64decode('QVZ0OFYxX24wWThwR1M2WDJ1MjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΣпιБЩτζаΞιωПδБμ():
    value = 226241
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXzSO1c9/6QxKx2L6w+xAD0k7Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 13 * 70 < 0:
        _dead_1296 = 35
        pass
    return total

def _шэлΚьγфяηυРЬфψ():
    value = 280073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSXgWGsP2roMDzuG4nGnGQw75mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψатЖξСтΠщ():
    value = 547624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDfJNldq5PxWDDXymEOHMiF411s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9287 = 369
    return total

def _чΨΙЮΜΞΧΠьΟПΟ():
    value = 514179
    text = __import__('base64').b64decode('WXZiNHNxMk9HdHBCMGNWNUdnQWM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        181
        _dead_9662 = 879
        pass
    return total

def _ГХΦзЬчΕβθафПε():
    value = 873666
    if False and True:
        _dead_6088 = 925
        pass
    text = __import__('base64').b64decode('bnZNbGlhRFFCdl9HMDU0d0ZkbDQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 11 * 35 < 0:
        336
        305
        pass
    return total

def _ΟсьπΟуушЛмлжρЬΜЧ():
    if False and True:
        45
        726
        600
    value = 862298
    text = __import__('base64').b64decode('czdhZWtvUUNYOGV1NnlEYzB5dDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΕμσςЛЬΥρКтЛ():
    value = 275783
    text = __import__('base64').b64decode('UklPaGlrUjhDbXRMbjBST1h1alc=').decode('utf-8')
    total = value + len(text)
    return total

def _βжхδУШΚζкЧж():
    if False and True:
        636
    value = 492730
    text = __import__('base64').b64decode('dXh1N0R2c1lsS1BpcFZieGFJYms=').decode('utf-8')
    if 98 * 49 < 0:
        pass
    total = value + len(text)
    return total

def _нρЙИйζъЮШ():
    value = 625861
    text = __import__('base64').b64decode('ZzNIT09ySE50TV80RFYzaW1KNjI=').decode('utf-8')
    total = value + len(text)
    return total

def _АдΞфАБВВ():
    value = 29609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgfJenQ6zK8qNzmA8XWGIBAe1Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΕАΙΑΓΟОъ():
    value = 440353
    if len('') > 0:
        777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnrvZWAqxpghbTqb/3SJEhIG1X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 65 < 0:
        pass
    total = value + len(text)
    return total

def _ξΡсаыбНбмПФΚΧΑТ():
    value = 401782
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQv0b2Vt+IUnEzyg4wKEEyAry2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩГжωβЭοΚΩΞ():
    if False and True:
        pass
    value = 937237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDfiWWIL5pwAaFynxnfBAR8ezkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡлΨΔйУуАРЯШС():
    value = 618527
    text = __import__('base64').b64decode('RkVyUWtiX3c0TXZKNk9aZnN0bFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦδЖιРдбρΡЛΩηЗЦ():
    if False and True:
        _dead_5266 = 259
        90
    value = 684116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwPAQ1wI/bssDQSL5G/HbBUE1nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        406
        705
    total = value + len(text)
    return total

def _ВВωΓыщМЛЗФηпΝЕΞτ():
    if len('') > 0:
        pass
        _dead_8858 = 507
    value = 998116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiH3d1cdzqdWEgWPnH7BHQw6/UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓθШБъΑΔжξж():
    if len('') > 0:
        750
        pass
        pass
    value = 152249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BD/0SAAG9qcZNxyi20XHOzMC5mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оИсΛЪъΩс():
    if False and True:
        pass
        pass
    value = 410061
    text = __import__('base64').b64decode('SWg0Z1hhNzN0R2FxWmxKSTZCUno=').decode('utf-8')
    if len('') > 0:
        342
    total = value + len(text)
    return total

def _чкκДΥιΗрюэ():
    if 42 * 48 < 0:
        pass
    value = 714130
    if 41 * 64 < 0:
        211
        pass
        pass
    text = __import__('base64').b64decode('RGNyWXBEWERmY09xaDFqdTF2TGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕйνΛηθΩБуюΨ():
    value = 211719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTziPEgtqIMAKg6I0Gy9IAsWy1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚЫгэачαплαЙтхς():
    value = 904507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB3nV1Y95rwiDiSs7AeqNX0Ww1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИБΧКψΞαθЕ():
    if False and True:
        864
        pass
    value = 598969
    text = __import__('base64').b64decode('R1NUa2NtMktuSVV0SXlKRE50YU0=').decode('utf-8')
    if False and True:
        pass
        _dead_6016 = 364
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_8652 = 170
    return total

def _лζйЙσЬПΕЬ():
    value = 81393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH+2ZAg/rakBFQCA6XigYxIe7E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΨηтЖЙςщΩЗΒ():
    value = 836710
    if 47 * 68 < 0:
        _dead_7397 = 654
        924
    text = __import__('base64').b64decode('ckh2bXpZZmR4VF9vRFRyT29rb3E=').decode('utf-8')
    total = value + len(text)
    if 72 * 51 < 0:
        pass
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 28 * 66 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    _dead_2081 = 27