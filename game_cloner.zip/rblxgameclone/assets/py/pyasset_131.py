#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ЛΓΤаρОκГΝζςΘξю():
    value = 234092
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzvVPGdqwZgSEDuKx2WWBAMp8kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РюεяΗЛЮаЕΞ():
    value = 437879
    text = __import__('base64').b64decode('VUtDRmZodjVvT0R5dVVJRTVIdGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟζмжУЮЩъρьΣ():
    value = 318993
    if 71 * 54 < 0:
        25
        pass
    text = __import__('base64').b64decode('WDFNVk1YbTJkTWxkRFhmUXBCZE8=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _нМνНлΞИΗу():
    value = 411387
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dwb8WGEy/YorDVj06VCcZhYL614='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъЯъΨЩυыΙюАδΗδт():
    value = 993215
    text = __import__('base64').b64decode('YXVYek0xZkhWUENSaXFlcDBVcUs=').decode('utf-8')
    total = value + len(text)
    if 80 * 66 < 0:
        _dead_2624 = 688
        99
    return total

def _ьφмФгπФΧА():
    value = 816552
    if len('') > 0:
        _dead_5065 = 297
        pass
        pass
    text = __import__('base64').b64decode('cVFWNnpsNEZudGV1a3laZmk4aDE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        8
        292
    return total

def _ыхΓУχыфлюσΙкжя():
    value = 703551
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiLbQEEw/6MAMDeXmnmVGwp45zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жФΞсδΛДабΩ():
    value = 876175
    text = __import__('base64').b64decode('dU9zc0pkTXF0dVJMdWZONVRMd2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΣвшРкЭΕЖχ():
    if False and True:
        _dead_7072 = 435
    value = 888643
    text = __import__('base64').b64decode('R184SjBtUXNnOGlvUjZ5Y3AwZ1k=').decode('utf-8')
    total = value + len(text)
    return total

def _чΞЩКгΘΩΥμхПОσА():
    value = 285651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHvxTWEP/ZIiaiis0n2cPg4N0kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хЙιΕΝЦЧт():
    if False and True:
        _dead_8823 = 269
    value = 762722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR3wTwkw1vlRKgi6xm6oOSgA51o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        678
    total = value + len(text)
    return total

def _ψЯΟΟнШлЦЖσΤΠΝΕмΗ():
    value = 789162
    text = __import__('base64').b64decode('VmU3TGp4QmYxdmFKM2sxUHRSRF8=').decode('utf-8')
    total = value + len(text)
    return total

def _θруΘъПΟмгΝЛΩ():
    value = 530514
    text = __import__('base64').b64decode('ZDFVWDBpODd6TExWVFNMaEVlbTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙθηχφωΣЛтζΧЖХΤξ():
    value = 482181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jij3RAga6qAaCFq16XSSG3wF7zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уьъγξΖДрУγ():
    value = 343757
    if False and True:
        _dead_4500 = 372
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwftUUQI7/0uDDCC3HCRHxQmynQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_6878 = 410
        611
    return total

def _βΓκΦΙλЗщфωЧшС():
    value = 3836
    text = __import__('base64').b64decode('Yzh5STVYZFdlOGI0WUN6dXpSblo=').decode('utf-8')
    if False and True:
        _dead_3997 = 938
    total = value + len(text)
    return total

def _ОΡНΖιтхвβЛβоΕД():
    if False and True:
        _dead_6783 = 540
    value = 577922
    if False and True:
        _dead_5115 = 633
        _dead_4304 = 797
    text = __import__('base64').b64decode('UzJqMlRPR29waGpuWG5BajNVdEY=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        713
        205
        _dead_7318 = 522
    return total

def _юхδНЛψΚкЖВд():
    value = 248380
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQjLZF4r2LwRDhz67lzJB3AJ/GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΚКжйтзψЕσПР():
    value = 171391
    text = __import__('base64').b64decode('ZVR2cG50NnRfdllOeEpYakFOaGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯшιερяΛчяοапЕ():
    value = 798239
    text = __import__('base64').b64decode('S2hwTWxkT2VtM3hDTjYzaGNFMFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯωЯФζψΖγщ():
    value = 441767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj3WbUNv76AlPhW26VCnbC0c/Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гкκыΔЧачаЮΖО():
    if len('') > 0:
        pass
    value = 629604
    text = __import__('base64').b64decode('TmprQzJ2dmJMUkgzZ21SUDVuTVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜфчЭъθЦКдлЫСЫЕкω():
    value = 647296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzuweggO1IdbOVum+XiXEwQdzD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яλЫОβоκχй():
    value = 1570
    if len('') > 0:
        456
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAXXWnI+r4MoAiC28FC8OQ8d/UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΝэеаΒμωэсΝВЯт():
    value = 286731
    text = __import__('base64').b64decode('cG9UaHFUTmFfT1ZXSUY1enhXTFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙНЬφΝЮΑЛΑжХ():
    value = 538140
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAHJW3cs2vgIGBu350eWACJ+tno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εИПщΡПΙСβΑγτ():
    value = 967307
    if 61 * 27 < 0:
        65
        721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAHyPWE36PwuLAiIyn3FGzwY/Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΣΚΨяνφΨφчоςчεхГ():
    if 80 * 65 < 0:
        601
        pass
    value = 684781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB+zZAYNzbAHGQ268EO1AiM/6Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γхцΡЖοοΛуΛζ():
    value = 700914
    text = __import__('base64').b64decode('eXFOUF9lamJJX3FWdDI5b21ub1A=').decode('utf-8')
    if False and True:
        pass
        112
    total = value + len(text)
    if False and True:
        156
    return total

def _ояЬсΠΞглΑжψμΓьνА():
    value = 740208
    text = __import__('base64').b64decode('blNod0hfVm93VWRnemNsQWpKbzQ=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_7716 = 262
    total = value + len(text)
    return total

def _ьσмΤДΘкВπψзΘΤЗΒж():
    value = 856108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AA3DYWE2waItHRWS3Gy2JnQ+wHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УШοаΜтξΘοаΤΧσ():
    value = 889575
    text = __import__('base64').b64decode('SUtSUTRzcGdrazYyeEdvTEJXb1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪθщΗаЫЗСς():
    value = 915791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhDVfksB7IkpKDiW70yJYh0M6kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΗηиΥΕΓгДКЛРо():
    if False and True:
        635
        pass
        _dead_5864 = 844
    value = 836298
    if 98 * 29 < 0:
        926
        pass
    text = __import__('base64').b64decode('YlJsNU9ucGpCcXI4ZF8wNloyb3k=').decode('utf-8')
    if False and True:
        _dead_2615 = 282
        pass
    total = value + len(text)
    return total

def _КΓнΘРжΓαβзАζ():
    value = 993782
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXrePnU4zLomMCmU8UKkYnEY9Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ωПОчКПфΘυΛЗб():
    value = 494396
    text = __import__('base64').b64decode('aEJncWVCZ2c4N0ZVdVB0ZzRPVHM=').decode('utf-8')
    if False and True:
        _dead_5406 = 788
        pass
    total = value + len(text)
    if 5 * 17 < 0:
        807
    return total

def _щΥДΠвТρЪξзККΞ():
    value = 866452
    text = __import__('base64').b64decode('dVJyNDkxSmpwM0YxQ200VEhtMVU=').decode('utf-8')
    if 87 * 85 < 0:
        849
        _dead_9377 = 688
        _dead_5583 = 843
    total = value + len(text)
    return total

def _юиθвнΨйъЗΤζΔоТ():
    value = 413706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih3QNl4W048UPhny2HfAGRU46kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΟτζкйκχδγτψ():
    value = 981138
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARjmXQRtyqIUGCiI7wK5bAd5yn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бηуЫяФθΨΥщлφΚ():
    value = 875913
    text = __import__('base64').b64decode('QUJLalBtMzB2cU9pOE9lckFNQWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ДЪΨЗьΩВсΦΔεфРЖап():
    value = 987164
    text = __import__('base64').b64decode('QWJVZmRnMXRsYV9RUG5QcjZXc18=').decode('utf-8')
    if False and True:
        167
    total = value + len(text)
    return total

def _κЫРгУρлμгκФКΙι():
    if 62 * 75 < 0:
        pass
        _dead_6225 = 341
    value = 522223
    if 98 * 24 < 0:
        _dead_1815 = 135
        _dead_8921 = 35
    text = __import__('base64').b64decode('aTBsZkk4b3NvaUtSWTFpRTU2N2c=').decode('utf-8')
    total = value + len(text)
    return total

def _рЪгыГΝΝПЗхлΝ():
    value = 61249
    text = __import__('base64').b64decode('Ujdqek9oRGpBU2lHMWFpWk1EZkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ХвЬДфКЗЫΡηьω():
    value = 599676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhjxZ1we6/BQPyOGmlK9BSE26Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шмΓΔΥчГΧ():
    value = 605577
    text = __import__('base64').b64decode('ZEVDanlwdnRveVhmZ0xjMmxxaGY=').decode('utf-8')
    total = value + len(text)
    return total

def _πωЧβυκτя():
    value = 616690
    text = __import__('base64').b64decode('T2hDT2MwTm5ZY3Y5U0JwXzUyd1I=').decode('utf-8')
    total = value + len(text)
    return total

def _σιΩγξрфПΤЧБЕ():
    if len('') > 0:
        _dead_8612 = 800
        _dead_1648 = 577
        pass
    value = 234684
    text = __import__('base64').b64decode('dF9RNjY4cWxuMzBKMkZET3E1Sko=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9809 = 726
        pass
    return total

def _ВλδΖΧэΩΛукΝ():
    value = 773236
    if 97 * 71 < 0:
        _dead_8059 = 72
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCXbT2YW1JgRHweU0X+cLCgAz1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 99 < 0:
        pass
        39
    total = value + len(text)
    if 98 * 56 < 0:
        pass
        pass
    return total

def _ЗЪтМПδπΒ():
    value = 244790
    text = __import__('base64').b64decode('Snl5Z1RneXlCeHZ3OEhGQVNQUUM=').decode('utf-8')
    total = value + len(text)
    return total

def _НΤпΛκусхЛ():
    value = 777428
    if len('') > 0:
        _dead_8541 = 92
        _dead_5997 = 752
    text = __import__('base64').b64decode('dklRZnZMakxoTTIwdFhMcjlJZXM=').decode('utf-8')
    total = value + len(text)
    if 32 * 22 < 0:
        pass
        845
    return total

def _ЛλΖаτАйΓ():
    if False and True:
        _dead_2549 = 529
    value = 221543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxnlWl472bkNChuUxQOTOCY83k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нОЕΖЕмΠγьΑκ():
    value = 578540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAr+eG5u0P0UGzub4UKXM3F+23Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4218 = 463
        pass
    total = value + len(text)
    return total

def _яЧъΠФкχыоΔмдΧ():
    value = 96543
    if 19 * 36 < 0:
        _dead_2809 = 670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzbXZFQf9o43IhmbkVuBbDUuyEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гЭυηЪΒфωн():
    value = 489524
    text = __import__('base64').b64decode('TFZLME5xR0lVcHh1WWNJZGM4azQ=').decode('utf-8')
    if False and True:
        _dead_2071 = 581
        633
        253
    total = value + len(text)
    return total

def _яХξфТсьυвηПд():
    if len('') > 0:
        30
    value = 610478
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('ZzVVNzlLdmN2bVc1N2VHMXNjaDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭαεФВшуβЪкαряΕΚτ():
    value = 576099
    text = __import__('base64').b64decode('Z1RwWkZYNEZBUjE4Rm5PSENyaXk=').decode('utf-8')
    total = value + len(text)
    return total

def _уЦπэВΧЙНц():
    value = 810809
    text = __import__('base64').b64decode('Q1ZYYkx4UGxQRnUxRDVHQUlMU0E=').decode('utf-8')
    total = value + len(text)
    return total

def _чМХжπтбηζΤΑχС():
    value = 863060
    text = __import__('base64').b64decode('RFdVNkc1RVpDU3RFVUlSbnFGR3c=').decode('utf-8')
    total = value + len(text)
    return total

def _орЖζεβγοф():
    value = 495353
    text = __import__('base64').b64decode('RDJ0RGZtYmFtWmNSMmlZbEw3eW0=').decode('utf-8')
    total = value + len(text)
    return total

def _γΗεΤβεАшΙЪ():
    value = 610834
    text = __import__('base64').b64decode('QXdLWU9zWXRwQlBZOTI5dE14ZWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ьωАγΘθашШν():
    value = 477007
    text = __import__('base64').b64decode('d05TTGtMcVVDTDRsOUNoTDd0Ml8=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΛнφΦПЙМю():
    value = 878585
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXvzVHoowf9aGAGP8FqHHn184HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υЖмрНσМΣΡαРГΔМ():
    if 63 * 82 < 0:
        470
    value = 603085
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQHAPlY15pwNYgGlwVKXFT1/xno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 53 * 54 < 0:
        pass
        pass
        86
    return total

def _ллКζΞбΙбй():
    value = 760065
    text = __import__('base64').b64decode('Vl90TDR0eFlNUDV0V1BOOFZqQ1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _αкщξφОЭυΖТΘМΜлЯЮ():
    value = 618285
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQe9OVQt86ogbAOUnHKUPQN2z1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 3 * 24 < 0:
        109
        217
    return total

def _αИΔШгТЦэжψЗЕЦе():
    if False and True:
        _dead_6108 = 291
    value = 724073
    if False and True:
        932
        pass
        _dead_2798 = 662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwHFV0Yp5K41PwGCmW+AFwM9smo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΑИжЦтАφ():
    value = 884446
    if len('') > 0:
        234
        _dead_1134 = 599
        pass
    text = __import__('base64').b64decode('emxSVmtXYTFnT2RlZVNjSVp3UGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΡζбЗοΡφЮдИл():
    if False and True:
        pass
        930
    value = 989227
    text = __import__('base64').b64decode('SEtHaVJpdXJDQ0lrYzVQMnZqUUM=').decode('utf-8')
    total = value + len(text)
    return total

def _χбβιαщИихПΧШЖух():
    if 52 * 92 < 0:
        816
        pass
    value = 43222
    if len('') > 0:
        779
        pass
    text = __import__('base64').b64decode('WWZIZnpEeE0waVptRGFnZUpzZ2U=').decode('utf-8')
    if 47 * 87 < 0:
        pass
    total = value + len(text)
    return total

def _ПЛΛйъСΚмЛιмоЫоΣН():
    if len('') > 0:
        512
    value = 752944
    if False and True:
        304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDjRTGk8zq4CFRmkyluCDS4Oxk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΑΞνΕчβωХΠЗΥΛΤл():
    value = 847055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh7tPkg47YoKER6Ezg+WPhUM8WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8819 = 839
    total = value + len(text)
    return total

def _ψщиΖъОрГΛΣЯу():
    value = 409157
    text = __import__('base64').b64decode('Wk9WOW9ZTFMzQ0N0ekdsS1E5SVo=').decode('utf-8')
    total = value + len(text)
    return total

def _оЮΦгζβсΔж():
    value = 413697
    text = __import__('base64').b64decode('WG5UVnBteVNhbVdueHV1eU5RajU=').decode('utf-8')
    total = value + len(text)
    if 90 * 3 < 0:
        _dead_7948 = 444
        pass
        _dead_9472 = 192
    return total

def _ΩшбмΜΘηΑзюΒΘΗэ():
    if False and True:
        pass
        pass
    value = 225939
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fh/OWVQj14MrCCH3mHSobT123Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        502
        pass
    return total

def _Мςяюσзεш():
    value = 771358
    text = __import__('base64').b64decode('UHFlREJKOGtaUjBsMXltRXd0SHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΦНΞШοβЮΩОНхГх():
    value = 334125
    text = __import__('base64').b64decode('aURRVkxqWEV3ZE9qdmE4dFU0bWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΩсεиΦμοУΒтΗцλШ():
    value = 617909
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSrFTAER1r0zGV2bzFCYOA82zj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩφΟЯКεΔΨИΩУЯΧш():
    if 62 * 80 < 0:
        109
        904
        _dead_1864 = 31
    value = 930306
    text = __import__('base64').b64decode('Q3lQbjdXalh4eFJtSW84Sm0xTFE=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_5038 = 112
        pass
    total = value + len(text)
    return total

def _ΚΑКьмоΖυ():
    value = 39776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAzlRkkO3KQOKjyU4kW9EQ8ax18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯυфυΔΟшΞερяНΞψЯ():
    if len('') > 0:
        pass
        pass
        pass
    value = 768048
    if 63 * 61 < 0:
        _dead_3867 = 317
        _dead_6456 = 982
        378
    text = __import__('base64').b64decode('VWpxM1I0a3llZVlqTFZleTVHT2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ωδποЮыбΙΔдМКУεΑю():
    value = 931867
    text = __import__('base64').b64decode('Sk5HY0o0MTVoTmtDamI4N040Mk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ьтХνΓχοВсаΚμЯч():
    value = 26405
    text = __import__('base64').b64decode('TGtEZTR1cGVETU9oUExxZzAwNnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΓΑРгιрΒЙлЦ():
    value = 52674
    text = __import__('base64').b64decode('bDZvaFlkTXBpd180akQ0MWlmM1M=').decode('utf-8')
    total = value + len(text)
    return total

def _γПΖΒНΑΜьκпη():
    value = 996140
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IinTX3sjy4Q2aha2m2eoInYizVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛспΚξьхΞыгφΓюννβ():
    value = 670415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwnzbQESq/0AHiCKzUKiFSkG/Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кθσьβмЮпΦιрЖΙЧ():
    if 65 * 65 < 0:
        794
        pass
    value = 635756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBDPWFAh9KYWbV2H61SdJBws8Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΤΖГЭσЗΧ():
    value = 142275
    text = __import__('base64').b64decode('VHoyMHlEa3QyREtMVEV3REJMbVo=').decode('utf-8')
    total = value + len(text)
    return total

def _λθФηΑщΒЙдыλСиИЮ():
    value = 813619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxnwV1sGxqo3IzWE4n2bZTcl5kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СНфΔъΨςДβХεщк():
    if len('') > 0:
        596
        703
    value = 500528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICjMZGVhzYE0CCyswXeFYRMpzEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯЛЩξЦмξГΠЖΑ():
    if False and True:
        _dead_2286 = 499
        198
        pass
    value = 602348
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnrxXVIj5LIMPib3wlGGbD0Z4Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йкΙΞКρλшзСЗьфт():
    value = 353885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB3AXH0VzYIhAyeczny9OC0d4nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УξЮЬαЬГКфв():
    value = 117508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FASwPAY4poQPbRqym26ZPwcu/Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5075 = 329
        _dead_7676 = 319
        _dead_9756 = 740
    return total

def _πыЫбπωоЯйхΦζΤсΟ():
    value = 456769
    if False and True:
        _dead_5994 = 491
    text = __import__('base64').b64decode('WVZ5eGNlREdFTTBhODE5TWZuYkw=').decode('utf-8')
    if 27 * 41 < 0:
        _dead_5397 = 846
        pass
        851
    total = value + len(text)
    return total

def _ΒмхуцΨУЫ():
    value = 545897
    if len('') > 0:
        _dead_3059 = 19
    text = __import__('base64').b64decode('dUFyMDl4b3VKckJpeVpBNl9FQjI=').decode('utf-8')
    total = value + len(text)
    return total

def _тоλΝΤлпчжΧЮγ():
    value = 906413
    text = __import__('base64').b64decode('YXFlU1d0Z0JtYXhzX09DWU53NHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЖЙфЯЭΨЙЩδ():
    value = 616533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3v8ZUETxJ0nDiGPxEGqLiQG8X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΤдξφκАλΣЯбπ():
    value = 531993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC3KbXBpyJs8bCSvygO9NTQL7G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФхλХФψцπΦИ():
    value = 842411
    text = __import__('base64').b64decode('alNidE56ZnNUa3hnVk9ZRWxyM3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ждеШδФПΠμВκХ():
    if len('') > 0:
        630
        86
    value = 911244
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwW3b2lo34QzNh+o526qDgoi8Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κНкЗбАΨл():
    if False and True:
        _dead_8989 = 711
        _dead_4186 = 401
    value = 521984
    if 48 * 85 < 0:
        _dead_4481 = 386
        pass
        _dead_4889 = 69
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiPuXXM32pIBbDeT4XyjbSEa60Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        670
    total = value + len(text)
    return total

def _щΡпШиРФХЗИτΑр():
    value = 264982
    text = __import__('base64').b64decode('aEZTcGtIME9POHVYaXlnajVRa28=').decode('utf-8')
    total = value + len(text)
    return total

def _ιμРПфвΡдЛоχ():
    value = 521634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwK0anUR5Ltablqon2TALXAi8j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рμαАρЦоСчХκαИЯΒ():
    value = 162274
    if False and True:
        pass
    text = __import__('base64').b64decode('RlR1V21sTlhYNlhIeHh4eXVMZDg=').decode('utf-8')
    total = value + len(text)
    if 16 * 4 < 0:
        287
        10
    return total

def _ξξЖУчтεтρ():
    value = 374102
    text = __import__('base64').b64decode('c2xibFJ4R1FfR2VWYm9wakUxT24=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨγΣйΛΔЧШωпεтηυ():
    value = 806562
    text = __import__('base64').b64decode('WVdTaW9FR3pEeVFJbU1IQzV6OGg=').decode('utf-8')
    if len('') > 0:
        701
        _dead_2661 = 294
        _dead_7799 = 189
    total = value + len(text)
    if False and True:
        99
        856
    return total

def _ωσυфПнАЬлЪΨЕ():
    value = 443740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQjbf14S9J86a1yV8VyEZTEI8lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΓμхδΧААжθο():
    if False and True:
        _dead_3205 = 988
        _dead_7569 = 992
        197
    value = 451292
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQDjfFpr55wNPhyq4l6gZwt+5mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςцЛααгГψВγΔШ():
    value = 911964
    text = __import__('base64').b64decode('a052QVY4ZllRWWxRbld0eklJdWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛРЮРσΡцъсΡβΙΖ():
    value = 274996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTb+VloP6ZAZKT+05kGaPAwL00Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 55 * 80 < 0:
        pass
    total = value + len(text)
    return total

def _иЯυБКΚнεрΡΥΚΒ():
    value = 215749
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzvvfXpt8aI7EguH23fBBTQ3zGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ахΕцуζΒφышыЙ():
    if len('') > 0:
        pass
    value = 715443
    text = __import__('base64').b64decode('Y3lFN2hvbFg0X0hZVjBKYWZ1RnI=').decode('utf-8')
    if len('') > 0:
        169
        87
    total = value + len(text)
    return total

def _АΚшмЪчσЭΔйюυгλО():
    value = 866153
    if len('') > 0:
        _dead_9415 = 685
        _dead_3199 = 666
        _dead_7725 = 431
    text = __import__('base64').b64decode('alpVeGxYU3YwZlp1ejNfX2ZzOHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣЫςЛςΒθΨ():
    value = 874748
    text = __import__('base64').b64decode('Y0E1NUxTOGRvRkZsY3Jzd3VER2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙощюαζдΘ():
    value = 926274
    text = __import__('base64').b64decode('WjRzMVlnUXVGcnZSWnl6M1dLUHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _СχжньКΙнК():
    value = 349269
    text = __import__('base64').b64decode('ZzA0YWc4SGZaRU5mSXh0akVRX3Q=').decode('utf-8')
    if 64 * 15 < 0:
        _dead_7676 = 476
    total = value + len(text)
    if 7 * 76 < 0:
        _dead_1602 = 740
    return total

def _юΦщΖкжςαδчν():
    value = 632207
    if False and True:
        388
        354
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB/0VkE82Y8Kby6o9w6hBAYd4D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΥρчбыБоΧΖαΒЕτρ():
    value = 922557
    text = __import__('base64').b64decode('dnRMbk5pTGVfemUxNWpEeG9McXo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        969
        pass
    return total

def _рЯωφапΝйΖωСяоБΘГ():
    value = 865625
    text = __import__('base64').b64decode('U1ozS1hvajcxOUxjYWhha3dHNnc=').decode('utf-8')
    total = value + len(text)
    return total

def _БкыΔΤαасЙЬкν():
    value = 358809
    if False and True:
        _dead_1042 = 287
        770
        pass
    text = __import__('base64').b64decode('ZTd3QzZ0SGZwWGVxR0Y4ODJkYkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩЭΟДЖяРФЮЙ():
    if len('') > 0:
        pass
        215
        305
    value = 193734
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('aFA3X0VObV9McUFPdUVhVzUyeE8=').decode('utf-8')
    if False and True:
        _dead_2100 = 491
        pass
    total = value + len(text)
    if 84 * 26 < 0:
        pass
    return total

def _ΑιфчΜЪпТΚМΑА():
    value = 713096
    text = __import__('base64').b64decode('Y1BESjVQY1R6OHlhZ21aZWx6bEI=').decode('utf-8')
    total = value + len(text)
    return total

def _еΠФЛΡНУНγ():
    value = 68158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxvXSAUtyqwtMFmv5E+XET94zEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 11 * 33 < 0:
        _dead_2335 = 828
        _dead_4165 = 595
    return total

def _ЦδΥΓУτψЭΨА():
    if False and True:
        793
        191
    value = 539604
    text = __import__('base64').b64decode('Q3drcldJb01JMjJmc1VhVjBoWUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝьΒМпйπдΤуδς():
    if len('') > 0:
        _dead_1704 = 207
        pass
        _dead_4750 = 711
    value = 111086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXm1Q0Y//I8MAF6X+gCENzMK9XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3236 = 356
    total = value + len(text)
    return total

def _ийΦιРΕЙΝдΗЬоИШ():
    value = 534212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwbdRXUY7Z0SAyaO0W+YESsIsF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РЪЧοОааΘΧ():
    value = 401508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FB+yNlcrp54zHFymynrCLBB640I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΜуΜζΟЬУφ():
    if 92 * 46 < 0:
        467
        990
        pass
    value = 236818
    if 74 * 64 < 0:
        _dead_4791 = 612
        pass
    text = __import__('base64').b64decode('dDNsRDlaSXNfbTg4c3B3b0xjeno=').decode('utf-8')
    if 59 * 38 < 0:
        _dead_6506 = 957
        pass
        _dead_7288 = 290
    total = value + len(text)
    return total

def _ЮБтШзκβИΔШягиβ():
    value = 332519
    text = __import__('base64').b64decode('YkxhbzkwT0R0bEFKVUIyVF81dk8=').decode('utf-8')
    total = value + len(text)
    return total

def _мФиЦεДлфЛбчяшч():
    value = 428177
    if len('') > 0:
        740
    text = __import__('base64').b64decode('YkVKbWxFRVlWOVhRdnpQaFEyZWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭЦяФσΡКΤзЮ():
    if False and True:
        _dead_9029 = 660
        918
        _dead_5075 = 42
    value = 961505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBjneVQszfAnEwX2zVuAOQMXzEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        912
    return total

def _ΨТЙΗΣдρλНΖсΙТμυо():
    value = 10687
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjW0Y18c/KVSNwiv40ycHSIswVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λβПЕИЖъэΜЧЪ():
    value = 604590
    if False and True:
        574
        711
        _dead_4636 = 723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiDLeXsdy7smKz369wWHOXAHtmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2310 = 809
    return total

def _κйсВРΚэАφкЫΛОи():
    value = 568221
    text = __import__('base64').b64decode('VHNVeXJXZXN5RTR5bTNlNWRwQ1o=').decode('utf-8')
    if False and True:
        754
    total = value + len(text)
    return total

def _ΠъГΒдηеιχЖεΦТю():
    if 57 * 96 < 0:
        492
    value = 548038
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiP2W3MQ94JXDAyL2U63bCQp/kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щУмгηНеΝσдГΝ():
    value = 885411
    text = __import__('base64').b64decode('S2FMWkJ2c0xXZTV6RGJ2OFU5OTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛφУШΛЙλЖυжΛбΜθД():
    if 84 * 53 < 0:
        389
        _dead_8734 = 883
    value = 853212
    text = __import__('base64').b64decode('SXlVenI3d3hlaTl3OElONG1ibTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ζδκγμΔνУбяΑΖΦЧЗ():
    value = 297847
    if False and True:
        _dead_6231 = 251
        954
        _dead_4748 = 364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky3SaWUy7PFXKha790KXDi8F420='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7612 = 256
        856
    total = value + len(text)
    return total

def _βφтΖΑυνАГф():
    value = 301098
    if len('') > 0:
        560
        _dead_3515 = 918
        605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBbqS1Uz3LtVKx7z7mmbEXc/zzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ρщΠΟδЛφΡκеΟжн():
    if 14 * 80 < 0:
        pass
        pass
    value = 834900
    text = __import__('base64').b64decode('R05LcFhabkdldGlNQ3RqUWNnNHU=').decode('utf-8')
    total = value + len(text)
    return total

def _γπЮемлЦр():
    if 54 * 77 < 0:
        344
        _dead_4174 = 180
        _dead_6395 = 273
    value = 434709
    text = __import__('base64').b64decode('QTA1MGFiblhzNlFzemd0Qm11Y2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЬΩеЮгφΚπЙ():
    value = 974371
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECuyfHMRx4AICyW33liiDCsatn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОщοΤχиΘЖэφη():
    if False and True:
        214
        294
        511
    value = 926247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB7uW2482o0kbyOZ2k+gJiJ+5jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚααφАΤμгκΑПЗΨо():
    value = 274044
    if len('') > 0:
        pass
        867
        pass
    text = __import__('base64').b64decode('WExOU3FOaVRiQmVLc3Q5ajhfb1A=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6313 = 429
    total = value + len(text)
    return total

def _чγΨеФаΠπХ():
    value = 342739
    text = __import__('base64').b64decode('clJsVm5sdkxHVEFzX1lSZnpySDI=').decode('utf-8')
    total = value + len(text)
    return total

def _шΞγρдрЧΩζΛ():
    value = 13925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQG1eGBg2IxQIla6612kITcd3Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щЦбΝПυΚΞΗБΛХЕκφ():
    value = 128428
    text = __import__('base64').b64decode('bTVDR1ZQcWN6cGpBUjcyd1RyeTQ=').decode('utf-8')
    if len('') > 0:
        _dead_5202 = 355
        905
    total = value + len(text)
    return total

def _θЯΧЫИХПАъКΛЧУςл():
    value = 703302
    text = __import__('base64').b64decode('allzTm5PU3hzd1NRb3l5T1U4YVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _цщΖгφЙйΓΗфгΠΖεκш():
    value = 617307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChngdGJpxLovIwr3wnvEDHAq0T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΠεДФьχяузЕфΠβρч():
    value = 239006
    if False and True:
        pass
    text = __import__('base64').b64decode('Q09jQ1JvbXdRM1pGc2FQNk5nNUo=').decode('utf-8')
    if 92 * 23 < 0:
        550
    total = value + len(text)
    return total

def _ΑΡщтфΙхГεν():
    value = 4327
    text = __import__('base64').b64decode('ZzdqTEZCa3NjbWNyNVhiOExUU3M=').decode('utf-8')
    total = value + len(text)
    return total

def _τтТДΛΑЮцАВмйюуис():
    value = 664644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyfMRG5pwfksbhmJ/EajB3AB/l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞξНЗЫΚηДнθψБдΩγ():
    value = 740859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ijn9awYa8PsPCQOK+meIEj0D3jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λдηΒΓγΚγйκефЯΒ():
    value = 603055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwnObFkszpoELy6C/USfEwgDvEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        14
        678
    return total

def _ΩχХΓкΦδс():
    value = 359213
    text = __import__('base64').b64decode('ZzM1SGI4d0JKUnEydFF1c0I3ekY=').decode('utf-8')
    if False and True:
        pass
        347
    total = value + len(text)
    return total

def _дΧΙвΩλδуэрΑнюНАд():
    value = 283608
    if 11 * 20 < 0:
        pass
        _dead_6429 = 729
        _dead_7666 = 42
    text = __import__('base64').b64decode('dGIycHh0QW1Ec3A4N0pxdEtpQUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΥеνΧаЩсМΟιрΓЗ():
    if False and True:
        258
        pass
        pass
    value = 2944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjX0OEYOwYkxGVq2xkGHYyg3ylw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝθοуЛεтΛуМй():
    if 19 * 43 < 0:
        pass
    value = 875475
    text = __import__('base64').b64decode('R3dGeU9KQTMwNDE4bGIxclpGVm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧσГχтфэЕЭя():
    value = 552213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHz+TWE15K8pPwypkVeqBB963k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мβΘηΝвИМΙΠω():
    value = 402602
    text = __import__('base64').b64decode('ejZZTUQ3b1FWZWQzbThJckRjQlU=').decode('utf-8')
    total = value + len(text)
    return total

def _αШητЩзмсΓЙЩС():
    value = 385772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHjMdkcG7r0CGFi1xleyJgkEwEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зЩНЫшΗδюεΟΤ():
    if 25 * 68 < 0:
        506
        277
        pass
    value = 687404
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiPhYVg3yJgLLhuEngSELiwJw1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1345 = 761
        _dead_8214 = 139
    return total

def _ЯΑНпΞΕЫΨΨПчкΕ():
    if False and True:
        pass
        943
    value = 196927
    text = __import__('base64').b64decode('aDZMbEN6dTlpWFdkTUxrYU1wMkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЕыνυςЩМЬЭΥΒЦИ():
    value = 554807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQPofEkP8qk3HgKu8FuWZHwbyzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УшΟΝЧШжλδЗυщ():
    value = 495021
    if len('') > 0:
        947
        pass
        _dead_2356 = 593
    text = __import__('base64').b64decode('S0puSTlWaU1hb3hBTnBqcFpKTHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _СβΔФРσζъО():
    if len('') > 0:
        _dead_6200 = 634
        720
        17
    value = 949295
    text = __import__('base64').b64decode('ZlEwbG95elN2N2FXY2Q4RkZNdnM=').decode('utf-8')
    total = value + len(text)
    return total

def _оΑμζлЙαηΩιИоπ():
    if len('') > 0:
        500
    value = 165784
    if 88 * 87 < 0:
        _dead_1491 = 458
        _dead_9538 = 815
    text = __import__('base64').b64decode('cGhkaVozRmVPclJ0RDBuV01NWUs=').decode('utf-8')
    total = value + len(text)
    return total

def _вΑЛцυзΓЖΗВΕз():
    value = 532344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHyxOnUr96ITPxqZy2bBIw96vGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫнтζПοсИυζРιΔ():
    if False and True:
        pass
        pass
        _dead_4995 = 458
    value = 582458
    if False and True:
        _dead_3927 = 446
        111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCbIW3cV6ppQHweE7UyHbTInvX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 42 < 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        249
        pass
    return total

def _вИЪβаθψΧλΓ():
    value = 185902
    text = __import__('base64').b64decode('TkVYRnAyVExGV3ozbXNYbFgzY3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _лыψΛοΚгТΥΧρВ():
    if False and True:
        _dead_3160 = 776
        pass
        _dead_6746 = 169
    value = 993107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgnVUVIWrowSPyG38gWkJh8K/Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βфэΩтЩξΟςПгЬΛωΦЗ():
    value = 555758
    text = __import__('base64').b64decode('cUhHd3lTUF9WekNUYmZrNE9SZlE=').decode('utf-8')
    total = value + len(text)
    return total

def _орΞИηПзΕζЬ():
    value = 657906
    text = __import__('base64').b64decode('eDdpVWdlYmtrRHpQYmFUeDMzU3E=').decode('utf-8')
    total = value + len(text)
    return total

def _лЫЮнΚυВя():
    value = 326666
    text = __import__('base64').b64decode('SmNKYkJCaVA1UGJvMXdWSGJPMzI=').decode('utf-8')
    total = value + len(text)
    return total

def _γφчΙΟωяΘЮИВЧ():
    value = 526440
    if False and True:
        939
        361
    text = __import__('base64').b64decode('ZXB2RlZUT1BLbE01V2tsSzRmVEg=').decode('utf-8')
    if 47 * 99 < 0:
        _dead_9013 = 253
        64
    total = value + len(text)
    if len('') > 0:
        _dead_8862 = 610
        pass
        _dead_1497 = 792
    return total

def _φΦКЪкВηАοΜψсπ():
    value = 733847
    text = __import__('base64').b64decode('dmFmYl93UkV5eDdQQ0NfR3g2cnE=').decode('utf-8')
    total = value + len(text)
    return total

def _ππΣьюρβгΑМηюб():
    value = 599999
    if len('') > 0:
        571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBnePnY27botNh71mVCYOSsdzHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6256 = 485
        pass
    total = value + len(text)
    return total

def _ΗιэοВкφпΤКшаЬ():
    value = 773790
    text = __import__('base64').b64decode('cnlXZlhWZmpvNk10WFR2MHA5UlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧяΖэкХЭТыυИΣυ():
    value = 929126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASHXQFY7/Is7Lw2n/we1Hz0b0Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φчЧБΖмНλβзκΧ():
    value = 955008
    text = __import__('base64').b64decode('YzRDYnZBNkg5ZzR3cFZOOEdLOFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ъΔψыΛМεΒВΜ():
    value = 965444
    text = __import__('base64').b64decode('VklfaTh4cENxNTU4cFBKTktqZkc=').decode('utf-8')
    total = value + len(text)
    return total

def _цСПСщΑерβκкΙΦ():
    value = 684495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bgz3YgI42rI8MDWW0W6lLgwJ1Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1239 = 215
    total = value + len(text)
    return total

def _ΘМΥΣюНΘΧТЪЗЫЪω():
    value = 245036
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PALLRlwN2f8FMAGc3F2IHzAu1D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υчχΑμОФςЗεγΨ():
    value = 835119
    text = __import__('base64').b64decode('bWhUZ0NxaVB2aFBQZ3VWREI3REU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZA==').decode('utf-8'))
if len('x') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()