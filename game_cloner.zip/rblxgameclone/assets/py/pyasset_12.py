#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _эΕЛчψχΦκΦ():
    value = 454712
    if len('') > 0:
        _dead_7949 = 901
        pass
        _dead_6747 = 247
    text = __import__('base64').b64decode('cm9pRUh6clRaQjFPakxjdEFEd1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡюьηΞΨΗпА():
    value = 740322
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('U3lDZVlNb3NiRTd0OHZNaGVnMmo=').decode('utf-8')
    if len('') > 0:
        pass
        398
        _dead_5158 = 894
    total = value + len(text)
    if False and True:
        pass
    return total

def _ьЫЙЧдКυЬ():
    if False and True:
        pass
        783
        pass
    value = 587990
    text = __import__('base64').b64decode('T1lLcUhORGl0VGZ0cXd4TVVPaWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝОвхфХΦЙКЩц():
    value = 615953
    if False and True:
        _dead_8077 = 727
        _dead_3484 = 673
        pass
    text = __import__('base64').b64decode('bE01Zld4cHlSQnpyMkZHQ2UwRzI=').decode('utf-8')
    if False and True:
        pass
        622
    total = value + len(text)
    return total

def _ТνΨφБΕнХжЯрсАуθ():
    value = 962034
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyLrbEcSya1QaSmvy3W1GXIq1zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬцηΔхΜРΒ():
    value = 374138
    if len('') > 0:
        509
        _dead_8897 = 857
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzzoXgkuyaEaYymCkXGGJz8pvGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        651
        961
        799
    total = value + len(text)
    return total

def _ТΗъгНКτΣ():
    value = 284673
    text = __import__('base64').b64decode('UXJtYzkybFgwMnBmc1JzbENMdEw=').decode('utf-8')
    if 81 * 7 < 0:
        _dead_1040 = 466
    total = value + len(text)
    return total

def _ЦΥθΧГйАиЗЯΜЯПΠъ():
    value = 214116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCTgWQctqrtQN1yC6W6gJj8i8H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лмψΥЖттε():
    value = 4029
    text = __import__('base64').b64decode('TkFnNEZnY1RXMDk3eGN1Z2xFWmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _жΠΜИаЛГьΩ():
    if len('') > 0:
        pass
        _dead_1864 = 82
        729
    value = 454347
    text = __import__('base64').b64decode('eDV6ZHY0RlI4OGxCS2lOempvSE4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7183 = 851
        _dead_5231 = 928
        _dead_1812 = 188
    return total

def _ЧЬΨΦΑχααзР():
    if False and True:
        713
        148
        _dead_9902 = 733
    value = 239794
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzW9f34r9YI5FAeU2UWZCw0IzGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 59 * 57 < 0:
        _dead_5144 = 72
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ЫΗκщФШОВ():
    value = 309679
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETvieFAT04xXKl6x/V2TOwMMs30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨЯχТэУйθΟхЖПИΧ():
    if len('') > 0:
        _dead_6918 = 674
        576
    value = 652110
    text = __import__('base64').b64decode('WFc3NGxPekk5cmprSDlucV96R1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _СЧΞЙЦЖрдξΣ():
    value = 82528
    if 97 * 14 < 0:
        _dead_1533 = 22
        _dead_4960 = 320
        _dead_8844 = 507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAjXRVQu0vsyCCeHkQa+ACMi7To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 88 * 37 < 0:
        113
        pass
    return total

def _ъδθΚзчСΣ():
    value = 813118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn3uYmQazI8KDAKImHyabQR4934='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 52 * 50 < 0:
        _dead_5218 = 423
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _щαяФΖюΩлΣρ():
    value = 803863
    text = __import__('base64').b64decode('U1JhNkViV2M1Qk1WaWxsRmtYNm0=').decode('utf-8')
    total = value + len(text)
    return total

def _οшνйωЕяηВ():
    value = 579770
    text = __import__('base64').b64decode('T1dRNUF3WF9iMXkxU0pJdzgxVGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ьςюΗнΛθΔΡъχομЗ():
    if len('') > 0:
        pass
    value = 671616
    text = __import__('base64').b64decode('Z2h5RlhnZnBJd2ZCT1pxUnB4YmY=').decode('utf-8')
    total = value + len(text)
    return total

def _кЮРξδδпαтУТλ():
    value = 251568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTnqQ0sh06EMaDaH8nm4PhEi/UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΜφНςλΗЫΟзσΘΨ():
    value = 192004
    text = __import__('base64').b64decode('bDZ1X1duOFlpRGlNWElIdlBRdXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ылωэΤХХΑУ():
    value = 351162
    if False and True:
        _dead_6045 = 881
        _dead_7387 = 499
        _dead_4688 = 673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg79ZWsG2IkINziry33JPj044FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гМδЙлωΤΗφ():
    value = 239479
    if False and True:
        _dead_7622 = 910
        476
        _dead_7310 = 912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3nof1lg6ZASG1ukkX29ZSsZ4VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        376
        _dead_2324 = 100
    return total

def _ФφНнδζΤТфдКвτΟΤ():
    value = 265490
    text = __import__('base64').b64decode('RWRhSjZHUm5OSm1MOXZfUFNYYnQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8452 = 797
        pass
        _dead_1864 = 273
    return total

def _чδдΖЩэЧΜйηяВ():
    value = 569918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBzXNkQd34stPV+1/AbGNh143E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _длρΧЕИΗΞμБУμЫ():
    value = 309816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQyxSGkr0vFQMCez5QG7ZAd+1EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΜПвνχЕφφ():
    value = 484532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EynvfGUY5J0nDlmZxWOcBAEF93w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨεαСУФΘЛκεβψΩМΓθ():
    if False and True:
        _dead_1312 = 71
    value = 213246
    text = __import__('base64').b64decode('TDBIdm9qMXJWVHVuaUN2Uzk5ODg=').decode('utf-8')
    total = value + len(text)
    return total

def _АшΒЭρсцλ():
    value = 565918
    text = __import__('base64').b64decode('VG1BNEI1TTI3T0ZaQ09CcTd3b2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ГиюλмВσΠ():
    value = 316196
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXnqVmUf2aVbID6tkEOKMTMH1Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤшΣевРЯБЯνСγНΧп():
    value = 251134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw3gfG5o06oKIBX7z2+YJwYr9jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΟПεΡΠΒСΖДτфς():
    value = 656001
    text = __import__('base64').b64decode('Z1JRampzQU9GaGNtWFZoNDVLNEI=').decode('utf-8')
    total = value + len(text)
    return total

def _йβιΩУШБθЫуΡιЩиχ():
    value = 430463
    if 45 * 22 < 0:
        _dead_1355 = 660
        _dead_9067 = 700
        _dead_1208 = 596
    text = __import__('base64').b64decode('aDR1TmM0RHJDVG83YnZkVzJuenI=').decode('utf-8')
    total = value + len(text)
    return total

def _τΝШпρчМαωэЗν():
    value = 397416
    text = __import__('base64').b64decode('cWxLZEhXRE01WVJKdGJKWjd5UnI=').decode('utf-8')
    total = value + len(text)
    return total

def _κЬзΙζμτνъЗΛбкΨ():
    if len('') > 0:
        pass
        354
        pass
    value = 960363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnvufVAG0LghFTmL0ASBPi8tsDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6375 = 571
        _dead_2369 = 384
        pass
    total = value + len(text)
    return total

def _ΝδЭσДИИΖτх():
    value = 836605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADrwR1cxx/g2IzqZ0UGaPhJ63lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςбΠΤяΑЭБЗ():
    value = 654666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgbRQGII+78aICbyy2ClDDc/ylc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞЕзчιΙαπиЩеЧΕ():
    value = 60437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAnoOWI/1P0EDlamwme1HiwX7Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3639 = 688
        pass
        _dead_6756 = 314
    return total

def _яЛΨзΟνωΔяъЙεЗ():
    value = 594954
    text = __import__('base64').b64decode('SFFtSXRRWWxqUmo5T3ZNanc4SzY=').decode('utf-8')
    total = value + len(text)
    return total

def _τΓнВоизοθΒ():
    value = 328915
    if False and True:
        pass
    text = __import__('base64').b64decode('cnhTYnZvelZOenQ5QVQyMkc0dFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ХФαЖйявШЗЯ():
    if len('') > 0:
        _dead_9672 = 266
        pass
    value = 186319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjX2RgkK2Zw0AyuX3WmkEigZvWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κъιДπСЙъгΟ():
    value = 44653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTnFf2g8yZ0VFTqg3GTHMBEg41w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χъзЖэюПнБАуαΟεκ():
    value = 255494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQfRSkI4/JASDBa1+FWVMRME5W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τусКзещΔ():
    value = 584917
    if 36 * 42 < 0:
        112
        _dead_1847 = 473
    text = __import__('base64').b64decode('dzd1cXBQaVF0RlJ6bEs2VWhmQnE=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _фНДФлςςЮхξАРСΖу():
    value = 778728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRXudEQwq5sRKl2zxVyYLQYXtnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЦвнпЪАΠ():
    value = 989446
    text = __import__('base64').b64decode('bDhkOFRIRFBrRnVFUTJ5bVdGTFA=').decode('utf-8')
    if len('') > 0:
        _dead_7896 = 529
        pass
        922
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _οгЕыйЫЯпЖмшΚакЙЛ():
    value = 666452
    text = __import__('base64').b64decode('eFRabDZKSFVFdTZvOUtydnI2emU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΥΗπΨΕΒЕУвъбШ():
    value = 503321
    text = __import__('base64').b64decode('SUdmNGJpSG1fQmRPVjBXM0I5bUo=').decode('utf-8')
    total = value + len(text)
    return total

def _φСΧΟдХКРбΦ():
    value = 727399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiXnPmgXyIM3A1m06V6lBwc3tkk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 54 < 0:
        60
        _dead_7382 = 669
        pass
    total = value + len(text)
    return total

def _ΓзОΔдДВЦсз():
    if 75 * 51 < 0:
        _dead_3715 = 399
    value = 469659
    text = __import__('base64').b64decode('WGwyNER5M2pYS1hMVHZpZ0V1NjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗРяЛΦμΟзΜЧс():
    if 41 * 85 < 0:
        287
        pass
    value = 85150
    if False and True:
        _dead_8817 = 719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQHzWFoA7bggMAeQ+EbBFy0nyEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 96 * 40 < 0:
        _dead_3160 = 625
        108
    total = value + len(text)
    return total

def _охЪθшΒкψθРζЩΠиΡΡ():
    value = 956439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx/9P1w3xqIRECuy3l7EJTU37Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηρβНйДΙЪΟХθ():
    value = 599737
    text = __import__('base64').b64decode('U3Z0b3BxYlc2akx5NkxWUG95dGs=').decode('utf-8')
    total = value + len(text)
    return total

def _γωΕβПΑаюсΧλЬНαя():
    value = 307912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyHLZHUjrrEgEAW2ym6+PCx68Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 5 * 4 < 0:
        _dead_2108 = 754
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _гГνНБхμгμЭЫф():
    value = 534237
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('a2xSZUZiRUJVYkV4WTRTc0lTYnk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2581 = 681
        _dead_8264 = 644
    return total

def _гΞщъΨαФςбρЕ():
    value = 660428
    text = __import__('base64').b64decode('cXdwbnc0RktuV0NkRmdJcl8yVmw=').decode('utf-8')
    total = value + len(text)
    return total

def _τζΓмΘэΔΞα():
    value = 46190
    text = __import__('base64').b64decode('aE56SkVwdzdLR3IwMmg0Wno3U20=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        382
    return total

def _ЕбыБδьчвλ():
    value = 628997
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fhf2bHIs3alaPSKn2Hq1GQsc0Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χαаλΡΛΞΘΓ():
    value = 739154
    text = __import__('base64').b64decode('bzZVdUNma04wQ3pNNm9Cd3FuVk8=').decode('utf-8')
    if False and True:
        _dead_1838 = 136
    total = value + len(text)
    return total

def _ΠΦюΧйΡчАФ():
    value = 121529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHv3bQYT87ghEyep+GbGIS8BsDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΜΡЩΟэφυ():
    value = 867293
    text = __import__('base64').b64decode('ZjUyM0V4VEFTR21CYWlxdE8xdU4=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _βВШЯΨχбζ():
    value = 473363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRjwQFQV8JwrBQeQ71GWARUdxn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τэРПВΛуχЬγΞЮЪΩΕФ():
    if len('') > 0:
        pass
    value = 552501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bwn1S1pu0pFTGSP0mgW7EiAuyzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΜЪаΙγμς():
    value = 478362
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAncSUYe0KAINQLw8WCaDHYC3EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 92 * 11 < 0:
        pass
    return total

def _κСжΗЩΙλчеФкш():
    value = 819365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCy9aUAd6/AXHjmI6Q++JBQg1lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЛяδжЕйОωτ():
    value = 966771
    text = __import__('base64').b64decode('ZjdjdXJhakZOU0lBOUJHMEtuWmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬРΞЧΦΩμГο():
    value = 240684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IALWRlUS1fkoADqomHi6JysG7mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒшΔКРТωΙΟξΔЙΣΩР():
    value = 887263
    text = __import__('base64').b64decode('ZE82dnBYOEJnUW5LWU5uQU0yQ1o=').decode('utf-8')
    total = value + len(text)
    return total

def _рСВЩлцΙпνκθнα():
    value = 861705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAvFfGcq3YMTHA6m20C6FQ8k5lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6857 = 789
        134
        pass
    return total

def _щРηρΕξТЕΖΡΒД():
    value = 249617
    if len('') > 0:
        _dead_1869 = 500
        _dead_1180 = 766
    text = __import__('base64').b64decode('RE1FblZQZDVKTktWOE16OHpzR1Y=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9941 = 291
        pass
        943
    return total

def _юνОфЫгъΝ():
    value = 711000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQbyP0csp5oTKDWW216JHgA3t3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 31 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()