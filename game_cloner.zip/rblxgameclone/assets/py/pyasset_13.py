#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ОνШаοцЗСтφΕ():
    value = 538361
    text = __import__('base64').b64decode('RVhnTzJGM19ybEw3ZnFoZ1BFMko=').decode('utf-8')
    if False and True:
        827
        _dead_4652 = 462
        _dead_9789 = 137
    total = value + len(text)
    if False and True:
        _dead_7149 = 723
    return total

def _УжъΜхаЬηзΖР():
    if False and True:
        pass
    value = 259063
    if 78 * 77 < 0:
        906
        _dead_6348 = 933
        pass
    text = __import__('base64').b64decode('dWRxbVZuYzhYbDl0S2p3Y1JlVWg=').decode('utf-8')
    if False and True:
        pass
        _dead_1243 = 631
    total = value + len(text)
    if 82 * 5 < 0:
        pass
        _dead_3428 = 667
        267
    return total

def _ΖуВρλгчэЯчКΡΛ():
    value = 249091
    text = __import__('base64').b64decode('ckIzZ205enRqeG4xalZnU2JJbFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔЬОμμЖξфсΚ():
    value = 902221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FH/KbWAMzPsKOAD0mVvAACAGwTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лрбхаяΥΣΞΗуИσрл():
    value = 895964
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('ZGc1WEhGTFdfemZxaHc0Yjk4R1M=').decode('utf-8')
    if len('') > 0:
        284
        pass
    total = value + len(text)
    return total

def _ΧλтЦЪууСΨσ():
    value = 535044
    text = __import__('base64').b64decode('RktXbjNWTXhTSHlNVU5KWHl4cVI=').decode('utf-8')
    total = value + len(text)
    return total

def _эΜγΜЯыдδМЮяρΗτ():
    if False and True:
        pass
        pass
        79
    value = 646538
    if 24 * 50 < 0:
        48
    text = __import__('base64').b64decode('bEJjbzJ4R2pDaVZtOWFMQkhXTFE=').decode('utf-8')
    total = value + len(text)
    return total

def _иЩωμъОЦЙπξпξкΑΒ():
    value = 99678
    text = __import__('base64').b64decode('SUw0VWtBUnlVVDZqWHJSV1VTNng=').decode('utf-8')
    total = value + len(text)
    return total

def _яХэкГπХязжНεσжС():
    value = 285443
    text = __import__('base64').b64decode('elp1Z2t1cVRWWWJ3YkpIVFhXc2k=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _КйОЮΑπЯгюъΕзУΞ():
    value = 739107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD+8e1ku+ZkTEwj10k7JH3Mq1V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _σЯНГоэеЮΥБΛЪйу():
    value = 82637
    text = __import__('base64').b64decode('VFBKS3NZTkFLanM4VEQ1cTRvU2E=').decode('utf-8')
    total = value + len(text)
    return total

def _чГпОеηβГамΣΧΦτс():
    value = 489707
    text = __import__('base64').b64decode('b2FZU2FwNGVXbk55T0JUSGNNOGo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        71
    return total

def _ΗВΨΖΥюιρΒНΓыБτъ():
    value = 560260
    text = __import__('base64').b64decode('YVFWYzlhOEZ2UTgxZ2t6bHI1SWM=').decode('utf-8')
    total = value + len(text)
    return total

def _мкХεΒПяП():
    value = 384263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCq8a1ge8KJWEQXz+UeGDQF21ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΡЯЗβчДщξΥΡыЦ():
    value = 559066
    if False and True:
        384
        pass
    text = __import__('base64').b64decode('YXgwNDF4TkJ3QVB5Z3JiT28ybW4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9839 = 499
        141
        _dead_5644 = 140
    return total

def _ΖиΟкуБυС():
    value = 37998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERjRPlMN/JcOKxybzwKIYy99/lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДЦΣΥЩрΜΨЯПξМχΣΤ():
    value = 507845
    text = __import__('base64').b64decode('RFFnNW5WdFFoZ0k5dEtfZDV6YW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΝСιλΡВЖтЖмνΣ():
    value = 965498
    text = __import__('base64').b64decode('WDJES0dhNkRRcmR2WlgwZjVvQlA=').decode('utf-8')
    total = value + len(text)
    return total

def _сΥμφηЗлЮГμςКπ():
    if len('') > 0:
        585
        270
    value = 963114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiOzYXAbzaUZICqvmwbHYgwE1lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОπКюΟщβБΚП():
    value = 292068
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSTrfnIA2I4oLgCr8AK+GD999VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЗΕΟΔТУЦ():
    value = 637527
    if False and True:
        849
        pass
        850
    text = __import__('base64').b64decode('V0t4M0ZBT2Rtekh6aFAwSG9rRVU=').decode('utf-8')
    total = value + len(text)
    return total

def _КйαДжПыЗцΩνЙЕΞ():
    if len('') > 0:
        pass
    value = 960359
    text = __import__('base64').b64decode('YzVmYV9lUDYxSm9ETkV0aHhJYU4=').decode('utf-8')
    if 38 * 66 < 0:
        pass
        _dead_4529 = 847
        pass
    total = value + len(text)
    return total

def _ΦΜβξΗΟСМ():
    value = 986862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITzGXQQe0LIOCBalzgO3I3wH6E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        935
        _dead_2933 = 639
    total = value + len(text)
    return total

def _ΥнВйτоИΠσыЪЗХАοΡ():
    value = 836633
    text = __import__('base64').b64decode('RWhXc3hxZHgxdHBrNkYyalhGSWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧТΤзтЗйηΘФ():
    if 98 * 1 < 0:
        472
    value = 482602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BybLY3sq/ZcwAhySm2CADnw1slc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7153 = 883
        pass
        275
    total = value + len(text)
    return total

def _ΤЧΑПсКтЦοэΔλзцο():
    if len('') > 0:
        727
        800
        _dead_3346 = 141
    value = 695480
    text = __import__('base64').b64decode('ZjdyYmQzTTE4dTkwelBUNHBjX3U=').decode('utf-8')
    total = value + len(text)
    if False and True:
        375
    return total

def _ПψησВψΛχЧΠηΖ():
    value = 138502
    text = __import__('base64').b64decode('cF9QSGhSZjhBUnlBZ211SXRFUmE=').decode('utf-8')
    total = value + len(text)
    return total

def _вГΗеΖьхσγЖ():
    value = 549630
    text = __import__('base64').b64decode('dXFXRFM0VWxhY1R0c0hCTWlEZkc=').decode('utf-8')
    total = value + len(text)
    return total

def _фΤопΑЕДаχευορ():
    value = 464505
    text = __import__('base64').b64decode('TTB2RE8yNXJ0a1I5UjJvbDlxdUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΓМεΛмйΑПвлнΞ():
    if False and True:
        497
        540
        _dead_8595 = 656
    value = 54413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Anuxb2gJpokpKTem4mebDCM+tkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 18 * 41 < 0:
        pass
        _dead_2688 = 174
    total = value + len(text)
    return total

def _ЗЫЗυηЬηνЫр():
    if 15 * 54 < 0:
        729
        _dead_8830 = 8
        pass
    value = 866759
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCjGe2A/34UwFQqkxEKaMQYJy0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 65 < 0:
        pass
        819
    total = value + len(text)
    return total

def _ПπυΔПμЛФЕЩλβ():
    value = 226555
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXb1fAEG7642AzaP+weTFhYl808='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΤпБΟРΧπцкιОΒЕ():
    if 87 * 32 < 0:
        _dead_7156 = 763
        _dead_1713 = 483
        pass
    value = 530643
    text = __import__('base64').b64decode('RmdPVzIweWxTMEJjVVZMS1dFaUg=').decode('utf-8')
    total = value + len(text)
    return total

def _гшΦыЖμдЯξΤбχУз():
    if 97 * 64 < 0:
        484
    value = 821067
    if len('') > 0:
        _dead_1870 = 846
        pass
    text = __import__('base64').b64decode('bjV0RHJWcDVXVFNqZjdqWVNGelk=').decode('utf-8')
    total = value + len(text)
    return total

def _φПΘжпλиаρπеЬχΕ():
    value = 644560
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj3IeAYP87IsYl+x6g/HCzQO6Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩЬΕшνΟΝβΡГ():
    value = 472821
    text = __import__('base64').b64decode('aHFFaVpreDJ3allzcFVlWnNfUVA=').decode('utf-8')
    if 70 * 55 < 0:
        621
    total = value + len(text)
    return total

def _ъκЙмНμθЮБз():
    if 18 * 2 < 0:
        _dead_1532 = 59
        _dead_3952 = 39
    value = 91239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT7pb1AY7oEHDwebwVuqEBMe7z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φЖшпрΤΑνУΗК():
    value = 846208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MinQYnM1+6FXMwLxx12pBhcnyU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        243
        _dead_5565 = 967
    total = value + len(text)
    return total

def _ЕδθсΦΝнοТ():
    value = 862142
    if len('') > 0:
        779
        116
        _dead_6366 = 358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCfdPlAW5IYTKSfz61WkOTQuym8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        635
        pass
        817
    total = value + len(text)
    if len('') > 0:
        460
        438
        _dead_4780 = 917
    return total

def _ююЧуГеыеΤЫвС():
    if 62 * 99 < 0:
        _dead_7891 = 852
        76
    value = 813916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxrQSEMx9581aCj3x3mILDUe53s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оТοЩШБВЖц():
    value = 332941
    text = __import__('base64').b64decode('VnpYV1hrTG9IeUx0eHFIc01veHc=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_2556 = 157
    total = value + len(text)
    if False and True:
        _dead_5590 = 282
    return total

def _ПЬгшюеШБЛЫуγΞ():
    value = 812900
    if False and True:
        pass
    text = __import__('base64').b64decode('Q19PVV8wQ0R2dTNicUs4Z3pGNkg=').decode('utf-8')
    if False and True:
        855
        _dead_5184 = 730
    total = value + len(text)
    return total

def _МЛНДЧкГв():
    if 4 * 71 < 0:
        _dead_9237 = 922
    value = 631772
    text = __import__('base64').b64decode('R0hHMWRINGRuX1V6M056ZEpSYVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦуЙрΧΑЕΛВηΥШэз():
    value = 341762
    text = __import__('base64').b64decode('RlZnTWMxQ1ZDM2pmbU9FYTdtVGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓχФκΟГИΓОяуЦДй():
    if len('') > 0:
        _dead_4555 = 849
        _dead_2756 = 293
    value = 278531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pze1YWMW9pcwEiKSxXu9Ij8Y7kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6108 = 920
    return total

def _ΣκкуНРΜσВΜζюΩг():
    value = 68133
    text = __import__('base64').b64decode('Q1haYWRHV3R4UWo3WFVFSFdQcmg=').decode('utf-8')
    total = value + len(text)
    return total

def _бГδУκИЫОηбΜЗ():
    value = 122941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L37lV3gM/ao3aRaO/FuTEBB4/Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗвыПФЛДλаГΞ():
    if 90 * 59 < 0:
        pass
    value = 685102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSrnfwM08r8zNzmAmWzFByMfvUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3553 = 861
        _dead_4968 = 139
        _dead_8233 = 586
    return total

def _хНаνεθуτΘ():
    value = 335071
    text = __import__('base64').b64decode('TFNZSUpmc1FyXzRLRUJscUM5NXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞωρдηνξЪГьςοу():
    value = 259649
    text = __import__('base64').b64decode('WE1LRXV2ajFfRk5PS0R1elpaWTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _СθшчΕπΞΧЭ():
    value = 967287
    if False and True:
        812
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH3UXwMy54cZOz6t7X6bEhY9wWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οБШΡоКШσм():
    value = 897944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx28a3s71JcoNx6tx16IYQcf3Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        275
        pass
    total = value + len(text)
    return total

def _ΤеЕεΝχΒСЗυУЮυ():
    value = 931460
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRnmSH0p5JxSHDqGnlDHY3At0Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иБтψδждОΘΩюΜα():
    value = 967008
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PST1X1QB2rIPA1e343W0LgYptGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 79 * 56 < 0:
        404
        pass
    total = value + len(text)
    if 89 * 79 < 0:
        20
    return total

def _иωφΓнпΕшЬИξΧΨΗшφ():
    if len('') > 0:
        pass
        pass
        pass
    value = 436773
    text = __import__('base64').b64decode('dEJkdjdtVnRxVW56NkUxTHdXSmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭуπлОΣхнамф():
    if False and True:
        646
    value = 185955
    text = __import__('base64').b64decode('QjFvR09NNUxZNVhjM1J3SnVfRTY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8707 = 795
        _dead_8971 = 506
        370
    return total

def _εжΔаσКЕΙоЧГωΛςς():
    value = 450565
    text = __import__('base64').b64decode('SDJ3X3dNaExkdUVjMHAwWWNFZWY=').decode('utf-8')
    total = value + len(text)
    return total

def _МЬωбηСαΦ():
    value = 23096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnbObVkV6PsIah7wxU+gPHcg4Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нςяγЛφΗПΟδΘ():
    if len('') > 0:
        _dead_9366 = 41
    value = 834509
    if len('') > 0:
        _dead_9838 = 952
        274
        pass
    text = __import__('base64').b64decode('TWNORDZWTWs1MkZJRklJbGFoQ0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛаηмгКчЦнП():
    value = 59865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQ3+YQIVxP5UEReT/wGoHyJ45k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 37 * 50 < 0:
        pass
        522
        162
    return total

def _ΖБнфΙφΩТλζ():
    if 49 * 4 < 0:
        _dead_2355 = 313
    value = 411075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ey3pYkUg84cXNAKb0lKgFhMY4Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 15 < 0:
        882
        pass
    total = value + len(text)
    if False and True:
        _dead_5554 = 584
        pass
    return total

def _ылГςьйцΕλΔВΦИ():
    value = 43752
    if False and True:
        706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSnQVncJ/LozCFn3/36xAhYG9Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нГПпдςΞДΡвЕ():
    value = 663715
    text = __import__('base64').b64decode('WlpJN0RmMXFCQ2o0a29xTTRNSmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖФтпйЪΤкЯЯу():
    if False and True:
        618
        pass
        577
    value = 960814
    text = __import__('base64').b64decode('dWJCVzFaWUNyU2Z0bGNpWmVKRGc=').decode('utf-8')
    total = value + len(text)
    return total

def _СыШтЕδξЫыΤЭыΨд():
    value = 322033
    text = __import__('base64').b64decode('aWVZRTFBV21GQ1JnVmZwcE5iRXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ρдеΛЩЫξкΣω():
    value = 985761
    text = __import__('base64').b64decode('ZEc2S2JySW5KTmxCR1pRWUZva28=').decode('utf-8')
    total = value + len(text)
    return total

def _НаючβоеΔжкНф():
    if 36 * 60 < 0:
        _dead_7460 = 828
        _dead_9451 = 789
    value = 984288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzXyZgMX7r5SbSX3mGTDY3YisG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 49 < 0:
        812
        _dead_5568 = 251
        608
    total = value + len(text)
    return total

def _ΖλΧУЕφВОΗ():
    value = 667480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx3nVFs49pJbHCOm2gPEDgwHvXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝЩзΠпЕΕΕ():
    value = 982051
    text = __import__('base64').b64decode('Vl9iRTRvb1R4bEJrNUNIalRWa0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑчΦхОЙзхАмλЫгΖес():
    value = 374571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ii7WZQEMyY4XYzyb2F++ZnAH73o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηСЩΕхиЛΓйГэΜοсП():
    value = 462180
    text = __import__('base64').b64decode('cWZ4UHZKQlJzUU1SMXBIOFVmMkg=').decode('utf-8')
    total = value + len(text)
    return total

def _УЩелтΗτШ():
    value = 494562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCLoawgO5p4aBRac/1udGREE4UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        678
        984
        pass
    return total

def _βΓйИδювНΥк():
    value = 885972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyL2ZgA+yPslNgG1zwGUFw9/0X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        359
        pass
        _dead_8293 = 717
    total = value + len(text)
    return total

def _ωοΜчελΘИЦΑшΗе():
    value = 626717
    text = __import__('base64').b64decode('TGViakZ5SHpZVDhxdnZyUXpYOUk=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЗЦАΒνЫпΔъТВΔИΠ():
    if len('') > 0:
        _dead_4665 = 369
        705
    value = 190658
    if False and True:
        pass
        708
    text = __import__('base64').b64decode('Q1NreklGVDFGWmNoX1RfWkFrYWQ=').decode('utf-8')
    if 83 * 29 < 0:
        _dead_7783 = 483
        pass
        349
    total = value + len(text)
    return total

def _ΟЕΦχΓслΓ():
    value = 971291
    text = __import__('base64').b64decode('T1BvV3ZrMDQ2elpvRDFRNDNmc1o=').decode('utf-8')
    total = value + len(text)
    return total

def _рКδψΤΔξеΜ():
    value = 773742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwjGb2ELr7xWOCiw7GObEnwO/lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 9 * 88 < 0:
        _dead_5057 = 929
        pass
        _dead_4850 = 892
    return total

def _ΟюΘΧЫзΗΩиβ():
    if 50 * 38 < 0:
        _dead_6852 = 895
    value = 316133
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXrsPAkv0qcyLzqb0gPGYn0Vs18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 47 * 29 < 0:
        pass
    return total

def _иΠΛЕφςмичΖΞ():
    if False and True:
        _dead_7352 = 417
        79
    value = 800619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwfIa0Yg350SIiCqzkGdZ3Uj9Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΓБУΨУмбЗ():
    value = 214931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwjFeFUDqKlQCzzz4AG3Bgl4w2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лγςεыХΕβЫЖие():
    value = 780716
    if False and True:
        pass
    text = __import__('base64').b64decode('cXlNZllkRzZrRUg3Mkh0ZG1fcjQ=').decode('utf-8')
    if False and True:
        _dead_5209 = 438
    total = value + len(text)
    return total

def _ρЭмКΨθΟξΞцαχ():
    value = 291843
    text = __import__('base64').b64decode('YnlRdTRuQmI3U1l1Vm80M2x6aUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥаοмВжθζφ():
    value = 125441
    text = __import__('base64').b64decode('V0dFaTBVN2xnck9lNGQ2UElGVFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ρцЫвХкγΒεΡονξΞ():
    value = 54076
    text = __import__('base64').b64decode('R2VyZlVkSDY0aU5uM05zRTlzRjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΠЮэнΖβΚΕ():
    if False and True:
        pass
    value = 86160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCLsZ2YX5rkaDwmwy3GoIXQOvEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТйзΕΗФΕΧ():
    value = 616606
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxzQRQEq67I8EBmkn2CvPjJ2t2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фмУшшωЭЮгψψЗЯ():
    value = 494321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgD0bAAI5oQOPhmEy0S7FgkB3Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 21 * 78 < 0:
        _dead_2725 = 616
        _dead_1352 = 503
    total = value + len(text)
    return total

def _ЧΓзυΕчОМФДηо():
    if False and True:
        pass
        246
    value = 613955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz/zb2EO9KoUAgCkxgC4ZnM+vWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓМυгδΓТσхθПψЕШф():
    value = 687633
    if len('') > 0:
        354
    text = __import__('base64').b64decode('c3huNzlWVF9tT0NCbTBmVW40M2o=').decode('utf-8')
    if False and True:
        pass
        _dead_5653 = 177
        390
    total = value + len(text)
    return total

def _δχПφΙМθΠЖσΛΑДЯУ():
    if 15 * 47 < 0:
        795
        374
        pass
    value = 104352
    text = __import__('base64').b64decode('ZEx5cHZqQnU0Y0ZVcGdqSTUxWko=').decode('utf-8')
    if 54 * 96 < 0:
        _dead_6410 = 523
    total = value + len(text)
    return total

def _ΜОБπдυνσΜПΦΙ():
    if False and True:
        _dead_8093 = 670
        _dead_2599 = 179
    value = 591447
    text = __import__('base64').b64decode('SjRNY0VvMWJaTHk5UXNhSVhYREQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ГЭоЪηθБζЭ():
    value = 434269
    text = __import__('base64').b64decode('VXJCelhva2JqUHo5Y2pkSUo5WE8=').decode('utf-8')
    total = value + len(text)
    return total

def _τавВЛΜЭЛлСхξ():
    value = 437496
    text = __import__('base64').b64decode('Q0gxYkxkaFcxcGZGY280VldGMHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЙςьρПΝνпΒΞв():
    value = 394358
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCPeSmgU7apaKSGb4XmRYSAWzjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6408 = 582
        pass
    total = value + len(text)
    return total

def _ДсΟтκδЛωй():
    value = 258075
    if False and True:
        _dead_9351 = 967
        _dead_7881 = 483
        _dead_9165 = 719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT21WnQIx4I2LyGp+HCdPCkLyFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        354
        pass
    total = value + len(text)
    return total

def _сЗДэΞуйμвоΚЯЖ():
    if False and True:
        pass
        pass
    value = 531704
    text = __import__('base64').b64decode('TGZJMHFhY21KRkdTSFphSmV1ejk=').decode('utf-8')
    total = value + len(text)
    return total

def _ДжΜГψηкъ():
    value = 676249
    text = __import__('base64').b64decode('b3NqTmlvQ1hyZ1RwOGhBWDNRVFM=').decode('utf-8')
    total = value + len(text)
    return total

def _πΤβшΒУАξх():
    value = 545444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQr8ZUQ97asaYyak3VfEBzQJyUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АлцΩНЦЧЕчЧхЬτяъ():
    if len('') > 0:
        _dead_3716 = 970
    value = 627478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PC7JQmltxPkGDB6BmV6/HnEH92k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞАΨдтЛфЭБУХЧ():
    value = 780653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BByyXUdg8p8Xblmqz1+eAXEs7Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫМγπЗВΗИъхцрЪеВК():
    if 46 * 92 < 0:
        pass
        pass
    value = 272539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EALhTVkd970PHTqRwlO1LSN9zHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕаΙλαхΞбЪи():
    value = 799563
    text = __import__('base64').b64decode('Z09UUWlwalM4dXZ3VjdaQ3BGMHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜЕвСλДЪэфκЯ():
    value = 981991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCDPb1VuxPw3GQzzwlSGLgYZ4F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 56 < 0:
        669
        265
        pass
    total = value + len(text)
    return total

def _сρгВэμЕлЪ():
    if 20 * 45 < 0:
        pass
        pass
        _dead_2848 = 866
    value = 423215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwroX1Yvwa4lNCqc/3yzOCE2zE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гρичыΗυЦχИΡμΦлυ():
    if len('') > 0:
        pass
        208
        783
    value = 54710
    text = __import__('base64').b64decode('ZlBueTg2OTZXaHhZQWc2UmhfOTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛгРоΤШяиУЬХΚ():
    if False and True:
        _dead_1432 = 469
        811
        pass
    value = 913902
    text = __import__('base64').b64decode('dml3aEhtb19QSGp1c1FHa2hOTmY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        829
    return total

def _ΔΔωйгнΜьрФямПг():
    value = 973515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRbMQmdurrA3FBy3yWXGGncY43g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _фФθшнΗЩБαПьК():
    value = 861236
    text = __import__('base64').b64decode('elA3Y0lFTmE1N2hXbTBZcjVFYVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ψτχΚежъЯΦυюэ():
    value = 360377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny39fkEf/KErOAGu306zLhYX/Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 44 < 0:
        _dead_8189 = 571
        pass
    total = value + len(text)
    if 12 * 64 < 0:
        _dead_3272 = 46
        _dead_7874 = 144
        295
    return total

def _ΔΨэАЫйвκЖυηΣЩδνщ():
    value = 434590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTrDWWsx2btVaT+p2UGSLnEj4lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вШУНαвСвъЭЛτяωт():
    value = 472473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhDNPXlt86UnYwaFyg6aBhApwEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΟФπЬηΨТ():
    value = 479765
    if len('') > 0:
        pass
        pass
        362
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAjKYF8b+KULGy6l0WW9bC8HvVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        416
    total = value + len(text)
    return total

def _БЭЦОЖσπσяКм():
    value = 850082
    text = __import__('base64').b64decode('bVpCRHhPOTNJN0tIcnhyWDhDTVE=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ФΖΗУэфΠАΒАаяОРΘ():
    value = 250866
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBrGegUQ7/1bEAGJylfGNz8Ny1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗнэЯффЬф():
    value = 936668
    if 85 * 12 < 0:
        pass
    text = __import__('base64').b64decode('UmVxTlFVcldNQ0g2cFpIUDQ1bEI=').decode('utf-8')
    total = value + len(text)
    return total

def _СиШκΒεаФТе():
    value = 159075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESXzagAg0vA3OTv79weyGSM8zHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        979
    return total

def _ЛеяγЖяψШ():
    if False and True:
        pass
    value = 468946
    text = __import__('base64').b64decode('UnNxOXBmTVlpU3ZkOTBWUkVXRTk=').decode('utf-8')
    total = value + len(text)
    return total

def _йеоφХΗκΩСЛ():
    value = 284750
    text = __import__('base64').b64decode('ZEdTbTh6UVBuRnNXMnVOeGNPYXc=').decode('utf-8')
    total = value + len(text)
    return total

def _аыεГιξЛЦ():
    value = 431592
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQnbSnMVyJI0YweVmFK4AQ8+01s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 11 * 3 < 0:
        489
        348
    total = value + len(text)
    return total

def _лЛτπлюΝςл():
    if 71 * 43 < 0:
        _dead_6840 = 419
        pass
        726
    value = 127281
    text = __import__('base64').b64decode('ZTR6aHlFbnV0Q2NxV0RiU1F6ZlQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ШЭуΑкМмВь():
    value = 685405
    text = __import__('base64').b64decode('WnE1S2FRMDNnV2VnRVlQMU1kTHM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9766 = 430
    return total

def _пиβЦЗνъμΛκο():
    value = 780582
    if 16 * 3 < 0:
        pass
        968
    text = __import__('base64').b64decode('cHRObGhZa2M0RkYzS0lfZWhtOFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΖνТΩуυυΝΨ():
    value = 747408
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITi8XHwS26MXawarynC3PRAVvEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βθБΝΠζсПШВДЪ():
    value = 68135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzzHO0Ng6v45a1qc8EW5G3c6y0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 45 < 0:
        pass
        703
        pass
    total = value + len(text)
    return total

def _кюДАηκιтАЮГμξэЧ():
    value = 303382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NizdPEMU/fkkLCP12EeREyAn0H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фПΩΓΘбειСИЫψ():
    if False and True:
        pass
        899
        _dead_7304 = 340
    value = 498052
    if False and True:
        188
    text = __import__('base64').b64decode('bG04bUFsRGYySnZZQVE2NUJyV3Q=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΛζюФэюΘСΖ():
    value = 744793
    if len('') > 0:
        _dead_8055 = 386
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lhm9ZFJs7IETMD/w/3W4OHc30GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 53 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _БЮЙчΥΞΝщУΒιеΠς():
    value = 143597
    if False and True:
        pass
    text = __import__('base64').b64decode('cmYyMGd5NHNHdDl4ejZ5WlJNSU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚДУαςшΕλОψΖтεΘТΣ():
    value = 300627
    text = __import__('base64').b64decode('V2Z0TGxJZmJCaG9WY1lHbzFSMkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ρςШАΚΩΠφΑ():
    if len('') > 0:
        560
        184
    value = 768862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NybUUVUI/bklHAunwHyeGC0I/Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖγбАγΔдЗΗΓщиΤПЦс():
    value = 933113
    text = __import__('base64').b64decode('R21OS2ZOc2ppc0JYTXN0OEtBOHA=').decode('utf-8')
    total = value + len(text)
    return total

def _фьΩιНжяИЦМΔИЯЦ():
    value = 657999
    if 79 * 25 < 0:
        17
        _dead_1695 = 609
        _dead_8487 = 156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj/yV30+7vEVDjuxnlqROAYV8ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _БоΒЮПЩΥТЦчε():
    value = 421157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwbMfmlr2o05Nh6c6g7DDT8/ymY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        127
        765
    total = value + len(text)
    return total

def _мΜСΠйщΝΑПиωщл():
    value = 28859
    if 29 * 47 < 0:
        _dead_8393 = 820
        _dead_7425 = 399
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQfWSGMY+ronNCKp2VTCHjEk1UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΣΘнЧшНПЦЫЭг():
    value = 900081
    text = __import__('base64').b64decode('dFM2SjFLRXRucWZNcUJobU1OUUY=').decode('utf-8')
    total = value + len(text)
    if 99 * 1 < 0:
        pass
        _dead_1535 = 815
    return total

def _ЛОощжρξΝИΩΒωφη():
    if False and True:
        495
        pass
    value = 623564
    text = __import__('base64').b64decode('eVN2RGlQOVBQS3RubG53Wmd4eHo=').decode('utf-8')
    total = value + len(text)
    if 12 * 53 < 0:
        _dead_6394 = 972
    return total

def _ΦУДΝΕΦΗБΙТυ():
    value = 432365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCrCXlYW+Ywzalfz6myYPQ4A7Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        286
    total = value + len(text)
    return total

def _лиΓОοΠлЕΖз():
    value = 491009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQ7DUQMe+Y5aMyS62l2WMDEH92I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪЮОуЕУдЩΡцШНн():
    if 64 * 6 < 0:
        _dead_1170 = 774
    value = 33541
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3/BewM7qvBRNBqQ0UDDYSYFzFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ймЗоГγиΠзυМθхΥΣ():
    value = 405252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRXiYXxuqYFVaCim2WSBPjUc0Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шеθΟщОΡЕМΧΧΕпО():
    value = 903459
    text = __import__('base64').b64decode('SG9hNlVTcEQ2dDdiT25ZVFdXcEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ДьΟыΑψπςπζояю():
    value = 415517
    if 75 * 83 < 0:
        473
        pass
        pass
    text = __import__('base64').b64decode('TWxMMmdhS2tHSm5BQ2p2alNBaFc=').decode('utf-8')
    if False and True:
        308
    total = value + len(text)
    return total

def _ЦнΒяДΑпэйоЬΟχΙΝ():
    if False and True:
        498
        657
    value = 56885
    text = __import__('base64').b64decode('dmt5eGl1MHd6a0E1RnlOaGxzMGY=').decode('utf-8')
    if False and True:
        _dead_3776 = 939
        pass
        _dead_8929 = 758
    total = value + len(text)
    return total

def _жχΗЗΛΠЖςΗМвЭвω():
    if False and True:
        _dead_6671 = 74
        _dead_2463 = 452
        pass
    value = 978512
    text = __import__('base64').b64decode('UUh6a2dYM2NsY1VVY3FidHFacVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭяЙРМУуΜπуεΒшφ():
    value = 719909
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BATINkRr5I8BMSmx/n3GZXQk/Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΗκрЫКУзβщ():
    value = 90668
    text = __import__('base64').b64decode('dGtxbGxvdU01QUNHbHdSNGVMemE=').decode('utf-8')
    total = value + len(text)
    return total

def _τифсэγειбКгΖцчЫД():
    value = 296262
    text = __import__('base64').b64decode('cXdQaFdzaXhnS0JnbmczTzkzbkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΣттΝΘΖγΦУжЮЧпНΠ():
    value = 450950
    text = __import__('base64').b64decode('Z2ZVdk1EdFozNmd4c1hhSkdmWWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕυεΕπΧφΠхΤрξεйиы():
    value = 946142
    text = __import__('base64').b64decode('TlpTbW1sMzlLNjBWc1E2MlhYWXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦэσПΚЯКУγЕ():
    value = 648146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3jlPV023/okBR3x6mOmJR8KtF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧзφЭФΚκгксюЛужа():
    if False and True:
        _dead_9208 = 192
        _dead_4629 = 539
        pass
    value = 114583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyPlZWls+YsbaQT74nzJBCE2/Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8064 = 88
        331
    total = value + len(text)
    if False and True:
        pass
        727
        701
    return total

def _СδаЫΕэςω():
    if len('') > 0:
        pass
        pass
    value = 545275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAexRmgr2bwNElqG4nG5Z3UrvHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _иЗΠуλЪВνΡζЛλ():
    value = 602279
    text = __import__('base64').b64decode('RkhfNEV6NjQyOTBDME1PaVpremk=').decode('utf-8')
    if 67 * 95 < 0:
        pass
        _dead_8899 = 758
        pass
    total = value + len(text)
    return total

def _ΓγφσρИαДΛΥбΖΕΠΥ():
    if 46 * 9 < 0:
        _dead_3275 = 685
    value = 654013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px3ra2so3aI6Yz/1zVWePwse1Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φДΦщуΦЭμεйΑрГИУЛ():
    value = 43662
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgDyO2Me0YAgMQiR42bJNhohvHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КυТΔΡжЖН():
    value = 258640
    text = __import__('base64').b64decode('cUsxTjZ5NmtFVl9MXzRnZGgzUjk=').decode('utf-8')
    total = value + len(text)
    return total

def _сΣδЯςΩмлΘΑЯ():
    value = 620614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnfJRXYXqbgqY1vywk+qDQ8it08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4060 = 775
        _dead_1585 = 638
        _dead_9973 = 477
    total = value + len(text)
    return total

def _ΛЖВηЭпΑщΣхЪ():
    value = 536788
    if len('') > 0:
        750
        687
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCfoaH4A5K0UFg6n/2WgEAsc/TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8694 = 348
        pass
        pass
    total = value + len(text)
    return total

def _θЫиккчΘηН():
    if False and True:
        pass
        108
    value = 874859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AA6yVlk09KJWMwu67kCFJg8o/n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1122 = 252
        pass
    total = value + len(text)
    return total

def _νвкμψζкΣγχт():
    value = 534572
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iw3ybGgy665QBRiP7kWgJh0m7Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 55 < 0:
        799
        136
        _dead_6121 = 384
    total = value + len(text)
    return total

def _οψσлγМιиΕХ():
    value = 566606
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgHie1MJ1qs7LzDxmGS5YTQ/ylg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 66 * 52 < 0:
        96
    total = value + len(text)
    if 26 * 46 < 0:
        _dead_8642 = 644
        _dead_9965 = 381
        927
    return total

def _КΗψΕбыоχΔаи():
    value = 869403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwPgb30TxvsBHAKG8UTEJCI+6kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔРжθЙβДШδΠ():
    value = 130384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwLRP0sJ2YkGCi717EKcISAo9VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιюΠΤΞцшτξΜ():
    if False and True:
        _dead_1576 = 362
    value = 493982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3rsTXoNxIkyOQqAzk+7Pnd/0WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        279
        _dead_3936 = 963
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if 34 * 12 < 0:
        pass
        _dead_1676 = 609
        830
    print(__import__('base64').b64decode('dA==').decode('utf-8'))
if len('xx') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    301