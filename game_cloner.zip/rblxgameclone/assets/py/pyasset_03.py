#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _яχпМЭφΩκΗΡΤυΖΖбо():
    if False and True:
        89
        pass
    value = 489923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByDGREIBrasUFyLxn3ukMDQl0Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        415
        335
        550
    return total

def _ΙЫπςЯЦτькΩкθΧΞγ():
    value = 749613
    text = __import__('base64').b64decode('azl0c2NObzFsSFBnZmNMb21JR0c=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΘоПλΤνΡюеЯ():
    value = 415503
    text = __import__('base64').b64decode('WjZzVlI5b0hqSDlta2wzaEdVOE8=').decode('utf-8')
    if False and True:
        _dead_1094 = 297
        _dead_7982 = 421
    total = value + len(text)
    if False and True:
        _dead_6457 = 563
        pass
        pass
    return total

def _σΩеЩФψΔΡнПцож():
    value = 251793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxrdbUI177snPzWTylmTDiAh4jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФУЩρшппΥΞлΨитНΙ():
    if 34 * 18 < 0:
        _dead_3804 = 63
        pass
    value = 112889
    text = __import__('base64').b64decode('Zm1zd2F5Z0NTZFFKV1llcnVnSUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЙйчХΦаыνδΦФЛчй():
    value = 585137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBntTAJt5r8LDQqTxgaqJA8c518='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚВΚЪξгШхΜφяаΒςГ():
    value = 23182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyjAYlk+zaoCKCaTz2ehEz8a6UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        572
    total = value + len(text)
    return total

def _КонΜюЫЕπλщΨАьл():
    value = 767541
    text = __import__('base64').b64decode('dVczUlU5WW9nd2xhZHNuSkRhdGk=').decode('utf-8')
    total = value + len(text)
    return total

def _РМΒЦβЕнмЭΟφΟОтц():
    value = 55494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnnMeWcpxK8LKg2s7FjHBxAd0X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γτΓγСХΤΥιμΤφ():
    value = 524249
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTe1SAka7Z4ma1uR4luGIi82xzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οыКΧЖКБх():
    value = 852783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiDeamBg/605Ij6h+Ea+FiE+7kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7431 = 923
        _dead_1639 = 996
    return total

def _ΞΟщчΕοшйαмф():
    value = 798887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSXQOmkS2rA2OB6i6XPDNw98wlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΙЛЬΠЙсВ():
    value = 839624
    text = __import__('base64').b64decode('WnpRdHlQTFJKVFNkMEI4V3lCbjA=').decode('utf-8')
    if 43 * 40 < 0:
        243
        _dead_3972 = 998
        738
    total = value + len(text)
    return total

def _ΚщцСЦψνпр():
    value = 999216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxnSaGIJ0rBbExel8FCTGwJ58jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 44 * 46 < 0:
        162
        pass
        pass
    total = value + len(text)
    if 19 * 48 < 0:
        656
    return total

def _СψВеΨωΕЧСжлωЪ():
    value = 306644
    text = __import__('base64').b64decode('T1RGRXFRdGhodlYwS1l6aGkyVEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΞуηπΒγΟΝщΓΩΠΚтΘ():
    value = 492390
    text = __import__('base64').b64decode('b0tNSVlFc3V3QTJYRkVtYlEzaUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΕЧсыШΚΘεЭМζЦт():
    value = 899636
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDXlN0sYyP8TYimb/1+gIAA8xUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИУцΣХхБяφΤЕΥΚХ():
    value = 639533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR/PZFc2p4QAEwWbmUyFHC4F7lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МюξПТЛΞУдΤ():
    value = 478293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NH7iRQcQ9J85NgyNxF2qERcL9lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        352
    return total

def _υлКξшΤУΞЯκ():
    if len('') > 0:
        785
    value = 646493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiXwQH8eprwCKzqanmeUPhQ7/T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 6 * 21 < 0:
        pass
        875
    return total

def _ЕΝЩЕΦθΞчΝΖЫцуж():
    value = 87391
    text = __import__('base64').b64decode('c2gyeWhDbm1Cel9YU0pxQ2xyczE=').decode('utf-8')
    total = value + len(text)
    return total

def _фρΡυКАИэыМμР():
    if len('') > 0:
        _dead_9806 = 14
        867
        _dead_1650 = 542
    value = 531714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHrbamAt87wqO16hmF2dZ30Z10o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΞΡЛпεΞч():
    value = 901765
    text = __import__('base64').b64decode('QXRUbmtLQ2VObHJvU3hzbVNTUXg=').decode('utf-8')
    if 70 * 62 < 0:
        pass
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        689
    return total

def _βСЪСονρα():
    value = 437060
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MC7yfAUc5KM7BQi0mUa9GCo6/TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЫОйΧрШл():
    value = 272308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhjJfkIY1aoHKx+m/3m3Zw8M4GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΗзЩщЖξхκжΝАγЧд():
    value = 910374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FA71ZGE8qLEsDAiL6VKbE30s1z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωДλЛοΚоΨм():
    value = 510055
    text = __import__('base64').b64decode('Y2FSMzZKUVB1TE1xbVlES19RUk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ОЦМжΠыЖπφΘпГ():
    value = 513794
    if 89 * 47 < 0:
        pass
        _dead_7251 = 250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiL8ZX5tx60aNTv0kESxIzQr3W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЗΗВЬηЦξΘЗ():
    value = 519300
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA3bYQQQ/YcBFCuuy3ipJj0k3To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПмΙθВФъζΨЛв():
    value = 720881
    if False and True:
        _dead_6054 = 319
        657
        49
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQDxRAk70LEUFCux33KeLBF2yG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8245 = 947
        862
    total = value + len(text)
    return total

def _χιιςэлЯΨа():
    value = 122055
    text = __import__('base64').b64decode('TGxSNDBjYU84UVVPdDMyRjYycWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤоЭΞΗςΔχΛггμЖАРй():
    value = 43027
    text = __import__('base64').b64decode('Ujk3elpoaUI5SFM5V3hsSE9UMU0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        366
        pass
        _dead_1950 = 949
    return total

def _ηκЩАΜАψЪοΔεЭΨСΦι():
    value = 369211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NC7yZwE18YMHPB+l0H2zBiQltXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιΣδочωИэЮВ():
    value = 498656
    if False and True:
        396
        pass
        _dead_5882 = 162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBvlRElozbEADAWUzgC6HHB21F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 82 < 0:
        _dead_4834 = 12
    total = value + len(text)
    if 27 * 82 < 0:
        _dead_1994 = 338
        674
    return total

def _οψΖАуДкоΦгЮ():
    if 10 * 60 < 0:
        _dead_7123 = 548
        pass
    value = 554495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH31Xllh7KUIaDqzxFuABhIF4W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙςшБΤοчОφБΔизΩдС():
    value = 475449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzXJZQUr349UFlysnkKUZz8Qz3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΣΓфйБΑнΖπфЗ():
    value = 820688
    text = __import__('base64').b64decode('WHdXM2t4NGZ4WHJDZzJfbnFYZlY=').decode('utf-8')
    total = value + len(text)
    return total

def _αθαЖРτЯтжωГυΡΜ():
    value = 253238
    text = __import__('base64').b64decode('WlF5NnBESEZKZ3RVZFlJVzRSMHI=').decode('utf-8')
    total = value + len(text)
    return total

def _АοВγоХуΩХевщОвй():
    value = 613837
    text = __import__('base64').b64decode('QlNzYUY5Y2E4bER0NHQ0Z0Q4QTE=').decode('utf-8')
    total = value + len(text)
    return total

def _унИвΛЧПвП():
    if len('') > 0:
        _dead_7790 = 94
        pass
        _dead_2448 = 868
    value = 101225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISHya1QXq/0aHjCA+1ebHAgssDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        906
        _dead_3144 = 37
    total = value + len(text)
    if 56 * 99 < 0:
        970
        _dead_5799 = 594
    return total

def _ΨПΕηчйкСнФЕΧБ():
    value = 223090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSTGdnlu9Z0RaSSi8GKRYDUI1jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗрюνΔЭΗθ():
    if False and True:
        _dead_3991 = 440
        905
        178
    value = 95453
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cgjrd0kz+7pSPQiTx2avGiIfy1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 95 * 56 < 0:
        pass
        689
    return total

def _ЭУРθйΧАъйφψΔ():
    value = 757888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxXuSVQMzoQoNCCF0EG2PnZ7vWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        927
        546
        477
    total = value + len(text)
    return total

def _МьСΥζЦхГлЩЧ():
    value = 549083
    text = __import__('base64').b64decode('QkVlN3JJX0FGZlBHaUVEcVk4Nmk=').decode('utf-8')
    total = value + len(text)
    return total

def _σΑТЬЬвРбρцΛηΨΤ():
    value = 414294
    text = __import__('base64').b64decode('cnUwR1hfMmUxWXo1eUJFMWNjcGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯмДЛΞШХЖНΑ():
    value = 835173
    text = __import__('base64').b64decode('ZWkzV01rSldlOU4xYmtjdmszcXk=').decode('utf-8')
    if len('') > 0:
        _dead_3332 = 433
    total = value + len(text)
    if len('') > 0:
        _dead_1114 = 433
        _dead_1086 = 767
    return total

def _кΖεχΦμеΦдρ():
    value = 244431
    text = __import__('base64').b64decode('Q3oxRXkwVmZLRFVEeGJMQzJ3Z24=').decode('utf-8')
    total = value + len(text)
    return total

def _λБΥЧъкδσьΑς():
    value = 804743
    if False and True:
        698
        253
        pass
    text = __import__('base64').b64decode('eGNhZVN6VXZVcnFFZklod0hCMjM=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЪПуΠΡОпгиРуμΘη():
    value = 18216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH/cPWk0wakqDQO040ycC3019G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΖувΞЧΣь():
    value = 854020
    text = __import__('base64').b64decode('REdnRG5jUmZsOGNieW01c0R4dDU=').decode('utf-8')
    if 63 * 88 < 0:
        _dead_1810 = 140
        pass
    total = value + len(text)
    if False and True:
        202
        _dead_5336 = 651
        _dead_3496 = 88
    return total

def _гψжАΗвкμеШБ():
    if 9 * 69 < 0:
        _dead_9341 = 149
    value = 630022
    text = __import__('base64').b64decode('QXBadHE4aWJhT3FiMzJzcDN2SFE=').decode('utf-8')
    total = value + len(text)
    return total

def _хЫΘΙнЦΚсхчпхп():
    if len('') > 0:
        pass
    value = 495017
    if len('') > 0:
        752
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxfSZlU76IcyOAer7mzCIXQMwE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПдГЪБяΡъИс():
    value = 180991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQa2PWRt24YZbAav7lmhBCsNzVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΨбΙυьсοзΩΙГΠθ():
    value = 529360
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhnQQXlu1pJTAxy03FyDAxF/7Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦъυкФщЦеДΚоа():
    value = 720638
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('Y09JdzlkU05pMVptV0IwNXRzWVY=').decode('utf-8')
    if 74 * 24 < 0:
        _dead_7263 = 596
        _dead_9690 = 657
    total = value + len(text)
    return total

def _бЯΥвΖиеξφПΣς():
    if 53 * 32 < 0:
        _dead_7529 = 500
        268
    value = 181547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh7UfkUOyb4KESqN5364ZykIvF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΧγΜΡσюΤΚшΓо():
    value = 829068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyjHWFQh3ZEKHASm8GWaJggew0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗщΗΗγИШкЗУτпч():
    value = 270937
    text = __import__('base64').b64decode('SjRlN2lOSXBVeFFydm1sVmxwSVY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1707 = 362
        _dead_9373 = 830
    return total

def _ШχβπзИцрζΓАτ():
    value = 386443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyW2aVoM2oAkFCyv/FOHDSx50mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПξβЩЦΕКъЫЬэБδИ():
    value = 667159
    text = __import__('base64').b64decode('eTRFbkxTZnJVWHJBSE1TcFJLUGU=').decode('utf-8')
    total = value + len(text)
    return total

def _чШбйΖοΤυαэА():
    value = 435716
    text = __import__('base64').b64decode('YUZoSDlWQVB6eUhhbFRnbUlPV0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ХЫнНΨэчи():
    value = 891951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzjDfAQvy5EmKjv35nSCGAh7xmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дξΦкцνОЪρΝυψрΣχц():
    value = 974359
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhfleV4W/IQzNgysmWm5GT0qzD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _псγΤсЙγμПЧпяыА():
    value = 934987
    text = __import__('base64').b64decode('SHFKSE1qTTRnN3RjMVlHTUtnNFI=').decode('utf-8')
    if 4 * 74 < 0:
        _dead_5334 = 580
    total = value + len(text)
    return total

def _пЧЬЖЩчλψяК():
    if False and True:
        pass
        _dead_2769 = 167
        _dead_6787 = 782
    value = 233154
    if False and True:
        _dead_8836 = 108
        625
        347
    text = __import__('base64').b64decode('WXZhbmo1T0dNUzg4WnFVSHRjWW8=').decode('utf-8')
    if 68 * 94 < 0:
        pass
        335
    total = value + len(text)
    return total

def _θΗΣΦХΤЧЗδΤ():
    value = 281492
    text = __import__('base64').b64decode('cGJPdXZyZF9qZlJEQndENWNCS1I=').decode('utf-8')
    total = value + len(text)
    return total

def _юеЗΡИЗζΚт():
    value = 328186
    text = __import__('base64').b64decode('S2NwVGViMTcxX3JzU0pISHpDRUg=').decode('utf-8')
    total = value + len(text)
    return total

def _νΑнуωφΓΔ():
    value = 149474
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAXtZAAp6bk2EQOg4XSvGgx71D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1694 = 626
    return total

def _ЙсζΧвчлΨΔЭРс():
    value = 638182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Di7bXFcJzP0tNli66WSyPT8nwHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УπТΞΚθΧИΝщκьΜУу():
    value = 12139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATvJekMw0a1QGD2Z72abLgIJy0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъмвМЭЗЫПΚΡβΖ():
    value = 63585
    text = __import__('base64').b64decode('dFVkMDRpSlpsRGh0c1hUbXN0WVg=').decode('utf-8')
    if 47 * 81 < 0:
        490
        _dead_2824 = 82
    total = value + len(text)
    if len('') > 0:
        880
    return total

def _τФυЬοΗЮΠЬ():
    if False and True:
        _dead_1918 = 569
    value = 990639
    if False and True:
        pass
        163
        472
    text = __import__('base64').b64decode('andaNWpabTNaRzVGNGJOUHhleUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ГкβЪнψχтАΙе():
    value = 68767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX/ybQNt07g8DyKx3Ee0bT0o6zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЗыηΤТЙьγΠЙЪπν():
    value = 221622
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ay3hYUUvzIMuIA2MmFqAETV7x08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 78 * 79 < 0:
        pass
        _dead_2209 = 888
        _dead_5128 = 428
    return total

def _υЖФьΑΝαэМΔβηвЖ():
    value = 156416
    text = __import__('base64').b64decode('dXdLNWJkRTN1MFdGR0U3eVFxTHo=').decode('utf-8')
    total = value + len(text)
    return total

def _μнσανΤбТ():
    if len('') > 0:
        pass
    value = 772913
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MArzRGs17vsibBuG/FqcbQQe6Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яАςΚКΜΞДΙэЬЭωЕРΧ():
    value = 654632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET7rNlAT+LgybC6y3H7CPS8uw28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κщΙΗЩυАЕХъΦνЧию():
    value = 672988
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSLWPXw1ro8XHQe06QeYJQQavDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΥеεМэЬσ():
    value = 268718
    text = __import__('base64').b64decode('UmVXbzgxM1RuTDEyNDNPbFNoSTY=').decode('utf-8')
    if 22 * 85 < 0:
        _dead_8293 = 980
        926
    total = value + len(text)
    return total

def _ЙζΝзЬеИщЗΘΘΝЗ():
    value = 900351
    text = __import__('base64').b64decode('THhpRFhmd1RCemQ4YjlhYW4za1U=').decode('utf-8')
    if 74 * 66 < 0:
        pass
    total = value + len(text)
    if 91 * 28 < 0:
        _dead_5317 = 168
        pass
        _dead_8830 = 846
    return total

def _БРЬТШΛκж():
    value = 349025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSTKbV0ur4EOYl23mUCEBgAO/nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2671 = 851
    total = value + len(text)
    return total

def _ПΗчЫфαкаφЩ():
    if len('') > 0:
        pass
        pass
        771
    value = 868265
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHbxOQM4x7tUFgqT/WWcPyk7yUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΚξцКεЗΨ():
    value = 843115
    text = __import__('base64').b64decode('aUNHcVZyRnY0bXNwY0xCWGU0RnU=').decode('utf-8')
    total = value + len(text)
    return total

def _чцхφΘΒΜЖλιйμ():
    if False and True:
        65
        221
        _dead_5923 = 64
    value = 329695
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSTtOlwhqpkHaBm57FG9Bj8n418='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΓαАевσТΠиТвΗхψ():
    if len('') > 0:
        _dead_4533 = 403
    value = 855043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARjoSlQj0qALKDu2/wPJYHUb40I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιвμηВгηЯХЖο():
    value = 479729
    text = __import__('base64').b64decode('RUo5UUFhTVJ2T1QyY2VTU2tEWFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЦхуеΤΜΨζΗЫМΛпΘ():
    value = 289652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3vHUUU7qKAzMR613GOAPAAEtnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        547
    total = value + len(text)
    return total

def _νеЮэЭχβΦыφΠΤΖ():
    value = 530708
    if False and True:
        _dead_7454 = 460
        pass
        pass
    text = __import__('base64').b64decode('bVU2QzQwaldsWE5NT1NpYzBaaFo=').decode('utf-8')
    if len('') > 0:
        _dead_3694 = 668
        317
    total = value + len(text)
    if 62 * 56 < 0:
        _dead_6430 = 541
        pass
    return total

def _ХδпЕσςΛыΟтжчΕБэВ():
    value = 710823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgbRflo9wYoyDgqhz2S7IxcOynw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νБΣΠНΘЬОΗ():
    value = 542033
    text = __import__('base64').b64decode('Tl9FZWg0MVZrMXE4Tl9tVnJtSjU=').decode('utf-8')
    total = value + len(text)
    if 47 * 40 < 0:
        75
    return total

def _аΕцψυКΤθγΣщωαБ():
    value = 883037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnrVY1Ic370IYyu1yXqpFiMktHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧσЛшсЫюэπЪЪ():
    value = 187670
    if False and True:
        _dead_1126 = 883
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxuzeAcd6KMJAwig4ACWMC4g6lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5999 = 178
        pass
        899
    return total

def _ьΝНЧыиΖЗОЗщэ():
    value = 269205
    text = __import__('base64').b64decode('SlhOblBHVDNqWkJFeXBNV2FKWU8=').decode('utf-8')
    total = value + len(text)
    return total

def _οэКуΥΖΗъφ():
    value = 789953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgXzUVQY8qQJETyJ2nWVMiccx2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 20 * 10 < 0:
        _dead_8185 = 228
        768
    total = value + len(text)
    if False and True:
        pass
        770
    return total

def _фΒЗиοлэΖЭнσхΤУδ():
    value = 967354
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB2yZ0IKy6VWCTmq3VWXDCc96ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧγРиγπιВιχψмπ():
    value = 500463
    text = __import__('base64').b64decode('a21Yc1pqUmZUNFNVeDZPaEg5bDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ТЗхπΗηΒЬЛ():
    value = 234190
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDzLPGc/x60NGx2M+n+yMR8W00E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4581 = 254
    return total

def _ΔАΠаπхΒВРЩЖУΨΝ():
    if 69 * 25 < 0:
        _dead_4290 = 606
        pass
        pass
    value = 844185
    text = __import__('base64').b64decode('dDhJTk96TjUzVWNTcDJPaTJUSUQ=').decode('utf-8')
    if 12 * 89 < 0:
        _dead_4830 = 448
        575
        455
    total = value + len(text)
    return total

def _ъНεΔьτδΦег():
    value = 824243
    text = __import__('base64').b64decode('eDZMaXczYVdFSEx1VTl6RTRyMlI=').decode('utf-8')
    total = value + len(text)
    return total

def _φсГνэЫдβΡщвнаΥцд():
    if len('') > 0:
        970
        pass
        338
    value = 80088
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('U1YzeV9TXzVFbkNhbkp2SkdWeFM=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4308 = 414
        pass
    total = value + len(text)
    if 21 * 27 < 0:
        pass
        pass
    return total

def _КсλеПαγоΧΛ():
    if len('') > 0:
        _dead_8467 = 456
        _dead_1576 = 104
        pass
    value = 724230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiLTdkYP7p4TLyuI3kSxFgMk/E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нкЙРΩВψзΤΟσлУоΑа():
    if len('') > 0:
        pass
        _dead_9992 = 133
        pass
    value = 1039
    text = __import__('base64').b64decode('b1Rhd0Fkb0tLMnpxbHhBYjkzb3Q=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2026 = 160
        pass
        pass
    return total

def _ЖΖνНШНКДΗЮб():
    value = 584088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAfeXFABqqVUHxmT8F6CCwY151s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥЦПоρфжΜθсθФ():
    value = 776055
    if 75 * 50 < 0:
        922
        457
        _dead_5115 = 931
    text = __import__('base64').b64decode('VGxXN3psV29QQmM0ZWVXM2d3UlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩтЭιрζыΔσэЯОуσΝЛ():
    value = 959369
    if len('') > 0:
        _dead_4266 = 745
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS7WS14N+bAyNT+5+k6RLiwJ90Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζЦψιьэЧΛЯμς():
    value = 897910
    text = __import__('base64').b64decode('S1lsVnJ3UlZTajR6RjJQdUNYSmo=').decode('utf-8')
    total = value + len(text)
    return total

def _бεЛмМΩЦΣА():
    value = 934121
    text = __import__('base64').b64decode('c0RCd2U5bmRnSXRxWWxMRjFScjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _РХδμВдЧЯξδФцаЮΙЖ():
    if len('') > 0:
        pass
    value = 859224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCrqaVMJ250BIwmW5HW0YR93yzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 21 * 4 < 0:
        740
        464
        pass
    return total

def _ИФЯΙαбφмςеЩР():
    value = 257179
    text = __import__('base64').b64decode('cHRSZVU3VThLaWUzN3dXNUNfVVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜШαЬΗΦΑЮьξщ():
    value = 379375
    text = __import__('base64').b64decode('a3llSVE2b2JCUGV6Y0JKOHBRQXo=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4959 = 949
        990
    total = value + len(text)
    return total

def _ФΤщЭΑЖзηΔ():
    value = 858009
    text = __import__('base64').b64decode('SXVOZlY5UDRFZVFwcEIyN1RpVXk=').decode('utf-8')
    total = value + len(text)
    if 56 * 52 < 0:
        _dead_4506 = 767
    return total

def _ΙдяЭοΠψМиЛыυΖμП():
    value = 687414
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxqyZEcK7ZAQLCiw0nG8HDYexU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΝкΔΞдйИΠυпБ():
    if len('') > 0:
        _dead_8328 = 347
        _dead_1834 = 384
        203
    value = 61637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDrcfgIs1LotID366keaEHF56Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮУςΩπЫγΒΑсфΜκ():
    value = 399379
    if False and True:
        pass
        804
    text = __import__('base64').b64decode('UEt3WkJpZlNTQV8yRGc1YlBxUnM=').decode('utf-8')
    if 42 * 48 < 0:
        pass
    total = value + len(text)
    return total

def _хΩθэхеλЩΣа():
    value = 475104
    text = __import__('base64').b64decode('WUpEZ1BPNnlXTjlTalY0WldpNHE=').decode('utf-8')
    if len('') > 0:
        pass
        508
    total = value + len(text)
    return total

def _ξЕεожγтжЦЩОκ():
    value = 235806
    text = __import__('base64').b64decode('VkhfRzZXUkZTVzVYR184aVhqYmc=').decode('utf-8')
    if False and True:
        _dead_9281 = 431
    total = value + len(text)
    if len('') > 0:
        552
    return total

def _зКΦПΑысспЩΡЕΛд():
    value = 235055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyvyP3YA5rAJPQiK3X6HHwIOx1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8803 = 891
        _dead_2783 = 947
    total = value + len(text)
    if 90 * 28 < 0:
        890
    return total

def _ПΙХуβΒЭψД():
    value = 618845
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwrFVlNq3/82Ih+B43KjPHUC9D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΔбеюЙЬКρъуэΤωο():
    value = 491726
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQHnTQgv96wlEzCvx0TFLDIGsXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 23 * 50 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 74 * 16 < 0:
    743