#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ζбΦцнΛчμЬ():
    value = 617946
    text = __import__('base64').b64decode('dzNVYVEweGhZVWN6RWhkdW5odVg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_8454 = 241
    return total

def _ΨрψυμщκΠΦ():
    value = 596841
    if 33 * 99 < 0:
        _dead_8044 = 629
        485
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kg3AaEE66oQlHzih8lWfFxYlvT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕчШΗωшλΡΟυсЮш():
    if len('') > 0:
        952
        852
        _dead_6022 = 436
    value = 339511
    text = __import__('base64').b64decode('Z3YzM3ZrSG1lOHJEc0FSaGFJQTM=').decode('utf-8')
    total = value + len(text)
    return total

def _πЗΒηλκцΦΜΣσКШФ():
    value = 81897
    text = __import__('base64').b64decode('dkFSRTN6bUUwNE1wQ1Njd0VveEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞыТЪΙсβдΘσЫ():
    if 56 * 45 < 0:
        724
    value = 974137
    if len('') > 0:
        pass
        _dead_2573 = 236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N33IW2I316QHAy67znDBLicq528='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔвПгзХрЬε():
    value = 518567
    if False and True:
        786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jj7uXAgRp6woGSWEx3i6FwsY1mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞζυБжΑαыΤЯВΥюЙ():
    value = 370464
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCbrOW4e3J0mEwyT7geyGxIo5mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮцσзМχΨуοσп():
    value = 892830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DB/PbQMU2btTMl264le0Zw5340M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        389
    total = value + len(text)
    return total

def _йχОΧΨΞΔЩШ():
    value = 607584
    text = __import__('base64').b64decode('TGdXUHNIUmFDRHFlbU50NTQydW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ъэгшΧνЫТеΤΝБ():
    value = 522414
    if False and True:
        pass
        171
    text = __import__('base64').b64decode('cjRxNVo3TXJQNVpqU3lZS244aF8=').decode('utf-8')
    total = value + len(text)
    if 82 * 52 < 0:
        _dead_2936 = 987
        pass
    return total

def _οЮψФРΠπλ():
    value = 402778
    text = __import__('base64').b64decode('eHJ2SmVOVjNQUmNHalRIRlR2Z1k=').decode('utf-8')
    total = value + len(text)
    return total

def _σΠΠЩВхΡςНдτΖΩ():
    value = 360355
    text = __import__('base64').b64decode('TjJfb1JjZHB2TnRSRnVCZEtfN3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΖτэУηΔκЭΗоκщ():
    value = 329588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kwz8OX8Y1fFbFF6G/2WmAxF28Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 38 * 15 < 0:
        _dead_2089 = 91
        _dead_6882 = 450
    total = value + len(text)
    return total

def _εαΑмпΨМв():
    value = 136449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3zePgkT1KwEFD+bmAbABj0jxUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 16 < 0:
        pass
        pass
        128
    total = value + len(text)
    return total

def _ΧμыШшτΔтοψюЩк():
    value = 111985
    text = __import__('base64').b64decode('aUxGTkl1WDhPaWN4M2FLQngycng=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔГННдξоπпУβηУ():
    if len('') > 0:
        735
        pass
    value = 361024
    if False and True:
        935
        pass
        _dead_3881 = 478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DC3FYAUI7bBaDVmNw0+8AgAaw0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        409
    total = value + len(text)
    return total

def _ЖЫτРΝЫΒоРоυШψфТШ():
    if len('') > 0:
        _dead_4897 = 123
    value = 612541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kij0dl5p958GAg2Inm/ENXUu6GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΚΒεВУΘцΞдзΞ():
    value = 410583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAHiVFQOprA2BSLw4VmVIHEpsWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йсггтмςΚжπкιИ():
    value = 218286
    text = __import__('base64').b64decode('T1pXb1A0VllDa2lCSFdqOXU1VHo=').decode('utf-8')
    if False and True:
        _dead_8699 = 22
        _dead_7473 = 739
    total = value + len(text)
    if 100 * 80 < 0:
        306
        162
        _dead_8165 = 575
    return total

def _щυΡшτΚСкувΟЮκ():
    value = 667686
    text = __import__('base64').b64decode('UnBPb3duWWRqX0FyM3JjOVE1RkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ыκξΕеПΩтКН():
    value = 601418
    text = __import__('base64').b64decode('Z01yTXNrbzk2TGszWmxqb0VlU1U=').decode('utf-8')
    if 57 * 26 < 0:
        _dead_9090 = 89
    total = value + len(text)
    if 53 * 50 < 0:
        _dead_2682 = 378
        pass
    return total

def _гИжθЧАΕσΑчρТςμБТ():
    value = 738805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQPWQGUX6vAsL1yMw1WXFT8rt38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡызλоЦΛшρд():
    value = 988213
    if False and True:
        _dead_8412 = 59
        714
        728
    text = __import__('base64').b64decode('RlF3cFR2MzBkb2M5MDVEWVJmQms=').decode('utf-8')
    total = value + len(text)
    if 34 * 79 < 0:
        195
    return total

def _ιυΟοЮЙλХζМθψψа():
    value = 808995
    if False and True:
        477
    text = __import__('base64').b64decode('VHk0c0pXeGxSZnBjRGhjc21RVFg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4625 = 771
        pass
        pass
    return total

def _УЦУТМЫеωЩφ():
    value = 798917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgL+aWkD9LwRAyKowlW1ZDx50kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        189
    total = value + len(text)
    if False and True:
        _dead_3363 = 80
        478
        706
    return total

def _ΤОЩΞμζчΞν():
    value = 627525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgbUaHoXprwtOC2n2VSHEgAk1Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кμЖЫБСЩЗПъаΨВςΠ():
    value = 901906
    if len('') > 0:
        _dead_3042 = 295
        pass
        187
    text = __import__('base64').b64decode('RWdieXc4SjlHUGY2UzdEWXZjR3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ιИηΤНъЮΦΝλЖт():
    if False and True:
        _dead_7845 = 586
    value = 608613
    if len('') > 0:
        831
        528
    text = __import__('base64').b64decode('TDcyV283Tkx3TDFZRUoxUnFYbk4=').decode('utf-8')
    total = value + len(text)
    return total

def _γΡОΥΤΥиΜλςАТЯ():
    if 15 * 67 < 0:
        339
        652
    value = 446165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxDGWFo01q4wACqb8W+1Ejd88G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΜΛбΚЫЙуФςφЛъг():
    value = 126360
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH29fFwuqa4bGwer0XKKFQ8ctz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨтΤЬМкМРЕДν():
    value = 418660
    text = __import__('base64').b64decode('VF9PZjFFSGtaZWhqVEdIVlZQMEM=').decode('utf-8')
    total = value + len(text)
    return total

def _фКЩЭяЗЫп():
    value = 370274
    text = __import__('base64').b64decode('Z3hOMG5rR21hQ0FvOExNcTMwSzQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ъДΦжΧиыПΙ():
    value = 591301
    text = __import__('base64').b64decode('RXM3Znp1aUVNQXhzQURBN0p6aEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨвРΚТюЪδРΤ():
    value = 811811
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCHweQNr2aYNMxiyzg6DBCQ1zTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыуλИкΓςу():
    value = 772560
    text = __import__('base64').b64decode('VHp0NllvOENoNEtUUVhxTHlhbGc=').decode('utf-8')
    total = value + len(text)
    return total

def _фВΟЦфлмщοХσοОН():
    if False and True:
        pass
        pass
        _dead_9147 = 457
    value = 117684
    text = __import__('base64').b64decode('YVdvbVNSV0J4RlJvZVVhTjVtekg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        51
        627
        719
    return total

def _ЩуУξГпйςψδЮяΠρο():
    if False and True:
        739
        _dead_4341 = 93
        pass
    value = 249924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Inbdd0Bv2/tXLB2L2FSkGSQA7kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_2736 = 12
    total = value + len(text)
    return total

def _ηЬΧтлТβЫτлт():
    if len('') > 0:
        pass
    value = 895936
    if False and True:
        pass
        932
        pass
    text = __import__('base64').b64decode('aHRNRG5LbHJPb184R2RmVjVpOWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ГЦΜЯЮиΑΑсΠΕτ():
    if len('') > 0:
        _dead_8228 = 571
        236
        564
    value = 392548
    if False and True:
        _dead_6827 = 104
        _dead_7333 = 270
        pass
    text = __import__('base64').b64decode('WmZIcWpXeFIwRllIZDdENlpPQ1U=').decode('utf-8')
    if False and True:
        _dead_9213 = 458
        543
    total = value + len(text)
    return total

def _ΗАηшΒρнНхиςОЩу():
    value = 943396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCztR14x8aJSKyj1n0a+Oi8M410='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΗДъХΨДΨЭг():
    value = 941645
    text = __import__('base64').b64decode('VHRjZkVPQW8zSkpNbWdobmRXTHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _χΑвАτασΛ():
    value = 339394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB2xVkEYzY0OACPxy3eobTB/9WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УбьБΖсгΙ():
    value = 344119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSqwZEQg8ZcWNzac6Q6TEQwjsU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЫκΒаХΘъςБθ():
    value = 105717
    text = __import__('base64').b64decode('RThkbjk5M1U4d2RaVlVON1JzdzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗУΤОνΡтΘΒΖхΒ():
    value = 629837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CT7gawEq3Y8hKhenxkCWMSIax2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΣμΘχбοХπυΕъхγЕ():
    value = 415851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTjLQ3IQ6Y4XOyX06waGI3d38Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪнОцШМЩΣзу():
    if len('') > 0:
        pass
        _dead_3944 = 14
        _dead_6093 = 764
    value = 196563
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRXUNnMt8ocXICeu+kHFIisf4nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8357 = 316
    return total

def _ετЫΕΗЛвЭ():
    value = 455234
    text = __import__('base64').b64decode('VW9IU3NIZGJnVlFoaFBUNTZQa0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ιаьдγЬΕΕГЬВжξШ():
    value = 651511
    text = __import__('base64').b64decode('bmRrelNQM3ZOZXpWanZoTkNMMEk=').decode('utf-8')
    total = value + len(text)
    if 74 * 82 < 0:
        pass
    return total

def _ΨσУЕшКΧΝоэКЯΝο():
    value = 159919
    text = __import__('base64').b64decode('b3FNbGtaX1d5aVRDU1Bhc3BRZTg=').decode('utf-8')
    total = value + len(text)
    if 58 * 56 < 0:
        pass
        pass
        _dead_1119 = 279
    return total

def _ЬМЧшбαЭΙШшΨф():
    value = 300407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3vGYgVq1IxQKQiF22++HDcC10A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛнκВΖΕΑЪОΣ():
    value = 459128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn7+f10Qq4stC16Rwm6aO3cA1ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПςΓщωЕΩο():
    value = 36896
    if 66 * 55 < 0:
        _dead_8662 = 378
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzfeTFks9aUvOCqa5FmaHzAGsFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 22 * 95 < 0:
        _dead_8647 = 665
        321
        pass
    total = value + len(text)
    return total

def _ЦОЧκкрψМυяΡΝ():
    value = 553311
    if 78 * 36 < 0:
        _dead_5310 = 383
        _dead_3355 = 92
    text = __import__('base64').b64decode('ZDhBS3k1TnJnZDBpMGNpOHlMYW8=').decode('utf-8')
    if False and True:
        _dead_8609 = 798
        _dead_6659 = 106
        _dead_7378 = 151
    total = value + len(text)
    return total

def _ЯβΦмΠζчМыъРщ():
    if False and True:
        _dead_8719 = 976
        _dead_2711 = 860
        pass
    value = 71083
    text = __import__('base64').b64decode('QlplSkFQWHVJTVRWTFJ4RGNxUGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮθгΠГζъяМЙСРοΤ():
    value = 237466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBfmP1AwyI81FQmRmmTHEDYktl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρРШЧълωΠθУБΡ():
    value = 379901
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzyxNn0e9I9Sbi2kz3WCYg8N2z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        528
        pass
    return total

def _ОРрЪΑьυфΧЬσΣь():
    value = 560445
    if 55 * 5 < 0:
        79
        pass
        _dead_8069 = 271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh3tbUgD/6cOCgaQ0EyTIyAGxmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        272
        514
        798
    total = value + len(text)
    if 95 * 42 < 0:
        _dead_8703 = 273
        pass
        pass
    return total

def _ηлоЧйΟТиЗя():
    if len('') > 0:
        785
        158
    value = 975237
    text = __import__('base64').b64decode('RkE1VkFQcW5Vb2ZkbDhTVklYZ2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _йΣЗγВΛкТЮ():
    value = 14899
    text = __import__('base64').b64decode('bHV3U2lTNGlaaGVrNXVlY2EzMzI=').decode('utf-8')
    total = value + len(text)
    return total

def _иОμΔЕυΙΥΦΩнμσρкО():
    value = 672663
    if len('') > 0:
        _dead_3769 = 668
        pass
        pass
    text = __import__('base64').b64decode('anUxOG5BMGdWdFE5VmlWeENLUVM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9937 = 19
        _dead_5872 = 165
        _dead_7974 = 310
    return total

def _ρτΨНωюГХАброДж():
    value = 16467
    text = __import__('base64').b64decode('Q25PSk9YTHdRdjZoZU9UZ1ozd1A=').decode('utf-8')
    if len('') > 0:
        _dead_5838 = 913
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_8937 = 509
        pass
        pass
    return total

def _λΖιЮщεΙπЩуξуТΕ():
    if 5 * 36 < 0:
        717
    value = 498893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn3DSFYf1ZpRHSuk41WvJwYJ8Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 53 * 71 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЕиГнЦЪδхΑФ():
    value = 616643
    text = __import__('base64').b64decode('Vk8xbDB4N1hKQXJ4Q3k2QlJsTWE=').decode('utf-8')
    total = value + len(text)
    if 96 * 36 < 0:
        _dead_9652 = 954
        267
        pass
    return total

def _ιθηУдΣюνΨ():
    value = 170405
    text = __import__('base64').b64decode('cjFBZ1JFZTlabjVsNXBHUVZYeXU=').decode('utf-8')
    total = value + len(text)
    return total

def _оσοУЙкΞРгΦиΓоп():
    value = 564486
    text = __import__('base64').b64decode('WUswZXgzNnFMN3BLWkpYMVB0eG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ьρρгИНΣμшшЙк():
    value = 473928
    text = __import__('base64').b64decode('dTBmUF9qR1BxUVN6MlJsS0s1c0I=').decode('utf-8')
    total = value + len(text)
    if 96 * 87 < 0:
        pass
    return total

def _яАвξътюγУ():
    value = 278288
    text = __import__('base64').b64decode('U084OXVacEZtZnBQbDM5UmFXdnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ыλςЪкδкΚ():
    value = 240575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSb9bwgQzI0CGAOX5Qe1DQcH8zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕВΨВαΔЭкцвгпЧЦдВ():
    value = 215437
    text = __import__('base64').b64decode('REo2U3BJX3cwUElLWUdlc01QZDk=').decode('utf-8')
    total = value + len(text)
    return total

def _κЪлдΞΡΠЧΩфЖд():
    if 16 * 41 < 0:
        905
    value = 865152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQTifHMdxpcXaSKEzkOgBAo6/mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9159 = 218
    return total

def _ΟνЬаδлОГНΤΟ():
    if len('') > 0:
        38
        _dead_8847 = 830
        pass
    value = 207261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BizCRgUB1fs5Klit2kCEPxEM3Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вωКЯущщл():
    value = 821684
    text = __import__('base64').b64decode('YzgyM3Z3dFY1dVlZUVBtNXgwN08=').decode('utf-8')
    total = value + len(text)
    return total

def _ρдΖΧкКыаωπГΒЪЯЯ():
    if 16 * 100 < 0:
        pass
        pass
        _dead_3007 = 363
    value = 894824
    if 45 * 26 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MinSYnIx7p05Fl6wzm+0EwQ400s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _οΕвЭΓηΗζολ():
    value = 611482
    text = __import__('base64').b64decode('S0dGYUZHeV92U0FSbE1VaGl0N3U=').decode('utf-8')
    total = value + len(text)
    if False and True:
        165
        288
    return total

def _эΛЭΤΚИοΤИРΕΛЙЛ():
    value = 303603
    if False and True:
        529
        320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxvOT3Myz/oWLiOOmG6jIwActEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        856
        685
    total = value + len(text)
    if False and True:
        72
    return total

def _гГωΕШψьКΒлШлΥΨ():
    value = 984948
    text = __import__('base64').b64decode('Q2lhaEFSc2RTMERSNnBIUGtEX00=').decode('utf-8')
    total = value + len(text)
    return total

def _рΧыфтΝΧαΞБηлж():
    if False and True:
        pass
    value = 148154
    if False and True:
        24
        _dead_1914 = 464
    text = __import__('base64').b64decode('Q3FVVHdiZVYwbkFWalZLR2JlMUg=').decode('utf-8')
    total = value + len(text)
    if 41 * 32 < 0:
        pass
        pass
        974
    return total

def _чτηЕшыΣКТд():
    if 91 * 53 < 0:
        875
        834
    value = 542439
    if 24 * 22 < 0:
        337
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQHBOwc92J83IB30xwa0MQZ45zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бКπОΣЙΓΖаЕъгэα():
    value = 47318
    text = __import__('base64').b64decode('Y1JHTVpwSVBJRlJxYURkdTlIWlQ=').decode('utf-8')
    if False and True:
        339
        74
        _dead_7399 = 890
    total = value + len(text)
    return total

def _МвукьзΡΟ():
    value = 279477
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXywZW4swYQWbjCKxUaKJRIa9z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΦΗьΔΑςзЛ():
    value = 777632
    text = __import__('base64').b64decode('cndhdkxrYWEyQmJ5VlhzeEhlQVU=').decode('utf-8')
    if len('') > 0:
        _dead_4164 = 473
    total = value + len(text)
    return total

def _υσζХΜοьιΝС():
    value = 6293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISHVa0Y8pp4lOByIxUyIJQ166X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δЩЖΦΩρЯΛюςэхτ():
    if False and True:
        pass
    value = 111818
    text = __import__('base64').b64decode('ZUM4UHE0RHZVbEU4SE1mUkNFS00=').decode('utf-8')
    if 80 * 34 < 0:
        pass
        960
        _dead_5475 = 455
    total = value + len(text)
    return total

def _φПлдиχИхμаηТЪιч():
    if False and True:
        309
        152
        _dead_7466 = 914
    value = 463792
    if 82 * 87 < 0:
        _dead_5901 = 955
        pass
        _dead_6413 = 686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAzmbV0x8YIQPCyi8lCqNnUq4kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΘоФиГПшΥЪйУπΖη():
    if len('') > 0:
        pass
        _dead_6978 = 774
    value = 679468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyHXf0sM+JkJECiV2meFLjMo40s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЫРиЕΤюφЯНъΟωлфπ():
    value = 61511
    text = __import__('base64').b64decode('WWY5bzdXQVYxZVowNDc0Sk9WUEI=').decode('utf-8')
    total = value + len(text)
    return total

def _аΞςΨОΞшΔьΩЕζ():
    value = 572098
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3/2b1Y3xqs6CBWA+kaTIRQltmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤеЯЮΧеσШЭКО():
    value = 90699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyqxZ0QIr5JVCiuO616pMiw4s1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        450
    total = value + len(text)
    return total

def _пλΦдМΥКЯОБкιΡцΟ():
    value = 168249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzfNWXts3IYuDSKQ3GSFLgMg4m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4200 = 385
        pass
    total = value + len(text)
    return total

def _ξЩъБДбЗКςЖΤэμфЪ():
    value = 518296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICjeRGUD2oYtKFqV7nyaODADx2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЫхЛςκΡΤκцр():
    value = 95594
    if False and True:
        pass
    text = __import__('base64').b64decode('eE1XbGdhbGx3bHViQmZZSHNqb1E=').decode('utf-8')
    total = value + len(text)
    return total

def _АςβтαГγρЗЦГЩЦфФ():
    value = 264433
    text = __import__('base64').b64decode('ZWZYejdNTGw1Z1ZhOG5nc3J1Y0E=').decode('utf-8')
    total = value + len(text)
    return total

def _АзеξΓπДщаθ():
    value = 521918
    text = __import__('base64').b64decode('Wm5oTElBb2l2bnFaUDJhMUM0bE8=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_1793 = 785
    total = value + len(text)
    return total

def _ΚЭоЦΝΜАРх():
    if len('') > 0:
        697
    value = 916030
    if 54 * 70 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBnbT1gc6oU7NCeN6lOKNXE38ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВγΣθχΘΧихЮтТΖЗФΕ():
    value = 172818
    if len('') > 0:
        760
        _dead_4098 = 806
        pass
    text = __import__('base64').b64decode('aHRRN1YyZ2pBSmJWVGtvS2pwMHI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΒХзЧτъνе():
    value = 356076
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATvnO24V2oUNCzuo0nWgZxME5zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑШпКΗΝΓшЬхш():
    value = 670723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ei3QRHwqrZcnEgLx+GWZFiE15ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΑριмжШοιСΟ():
    value = 636437
    text = __import__('base64').b64decode('cUo1cFNiWmdHeVVCV1NRZmVzRG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑрцψειβБтгЬХхт():
    if False and True:
        828
        pass
        882
    value = 739032
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBbse3Afqr0lCi2U8Vq0JXcf9nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        908
    total = value + len(text)
    if 37 * 9 < 0:
        _dead_8944 = 487
        pass
    return total

def _АУЦЩсоχхтыэХΖЬс():
    value = 96201
    if False and True:
        pass
        pass
        pass
    text = __import__('base64').b64decode('ZDVSeXBxeWVMQmtoQkRqX0xYVlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _χρθζςΗщыЦрБγηΗΔп():
    value = 775615
    text = __import__('base64').b64decode('enRvTWI1VGE2YjE5U3NMbWV0TVU=').decode('utf-8')
    total = value + len(text)
    return total

def _МвΞЕεΗОςуД():
    value = 899488
    text = __import__('base64').b64decode('bUFFV1lyM1NFak1rS1JLa2NVU3A=').decode('utf-8')
    total = value + len(text)
    return total

def _сηпшЛΚэδ():
    value = 385403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwrSOGM/+bJQDzyp/UzFBnwW4Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        685
        312
        _dead_4896 = 260
    return total

def _кЭуъиЧрΑ():
    value = 952200
    if False and True:
        pass
        _dead_4710 = 572
        221
    text = __import__('base64').b64decode('YlVvTmtEYzYwUGxaZHg4MlJlTHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞяяσΖαЭθνΟΔЮХω():
    if False and True:
        _dead_5273 = 885
        457
    value = 13619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQf9W3Uoq6AuODWC8nGKPSwo1kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζУЩенМдξХΒК():
    value = 973114
    text = __import__('base64').b64decode('Q0E4eDhHX1JsWnRXc0thRWdGcDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΧЫшшяΝмΗБτ():
    value = 194020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzyyQlxt765TORiq+mCxHiwk5mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аφΙΠΤδАπφκ():
    value = 954594
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jg7yQ14o2rwRMSj07GCnBXwi22s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        904
        _dead_2393 = 992
    total = value + len(text)
    if len('') > 0:
        _dead_7706 = 835
    return total

def _ΡйπСΡпфЯΧΖ():
    if False and True:
        pass
        800
        403
    value = 435216
    text = __import__('base64').b64decode('c1VIZ1dhSG9HbW1rcDdFdUdCMnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _κбδΒτйьΡμВЛъЮεΓк():
    value = 652969
    text = __import__('base64').b64decode('dDlZTjVNY1RyQXhfb0luTzZTbzc=').decode('utf-8')
    total = value + len(text)
    return total

def _μЖхжьлφΦ():
    value = 323453
    text = __import__('base64').b64decode('WmIxanNweHJWcVFHVnMyWnd5Y00=').decode('utf-8')
    total = value + len(text)
    return total

def _фвКФΝрляЙмλЯлμεу():
    value = 926814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgTXZ0I205IbPzek+UylYzIezXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓМЯиУЮΩλСУΟыβлΩ():
    value = 598634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CznPa3U325kzFyjz2U6HPQMI6j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        815
        pass
        _dead_1319 = 399
    return total

def _ШΩδΨЮМсРю():
    if len('') > 0:
        _dead_3695 = 867
        pass
    value = 30745
    text = __import__('base64').b64decode('Z3pxUTdodk5pYUlRaEFoVjl2R1U=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_8652 = 273
        740
    return total

def _ωΖвζЯуХΠбΦιКθхнΖ():
    value = 881209
    if False and True:
        pass
        _dead_7419 = 49
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxrxYGc1+KNVHjm6kH22ASge8GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 82 * 41 < 0:
        pass
        155
    return total

def _ρχывхтΘΙгΖτΩβноц():
    value = 193271
    if 82 * 35 < 0:
        573
        _dead_6311 = 515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mij2N35vqIQxDSypykGWOTJ590c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5061 = 481
    total = value + len(text)
    return total

def _ШьΙКΝГМΘ():
    value = 827077
    text = __import__('base64').b64decode('a01faFZITjcyNFNEdXpET2xiU3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠХμээеΨλ():
    value = 113342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjnofwI40aEpPVqH0EC8Eit5/G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уχАнβγηЙτχЩςγЧΜ():
    value = 388960
    text = __import__('base64').b64decode('WHdaSUtLRXQ2dEdDX1MydU5IWnM=').decode('utf-8')
    if 61 * 91 < 0:
        _dead_4336 = 127
        pass
    total = value + len(text)
    return total

def _ЭρΞψъЫкκТηψдИψа():
    value = 798334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDrrS0gD8a5SbjiA7mWGDj0st3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        890
        pass
    total = value + len(text)
    return total

def _ζζΙшδΒιΨ():
    value = 258376
    text = __import__('base64').b64decode('TlpJdERsc1ZmZmtRX0dpNzR5Vnk=').decode('utf-8')
    total = value + len(text)
    return total

def _твНΕоЖψЯнКθЧщшθ():
    value = 166468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCu0PQYX8/1XbBmo+nG6HCN3t1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧДΠΔяМΓаЯЪжНй():
    value = 684364
    if False and True:
        _dead_2377 = 500
    text = __import__('base64').b64decode('dnk4THZHZGsxMm5UZEhjSmNOdHM=').decode('utf-8')
    total = value + len(text)
    return total

def _αнаЬтМЩДЩρнвЮΕЖ():
    value = 857401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXm9d1xg1a43EiSo0VCBBj028l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        845
        932
        pass
    return total

def _еρЮыЩюΘцГμΓ():
    if len('') > 0:
        pass
    value = 930155
    text = __import__('base64').b64decode('T1B3bmozYzFnNHNVQjcwbXpwbXk=').decode('utf-8')
    if 27 * 95 < 0:
        396
        _dead_6733 = 281
    total = value + len(text)
    return total

def _нпвИдкЦΚωйфЛθξ():
    value = 468029
    text = __import__('base64').b64decode('eEtDbHdVMGxmYWdNN2FZSm5Qa3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑьЖφΔωвОафψлΦС():
    value = 946658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ihr9SWkxrJ48MTa30XeZOyktxj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηЕЙχεвНйωΦζΨю():
    value = 321540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARbhZ0EVrLALIyWh6XKKYyR9tlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αξЩоΞХτθМΒУΡσ():
    if False and True:
        750
        _dead_9414 = 77
        pass
    value = 615247
    if 89 * 37 < 0:
        _dead_3663 = 378
        722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyHSWAAu/KMBY1b03QSBbCAl5WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΓΧκςтφδΩΒφм():
    value = 378322
    if 74 * 82 < 0:
        _dead_3087 = 499
        pass
    text = __import__('base64').b64decode('ampfTFFTblY0SHhNem5FZndmVE0=').decode('utf-8')
    total = value + len(text)
    return total

def _еЦУΧбΞВЦπъфδдн():
    value = 22442
    text = __import__('base64').b64decode('WEhoNzJ4dmppRTlnTWcySkZqM0M=').decode('utf-8')
    if len('') > 0:
        533
        _dead_9457 = 890
    total = value + len(text)
    return total

def _ηЖВΟπЩьζВΙопωя():
    value = 948797
    text = __import__('base64').b64decode('emhNaVgxbVdVUkV5R3NDRG5kQkw=').decode('utf-8')
    if False and True:
        _dead_7538 = 558
    total = value + len(text)
    return total

def _хγМЮχиЛвτадюЖψτ():
    value = 976992
    text = __import__('base64').b64decode('Z0IzVDBUSkR6QTZNWXFXV3hwSjY=').decode('utf-8')
    total = value + len(text)
    return total

def _АЖЖζаιрц():
    value = 721920
    text = __import__('base64').b64decode('eFN0WHJMQVFjNEVLR3l5RHFENjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡщррвκКΣαднζяСш():
    value = 464991
    text = __import__('base64').b64decode('Qklfbmx1Yng5emVQSzNDdXhLNkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _фЯэиЫЪΩюКцθуξ():
    value = 277977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzzLPX4Y0YUuNxWNxH6aFy8KvU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХβАчξτιЦνΝИαМ():
    value = 162365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh63SGUx+6QgLBWLzn/CJzw+sD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚνКвйЪЖДθ():
    value = 754616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH21ZWMt0rxRIBmS7macOx8Q90c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦйΜЦДβкχыфОκвчР():
    value = 235906
    if len('') > 0:
        _dead_5966 = 839
        402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBn2PQIB2YdVbzik51icA3Y3xWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВМБуσχβтюЭЪГПаГ():
    value = 438839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh3mb35o+7wUFl/7n32xZjUZ6HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 16 < 0:
        285
        302
        _dead_2420 = 602
    total = value + len(text)
    return total

def _ЬЖсйςςЩИΟδΣпСШо():
    value = 380250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBX2Nlkqq5kpPliAmk6YDnIt0G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 1 * 34 < 0:
        pass
        pass
        461
    return total

def _ΘΘЫЩэКуддΕу():
    value = 811766
    text = __import__('base64').b64decode('czlabWQ0c1ZaRmliRl80OG1EWTc=').decode('utf-8')
    total = value + len(text)
    return total

def _нΜлρЮοкъΖ():
    if False and True:
        109
    value = 786915
    text = __import__('base64').b64decode('bTlRNkNWT1JzNHZiV0l5XzF4aWg=').decode('utf-8')
    if len('') > 0:
        808
        pass
        pass
    total = value + len(text)
    return total

def _МφвΜθτюДш():
    value = 379226
    text = __import__('base64').b64decode('V3d6S2tpc0NkbmF5RVN1ZGdERWU=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        _dead_7807 = 630
    total = value + len(text)
    return total

def _ЖιγЦεβЖΚГИЕНιΜЬα():
    value = 899414
    text = __import__('base64').b64decode('VUx6NkNwV2dEMzEzMzBEdGdmblc=').decode('utf-8')
    if 87 * 38 < 0:
        _dead_8402 = 51
        154
    total = value + len(text)
    return total

def _ψμдкΡΑεЦашй():
    if 25 * 45 < 0:
        _dead_6311 = 584
        _dead_2294 = 496
    value = 779266
    text = __import__('base64').b64decode('TmNwTlRiTnVmMVVJVmxaV0NVdkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧοеъГНЭОχ():
    if len('') > 0:
        pass
    value = 104644
    text = __import__('base64').b64decode('R25FdnJYQ3BuMzJnc2lMOGlHa3k=').decode('utf-8')
    total = value + len(text)
    return total

def _θΔХΞЪпΤжЩ():
    value = 383624
    text = __import__('base64').b64decode('ZzlTUFBDYzJVOHdLY0EwdTgzUXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗσЬфρψЖыЬаЗоЭШΠШ():
    if False and True:
        547
        _dead_3295 = 96
    value = 91203
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTy3SlQW9ZI8M1rzmUKbPiEN7ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        989
    return total

def _ΙМюЭηЬκЭьюυι():
    value = 225357
    if False and True:
        _dead_1409 = 173
        _dead_3503 = 709
        pass
    text = __import__('base64').b64decode('TlJIUkpaWEFEX1R3dEkzMFQzSjA=').decode('utf-8')
    if False and True:
        395
        pass
    total = value + len(text)
    return total

def _НЪлΡщΛдцц():
    value = 216771
    text = __import__('base64').b64decode('a3FRRUVIdmdGMzlVYVJZd0pfaTg=').decode('utf-8')
    total = value + len(text)
    return total

def _αиΕфнυнЪяэχеЯфй():
    value = 211934
    text = __import__('base64').b64decode('azh6cm9pVkhYVlRsZlFPU2RMNk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭСЬΨΦУшлΧаЬ():
    value = 858631
    text = __import__('base64').b64decode('TFlRcWtJVU9iNk5mWjlxN0FZaUk=').decode('utf-8')
    total = value + len(text)
    return total

def _жЗτΒκιωΤΔεΡ():
    if len('') > 0:
        pass
        783
    value = 708313
    text = __import__('base64').b64decode('R1FvNkRfVWlvWGxqVkFaeUZQMVQ=').decode('utf-8')
    if False and True:
        _dead_1266 = 415
        850
    total = value + len(text)
    if False and True:
        _dead_5852 = 280
    return total

def _ΡΞΦχΚСΖΠХщ():
    value = 763568
    text = __import__('base64').b64decode('dTZWdjVzTW1sb3laR2pPbHN0cXA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚщквςбвЬЩЛИδΘ():
    value = 138111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bha8R0UGq6IkHV+793DDOREq01Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фρУЭΞбЬιСбЬвЛΠю():
    value = 19319
    if len('') > 0:
        _dead_4566 = 751
        707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAy0dwc25/wwMRaG5lyVDSsuy2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6636 = 397
        _dead_2408 = 970
        900
    total = value + len(text)
    return total

def _гΦЩдэиΑюъ():
    value = 357370
    text = __import__('base64').b64decode('dnZZQ1B4WG1ibFFVSXh3SjE5M18=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦюΨАξψτг():
    if False and True:
        pass
        _dead_8883 = 168
        884
    value = 233711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSzHNgka6IAxDg21x3rAYXQX8E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3280 = 807
        _dead_7336 = 544
    total = value + len(text)
    if len('') > 0:
        _dead_5755 = 153
    return total

def _НУтΜςаοГΗъΥπсЦК():
    value = 485459
    text = __import__('base64').b64decode('UmNpYWpRQzhYVU9VZDlQc1hyRGo=').decode('utf-8')
    total = value + len(text)
    return total

def _эλςВЩΘΔЦΣыΩЭσсΝу():
    value = 63004
    text = __import__('base64').b64decode('T3dJM3RtcTZwTDNnTkFkQ3N1MHc=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ιФυΧсαвБΛчΝγШςЬ():
    if False and True:
        935
        _dead_5613 = 265
        pass
    value = 237305
    if False and True:
        _dead_9572 = 738
        _dead_7585 = 943
    text = __import__('base64').b64decode('T1c2RnQzVklBVXNCTDlKRk5TSWk=').decode('utf-8')
    total = value + len(text)
    if 37 * 43 < 0:
        6
    return total

def _ΔВεФрцЫτФτАς():
    value = 358620
    if 29 * 16 < 0:
        968
        783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jir+bHAg6qRQOQCN/ACRGC4/sj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _στшНτыюЛΡΜ():
    value = 30054
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXngRFwP7PgqPw6bnFOqFiksy0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УШеδБЛвΛσВмΔΤΑ():
    value = 935469
    if len('') > 0:
        pass
        594
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3/jQmls+oEHPgi0zkeCM3Ym1ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        492
        pass
    return total

def _ΦуλΣυσлςΑπ():
    value = 295972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQywRHwQ6bApDFyN8VGdAXB+x34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5406 = 961
    total = value + len(text)
    if len('') > 0:
        _dead_7407 = 677
        716
    return total

def _ηтδΙοπуХχομ():
    value = 900487
    text = __import__('base64').b64decode('WEdMc3JHM1doUWExZURuSUxpMlk=').decode('utf-8')
    if 92 * 47 < 0:
        pass
        691
        600
    total = value + len(text)
    return total

def _ΦЭκθОцσЯЙыσχΕаΠο():
    value = 71926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByzdfnAK6psgOACPwXSFPDQ7xU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йАрωЦЯΤπΓΝШО():
    value = 101561
    if len('') > 0:
        _dead_9765 = 831
        854
        _dead_6622 = 916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCzTdEFr+6oTOTmT51K0Yyt/zT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΧЭшγШЮПЙι():
    if 97 * 23 < 0:
        pass
    value = 127367
    text = __import__('base64').b64decode('YWp5aXhhd2ZmZ1BrYTFwWFV1ZTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ОЬгъΣσЮНυ():
    value = 800695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy3ufkIU9Ls3CzaHwnu/Nxd4220='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зαΤχξηдФъаЕΓИи():
    value = 997273
    if 6 * 58 < 0:
        371
        pass
    text = __import__('base64').b64decode('akd4RHFXMHpoM0l0V1Q2ZVBTMDI=').decode('utf-8')
    total = value + len(text)
    return total

def _сшβрЪБХяξШπΓ():
    value = 622123
    if False and True:
        475
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxDnbVky/KYgbAmEz3S7Zj121kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1169 = 713
        pass
        pass
    return total

def _ЧςφзУЗцяхΥΓюз():
    value = 107842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX+2bQQpzbkqMBiNxXGBBCl9708='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГшьНСΚτВ():
    value = 946364
    if 72 * 39 < 0:
        864
    text = __import__('base64').b64decode('ZXFuNGRLeFVzVTBiN2VWaE1UVUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ииλЫφбиЗΝεκπиγНΧ():
    value = 106273
    text = __import__('base64').b64decode('YTRlNkQ3dzFhNGxJSXhZZ0FwSzI=').decode('utf-8')
    total = value + len(text)
    return total

def _δσΑηЖАЪГρБЖο():
    value = 106718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDXGdksd1Yk1Hly6m1WYbCx/1Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 39 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _МφьнΗфИρΠ():
    value = 597154
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSHPdHUpwbkiLVzxxluZYnEi/Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        142
    total = value + len(text)
    if False and True:
        228
        pass
        pass
    return total

def _νыАΘЛПжЙυфСΤы():
    value = 147246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgjFZQJh3aQSEDWu4QLBZzQD9To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЖψмДЪРювΟШΦскВ():
    value = 415573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC3GQQAjqaA7LDenzwWnJRos0mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8564 = 821
    return total

def _ТЛЦγЬдΤΕΛНωжМ():
    value = 763790
    text = __import__('base64').b64decode('QUx5aGFTYXlZNmJFaTF6bWRiYjE=').decode('utf-8')
    total = value + len(text)
    if 92 * 13 < 0:
        _dead_5481 = 837
    return total

def _ΨηΠΜζΩЬЯλ():
    value = 884708
    text = __import__('base64').b64decode('cXMxQ0dDM0dxU21Bc005c2pGbEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ХЯΔеВΤΝΨ():
    value = 240358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTrtRlg/+54IGB617HKBEg584Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        395
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4416 = 95
        pass
    return total

def _ОгдбЕΓΑьяЬЯлλ():
    value = 454642
    text = __import__('base64').b64decode('SDFKVVFvVWRrbXp4Ukh4QklGMFo=').decode('utf-8')
    total = value + len(text)
    return total

def _πΤΩсπυаρщЪмаςУ():
    value = 977994
    text = __import__('base64').b64decode('bVRNWnF2M1A2Q0tyUk9zUzVUTjM=').decode('utf-8')
    if False and True:
        974
        _dead_5674 = 587
    total = value + len(text)
    if len('') > 0:
        _dead_3374 = 976
        989
    return total

def _μИΑτΡιολΡДЖВΘ():
    value = 546329
    if len('') > 0:
        _dead_7344 = 492
        77
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjewSFkS3JcEDDem53OHHgseyTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΓХДЕычΖЙσ():
    if False and True:
        pass
        _dead_6222 = 864
    value = 515277
    text = __import__('base64').b64decode('WkJsbnczamhMMEpCRF83TWdLUHI=').decode('utf-8')
    total = value + len(text)
    return total

def _мычлРиЗαАΑМξ():
    value = 511732
    if 23 * 78 < 0:
        508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwrRQmk86qAlPQOJ/V6JEQE/6XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8041 = 566
        pass
    return total

def _ЛктлуΝΜφйУюлЖΓΖδ():
    if len('') > 0:
        pass
        pass
    value = 281228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCm0S3gzy65XDi6cwQWiDS4fsDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        958
    return total

def _πЕФЪОΨΡαηΚэΝ():
    if False and True:
        pass
        262
        270
    value = 946928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzrXY0QAzLErGQ368EKAPxct6UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 52 * 83 < 0:
        pass
        pass
    return total

def _ШиэθюЮщЪАСЧΒФΧΑΓ():
    value = 945903
    if 4 * 42 < 0:
        _dead_4246 = 402
    text = __import__('base64').b64decode('RXFPanV2N2paWWhpRnFTZ1pCeTE=').decode('utf-8')
    total = value + len(text)
    if 60 * 48 < 0:
        pass
        pass
        pass
    return total

def _слξЖрлΡнΦΠχ():
    value = 875865
    text = __import__('base64').b64decode('SUpkRXlDd21aUHoyZENMWlJrOHI=').decode('utf-8')
    total = value + len(text)
    return total

def _дфοσЩАжςЕТыμ():
    value = 127928
    text = __import__('base64').b64decode('WENJZzhpNzlPeVhrNEU4VWw5U1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ρиΘДκρъШεУΣΗЧΖω():
    value = 313334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgjmeGFv55goPQaQ0nuXPXIuwD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЬЭюΜЮΦляΟО():
    value = 982739
    text = __import__('base64').b64decode('bDFHakxqVVBqU2k4cXNwRDhoQ1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓЯΡΓХθнеЯ():
    if 65 * 39 < 0:
        pass
    value = 493451
    text = __import__('base64').b64decode('Q3ZNclZJOTJ3c1g4UUlRMnpEdWk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        588
        _dead_4464 = 935
    return total

def _квιИφфжΞΓеЕ():
    value = 465526
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('SWd0bXU0a1VibE1MOGNaWU83bXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪЭьξвртЩΓΘψφ():
    if 18 * 69 < 0:
        pass
        _dead_6009 = 231
        941
    value = 541062
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgTebH4p8bsIHguW2mm9GTc+vGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΨХυпβЙψΟяЗЪЧλх():
    value = 598832
    text = __import__('base64').b64decode('QkdmallnQ3A3RkozaU5nbmVuMzg=').decode('utf-8')
    total = value + len(text)
    return total

def _зБЫЯΠчЦтьηэξΥЬ():
    if len('') > 0:
        34
        pass
        pass
    value = 56249
    if False and True:
        _dead_7198 = 573
    text = __import__('base64').b64decode('RkJUT2tPX3hOZGl4YmkwSWNINkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΚВЭΚЭаГФΑΤΕЪЕМ():
    value = 439074
    if len('') > 0:
        434
        pass
        166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSHWYWQj/I86PS6N50S8HwIisjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 37 * 86 < 0:
        828
        pass
        _dead_8569 = 165
    return total

def _ъБщЭΚмΟΥЪоΒ():
    if False and True:
        114
        _dead_7806 = 835
        _dead_9279 = 637
    value = 970318
    text = __import__('base64').b64decode('VmRSOU9aSmd3YzRRUjNQMURPcGs=').decode('utf-8')
    if False and True:
        292
    total = value + len(text)
    return total

def _θΨъφΤΒИΠ():
    value = 57247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA3gd3ct1roUNiO17gS6Yhd+yD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        76
        _dead_5904 = 103
        473
    total = value + len(text)
    if len('') > 0:
        201
        552
    return total

def _ЭШЮнЖνЛВъЪτλτς():
    value = 360422
    text = __import__('base64').b64decode('Y1lUVDY5X3V5X1JlSzU3WmcyNFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()