#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _οΦШΝΔΦΙΣΛГΖЙлΝω():
    value = 594676
    text = __import__('base64').b64decode('dEhGYldRRHlzZnFGWmFtRUZWckI=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЮззωДпоκ():
    value = 987624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyDLYXs03a0WLxWp91CCOwMf3Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 30 * 88 < 0:
        _dead_8052 = 560
        301
    total = value + len(text)
    if len('') > 0:
        _dead_3973 = 112
        _dead_9058 = 774
    return total

def _МЧΘЦдνцР():
    value = 887862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRawfGAT/YQLaCTz8k+ZIhUbt2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        503
        189
    total = value + len(text)
    return total

def _зЮμООщπΩЛ():
    value = 947374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ei6yNgQy3/AJGVuk2lvHbQ558VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΖшЕмиτΑρмΟэξγδ():
    value = 238458
    text = __import__('base64').b64decode('WEFHSFJhVjNDTDltUEdwUTlfbWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЦΥцλυэЫΠХе():
    value = 883740
    if 77 * 2 < 0:
        _dead_2905 = 663
    text = __import__('base64').b64decode('S0h6NENLeU1QTDMwTmt0VVZxUjI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_6266 = 16
        pass
    return total

def _ΥζτТεΨьθΥржЭюьΟ():
    value = 801053
    text = __import__('base64').b64decode('cnNpeVNfTjNpWnhaWjdFWEdibVM=').decode('utf-8')
    total = value + len(text)
    return total

def _υЧВαΨйψΓΥΛ():
    if False and True:
        _dead_8942 = 903
    value = 941214
    text = __import__('base64').b64decode('V19rbGluNUw3VmhZdVBZc24wM3c=').decode('utf-8')
    if len('') > 0:
        723
    total = value + len(text)
    return total

def _СЬτФлЩЦИΞΠοΖωΣж():
    value = 391025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgG3dnISwZIbLS6t91qcE3IAwkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВесΜΝΟЯΘξγг():
    if len('') > 0:
        pass
        _dead_4345 = 431
        332
    value = 468002
    text = __import__('base64').b64decode('VXhoYm9wTDREel9SWTVsRUpFR0c=').decode('utf-8')
    total = value + len(text)
    return total

def _вδШнрВΤυφζ():
    value = 177829
    text = __import__('base64').b64decode('Y0RzdzRiVEVvOGZhc0VVVXo0Zjg=').decode('utf-8')
    total = value + len(text)
    return total

def _жОιпззиυΧε():
    value = 350135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHzQQVdo2oYSAlb77wGfHAYp3EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙλΤωщфбЪююλНΠ():
    if 96 * 17 < 0:
        _dead_5189 = 464
        pass
        _dead_9663 = 223
    value = 442069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXz0NlIJ1oMbEQqq7QWFPggH7j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2349 = 648
        _dead_8765 = 54
    total = value + len(text)
    if len('') > 0:
        726
    return total

def _ΟШΞΣВΩъЭυ():
    value = 647333
    text = __import__('base64').b64decode('WnhCUTYzWlBBd3pVa2pEYVVFaVE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        187
        pass
    return total

def _κИйывыжж():
    value = 642825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAe9Qmkg66ACCgCP/1GqFiEOtlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙеВΙτтΣв():
    value = 564973
    text = __import__('base64').b64decode('UkQ5bGFsYllUMkh0N1pZa0E3elQ=').decode('utf-8')
    total = value + len(text)
    return total

def _чΣνТнпИчΚπРΓΦαиΤ():
    value = 487658
    text = __import__('base64').b64decode('QXBGZ1k3SENjTUtUUEtmZDFVUDA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1218 = 674
        733
        _dead_2975 = 849
    return total

def _ρΥΜΑПΜчΞЭУψьΞΠъ():
    value = 261139
    text = __import__('base64').b64decode('djJ5R2dCZTlSaUV1TDQ5SFRkQ3I=').decode('utf-8')
    total = value + len(text)
    if 18 * 73 < 0:
        pass
        _dead_3653 = 476
    return total

def _ЫюВрεγζцгз():
    value = 470848
    text = __import__('base64').b64decode('c1ZnQmMyRU5rS1JfeEhCZlRkOVQ=').decode('utf-8')
    if 4 * 56 < 0:
        252
        _dead_6288 = 378
        _dead_6933 = 783
    total = value + len(text)
    return total

def _НянжЪйЩиΞΠжцчυΧ():
    value = 539275
    text = __import__('base64').b64decode('UG02NG1VWldLMEtYS1YwcmlQNEI=').decode('utf-8')
    total = value + len(text)
    return total

def _лчπпшΦОЬφ():
    value = 643322
    text = __import__('base64').b64decode('TjZGNkk3Tm55aWxjOXNDa29Ta2k=').decode('utf-8')
    total = value + len(text)
    return total

def _бψθΘуφμеПВчЫΞкΒΨ():
    if len('') > 0:
        489
        pass
        _dead_3119 = 743
    value = 380905
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw3KN3Npq7wqCC313nWbESYc73o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        890
    total = value + len(text)
    if False and True:
        _dead_3173 = 534
        _dead_6560 = 862
        803
    return total

def _шпΙЮМщпюΘ():
    value = 447870
    text = __import__('base64').b64decode('WUJORFVHQ19nRXN5WW8xVHkxX28=').decode('utf-8')
    total = value + len(text)
    return total

def _шσΝΑΝΧнδξнцυδ():
    value = 224126
    text = __import__('base64').b64decode('YTJTQ1JyMm10NTA4SWo5azRBZm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ХГΟΜмΜΩΘ():
    value = 713047
    if len('') > 0:
        _dead_9588 = 766
        428
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3v8ZGEzqIckIAus8UWVPRE9xX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6450 = 390
    return total

def _ΡХюφμкχлЭдШкз():
    if len('') > 0:
        _dead_7940 = 947
        239
        183
    value = 674637
    if len('') > 0:
        _dead_2755 = 761
        _dead_1707 = 581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQjwSmI96p0hFCSR41yYDQB88UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        197
        pass
    total = value + len(text)
    return total

def _ХπΡеЛйοВМΧΠη():
    value = 417740
    if len('') > 0:
        _dead_9917 = 950
        pass
    text = __import__('base64').b64decode('WllvdzFCWWR6YkRUVWNJNV9CZms=').decode('utf-8')
    if len('') > 0:
        332
        937
        _dead_8838 = 964
    total = value + len(text)
    return total

def _АлβЬδНΗт():
    if len('') > 0:
        _dead_6920 = 313
    value = 759799
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwHHUX070ZAEESmqxQeFFSAc3no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чэШΓЗΗПнΧ():
    value = 621672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHb+VgIcz4MoIj2yyVSjNS46x3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 42 < 0:
        _dead_7855 = 319
        17
    total = value + len(text)
    if 12 * 29 < 0:
        pass
        pass
        _dead_7899 = 647
    return total

def _эΟВΔηИΦΓνа():
    value = 960095
    text = __import__('base64').b64decode('RllVT1d6WWh5OVQ3ektGNDNTRGk=').decode('utf-8')
    total = value + len(text)
    if 27 * 14 < 0:
        _dead_5980 = 313
        pass
    return total

def _ρΙωбΩЮςбП():
    value = 242258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyTSdEQW0p81Dw6H8lu8Gws9y3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тηЭЧχЪυкΖεБωгσ():
    value = 723666
    if len('') > 0:
        _dead_2450 = 45
        49
        256
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiHlSVwfrpA6Izaz8XWKEAsB81c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υрΕеьХΧХΜВφиШЛΣС():
    value = 631765
    if 91 * 74 < 0:
        457
        649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FifrRVQb8fsOEQyFkUXBMzUG1WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1548 = 889
    return total

def _еςΓγΜпуЦвΑ():
    value = 72514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz/HNnwd1r4kY1as3XOWFQA3slQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лтыκπэΤрЮъДХлΚ():
    value = 254215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NH3HN1gN+vgqbhuqn1i2GHEEyXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξецΗΩъΟСкв():
    value = 60549
    if 47 * 82 < 0:
        219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA3FX24N8JArMliw4QOTDQ86zEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΨΠσΩΑλлυИ():
    value = 631408
    text = __import__('base64').b64decode('eHdRMVNZSVF5bnNjTk9oN05mbV8=').decode('utf-8')
    total = value + len(text)
    return total

def _οΘНоЦяιгнσ():
    value = 524601
    text = __import__('base64').b64decode('Vm9TOXVTYXh1SGxNVVQ2eUUyMkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _γСφнΞσьКлβйПвЛ():
    value = 515973
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiLHXQIW5qUPKDeumFWmF3cpt2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5196 = 680
        pass
        555
    return total

def _τЭЛЯуФαп():
    value = 622479
    text = __import__('base64').b64decode('cGZIZ0xfS3RBNURVNXFSenNMS18=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΗуΡъкгΩχхлΔН():
    value = 659536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mw7wWANh76RWHiq553zEBAN6sH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πγаКаΗΚлХα():
    if False and True:
        pass
        59
        pass
    value = 375063
    if 53 * 45 < 0:
        _dead_6346 = 994
    text = __import__('base64').b64decode('eUdCT1ZQQjFpeDhmTHBRTHd1NUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦКψувюфΔυчΒπε():
    value = 825048
    text = __import__('base64').b64decode('Y1NLcEZ1Mks2ZklqUGdpZ0NnWjI=').decode('utf-8')
    if len('') > 0:
        pass
        632
        pass
    total = value + len(text)
    return total

def _ГяюΗНрънНλΖΚцΚп():
    value = 812212
    text = __import__('base64').b64decode('Y2xfU2R2ajl0c0NuN2ZhSWxraHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЗпρφЬΓΩΔςΧΗΠЦ():
    value = 572452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAGwRUUx6akaNgWx6gOIMTMZzEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔτζнΒЪЫу():
    value = 238295
    text = __import__('base64').b64decode('UFZEMnluVUJJVTI3eERSTG13eTM=').decode('utf-8')
    if False and True:
        20
    total = value + len(text)
    return total

def _ρЩΖХвψвьΕΙθ():
    if 38 * 14 < 0:
        pass
    value = 639365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCfiPFBg3IIaGQScwEyXJiAc1lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 48 * 40 < 0:
        835
        726
    total = value + len(text)
    return total

def _κδδцЫτΚПЫсΞжγ():
    value = 455658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3nAY2U+rb0AFhf0yWS1PBUs1HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8412 = 514
        pass
        409
    total = value + len(text)
    return total

def _ЙβгτНεΓлΞδιхΦ():
    value = 259311
    text = __import__('base64').b64decode('QThjYVJwaGxtTDJOVmFBQW5UMGY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЧΝΖκΨΑθАσχηφ():
    value = 543473
    if False and True:
        _dead_5863 = 380
        _dead_5937 = 855
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LT7VfmgW7PkMAxuT3FC6FjEZ6G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΥΑШΡνεκΗПςΩп():
    if 28 * 63 < 0:
        _dead_2308 = 746
        pass
        pass
    value = 742831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz79Q3AdpvglYjvx71+1IRB81Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        807
        pass
        pass
    return total

def _КηииγЫΧХжαιΔω():
    value = 704126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nn/Jeklg8L1TFQ6AmFqqJhQV8Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚлωчфЯШтуВμзл():
    value = 375101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiaxYm4GxLsONS6q6n+SZRoL/kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лзшщЧнХΑЗСщηИбЬζ():
    value = 720110
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgrybWYQ5rk7A1fxxECALQ05y3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΘЗεгчΩΧлΔεпЙЪмэ():
    value = 286043
    text = __import__('base64').b64decode('RXdZQ04xaDc2UTlMbUI1dnRmaFA=').decode('utf-8')
    if len('') > 0:
        _dead_3053 = 413
        pass
        _dead_5022 = 851
    total = value + len(text)
    return total

def _ΚЕСЩΤΨтΟэБ():
    value = 636477
    text = __import__('base64').b64decode('Q2laUmpHMFVYdU56MGkxVkV4SXU=').decode('utf-8')
    if len('') > 0:
        759
        pass
        850
    total = value + len(text)
    if False and True:
        722
        pass
        pass
    return total

def _ЧμΒΔΤФьБΑкяЛ():
    value = 903910
    if 27 * 20 < 0:
        547
        _dead_9659 = 970
        858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwDtYwEcpq4mCi7633igGCEh9UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζξΛΒΥЛАΝΤ():
    value = 668392
    text = __import__('base64').b64decode('Tk5LX3FCTFpKYXV4SXBBaEZLWXY=').decode('utf-8')
    total = value + len(text)
    return total

def _оЮΣκΦΗчρ():
    if False and True:
        _dead_8189 = 691
        pass
        _dead_8945 = 477
    value = 171738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHbbWEFsy5cICgas6WKnLhUZ90k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        476
        _dead_8068 = 951
    total = value + len(text)
    return total

def _ηΒοЙэящΩдЙънΤς():
    if len('') > 0:
        _dead_8080 = 452
        _dead_6889 = 136
    value = 933369
    text = __import__('base64').b64decode('RXZmTnluSnJJS2pueHRMcXZtOTk=').decode('utf-8')
    if False and True:
        899
        pass
    total = value + len(text)
    return total

def _ΦγДΖοΕЭУЬΡъРэюτ():
    value = 337664
    text = __import__('base64').b64decode('cW5Da0Z6Wl9nSUVZeGttOEZINVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΨЙцдΤучεΩэζ():
    value = 537259
    if 48 * 34 < 0:
        _dead_5342 = 170
        _dead_5898 = 542
        pass
    text = __import__('base64').b64decode('Qm82d1dTX1NCYXo3NTFPYWp1TkI=').decode('utf-8')
    total = value + len(text)
    return total

def _мьЫГШьеиΞшъГ():
    value = 426450
    if len('') > 0:
        407
        pass
        pass
    text = __import__('base64').b64decode('SkFfb0MwV2l5TTdNUFVnd0R0SXY=').decode('utf-8')
    total = value + len(text)
    if 71 * 50 < 0:
        _dead_2596 = 87
        _dead_7348 = 144
        pass
    return total

def _ινΟеЭЧΧДСмсю():
    value = 431384
    text = __import__('base64').b64decode('ekZYZVhORHoweW0xSVpHMlFydUM=').decode('utf-8')
    total = value + len(text)
    return total

def _яξБцьАГцΜНсьТ():
    value = 168608
    text = __import__('base64').b64decode('QnozdTF1dnpfTkhzMXllVFk0alQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _хЧйоανжМΠБΩХаΝ():
    value = 555074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBvgfmMM7YQ7EiG24kK6FywD01E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оδяаХщтоФ():
    value = 319096
    text = __import__('base64').b64decode('WUdjc2RBYXRKOU1VUm5fS004cWk=').decode('utf-8')
    total = value + len(text)
    return total

def _БоζЬςГДΒχ():
    value = 511392
    text = __import__('base64').b64decode('Zkg1YzlWVktuUFFMNEhBbFVOeEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ζνςАΓэАРэюξ():
    value = 403419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXf3WXZh0L0zHD2r5WaKOg8e40I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τθΥъЫΛЯД():
    value = 591141
    if len('') > 0:
        4
        741
    text = __import__('base64').b64decode('VjZFcERMYTVPU3BsdmxQY1lCX0s=').decode('utf-8')
    if 50 * 9 < 0:
        _dead_8253 = 731
        _dead_2484 = 778
    total = value + len(text)
    if len('') > 0:
        _dead_9271 = 188
        _dead_1408 = 334
    return total

def _ξокИфйΖβ():
    if len('') > 0:
        pass
    value = 824857
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dg2xVFZv/ZoFMhah6WGBIjc74XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щбдΡвЕεдИУснюψΒυ():
    value = 703853
    text = __import__('base64').b64decode('a0xFZWh5Sjc1NkZSdXBxcVFNcjk=').decode('utf-8')
    if 37 * 28 < 0:
        648
    total = value + len(text)
    if False and True:
        _dead_4846 = 560
        13
        978
    return total

def _дКпφяжρЛπΗκΥАщ():
    if 31 * 50 < 0:
        _dead_1148 = 595
    value = 112905
    text = __import__('base64').b64decode('RkNJN0dBcDg4d3V5SWFBTzN5dE4=').decode('utf-8')
    if 50 * 41 < 0:
        969
        _dead_8725 = 524
        69
    total = value + len(text)
    return total

def _ФуθχΡХΤЗΟМАаυ():
    value = 288904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EynzYVxpz5skODut70OHHnY5/Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕЯюφИЩρΡцωЪ():
    value = 279892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRC1fkE7q5wVAhj0+mCbFw0H0Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 82 * 79 < 0:
        523
        301
        428
    return total

def _ημУюΝДξξЩπΧгΥηб():
    value = 255343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSaxZX8K0a8uaVuzwEaTbD0n7j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 63 * 14 < 0:
        pass
        681
        _dead_9943 = 6
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΒгΕфνнЩσсπВΧλВην():
    value = 872546
    if len('') > 0:
        _dead_2784 = 377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzvKfUYG37E2DgSWwlKaED0r6k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣбчνηНυоКρφΘΜ():
    value = 989728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCnWOnA26b0FbyT6wnqpFjw5tn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΔθλπεХСЕвИш():
    value = 277590
    text = __import__('base64').b64decode('emVZRnB6anJZbGdmWUJwOW54Q0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ρЙαλΡΓηнРф():
    value = 568871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDjXX1kw174gMViV6nyVYwIO5ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХщΒюПНеУуРεЙ():
    value = 652951
    text = __import__('base64').b64decode('Q21kemhsTE1qWk0wcHZpOWRFTTE=').decode('utf-8')
    total = value + len(text)
    return total

def _зΗΩБчζСΝξτθХΜΟ():
    if 98 * 17 < 0:
        pass
    value = 892782
    text = __import__('base64').b64decode('dmlKeWVQQjhIRXF1TlZRMF9YNmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ФЯςкηюαяΑΣ():
    if 56 * 40 < 0:
        703
        _dead_8220 = 771
    value = 894041
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhe3O0gr6v8KDwOM0nifGXA34Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        770
        574
    return total

def _гθШдυΡσРЗЙзεЖг():
    if False and True:
        pass
    value = 853946
    text = __import__('base64').b64decode('ZkRKb2JyN0ZJTlBBWGFLT1FFYlI=').decode('utf-8')
    if 54 * 47 < 0:
        pass
    total = value + len(text)
    return total

def _ΟйвЩΠΟΤυ():
    value = 301166
    text = __import__('base64').b64decode('TF9vR2ZpZ0xSVFBGbGNmSGpJNlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΒπψΚΕωΡ():
    if False and True:
        937
        725
        51
    value = 78555
    if 26 * 96 < 0:
        pass
        91
    text = __import__('base64').b64decode('Z1BOem94dzJ4NjN1WEJETFQ1eU4=').decode('utf-8')
    total = value + len(text)
    return total

def _кβκΔΛΛοσωБ():
    value = 668105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzzpeEcxqPwsHgWv0ka+OR9+slk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΨΗЫχоРΘε():
    value = 863023
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQnpQGQRp6cPNxqK8V28OCcQsUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛКαΝЭγγвзИΩс():
    value = 340389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS7XSUsh66waDVv242OKNhwg9Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХвΙмхядюσΗ():
    value = 398944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH/+dmcb1J4qPiS3m0OBDQQb73o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7676 = 881
    total = value + len(text)
    return total

def _аνμηаКЦЮΥΘπς():
    value = 315900
    text = __import__('base64').b64decode('VFVNWWxMY0YxM2xZTmd1Qk5RWUw=').decode('utf-8')
    total = value + len(text)
    return total

def _бжηайΠΡЗ():
    value = 712468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA3OeVxgrYk5OymR93rBYR941Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 1 * 85 < 0:
        pass
        pass
    return total

def _шКРσВшЙΟΝу():
    value = 348384
    text = __import__('base64').b64decode('cVNkNmh3STNWY0FJUXFaRWIwR2I=').decode('utf-8')
    if len('') > 0:
        _dead_8199 = 233
        pass
        _dead_5357 = 538
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _λЪАйΡφτЮψЪяхΜьΛ():
    value = 444392
    text = __import__('base64').b64decode('bGZ0b3E3ck9wdFhpUnNTMWNmVE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡτΔеЖσφδежσ():
    value = 269085
    text = __import__('base64').b64decode('TmVUMFdPOF82aGREbVc0Z0puNEc=').decode('utf-8')
    total = value + len(text)
    return total

def _вруДтχфХΘιΥ():
    value = 967553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHr3Y1wM7IMKKVabwkKAHCYg0mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σλгσδЯгЖηβΡзΗМе():
    value = 806263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ki7iYVs2z/lbOF6Fw3/CJj8VtGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РэхоашшЛςфγжρф():
    value = 702038
    text = __import__('base64').b64decode('V2VFcTF5Y0Rrbk5waFhyYTFicjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠτймΥЖщММлδА():
    value = 248336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjX2S3Mu2r41HyP1nluIO3UE62s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4455 = 668
        pass
    total = value + len(text)
    return total

def _фΑΡфЦΚΘλмГρмЦ():
    value = 489134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn/HVGZr14dQCByhnkaIHy4Y7z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыългΟмрИлцш():
    value = 481356
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCzOflowwbEiLiW03WG4ESYn9H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ЛчлуΔГЗσГΝЪΣ():
    if 80 * 27 < 0:
        pass
        _dead_3366 = 968
        pass
    value = 662069
    if len('') > 0:
        _dead_8006 = 277
        _dead_6908 = 160
        646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KinxP1Q17Z0gKQe6+3ScDAh89kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΒдэбΣеЯОοΛΝСэ():
    value = 246186
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESjbTHkY8voWGByp8UO2NncitVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯюМкпнПяξсΦ():
    value = 17053
    text = __import__('base64').b64decode('V0Z5ODZoSm1NYVRDWmh6Z092aDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΣνИΤЗпΘ():
    value = 227060
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AybjPEU954AzFFiI8maDMxc7/Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лПΘМЕЫуйСУтζрΠ():
    value = 663238
    if False and True:
        269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDj0WW400PoLYj6U4lCZEjAJ/UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8698 = 561
    total = value + len(text)
    return total

def _αγлЦЪначРυОΕяΙΝω():
    value = 898951
    text = __import__('base64').b64decode('TU8zMmRCQWVCTHhGTmw4OEx2Y2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ШчовшмδЫξφΡΒ():
    if 74 * 71 < 0:
        511
        _dead_9370 = 303
        _dead_2704 = 808
    value = 589679
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bjv9RH4K9L08AiKE+V27Nzd77UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФИзХΡБχςБЕЬχκ():
    value = 635281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC3oamEUzbAQNRmVz3qiGAYd83Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _αΓΒΠпειяθΥсшцΩΟ():
    value = 179790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz7lbQUT2KsrExqN2F2BMTAB42g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υНтпцЪшаΣΛοЕθпΨ():
    value = 440131
    text = __import__('base64').b64decode('SlhtMXZBeEQ2Y1hDTlBFbHNDNkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩчЛтψΜμΨφоε():
    value = 670585
    text = __import__('base64').b64decode('UmpwNnB1VGszS2ZOaERWc1k5Q3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒИЧЖзВЭьфΩ():
    if len('') > 0:
        828
        _dead_2450 = 795
        559
    value = 165976
    text = __import__('base64').b64decode('d3JySVhnOWoyVkpRTzd3X3F0Mk8=').decode('utf-8')
    total = value + len(text)
    return total

def _уΜыэКиЙП():
    value = 617336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In3GNkIappAOaACE7lzJBnEp3kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯфЕатψΖΚΜгжв():
    value = 649659
    text = __import__('base64').b64decode('dUIzWmNlVkdna0t4SFhPcUxLX0E=').decode('utf-8')
    total = value + len(text)
    return total

def _αдкдψρуΞЙд():
    value = 104334
    text = __import__('base64').b64decode('TTlsUjNmeEZyRlBJQU9nMFpPQmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЬθыГΣΑЦδщЩΡ():
    value = 883782
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn32R1kt96YiBV+rznS9J3QQ1Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШцσхτпηэΘθΘλαГк():
    value = 846467
    text = __import__('base64').b64decode('eEVhbjV4anNBcmxSSUNEeDFPUHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ДεХйБрзπΣКΜвБ():
    if 98 * 72 < 0:
        816
        _dead_8398 = 566
        pass
    value = 141963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQfHaH000/xWLAOa5Ve6IQh+8EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        523
        pass
    return total

def _ΡΞЬΤзчИХοψбДяκ():
    value = 2862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CATCbEMwxpkRGRm73AO2Fj0Q4Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьМηмΡΓΡмυ():
    value = 89201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bzq9ZAcYqa0yOVys61rDGC0g7Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δМχЖОΜτБщТСВ():
    value = 53196
    text = __import__('base64').b64decode('YkNiMXFsZXA0TnlfX0FkaThFUWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙρщЩφЖрΝλΨψНηо():
    value = 762044
    text = __import__('base64').b64decode('UEs0c2YzRGxGYjBJWFBySHF4UEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ьяΒсΧΡмНИμч():
    value = 917824
    if 12 * 75 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FynqaVUK6KUzNT22mgHBJ3Iask8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        484
        444
    return total

def _гнΘσΠЛцοУχаПчи():
    if 48 * 52 < 0:
        42
    value = 350040
    if 61 * 67 < 0:
        993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3i9eVg4z5gQKAH22lS5Oysay3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЖпкфяΡЦпДΓЦΧ():
    value = 247377
    text = __import__('base64').b64decode('c3JXMkpoUXdjYng2NE41VG9OVGM=').decode('utf-8')
    total = value + len(text)
    return total

def _гЪΥлЙаГжθηНλΧΦг():
    value = 359282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kji9amszqrApayen+X+mNhd510Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖБЭЖκμпνЬХЪю():
    value = 581142
    text = __import__('base64').b64decode('dXgybUNVbkpXM2ZwUGlYRUNhVWQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6776 = 520
        _dead_9367 = 745
        _dead_4508 = 96
    return total

def _δЛФΙЩЗзЧΑΥ():
    value = 818216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHbRRgA+wYcsHSyTnESjZC5/0Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яνиΩΞβΗфЭΜωΙКЛйУ():
    value = 558774
    text = __import__('base64').b64decode('dmNiUkJBUkR4ZldRbmRFWk1JWEg=').decode('utf-8')
    if False and True:
        _dead_6927 = 728
        185
        pass
    total = value + len(text)
    return total

def _ΖθуλΘεзОК():
    if 68 * 66 < 0:
        _dead_1107 = 64
        909
        132
    value = 560871
    if len('') > 0:
        446
    text = __import__('base64').b64decode('ekI4Rk1qaUxZWUFNTllyQ1ZFRnU=').decode('utf-8')
    if False and True:
        495
        _dead_7187 = 486
    total = value + len(text)
    return total

def _ψыЭΝМжХΓ():
    if 61 * 71 < 0:
        584
        _dead_7305 = 854
    value = 394065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB61agEBp68rYhe322yhPCon/D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔЕтΡылэΘ():
    value = 373218
    text = __import__('base64').b64decode('UkpTQjh0T2N1UXVkUVFkNWlzS1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΣνακΘКΖуηνΔЦБЗ():
    value = 469468
    if len('') > 0:
        457
        608
    text = __import__('base64').b64decode('RkRKcjVMMzQxTmd1czRpdDJselk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        417
        pass
    return total

def _ΜйπПΤΙβςΡъνлщву():
    value = 692426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXv8d1kj7rg2DySV7Xm8Ey4X3mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑωΦлΥаюОΤКЛ():
    value = 948029
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSjDQgUJ04AwYx+S3VKZOBp3tzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъсЫΛζцкгМс():
    value = 709233
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgvsOEY6pqEPNwf7w1TAPygA6WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γГЭХιγЦУеря():
    value = 203518
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAP+RX0g6IovGDi53wSkGRY/0kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εйТйтΑψΡΘσμЭО():
    if len('') > 0:
        91
    value = 253931
    if len('') > 0:
        _dead_6684 = 448
        pass
        13
    text = __import__('base64').b64decode('WnhXcFNZc0pQZmJiNmRfbjU0Ujc=').decode('utf-8')
    total = value + len(text)
    return total

def _δДσЪРΠэищΤπΩθЗ():
    if len('') > 0:
        pass
    value = 518161
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwvRZAUf2YwZEV77kQSqHAgl5W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6379 = 299
        pass
        _dead_1796 = 120
    return total

def _ΗРагИΥоεыμτЦΜδ():
    value = 57780
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzfTZAcv24INPD6Rm1zJOgs2/UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 88 * 18 < 0:
        pass
    total = value + len(text)
    return total

def _ЮПЩчЮετΤξщδнοΠ():
    value = 115870
    if 75 * 25 < 0:
        _dead_8663 = 433
        _dead_1911 = 373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTy2PmYv5ooOIxWs/1zIHTwN9Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 12 * 6 < 0:
        _dead_9081 = 134
        _dead_9713 = 476
        pass
    return total

def _сΡΚВАКυγгвАΗАκоы():
    value = 579773
    if False and True:
        _dead_8176 = 842
        _dead_3355 = 345
        _dead_5436 = 770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PB+wVnMK3/kuKjWN8XSFIC0ezXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4854 = 900
    total = value + len(text)
    return total

def _ΑйТΨΘчΚАиκи():
    value = 692900
    if 42 * 28 < 0:
        _dead_2521 = 135
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DC7oOwM/0osZYyK26m66MA4M/kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        593
        _dead_3481 = 76
    total = value + len(text)
    if False and True:
        _dead_5205 = 397
    return total

def _ιНгабФДиαπЛДΡλσ():
    value = 904128
    if 58 * 60 < 0:
        _dead_9996 = 849
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAa2V3cuqr4iLQiv22G9HTMZ7zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΧВψжΟьκΠζжУΝ():
    value = 137638
    if 9 * 86 < 0:
        300
        _dead_7213 = 780
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M322dwAA06FUIwT1x1CqID09znc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5529 = 893
    total = value + len(text)
    return total

def _ЩξБЧюΤЦюαΣ():
    if len('') > 0:
        905
        649
        _dead_6442 = 674
    value = 291694
    if len('') > 0:
        _dead_9166 = 259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgH9WH4UqZcyHRb0xlGHOiYJ1Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _иκΕэЫйшΣмΜτΠы():
    value = 953346
    text = __import__('base64').b64decode('RXhSWmJKR1FQdElfNWcxYVdTNV8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕοΟγрωмςσΔ():
    value = 233323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh7VXlRsrqciFCWt4AHJGhUu6F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮδБпоЦξРτЯъУяθ():
    value = 762939
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyPVQloS0ZxVIyuJnGbBGBMd/Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЬЭΕυΣχΓЭΠБλС():
    if 44 * 21 < 0:
        pass
    value = 373199
    if 84 * 57 < 0:
        pass
        pass
    text = __import__('base64').b64decode('TmRFR200R21FeWNyX1o3RlJHWUc=').decode('utf-8')
    total = value + len(text)
    if 24 * 53 < 0:
        669
        _dead_1380 = 481
    return total

def _ΔОзОюКοΘсцаРоЭьμ():
    value = 422116
    text = __import__('base64').b64decode('RmVCT0NxWjZORHdmc0R6Rkpldng=').decode('utf-8')
    if len('') > 0:
        _dead_3605 = 818
        pass
    total = value + len(text)
    return total

def _ΨлНΡφΦΓЯер():
    value = 246929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBy8XksPx/oVFAOyyUC7ICMf7WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΑгΩхΙρΔщ():
    value = 378522
    text = __import__('base64').b64decode('cnNyTnhidjY4WlVwbm85cU5lWmM=').decode('utf-8')
    total = value + len(text)
    return total

def _тκыжςσВεΩ():
    if 53 * 19 < 0:
        _dead_7031 = 653
        pass
    value = 179112
    if 95 * 3 < 0:
        _dead_1231 = 913
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHj3bwYpzp4CFB+I536JB3MOvXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        758
        820
        _dead_4550 = 827
    total = value + len(text)
    return total

def _нΣхсьРСтμΨΟ():
    value = 566119
    text = __import__('base64').b64decode('QXpmem5ZUkVRZDJVVlRsVzdRMEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ХЙзфΟтΥЦΣΦЖΘэЫР():
    if len('') > 0:
        pass
        775
        pass
    value = 89491
    text = __import__('base64').b64decode('TnV5ZFdKRThnQ1FGSVY1WVFSXzU=').decode('utf-8')
    total = value + len(text)
    return total

def _вЕщЖТαмнпςЖεΥъУТ():
    value = 136345
    if len('') > 0:
        810
    text = __import__('base64').b64decode('cXg1MlNRbDEwS1NjMkJvVzVxVDY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        173
    return total

def _ΚыεяΙζдгеджшΔΖ():
    value = 632054
    text = __import__('base64').b64decode('UHZzRl9tYUM4VWhQSEswa2ZETHM=').decode('utf-8')
    if len('') > 0:
        92
        pass
        pass
    total = value + len(text)
    return total

def _йеЮοЕθННсв():
    if 35 * 39 < 0:
        pass
        695
    value = 14567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAq8NkIBppAQaFi5x36+HS825lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫБЗЛΕξнοж():
    if False and True:
        _dead_2355 = 301
    value = 198619
    text = __import__('base64').b64decode('S1laWDdneUplRE9wb2ZwUV9WMHE=').decode('utf-8')
    total = value + len(text)
    return total

def _υниΒГЩλбй():
    value = 542986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESPvVlo8054wPCWGxl6gFXM37l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 53 * 22 < 0:
        624
        pass
    return total

def _ДνеΙмеИсюитбεМ():
    value = 63794
    if False and True:
        pass
        262
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnbOZ1gdp68JEB2nmVylNjwax0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4491 = 988
    return total

def _шτМгзωЛщАκК():
    if len('') > 0:
        pass
    value = 166529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3jcN0EM16YSHSO67EHJYi8lw1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        892
        956
        _dead_7184 = 187
    return total

def _лфΜφОξиГйе():
    value = 227987
    text = __import__('base64').b64decode('dXlnMWRXbFJIaXNLaWp6NmllTWU=').decode('utf-8')
    if False and True:
        _dead_5958 = 553
        728
    total = value + len(text)
    if 65 * 55 < 0:
        781
        107
    return total

def _ΘчΝКσΛБσцЕд():
    value = 624257
    if False and True:
        317
    text = __import__('base64').b64decode('eDBsZDNKQzB1RXhXWUluMF81STA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΑОψсΒВВС():
    value = 661740
    text = __import__('base64').b64decode('eU9odTVpbjFqalo4WG91OExwcUk=').decode('utf-8')
    total = value + len(text)
    return total

def _πЙπЪαЕкДΝДГΩΔц():
    value = 370425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lzz3PXMj9ZcvFQ2zzGWzJXI1sHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΠβςςεςуΞΣΑ():
    value = 118717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LC60On0IpvA1NCSk71LBZQN9sV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γЩυУΒКΕьΡ():
    value = 804285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTfJfVhp9JIbHwiG/E6+LgQZ91k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _апидПλΖг():
    value = 644220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAy0ZV0G0IYJEiryz1zFPycaszg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΔюΤβРΗτυЫфαууτ():
    value = 503368
    text = __import__('base64').b64decode('T1diV0JfSDZnSnVBWmJiSTBqTk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙяζеλСΖΗЯΞтζЫαЯ():
    if 2 * 77 < 0:
        pass
        152
        741
    value = 937153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQbKYwQ0rLEFEVin2VWEZj0K6W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γЩщμКьМЙДоежЭ():
    value = 251525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgThXkUY37A7b1mkxW+0Iwkl0kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΚυЙΣΑδκсЕΖтОЬΟ():
    value = 855660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh3USQcezbo5DAipnkWAGhB43lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚЭΓΑΘЯДπηЫ():
    value = 598882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAG1RGINqJEWGD/13kXGLHY283c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞλπХΕЛеоРБЫΖ():
    value = 2578
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTXCY3Yu9f41FCuH63eEGggl0zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_2667 = 67
        _dead_9278 = 142
    return total

def _ФцρсафГЕ():
    value = 165576
    text = __import__('base64').b64decode('UnpXUmNvQkUwTGR0N2RRZU5fZEU=').decode('utf-8')
    total = value + len(text)
    if 10 * 13 < 0:
        pass
        311
    return total

def _μεнρувуЬЪИЙεαβ():
    value = 657505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChrJfEYszbITGSWX4FCxGXck5Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4354 = 371
        pass
        286
    total = value + len(text)
    return total

def _аκΘρБεйДэΙρаΟь():
    value = 752228
    text = __import__('base64').b64decode('S1hfcDF3eWZxbUhydzQxZHlyUUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ыаΧδЩΘυМР():
    if 6 * 94 < 0:
        _dead_7994 = 915
        _dead_1658 = 180
        842
    value = 425425
    if len('') > 0:
        pass
        261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQPvXnAg1KAMPgukwXySOx8+8jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4340 = 384
        8
        pass
    total = value + len(text)
    if False and True:
        _dead_5616 = 753
    return total

def _аЙПτЩЧинςγЖИζРи():
    value = 85753
    text = __import__('base64').b64decode('TXZDQk9RbjVIc1JnaklvYzk2QkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥУЮннКςсΖуΡ():
    value = 556615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyPMVwIS0rJRExaQnn2ZYhAptGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        493
        845
        pass
    return total

def _сΩΕτчΜΛθ():
    value = 935584
    text = __import__('base64').b64decode('eVZvVm1Vd05FWFplZnVUVTJEWDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ναЦИзХфо():
    if len('') > 0:
        94
    value = 330659
    if len('') > 0:
        pass
        _dead_9655 = 247
    text = __import__('base64').b64decode('ckw5S2c5alhpa0dOa2FIWkZTNF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯтξЮδΞΗΡуФюπ():
    value = 709649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LS7nQV4U5KxXLFyT4lChZCN27Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦЖльζаΤκсщΧΩ():
    if 92 * 96 < 0:
        pass
        _dead_7168 = 793
    value = 906132
    if 32 * 44 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgHCOQgA8KMSMhrzmW6FITcsslk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8233 = 970
        435
    return total

def _ΠΔκΧΕЫΣξΒшЙьαкκΟ():
    value = 685327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXvPOFs4r7lVCiyAxGeZEw0utzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7490 = 294
        pass
        _dead_3570 = 586
    total = value + len(text)
    return total

def _рмЯДΖвФΝЯсН():
    value = 346889
    text = __import__('base64').b64decode('dWxPQU03b0I3X2FWdHZ6TExqOUg=').decode('utf-8')
    total = value + len(text)
    return total

def _уЫςΦΞлжΟчδъЦй():
    if False and True:
        pass
    value = 526203
    text = __import__('base64').b64decode('U0szdUNidXlSanFVOUpJVEhocVg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4747 = 807
        580
    return total

def _υοΠρоЪχъΓ():
    value = 330956
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChXWaGkJ0L46CwGN4QW0BTQd/HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λИβΞШτγмУиΔ():
    value = 727731
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3/wUQc36Z4GLyGC7QKABHMr4G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΜΤъАβΧУΡ():
    value = 421338
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCjBSQge0LJXIhWt8FCZPwsQ3nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чБкмЯжмШОЭЧдν():
    value = 602443
    text = __import__('base64').b64decode('aDRpbkpzYnc3T2lnZUowTTRiZW4=').decode('utf-8')
    total = value + len(text)
    return total

def _вуШολΠщч():
    value = 175164
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBu3Wlo3yIMJCzu1x1W/MzAoxzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4139 = 900
        _dead_9063 = 788
        _dead_4994 = 734
    total = value + len(text)
    return total

def _θιКΔгкΤΥюЫф():
    value = 188322
    text = __import__('base64').b64decode('VjlfRmhQNnUzV3BKMUlGSFlkZGg=').decode('utf-8')
    if False and True:
        pass
        _dead_1806 = 324
        930
    total = value + len(text)
    return total

def _ЮЮηдΚЦχΖШΞΡωхω():
    if False and True:
        _dead_9317 = 969
        925
    value = 727370
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('bUV6eGJTRFFtZFJnM3ZsdHoxV3U=').decode('utf-8')
    total = value + len(text)
    return total

def _нйΡРвΞπσΑЩ():
    value = 320238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3j2bEJp3fAtMTiK5niTDCg87VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΩПГЪЛхШΥцяΨ():
    value = 967862
    text = __import__('base64').b64decode('anducHNqUzNPTnlURnlnT1pYUk8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        158
        pass
    return total

def _ьпιяΣюΡЛ():
    value = 899088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwfsSlcc2J0GNz+k/3qvOigjyUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 45 * 66 < 0:
        110
        408
        _dead_9398 = 879
    total = value + len(text)
    return total

def _дιξсншςЕΞΘβερ():
    value = 548327
    text = __import__('base64').b64decode('Y1dFN1cyQnNDX25Gamd5RVhnTFk=').decode('utf-8')
    total = value + len(text)
    return total

def _βРцйзζΗΘоΡЩΚфЕЗΕ():
    if len('') > 0:
        867
        pass
    value = 285814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mhe9ZWI6+IIMbQWSmFnJHhJ282s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъоΖОУГζЭЗρξКζГяμ():
    if len('') > 0:
        pass
        _dead_7752 = 444
    value = 514932
    if False and True:
        341
    text = __import__('base64').b64decode('bE03X3E1T2FBV2FDMjFoSzlxOGI=').decode('utf-8')
    total = value + len(text)
    if 27 * 79 < 0:
        pass
        pass
    return total

def _ωъцΞзЪЙРΔΠРΡП():
    if False and True:
        pass
        _dead_2312 = 504
    value = 167352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgfTT2tqyZoXMByX6wCCDSR6sFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ХВлуПКпξДп():
    value = 284654
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICLLTQka3/lQPQ6a/Wm2HSkMvHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 48 * 23 < 0:
        pass
    total = value + len(text)
    if False and True:
        670
        _dead_6452 = 348
        492
    return total

def _оθαЖзЕЗйоИБτδр():
    value = 592669
    text = __import__('base64').b64decode('VnpoaW92T0xnVHgxRk45bWdfcm8=').decode('utf-8')
    total = value + len(text)
    if 83 * 91 < 0:
        pass
    return total

def _АбМлКщΘЮАиФОχειΖ():
    if False and True:
        _dead_3920 = 293
        _dead_8567 = 823
    value = 775593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhjoR3UN16RXLymCnGOVJB999F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8193 = 219
        _dead_6051 = 157
        pass
    total = value + len(text)
    return total

def _яΟΖаχδЧТΚмйУвΨо():
    value = 566564
    text = __import__('base64').b64decode('ckRNT1Bmck91ZXp6eHNBNzNaUWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()