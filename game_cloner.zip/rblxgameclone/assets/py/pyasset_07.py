#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _нъфвΥтΙΗ():
    value = 863436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRfqdGY/xJxTFSOb93OIOzIN6mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡγЙТσΙНΓοэθΗχЕуΥ():
    if False and True:
        _dead_2172 = 560
        _dead_7054 = 339
        _dead_1605 = 614
    value = 336237
    if 71 * 86 < 0:
        469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgXeQGkgpqszCQmMxwecBAF37Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7969 = 229
        785
    return total

def _πνΣσοщЧΡбэξШн():
    value = 425877
    text = __import__('base64').b64decode('dEl4c2JvRXJQSE9nY0E5SW55Vk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΕΙΡнъΙЮΧМжаφ():
    value = 686442
    if 11 * 36 < 0:
        _dead_1888 = 366
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn/hZl4N9IEXLAKPxHuGJTIW5VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _УзαъюЭМρατψψΜχВ():
    value = 779274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD7iV2seyv0gFQqw5nOHPgYe9mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΕΞκεИВюΨЖПИъ():
    if 22 * 80 < 0:
        pass
        275
    value = 233316
    text = __import__('base64').b64decode('ejBiVjdiX1pZWmszT0ZwanNOTE8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2851 = 2
    return total

def _ОΤХΥΞΜΦбλΨОυΒ():
    value = 537772
    if False and True:
        476
        _dead_1357 = 991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQblaHce+JEVCSXx72+0GAYa9FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъπΕΦТΡхδΟΝΘМτςл():
    if len('') > 0:
        pass
        pass
    value = 662888
    text = __import__('base64').b64decode('TnFDeWxvUnUyMHdDYWtBbGxEd3o=').decode('utf-8')
    if 19 * 9 < 0:
        183
        598
    total = value + len(text)
    return total

def _χΠРψПзηяпβτШьуω():
    if len('') > 0:
        260
        804
    value = 221674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3bsSgZh96YSND+pmVnGESEF80s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цбαплЛлЙγΜЮ():
    value = 995883
    if False and True:
        pass
        pass
        _dead_4589 = 368
    text = __import__('base64').b64decode('UmRxcUdXV2IyWTNpNTBuak1wNF8=').decode('utf-8')
    total = value + len(text)
    return total

def _цАМтяжЪгζλΛΩМξ():
    value = 434474
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHvWUQcR2q8Qa12K/W6SEQcI/Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        904
        710
    return total

def _йΨТλυЛКЖСΧк():
    value = 556549
    if len('') > 0:
        500
        185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgjdPn0N9bwyPheb92GaEgl56Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТцфьΖУНΔрφв():
    if False and True:
        pass
        _dead_1287 = 842
    value = 737074
    text = __import__('base64').b64decode('T0d5OWNsUjVoeXg3SkhERk15aUg=').decode('utf-8')
    total = value + len(text)
    return total

def _чНивσΠΩлДΨхрρ():
    value = 545486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiTJX3wsxIo0Lz2tm0ySHwgc138='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛζЭβяъΜтАгбΑп():
    value = 440111
    if len('') > 0:
        134
        127
        pass
    text = __import__('base64').b64decode('SkNqcklUalJLWTk2bEdJOXpIc1U=').decode('utf-8')
    total = value + len(text)
    return total

def _φрοАъБрВХЮя():
    value = 666122
    text = __import__('base64').b64decode('R2w3M1ppRW5MNVh1RTdDWVRBRlE=').decode('utf-8')
    total = value + len(text)
    return total

def _ДбνπΠΥΟΟΡ():
    if len('') > 0:
        pass
    value = 851220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDnvQAhopolRaz6y7USpHysh83g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩттаΤцнΥВЛаκЭДΤЛ():
    value = 290303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnezV2AL9qxTKgiM+mDEBgIG3UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κοСЕΥΥтЩшу():
    value = 965661
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTXgWF8T0qs6NiH15n66IDcC7UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юЖθΟЧЗЦыγсоЛМеР():
    value = 832348
    text = __import__('base64').b64decode('clVNQ2d5cXNzbmdYdFE0QmFBdWs=').decode('utf-8')
    if 61 * 69 < 0:
        666
    total = value + len(text)
    if False and True:
        339
        _dead_1473 = 216
        _dead_2264 = 610
    return total

def _ΙяъбАНЧψнθлθгЗμω():
    value = 771239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz3cT2Ro0o1UFAein1WUDjAZ10c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        371
        pass
        _dead_8887 = 888
    total = value + len(text)
    return total

def _ТγΘχйΗΟЧηХΑ():
    if len('') > 0:
        pass
    value = 172171
    text = __import__('base64').b64decode('c0ZEaE5lR1ZDcVdBZkQwVUVSMEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _шΧэΛАЬΠν():
    value = 845421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRbhNl8+/Y4VHi6FxVSTOjQg/Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _БΔΨЙθОЕΞЩ():
    value = 113910
    text = __import__('base64').b64decode('THR1Yno3RzBjc3hNZ01jRVdQUVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΨоГЭζΠΒлчп():
    value = 575853
    text = __import__('base64').b64decode('bWpQMWU4NUhkUE5US3dOd0d0TkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓαзЯЮδΜяШъΣΘЧ():
    value = 873034
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dyq2NkZg9L0oDyP0/EyhOXQc3kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        893
        pass
    total = value + len(text)
    if 35 * 48 < 0:
        pass
        _dead_4525 = 424
    return total

def _гЫеΒЫνςПйΡгдъΔШ():
    value = 370189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3ruPls6xr4LHD+qy3qAMwh6sms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯηοйΜИТβуП():
    if False and True:
        pass
        957
    value = 256704
    text = __import__('base64').b64decode('YVJZV25DWkY4N3RYYWlYRnJQb3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ξШΦЩфУБД():
    if 49 * 43 < 0:
        pass
    value = 834203
    if False and True:
        _dead_3494 = 694
        _dead_9298 = 709
        _dead_4361 = 485
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izb9Pl5r8PkMHB7w6wGlC3cexlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        430
        _dead_3780 = 237
        pass
    return total

def _юерΡЕΘΤшΖΟνΠΙюν():
    if 25 * 93 < 0:
        974
    value = 988248
    if len('') > 0:
        387
        pass
    text = __import__('base64').b64decode('a0pVcjA1MFNzTElyYjBCMXJUV2U=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЮДФγоΚйЮВСзТφς():
    value = 250713
    if False and True:
        pass
        _dead_8986 = 640
        pass
    text = __import__('base64').b64decode('bEVUX0w0azkwbWJtS2JlNnBfZGs=').decode('utf-8')
    if len('') > 0:
        961
        _dead_3890 = 206
        pass
    total = value + len(text)
    return total

def _ξоεжзИхыДρБХьΗςЛ():
    value = 74665
    text = __import__('base64').b64decode('VE5kZERycEFUQ2VtbGp0Y0hsQ2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ВЦгФьГЩПι():
    if len('') > 0:
        _dead_9093 = 199
        _dead_4787 = 916
        pass
    value = 494893
    text = __import__('base64').b64decode('bUdoeGZwN2ZRdW81clVuWHZzUnY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6844 = 2
        866
        _dead_8745 = 61
    return total

def _ЖгАοΕНМμ():
    value = 982516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRfLY0Zq26syOCOh8AK8JnIdwmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9742 = 748
        _dead_7662 = 609
    return total

def _еогΠСοηлЧШП():
    if False and True:
        _dead_4088 = 231
    value = 523430
    text = __import__('base64').b64decode('RmxTeHdlNllHUmRMbFVvTVNTTEs=').decode('utf-8')
    if False and True:
        _dead_2329 = 488
        _dead_5900 = 324
    total = value + len(text)
    if 80 * 80 < 0:
        pass
    return total

def _яГδнааЯйжотΛ():
    value = 951522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lif0eUcJ1JwbCjDw2HCoEzIs11c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЩνфΒΖеЛЭ():
    value = 882675
    text = __import__('base64').b64decode('d0hiUjAwU1NuTVM0dE5tMXI5d3o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        868
    return total

def _ЩфэрωυΞΚςФζΣζ():
    if len('') > 0:
        _dead_9730 = 992
        pass
    value = 804047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAO0Y2lu+LAibF2nwWKSYRF212E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гχδКГясΡюЪ():
    if 45 * 81 < 0:
        pass
    value = 634466
    text = __import__('base64').b64decode('aHBOMXo5RFhBNzdnUDdIYjlZZVg=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ОφικяЬΚТИηΒшγ():
    if False and True:
        _dead_8129 = 756
        _dead_2515 = 349
        pass
    value = 245411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AX7jfQgU9vwEbjmMmV+jISof0EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υНХγАΒЯβθшэИДКр():
    value = 751823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCvSOlAt3a4mFBer4gWZPwZ/1H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΣζЯςηЪУДгζиЭАЩ():
    value = 453159
    text = __import__('base64').b64decode('cHJrODFTV0hqNTgwUjhhZVZOMnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗψрΓΩΚΦяκ():
    if len('') > 0:
        pass
        _dead_6321 = 488
    value = 396829
    text = __import__('base64').b64decode('V0hMa2tZY2Rld1hjcWRBUU1BVnY=').decode('utf-8')
    total = value + len(text)
    return total

def _πзрЩлузΜКθВθΚΞ():
    value = 740104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyjXQlUo1/AgbjyH5124AHAa7Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΚλΒРιЮΦФЦφΞф():
    value = 305303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB78O31q15oONlyOzUG8OSMo71c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЦνοσэλξЭТЕЩςшл():
    value = 842298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSyzOHsKrJcLEByW+k6HPB8/4V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πХηнзЦΕуΞ():
    if len('') > 0:
        pass
        pass
    value = 16906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgPtN2UMqaIpLTeKmUeyYzcJsTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        892
    total = value + len(text)
    return total

def _жгζΖДЧТΣΘΕξ():
    if False and True:
        _dead_1227 = 272
        585
    value = 793037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAr9b3QX6JkmCzWo+HC9FR88/Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥτрκтЦАπαФУбιдФ():
    value = 137128
    if len('') > 0:
        _dead_4772 = 936
    text = __import__('base64').b64decode('SDhQaWdjX1ZpdHc5R0ZrbUp1YTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ςφРыыΨШαкΟΔ():
    value = 731767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EH7vSFVt0aQWPCb0nF28IBwa610='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΕРΡКДЩйди():
    value = 860424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nxi0TFUupvwIDzez0H6XOTU64GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υШΔВΣηφцКΚ():
    if len('') > 0:
        _dead_8118 = 977
        pass
    value = 804827
    text = __import__('base64').b64decode('SnozQ0hPUVV3c1ZhODIxV2NBd2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _НЭΤынΣσΟИχлР():
    value = 518373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgzQbAky94QWKCSU20W3YScAt1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΒЮΩэΟθицЖфьх():
    value = 826959
    text = __import__('base64').b64decode('dldkTDl5eVl6TnZlTWhtZ3V6OVA=').decode('utf-8')
    if 11 * 51 < 0:
        _dead_3412 = 510
    total = value + len(text)
    return total

def _λΗОТΦлГньΛ():
    value = 382526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTXeQVI4+vAuAxmFywWSOw4d6Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬοδХпКюνБт():
    value = 311785
    text = __import__('base64').b64decode('SWQ3MGlkekVBbTNwcG5hWlR3ako=').decode('utf-8')
    total = value + len(text)
    return total

def _ьеΣРЧКдωφЛхσηЪлΣ():
    if False and True:
        pass
        _dead_4049 = 923
    value = 867981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB3BSlcdp50aGViVkGaGFnJ+tUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьгТαРыхЧ():
    value = 138527
    text = __import__('base64').b64decode('UUFjcktGenZRc0F3eTd4ZDNZMmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΨξмШχппΨшΒ():
    value = 368054
    text = __import__('base64').b64decode('VUh0MGE3UkhDYlhpZnRkdUYwb1A=').decode('utf-8')
    if 59 * 2 < 0:
        pass
        pass
        28
    total = value + len(text)
    return total

def _АВЕΑщΣДΖΑХυгзΑ():
    value = 246046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCbxd34K7bBTCRmxxwGYZ3UN/nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чцΨщЙΞδыМРγνзЪΞо():
    value = 224186
    text = __import__('base64').b64decode('SnVDUHZjaEx0NTdRZWFtRVQxaDA=').decode('utf-8')
    total = value + len(text)
    return total

def _уюРрαШμΦκγχШЮв():
    value = 357224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LynGeXYUy58aCw2NylGyPjck6EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЛΦΡΚВχНθы():
    if 35 * 59 < 0:
        _dead_8481 = 751
        10
    value = 93431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh38eXI4954HNzeG2liDDRY81Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΙΖΨρΝклβр():
    value = 988333
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jzr2fV0b7bAOFFmn/AKFZyl2zFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙмλΜμдбЩΩдΛξяьι():
    value = 300026
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxD9XWEa9LsmMiSNxne3FgA3tVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МртЗдΟЩтИАШνμγ():
    value = 242383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgC1YFhu9L43DyyW5FiSABQA23Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7652 = 864
        pass
    return total

def _ΠцКΝБκкδτμ():
    value = 373634
    text = __import__('base64').b64decode('YXoxb3BFbDZLaDRPcGtZdEp4c1c=').decode('utf-8')
    total = value + len(text)
    return total

def _υвфΩТшΥвсЬ():
    value = 583064
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz7Jf3ts14kJHl+HxUfJYyp53Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бθъЩΨξМхχБ():
    value = 121352
    text = __import__('base64').b64decode('RHhhRXI4cjZmVnh2TUNNbGtORUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ζКПЧУюУωφОζΛйΟ():
    value = 372126
    text = __import__('base64').b64decode('ajcydGREU3VhRGthZUltWXB3QW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΚБуЭэЬΕЪγκФχМ():
    value = 564203
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiLSZGJo1LkBYjyZ5364LSp8tzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αιъкΧβоФαΔπΙΝСМλ():
    value = 793229
    text = __import__('base64').b64decode('eGRfS3EzemFJem81OU51WExPdms=').decode('utf-8')
    if False and True:
        624
    total = value + len(text)
    return total

def _ЦηΘЗεЮтбМπΩεеλ():
    value = 20099
    if 45 * 45 < 0:
        pass
        _dead_3079 = 784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRnLX1M02pgsHlaxxAWcNhYFvTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ТΧШφсνβЯщЖεΖ():
    value = 827330
    if 61 * 74 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Igb3OVM825lWEC2hnk/EGSYK3kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7066 = 471
        866
    total = value + len(text)
    return total

def _ΣбΦΥшηωИЕΥиФЦΜю():
    value = 762105
    text = __import__('base64').b64decode('d3hTdlBUanUwYWljNDdWanhSN3o=').decode('utf-8')
    total = value + len(text)
    return total

def _яГоΝΘΣЮψУΝЛцМ():
    value = 139358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzvsWXsVr6QSLQ7z+mefBTJ8/D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СНЩρЕыψУВπЬτЦ():
    value = 227132
    if len('') > 0:
        _dead_3660 = 52
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTj1Vncs0aIvbh6S8mWnBwg55lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 36 < 0:
        pass
    total = value + len(text)
    if 76 * 35 < 0:
        358
    return total

def _кΞΗОνафбСα():
    if False and True:
        pass
        _dead_6881 = 890
        934
    value = 784474
    text = __import__('base64').b64decode('UnltVzlBbWZjQ2E5QUxBOFZWZnI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        49
    return total

def _πМΞчъΗΙΥμгфΑПШУα():
    value = 407300
    text = __import__('base64').b64decode('V2xPRDVyNHN5WHlMUkdrME9tMVI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_2544 = 46
    return total

def _РЕкΧΑΙзЩ():
    value = 818873
    text = __import__('base64').b64decode('blprR0pMak5EcmNqN3daNzdkZEs=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_4221 = 750
    return total

def _БабсаоρρСΘ():
    if False and True:
        _dead_4736 = 602
        _dead_8203 = 936
        pass
    value = 629517
    text = __import__('base64').b64decode('RnZ5QVpwZldzR012UzBzNUl0ZGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩЪСαьГΛзмпЙс():
    value = 131858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAnzN2cv7bIJaDeV+UGXYRwX9Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 95 * 36 < 0:
        _dead_7823 = 583
    return total

def _ΕрфЗофΕμрДφнпωб():
    value = 157777
    text = __import__('base64').b64decode('TlJmMkh5cmdSNkd6SzYzQzRzbkM=').decode('utf-8')
    if 100 * 3 < 0:
        308
        919
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΑЪмуΗθСэвЗ():
    value = 143171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwHDYn0J2/EHNyCi5U+GIXc643k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фДΡчюΞΤΔй():
    value = 32133
    if len('') > 0:
        pass
        _dead_4934 = 604
        _dead_3720 = 867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3fsd2Jp+ok5CBiT2UCyZA8Eym0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВжιкЫγчЪΑлнзфβΛΗ():
    value = 55795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH62Q3Br7/AsbTb0+3fDPC82yl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АрНρъПпкΕΛВ():
    value = 305917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA3HWQYhqKsCETa38lyVNTQc6UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛКЛГΘпНρΦаЖψ():
    value = 316937
    text = __import__('base64').b64decode('cXJGbDNMdTZDeTZ5MHc1SUdSdks=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΤΞтΨиΘгм():
    value = 328394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhbnbVwf8JIWKye7kHfEIH0Xw28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вНйэЦηΒθПΨ():
    value = 354128
    text = __import__('base64').b64decode('dDM0T3QwUkduaUc4emhFTEQzWlI=').decode('utf-8')
    total = value + len(text)
    return total

def _уМΣТΑιΒОБΓжМχνΝ():
    value = 472273
    text = __import__('base64').b64decode('VDNKakw3UFBiRktsZ2FpVDhrRWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _щΜЮκЙΤΓыκбЮαЛХΑ():
    value = 968337
    text = __import__('base64').b64decode('UDVGZnpCS3VkSTY3bzFzWDNaSEk=').decode('utf-8')
    total = value + len(text)
    if 90 * 91 < 0:
        _dead_2966 = 986
        pass
    return total

def _ВНяиεциΓμСΓ():
    value = 485359
    if 1 * 61 < 0:
        _dead_8183 = 589
    text = __import__('base64').b64decode('bFY1NGd6TmZFcjJsUWZEMG1FNG0=').decode('utf-8')
    if len('') > 0:
        pass
        722
    total = value + len(text)
    if 13 * 22 < 0:
        pass
        _dead_3415 = 637
    return total

def _ςКψΗВЧΑМЪλςδπУυЦ():
    value = 88408
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxDBWEsJ8/EkLAWt/VSYJ3wY/Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΞЪΣяЮЦρОЕοθ():
    value = 883285
    text = __import__('base64').b64decode('bEJQMkVHcU90aGdjUmI2SGYxOWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ТфΗщκЪХΤςΖпЭЪΝ():
    value = 91688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjjnZn1o2v8VFS2Oy3yiHjwd7jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гшЕκζфмеДμλхс():
    if len('') > 0:
        pass
        _dead_8310 = 246
    value = 735823
    if False and True:
        721
        pass
        761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQTdYng/8Y4tGFeI/1WEExUA/Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓФжΥрЪΥЧΡяиьЯΛТэ():
    value = 682448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR/PbVwJrKlbOw717VqyHSMa8kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜоθбйψЕАпδУкΕΕПΩ():
    if False and True:
        pass
    value = 934712
    text = __import__('base64').b64decode('WUVRUUtCdl9JUGJZQ1J5ckIwTmU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9175 = 77
        pass
        pass
    return total

def _ΠЭЩΤщчΤρΛЮτиΣ():
    if False and True:
        _dead_4127 = 432
        pass
    value = 543512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhzeUWY45r8rGyCtxXWDOSkgvWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 68 < 0:
        pass
    total = value + len(text)
    return total

def _УсΔΙАΟδЙΗоЭΠ():
    if False and True:
        661
    value = 414124
    text = __import__('base64').b64decode('bUtqU3dQTjllaEl0OW92TzRRZGE=').decode('utf-8')
    total = value + len(text)
    return total

def _βнηщшАхΘεзδο():
    value = 293733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBDwVF04z6MBNiWy0VS1ZRc4yjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ωΔаЩчΒαзрΞΕ():
    value = 862227
    text = __import__('base64').b64decode('U0dBQjdQTzk1aXFDQU9qZ0lTN2Q=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        _dead_7550 = 490
    total = value + len(text)
    if len('') > 0:
        _dead_4511 = 340
        _dead_9639 = 83
        _dead_2514 = 973
    return total

def _ГΚФαКЧуОВюΛ():
    value = 654351
    text = __import__('base64').b64decode('RXNIaXdPRnJnSlBMZ1EwZ0lkaUU=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΑΚчΚЕлцъρΓ():
    value = 554429
    if 34 * 71 < 0:
        pass
        _dead_9221 = 366
        417
    text = __import__('base64').b64decode('Ul9hTEJfeDE1Szdrc3hYN3NmQUo=').decode('utf-8')
    if 37 * 71 < 0:
        306
        76
        pass
    total = value + len(text)
    return total

def _φΩгУΑжξΩХЪζ():
    value = 312937
    text = __import__('base64').b64decode('R2U5UWpkMHhMMDRsZjJQX05qUnU=').decode('utf-8')
    total = value + len(text)
    return total

def _аПвШЮτσВΘТКсςκΩη():
    if 26 * 54 < 0:
        pass
        _dead_7810 = 631
        _dead_4498 = 607
    value = 967537
    text = __import__('base64').b64decode('Z0dNd2dLSm5VVlcxejRmbjlkd3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩфЮХУХχο():
    if False and True:
        _dead_5059 = 338
        _dead_5026 = 77
    value = 322183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARvGPFxq+KAXaFqS2lm2PXI49ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΨлцηΡστпΜеИьησ():
    if False and True:
        _dead_4147 = 573
    value = 761775
    text = __import__('base64').b64decode('cnJUNHo1NHgydnp2Z1BpTmZfYWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣоΧГΞнзЛЕθъ():
    if len('') > 0:
        _dead_3241 = 128
    value = 261916
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAzMYwdvyI0hLxu24HOYBw057Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БиγΣиλРеэ():
    value = 948440
    text = __import__('base64').b64decode('Zkk1NGdVZG9LQnBGNnhaM0psYXk=').decode('utf-8')
    if False and True:
        546
        pass
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()