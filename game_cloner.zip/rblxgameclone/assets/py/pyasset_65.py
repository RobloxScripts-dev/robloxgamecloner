#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _цχИΝЩУοΙХРм():
    value = 300185
    text = __import__('base64').b64decode('dFZFdHBYMkdYS1MyQ3RfVTJCajQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛйХЙОДЯзЖАл():
    value = 394068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DybRaHo75rgFMlyhyQG1DTQ73Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λюαмРΗвх():
    value = 11117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBvuagJoz/4ADA2ozw6+NQ0h03w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лρΑΙΞΠВΡЮ():
    value = 192718
    text = __import__('base64').b64decode('dnlmZWFKSThnbFV4OU9tWWdPTDg=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ρадШкΞнЛгΣ():
    value = 271231
    text = __import__('base64').b64decode('aEl4SEpxSTNEZDh2NmxRWTRGYU0=').decode('utf-8')
    total = value + len(text)
    return total

def _НРвηΞгΓФΘτЛΛ():
    if False and True:
        _dead_7906 = 702
    value = 992441
    if False and True:
        610
        551
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB2xPmBg65FVEC2U+2+RAA4b3HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ρРюуμδСчпаνр():
    value = 621925
    text = __import__('base64').b64decode('dVlXZWZHZDI3bEwzZ092dEFxMzk=').decode('utf-8')
    total = value + len(text)
    if 43 * 38 < 0:
        pass
        pass
    return total

def _ΡшъτйаΕьннΛй():
    if False and True:
        976
    value = 790670
    if 28 * 59 < 0:
        _dead_4399 = 113
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyqwVm4Dpow6PwSB536BOwB9zUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        931
    return total

def _яЮзγΞЙΥвιΤТ():
    value = 900319
    if False and True:
        _dead_3783 = 325
        848
        _dead_2326 = 228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT/ASVQQ3LkkCgOrym6xEBo963k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 17 * 41 < 0:
        429
        351
        pass
    return total

def _οжщΛΩΩΔσ():
    if 40 * 51 < 0:
        708
        pass
        566
    value = 707117
    if 25 * 45 < 0:
        259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxXJfXQLzK8ZbQG74Ve0FSgu0EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΤчгНΙЗΞγНеЗΨιЫ():
    value = 924685
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhqwWgUV7fAtGyaGkEO+Y3IZwUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΘψπψхсхцЗгЛз():
    value = 927537
    if 31 * 19 < 0:
        342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQjJfnQPzJgCFwKo2HedDiF87UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 32 < 0:
        210
        _dead_9447 = 214
    total = value + len(text)
    return total

def _ωЯкωΠξσЗηЧ():
    if 38 * 85 < 0:
        _dead_4065 = 366
    value = 384544
    text = __import__('base64').b64decode('ZE9GS3NvVVBPSkU4OEt3Q0lYMFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ФтρБТξφωσΧκΖШυ():
    value = 206154
    text = __import__('base64').b64decode('ZklpSnR0ZDU5b3NaUWpUUTgyMF8=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _λΠΧφΒκΥРХЕΧΣλοэ():
    value = 853644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHvWSFIv5I88AyKA73ecJx8f6Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЧαгΚАКеξьгВ():
    value = 562257
    text = __import__('base64').b64decode('TzA2eG93Y05XbUNNQmNmSjNyR0w=').decode('utf-8')
    if 26 * 3 < 0:
        835
        119
        _dead_3472 = 169
    total = value + len(text)
    return total

def _βΡУΚяξθφ():
    value = 593773
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3vnSGER1aEpD1qv+GC9Y3IH9mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΘΝобуδАЪэκ():
    value = 190357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICzQQAMd75klb1/zmWCqPTJ97V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΟВΡζдСηζΜΙν():
    value = 617721
    text = __import__('base64').b64decode('eUNVM01DelRpbk8ySlQ2RWdFMEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ИηПΠψшχчГдλιΝдОκ():
    value = 890966
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MizOZ0Ih3b0HaBaunESRHAcu12w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡξтГМЛсαкКАВВнЪ():
    value = 353709
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiLhYWExqP0JPySRwGObYjA65zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠИαдικεЧΕЭΠδΠπК():
    value = 115506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhuxVH8h7v0mCQX2zkK1BgIW0Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠКъХрβδΗΝХЛюοΩ():
    if False and True:
        _dead_2560 = 484
    value = 375302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz/Sf1lt0/oZLwKx8lu0MA0Hy2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 22 < 0:
        _dead_8404 = 943
    total = value + len(text)
    return total

def _χЦΨъΡфФНб():
    value = 187647
    if 55 * 44 < 0:
        pass
        _dead_3127 = 815
        pass
    text = __import__('base64').b64decode('bm9JazRVS3FEakNyczV6YmJ1aXU=').decode('utf-8')
    if 90 * 88 < 0:
        303
        _dead_7718 = 482
    total = value + len(text)
    if 22 * 96 < 0:
        pass
        176
    return total

def _хбςщΦТРхйыуζςЯ():
    value = 286086
    text = __import__('base64').b64decode('cDFjN3FFbjZrVU9BckhqdVNLSkg=').decode('utf-8')
    total = value + len(text)
    return total

def _СπΠЭьуΡΘ():
    value = 542384
    text = __import__('base64').b64decode('WFdyZWZxZ3VQU09UT3J1Nko5b1o=').decode('utf-8')
    total = value + len(text)
    return total

def _хьрЖμгτΦкГэΨжτбθ():
    value = 893596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDXpOGE33aoMPSic5ke1HigbvFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чэθЫБхъяΛΒ():
    value = 190978
    if 6 * 5 < 0:
        pass
    text = __import__('base64').b64decode('dVF3cnl4VlF0dDNsMDUzOGtvamk=').decode('utf-8')
    total = value + len(text)
    return total

def _ИиЪλШДЩχκеΞι():
    value = 458335
    text = __import__('base64').b64decode('aUJTajdqR0VRTzNjbHJWX2h0YzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖξЪиЛφьΒлЫкрСΠп():
    if False and True:
        pass
        _dead_6743 = 265
        _dead_7067 = 599
    value = 544301
    text = __import__('base64').b64decode('bnBkel9VaTNVNEtFSGlSSGY2SnY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        198
        pass
    return total

def _ЕλжлоПфпοΑБ():
    value = 651604
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQbzXllg1Pw1Myi67F29PyIfwls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΜЭэдφДЗΠΡ():
    if False and True:
        919
    value = 687775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgjHWWlv+LsmH1ay50SdHih9/W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9228 = 37
    total = value + len(text)
    return total

def _ЗсЫχωДωΟεАуХμКΦн():
    value = 711035
    text = __import__('base64').b64decode('VGhCcGtfcWhxYkViQ3RyNUIyYUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΣλЖгХТρλВλЙΟ():
    value = 862187
    if len('') > 0:
        _dead_5937 = 803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBr0RVMA6pxSEyqtzVGkbH0CwU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЩκΔтСсШρχΓνб():
    if False and True:
        749
        pass
        pass
    value = 290995
    text = __import__('base64').b64decode('RlFpZkNab3V6bjZMcWRSNmtGUDI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6322 = 459
    return total

def _сИЬЗпНГоМУРπ():
    value = 926097
    text = __import__('base64').b64decode('c1ZoMnZ1NXJsWHBBOHh4NEI2ZXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖЫБΡΙςчρЦ():
    value = 223616
    if 16 * 56 < 0:
        _dead_2338 = 789
        298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwvwOHUp67g0ACyK5nCkPhc5tGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 85 < 0:
        _dead_2299 = 783
        _dead_2384 = 694
        680
    total = value + len(text)
    if 21 * 79 < 0:
        154
        pass
        pass
    return total

def _гΞЬГГЛтΑςΥеωζψъ():
    value = 959075
    if False and True:
        pass
        161
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex7TSVdvq4dTG1qT0lOXbRUn9HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 78 < 0:
        189
        800
        _dead_8407 = 887
    total = value + len(text)
    return total

def _ΩΥйаГφοж():
    value = 528008
    if 57 * 100 < 0:
        pass
        _dead_1661 = 35
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHvTfn4J1L5XF1a62nK+E3YbvTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 100 < 0:
        666
    total = value + len(text)
    if 71 * 14 < 0:
        _dead_3218 = 495
        970
        _dead_3911 = 15
    return total

def _уоъЕюΖГψгжπθΠшЬб():
    value = 79046
    text = __import__('base64').b64decode('UE5RWXh4Ml9ESU94aWNmZ1BZREY=').decode('utf-8')
    total = value + len(text)
    return total

def _σφиτρной():
    value = 28604
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBDHXnRt7JJaG1667XvFA3wZslQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1441 = 945
    return total

def _ωЮьφуβΨиΒρΟΣм():
    value = 818501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3jtTHMoyIsJDQq20EGEIHN29FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 73 < 0:
        pass
        300
        pass
    total = value + len(text)
    return total

def _ΕζцηцкχрΥΞ():
    value = 322695
    if False and True:
        pass
        _dead_1144 = 408
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3awR0kz04knNyiBy2OZGXQ122c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if 24 * 51 < 0:
        877
    return total

def _ИвξΞΕΘΓИФИσЗιη():
    value = 4622
    text = __import__('base64').b64decode('YXBfQ09xN1VkM1ZkNU9wbmJ6ZUc=').decode('utf-8')
    if 28 * 34 < 0:
        _dead_6504 = 951
        144
    total = value + len(text)
    return total

def _ΠазβμъоΠ():
    if len('') > 0:
        _dead_6060 = 711
        _dead_7069 = 575
    value = 895387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cnm8VwAh6b5UYwCC7HWCJSMKwGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7411 = 392
        _dead_9826 = 949
    total = value + len(text)
    return total

def _ωРДюйΝЫсΡΖ():
    value = 139965
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCuzbFlo55o8EDDy4UKhJS089kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЕЛФΕιЯζωΝΞЩΝσю():
    if 100 * 25 < 0:
        297
        _dead_5777 = 340
        197
    value = 54492
    text = __import__('base64').b64decode('Sm53M0FpVzlvOWE1SHBzWnVtemw=').decode('utf-8')
    total = value + len(text)
    return total

def _УфйσэΑΧАъЖ():
    value = 515769
    text = __import__('base64').b64decode('VFBPRENSOTZNS0R0WDMzMkJ4X04=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8919 = 594
        204
    return total

def _ωСΤМκςАΒ():
    value = 933329
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnjsQAQb75w7MxuS7WGyCyco8z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΑБοΖΦθΟбСКуχОЭи():
    value = 614042
    if len('') > 0:
        561
    text = __import__('base64').b64decode('S3lxc3gzWkhVWHlVcnhzSFlqTnM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1162 = 49
    return total

def _ШгбРЪЯюСаЫ():
    value = 910377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwjrTQgg/J0WCieywVyaIx995V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хРςтρхнЛйυκΨγЕ():
    value = 927620
    text = __import__('base64').b64decode('S2kxdjcwOUZsYjc1NlN2WTd5MTY=').decode('utf-8')
    if False and True:
        _dead_2071 = 903
    total = value + len(text)
    if 65 * 8 < 0:
        _dead_9882 = 579
    return total

def _иΥΘξаΨσλΧкЦΑδδσ():
    value = 441310
    text = __import__('base64').b64decode('R1E0ZWtSdVdka2dSc0xyX2k5a3M=').decode('utf-8')
    if False and True:
        _dead_2347 = 987
        _dead_7508 = 706
        857
    total = value + len(text)
    return total

def _БφπΩшΩШеп():
    value = 149659
    text = __import__('base64').b64decode('aUM5cXc3aE9aUVZtekEySEszd0Q=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΜσЦνΛыΝνУрх():
    value = 634583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cxq8UQkPr/sZNi2A2Ge3LgN35UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭρУеОеьНчЬ():
    value = 969676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDzBS3tp7rkzaSiV7mW3LjUW73g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖпйыΠΚοьΦЪΘςер():
    value = 880973
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgS3Xkgvr4Muah+0zWDJEXcjyUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒХαХРьηКΜбλΝОς():
    value = 773445
    text = __import__('base64').b64decode('RThXUzhEdVd2aGFYYjlJMmwyaEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΜяτΩэГЪρнς():
    value = 186201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiH2eUA385gQGzbxzGPEMgku220='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒοИΥщΗвЕВеШ():
    value = 101521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBnIdmJpxPlbAl2G8n3HABM8s2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩχΓΜЩЮЖЦΧΒхс():
    value = 151308
    if False and True:
        785
        _dead_4288 = 723
        152
    text = __import__('base64').b64decode('a2RFTDdGaUM2ZmFiV0JkRHh1TFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭнΚЩНβйНт():
    value = 829513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KATIQFJu/IUVLlegxUe1DAp61F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΦщΜЬτгΥπΣнМФрΩН():
    value = 305280
    text = __import__('base64').b64decode('UUhxbUx4Yjl1RFVQSUlvU29DaVI=').decode('utf-8')
    if len('') > 0:
        _dead_9943 = 174
        123
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _εючθψιСчτθμ():
    value = 215637
    text = __import__('base64').b64decode('YXJ4THVPSUJoalN6M1JhUnF2T0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ВвΣвτщъЭΑ():
    value = 597725
    if False and True:
        311
        442
        _dead_5913 = 796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn3xR1QY5KUxHTmS92LAYwkQ5n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 84 < 0:
        319
        _dead_7693 = 401
        pass
    total = value + len(text)
    return total

def _ЩξйГρβДΥЦтКЯδΣДμ():
    value = 155497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzjGN3Iqx74tNzXxmXiyMjV2/T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        279
        pass
    total = value + len(text)
    return total

def _ψΑсΨаλЗφеγИдκ():
    value = 347367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwbdXFkczq0EGByC8APDED0BtGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μοжЮΦАДяДΝΠΛ():
    value = 698284
    if 7 * 16 < 0:
        470
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCezeF8Q3LBUFhei/WWAYD0ewT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮвМΞгОвγЩσμЕχ():
    value = 493512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dyv2PAEwy68aAy6hxGK4AgkH4Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лСЯχωтιΠЛτκо():
    value = 937900
    text = __import__('base64').b64decode('ZUdPMVQ0SldkdzBoVlFkNGYwUjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦьΜΡΖГζοщδяч():
    value = 700720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA72Qkdt5pgMDSuWwne2Ai8r9kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 84 * 99 < 0:
        614
    return total

def _υГΠΓιбякΙωСуДΛθ():
    value = 777191
    text = __import__('base64').b64decode('ZXB0ak5GRmZBdGRzaE5mQ3JseWE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8266 = 148
        923
    return total

def _ΥςРФΡАδθГυДσ():
    value = 564020
    if False and True:
        638
        67
        586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzbWSmA/3f82Ezfz72OUE3wt3V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘπμЖНжЧбяΜХУтπ():
    value = 969145
    text = __import__('base64').b64decode('Znp1NjdubDU3RERQR05CYzd3Tjc=').decode('utf-8')
    if 10 * 50 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΟСЧΡΘдкЬрτζЭйл():
    value = 9316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCjuSQQ83KElKQOc/U6cMRwZwFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7112 = 177
    total = value + len(text)
    return total

def _пУлνуаецяοτП():
    value = 169046
    text = __import__('base64').b64decode('VVdVVTZKM1RaTzBobk10RHZIRFI=').decode('utf-8')
    if 28 * 69 < 0:
        _dead_1339 = 960
        216
    total = value + len(text)
    return total

def _гζΧΖβςнпφУМεю():
    value = 122578
    text = __import__('base64').b64decode('c2pqQnNyZkhTZURRZXVlU1pvWVE=').decode('utf-8')
    total = value + len(text)
    if 25 * 81 < 0:
        646
        _dead_9578 = 275
        pass
    return total

def _ЮαοфДφяоПшьсЕ():
    value = 306792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IT6yZ25v0pwHbA22+WexbC8d6WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        574
        pass
    return total

def _δΥТЧОЫТЮЮ():
    if len('') > 0:
        597
    value = 788145
    text = __import__('base64').b64decode('T1hUSHhmN2lacHZScVlqQ3F5RFg=').decode('utf-8')
    total = value + len(text)
    return total

def _σΝЪδΤχСКΡКμ():
    if False and True:
        pass
    value = 810107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAP+f3co/PwBGwGs4XSkEXEu/W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        87
        pass
    total = value + len(text)
    return total

def _ωθπΜЫШуЬχζυГД():
    if False and True:
        0
        _dead_3680 = 813
    value = 18973
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgvGS3gs3b5SGV6g4Vq+MSkp80M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΞГлΠΞИγрηΡОψПшк():
    if len('') > 0:
        974
        80
        636
    value = 405952
    text = __import__('base64').b64decode('aDVqdE1JekhfUm8xTVlNOEcwVEk=').decode('utf-8')
    total = value + len(text)
    return total

def _РВвоΝнΤνлΞ():
    value = 584728
    text = __import__('base64').b64decode('dndDbl91clFGa3hzbDRxOVZuVkU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7482 = 334
        654
        pass
    return total

def _κМΘΛяаГщαлΟυΛкк():
    value = 880332
    text = __import__('base64').b64decode('eV8ySllFdHBGRDh1QXZLbkFhdTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _поΣδεэΚЩЖ():
    value = 998686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj/Uem4L+59RFDmF2VSgNSYm9m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓйпаРοтθΩ():
    if False and True:
        339
        808
        _dead_8878 = 42
    value = 197610
    if 28 * 17 < 0:
        _dead_5199 = 505
        684
        pass
    text = __import__('base64').b64decode('SnVRQ1JZZ0dBYTIxOVBQWV9uaFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚРςЭЗΕχΦНЦьιйК():
    value = 268535
    text = __import__('base64').b64decode('TFBKNU5lcFhYblJIdTRJVXZQbk4=').decode('utf-8')
    if len('') > 0:
        753
    total = value + len(text)
    return total

def _йКоδκζШΧТ():
    value = 342686
    if False and True:
        _dead_8866 = 223
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT32Z0Er0JonDgO7wVKkDhYbwmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4158 = 206
        379
    total = value + len(text)
    return total

def _айчХбЧфυΖеααηΨГ():
    value = 668630
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz7SWGcx/ZIUNB2cy26kDTECxng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЮΦМГЗκекЧζееν():
    value = 54655
    if len('') > 0:
        pass
        _dead_6926 = 487
    text = __import__('base64').b64decode('VjcyVTRDOV9CZURxaGljZm0yS0U=').decode('utf-8')
    total = value + len(text)
    return total

def _λПЗΑШΛγЯψΗиЗσЕьλ():
    value = 128814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT3ebwIM2LFTLF2sylCpHyMf8EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эйвлОбКьρАя():
    value = 917564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fy3TNm4Aq40iFRmhm2SgMj0GyUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υαТсуНхξθξЪ():
    value = 154130
    text = __import__('base64').b64decode('c0V6QXdCZDNRY2pDRkJ6Q2VzMjU=').decode('utf-8')
    total = value + len(text)
    return total

def _γΠЫδыЛяшШΣьця():
    value = 796523
    text = __import__('base64').b64decode('dUVadUhaWUpNU0lZbFU3a3ZMdnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЛγδΜΑжιъεпынΥо():
    value = 671513
    text = __import__('base64').b64decode('b3VZMUdpaThFbUVJdTZOOHVPS0c=').decode('utf-8')
    if 89 * 85 < 0:
        _dead_3302 = 175
    total = value + len(text)
    return total

def _юСдБйωΗьИΧ():
    value = 540467
    text = __import__('base64').b64decode('Vl9nenRqTVgySUZIVG1mOHpZb3I=').decode('utf-8')
    total = value + len(text)
    return total

def _гθωЪΞМбΣηшΔ():
    if 58 * 82 < 0:
        _dead_8710 = 595
    value = 775959
    text = __import__('base64').b64decode('b0J4VDFBb25SakpFcmdzV09fdWM=').decode('utf-8')
    if len('') > 0:
        _dead_4599 = 831
        303
        pass
    total = value + len(text)
    return total

def _ЖиιцαлЪвλЧηмωшΨК():
    value = 786071
    if 97 * 91 < 0:
        _dead_6242 = 351
        12
        _dead_3994 = 342
    text = __import__('base64').b64decode('UzlVQ0RLUWZ3N2hBWE01UGxvT1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛьРЯзйлφшЦху():
    value = 392798
    if 35 * 14 < 0:
        pass
        _dead_4776 = 68
    text = __import__('base64').b64decode('ZFVScDN5aXZubFhhREQ5ZXFZTXo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2563 = 266
    return total

def _ωЦЙЪΑσьрШοПЫδКυ():
    value = 29100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DALROwAg3YtREQuq2AGnZy0K83o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩЫЫΞЮКρФо():
    if len('') > 0:
        pass
        125
    value = 349040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBmxS11t7L8hICKC4VqiFi0Y22E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        41
        51
        pass
    return total

def _ΤБФаωЙРЧИ():
    value = 14945
    text = __import__('base64').b64decode('V0FXZzN1VHBvOVF2a2U3MTR6R3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΛФΝлΥΘδτΑП():
    value = 450661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHjhVmMtwZwzH1izyXSvYwcl4n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 65 * 91 < 0:
        _dead_3556 = 827
        pass
        pass
    return total

def _ΥΚλΛКЖΥПΚкΟщФрιω():
    value = 238213
    text = __import__('base64').b64decode('VDkzN3pPMnlrQTZWNVFWdnZHWGo=').decode('utf-8')
    if False and True:
        _dead_6922 = 1000
    total = value + len(text)
    if len('') > 0:
        _dead_5018 = 318
    return total

def _ТФΗДσбяοъсЙнΗР():
    value = 972294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQzsXmAh35pRHg2Bn3GxOnEQ9FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХЫσΛξтъыΜ():
    value = 292721
    if len('') > 0:
        _dead_8835 = 743
    text = __import__('base64').b64decode('WVlHMmNndmc2cFpSMlNNRDFfTjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧкΥζεΒΗОεЙμ():
    value = 130363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fi2xWHAY15klPSz7+VS6LXd+zFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_7050 = 295
    return total

def _ΕΩСΣТНмГ():
    value = 628919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgHAfgcq7oVQFg3y2XC9F3YLx0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥшοΞςЦΨΠю():
    value = 80703
    text = __import__('base64').b64decode('UDNJRXYyMDlfZTI4TElrSTZZY00=').decode('utf-8')
    total = value + len(text)
    return total

def _μЮФμθΑрЪЬбηГЙя():
    value = 859661
    text = __import__('base64').b64decode('Y3FrbjlLc0tJcW82VUJXUW1VNDM=').decode('utf-8')
    if len('') > 0:
        _dead_7723 = 561
    total = value + len(text)
    if False and True:
        pass
        738
        _dead_4644 = 529
    return total

def _ΘШΑДΜνΛηэЖк():
    value = 219763
    text = __import__('base64').b64decode('VktwRGF2UWNvSV9TblJHbGJvV2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ъхδΞεΚКΜЕμΞий():
    if 57 * 1 < 0:
        pass
        pass
        pass
    value = 535725
    if 4 * 89 < 0:
        _dead_2648 = 226
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Awy1XXcj0pshbyeK0HTBJhV77Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _шэБΣΤЖμиθΣΗЖнК():
    value = 329498
    if 78 * 93 < 0:
        404
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH/tNmI97fsQHS3x4UbBGSN27j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΑШшχяηΟЪλΦ():
    value = 241529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx23RUhv1oAROBz6mnSgAjY91WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        89
        _dead_6778 = 771
        781
    total = value + len(text)
    return total

def _ОеωмЬΠяЛξχΞвδ():
    if False and True:
        764
        pass
        84
    value = 996956
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn73bGkf05s1MiaCz1u/ZAsrtFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΓσОЛΧхеΗλυПвЛш():
    value = 770468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBrpYEMs9rgPGV2S3X29ASMXtlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьυΑзσзтДΟбΜчυР():
    value = 97690
    if len('') > 0:
        _dead_3481 = 498
        231
        _dead_2216 = 653
    text = __import__('base64').b64decode('TkZ0SXQ4VTJLZVpPUU9XWEVUS2g=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        939
        pass
        35
    return total

def _хУсΜовЯктСμьЫιр():
    value = 127642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCLXO1U3+acQIB+qywKkZCkNxzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭςГфОЕΙκγπаυЫΥ():
    value = 574046
    text = __import__('base64').b64decode('aFkzaGlUc1ZubWRlTXBGRVdXdEM=').decode('utf-8')
    total = value + len(text)
    if 73 * 70 < 0:
        pass
        _dead_3637 = 116
    return total

def _АЪωιΚαГЛМ():
    value = 164817
    text = __import__('base64').b64decode('cDBPQUMzZXhmNFVkQ21JMUltVnM=').decode('utf-8')
    total = value + len(text)
    if 69 * 96 < 0:
        _dead_7268 = 750
    return total

def _ШжЦιаαЭПоСьΧц():
    value = 611553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BinuX10714sqLFmqnQC+Exwu1ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υнкΟςΙкξбЫЩхГ():
    value = 949343
    text = __import__('base64').b64decode('cjV3ZXhUQk5zdWtmV0c3QzRFR00=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЪНШЙпюУЖ():
    if 8 * 76 < 0:
        pass
        pass
        _dead_5225 = 509
    value = 763779
    text = __import__('base64').b64decode('QW5VMzVtakVqX0dLZ2pRUnc0UUQ=').decode('utf-8')
    if len('') > 0:
        86
        _dead_6443 = 312
        437
    total = value + len(text)
    return total

def _МσХФЛЧΗюх():
    value = 959198
    if len('') > 0:
        780
        _dead_6167 = 551
    text = __import__('base64').b64decode('c1RwTEx6MHJvdTIxdjVncnNwcTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯεФПЙΡΚф():
    value = 724979
    text = __import__('base64').b64decode('ZkxOTG9ldmZodUhuX0FNazdHSEE=').decode('utf-8')
    total = value + len(text)
    if 28 * 72 < 0:
        _dead_4135 = 736
        _dead_6612 = 10
        781
    return total

def _гοψΖЖиΙвЕΣχ():
    value = 307306
    if len('') > 0:
        688
        pass
        _dead_1997 = 162
    text = __import__('base64').b64decode('T0poS2lnN3BlUm1CQXBjeUVZQ3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΗжЪδΟηвЩ():
    value = 220050
    text = __import__('base64').b64decode('ZlRJYWtvMWtMTFJPVHltRTJlNkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯφоЬЗιлм():
    value = 711628
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('VlloSlZ1M3VZUEt4NndPcldmUnQ=').decode('utf-8')
    total = value + len(text)
    if 83 * 27 < 0:
        882
    return total

def _ЖБбЖйΘλΤ():
    if 54 * 29 < 0:
        pass
        _dead_2564 = 461
    value = 721727
    text = __import__('base64').b64decode('SEI1WTl2RFN3aFFtc056NWw2Y0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥбΟΕαяζЬψθΛ():
    value = 648150
    text = __import__('base64').b64decode('WXl5azRZSXBpSl82N1lrUmo0TGo=').decode('utf-8')
    total = value + len(text)
    return total

def _эΓпΕБоολЧАν():
    value = 214795
    if len('') > 0:
        pass
        998
    text = __import__('base64').b64decode('d0xCbFE2ZjU1V1kyVjVNZjdLdXk=').decode('utf-8')
    total = value + len(text)
    return total

def _гЕЮκЬΑΦΡЭβ():
    if len('') > 0:
        pass
        _dead_9071 = 395
        592
    value = 362401
    if 62 * 61 < 0:
        _dead_1350 = 53
        _dead_2899 = 94
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AALOawM17YMIMAC0mwOTHg07vFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        741
    total = value + len(text)
    return total

def _ΦωЪυвВХΡΡМθ():
    value = 345451
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgLVWnQO65A8EgD23XmoNzYgwDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥρФΥьтдΨсЭ():
    value = 461828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCbJZGIw/Lg7NweU3F3AJC8VxT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3944 = 844
    return total

def _ΜτυГΕΝьΔУдξΥтΤ():
    value = 325914
    text = __import__('base64').b64decode('RFZYN3FVUDFuVU56S3dySWlqZjM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ВκφБЯекΑιρЦФЙП():
    value = 712854
    text = __import__('base64').b64decode('bW5EUVRGZ21KZGdtVVpoQVRwYmo=').decode('utf-8')
    total = value + len(text)
    return total

def _γсπтХфκщКΥγσ():
    value = 484410
    text = __import__('base64').b64decode('ajFJY0FXTkluT0I5MUNIRVJ1NU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΛФκΑΩΜωЭБ():
    value = 707150
    text = __import__('base64').b64decode('cjBUS05vTDZfV1E4Z0hxQ2ZJNEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _απойυΛоБΚσΚΓщ():
    value = 508976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH7OZEAp6YEUYz61/2WcHA0J6Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        421
    total = value + len(text)
    return total

def _ПγφπчΠъШмΔ():
    value = 811207
    text = __import__('base64').b64decode('cmJMeF9Xc0gzR0RhWmhRWVg0Sk4=').decode('utf-8')
    total = value + len(text)
    return total

def _виЩΕщωЪΣЛβыι():
    value = 643802
    if len('') > 0:
        10
        pass
        757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lzb1T3NtzP0EAzuynHG7EyM9sVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 17 * 91 < 0:
        pass
        154
    return total

def _ΑвΦЯЮьΧςфΑШΑяфй():
    value = 728081
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH3nSglupr8bMVa3z0KYOjwk82w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7136 = 155
        pass
        _dead_6980 = 927
    return total

def _хнΞЦΓЧφЪй():
    if len('') > 0:
        _dead_9374 = 43
    value = 67147
    text = __import__('base64').b64decode('YTRtdEFHTkE0aHI1MUFlRlpKdHc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        708
        pass
        640
    return total

def _ΒЮΑΗΘлюЖψ():
    value = 238427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzjvOQRh9JwbBR66mnyoZQItyFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σщιМΝШНъζЕСрα():
    value = 357524
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASaxa3lu3/88GCyx/1fBBj974TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бтΝδδΘιφΖЙФЗ():
    value = 319751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjjeaGA73YMkOwGk+3KjLQAVzj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧοσγпВЫγκΣ():
    value = 564949
    text = __import__('base64').b64decode('dTRNR1JmUUpJRGplbzV3cVg4MEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕτЮЛХКУΜ():
    value = 899547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSn8R2cwqI4vGF6s5Xi8LDQayHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΜВσаνβψцΑΖΥΕυα():
    value = 478137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQzLd3gez78WDwqV31jCbSctyU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гσьАΞЬЦгΨΥгβъфςя():
    value = 998736
    text = __import__('base64').b64decode('cFZaandEbUlfaE9NV0E3blp2Zlo=').decode('utf-8')
    if False and True:
        748
    total = value + len(text)
    if 25 * 95 < 0:
        _dead_3735 = 992
        309
    return total

def _еΞГΖκФИθαкып():
    if len('') > 0:
        pass
        _dead_7852 = 420
        451
    value = 985781
    if False and True:
        _dead_9399 = 540
    text = __import__('base64').b64decode('cjlNcU5qU1B0Q0RxSmNpNFhIWVQ=').decode('utf-8')
    if 14 * 9 < 0:
        503
        _dead_5963 = 575
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9853 = 15
    return total

def _РκтНвЪэСΨЯыλЛΡχ():
    value = 780849
    if False and True:
        _dead_7724 = 515
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hwm0ZHYoqJs2MSixy1eqO30EvF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖτεΠωΟΒρБА():
    value = 543719
    text = __import__('base64').b64decode('ZnU0WkpUY0NSTHU4QWtEc2xOQzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠаβΜХфνГс():
    value = 229088
    text = __import__('base64').b64decode('QmRCU2FGM2FrUnhEYWRudWNpMjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ζПГжЖСБΨ():
    value = 53154
    text = __import__('base64').b64decode('anlralFMTVhBOEVWWGx3bFdOQV8=').decode('utf-8')
    if False and True:
        693
        pass
    total = value + len(text)
    return total

def _ΖювβΣМВΕсЦВзΓГоэ():
    if 49 * 12 < 0:
        _dead_1490 = 948
        _dead_9016 = 541
    value = 579171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzXiRUcw7YIIERu7mFjAYiAf1kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9073 = 83
        _dead_8969 = 429
    total = value + len(text)
    return total

def _ПТИσΧыУЕОχΕШ():
    if len('') > 0:
        pass
    value = 395731
    if len('') > 0:
        _dead_3849 = 776
    text = __import__('base64').b64decode('YTFFZF9SV2g1VlRjUWdRRmUzX1M=').decode('utf-8')
    total = value + len(text)
    return total

def _уыИΣЫДκλωрβα():
    value = 303053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETXNTHQM7pcnPjWsxkGUYSAly1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4890 = 69
    return total

def _ЕΔγФνьЦя():
    value = 983861
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAaxfANs6JswER2zkWnJYTMpzXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9908 = 992
        _dead_4948 = 561
        881
    return total

def _ηБЬяπΠπЫΗΒИЫЭж():
    value = 993198
    text = __import__('base64').b64decode('ZXpjVUlLa0ZsdFNPc0t3cUJ6eDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΕαЗΟοщρеΨζΙиΧ():
    if False and True:
        pass
        _dead_3449 = 861
    value = 703054
    if False and True:
        886
    text = __import__('base64').b64decode('bnkwNk5kRThXN2FlR1RwcHBXbTc=').decode('utf-8')
    total = value + len(text)
    return total

def _кεΛξвфεΤфяч():
    if 45 * 39 < 0:
        _dead_9006 = 146
        _dead_2306 = 911
    value = 109236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PATTS1I9rKovNTas/HGfB3Ua63g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιСЖΕπναΕ():
    value = 971563
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KynrUWQJ+KAgYy2J3Fi8DRod/Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7177 = 970
        _dead_6342 = 984
    total = value + len(text)
    return total

def _ццΔМΤАлБ():
    value = 262755
    if 44 * 80 < 0:
        pass
        _dead_3048 = 224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxjNa3wOzqwnER+hyWzDJTN4s1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БкηΣнΧДαΡяжУΦη():
    value = 80867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHz+TGET36wNGAWn0UGDIwp93k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΤЛэПΥМюд():
    value = 615210
    if len('') > 0:
        841
        _dead_8884 = 822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTnKVnAP3/lVLR6G41G6YQg11nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эаВΒУшеТнэ():
    value = 448674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FibUd3wq2rgWBVqZ0WeoDAp6wmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨЛШойδΘεьДлюγцЕ():
    value = 293062
    if 79 * 42 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnaxSFlt94kANT+n62OHOnQh/nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_3765 = 389
    return total

def _ВЙЕзληΤη():
    value = 302297
    text = __import__('base64').b64decode('dGtqM0VHX2U4cDMzS3NTWGxPTXI=').decode('utf-8')
    if 3 * 74 < 0:
        _dead_1059 = 663
        432
        pass
    total = value + len(text)
    if len('') > 0:
        955
        864
    return total

def _ΤцЫУΦΨшкПλщΨЦξ():
    value = 536710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NA3jfgMs8rstaj6A0l+fYRoXwDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фвΓοюГУбаЛπψсχп():
    value = 716504
    text = __import__('base64').b64decode('SVZrMUExMmhpZ0NsV0tBQXF0UzU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        155
    return total

def _ТьВЙжЪΘΖ():
    if len('') > 0:
        _dead_1813 = 803
    value = 805885
    text = __import__('base64').b64decode('ZzNqYkQ4dnI5YTRacVFWSkVNOVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ιуЗхнатЩаЩаФφ():
    value = 917385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CifVWwUt3aEUNTuP2HOyPjMl8zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юγтςЬΜвЛ():
    value = 348224
    text = __import__('base64').b64decode('QlNRc0xmZ0NEVHZYbXo4M0NpMHc=').decode('utf-8')
    if len('') > 0:
        704
        pass
    total = value + len(text)
    if 18 * 87 < 0:
        _dead_2495 = 7
        pass
        110
    return total

def _ябπДКгъВЖζЩ():
    value = 951708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB/INm4y2p0rMgqg2HCkEicE3n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УамйχεхΧзπщ():
    value = 632796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh/tYQQz3IRTajvyzmHAHyQBsD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7801 = 819
    total = value + len(text)
    return total

def _еСνσшоуΑьη():
    value = 72790
    text = __import__('base64').b64decode('WDJCbGRNdHpubGJyakdyNk5GcmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 65 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    _dead_4505 = 486
    444
    pass