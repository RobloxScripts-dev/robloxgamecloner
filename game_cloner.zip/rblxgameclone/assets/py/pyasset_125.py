#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΠнцкχλΥжх():
    if False and True:
        769
    value = 287255
    text = __import__('base64').b64decode('UE1VbzNnMUpSWFMyWjZUaUpQdFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ψцΗАρВΓцВ():
    value = 858042
    text = __import__('base64').b64decode('ZzJMZVFOSUdFV2h6cktkWmFlaGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΖΡΘΞδУщΛСωΜПюф():
    value = 412615
    text = __import__('base64').b64decode('bmdxQk00anJKWXlFZ1kxMzlPS3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑφΧЙΝδйвεЦθΟь():
    if False and True:
        797
        769
    value = 49231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwLsPmEd7oovHTmH20LCZgx76EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9247 = 166
        129
        _dead_1908 = 351
    return total

def _ψπпβςжВιКДЮλ():
    value = 620738
    if 46 * 29 < 0:
        _dead_5737 = 429
        pass
        pass
    text = __import__('base64').b64decode('Y1E1SmVDNWZDTUx0Mzc4V1lhU24=').decode('utf-8')
    if 87 * 34 < 0:
        44
    total = value + len(text)
    return total

def _δΡυκΜаβτЙФκμΖ():
    value = 488978
    text = __import__('base64').b64decode('Slk4V3hSbDY0OEFSTHZJMWpSWnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ДСаΞзюВοКΕЮθΓδΑ():
    value = 988227
    text = __import__('base64').b64decode('QWdLODFxTElSRm1VelJiYXNSMWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΕμδЗИΩγТКΖΖЖЖШб():
    value = 7968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzvrOAUjz6UlbhWP7w+oBn0csTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _оΠηγмψРфСзй():
    value = 985014
    if len('') > 0:
        _dead_8596 = 854
        _dead_6069 = 607
        _dead_3109 = 146
    text = __import__('base64').b64decode('cVhDYVNvQUwxbFNDMjR1cjZiUUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧζЖКФцΟθФ():
    value = 996172
    text = __import__('base64').b64decode('TURfbUwwQW5uQ1lGR3I1UHk1S0k=').decode('utf-8')
    if 25 * 85 < 0:
        _dead_8032 = 389
    total = value + len(text)
    if 33 * 59 < 0:
        324
        pass
    return total

def _ηΟУΣμτоΒПЫΘ():
    if False and True:
        194
    value = 385622
    if 45 * 3 < 0:
        849
    text = __import__('base64').b64decode('aWN0R0o3Y3JvTW5GRXJvd18xU0M=').decode('utf-8')
    total = value + len(text)
    return total

def _хλэΔжэΧчхΝОΣаΜМ():
    value = 838508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyfxdwVg5oohGCy6mEfDPhAQ7UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЕрνκΗИЛχЫкσл():
    if len('') > 0:
        pass
        pass
        _dead_7465 = 459
    value = 804524
    text = __import__('base64').b64decode('Q0xIY0tJRmRuTDhiUEdKR01TcmU=').decode('utf-8')
    total = value + len(text)
    return total

def _СхγчμНΔχΣЛΛΩγ():
    if len('') > 0:
        pass
        _dead_1450 = 678
        277
    value = 221720
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHuwQHIuqINWLTW62X+ZMScKylo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΣйУчЦβОχΗΑ():
    value = 745727
    text = __import__('base64').b64decode('d1g2bE5IT01KcTNjcG9ScG4yOUU=').decode('utf-8')
    total = value + len(text)
    return total

def _авФΧφλАЦВХΧΜМΧчы():
    if len('') > 0:
        pass
    value = 377370
    if len('') > 0:
        427
        _dead_7266 = 152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB3Se2Bq1I8PbgCmmVKdMT821Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыДκяΙβщτКЬЬчШ():
    value = 962535
    text = __import__('base64').b64decode('SzdyaF8yNGdNWGMxYThhdkgycEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΩйΚΜΟЦСУщЭΞДΙκД():
    value = 223449
    text = __import__('base64').b64decode('T2VsSE4yUHFBUmI2TzZubFVkb2w=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        _dead_7344 = 439
    total = value + len(text)
    if 52 * 90 < 0:
        395
        pass
        936
    return total

def _гжКхоЬсΜНрчΓΟДТ():
    value = 461409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQGwRGAf9r8INw256nu/Og0stVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юσΦψэАΒυЙСВгαρα():
    value = 994515
    text = __import__('base64').b64decode('VG1uWWlyNTlNQURzUFpHTFpoNkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ъаΓκθбκλЩΓδргУ():
    value = 231285
    if False and True:
        714
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQfCZms086oRCFiRxGPEGSEa82Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        556
        pass
    return total

def _гмаЬМΟФιи():
    value = 645105
    if len('') > 0:
        587
        290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXnvOH4M9IckaB2o4UWjMiN2y1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        50
        _dead_1229 = 804
        pass
    return total

def _ΡΣСвБΟΤеΟ():
    value = 667298
    text = __import__('base64').b64decode('aHhnYjU4N0JlMWFhN1lHOFZpS20=').decode('utf-8')
    if 63 * 100 < 0:
        _dead_6158 = 569
        475
    total = value + len(text)
    return total

def _ΗсеуЩГμбσлсΚЖИ():
    value = 268276
    text = __import__('base64').b64decode('cDlkdWFGTnYxV21NYmlfckpFcFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨεζакΘΛужДμσЬ():
    value = 97342
    text = __import__('base64').b64decode('aGtOTEVBeWhsU0FiT3k5amswdEg=').decode('utf-8')
    total = value + len(text)
    return total

def _οлΖВРτъпΑОΝΠδ():
    value = 842719
    if len('') > 0:
        117
        pass
        pass
    text = __import__('base64').b64decode('UjZJS2c4dWZ1UkMydUhBS2pld1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _рΕΑШршΣЮ():
    if 20 * 39 < 0:
        pass
        126
    value = 775170
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISHLTXMI/4YBLj+b4k/EIBcDxm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9998 = 920
        _dead_5925 = 591
        _dead_7598 = 806
    total = value + len(text)
    return total

def _τΤшΤαЦпкТьЛшАΙн():
    value = 950824
    text = __import__('base64').b64decode('VzhHMnJRbTRMWDJNMTc5VVVTbWU=').decode('utf-8')
    if 4 * 30 < 0:
        295
        11
    total = value + len(text)
    if 16 * 97 < 0:
        pass
        889
        350
    return total

def _ЭεЩчувΒЦЕΥсЯНСЫ():
    value = 663742
    text = __import__('base64').b64decode('VTBvd0wyM19lNm1mbDdFbTB0d2o=').decode('utf-8')
    total = value + len(text)
    return total

def _βТеΡσΟхзΓЫкЧвхЯ():
    value = 965122
    if len('') > 0:
        pass
        10
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS7Kdwht8P4KEwqMwlqBBicl43Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 31 < 0:
        792
        _dead_3400 = 248
    total = value + len(text)
    return total

def _κΩмАΓхАъτУОСЛцЧ():
    value = 654129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgK0f3Qq9pw7HAaA50WRYg8N6nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1229 = 781
        _dead_9669 = 767
    return total

def _ыβчПβХбэЛΔфВΔЖ():
    value = 722997
    if len('') > 0:
        pass
        pass
        _dead_2082 = 914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTqxOlMX+6oXPC6GwgCxICMDzV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠчδхΚРбГ():
    value = 81545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz3gbAUe+5IwHw6r3mGeFg925V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 42 * 92 < 0:
        619
        410
        _dead_9090 = 255
    total = value + len(text)
    return total

def _УΞΝАюршЬбЯшθΟк():
    value = 755706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDjhRQI62qJVFiCCz1WIbSd46VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 11 * 96 < 0:
        pass
    total = value + len(text)
    return total

def _ЕΟяфкΛЛфμΜκЮζ():
    value = 691892
    text = __import__('base64').b64decode('d0tmR0pJR2xNOE85U0NUeVl1NE4=').decode('utf-8')
    total = value + len(text)
    return total

def _хнКрΖΘΥЕρΧыΜι():
    value = 680220
    text = __import__('base64').b64decode('S2x5TXI3WDRhb3VKUUJ1Q3BJNlc=').decode('utf-8')
    if len('') > 0:
        _dead_8868 = 625
        _dead_8321 = 618
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_4718 = 940
        _dead_9411 = 417
        pass
    return total

def _δОκТΦδяδηΦАΜκ():
    value = 965286
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH/FN1Rg3ZIJCDq67nXFOzws1ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 84 * 18 < 0:
        _dead_3658 = 965
        _dead_7115 = 859
        pass
    total = value + len(text)
    if 7 * 57 < 0:
        pass
    return total

def _σφΑЖБъКθ():
    value = 134290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDnVbFls040iCVuLn1WJNisY3Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _беМΙΑηюЗУжΘЙ():
    if False and True:
        pass
        pass
    value = 201555
    text = __import__('base64').b64decode('Y2h1RkJlSDlMRE1QZmlpX2k2UHk=').decode('utf-8')
    if len('') > 0:
        676
    total = value + len(text)
    return total

def _фаЧяΝρΖΑΟ():
    if False and True:
        740
    value = 944327
    text = __import__('base64').b64decode('WXNqRGdkQjFsQWpzMmVCOV9oQk8=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ТμГЩΝΦβξРΕ():
    value = 268322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FybqeFNhqPA6FwmxyU+VYQQ68jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юЬФУмхδхдеЖσΩцК():
    value = 54676
    text = __import__('base64').b64decode('aU0ycXlIaDNOX2dEVHVDc0wwUVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЬОпΥГΥΝъД():
    value = 167059
    text = __import__('base64').b64decode('ZEN5d1pZbzh5WjdPZ1VZVDRxQ1c=').decode('utf-8')
    if 83 * 9 < 0:
        pass
    total = value + len(text)
    return total

def _ΛΤыΠмыКШияРеΔ():
    value = 922480
    if len('') > 0:
        294
        _dead_3262 = 952
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQO0f3U6p6oWMDCU2mSWZ3wetFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        9
        _dead_7288 = 116
    total = value + len(text)
    return total

def _РхλУςЫФρБлЯΜψ():
    value = 698229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PATnfn4w+rEZCQig5HyAMRQ87j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РоΕУщДΟΤ():
    value = 422778
    text = __import__('base64').b64decode('ZTloWmZ0ekRXd2oxalI4bm95ZzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛлΗыНКΝνуεσ():
    value = 484411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyPpdnNo0/ozHF637ka1OCoY5n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШμкΦΑГЩТФξ():
    value = 912945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRbONlk47JwyY1rxwQe5NS8Xs3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яЬйΟЫκΡаτβдποфας():
    value = 918266
    if len('') > 0:
        pass
        _dead_6873 = 341
        _dead_9625 = 196
    text = __import__('base64').b64decode('RU1VMXF2UWNDclFJR2JqSW9DalM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘШтΠаχшЫЬθΧΞαВЦΙ():
    value = 788081
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh/lQUEp548zbiW7kUaCFSgl0HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДФθбλΥθВЧэΨЕ():
    value = 252364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSLIdAURyKk3GD+Q+ga4Ggot0kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РиΘЧнеЛΨ():
    value = 516211
    if 92 * 54 < 0:
        _dead_2523 = 207
    text = __import__('base64').b64decode('SWJTZGkzdEtSY01YMkFqRmpuOF8=').decode('utf-8')
    total = value + len(text)
    return total

def _хφфξλμсψыюИ():
    value = 357346
    text = __import__('base64').b64decode('T200bmJMdkVhOGtDU0RlbVN0TDI=').decode('utf-8')
    total = value + len(text)
    return total

def _τБПΚмЫΠЕ():
    value = 810435
    if False and True:
        _dead_2838 = 110
        263
        _dead_7861 = 686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwDFZnsAxpgpKjv77WOoACcosGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4367 = 340
    total = value + len(text)
    if False and True:
        753
    return total

def _юΑνрПяХσυ():
    if 48 * 60 < 0:
        _dead_5942 = 900
        987
    value = 844175
    if len('') > 0:
        _dead_2333 = 690
    text = __import__('base64').b64decode('clBITGFJckRjRkY4allTVzlSdzI=').decode('utf-8')
    if len('') > 0:
        _dead_5793 = 807
        pass
        319
    total = value + len(text)
    if 22 * 61 < 0:
        pass
        _dead_3148 = 504
        _dead_6806 = 429
    return total

def _ΖЕТΘπτΤюфОθΕлΤй():
    value = 672154
    if False and True:
        924
        _dead_9073 = 959
        725
    text = __import__('base64').b64decode('dEtHa3d5RVZ4cGxOcVNrdTdfaGk=').decode('utf-8')
    total = value + len(text)
    return total

def _κЕОАΕжСБтЖνЕнΓΥ():
    value = 523206
    text = __import__('base64').b64decode('azFwZFFuQ2JncXZ3UU91M0F2ZFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _бюΣШЧΠюеы():
    value = 118495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCn1V1owyIUKDSG1/GfCJDU2y00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТπρΧΧХπжРΡС():
    value = 539485
    text = __import__('base64').b64decode('VTlGSTVNRUM5cW1mVnV2NHN5SkE=').decode('utf-8')
    total = value + len(text)
    return total

def _АДмγфЬтЧΥцσ():
    value = 98237
    text = __import__('base64').b64decode('b1FhdUNWZ0RVaGprM3ROb29rZFM=').decode('utf-8')
    total = value + len(text)
    return total

def _рκщшцсεЧδАШРε():
    value = 887650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQm3VHBoqqcIOSmM4A66JnAA/To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σοψгκСОГЭ():
    value = 148253
    text = __import__('base64').b64decode('eFNzMTJXTHloSjNXZUdTZ2luQzI=').decode('utf-8')
    total = value + len(text)
    return total

def _бЯτЭаюХζΡΕфΡыΠЪ():
    value = 857685
    text = __import__('base64').b64decode('Rm1ZYTR3Z2tuX3Z4TVRnSXJrNmg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ψЕжαРΣЯццйΣβсю():
    if 87 * 66 < 0:
        pass
        _dead_3449 = 942
        pass
    value = 387775
    if False and True:
        552
        437
    text = __import__('base64').b64decode('b1JKcFkxWmFKMHhNVExpR2Vyc0g=').decode('utf-8')
    total = value + len(text)
    if 6 * 33 < 0:
        608
        _dead_9329 = 669
    return total

def _θΟхкЛεУΡоκ():
    value = 361240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx/teEBtz6I2biO74wKWZjYj5V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λфжλЪМςХСыТ():
    if len('') > 0:
        pass
    value = 646018
    text = __import__('base64').b64decode('dUpsTjZiekVpTW1BSTMyQXdESUY=').decode('utf-8')
    total = value + len(text)
    if 54 * 26 < 0:
        _dead_8161 = 550
    return total

def _ЪΥΛЗъдуηгбГНψΥжω():
    value = 286081
    if 72 * 24 < 0:
        236
        _dead_6631 = 190
        832
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQrQSkMJ26IaYguO8EO8JXwX/kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΡЛυГЯρнкτкгЭйβθ():
    value = 645587
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pxq8YgUhyLwCP1eLmX6AET8p3EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜДψΨЗЯΤЯЩεΝ():
    value = 860173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjXTe1806PASHh+G+FefDgI59j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΚГБΝθζρэеШБчД():
    value = 775462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LivbUQIv14EtKiqF6WPHMBUFtlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΝгκЗиσЭеχШ():
    value = 771735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCL8dgVu85khICih6gCKOnYY5lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 49 < 0:
        993
        _dead_1909 = 963
        269
    total = value + len(text)
    return total

def _σЪρыЫμψзЙР():
    value = 381222
    text = __import__('base64').b64decode('d3hzQ3NESlpSZ3QwUzJhNXpDSFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ςλфςχЖТΠб():
    value = 568321
    text = __import__('base64').b64decode('U2s5cmNFNjBGVnZyQXBkN1NIcHQ=').decode('utf-8')
    if 64 * 35 < 0:
        pass
        772
    total = value + len(text)
    return total

def _ΚФчпχΠΙΣΠΩВгπΝ():
    value = 324865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyjiTHUD95c7Fwy7nU6aEgMj9lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УτтΖзνжηВ():
    value = 878667
    text = __import__('base64').b64decode('dWQwdkJhZm15ZlA4YXl2RzlIM2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ιУПΞЙδгъεαΧΓΧБΙ():
    if len('') > 0:
        pass
        pass
        pass
    value = 548749
    if 77 * 70 < 0:
        950
        829
    text = __import__('base64').b64decode('VGM4UGhOajF1X19tUlcyQWV3RW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΓЗфФъΧъПлΡгж():
    value = 991951
    text = __import__('base64').b64decode('aE5mZ2JWZTJoVHFIZ2l3dFRsVUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯφΨπΡΥΘμтΗлΨνΖыо():
    value = 948216
    text = __import__('base64').b64decode('R3MzYzJYaTlfaUl5cG1hUXBVSUY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        160
        pass
        pass
    return total

def _дЛЫυβσΔРψΡПИΒЗА():
    value = 741694
    text = __import__('base64').b64decode('UXc3ZFNGNXlsSEg5MXI2MGtyQ28=').decode('utf-8')
    total = value + len(text)
    return total

def _ДφιМнЬДηхΗЩζмΣ():
    value = 23891
    text = __import__('base64').b64decode('aXFoQk1IVnpUUGJvalRUVHhqX1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞηДθΩШиαΑтчΘС():
    value = 224678
    text = __import__('base64').b64decode('Qk5MZmNpdWE3TDZCelVZOU9TbEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ζЫУцνΩехЧΚχОшοП():
    value = 49785
    text = __import__('base64').b64decode('dGpzd2RBcjVpUEo2djZaeVV1ZUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥынюφΚнуЮ():
    value = 925310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD7eeFghrqoyMzmz7lC6Fgwi7Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μδцΛςюγМе():
    if False and True:
        pass
        pass
        _dead_5868 = 711
    value = 938248
    text = __import__('base64').b64decode('S0Z0Vnl1YVlmc0xZU0w5TXEwcHQ=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _мЗызСдвШлКΓΣδЦΘЪ():
    if False and True:
        290
    value = 640166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lw7iPggrrLEEDyamwGOqPi0r1D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΑсШΣкхЦЕСωτρπΕФ():
    value = 287528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KivBVHoV+LEkOV6CwUSyLiQ10WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7976 = 665
        _dead_5989 = 534
        pass
    total = value + len(text)
    return total

def _уЛСшэΛйдΧ():
    value = 848530
    text = __import__('base64').b64decode('ZU5TMGdKSmFGZktqR3ExMHhZdEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗЙнαΗπфΔгЧШ():
    value = 302227
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCrFZEML368RMRn6zwGTLDd8vUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МτЬхρχΔеБщгε():
    if 79 * 7 < 0:
        664
        383
    value = 782522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR/iXQJv/aEFHQaTwWWaMA4pwz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙВЯУиЩδнЕчζЖСщ():
    value = 410207
    text = __import__('base64').b64decode('Z3VSdDVlbnE4QV95Y3hadkRjSVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ВψΤоτΠУΝνΓγ():
    if 1 * 69 < 0:
        636
    value = 323307
    if False and True:
        260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E33KOV4U7KpWKxeNz3uINRQlyFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        153
        pass
    return total

def _ΡкΒБГлЖЖλХЗ():
    value = 848243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX7xXGM71pspDgS03G+YHzIf9VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЭАьΜΑтШЧΕΣβρΦζα():
    if len('') > 0:
        pass
        875
        _dead_6680 = 805
    value = 251426
    text = __import__('base64').b64decode('d3ZqeEVkd2g4YlpESkQ0TlVQc3Q=').decode('utf-8')
    if 20 * 1 < 0:
        436
        _dead_5909 = 136
        937
    total = value + len(text)
    return total

def _ЭΧζгАиΟиЪβИ():
    value = 956852
    text = __import__('base64').b64decode('aXNhRUQ1a3R1YmtSR1JIWmY4YWY=').decode('utf-8')
    total = value + len(text)
    return total

def _χΞδΠηСΙδДОиГКΝ():
    value = 287666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC3DNkMD965WOzCvkUy2EHwbxTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΕшЗΞΞотΣ():
    value = 369984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSvrQGsfp/FWbVeC5kakFz187jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        450
    total = value + len(text)
    return total

def _нЮΘΜΜкзБШКЕΣзЯьμ():
    value = 941318
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AX/gO0It2bxULiWgmXe/BT17wGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηДлνΨΟνыаΗЯΟΚοΑ():
    value = 931641
    text = __import__('base64').b64decode('VXJ6NGVEb2pHdVBnc25DWTFGV08=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜзςМЖоΩумχ():
    if 81 * 98 < 0:
        pass
        _dead_7547 = 70
    value = 423276
    text = __import__('base64').b64decode('V043WjJlZmltbFFuN1FsWDRFdkc=').decode('utf-8')
    if 50 * 74 < 0:
        pass
        337
        760
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_8674 = 285
    return total

def _ЫσΡцЫβжОρςе():
    value = 494261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyDjRmUBqLtaEFmN7VK3ExwZ40o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДμЭчгΑвп():
    value = 821623
    if len('') > 0:
        8
        _dead_7019 = 534
    text = __import__('base64').b64decode('d3JXakd2Nzg3bmQ3alF4eHdta3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΝιυΖпΔТ():
    value = 441008
    text = __import__('base64').b64decode('bFVJZnVTODNPRUFvWXloOGRjdzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ωуЬθшλΖΤ():
    value = 602751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ixf8T1lh1vwBCiq3+n6xHjEC4zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΥеζйфйΦЯΩФх():
    value = 215984
    if len('') > 0:
        pass
        pass
        489
    text = __import__('base64').b64decode('T291WV9lRHVCUHBIcHpWTUw5QUc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        882
        pass
    return total

def _ыΣюцΦгшΣиΛдφиκΟΚ():
    value = 594437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjzMY2Aa76kPFg6Kw3C8FiEf/Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΒЬАвЗΘпΣεЦσчрΘσ():
    if False and True:
        903
    value = 40659
    text = __import__('base64').b64decode('S0xqZWJzX3pfNk5ZXzhvYVoyZ2w=').decode('utf-8')
    total = value + len(text)
    return total

def _МхНдгΚпзиνψυпЦЗ():
    value = 425918
    if 10 * 67 < 0:
        pass
        _dead_8250 = 886
        pass
    text = __import__('base64').b64decode('S21UXzhiWTVHbzJLZ2RCUVAySmw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        710
    return total

def _ΧιΦиΞпθРщсΗοжΖ():
    if len('') > 0:
        _dead_3874 = 837
        _dead_7501 = 948
    value = 335710
    text = __import__('base64').b64decode('SnhxZDd4OWlwNlZkenZDZVJ5Y24=').decode('utf-8')
    total = value + len(text)
    return total

def _ъεЛШΘоιФ():
    value = 348082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx7NYUUDqrEoPyiZ4125YHwuxTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 22 * 99 < 0:
        6
        217
    total = value + len(text)
    return total

def _εЗρяДбΞРωκвтзБВ():
    value = 780171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IS3pOlkN5rIKPQm13XrBI3EQ8UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘνОУцУσеΩЭ():
    value = 891502
    text = __import__('base64').b64decode('bnpweFhIZkdITk5ZeUlMSHNJS1M=').decode('utf-8')
    total = value + len(text)
    return total

def _οξΝνИζΘгьЛυ():
    if len('') > 0:
        _dead_4029 = 764
        pass
        pass
    value = 336938
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ewm3XmQUxoQaFlen5EyjOggg/W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        175
        _dead_4932 = 489
        pass
    total = value + len(text)
    return total

def _ΖэРΛЕуюирΓΨ():
    value = 873473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACfWY3Qx1YtaOAqK32GJJyk6zjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥапоψΦЙυоηЯоΦ():
    value = 531193
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh3PQQEz86ACHD27yVmVGQd23HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 78 < 0:
        950
    total = value + len(text)
    return total

def _япЖНхΖνЕоαХщы():
    if len('') > 0:
        378
        _dead_8107 = 593
        _dead_3218 = 126
    value = 581145
    text = __import__('base64').b64decode('T0FsWUFLVnZRQmU5a0F1SkxtZU4=').decode('utf-8')
    if False and True:
        _dead_9347 = 234
    total = value + len(text)
    return total

def _шиОΖЬθедмлΦΑчΣЗ():
    value = 973582
    text = __import__('base64').b64decode('VTJKQmFuYnNuVFY4VmIyeFZHQ1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _τЫХςМЧαмэВюπΕЫοС():
    if len('') > 0:
        _dead_2460 = 399
        _dead_6955 = 86
        _dead_6326 = 439
    value = 534614
    if len('') > 0:
        622
        pass
        _dead_3258 = 90
    text = __import__('base64').b64decode('a21wdVdOV3VZMGxEZG9IVGtKczE=').decode('utf-8')
    total = value + len(text)
    return total

def _цψνсЙΒΥΡΘи():
    value = 916385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjvzWnQspqEiNwyH/0OhNwkF00Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чЪпсСπθςΛйРФО():
    if 85 * 44 < 0:
        pass
        84
    value = 622581
    text = __import__('base64').b64decode('SHlhZGdpeDZxd25tc21nSHBkQUc=').decode('utf-8')
    if False and True:
        pass
        403
    total = value + len(text)
    if 25 * 84 < 0:
        993
        pass
    return total

def _ЕοОφςарχогТыΠΩаД():
    value = 33957
    text = __import__('base64').b64decode('RkhVTXVVeUFhMnhIZWlYU1NlZms=').decode('utf-8')
    total = value + len(text)
    return total

def _МωηΑγХΝхβнΣЯ():
    value = 612871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzXWZEQpp/9THiaV40+IHwl371c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΝδэяЙвННПЕαΗλ():
    value = 11555
    text = __import__('base64').b64decode('U0tHUlc5N25HQW1GcVVtczVrTEY=').decode('utf-8')
    total = value + len(text)
    return total

def _жΩΕΞыХЮГрзЧхΩЮ():
    if len('') > 0:
        590
        pass
    value = 758424
    text = __import__('base64').b64decode('VVNWMGVwTE5kZm8xaWIzVzc2Sms=').decode('utf-8')
    total = value + len(text)
    return total

def _ПъναΑнкΚжсЯНΘΣФ():
    value = 171663
    text = __import__('base64').b64decode('TlU1OTNpTmtPZzJDMTNMenp5RjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ξыЬχЬΛзΡλφΠЯ():
    value = 34711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyPwOXksxqxVF1aRnHmBLQQH/j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξυЛολυкΝл():
    value = 786240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRDMRQU+84IlIi3x4gKXIXQs0Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юЛμΚеΖυжВΦшσПψюх():
    value = 616585
    if len('') > 0:
        _dead_7957 = 808
    text = __import__('base64').b64decode('WW53aUo4T1pIRHJPUEZSaHBkcFI=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        401
    total = value + len(text)
    return total

def _фωХсΖБπэ():
    value = 365621
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQ3idnUP3PEBYjWc+QS5BiMGz3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2666 = 949
        228
        _dead_8433 = 743
    return total

def _ΝньНмЛΗШЖлρьщАιФ():
    value = 44230
    if len('') > 0:
        _dead_7750 = 531
        _dead_5718 = 459
        _dead_2605 = 333
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASzFRFA01v8KNhuw5AbCGjYmsWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сВΡβГпхяβФФιΥΥΕХ():
    if 28 * 34 < 0:
        791
        179
    value = 655310
    text = __import__('base64').b64decode('b2g2dk1FckJMRWpmeEFDX1VBcHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΔфАνΓвυηАИхюэ():
    value = 222810
    text = __import__('base64').b64decode('dW9VT3hXMWg5S256VlZpNkJfOU0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4991 = 481
        _dead_7672 = 330
    return total

def _шλСшДхШФЩΞμ():
    if 77 * 37 < 0:
        pass
    value = 637833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQLJQ0Q204k8aA22xHqfPA4C3Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 67 < 0:
        pass
    total = value + len(text)
    return total

def _ЧнΦТЙЫвЕΜξψГλЦП():
    value = 24902
    text = __import__('base64').b64decode('Vm5oTUtXV2J6bTZYVklTak5GVmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΘЭтδБвΖЦФГ():
    value = 724033
    if False and True:
        pass
    text = __import__('base64').b64decode('SzlYMXpES3dmWXhNNjFjNmUwYXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ХпΦΣЬΜΝψфχκαω():
    if False and True:
        pass
    value = 513114
    text = __import__('base64').b64decode('QlVHWnNBNUdFX21xd0dMakhTclE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩьзαΡжХΒΛ():
    if 83 * 59 < 0:
        pass
    value = 840240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARnFSGAwp5tVClqvm3WVYHQt1Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μввбΠΦбСγсхйΞΘ():
    value = 826466
    text = __import__('base64').b64decode('clZHT3RTa3NuaVV0ekxaVUxHalI=').decode('utf-8')
    total = value + len(text)
    return total

def _гσςъψЙβфЪДгΩηЯз():
    if 77 * 31 < 0:
        390
    value = 498797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSDWTXcz9I9UFx2N4A+kBQsl9Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 56 * 41 < 0:
        _dead_7652 = 482
    total = value + len(text)
    return total

def _юλПЬμгυЩЮЫςа():
    if False and True:
        677
        417
    value = 611898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBe9RVgd7JcAE1uX2W+SbXQE3ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΩФЖЛΔΠσнчлρΕΣжΚ():
    value = 884633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3vbXAEK+bwBMF6l/kOmZjQL4GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮмРφЙΖБРψщлмλЖИΕ():
    value = 750008
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwPxVFYO8osqMQq1xwfHNxod50Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΟοζДΗΡЯуκ():
    value = 948454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxvoYnNs+/4qCj2M+WapBxAovX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 49 < 0:
        170
    total = value + len(text)
    return total

def _ОхΓυρφαΥιвлΒг():
    value = 909715
    text = __import__('base64').b64decode('ZjJmOWxETUhUYzFvTTVHUkRSeng=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЭТфыΕΗвΙоΝЯоσπн():
    if False and True:
        916
        119
        _dead_1458 = 137
    value = 743586
    if 89 * 84 < 0:
        _dead_7245 = 608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgnWeQAyz7gsbz2741+EHzwW9VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΟΒгθςСυщ():
    value = 547523
    if len('') > 0:
        100
        12
        pass
    text = __import__('base64').b64decode('UVN1VnRYUVV0S0s4T282c2VmNFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕχРпжуΣΒщЙы():
    if len('') > 0:
        pass
    value = 322863
    if len('') > 0:
        457
        _dead_7372 = 282
        _dead_3656 = 699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDqyfVQ96P0qag6S91XEJHZ7yUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _зПθΒчъщфγбΨ():
    if False and True:
        _dead_9442 = 465
    value = 941001
    text = __import__('base64').b64decode('aUlHNjgwdjk3c3BhWUlkYXo5MmQ=').decode('utf-8')
    if False and True:
        _dead_9776 = 334
        754
        508
    total = value + len(text)
    return total

def _ΚйВΒйДэΣχМεцΧΥКΚ():
    if len('') > 0:
        pass
        pass
        pass
    value = 148630
    text = __import__('base64').b64decode('eVZlaTZsTF9jbmdWQUxwNlpPaHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭрθπβШПцΞЖ():
    value = 515373
    text = __import__('base64').b64decode('akN5T2t1MElwTVZsaXJyRnJWRDA=').decode('utf-8')
    total = value + len(text)
    return total

def _чВφзλαтΚΑУΩγΤнтπ():
    value = 707543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhbLSQcz7PsrYxiZxQScIioZ4lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΧΦцΓНъгУνΖΒыЯΗ():
    value = 770534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTrdeXxpzroZFT2X+XiXHiQd3U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШСγБпнΘРηφΣВЗЭΖз():
    value = 950896
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR/8VF48044xNzfxz3HIJQ4e02A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _στΝсэΒяЦΥ():
    value = 568576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAD8fmse0oBWKQapmQ62OS8Fyls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΝлваΟΝΑгУУΗД():
    value = 178277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAjeekI9qbowEVel+gSmBzMg/mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΜзпЮΚΛγЧδС():
    value = 212563
    text = __import__('base64').b64decode('REYya3dlWTdIUmtFOUpxM25RNTU=').decode('utf-8')
    total = value + len(text)
    return total

def _МйιЬииТεЖπβдωΞ():
    if len('') > 0:
        180
    value = 932172
    if len('') > 0:
        695
        pass
        _dead_4237 = 958
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQrvXQAY8pxVCy2C2AC0NxwI93Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧфжΚΓαςйДЗθКЩю():
    if len('') > 0:
        416
        pass
        849
    value = 179403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID/QZAAq7ZtabT2awAG/YBM320o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 88 < 0:
        _dead_9700 = 253
        130
    return total

def _цЕΞГВОХЙьфЕЯзр():
    value = 878376
    text = __import__('base64').b64decode('eDRjbWVhcmNpYlJfbWZFZU1ydWo=').decode('utf-8')
    total = value + len(text)
    return total

def _гΤеξФоΗоεΧфЮМЖξ():
    if len('') > 0:
        pass
    value = 28031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgL0XWEo1rpXLVn692aVEgM7vT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΦυΚкНшИΓЮοЛΚζμ():
    value = 454913
    text = __import__('base64').b64decode('U1pSMk5mMDl6VzlXRlFGVG1GNXk=').decode('utf-8')
    total = value + len(text)
    return total

def _жζΗΙяΝТЦωгоΜΜлУ():
    if len('') > 0:
        951
    value = 947358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fiq0S2IByvlSNg6S/FGFZn0h6nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СндΠЦΦьЮλъйц():
    if len('') > 0:
        586
        495
        _dead_2989 = 148
    value = 844319
    text = __import__('base64').b64decode('bld2ZmNHSjlDNUViR1ZVTUJOTWk=').decode('utf-8')
    if False and True:
        209
    total = value + len(text)
    if len('') > 0:
        370
        _dead_1689 = 299
    return total

def _яЦБΘζδмъξΓБаΨψ():
    value = 200731
    text = __import__('base64').b64decode('VmNfNnZwS2g4a3RvTnlWYjhMVTk=').decode('utf-8')
    total = value + len(text)
    return total

def _экЮЗΗДыΕΞЧυΣсКΧ():
    value = 724404
    text = __import__('base64').b64decode('dlF2QXJuWF84X2t6Q1VHbXJZUFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ωжΥсΩШЧоΣ():
    value = 862216
    text = __import__('base64').b64decode('SUVXbmhkOHZsZWo5R002c2F1N3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ηСψΖΡяΒГΩηшбиΦ():
    value = 667905
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwLzOGUx8IE0ExuvkQS5MjAe03g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цχРνЗσЗХ():
    value = 763219
    text = __import__('base64').b64decode('el95YXNpT2tGWGtxbVRzQk9TMW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬХβйЗЙΤОо():
    value = 203637
    text = __import__('base64').b64decode('R25OYV9keUxiUF9aanc4OUxpNWs=').decode('utf-8')
    total = value + len(text)
    return total

def _φδχΜчμЛэТ():
    value = 985908
    text = __import__('base64').b64decode('ejc4MkhlYVhoU0ZQWHh6SWtFT2M=').decode('utf-8')
    total = value + len(text)
    return total

def _СЯΠσОΓΜωΥчΞЛν():
    value = 565496
    if False and True:
        _dead_8977 = 151
    text = __import__('base64').b64decode('a3RMSjhDUUROeXcxaUhuS1lyd3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑЭρиыοмэИΡ():
    value = 616794
    text = __import__('base64').b64decode('RFlhSWJkR2diRGl2WTB0WkZYNlI=').decode('utf-8')
    total = value + len(text)
    return total

def _дςεшΖРΟΛΕΝяΓА():
    value = 378472
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiLgX0I68f0oAyebxlm/LiwY80o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 3 * 24 < 0:
        pass
        399
        _dead_5850 = 453
    return total

def _ПΗБηрΘМςЩ():
    value = 157319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX7AXXQjpq8gNCimmgLBASR43mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΕжΩΕχΛΡйЮΘΨ():
    value = 483080
    if len('') > 0:
        966
        48
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh/COnApxLA2Lzmn233JEyEm/Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        465
    return total

def _жэιуνжΠΖбΛчβЩА():
    value = 585810
    text = __import__('base64').b64decode('RjBUSFY3b1ByMzRRNHJycFN1Z3Y=').decode('utf-8')
    total = value + len(text)
    if False and True:
        765
    return total

def _УαБΙцεΨθсλЙь():
    value = 636494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB/mRHYw0ZoSE1iw2VuCYycJyGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τчεЖΟкΜхпч():
    value = 146522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQu2bXAG2r4nYzel8l6ANRd+yj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФеΗηΤЪΓΠГ():
    value = 549372
    text = __import__('base64').b64decode('TzRNRGZvOTJTemYwQjdQd3c4MTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬШоъΩΤрΠοΙαγе():
    if len('') > 0:
        pass
    value = 99771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyLwaH0O1L8iLSmWn0CHEQcg0m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΙоЦЙЪРЛщеэπдв():
    value = 481312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACznQVU60LkNKjy1yXCzbBUIzTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥяΖοэΒСωВчΕсΚ():
    value = 218793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgHvOgIhqq0HOxr2wGKxIS8/tEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НЕΝΙкψжωИκ():
    value = 245144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxbDfEUYrakmLRuE6gK4IhEq81Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 21 < 0:
        761
        pass
        5
    return total

def _ρнСрлюреХшющца():
    value = 895654
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBzMXkct3a4XLTyW62OqPXB36mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дοΛδЬЭвςжгт():
    value = 712965
    text = __import__('base64').b64decode('QXA5THU1Zkx2MVFleklQRkZ0SnI=').decode('utf-8')
    total = value + len(text)
    return total

def _виАиΡΕΑТЛЦυиоυд():
    value = 95413
    text = __import__('base64').b64decode('TzBEeVR4VlR2Nlg3aWR1eEs5S24=').decode('utf-8')
    total = value + len(text)
    return total

def _τбΩэтвδтЩνΣ():
    value = 552963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HATAZWdp5ItQDA2C31i2HnZ9wlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7963 = 674
    total = value + len(text)
    return total

def _ЭюББВлωМ():
    if False and True:
        pass
        837
    value = 367583
    if len('') > 0:
        874
        518
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR7wZVtoy41WClqC9wLJYyM23WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4533 = 74
    total = value + len(text)
    return total

def _ТΜБюΓуξъюгаРΟ():
    value = 562988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjzDbVs38YwQMB+c23mxLQsr4GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НкСЧχДВΧжρ():
    value = 333071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISTTXGY0/J86KTixkXWBIQE4xko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        657
        pass
    return total

def _эиΚΘΡΜССръппμк():
    value = 836351
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx7JPEIuzowSLTabmkOCBCIs93k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        520
        _dead_9791 = 351
        _dead_9868 = 991
    return total

def _гьηΩыИЛхоВа():
    value = 975769
    if 41 * 67 < 0:
        _dead_5345 = 360
        _dead_8759 = 634
        87
    text = __import__('base64').b64decode('dFlRd0E5aU9VU2M3WDFMejhJZ0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ДμΑАΦχΠγυьΦγσЪчβ():
    value = 628451
    if 48 * 83 < 0:
        136
        393
        pass
    text = __import__('base64').b64decode('ZnkyMFRGaGJQZDk2bmxMaGt1Rkg=').decode('utf-8')
    total = value + len(text)
    return total

def _δρςхъурИЖΠΕ():
    if len('') > 0:
        602
        _dead_1759 = 184
        _dead_2186 = 400
    value = 817041
    if len('') > 0:
        844
        522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB3zQlo96a4gChWq51HGIiYLwXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_5252 = 162
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()