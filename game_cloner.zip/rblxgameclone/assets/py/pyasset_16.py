#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _γщшιαΩΟАΔЧыσΟΩЬ():
    value = 585928
    if False and True:
        345
        840
    text = __import__('base64').b64decode('RlFLTU1ZcklZaGp2anBiNkdtckk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜЮуμеΜщΨиΞ():
    value = 275989
    if len('') > 0:
        297
        _dead_9959 = 462
    text = __import__('base64').b64decode('WlBKREhJUGtfbk9hSVVhYjAwZjY=').decode('utf-8')
    total = value + len(text)
    return total

def _εРцЖΓΘΚИκΟМуаΘο():
    value = 389983
    if False and True:
        304
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3rjYnsQ0IY7awuSngOAMAc6x1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        892
    return total

def _шпεΡЮθΓβюв():
    if 26 * 85 < 0:
        pass
        _dead_2368 = 62
    value = 632682
    if 14 * 76 < 0:
        pass
    text = __import__('base64').b64decode('SHU5NlFyY181MHBWbTYyNTV3akE=').decode('utf-8')
    total = value + len(text)
    return total

def _щеλδжрΞηΤ():
    if False and True:
        _dead_4421 = 143
        pass
        pass
    value = 358288
    text = __import__('base64').b64decode('ZTN0bjhVZWdDZ1FuZVlLNTh6T1E=').decode('utf-8')
    total = value + len(text)
    if 43 * 22 < 0:
        380
        _dead_6409 = 935
    return total

def _ψεяΥЗАχσΡхОдρΒ():
    value = 509056
    text = __import__('base64').b64decode('T0FUbThFZkk2MFh6RTFXNFRlQlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΗОСъςσШμνЩфз():
    value = 443590
    if False and True:
        pass
        _dead_3238 = 986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXzQXmcK7q8aGyuK4QaWHyEq7zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        406
    total = value + len(text)
    return total

def _ЖξьΚНωΘъ():
    value = 822329
    if False and True:
        pass
        508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD7dUVsNzL85bgeCz1qGGRd4100='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6195 = 59
        _dead_4207 = 860
        179
    total = value + len(text)
    return total

def _пЙЭΗуβФСсЪ():
    if len('') > 0:
        _dead_9091 = 32
        _dead_2266 = 531
        pass
    value = 10514
    text = __import__('base64').b64decode('Y0ZpQktUeHFZYzZjQWh1M1RQOWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΓдхрФКτмκКμ():
    value = 19012
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBrGbVUIrf8PBTCw4lLAIQ8Y/Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΠДΟжεΘм():
    value = 179914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzzDYQcW85sTayer5QWkIzcq3k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зцъρЖΔЭΞжΒΛЛхйΡ():
    value = 208379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3fSNgMprpwAFDCmxmaoFhoHyTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟпδζΤΓΝэЭзβП():
    value = 579515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiPyRnw+7J8sAx2q2wKVHTUpyUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5925 = 96
        _dead_4330 = 464
    return total

def _ОΓНЧМφГлΣΕЗуΠ():
    value = 72457
    if 26 * 36 < 0:
        pass
    text = __import__('base64').b64decode('ZlNmT1VCblJqSHpTOVRFdGxIdm4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2366 = 110
        pass
    return total

def _ЮЫσΦδУΦΣΙΕδ():
    value = 620653
    text = __import__('base64').b64decode('YjMxdjV5d2lVOHZhck14NDJ4OUM=').decode('utf-8')
    total = value + len(text)
    return total

def _πиκбМжκωΖ():
    value = 461313
    text = __import__('base64').b64decode('WGhaYmw5aFdlR1FxWlN4MTgyZFA=').decode('utf-8')
    total = value + len(text)
    return total

def _σХЧΞЦАъαЕλπςъе():
    value = 698941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Li70ZWM20Y1RY1qa5F+yNhEf3lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 74 < 0:
        51
        715
        pass
    total = value + len(text)
    return total

def _ЦδВΨСΗсЪКς():
    value = 34685
    text = __import__('base64').b64decode('QU5fSW0xaDh6Wmd4b0thM3hMQjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕбЩΙηψηαЮ():
    value = 369462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSPbWAEr7Po5EQmH7FOWB3V6sW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΜΦВЕΘяРξΤΦ():
    value = 276446
    text = __import__('base64').b64decode('TWtPMU5OVkdBUDRHSW9YVlBnS2g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _УИПРМЕЙбэρ():
    value = 931047
    text = __import__('base64').b64decode('VTlKU0w5OTlEbDdqVTlMSV9nMDk=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ШΞυΣДΓжЯΠцЬд():
    if 56 * 54 < 0:
        786
        713
        pass
    value = 365197
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSThdlwc74YoDF+QnHCeJyt99Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        586
        138
        pass
    return total

def _ΞζщξьφΜτ():
    value = 245686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR7GfX4/wZcSPD/0m3u4EAot6mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        872
        608
        666
    total = value + len(text)
    return total

def _ЦεбπЗЗвПЗмяΥρс():
    value = 978094
    text = __import__('base64').b64decode('V0dUNzRjclVaSkFjMVpxcktaMjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑУОпыЗκγνбМоλΒн():
    value = 246998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx/zX0kU565XYzyJykaIACcg4ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΦЬЗбΙювСаιгяЭπ():
    value = 916221
    text = __import__('base64').b64decode('RVV0UGJyUlNJcDVpZHJqVlR5WnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΔвЭЙΡΖΨΧшνЬΝвнΙ():
    if 99 * 98 < 0:
        994
    value = 958531
    if 7 * 94 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHnUPEFvrvE6Nx7231TBPQp94WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣУЯξΦЛκςоЙ():
    value = 726272
    if len('') > 0:
        _dead_8160 = 247
        pass
        706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQO3ZGI7yK4oMQqQxV6bOCc//WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        631
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        963
        433
        910
    return total

def _мЭλИДδΡЮ():
    value = 31610
    text = __import__('base64').b64decode('VkNvQzF0eDlZNnBJV1lrYmJZZXU=').decode('utf-8')
    if 82 * 37 < 0:
        pass
    total = value + len(text)
    return total

def _ЦΙψсЫрюВΠ():
    value = 193447
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnzoQHAV5q00DwOc7Ae0OnQ//nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 51 < 0:
        _dead_8989 = 837
    total = value + len(text)
    return total

def _иЯΤΨчεЫеоγаΒςМ():
    value = 569324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MALcN30A6p4iIhn7yXeXFi97738='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уюГΜβμяНшνЬ():
    value = 316617
    if 8 * 43 < 0:
        989
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Chm8S1wT+YAJCzi7kEKCMyIg8mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 9 * 29 < 0:
        _dead_5539 = 167
        734
        pass
    total = value + len(text)
    return total

def _ФαυηξлΦφьчХΣρФЬδ():
    value = 171702
    text = __import__('base64').b64decode('Vlhzb1E1b21peVNHbU42dkRtYVA=').decode('utf-8')
    total = value + len(text)
    return total

def _θωьОчБАы():
    value = 20044
    text = __import__('base64').b64decode('QkNxWTZSM1lxRnlzX2J2dENhTkI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5038 = 25
        340
    return total

def _ξЙψрθФЗцо():
    value = 995322
    if len('') > 0:
        934
        328
    text = __import__('base64').b64decode('VnR5UjRqT0loSUo0SnF2VjJvNGM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9957 = 448
    return total

def _ВπβКиФβΨтμэσΗ():
    value = 684534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NC7HOkED84UMCTqc6X+SI3Qbsm8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        948
    total = value + len(text)
    return total

def _ЖШЯШΘЖΓц():
    value = 54846
    text = __import__('base64').b64decode('VXR4Sl9EVnVDVV9pTm45a2E4ZDc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8666 = 504
        642
    return total

def _уЫсλΚмКΑ():
    value = 357239
    text = __import__('base64').b64decode('WHJOM1g2RElKVmZKelpfYzd4QUY=').decode('utf-8')
    total = value + len(text)
    return total

def _фУРκκгДкτΠКΠэ():
    value = 133117
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Niy1SXgNyY4BKBX2xVi8ZHQa/V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 82 * 98 < 0:
        287
        pass
        pass
    return total

def _ξЙшΨЭыψΔθπΩξИ():
    value = 553193
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyGzeklp26YxMDmZ91GjMzMH81s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6410 = 679
        684
        pass
    return total

def _УωποАДхζН():
    value = 621904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQ3mOmAs2IsFESmL+XrHDSwuw1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        130
        123
    total = value + len(text)
    return total

def _ΤзИΜОтАοЙыΥэШδЮ():
    if 71 * 53 < 0:
        _dead_6573 = 37
        164
    value = 837836
    text = __import__('base64').b64decode('Q0taYXJYbGNVZVRPUW9iaXo3Tm4=').decode('utf-8')
    total = value + len(text)
    return total

def _αΓщВпАΩρΣпΒуИ():
    value = 450367
    text = __import__('base64').b64decode('WFphUzQxQVJFOWRWQ3hHWm55bmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ГБΖηАПΤпшη():
    value = 173839
    text = __import__('base64').b64decode('SWNPTkhwUGxMRDU2aU1uRExvc0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖъРВГщЧβя():
    if 39 * 5 < 0:
        _dead_5518 = 470
        _dead_1217 = 568
    value = 366552
    text = __import__('base64').b64decode('Um9BQWNTeVlqYTRBbVQ3bUlFcGI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _НΣмйыΧфжπρΤοюм():
    value = 323569
    text = __import__('base64').b64decode('cFUyTDJYUk1OZXVNN2o4dUlYUjA=').decode('utf-8')
    total = value + len(text)
    return total

def _жιУεΔиЪΜФтхА():
    value = 403396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh+9ZlZr5pg3FFeJ+GWvOyQ23DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3694 = 437
        574
        763
    total = value + len(text)
    if 47 * 20 < 0:
        _dead_6796 = 979
    return total

def _ыξЙΔЫΞЗцтк():
    value = 700439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRbpfkY0r4QqOQW56liWBgEZ6Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НгΙРтюэШЯρоφΝсζ():
    if 2 * 42 < 0:
        _dead_6304 = 594
        pass
        pass
    value = 220107
    if len('') > 0:
        677
    text = __import__('base64').b64decode('UHpPSHJMaDBBcXA0RVBqb2hMUVM=').decode('utf-8')
    total = value + len(text)
    return total

def _θΤΩπΨΦδСκ():
    if len('') > 0:
        _dead_6026 = 470
        pass
    value = 983099
    if 63 * 74 < 0:
        40
        406
        328
    text = __import__('base64').b64decode('Z3VBTFB4SWxHaTNGaEd5NVBGd2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡχЮξΤюяЦη():
    value = 267793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDz3bQZp7o9aMRi5kHeyBXAq5mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟψбАυςΑУм():
    value = 749515
    if False and True:
        _dead_2095 = 487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KybsOWk/x7ExPSeu+l3GHnMu3no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        670
        pass
    return total

def _ΓЦтοΓЛθΛРΝуΛζ():
    value = 267417
    text = __import__('base64').b64decode('d1kzWWFKRHFpa2J6R1QyS2UzU2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ГλΒЯιΝнэ():
    value = 385479
    text = __import__('base64').b64decode('S180MzYzVUVmX0xkanJCcUEwZHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙςοЬБβΟмφъЦъΖшЯ():
    value = 501339
    text = __import__('base64').b64decode('enF4QnFwUFhRdWVBbG1oYjE5SnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑπβдηжЯοсУИ():
    if len('') > 0:
        pass
    value = 195084
    text = __import__('base64').b64decode('Y3lreVhtbmRLd0d3NXhOdDdJVVU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        233
        _dead_3886 = 831
    return total

def _δΘгχЫτεΖ():
    if 95 * 65 < 0:
        _dead_4735 = 668
        _dead_8334 = 444
        pass
    value = 398871
    text = __import__('base64').b64decode('Q3ZjUjFicEh0RlBmcTdTVTB5WTg=').decode('utf-8')
    if len('') > 0:
        812
        273
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ΒКчΚσЖОфГврайрЙΩ():
    value = 565204
    text = __import__('base64').b64decode('ZHNpWDZYS292OThnN000eWhoZDY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6655 = 33
        pass
        pass
    return total

def _ΣкΗТωζьбΡΚγпЧ():
    value = 164532
    text = __import__('base64').b64decode('aktxU245MHhfdXpSUTdVeWFsQVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕжΧιχЙЩЪξΡωλФ():
    value = 209304
    if 18 * 30 < 0:
        pass
        _dead_9720 = 821
    text = __import__('base64').b64decode('SnFHdzZTRTlzUDVRVTJnNVc2d0w=').decode('utf-8')
    if 43 * 2 < 0:
        503
        _dead_3279 = 420
        833
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4029 = 958
        _dead_5283 = 553
    return total

def _ΗьδбБсζВσΚаΑЯ():
    value = 327215
    text = __import__('base64').b64decode('Y2tPcHg5V3gxWFdUUU1qTUVpYTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞαΩотЯШυΩяО():
    value = 59118
    text = __import__('base64').b64decode('cVI3SjFid2JwUjZMQlpFQVd3VU0=').decode('utf-8')
    if 77 * 91 < 0:
        pass
        pass
        _dead_6896 = 338
    total = value + len(text)
    return total

def _ЕмчΣЛЗψм():
    value = 160469
    text = __import__('base64').b64decode('WlptVDk4VndsbHRXSE1sRlg4bGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ξЭωΡНяМνкΨ():
    value = 736920
    text = __import__('base64').b64decode('ektKY0F4SnRjWnFXNDljR21aWTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖЯЩΑΘЗыВκδΝдтυф():
    value = 597830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwTtf0Ejy781Dx31zQK9OA4By30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_2645 = 245
        pass
    total = value + len(text)
    return total

def _ΨΛρУΒиинт():
    if len('') > 0:
        216
        _dead_4171 = 483
    value = 358952
    text = __import__('base64').b64decode('dklTM3N5TTAxOWNkdUhaQU1tNGU=').decode('utf-8')
    if 91 * 91 < 0:
        _dead_2304 = 59
        _dead_8172 = 639
        _dead_4607 = 183
    total = value + len(text)
    return total

def _ζРπчкнЬΤΒЕ():
    value = 824988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L33saUsg5v8ZLxaJn3upFyYkylc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖоΛΓяπыΘΚ():
    value = 171686
    text = __import__('base64').b64decode('ZDh2U0U5ZEFqQ1F6R2VJV0F1MEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΦФОΖΟΣΦΖΟоμЭωΤ():
    value = 689104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCPuSXIUqL9QFT+A0ASfP3Qo1Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭНСЯеТэЭΒЛНКЗК():
    value = 73404
    if len('') > 0:
        730
        396
    text = __import__('base64').b64decode('WTYxOG9VV2kycG9WenFxUXpMZ2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ςξеΩЪъюе():
    value = 18019
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnvwWXML148xPVmFw3yqBy4f8V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        pass
        814
        701
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 92 * 72 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()