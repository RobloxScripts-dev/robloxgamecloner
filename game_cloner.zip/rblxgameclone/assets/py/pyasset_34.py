#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _рЬУнВΨркШ():
    value = 895731
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3u0O0c/9ZAsMiCv4UyEbCQW63s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υНПътιηъХΞνцгЬ():
    value = 304688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kiy0fnoJ55k0GQmbkVSnPyMm9mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧиηΒЖΣτΣ():
    value = 534543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiOxZV4/yKBVGx2TxWyeBi0ftW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΧМНХбЪΖ():
    value = 437279
    text = __import__('base64').b64decode('YmphMGJ4X0pOZ24yMmc0ejlmVW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ρτΟνикНЬγшγЪож():
    value = 392062
    text = __import__('base64').b64decode('YWJOQWZleHhlRTBvZmd0UTJ4ckI=').decode('utf-8')
    total = value + len(text)
    return total

def _йσοюφЖΜφΕιЖ():
    if 68 * 7 < 0:
        _dead_7418 = 920
        pass
    value = 516620
    text = __import__('base64').b64decode('WlJHV0p1bVFTblBtQko4QmJqc08=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ηЦяαΧΕСВАЦЩэшΡДр():
    value = 472108
    text = __import__('base64').b64decode('ZDZISEUyRXRlYVA5Y2RBYkVZT2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΨΨФЕΗΕΛбмТρΑςщр():
    if 84 * 11 < 0:
        pass
    value = 584748
    text = __import__('base64').b64decode('aWpDWkdQWkVqQk43VE95VTdncmE=').decode('utf-8')
    if len('') > 0:
        _dead_3029 = 401
        _dead_2285 = 464
    total = value + len(text)
    return total

def _зΧГЕЩуΒЗФБнΡ():
    value = 903040
    text = __import__('base64').b64decode('ZGFERnhTVUx1WmxwQTBxRGtLOVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΦцпААΞΝ():
    value = 120665
    text = __import__('base64').b64decode('V0FKczlSVWt4MXlvdXY1aGFlTko=').decode('utf-8')
    total = value + len(text)
    return total

def _чихΤЬΤνΩθу():
    value = 20217
    text = __import__('base64').b64decode('dTNQemU3cW9VT25hYXk3SzJ5Qjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜЩЙйЦЫΑЮυΟБЙ():
    value = 261226
    text = __import__('base64').b64decode('a1YyRTdZS3RIVXFaSHJRbU5veDg=').decode('utf-8')
    if False and True:
        pass
        866
    total = value + len(text)
    return total

def _ДΙгιεςΩΣж():
    value = 296821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LD3sYnAG6bgHaFz6nle8DiAQ/Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8300 = 480
    return total

def _ПкСФнΒдυχΟэоПζЬ():
    value = 777559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByfQf3s22L0GAi2I4k6vNgwi3GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9285 = 401
        pass
    return total

def _κλΦιэрмцΨНауЯщ():
    value = 32552
    if False and True:
        _dead_7265 = 96
        500
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhD3WQg9/f4yD16Fw2C3Yjx70mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πψСΩекζοΨγт():
    value = 458214
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jg3mT0gy6J4aFSqu3liaZQ0N7l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηдтНыплΟУ():
    value = 196562
    if False and True:
        276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISX+QQYYqLoILwOn7A+kFxd/w28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 91 * 43 < 0:
        _dead_1385 = 205
        pass
    total = value + len(text)
    return total

def _δΒХСΔιβэΠ():
    value = 86455
    text = __import__('base64').b64decode('cHBFVkFDcmJDdGpKVnNxYTJKeEM=').decode('utf-8')
    if len('') > 0:
        905
        pass
    total = value + len(text)
    return total

def _νЪАτюГΚЖ():
    value = 217462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyD0O1Ya7qoJaR72+kOXC3wuyWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШцνΝΡΧнН():
    value = 124081
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQjKdAI0zroLCD+Rmn6IIgcf9Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УφОφΗεжъ():
    value = 379404
    text = __import__('base64').b64decode('SzVFWjhienVMb3FlemFDMnBrM3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΟцΤλхтоГТΒΝΥв():
    value = 124904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCDhX30u84IkDT2Bz2DFbD0F6zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭКрΜгΩΦΕщξςΓφ():
    value = 170831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwrXWlc6q7otLwGz62WCIh8Mxzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДАαъψзщшкМΕ():
    if 85 * 66 < 0:
        262
    value = 830893
    text = __import__('base64').b64decode('cUZrV0c3M2N3WG5kdGp2VTlkenA=').decode('utf-8')
    total = value + len(text)
    return total

def _оЗчζΒнНф():
    value = 244782
    if len('') > 0:
        pass
        936
        807
    text = __import__('base64').b64decode('T2dmcnhzUk83NllrRGhMS1l2T3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _этыдюЩЩΝюгйΘс():
    value = 518177
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXjud1QIp54kFCS58F2ELjB56Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥУφвφдξВжΓοЫвдчл():
    value = 660473
    text = __import__('base64').b64decode('V3FtZ0xNTkNyWXdDNHlEMllrb20=').decode('utf-8')
    if 22 * 66 < 0:
        0
        _dead_7511 = 438
    total = value + len(text)
    return total

def _ИρхЕВжΖчкαλЪшЩτπ():
    value = 667433
    if 35 * 22 < 0:
        pass
    text = __import__('base64').b64decode('a2JjdDY2dmtQaXczVmRJNGpHZTY=').decode('utf-8')
    if False and True:
        pass
        21
    total = value + len(text)
    return total

def _ΧψςπнПЗДωРЮРΡΒ():
    if False and True:
        _dead_9253 = 118
    value = 452987
    text = __import__('base64').b64decode('ZXB3UWR0ZW9pMzlxNWVQSjJUVDE=').decode('utf-8')
    total = value + len(text)
    return total

def _оьλνςθΠФνа():
    value = 578153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSvvPWMGyZwnbhyazk6/Zxckxzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛкпγЩДлуΓЪаπИζ():
    value = 42816
    text = __import__('base64').b64decode('UjVodEFnUWZPTnVkRTZaak9ieWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚСЕЙεсΝΗχтЦ():
    value = 789358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQvjOlko6I8JAB6oyVy8YzYc8z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νγФΜйχψιдкΛЪэαΔ():
    value = 428795
    text = __import__('base64').b64decode('VXM1aE14djFkS2s4bTVNT0JpZUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΡθГдцЛΘяεнΕА():
    value = 4708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3m2XEU7yfsiLh+7ylrCAhIVz1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤυτпΝΙСΖц():
    value = 401553
    text = __import__('base64').b64decode('aldidE9KbzlfcXJUZ2FwaF9ieGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΠσЦΚЕωхΟьλЛБργΓ():
    value = 660890
    text = __import__('base64').b64decode('dEd5Y2hGbU9iUVNyY0JPbFhodTc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        9
        _dead_8071 = 705
        _dead_3796 = 571
    return total

def _уΓвΡаПрИл():
    value = 596169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjbdTQcp7KUCKCqSkGGEGwkq9Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιΥΤдΛΑЕъНβвΚαфТИ():
    value = 462792
    if False and True:
        _dead_6241 = 656
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRjWOUUox542FyDy0QK0ZnAf9X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 100 < 0:
        pass
        _dead_2668 = 297
        460
    total = value + len(text)
    return total

def _СЩвэπΨеΙрЛΟ():
    value = 739191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxrwbQkj8ZABD16q8Vy+HDcLvHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        770
    total = value + len(text)
    if len('') > 0:
        _dead_7052 = 185
    return total

def _ΩЖпйуЛэИЗΙΖ():
    value = 273788
    if 53 * 49 < 0:
        _dead_5650 = 654
        743
    text = __import__('base64').b64decode('YU1ndUJvaEJkMFZiRElhcGY2TzA=').decode('utf-8')
    total = value + len(text)
    return total

def _РШΩвρΠΘγνΟΚγВФкη():
    value = 556985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX/JT3YO/405Aze0yl+eFgcY4V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βιχУΥΡθηмЭГΜЗД():
    value = 497464
    if 81 * 1 < 0:
        pass
        _dead_7782 = 694
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh/uSUYMqrhRGQKqwASfPDM8/XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДЧИЯΔЦМЩνсЖыВЛощ():
    value = 471656
    text = __import__('base64').b64decode('b19wVUV1SmFtZUFnUE45Z0dTa1U=').decode('utf-8')
    total = value + len(text)
    return total

def _сνΨУβΖиыр():
    if len('') > 0:
        _dead_6821 = 155
    value = 493279
    if len('') > 0:
        _dead_8293 = 670
        79
        136
    text = __import__('base64').b64decode('ZldjSHcyNXF3eXVOa3hScHFSVE8=').decode('utf-8')
    if len('') > 0:
        _dead_6821 = 759
        183
    total = value + len(text)
    if False and True:
        _dead_3854 = 399
        _dead_1152 = 930
    return total

def _ΠχМΦфНьуΝы():
    if 18 * 4 < 0:
        _dead_6513 = 632
    value = 151221
    if len('') > 0:
        _dead_4238 = 15
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH/dOntq0o8gPC6V4WLJHDIe/kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΨяОоЪτЧькШΝэ():
    value = 438954
    text = __import__('base64').b64decode('b2MzcW9MZGM2WU52aVV5dHlrZVE=').decode('utf-8')
    if len('') > 0:
        104
    total = value + len(text)
    return total

def _ЮЦξΖйΡтжТшοιк():
    value = 380489
    if False and True:
        622
        850
        348
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTnNdgY7+LkVLT6mmgGhZgx28Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4783 = 468
        _dead_9946 = 670
        595
    return total

def _оЫВяΩζωзπυЪОЧΨэΓ():
    value = 467051
    text = __import__('base64').b64decode('djJ6RV9yYnJKOVNWalB5VWYxdUo=').decode('utf-8')
    total = value + len(text)
    return total

def _сΘЙψФδπДΠζιмΒΘыс():
    if len('') > 0:
        _dead_9198 = 430
        pass
    value = 211817
    if len('') > 0:
        _dead_5216 = 969
    text = __import__('base64').b64decode('TTBQZjA2YW9ZRjFzV2lXSlhlMkU=').decode('utf-8')
    total = value + len(text)
    return total

def _УγΚЬмХцТвκЮ():
    value = 710541
    text = __import__('base64').b64decode('Z0p2Y05iS2E5QWFwTE1rbjZTaWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩνζπаΖцЧБвыФцΗ():
    value = 744531
    if len('') > 0:
        _dead_9049 = 90
        95
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A33+fwY+wZ5TAD/w2FqjZj96434='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οωЪΜгΝДцтΜΜе():
    value = 861384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCPMbW4Xpo06PjuQ61enNjY61lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΩωсГНуЬоκ():
    value = 970230
    if len('') > 0:
        177
    text = __import__('base64').b64decode('eTRWM1VnZlUzVDFTdTZveGdNano=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΠΦΙρШЕλΔβД():
    if len('') > 0:
        _dead_3892 = 362
        pass
    value = 456267
    if 75 * 51 < 0:
        pass
        875
        _dead_4859 = 886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSn8aG4r0P8bDh6tmlfFbC4+22c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8326 = 854
        _dead_1331 = 842
        498
    total = value + len(text)
    return total

def _νмъЧωΒΙΖиςΠВй():
    value = 80035
    text = __import__('base64').b64decode('REFIUUxRY0xEVnFXYUtxVnJrbm8=').decode('utf-8')
    total = value + len(text)
    return total

def _сЫΝγРНВΥΝвΗαМеЖ():
    value = 829334
    text = __import__('base64').b64decode('UmREWTRiZVMzdlNtWDcydHY4bGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦσжЪЗОДηРФЮΔК():
    value = 338274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQHCTHMjx7sGDgKnxF28Jyl+5UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8180 = 17
    total = value + len(text)
    return total

def _λХΦΨμНΩν():
    value = 873955
    if 4 * 15 < 0:
        _dead_3361 = 901
        pass
        _dead_2079 = 888
    text = __import__('base64').b64decode('WVNfc19vTk5PVlRlV3pIZHhGTjY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2403 = 916
    return total

def _ьΘλπмчμЙь():
    value = 370509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kwf2VgkoprIUCxWa21e2OyIKsmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒτΕьΝГΜΤВТ():
    if False and True:
        796
        _dead_7523 = 590
    value = 946548
    if False and True:
        _dead_2851 = 553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyTqdlIw270KageO0H+/YiIK3kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()