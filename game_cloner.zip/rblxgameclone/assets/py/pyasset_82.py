#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΡΗυСЛζψшξλΝηиκ():
    value = 401232
    if len('') > 0:
        pass
        _dead_7597 = 666
    text = __import__('base64').b64decode('ZlpQQWwwbTcwc2Z5bGZ3a0NTOUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑΨΖиыΜСυ():
    value = 934400
    text = __import__('base64').b64decode('YTgzck4wZUVEMGtudktvejZsQ20=').decode('utf-8')
    total = value + len(text)
    return total

def _ιмΗσШтΣσеΙτεζфиц():
    value = 481287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Anv9a11p37IqMiySkVWXZgoEzGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪγПОожВчро():
    if 43 * 80 < 0:
        763
        _dead_6656 = 860
        _dead_8200 = 539
    value = 865691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgHxWlQc/7IgGQyp/VG9IBd+0nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΞэΓЛЭΛδβΚэх():
    value = 535516
    text = __import__('base64').b64decode('VVpaQlRMV3dRNWI3OThUeTBJT3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ТМΛвКζюΣКоЖφыπмн():
    value = 976147
    text = __import__('base64').b64decode('VU1fRUVOeExTTXFxRU9DcUVPVmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞолθΑΞωЕфСНψкЛβ():
    value = 88676
    text = __import__('base64').b64decode('dXNZUTJWZEx6Vk9fRnNrWWZqVlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _уАΔчωЛИчЙщк():
    value = 183848
    text = __import__('base64').b64decode('ZEhwdzRyYzlWbHJXN203RDRJVFI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        125
    return total

def _УΛξΑΓйζнπΤΗπаλФ():
    value = 573186
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw6wVH8K8KQaAjbz8H2cbCsQsmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κЖПποΥШНΧψн():
    value = 339503
    if False and True:
        _dead_4601 = 955
    text = __import__('base64').b64decode('WDZKMlltSFZITlYzOEtBSDhYc3Y=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_6868 = 64
    total = value + len(text)
    return total

def _СδрΡχΕчКЛзЦΔζκ():
    value = 305540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA7pfmZpzKwTKymm0UXBNz0g3Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аУлχЖрГж():
    value = 781324
    text = __import__('base64').b64decode('cGlIOWRYNnpVemhZR0toWlJfSko=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗνρЦΟМθвτδсбжШ():
    value = 10432
    text = __import__('base64').b64decode('SVBYWVg3S25LNkphT2xPdWRHd3g=').decode('utf-8')
    total = value + len(text)
    return total

def _щЦЫΟΖΟвΞλΩюγпкΠΩ():
    value = 720326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQaxbFUO+KAAHRyy7WG+DhM54kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωυхτζюкΕ():
    value = 47672
    text = __import__('base64').b64decode('SUJWNVl3YzNLT3NXbEY2eHFHMHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩЙжшΞΨшсθ():
    if 41 * 91 < 0:
        664
        _dead_8254 = 418
        965
    value = 923702
    if False and True:
        834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRDXPkFhyo0GIByrwWyHLCQtt1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эбтшαиьуκЪνьςсνШ():
    value = 387645
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQC1XEtu2f9TNjyG+WSZEjEXtGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΞνаφπеΣΧΧβΛуΓ():
    if 6 * 91 < 0:
        440
    value = 164525
    text = __import__('base64').b64decode('QUpuMXBHZEtNTXJMMVRyVVdzRE0=').decode('utf-8')
    if False and True:
        523
        _dead_4015 = 137
    total = value + len(text)
    if 62 * 65 < 0:
        _dead_2682 = 810
    return total

def _ЪχεΝΕΒςжо():
    value = 137449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzfPUW5v3Z8PGCammgO7GCcV1EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 33 < 0:
        _dead_7263 = 386
        pass
        601
    total = value + len(text)
    if 24 * 57 < 0:
        606
        930
        722
    return total

def _νΖгфхЩΝΥβιΥ():
    value = 773825
    text = __import__('base64').b64decode('S1luVVNINXhpTHlnZDkxRTBFRUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓгΟВΑΨбρЪΝ():
    value = 664031
    text = __import__('base64').b64decode('djljMUtnNkJMWWx4MTVfcmEwcVY=').decode('utf-8')
    total = value + len(text)
    return total

def _йνЖНсΨΗφЛ():
    value = 440605
    text = __import__('base64').b64decode('ZVZ5a0E5emV1S0g5MzdfaVBWX0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _шλΞχςЖвΛ():
    value = 607848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBvwQUZszJoZPSGcmGOVIzIY9mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υКИΑιэσΒωгйΕωж():
    if 17 * 35 < 0:
        437
        _dead_9692 = 214
        _dead_4648 = 703
    value = 822395
    text = __import__('base64').b64decode('ZEFCblBZWDI4c2pkYk5Nd0haazY=').decode('utf-8')
    if False and True:
        _dead_9527 = 801
        pass
        pass
    total = value + len(text)
    return total

def _оофψОΓпчхψΩΘ():
    value = 82857
    if 81 * 7 < 0:
        542
        82
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LC7JV0s704AGF1a6+FCXHBAm42k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΩБъВЮОцпь():
    value = 978961
    if False and True:
        _dead_2826 = 820
    text = __import__('base64').b64decode('RGRjaG1LM0FpQWJtZHJhYk90M0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤгπЖОΑΟηΗπΦсοε():
    value = 87588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3jMUXgpz5tQOV2knkbCLR8ptmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        547
    total = value + len(text)
    return total

def _βрΥйзΒшΕтя():
    value = 570909
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB/ObHUMrJgSNDei+3u6EAwVz0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щШХφЕρЗοШа():
    value = 46502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRDyRVAs+JAxOST77F/HESEbyXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КβΒмΜшУэЙαмрЩЙШυ():
    value = 262205
    if False and True:
        _dead_4508 = 135
        pass
        _dead_3567 = 360
    text = __import__('base64').b64decode('blpaSTU3MDlfZmxqUlJ3UHdoM20=').decode('utf-8')
    if 57 * 33 < 0:
        459
    total = value + len(text)
    if False and True:
        pass
        945
    return total

def _ЛжΞдΓМзуиКнρχЗЗв():
    value = 835627
    text = __import__('base64').b64decode('STdUY2FmcTNzb2w2RFNXSHRiMDc=').decode('utf-8')
    if False and True:
        _dead_9659 = 721
        _dead_1864 = 335
    total = value + len(text)
    return total

def _ЧИσрΛψлΝЙрζΓου():
    value = 886300
    text = __import__('base64').b64decode('eDJpNzFyVHkzWGtqQ1hBSTVWNDI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8469 = 110
        _dead_1350 = 229
    return total

def _ПΜШйΔΨηфβЩβΚΩΘХп():
    value = 844589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwXvW1098I4mIjv25nqJBS46yHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИПтиεЕщζдσΝζ():
    value = 152973
    text = __import__('base64').b64decode('ZVRJX2NzdVA4N3dqV3RqU1BvNEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒзΡςдьαΨΞβиΒэνΦΑ():
    if len('') > 0:
        _dead_9652 = 976
        pass
        _dead_6857 = 579
    value = 587520
    text = __import__('base64').b64decode('R0ZZajEydU9pb0hnelJiZ1hIWnM=').decode('utf-8')
    if 55 * 91 < 0:
        393
        892
        _dead_9415 = 184
    total = value + len(text)
    return total

def _чТЭМчВВДХβςΗа():
    value = 154929
    if 98 * 5 < 0:
        pass
        pass
        912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwvWTUIcz7EWHgGF0F+EHRM7tk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8523 = 515
        145
        _dead_2311 = 554
    total = value + len(text)
    return total

def _ЫχэятяπьЖς():
    value = 114227
    text = __import__('base64').b64decode('U0ptaTh5cFN5dE8wMXQzNktmZTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞКьσаНθЛ():
    value = 24025
    text = __import__('base64').b64decode('eHV5aDBWamdVMktPXzREeTlpSzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ζУТЗγшиЬбМюΤФ():
    value = 804100
    text = __import__('base64').b64decode('UHo1MEtGSjhmUDBWck5XTDduWHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ρгЪПχИΨюШчЧςхаю():
    value = 199543
    if len('') > 0:
        _dead_2063 = 726
        67
    text = __import__('base64').b64decode('ZTRGc0dpTFF4dkpJdVlLcGt6UVg=').decode('utf-8')
    if False and True:
        790
        _dead_5133 = 837
        pass
    total = value + len(text)
    return total

def _ΓνСфΧРΧПъΤЕδУΩζ():
    value = 674847
    text = __import__('base64').b64decode('YTRNSVhBX0dtbHJKenRDVlBHTE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ψуъСοЩДъж():
    value = 912867
    text = __import__('base64').b64decode('SEJVN0V1RUZLdFVXOWJud1pzR1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΣдяνЯΕΟлΩЮ():
    value = 237486
    if len('') > 0:
        _dead_2584 = 162
    text = __import__('base64').b64decode('WExRek1MSFl0Tm5ZU1BweFN4RmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦλЯεоΒΡΩσзЭΚοΧ():
    if len('') > 0:
        pass
        996
        pass
    value = 220361
    text = __import__('base64').b64decode('dklmd29PN0d5dk4zOEliRlVRc28=').decode('utf-8')
    total = value + len(text)
    return total

def _пΚОрърРтюΕЛΟζχ():
    value = 360255
    text = __import__('base64').b64decode('eDdsMFFWTFhuY2xjMm4xWWhiMTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗРФСΠμыτцΣΣИν():
    value = 184883
    text = __import__('base64').b64decode('VkZsSF9FSTRmeXJXVDdZZTdJbHA=').decode('utf-8')
    total = value + len(text)
    if 15 * 16 < 0:
        144
        721
    return total

def _ιАаαлГЙΦΨΓΡн():
    value = 629493
    if 53 * 44 < 0:
        192
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiHmX2Y016cEHR2E8UXFAhAl42Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2480 = 423
        924
    return total

def _ясςОΝрХε():
    if False and True:
        pass
    value = 533731
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCXMe1UB5LoVax203k/JPzw+6js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩεХгΨГЙετπΥΕЩЖх():
    value = 940265
    text = __import__('base64').b64decode('R05ON283NzZHM3JFc2hNdUxONzM=').decode('utf-8')
    total = value + len(text)
    return total

def _хλШЬΡбφбКΚъяρСпσ():
    value = 434955
    text = __import__('base64').b64decode('R3c2cjJPcHFGZFhIcUlvSVhyRmk=').decode('utf-8')
    if len('') > 0:
        _dead_2688 = 807
        pass
        106
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7722 = 160
        pass
    return total

def _ЧναΑЛъУΑΟцЯеΖИЧ():
    value = 264639
    text = __import__('base64').b64decode('eFp2TTJVeWVoZzU2X1NDazBzeUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒяολτеωгшЬχ():
    value = 795878
    text = __import__('base64').b64decode('b2tQUEVJMVRoN2tuTWlUNHlqbWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨφυХБλΞБσψλРБ():
    if False and True:
        215
        _dead_9656 = 910
        349
    value = 209267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBbnYAcAzLoGMTuO92eSEzZ382Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _оЩξΤдОЬмюысΧБΞΙ():
    value = 544311
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C33JQ2VgyKAkHQ6i3UOaCxp6xTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_3050 = 550
        10
    return total

def _пнχιιвΗЗ():
    value = 488235
    text = __import__('base64').b64decode('d25uX1I5VkNTWDNMc3QxWkVnZ2g=').decode('utf-8')
    total = value + len(text)
    return total

def _уΨЫμкτΞпЪδвΡΓУс():
    value = 238893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRDlXX0p3IInFz6J7leFYQcO8VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЮΦДφЪГδсΡыκσλ():
    value = 245449
    if len('') > 0:
        _dead_7977 = 527
    text = __import__('base64').b64decode('Tkd3WUxXRU95Z0JkUERLUmpqakI=').decode('utf-8')
    if 73 * 96 < 0:
        pass
        _dead_7097 = 737
        pass
    total = value + len(text)
    return total

def _йςΧΑΤιЩФх():
    value = 81301
    text = __import__('base64').b64decode('aG9USDhSN1lQSDRSSFVpSkViUXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤчЩМсζΔπηСΩΡνьχδ():
    value = 526558
    text = __import__('base64').b64decode('ZlJWVmxDUlB1RlY0OGlXZkk0Q1o=').decode('utf-8')
    if len('') > 0:
        181
        _dead_4645 = 297
        149
    total = value + len(text)
    if 57 * 21 < 0:
        743
        pass
        _dead_4582 = 594
    return total

def _ЛуЙηауЧΞЧγΡЧλй():
    value = 768119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjjoP38D37EEAyu7xw6GAz9+wEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 49 < 0:
        pass
    return total

def _ψΖμгнкρΡαπхνζ():
    value = 790619
    if 54 * 99 < 0:
        pass
    text = __import__('base64').b64decode('SXppQ3drZmd5ZlhUaTNBc1c5Sno=').decode('utf-8')
    if 6 * 16 < 0:
        _dead_9142 = 863
        383
        958
    total = value + len(text)
    return total

def _ΦΩΒкрЕШΙиΥЗгγрнε():
    if False and True:
        pass
    value = 933511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwHRQX8VrL4MHSmvxEOFZhV7tUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еЯΩтьынучзИИи():
    value = 403434
    if len('') > 0:
        885
        pass
        pass
    text = __import__('base64').b64decode('ZDdCWEhrak9YbzJDZExvaHg4eWk=').decode('utf-8')
    if len('') > 0:
        _dead_3995 = 809
        _dead_2267 = 86
        639
    total = value + len(text)
    return total

def _τΩЙЕжТмσи():
    value = 7770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCLNb2E1249aIFeWnnqDZxMkxVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        171
        _dead_6937 = 740
        376
    return total

def _УψйθΟηθлХαΓэшьх():
    value = 173300
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lw7MfnMxxPw7DSKyzAPELgk+ykI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΛκтρХдΣс():
    value = 619495
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('RlJSejE5TjF2S1B6b2cwMTJsb2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟНμιΣγαεМЖбЕвΑ():
    value = 400930
    if len('') > 0:
        952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pz7URkgh1qoOGSSMwAWgPB8X1zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 71 * 74 < 0:
        501
    return total

def _ΒтХΜеβЙпζщДхЖ():
    if 19 * 99 < 0:
        567
        pass
    value = 905322
    text = __import__('base64').b64decode('anMyRXNpVmR0STNtZTRYcjJmME8=').decode('utf-8')
    total = value + len(text)
    return total

def _νΦИιяβΖρδЬςкчΕТ():
    value = 907192
    text = __import__('base64').b64decode('QUVwSkJVVmtoUnB0ZmoyS1ljU2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕπικοыγδωяΖΗШ():
    if len('') > 0:
        _dead_1731 = 988
    value = 805335
    text = __import__('base64').b64decode('VHJXNDk3MzJMclVXbnlzTkwxR1Y=').decode('utf-8')
    total = value + len(text)
    if 13 * 76 < 0:
        _dead_8652 = 575
    return total

def _ХξаυνπνΡ():
    value = 601975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj7pNlcL7IdRIiL2ynWaHgEn00A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йθΨιиοεε():
    value = 492440
    text = __import__('base64').b64decode('VzJnVlVLejA3ZG1YaUl3UmFZTmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚХιЙзЩзНЫЛΔИоф():
    value = 699562
    if 52 * 31 < 0:
        _dead_9553 = 360
        _dead_3157 = 521
    text = __import__('base64').b64decode('UUU5WGY0cFhJRnpHblpwNGk2bEE=').decode('utf-8')
    if 88 * 77 < 0:
        pass
        _dead_6316 = 948
    total = value + len(text)
    if len('') > 0:
        _dead_1604 = 860
        pass
    return total

def _ψΣщχбРЭУОэΟ():
    value = 399213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3f9bVYM3L8HFxe130OZGHIt40s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΥщЪμзΟЦВшш():
    value = 481762
    text = __import__('base64').b64decode('ZHl2YUh1YUR5MlRsNHB3VXRXc3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ςξπΓжΞЩςωΩсдΖхС():
    value = 745634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESS2NgY39owoayGwy32VASMo51Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΒвμяαφИПΠβхтΜΙγ():
    value = 939053
    text = __import__('base64').b64decode('Y0JDUmNyQUFJOU1RbTJXZjR3ZHE=').decode('utf-8')
    if 95 * 44 < 0:
        pass
        pass
        983
    total = value + len(text)
    return total

def _ΠΚКεХшгРΧΜυΞΚГΑ():
    if 4 * 45 < 0:
        pass
        _dead_8389 = 383
    value = 872065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyHhWWFrzPwyHx6s+mCpEzYC41Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝιΝШКφТΤξ():
    value = 272633
    text = __import__('base64').b64decode('TEJ0OFhjWnJVQVQzOUhQZVU3NmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΩηЩψινΔ():
    value = 242816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRjoZGgqxpoTFBqAmmenIxF7428='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РзγбСΔЫτΘ():
    value = 224742
    text = __import__('base64').b64decode('c0pHV3VOUTN4aExEMGRudWRtZjA=').decode('utf-8')
    if 81 * 6 < 0:
        pass
    total = value + len(text)
    return total

def _ГйшЙиΛТЬУсΘ():
    value = 488046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyWxPl49+fACLSv0/2aKPi4X828='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 99 * 57 < 0:
        pass
    return total

def _лПΥΛЬοБьЗ():
    value = 298580
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzrdS3M+66sEFCaR5kOGGhw58UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мсΩЛΡрЬΖвΓ():
    value = 310723
    text = __import__('base64').b64decode('Z21TakJlbERmaFhzZ3FoRUVNSGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΦΩλДεΕΠзОΤаΟИΣ():
    value = 56993
    text = __import__('base64').b64decode('aWZjdThQWU1pYllEMGFOdXp6X28=').decode('utf-8')
    total = value + len(text)
    return total

def _чЛΞфлмИζкйΡа():
    value = 641872
    if len('') > 0:
        _dead_3649 = 29
        _dead_4539 = 410
        pass
    text = __import__('base64').b64decode('YUpJcXJBS1VfMFlBRmk2UjVlYjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΔЮУΝШωΣмπТΝяд():
    value = 543410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBzwSkMy8PgHDSaPmHmVOTwFxlc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚλМΛΔΤЙβ():
    value = 974278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3zOQEssz75aLRao5FSEBTEH/lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яЕсэνОΛΥΕяТοАΟс():
    value = 701960
    text = __import__('base64').b64decode('c1FvYUVXQ2l2MWdnelU2RVpFb1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΨΣэчΛГζ():
    value = 604882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LS2zX2MO1IdWGFaS2gOCP318538='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΞТЭьШЛхΘъθСьα():
    value = 469007
    text = __import__('base64').b64decode('RXV2RlZnMjM5WjREZ3BxdW5yd1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ШюσОТВЖЙνИυС():
    value = 418551
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CA3dSEQ9x/AkCxW06ma1Fh0WvGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οтΔтΚωΑГЪьψ():
    value = 532277
    text = __import__('base64').b64decode('Wkw2MDRhb1hKcTl5ZHJ5dWtfV1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚиψβМЗΡεр():
    value = 898484
    text = __import__('base64').b64decode('ZEp1NHZwUUlYTVRma1JTdXFyZDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜБΘσΣпОΛЦнП():
    value = 788553
    text = __import__('base64').b64decode('ZUZHRkpSWnJTakpieWNVeFcxZ1I=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_2764 = 815
        _dead_3605 = 492
    total = value + len(text)
    if False and True:
        _dead_8766 = 486
    return total

def _рβрзЦШΦΤΦηωЗσо():
    value = 947489
    text = __import__('base64').b64decode('dU94bDR5ZXlmaFFnUm9jZzhYdmY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _жΙуγΞτυл():
    value = 91615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwfiYVUh6LkUKj2VzmKjHwYntl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψσΨБХιГдСНΗτεΦ():
    if False and True:
        pass
        pass
    value = 26029
    text = __import__('base64').b64decode('V3pmSU9XQjZ2cDExdUY4RWRBaW0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6679 = 73
    return total

def _κγфэυςцЫжжζψ():
    value = 550126
    text = __import__('base64').b64decode('aldDNWNwbXVGcnBiNXpXcHRCT28=').decode('utf-8')
    total = value + len(text)
    return total

def _ιчΚщνЦаЖΡΩчРΖυ():
    value = 521013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzrlXnsB7JBaEQWl+XPAOw990EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΠрЙΡЛιθмаЩ():
    value = 635007
    text = __import__('base64').b64decode('bGFENVFVQncyTTd4VFhINjJqQm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ηлηмьΔθΝЖ():
    value = 514681
    text = __import__('base64').b64decode('VzU4aENZWm9kYnBPWmZtd2NudGo=').decode('utf-8')
    total = value + len(text)
    return total

def _зΠμδΩэΤКоЫи():
    value = 920682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHvIW3YM+Ic1BQDwznuoEhYV1F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 38 * 6 < 0:
        _dead_3719 = 631
        _dead_4864 = 381
    return total

def _ωЪЯξтиαΕНνа():
    value = 680457
    if len('') > 0:
        _dead_7677 = 663
        _dead_6302 = 229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzzHYlQyx4QUKimB+UDALgAI6DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_6314 = 929
    return total

def _ХДыгЛхшАюηэЦзЧ():
    if 28 * 89 < 0:
        pass
        64
    value = 103663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX63Yno4/L8GPjCg43uSBx996Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2560 = 307
        501
    total = value + len(text)
    return total

def _БдЕцςжЛΟл():
    value = 462717
    if 91 * 12 < 0:
        _dead_1400 = 334
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBfNSwUA0bE6P1iQw1iKJxAftHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        174
        225
    total = value + len(text)
    return total

def _ςъдΣОμПиενфшсмщ():
    value = 911151
    if False and True:
        887
        _dead_4901 = 807
        _dead_8892 = 805
    text = __import__('base64').b64decode('aTlXYlNXMWQxSlZ3c2s5UmJUNk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘψХшмХхΟЙ():
    if len('') > 0:
        _dead_8665 = 327
    value = 305861
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw7RUVQd3a07GxaM7Q+IZA0stEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 6 * 32 < 0:
        185
        70
    return total

def _θвΒΙуΩкмδйцыπпе():
    value = 730409
    text = __import__('base64').b64decode('Z0U2andIc3pLZUZIaHU0RDJ2RWw=').decode('utf-8')
    total = value + len(text)
    return total

def _οнюΘьлщу():
    value = 271458
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT/jalkbzq8UbBb68kGiERcV7F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 95 < 0:
        829
        pass
    total = value + len(text)
    return total

def _яφδнπξφЕΣρξр():
    value = 95033
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCz3Zn4T7pI1Cl/wmAWUGyl2vX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γчжМуγΗБ():
    value = 784362
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax20enUe9YUgMwWA93nAAn093jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΝЯχряоЮδфрФГл():
    if 91 * 69 < 0:
        pass
    value = 887532
    text = __import__('base64').b64decode('SmE2cWlXNUJQVkltdlFvS2lQRFo=').decode('utf-8')
    total = value + len(text)
    return total

def _хОθшФρЧхоΘ():
    value = 142051
    if False and True:
        pass
        95
        pass
    text = __import__('base64').b64decode('Q2pyT3Z3VHR3ZnA1dUlwenJaaFM=').decode('utf-8')
    total = value + len(text)
    return total

def _кζΥΘμЩβГΘ():
    value = 942692
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lha3eX4e+rsoHQCa92aIYjUCzU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УεТθюВλοЦЪйа():
    value = 483271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDX9ZF4X/K5SFln0xFyRHjZ49T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΡцыИΠъξтГШВчИШ():
    value = 648846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jx7xfHJv1q4nLxy2x1OyBhV8w3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦдАИТΤХе():
    if len('') > 0:
        493
        pass
        pass
    value = 162049
    if 86 * 89 < 0:
        129
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ei21THAG+7opIjy1x2OyEHEW71w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШωδКАМЖы():
    value = 537943
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('TG03TDROblhBQWJtYk1oNjR1RGs=').decode('utf-8')
    total = value + len(text)
    return total

def _зκРбχςХΔьАф():
    if len('') > 0:
        pass
    value = 316658
    if 77 * 1 < 0:
        _dead_2735 = 652
        824
        _dead_6016 = 431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzXCOAEb9ZAAAFiJzVycIiIF6Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЯБΧСΚβΤΥЙчυΦМЛ():
    value = 155640
    text = __import__('base64').b64decode('YjFjbHlac05EMVdfQVQ4elJYal8=').decode('utf-8')
    total = value + len(text)
    return total

def _ИТВгΦХςΙδшмι():
    if 21 * 20 < 0:
        727
        776
    value = 444457
    text = __import__('base64').b64decode('UHNOemQ4ckJROHV3bktNNW5sQU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ψτщΑΩОΦзιΔψГχ():
    if 91 * 78 < 0:
        _dead_8040 = 247
        658
    value = 708373
    if False and True:
        752
        _dead_9159 = 741
        _dead_5335 = 427
    text = __import__('base64').b64decode('YmVTemQxNzI2T3IyWXNKejBJNEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЧэΑкчГцΘЖтΥГ():
    value = 915407
    text = __import__('base64').b64decode('dk5DaG93VlhGekpmZXVlakFyTVo=').decode('utf-8')
    total = value + len(text)
    return total

def _μψΚωТцΑуΤΟρμιΛ():
    value = 765822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mnq8Q3YM1JcCPSmszg61B30K5k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υчυΖоЭджэзфΜе():
    value = 271155
    text = __import__('base64').b64decode('aEp6UUVhUXJzWHVjYXp0Z0I2Qkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧцπТШЩΕЮМБщΙ():
    value = 345190
    text = __import__('base64').b64decode('SnJYSkoxVURVVTVzRGR6WTZWN1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΩλθШтЛαВ():
    value = 907822
    text = __import__('base64').b64decode('d1lxQmw4bWh0bFI0TWxyQlFkZ3o=').decode('utf-8')
    total = value + len(text)
    return total

def _τΡЙгиФуθшΔΛЦяΘ():
    value = 278860
    text = __import__('base64').b64decode('RWVnV2gxMVQzajhTY2xhUmg0ajk=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΠЧοЖνЦзЗΞдυαфМ():
    value = 7168
    if 32 * 57 < 0:
        pass
        _dead_3586 = 259
        _dead_3345 = 595
    text = __import__('base64').b64decode('bnZmUzF4THpJRWxEQm44WDZDYWc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_5654 = 988
        _dead_1718 = 81
    return total

def _кЙЩЮоБыЖКкЧпΨфР():
    value = 464871
    if 52 * 8 < 0:
        _dead_2458 = 62
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXvOOEQRqaFbMinxxUe6PTIb8TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΑνобНшш():
    value = 861873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBziY0cur/o3aQW6wXuFESIVznc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бЯЯйикηяЪЮΠгλсЫι():
    if len('') > 0:
        _dead_7890 = 62
        _dead_4050 = 533
    value = 180791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTf9PkYY65cxDAyH0WaCNyF27Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6129 = 511
        582
        212
    total = value + len(text)
    return total

def _ΠσйгиΒУзΠΘЧхν():
    if len('') > 0:
        273
        _dead_8557 = 414
    value = 101448
    if len('') > 0:
        pass
        480
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERbAR3YK94okblyCz2WkAxc+t34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОдКЮΝпуρЭБχσ():
    value = 191338
    text = __import__('base64').b64decode('YkxZX1RXbVp4QnU4YmNoRmxGYWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛπθКυνЭяЖдχЬДя():
    value = 830254
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBzFZn0yprlbbRer+QK5PnEftlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΗШγδΒΝжаиΑГσ():
    value = 142339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzywfnwS8fwkNyvx+HLDPxM8tFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БГΨЛжУыбΡΜьл():
    value = 671287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EALDfksW+ZpRPTWS0H+3ERR91Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΙρΜλяςυСξсФИ():
    value = 997693
    text = __import__('base64').b64decode('TW5PRjU1UVkxR2RpNXBkbW5jMVU=').decode('utf-8')
    total = value + len(text)
    return total

def _πΡΚΑШЩρφДψм():
    value = 139858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh3pVmk/0YQMHB6Q7wCcDA8u4mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΗахыεΓъΔЪэФ():
    value = 57543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fn/KUXZrr48WbwO34QCRDjE3sUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κОщΗэБЭЕоюι():
    if len('') > 0:
        _dead_7226 = 719
        _dead_8487 = 741
        _dead_8656 = 592
    value = 239564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB3oR3gN5L8TPQqy3mS+ORwD7jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9199 = 914
        395
        _dead_9281 = 223
    total = value + len(text)
    return total

def _иаΑЖθΛсчЭ():
    value = 236068
    text = __import__('base64').b64decode('Q1VYM2pzQ0lOblpUalphb0pONFk=').decode('utf-8')
    total = value + len(text)
    return total

def _чσЧΥьΟПΜλт():
    value = 298708
    if 95 * 84 < 0:
        _dead_4677 = 952
    text = __import__('base64').b64decode('Tkg3eDZac2llVWRfTDUzUnBOblM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        19
    return total

def _ЦΘтΖцяΜκЕЙ():
    value = 272155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InjNOl1ur5AGMj6C0mmROwwsxWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡφψψΤВзφе():
    value = 81565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mjz8aEUw8qJXFjWs7EDIPAAl9mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΕхТΞшщЗ():
    if 54 * 41 < 0:
        _dead_8676 = 7
        463
        671
    value = 780896
    if 58 * 91 < 0:
        pass
        _dead_9882 = 791
    text = __import__('base64').b64decode('QnFhNnBOOWY5Ml9MTTlKd0EwMzY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6626 = 827
        _dead_3090 = 957
        _dead_3917 = 767
    return total

def _σψβςΠЛТЧβ():
    value = 251157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnfAaXM9+P1RGAChzAOmNjAWyXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒηπБъλЫАЗ():
    value = 701544
    text = __import__('base64').b64decode('SXM0MUk2R1l1a0JVZWdzMGQzUDA=').decode('utf-8')
    total = value + len(text)
    return total

def _КОрΑФλйЗιЪпрΑΧ():
    value = 270525
    if len('') > 0:
        _dead_2499 = 637
        pass
        _dead_3907 = 404
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mi7xQEkSq483IDir4mGFECN6wlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кψΠΖЖΩьξυ():
    value = 746074
    if len('') > 0:
        24
        118
        252
    text = __import__('base64').b64decode('a3VRdGg1TWt6ZmJTbnp3Tkpaa2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬλТпэбΖуεЖΑΙΣβΦ():
    if False and True:
        pass
        228
        _dead_7186 = 658
    value = 896344
    text = __import__('base64').b64decode('QzdjaW5TQ2pJNmxCZDQ0ZDN0Q1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΠЕПВδЮПвЦЕЧАЪζЖ():
    value = 87509
    text = __import__('base64').b64decode('ZUVpaWYzbUtKaTkzbUl0eDNlQUI=').decode('utf-8')
    total = value + len(text)
    return total

def _свΥчюПтЯθΓΔАтδ():
    if len('') > 0:
        pass
        _dead_9271 = 195
    value = 631149
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD/ASVcK558nYiuixHulIw161Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αютβпШμωΛНΦκμΘ():
    if False and True:
        129
    value = 153488
    if False and True:
        748
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiPtTUEY8aUgHA2w+QGeMHYg6l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        501
    total = value + len(text)
    return total

def _ГгΡнξоБΝя():
    value = 943513
    text = __import__('base64').b64decode('dHkwNlRQMnNSR3BZODZjUU5ZRDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙьцΘΦΩηьγψ():
    value = 526027
    text = __import__('base64').b64decode('VzhScGR4cVdBWDJMZjd2NFh2MDc=').decode('utf-8')
    total = value + len(text)
    return total

def _РхяшвЯфΨК():
    value = 66040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiTPb3QJ86EbbVuW4WepNQAjvT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 39 < 0:
        _dead_4212 = 391
        pass
    total = value + len(text)
    return total

def _ΛШθΚизоъΒЩλΧКаΣ():
    value = 419429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Enr2OF4S8IAyHzaVn2OyAw44tWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 59 * 97 < 0:
        70
        pass
    total = value + len(text)
    return total

def _ъЫюУΔЭфыРωΒтΡьм():
    value = 558631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh/rQAMo6Yw1CSat+WSqPDB7tTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        724
        402
    total = value + len(text)
    return total

def _ψκζΙЭεЛтБ():
    value = 139223
    if len('') > 0:
        802
    text = __import__('base64').b64decode('bXhONHFCbkNpUnZxT2RnYmN3M3c=').decode('utf-8')
    total = value + len(text)
    return total

def _λσьΝбНШΕЪ():
    value = 907751
    text = __import__('base64').b64decode('blhTRGNtemNjd05FNjVzOGhuMWg=').decode('utf-8')
    if 97 * 34 < 0:
        110
    total = value + len(text)
    return total

def _γζρявЯΥΥмη():
    if 17 * 6 < 0:
        pass
    value = 611887
    text = __import__('base64').b64decode('YVRoWHFhX1hidVlDYmdYQW1pSlA=').decode('utf-8')
    if 35 * 89 < 0:
        796
        432
    total = value + len(text)
    return total

def _ΘыцΛИМцъΥфльЩοэр():
    if 10 * 99 < 0:
        697
    value = 515218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxjFamQe75o6bxux732iNzEb7Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 42 * 39 < 0:
        482
        _dead_1597 = 105
    return total

def _ΨχυВξРЙзυПυСΦθь():
    value = 16775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzXXfVI3yYk6OVqi63W3JHB+4Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖЛнΖчΟШЭ():
    if len('') > 0:
        _dead_8825 = 339
        196
        _dead_5423 = 383
    value = 799336
    text = __import__('base64').b64decode('R0tDTTk1RmpzbnF3ZU1QSFBheHU=').decode('utf-8')
    if 15 * 21 < 0:
        830
    total = value + len(text)
    return total

def _ЕεжβоЧпПюυн():
    value = 450789
    text = __import__('base64').b64decode('RWtJSG5DclRjVFJ2YjlIdUhfZDQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8702 = 570
        730
    return total

def _ςξяΒезикΜ():
    value = 862503
    text = __import__('base64').b64decode('dmlfaEhXS0pKX3F0NXdRTlRadGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΡηмΝЛРЭщΘяΗшбФ():
    value = 193711
    text = __import__('base64').b64decode('S1dCektYa1VEX3d3c2lKb0ptWWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕКЮΖЕбσΡΓΑТДрχ():
    value = 289671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQLXXHY317wOD1e60lCXPRQY7T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΨшΓМЕМш():
    value = 107160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhXyN2IQ3b0KHga6kESCHj0M4Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωγЖαушΧΔЫЧαьζζэя():
    value = 837323
    text = __import__('base64').b64decode('VHV3eTJxZnMxTFIyTnU0bjVQWXc=').decode('utf-8')
    if len('') > 0:
        _dead_9152 = 593
        pass
    total = value + len(text)
    return total

def _ЯζАЩЗРябΘ():
    value = 496067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3nefmYwxIQTHCOv+FimMysH5nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НδЦΔСΔΦиЫЮъм():
    value = 551297
    text = __import__('base64').b64decode('UWxkNUU1TnRVVkJMbkhpV2pybGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΘжюкΩλЪОмЕκΠΥ():
    value = 79843
    text = __import__('base64').b64decode('b0lrNnU5Wm82TGlvSlpxN3hqMG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖсеιЭΙοеΡοΓΤЬчμ():
    value = 191000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSC0Vlge2rIuNwX0wgXFCwslwmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗЬУячаναСΓρ():
    value = 689431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSzMYwdryKALNCuA+gaUERE6138='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4771 = 525
    return total

def _МжπРИβσдЭШЪψυΟл():
    value = 282240
    text = __import__('base64').b64decode('amR0eVZaZVE2MncyWk5objFjamU=').decode('utf-8')
    total = value + len(text)
    if 80 * 27 < 0:
        2
    return total

def _яСВμΠеζР():
    value = 738779
    text = __import__('base64').b64decode('cWZiREpIeFRCeENQNlJnRnpGTHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΠΕЯΗδКюβАКД():
    value = 231120
    if False and True:
        _dead_8414 = 295
        567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISvRYUAMr5wTLjeykGeSAQQq6Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζΟАоΙφщθΛэСмХΔ():
    value = 551425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTbxYwIr/6MyD1mF30yeMy8f8l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7545 = 243
        pass
    return total

def _αЗыΞяуΑцфйЕмКωΚФ():
    value = 830307
    text = __import__('base64').b64decode('SHVCa0ZhbkQ2dmx4cUl5WWx4NjI=').decode('utf-8')
    if 37 * 67 < 0:
        _dead_9532 = 513
        _dead_8337 = 316
        pass
    total = value + len(text)
    return total

def _ΘΒКΥхςнКтчΣ():
    value = 766731
    text = __import__('base64').b64decode('SFlCZVNHZkxQUVVjeVVBTV9pUWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΞΠΧаЮяЗЦΔЮПнαΟΧ():
    value = 335762
    if 65 * 26 < 0:
        527
        _dead_1653 = 654
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRrrZHMj/alRDACI+gK2PzE29F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςζΟοЖεдЩдЖΜ():
    value = 725494
    text = __import__('base64').b64decode('QlJIUkFmNHFBNldlOU1LVWl0b1U=').decode('utf-8')
    total = value + len(text)
    return total

def _гБζыψЫбШΧпъьΓЭφ():
    if 38 * 65 < 0:
        pass
    value = 80574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MintRGkz6b4FEA6XxlmoNg0owEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ырΟлηриИь():
    value = 828221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DizVW3A36opRKSmJwAO7bAR7x0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νлЖψρθθэБОЬъΘКБα():
    value = 216259
    text = __import__('base64').b64decode('ejVDSEVSbWtiMGlwaHRRZWVBNlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _еΓнΕфЦКρЪЮυаВ():
    value = 517525
    if 97 * 45 < 0:
        _dead_6401 = 2
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSj0d3MaypIsbB2i/g+fICkrvU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        211
        pass
        pass
    total = value + len(text)
    return total

def _λωΥΨжХжΣАΖ():
    value = 522074
    text = __import__('base64').b64decode('WlFkdTlKYTlqd1A5T3pycExoYXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _κΟЮбмМΑИΧΛΗ():
    value = 955137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy7pbEhuwf4NDDmsywKHOnM/8E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 88 * 21 < 0:
        _dead_9786 = 230
        _dead_2439 = 768
    total = value + len(text)
    return total

def _АΔΒднъАЙΠγЛ():
    value = 71858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAvwVnxs6a8EMST1yVuYNT05yTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3767 = 900
        395
        3
    return total

def _λςфыэιТτюψюΝОИδН():
    value = 963476
    text = __import__('base64').b64decode('RmdXVG5sVDRrRmpjVmVBS0w3eGI=').decode('utf-8')
    total = value + len(text)
    return total

def _κτэЬРΒуΦеЗ():
    if len('') > 0:
        _dead_3892 = 516
        _dead_5020 = 73
    value = 372792
    text = __import__('base64').b64decode('R0hrMzE4OTJ2M0F5QmNzc2NxdEY=').decode('utf-8')
    total = value + len(text)
    return total

def _РγψСкιмυдζ():
    value = 117855
    text = __import__('base64').b64decode('WUd5aXRhTlY1dlhyTWtoZ0d6T24=').decode('utf-8')
    if False and True:
        pass
        902
        pass
    total = value + len(text)
    return total

def _АрχνΧαрΝМ():
    if False and True:
        228
        pass
        pass
    value = 265799
    if len('') > 0:
        _dead_3053 = 550
        285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHzTYHowz/AuGyK141e5HQsFyXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЫМΙкυπΠ():
    if False and True:
        pass
        _dead_7481 = 593
        _dead_4162 = 162
    value = 857300
    text = __import__('base64').b64decode('ZXhzT0RPU2xXSDNiNHRkczlwT1o=').decode('utf-8')
    total = value + len(text)
    return total

def _πМγрχвАЩсξηβ():
    value = 253425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjX8ZVs2+7AnPi7ymGzCHgMdvEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        287
        819
        pass
    return total

def _ДпΞЮζФХт():
    if 58 * 62 < 0:
        634
        672
    value = 299367
    text = __import__('base64').b64decode('akxURDNkaW1fUHZ2SkxKMjZ5MVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤКЭдУΠСПжяЖпьΡ():
    if False and True:
        pass
        pass
    value = 12166
    if False and True:
        82
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag7vbGthyYYnFzyP0GmjIwYL0W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 88 < 0:
        pass
        pass
    total = value + len(text)
    if 91 * 67 < 0:
        pass
        _dead_9764 = 245
        411
    return total

def _шаΓσιЕДξ():
    value = 458648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBvNQwQQzLwgAhuomHq+DQ4O8GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗУЮкщхкςςτСΘ():
    if len('') > 0:
        _dead_9744 = 358
    value = 511137
    text = __import__('base64').b64decode('WklMMWh2bnl2azZHZ2pOMEJ3MUs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        728
    return total

def _АΗгНΣГδМЭгΗΣъζЮН():
    value = 686273
    text = __import__('base64').b64decode('SXplUEM0bzMwUG9iSlIzREZDQmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΧРιЦΚΓλΧВ():
    value = 558239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACbxfUY73/4mNyGl0kKvbTIJ53o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МςΔбюΞΞээπφψυэ():
    value = 924494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyfpdnAA2KQxDl6M4GWxBhUmzk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if len('x') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()