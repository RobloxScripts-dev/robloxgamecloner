#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ψЧМΝΘЫНмκФЬ():
    value = 859808
    if len('') > 0:
        405
        256
        _dead_1384 = 382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mwa8eQE/xI4TYhur4QS5GDcY52E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6642 = 740
        _dead_6906 = 204
    total = value + len(text)
    return total

def _ΞΗюΛгξΣΑеЯΜΗиξ():
    value = 873998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXzLbVBu0YAQKCKVym/HAHJ+5lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΨΚйОРρςΕΦмвμ():
    value = 236464
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwvAWn4LyoomEVeywUybOC4b50I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘзЪκβΚъδΕТю():
    value = 575869
    text = __import__('base64').b64decode('UVdRM2RsME5WdGFBWE01a1UyMlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ьιтрΕтΧЛχцнОкПЙ():
    if False and True:
        473
    value = 145568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxrzPQMM/78ELTahxkWSPgB6vWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ζζΝχоπρщЯбйЙшф():
    value = 122504
    text = __import__('base64').b64decode('cnpvbDZheUxDdWlSekdHWTc2YzM=').decode('utf-8')
    if False and True:
        504
    total = value + len(text)
    if 24 * 3 < 0:
        303
        909
    return total

def _ΘβЖХΠОеР():
    value = 759823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAviTVwT84kQEw6Z+VfEPQI7zXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖНЙςэχΟЖАφжνЦοф():
    value = 380421
    text = __import__('base64').b64decode('cVBsTU8zQVV2V0lnaVhGQ2I3NHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔезьЦчДЦиΧιжл():
    value = 463895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwHoeXA97vg8CiuZ7A+7ZBwQ/Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔВμрμιШΤσЖ():
    if len('') > 0:
        pass
        pass
        pass
    value = 871109
    if len('') > 0:
        66
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dg32O2IR764xN17y2FCTJyIQwm8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πЙщξЕЭкαихΗη():
    if False and True:
        pass
        578
    value = 898000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxzjOwMowbwMPyiM6VTBOQIWwFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΠкξΗЫшΑξΘθкщЪΔ():
    value = 740521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwL+OHdh7bkPHBuz2kLIJA8q50g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вРБЭПзΙшνεΣθ():
    value = 34506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQ3+fHIO5PEzNyOAw3m1NzwQ7Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 35 * 22 < 0:
        _dead_2223 = 344
        pass
    return total

def _яσεЭΡжцΝЕЪШ():
    value = 209631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag3gWlhtx/kIYiCg2WSZGTApt34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6144 = 918
        pass
        986
    total = value + len(text)
    return total

def _ΟйΜОъςλγΡ():
    if False and True:
        _dead_3388 = 492
        _dead_6393 = 552
        pass
    value = 597680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR7vVF4x7P8xElmF91i1FyR86jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭмΨвКчκЯ():
    value = 554643
    text = __import__('base64').b64decode('QjdFM19jajB1ZGZSYlhEcjlKdEw=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΣρΤΜЪЩΥχкβ():
    value = 788140
    if 35 * 58 < 0:
        873
    text = __import__('base64').b64decode('eXh0WmI4TTJ0S291MlBDeV8xUnc=').decode('utf-8')
    if 72 * 59 < 0:
        _dead_4532 = 851
        pass
    total = value + len(text)
    return total

def _фжΠΙιУςлφиХЙЧ():
    if 92 * 45 < 0:
        pass
    value = 975580
    if len('') > 0:
        354
    text = __import__('base64').b64decode('V1FaN0doWGZtT2JYVHVIRGhzSGs=').decode('utf-8')
    if 85 * 50 < 0:
        _dead_8295 = 69
    total = value + len(text)
    if False and True:
        _dead_4584 = 534
        pass
        pass
    return total

def _аиХΧЗЧЯпΙΦ():
    value = 453549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDbWTGA8zfw1bCmt726iYhccsks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4921 = 76
        pass
    return total

def _ΦЩΧчοММΠ():
    if False and True:
        pass
        _dead_6543 = 637
    value = 157729
    text = __import__('base64').b64decode('R0ZQMmFJUHpzdEt3TlhqRkUyNUo=').decode('utf-8')
    total = value + len(text)
    return total

def _νСВИшЪΕςЧпзюМ():
    value = 377243
    text = __import__('base64').b64decode('cElzSHNxcWE5NldKVTFGdFJEbEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ртΖфхβЬφΟд():
    if 49 * 31 < 0:
        715
        _dead_4754 = 286
    value = 572769
    if len('') > 0:
        pass
        368
    text = __import__('base64').b64decode('SDVEQVdEdHY1SWNtczBVUDhBWHE=').decode('utf-8')
    if False and True:
        65
        _dead_8255 = 778
        _dead_4536 = 255
    total = value + len(text)
    if 30 * 64 < 0:
        _dead_2179 = 955
    return total

def _зρХΑоГтМЧΧΑΧΘгг():
    value = 579148
    text = __import__('base64').b64decode('a2V3ZGU5TDEyMHdmaktaeUdKajg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΣκΖКНρэЬ():
    value = 539226
    text = __import__('base64').b64decode('WWNFb2F4VElSQVFvMV9Rb0oxZmM=').decode('utf-8')
    if 79 * 2 < 0:
        _dead_8669 = 848
        _dead_8451 = 214
    total = value + len(text)
    return total

def _иΕηδлАэяЩΚЯ():
    value = 40375
    text = __import__('base64').b64decode('Qm9MeUczWWNWeTdhYTRydEpxemM=').decode('utf-8')
    total = value + len(text)
    return total

def _щπςягйςλоΟС():
    value = 945981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwL3YAgo6flbAh2h20eCABUQ834='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οθχЛВначΗΞ():
    value = 1947
    text = __import__('base64').b64decode('TEZGcnJXc3JNV25HT0R3YW85S28=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗПθυΜΜВГωΣКьΗχр():
    value = 699052
    if 4 * 68 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx3XdHs9zrpaOSWl+UGUOhUjt0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξеЕцΝнΤχЪφ():
    value = 271356
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwrDdwkrqrE0bSaLmUWJGQs2z2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωπЯζΧщΚЬСΕиЫзΣгω():
    if 5 * 9 < 0:
        pass
    value = 633119
    if len('') > 0:
        621
        _dead_8835 = 335
        _dead_1474 = 257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag7OVHdp3fxQDQqZ+QaiHDc5z1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚαбλЬиτщΧΝΛθ():
    if 30 * 3 < 0:
        263
        pass
        650
    value = 703044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASvpalQq/KAtLFi55H60BjEp12Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗйАЕφКΘТъОКΜ():
    value = 689893
    text = __import__('base64').b64decode('dEdWOGR0ZWR3YUd1c0toSkpnZVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΤζКΒЭРΝшЬωшй():
    value = 531957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiO1SAE79LgwLCv1y13EIgs75n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1375 = 891
    return total

def _чΝξΥЩΙζи():
    value = 481737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQ6zRVgNz4UkLAqp/HrDNjA26Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АДАДУΩЙψ():
    value = 859286
    text = __import__('base64').b64decode('anVvSXd2eGFHcW13MVI4N1dwU2U=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_6807 = 98
        pass
    return total

def _УШОιβΣμлЩчПΖЬАψЕ():
    value = 3896
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC7BOXsw3Z4tEzqFkU7JFREX1X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жмБηДκμКυ():
    value = 595899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhfCQ2sf6o8NK16O8UKSLHwltGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΤзΗυХεдως():
    value = 104862
    text = __import__('base64').b64decode('STBxb0V6U0VoQmNRYlg5RFhHN3g=').decode('utf-8')
    if False and True:
        _dead_9639 = 434
        449
        734
    total = value + len(text)
    return total

def _ΣΒЮΧбКкκκюПγшΣнΖ():
    value = 169654
    text = __import__('base64').b64decode('QUoyVnBveHkxWHJHTkt5bVJhcVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ибΦЧДпАκДΖΗΩД():
    value = 886723
    text = __import__('base64').b64decode('eXdhbWZlNlV4Qk5VcktDSlpOdVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣЮδоιΖΦщцмцΔу():
    value = 28556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSjmW2VvxroEKyKVnA+2JgYCtmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νξэιЮнЭбυЦΨλАб():
    if len('') > 0:
        pass
        415
    value = 243433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy7uOHU+z4svY17wm0yoM3Z61Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4784 = 554
    total = value + len(text)
    if len('') > 0:
        564
        _dead_4337 = 676
        913
    return total

def _ΕςОЭΕФфθχΔи():
    if len('') > 0:
        _dead_5539 = 3
    value = 788524
    text = __import__('base64').b64decode('STZfR2FjaVNRMkxSYnRGQUVHVzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞоЗФτйСΣЪμШтΗес():
    value = 681533
    if 94 * 57 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyHIfEsS+/4EACmXz2+DIgoZ3D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 83 * 28 < 0:
        58
    return total

def _НТΛΡξюαУΔУΒΗыЗЫζ():
    value = 882764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRyybEEI8oYbDlm2wmfEJiop/Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        590
        _dead_9229 = 976
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4552 = 24
        _dead_1009 = 621
    return total

def _ъΞαΙΥпйУнΗΡщΖζуБ():
    if len('') > 0:
        _dead_8313 = 757
    value = 317581
    text = __import__('base64').b64decode('c2U3ajlERmZQZzZxRTlXbkxGU2Y=').decode('utf-8')
    if len('') > 0:
        103
    total = value + len(text)
    return total

def _ЬпВвпэκфΜЪРхЫΚК():
    value = 541053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgvxO3we0aAub1ix0gDDYAMQwWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠаΟДΠΖЭΗОζ():
    if False and True:
        pass
        pass
    value = 360927
    text = __import__('base64').b64decode('TXUyamhwSlhKaUZPM090TmxkeDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЧрБΙшбрΠνГΧβШ():
    value = 433364
    text = __import__('base64').b64decode('cGdmVFFPSHU1RXN6ZnNKZXM5UTY=').decode('utf-8')
    total = value + len(text)
    return total

def _δцоψгΣяЯ():
    if False and True:
        pass
        305
        _dead_8285 = 778
    value = 200323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix7DWl0xz45REyCw/ESWYCcM1l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρДХзΕЧИрФ():
    value = 422910
    if 59 * 92 < 0:
        _dead_6793 = 530
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTfbaEIP9YoWFwOP73eYDhEAvEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БπησχЗΖψяΡ():
    value = 580756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyjhVFgB0bk1DhqIkVCZEAF6yUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧЧэьΕυνжтΓΗАφгз():
    value = 415384
    text = __import__('base64').b64decode('dnJhb2FocjRyQ2d6MjdrR2Y2SXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭьΧшΡКсИи():
    value = 857924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQrVaW4zrp05HyHw+VDDMQA10zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞВЮПΗΠГЧУхщ():
    value = 238471
    text = __import__('base64').b64decode('ZEQwbG5xRzRJdDN4anlzaE1JYWk=').decode('utf-8')
    total = value + len(text)
    return total

def _бЧГΡыуФθΤф():
    value = 573808
    text = __import__('base64').b64decode('czUzS3JmZ01vTnB3ekZCQVREYjc=').decode('utf-8')
    total = value + len(text)
    return total

def _унзΝБΓΠйφς():
    value = 406827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxjATGQzp4YXCzWG51CkLgon01Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 78 * 94 < 0:
        834
        _dead_5633 = 984
    return total

def _ΒжечйτРΡЕκбч():
    value = 77282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAjLWXlg8KtVCQqVygC3ABF9smw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рδΟшудψρε():
    if False and True:
        pass
        pass
    value = 746801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS7vd0E9/aBbAjvy/1OCZzUq6Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κоУрЛχфοйξйυΓрκ():
    value = 485971
    text = __import__('base64').b64decode('bVVBU0Fic0lFaGFtc0RvbmFtaHY=').decode('utf-8')
    total = value + len(text)
    return total

def _эΛЬюЮяΒμъ():
    if len('') > 0:
        pass
        _dead_1979 = 999
    value = 973359
    if False and True:
        970
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQDpfEsjqockKgGokAOpFxEZ8Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥεЯΒΓΕхЖНоН():
    value = 482962
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HX/dd1wc/LAkFl2P/GSqbQMI120='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 90 * 100 < 0:
        _dead_4197 = 507
        pass
    return total

def _θВΔΥΟсЙδΑСκ():
    value = 210194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCDCfVpspo82NB65wlSvBi0C8Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θбφПуλаС():
    value = 573127
    text = __import__('base64').b64decode('bmNTWEljTUxJc243T2E0b29ZRjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ХмдКΒβЗνΝΤеоιЧМ():
    value = 624708
    if 64 * 36 < 0:
        151
        pass
        282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAfzPVZu/5I3KCCl0m+qOCwX/EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШЯοΗЙЕтΠτЗснЦ():
    value = 621327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In7Lelkw1qEHIheT/1rFACQV4kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5127 = 740
        _dead_2211 = 50
        pass
    total = value + len(text)
    if 84 * 76 < 0:
        pass
        225
    return total

def _ОЬМζееЦΝεвгη():
    value = 665121
    text = __import__('base64').b64decode('ZEIzc1lDUkNWTnBVVG5CVE1vekI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЪδΙТΣβРА():
    value = 304324
    text = __import__('base64').b64decode('SzRXakR5OEFpSnVFS1F2MzRzOEY=').decode('utf-8')
    total = value + len(text)
    return total

def _БЦΤΚψαЖГ():
    value = 174331
    text = __import__('base64').b64decode('SGdGNkVITFQzVnZSUThwZG5PdUY=').decode('utf-8')
    total = value + len(text)
    return total

def _оτΓтΛΙЪΩнчМИЖΞζЬ():
    value = 244707
    text = __import__('base64').b64decode('QlF1TlBUSHl3ZmtTQVZkc0ltZ3k=').decode('utf-8')
    total = value + len(text)
    return total

def _гуΦОБΛυΙ():
    if len('') > 0:
        pass
        465
    value = 721096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX6xYFg+8f4tOQOF3VSzPTQZ908='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_1355 = 634
        969
    total = value + len(text)
    return total

def _ллδΩЪΖБΖρ():
    value = 210215
    text = __import__('base64').b64decode('bFB5b1F4Q2RjaDAwVUUyUFNnR2k=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        616
        521
    return total

def _νδΔФχячξЫν():
    value = 778661
    text = __import__('base64').b64decode('VW5ERzNiUUdxY3lfYWhnUHdMbnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗаАΝУΥчΙЬ():
    value = 808789
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwnuYF5p/4YbMC6xz1W0JXN40lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψδρΤЫмЮшБшЩΘΦгδМ():
    if False and True:
        pass
    value = 596261
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnfUYQgKqpFQFQGSyV2VBSEYzEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_2120 = 824
        _dead_6049 = 994
    return total

def _оЩρэπИхξОοъирΨΡ():
    value = 497438
    if 48 * 64 < 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('cVFIOEJkRlBHaVpCNEpDNXY4Q0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨБРΨψщрζαЧςбαСε():
    value = 803763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgjbQ2k6y/4rLi2C2l3BJxE97mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5522 = 488
        pass
        447
    total = value + len(text)
    if False and True:
        _dead_8330 = 728
    return total

def _οεжκЯеΒχΖ():
    value = 309522
    text = __import__('base64').b64decode('Q1psUmFYNTFMVENzYWhwM1hiZHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭяГзυφβРЗМдчЦδ():
    value = 218260
    text = __import__('base64').b64decode('aTVmY2o3MkhydHpuaGNjZWVaN3c=').decode('utf-8')
    total = value + len(text)
    return total

def _фТФΞΠΛΚХОκ():
    value = 86967
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mjn1Vl1r2P0aNiny63yJJz8r0lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ряβХκсΣЩГИΞΚУг():
    value = 94520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQzFW1cfyZ4gMTqVnXfHBzYLz1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μТοξΚЬАεлυИяЕ():
    value = 839094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCHIYX4jrPACMCGO71DGOSAJwDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иЬιсдтХш():
    value = 28725
    text = __import__('base64').b64decode('cGg3REh0bWdSalZDN2hKZmRnOHY=').decode('utf-8')
    if False and True:
        _dead_5636 = 163
        601
        _dead_3430 = 845
    total = value + len(text)
    if 30 * 55 < 0:
        pass
        pass
    return total

def _лЕμдξОΧΘЖзΝΑΤ():
    if 95 * 34 < 0:
        116
    value = 102621
    text = __import__('base64').b64decode('VmxHNXBEVWRBX3JtU0pGZ0VsbjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙррФвΣЕнЙ():
    value = 366536
    if 1 * 8 < 0:
        21
    text = __import__('base64').b64decode('VTVndWMyRllNdWlUQTRSUDg3ZE4=').decode('utf-8')
    total = value + len(text)
    return total

def _δЭυПΞыЕПКАЭΣдиа():
    value = 889791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhjxYGc+0bEgPQmL/XqUHCc412g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъжЬНКяΓΣЖмλΥйδу():
    if len('') > 0:
        155
        308
    value = 229006
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhDGNn9vxq9SBTy54wGiYDE+6jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8620 = 593
    total = value + len(text)
    return total

def _ЧтэцрККЪиХЗδΨΥ():
    value = 529971
    text = __import__('base64').b64decode('ZFpUQU81Z095WkIwVzFWSTNTOUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖпАχъфцεвΟб():
    value = 724309
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCD8OXY7z6NQbDqm+2yGGTQk1zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5503 = 214
        pass
    return total

def _ςβоσаνБΝΒпιх():
    value = 675253
    text = __import__('base64').b64decode('VnpvZG5SMjMxaDhMNkFPNDdRWGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ηψΚэΝПлτАξΖбшоμ():
    value = 781223
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSnbXlUK3fkoLRyb3FidGzAW4W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_3557 = 79
        639
    total = value + len(text)
    return total

def _янκнΒΑЬνΡДчΗψμЯ():
    value = 284370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSvDOVA696tbCh+I4nDANRUC9kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦκστшЖΠу():
    value = 224571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwLvXgUp0qoSNx+U5HiXYXwG0z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γσΟшΕфйЭΜЛДэΦ():
    value = 49626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgHbRF0D6YwybSePmUKlOi8j9U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йвΛфΥΤΤηςГΘ():
    value = 552472
    text = __import__('base64').b64decode('RkNwZXdMNkNLTmdRbzFyVFhTREI=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΕкνκЭΛЯРΨΗИΖΑЦ():
    value = 31107
    if len('') > 0:
        758
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiqwbFwcy/BQKiaz6mLEMi4Hxmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΓπΩδАλыРДЙ():
    value = 193288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXjrS2Ef2o8XMlav4X+JISMHxXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        560
        _dead_8373 = 280
    total = value + len(text)
    if len('') > 0:
        623
        pass
    return total

def _ЫЫσΞбибъζΠъФ():
    value = 379124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiLyTHI/0pc7EzzwmwXABwp5x1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗйηΙοЪмΓсОаЮбΕΒт():
    value = 618885
    text = __import__('base64').b64decode('dkxUb2NnREV5QW5ZRFdlYVNlT1g=').decode('utf-8')
    total = value + len(text)
    return total

def _цΑςоЧГδьςЪξ():
    value = 999200
    text = __import__('base64').b64decode('aUVMMU9zZnc1SjRkVGhzTjVMeDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ВШЙфΩЧБЯΘГΛфα():
    value = 706495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRCyN1Rr9pBaMgianXjJIHQa8GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лцλЩΤфйΩжΨРцЖγΗ():
    value = 739100
    text = __import__('base64').b64decode('aXJMNTRLSDFfQlBGRWNPYldfYmI=').decode('utf-8')
    total = value + len(text)
    return total

def _йПΙφрδκПΔаΞмГΦ():
    value = 963132
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADeyZ1kQ7LI1bw6s5n2kPCwN42o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξйΡаΜОяΙ():
    value = 210590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ai69Q3Qzr5tXKiqUyW6yYz0Oy38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟЗТμЫλоС():
    value = 752414
    text = __import__('base64').b64decode('eTVIbU02ako2WVAzbDdPSGtXZ2g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_1947 = 514
    return total

def _мΤлБλвцс():
    if len('') > 0:
        pass
    value = 46601
    text = __import__('base64').b64decode('ZjdRaEFKNHhJV0k4SzNaSWcxN3I=').decode('utf-8')
    total = value + len(text)
    if 70 * 4 < 0:
        pass
    return total

def _ыνΖλΚэΩψсРШ():
    value = 473836
    text = __import__('base64').b64decode('RTRDTEowdWpvOFJSYzh0NDBvR2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕДАΑЧμжыΣСΑЛПΨιИ():
    value = 492519
    text = __import__('base64').b64decode('eXN0c20xWkVMUHZLYWxkamI1bnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _щыЪΣΖΗΕы():
    value = 255065
    text = __import__('base64').b64decode('SE8zOTk5dnFlZ3V4YkNzUDhIVU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧδςЪмбИтςΣГω():
    if 84 * 93 < 0:
        817
        _dead_6727 = 249
    value = 793841
    if len('') > 0:
        pass
        _dead_9807 = 566
        97
    text = __import__('base64').b64decode('eGZMX3kyZVFBZDlhcGZyNDlUZnA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        315
        pass
        121
    return total

def _йΛКναдДа():
    value = 766193
    text = __import__('base64').b64decode('d0lPdXBFM0lIZGd6V2dCV3Y2OVo=').decode('utf-8')
    if False and True:
        164
        580
        913
    total = value + len(text)
    return total

def _δБΔΤΕΩПΕГρте():
    value = 964906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByzUPnMO2oY2awWm5kzAPCE980k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        12
        173
    return total

def _НβАφАζгχθИΗΒιθσ():
    value = 908015
    text = __import__('base64').b64decode('SkxNYTFYbGJrSEpfaVhuQTF5eF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧеψβчжΥЦΣЗΝРОπ():
    value = 165767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzrIX1gozaU8YyyM42ODIjY39T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        886
        _dead_7392 = 74
        pass
    total = value + len(text)
    return total

def _ζлХэшЗыςЫ():
    value = 716205
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRa0aXcr3/AhLgapw26FMTILtVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τПЪΛΜμγσΗЬΜщΘУИ():
    value = 211481
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhbDQEZorf0TKh6Sy1yfDCIL9k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8521 = 744
        _dead_6607 = 799
    return total

def _СаυοςΝΕΓыШΥ():
    value = 671924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCHJQ3gp9Y81DRunzWmjEAQA43c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6557 = 850
        pass
    total = value + len(text)
    return total

def _θΦиΑЪΞδжНυφИээΙф():
    if False and True:
        _dead_9370 = 558
        59
        932
    value = 835910
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXrsVkcfy6AUFTyA7QSAAysO0kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        124
    return total

def _МΨФπгТАИΙуθνξΚлв():
    value = 381504
    text = __import__('base64').b64decode('VDNqd3IxdXlDaDZIT3U4R0hQOHM=').decode('utf-8')
    total = value + len(text)
    return total

def _юσЦСΠγмьΜоΩγζ():
    value = 270166
    text = __import__('base64').b64decode('b29EeWFNeHI4V2pYWG5ZQ2JKN0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _гΥУΔΠъμЛуοαшΞΡ():
    if len('') > 0:
        267
        _dead_1232 = 48
        _dead_6706 = 359
    value = 784927
    text = __import__('base64').b64decode('YlJZbmNYemJud2gwSklzS3hlbDU=').decode('utf-8')
    total = value + len(text)
    return total

def _ХсΨςоΜξτΗФИФΣΣΝΓ():
    value = 945229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiHDNwYwxqZVIBeknXCeGQEh8Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        763
    return total

def _анэПЦкΚΛжφ():
    value = 987800
    text = __import__('base64').b64decode('ckFKVWtWR0pTYzAxOEVyN1NxOGU=').decode('utf-8')
    total = value + len(text)
    if 74 * 59 < 0:
        990
    return total

def _гγсЧИшιΩρЧδСОжщ():
    value = 498872
    text = __import__('base64').b64decode('bmtHM0p1bEFlaW5mXzNES1Y0NkM=').decode('utf-8')
    total = value + len(text)
    return total

def _РΦбИΒγΩЭνΓθАнюαЯ():
    if 68 * 93 < 0:
        pass
    value = 412706
    text = __import__('base64').b64decode('UlVmR3pwZHBpYWV6bVB1N1ltMG8=').decode('utf-8')
    total = value + len(text)
    return total

def _гοεоыγЩЩчτВΣФΝн():
    value = 946438
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDjjbHVp2IIZGSK2z2WyFyc97F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _рзυЯцХχΛЬъζМπК():
    value = 237942
    text = __import__('base64').b64decode('R2VBc3ROX1VjNVlEZ0g3akVVcHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЮЛаАΥЫκЫуцкИЫ():
    value = 273236
    text = __import__('base64').b64decode('ZU12cTJxMUJXSkh2MWhLRHQ2eUM=').decode('utf-8')
    total = value + len(text)
    return total

def _гъΝζМНΓЛЖΘьЦ():
    value = 857042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky7OQHo2q707AFv2xkGdHyAbzWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уРбδΕΗЕЖνбευξ():
    value = 725772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDzgT0drqr5bPQX6/m6BOQEVvFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        672
    total = value + len(text)
    return total

def _СШжΜΟъНьщФΛЮ():
    value = 502574
    text = __import__('base64').b64decode('YTZvTFdyMmEyWThiNE54SXJNeko=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖцОμужΘцМ():
    if False and True:
        184
        _dead_4812 = 779
    value = 939957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQDRbEkNqbszLxmb/EzAbXYZ3X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7993 = 256
        499
        pass
    return total

def _йВлНλЫπςΨЙ():
    value = 944387
    if False and True:
        pass
        pass
        _dead_4498 = 992
    text = __import__('base64').b64decode('QWFDUnpIbWx4V1dfaGRMalNCWWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ιРΤайΩκχΚфХω():
    value = 560759
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxWyd3Qq/PgmCDel6wXJGiAjxmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5997 = 577
    total = value + len(text)
    if 11 * 49 < 0:
        379
    return total

def _ОМΑырпЗΩ():
    value = 432906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz+0V34u6fwOMDaHz2GjO3Mj6nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΦνбгξКΞΑЫПМνα():
    value = 400404
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTjhb38t3aRQLR6c3l6YPyQW0Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψτюРушξСгΣохД():
    value = 74742
    text = __import__('base64').b64decode('ZjRpOUlVdzFzX3Vsa0ZhclVxS3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _εОЪиΙЭжψΨЧ():
    if 34 * 27 < 0:
        891
        765
        pass
    value = 231635
    text = __import__('base64').b64decode('RGZicGZ5cWlRaGN4NlFlSnhadG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ХГЩХЬΟгμΖ():
    value = 783191
    text = __import__('base64').b64decode('b0I1emhwaFp1SFpnZGJWNjl2bGs=').decode('utf-8')
    if len('') > 0:
        _dead_6029 = 92
    total = value + len(text)
    return total

def _ςσхОвкьσЙκы():
    if 81 * 69 < 0:
        _dead_7135 = 547
        890
    value = 964883
    text = __import__('base64').b64decode('bm5FYU5UdFcxY3FpMU15QmlnRmg=').decode('utf-8')
    if False and True:
        _dead_4069 = 135
        pass
        441
    total = value + len(text)
    return total

def _ПΩοηихψΗяΜ():
    if 40 * 100 < 0:
        pass
    value = 758429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHzvWAML2YINDViP+nqUNhomw0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 1 < 0:
        336
        pass
    total = value + len(text)
    if 52 * 75 < 0:
        pass
    return total

def _υлиЦЛΝжγЭ():
    value = 431359
    text = __import__('base64').b64decode('emQxb2lBQXdWdU5rN29WQnlkbTM=').decode('utf-8')
    total = value + len(text)
    return total

def _БцπЙχПйХлπьΛδКфэ():
    value = 930155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnrvZggXzJc7aiaQ/A+YPwt272I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΥσςκΟЖХуΗГ():
    value = 229722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhztXGE/2fkpHQrw+06XYAoI4z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        162
        pass
    total = value + len(text)
    return total

def _ЭκΜλдΤΑπ():
    value = 866009
    text = __import__('base64').b64decode('cTZZS2ZiRjJMVExQdU01Wng4WTA=').decode('utf-8')
    total = value + len(text)
    return total

def _щсЦлЮωдΓΠ():
    value = 611262
    if False and True:
        pass
        _dead_7946 = 660
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CA7PYQUy84oEMiaA32y8YjwXx3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2381 = 564
        803
        439
    total = value + len(text)
    if len('') > 0:
        _dead_9075 = 354
        pass
        _dead_1841 = 792
    return total

def _ΧΘкйЗйηΗУΟΣο():
    if len('') > 0:
        pass
    value = 231640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxjHaVUSqP08DRul2lCTBio6wDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛνθДΥфхЭяοЦУЧ():
    value = 579278
    text = __import__('base64').b64decode('WXRlUnBra2E0TEF4bFpyYXNGNV8=').decode('utf-8')
    if 67 * 69 < 0:
        _dead_4277 = 771
        465
    total = value + len(text)
    return total

def _νΟοΧСЩωВфξЦΔλσΝ():
    value = 572263
    text = __import__('base64').b64decode('aTJzSXBDVTJjbGdKbDhnYXIwRkk=').decode('utf-8')
    total = value + len(text)
    return total

def _πКΝЧЬрυιΘцχΡξ():
    value = 863733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxD+X38+p4EVPlyo2nGBGAAf5lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑФгЭΚωοбУΕЫΕпα():
    value = 974267
    if len('') > 0:
        731
        515
        165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3i9Olho8ZlULx2b3l6JNjIL1EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_7977 = 754
    total = value + len(text)
    return total

def _яжтζφъτааТЯΩь():
    value = 783148
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiGxegQd8ocvaCCEzgKfDX193lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΞДΠΤБμΟЙСьВжΝр():
    value = 310617
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDn3VEUD8JIVaR32mlidNRYE6F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΜΣкЧеФРБвйΜк():
    value = 514781
    text = __import__('base64').b64decode('aHNxaTFpRkF6MzdRUFJSNnd4Tmk=').decode('utf-8')
    total = value + len(text)
    return total

def _κтЬюбЯμзАШйяεАΕ():
    value = 673183
    text = __import__('base64').b64decode('a3hTaERWMmdvM2UzNDdPNllPazI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖγΚхЦеЗцЙζм():
    value = 515221
    text = __import__('base64').b64decode('WU0wUW9RZmlRVjJiTDRGS0VCaDk=').decode('utf-8')
    if 91 * 16 < 0:
        538
        _dead_1395 = 112
    total = value + len(text)
    return total

def _ЙЕкλУмТдΜ():
    value = 691562
    text = __import__('base64').b64decode('d2lzaWVtTTZRcW85ZmwxWjdZUjg=').decode('utf-8')
    if len('') > 0:
        _dead_2665 = 329
        _dead_6606 = 101
    total = value + len(text)
    return total

def _δωДэкλясω():
    value = 112626
    text = __import__('base64').b64decode('cko4bm80emJqUkthd3dHa1BsUGc=').decode('utf-8')
    if False and True:
        _dead_4668 = 184
        _dead_1865 = 880
        pass
    total = value + len(text)
    if len('') > 0:
        442
        pass
    return total

def _ψбΗЙΧθЦΙц():
    if len('') > 0:
        _dead_3681 = 576
        12
    value = 851724
    text = __import__('base64').b64decode('Wlllc3FnTVhwTVNKNlY1a0daeDI=').decode('utf-8')
    total = value + len(text)
    return total

def _фщчρУπΔуоΥК():
    value = 405109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjfDOH4P2IklO1iP72OWHC1/72Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _πяρΑηДΧω():
    value = 638919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBzVb2sU9YQnbRqz5lydbDAhtUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        701
        313
    return total

def _πΚешΖωыфΤ():
    value = 565501
    if False and True:
        pass
        pass
        _dead_7813 = 489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cyr0XnwO/4ZQagSAm1ShFRMgyVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 47 * 77 < 0:
        pass
        pass
    return total

def _зсгРΘσΧР():
    value = 221831
    text = __import__('base64').b64decode('b1VsaDNfd09Rc29YN1BBeDM4WU8=').decode('utf-8')
    total = value + len(text)
    return total

def _УπΝШΟΖАЙ():
    if False and True:
        _dead_5089 = 4
    value = 870066
    if 52 * 66 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3vSSFAtzoUkKymxxwWcOwYm4mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        840
        110
    total = value + len(text)
    return total

def _ΨςптпχΥыЯΚе():
    value = 134774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTX2fwke8pcUHST2mXGHMh0g0zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оПуΡсоψнЯГε():
    value = 42865
    if False and True:
        _dead_1141 = 672
    text = __import__('base64').b64decode('Ynd5WGl4Q2pPdTNkcERlck1oZWE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6159 = 812
        pass
        816
    return total

def _ηγЯУΞМευΒе():
    value = 743481
    if 57 * 13 < 0:
        _dead_5534 = 486
    text = __import__('base64').b64decode('VHJlYjVVc19YYXR5R3ptMEx5OEU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3934 = 603
    return total

def _ΧЫЬФмФтΠζΗТю():
    value = 567403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCvTZQQt37pSCCKF6nOGBiYb9Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χφΨρξΦπР():
    value = 255262
    text = __import__('base64').b64decode('a19tQnMzelNCdlE3UmFKT0M5ZjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΥвβняЗЭъαХгш():
    value = 230636
    text = __import__('base64').b64decode('ckVCcGJLREs3cXdGNHh5bWtfXzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ФЗιδщΗιЪуКΨγтЯ():
    value = 477487
    text = __import__('base64').b64decode('TEdBS2JCREM0QnRlNXJoSDJrXzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ГыВННиЫо():
    if len('') > 0:
        291
    value = 224061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH/QekYW/ZdWCymXkGScHwE+tn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        53
        167
        526
    total = value + len(text)
    if 33 * 26 < 0:
        _dead_8739 = 600
    return total

def _ΝΧυΨгГныψпι():
    value = 129613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAPPY3wY8oQkDw2Mn2SlBnQa40Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΔШΤФυυыρИДГψФ():
    if len('') > 0:
        932
        pass
        _dead_3466 = 804
    value = 474995
    if len('') > 0:
        _dead_6587 = 886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCX9RAZgx6cvGwyCy0WmNxM453o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 70 * 96 < 0:
        761
        pass
    return total

def _еξЬΦМΡЧГσψΙ():
    value = 884711
    text = __import__('base64').b64decode('eHMwWkd6TFhyYXY0MVM5aWdUQXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒУλΠτΖЦπβς():
    value = 502331
    text = __import__('base64').b64decode('bW9fbVRKSnlETmNNSndKSVZRcHM=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _еЖПБΦΕΚЗЧδгй():
    value = 159803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3vGRXIGqJkMO1eQ0WeRYyQk9m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЖχπιΦΚαЕъЮ():
    value = 837739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQSyQUMJpowHOB2XwULEM3wY7Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МшωфТзγΣТягκлςЭτ():
    if False and True:
        _dead_7092 = 593
        pass
    value = 842520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lze2ZWMB16shAzywxHSBJy410VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        54
        _dead_5845 = 647
    total = value + len(text)
    if 91 * 78 < 0:
        834
        945
    return total

def _μψΨθжΥξζΓХ():
    if 64 * 79 < 0:
        pass
        248
        pass
    value = 733632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgjKfWVoz4wMFiuC2n+aAHEb4Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        889
        61
        _dead_1445 = 326
    total = value + len(text)
    return total

def _йυаκАэщэфФεαΨ():
    value = 607520
    text = __import__('base64').b64decode('WEViQ3pReU9veTlQWHFtaHg4NWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ыДЦОαЕβОЪμБйх():
    value = 321156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DynrSQk19442ahihnkGBOXU+3j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιρεбИξДЗхνЫΑгΝя():
    value = 806629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDn3UQQY5PwQNxi5/H2jGj8D9UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧЩοВΣСЧΓяΗ():
    if False and True:
        pass
        556
        1
    value = 333783
    text = __import__('base64').b64decode('aTdoRTF5VU9vZFJnSXl3bUk2WUU=').decode('utf-8')
    if False and True:
        _dead_5925 = 547
        pass
    total = value + len(text)
    if len('') > 0:
        9
        _dead_1391 = 238
    return total

def _БПижАпВЛу():
    if False and True:
        _dead_4787 = 0
        994
    value = 999019
    text = __import__('base64').b64decode('VFFVbTlnMktXcVFjN0RsU0tvNGI=').decode('utf-8')
    total = value + len(text)
    return total

def _кЯΕΟмцъпσаΚ():
    if False and True:
        pass
        _dead_9636 = 858
        324
    value = 633896
    text = __import__('base64').b64decode('ZmR2Rjc1dWhfeWloZEpTTkRpU2I=').decode('utf-8')
    if 44 * 91 < 0:
        697
    total = value + len(text)
    return total

def _ΕκφошηЫгγКθΓ():
    value = 827121
    text = __import__('base64').b64decode('d2JLN21zTHhNcjhxcnpSNUtLbnA=').decode('utf-8')
    if len('') > 0:
        pass
        33
    total = value + len(text)
    if len('') > 0:
        599
    return total

def _цьζАъЦλфηП():
    if 70 * 49 < 0:
        pass
    value = 179988
    if 62 * 81 < 0:
        _dead_9298 = 487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3/hQVYp1ZBbLV+20HyvEXQh7Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        703
        pass
        _dead_4400 = 325
    total = value + len(text)
    if len('') > 0:
        _dead_4129 = 410
        _dead_7641 = 538
        pass
    return total

def _тЕыйΒАρш():
    if 50 * 33 < 0:
        pass
        pass
    value = 936648
    text = __import__('base64').b64decode('QmlKMzNySWNNQWw0S2VaX1NTODQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓМкЗρΟфЬьх():
    if 66 * 80 < 0:
        _dead_8030 = 143
        _dead_7493 = 449
    value = 379864
    if 49 * 1 < 0:
        _dead_1428 = 415
        19
        412
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IC21WwEIxvFVHxmR936BHycBt2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яνфΠМιΙΧЫο():
    value = 627032
    text = __import__('base64').b64decode('QVlXOU90c3dqN1dsVTdMZGwwRHM=').decode('utf-8')
    total = value + len(text)
    return total

def _σκарΤмЮαчΞЧ():
    value = 819772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXm9d2MQ24ItLBaX7HqIEy14t0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _УчЖΡйцзΑЕ():
    value = 464188
    if len('') > 0:
        66
    text = __import__('base64').b64decode('cnFSNUZDbzdTUDlLczRMemEzYnE=').decode('utf-8')
    if len('') > 0:
        _dead_9799 = 188
        101
        _dead_7432 = 502
    total = value + len(text)
    if 57 * 51 < 0:
        pass
    return total

def _ςяΤΣаыηЙИюмυЫ():
    if 2 * 8 < 0:
        pass
        pass
    value = 574188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiTeTX4J6ZIMGAeJ8HKHGgs6wUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_2208 = 97
    total = value + len(text)
    return total

def _ΤбГεΞХясЩΥЩα():
    value = 677965
    text = __import__('base64').b64decode('cXRtRWliM3VEd0gxOUlFQlZhd3A=').decode('utf-8')
    total = value + len(text)
    return total

def _πчΔяΣШаΞφСΡЦьξя():
    value = 916725
    text = __import__('base64').b64decode('R1AzQkpNWHUyM2F5aTlYNW9UNng=').decode('utf-8')
    if 53 * 58 < 0:
        488
    total = value + len(text)
    if 81 * 13 < 0:
        pass
    return total

def _ΑΞЩнεАПбэЭΧЕλбε():
    value = 471926
    text = __import__('base64').b64decode('aEZxQ1dENF9MdEM1ZGZqVWs3ajM=').decode('utf-8')
    total = value + len(text)
    return total

def _ШОхЬΧωУйξΛΓпБΕΗυ():
    value = 34942
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHnVYVoLyaAZE12g20+zBhR90Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡψзгЦсΒэΛхАчцШК():
    value = 875310
    if False and True:
        _dead_5081 = 231
        pass
        _dead_2139 = 601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MATNOWQqqaYuDSqQyl+/ZTAZx2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 19 < 0:
        pass
    total = value + len(text)
    return total

def _ΔωщБθΔςс():
    value = 511855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh3oUQdr6bAaYhn022W3DT811Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1569 = 538
        pass
        _dead_1248 = 96
    return total

def _ЯλΠμЭюрЮ():
    if len('') > 0:
        809
        906
    value = 494430
    if 69 * 58 < 0:
        802
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyrHfmUIqYkAGRn33EzCDhYm1nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖсωψЖβъиЛТ():
    value = 847906
    text = __import__('base64').b64decode('Vkk4eGxqbXpVc1g1V2U5UWFlb2w=').decode('utf-8')
    total = value + len(text)
    if 21 * 47 < 0:
        pass
    return total

def _аεхΡЧжМφЭдчσЮ():
    value = 442720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESXWPQQ2q/0wHCaH8kGdByAF7m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1266 = 640
    total = value + len(text)
    return total

def _ξхмΡуПμКΔΦΜ():
    value = 107974
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Azn8WAY615wWPQK6ww+cEzI29j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιτхηψξсГ():
    if 43 * 51 < 0:
        pass
        _dead_4245 = 897
    value = 426907
    text = __import__('base64').b64decode('TDU3TndxRXZ4R2xfenFNSGZwSjQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _РАΦССсДγνвКΙΘ():
    value = 971572
    text = __import__('base64').b64decode('Y2NocE03N0VheWpSV0FBclBHSHA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        252
        213
    return total

def _ρφдиγΥЭρЖΒ():
    value = 411411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRflYGEcyqkODgOFmnWFZR8J81k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯцЬЯЬнΜяя():
    value = 891415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CD3mWW4s06UmHS2h+HeCCwQe0l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if False and True:
        _dead_9157 = 578
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 79 * 17 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    935
    _dead_7122 = 360
    _dead_5958 = 239