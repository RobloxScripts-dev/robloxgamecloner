#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _зΑΖσαΟдО():
    value = 560670
    text = __import__('base64').b64decode('YzJyMWxFb0xxazE1Ml93M2MwR3Q=').decode('utf-8')
    if len('') > 0:
        620
        pass
        pass
    total = value + len(text)
    return total

def _ВΨяфцСιТν():
    value = 497072
    text = __import__('base64').b64decode('bHFRV01la1lMZGloZmNhYmhSQkg=').decode('utf-8')
    total = value + len(text)
    return total

def _δЫтυΥΖαрξжΦς():
    value = 522806
    if False and True:
        _dead_5110 = 593
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxXOWEMU9Yo0LTeLnFyjYiYN0Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 48 * 21 < 0:
        809
        _dead_9593 = 907
        pass
    total = value + len(text)
    if False and True:
        _dead_9451 = 595
        pass
        pass
    return total

def _ХБЯΒЩΨνι():
    if 90 * 55 < 0:
        _dead_1742 = 328
        pass
        pass
    value = 247555
    text = __import__('base64').b64decode('bEVRREVBZXFCYnpFVWNFOEh5YlM=').decode('utf-8')
    total = value + len(text)
    if 54 * 52 < 0:
        586
        30
    return total

def _ЬΙΑΡЕτУр():
    value = 166011
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjyzNmI7qoZRE1+K+0a3In0j3lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬησЗщΖΘДЙГ():
    value = 201137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxfrdAk67YMwCS2a7X64ZnAp70E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝъЖЬσРШατАжζ():
    if len('') > 0:
        873
        53
        762
    value = 482414
    if False and True:
        _dead_1023 = 948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiPHW2s62r4hPCuo/gKmMh0F50Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βΦаΩсΤИшфΟ():
    if 81 * 57 < 0:
        513
        _dead_8488 = 932
    value = 638308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQfxRVocz4kqHAP2x1rHERME0HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        536
        _dead_1575 = 872
    total = value + len(text)
    if False and True:
        212
        pass
        69
    return total

def _ΤαφΠНОчт():
    value = 203157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBrvT10A6v4ZEQ2vkHSiHxAG9kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΤγκΘκРасιμω():
    value = 22874
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTbgSmYU8L4lLCuLzFGJIQEYzHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        959
        pass
    total = value + len(text)
    return total

def _чЯεΕκθοφПεтΡЛ():
    value = 583823
    if len('') > 0:
        _dead_5850 = 956
        _dead_2252 = 915
        _dead_6604 = 732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQD0YWAG+5k5MxuW7EbANw4D8X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тнγЪΝОΨΠΕБл():
    value = 370350
    text = __import__('base64').b64decode('ZmhOejhZV1JJRnZtQW00cktXcW8=').decode('utf-8')
    total = value + len(text)
    return total

def _шХгЗСНщЙе():
    if False and True:
        pass
        pass
    value = 231444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3vUS2I6rroAPwCky1C9Z3Q7wnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φμХΚγΕΚУфΜκκцγЦ():
    value = 519825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQG8Olhg6/pQCAvy4WyCDDcY3E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЙРДюХДεΚ():
    value = 623928
    text = __import__('base64').b64decode('d0NCMHhNWU9LSXp5clZJZTgxcGg=').decode('utf-8')
    if 38 * 18 < 0:
        73
    total = value + len(text)
    return total

def _яЯфоеυεζψΛР():
    if 43 * 1 < 0:
        _dead_7080 = 806
        _dead_7550 = 449
        774
    value = 582566
    if 91 * 55 < 0:
        801
        _dead_3467 = 74
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aif9aVg9rIxbOwKokGa5OScN6Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 24 < 0:
        183
    total = value + len(text)
    return total

def _аΡγΓябΡΜзенμКГнο():
    value = 187115
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTbCQUIV8J8gaSmu2AHHPwF83E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮтхкВнмуЛρξΦС():
    value = 501373
    text = __import__('base64').b64decode('YWIxQl9DUlk2aWZZWUlfNmNncTA=').decode('utf-8')
    total = value + len(text)
    return total

def _αкМаОΧςνζкЬшζ():
    value = 767216
    text = __import__('base64').b64decode('dTllQWYxNGIzMjJUV09VU2ZGeXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ωЦЧоυΗЕΒΙЬΑзГΥ():
    value = 457199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EznFY1Ayz5AKLD+imVyCIy92/Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХνΟаЬчιхяГφЖμрΗ():
    value = 590860
    if False and True:
        _dead_5655 = 820
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgP+ZWsh1olSKQ6G8VelAw4OsFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΘΧДИюΕЭзβК():
    value = 51294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH7AfwQW6voVLAbxxV+bBCQYt3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟεΘΧΖОΥΞ():
    value = 590567
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kiz+ZV8LrIwxMCeiwnyCPi8H5Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1354 = 437
        641
    return total

def _БυцΚКсΦΚ():
    value = 307433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxmzUX0/p7pTPyOZ4HCUPCgX4Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΙПτΨЬχΨλθЯбеΚ():
    value = 507300
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgzIbAkY+LpaOVn17WaEJggD5ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧπчшАΠΖрΨξбΑАШτ():
    value = 571823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSzWPHwy0o4pNj6m+nK+Jwcb8HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РАρΚηΝΤмΤΔκ():
    if False and True:
        pass
        pass
        pass
    value = 402798
    text = __import__('base64').b64decode('U1JQZXBvd1dfZ2RiVTVieW1iVG4=').decode('utf-8')
    if 15 * 41 < 0:
        _dead_4673 = 668
        pass
        591
    total = value + len(text)
    return total

def _ΜΜшΖΩСδΙΩлΟΗЛ():
    if 94 * 77 < 0:
        _dead_7587 = 366
        _dead_5235 = 115
        _dead_9691 = 295
    value = 929805
    if len('') > 0:
        pass
        _dead_1995 = 198
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHzwQ0hrzI0tMwGy+lS/bAQ+7Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ЪФΣΚЖЧΝσИΘщπЪЮЕ():
    value = 261517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXrrQVMerJ9TPFi3nUe4EjYlxl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        421
        _dead_7005 = 849
    return total

def _χУΔηΛСΑжχхα():
    value = 556419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRjFYFc0+JILAz6u+lOXAy0X50A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΚАΠΩлнΤг():
    value = 829558
    text = __import__('base64').b64decode('ZkNUSHRZbEdUTjlLRTZocnR6cXo=').decode('utf-8')
    total = value + len(text)
    return total

def _еЫПЖисщЭЪЙЫПБяАМ():
    value = 8141
    text = __import__('base64').b64decode('ckZjR1ljdXR6TlBrRHE1ekZYNW4=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_2247 = 348
        800
    total = value + len(text)
    return total

def _ФПΥШиигφηПнρΡФ():
    value = 701623
    text = __import__('base64').b64decode('Tk1WVUhEajVlNV96djhOVVlwYTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥьйНКЖυнιаΩО():
    value = 218596
    text = __import__('base64').b64decode('aHNWeERLTXphMURiQWFTN0dqbGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ψшЖЫδκФЧхЮΕуа():
    value = 310933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCjSXWMz6Pw2KASawgCIGB133kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑηАнΤΜыЛДθ():
    value = 16176
    text = __import__('base64').b64decode('b0JaWUphUTlRMVZuVDAxN2N0aXY=').decode('utf-8')
    if len('') > 0:
        _dead_8610 = 326
        pass
        522
    total = value + len(text)
    if 41 * 44 < 0:
        946
        480
    return total

def _θΚΞΧΣикжЖ():
    if len('') > 0:
        _dead_4531 = 27
    value = 244885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nnu3b3sO7/8nAzeW3H6YbCwo6G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΔΦМФΧцγшΠЫΟе():
    value = 525742
    if False and True:
        pass
    text = __import__('base64').b64decode('d3JJbnA5cXNIZ2k1dHJVOU5RRlo=').decode('utf-8')
    if False and True:
        _dead_4018 = 876
        636
    total = value + len(text)
    if False and True:
        462
        988
    return total

def _ΜУгыμчЩΘΩβАΙю():
    value = 617032
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAHjelYqrpoQPx+iwX23Zi55w28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛεΠжοДПνзОΦЩ():
    value = 253827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iir9WXA7x/gFDyuQ3Qe6EyoA500='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥνаιцУЭсξГρМ():
    value = 498535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxnxSAFspoMlNSykzlOELhIXw2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΨятφлжβВЩцβ():
    if len('') > 0:
        _dead_4241 = 573
        _dead_8283 = 660
        _dead_1821 = 419
    value = 785710
    text = __import__('base64').b64decode('dnFRWFFvc0tlc0dqalU1SDJtU1k=').decode('utf-8')
    total = value + len(text)
    return total

def _τΩΡπΗΝАΒΛ():
    value = 48401
    text = __import__('base64').b64decode('aDkzMkRjWk1mOE10U0FvTWxpTmg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9132 = 448
        pass
        _dead_6145 = 689
    return total

def _ьЛβφЙчНч():
    value = 511310
    if len('') > 0:
        _dead_6260 = 28
    text = __import__('base64').b64decode('RjlYeHVkbkpNTjRMWUl1WlpGa3Y=').decode('utf-8')
    if False and True:
        _dead_1028 = 798
    total = value + len(text)
    return total

def _ЬΣΖэЬфДмαтпЭППβ():
    value = 668673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3rVaUgj6IESKj662w+iHnEC8HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒυЯвψлДкЧщюю():
    if len('') > 0:
        pass
    value = 113264
    if len('') > 0:
        _dead_9258 = 729
        905
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgbKV1sy36cFNFrz5kXDCzciwVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μузчκнΩΑΨЪ():
    if False and True:
        372
        416
    value = 248021
    if len('') > 0:
        _dead_7627 = 123
        _dead_1378 = 182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxzGN0sh1akONgel0QXEOwAt1lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьωрИэψбЗ():
    if len('') > 0:
        _dead_3859 = 535
    value = 316462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn/NZ0cB//AZGQH68WagLgobt0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        45
        365
    return total

def _ДΞФЪγпуКгШΓТΞ():
    value = 372355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgLPOEEQp5o8KV+C+G6XHCgA1jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КφθΨΕЩМхТωΨЕΧоν():
    value = 806286
    text = __import__('base64').b64decode('eFBYcjdVdzNSbXo3amp1NjI1bnU=').decode('utf-8')
    total = value + len(text)
    if 64 * 2 < 0:
        206
        pass
    return total

def _ΗΞυθЫθσЦЫмь():
    value = 99914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix7JXmQP/K0EKQP74WSWOhEj/Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _рвεНΛэАТΨьеβаφБγ():
    if 66 * 60 < 0:
        pass
    value = 973543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgLrWEA96IJWMgr27kK6PS8g0ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2183 = 846
        131
        727
    return total

def _щйВΨηΧЖОьλΜΑχιП():
    value = 913820
    if 42 * 87 < 0:
        796
        184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwLTYH8g0q0OAjiO5H+6FSwIzW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 37 * 58 < 0:
        353
        pass
        602
    return total

def _τΘαΤΗцЙЯβξя():
    value = 866422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyTpaVQ01po3MQyGxACeOgIDvGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пйиЭюАΦМТΦΘИи():
    value = 886344
    text = __import__('base64').b64decode('clhtOUx6OHNJRkQ2T2lrdlUwdFU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5875 = 203
        pass
        894
    return total

def _μТΦфΝμχξΞΛΡмЭЧ():
    if 58 * 47 < 0:
        _dead_8715 = 469
    value = 431879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCy9QGAt76tVbl61yVqaAx0q4l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μшЩΟглЬдμΑ():
    value = 580048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LALdTGsMqJgpaz+E21OUCzYOx2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΔОπЪυСλдτЬΨγмΔШ():
    value = 223995
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTuxWUYt6o0qDgmJn0SmGyMp8Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πЬХψΧΨξΛбфШБХ():
    value = 839887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQrJPkc+pvouHAa0nH3BDAIOskI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΡХхωРΜΜЭΖρмц():
    if len('') > 0:
        _dead_8366 = 228
        pass
    value = 724571
    if False and True:
        _dead_1770 = 772
        _dead_8579 = 503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQrNPV8O9p4GHlegwXW+ORo9wTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еаУбςтγФЗ():
    if len('') > 0:
        _dead_2165 = 459
        _dead_6109 = 284
        pass
    value = 778903
    text = __import__('base64').b64decode('Y2d3RllzUlNJOWQzTGpuZHpkcHI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        497
        _dead_4857 = 950
    return total

def _зРЯэОтζβΦБДКаю():
    if 71 * 62 < 0:
        355
    value = 106483
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('a0VXZzB0VWpQUlVJSHM0YkZRd1E=').decode('utf-8')
    total = value + len(text)
    if 83 * 79 < 0:
        pass
        92
        _dead_5991 = 336
    return total

def _оЩΣЩΡΤπо():
    value = 69358
    text = __import__('base64').b64decode('ZGMwbTVaVENvQlFRb0h0ZEc4alc=').decode('utf-8')
    total = value + len(text)
    return total

def _жЖЯΒПτУрιщ():
    value = 321254
    text = __import__('base64').b64decode('dVNTdWFlUEFESk5qME1MNFBpbEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΣτрρΒФЕΡр():
    value = 776053
    text = __import__('base64').b64decode('WTRDbFdna2RRdUkzd29ZYnpDVGI=').decode('utf-8')
    total = value + len(text)
    return total

def _хщЙЛηэъзΑЙщΦфвν():
    value = 146741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3/iSgEsr54oKCz0nlS2Jgh+1UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕлΓгЪЙΡЭхΛлЛЖα():
    value = 183302
    text = __import__('base64').b64decode('QmN5TVF5c3FUWjRGMTlrZnJrV1g=').decode('utf-8')
    total = value + len(text)
    return total

def _εΟηιвΡфΡъχфЮг():
    if 21 * 50 < 0:
        _dead_8510 = 737
        _dead_9321 = 51
    value = 928260
    if len('') > 0:
        _dead_9109 = 441
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX7NWFw0rLEPFimEzmeUZAk7/Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ΗΤюγсьчνчЗаИΤя():
    value = 839682
    text = __import__('base64').b64decode('a0lWZDlQOF9rWHl4aDY3MnZ2b18=').decode('utf-8')
    if 50 * 76 < 0:
        pass
        _dead_9271 = 962
        pass
    total = value + len(text)
    return total

def _ωςьЬπЦψΑ():
    if len('') > 0:
        pass
    value = 438975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiLSR24oroQWFBqpxF2DZRB94F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        223
    return total

def _ЮАαεгΞТдЦΦЖΟωЙ():
    value = 721915
    text = __import__('base64').b64decode('ZXhFWEpLZWJDcUdoWHFUUHc2NXo=').decode('utf-8')
    total = value + len(text)
    return total

def _οфοчиΖВυΓΡ():
    value = 530889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB/rS0Yv3Z8GPVmL21WBOigZ038='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2012 = 564
        930
    return total

def _ΨΜщΜΨΖεонπΗΩЖ():
    if False and True:
        _dead_7548 = 527
        pass
    value = 762838
    text = __import__('base64').b64decode('TjRyOXJ6Z19MZDhneDlDWDJhRlA=').decode('utf-8')
    if False and True:
        _dead_7318 = 701
        _dead_6576 = 239
    total = value + len(text)
    return total

def _ЧфцаУΓδйд():
    value = 647711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAfBY241rf4FHimG7mSqH3Ms9kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯщЪаШоПΧВιнΤ():
    if 4 * 62 < 0:
        _dead_9088 = 247
        pass
        pass
    value = 126854
    if len('') > 0:
        767
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXazXAYh84MhIw3631nEGgYF3m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 74 < 0:
        734
        349
        pass
    total = value + len(text)
    return total

def _ΓΡΦеΠЭψВ():
    value = 538211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwHbNggg2qEmDAKZ21SbJCoL71w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МхρΙυεΑтКχкΖГиπ():
    value = 67463
    text = __import__('base64').b64decode('cjRUTm4wYzh2eDRnOGZFeGZGd0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞязЬγΠΩздεЖ():
    value = 742420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA2wR3ULprEmECGTm3S6ZAR/sF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωωуъΓхеθеСξЕтм():
    value = 188877
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDy2Y3kN2rgpEhyr+HqSOgMl4ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΓйΨγГфчВΣА():
    value = 338062
    text = __import__('base64').b64decode('aUQ3dWxzYVNtNWR3VDR3aG81dzk=').decode('utf-8')
    total = value + len(text)
    return total

def _αΩΗЬТΣЮунΚДмοр():
    value = 632301
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwvBbFY16YEmKgX37ACKIQcAwGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζΝΣΜΣюνΠΑ():
    value = 673280
    text = __import__('base64').b64decode('ZG92bERqMUhxVV84Y1FESXVzdWE=').decode('utf-8')
    total = value + len(text)
    if 56 * 23 < 0:
        _dead_6184 = 133
        258
        621
    return total

def _ПςтηххАЧΕηΒВлз():
    value = 958375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyHuO3Bu7PxSO12v7V69DSoZw0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εтζУтπпоЗΟ():
    value = 349058
    if 15 * 16 < 0:
        _dead_8659 = 397
        171
        464
    text = __import__('base64').b64decode('R0ZHeUVGUkk0VmRlWlF6UXhpY2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ПфЧМοψцЙυλСошπБΚ():
    if False and True:
        640
        328
        410
    value = 975725
    if 90 * 47 < 0:
        pass
        _dead_7942 = 224
        _dead_8488 = 645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQG1bFZt5qE1Pj2XkEe3LQ549Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 89 * 68 < 0:
        _dead_2172 = 252
    return total

def _ЯъЮЧеЭшДЩΣτκ():
    if False and True:
        48
    value = 385604
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB/wa2E/1b0rERy6ykWvISQr108='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        757
        pass
    total = value + len(text)
    if len('') > 0:
        750
    return total

def _зНтжЧэΣГКърЪζ():
    if 93 * 83 < 0:
        937
        _dead_8932 = 452
    value = 219911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDzAbUkRyLxWND6wxQHCECYo42Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔФхυйΗΗКΕΖтйΨ():
    value = 577343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwXWVmccr4MkPwz3yg6GMzF8/Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬсУИκмшΖНЖΝПМъ():
    value = 900691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Exu3VFUOrKEqMw6p4gO3DBUktkg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΓΒАВвуΟΗЦΩПмКпΦ():
    if len('') > 0:
        pass
    value = 669127
    if False and True:
        120
        _dead_7913 = 16
    text = __import__('base64').b64decode('WTdITzZIZ2cwVnZuY0tTNkROMno=').decode('utf-8')
    total = value + len(text)
    return total

def _БцβьОАБθψцΚтδлэΔ():
    if len('') > 0:
        pass
        902
        266
    value = 993276
    if 59 * 85 < 0:
        _dead_1424 = 655
        111
        701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQrNOgdgrYdTGDWv0EHHLnQg6ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъюЫΞбωДχЧλΨ():
    value = 601810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mzu0UUE77YwwCx+I53KWDCMH3mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ωρГωлэωΗτП():
    if 20 * 53 < 0:
        _dead_4534 = 763
        _dead_8383 = 294
    value = 112560
    text = __import__('base64').b64decode('b1FSaGRva1hyMW03bFVXVXhVRkE=').decode('utf-8')
    if False and True:
        443
        _dead_4908 = 717
    total = value + len(text)
    return total

def _цτλдтшδσЧ():
    value = 567684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3v2PkIXzvkLNTuxxnDIZgkX6Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЖсврΔЪояΚЪИ():
    value = 259012
    if False and True:
        pass
    text = __import__('base64').b64decode('RW1tNzlEdDRzTHl1Q01WSmtzMno=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7317 = 296
    return total

def _ΓζПаγΚΥЮНьΙΝ():
    value = 351568
    text = __import__('base64').b64decode('TXBRTlBLUlVUUnl6VGRaMUEwUTc=').decode('utf-8')
    total = value + len(text)
    return total

def _αλШЕΒЕЫνВΛθΩΤ():
    if False and True:
        pass
    value = 825920
    text = __import__('base64').b64decode('U2lIUXo4c3puOXJ2ZnYyVE01WGw=').decode('utf-8')
    if len('') > 0:
        _dead_6000 = 657
    total = value + len(text)
    return total

def _йρЯЬБΩщΠоФй():
    if 55 * 47 < 0:
        pass
    value = 846421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgzPPEZrzKM5az/wmEOEZQo8vWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЮΛдЗТЛжНПжК():
    value = 478743
    text = __import__('base64').b64decode('QmtsYkVyNlB2UDZyVURocWowSkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΞΟЖυмщР():
    value = 842301
    text = __import__('base64').b64decode('b3FpMk83ejBiemRkcE05c0R1SkM=').decode('utf-8')
    if len('') > 0:
        548
        363
    total = value + len(text)
    if len('') > 0:
        90
    return total

def _УΦςТΚгζХδТη():
    if False and True:
        927
    value = 667538
    text = __import__('base64').b64decode('dWk4bTIxa3lieGl3a3RITWZjYzM=').decode('utf-8')
    total = value + len(text)
    return total

def _хъщΑНДЫρАΛΙσ():
    value = 954511
    if 88 * 91 < 0:
        38
        pass
        _dead_1390 = 776
    text = __import__('base64').b64decode('cnNHREE0VTQ3S2M5dXZpV0NPd2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЮырЬЗΜОΛИТь():
    value = 802380
    text = __import__('base64').b64decode('T2tLaV9qMUVTTF8wUVhBWkpYMEc=').decode('utf-8')
    total = value + len(text)
    return total

def _χефΔδαцεω():
    value = 917143
    text = __import__('base64').b64decode('bDVjWF9WSFdsNl9RMmZFNmVwbFA=').decode('utf-8')
    total = value + len(text)
    return total

def _φПЬΕкКπγΛ():
    value = 620205
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MX+0XXcg349SMCiH71e2ZhAgtWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΝΞСΕЧΙΖАЗюς():
    if False and True:
        pass
        pass
        845
    value = 914496
    if False and True:
        pass
        655
        50
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3zsaAYe+qkxET215UaXInIIzzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШφΙЕρςЕλХΓΤПЮΘ():
    value = 490121
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHzAd3Q4qqQwLAi0w3CEFwwOtms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΝщЬЙχβтеΖψζз():
    value = 170880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyvOWUkDxvg1OCz75268MRMV8jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΝРеΟНтЕΥγСм():
    if 41 * 95 < 0:
        pass
        pass
    value = 572946
    text = __import__('base64').b64decode('S2JRQmFRMHlQNklWZ1BLMlpkVUo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _МΥηΠиξΝχ():
    if len('') > 0:
        pass
    value = 782920
    text = __import__('base64').b64decode('TnlNYnZCWGJJb3llaEtUdVVjOVM=').decode('utf-8')
    if len('') > 0:
        _dead_4434 = 816
    total = value + len(text)
    return total

def _ЛТΠδвψаλюАυФя():
    value = 957666
    if 34 * 50 < 0:
        pass
        _dead_9799 = 945
    text = __import__('base64').b64decode('S0RCck1odTNFN0FVMFJQd2lKZ1U=').decode('utf-8')
    total = value + len(text)
    return total

def _шэЦщσΤФчр():
    value = 375553
    text = __import__('base64').b64decode('SWZDeVpjenFMMTRoeEdZcEZRNkU=').decode('utf-8')
    if len('') > 0:
        _dead_9337 = 576
        _dead_9748 = 459
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _юЫЪфΠеπΨ():
    value = 521609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EC6yRkMN5I0hMRuz7nWANRcMskI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λйНβΣΚеζΒΝоσ():
    value = 318560
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCfdXFos//s7GACcmXeSAxYL/V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞФюФфжыΘлЫΛШдчБ():
    if 85 * 92 < 0:
        _dead_5566 = 403
    value = 663472
    if len('') > 0:
        _dead_4248 = 684
        _dead_2041 = 7
    text = __import__('base64').b64decode('TGk0dnk3anZiODNGT0dBMzE3WVg=').decode('utf-8')
    total = value + len(text)
    if 100 * 40 < 0:
        _dead_4587 = 30
        454
    return total

def _αЗиююΕФΒΖвИ():
    value = 511658
    text = __import__('base64').b64decode('bFdJOElIUDNkXzBLVGJwWHprbWs=').decode('utf-8')
    total = value + len(text)
    return total

def _РВюεХΕЖЧхΓЪыαΚс():
    value = 596273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCW2X2YR+ZE0NS6FzFe6InI78ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΞΜагηΖΞχАδ():
    value = 507483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NibRT3wVq4QNDReR+0O7ZwIn3DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭзωвГйεХКЯ():
    value = 6512
    if 63 * 92 < 0:
        _dead_7481 = 0
        975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjf9e2Ju+J4OOQuA4V+0H3wD1m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΖθхζхХъЖ():
    value = 895111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3r1anVq/6IBNz/z4Gm8A3Qd0T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞрмΧςАтЪΒГςиυЯ():
    value = 781532
    text = __import__('base64').b64decode('ek93ZGVNam9CYkY4OXVZSUluaDA=').decode('utf-8')
    total = value + len(text)
    return total

def _зεЭзφρТйнφК():
    value = 29730
    if len('') > 0:
        304
        pass
        633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSzjN3sLx5EybBi55lS5Dn071Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йЭШЗшДФЖΛГΚΖρ():
    value = 733151
    text = __import__('base64').b64decode('ZEZMS0lLbGpfbG00MGR1b01tTW4=').decode('utf-8')
    if 30 * 66 < 0:
        _dead_9788 = 936
    total = value + len(text)
    return total

def _ΨσΜΣсЕуΠб():
    if False and True:
        _dead_3689 = 112
        723
    value = 659047
    text = __import__('base64').b64decode('WGRkWUdWR0ZOT2dLdnpDaDdNb3M=').decode('utf-8')
    total = value + len(text)
    return total

def _οχЬбхαЬыЦетЗ():
    value = 888688
    text = __import__('base64').b64decode('QUtyaXhNU0ZJM2Z1VmJnVXp4a20=').decode('utf-8')
    total = value + len(text)
    return total

def _жλΤςФГψуЧΔΥНΠΠ():
    value = 900298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EC7DeF0b9aZVHwb73UGxAXAm8jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θеяОΞΗρΒτ():
    if False and True:
        221
        2
        _dead_3935 = 978
    value = 808811
    if 99 * 12 < 0:
        _dead_9777 = 672
        302
        _dead_5856 = 190
    text = __import__('base64').b64decode('R0lQTnpWbW1nQXR0VWN1bVdMUlU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        387
    return total

def _ВЮфЬΤοХжΖ():
    if False and True:
        869
        511
    value = 502464
    if False and True:
        _dead_6830 = 375
        _dead_6153 = 972
        146
    text = __import__('base64').b64decode('SGpqblpKZlB4dTNDNXlzdXk3U0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗИМЕанΡРΘяοФГЙΩΩ():
    value = 907600
    if len('') > 0:
        _dead_4037 = 169
        _dead_1172 = 191
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHa0e2gd+vAlbCy2kGC+HzML60s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цчбУТΚеДогйя():
    if 94 * 30 < 0:
        349
        _dead_4157 = 569
    value = 292551
    if len('') > 0:
        862
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3m3f3Vr//EkHQSxzlfHPgINyjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ВΧыимτΕб():
    value = 426966
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JinwYF0t7J5SChqskEevBjYg4lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        330
    return total

def _вйНψρжВй():
    value = 73038
    if False and True:
        _dead_1530 = 214
        796
        _dead_4506 = 407
    text = __import__('base64').b64decode('dXZwS3ZMNG1laFFKMGZOd1IxdWc=').decode('utf-8')
    total = value + len(text)
    return total

def _βхΙяжгιмэκΗМзтαа():
    value = 146482
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjzybH1trZA3FFvzxEW0P3EFtUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΤркЯчСаΚцЗВЪζ():
    if 82 * 81 < 0:
        pass
        pass
        pass
    value = 738490
    text = __import__('base64').b64decode('Z2pNVmwxRm9IQ3d4cEVJWVNCSVM=').decode('utf-8')
    total = value + len(text)
    if 90 * 33 < 0:
        pass
    return total

def _τσАРстκΖφзх():
    value = 555313
    text = __import__('base64').b64decode('VmdZUTU5YjB2NWFmYXFVNHJuSHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _κыПωοπчжΕиЭφоэηЬ():
    value = 637418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHjXaUUKrJwrHDWlzH+BExI45Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6979 = 756
    total = value + len(text)
    if False and True:
        138
        pass
    return total

def _ЧςъаЮηξΦояμфя():
    value = 82509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ewu2R0gj0706GwaFyVOWZCh45jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иЩЧцЧЮθРЪΞ():
    value = 67895
    text = __import__('base64').b64decode('ZmhVUjZiODRWTEFzTDZfbkNtV3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΕуαЪошσуνσЦЧщдГ():
    value = 573240
    text = __import__('base64').b64decode('UHQwcXhWT2pKWVJ6anZxMW1LWTM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        269
        pass
    return total

def _ПЕЬΧФМГЮиЩΤ():
    value = 307030
    text = __import__('base64').b64decode('ak5hRThGZ0psbW5YZUZTWWlYU0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪЕшςТκдΦпю():
    value = 769808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw3tUQQV/4pQKT7x2nKAZxU60UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νеΞуΥЕЙш():
    value = 369816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCjJOHoU1qMEEFr1+GeabAs9620='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШονфΦΝзАΩзщЪ():
    value = 922904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTn3ZAVo7vA2Cwir0AK5MQYD/kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СθβΖГΦιЛΞ():
    value = 177716
    text = __import__('base64').b64decode('Sm9oYUVnZHN5QmZrUExCNjV2RXA=').decode('utf-8')
    if len('') > 0:
        719
        555
    total = value + len(text)
    return total

def _θΨЬТсΤСΔЛγРЛщκгΜ():
    value = 799556
    text = __import__('base64').b64decode('Zm5BR0F5NDV1d2x3aFlLaVEyQnM=').decode('utf-8')
    if 18 * 62 < 0:
        447
        pass
    total = value + len(text)
    return total

def _ΣυсφΕщжγЖδЮΧ():
    value = 628061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An/3Vl8h1JhRDQOhkH2AEAYD9ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤСЪψΟиφСΝτΗΚЛΩ():
    value = 816794
    text = __import__('base64').b64decode('cTY3Qmc3QWNXYmhia0tLVXg0VGo=').decode('utf-8')
    if len('') > 0:
        129
    total = value + len(text)
    if 56 * 31 < 0:
        _dead_1107 = 209
        pass
        168
    return total

def _оΛПюыакОйсРΨ():
    value = 168299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHzHT1No640zFTD6m0S+ESM94UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _льΕρыεзζσ():
    value = 241759
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBjDbUsy05hXOx6g+QfIbS4Dy3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        597
    return total

def _улХЙΑтχιЦУЬ():
    if len('') > 0:
        pass
    value = 689051
    text = __import__('base64').b64decode('c082bVRwQkRIS1lTMlNCUDZyRmI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣуθтБпяγΥмхδДΕщ():
    value = 96330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FB/lR1Q+y5s7FimczgCSYTEuznc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дφмшпχгьфΣГЩыΨВ():
    value = 746353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRy0SEQO5K8BHB6knXXCHXN/0Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 61 < 0:
        _dead_4757 = 17
    total = value + len(text)
    return total

def _ЪусΕФЪчРμπрмЙИТ():
    if False and True:
        _dead_4614 = 205
    value = 499108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwbSRnsGp601KR6E7mCDHQEQ7Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        480
        24
    return total

def _ΣΥъгνωΠвμУОоΡγ():
    if False and True:
        _dead_9865 = 610
        _dead_5715 = 262
        pass
    value = 892699
    text = __import__('base64').b64decode('THN1VUtIeU94Y1dmZThYZmszcXE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2503 = 307
        62
        _dead_5475 = 661
    return total

def _еΕΗегиЩζсНзиАФ():
    value = 36013
    text = __import__('base64').b64decode('a3VRU1pPank3cWc2cjAxMzIzMDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΘνВъРΝΠΓ():
    value = 688983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDznaH48yKlbNlfz7kSAMXYC13Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_8527 = 411
    return total

def _κюιсЙηЩЭΛЙ():
    if False and True:
        _dead_2904 = 358
        pass
        pass
    value = 136090
    text = __import__('base64').b64decode('aER0dFRZSnd4dU1wdUJMdlBPVDI=').decode('utf-8')
    total = value + len(text)
    return total

def _αКшЙΕРΤνПйκ():
    if False and True:
        240
        _dead_9510 = 337
        pass
    value = 348124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXfTPgBp3I9WHhmb+1u6GDwQ0FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        198
        41
    total = value + len(text)
    return total

def _ЧΧЭΒДЕБΚЗΡсΘ():
    if 79 * 13 < 0:
        _dead_4731 = 899
        _dead_2645 = 469
        _dead_4565 = 432
    value = 6821
    text = __import__('base64').b64decode('Y01lN3VVMjlXY1pZUENmcXlPd1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ξЖяЕЖкЮΝЩΩО():
    value = 292479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBa0N3Qx+YM5MiKp32XAECA5x1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЖοΖКрξьъΟλрК():
    value = 937046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjnddAIV34JaCQy65FOlMiZ29mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        396
    total = value + len(text)
    if False and True:
        _dead_7669 = 636
        _dead_1497 = 951
        672
    return total

def _еЧмΨАΖКФΧГРВζьгц():
    value = 954327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Myn2NmY/zalTOQmV4Hy2ODck9Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МОеэЕчИъ():
    value = 510169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTzxZ3gQ1YoEGxiNyn21Ji0HvWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОйПЕςПрПхцΗжζод():
    value = 629332
    text = __import__('base64').b64decode('d1dBanMwenpXUUJXcjE4TWw4OHA=').decode('utf-8')
    total = value + len(text)
    return total

def _УЦΞуЬΛкРξΕР():
    value = 808108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAvrVH8R8vw7CxX7xEWIMnN/9T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кЫтΚюδхВйОМ():
    value = 955173
    if 32 * 82 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxjrQGQA0b03EV6p8maIPzZ451Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝвИВяΓЖΩΟΧСвдХ():
    value = 234199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCbDXV4I0pkNbVa2wVGjAQZ90G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ЖщсьСΡρεб():
    value = 407480
    text = __import__('base64').b64decode('UDNwbTZmUmdad1A1cFhKVHJrRHY=').decode('utf-8')
    total = value + len(text)
    return total

def _рЗдэυнЪλΒε():
    if 37 * 53 < 0:
        _dead_6655 = 106
        470
    value = 556212
    if False and True:
        pass
        _dead_2916 = 235
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiDmVlUIrronb1um3nG4Enw41kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1472 = 285
        _dead_3858 = 401
    return total

def _τχκωСΥРФьл():
    value = 958182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAjdZUgAq7xUGRn6xlSjJjUJskU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΒпфМΞπВчεΔшзЭП():
    value = 939141
    text = __import__('base64').b64decode('THU0YzhNaTVXcnRYM2xjWDdmMjk=').decode('utf-8')
    total = value + len(text)
    if 29 * 100 < 0:
        pass
        pass
        635
    return total

def _ζΟущляχтσйезЖО():
    value = 404269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyHXaVcbpoYyCiqmwGCfIHMGtlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σμΑОфΖТЦПκлδЕσЩ():
    value = 555602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxXKSn8e64suaiuV/m65BnAr11c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΠοоСΠωь():
    value = 325148
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M33HX0g285omDyS0+w65Gyl952Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        36
        388
    total = value + len(text)
    if 21 * 23 < 0:
        pass
    return total

def _ДкЖРβΓлбжΣΒЧЮ():
    value = 342850
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnvxWHceq/9TPACVmHmCJDE67j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θгЖДωΚΞφΘъΖВ():
    if False and True:
        _dead_3050 = 822
        _dead_7086 = 236
    value = 52385
    if len('') > 0:
        _dead_7763 = 285
    text = __import__('base64').b64decode('d1RGcWpiUUpGTWhaMkQxOW5LbnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ИзΑиЖВоμц():
    value = 953820
    if False and True:
        889
        557
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxjNekg36Iw2EgGi+ES9DgMa8kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        575
    return total

def _ΡΧΘчУΡΤиΙтсзΥχΟ():
    value = 966640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InfxRHgS7fpVAzz1z3qFOD0gsTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СωгЮΦоνИΞΔАΓπж():
    value = 199838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FynOXEQcy5EFFDyI6lSCZhYCxT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кοтвэсνΤмДЗЮФβя():
    if 98 * 9 < 0:
        pass
        pass
    value = 97812
    text = __import__('base64').b64decode('VXBDcnU3d29EYXo0VHBiSHFEbGk=').decode('utf-8')
    total = value + len(text)
    return total

def _αςщΨЗГЩг():
    value = 324918
    text = __import__('base64').b64decode('QlJlWFdNdnBpVVhFaHJ5UUlIcHM=').decode('utf-8')
    if 27 * 86 < 0:
        208
        pass
        577
    total = value + len(text)
    return total

def _χΡΚΖхяΔυАγяΒлоΨл():
    value = 550551
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSHia10e345WIASZ+AS5Ow8mxzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΗνнρρΧцЩП():
    value = 620340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTfxPAMMracgAiu60g+oHBw48kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣχΩчΥвхжът():
    if len('') > 0:
        pass
        pass
        _dead_1498 = 634
    value = 789809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhX+fXY96Pk5Ywyu3mykDSIQyWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        237
    return total

def _ΞρЖнεВωбΧΡЩЩ():
    value = 667615
    text = __import__('base64').b64decode('V2FZN2J2c3hBeGk3eDJtTUlCcnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ηφΗηρбрТТΚΟ():
    value = 366494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgXreX8dqpJbawH672fGIAkdyj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βЬЛУΕДΜΨЖл():
    value = 895834
    if False and True:
        pass
        8
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CT7ASWlu24sXGzCz71+cFyED9GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        47
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΔΘХΜПΟψгЫ():
    if 65 * 99 < 0:
        _dead_6122 = 318
        pass
        272
    value = 488880
    text = __import__('base64').b64decode('bnVRSWdjbGJDVlhpNEtXaGNob3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛДИΔнЛПКΖхЫ():
    if 72 * 44 < 0:
        pass
        pass
    value = 285468
    text = __import__('base64').b64decode('eGtrc1ZONE04ekR0eDlSQTZfbFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ςвЫаИЫΙυъΟэσЮΩΡя():
    value = 146338
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACXMYHsG3KQOFAOR41e7C3Q93T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡθБШъфЭоъшЮ():
    value = 345561
    text = __import__('base64').b64decode('bW5GblROZ3FCUHVSZ0NDd0tDNUU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        607
        _dead_4126 = 116
        _dead_8726 = 645
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 11 * 82 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()