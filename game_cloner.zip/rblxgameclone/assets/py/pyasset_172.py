#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _αОλΖιгωΝАЖβичЬξЭ():
    if len('') > 0:
        pass
    value = 692342
    text = __import__('base64').b64decode('R1FEcmMyZlVucTJIVzB0V3Q0V3A=').decode('utf-8')
    if len('') > 0:
        _dead_2295 = 864
    total = value + len(text)
    return total

def _жбγβΔдυМЦΔκДΟ():
    value = 781497
    text = __import__('base64').b64decode('UElYTXIxaG02NlBRbjJ6M3hDZGY=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _κоΔпафφαчγНя():
    if False and True:
        pass
        658
    value = 521469
    text = __import__('base64').b64decode('YXZBQkNiT2FvNlFSOFBEZ0JxTnA=').decode('utf-8')
    total = value + len(text)
    if 80 * 91 < 0:
        980
    return total

def _ЕμЫЪюδгΧТ():
    value = 556637
    text = __import__('base64').b64decode('dE1yQllGemplVVk1Qmo0WER0VkE=').decode('utf-8')
    total = value + len(text)
    return total

def _МΗВДфΗπΗоΤΗпШ():
    value = 617420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwDIe1pq/aUlKR730V+CIQcC8Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьНжΑЯΧзιА():
    if False and True:
        402
        pass
    value = 147106
    if False and True:
        _dead_4570 = 82
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyLAPgM8/4ksOQz28EaxGAse9zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9131 = 502
        _dead_3010 = 819
        _dead_6331 = 392
    return total

def _ΜΞдтΖβфΛ():
    value = 369726
    text = __import__('base64').b64decode('dV9BY1FxVURvMUs4TVFMemtlVkk=').decode('utf-8')
    if len('') > 0:
        343
        66
    total = value + len(text)
    return total

def _щΡζццΓуУс():
    value = 125070
    text = __import__('base64').b64decode('ZWs5ZkNuUWdSeEVEOG9KTjVvbVg=').decode('utf-8')
    total = value + len(text)
    return total

def _δЕΘπЛюΨтυΞΩпφд():
    if False and True:
        189
        686
        pass
    value = 626479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTbRbwcp6pAEPRn64AKxECcI7mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яЛЯкэУΧΞΩчΒΞИРв():
    value = 499901
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzbnXVZs6/owbA610n6HOj0Ew3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓССΡЛΩжНΙЖПΕ():
    value = 934478
    if False and True:
        _dead_8819 = 519
        _dead_9530 = 177
        _dead_9379 = 44
    text = __import__('base64').b64decode('aGk3aUpoZFh5OUlsc1kzWjN2aFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔзйσЕжОНψψЬИ():
    value = 999963
    text = __import__('base64').b64decode('andadWpRZ3NpbEd0Y1ZNOTBhNXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЩУΛЧТΑΜνΠфΨъВΦ():
    value = 241323
    if 94 * 90 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eg7CYnYDrYMCbFiIxmmCLSAH52o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρОНячЭКΟЭα():
    value = 646799
    if 65 * 64 < 0:
        340
        518
    text = __import__('base64').b64decode('QWlLNDhlejBsQ29oZlFVZENSRDA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЦкХИΣμиεчьИΙπ():
    value = 484681
    if False and True:
        24
        _dead_5134 = 987
    text = __import__('base64').b64decode('bzZUeEJsVEpZTDJmX0NONmNiNGc=').decode('utf-8')
    if 32 * 49 < 0:
        _dead_5357 = 26
        pass
        _dead_7252 = 597
    total = value + len(text)
    return total

def _дпΛХъθвλ():
    value = 632204
    text = __import__('base64').b64decode('SVBUaHJSdVdRTVd5RUNVUjJ0NE0=').decode('utf-8')
    total = value + len(text)
    return total

def _МрЕЯΞЦαОрΦσΓ():
    value = 818194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQy3YQIP7KkqHSGunXyxEyoB40o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚζРωМГΑЯΤДоςшΘжρ():
    value = 881739
    text = __import__('base64').b64decode('bFBXYktpZl8zSkFmd1F2M1Nfdkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ОНЕΛΑЫПν():
    if False and True:
        pass
        _dead_2782 = 659
        pass
    value = 475894
    if 58 * 71 < 0:
        _dead_3825 = 942
    text = __import__('base64').b64decode('QlBpN1hIUXpDZzluSUJvaWw5cVg=').decode('utf-8')
    total = value + len(text)
    if 44 * 17 < 0:
        343
        pass
        pass
    return total

def _ЪНймκяйΣφадИуΦΕ():
    value = 573830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dya0ZUIf9a4mGyKR4FihAx8s7Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζГСЫκэКΙАΕлвзφ():
    if len('') > 0:
        462
        _dead_3961 = 507
    value = 678868
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESezdlcP1a4SERyawHmmMiAm9GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5645 = 792
        904
    total = value + len(text)
    if 49 * 39 < 0:
        pass
        pass
    return total

def _чνКφЕΤЫл():
    if 8 * 59 < 0:
        pass
        pass
    value = 517551
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Awv9S14t+ZcFGxyh/nmIZhMsyzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΓхλюоφΩυΠ():
    value = 52112
    text = __import__('base64').b64decode('UVdQV0VMRnRaUlBNa3FUZXZ4T3o=').decode('utf-8')
    if 93 * 44 < 0:
        pass
        201
        _dead_4610 = 90
    total = value + len(text)
    return total

def _ОдхкЩсыфρЛС():
    value = 71127
    text = __import__('base64').b64decode('d290RDBCRkpaTUxvbEk5NG9xTDU=').decode('utf-8')
    total = value + len(text)
    return total

def _δυθψΛДβяΞηЖΝγБмх():
    value = 471067
    if len('') > 0:
        _dead_9427 = 443
        316
        _dead_9636 = 991
    text = __import__('base64').b64decode('WmV1bGF0WjZ4ejBUTVN5UVJOSU4=').decode('utf-8')
    total = value + len(text)
    return total

def _НθвνхмЖκΨХ():
    value = 424301
    if len('') > 0:
        pass
        414
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDr3SEESqr8EG1f6ngekIjUpznY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 38 * 23 < 0:
        _dead_1957 = 186
    return total

def _ЧγзУАьψΚΗзψΧΖΚ():
    if len('') > 0:
        _dead_7208 = 230
        pass
        _dead_1207 = 168
    value = 749581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgjMSWQf1Jw7CDawzE/JYCA8tDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΡЕяМμЪФб():
    if 80 * 82 < 0:
        197
        pass
        _dead_6360 = 5
    value = 805457
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBbFZ2c+xqJVHh2W4wG4LQI2w0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γЖЯдμΛτтщΩлоαγю():
    value = 499113
    if len('') > 0:
        _dead_2489 = 773
        pass
        _dead_1472 = 955
    text = __import__('base64').b64decode('TDJFN0JsN2d6ZWR0eUN0c3NWMkI=').decode('utf-8')
    if len('') > 0:
        _dead_7851 = 112
        pass
    total = value + len(text)
    if False and True:
        _dead_2556 = 86
    return total

def _ыχυΞлЫУюν():
    value = 573099
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQfPY1cTppcSPB2k4XmdLncIyGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςрΙικπУЯαΥЭыДЖэх():
    value = 367290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRDdSQEB1bIFb1eP2XWcbDR5sGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5442 = 575
        _dead_7290 = 334
        pass
    total = value + len(text)
    return total

def _ΞΨΥκζЦΜЪч():
    value = 338753
    text = __import__('base64').b64decode('VlFqcDd0M3N2NHdlU1FzMncxbjE=').decode('utf-8')
    total = value + len(text)
    return total

def _πТκнΕБσИЯΖФИЖπО():
    value = 295401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRfsWHMXrLwBEiaU/kSFZxZ5z0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9056 = 982
        pass
        811
    total = value + len(text)
    return total

def _ΝХεдяьКΓΣΨΑΓΑлЗα():
    if len('') > 0:
        pass
    value = 295776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgTGQlUp255SNg2Km2ClJykI3lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΗθкФлεχНΥΕЮшХψΖ():
    value = 424797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXjXfkIgrpE8EzmLy0+GJzYZ7G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πЬχеЗйνФжΖΦНαΜΖ():
    value = 879165
    if len('') > 0:
        _dead_9374 = 561
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDbxfgQS9KFTKzuk31y7ECkn/l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        321
        pass
    total = value + len(text)
    if len('') > 0:
        526
    return total

def _ΕΚςКμκгсЪИНγЛ():
    value = 566447
    if len('') > 0:
        _dead_5238 = 986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBW3RV5py71QLST35U7IGg0a7ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6039 = 798
    total = value + len(text)
    if 57 * 64 < 0:
        pass
        302
        pass
    return total

def _ηЪΓιтΘбщ():
    value = 869280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATblfEY+9PEZPCiZmVuDYzICyXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _члСεΘοΛΝжАъЩЪ():
    if 94 * 95 < 0:
        _dead_7041 = 611
    value = 318449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MA3MRH0hxvsREw7752aFYCwM3EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъВЪпζВИΤсιΔΤΟΛλ():
    value = 463792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAnUbVQI8JkRIiew4lCJAg8Htkg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 90 * 82 < 0:
        pass
        442
        _dead_3842 = 161
    return total

def _ΞζШиШУΝΒ():
    value = 865439
    text = __import__('base64').b64decode('RTl3X2VFc2x2RWEzQU5NZzVmdzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЪσЪпЯβΑΦτΚъхΤЙИ():
    value = 108337
    if 46 * 37 < 0:
        812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh71eXYBxrAuAwSFkQOJMDcd90U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        579
    total = value + len(text)
    return total

def _юСЖρАцйиΕсψρЕг():
    value = 916685
    text = __import__('base64').b64decode('QWhvZGtWd25VbUpEY0t2TUVGRUs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5904 = 39
    return total

def _жглРюΩΚсЙΣиοΤБ():
    if 76 * 47 < 0:
        pass
        pass
    value = 255363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mzm2WUkhqowzAAelkHeUNTMD728='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        430
    total = value + len(text)
    return total

def _ЙΒιΛΣΛрИξψληΦЛ():
    value = 610403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQPLZnVo3KMULj+p4meVJC4N41Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        697
        _dead_1207 = 717
        772
    return total

def _ΘλдшσΓуσЩΠыυ():
    value = 77592
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTvsaEYs6pczKSeT+VqTASIg6lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иДοнОβГдбχъе():
    value = 321006
    if len('') > 0:
        _dead_8431 = 995
    text = __import__('base64').b64decode('RVBXZ2hPVVBWejNlNk82VTA2VHc=').decode('utf-8')
    total = value + len(text)
    return total

def _БυжьГκЖΙМш():
    value = 944840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSe3SEYcz70AMVmG31+qNSIg6Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕцξсГЬΜолмΑΡущ():
    if len('') > 0:
        169
        35
        433
    value = 36007
    if False and True:
        pass
    text = __import__('base64').b64decode('cnhNemtCaTczSzl2RkJTWmZsZnI=').decode('utf-8')
    total = value + len(text)
    return total

def _рΡгпНσюеЭΛΥρχиψ():
    value = 754382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy3oRH8fqPABOCf18XOGGnY80j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯυШτφъоςаъОΠ():
    value = 184287
    if 66 * 13 < 0:
        30
        _dead_3624 = 674
        843
    text = __import__('base64').b64decode('RkhOUzNGXzNKWldBV202ckpTUGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ιЬАвжйывΦЧоΛ():
    if False and True:
        518
    value = 851976
    text = __import__('base64').b64decode('U3V5MWtrc1d2eHVwVFNDZUxHUUo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5315 = 371
    return total

def _ΩΡчφьмучΖΔ():
    value = 141687
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx7BbEsr550tI1e0nmy7YDI+4ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИαΛΒуСУэФ():
    value = 918692
    text = __import__('base64').b64decode('bTlac2RJczhkcnV3amEwUmJZMjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _θХУωλΑВц():
    value = 33915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MA28SwAQ8ZkaDRqo5HKDZwc441o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛУЦхКцзЬ():
    if len('') > 0:
        331
        pass
        642
    value = 231579
    if False and True:
        _dead_2109 = 255
        pass
    text = __import__('base64').b64decode('dXd0TGU5YnY4S0J5cUkzVVhydm0=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if 97 * 92 < 0:
        pass
        _dead_3516 = 49
    return total

def _ΘφΟφгХθθзЖЦь():
    value = 287799
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXnRXEQOzLwyPSuzwGOEHXIDsmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΡъЗκΙЕζΖιΚΑ():
    if False and True:
        965
        601
    value = 38627
    if False and True:
        386
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh7RWHUd3/AWFD2bn3+EJzd54WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΕдΤΣΘюоцэяμ():
    value = 105249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDWySmc7pow6Iyaix3GXAhUKzWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΖηмИΘМэКГ():
    value = 502211
    if False and True:
        pass
    text = __import__('base64').b64decode('Ukx6QXJKTmRVaFdkYTF0OFJxaDE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        664
    return total

def _фЕеΩφАСИΧ():
    if False and True:
        12
        348
    value = 505417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwqwbHgQwapaKgT6y3SdIHIe80I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        322
        _dead_1827 = 284
    total = value + len(text)
    return total

def _ΣκΦщлЯиАкЩхУо():
    value = 787049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSv+XmMN3K42PzuwnmHGIAcD4mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7967 = 952
        pass
    total = value + len(text)
    return total

def _фСФρφТФЫй():
    value = 845554
    text = __import__('base64').b64decode('ZDBmclg4d3VlMHZqVDRBN1FJNlo=').decode('utf-8')
    total = value + len(text)
    return total

def _αΩДьйьяЩРкЪФгжЗτ():
    value = 564082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwfhdG4v5L8TFTeByXW3Hx0a43o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЩΧдΩΝЖφБЯΔηДχσ():
    value = 47263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh/mXAJq56RXKSun8ESxIQAjw2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        195
        pass
    total = value + len(text)
    return total

def _ΔθрΤЙΔяΞλμххмδΠ():
    value = 934058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AATlRFgwpoMSY1qX+GSyMj1/8Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξлφЧоцДвΧЦюнΛРА():
    value = 684565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjfeQQcP6ppRYgyExkGHbCMu12A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘиωПΘПκΨфЯΨσΔςΠ():
    if len('') > 0:
        546
        330
        590
    value = 479500
    if 7 * 76 < 0:
        _dead_2445 = 662
        _dead_2430 = 314
        103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh28Vn4e3b0BYi6E/nWjIwsG7Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юччУЭΧЛΩФлθι():
    value = 517815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD/teQAy7v9TKQGN/lCVEws9zEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λσΡбгНШЛθΛ():
    value = 771113
    text = __import__('base64').b64decode('ZmVpRVcyOGlfdGJXeUgzMlVlZTA=').decode('utf-8')
    total = value + len(text)
    return total

def _οπΛςьЪОςξ():
    if False and True:
        _dead_9961 = 675
    value = 388830
    text = __import__('base64').b64decode('blFPR2dwRHFRdkt2ZDRiQ0hvdVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ξЩйнопТιПи():
    value = 646298
    text = __import__('base64').b64decode('WVRZbTQ0QzRHRmJEd1VLek41XzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣςЕξфеεЖληуΛΣνΛΣ():
    value = 964038
    text = __import__('base64').b64decode('VDExaDNiVmlYN3pybzBCa01URE8=').decode('utf-8')
    if 6 * 92 < 0:
        716
        pass
    total = value + len(text)
    return total

def _ΜшИюЧЭξЭεиФΜ():
    value = 986152
    text = __import__('base64').b64decode('aUhWWjlHR21RUmp5NV9GSEllcXQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        405
        pass
        pass
    return total

def _εΥΕЦυωзΞкяИωεЛΣ():
    value = 229147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX2zSV491ZlUCV2P5mXAIgx8y2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7221 = 405
    return total

def _эΘξЧΓξунЧХьЗг():
    if 74 * 38 < 0:
        pass
        pass
        pass
    value = 509175
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AinLfEEK1rkHFyeP42OCYRIo9G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЬБΞПОяеОнюс():
    value = 448018
    text = __import__('base64').b64decode('b2hUa0hTc241UDh4cWtnZU5EMTU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        468
        645
    return total

def _ΓψЩΤфςψцκв():
    if 21 * 64 < 0:
        862
        _dead_3444 = 480
        pass
    value = 390640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxjGdloN9p0vLF6q5EeXbA0X/kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        327
        pass
        100
    return total

def _ΧаοаЫцθσσοкЯгИфК():
    value = 965008
    if len('') > 0:
        _dead_4541 = 365
    text = __import__('base64').b64decode('REVaaERyZ2t1akZ6YzF2eWpnN1M=').decode('utf-8')
    if len('') > 0:
        _dead_1359 = 769
        pass
        215
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΣχΚιиΙЧшΣЬБсЪаδм():
    value = 272869
    text = __import__('base64').b64decode('TTVjcG1fUjRSSUlFR1lpMndRYzY=').decode('utf-8')
    if False and True:
        pass
        _dead_6838 = 404
    total = value + len(text)
    return total

def _ывυδσεьζЭло():
    value = 916445
    if len('') > 0:
        _dead_9863 = 947
        445
    text = __import__('base64').b64decode('enNIbmdFc0Z3Umd1VVRyQWo0X2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЙЪΠЮΕωπΣΜО():
    value = 100830
    text = __import__('base64').b64decode('VENQNkMyaG9wQmw1THVOZTNvSHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΠΤΒφйοимΗεЪнΦι():
    value = 893460
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MizcVkVrq64ULAKP/gaWMikn12Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьУОηψЙΦДэμπθ():
    if False and True:
        pass
        _dead_4539 = 231
    value = 744673
    text = __import__('base64').b64decode('ZnY4cVk4MHBLWXBldlFicnFNbkE=').decode('utf-8')
    total = value + len(text)
    if 83 * 88 < 0:
        _dead_2725 = 443
        169
    return total

def _ΘзвδΗйτηНпЕδиβΗ():
    value = 559032
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hxq9SEE7z4EuYjic8F+TC3wD4Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 78 < 0:
        _dead_3246 = 249
        226
        _dead_6782 = 195
    total = value + len(text)
    if len('') > 0:
        pass
        844
    return total

def _ΔМДΚТыУдД():
    value = 884809
    text = __import__('base64').b64decode('SVEzQ0F1MTd0Z005d0pDTF8ydFo=').decode('utf-8')
    if False and True:
        939
        pass
        991
    total = value + len(text)
    return total

def _УЪчККШпйБχ():
    if 58 * 4 < 0:
        pass
    value = 40779
    if len('') > 0:
        _dead_3023 = 620
        _dead_8807 = 666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhfNQXZs8v4qKym37nGWZQ86vEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        139
    total = value + len(text)
    return total

def _ОРгШΣДΠκнΦфΑΒτ():
    value = 203008
    if 18 * 59 < 0:
        _dead_4334 = 708
        pass
        _dead_8509 = 87
    text = __import__('base64').b64decode('YXZRSkdvcFltMXVlVnFJMEIzUUs=').decode('utf-8')
    total = value + len(text)
    return total

def _оΗΜУшΓБЧΨΔ():
    value = 608924
    text = __import__('base64').b64decode('S0VmOXZJYjFuOTNIN0I5UWlDTUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ГεψШτЛКΨωщ():
    if False and True:
        871
    value = 783927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQC1ZFhh25cZHh6162S8JnUi13Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ълΑВалЬΗПзНΡχ():
    value = 502654
    text = __import__('base64').b64decode('bmt2UG9Qa1Z1TWNGZlBnNHMyVzI=').decode('utf-8')
    total = value + len(text)
    return total

def _βШΓяхςΦΘΣΞрщΣжЗ():
    if 30 * 31 < 0:
        pass
        pass
        pass
    value = 484309
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3u2YlUJ9fgPESOEmkefIzM950c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥνΒτδЧΘΔпКъφΑ():
    value = 777830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBj3Q1sbz5kxKTWKmUa8ZzB/4Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 73 < 0:
        _dead_1837 = 780
    total = value + len(text)
    return total

def _ΓωяκΖйВяνПυИ():
    value = 183010
    text = __import__('base64').b64decode('SkUyejdPaGxiM3ZPTjlqYkZtbDI=').decode('utf-8')
    total = value + len(text)
    return total

def _αсУПЖМφщθεлθΘЩΣψ():
    value = 32920
    text = __import__('base64').b64decode('dko5azVDeUpybXFhdjFUR3hwRU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ъφΙЭяηЭщξЖРο():
    value = 285851
    text = __import__('base64').b64decode('Vmo5amprQkwyS2UzdkJsR09va2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ρтλΞДЦτбАаКν():
    if 37 * 35 < 0:
        pass
        471
    value = 239704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICLTSH8z1IpUaQa38EyAOiwX6mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГηδюβрΥχЙλδЯЕΘ():
    if 57 * 53 < 0:
        _dead_8576 = 46
    value = 697797
    if False and True:
        _dead_3733 = 835
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyWzOUkrrfBTG1aAxFCTIn05sUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_9285 = 22
    total = value + len(text)
    return total

def _ΙαΡΧΤЭРЭНЪΧΧжσчη():
    value = 172334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjeyXEhtqoJWaACyz3WULBoq8G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ХвШΟжηСπиΧггιЯ():
    if len('') > 0:
        pass
        pass
        pass
    value = 790856
    if False and True:
        _dead_5272 = 577
        _dead_8943 = 544
        pass
    text = __import__('base64').b64decode('VmpsbUYzSG9JT1VScktlakFJMXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΗдμлНΝΚβхе():
    value = 299884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgnqV1Vhz/grDl+o5UOWYAAY9kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΨΓκγΞХЩСаυрЕыХ():
    value = 85484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCrqNwcr+54vCgKw8G+9Z3Y51GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭωΑАπΡжчЦх():
    value = 55079
    text = __import__('base64').b64decode('ZTRJWnpjWFpGZFNhdW5PTndSTkQ=').decode('utf-8')
    if False and True:
        33
        pass
        503
    total = value + len(text)
    return total

def _рαυьЪжцфθФ():
    value = 1480
    if False and True:
        _dead_4269 = 241
        470
    text = __import__('base64').b64decode('cGttVjFoRU90cmFLS3FUSkQ5aXc=').decode('utf-8')
    if 47 * 75 < 0:
        _dead_7672 = 366
        _dead_3774 = 766
        pass
    total = value + len(text)
    return total

def _УпОНнЦтΤрχβКшГ():
    value = 738889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mw7VUQdh/LsMEACg/ACULjB4wUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΝДφрсαπ():
    value = 767433
    text = __import__('base64').b64decode('alZ6VW5ET0ppU1ZhaXo0eEkzdTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝκсΥУΧзεЫΠρмΕΝΟ():
    value = 888185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXvgYnQS8YpTaD6R0U6YMTMV9Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЮψвнΒлВЫζвГГЖЖС():
    value = 472429
    text = __import__('base64').b64decode('am9yYzNaVXZxdWxydWtaNVdNS2k=').decode('utf-8')
    if len('') > 0:
        _dead_1351 = 145
    total = value + len(text)
    return total

def _ΚφачОУιХЩζκаеθ():
    if False and True:
        788
    value = 620161
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MC7gN3sAyo8yCxeIz2OyPigpyX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝЦΜоАФДьρΠЙяΟЙч():
    value = 358322
    if 20 * 40 < 0:
        _dead_5108 = 933
        _dead_7058 = 290
    text = __import__('base64').b64decode('RWJCWk9YQnBEMzB5U29QX3lFaWc=').decode('utf-8')
    total = value + len(text)
    return total

def _тΩтΟΕΩШΚΩдξΥТ():
    value = 936547
    if len('') > 0:
        pass
        648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ki3tSAQSwYABIzav+V22IXAYs0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 77 * 25 < 0:
        927
        250
        559
    return total

def _ΧНУζΥСМΣц():
    if len('') > 0:
        _dead_2656 = 480
        pass
    value = 668414
    text = __import__('base64').b64decode('aUhQUzAyUUViUnRVVGNiZkNQT0w=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЬВΗρХΚγдкΣΟкΤЦ():
    value = 224838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCbpaGA4+YslLwKKnG6XABYD/Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔнοЧТΔАНжк():
    if 22 * 80 < 0:
        930
        894
        _dead_9422 = 578
    value = 444458
    text = __import__('base64').b64decode('TjhtbUdJRmlRYXpQeklIUTBjQWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓσЭВУγУΩМαΡйытЙГ():
    value = 813971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kyq1Z3YMqZo8HyC6m1eoMw0AvWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мДΗςПЛενΒЦж():
    value = 858021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx+wa1cK8ok5NC2NnXmzJ3EC4V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьКцкиХΕвΤσ():
    value = 791821
    if 83 * 68 < 0:
        _dead_8865 = 55
        954
    text = __import__('base64').b64decode('SmRvbHBkYzI4dkZLVExGWm1pOHo=').decode('utf-8')
    if 28 * 98 < 0:
        275
    total = value + len(text)
    return total

def _юΥσшдЙшйА():
    value = 611580
    if 6 * 60 < 0:
        pass
        _dead_1499 = 710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgL3bQAhyoYwKFitzViCBxoO20M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΑШσΩхЭοπξΤ():
    value = 271973
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjrUT3sa9r4VIDyz4mK8BBUD21g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕэΣйЩпΨгПаэЩ():
    value = 994829
    if 54 * 64 < 0:
        _dead_2004 = 824
        797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHrUPkRp3aULFi6BmgWRLAwkz2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 17 * 48 < 0:
        922
    return total

def _ΤШЙэуоэΝυΙБ():
    if False and True:
        854
        pass
    value = 157917
    if False and True:
        889
        _dead_1434 = 734
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXnxPngL/bALCgWmzXOUM3AY/Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δКμξдΧεЯ():
    value = 577969
    if False and True:
        pass
        _dead_3014 = 94
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQHCRUIrrJxaMCu1/12xABM4tWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        577
        pass
        29
    total = value + len(text)
    return total

def _ЛΟшσυυΦА():
    value = 751385
    text = __import__('base64').b64decode('SHNlbU43ZzQyX2pRWU15dzZkVkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ААКрεκнς():
    value = 501308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXbBPmdg6rEoPwa7xGe4IAMhwz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7579 = 357
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ЫбсФПΡΨЪаΩк():
    value = 392053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KynvdFkW7I0RbhWo7lWBHDYKvD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αЯфбΠΤΟКнБЯφД():
    value = 705043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnfTSVMt2/EJPRe75Aa3FQMC40s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сφЫоπΗυсУГк():
    value = 844188
    text = __import__('base64').b64decode('U3Y5MHFacGF5eUVZOFRkX2c3ZFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ιηяОΓсрρΜρЛнЩЭ():
    value = 264665
    if 97 * 73 < 0:
        155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwmwQHhs+osFAw2Q4lvCOhAE8jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒйбΣвλΚМ():
    value = 825026
    if False and True:
        _dead_4185 = 660
    text = __import__('base64').b64decode('QnduRVpkVkpTZzdBamNtSHI5S2o=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        317
        _dead_9005 = 416
    return total

def _ЙтУκЩТьτΦЫтЩЮΦоа():
    value = 464537
    if len('') > 0:
        769
        pass
        320
    text = __import__('base64').b64decode('Y010ZWRxZ1RkcUNNV1pIc3Z3T2M=').decode('utf-8')
    total = value + len(text)
    return total

def _эяКОдКΦЫ():
    value = 677723
    text = __import__('base64').b64decode('SlNhYkhxWFJJTXh0cWp4N2RqQm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЬцжΖЬχАХМθЗ():
    value = 114173
    text = __import__('base64').b64decode('cVJVQklGcHVsSklkb3A0dmtrb2I=').decode('utf-8')
    total = value + len(text)
    if False and True:
        833
        646
        903
    return total

def _эГщцΩвωвΦцДв():
    value = 937211
    text = __import__('base64').b64decode('c0dLcDFya2hxSmlibHZ5OFlsaXM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        66
    return total

def _ДлθμЩфТЭэЗκηζςфω():
    value = 242644
    text = __import__('base64').b64decode('QkhUYkUzVEhZNnVNNHptTDhiMEc=').decode('utf-8')
    total = value + len(text)
    return total

def _сμιЦыпфмОуΤΥе():
    value = 127848
    if False and True:
        997
        _dead_1584 = 737
    text = __import__('base64').b64decode('aEFwYUJOWG9TYmNBYkFYSFVHNl8=').decode('utf-8')
    if 12 * 14 < 0:
        _dead_1271 = 622
        _dead_4221 = 404
    total = value + len(text)
    return total

def _ηтΓβзЦΖИЯцкмЕη():
    value = 88664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy7mW1Vhqv8uaTyG/3qKM3UY/WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЯУζюрыЭСНυЛΚчλο():
    value = 927226
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQrSW3M4p6QMNBiS3n/EGRAJ4GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИιΧΤыНΩРЕςы():
    value = 835128
    text = __import__('base64').b64decode('U0lNVGdWR2VJRmRZeDdkNWppV2I=').decode('utf-8')
    total = value + len(text)
    return total

def _εΡΜхσяАΛХйЯπкθ():
    value = 765858
    text = __import__('base64').b64decode('R0k5YmVfZkRncG1PamlPXzNvWXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ыχЙγРМΣЦЬΨΝΖРΕ():
    if False and True:
        209
        305
        _dead_2040 = 493
    value = 612229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBzWPEkDzZ8nPRaG8XWULREV0Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЕαΡфΡпоТνηΣσσъ():
    value = 145104
    if 59 * 28 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBntSFgX9f02L1yp2g60DRwm4zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρлмςΜЗКАΗυШсβш():
    value = 393876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRnvNkU/6vAaCCOz3WW5YXInvUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        380
        _dead_8688 = 732
    return total

def _аТшАЫΕйΕΤяΜньЧΒΜ():
    value = 328065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQvlagM+3fkkYl6uxgOAYB96720='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 39 * 91 < 0:
        pass
        pass
    return total

def _ТлйΛФγκЧ():
    value = 513805
    text = __import__('base64').b64decode('RzduX1hDYVRxX2RFSXdQUExrdHQ=').decode('utf-8')
    if 58 * 17 < 0:
        _dead_8469 = 863
    total = value + len(text)
    return total

def _ФηъвΦλΑΥКТ():
    value = 794144
    text = __import__('base64').b64decode('T1VKdzkwMEtDWVBEaE9nMnh2Y3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ВαмЬАъьйΛУлΟм():
    value = 797182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C33JRXgj/JJaAl+U0XyoHwg+4Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΟΨрΗЕζпγХЫΑДΟΕ():
    value = 800100
    if False and True:
        _dead_9123 = 213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3jgSkcg8Iw2AgCH8lmkOQ5+7mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ййΤябезэВЬлκЖК():
    value = 546649
    text = __import__('base64').b64decode('Q0RxTldLSnpReVE5cUl2bmlLNGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΥπЫθξРОХЪτΘР():
    value = 516264
    text = __import__('base64').b64decode('aFJpY0RjSFk0NXp5RUJQSTNiQ0U=').decode('utf-8')
    total = value + len(text)
    return total

def _итцЫρΦΦУχыИ():
    value = 567200
    if 70 * 78 < 0:
        779
    text = __import__('base64').b64decode('T1hwSTdEX2I5MnNNNEt5VWxtRHA=').decode('utf-8')
    total = value + len(text)
    if 34 * 100 < 0:
        _dead_5382 = 808
        313
    return total

def _ШΥнцЫνκщЙЛω():
    value = 773216
    text = __import__('base64').b64decode('bkZlSlhoNFB1ZVdiTE5ZUTNNSG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ыаΞмтаφμΑ():
    value = 924343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwjCSwkhr6NUDwCw7nO4ZjANsVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Чρзеχккδνънш():
    if 3 * 60 < 0:
        _dead_5744 = 685
    value = 400306
    text = __import__('base64').b64decode('S3FrbU9VWjNoaDhrelExUjN1N2g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        306
        _dead_7500 = 923
    return total

def _ыμΘъдΟυПθΝЕςπше():
    if 11 * 89 < 0:
        _dead_6092 = 484
        27
        pass
    value = 657790
    if 2 * 61 < 0:
        pass
        _dead_7428 = 3
        _dead_2821 = 128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzrCdHIezbsHKAnxzFmCCzZ9/Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓЦΞλщΥгυйπт():
    value = 320726
    text = __import__('base64').b64decode('UGtuVWRlSlpKVFJzUzVxd3I1QUk=').decode('utf-8')
    if 83 * 96 < 0:
        pass
    total = value + len(text)
    return total

def _ψψπτкЭσΕμеΕΣЩ():
    if 36 * 80 < 0:
        pass
        434
        pass
    value = 182602
    if len('') > 0:
        298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATbQbEM72L0tOSuI22S3Mzwc8DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 82 * 78 < 0:
        861
        593
        pass
    total = value + len(text)
    return total

def _ΥзιοЕβкπΝОБΚмτж():
    value = 410959
    text = __import__('base64').b64decode('ZnlXdGRoVWJOXzVXWmV4NTM2cGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜГСЗπКЦψΘкΣυζ():
    value = 735002
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwHDfVYy/I4UaSSTn3KeNQ8u3Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФνоιΦсΚСтαγД():
    value = 154754
    if len('') > 0:
        370
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHjpPEYW1o0abAKX2kaVDgMc518='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 29 < 0:
        163
        231
        _dead_3288 = 647
    total = value + len(text)
    return total

def _ыΘСТуйτΣьЧдЪΓь():
    value = 140113
    text = __import__('base64').b64decode('ZGZPZ1BrblRrV2RqOTZweV9YeWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ГπвΠПξцΝφ():
    if len('') > 0:
        _dead_3942 = 91
        _dead_2108 = 360
        994
    value = 957058
    text = __import__('base64').b64decode('b2tKcGxrc19fMVJ2UmYzbVQxZlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫрωηγУΞηлГφжΦ():
    value = 390272
    text = __import__('base64').b64decode('ajgzc09FbWFmT0M3SVRuZTRVOHg=').decode('utf-8')
    total = value + len(text)
    return total

def _кШξщУΧцΓΩыъЪЯЦАψ():
    value = 458831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3/dbWEdxKIIADyU+2aAEzcssj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨХЭцгζСупщКΙхо():
    value = 143140
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAThfXMS2JEPKz6Q53+TMR83sUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΦРΞэςнΦβαρдШο():
    value = 135888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KznKV1s48ZJRMSiy4W+jNj8dvHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХгкюэαΧσΚΘΖбΒчΓυ():
    value = 448527
    if False and True:
        500
        388
        _dead_6030 = 527
    text = __import__('base64').b64decode('eHYzakM2QU44RmRiOWFaOTBaZ1M=').decode('utf-8')
    if False and True:
        830
    total = value + len(text)
    return total

def _ιηαΤσωяИ():
    value = 932794
    text = __import__('base64').b64decode('QkFOVDNXVUg2c2dVemFURkRxWFE=').decode('utf-8')
    total = value + len(text)
    return total

def _εъхЦГемЦмЗθΑ():
    value = 46978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jj3bYGQV66QoCyyvwgG/Ezd53k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        389
        491
    return total

def _ЙртΧвπЕПЖιβπΩ():
    value = 779701
    text = __import__('base64').b64decode('cXhfSldFdmgxNEVzT0x1ZUZocFk=').decode('utf-8')
    total = value + len(text)
    return total

def _МΩйьМеΒЮΝΞщνКψ():
    value = 580627
    text = __import__('base64').b64decode('VVExU2g3VkhrT2FMU1NrRTNETlY=').decode('utf-8')
    total = value + len(text)
    return total

def _юСδдΦРΥπТЙфπΤюОе():
    value = 650900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiDuZnsq2IsBaFq72HK8LAQZ2zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()