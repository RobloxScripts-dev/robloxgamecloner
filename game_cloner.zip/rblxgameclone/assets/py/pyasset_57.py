#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ιРхчцвΣΙΝΑ():
    value = 145436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSbWV0IA3KwEGTyg0mWWJQ0OvEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        440
        672
    return total

def _РТДЛЩИΥκγЫαΞлЛНГ():
    value = 13597
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxXmaAIg1K4vKBqG5wOSAisGt2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЩΝЦЫΘвΚΡЬД():
    if False and True:
        88
        pass
        pass
    value = 93588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDz1ZnduxKEIawj64XOhETQAx3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нРФЬОАΞддЧлА():
    value = 947642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzXAOFZt1bwWLy27z0CSNg0EtUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 64 * 24 < 0:
        _dead_8228 = 972
    return total

def _эμСЩΡλзδΧЛеЖ():
    value = 379378
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyHWQF876YpbMT+yn2G6DAQd3lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζкσмюРНъκыээΝ():
    value = 363580
    text = __import__('base64').b64decode('TGtUcG1MZ2RfZ1dMdWh1UEI3c3k=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΙΓЛиιΞЩΒШдΙΖк():
    value = 409409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyfcOFwjpr85FB2A0Xu4EiYJzmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΠΝъйИкМδιкΧεδ():
    value = 161737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz3QOQVqr78iaR/zn3W/JisE3UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 48 * 24 < 0:
        _dead_4598 = 610
        291
        _dead_5243 = 679
    return total

def _ΓηьЕшηΔКΤу():
    value = 426071
    if len('') > 0:
        643
        493
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh/HPlA9qqsIFziP/GeDDTUdwzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6386 = 571
        887
        578
    total = value + len(text)
    return total

def _ГшеγΙΨВБгиЖж():
    value = 691535
    text = __import__('base64').b64decode('cldPVjBDbmd5M0VSMXdQNnpaOVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ДТжΣяΞчδ():
    if len('') > 0:
        pass
        pass
        579
    value = 752779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzzhTXlt9aAVEyCZ8XPDHTwu93k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        591
        612
        _dead_5255 = 272
    return total

def _υЭΡΥюΝημвшьГχ():
    value = 276424
    text = __import__('base64').b64decode('YTZ4MGZVbVZUdTczU2tsNDBGMkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЪщкЧσЯгЙНχВνψ():
    value = 357164
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRCzWlQhyfkiYxzxnnK5Bx1+0GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πхγωЮоΣдшыЯжΠ():
    if len('') > 0:
        966
        pass
    value = 762109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR3STwk47foyMxiP5g6nFnYV3Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 70 < 0:
        pass
    return total

def _δПΤΟзνΗюφΝУζ():
    value = 212455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAr9fl0c3KkIbiGK0VGINw8D03g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тУЕФехыХюΑδЧЮ():
    value = 723627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRDHaggJr4MhaF2L71OYYyAhwUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4171 = 153
    total = value + len(text)
    return total

def _ΞφΙΩΖοпнι():
    value = 710373
    if 93 * 9 < 0:
        354
        pass
    text = __import__('base64').b64decode('RWVEVXgzT2pTU1FzNHRSS1NQNWE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ΘТВдЭΝΔЩЯμΙЗε():
    if 6 * 75 < 0:
        _dead_9566 = 926
        _dead_7239 = 88
        _dead_4370 = 306
    value = 911543
    text = __import__('base64').b64decode('ejVpTDRxdWFvdXQ3dm1SWFQwMWM=').decode('utf-8')
    if 40 * 45 < 0:
        pass
        pass
    total = value + len(text)
    if 85 * 69 < 0:
        _dead_2163 = 435
    return total

def _ΓГСΦЗпЭеЙОΚωΛп():
    if False and True:
        _dead_6525 = 862
    value = 707773
    if len('') > 0:
        _dead_8843 = 803
        _dead_2071 = 737
        480
    text = __import__('base64').b64decode('RW5tX2d0a0toSWkwQ2NVZnI4ZFk=').decode('utf-8')
    total = value + len(text)
    return total

def _иηπΘλπΘзθτμюΧψ():
    value = 736181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjbpRERuwflVIzmU2AOCCy44y1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γцсьйЙиьмΚΒммлφ():
    value = 703158
    text = __import__('base64').b64decode('QTNLRlo0cEtLcWtRMVU5X2Z2MnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _мДВЫΟЖΠκР():
    if 8 * 95 < 0:
        54
        pass
        108
    value = 912718
    text = __import__('base64').b64decode('U21pWWVuS09kUnVwU0Voem9yUm4=').decode('utf-8')
    if len('') > 0:
        217
        93
    total = value + len(text)
    return total

def _ЬΧТЯΖьΡМСΤТΥЖДβ():
    value = 292129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyfjbFRuqoIbKzaB+nueICkJ0Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 71 * 59 < 0:
        _dead_5072 = 317
        928
    return total

def _αвΒΑьδΣφж():
    if len('') > 0:
        774
        268
    value = 115159
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyTDWWM86Yo7ER3z937HbBR8wUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΜэβиθΜгЗцбχЫ():
    value = 216382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSX+OVAWp4lUETqR0AOZFw851mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жяηяЗЛсЙΞκЮНΤИ():
    value = 438169
    text = __import__('base64').b64decode('WklUZ0RZNnpySVlxd1FCOW4weUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΨвηфΚδЙ():
    value = 709322
    text = __import__('base64').b64decode('ZEZtQnYxZkkySVhwNGFJeGlhMjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟэΠБСΕлτШψъМвφζУ():
    value = 613235
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTX1PmY1xpgqNjiV3VORPSAet2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μтЧЦУτΛУΒвηЪ():
    value = 523798
    if 97 * 75 < 0:
        pass
    text = __import__('base64').b64decode('bWN6SHcwajFIdEVtWWhJNmo1bzI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ТтыΡψΠΩТΘρЗχΚащЫ():
    value = 178009
    text = __import__('base64').b64decode('ZFg1MzdLMG9JZ3Jzc2RTTHc4U0c=').decode('utf-8')
    total = value + len(text)
    return total

def _σнβνηЕБсμЖμЫ():
    value = 459365
    if 55 * 29 < 0:
        _dead_7974 = 852
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHi2TAEYwb8NIBWI2UeEMyoAykQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑШЧΕХΤγΥФρ():
    value = 726523
    text = __import__('base64').b64decode('THhWRmtpOGl0QXFhUnBSbFFSMTk=').decode('utf-8')
    if 70 * 42 < 0:
        pass
    total = value + len(text)
    if 48 * 78 < 0:
        _dead_7542 = 278
    return total

def _ζдЗЖΑшШοдГщъ():
    value = 106320
    text = __import__('base64').b64decode('RldTdWFDakltWHhJaE5zRG1BSl8=').decode('utf-8')
    if len('') > 0:
        _dead_5284 = 203
    total = value + len(text)
    return total

def _ΓλэЫББφВЯИБшψфШъ():
    value = 157303
    if False and True:
        _dead_1292 = 671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCbtVkE717EEaTCSwkW3Fjwo0lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        116
    total = value + len(text)
    return total

def _ξζΙνбчЖΒΧнчβαДнδ():
    value = 894668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzjOOkgg1IUgOwCV/VeTZwkatmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮθвЕΚЙыбПЩΩνсдц():
    value = 863050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR7GXwMK3ZgTGxm70VmXFxUV6D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑУζаφΘβιз():
    value = 334441
    text = __import__('base64').b64decode('V0h4YUFSNjVKdjkxdGVhZVdGeXg=').decode('utf-8')
    total = value + len(text)
    return total

def _θМΣΧЫкЯΟЛЦαχς():
    value = 675538
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXvWOGE3y4wROCqH61WHAHA50GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сχνΔΕЗψΖЯяαЪ():
    value = 495277
    text = __import__('base64').b64decode('Q1k3NDJHblZzbFJVOUJBNHZmcVA=').decode('utf-8')
    total = value + len(text)
    return total

def _φψюКΞЪαаοσΜΡ():
    value = 149166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NySzNnoo6KYFDBun5GOCYRB31Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫгψШεеГжСααи():
    if 83 * 52 < 0:
        _dead_1086 = 581
        _dead_6533 = 719
        pass
    value = 831574
    text = __import__('base64').b64decode('a29sclRCdnl4U1dSYVczRXNLTmM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        378
        720
        425
    return total

def _асбΤеΤИтчП():
    value = 851149
    text = __import__('base64').b64decode('WWtLZnowNkxkS2JfMGVxQzBvM0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΗΠνΨвЙЕЭΤ():
    value = 497415
    if False and True:
        551
        pass
        _dead_3338 = 813
    text = __import__('base64').b64decode('VFIwS09zMmFIUW9zMWtsSjNyUW4=').decode('utf-8')
    if False and True:
        753
    total = value + len(text)
    if 76 * 70 < 0:
        218
    return total

def _эΟΚаΠЮшΓЖЬшЗ():
    value = 708678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQT9fnMN7KU5albwwXSXBjM40mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СкуриДΤА():
    if len('') > 0:
        _dead_5848 = 785
        598
        774
    value = 603488
    text = __import__('base64').b64decode('Wjh3WWxQV0ZWanRfd3MxdWFtd0M=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_9512 = 151
    total = value + len(text)
    return total

def _АОΜψюдΗοРΛрβξνдЮ():
    if False and True:
        554
    value = 507659
    if len('') > 0:
        _dead_8479 = 541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQf1aGlt+60TYi7z5EWyGgIhwEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΔηθГзΖΚποκпИЩл():
    if len('') > 0:
        32
        _dead_4316 = 652
    value = 85115
    if 32 * 82 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiW9ZmgpyZwJaVasyVGYYCIO/Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_8985 = 318
        426
    total = value + len(text)
    return total

def _ςΦИζКτΩΓМκ():
    value = 568162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwfTOQc1xJ8bFBj7xlq9YCQK6zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓлςεжюЪЗТψкНБυΚτ():
    value = 409514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxnHPQMVzY1VNVmM+1CHDS19wX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΥЗЛпУζфΛΜςΘ():
    if False and True:
        _dead_3613 = 767
    value = 765490
    text = __import__('base64').b64decode('ek9GOXFScDdEQ0F3QkFoQm9yZzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝУХОфакц():
    value = 318471
    text = __import__('base64').b64decode('ZUZ3ZHNhNTFFd0c4Vjg5VHhXTnY=').decode('utf-8')
    total = value + len(text)
    return total

def _μΔиЭХеЙΓρЖмΡπуκ():
    value = 530663
    text = __import__('base64').b64decode('ZExFank2ejBHVGg0azNNbXc0Tmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΚμβψΨЫлφΘταчМг():
    value = 263711
    text = __import__('base64').b64decode('amxfbFBfMUNnaGJINk13WG9ZUjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЧМΧюПτσ():
    value = 814527
    text = __import__('base64').b64decode('d2FFbGhwRl95T2VQcm9DVUdCYks=').decode('utf-8')
    if len('') > 0:
        243
        pass
    total = value + len(text)
    if 83 * 57 < 0:
        _dead_3685 = 818
        345
    return total

def _ΓμΤдшЯΓБ():
    value = 27196
    text = __import__('base64').b64decode('R1hrazhfU3J1OWlvR3d1UVhnNmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ыЫπДιΤПеχςЖ():
    value = 722930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzexRnsD7Jk6NgGq3WKiBnMYvHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΙζЪоΡΨгЫΠ():
    value = 152812
    text = __import__('base64').b64decode('Wlc5MXVJVFF2cGY2VG9WT2dra2w=').decode('utf-8')
    total = value + len(text)
    return total

def _θΟλΚйΟАΗиЯΩυщВо():
    value = 647118
    if 27 * 35 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jny8f0Yy3YwuPy32mGaTZyMjx2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΓЬйΠЗуΗХ():
    value = 932352
    text = __import__('base64').b64decode('azlWbFJQNUVRNXV5WE5BY1l2RUk=').decode('utf-8')
    if 3 * 81 < 0:
        625
        _dead_1337 = 196
    total = value + len(text)
    return total

def _ЮлΒρыачειαжωАК():
    value = 142831
    text = __import__('base64').b64decode('bFBGODN0S3pmcnJYQXFKMDJqUU4=').decode('utf-8')
    total = value + len(text)
    return total

def _рΡгΧπЕΣδΡρυ():
    value = 466556
    text = __import__('base64').b64decode('YXZHZ3d2Vl9IYmk4REY4VW9XY04=').decode('utf-8')
    total = value + len(text)
    return total

def _СкμΧΩΕтЫДΨ():
    value = 607263
    text = __import__('base64').b64decode('Ylk2bjhxWFRWOUtaeHNXVHB2bW0=').decode('utf-8')
    total = value + len(text)
    return total

def _вλωЩμφаБуьΖиЫЛ():
    value = 302177
    if False and True:
        pass
    text = __import__('base64').b64decode('cFAxaHdwak1GS01zM0RXNnVGY28=').decode('utf-8')
    total = value + len(text)
    if 43 * 95 < 0:
        pass
        _dead_9771 = 26
        138
    return total

def _ΥγффΔΦΥХιДЕκ():
    value = 530865
    text = __import__('base64').b64decode('UkhtUE85TmNnbk9Pc2dNNjZCY3E=').decode('utf-8')
    total = value + len(text)
    return total

def _чгБхОΚκКИС():
    value = 293303
    text = __import__('base64').b64decode('U1MyVnJuZ1pTMWlIdG9zSDJqb2E=').decode('utf-8')
    total = value + len(text)
    return total

def _СΟρΞЫΛчСΕЕ():
    value = 867842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bj7IT11g9/BWEQqlzAe3NyEoxlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψхмυΓδΜшСЕ():
    value = 628327
    text = __import__('base64').b64decode('TUw2TTJHWUw1VEdIbnhQSmZyQlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΗЫδяНγΟуοюхΣпκ():
    if len('') > 0:
        _dead_4981 = 402
        553
    value = 621304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgnNPnIMyowzbBma4n2TFS8N4Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 40 * 75 < 0:
        _dead_8464 = 178
        pass
    return total

def _ХЩяМχьΞррΞАиδΗσУ():
    value = 391776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwHrNmsQ66MaaSui6XXGB3cVtTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΝφΓМΑΑзфΧТ():
    value = 620556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQ3edwkh7fw7bDeE20+8EnUj0jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΞρЛΚωγγкчР():
    value = 72589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzvFQWQX7I0XIwP72wGhFw4+/k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΦВπкψτд():
    value = 561121
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBnBTEFu+pA5Pyavz3m8BXEq7Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬаэΩкШΥЗэ():
    if 47 * 32 < 0:
        _dead_3137 = 741
        pass
    value = 250503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXi3N18ByYUGA1ap2GaEHQYKwzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΙЭμшИηрмуλ():
    value = 928260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSneXQNs0aAsPQG7nXGHPxQHxl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        440
    return total

def _ТΤΑшбιюΛыТ():
    value = 597102
    if False and True:
        429
    text = __import__('base64').b64decode('TFhzVGIzVjJJODRETDNYbmhEUEM=').decode('utf-8')
    total = value + len(text)
    return total

def _бΧкЪЖдкΠЯмЮАΨμςэ():
    if len('') > 0:
        pass
    value = 942683
    if 42 * 38 < 0:
        pass
        742
    text = __import__('base64').b64decode('bEtWa0dvTXk4bHNCVmRyakdzTVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΤпэЙγηмЙυιΓ():
    if len('') > 0:
        pass
        _dead_5405 = 649
    value = 779984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiTsWGIAy6M2KC215Q+RIhoM02c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТуφИΟнΟΞΛμ():
    value = 509550
    text = __import__('base64').b64decode('Rk5BZmRFZ0dia2JnYWo2bFFIOEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ыПδЫПЗВυЛь():
    value = 170528
    text = __import__('base64').b64decode('djdkSktFckk1QmtyeDZWRlREQlI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _бξΞΗБахЮУШЪ():
    value = 543329
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHjsY3A2xIwSETeWn0+XYyE1x2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        343
        378
    return total

def _ΒΠукΗΠЛгΑΔδи():
    value = 888822
    text = __import__('base64').b64decode('QkQ0Y3B6ZWVfV1JsOTlLbTlwODU=').decode('utf-8')
    total = value + len(text)
    return total

def _κзыоχиηАΜινо():
    value = 860739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwnePn0zypoHKxeI0Qa3AigC6lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τЙρТШωЕΒνκΞσεΒЪз():
    if False and True:
        pass
        pass
        pass
    value = 758930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cz/MVF4YqYEsaBaLnWybGiYCx1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πςΞЪκφХеζЯΒκЖшγΦ():
    if 83 * 81 < 0:
        32
        pass
        pass
    value = 468776
    text = __import__('base64').b64decode('bW1Icm1LMW1WZU9TNXg4RWY5MVI=').decode('utf-8')
    total = value + len(text)
    return total

def _γΣξЛΣθлЙ():
    if False and True:
        pass
        731
    value = 361326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXbiPEUNwbE7DiSKkAORGBEf5Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩЫяВЖθдΔΚ():
    value = 975269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH7gTVg866U2GDDxxQOABzd+3DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δτΦΙπхуΚЭβ():
    value = 477078
    if len('') > 0:
        pass
        162
        _dead_9613 = 843
    text = __import__('base64').b64decode('eFJ5R2xMc29XNFBITUpKaXlNNUg=').decode('utf-8')
    total = value + len(text)
    return total

def _чχЩтΓсЙшΣхΓΛнΕΣ():
    value = 83466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhzVYwUGzYIbLyqNnGbJLTIH7lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьРйκЩΣΗЗф():
    value = 237902
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQfeTVk8qrA1GQCH8gGlOh043GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 7 < 0:
        790
        _dead_6043 = 34
    total = value + len(text)
    return total

def _μψζςгОхйЯцЭхΤТ():
    value = 146927
    text = __import__('base64').b64decode('Yk5oMlNPSFZNalJpX0xxRVJPTGY=').decode('utf-8')
    total = value + len(text)
    return total

def _кΔЛсЯψдΠΥρΛбСΞσа():
    if len('') > 0:
        _dead_4035 = 127
    value = 502715
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjvxaghhzIYRIjC7nF+CASoJ/Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 40 * 31 < 0:
        776
        591
    return total

def _φфРонДЧяСпЬлжШΞ():
    value = 63838
    text = __import__('base64').b64decode('S3kyYlBWOFVpNmhzVVdSVFptVms=').decode('utf-8')
    total = value + len(text)
    return total

def _нλεψОΨпΜτς():
    value = 237890
    text = __import__('base64').b64decode('VVNONFhTaUNQTVl2Z3ZfNGxuVHY=').decode('utf-8')
    total = value + len(text)
    return total

def _εХрэΔпκЩЧШ():
    value = 886393
    if False and True:
        _dead_9635 = 248
        392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCDRX0MA6qRWFT+17Xu+ICgl/mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        421
        _dead_1971 = 717
        _dead_2885 = 971
    total = value + len(text)
    return total

def _тγδыγφкψ():
    if False and True:
        743
    value = 513829
    if False and True:
        42
    text = __import__('base64').b64decode('d1dEOEFFUUQ0dGJTM0t5VDM4bk0=').decode('utf-8')
    if False and True:
        _dead_2049 = 640
    total = value + len(text)
    return total

def _СйОйθмθΟ():
    value = 870008
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3vLQGUvp5IXYwOo8HmqEnM4828='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СκκαьуΔΠ():
    value = 792726
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxrnYFJo/IcIDQiG3lGIEB0Qtjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΩγυΛςФΑ():
    value = 735697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHvpWmQc2IEHKwbz0HqnAzQB0Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΦμлдчХДпσΦβ():
    if len('') > 0:
        _dead_2787 = 123
    value = 831931
    if False and True:
        527
    text = __import__('base64').b64decode('a2ZmZDNWS3M4b1RoVEhoVkt6NnQ=').decode('utf-8')
    if len('') > 0:
        549
        pass
    total = value + len(text)
    if len('') > 0:
        916
    return total

def _εΗдЮЧмζΟшъ():
    value = 664463
    text = __import__('base64').b64decode('ckNDMExrQ3ZaNWZSRElYSEY2ODg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚζЩгюσθДВΣ():
    value = 54082
    text = __import__('base64').b64decode('a2FaVkZlejFrXzNYcGE3Q1NSdUI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9764 = 484
        pass
    return total

def _ьΥπΤясαΞйΒΔ():
    value = 653655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSPoV25s+acGPQG5zVWWGTR+xWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΓГЖΜЖхβЛЧДщкяλρ():
    value = 719929
    text = __import__('base64').b64decode('ZjdENUpZMkxLb0pTVFlRX3BXRUY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        603
        _dead_1371 = 374
    return total

def _ρΥЙьΥхςыъβРзΧτ():
    value = 534468
    text = __import__('base64').b64decode('SUNfVGduVVNLaDU2cFVPNW1EekU=').decode('utf-8')
    total = value + len(text)
    return total

def _вПσμпωХЫΖ():
    value = 48107
    text = __import__('base64').b64decode('TXc4V0Q2c1RKQjQ4d0NFQlEzZ1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩяКγЙфзθу():
    if 41 * 68 < 0:
        pass
    value = 25271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSC8XHcz6qkiOx2E4lSePBIi71s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 84 * 10 < 0:
        _dead_3720 = 815
        _dead_5337 = 773
    total = value + len(text)
    return total

def _еΥмхфΟрюЧ():
    value = 734368
    text = __import__('base64').b64decode('U0h1c2t6bjBsNXRWQ2llNEdCZ1E=').decode('utf-8')
    if 84 * 16 < 0:
        _dead_3863 = 320
        844
        913
    total = value + len(text)
    return total

def _ЮΜеΓΦΡАΤθΛшωΞ():
    value = 589652
    text = __import__('base64').b64decode('YmxuQlFrUERzNHJaenFxeXg0MjE=').decode('utf-8')
    total = value + len(text)
    return total

def _БЫмνχрСъαΒ():
    if 46 * 68 < 0:
        44
        _dead_4406 = 914
        pass
    value = 729311
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRu8YQcx7ZBSGzqHmUW3Jy8Bs30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΟπΓΜзЗюв():
    if len('') > 0:
        _dead_5211 = 922
    value = 818655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBDqf0kD25IzCFeqyWClFigHsFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8925 = 849
        _dead_8891 = 993
    total = value + len(text)
    if len('') > 0:
        997
        624
    return total

def _яШμРΣΚЗΘЧφГ():
    value = 519451
    text = __import__('base64').b64decode('QVNHTVZUZnVFOFNyM3J6dHViTm4=').decode('utf-8')
    total = value + len(text)
    return total

def _σоΗιЫΟгЛΙЦΔ():
    if False and True:
        pass
    value = 336225
    text = __import__('base64').b64decode('Um1hdUc2YTFrX3puWFhEU2tJV0M=').decode('utf-8')
    if False and True:
        pass
        _dead_9155 = 834
    total = value + len(text)
    return total

def _ΚТкκφВУςΜΩОΡ():
    if 47 * 45 < 0:
        pass
    value = 836399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETX+f3Qr3IY1bz300XqlBCgF0ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юУЦΙЮΛκийΔΡБШЧξо():
    if len('') > 0:
        472
    value = 87045
    if len('') > 0:
        470
        pass
        _dead_3918 = 457
    text = __import__('base64').b64decode('b0NieDFZRUZBdHBMY0doRTZPVW4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        448
    return total

def _αйΨххиΙΝДТ():
    value = 368366
    text = __import__('base64').b64decode('TEFqRzhHcWFWalJySFNzSUlWdXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ъуΒВСМΤοидΘκА():
    value = 922283
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('azh1UElTOU9PX09JMnFoNGJSb0M=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _πзйУЫΤΔЗРψн():
    value = 155954
    if False and True:
        662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQTpS0Uv9p05DQexy1HJIid57To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηСХСκМονЪоьΘэЫ():
    value = 902719
    text = __import__('base64').b64decode('ZmlVaWx2VkpnUWZ6YkFMSEkyV1A=').decode('utf-8')
    total = value + len(text)
    if False and True:
        823
        pass
        815
    return total

def _ΖЮчζыδШδΨ():
    value = 431814
    if False and True:
        _dead_3134 = 743
        _dead_5384 = 189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgjIXUJv7pI0AyiT4wW/P3Z2xW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΒЦрЭФψЪ():
    value = 170769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiDFNgVr6YY2BSSkzUKyJxwO6zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9254 = 361
        191
    return total

def _ΓΘефΧЖΟΘΞь():
    value = 680849
    text = __import__('base64').b64decode('dkJDb1BoaUpobEFFUDV0U29ucFM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΣяпЩγжΩюлЬрюх():
    value = 807006
    text = __import__('base64').b64decode('VzFROHdqb0ZzZDJkaUo5Z3BORDg=').decode('utf-8')
    total = value + len(text)
    return total

def _υΒПΦвΧΓЧДκрща():
    value = 375308
    if len('') > 0:
        _dead_6299 = 529
        pass
    text = __import__('base64').b64decode('Y3EycEtzYTYzZG1jSjhjUTN6Rmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦЬйΖγнΕхζрΙΕθеγА():
    value = 541957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR3ReF46wbAVCliQ5E+ePBoQ8kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αζВΗτиΡрΡй():
    if len('') > 0:
        _dead_2829 = 57
        _dead_7309 = 202
    value = 651844
    if False and True:
        pass
        _dead_1718 = 506
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX33T1Qa1blVE1azwneiODMkyz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬидхЧΘцПяэС():
    value = 137175
    text = __import__('base64').b64decode('RzNETXRsdmZwOUdCdmhLNkFROFE=').decode('utf-8')
    total = value + len(text)
    return total

def _МвеεχХжйъΔΠЖгΓБ():
    if len('') > 0:
        pass
    value = 512589
    text = __import__('base64').b64decode('T0VCU2RqcXN0SWhTQkI5Zkg0NXc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        345
    return total

def _АРмμΠпЕнЕоПш():
    value = 407990
    text = __import__('base64').b64decode('azdYS0tkaU1xR0s3NUo2T2NVY1Y=').decode('utf-8')
    total = value + len(text)
    if False and True:
        206
    return total

def _ΘЛΘШяΖЫГ():
    value = 538395
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHbte2Qs+LIGHQSK/A+ICwsMvTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_5952 = 353
    total = value + len(text)
    if False and True:
        _dead_2291 = 912
        _dead_8774 = 543
        _dead_1297 = 974
    return total

def _ζадΨψςΡЩТοΓ():
    if 84 * 74 < 0:
        601
    value = 117023
    if False and True:
        _dead_5437 = 126
        pass
    text = __import__('base64').b64decode('a2twOXd1X0R6MDVKbnlhdXZoeWE=').decode('utf-8')
    if False and True:
        _dead_8297 = 436
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        733
        pass
        _dead_4978 = 619
    return total

def _дΕΩΡигжНΑИΡγ():
    value = 529851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDzLP1YL36oMKQKL7l+TFRcp6F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3280 = 794
    total = value + len(text)
    return total

def _РΦНΨФСьξЦЬΗя():
    value = 876871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ci28PVYJ7JFWGBuEn0+9GAkp7Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠВъзэΚфΨмζΩλΙфΩР():
    value = 263250
    if False and True:
        pass
    text = __import__('base64').b64decode('bjBOVTVaVlJ0TmtWc2s5UTMxRnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟрσοодЗυФЖУΝμ():
    value = 252773
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCHlb0QA0rhRDF2K6X+eEnE8xVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 54 * 59 < 0:
        _dead_7101 = 597
    return total

def _ыЗЩдμφομЬуИυюгМ():
    if 6 * 33 < 0:
        _dead_4018 = 808
    value = 366523
    text = __import__('base64').b64decode('bEpCeTgyTnZ2azdTY2YzaklnZF8=').decode('utf-8')
    if len('') > 0:
        _dead_3957 = 93
    total = value + len(text)
    return total

def _ΥлΧзРУЮΥхДхΡЯыΧ():
    value = 723065
    text = __import__('base64').b64decode('TXNGR01RZU9uWjFGMXJuUnVpVUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _хЖеβАΔыτщФМζЫΠн():
    if False and True:
        841
    value = 476712
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB7cY34/+PghFQD38QamMxA401o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4963 = 991
        pass
    total = value + len(text)
    return total

def _ЮλЗхЖеХуνГЦιХу():
    if len('') > 0:
        pass
    value = 630352
    text = __import__('base64').b64decode('Z0hYdkt2bk1jMmVMSlVDYkNoN2E=').decode('utf-8')
    total = value + len(text)
    return total

def _уκΖδФАΥлκΟбΦе():
    value = 148272
    text = __import__('base64').b64decode('VGZxUFpJZDhNSHU1cXl0TURXVVA=').decode('utf-8')
    if 97 * 1 < 0:
        570
        506
        pass
    total = value + len(text)
    return total

def _ГνЕйπдΕя():
    value = 193943
    if 30 * 29 < 0:
        _dead_5417 = 979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQPCTV4I3bsWAgqwwlWqIBF441Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 59 * 14 < 0:
        _dead_7616 = 990
        pass
        987
    total = value + len(text)
    if False and True:
        _dead_2678 = 451
        pass
    return total

def _ФШсΥючпΦς():
    if len('') > 0:
        pass
        35
        _dead_4438 = 630
    value = 446922
    if False and True:
        604
    text = __import__('base64').b64decode('U0s5dDhSNlkyTTY5R0RtajRJMnE=').decode('utf-8')
    if len('') > 0:
        _dead_3561 = 133
    total = value + len(text)
    return total

def _ныεμУξжεнейъβК():
    value = 459280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHndSkFp+KoWBR+I/VS6BiMnxmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑπЦаΤвΦчΧ():
    value = 880746
    if len('') > 0:
        pass
        _dead_5595 = 784
    text = __import__('base64').b64decode('UWZ0emk2cXY3Q1kwQUNEbVZZaHI=').decode('utf-8')
    if len('') > 0:
        _dead_2590 = 660
    total = value + len(text)
    return total

def _ΨΖдГψФιЬσэνзГΛδΟ():
    value = 441743
    text = __import__('base64').b64decode('Z0xBX1l1Z21rME8wTHR1RjhETnA=').decode('utf-8')
    total = value + len(text)
    return total

def _цλΙθΕαμγννдλнιщ():
    value = 432401
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('aV9yMkdST0VLeWdSY0c3WWs0Wmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΨπгбГΩцСсг():
    if 96 * 80 < 0:
        pass
    value = 552211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax63QUIr6bEkIjvw8VWzJC4LwmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХЦβлюΑβаоьωΞΩП():
    value = 843999
    text = __import__('base64').b64decode('a0xORGhJVnIyRmpOUHZ5VHVmMGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΜΣΥΠщйζлЖΠЗζъζθ():
    value = 681935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTqwP2UW8YU3Ywqv5UWmNg58sUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФющбСлшΠшлΗΖе():
    if 81 * 35 < 0:
        72
    value = 712373
    text = __import__('base64').b64decode('dVlYcHRrQWVlVDBjTzd0dUx1VlA=').decode('utf-8')
    total = value + len(text)
    return total

def _АαЭЛΠξЕНσψАω():
    value = 166292
    text = __import__('base64').b64decode('UFY3ZV9jbHl6SEFqeGNvdVVtVXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦδиФεлнвλЮιКщΩ():
    if False and True:
        pass
        96
    value = 105229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyzyRHA+66QvHQn70kLGGncm7kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞЕΥДГΖВБЦβΟМ():
    value = 249776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj3DPmIa7roUPz/yzUO3ZRMp418='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шэΓεΕЕЛТЯβГвЭрν():
    value = 309495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQq9P3xtqokxDy6b/QGaAioK6zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вЕςАΒфκащпЧпΖЬИР():
    value = 517145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxvuWAA286MUbTn73XunEgIOw3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔωκμПΕΖЛΗ():
    if len('') > 0:
        _dead_9419 = 630
    value = 222278
    text = __import__('base64').b64decode('aWU0OXF6WlhER2sxUWlvWjUxNUc=').decode('utf-8')
    if len('') > 0:
        213
    total = value + len(text)
    return total

def _хρыъбЗЙΩкДΝЬΦбз():
    value = 410592
    text = __import__('base64').b64decode('ckVST1hBb2hhdTl1SHdWTkhhb0M=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5058 = 28
        pass
    return total

def _лЙΣΒοмΜδΝЭр():
    value = 153629
    if len('') > 0:
        412
        pass
        510
    text = __import__('base64').b64decode('THB1cVVhUThkUHRyalN6b0hRVWE=').decode('utf-8')
    if len('') > 0:
        pass
        723
        pass
    total = value + len(text)
    return total

def _ΛАΝпΕъЩΙрЬШГтΕхΝ():
    value = 620565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCLwOEce8pkwbg3y6nrHEyR/6Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9130 = 28
    total = value + len(text)
    return total

def _гШюηΖΧьЪλκ():
    if 24 * 76 < 0:
        pass
        _dead_5606 = 481
        pass
    value = 671862
    if len('') > 0:
        932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izvga1sgxronOVuxkW+HGxUf6j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 36 * 24 < 0:
        _dead_7345 = 126
        pass
    total = value + len(text)
    if False and True:
        _dead_6993 = 169
        pass
    return total

def _щТζБΨΘπФЧжя():
    if len('') > 0:
        239
    value = 850316
    if len('') > 0:
        915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSfOV1sD+f45FTma7wSlIgcAt1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 31 < 0:
        pass
    total = value + len(text)
    return total

def _ΩЖγΣЬΙξβИβ():
    if 86 * 59 < 0:
        pass
        627
    value = 535837
    text = __import__('base64').b64decode('S0g5bldYVkx5NFZTWm5URTFWZVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒОИλΠКβФЬсΔъσШ():
    value = 94602
    if False and True:
        _dead_5919 = 556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAC2X2IY/KwsHFagzwK6LQgZtlc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        384
    return total

def _ькΒЧγΨШнФπЯдΒνЪ():
    value = 761491
    text = __import__('base64').b64decode('bm81cWlTZENrQVNDRzdqZWIzWXk=').decode('utf-8')
    total = value + len(text)
    return total

def _юΓΡЫΒэнπ():
    value = 696162
    if False and True:
        pass
        260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAm3XWsO3bsAGDiGn16kHykMw1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        415
        901
    total = value + len(text)
    return total

def _лфыНЖсΩРΤΕцβЖ():
    if len('') > 0:
        pass
        718
    value = 935342
    if 77 * 74 < 0:
        pass
    text = __import__('base64').b64decode('U2d3M3hfd2lScFhQakE3cXhIbVY=').decode('utf-8')
    if 43 * 80 < 0:
        976
        _dead_7582 = 648
        638
    total = value + len(text)
    if 62 * 66 < 0:
        940
        pass
    return total

def _пπЬКλхΚеεχв():
    value = 236756
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQ3deVUS//4OIAS73mG2Yyp20To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _νπэЩймфСΑωАпюФμ():
    value = 32870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCO1O0MpqPwrCjCymGa7PzQmsls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τнЙЗξЭχиъЭΞΓ():
    if 53 * 16 < 0:
        347
        pass
    value = 845610
    text = __import__('base64').b64decode('eDQ3TzAzWGdaSEVTa1VESTJweE4=').decode('utf-8')
    if len('') > 0:
        _dead_6341 = 969
    total = value + len(text)
    if False and True:
        865
    return total

def _ΙфДαМШкНгЛщзρνω():
    value = 491880
    text = __import__('base64').b64decode('SVhKTXBaYjhINlRUb1NlWkhVcmw=').decode('utf-8')
    total = value + len(text)
    return total

def _υδΙИБЫПΔПеьΠ():
    value = 114644
    text = __import__('base64').b64decode('VjNDWTdLRjdhZHoyN25nWEk5MGk=').decode('utf-8')
    total = value + len(text)
    return total

def _αΔУλРνЫржщРЬЗΥ():
    value = 593540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBrHT2Frq4sTPjqF8WWyHiotzjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6636 = 138
        pass
    return total

def _юаχоыςЧхΕωдΑΥ():
    value = 433667
    text = __import__('base64').b64decode('YlRVS21pSm1LWWhfM012dUpRRXM=').decode('utf-8')
    total = value + len(text)
    return total

def _БАυΖεвоЯΧбн():
    value = 962493
    if len('') > 0:
        558
    text = __import__('base64').b64decode('akdhcnY5S2lBUXpBS0xEWVdqU0E=').decode('utf-8')
    if False and True:
        _dead_6852 = 981
        626
        pass
    total = value + len(text)
    if False and True:
        312
    return total

def _евКянΑοЪΓЭτЗΔ():
    value = 869350
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwTKPEsJpoBRKQWb4FS1CwsExmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РκдкКБЦфтхгС():
    value = 614460
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nnrrd10ax7w2Dl6i+X21LXQkskE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧЪсεхЪΥςЩтгУσБЧ():
    value = 742111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjfRPgIqyb03KQX2zW+GMAc6wl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рмюιΧКчаъЫΝαΨψιб():
    value = 486747
    text = __import__('base64').b64decode('aU94b1FnejNhVnNtQm85VVhfNnY=').decode('utf-8')
    total = value + len(text)
    return total

def _χΤЪвΨБУΘТμБλυаθ():
    value = 936113
    text = __import__('base64').b64decode('UHhxQ2tDVHg3akdnQXpaTmpoamc=').decode('utf-8')
    if len('') > 0:
        _dead_1300 = 682
        187
        718
    total = value + len(text)
    return total

def _жκБЫнιΣΟ():
    value = 301822
    if len('') > 0:
        _dead_4667 = 25
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQTSe1Is+P0aMCG70EKcMD8Nzno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фДΠπΝεσьЙολ():
    value = 616907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fj+xa3Q/+IEyEwf7mVTDIQ0h7Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        913
        _dead_9740 = 87
        737
    total = value + len(text)
    return total

def _ΦкΟСяτΘДπΗσςοκπ():
    value = 695667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQezN2cN7qAaNh2P63SYBAYm/js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗыгεгфтЭΙяе():
    value = 117739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw3nN24XyIsCaj6W5WSYGAd61lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 44 * 94 < 0:
        pass
        _dead_3324 = 363
        _dead_4786 = 320
    total = value + len(text)
    return total

def _ΡυБΤΩкτЩяλэЮмХиШ():
    value = 567916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhfXPHUrx58JBQ6X2mO+YiwW1Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зωфΤЮοДГД():
    value = 106897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChDVbAEjy6YJHS65yUGyZHN8sEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 75 * 24 < 0:
        799
        pass
        pass
    return total

def _ΜцДыЦЙзюΝ():
    value = 825576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTrJXmsO9KsCCxag/1qyGSwO83w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψζβЭαбρМм():
    value = 45142
    text = __import__('base64').b64decode('ZXJZbHZwZlY1YU94NXg1YnJnSlc=').decode('utf-8')
    total = value + len(text)
    return total

def _зРВйΚдоУЛйсΚΙΓ():
    if False and True:
        pass
        268
    value = 898392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwzLX0c6rqA8MF32wWOVAAo/0HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΕЧνΕкΤτъΤ():
    value = 682022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTjJPVkN56IBOFeZ7HmBHisH7E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙбΦФМΔшоΜυιλωБлд():
    if len('') > 0:
        pass
        _dead_3148 = 528
    value = 984812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwC9TWAs87tTKxWK4mKnBX0g9js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞБЦСΤΤяаΣΦΕмΥΛр():
    value = 112555
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjbseUMs+ZkMNjq74wC8PCN74m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УжυςδуμцЫΕΘ():
    value = 403326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx7MTFg4zKQRIy333G+oHgQFsXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еφйОЮεРнШσΕ():
    value = 574811
    if 53 * 76 < 0:
        326
    text = __import__('base64').b64decode('dXRGT1RueTRGdXZlTTFxN2VRYU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ωχШψηηыψζρдАвΙ():
    value = 578304
    text = __import__('base64').b64decode('Y093cnN6eUpzUkhoZWZDRl9DNzU=').decode('utf-8')
    total = value + len(text)
    return total

def _αΖγΧσСΔΜДочΩЪжη():
    value = 350217
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3jQVEto+v0mCVimxQKSPx8L5Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        322
        892
        pass
    total = value + len(text)
    return total

def _ωΜШэщуΖкцдΩρМШЧ():
    value = 244370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACDlTHsX96o6OSms/AaWIRo9xno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 83 < 0:
        _dead_4588 = 860
        784
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8440 = 943
        pass
    return total

def _иуΗΥΠсЕρ():
    value = 323511
    text = __import__('base64').b64decode('WjB1M3NSNHhJS0dreTNmVVNpdlY=').decode('utf-8')
    total = value + len(text)
    return total

def _σΖыИυΘщЪΤΛамыФтΡ():
    if 12 * 90 < 0:
        402
        _dead_4496 = 790
    value = 610537
    text = __import__('base64').b64decode('WnZFaGlNcXBhaG9iUVpCb0JkbDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ицοАРтРχЧΘβΑЦΞмΗ():
    value = 837767
    text = __import__('base64').b64decode('cGE1cUVhUTB3ODMzR1ZxSUJRZXU=').decode('utf-8')
    if 8 * 27 < 0:
        pass
    total = value + len(text)
    return total

def _ццρыαμπЬфСпВ():
    value = 321118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjuwfAA/37EvFA2FxAKHHikf/Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γОΨЯΥтπъйΞзЕфΩ():
    value = 844953
    text = __import__('base64').b64decode('UFpSMFplSW1DUU5sY3VsZ2VhZmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _κЧТШΥъΝЯΓЮ():
    if 44 * 97 < 0:
        _dead_3306 = 499
        708
    value = 919532
    if 17 * 10 < 0:
        784
        pass
        429
    text = __import__('base64').b64decode('aEROWkFoRXlQZkc2aHB3ZEZfYVY=').decode('utf-8')
    total = value + len(text)
    if 99 * 38 < 0:
        pass
        pass
        _dead_8368 = 603
    return total

def _ЙοΟυΧэφСд():
    if 37 * 87 < 0:
        114
        pass
    value = 255528
    text = __import__('base64').b64decode('c3FDbk9LSjVUTzhlbmEzbXIxUm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЫΩσМЛЬпЖΤЯΜт():
    if False and True:
        103
    value = 488041
    if len('') > 0:
        pass
        548
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjX9fksUxIcCFh31zHmcGz8Q/n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 86 * 47 < 0:
        pass
        pass
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('cg==').decode('utf-8'))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()