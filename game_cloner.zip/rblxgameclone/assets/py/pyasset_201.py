#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _δΧΙΜлЙПΗЕЬСΛ():
    value = 157046
    if False and True:
        pass
        748
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji7UaH8T57sUbF254GygNy8f420='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9213 = 530
        360
    return total

def _тЙБлЪхЯжЫω():
    value = 381822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR3XanUP/bEXHg6m7nCoMwAV63Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 85 < 0:
        pass
        _dead_5455 = 75
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЖиΤвτξΩαΩшЫхнкΤλ():
    value = 698730
    text = __import__('base64').b64decode('TVBWb1I3UFFGcGZxNEx3RG5rQ1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬωяЧΙЗчЭсЩΙуШμ():
    if len('') > 0:
        pass
        464
    value = 554305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KS7VQFsuqKQyCT+qwACyYQw+8T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4153 = 964
    total = value + len(text)
    return total

def _РшуχеΙκγсδθ():
    value = 402937
    if 81 * 37 < 0:
        _dead_9630 = 152
        _dead_3022 = 28
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnrRa3YjzoFQbSyr8lSdGBF9xlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 77 < 0:
        pass
        _dead_6437 = 72
        pass
    return total

def _ωδΑИΣθРΚКеζ():
    value = 398543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Biq2QVdu57k6MQeI+lWhEnQG4WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъαВъΝчУмΠлЦдψзА():
    value = 565335
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnvvZF0f2Ik5DiGu6nOmIikZ3Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лλΒΥвжΗγΡτηЕ():
    value = 29386
    text = __import__('base64').b64decode('YTc3UFMxdmdhTG45a2Y1N2dxR0Q=').decode('utf-8')
    if 100 * 7 < 0:
        215
    total = value + len(text)
    return total

def _ЧμτΣξνкПεΩΙЬжфπ():
    value = 200584
    text = __import__('base64').b64decode('Z1FuTEdJbHRpTk9fV0ozQlU1eVo=').decode('utf-8')
    total = value + len(text)
    return total

def _НВХРΝКЗτΧщЭ():
    value = 669828
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCPGeWsp8P8iMwGkmAWCMwp3yXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 79 * 45 < 0:
        _dead_1176 = 183
    total = value + len(text)
    if False and True:
        277
    return total

def _бтΡяλωΓщуβЩэКПΚу():
    value = 309834
    text = __import__('base64').b64decode('VUNrbDVNN0xSNDVxOGM4Mm1UUnA=').decode('utf-8')
    total = value + len(text)
    return total

def _УхεψιТиЭβΞρНА():
    value = 570674
    if False and True:
        648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3zAamE61/owLDaL4g+/PA8W5Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤсоиХшЖнι():
    value = 589353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCm8b1sP7K1aGFaT0lCoYSc81lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4829 = 489
        _dead_1491 = 195
    total = value + len(text)
    return total

def _ΕιОοНτΥжγ():
    value = 739626
    if 72 * 3 < 0:
        407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCrXdgQt3aMBLwSSynKDAwsksz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΠςИθοОΦοшΜАрχч():
    value = 802627
    text = __import__('base64').b64decode('a19LdWNYMERVU0xpcm5ScVlDZXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _γΗπКФεΛппΩΡиГТΡД():
    value = 562895
    if len('') > 0:
        996
    text = __import__('base64').b64decode('d0tLYmZQS2o0Tk1VT2VWRzJqTTU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5536 = 334
    return total

def _ЭКзЩЖΖεЦρлαЗ():
    value = 947728
    if False and True:
        pass
    text = __import__('base64').b64decode('ZWNGc095MTl5RWFNS3ZIYTN5Vnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЧυρЮЗьЗΧ():
    if False and True:
        528
        pass
    value = 360514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECHiQEMLp4w3NT6QykWWJSwk5zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_3469 = 930
    total = value + len(text)
    return total

def _ΩлΛαΣΕуЕ():
    value = 85580
    text = __import__('base64').b64decode('RjVpVDQyUTNwcnlrdXFqN1NQYWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛФφФρΤъΓΕξΤе():
    value = 470841
    if 77 * 88 < 0:
        _dead_4222 = 582
    text = __import__('base64').b64decode('ekF0MHMyOUZCdnU1V3o5WUY0REc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_4965 = 486
        _dead_4730 = 914
    return total

def _ЪΣμΗΨмΦЧН():
    value = 451497
    if False and True:
        297
    text = __import__('base64').b64decode('UXl2QUVhUFY1WGZ6eDkwdm1JaXY=').decode('utf-8')
    total = value + len(text)
    return total

def _РΤкΩрΗЖСγκтфΗбЪя():
    value = 918904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQXtYQU6qbE3YhuB3meoZgMZ8G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хγХΔΦλпкςθВρΙлб():
    value = 12584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FA7OSGYpy4MOFgn0xlfGOQYk8zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭжцпΑΑЫфδтЦξЙТΟΧ():
    if len('') > 0:
        _dead_8569 = 141
    value = 934067
    text = __import__('base64').b64decode('emFuY2YwcHQ3Z2tSUUFlemVZNUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _РЮξХΣоМъΔЦτэьп():
    value = 260710
    text = __import__('base64').b64decode('dElPZWtZRkN4TW5DWVc0YktJX08=').decode('utf-8')
    total = value + len(text)
    return total

def _бΒЩАлъβУρЫЭЮεч():
    if len('') > 0:
        144
        688
    value = 436601
    text = __import__('base64').b64decode('VzIzYzJ6VXNzVEtyMHlLUkFsRXc=').decode('utf-8')
    if False and True:
        _dead_6794 = 660
        _dead_4190 = 608
    total = value + len(text)
    if False and True:
        pass
        _dead_6903 = 72
        pass
    return total

def _щюеΕμбΖΖчρщцτЙ():
    value = 627493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRjFY1Mowa5aEQnw536nAig3wno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 51 < 0:
        _dead_4716 = 801
        pass
        _dead_9066 = 473
    total = value + len(text)
    return total

def _еΘБψΣΣσгАГ():
    value = 148733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kz22P3k3wb8ZNxmL5QaUDj921zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εРΥфΑπΖйщыьΝ():
    value = 423496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('My7VXkUc9PkWGQ6c7nKDIgc240E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9315 = 269
        697
    total = value + len(text)
    if False and True:
        _dead_8774 = 927
    return total

def _βΨКунКΤψд():
    value = 522511
    text = __import__('base64').b64decode('R0pyWFdtS2NZa01BcGVOYm1kaGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЪςБΓΝΔΠСΑλлЬΖщΛ():
    if len('') > 0:
        664
        pass
    value = 482151
    text = __import__('base64').b64decode('eDVXUzhxcEJpQ0hqS0JqSEQ1ams=').decode('utf-8')
    total = value + len(text)
    if 11 * 6 < 0:
        56
    return total

def _ΩзЧМΞБΓдЕΧЛЖν():
    value = 404408
    text = __import__('base64').b64decode('amdhazlNS1RIc21XcFdGUEZfQjA=').decode('utf-8')
    total = value + len(text)
    return total

def _δхДΩυШδшХΛ():
    value = 812330
    text = __import__('base64').b64decode('VXBzeW40MjNEUVliVnYyZVZUWlY=').decode('utf-8')
    if 38 * 11 < 0:
        _dead_1996 = 307
        276
    total = value + len(text)
    if len('') > 0:
        908
        pass
    return total

def _югЦмΟэЫΘΦοУъп():
    value = 244572
    text = __import__('base64').b64decode('aWFiZE8ycEpjUVRyQ1ZBb1hVcUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЕэΦΒЧБθΠΡΛЖλяц():
    value = 339928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgLTWnIOrvo6LwaX5UTHLQYL6WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞЭКΚΨфГοЦ():
    if False and True:
        pass
    value = 374975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fgq2fGs27YUAHzz16Xu8bQQJ9FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зАчιПγΣΖС():
    value = 194804
    text = __import__('base64').b64decode('dmtaQTY4a2l3WWZ5SFBnQXBwT0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛωРяГΓяζ():
    value = 668183
    text = __import__('base64').b64decode('ZVk4Z0xqYnRlQmFTVF9iV1NHdl8=').decode('utf-8')
    total = value + len(text)
    return total

def _θζзζЦБоы():
    value = 862912
    text = __import__('base64').b64decode('dGxhaktWMFVzQ3Y5R2tlVXhTNFM=').decode('utf-8')
    total = value + len(text)
    return total

def _χРйапνΥА():
    value = 454015
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxfWZnNs9fkLEQr28HGvAy8q92c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θуιпλзΧсОκωΛЫБНΙ():
    value = 625504
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISLgQEAX5/4HEF33zULFFy890Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ζБωГТОρχВфγ():
    value = 846726
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IST0d1Qt8qYRECeu6k+AITUts2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΛЫΔщщГнΕуδКαΗШБ():
    value = 468802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATnUakED9Y0vFgac8WeXHjMs00o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 99 * 31 < 0:
        966
        _dead_3898 = 830
        180
    total = value + len(text)
    return total

def _цЗψйΥΛлЬрЮψ():
    value = 644667
    text = __import__('base64').b64decode('RXhDV0FIdWVMdGNNQnIwdEM3Qlc=').decode('utf-8')
    total = value + len(text)
    return total

def _нктεБΦΧθПХ():
    value = 686680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiezP0QKqJdbKCWRzlOJEHA3/jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑχдпδβЧЖОΑАΤЩЪ():
    value = 511738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXnyPnJhwacoGBby43SWZCYn62o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        834
    total = value + len(text)
    if False and True:
        960
        pass
        pass
    return total

def _ЭцюοψλрзςйчКЮΞφ():
    if 19 * 48 < 0:
        _dead_9068 = 490
        306
        _dead_4436 = 207
    value = 837120
    if False and True:
        719
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lnr9V34g96sGIC6rwnSlE3MB7mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8837 = 472
        _dead_5302 = 334
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        718
    return total

def _ЬэКчвΕαΥσΖР():
    value = 167847
    if len('') > 0:
        392
        _dead_2536 = 84
    text = __import__('base64').b64decode('QUFLeU0xMEpyQVJNWFNvMWZKMGM=').decode('utf-8')
    total = value + len(text)
    return total

def _σюφΔФΙσоοоИ():
    value = 505726
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDa3O0AhwY8PAiey7WSJIBR671Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЛЦΑмЪАИчωМЕЯγ():
    value = 281715
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgrCOngN+oIKIzuoyXGcCxN4tUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤзσΡжΛοΞΤЦμн():
    if len('') > 0:
        _dead_6607 = 85
        _dead_5663 = 175
        478
    value = 792208
    text = __import__('base64').b64decode('b1lTS1JSMWo2UldWbHhxWkNzVlo=').decode('utf-8')
    total = value + len(text)
    return total

def _βρπыШΓрЖΠм():
    value = 430318
    text = __import__('base64').b64decode('ZHVKNXFXVGdJZ0JiREtQZHM0bXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫкΚГΗΨгθ():
    value = 381610
    if len('') > 0:
        pass
        861
    text = __import__('base64').b64decode('TVBMVnFia3NvWUFCcndYSXNZSk0=').decode('utf-8')
    total = value + len(text)
    return total

def _кφχиэЗцБδЯηΧυ():
    if 40 * 81 < 0:
        _dead_5672 = 798
        _dead_6767 = 353
    value = 615548
    text = __import__('base64').b64decode('ZDRBZ0pyN0hxRzJUc2VuVXgzU00=').decode('utf-8')
    total = value + len(text)
    if 93 * 56 < 0:
        799
    return total

def _ΟΡτЪΑМЮЛУΛзРωГγЧ():
    value = 580637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASXwSFU/rLIoHhWz/kWFHzcq01E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        781
    return total

def _МΞэУЛэИйςγΛгγь():
    value = 531383
    text = __import__('base64').b64decode('eWE4TThJamY3SDF1T1lQUkVaY3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _шнκОМηΓшМΠТы():
    value = 327272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHbxSQkw//4JEDWs7QOgIwIbsHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аПιТоυςЮΦ():
    if False and True:
        457
        pass
        _dead_7274 = 285
    value = 712356
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('R0NkckV2UjVNTnF1QTZGcG1sTk8=').decode('utf-8')
    if 52 * 98 < 0:
        179
        _dead_7696 = 751
        pass
    total = value + len(text)
    return total

def _КУщрЖУγцΗЗΙМЕЦДψ():
    value = 742195
    if False and True:
        _dead_5989 = 461
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQTDPnAO+4QmGQC17F6yGiABsW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΥβыΚШиΟ():
    value = 906898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiHFQWMQ7PwAa1aF8HCTMCwG51w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖκцЯйξчР():
    if len('') > 0:
        pass
        375
    value = 526060
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADywXmAo7IIxHAiGzXegHREE9kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_5452 = 65
    total = value + len(text)
    return total

def _ΠкАъЖΖψЙ():
    if False and True:
        pass
        _dead_5984 = 262
    value = 406223
    text = __import__('base64').b64decode('bWlFcFVCdkxPUUZxS3EwN1RZRGU=').decode('utf-8')
    if len('') > 0:
        436
        pass
    total = value + len(text)
    if False and True:
        _dead_4109 = 563
        820
        608
    return total

def _ТβΕЙνΑΘмбνωλЗЪНТ():
    value = 841933
    text = __import__('base64').b64decode('QXBnUDdUVTJXVllqRllRd1MwY0c=').decode('utf-8')
    total = value + len(text)
    return total

def _рΥδпπНΗΡψХн():
    if False and True:
        1000
        _dead_6290 = 504
        pass
    value = 370447
    if len('') > 0:
        941
        _dead_5703 = 537
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnnVVFAfxPE8OBaB/1mmB3QH0X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        667
        pass
    return total

def _ΒΠюАФΚПХΜзΕГ():
    value = 523926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky7WNm4Q84USAyDwnXSUBBQn/nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΦΙФθΠεиυДЮΓΦμΑΧ():
    value = 461723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgTyPWUp0r0SIjeI7l+9H3Eosnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΔΠυиΠΦλι():
    value = 415590
    if False and True:
        _dead_7337 = 583
    text = __import__('base64').b64decode('a25uTjBJdUJRTExZbVVUYXB3Rzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΚΖφытαФΚ():
    value = 274306
    if 58 * 52 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwLqWHMh1/pVaAKN7mGmOiEG8Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 38 < 0:
        pass
        _dead_5385 = 451
    total = value + len(text)
    if False and True:
        42
        696
    return total

def _хЩпНΟΝьззфχ():
    value = 263148
    if len('') > 0:
        _dead_4369 = 76
        _dead_4991 = 505
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxXuN1M00PoPIyO340CqMQMDxUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        899
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_1621 = 817
    return total

def _ХьЦΣэПмй():
    if False and True:
        pass
        295
    value = 920102
    if 35 * 79 < 0:
        860
        181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cgv+X0VprP4uFxyU2k+GYTADzHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 8 * 19 < 0:
        _dead_4574 = 738
        751
    return total

def _мξΨΦΓхΣУ():
    value = 1424
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('ajlzZHp5dHhRb3RZVENOdWFxY3o=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        386
    return total

def _ВъьςлюΓςημ():
    value = 333661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwjyQAMD1JcZaAKN30G8PgQssjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СдΖΑуΕРυиο():
    value = 888299
    text = __import__('base64').b64decode('QWdxbmRadmJfWnpINV9EWWpfVTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗμΓΥЭΧжφΓΦЮ():
    if False and True:
        30
        513
    value = 848106
    text = __import__('base64').b64decode('Qk4wVEUydkxtcm5uYVo3TWUyQk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΜаздΒΠсωхФ():
    value = 652610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSXQZ3Yg7ocmORuB/AWVbXAnwzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΨмΑЬκδоΖЯκСμΣ():
    value = 116943
    if 81 * 50 < 0:
        _dead_1075 = 120
        pass
    text = __import__('base64').b64decode('eUZ1d2dfVlRnYjMxdXFnQ0NKSDg=').decode('utf-8')
    total = value + len(text)
    if 2 * 43 < 0:
        _dead_3007 = 47
    return total

def _ЬАкъλЗΛпЯЖωЕξ():
    value = 233155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aia8Q3UU0IELEB6IyQ+5Hg4+z1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υзΒΤμρЪхы():
    value = 26223
    if len('') > 0:
        _dead_6701 = 837
        917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhCzdnM+7b05Fij131C6NzQp5zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 72 * 43 < 0:
        pass
    return total

def _ρΟμχСФωЭЖНяЯΧΑΔ():
    value = 369758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny6xO0Zp/bgSLiSUkH+iAism4Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЯЬЫФΝχΒΨΠψΜб():
    value = 222561
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDrLV18cyZoGPiKs5m/FHjcg1jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΠыσζХΓεдрΗΞсНΙ():
    value = 41938
    text = __import__('base64').b64decode('bGxPTmhGXzlrS0RXenlybnV0SWc=').decode('utf-8')
    total = value + len(text)
    return total

def _АηΡГΜπΜηНь():
    value = 148030
    if 39 * 99 < 0:
        931
        _dead_9429 = 919
    text = __import__('base64').b64decode('THJLQkpxU3B4bmJxVk1CRTF0eFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚУΚωФйиςВЛ():
    if len('') > 0:
        _dead_8463 = 372
        _dead_9513 = 819
        _dead_3877 = 321
    value = 633258
    text = __import__('base64').b64decode('UDh4U3dXSWhKR3d6N2JTNmYycnU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        327
        _dead_5784 = 566
        _dead_6112 = 512
    return total

def _ΜСжΔкЦΗΖΟшΔιшΖХш():
    value = 411129
    if 96 * 65 < 0:
        614
        55
    text = __import__('base64').b64decode('bUJYR0l1ZFVRMWtKamZBR3dJeHo=').decode('utf-8')
    total = value + len(text)
    return total

def _юΘбКБςβоКΑв():
    value = 264488
    text = __import__('base64').b64decode('UFpGUHlPMnJTWWlhcmlHVjRuaDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΙΟыφЙΘхθБωΤς():
    if len('') > 0:
        _dead_6136 = 167
        24
    value = 755889
    if 82 * 45 < 0:
        631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRbgbUYjqb00Yjv74VLDH3YW/U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        858
        pass
    return total

def _ЫΝДβЖЬΦξфλγвЭΗЦ():
    value = 693238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSOwa2BvqJ4tKD+ly329ZiYNwVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рНСЭгшΦΡебнψьЦΦω():
    value = 662284
    if 92 * 26 < 0:
        507
        _dead_4283 = 965
    text = __import__('base64').b64decode('TGdOZUdwVGVfOVpwRDlkTWtSMzY=').decode('utf-8')
    total = value + len(text)
    return total

def _οΝΝωυκъыΧуз():
    if False and True:
        _dead_4085 = 335
    value = 759251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByvKUV8x/IMbGyKt2X2RDBELtmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5120 = 445
        pass
        952
    total = value + len(text)
    return total

def _ЯДЮФκΕашψФМзКЛ():
    value = 316788
    text = __import__('base64').b64decode('Y3JtMGY2cmRsWEFBQlg5V2VWYmM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        71
        pass
    return total

def _λεμКпЕυЕΩнЗЪς():
    value = 891853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECbKQGcO94I8Cgn0y1OhODcI3Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙЕэΒжΒЗγ():
    if 50 * 64 < 0:
        473
        pass
        290
    value = 108955
    if 60 * 50 < 0:
        365
        _dead_7497 = 675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBbHTVUS3Y4aMCilxH2EPAEuzX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 87 * 65 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЙОБπΔХЖДэзρξ():
    value = 219002
    text = __import__('base64').b64decode('dl9GWXBUTmVzajY5UWNIWmMwSlc=').decode('utf-8')
    total = value + len(text)
    return total

def _λΔΦξшнВсπнбЬ():
    value = 579998
    if False and True:
        _dead_5890 = 151
    text = __import__('base64').b64decode('QklVemRCMkZxaFMxaGF4MGZFX24=').decode('utf-8')
    total = value + len(text)
    return total

def _хГΓЩμхФа():
    value = 400232
    text = __import__('base64').b64decode('VGhIeVdUYVRBZF9fM0FHUExlTVU=').decode('utf-8')
    if 96 * 50 < 0:
        _dead_4566 = 549
        237
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЬκкσσΕΚХ():
    if len('') > 0:
        _dead_3084 = 731
    value = 214997
    text = __import__('base64').b64decode('QkU2b3VnR0FCV0tvT0htODdWaUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΦωΗδΗτыЩйΖЫгЫγ():
    value = 873033
    text = __import__('base64').b64decode('aUJxel96Y0pmRXMybTFwejFjTU0=').decode('utf-8')
    total = value + len(text)
    return total

def _БЫиΤρчχСс():
    value = 885203
    if False and True:
        _dead_8211 = 544
        506
    text = __import__('base64').b64decode('WTZqY25SNkR3c25Xd1JHdDdTS0c=').decode('utf-8')
    total = value + len(text)
    return total

def _яФМΞζЫγЭбЫДЯ():
    value = 389406
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCntekIR64ZXIAyC4VKmZjwiwkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        132
        848
    total = value + len(text)
    return total

def _ςΠςхΒΑΤдЭБ():
    value = 844151
    if False and True:
        _dead_6257 = 548
    text = __import__('base64').b64decode('YTZQR2RpUjdDXzZwTUdqNGNnazU=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _бΓОΚжЯчΔпЪαΨИπ():
    value = 979479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj/+NmAj6/ELEjia5HGdOS8Otjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШПОΝΝИжπζВаθзП():
    value = 655677
    if 68 * 64 < 0:
        _dead_3827 = 817
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwTmPFgG7JsrCR+CzVSlPSI2wFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1400 = 616
    return total

def _ΗψΝБΕξηьФбι():
    value = 940701
    text = __import__('base64').b64decode('bzU2WG81OTRtNW5EUkZaWjltc0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯгЕаФзμтнΟЗьрН():
    value = 528100
    if False and True:
        pass
    text = __import__('base64').b64decode('enUzYV83WGRMY2NkVzhQdUdvQTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ρщψфЪξхΑ():
    value = 746787
    text = __import__('base64').b64decode('RUp3T0R0Zks3UEJEdU1RN3JWNmY=').decode('utf-8')
    total = value + len(text)
    return total

def _чЯαΠВΥиЦΞΑτлκЕ():
    value = 491130
    text = __import__('base64').b64decode('VGNVN1JPOEJqTkdGMEVfMnZaMkI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        923
    return total

def _οшИσΗцЗσЗτИСИΥλр():
    value = 215126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnuxVlc4qIMoDjyF/1CzNxcr/lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΩЖψЬеАωЖΗΝБιЯ():
    value = 78853
    if len('') > 0:
        _dead_1792 = 702
        pass
        pass
    text = __import__('base64').b64decode('dkJQUzFMTHNCYmlZUnlEVU1jTXg=').decode('utf-8')
    total = value + len(text)
    return total

def _вшΟдρΙЫПц():
    if False and True:
        _dead_9946 = 349
    value = 866337
    if False and True:
        339
        277
    text = __import__('base64').b64decode('dHllcFJWUmF2cGpsZFAxdnVuSDI=').decode('utf-8')
    total = value + len(text)
    return total

def _цηκζыΨξΣеνФзП():
    if 12 * 9 < 0:
        532
        pass
    value = 962113
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyLiY3IKyqQoESKinFOoNQsA5ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕбμоΙαчζЛюуμтψ():
    value = 468417
    if 25 * 21 < 0:
        560
        _dead_9491 = 59
    text = __import__('base64').b64decode('ZW4xUE5tb2NYTk51QjAwM3hlR0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЗэЫСшΟΧνιΒ():
    if False and True:
        pass
    value = 17845
    text = __import__('base64').b64decode('dWVsdVVhcFBfSVZ6Tm9FSnZlcDI=').decode('utf-8')
    total = value + len(text)
    return total

def _φъфШоΑШэβЕΥΕЦ():
    value = 528866
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT31dgks3b0XFiCS0F6/IXI9/lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 63 * 2 < 0:
        pass
        _dead_2794 = 677
        423
    total = value + len(text)
    return total

def _чШΕттцЗВΞ():
    value = 904275
    if 92 * 42 < 0:
        pass
        791
        752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NybWOwYv1Z82F1mTnFWAFxQq3FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        834
    return total

def _αψпГЗΟЧйηυΩл():
    value = 883304
    if 76 * 99 < 0:
        _dead_1952 = 236
        pass
        pass
    text = __import__('base64').b64decode('YVZ2UFlKbjJlb0tzc0dTdnhzSzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΙЩкΥΞаδΑαКЦωαЭ():
    if 8 * 21 < 0:
        978
        905
        696
    value = 905886
    text = __import__('base64').b64decode('TFZBY1dFdVFjRmJoTzVqVVVpVGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΠМζыОΞΝςшШкΜЪнЩ():
    value = 117794
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dyrte2U8r5E2IwiGxW61EBUn218='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖδЧοАзшДΟЫφΒЦзЯχ():
    if len('') > 0:
        pass
    value = 305521
    text = __import__('base64').b64decode('STJ5d2d5OFZ5QzFmbnVxWkNTNzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _οΠТЛΡуκΙρрЮЗъδ():
    value = 737357
    text = __import__('base64').b64decode('VFBaMFVvRVBaSGo5RzhLNzVqVFc=').decode('utf-8')
    if False and True:
        91
        4
    total = value + len(text)
    return total

def _ιΥуИπПдΠтΖАъΡпнτ():
    value = 141782
    if False and True:
        733
        231
        431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAK2dAU11rkWMBWS6QeZBB0m3UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        71
    total = value + len(text)
    return total

def _ΡгШΡργδЮЗφГΙЮ():
    value = 890715
    text = __import__('base64').b64decode('aFJQNm5ZQTUyNHJnd0ZKUWFaeFc=').decode('utf-8')
    total = value + len(text)
    return total

def _хΗВππЩαш():
    value = 206012
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCX1dgcc2KkhKiaTx0eZFxMD72k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯъСευцЩчω():
    value = 817878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHbXWUEyp7EyEQaB/m6RZik8/Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХЪΨΕπЕУΖзПΖюΦΛГ():
    value = 533396
    if False and True:
        _dead_4199 = 213
        109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwHxfl4z//wUNwemw1jFMzIV3Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        862
    total = value + len(text)
    return total

def _аХΦψгΗγΒЮЕГΓ():
    if False and True:
        _dead_9690 = 510
        pass
    value = 868759
    if False and True:
        _dead_6465 = 453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBvnNlwcqYUNKCuvnG+2PQws8DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6385 = 435
        _dead_8632 = 156
        672
    return total

def _СΚфρЯХоπψЬнктΕΛ():
    value = 619662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQbBZwlhqbAhDAv06XKcAzIt4ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МζЫЫЕЧΙТΒ():
    value = 239883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBnIY2MN6IcqIy2S3AC0Zwl6tns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πκΛуρчςЮ():
    value = 130761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CALbTwRp8KsrKgqkzGWeAw0c4lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙзМГοχРяыЧΤΑЮаα():
    value = 104131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgnbbQEI+qE3Kwu35neALQQjsno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΣΥяаЬΝк():
    value = 564367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQvoensY+74wGz2g3UPDI3wlxkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8077 = 174
    total = value + len(text)
    return total

def _шψΕυρвΠΠцτΙΩ():
    value = 307071
    text = __import__('base64').b64decode('SnhyT3VoZHB3bk9jT2RKZ0FxMk4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        70
    return total

def _жчξрЛΑзбЪщ():
    value = 247636
    text = __import__('base64').b64decode('YWZLX3ROd1NfMkQ1XzV6eWllTHY=').decode('utf-8')
    total = value + len(text)
    return total

def _зΑΥωςΗДегΦьЧрыНζ():
    value = 305151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAK9UV4V8/4VLxW60WS5YzIX8VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΔБИФΓыоδбЯΣψ():
    if 35 * 25 < 0:
        351
    value = 236548
    text = __import__('base64').b64decode('dVlqczFoSHE3T003RzB5X08wWXM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_1029 = 960
        pass
    return total

def _τЬЧΔПΩХΙυюъΖаЕ():
    value = 152826
    text = __import__('base64').b64decode('T2RRZjJ6bEFpd3RDN05xUmZrV20=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬКшΚσфмъырКψА():
    value = 932167
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kze0Q3Y7xoM0FSmJ7WG1My09/js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чшАκΧΗлνдаγθаБв():
    value = 317945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn7uYwgg7roQYwer33K0ZQ0/0Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΞеуΔъПΙΒНΔыΕ():
    value = 661135
    text = __import__('base64').b64decode('d3FWeDkwVlBmNVRDRUpJVFNIa0U=').decode('utf-8')
    if False and True:
        12
    total = value + len(text)
    return total

def _λкЛμЗнβшчУΕнΔЯδ():
    value = 522856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3jRQEkpqIUiYyb0y3S3IhAh/Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΗбКСΜмΨдтρ():
    if len('') > 0:
        _dead_7587 = 681
        _dead_6825 = 411
    value = 620929
    text = __import__('base64').b64decode('dlZ0NWtHS2Z0ZWhBMEg3Uldyd1Q=').decode('utf-8')
    if len('') > 0:
        _dead_4154 = 936
        pass
    total = value + len(text)
    if 12 * 27 < 0:
        pass
    return total

def _тЛаΧΕγВеΥ():
    value = 276545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBr0awQv76MmGDz15VuAYAY89z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        313
        pass
        175
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1801 = 956
        pass
    return total

def _γυπΣчбΓсγ():
    value = 101307
    text = __import__('base64').b64decode('Z3d4RVNlSDM2SXJ1NGxvMURVUDk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7772 = 800
        108
    return total

def _дТΠΔΣωСΕЪдэгφπΩл():
    value = 963590
    text = __import__('base64').b64decode('bU96RHhVcE5remhpa2FwbEVMNWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЛЮнУΚωωъ():
    value = 571774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MznNPH8/+5gbPgr093WHIzQuvUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СИΔдбяτФ():
    value = 589171
    if 81 * 28 < 0:
        pass
        pass
        _dead_1406 = 510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LS3wRGYIrb4VCV+5nVKiGAAD7k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 63 * 82 < 0:
        88
        _dead_8517 = 100
        pass
    return total

def _ЪσзРνμПЦ():
    value = 44117
    if False and True:
        274
        93
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kz3rYnIx2qEQGR+A62HJLhAX0EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йЮΡΗςωгωзшэλХζц():
    if False and True:
        pass
    value = 640498
    text = __import__('base64').b64decode('b3locWFzb01XenpCcEVrcjE3UXE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3244 = 850
        _dead_6855 = 191
    return total

def _ФЕλЬταЮШьΙКэ():
    if False and True:
        pass
        _dead_7760 = 507
        _dead_7886 = 293
    value = 923754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgvIQAk7zYoVal/10nSeM3AVynQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        258
        _dead_2571 = 710
        pass
    return total

def _ΤЪАνТκξщЪМΙы():
    value = 686189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AySzalAh+r1VLyqN93uFBQQHtD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_7334 = 390
        _dead_3511 = 831
    total = value + len(text)
    return total

def _ОеΡЩющкЬΖПΖщЛн():
    if 75 * 13 < 0:
        923
        pass
    value = 174207
    text = __import__('base64').b64decode('TWhzOGZEWm9Zczhuam40blFtam8=').decode('utf-8')
    if 22 * 12 < 0:
        515
    total = value + len(text)
    return total

def _ΕгΜэЕДΝοъ():
    value = 374161
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iy7eVnAu8/EEC1mr4Vi/Yjx63Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КчОδунΛъεнΚ():
    value = 165487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwnoW19trqUaPCeS4HW8OnB8sGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕυИςБΝьζъτьн():
    value = 309460
    text = __import__('base64').b64decode('QjFJRW52UmJjZXJQdDdTZlg5eHA=').decode('utf-8')
    if 64 * 81 < 0:
        pass
        pass
        596
    total = value + len(text)
    if 92 * 34 < 0:
        _dead_1498 = 556
        pass
        pass
    return total

def _ΔЦωнзΓпЛΕАпЯΕΚ():
    value = 961883
    text = __import__('base64').b64decode('b1owQ2hjZTdMeFhfdlRqMTBSRjk=').decode('utf-8')
    total = value + len(text)
    return total

def _еЛэςМдПш():
    value = 236584
    text = __import__('base64').b64decode('akd0X3hLZzJOS3RxMU5XOVg0cDU=').decode('utf-8')
    total = value + len(text)
    return total

def _дЖΨηПΖКЕэΠοδюй():
    value = 361692
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjvVYXYy774nPSiqy2zGB3cFtGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηЭЫАσΘЛψьбшπψ():
    value = 568824
    text = __import__('base64').b64decode('eTI1ckxqS2MwRUtkU0k4WkkxVlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥθбΩШΛЖЛЧΗΑΓΣи():
    value = 233437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARqzRmUrx7kFLBeu3neCYCAg81Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 91 * 9 < 0:
        _dead_2787 = 375
        pass
        874
    return total

def _нмжВцИΨΖυЫΣККн():
    if 92 * 22 < 0:
        _dead_4159 = 399
        pass
        pass
    value = 679660
    text = __import__('base64').b64decode('RUl2QXNtYl9wbjJJQlNyNnp2dk0=').decode('utf-8')
    total = value + len(text)
    return total

def _уαгΡлΖеΛк():
    value = 187962
    text = __import__('base64').b64decode('bkVnOUVsbWQwSmNzMXR5N1h0cWw=').decode('utf-8')
    if len('') > 0:
        _dead_7926 = 33
        pass
    total = value + len(text)
    if False and True:
        452
    return total

def _τЪЯеψХУс():
    value = 154946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BinqdkILyvFTMl+63wKKJHcsyDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΕсβкηыП():
    value = 204463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwDrVAVq64c7Yhjz/VWbBQYovXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПЫЮЩρЩЭΩоЯΝбδΥΡ():
    value = 661638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhrNXFA0058HOBiW8G7EFxQG51w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΟьΣеΟμСΤζФξЛδлБΠ():
    value = 451812
    text = __import__('base64').b64decode('VTFxalJKUlhMbW5iT2VRb3hNSW0=').decode('utf-8')
    total = value + len(text)
    return total

def _цЩКηуЬЛчПсΩοвя():
    value = 386126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiLPdgYp8ZsCHQKz7Fy6OTI89Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЮΝπΖШуινηοοТ():
    if 92 * 47 < 0:
        pass
        pass
        528
    value = 796336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjbFRmkW57sMNQmL/W+zHTEKsUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 29 < 0:
        _dead_2502 = 203
    total = value + len(text)
    return total

def _ъεКзЩжκΕε():
    value = 86502
    text = __import__('base64').b64decode('c29TeGpydkh0bWFZbHFvbExtWnE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗиДЪЧЯлвъЯΝРπЫеχ():
    value = 707160
    text = __import__('base64').b64decode('Y1MyT2xsVGdjYjVSSElSUUxIMnc=').decode('utf-8')
    total = value + len(text)
    return total

def _αгщЛжЪΡАлΦсбфМэ():
    value = 161398
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByzpfFog6aY2GSOS4mSWYyk24Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΛмЗФΟμуФиλт():
    value = 327805
    if len('') > 0:
        819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQfVa1g8qKMAaBrz/mCXODEu4mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔВωТΞУωлИ():
    value = 827658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAnmZUY41KpQMDic72PDIyF361g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝлμЧμιЦгтЭРр():
    value = 172358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiH+VAlg+bsTYlm190+jHhUEt1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηЦΣΟоечиЬπЫ():
    value = 151013
    text = __import__('base64').b64decode('bkJha0NOT3ozdkIwd1BmMGJQTFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧьМθПЯΜтьбΑωΡмлΡ():
    value = 279821
    text = __import__('base64').b64decode('bXlPa0hJX1BuMVE3bmoyZmFLeFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔηΩыъфυЩ():
    if len('') > 0:
        pass
        439
    value = 697813
    if len('') > 0:
        pass
        541
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgHOP2seyIAOa1aW8HKDZQMJ6G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 7 * 78 < 0:
        pass
        pass
        _dead_7203 = 64
    return total

def _ЕЦмЖγдΟбυц():
    value = 735923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BybTZXQf0/8JFlag2WabDgM2s1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЕЩОαРΡТΛЫП():
    value = 294871
    text = __import__('base64').b64decode('eVp3TGZPVHloMzhoRTZvM2hDTDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖОБσъΤпЖΞΜБ():
    if 80 * 38 < 0:
        303
        971
    value = 595690
    text = __import__('base64').b64decode('bEFyMXpIYnlEVlFLeU1UQ2xHTDQ=').decode('utf-8')
    total = value + len(text)
    if 73 * 55 < 0:
        pass
        _dead_4604 = 501
        pass
    return total

def _црцИтшкшЖξЛСЧΕП():
    if False and True:
        566
        _dead_4025 = 6
        _dead_9511 = 224
    value = 449633
    text = __import__('base64').b64decode('bTAzeV9PSTcyd2JrcE1xR20wWGk=').decode('utf-8')
    total = value + len(text)
    return total

def _жЖκΜμЗСЫΛς():
    value = 991491
    text = __import__('base64').b64decode('RkhTNV92WjNvRTEyWThLRF9xNFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЖяΗλΝγΘран():
    value = 852660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhyxT30I24YzAh605gPANQwesU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШетжЧЬЕΜРΦВотТ():
    value = 298293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID6wXlUdproUbg6ZykCVEi0t8zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1146 = 12
        pass
    total = value + len(text)
    return total

def _ΖАГвΤЦεуλишр():
    value = 748189
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDn9S0gNz70OABaz3nS8PhIk73o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6252 = 526
        _dead_2292 = 922
    total = value + len(text)
    return total

def _λОТКОВζФ():
    value = 437562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiSyXnoN8aE8LSyV+E6UZi8syH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΟДЮрΣчИЕх():
    value = 761252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXrAO1Bhr4IvLSm06gWgCwghsHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8375 = 933
        496
    return total

def _ьУΧχцЕМГΡфчΥеужю():
    value = 152978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgHuR30J2qAxCV67kAepIC8ByXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5227 = 624
        _dead_3609 = 558
        pass
    total = value + len(text)
    return total

def _счРЭыΜωςъЩιБγжΝ():
    value = 403985
    text = __import__('base64').b64decode('bjc0OGpxS0xpOXlqYzVjQkVQR28=').decode('utf-8')
    total = value + len(text)
    return total

def _йαИΛылею():
    value = 542456
    text = __import__('base64').b64decode('d0JnWkczZmhLNE9GN0JXTDlGYzM=').decode('utf-8')
    total = value + len(text)
    return total

def _κΕηыъжСеηΚцФΛμ():
    value = 84877
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRnuZwk47oAIFTWX5walNw4Y9mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цγωНюμКыжΓΜζσ():
    value = 84840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HALMeAgp64kzGF2n61KCFzwV00w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 80 * 47 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    _dead_6586 = 966
    pass
    994