#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _УφаЖЗСΖςоΧщйυ():
    value = 763668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwncSmYOxpBSAAKE/VGvIAsg6X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕζυλΓлФυДяДθию():
    value = 310986
    text = __import__('base64').b64decode('WEM5dExJZzlYX3FOc1JFazBHeHE=').decode('utf-8')
    total = value + len(text)
    return total

def _хВΩιэΣЯЩΖ():
    if False and True:
        928
        _dead_3689 = 569
    value = 993544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyXNT3IT9r86C1iLxlOAMwYm/GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5463 = 535
        pass
        _dead_3268 = 938
    return total

def _ЮЪАЫуΤκМη():
    value = 825041
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ew3OZGAL5oIKFFakmQO+DSc3/lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛХВκпЙЦжΔбЙ():
    value = 97941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjexOHU88YQ5Ex2AzWC+HAYB1Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧДвТРвБΣ():
    value = 744297
    text = __import__('base64').b64decode('bG5aNzVJVE1zVXh1SU96N1RScVo=').decode('utf-8')
    if False and True:
        _dead_9037 = 502
        _dead_6990 = 684
        979
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _еΘчΖбΖεГυЩβЯΩА():
    value = 909907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISLnb0cd850aal3wnnCfZikbzDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗψГлДящхμθяЩпы():
    value = 942947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aw3Uf3k0rbosbiOC2kKvJgkt/Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОУΣЖрαШфЬγлбюШВ():
    value = 932865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASvWRkct9aVTIwOa8nieYTEIs2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШζЕУЩφЗЦоНγΧСΙΞ():
    value = 382040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PB29fgUVwZEyYl2CzGLIMTA4sFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 2 < 0:
        pass
        715
        pass
    total = value + len(text)
    return total

def _ΕЭиπЖΡЗζΔθШЭв():
    value = 571093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3/qW0UX7rEyMguL93ynAiR78lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_5541 = 218
    total = value + len(text)
    return total

def _αЗδλдсШТсΑω():
    if 96 * 22 < 0:
        pass
    value = 731951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgnJUVky/4wyGCap8WWWNhIasTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΚыπνφйьчζзкпл():
    value = 235098
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az/ub0gup4cwaxiNz1+2Zi8i4Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иεχΘЬΠПΥζΓТΞΓяΥ():
    value = 572255
    text = __import__('base64').b64decode('bllZc3ZPMjRMeHl0NFl4ZnFXeHE=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ВжбэХΘθρФφπтЙ():
    value = 813433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('My7JQnwu/4wCLl6B/1nJEyQ1zlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μХюжъфцТ():
    value = 945682
    text = __import__('base64').b64decode('WFhlQlhabDd1RkVQRjExMjJRa2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚАθиδΓРТΟЮдΠаωИθ():
    value = 116096
    if False and True:
        _dead_2158 = 230
        932
    text = __import__('base64').b64decode('Q0dTa1dmSUZfVzRLNEJJaVBBczE=').decode('utf-8')
    if 88 * 81 < 0:
        _dead_9819 = 438
        _dead_1944 = 153
    total = value + len(text)
    return total

def _πδвъСωζНУмфГνЬщ():
    if False and True:
        pass
        _dead_2823 = 691
    value = 363824
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxrIVF0aqrwNKj2OwmSYZHE27jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΣτδгΝΛхσχеωсΝΥ():
    value = 409711
    text = __import__('base64').b64decode('bDJLRlpIWEhHcTMxdm9LQ1hIbkw=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЬСφΣнΝδэρΨАшуУ():
    value = 465897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh/jZVxr5rsELgiA6UyiHip/vWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞъΖιωЦВйяκΣ():
    value = 860469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwzpXXg926AmYymB/XmaIC0X6E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρаяГΟсψшИ():
    value = 81714
    if False and True:
        173
    text = __import__('base64').b64decode('eXN6XzBUOGlfb2ZxTTQ0YzlBeFY=').decode('utf-8')
    if False and True:
        _dead_9527 = 287
        _dead_7533 = 743
        _dead_1260 = 843
    total = value + len(text)
    return total

def _ψЙэЩкδыρгΗφЪТ():
    value = 67240
    text = __import__('base64').b64decode('dXBkVmhsSUNsOGF5WWhZRXZaMkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΗЯХшВΟжΝШСэЯΓ():
    value = 841144
    if len('') > 0:
        902
        518
        992
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSLcNwA1ppFXBV+ixGSbORENykc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 17 * 99 < 0:
        pass
        _dead_3701 = 743
    return total

def _ФгαΕйюυрΑζпΚΔ():
    value = 818426
    text = __import__('base64').b64decode('QVZiUURVWnpwdThhazdyN2JOeDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞрΖЕгйГбш():
    value = 267179
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjnNUWcp3fw8C1uR3HuCPS03zjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        418
        pass
    return total

def _ΔшЭтхτСЛСфВ():
    value = 491675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AijcSXQ25KkBETuF5wHGZ3Z8z14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟδчμπюδΝчМ():
    value = 708055
    if len('') > 0:
        880
    text = __import__('base64').b64decode('VkJMYk9oeDhKYlRoTEQ5djNNSFY=').decode('utf-8')
    total = value + len(text)
    return total

def _υЖЖΥΟχΛяУЫЦ():
    if 44 * 37 < 0:
        _dead_3297 = 354
        pass
        _dead_1959 = 971
    value = 380351
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyvJSlU+qvAEHBeT6nSHLTcQvGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПθЙξλЦΤγ():
    if len('') > 0:
        792
        _dead_9597 = 915
        124
    value = 978377
    if False and True:
        _dead_5822 = 710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HybcP14z+4BTOVaF5ka6AhR37Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠйВΖσЫΠδцркСэΓ():
    value = 322364
    if 45 * 1 < 0:
        420
        pass
        498
    text = __import__('base64').b64decode('TUdMb3J4UElxTlRPZHZ6NmpKWFI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8708 = 492
        _dead_2664 = 227
        pass
    return total

def _ФΣψενκгςХННгЛКф():
    value = 341646
    text = __import__('base64').b64decode('QTluOEZhekRxMWxaYXRyQmFjcE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪкΞВкицΨλеХ():
    value = 369318
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Enm2Ql4M0YMXMFaXnX6fJxx88Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5189 = 503
        451
        _dead_1747 = 154
    total = value + len(text)
    return total

def _ЗΟθκяГъгЬΟТнΝ():
    value = 891955
    text = __import__('base64').b64decode('S0RRVFRwQTVJeHF4Tl9XMkVlX0U=').decode('utf-8')
    if len('') > 0:
        _dead_1992 = 49
        _dead_2610 = 71
        pass
    total = value + len(text)
    if False and True:
        867
        523
    return total

def _νЫΓΙγыΟхф():
    value = 220640
    text = __import__('base64').b64decode('UHRQZFZhajdnalpyMDJVX09aRG8=').decode('utf-8')
    if False and True:
        _dead_4035 = 625
    total = value + len(text)
    if len('') > 0:
        _dead_4352 = 46
    return total

def _утИиШНιТрΩьσ():
    if len('') > 0:
        pass
        _dead_6890 = 518
        pass
    value = 166835
    text = __import__('base64').b64decode('bWhfUzlOT2hDaER1TmRWU3FvVjU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_6692 = 294
        _dead_8922 = 893
    return total

def _ЬЪοзКбΞνЪ():
    value = 882411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDjpfUZszYk1NDWuwVTFGCA+s0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σцρмδοΩΑψΗε():
    value = 689689
    if False and True:
        111
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICjWVGMh+5cRHDr24QODHRw8y2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _аΓσΟмηυρξЮΩВчпр():
    if False and True:
        _dead_7639 = 123
    value = 660873
    if len('') > 0:
        _dead_2142 = 56
        pass
        pass
    text = __import__('base64').b64decode('eXF4VEpTZGtXdlVDWW85NlhCTVk=').decode('utf-8')
    if 97 * 10 < 0:
        99
    total = value + len(text)
    if False and True:
        _dead_7663 = 833
        pass
    return total

def _щαлΔιЫреΩфй():
    value = 555135
    text = __import__('base64').b64decode('VDNMajM3NXhrVTV2RDNnbnpXQXQ=').decode('utf-8')
    if False and True:
        _dead_4705 = 263
        pass
    total = value + len(text)
    if len('') > 0:
        64
    return total

def _ιΗЗУΝΒзΓΟдБμЕΞйβ():
    if 60 * 94 < 0:
        445
    value = 62247
    text = __import__('base64').b64decode('aVlDTnFHUnZzaVptbno5M2tjZXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΠпλΝФаΘГАмΕ():
    value = 360238
    text = __import__('base64').b64decode('UWhmX01GTkViVUYybGR3ZFBvUW8=').decode('utf-8')
    total = value + len(text)
    return total

def _гхξΣаУΦΞПΥу():
    value = 17956
    text = __import__('base64').b64decode('eWFlb1lXNzBLNENoamZvcE9sakc=').decode('utf-8')
    total = value + len(text)
    if 53 * 20 < 0:
        pass
    return total

def _μъρЦТθΝΡΔжυнζуЕ():
    value = 783738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAzAN1xrrYEOLRn05EWSATwQxUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        478
    total = value + len(text)
    return total

def _ΣеТлуηДΣьяяτдзЗ():
    value = 243737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnbgS1gI16c2Ex+h+GWVIgAj6VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤРжυВНχЙЯьфэЧ():
    value = 856464
    text = __import__('base64').b64decode('YWdfU1RzbXFDRnZjWTg3VDJFbWk=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ψЮъΠλтюΚВгЬХΧн():
    if 96 * 20 < 0:
        _dead_2951 = 360
        pass
        _dead_3725 = 687
    value = 734063
    text = __import__('base64').b64decode('bzBiNTlSem5kdFJRbmZ2ck5TdkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΡΩЪЕСсεСΜУχЧПεΙ():
    value = 85022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRviSgEA2vE5KwSi72KcNR8i4U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψψνΩэфΤщУ():
    value = 369276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzX2fXVoyo4QMV+J8QCYA3A46F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οβРΡЪμдВΝξμоь():
    value = 98840
    if len('') > 0:
        888
    text = __import__('base64').b64decode('Tk1ncTlqYkNoY3hWSHRta0NzOFQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЫкθБτΠмοЪςфВδгТЦ():
    if len('') > 0:
        _dead_4119 = 446
        _dead_2323 = 611
    value = 242725
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBfDe19p6JExKQL15X6UIgIn4F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 79 * 75 < 0:
        pass
    return total

def _щрΟΟеΨаЩЭПж():
    value = 931135
    if len('') > 0:
        pass
        273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MALMWVMb+4kTbzz2wQGGAyMswEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 5 * 25 < 0:
        _dead_3384 = 234
        802
    return total

def _ηΠμТБОυйοИвυγЧ():
    value = 355843
    text = __import__('base64').b64decode('aUZ3ZHdMWGVuTHB5Z3F2WFI4N1k=').decode('utf-8')
    if len('') > 0:
        _dead_9203 = 391
        _dead_9309 = 339
        pass
    total = value + len(text)
    if len('') > 0:
        168
    return total

def _ШυаеΖΙΨδΜΣВЗчτк():
    value = 182746
    text = __import__('base64').b64decode('eDlXM09ZeGJzV1ZNQm5qMnNNNWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΖШΣЦΡκлΡижαμ():
    value = 155720
    text = __import__('base64').b64decode('TmdGbGFGQzNGQjJ6c01PWGY3TmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ВьρΗВЧεφΛЧПΦσЧнЗ():
    value = 662773
    text = __import__('base64').b64decode('WXZLV0Zza0J5X2JFOFZ6WGpFTEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ХιφΧαцθиΒΘπΕУУи():
    value = 387589
    if 69 * 67 < 0:
        213
        pass
    text = __import__('base64').b64decode('ejN4cUhLaVZmUlplell2UXhpbng=').decode('utf-8')
    total = value + len(text)
    return total

def _ъоΔЯΒиЕЮζΙΦюЬΒο():
    value = 419666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiXQOX8w05EkCBW54HygNgMEzVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩκЛΙаюφωДз():
    value = 302739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRnbW2IW8PAJMASA5FmpPxwkxUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αЧхЭнΠΧЪι():
    value = 888984
    text = __import__('base64').b64decode('TEN1RGd1bGc0cDJLR3JNaDlSYkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝπНЧщμцΑБΣιΑМэМω():
    value = 637020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjazT1UY2aMROxep6g+DEAgGsng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πЕΜЭпΓκнΤЪΠψВЙ():
    value = 341504
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nhbxel0wx5sKGzqK5FXDJiI3/mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щВлδΜЕрνΙхЦΒΔ():
    value = 214027
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhizX2Vu1oMEDwam7m7BGCMayFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 49 * 59 < 0:
        pass
        _dead_8600 = 294
    return total

def _ЮγТΦЫΔΙγΧΠу():
    if False and True:
        365
        _dead_9432 = 525
    value = 861273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBDbe2s62f0SDyey61S5PxYm1z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЬЗюжΘΑфΩщΕνС():
    value = 422617
    if False and True:
        10
        329
        99
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IibMX0RrprIZLSmVy3CWHhMi8XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 15 * 45 < 0:
        647
        _dead_3134 = 268
    total = value + len(text)
    return total

def _чνЪЦЫбΟΤПЯΖБлЖ():
    if 92 * 94 < 0:
        46
        pass
        pass
    value = 411682
    text = __import__('base64').b64decode('a18wbjNnT0R4ZlR2MDBvdmtvcVY=').decode('utf-8')
    total = value + len(text)
    if 76 * 41 < 0:
        985
    return total

def _ΨШШжАХжштБбъйЮ():
    value = 704275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRe1YlgLraUtbxn642CFCw4r1j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γкЩПХΞрΛΠьχΥωΤΥΞ():
    value = 220650
    text = __import__('base64').b64decode('WVRPUDQ4VVpIejg4N2RrSlNPemQ=').decode('utf-8')
    if len('') > 0:
        187
    total = value + len(text)
    return total

def _ИκοВвйСБΛЫЕЭл():
    value = 171251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCHATEdtrrlbHVeQzn6TN30Q9js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _всπЖЗΨуфпεΚеΜ():
    value = 129462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBvDQnkW1qVQMiqwy2C5EHwEyks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΙωеОьйЯмЖш():
    value = 921457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDfbeUAg9PgxIwORkALFMDQt00Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        145
    return total

def _κлХяЩΠЮΖΝ():
    value = 668091
    text = __import__('base64').b64decode('ZDFFUUZxNHNLWW56T21jMDZrZGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝНзюΩΛКГ():
    value = 370244
    if 92 * 96 < 0:
        968
        pass
        131
    text = __import__('base64').b64decode('R0VueHhrS01ETmR1NTlPME05c2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ППΩДαГлζПΣУ():
    value = 732375
    text = __import__('base64').b64decode('VmVSSVRua0E5dTMyNENkU3ZCYWM=').decode('utf-8')
    total = value + len(text)
    return total

def _хΓΣоβΓβЧИΚγЗΠγХ():
    value = 681509
    text = __import__('base64').b64decode('dVpxdWRDUUdYM0kzQmp3QzNuZnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣЛЯУъВвΤΖзξСυ():
    value = 560556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ6xZAFp27gNFQKC/l6xNwkitjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡАζОΛχЫЪ():
    value = 176491
    text = __import__('base64').b64decode('c2pHOXVOWWdpaHZ0WHRDTUU1Y2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΜГЬфχщΧцβΠΙНδЫ():
    value = 122972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyjBWQMtz/5XLFeBmHi2JCIb3jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кТЩмсШЕλΠΡоаЦΨ():
    value = 396186
    text = __import__('base64').b64decode('cEJseWU5eE9zYkl1R0lHa0lBMVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ыσζΙьЦВυΥЕΗΞцР():
    value = 65298
    text = __import__('base64').b64decode('elNLNUhjcW0wYU84X08xQU1XNGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒшЖΠвФΝοЩ():
    value = 667720
    text = __import__('base64').b64decode('a2JzTGkxMmRJal9UeEV4T3oxT3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΜЯΖьιзΙΒλμДАМβк():
    if 62 * 76 < 0:
        pass
        582
        258
    value = 555752
    text = __import__('base64').b64decode('S0prU21WWmJlR0ZaMzB1c3hHVzA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ξΨмПθφνПюςΧ():
    value = 420919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjzOZEcL2rooMSWF4VuiOAB63nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДнФΒβСβпЧΑЩοьГГγ():
    value = 536217
    text = __import__('base64').b64decode('VWRkZWxQOXBzR3VaTTZHelpyVlU=').decode('utf-8')
    if len('') > 0:
        254
        pass
        _dead_1502 = 986
    total = value + len(text)
    return total

def _УΣкшμрзПΛпΙБβЦ():
    value = 916822
    text = __import__('base64').b64decode('RGpybEg3VUZqWURTdFFFbUdsUFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕшаΤЮЬПэ():
    value = 345261
    if False and True:
        pass
    text = __import__('base64').b64decode('bGhySmhlZEFVVXg3MVhJY3hVVTU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7223 = 135
    return total

def _АΖΑИзхжΝρмт():
    value = 473450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDezfgMs//AUHlaIwVWVMQYd0H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хлЖяЛхыьςки():
    value = 294905
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnzxbwIT+KEWMiGi8Ve2ByIM4HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΣθЦбΙШΣэЕ():
    value = 762224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LS3DPGAsprEbIyiq0GygPQwn93s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уξЛиЛюτΖγΧτΦ():
    value = 140215
    text = __import__('base64').b64decode('WGRvUnMzejZTVTNRdXJDeE4zN2g=').decode('utf-8')
    if False and True:
        _dead_2067 = 962
        _dead_1320 = 5
    total = value + len(text)
    if False and True:
        25
        54
        567
    return total

def _ВЬΗΖμΑοпξ():
    value = 681089
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dwfcb10U8qE2ahX26UOCYDYt12s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сфΒДмξтП():
    value = 732496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh/peEYv+poQAi2h31CmDQp83Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪθдоΤλИαПΜυπΖΝ():
    if len('') > 0:
        208
    value = 647814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EC3mQXoYyP9XAyq0mViJPiQHyng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 38 * 84 < 0:
        pass
    return total

def _ΜθρцγΖОδдρ():
    if len('') > 0:
        _dead_5266 = 668
        _dead_6475 = 958
        414
    value = 111217
    text = __import__('base64').b64decode('bldzOUNVUGlJNlFFdml4U1RoRkw=').decode('utf-8')
    if False and True:
        590
        _dead_2211 = 38
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9009 = 669
        pass
    return total

def _ΠμмьЖПιсФΠ():
    value = 731822
    text = __import__('base64').b64decode('RmRNTXlnZWRHeEdVZ19CYXo5N20=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _МьЖЗфЖιζуЗ():
    value = 88199
    text = __import__('base64').b64decode('QjhqQWlxd2FCZHQ3NVU3bmQ4TW0=').decode('utf-8')
    total = value + len(text)
    return total

def _γΕτБψΓΡУЦ():
    if False and True:
        pass
        567
        930
    value = 602675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT3IaEEDyY0nKQmTmHubMRN842I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΠψЖЩПяНШЪΑй():
    if 87 * 99 < 0:
        pass
        pass
    value = 60751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBjCSAAR3b0IMQWxkFChBDwe5XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3886 = 202
        _dead_7577 = 187
    return total

def _ΒΖФебВБδ():
    if False and True:
        _dead_5783 = 829
        418
        pass
    value = 399445
    if len('') > 0:
        pass
        338
    text = __import__('base64').b64decode('Z19EVUNFWEFhanF4aE82WWUwaXA=').decode('utf-8')
    total = value + len(text)
    return total

def _мЗΘнщγАЖкъΤΩщЛς():
    value = 583035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH7pZQE+7qwtNVj05VOTHT834mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1367 = 269
        pass
    return total

def _ΧΔЯΡвΒηΨ():
    value = 594632
    text = __import__('base64').b64decode('RkpIWWZzdDFVYTh6emtCM1NGbWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΞΖφφγσпηαйиюС():
    value = 59960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgSwfWgKz64zABy05GeEbA0221Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙПТпζΛэζЯЭ():
    value = 470590
    text = __import__('base64').b64decode('RjhSRm1ha21TT25MNE5jQXNfajA=').decode('utf-8')
    total = value + len(text)
    return total

def _МωΩхγΘΦΒЬсεЙэЗеО():
    if len('') > 0:
        _dead_3296 = 970
        pass
    value = 196511
    if len('') > 0:
        614
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhvBOmYS7b4UDiqH32O4EjIn/Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5635 = 444
        676
        853
    total = value + len(text)
    return total

def _ΦцΞЖщφюЧ():
    if len('') > 0:
        pass
        _dead_3244 = 840
    value = 838925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NijpVHAj24wLbQ2h7XieFgF913s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9768 = 688
        _dead_4170 = 62
        42
    return total

def _РξΝрρкυΕЩΑц():
    value = 915595
    text = __import__('base64').b64decode('WDM1bHFqMFJMR1FoR19RQkhXanE=').decode('utf-8')
    total = value + len(text)
    if 65 * 97 < 0:
        _dead_4120 = 344
    return total

def _зСИшνБτΡыΙγλοΨ():
    if len('') > 0:
        pass
        541
        _dead_9035 = 598
    value = 62456
    text = __import__('base64').b64decode('Vm9rUGZKclNzYUFWcUZibXhVbVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ВПΨδΤΒхЫЬЮτйΟ():
    value = 396929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwfXO30W9IM8MF2Q0mKALQB24Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эγэЕпγνςЫδΧγΓ():
    value = 802346
    text = __import__('base64').b64decode('ZUwxWk95WTRvbktQaVc4Q2UxaHg=').decode('utf-8')
    total = value + len(text)
    return total

def _дВдΟюЫИвцνрξγПν():
    value = 90131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzvAVGkdpqcKFxrznX27PX0r5T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БγξИжзЭНφбΦψьт():
    value = 714991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy7GOH47rPERNx6ZkQKoHxEswVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2385 = 572
        pass
    total = value + len(text)
    return total

def _βфйΨГУПεαΠф():
    value = 134401
    text = __import__('base64').b64decode('eW1nSVZkNDRUTHdGVlFQZXp1TVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕМЕβБηΨМъ():
    value = 989683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwjUS2Qp8LwmAFyOn2+nCwcm11w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        494
        pass
    return total

def _φщΒвПйъЬПσнΔβΙгн():
    if 78 * 77 < 0:
        _dead_5234 = 659
    value = 320459
    text = __import__('base64').b64decode('WFM5YXRBZVA2bXlBMlpTdkd2Zkc=').decode('utf-8')
    total = value + len(text)
    return total

def _εξЕμνпЗжηΚδЯ():
    value = 245189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iif3RAcM7p0lGTWL2F3DNw8bzGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СβбФΒЙхюЪаюωΧс():
    value = 505042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dhm2SnM/0r4MYjiZm367ESEKzWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 44 * 2 < 0:
        614
    total = value + len(text)
    return total

def _ИОовξпπΙЗψо():
    value = 538673
    text = __import__('base64').b64decode('ZGlVa0cza1NLZ3lQUlpFMHFfUEY=').decode('utf-8')
    if False and True:
        pass
        737
    total = value + len(text)
    return total

def _ШЩЯνΚΨςВη():
    if 22 * 17 < 0:
        68
        _dead_8613 = 944
        _dead_2817 = 66
    value = 755530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dzv+ZVsq8Z0KN1f2w2CWFggI0lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        178
        pass
    return total

def _ΕЯКΡυсΕΗ():
    value = 915300
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FymwYwcTyqwLKQvz3QO5MnAA6V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИτΦθτΚВЮу():
    value = 864620
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyXOX0QV9ZobbyGEmVGYOyg17z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τξЙζμγλэе():
    value = 21342
    text = __import__('base64').b64decode('WE5ZV0dMMGFPaERCQ1dmZW5TMF8=').decode('utf-8')
    total = value + len(text)
    return total

def _вπаюПξΕФЫΣ():
    value = 254199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQDVY2I2+Ps1ElypzFWeCwh3yWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЬχΜрςνЗлΦ():
    value = 49027
    text = __import__('base64').b64decode('QkkxSVVmc09SVjZEbExrTk04SHY=').decode('utf-8')
    if False and True:
        313
    total = value + len(text)
    return total

def _ΡΓбэИαбНЖ():
    value = 246724
    if 90 * 39 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAixaXQIx5xVCQ6H/UHAZhMQyVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΞκхХΞЗЖЛИю():
    value = 984031
    if False and True:
        187
        pass
        _dead_5895 = 894
    text = __import__('base64').b64decode('cktYck1zTDUyMEFTVVc3QVBEQ1g=').decode('utf-8')
    total = value + len(text)
    if 63 * 47 < 0:
        pass
        _dead_7393 = 405
    return total

def _κЬακνидδЭН():
    value = 284482
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgbtfH4B1Jo0Agv6+2TDAHUD63Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΦδсФЫπδЩеλК():
    value = 450448
    if False and True:
        _dead_5099 = 493
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQXASAgb9fBQH1eV+V+BDAYQx28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟыРΔСΖΤГСΥлСωΜЙυ():
    value = 373818
    text = __import__('base64').b64decode('RVB1YkN3NjJwbUtCWXFMUVFUVXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛНπεФωщОКΤ():
    value = 318870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En72Rlht1KU3HiGC5AOmBzMA80s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΦδΘβπςцхэЯΝНΚΙ():
    value = 943828
    if False and True:
        628
        _dead_2205 = 394
    text = __import__('base64').b64decode('UkZlQUZJaUNKYk9aaGFTdm5sSlU=').decode('utf-8')
    total = value + len(text)
    if 39 * 70 < 0:
        _dead_6162 = 345
    return total

def _бюШРρчΟцяτрτ():
    value = 266591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgeyWlc/27AWbjj13HioYyM9tFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('bQ==').decode('utf-8'))
if 37 * 16 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()