#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _соΚΙМφТγ():
    value = 500650
    if False and True:
        _dead_7474 = 168
        _dead_3464 = 849
        469
    text = __import__('base64').b64decode('cno3el8yd2U4c1Fud3RnSXZGUGM=').decode('utf-8')
    if 88 * 18 < 0:
        565
        _dead_2761 = 332
    total = value + len(text)
    return total

def _яЖбΧΣДФяШКΘИнΚ():
    value = 107961
    text = __import__('base64').b64decode('eE10NWxsdDZEclBfb0tHN2RtZ3A=').decode('utf-8')
    total = value + len(text)
    return total

def _еθεщнπΛΒЮ():
    if False and True:
        _dead_1940 = 920
        825
        _dead_1258 = 155
    value = 993251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAe3e2I6+J4tagOg4VqUGzM492s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨρΕδыфЬцЛΔяσЬΙ():
    value = 426779
    text = __import__('base64').b64decode('ZE5vMjlPWUpobmtSTG5mWmVtRDE=').decode('utf-8')
    total = value + len(text)
    return total

def _бЬДУмΒУдэΡ():
    value = 763098
    text = __import__('base64').b64decode('d09UaUxWMzZnOG9UVEFNY0J3WTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _йΘзΥшцβΠУΟ():
    value = 189500
    text = __import__('base64').b64decode('cTFaS0ZZbXNSbEYzMjRqS2JUWXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪМКΘЩНпθΜхДη():
    value = 426034
    if False and True:
        _dead_7786 = 536
        pass
        _dead_3272 = 557
    text = __import__('base64').b64decode('Y050Q2dtcFVzaXJReXZNZVF2dVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛйΥЗβξХмυчмлβχЬ():
    value = 638834
    text = __import__('base64').b64decode('a1Q1MTkwQ0s4U3cxbl9odWEyNlM=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_9335 = 291
    total = value + len(text)
    return total

def _ДЬЙσΠнνРукОЪАшц():
    value = 128472
    text = __import__('base64').b64decode('ZklTaVZkaTV2Z25ORndXc09Md1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΛлνмΔГЧнμΙζΡ():
    if len('') > 0:
        pass
        188
    value = 305849
    if len('') > 0:
        77
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCXQbXUW0pwrEhWKx36dFjQqsXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2451 = 419
        pass
    return total

def _рВΤΟЫΓйТ():
    value = 298039
    if 8 * 13 < 0:
        912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD+yVFwpyKk7Cz+inXeIFSZ2zDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЮΛζκоηюμьΩФΔб():
    if 11 * 46 < 0:
        _dead_6783 = 718
    value = 144178
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDnsXlMx3a5XNRf00WyROhUex30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЯСρютОчНΘК():
    value = 929913
    text = __import__('base64').b64decode('aFJROTZoNFBKaXFuN2dQc2dPZjg=').decode('utf-8')
    total = value + len(text)
    return total

def _νΘΡΙЩπΠшюΕ():
    value = 195102
    text = __import__('base64').b64decode('bnpJV284b09HaFhId25yUFpueUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙыСΥςЛΚΤНяЮη():
    if len('') > 0:
        _dead_9416 = 884
        710
        _dead_2327 = 797
    value = 78537
    text = __import__('base64').b64decode('SmFqb3NOem9lcWU5YUllVXJ5cWc=').decode('utf-8')
    total = value + len(text)
    return total

def _КΟмΝнΙυΗΥ():
    value = 3322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwvJSHcI/PEkIhmW212SLDAY9GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩδйΥКзЦэКρЪκΠГа():
    if False and True:
        821
    value = 940341
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lwe9RlAS2KwBbgq2zV6iZHYq1lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 10 * 87 < 0:
        231
    return total

def _ыμΧΑБμЮж():
    value = 153720
    text = __import__('base64').b64decode('ZUlJNERJRk5ZM3hfZHFSc2ZvWkU=').decode('utf-8')
    if False and True:
        _dead_1351 = 730
        pass
    total = value + len(text)
    return total

def _σИЬμЮЩЕИяОСΘц():
    value = 489414
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCPVZWkT04MKbyiTm2PJLj938nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШφчиЩЮОпΟθМР():
    value = 730937
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAbqWF9owZtVAyqi5EO3ZjwB/Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΖυφгχбχτсХЛΤЛΙγ():
    value = 819373
    text = __import__('base64').b64decode('ZThBMFE5ZXNlZlVKdEU3Q1B6bWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΔωЗοЧЯйωзςэ():
    value = 711727
    text = __import__('base64').b64decode('WmJSanJSNFJKNzZWVDhFbWRfOFo=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЭтΥьмΒеыδπ():
    value = 574486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgP1OFIrzaYqMhmGy1iGHw8IxmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жКЭοΔΒНДΡЖЙфхжο():
    value = 972384
    text = __import__('base64').b64decode('U2R2dDczamhScUNIcmxaWFVXa1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΣΥпЧьчΚпзΗΡ():
    value = 558366
    text = __import__('base64').b64decode('b0NncE5WVDhZUHo2X085Z3Q3ejE=').decode('utf-8')
    total = value + len(text)
    return total

def _хдΤνβиЩΞΨЫΙ():
    value = 277223
    text = __import__('base64').b64decode('RTd1dXpzVGM4Wm9mMDdTMVRRcm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΨШΛΛΚущДΘЖОМч():
    if False and True:
        pass
        580
    value = 707533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyXIOnQ69aYzNiWtwVChBTUt4jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_5126 = 0
    return total

def _ΗДωΔЬζВЯуЧДЭ():
    value = 169886
    text = __import__('base64').b64decode('bGV3djYyVzE0RExtemwxSGV4Umw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧψеЖйЫАΕλуЪκщ():
    value = 746708
    text = __import__('base64').b64decode('RUhhT0NzeVlncGVYUUhtbnZNRU4=').decode('utf-8')
    total = value + len(text)
    return total

def _МвэφиПΒθπВьωΧο():
    value = 622072
    text = __import__('base64').b64decode('QldTSk90NHRoR3l4RzNrR0lvYWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ХЪЕРΧДВτЧ():
    value = 658981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQrdeEMr0pAvFTa6y3yhHAt+1GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜзПыΧВьεЯРлΙηфγ():
    value = 215127
    if len('') > 0:
        626
        912
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXn8eXw71K8iazfw50G0NRcu0z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РУУЫПξНΞуππГςц():
    value = 750139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AS3meUZp5osJPS6F73y+Jy42w0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮтΖομИζБγΟъκΨКЮ():
    value = 598375
    text = __import__('base64').b64decode('T3RQNVpCV0lRTHg3aTBTSmRrYTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΠΠΘКДηШ():
    value = 319026
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjrQPXcA3ZgsDiua43CkPC8dxnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚιЛныгйс():
    value = 335314
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwHQZ1c0+a4BP1uW3X6cC3UGyVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьφβΥгдθμμАιмκς():
    value = 583703
    if False and True:
        _dead_8153 = 775
        pass
    text = __import__('base64').b64decode('UkxfbW9VaGV5cTBjc05qZkV2Ml8=').decode('utf-8')
    total = value + len(text)
    return total

def _оΘΥХъЫАЯΒКςξЙШК():
    value = 148790
    if False and True:
        _dead_7982 = 734
        _dead_3034 = 18
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCzvUXk18oM3Fzv02weWGyI59UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ημХшβНэлмНШРЪ():
    value = 533647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDj3Ontp2v0gHAi58VmcAiYtwlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШФфуюξΒпΥгΧδфΛΟ():
    if 10 * 41 < 0:
        761
        _dead_9215 = 381
    value = 357936
    if 3 * 19 < 0:
        pass
        604
        485
    text = __import__('base64').b64decode('WlhRYzU5YVRQaHVyNF9HenJKQlI=').decode('utf-8')
    if 57 * 10 < 0:
        103
        _dead_9937 = 84
        pass
    total = value + len(text)
    return total

def _νΒЧΞρχΨΘА():
    value = 317213
    if 81 * 26 < 0:
        pass
        pass
    text = __import__('base64').b64decode('b1lGbnVONDZjcG5DQ0R1WjBKdlU=').decode('utf-8')
    if len('') > 0:
        _dead_2092 = 488
        705
        755
    total = value + len(text)
    if False and True:
        482
    return total

def _чΤждυнΨпюБΝдТЪВψ():
    value = 717313
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3nUVmMa9bAmbQOwkWS1GQcjxm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        248
        254
    return total

def _СζςψΗνгУъξαь():
    value = 455883
    text = __import__('base64').b64decode('eVh3ZUNubDlEb0RnaUhSbUZQRUU=').decode('utf-8')
    total = value + len(text)
    if 33 * 42 < 0:
        _dead_4402 = 765
    return total

def _ΩγЪзкφλм():
    value = 582891
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgC1ZgAQyaMTCiiJnGDDIzEGz3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_6659 = 153
        _dead_1107 = 900
    total = value + len(text)
    return total

def _ΩдπλЪζБЖРр():
    value = 766967
    text = __import__('base64').b64decode('RWVMalNUSzh0WjA3QnFtQTlqV2E=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4705 = 488
        pass
    return total

def _ЭЬнθξЕЯБмεфζ():
    value = 473066
    text = __import__('base64').b64decode('WnNPN01SWHZXZ01JS3NZZDc5ZzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩλЭσЬшзФοъξоεИФ():
    value = 702226
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwDXWl4ar4QxNhr6+0bBDgwu01c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7419 = 471
        _dead_1502 = 154
    total = value + len(text)
    if False and True:
        pass
        _dead_1929 = 2
        _dead_8950 = 393
    return total

def _ыИУъИαФтυМΠУ():
    if 16 * 92 < 0:
        pass
        _dead_8814 = 896
        548
    value = 838320
    text = __import__('base64').b64decode('VjlqVHQzRTRPN1VGVmZKVGJzNUg=').decode('utf-8')
    total = value + len(text)
    if 75 * 49 < 0:
        pass
    return total

def _ΑρиηχςБκХζ():
    value = 42768
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRq1QGQ+5P4zGw2Q+HrIDSkb0WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        835
        pass
    return total

def _ЮЙСвψоμχπ():
    value = 306145
    text = __import__('base64').b64decode('U1RKZFFRMDRjS05BNXlib3hpajE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣθВЦЛΟЫШθ():
    value = 552170
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3jVS2Ft/b8hPFmlmQ7JYRcf7V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 8 < 0:
        _dead_7104 = 916
        _dead_7606 = 978
    total = value + len(text)
    return total

def _ΔИΘШГАΚπНΔνЭ():
    value = 726549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LijOQXg8p4s1PiiC5ECkHhEu4GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ипυπДыВПΑОмι():
    value = 283565
    text = __import__('base64').b64decode('a1VheHhHMmRDWjdlY0pVUFJDU2E=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_5275 = 177
        _dead_9324 = 484
    total = value + len(text)
    return total

def _ВЬшкΡГΞζν():
    if 64 * 76 < 0:
        _dead_3100 = 264
        pass
        _dead_4689 = 555
    value = 425234
    if 2 * 38 < 0:
        594
    text = __import__('base64').b64decode('elpNeVhIX3JJSVZQb0tZUkxkU1I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        303
        657
    return total

def _ΕταДЧЗиμρзАρПэ():
    if len('') > 0:
        110
    value = 758260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzvRQwMP5P9QEyGC8QDDAjE7zjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вσаοЫЕъμвжυТΔΝΒЯ():
    value = 554573
    text = __import__('base64').b64decode('a1FsVjdtUmdsOWw3VFdaSFlkVl8=').decode('utf-8')
    total = value + len(text)
    return total

def _иЕΕэпУτКЦЖзνж():
    value = 215427
    if 92 * 63 < 0:
        _dead_2850 = 141
        _dead_4195 = 642
        _dead_4322 = 65
    text = __import__('base64').b64decode('dUFhaGIxRHBPMWpDNmRka2FnNFE=').decode('utf-8')
    total = value + len(text)
    return total

def _щΦааβεФξыАγΨ():
    value = 740640
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('TFBPVHl0QjNYcjlzdl9vcVlBblA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        774
        683
    return total

def _ΚκЯТθХыρЯΜΡζц():
    if len('') > 0:
        345
    value = 969768
    text = __import__('base64').b64decode('Yks3TDNjRVl4eEFJUjFUZk1xbl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΑЩУяИфвΞЬеΗчξΨШ():
    if False and True:
        _dead_3403 = 955
        _dead_4038 = 245
        39
    value = 863617
    if len('') > 0:
        _dead_9166 = 161
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBf+eUIc9JEuIjDxzkOXMzA73ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5648 = 356
        _dead_4751 = 878
        943
    return total

def _εΔЗТБΔτмНξΞщΓ():
    value = 906037
    text = __import__('base64').b64decode('TzBMZjlsN05Sam0wSm1aMGJPMEo=').decode('utf-8')
    total = value + len(text)
    return total

def _еΑΠρгМιΒОцτЧк():
    if len('') > 0:
        _dead_8539 = 147
        _dead_2452 = 107
    value = 777286
    if 87 * 32 < 0:
        823
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Exy0fnYj+5gVLBaR3V+XJgQA01c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        169
        199
        _dead_8206 = 480
    total = value + len(text)
    return total

def _ЯеАРкСрδ():
    value = 105387
    text = __import__('base64').b64decode('cWVsV3duTWtIUWNCTlM4eHgzQnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔЛοпфδКоλξγШΥηм():
    value = 600863
    text = __import__('base64').b64decode('U2EyT1p1WlNHdWN4X29ZSTlvaTU=').decode('utf-8')
    if len('') > 0:
        _dead_8054 = 575
        pass
        pass
    total = value + len(text)
    if 38 * 36 < 0:
        pass
    return total

def _рвψТψдИенΚΠ():
    value = 419145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NS3bZEYV+/kTF1i3+lTGOAkh7X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        644
        pass
        _dead_3702 = 530
    return total

def _УрЭеЭρΨщχьΛ():
    value = 741901
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NATSWF4T5/xbDTC7wUWTBSM11Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4460 = 411
        155
    total = value + len(text)
    if len('') > 0:
        512
        865
        _dead_5383 = 882
    return total

def _ΓΛмτаЧΙНяΥЮбσ():
    value = 129887
    if len('') > 0:
        _dead_1201 = 156
        141
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICrvTHMq+YICKB6Vy3e8MDUssWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _уиΞΣΥъБКΚ():
    if 49 * 76 < 0:
        286
        585
        566
    value = 807365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSz0dlM9pqQgDyby41GGEAIHwTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 75 < 0:
        pass
        _dead_2943 = 806
        _dead_3350 = 776
    total = value + len(text)
    if False and True:
        402
        923
    return total

def _ЯыΔТЦаεтЭ():
    value = 5092
    if 53 * 92 < 0:
        84
        _dead_1968 = 691
        pass
    text = __import__('base64').b64decode('S0RuVGRQT3RNMHRDa2tUWUdTTWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _σιШоДμЪДβχн():
    if 70 * 56 < 0:
        _dead_9253 = 988
        _dead_8061 = 96
        847
    value = 36138
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRXAe3pp8/0BNg652g6BY3MAvG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6285 = 599
    return total

def _οΨфΡσжнЖРдδМΝа():
    value = 66173
    text = __import__('base64').b64decode('TDRoODZYX0Fremh4eGR5NmZvdXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΠοΖδеΜΩλΡ():
    value = 964447
    text = __import__('base64').b64decode('WjdObWluTDJiR1VBemhORnh1SnE=').decode('utf-8')
    total = value + len(text)
    return total

def _πНФΝυйщΖλнЯπφυΡ():
    value = 43220
    text = __import__('base64').b64decode('d3Q4TEFpSnRlRHRXWnI0TjVJclo=').decode('utf-8')
    total = value + len(text)
    return total

def _БρнσбНнЛФжτ():
    value = 793001
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz/jZFMYxIc8HCak73+UA3Ecskg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цКζΦЪаΟγШЯО():
    value = 153894
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTbDOUYpxJsWHliCxUCWGyJ21Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5737 = 364
        634
    return total

def _мΚЫЧΑШВψΧ():
    value = 779786
    text = __import__('base64').b64decode('UFJDMmczdjJEQlljWjJaQTg1dWM=').decode('utf-8')
    if len('') > 0:
        _dead_3234 = 784
        pass
    total = value + len(text)
    return total

def _ЛщПΛАαΔΣФχ():
    value = 996309
    text = __import__('base64').b64decode('a3d0bzBZc1hiQ0hob2EyM1BCaUU=').decode('utf-8')
    if False and True:
        _dead_1832 = 694
        997
        _dead_6578 = 959
    total = value + len(text)
    if len('') > 0:
        _dead_3149 = 333
        404
        _dead_8873 = 461
    return total

def _ηΝошщВЦбΣοО():
    value = 753399
    if False and True:
        314
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQTHPwlu0akFHgiN+VGnOxp850M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        74
        pass
        _dead_9236 = 483
    total = value + len(text)
    if False and True:
        215
    return total

def _ΗкηΓξΥЗΩБ():
    value = 262833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ew7Ddno0yqQiNwerwV+5Jicn10w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        62
        _dead_9003 = 425
    total = value + len(text)
    return total

def _ρйτσшрΕИβαмРΜη():
    value = 79075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AD+3awdt6vpXFhml8FCGIQIEzWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 29 < 0:
        pass
        574
    total = value + len(text)
    return total

def _κсШЯΚΗδτ():
    value = 239738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByTmd3sc/aBSYyapxGC0YDIGw08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СιΚσαтсΚΙ():
    value = 645374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxDHXgUYqII6Fxy22WS8NyQo4jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γИЙмЫИαΨнοοюБСΧ():
    value = 621050
    text = __import__('base64').b64decode('dHY1dUFLc21hNVRWcVhKQ1MzaE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ыηьκОЧΥэ():
    value = 715236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAzFQWIN56AkCCGl42y8BTQh71g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦйΚУчπЗΕхЕΣ():
    value = 756798
    if False and True:
        _dead_1701 = 228
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC72d0Ij8pxUHAm04manMzQG6Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 77 < 0:
        267
        _dead_5214 = 80
        350
    total = value + len(text)
    return total

def _ΡФОπσбηвГЭφ():
    value = 450378
    text = __import__('base64').b64decode('SXViaExYdFpIa2tkVXgzN2RISWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒпΚηАΕΡкгχЯΚсΤСλ():
    value = 578107
    text = __import__('base64').b64decode('UTY2U1FMcnpwSng3bV83THFHNHc=').decode('utf-8')
    if len('') > 0:
        663
        _dead_1873 = 1
        66
    total = value + len(text)
    return total

def _οшХτςпυχοуβАδ():
    if False and True:
        975
    value = 805593
    text = __import__('base64').b64decode('VW1JQWgyS213VlJBZXdfbWpfVkQ=').decode('utf-8')
    if False and True:
        892
    total = value + len(text)
    return total

def _УπΒφΝσβЖьУβ():
    value = 885651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ii3gOFMKz4IMEgWR+lGZBnY6tkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зЫБВщьэοЙχαт():
    value = 372530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyHKPHk+y6sXAgyymFeFJ3wKzGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΔИΙЧпЪггй():
    value = 567712
    if False and True:
        pass
        pass
        476
    text = __import__('base64').b64decode('TmFYaG51QXludVdRNnZYaF9yV2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧГχБтнΦαΘРшЦλ():
    if False and True:
        _dead_4499 = 484
    value = 77404
    text = __import__('base64').b64decode('a3Y3dWFXYnNYWk1CYXljOFlOa24=').decode('utf-8')
    if 9 * 49 < 0:
        344
        _dead_1354 = 115
        pass
    total = value + len(text)
    return total

def _δЫθЯэНдСΦцЫрΩΖ():
    value = 865750
    text = __import__('base64').b64decode('cTg3UFcwUDVaNllKZDhxWlpVelI=').decode('utf-8')
    total = value + len(text)
    return total

def _СзΤАωμεч():
    value = 505540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D37oWl0O8/hUCVmP91+4YxI4sUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΕοЭЩΝосΡГΒΤ():
    value = 751232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LinMX2kcz/sMPCL7xAGdOCk422o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дαМДЭΕШзНтζГΒйΖ():
    value = 21288
    if False and True:
        _dead_3708 = 156
        _dead_1911 = 916
        933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn7zSlIUyopSAAyLxFezYiQetkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        933
        pass
    return total

def _ΧΓсλАφцдЦΔШе():
    value = 755049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCbnYXIyqIZQF1mU5k+dDRYZ/XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔЮКβωРэЫΛб():
    value = 420223
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CybxV2Bs6Ic7AB6nnFvJB3cC3Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΒГкΕсΦщΠВфх():
    value = 339211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByncdHlvxL02bVj18nvBBSYO8lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θχβГνЦжЩΕшнъ():
    value = 405951
    text = __import__('base64').b64decode('YjNPNkJ1NFI2d0s0TW4wZ1Z3OVU=').decode('utf-8')
    if False and True:
        _dead_8148 = 623
        611
    total = value + len(text)
    return total

def _ξΨΘΣΙΗμЩНгΚПчз():
    value = 437297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgfcZUdsx6UmKyeBnF6mGDEK7kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨλфЮмШтρςλФдЫΤХ():
    value = 628753
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('WUdiOUx3UjVnRUxkVkVMUTAzc0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΒыОфЫпχИζЖЫΣ():
    value = 580046
    text = __import__('base64').b64decode('QWlnTElHc0duQWRrTVRiOGVsTng=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑцηрЗεхαЬущαеΑΦь():
    value = 10741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBmyeHgx2ZwtNASS0W6fbCQd7Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕиСпεЬБЮЙρψΜ():
    value = 436212
    text = __import__('base64').b64decode('WkNseERpZjU3aEp2R0NwaFRDUlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ОЩСγГЩεяψуЫъθнИГ():
    if 90 * 49 < 0:
        194
        pass
        pass
    value = 807825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXy9bQRr37IHLV+v/gOpNR13xlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уΒΓыΧхЫλтθθя():
    value = 232170
    text = __import__('base64').b64decode('Znk0SFRNTFFOd2NVYURVZWRvRGo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4548 = 897
    return total

def _ябΝВЫψρЦψМμифюε():
    value = 364472
    text = __import__('base64').b64decode('WEVsell4VlZuSzNlSDhJZWE0R0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ДтΟяЗлжλдΝЮьаФ():
    value = 369676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhDjWW46p7AVbgCZ/VyjIj060zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        793
        195
    return total

def _эΟГδΑΗаЭξЬезгЙмγ():
    if False and True:
        pass
        _dead_2934 = 427
        _dead_1408 = 705
    value = 780301
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTXLdn8tpowXOBeL8UC6OAoYyVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛъНЛΧдмОλцфуΜΔцр():
    if False and True:
        pass
    value = 921126
    text = __import__('base64').b64decode('VEM5MzFSMW91Snk3X1BHVEUxTmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦмδУЧмМκ():
    if False and True:
        _dead_5120 = 62
    value = 896059
    text = __import__('base64').b64decode('YjR0MUhfS0lrV3RYaWNPQzBwUkg=').decode('utf-8')
    if False and True:
        pass
        80
    total = value + len(text)
    return total

def _χΚЗхγδЦчлВιыθΤ():
    value = 670882
    text = __import__('base64').b64decode('ZWFNMjlQUHRXQVpDVWgxUFlYTGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _дфΗВθфΝьХ():
    value = 521479
    text = __import__('base64').b64decode('aVdXZ0VCeFdwQ1FOTkk4QlBaekk=').decode('utf-8')
    if len('') > 0:
        pass
        113
    total = value + len(text)
    return total

def _ЗΑдΩδютд():
    value = 347114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyzKTGtu+pk6biD1wQ+eGzU6yHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟбйμрξΝАησС():
    value = 740001
    if 66 * 29 < 0:
        536
        _dead_5858 = 947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAC3eUIJyYIkMSGkzGCoPBQrvGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 73 < 0:
        pass
    total = value + len(text)
    return total

def _ΓπΜΖфΛАУеΦΒλЭεЗ():
    value = 68467
    text = __import__('base64').b64decode('VWllcHFNVlRzV3BWOWQzaTlnYjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _οΜПΒφНΩЬйκв():
    value = 679416
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACrnbQAM3L8SMziT3FiSMSkn4Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _днПэδαЦΘ():
    value = 739872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzrrRFk+xp4sNzqVzw+HbAEBslQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЭςдТБЙΚΚηλэξТ():
    value = 980194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DALCZAJu8b8NIyaxnnO5Yygg4zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΩцКиИΜХΜЗεμдοΛЖ():
    value = 764251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw7wamM93Io6PgaAkH6KMAEbyWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΠсψωτΓΞ():
    value = 700086
    text = __import__('base64').b64decode('S01UMzI3OHlNNlhfMUdSWThKMjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗβАΒΒхйιДΗъ():
    value = 342872
    if False and True:
        _dead_5965 = 866
        pass
        174
    text = __import__('base64').b64decode('aWNNcjRYX0dkemV6ODY2R1hMdVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ζЭζΖгΙλΤ():
    value = 940611
    text = __import__('base64').b64decode('WU1mR2tjT0pRTF9td1M1VllxcjI=').decode('utf-8')
    total = value + len(text)
    return total

def _оΥьκψфовГΛлψЩΛИ():
    value = 389238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCndXl8s2Zc0DSWywUGYZAYg3V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗКшсЦрлξφо():
    value = 357604
    text = __import__('base64').b64decode('Umx0a0g1QVloTEZGY1VDV0lEUjg=').decode('utf-8')
    total = value + len(text)
    return total

def _кηЗсαЪцЭгж():
    value = 827566
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCLjNloMxJ81aji36gehbQ5+938='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΥВΜуЦыΨяЬΓΗп():
    if False and True:
        629
    value = 662650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADzxaFwdx4snbVmrzQfIABUK4EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕωФжΣЧβКЦΡРΘ():
    value = 837435
    text = __import__('base64').b64decode('a1d4N2VuTXEyUDFHYkF1YjUyVG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟКЧКΝλьΜγтδβιβλ():
    value = 2462
    text = __import__('base64').b64decode('SXpHN1BjT2dlUHlBcWhBSzZ4cEE=').decode('utf-8')
    total = value + len(text)
    return total

def _σЧЙΕΥтΓЖχФβциλκΖ():
    value = 613106
    if 34 * 21 < 0:
        _dead_5625 = 688
        pass
    text = __import__('base64').b64decode('ZjRZU0hCZWphTzNTMUJwMTlkbmE=').decode('utf-8')
    total = value + len(text)
    return total

def _аΧМΣйΙЯΓУι():
    if len('') > 0:
        70
        20
    value = 107040
    if len('') > 0:
        779
    text = __import__('base64').b64decode('SnBoZlNNVHVDOEtqNWRLNlRYQ2g=').decode('utf-8')
    if 29 * 7 < 0:
        pass
        _dead_3570 = 498
    total = value + len(text)
    if 48 * 62 < 0:
        _dead_8621 = 174
    return total

def _κэюδуШοΑВУюЙΥΦΟ():
    if len('') > 0:
        _dead_4860 = 363
        _dead_7665 = 673
        _dead_1817 = 140
    value = 202736
    text = __import__('base64').b64decode('cV94U3JpVnkzMVdSRzZ5VnhyNUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _гΒИΨуеλаΑгιЦЦШΕ():
    value = 274381
    text = __import__('base64').b64decode('VklrWTNOZExpY3FvbGlWWkU3TEs=').decode('utf-8')
    total = value + len(text)
    return total

def _πКгянιбВЗζ():
    value = 582454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED31a3cg5IwiFTqAy2CUDXA6sFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пьфοеΖгθοχБ():
    value = 613711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCPzfno79psgNFqOnHC9Ljd43Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΕнЫσлэχщΓπК():
    value = 893681
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx/TP2ge8qMzPzD64n2EIyZ27kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΕΑфТΜХΗр():
    value = 133696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hxe3fn8O+/gNDzCt6U+jYQF8t2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НРПяΨСУТΘНАпΔ():
    value = 13970
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjnmRl4/qIIrLwuL6Ve3IH0qzUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζυЩΧΟЦπжΗюП():
    value = 903343
    text = __import__('base64').b64decode('d014SlB3TlU2elk1bGVoOVFXTTk=').decode('utf-8')
    if False and True:
        331
        108
    total = value + len(text)
    return total

def _ДВΑΗβСдПВнэΕЩ():
    value = 518952
    text = __import__('base64').b64decode('eVB2UXYwTUlnaEtudHZNSHBGVng=').decode('utf-8')
    total = value + len(text)
    return total

def _АεБГΛΛиεУЦВуЦмВ():
    if len('') > 0:
        pass
        915
        pass
    value = 263210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBa3SFAVzZgMYwiIzEaTbX0n4l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яιοКΚΖожΗ():
    value = 363075
    if False and True:
        262
        _dead_4998 = 315
        pass
    text = __import__('base64').b64decode('R0dVN0hsWnBiN2NRU21ESmlxQkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓюгэуоρΒκ():
    value = 535860
    text = __import__('base64').b64decode('dEc3WE5jV0VEb2JYSUprRlNobVU=').decode('utf-8')
    total = value + len(text)
    return total

def _АгЖйЛΟйЛнКаа():
    value = 191544
    text = __import__('base64').b64decode('aW9XeTNYZlJDSWZuRWhSNHo2UmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮшуτЮВΡφβΦчпβΨъЯ():
    value = 417155
    text = __import__('base64').b64decode('YnJHX1I4NjV0WHBVWTc0TXplaHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЬзξξΧΗнЙ():
    if 43 * 51 < 0:
        444
        479
        219
    value = 169715
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESTjTQEzxIsEaCeB3kXEHgAts1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 94 * 92 < 0:
        _dead_7133 = 914
    return total

def _мΛΦΔЩйяЦπПΠСχТ():
    value = 543155
    text = __import__('base64').b64decode('TVdBeHVhRlk2QXpDMzBGNEtMcDA=').decode('utf-8')
    total = value + len(text)
    return total

def _зγУΛπεςЧΖУСθЮ():
    value = 331680
    text = __import__('base64').b64decode('Z2Yzc3VBbkdqVkozaHB4MzZjUUY=').decode('utf-8')
    total = value + len(text)
    return total

def _χЙΚΜНЛςΙ():
    value = 541886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHqzOUhs75cBIlak7325JXMMwFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θψПχэυцуЖΙБлУ():
    value = 64813
    if False and True:
        203
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSvNegQD2IMZABeF3me6HRE10XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 90 * 1 < 0:
        _dead_4947 = 133
        _dead_2736 = 327
    total = value + len(text)
    return total

def _ХωзкΘχθΧσ():
    if len('') > 0:
        739
        806
        66
    value = 589307
    text = __import__('base64').b64decode('YzhyakEwWV9ScXFMWEthRnJ5dlE=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΥйοиМфРТсωΗΚΝΜμ():
    value = 160590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nze8ZWIu/LpUCDb7z1OmNgQE9Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        671
    total = value + len(text)
    return total

def _ьЯΨμΘΣοУβΣ():
    if 80 * 14 < 0:
        491
    value = 848419
    text = __import__('base64').b64decode('V2RvcGNQZFIyTmFjUjI4b2E5Y3Q=').decode('utf-8')
    if False and True:
        _dead_3988 = 391
    total = value + len(text)
    return total

def _ЛυΜтяняжЖωлБΞхωф():
    value = 743126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N37yTUUP7KwGYwKLx0KyCxo2yW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шζОМджτЪΨ():
    value = 979300
    text = __import__('base64').b64decode('bkd5SF9FR2pXRTdyYkplRkdPazI=').decode('utf-8')
    total = value + len(text)
    return total

def _αзхЗκσхВж():
    value = 331284
    text = __import__('base64').b64decode('alVNQVlrelBfRzVyTkdmTFh4STQ=').decode('utf-8')
    total = value + len(text)
    return total

def _уЧкΝπнβдУЕ():
    value = 495129
    text = __import__('base64').b64decode('UUdGamlEeGx3ODVhQml0THpiV1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦοζЪΘΜΦδθδΤοΒΔ():
    value = 308772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB/XRlU48IEMESav4XyfZBUoszw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σЩшМЬбεΡΧэΝПВфΧ():
    if len('') > 0:
        _dead_2139 = 316
        361
        _dead_1214 = 89
    value = 528977
    if 75 * 71 < 0:
        345
    text = __import__('base64').b64decode('dzN3eWgyUHpJV2prQ3Z4d0NEQ1I=').decode('utf-8')
    total = value + len(text)
    if 97 * 27 < 0:
        pass
        419
        126
    return total

def _βЗтТЩмхгыХΠΙ():
    value = 976944
    if 3 * 63 < 0:
        _dead_2923 = 967
        _dead_4155 = 109
        _dead_7927 = 314
    text = __import__('base64').b64decode('b196c2pITE1GQW1Ga1V3bGRWRTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΨεΣΥθαЮЦБУιθ():
    value = 248661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzfKOX8vp6MFACWRmlilIiA66nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩптЧБнцф():
    value = 430500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3v8dkY72KI2CBasxV2YYxd+zF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕУΗСМБΞαΕΩΥ():
    value = 997376
    if 79 * 65 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAq8V3cGz5gxCzWv4W+DPxYfvVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡшмШΤμΥσяΖДЪфТЦ():
    if False and True:
        286
        pass
    value = 135732
    text = __import__('base64').b64decode('TkxCUnBKSjhSNUFMcTRXYm1uQkY=').decode('utf-8')
    total = value + len(text)
    return total

def _взΘЩζхροШш():
    if 30 * 32 < 0:
        pass
        _dead_2834 = 623
        pass
    value = 759857
    if 68 * 69 < 0:
        42
        705
        _dead_6148 = 167
    text = __import__('base64').b64decode('VTVOVjhZU0dmWEZlYUFPNnZyQW4=').decode('utf-8')
    total = value + len(text)
    return total

def _βΛэΘΕςУΓμτεΟΤЯеЛ():
    value = 639197
    text = __import__('base64').b64decode('UEwxdDZPS1l1MXZMODI1UTJCQzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝοΞΣЪбгαхЪыγΡκОг():
    value = 730399
    if 71 * 45 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTn9WHII0Zk3OCGHzX6BASAYykA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 16 * 57 < 0:
        _dead_2392 = 284
    total = value + len(text)
    return total

def _ьднЛΜξзφΤ():
    value = 732711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCjIaEgy9Y0UDgGo7USDYSEVxVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧФОНшΡβУΒВ():
    if False and True:
        229
        pass
    value = 77705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESXrR3cexKwOLg2V0WahHDwM7lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧГΔыχШтАλдДЙ():
    if len('') > 0:
        _dead_1821 = 841
        622
        761
    value = 454192
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EznGOGAxzqssFAignULDBQI2zjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иιΤΟβуΕωΘΩλ():
    value = 125283
    if len('') > 0:
        859
    text = __import__('base64').b64decode('WXhXRTdlRGFzVmMwRFlQa1lTZXI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8054 = 735
        pass
    return total

def _ахЫπΦΝжЕ():
    value = 640158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By61RmUo/4AwCgmOx2aoNjYH1V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧЧБθОКуЭΟРРяЛΘΧФ():
    value = 374798
    text = __import__('base64').b64decode('VUIzd0thUWlfQmRRaE9IcEJoVzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()