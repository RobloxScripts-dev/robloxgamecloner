#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _уЩνΟПчщАяγфкΝωΩ():
    if len('') > 0:
        591
        _dead_8927 = 366
    value = 245638
    if False and True:
        _dead_1022 = 674
        pass
        _dead_1999 = 149
    text = __import__('base64').b64decode('akV5dlJLbU1YMTN3UTlkUWUwX1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤμйжЬщЮчβАрρηоζ():
    if len('') > 0:
        pass
    value = 827408
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSPsRVUBqo1XLQKW7VyDMRd55X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        144
        pass
    total = value + len(text)
    if False and True:
        _dead_7888 = 541
        173
        _dead_9939 = 272
    return total

def _ηлΧжΜЩΦожцΑ():
    value = 310234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwXiemMU3Y0KBTqAn3+2Iw9872k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1960 = 71
        _dead_9111 = 499
    total = value + len(text)
    return total

def _αВΦЬщОеσИуγЦβк():
    value = 245229
    text = __import__('base64').b64decode('QTFtaFQ0cHBnUWZWTmhBcGJOS2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _δиυЫΕρξΓФц():
    value = 35278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgXLTFI93/hRKg6662fHAAMYz20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДφИГΘΜδπуб():
    value = 154671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxXlbEQc8I9Qbzqg7VvIYRIk73Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лмкЧПτСоΨφьуД():
    value = 615479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSfyYwAhrKM1PliJ33DHMzYp9GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хкπИΣеΖπΤхλАЮвκ():
    value = 645149
    if 34 * 50 < 0:
        _dead_1345 = 495
        pass
    text = __import__('base64').b64decode('UHJ3OGpGM183WnJ1eXNXUDNzZXc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _σΟχΤзψΥМсω():
    value = 710027
    text = __import__('base64').b64decode('ejJXUUEyTks0ZnV5Z2FmdVZ3QlA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЮΣΣДАэΘй():
    value = 217623
    text = __import__('base64').b64decode('UE5wdlIyalZNRkMyVzZleWh5VTY=').decode('utf-8')
    total = value + len(text)
    return total

def _УΙляΒпκζ():
    value = 704380
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSj+a15uq/kHFSezznOeEBcM5UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8206 = 449
        _dead_2668 = 356
    return total

def _ΞεжЧлвЯΦхςε():
    value = 449519
    if 50 * 86 < 0:
        pass
        83
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRe3dn5s6K0nExu04lyEMDw8zj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рυЕΑЧχПΗлπκШρ():
    value = 172074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATbtTQYp24E7NA2Cn3OpFxcYzDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рлΤИаσΚИΑЩЛψсВαδ():
    value = 727293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BibcbHQf3bIKGxua+H6pZTMQ63c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        771
        106
    return total

def _ΛКэХжиβСΕζΖΙςКςΠ():
    value = 593653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQ22ZXwQ2v0LDAut3H6HZAcOsUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фщтτδΩЕНΥдсνГΕЛΥ():
    value = 914686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bjf+RWgT9/FbORyL5Uy4ZxQm4n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        198
        _dead_9592 = 440
    total = value + len(text)
    return total

def _ΑζЪшГсΤΓφΠ():
    if 52 * 17 < 0:
        493
    value = 907243
    text = __import__('base64').b64decode('dk80YTB5YUM4TUV4QTJCVlVBbG8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5019 = 107
        _dead_3931 = 314
    return total

def _йЫΙΧбЬбч():
    if len('') > 0:
        _dead_6245 = 572
        261
    value = 256340
    if 91 * 58 < 0:
        _dead_6808 = 592
        882
        _dead_1442 = 431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADrAYXA7y5EbMFaIkV2EPSMM1Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 14 * 15 < 0:
        _dead_9230 = 935
        735
    return total

def _еχУηАиΚΠыЖβψΥЕγ():
    value = 399612
    if len('') > 0:
        816
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P37XSEQ6yoE8HCamyUSRGiA78Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        667
    total = value + len(text)
    return total

def _ЪМΓлσЙнΩΚλЪд():
    value = 118934
    text = __import__('base64').b64decode('cjJlMDZpYzNOeXZhaWV4QVdTUGQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if 85 * 53 < 0:
        pass
        893
    return total

def _ΦογдРΛЖЙеθШЖ():
    if 66 * 57 < 0:
        _dead_9857 = 407
        _dead_7982 = 754
        _dead_7309 = 775
    value = 104228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXbndm4U56ASAhWvxmKRJnE/3T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_7188 = 755
        427
    total = value + len(text)
    return total

def _ΑγбсψМοзуδ():
    if 35 * 30 < 0:
        _dead_7614 = 177
    value = 128727
    text = __import__('base64').b64decode('Y3d5SjNZWnhZWXl2ZzFDdml4S00=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥζΖиЗπДω():
    value = 781227
    text = __import__('base64').b64decode('R2pyMW1Eemx4QmhnNlcyb2xRMHY=').decode('utf-8')
    total = value + len(text)
    return total

def _КмЩθβПНсΧю():
    if False and True:
        _dead_5364 = 342
        504
        714
    value = 966513
    text = __import__('base64').b64decode('SkMzNDNHT0RnMm1kOENGN29tSXc=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_5638 = 537
    total = value + len(text)
    if False and True:
        255
        _dead_1850 = 927
        720
    return total

def _ДХъНйьЮыφБХ():
    value = 817321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CR3lQQYv55EMPl228F2nZ3UH2z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚршЪδВыОΚςы():
    value = 251302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwfTOlMA5o0Bbgel53GRLBQFtkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΕоеыΒομΕΣζэкβΠЫ():
    if 44 * 61 < 0:
        83
        pass
    value = 591760
    text = __import__('base64').b64decode('emlNQjdvSVh2VV9Ja3RVcDdOdzU=').decode('utf-8')
    if len('') > 0:
        _dead_1206 = 678
        836
    total = value + len(text)
    return total

def _ыυПβΜВΗΥ():
    value = 775954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LS3wXGgM+rFSDVuV7nXIMXMH4nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΚЖΒΓПМзоΛ():
    value = 272127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjmyNkEU1Kw2P1bxzUS8Pwgoy20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        964
        pass
    total = value + len(text)
    return total

def _ΨΤцМщхВΙЫНψю():
    if 63 * 88 < 0:
        pass
        _dead_2960 = 371
        pass
    value = 543874
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAa8V1Uo6LgrMC2r3F2kGA8u3GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЪлЕΧωЪРХБσ():
    if len('') > 0:
        446
        _dead_2729 = 365
    value = 105567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CijOZ1Merqo0Hl2A+1G4PC4Q1lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 18 < 0:
        _dead_3334 = 918
        785
    total = value + len(text)
    return total

def _ΥΙξЮπΖНΨξГ():
    value = 287985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA3cb1Mr1bA7PQ6G2WyCMXQk8kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κлιΛεПΟюмΓэЭл():
    value = 773117
    text = __import__('base64').b64decode('UHhVVjJSZU5yQW95TWdCUkRWVHY=').decode('utf-8')
    total = value + len(text)
    return total

def _γЧогЪуОжхΑцρмυ():
    value = 858148
    text = __import__('base64').b64decode('em1lZ1RCNzh1aVVWQ3dvdUN6RFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ζНщΒдвρΝπΕчΠξ():
    value = 870483
    if 46 * 92 < 0:
        _dead_3236 = 53
        703
        57
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyX3enIb/IkpCFmI5XigbQJ3vUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        929
        _dead_9173 = 129
    return total

def _шкТЛςΞШα():
    value = 920699
    text = __import__('base64').b64decode('dzdROHROUHp2TjNoWW9VY0hjNlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _жНММщаЫЫФ():
    if 65 * 28 < 0:
        _dead_8794 = 499
    value = 18767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR22PAgPqvAFLwiHmnHIIgR7wkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        170
        162
        _dead_7300 = 867
    total = value + len(text)
    return total

def _гззθχщДЫьсьНηξиΘ():
    value = 999479
    if len('') > 0:
        _dead_5329 = 177
        _dead_3662 = 463
        _dead_7755 = 354
    text = __import__('base64').b64decode('T1RHYmY3Wk9ZUHR0YThhRFdBRzI=').decode('utf-8')
    if len('') > 0:
        _dead_8318 = 88
    total = value + len(text)
    if False and True:
        _dead_7972 = 474
        pass
    return total

def _ЩчιКиЕοωγЦЭЕσΨгο():
    value = 783443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHbMPgcM05IPDRaF8W+vbBQAyl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9916 = 962
        _dead_7900 = 245
    return total

def _ΣбΙКСΚЖжТх():
    value = 517703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCXGb0Qw3ZgoMhuv5A61Bwcp4Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕιΝΔВσНпЮΖαΑβЮЮ():
    value = 713928
    text = __import__('base64').b64decode('QWtLanptTWtMVDBEOUdCeHZRTUY=').decode('utf-8')
    if 71 * 64 < 0:
        _dead_3735 = 751
    total = value + len(text)
    return total

def _λОЬуЪЛΜφλг():
    value = 763133
    text = __import__('base64').b64decode('QkxWNk55a0t0NHg4SU1DSm13M3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _МЕКоγΑεЧ():
    if False and True:
        _dead_2122 = 528
        181
        _dead_5165 = 717
    value = 610508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IivWeghpq/szLVmN21O4LCob/Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4329 = 452
        100
    return total

def _ОωЩзιΜуТчшйЯγСфα():
    value = 233027
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dyf3T3Us960sblv2wnDGPhE5z3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜяЗβхюхШкΔθхЗЫ():
    value = 325273
    text = __import__('base64').b64decode('SlRzYzJXYWZfQTY4SWhRV181Q0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ТцοУΥтΨκзйсю():
    value = 191115
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F33lVEJv3akaGB6QxQG1A3UH52o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1331 = 883
        _dead_8867 = 879
    return total

def _МКΟΟΩЖьщχЯΠψцУАΒ():
    value = 41407
    text = __import__('base64').b64decode('aDZwcUZDN2liWjhRM0hNSDZtRmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔдΚрыЕρνε():
    if False and True:
        _dead_3797 = 251
        pass
    value = 933939
    if 42 * 46 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHr3RGsz5IEvIB2qzUK3JCEJzVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        729
        _dead_5443 = 155
        pass
    return total

def _зюяΩфαщψмΞ():
    value = 596011
    text = __import__('base64').b64decode('ZkdTaktkcEdWN3pqQTdkWnExaXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _вЪкЩлοЩγθβФε():
    value = 855379
    text = __import__('base64').b64decode('R1FVZDFjY202bk93UWlMeVptSlE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮαΖКΖΝαпρЫ():
    value = 743658
    text = __import__('base64').b64decode('Y0t1V1Fwa3VuWFhiWFhyRGZqeEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ψьΝЙзТΓζсЧтюН():
    value = 288554
    if len('') > 0:
        248
        _dead_4565 = 978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBXIfmVr9qM5Flqy2EeqGzAY6kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧХυκлШΑЩЕБбΚ():
    value = 836726
    text = __import__('base64').b64decode('ajVNMkg2RVQyNUxwWXlUd1FnM00=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _щφМХНΑЗртЫдмγЮς():
    value = 647736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAH0fAkSroQ5H16H3H2nFjYOyEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΒуΙΖыχЖОИΜЯ():
    value = 27603
    if len('') > 0:
        379
    text = __import__('base64').b64decode('YzU3RXh1Y2xFNmc0OFh2eGUzRm4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4280 = 784
        _dead_8112 = 277
        886
    return total

def _РЯηСГδπКξξмГνο():
    if 47 * 82 < 0:
        pass
        608
    value = 512298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHzPekga06wBDC2N516oJD0cz3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        140
        pass
        964
    total = value + len(text)
    if len('') > 0:
        79
        _dead_5301 = 525
        517
    return total

def _ΑΨФоΨЧηЬуБВΓкЧй():
    if False and True:
        863
        12
        pass
    value = 871475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwKyXUs+8YIuCi60zW6/Ohw19zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ынΜбьаЧХаνγ():
    if 57 * 38 < 0:
        _dead_3751 = 460
        _dead_1295 = 434
        324
    value = 439647
    if len('') > 0:
        pass
        444
    text = __import__('base64').b64decode('SnVIWW5GUnJPRTVXNVo1M2o4M2s=').decode('utf-8')
    total = value + len(text)
    return total

def _щΦχПеЗЖЪИ():
    value = 82740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ez7jXkg6/49SYzakwg7AMDx5sW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бυоЬΥчΙεКЗΝΩεНΚ():
    if len('') > 0:
        _dead_4228 = 544
        177
        832
    value = 657743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH+wR0cM3/A0Kji6mGKzBnAm8z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 66 * 67 < 0:
        891
    total = value + len(text)
    return total

def _цпЩДГпγБЮЧπ():
    value = 70145
    text = __import__('base64').b64decode('R0tOb3p0R1I3cmY4bE1PaDFyQ20=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЗΛЬγΦμςУ():
    if False and True:
        pass
        920
        _dead_1531 = 303
    value = 283601
    text = __import__('base64').b64decode('WVZLZU1INWNMZ3RKOFJSQ2RwVG8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        995
    return total

def _ъοаξβφкδЭβΝΩФй():
    value = 146924
    text = __import__('base64').b64decode('T0FPX3VJYUJuWVJjS204b0FpbHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ιлчгсфβσЗΕηЪТыо():
    value = 514796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj7PV3IKy5AvazWMmVycJXU90Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 1 < 0:
        795
        _dead_9858 = 130
    total = value + len(text)
    return total

def _ΑΦЭΝЦЧеЧувЛЧ():
    if 48 * 75 < 0:
        914
        710
        pass
    value = 926279
    if 44 * 18 < 0:
        pass
        503
    text = __import__('base64').b64decode('Vl9ZVmxJNldwYkpZRzVNdDZkYkE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        389
    return total

def _φπГТΔИдНа():
    value = 851301
    text = __import__('base64').b64decode('czdjZGN6NU40NWVETm5FMl96VDU=').decode('utf-8')
    if len('') > 0:
        _dead_1712 = 239
        387
    total = value + len(text)
    return total

def _Αрюρθоοпц():
    value = 435411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwjPTQYb2oIaNx2Ayk6zBCghzHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧаРΛМКΛцЮпλΧΧхδ():
    value = 454168
    text = __import__('base64').b64decode('cXdwdGtZREY1SzJuNFBuSExjRXU=').decode('utf-8')
    if len('') > 0:
        pass
        847
        _dead_1324 = 734
    total = value + len(text)
    return total

def _ΠЦщшКΖКπηРΜЭье():
    if 61 * 30 < 0:
        pass
        pass
    value = 228104
    if 24 * 8 < 0:
        600
        pass
    text = __import__('base64').b64decode('S0lKdmRMQ2pIcWtWcVY4QnU1NXE=').decode('utf-8')
    if len('') > 0:
        827
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_6981 = 336
    return total

def _УεπЯβφРΥутпКΤ():
    value = 202033
    text = __import__('base64').b64decode('eURhajIzX2psT2FnMDZJR2k1dHQ=').decode('utf-8')
    if len('') > 0:
        812
        pass
        _dead_4974 = 989
    total = value + len(text)
    return total

def _ЭΧНФγпХЗПδЛЖтШΑ():
    value = 239323
    if 62 * 74 < 0:
        932
        _dead_7252 = 840
    text = __import__('base64').b64decode('TTF1UUtZbGRBYzZXb3lvQXpQNnI=').decode('utf-8')
    total = value + len(text)
    return total

def _яτрЧθΟΤоγΑЮГсДΘλ():
    if False and True:
        _dead_8091 = 883
        pass
    value = 575592
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgfxSWMNr781CDz30EGkEA4fyH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞςΑΠуξИΣФВπИβ():
    if 53 * 51 < 0:
        350
        99
    value = 809672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CA7eRHdh/IcxCh6umQ6DNz056Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НνΖλВυСΔИ():
    value = 391025
    if False and True:
        pass
        200
        _dead_4961 = 762
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB7eWlUNprlQNQCQ0XSiNRQ+t3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _МΖБчΞΧςΛШа():
    value = 942640
    text = __import__('base64').b64decode('VzhwNHhvcURkMjNUdW53TkdNUlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦрЕαДεЩУВЕηКьМПΩ():
    if False and True:
        _dead_6852 = 737
    value = 374920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dwv1VwYs8PwvACiiz2aBMDE703Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΡтфАмЛΝΔЙЧ():
    value = 811221
    text = __import__('base64').b64decode('TnBqVU1TbUNOX1BISG5YRDgwQXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩЕΨΔЮъЩΑФφшБи():
    if False and True:
        403
    value = 966213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTfyd0Yo0ooGBR/0kU6RYAEe02c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υθηфιΑГЫ():
    value = 70918
    text = __import__('base64').b64decode('Rmp2bXh0RTBETVNrOHlHNzVwRXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ВэРςкΚНΞΔБ():
    if 20 * 14 < 0:
        pass
        224
    value = 646995
    text = __import__('base64').b64decode('V1loZ3VoMDRNSTJrVmJmVzl1STU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЮкχβЭθΑкЕςηНΟ():
    if 29 * 65 < 0:
        _dead_3286 = 362
        _dead_8696 = 630
        _dead_9807 = 292
    value = 668569
    text = __import__('base64').b64decode('bUpMVHcwZzhwSGthYUxhNzJWRDg=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        963
        449
        549
    return total

def _цщΣΝΦЖэвжμζю():
    value = 17227
    if 45 * 85 < 0:
        pass
        pass
    text = __import__('base64').b64decode('QldEUmxVejh0ekJ4M2MxUFZqR2Q=').decode('utf-8')
    if len('') > 0:
        _dead_5162 = 541
    total = value + len(text)
    return total

def _ΣωэщαΚΥζΜоΚ():
    value = 348303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDreegYO051ROFiizka6PzE2w08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓωЪщΒηρΕυнщνю():
    if 79 * 71 < 0:
        _dead_5049 = 757
    value = 700947
    if len('') > 0:
        676
        292
        632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHnFeFY754MLCj6S0GeRYDY/73c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ΓиИрдиПξЪ():
    value = 246914
    if 89 * 22 < 0:
        713
    text = __import__('base64').b64decode('UFZOUDlQaUtqcTNaNmVtQTVHQng=').decode('utf-8')
    if 61 * 67 < 0:
        _dead_3427 = 877
        _dead_9413 = 882
    total = value + len(text)
    return total

def _ΞЙШЗψъςПςШΚПЕ():
    value = 390346
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQrWeFcM95gmAB654UWUJwMF9mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡкАжВЙθКн():
    value = 211994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InuzVAgyr5swNT6Tz0GzIho/1nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яоЮπЫΣИпΠЖλОΨАλ():
    if 37 * 62 < 0:
        pass
        308
    value = 988182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwXCbEIs8pEzOTahmHO1DAo342Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΙФΞМьφΛбэθщы():
    if len('') > 0:
        _dead_5640 = 347
        29
        pass
    value = 146871
    text = __import__('base64').b64decode('S3hsc2NFNUN6OGo2RkxRbmVvOUQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _эжФЧΖьрωηуКЮтΥОЗ():
    if False and True:
        pass
        _dead_2627 = 537
    value = 661442
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRvBaAQhqbFQGFqB3nWKJzMB0X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟРДψрΩξΞΩδ():
    value = 334599
    if len('') > 0:
        _dead_3398 = 942
        _dead_1205 = 465
    text = __import__('base64').b64decode('dTkwZlpjYWFhSXgzTUprcHdkSHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧьХиκаχЫяσЧЫρΩ():
    value = 517449
    if False and True:
        pass
        353
    text = __import__('base64').b64decode('TVAzSTdlZ0xxUTZqc0NEYlBkOG4=').decode('utf-8')
    total = value + len(text)
    return total

def _βηМЕЧЯУкЛШοΓρ():
    value = 112095
    text = __import__('base64').b64decode('TlFhWW5IOTcyZHZBd19RbEVIRUU=').decode('utf-8')
    if False and True:
        _dead_3456 = 227
        pass
        _dead_1296 = 845
    total = value + len(text)
    return total

def _χюдеΚзиУМνςэрАΤЧ():
    value = 234158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjjtYVkQqY8yGQK38AGSZh89110='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_2853 = 405
    return total

def _ΜъФΦЗйЙФвοХΟ():
    value = 169981
    text = __import__('base64').b64decode('RXIzR0lDd2dJZEEwa2VEUF95cTM=').decode('utf-8')
    total = value + len(text)
    if 41 * 4 < 0:
        pass
    return total

def _ДСЕшβщгЕςиЖΜр():
    value = 634316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BB3neXUc6oYlBSeC60KUEgd4vWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫжыдλВиОωΝ():
    value = 240837
    text = __import__('base64').b64decode('QUNiOE9abDZOT0xwMkFGRHRzS1A=').decode('utf-8')
    total = value + len(text)
    return total

def _θГΨЙдΞошЛ():
    value = 596967
    text = __import__('base64').b64decode('c2dJQUl2TEFHdUFZYlVmWDNGeVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _НЗЗжпхθлЭΛХωЖХμЫ():
    value = 129933
    text = __import__('base64').b64decode('Y0g4MmlwbnhjMEs5REJWWnY1T0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΒЦДБπзΨΧ():
    if False and True:
        pass
    value = 842702
    text = __import__('base64').b64decode('bkRrT2FUTDBQSXhIRTVFSXg0RFM=').decode('utf-8')
    total = value + len(text)
    if 53 * 35 < 0:
        _dead_3178 = 877
        38
    return total

def _εψπηЛЪΟЖЕР():
    if False and True:
        pass
    value = 896658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH3GPWsoy78WA1ui43zHYyw7zmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _жБηлηхоσΧыЫщЧжъ():
    value = 53394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnrSTEA9/50XKQexzle5YAZ97lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΡиπВКсЪЮιφΡΛ():
    if 16 * 38 < 0:
        _dead_3059 = 805
        _dead_9723 = 888
        pass
    value = 769272
    text = __import__('base64').b64decode('UVBuSWhOZEZ2SHk5cWtqa3FsNzI=').decode('utf-8')
    total = value + len(text)
    return total

def _МКЩλпВΖУΛпд():
    value = 871573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CD3BeEMP66AFaQ6X+H29bQN2z2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПτωтΖΤюξΗβДГΘщνш():
    value = 284601
    text = __import__('base64').b64decode('VWpMeUJVYjRBWmF6ZWRtQTc1UlQ=').decode('utf-8')
    if False and True:
        _dead_3868 = 912
    total = value + len(text)
    return total

def _ИчΡμβОошκэрЦΒ():
    value = 558170
    text = __import__('base64').b64decode('RGh0enpQb2Jub29VckNjd3g2VGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ηρчΧМцищЬЭн():
    value = 470433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fh/vbGgrxJ0XPBWt/X+dETc+63s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 40 * 52 < 0:
        325
        pass
    return total

def _рΘμЗΧΗЖγХЖπнυνя():
    value = 133555
    text = __import__('base64').b64decode('QmRkeE1lUExEMlA3eWI5cnZLelk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟйИВпυБΨωкΚηП():
    value = 926997
    text = __import__('base64').b64decode('RGdTMnhkSUhLcnFXVDdkUnJ1STE=').decode('utf-8')
    total = value + len(text)
    return total

def _νЖΔφΛЙЩЗЧ():
    value = 847303
    if False and True:
        357
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiWyW2EV2J8LEly0ylqiZQoCyl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3775 = 122
    total = value + len(text)
    return total

def _γδψкοΗΖЯιйΤΦεπωυ():
    value = 401533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3buWEcW9JwtNlig+lPHHAgcxVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΔπΗяЗБкЪψыкЕ():
    if 26 * 76 < 0:
        922
    value = 857835
    if False and True:
        556
    text = __import__('base64').b64decode('d2U3MHF5Z25oODFYblR3MW9MYWk=').decode('utf-8')
    total = value + len(text)
    return total

def _αυеиρΕΕΩ():
    value = 947993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ljq3ZVNtza4PKzegymXFLTJ7xlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 5 * 81 < 0:
        955
    total = value + len(text)
    return total

def _ψΟЪИушбψ():
    value = 256831
    if 32 * 2 < 0:
        _dead_4948 = 697
        pass
        951
    text = __import__('base64').b64decode('bUg2ZWtXcE1CU2IzNXczdEZvelE=').decode('utf-8')
    if len('') > 0:
        _dead_5359 = 134
        _dead_3731 = 826
        838
    total = value + len(text)
    if 37 * 19 < 0:
        pass
        _dead_6320 = 811
        pass
    return total

def _ΙтяЖьΜθΗмиТοЫйμ():
    value = 358328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTXGVGEdxIsoFyO3wAGBFTN973s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 4 * 72 < 0:
        _dead_5985 = 873
        366
        294
    total = value + len(text)
    return total

def _гщйρΞψрИЦМ():
    value = 349061
    text = __import__('base64').b64decode('Y0JBZldiQmR0a20xcU4wUklEY0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЬιΦМΧΦБΗъΚΒεхзЪ():
    value = 373155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Djn9SFts8YNVaF+y/1uSEy8B23Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςγЪμСЦфЖиЦ():
    value = 698883
    if len('') > 0:
        pass
        _dead_5154 = 513
        460
    text = __import__('base64').b64decode('a2lLSnU5WEhiSGc4OG1XSDhLams=').decode('utf-8')
    total = value + len(text)
    return total

def _лЯψαΔЭУе():
    value = 169137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NX/saVgG86o7HA2X52OZLRALykI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фГбЮНεЕνВθА():
    value = 502396
    text = __import__('base64').b64decode('Y1BWOXAycU1mX0tINzBCbmFPS20=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1719 = 845
        850
        pass
    return total

def _РφΧτДΧэΒхш():
    value = 439774
    if False and True:
        _dead_2844 = 917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzvbYnJo87IKBVykykKbBiYH0zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        483
        _dead_9138 = 938
    total = value + len(text)
    return total

def _ΣΝмъЦξЧЩΘР():
    value = 883147
    text = __import__('base64').b64decode('Sl81dTNCbVlRR1N4MDJLSE45Yl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΥЯρыυЮщЛΗξ():
    value = 263347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3rwZ30KzpgJYyyP8VKiGyw7s0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2699 = 850
        302
    total = value + len(text)
    return total

def _БΕнзφΒΤπσР():
    value = 460881
    text = __import__('base64').b64decode('cWtCcVNCVVJma29CR2k4NnlaVG0=').decode('utf-8')
    total = value + len(text)
    return total

def _αэЕЖΩτЩБσПт():
    value = 194057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzjpX3Ns6aNWNzX6nmGRZhIX8l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _йβЦψΚДΡХдσΧчзт():
    value = 232213
    text = __import__('base64').b64decode('SzJ2Zmxsb29uRU9meVJVRFZrR3g=').decode('utf-8')
    if False and True:
        _dead_4699 = 516
        724
        _dead_1931 = 430
    total = value + len(text)
    return total

def _КИЭРытйμπΗиΑξΛ():
    value = 21339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwDVaVQG1rwQDQqp3FiTMwoh7D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΘмЫэЯαянгЪδ():
    value = 460868
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyjFeUUa1YMHMCf291ioCxQ1vUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙьΒκтэВσршμФыΗ():
    value = 532870
    text = __import__('base64').b64decode('c0xNUkh3NjUzclpsOTVaVUQ4aVE=').decode('utf-8')
    total = value + len(text)
    return total

def _δΘЫΣъХνΖП():
    value = 549361
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjqzZQdg7asaADf0+HOXLQQ6yWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЦΣтΡЦДΓρβ():
    if False and True:
        _dead_3520 = 639
        pass
    value = 688240
    text = __import__('base64').b64decode('eXR6WVJEX1RFb1VES25IbGF6TTA=').decode('utf-8')
    total = value + len(text)
    if 63 * 94 < 0:
        pass
    return total

def _τζХνЮйсκΨΡΙТΕ():
    value = 737671
    text = __import__('base64').b64decode('VVBkNUJBakM4eDBIendSMk5tYkk=').decode('utf-8')
    total = value + len(text)
    return total

def _νЧЬМеΤжΠчЫΣΥЪΩ():
    value = 828079
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('STdvaW9acG5LcnJtSnk1b3lrVzg=').decode('utf-8')
    total = value + len(text)
    return total

def _λЪθтАЮΟβ():
    value = 44354
    if len('') > 0:
        496
    text = __import__('base64').b64decode('RVdmd1hSdGNXU2xQYnFYNDR5Nlk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _щΤмтζЬоΠиΜ():
    value = 866397
    if False and True:
        831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXrrZn1qx/40Eiuu5QCbIih44Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЪσТоЭЦΘςШЙ():
    value = 345842
    text = __import__('base64').b64decode('T3plQTVXRDRISDZ2SzJaTXVpcDE=').decode('utf-8')
    if 93 * 98 < 0:
        pass
    total = value + len(text)
    if 75 * 84 < 0:
        _dead_3328 = 465
        _dead_9773 = 17
        _dead_8689 = 586
    return total

def _ЛНьйЙμНфИΘбКХΨαμ():
    value = 155840
    text = __import__('base64').b64decode('aXd3NVgzVXBWYmJqenVSTGlTSzc=').decode('utf-8')
    total = value + len(text)
    return total

def _зΙΤсбкеΤуяΣа():
    value = 442426
    text = __import__('base64').b64decode('VElhb0hGeGdLaDBURUtoSkZGR3A=').decode('utf-8')
    total = value + len(text)
    if 57 * 15 < 0:
        93
        40
    return total

def _πйΗащшζЭнζЯΙ():
    if len('') > 0:
        504
        686
        pass
    value = 134024
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTnQOl8h0pcpKRukml2aBRAL1UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 74 * 42 < 0:
        pass
    return total

def _ωЫДχοΠабЦпАΤ():
    value = 145384
    text = __import__('base64').b64decode('YjRZNlZ5a29xVlZJYXFSZFNsWlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠажвμЗψгЦфЗΣεыкщ():
    value = 509380
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cx3GfXJg1pI7KAqM/1WAZCM59Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λщЪΙдДЖθФО():
    value = 985087
    if 78 * 98 < 0:
        _dead_9119 = 728
        _dead_5428 = 257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCHWbQNv7IsFFjybyUWyMRok9mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЦРхЪρрЦбΤЦζΓ():
    value = 128476
    text = __import__('base64').b64decode('dVZHTThqcHp6Wmt3ZmF4SEo3V0M=').decode('utf-8')
    total = value + len(text)
    return total

def _οЮЧюЙьщθАΖξΖрЩа():
    value = 747982
    text = __import__('base64').b64decode('V3QzOEJ5QkRqSTJ5OGZxaGxjM1c=').decode('utf-8')
    total = value + len(text)
    return total

def _υШχпТуЙδУЩоκΤφζ():
    value = 814644
    text = __import__('base64').b64decode('RG82aGZhbXBsR0s0YWRBcEgyeG8=').decode('utf-8')
    total = value + len(text)
    return total

def _γЩЖпйΠеСΞΦеΕЮжοю():
    value = 237895
    text = __import__('base64').b64decode('UUdsOUFqb3RiOGdVMlBZZTZkVHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞмФПξСтζдъЬдσяЧ():
    value = 95932
    text = __import__('base64').b64decode('djlQZVRkWU9ET05UelVobHNEbXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ηКхΕΧιαЦ():
    value = 805233
    text = __import__('base64').b64decode('bnRJSktKWVRiNVRBc1VqT2J6SU8=').decode('utf-8')
    total = value + len(text)
    return total

def _МВЮдαЩΑЛΚΟюСНЫφ():
    if False and True:
        pass
        _dead_8504 = 193
    value = 594879
    if False and True:
        _dead_5298 = 248
        pass
    text = __import__('base64').b64decode('WEd3WE1LdUk4WFpiUERMR21WVks=').decode('utf-8')
    total = value + len(text)
    return total

def _стДΟВкмьЪДАι():
    value = 224200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjXtZVk7z6IlYjyT5FC4PQwc3mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛτλνЬИλχч():
    value = 515157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyT0YnI+37wGDiWg6mCZBzAA1l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒψПвлЙВл():
    if 45 * 51 < 0:
        _dead_9186 = 297
        946
    value = 150546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQzCRHJh6bkkFQXyy1qTYiR+9Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡωΩθψАцΝпΜдяДкΕθ():
    value = 259444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwzVVGkQrYIHAyG653e8ASF9t0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        226
    total = value + len(text)
    return total

def _РηОвυψδΛΟЬζ():
    if len('') > 0:
        _dead_5387 = 242
        110
        _dead_6521 = 530
    value = 659749
    text = __import__('base64').b64decode('anRqQXpzT0NfcXlnT3pnQzVkTnM=').decode('utf-8')
    total = value + len(text)
    return total

def _пДΩЪаΩΖсЮпЧъ():
    value = 535141
    text = __import__('base64').b64decode('U25fQWh3Z3BNQUFvdElTSVNFMDM=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _βянЩΖγΣВщвΛΔсθΙ():
    value = 215666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRXLQANq/JkBBQaU5F6FJT0Yzz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        248
    return total

def _ΝФыНцζКΑиΝШΣΥ():
    value = 250100
    text = __import__('base64').b64decode('VG1MWlQ2THVPUTJiaEV4STFsako=').decode('utf-8')
    total = value + len(text)
    return total

def _тκцРχВΞедοтЪН():
    value = 404896
    text = __import__('base64').b64decode('WGJuZ1NJM1J4ejBkTVBXWUx4UHY=').decode('utf-8')
    total = value + len(text)
    return total

def _НяжΒξαΞч():
    if len('') > 0:
        pass
        _dead_1961 = 346
        pass
    value = 626326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fj7QbUhvzK8ZDQKawVihCz8qyUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 14 < 0:
        _dead_1934 = 109
        617
        _dead_3872 = 545
    total = value + len(text)
    if False and True:
        434
        _dead_4742 = 799
    return total

def _ΤγεΒЯцаνηля():
    if False and True:
        _dead_7567 = 723
    value = 437735
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiTiO3QcrfhXLwGQ8EKRPgQW528='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗяеΣεσАшЫГУξ():
    value = 790308
    text = __import__('base64').b64decode('d2ZJMXUybkJFaV9seTJCazgxS0k=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4367 = 275
        pass
    return total

def _эαщрКЩХχδСπ():
    value = 50712
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NALBPVUQzfpRKCO68keCPzIj/Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝчиΞЙрΩΕςЧΡ():
    value = 594400
    text = __import__('base64').b64decode('Q0NmU1pyTzFfY2pMUXFvajNRdWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪХΘτχжШдΒЧаεчоΥ():
    value = 43381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACX9TQcOzpoXLQim5kKCBD0V4jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _σЮΛЮдщЧбτΥдΘε():
    value = 201593
    text = __import__('base64').b64decode('eEFuNUFnMmZBMFFOSm9aZnlCSVY=').decode('utf-8')
    if False and True:
        _dead_9556 = 205
    total = value + len(text)
    return total

def _ΗЖРΙΨыΖκъΚшτчΓΡэ():
    value = 249582
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR7LSXIK/JcBDFeLz3eXEx0m73w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟιжΣНβωАЯБе():
    value = 520332
    text = __import__('base64').b64decode('a3F2eDNtOERlTjV0SkpYMjJ0ekg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯоΘЛΦτδйτоπΥΔΥ():
    value = 553937
    text = __import__('base64').b64decode('ZTIxRzM1cDhhUVk2T201SG9Senc=').decode('utf-8')
    total = value + len(text)
    return total

def _ГфнΠιцρνоΥзф():
    value = 911116
    if False and True:
        _dead_8372 = 266
        pass
    text = __import__('base64').b64decode('SVVYQUtLbkJPNFZKQnIyMHZMOHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝфыючСТς():
    value = 485795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiXiYlwvqPoSHSf1zmGvPgYe00M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΤΓоΣГΥΨнс():
    if len('') > 0:
        _dead_1222 = 739
    value = 521160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx7GSGU+1fkJaDCS5FGWOwsjxj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _каΜКЛΝωΒεШθ():
    value = 572393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ey28bWMhxrEtA12Zn3qAGhMAzEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨνЫъωГГπθхГΞΗТ():
    value = 15162
    if len('') > 0:
        _dead_9120 = 762
    text = __import__('base64').b64decode('SWZqMHZyb1pJMWRmMVpOZVZLUWE=').decode('utf-8')
    if len('') > 0:
        773
        326
        683
    total = value + len(text)
    if 54 * 69 < 0:
        819
        881
        811
    return total

def _ΗщУφψΜΖсДπΣвЯ():
    value = 480542
    if len('') > 0:
        _dead_3282 = 79
        773
        pass
    text = __import__('base64').b64decode('ZGozRWdCMW1XX0JrOUxlOUZWYWw=').decode('utf-8')
    total = value + len(text)
    return total

def _βκИИЗΖъχпΒидДдМГ():
    value = 719333
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwDLWV8crpAkBTyVnW+ZP3YiyDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΡΦАЭУΛМнΠяΦ():
    value = 540037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MArqTUI/qZ0QCC2a+GagYzF3sT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чРΒΥρБρΘЕвО():
    if False and True:
        pass
        _dead_5480 = 127
    value = 129165
    text = __import__('base64').b64decode('ZXlza2RIczBKZkk5WGZwQXNYY2w=').decode('utf-8')
    total = value + len(text)
    return total

def _НгаΔЦξчцХНЬЦ():
    value = 504652
    text = __import__('base64').b64decode('SWc5YktMVE51QklPaU1TSDZvM2M=').decode('utf-8')
    total = value + len(text)
    return total

def _δΒΦΘρмсшМαξдд():
    value = 850261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3jLfnQ706ITGQyC8Ee4Lg9/t30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        264
        655
        323
    return total

def _ΔьΦвчцЗΣ():
    value = 674440
    text = __import__('base64').b64decode('c09lX1p3S2xEdGlGalJJUVhBdFE=').decode('utf-8')
    total = value + len(text)
    return total

def _κВτνШΒОгЧξλ():
    value = 187491
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jhu2XQY13ZgZaCiU0GSbYnElt1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 46 < 0:
        795
        _dead_4606 = 663
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _ΔωςΧτбЖκιлмΙя():
    value = 405712
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETXiVlQ9rqkOLl2K7kaZZzw1tF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤДУμЧυΧηγжσ():
    value = 328995
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS3wPkY6zaFRIxmW/lqnbXIm9zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζыгпΙζξΓΙхΕπПθ():
    if len('') > 0:
        _dead_4200 = 156
    value = 930156
    text = __import__('base64').b64decode('Ujd5bm0ybFJMNnh1dUt0eG1sdDE=').decode('utf-8')
    if False and True:
        _dead_2003 = 740
        _dead_7677 = 859
        pass
    total = value + len(text)
    if 85 * 63 < 0:
        _dead_6126 = 181
        pass
        pass
    return total

def _ιοлωОфБΦиβаΞρ():
    value = 427578
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISrFf3cc0IAgY1yU4Wa7ABQi1EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВζΙθЪВЬΩλψ():
    value = 250709
    if 12 * 84 < 0:
        pass
        _dead_5919 = 677
        49
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjW1YFsY8KkVY1eX7GzGOSoj3m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βпВфΙвпΒεδЮ():
    value = 855789
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRy2YFcp3bgyAFqR0H2EPA414VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аВαΔцбБπЯς():
    if 50 * 76 < 0:
        91
        973
        632
    value = 629976
    if 90 * 57 < 0:
        pass
        _dead_8314 = 129
        _dead_7945 = 818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDreXAkfybxUHz6W6lmBECQD5T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пУйрмиΑЪпЭΓЪГЪ():
    value = 392687
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiDPeVMV3YtWGQeK/Xu9Gj0Y0Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠДэΥφγкшШκ():
    if False and True:
        pass
        333
        _dead_5042 = 130
    value = 360452
    text = __import__('base64').b64decode('VWhVbXhiWmVYVEpFX2RtTlF3eXk=').decode('utf-8')
    total = value + len(text)
    if 77 * 81 < 0:
        977
        _dead_3447 = 47
        447
    return total

def _φкυзхФΑИНэΥЭΝδξ():
    value = 873771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B368RgIo05svahis53mlHx8o4UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТюэЮшχКΙξкΤЮдю():
    value = 602584
    text = __import__('base64').b64decode('T1ZQNVlza19XcWhIWmxCT1R4ZWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ξгГΩΤηшψкΟПЪьΒΤн():
    value = 116160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ay7helpt8KpaBQql7QKHYSo5sHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОлЧЧвΕУΠΕΞσΒλ():
    if 19 * 29 < 0:
        921
        513
    value = 868257
    text = __import__('base64').b64decode('VFZiQjliTEdTRER5NzJtQkdYOU4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4627 = 675
        224
    return total

def _ΝςНΙОιξжШ():
    value = 248083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NH/RagYY3JIRDg2u71e1IHcf1Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΟγЫυωΠйя():
    value = 379046
    if False and True:
        _dead_5506 = 122
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQzXYlJhyLpTHhe1mWG1DQx25TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        818
    return total

def _ΑлАθЪБψБйξехгуоЬ():
    if 73 * 52 < 0:
        _dead_6544 = 973
    value = 256394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhvhbWgd54QqPD32ygGRJBcAzV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 15 * 9 < 0:
        _dead_3716 = 904
        663
        224
    total = value + len(text)
    return total

def _υЧйеяоΕεЙΝоЬкЧлΛ():
    value = 417266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXr3OnVrqrFVERm3mnCkEyg/tjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΘοйДйЧтуςΑ():
    value = 245625
    text = __import__('base64').b64decode('cE1lUnpDZHQ2cEdlbDNiVU1LMlI=').decode('utf-8')
    total = value + len(text)
    return total

def _сИΔαΜэΩΦВσАЬАзб():
    value = 584358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgfOW2kv5KVSPxq05U6UZCMN6n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΙγьΝяЙρξЧ():
    if False and True:
        pass
        176
        pass
    value = 307162
    text = __import__('base64').b64decode('aFNVVmdRZlVBWGtJU08xcjBsS04=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5570 = 600
        _dead_3070 = 935
        253
    return total

def _ΞечЧηУγжΕАФυΙοХ():
    value = 969411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHbCSkIO8pgrMiyQ+kOYbSsK7Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if 8 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 84 * 93 < 0:
    _dead_7499 = 877