#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ВυУЛйчсΚτεэΧη():
    value = 889605
    if 78 * 65 < 0:
        102
        23
        200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh7qWHA4qpsNMwuO7GmUJwM/4kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        252
    total = value + len(text)
    if len('') > 0:
        308
    return total

def _λΘγХЖτΘςФρτосΥ():
    value = 289460
    if False and True:
        210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByvrZUQyrJ0JLweukX2UDR8Z8XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 77 * 71 < 0:
        _dead_7030 = 12
        160
        _dead_2656 = 738
    return total

def _ΩΗЬβйεΚπЕэвШ():
    value = 891072
    if len('') > 0:
        539
        952
        _dead_9685 = 288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXnRdkhvqKkZNQqVwwTAHyEKtFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 54 * 32 < 0:
        pass
        pass
    total = value + len(text)
    if 26 * 51 < 0:
        pass
    return total

def _ξΖΨΔфΥущΡШοХэЮ():
    if 58 * 5 < 0:
        805
    value = 483227
    text = __import__('base64').b64decode('Y01LblFIb0k1dGdZTlVFZEVhMHA=').decode('utf-8')
    total = value + len(text)
    if 56 * 26 < 0:
        pass
        112
    return total

def _νΖрдΧоСοИЯμεμЧΖ():
    value = 761650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRDpO1AD/4BVFQWX8FqfHnQhy1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7522 = 19
        _dead_7058 = 759
    total = value + len(text)
    return total

def _ЫжκΟпЕВΛΧτМυ():
    value = 558768
    if False and True:
        pass
    text = __import__('base64').b64decode('bVd0QW16dDFPOXRMTUY2MUtPQTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ζчΜρоψХЩю():
    value = 977496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRjyO3Qd6oQ8DV+L9weYISI5z20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        160
        pass
    return total

def _тияΖрςтжλΑСδЖΒψ():
    value = 98462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iie0e10e6p8AECeC0H2SGXAl60g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣОнРξηδбμиΦЬ():
    value = 446049
    text = __import__('base64').b64decode('bWhrMFB1aGZnd0Q3bVBzNFQ1alE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑЮΩвщΦРЬΧуΝКΣνΝе():
    value = 398797
    text = __import__('base64').b64decode('ZUt4NENsN2hWRDEzMmVOMGhsWFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЖУκφМΞцΓλΞоЫψςΓ():
    value = 797457
    text = __import__('base64').b64decode('SGJsNUJ0N3BfTE01UzNvRW00SHo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6865 = 169
    return total

def _ΦКхьΕΛδЗфыΚλ():
    value = 394893
    if False and True:
        pass
        442
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L33LaVkg9PolLAO2zELGZCckz28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иφεшТγХτΠэЪд():
    if 60 * 79 < 0:
        pass
    value = 551710
    if False and True:
        _dead_2897 = 109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTjoR3860ZAhDFyAkAGXIjQbsTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2404 = 28
    total = value + len(text)
    return total

def _ВЪΡЧЕРЛΖДΑЪдпЧЕ():
    if 70 * 8 < 0:
        _dead_6306 = 652
    value = 458209
    text = __import__('base64').b64decode('UGhwUzFvRG5jb3R3TUI1dlI3ZnU=').decode('utf-8')
    if len('') > 0:
        pass
        896
        _dead_2047 = 840
    total = value + len(text)
    if False and True:
        _dead_4316 = 876
        pass
        pass
    return total

def _тшνБЙψКчЕ():
    value = 370190
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQrgZwgvxqUONQiX7XexGC026Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еИКЧΗαкН():
    value = 482795
    text = __import__('base64').b64decode('WjdCVjlZaDhKSkEwVFVSS1ZldGg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9964 = 417
        _dead_8953 = 397
    return total

def _ιμεΤγэяЮЙφЕМΧΒУΛ():
    value = 299375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3y1N1M+9PsWHAOpkUO8IzY3sUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БкДюБπΡкгΣшΧЪ():
    value = 879496
    text = __import__('base64').b64decode('R3U0OEREakIyY3c2cjY5amJWYnQ=').decode('utf-8')
    if 90 * 51 < 0:
        911
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_8814 = 708
    return total

def _κЪνψΘυΥμφпф():
    if len('') > 0:
        196
    value = 439550
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bz/gQFMS0KAuKgKSzFLBInUO610='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 49 * 37 < 0:
        pass
        _dead_5171 = 765
        667
    return total

def _ЭЬφκθФйΟΓΣ():
    if False and True:
        pass
        _dead_8121 = 409
    value = 230886
    text = __import__('base64').b64decode('Y045bnZITjZHcV8zb3Y4ZkN6dGU=').decode('utf-8')
    if 5 * 95 < 0:
        643
    total = value + len(text)
    return total

def _τФяоσσЭАДНκτъθ():
    value = 409241
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cx/CPEYh8qYIMxub/QKfGD8GykQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        9
        pass
    return total

def _аΩяΙγаЕОΠБθФ():
    if len('') > 0:
        pass
        447
        686
    value = 577110
    text = __import__('base64').b64decode('cmZFSEt2SGVzcUx5MjI5VVVWeFk=').decode('utf-8')
    if False and True:
        _dead_5468 = 43
    total = value + len(text)
    return total

def _ΩΦсγгσρО():
    value = 751586
    text = __import__('base64').b64decode('WlZrSmNYZU5ybWtOSWFZY1NGVjU=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        278
    total = value + len(text)
    if 14 * 9 < 0:
        _dead_6408 = 570
        _dead_1336 = 812
        130
    return total

def _яΨΥΞΜЙГφЮΟыΚфЖΜ():
    value = 275073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCP8WkcX8/gvYwv67gOmER0uvV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        671
    total = value + len(text)
    return total

def _ΦШеЮГΘсΥΡ():
    value = 850220
    text = __import__('base64').b64decode('dURLY25rX3hnUXpIeU9feWp0NkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭГЬΝχγΞσЫΡтэоΣьΗ():
    value = 457282
    text = __import__('base64').b64decode('SkY0WGxTNUJGeXBKbVE1Z29jVm4=').decode('utf-8')
    if 2 * 63 < 0:
        406
        pass
    total = value + len(text)
    return total

def _ΑΖЪμοьΕпгфιЕ():
    if len('') > 0:
        pass
    value = 505383
    text = __import__('base64').b64decode('TjZtRlVkMkFnb0w4VzdKT3BQdzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ГКωзсАоζДД():
    value = 438037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ljm0O1w1qJIZaSyBkWHBEjcm4lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ЪυйσΡΚХЭρП():
    value = 481535
    text = __import__('base64').b64decode('Q1UzOGhYQWFuZExwTm9rRUhzaEg=').decode('utf-8')
    total = value + len(text)
    return total

def _οτδοΑчИΠпйЪмБ():
    value = 843585
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACbjZEgrqbBWNVyiznWSFzYa/mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΖΡξюОνΓ():
    value = 322373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSXbVktgqY5QLlmnw2mfYB8E9U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΞΠΟжЪβοЮГПΗж():
    value = 351345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSzPSEkJ6YUALlmo7AGlJiF20GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хИЯφΟβБХΝыЯρК():
    value = 433299
    if len('') > 0:
        220
        552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBe0WlMj+4UzLzCwm3zJZwJ+9WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙсηРυκюдΝяπΥЭбЖю():
    value = 459182
    if len('') > 0:
        _dead_2307 = 369
        pass
        pass
    text = __import__('base64').b64decode('VVZhOVUzNDgzbnhxUlBCU0FjSXo=').decode('utf-8')
    if False and True:
        108
        _dead_2024 = 137
    total = value + len(text)
    if False and True:
        pass
        78
    return total

def _МΧЗыкπЫПψъβ():
    value = 232706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAngd2cqqv0kLAyam2/AJzEBzW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МВδХслρΙЛулЛ():
    if len('') > 0:
        _dead_5304 = 854
    value = 45934
    text = __import__('base64').b64decode('c2JjNVhpZnZhTGtTTGpLTXZfZm4=').decode('utf-8')
    if False and True:
        _dead_5269 = 513
    total = value + len(text)
    return total

def _ΑЫЭΤαУгШЮγιΡмБЮМ():
    value = 664794
    if False and True:
        pass
        _dead_3615 = 828
        pass
    text = __import__('base64').b64decode('bVhwZFFGVURFaVRnRXN4NkRBb3k=').decode('utf-8')
    total = value + len(text)
    return total

def _υрΒρпЖсφ():
    if 56 * 41 < 0:
        154
        872
    value = 173106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBa2PgYQq443bS3393mJCwB/60M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ИςΣΗгеθВНоΣνγ():
    value = 125459
    text = __import__('base64').b64decode('RjlmczFrOVgyczBNelBHSEx3MXc=').decode('utf-8')
    total = value + len(text)
    return total

def _γЮγβηΤеФцББЗ():
    value = 352863
    if 41 * 97 < 0:
        _dead_3914 = 584
        _dead_2625 = 814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBfSXAM+360hEgya8nilMz8Gzl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗЭЬηтсβΚνЭйα():
    value = 122067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTvuXVMb7Z03NjuV+37CNisN1jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МНмфρτΔЭыμхУυЬ():
    value = 631183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCfrWAQrx40TNzCB71uoF3Qb6X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΘгтεΜьФ():
    if 64 * 72 < 0:
        _dead_3264 = 373
        _dead_2550 = 585
    value = 290465
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HC3nXgcq+ooZAlmbx3yRPwMYy3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        213
        _dead_6745 = 361
    return total

def _ΥΦωΘгюπΕЗΩξзЕιО():
    value = 264043
    if 92 * 90 < 0:
        _dead_9165 = 773
        206
        _dead_4536 = 889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgXoWGku+ZATKCny23KaBz8ovUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 74 * 51 < 0:
        _dead_5856 = 733
        _dead_2453 = 429
        pass
    total = value + len(text)
    return total

def _БзЪесυΖυэусΟΔ():
    value = 349382
    text = __import__('base64').b64decode('elBUZndqN19hcmlEaExRSVBfc1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _κпйюαаιξБЪЛ():
    value = 286023
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgfDQ3wV0/0TOBmRzX3AGzclxWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΒКΝЙнаТРщюЧ():
    value = 330983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTbHeXUr6voOHgCp+2ajYR02w1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡЮΞеыаγδИΩЮυγ():
    value = 800991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQ7ea0A6+4sbPAeknU6hFws37kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βъцδцаΟνНΟ():
    value = 184875
    if False and True:
        pass
    text = __import__('base64').b64decode('dXNDaWlaOWJFekRjRlhOb2RLX2c=').decode('utf-8')
    if False and True:
        _dead_5339 = 552
        _dead_2782 = 235
        _dead_9833 = 531
    total = value + len(text)
    return total

def _ΕΩфμφΥΒξАλшΩξ():
    value = 183450
    if len('') > 0:
        _dead_1095 = 46
    text = __import__('base64').b64decode('SEJoRmtGaXJiSjA4Rzhwbl9FZ2w=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ευΙθЩДща():
    value = 375912
    text = __import__('base64').b64decode('dFJoYVg0R1RHNl9SY0Z4YkpJR3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЩЭΒΙΚδΟΣΔЕσχЫО():
    value = 754499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxvoZXs4xIRUNSaGkFWiMQN/90s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝбΟρрΗΓμЪоюЭЫХ():
    if len('') > 0:
        pass
    value = 439572
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCrPW3we07kyFFyw/Hu4MyR95V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_2071 = 852
    total = value + len(text)
    if len('') > 0:
        _dead_8346 = 989
        _dead_3932 = 681
    return total

def _бΒнщΚθБφЮсΥ():
    if 98 * 20 < 0:
        _dead_6216 = 956
    value = 127027
    if 39 * 27 < 0:
        pass
        _dead_8439 = 863
        68
    text = __import__('base64').b64decode('aElsTDlNd0xpbjJONVRZV2U4R1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩВπТиСнαταΒΧρПыΠ():
    value = 324930
    text = __import__('base64').b64decode('TVNvY2xQNERrSktUTUt2bXl4Yks=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ойωИωйσчΨ():
    value = 668237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxbuUQkvy7w5aAyg5HvAGxUD0lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χмъζυΤОЫЬъ():
    value = 788612
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3zXeXUGq6Qvazr20FKgFjc9/Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮρΑАΠСЕнγчηшЩЭρ():
    if 49 * 54 < 0:
        609
    value = 621349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXy3Rgc68IokPiuc21iTLnMg1T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аэльУΡнВ():
    value = 365683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASjmaks/6bE8E1qW7VmaYDwOyUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лτφΛЭΡηχΘΕ():
    value = 844499
    text = __import__('base64').b64decode('SkdIU3VxTmpscVZENHF2RGR2Tmo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЬУвρΥΚХηχτЪфΞ():
    value = 360495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ngf8VEEz1qUhYheBn3W2ET8I00o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡнЪВысαяЛ():
    value = 514661
    if 52 * 36 < 0:
        _dead_7432 = 210
        483
        765
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS3JdnZgrqEiNQOA/2C3DRUD5zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5969 = 299
    total = value + len(text)
    return total

def _ЧπаηΓЖюλД():
    if 57 * 38 < 0:
        906
        pass
    value = 568361
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzrHf2MPrqQwND+631yGETA5vHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        400
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ΓτΣЛйμюκζΧΒΣУ():
    value = 136141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwXmVkg63PA8IBeT/GKiDgoe008='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗοЮΔΚεфцπΙюςш():
    value = 829834
    if 100 * 52 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHnUdnMO5rILaAWx0GC/Zy01szo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яεЪχΦГΤκхчвΓЯ():
    value = 61285
    if len('') > 0:
        440
    text = __import__('base64').b64decode('cmJLNHhyNV9CSk00SlkxWDBFbDA=').decode('utf-8')
    if 75 * 72 < 0:
        pass
        pass
        _dead_4593 = 979
    total = value + len(text)
    return total

def _ΩΑЧхКγπцΝρЗΚΟя():
    value = 173823
    text = __import__('base64').b64decode('bVM3UDdRSkdnUWJ6TlNPaUhCUHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕхИГмΦφфΡ():
    value = 73067
    if False and True:
        pass
    text = __import__('base64').b64decode('TWh6ektxTEVUOHI3SktVcjNxS1Y=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3996 = 663
    return total

def _ЪΒΓЩыДтуфЙ():
    value = 564330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyvzfFId9oA3M1eH0nOEJncI4XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗтκСВЫзЫΥ():
    value = 141994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCXsdH0+9fkRAh+Z2H/CNxwctUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фηКЫтΗАαГΚВКЕЫ():
    value = 379474
    if 3 * 4 < 0:
        _dead_9875 = 266
    text = __import__('base64').b64decode('UUFSbmRONGtGb19kQmlyMWx5Rlk=').decode('utf-8')
    total = value + len(text)
    if 10 * 92 < 0:
        _dead_9729 = 322
    return total

def _σБκжГΒАψлτοΒо():
    value = 953739
    if len('') > 0:
        pass
        401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCztSWZs8JkFKh+ryk+RBXUH52o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        907
        116
    return total

def _гФσгиξжαуь():
    value = 28237
    text = __import__('base64').b64decode('THZkVWdsWExoUUZHQWhvMkpvX20=').decode('utf-8')
    total = value + len(text)
    return total

def _ОцРψΠВкШε():
    value = 848821
    if 31 * 7 < 0:
        117
    text = __import__('base64').b64decode('bGxkdG1jZHRrY1dRRndJWjhzVmE=').decode('utf-8')
    total = value + len(text)
    return total

def _аψΔσρЗЭωΒΓζκΚΡ():
    value = 492908
    if 95 * 38 < 0:
        pass
        600
        _dead_8144 = 517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRvrOkkoyfkaNQr020a2IzUs10E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        709
    return total

def _УПΝЯρФкΚыΨ():
    value = 867003
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('UFNJWXk3ZTlxcW5xY1RrT3lHZTg=').decode('utf-8')
    if 60 * 14 < 0:
        pass
        825
    total = value + len(text)
    return total

def _БΔЛшРνξОйσξг():
    value = 386966
    text = __import__('base64').b64decode('V3U0MEtBZGZrWlc3Z1F4MHp6akc=').decode('utf-8')
    if len('') > 0:
        _dead_2980 = 220
        pass
        514
    total = value + len(text)
    if 49 * 79 < 0:
        541
    return total

def _СΠРНΣΚξзиаΥЭК():
    if False and True:
        _dead_1805 = 779
        pass
        pass
    value = 631486
    text = __import__('base64').b64decode('eF9FNlEyNFg5dFNTWVA4NXJKUFI=').decode('utf-8')
    total = value + len(text)
    return total

def _тωωωЩΨσψΜυαыСь():
    value = 381552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgnmVgkK9owLYgyX3XCnMn0B4E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟпЧюΑПГΔΞдЯΘсξσр():
    value = 230963
    text = __import__('base64').b64decode('eU04RUhHUEY2QjFKU1k3MlNCdUE=').decode('utf-8')
    total = value + len(text)
    return total

def _вввЫΓоыКβмΒеηН():
    value = 872627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQjodHAJ6fgrGAWGn2SBJA45sEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΘгаδеЛюΤзюτчэ():
    value = 785193
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiTnZwZqy5tUERWT4Q69JSEh40c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔθюΒιСБйаΒпωТзН():
    value = 660741
    if False and True:
        591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ei7qY18d9q4yIiHyw2G/DXEp8Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лЖыΒЭщФЯΧγΔт():
    value = 457370
    text = __import__('base64').b64decode('Z3ZHc1dDR19EVmtITTdSVlMyc0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _νЯЭιшлНСμξУ():
    value = 931182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah61SX8P35skER2N22yTYBV79zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РНυφмΝХйεШ():
    if len('') > 0:
        pass
    value = 453333
    text = __import__('base64').b64decode('YngwdlNERzB4Y2I3RVl4WFhkcEE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        698
        _dead_8539 = 847
    return total

def _ЪигКЪφИдЯаκΔητ():
    value = 834213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjvuQWAg6Ycwbla5/nezP3B+wjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_4545 = 210
        _dead_9442 = 49
    return total

def _МκйшщФЯς():
    value = 48148
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhXzYHw22acUGSmJwWGbJQEl0Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦπхЪλЗнЯМвЮ():
    value = 762768
    if len('') > 0:
        pass
        pass
        840
    text = __import__('base64').b64decode('cGFTODJrYUdFR0J2QU5vZlV4dkI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        230
    return total

def _ΦФΠщΥцΣЛМΘΣγ():
    if 1 * 80 < 0:
        _dead_5453 = 550
        _dead_4133 = 172
        702
    value = 564343
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('Z2ZveEpnRUxPNlhRT2tFQUNtSTE=').decode('utf-8')
    total = value + len(text)
    return total

def _эЭлΓИДеνλωτφБэчП():
    value = 846635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCHMUWkA978ULjCwyl69NjF36EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τкΣΡορыЙ():
    value = 981740
    if False and True:
        365
        _dead_2011 = 486
        953
    text = __import__('base64').b64decode('R3lQckRZTEp0V0FIRmYwbnNiZW0=').decode('utf-8')
    total = value + len(text)
    if 75 * 8 < 0:
        471
        _dead_5226 = 89
        pass
    return total

def _ЪзКлττЭагΠμнэ():
    value = 798002
    if len('') > 0:
        553
    text = __import__('base64').b64decode('dEtWWFo0bWJlc1dyUm5XSUpxc0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ХηеζйЛЦМΣя():
    value = 193679
    if False and True:
        78
        _dead_4677 = 796
        958
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSbheGFh//0lAFqlxESVCw980nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тθаΠЧЮСΩ():
    if False and True:
        pass
        _dead_2107 = 851
        202
    value = 837030
    text = __import__('base64').b64decode('dGhQUWwweFoyQ1g5YmFtQjYySDY=').decode('utf-8')
    total = value + len(text)
    return total

def _σΨьуБΨυЦΑА():
    value = 750898
    text = __import__('base64').b64decode('cGNaeXI4NVVGcHI2WkpBM2FTS2k=').decode('utf-8')
    total = value + len(text)
    return total

def _шФκχБаЩя():
    if len('') > 0:
        pass
        160
        _dead_2522 = 590
    value = 646130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ijf+OXwB0oY2Fj+k3FqbMREI52U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 75 < 0:
        _dead_7334 = 73
    total = value + len(text)
    if False and True:
        288
        pass
    return total

def _τтюэкеВζЬЯ():
    value = 256006
    text = __import__('base64').b64decode('dFdGekpDUWx2V3BXaTBoTExBbHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ВзяуσшτΩ():
    value = 79775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwblSgYa3ZEybRyP7GDDIgYm4mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 69 < 0:
        577
    total = value + len(text)
    return total

def _щбΡΜδыхаΥЛхΖтЛ():
    value = 32702
    if 88 * 26 < 0:
        _dead_6900 = 44
        pass
    text = __import__('base64').b64decode('blZTX1pkWjhmQ0RVVXpBMWtpWVc=').decode('utf-8')
    if 58 * 13 < 0:
        _dead_5293 = 896
    total = value + len(text)
    if 95 * 9 < 0:
        _dead_1454 = 662
        21
    return total

def _ЦΒЭЫφлеΠ():
    value = 161973
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSvNOHUMqPsWAgj12XilHAQ94mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςЦΒΘΔπΛВλΥыДгΒЗй():
    value = 82780
    text = __import__('base64').b64decode('UmJQRGhxc21KWXIxdEJseGdrZDU=').decode('utf-8')
    total = value + len(text)
    return total

def _σμΡΗЦсθΘУюоνъъс():
    value = 709947
    text = __import__('base64').b64decode('Rm5XT2xNSV9US2FrVUxhUUFVTmc=').decode('utf-8')
    total = value + len(text)
    return total

def _НЗэΔжНΞКЖγοэ():
    value = 51540
    if False and True:
        419
        _dead_9388 = 80
    text = __import__('base64').b64decode('dlFUVTdKSUp6aWFBTDFKWkdCQ2M=').decode('utf-8')
    if 49 * 51 < 0:
        1000
    total = value + len(text)
    if 20 * 67 < 0:
        873
        529
    return total

def _УьΔΝОΚΣп():
    value = 585489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBbzTH4R/ZkhFwf25QW+Hnca700='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡжШеυΒВВгфСмИΞρ():
    value = 739428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDn9ZWMD9JcsMA370GSbGnE1xWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        413
        _dead_4467 = 585
    return total

def _эдηΝщМΓЧΔнλся():
    value = 341236
    text = __import__('base64').b64decode('Ylp0M1VFU1Z6NjBEZHJrR1BCaHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕлбЛςКΜмЪρνюФ():
    if len('') > 0:
        862
        720
    value = 417313
    if False and True:
        411
        992
    text = __import__('base64').b64decode('ZkNwODF0YVJWRnBqUFpBbHB3V18=').decode('utf-8')
    total = value + len(text)
    return total

def _сαΔШйΛвОοЙοжСкбЫ():
    value = 855803
    text = __import__('base64').b64decode('Zjc5VWhHdGxsdUI0TXd5aHdJVGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙюПуРηчΜсцмЫцТм():
    if 3 * 13 < 0:
        210
    value = 56759
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBC9RkJq5poSL1/y71W5MxUDsFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БуΞмнτЕΜΒ():
    value = 525027
    text = __import__('base64').b64decode('RHcyZ1RrZ0R0R0ZfRl80Z0VKQmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖэΣΔУΝΜΠэξ():
    if 8 * 35 < 0:
        946
    value = 670816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FH/FZ2gy7Y0UOAKP+GK9HxE/zWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 82 * 27 < 0:
        pass
    return total

def _ΣСуρщρΓТ():
    if False and True:
        _dead_5620 = 668
        _dead_9504 = 489
        _dead_3871 = 657
    value = 163058
    if False and True:
        80
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRvJTWQBr5gyLQP1yQ+8MAM64mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚЛΛτЖνπнΓю():
    if False and True:
        pass
        pass
    value = 672563
    text = __import__('base64').b64decode('YjBtMlI2SU1HSlIwRV9YNjVaVnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ТГΦπчтдЬЧ():
    value = 83147
    if 39 * 1 < 0:
        420
        _dead_6023 = 696
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiXMWGsO75pbNia133SVFTQu120='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        179
        _dead_3470 = 217
    return total

def _ЦоЩфΡЫφц():
    value = 171825
    text = __import__('base64').b64decode('aTl6YzdJd2VWT3VRcmttWVJRTnk=').decode('utf-8')
    if len('') > 0:
        592
    total = value + len(text)
    return total

def _ЙμгΡЗЛйШнЯХ():
    if len('') > 0:
        pass
    value = 449020
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD69OloOpq4ECBeT327HIil/y1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сЯЦΩΟφΤααΧхηДσ():
    value = 861182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCH2VFNv87EBPiCM73O3MQo9t1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФрциφшψШυмΡα():
    value = 557657
    if False and True:
        pass
        _dead_2066 = 39
    text = __import__('base64').b64decode('ZzVwczVZcmVzaVFXNDhGUWFvVXE=').decode('utf-8')
    total = value + len(text)
    return total

def _щςβΚУИεо():
    if len('') > 0:
        _dead_3419 = 618
        _dead_4317 = 352
        pass
    value = 652436
    if len('') > 0:
        853
        792
    text = __import__('base64').b64decode('YnNIZlI3cmZQUEJJdzVDeTE1MWU=').decode('utf-8')
    total = value + len(text)
    return total

def _εψьЕΤИЗΘХяЧ():
    value = 863452
    text = __import__('base64').b64decode('ZEdfYTFodjdyeXlWc0F0U2Jtalk=').decode('utf-8')
    total = value + len(text)
    return total

def _ψσσщКнЦφЫΨιмЗщК():
    if False and True:
        pass
        197
    value = 935408
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In3xOgdu9rhRbg2L/gKADjIl4Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        446
        _dead_6903 = 13
        823
    total = value + len(text)
    return total

def _зΣιыΥχОε():
    value = 692208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAPxeQY38q4NFhaOxHWvNj8c3G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΜΛкЙλиΘΧξ():
    value = 148024
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dw3pUUgo/KMlHlau+HWmZRMrsHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧВρУЧΑчΖаδΧΞΩПДε():
    if len('') > 0:
        _dead_2672 = 341
    value = 108301
    text = __import__('base64').b64decode('WUVUcEczeFV0NnpCSmdkWVdDZ1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟσΥρдφцкмΖωθаπн():
    value = 907189
    text = __import__('base64').b64decode('ZVBaYUw2bURiUTlnNnhJUE44SWc=').decode('utf-8')
    total = value + len(text)
    return total

def _АκпΝΑΞΕвЪ():
    value = 544551
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iw22WGk657ggYgyk7lyYZDY86jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гКтВдμμэЙЭЖλТ():
    value = 115579
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AizPVkE116Y0aAGX7m+qYBUj5VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХГжГΛΣεζаΖтνι():
    value = 791375
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyiwOUAaqv0qNCb27li4YBE7w3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΣβчХпΓρцЬ():
    value = 397786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQrjVGVurqABPDmcmU+vFywsyD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚλЩозЫуз():
    value = 57565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ay38YWU0/bIkIF76w0y7ISIA1Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΔГЫуйгοзцШΤпз():
    value = 363873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxjeWQYsp58OOVqJwmW1YDYZy18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3895 = 395
        _dead_4883 = 211
        pass
    return total

def _вσрЭЭКВУц():
    value = 690045
    text = __import__('base64').b64decode('QUlOeVFwQUdWV0xQSDRfTGxHUVQ=').decode('utf-8')
    if False and True:
        pass
        258
        pass
    total = value + len(text)
    if 26 * 71 < 0:
        378
    return total

def _пЦΖЭΒсοыΛδμЖ():
    value = 614086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyW3PXtp0q4OFSatwF2qDT8j72g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηнВкЩΕΤιψ():
    value = 87481
    if 26 * 21 < 0:
        pass
        pass
    text = __import__('base64').b64decode('Z0NQQlNXWkhrRGZ3T1JMTnN6bkk=').decode('utf-8')
    total = value + len(text)
    return total

def _νΖθυΗОчюμΠсΧХζ():
    value = 211446
    text = __import__('base64').b64decode('bTJaNEJ3T2xtRm9xM0JkckJ0eGo=').decode('utf-8')
    if 32 * 66 < 0:
        208
        _dead_8729 = 597
    total = value + len(text)
    return total

def _ΘЫЖЯКОЗцЗЛθТΒ():
    value = 437778
    if 3 * 53 < 0:
        pass
        712
    text = __import__('base64').b64decode('TjVsQkcwMXhfZm8xTzJTM2lyNmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ИξηЦΗХχпЕΔΨйρΟ():
    value = 422568
    text = __import__('base64').b64decode('TWRWa3lvV3J3MTdSRkQ2RDJUa2U=').decode('utf-8')
    total = value + len(text)
    return total

def _τΞΗъЖЪΧΟаМцЬτШыЖ():
    value = 749366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kg20fUEw7oQtb17zmVLJPCgb12c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ебафюΔΩэлхюΧΠР():
    if len('') > 0:
        pass
    value = 725742
    if False and True:
        _dead_4454 = 783
        993
        963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bj/DXmIG5r8wGTmr+Aa/Fj8k7l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΣМοъЫъКμθΕЪΠνзω():
    if len('') > 0:
        pass
        pass
        pass
    value = 569505
    if False and True:
        pass
        43
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ER/dRn8P+p4iAhuyzFmABBohsT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 49 * 25 < 0:
        _dead_3387 = 595
    return total

def _мсьЕЦμвωФЭяГΨаГУ():
    value = 580579
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnbNbFUtqrAtCQLz4HPGGygZvHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГνεШОшюЗΟΠЗμβщсР():
    if False and True:
        866
        _dead_4056 = 73
        837
    value = 480613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj7od3Zp2I8xMR31kE7HBj0H4GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭИЦЭВПсΖдгЗ():
    value = 531386
    text = __import__('base64').b64decode('VHc4ZHVfUHVyc2hQZ1NKdzl5Z2c=').decode('utf-8')
    if 42 * 44 < 0:
        486
        _dead_7245 = 717
        911
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ικыΗωςθΣИпэЙ():
    value = 187152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhnRO30S2b4pNjCJyg/IERM/9Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τνдтθекΓщΤмТЫΔνα():
    value = 134284
    text = __import__('base64').b64decode('Q05IRml0dWw4eUVnODlBeUlaN28=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒзυКдфИЯПΠПζζωщδ():
    value = 588409
    text = __import__('base64').b64decode('QzhGajdpNnBOckNPdTJwWXkxN2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪРЖХΞпΚМУгСΠау():
    value = 258173
    text = __import__('base64').b64decode('UjJNMXNIT3VDdU1mZ3VtdWFmdUg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        857
        _dead_8838 = 475
    return total

def _шьЕπЭГβΤΩ():
    if 16 * 33 < 0:
        pass
        123
    value = 167204
    text = __import__('base64').b64decode('S2pJaGZ1V0ppSmllTTRIRk4wd2E=').decode('utf-8')
    if 10 * 96 < 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_2836 = 315
        pass
    return total

def _цсдМηяαНОэИ():
    value = 179442
    if 34 * 38 < 0:
        276
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyfFaWEo1K8ALCivyUK4MiMItXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        716
        947
    total = value + len(text)
    return total

def _ΔΘμтτЗяς():
    if len('') > 0:
        pass
    value = 41074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQm8eABqp5k2NyKPzX7JIRI6sWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЧοψаВΚΟРЪэς():
    if False and True:
        614
        _dead_6014 = 890
    value = 416635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHbBXWIwxIpRLQL66gXADAs7sX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓκиΠСешьΛМъ():
    if 75 * 37 < 0:
        253
        885
        _dead_9873 = 774
    value = 123165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjbQaX4e8qcbKgGs42GvLSEm4mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        6
    return total

def _μВΑЬΛφЖφШσк():
    value = 301044
    text = __import__('base64').b64decode('ZE1HZTRhOTQ1cDBLbWQwdDdmRHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΠΜδΒгХчΑГκюЪш():
    value = 744464
    text = __import__('base64').b64decode('eldXeHlTTTlnOHdwZ2ZWWGJGVHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _αΔрγωωцПθоφΒΞЮ():
    value = 165038
    text = __import__('base64').b64decode('eE41NGlsbEJPWGNld0RJR1hxRko=').decode('utf-8')
    total = value + len(text)
    if False and True:
        328
    return total

def _жуОσβοЯΙеаυоиЬЫΘ():
    value = 289978
    text = __import__('base64').b64decode('bTRkS1A0TXJlYjVWWm5SYXBucFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗФμνΗνΗχУΨφцпФμ():
    value = 106062
    if len('') > 0:
        pass
        952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESnoZEgy5JgoaBa60kCHJDEg8Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        805
        pass
    return total

def _ΡΔЙЩЦтΛθ():
    value = 300791
    text = __import__('base64').b64decode('enkwWGhmVWpRYlFZblpuUWgxY0w=').decode('utf-8')
    total = value + len(text)
    if 80 * 9 < 0:
        pass
        _dead_1047 = 58
    return total

def _йЛаЫΒγΖΧЯу():
    if len('') > 0:
        45
        pass
        _dead_2582 = 905
    value = 946632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxfQR0Qw5IonOBag60O6HBw4zEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оПЫδπдηευеэΡ():
    value = 372036
    if False and True:
        _dead_8083 = 960
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ewq9SnYo2rkGaFaC3g6gJyIe6mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФШюйσΒюфςЖ():
    value = 848045
    text = __import__('base64').b64decode('STBxNnhuQ2x2SThQVzRwaUN1SUM=').decode('utf-8')
    total = value + len(text)
    return total

def _φιЙЪΧЬтеТ():
    value = 414314
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAXwb24O5/tbL1mqxwGeEDB8tnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ΩмыыюΓюΩγЪИφηΗСτ():
    value = 193304
    text = __import__('base64').b64decode('YWhySG9lQVNHQVV3UUZ3cldfRXk=').decode('utf-8')
    total = value + len(text)
    return total

def _жрΩиΧДЗΝ():
    value = 856047
    text = __import__('base64').b64decode('T3VTTHdiQzhjX3A0UG5WRFE5RjM=').decode('utf-8')
    total = value + len(text)
    return total

def _РНΖПΩыυЬζΑпσкπ():
    value = 897725
    if False and True:
        pass
        524
        29
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAbAOFIp+qUQOD27x2C/IHJ4wmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιйУοΦΔΨНмшЧр():
    value = 410703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh3SSnkb5KpTNyabmg6jbCIWwng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        791
        pass
    total = value + len(text)
    return total

def _грΩлЙрьсЬьσΣΛЧιν():
    value = 530473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AD32N2Qo2r4WHDf02WSnHQI+zHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖЛρНαШюГΜωθеγЮм():
    if False and True:
        pass
    value = 139881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD/mV10B0oZWAj66w2WBODwu1Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        711
        _dead_4662 = 857
        pass
    total = value + len(text)
    return total

def _ρзБβхνъη():
    if 30 * 75 < 0:
        _dead_6754 = 131
        73
        217
    value = 521257
    if 85 * 69 < 0:
        736
        _dead_9739 = 601
        _dead_5145 = 269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FATlbAg3+5o7Ax6JwEHBZj0Q6nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7089 = 449
        pass
    total = value + len(text)
    return total

def _ЬЖΞΥΞΛвΒθΙкΜА():
    if False and True:
        387
        pass
    value = 689392
    text = __import__('base64').b64decode('enppY2FBZ045X2NfY0hfTWoxT0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ζγθλΞврЩЗιΒτΠ():
    if 37 * 90 < 0:
        pass
        941
        850
    value = 922554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXfrb3xhzJA5Ehz6+UbEAQ458ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        819
        442
    return total

def _ХΟчАΞоυСКЗЬшζΠο():
    value = 577935
    if False and True:
        828
        _dead_3791 = 658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz7dYQMqxq4lNS21xUOyABEpwDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΚΣжьфТПςлλш():
    if False and True:
        604
    value = 590134
    text = __import__('base64').b64decode('cGdVSGFZSWNscFFQUVR4dTlMTXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜВЭыΠΥллβΩΖ():
    value = 686534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FifdXmEMqZc7A1y65lu9GC4Vtkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΒИГШΒΥЯезыаыΞ():
    value = 661772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH3nYGIbz40oPgGgz3K5CwkNw0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 21 < 0:
        pass
        pass
    return total

def _ΜЪБоΨχХь():
    value = 878380
    text = __import__('base64').b64decode('c3VjYUJ2NmtfNERLOGw0NUdfUW8=').decode('utf-8')
    total = value + len(text)
    return total

def _гЛСяхСкΤΜсЕвнРЙ():
    value = 455682
    text = __import__('base64').b64decode('Y3ZBbzhTVDRDQ0Yydkd0a0pGTnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΚεφΨщтБεцф():
    value = 33979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyjgZGsb9PoAbgac6WyBAjMh714='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('dA==').decode('utf-8'))
if len('xxxxx') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 80 * 19 < 0:
    pass