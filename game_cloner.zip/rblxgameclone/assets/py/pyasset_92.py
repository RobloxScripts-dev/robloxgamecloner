#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _αАнθλхξΗΩ():
    value = 585855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCHvV1YS6YYaOFytwXGbDgsn6ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΒфэΥΓцЭКΑαсВЙ():
    value = 227175
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyzsRHI/2a0bOF6hnn3HMnMqsEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΣцςЩαКμμΝκШ():
    value = 282191
    text = __import__('base64').b64decode('SFpjWmNVX3JNc2dmV3JfT08wbG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨЪμАвΟλωοсΖБн():
    value = 283169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQPOal80yaAtDi32kHuULiQY/T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λчΙμψУχΔΥЗь():
    value = 261915
    if len('') > 0:
        pass
        pass
        _dead_3227 = 608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxzxeQQhr5sbBQm0+nqzMSM+8ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1352 = 225
        pass
        pass
    return total

def _ЖцЪчвφпиΨθпзхΞГ():
    if len('') > 0:
        549
        _dead_9893 = 203
    value = 816261
    text = __import__('base64').b64decode('T2t6ZmxHVFJHMUVSOW9VN0ROZ2M=').decode('utf-8')
    total = value + len(text)
    return total

def _вηΘЖαΛξлΑФρσκ():
    if False and True:
        _dead_4379 = 489
        812
        pass
    value = 975605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAPJQV8R1PxUHzu5mHmINikJ7nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧмτΧЛΗхΖЖΣμσμЫЖ():
    value = 372917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgHmOVMG9JgRaB+N/1KgNTcJ70U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4717 = 866
    total = value + len(text)
    return total

def _ΞКйбαΡδΑΖ():
    value = 586368
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PC3TalgxyoUvEQGZ5FKpBwAWxnY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δмдОпВРΣΗ():
    value = 973714
    text = __import__('base64').b64decode('Tm1xZl95VUtTR2JZYXJmX2pQdHI=').decode('utf-8')
    total = value + len(text)
    if 89 * 27 < 0:
        pass
    return total

def _ΔΣчаΒδзΜОλИ():
    value = 39398
    text = __import__('base64').b64decode('ZDVyOGI2bDZVSHp3M2ZJUkpnaUk=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ωмЮзЧтΣБюξи():
    value = 354172
    text = __import__('base64').b64decode('b1ZIeGlRM1dJcWZ6MXJZbnlGd3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗакγЙιУыΚлШΞΞэЮ():
    value = 747668
    if 38 * 67 < 0:
        633
        _dead_1474 = 263
    text = __import__('base64').b64decode('eDZ1NTRDS1l5UEpxU3dHcldBMDA=').decode('utf-8')
    total = value + len(text)
    return total

def _γΟρЕηΛоръ():
    value = 956781
    text = __import__('base64').b64decode('VDJuVGh1TWxRYU1vRVJBXzgzaVA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9864 = 792
    return total

def _ΟНнГАтγΜШТκых():
    value = 925648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQrWRGMx+qwUHRWC8VWXJRcm7EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кИωЕдсюΠ():
    value = 574202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzW0XlkJ+KZXOzy3+XGRbTMM3l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ооΥуωΣхШХ():
    value = 778514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxvcYWst/YkANR614FelGQI191w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘνУГζЛΥпΕ():
    value = 356953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCTsZGIozLsGMlqKxFS5ETAa9Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΡлΗΕПЕЬηΗЕΩυй():
    if len('') > 0:
        831
        pass
        _dead_6206 = 797
    value = 425454
    text = __import__('base64').b64decode('cEpoZDRjNmZBeTByV0l3cWs1amM=').decode('utf-8')
    if len('') > 0:
        pass
        174
    total = value + len(text)
    return total

def _гДяпΛΕπΟгΩΤ():
    value = 214296
    text = __import__('base64').b64decode('ZjJweHQzUWVaQ2xMelNtQ1ZfS2s=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_8481 = 80
        18
    total = value + len(text)
    return total

def _θзЕΧыиξЪΝыЭΤэИеω():
    if len('') > 0:
        764
    value = 389472
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('d2ViX0dTcHg5Nmxwc2V3ZUQycDY=').decode('utf-8')
    total = value + len(text)
    return total

def _яλЬιХθНΧЮψэОοΙ():
    value = 689921
    text = __import__('base64').b64decode('Z2F4MGo3VUQyZlBvNHdTek94Tno=').decode('utf-8')
    total = value + len(text)
    return total

def _НЙеЗчЯψАйΛыЯЧμ():
    if False and True:
        pass
        317
        pass
    value = 387509
    text = __import__('base64').b64decode('V1JyYXJCT3FCUHpqN1BzZDMwQ0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮжΘлγщψЧЬ():
    value = 82144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCDIRgZp7q8MA1yv+l6EOXArsH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩКΦτтδΞЫ():
    value = 230294
    text = __import__('base64').b64decode('R2E5OVo5RXVWSHNSck9wSUZ0Nkc=').decode('utf-8')
    total = value + len(text)
    return total

def _рймΥΒфыψЭМ():
    value = 578695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRDmPUsI9LpWIySn91WiDgwCx1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛьδφРζοеРыβвтΤБ():
    value = 478589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCfvYWYT65ASChWEnX6IBQgtzV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πмлΔзнμνΥВη():
    value = 847793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXewSWtu7b4ZOF6Czl2GMho+8Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟйхΥθдкхтο():
    if 100 * 31 < 0:
        _dead_3791 = 834
    value = 850173
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('SFFyenFOajAyeWdodWI5R2QxQWc=').decode('utf-8')
    total = value + len(text)
    return total

def _азхаККЩψτΝГ():
    value = 952129
    text = __import__('base64').b64decode('TmJwaUF5VTQ5UUoxRU1EaFNYbGw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1124 = 534
    return total

def _УнВκоСυρ():
    value = 617751
    text = __import__('base64').b64decode('Q0tjalYzWXYxZGxKdnc0bWdUQ2w=').decode('utf-8')
    total = value + len(text)
    return total

def _τητΕνΦмεЛ():
    value = 577531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCPeTGQdyoYmHSGy21ijJg9/6Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙязыъιΤνоьМΘ():
    value = 350487
    text = __import__('base64').b64decode('SHdqb2ZIY3F4ZzNPTlV0aHd6Wk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮОДБΞαΤοиςЗнЕыσ():
    value = 932428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ES7MTWkc75ACbg7791yVPw8W5VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖψΝгБαЯъψУφ():
    value = 343455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCzrTH8q3P4LCAqi/3SdLhUZ0j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЩСщПДсИνμП():
    value = 545304
    text = __import__('base64').b64decode('em5GSzB3em9sd0s1S3doeHNwUzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΒыδШШАΤςπΠД():
    if False and True:
        _dead_1665 = 439
        162
        pass
    value = 608939
    text = __import__('base64').b64decode('dUp2N3p6cHRiT29FMnlIdVZ0S1A=').decode('utf-8')
    if False and True:
        92
    total = value + len(text)
    if 82 * 84 < 0:
        pass
        _dead_2772 = 915
    return total

def _юμнΖхюΕΝЖτΡО():
    value = 615445
    text = __import__('base64').b64decode('VUZDbm9nNWNQOGpZQW5XUG1DQWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ПτыМдмзю():
    value = 829342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnftWW4xqpwQN1mV6gazARMst0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΦПаэΦьЫу():
    value = 594632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSvXOUAp7P0tMAL16kyAOQIEvTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цνχΤУυΝзЧΥНΨΧ():
    value = 414315
    text = __import__('base64').b64decode('R3Q4aDJnbTFYdzBjSWUzMXdPdzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЮηЭвпΕα():
    if len('') > 0:
        527
        pass
    value = 257512
    if 29 * 49 < 0:
        228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzjHfnAQ2KYuA120mm+CIg49608='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φЖЫдсЗЗЖмЬЦΙΤ():
    if 46 * 79 < 0:
        _dead_8772 = 485
    value = 916991
    if 61 * 43 < 0:
        951
        507
        511
    text = __import__('base64').b64decode('WXhVMlQ0NGlYREVRSXhmVzViZG0=').decode('utf-8')
    total = value + len(text)
    if 57 * 41 < 0:
        pass
        _dead_9035 = 657
        _dead_2335 = 832
    return total

def _ныνΗуычУхΣК():
    value = 561908
    if False and True:
        _dead_4882 = 739
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3z1SgQg7aYQPB2t5XuhYQwZvWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        460
        _dead_7527 = 389
        56
    total = value + len(text)
    return total

def _ЯγТЪςЧΣΘδЗдηΩпЮы():
    if len('') > 0:
        _dead_5979 = 14
    value = 998564
    if False and True:
        _dead_7679 = 385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3/tPksfxKsgFQm36kK1G3wpwzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        164
        _dead_6621 = 763
    total = value + len(text)
    return total

def _СобυХьБкβПлΩΨЫм():
    value = 857225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjzeTXgG04QGNhaEznO2MiwqxVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 25 < 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_7932 = 534
    return total

def _учςБοΒящ():
    value = 28747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3/sSHg6qv8wIy6O70OfZnQr4mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        803
    total = value + len(text)
    return total

def _ПеΚωоΛнЕ():
    if False and True:
        pass
        _dead_7567 = 715
    value = 180634
    if 96 * 52 < 0:
        612
        135
    text = __import__('base64').b64decode('UjNTdG5LVUd5bGFWMkhCWERTdmQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        964
        pass
        pass
    return total

def _τВοЧБγОτЧкΙЩ():
    if 7 * 66 < 0:
        pass
        _dead_8753 = 653
        241
    value = 867108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITfPbwUL9v4zLwW34H+AP3V/vUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_1461 = 285
    total = value + len(text)
    return total

def _πюуπнΜοРτ():
    value = 380659
    text = __import__('base64').b64decode('dlFfWkpqOHZtZUFSb0FnQzY3V2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚэβξфТΥЮц():
    value = 579507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISDMTAAg/asUMC22w1WeAXV79Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΤΕШΧсμэΖжЙΑБИΣ():
    if False and True:
        453
        pass
    value = 705255
    text = __import__('base64').b64decode('SXBPR2RWeVQxRVhYdGZZQmZXTkc=').decode('utf-8')
    total = value + len(text)
    return total

def _χЦΑЫПюςМыοь():
    value = 628942
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az/FYgc26fkzLSiK+33HJiJ+zDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РψеΛЛгΝт():
    if 46 * 93 < 0:
        249
    value = 51318
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSDeTUIQxK0tEya75FSqZTA5tk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δМихΔзΖрЛεЙЗЙЧΤ():
    if len('') > 0:
        _dead_3336 = 883
        _dead_7293 = 3
    value = 250300
    if len('') > 0:
        594
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3brVgcu04wGBSH13k+1YHYNyUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦжБтБΒЯэш():
    value = 833089
    if 3 * 42 < 0:
        pass
        _dead_9467 = 219
    text = __import__('base64').b64decode('bDRnajBLaFpuc3V3THE2eWNxd2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥкΥΚΞСкГЧБκΩθ():
    if len('') > 0:
        _dead_6404 = 557
        pass
        860
    value = 397461
    text = __import__('base64').b64decode('Z0FQUFdDNXlfaG13QTBUTTZqZng=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑеχДЮОПιπΕкФЮаα():
    value = 935097
    text = __import__('base64').b64decode('ZlJYa0c5T0RBVW9oWVd2SVBTZVo=').decode('utf-8')
    total = value + len(text)
    if 59 * 3 < 0:
        pass
        _dead_2896 = 467
        _dead_1726 = 182
    return total

def _хΩуЬκδХГΒДвШЕ():
    value = 281044
    text = __import__('base64').b64decode('QzhQZ2pTRHJWT2RLNHF2NDlzOWU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _σГχСΗЧΚчшΙ():
    value = 108062
    if len('') > 0:
        pass
        _dead_9279 = 825
        757
    text = __import__('base64').b64decode('VjlKT01UNEpWV1hpbTJaZDlseHc=').decode('utf-8')
    if 83 * 64 < 0:
        pass
    total = value + len(text)
    return total

def _ДТсωΗдГрλЙЕγ():
    value = 223713
    text = __import__('base64').b64decode('b21ic3hZMDFvVmt6bEtFQ2pTTTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΥргΛаряΨΥжХ():
    value = 516363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgHha24LxvoCahqUzEaqZxEg1F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мγйчгЯЪПЪЬфχ():
    value = 80860
    text = __import__('base64').b64decode('cW44dnBZX05mSmxwY2JVYWdCOGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _εйδЫУμχЪ():
    value = 46486
    if len('') > 0:
        994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiDjTVY67asoHyK6ym6/ZCwe1ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΓЯМКавЧφьλ():
    if 22 * 66 < 0:
        pass
        pass
    value = 535834
    if len('') > 0:
        _dead_8466 = 617
        738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRDVWmc1yJ8NHyaz2lSXIC4ltWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΖЮΓβНβсιгПИΕкк():
    if 69 * 86 < 0:
        _dead_9862 = 585
        _dead_6539 = 768
    value = 432873
    if len('') > 0:
        598
        pass
    text = __import__('base64').b64decode('Vk45OWl5YUF5NDh0RVR5N1ZvV20=').decode('utf-8')
    total = value + len(text)
    return total

def _γοΘаЕФСρΡЪць():
    value = 396916
    text = __import__('base64').b64decode('R3JxOUdBY2FCczM2Z3hjZktxaTM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        840
        998
    return total

def _зδБуΓыъХΑΙх():
    value = 999827
    if 63 * 1 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyfjWnlqrJg8blqVnVSZPDA44Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _оΘΥαЦζιцрΤбηΝ():
    value = 48319
    text = __import__('base64').b64decode('SVduS251T0c5UnJuSzRPTnlrUEc=').decode('utf-8')
    if 50 * 87 < 0:
        _dead_7170 = 163
        _dead_5036 = 412
        _dead_1376 = 211
    total = value + len(text)
    return total

def _йЕЬΜЪΛΔыΑζ():
    if 33 * 40 < 0:
        258
    value = 512694
    text = __import__('base64').b64decode('ZGZYZEw2QzZsQ05BOWhlRUFsZ3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _чЩИυсμцΜфЛцιлΥИχ():
    value = 351890
    text = __import__('base64').b64decode('WUtzV2xCZlBDZ2VXOWZyNTk1d2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΝйУеЪθМйΠΤι():
    if 99 * 82 < 0:
        pass
    value = 785224
    text = __import__('base64').b64decode('R1dMd0lacXhUMUJZbWwwc1cxV1I=').decode('utf-8')
    total = value + len(text)
    return total

def _УλсΖХΜΖοрεγб():
    value = 223308
    if 89 * 78 < 0:
        pass
        301
    text = __import__('base64').b64decode('VzdkNVFNdV96WmpoUHA2TGFSQms=').decode('utf-8')
    total = value + len(text)
    if 90 * 95 < 0:
        42
        _dead_7402 = 573
        463
    return total

def _ВΠΖьМСΘюΖзζбυУΖθ():
    if len('') > 0:
        _dead_9475 = 531
        pass
        _dead_6231 = 462
    value = 99401
    text = __import__('base64').b64decode('ZnplaVplZjVJX21rV0FFRV81ZGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑЭцШρΙζΜбУчпχ():
    if False and True:
        94
        pass
    value = 738359
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgDPNlMKx/pXKB2V0lW5OSoIwTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 27 * 50 < 0:
        _dead_9519 = 455
    return total

def _фУγΡΙυυΒйΜэσλ():
    value = 887160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCO3Twcx7/ssKB6bywKHGxB5s3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юязЬмШθХξва():
    value = 432275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSr1ekBpy55bERinzVuHEXIazG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νδмыΙбιςΦιГ():
    value = 639669
    text = __import__('base64').b64decode('TTZkWXhJMTAyMEExS3czMmxoZ0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _НГсΓоДΚυοсΣλ():
    if False and True:
        pass
        826
    value = 269019
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBr8b34jprAZHR6PzXqobC8G/nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЖδΤΔσРΔхλиНЕщ():
    value = 345423
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzrdQkMT8/o6Ygep4XW5Ii0qw20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЫΖψжΜСЙΖδ():
    if False and True:
        _dead_1830 = 883
    value = 671151
    if len('') > 0:
        662
    text = __import__('base64').b64decode('d0JGYXdNWnN5MzVfVGo5dVB0SGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣсщТЧЭСΝоъ():
    value = 355846
    if 65 * 97 < 0:
        pass
        912
        824
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng7eWX88yKwUGAiS/AXIDH0Cylw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФλАωπыλЦзΛаΠΞк():
    value = 296168
    if 69 * 75 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB7zOnwN1LooKSS2z16iAxN/zTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 44 < 0:
        171
        60
        _dead_1749 = 353
    total = value + len(text)
    return total

def _РψЗψΝΓЗТΗН():
    value = 864578
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH/wd1YfprwrA1aLmHG1GXUow3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГзТыхХПшйЭΖΥ():
    value = 725729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXz0bUENz5snDDb1znGTYxA200c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БНηПаΡЪμρΕЭИЛБР():
    value = 85810
    if 13 * 36 < 0:
        _dead_4019 = 982
        pass
        158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3jWZn0fy5pWbiar4WnCPw0e7lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        106
        433
    total = value + len(text)
    return total

def _ачΔΑΞсйνмΧдψЪ():
    value = 900806
    if 55 * 28 < 0:
        396
        _dead_9283 = 425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXfCTW4/p6YRHRr6zg+JGwAh7Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 63 < 0:
        pass
    total = value + len(text)
    return total

def _ПΠбхηθаσУ():
    value = 280723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC7td1A7zK8Jayew0kS1DQ0QyHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νчΑΨхХнзЕ():
    value = 43726
    text = __import__('base64').b64decode('ZmU0Y2tsMUtEa1VMc1YzMkFVbFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦξПУЗοЩгςНφ():
    if len('') > 0:
        _dead_9515 = 530
    value = 393861
    text = __import__('base64').b64decode('UjhtMW5yX2hfbXkxdnNQVktQWHk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        806
    return total

def _ДЩЙΘтЬΖΕм():
    if False and True:
        _dead_2723 = 887
        _dead_7628 = 497
        _dead_9709 = 558
    value = 956199
    text = __import__('base64').b64decode('dzJVbWNXdWxQQVd0OHFvSklVRUc=').decode('utf-8')
    total = value + len(text)
    return total

def _βλΚΦΘΒωΒδя():
    value = 590922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACH2WVse7v0LDS21zWO6IwsX5lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘσИλыщγяυкΓζЮК():
    if False and True:
        312
        pass
        _dead_6690 = 628
    value = 73619
    text = __import__('base64').b64decode('YnpLdnVQSHBTc2xHRVc2ZDFPU0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟзЯхаκАгуΥ():
    if 17 * 20 < 0:
        _dead_4624 = 597
        _dead_4644 = 832
        pass
    value = 52254
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETnvQn0PrZEbCx2in3SmAw473Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        830
    total = value + len(text)
    if 65 * 95 < 0:
        pass
        _dead_1878 = 463
    return total

def _ΨгΗЗоЦаεиР():
    value = 548521
    if len('') > 0:
        _dead_6622 = 484
    text = __import__('base64').b64decode('R3BXOHRNN1hiOUZrcHBCaURXMnM=').decode('utf-8')
    if 8 * 59 < 0:
        674
        _dead_7938 = 46
    total = value + len(text)
    return total

def _ЯБΟшγЖΤлΔτκ():
    value = 587818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwK2e2co2fwbFju0+UWnHzEHtko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΒвАБЛЮПΖΙя():
    value = 542695
    text = __import__('base64').b64decode('VWJodmFXal9wWHRaT0tnQU1UWkg=').decode('utf-8')
    total = value + len(text)
    return total

def _БΚρжХаУфЮΓζ():
    value = 331726
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih7UOQc236EKMl+RxQ6hGhAk7jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _γεЪΚлΔуечСΝЛн():
    if len('') > 0:
        pass
        pass
    value = 486841
    if len('') > 0:
        pass
        pass
        162
    text = __import__('base64').b64decode('ZDEyeTM3dHA5Z0d3SklaX0RId0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _гΤуМЛгΑЭХ():
    value = 638176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSHGOUIdx/oCMFir6XOJAwYnw3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        522
        pass
    total = value + len(text)
    return total

def _ωνдνжрКиζΠгοдΞζл():
    value = 88940
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az6weG4KqqwpER3w8mS2ITUg1kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЙΝνβфΖрХεΞρКЭ():
    value = 766608
    text = __import__('base64').b64decode('QWRVa0dRNWZPVkM3UVNxcTF1Tnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ηζВοΩДЮЯшκрИΧу():
    value = 583004
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAH8f0IoyIotI12r0VizG3AC9H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚяγАΣοΣЗυαф():
    value = 333403
    text = __import__('base64').b64decode('eXdSMWlJdkxaODg5QkZTd2hqa0k=').decode('utf-8')
    if False and True:
        277
        pass
        900
    total = value + len(text)
    if len('') > 0:
        885
        893
        _dead_1803 = 198
    return total

def _ЙСЛΝКвςщОЩτъЗΨ():
    value = 907616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQWyO0sOzr41aRfz7F23MiIH110='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αЪЯссΡβΩιξфЪ():
    value = 977866
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ew3jeEI3y6QTKzzzw1GaGz8Q7Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙηкΩЦΔСχμΖАθΘЮЗ():
    value = 781071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NS7me2cNro5QHViP4XimAyB6yzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧРπщЭΦНΦхГ():
    value = 618115
    if False and True:
        62
    text = __import__('base64').b64decode('TWdvbFhrV1VWNEdHa3hwNjdBR0o=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        632
    return total

def _ιЕьΟотпМνХ():
    value = 402940
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR6wSXwQp/gGFCeX2UG6JRAM8jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пгΒнРТЛщфμйеΛ():
    value = 330168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwzSPFIL2P41GwqJxk+fZgQItHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЭЬжаΦΧщюД():
    if 46 * 38 < 0:
        pass
    value = 687370
    text = __import__('base64').b64decode('WVZrV2tMRWthS0VVNGpUc2hZdTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬρпААνдЛ():
    value = 86564
    text = __import__('base64').b64decode('bWp2WndRZWhQeWNPNnJ6QVJ3bVo=').decode('utf-8')
    total = value + len(text)
    return total

def _аЕЩαΨηШΤЪЮΦюΟьΝψ():
    value = 888791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dnq2TVo00voxKjrx8XGmIwoKskM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟиΔΛБΒΩοэτμЛГΤ():
    value = 205682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwHiYwg/6oFWHSqK/32cNRQd9mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 78 * 92 < 0:
        _dead_1510 = 798
    total = value + len(text)
    return total

def _μгуρЖψЪЬвΥψΠΑЯη():
    value = 916368
    text = __import__('base64').b64decode('dnlPdDd5azJjMUVERWQwX2ZZczk=').decode('utf-8')
    total = value + len(text)
    return total

def _αОеρПхζжγρеΜηЧ():
    value = 455742
    text = __import__('base64').b64decode('VURRY0V3aWl6N1MyMWo3TlVkSU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΚΘεТΙξΝэЯγθΦε():
    value = 517567
    if 26 * 23 < 0:
        _dead_7150 = 8
    text = __import__('base64').b64decode('UG1wSUZNQnlyb2lDdFhUR0RmRTU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _БПЦζщμДЫЖω():
    value = 678442
    text = __import__('base64').b64decode('WU43MVI1aFRyZnNiOTdMNEhhZjk=').decode('utf-8')
    if 93 * 52 < 0:
        pass
        714
    total = value + len(text)
    return total

def _ОΥОγΨялтΩσХТяя():
    value = 379189
    text = __import__('base64').b64decode('bmVCaGpEOTFEdWlQaE9TQ0tlUmw=').decode('utf-8')
    total = value + len(text)
    return total

def _λХгфХяπзγЖΠ():
    value = 6960
    text = __import__('base64').b64decode('akk0NWJRTjhVX0hpWFpSbTNMZXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ТчоπРсΖι():
    value = 163118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwnFX3du6aElAj2ly3uiBC0ezmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗПНмτЭБδΕλεкΥХχЪ():
    value = 208002
    if 30 * 3 < 0:
        pass
        _dead_9654 = 843
        _dead_3711 = 888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAHcb1dsy44BOCCO/H64Ai4C3n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΑЩБуζΓйΖ():
    value = 707624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag3jPVwYyYsqH1qm4V+JMxIo3Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑВΔяКΤьΥΟνΖ():
    if False and True:
        789
    value = 130338
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCDRUV4N5oJbNQOP90zDOHwr5Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 82 * 17 < 0:
        _dead_5732 = 261
        pass
    total = value + len(text)
    return total

def _ЧВиτΙащрΘβιШМ():
    value = 630120
    text = __import__('base64').b64decode('YzFrcWpWUU54VjRwYVJldVFUQzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩБΖЪσКΞΩах():
    value = 843470
    text = __import__('base64').b64decode('ZmpOVzE5QUV2WUw4U2p0TUxQeDc=').decode('utf-8')
    total = value + len(text)
    if 40 * 35 < 0:
        pass
        901
        pass
    return total

def _КчНзмινΥЭΑчфυ():
    if 53 * 92 < 0:
        pass
        _dead_4872 = 584
    value = 251287
    if 14 * 36 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FznjQFcWwZo7agOPzH6aGTwAwUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КλορфэЫИКβИξα():
    value = 832566
    text = __import__('base64').b64decode('clVuNG0xVTl2bkliaHBlQ3hQM1c=').decode('utf-8')
    if 92 * 48 < 0:
        629
        pass
        _dead_7593 = 213
    total = value + len(text)
    return total

def _чгйΩΤпΚΙХРτяΔ():
    if len('') > 0:
        _dead_2055 = 112
    value = 970356
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAnhdHgO+68bFQyZ41CYATYex0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НмфλπрнПМкΑЛψЗю():
    if len('') > 0:
        361
    value = 587948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCDnPX438Kk2OSyI0XiGYh926H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 45 * 12 < 0:
        _dead_3171 = 109
    return total

def _υпГВΜЙΠсΧΤΖГмфо():
    if len('') > 0:
        107
        _dead_5543 = 937
    value = 662216
    if 43 * 75 < 0:
        878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCi8W1Mo9/gNLx+r+APAAAMcxUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9988 = 143
        689
    total = value + len(text)
    return total

def _ФμΞхрΨАыψξΥσΓρмχ():
    value = 113700
    text = __import__('base64').b64decode('VmM0N2NEb09SWjlEcTZMUGRvV3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΙЯμονвξХВαЧκ():
    value = 270807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiPUYV5r8fEEPB6V5UGfHyl57kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зγхτφτАЭЧюΡФН():
    value = 734513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyvKWwMhz7BXCQb3mQCqABIKylo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АκФймωТЫзΘ():
    value = 213645
    text = __import__('base64').b64decode('ejJvSTlKbXJ1RWtBTktfeGJveU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЛΩΓЙшаЭ():
    value = 15746
    if False and True:
        pass
        557
        464
    text = __import__('base64').b64decode('Wjdhb0E0Y0xMNm9FSnA4aGZnTG8=').decode('utf-8')
    total = value + len(text)
    if 21 * 86 < 0:
        pass
        323
        pass
    return total

def _μξΟαрωΞЧЫЦοβΚΡжγ():
    value = 678615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESDOTGhv5ok6PSWJ5kHFIwEO1Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΥзмνωжФЩУ():
    value = 709429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwLCfVI1yZ4mAAeS4AHJBCsi3Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 66 * 88 < 0:
        491
        _dead_1073 = 628
        _dead_4241 = 364
    return total

def _ГβаδЧМЪεэзιλ():
    value = 525233
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDnVRUcsx5lXICH6+X/BDjV2tG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъфгуъουΠ():
    value = 735409
    text = __import__('base64').b64decode('cXM0ajdhRTFncThteGtmMzRwWDY=').decode('utf-8')
    total = value + len(text)
    return total

def _иκНыΠШΤАфΛλΤ():
    value = 803035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiLUWUU91I0kbVqrzFqCIHIuvGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πАιииσйиθуυτΔоГя():
    if len('') > 0:
        811
        _dead_4457 = 201
        pass
    value = 754771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRzAfwA39r0KFjeL+US5OzV58kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 26 * 88 < 0:
        736
        691
        pass
    total = value + len(text)
    return total

def _бЕΑгτлΣКЦΛπψрщ():
    value = 279564
    if 82 * 67 < 0:
        _dead_4505 = 965
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgDDencQ/7lSLCmgzgCbMCkp8jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        45
        _dead_8529 = 60
    total = value + len(text)
    return total

def _иДНТънхЫНΚй():
    value = 614355
    text = __import__('base64').b64decode('cGZUdUdzYWpiNXBhOFpjdWY2Nmc=').decode('utf-8')
    total = value + len(text)
    return total

def _νΟтζДСИΟπφΞΣК():
    value = 239299
    text = __import__('base64').b64decode('dzI0RkJVN3lmcjB0WnFmR0hXNmQ=').decode('utf-8')
    total = value + len(text)
    if 30 * 87 < 0:
        726
        _dead_9608 = 615
    return total

def _ЙИΩРАΠыяΛХ():
    value = 897771
    if 67 * 35 < 0:
        178
        pass
    text = __import__('base64').b64decode('cDBweWQ0WHNBeDF2NlVINlI3cEQ=').decode('utf-8')
    if 58 * 80 < 0:
        _dead_9260 = 379
        pass
        pass
    total = value + len(text)
    return total

def _ШθмЧΤНТδвΦд():
    value = 257058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxzbOwgR9pg2EQT26VmEHzcF3Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яНфЗλβξяΡδуμЫКЪу():
    value = 104007
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('SzNkQmJYRnVjY2RjU2pQbHdMb0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ТιΙБΙщεΗΚΝ():
    value = 395220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzX1Y3xs+qM0Nj73y3XDDBQm0Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΥωвξрξлΞЫЭ():
    value = 438803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KADXZAAf3443Pxyrw3GxGTx2yno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЪπьЕΑлщβλΑШОъоι():
    value = 497005
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICPeRmNp5IUVLlauwU/DLgc67kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4598 = 266
        _dead_8871 = 996
    total = value + len(text)
    return total

def _ЮрБωЮФяЮРοжО():
    value = 707129
    if len('') > 0:
        707
        _dead_4865 = 198
        _dead_3528 = 2
    text = __import__('base64').b64decode('bENEU2RDaTBJMkpSeko0QUQ2NjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ФышЭцВπгсΡΒΙβΤξ():
    if False and True:
        pass
        pass
    value = 108617
    if 77 * 42 < 0:
        92
        291
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F33samc4zfEGPSz33lWGEw0YyWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςτωзΦΒВЬζ():
    value = 521498
    if len('') > 0:
        _dead_8641 = 915
    text = __import__('base64').b64decode('Q3lpWTBnU0ZiRmw1VF9HWWF1bWs=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _НΗтърщъΓΧιтχНΩзΘ():
    if len('') > 0:
        pass
        607
    value = 129509
    text = __import__('base64').b64decode('U084NlBzd2p4THdsMWNIa0J1RGo=').decode('utf-8')
    if 21 * 44 < 0:
        267
        _dead_6740 = 972
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΒΜЪЙΒОφρ():
    if 58 * 43 < 0:
        pass
    value = 636701
    if 34 * 11 < 0:
        pass
        _dead_3227 = 74
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzfDPV0syK06PjmI0VieIikG/kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜуσΥзΚыГρ():
    value = 598643
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhrpPUEpy5caPA2pmFXHYgEM/UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρъНβЛκφπΝСυщΔЛвЖ():
    value = 811757
    text = __import__('base64').b64decode('RXdlNDVQU1RocWhvMEdaTWZueUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΘаеХтГδΤΟεЕ():
    value = 94865
    if len('') > 0:
        822
    text = __import__('base64').b64decode('WWZnS0pjaHZ2WXJPa3QxcFhpWGc=').decode('utf-8')
    total = value + len(text)
    return total

def _НцлДэΚΔΙеσΘВЮ():
    value = 304417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ey7CWmk45Pw0CAmW2W6vZRwrw0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓθΓΩΛохощМΦнтξΡΝ():
    value = 740211
    if len('') > 0:
        468
        100
        _dead_4936 = 456
    text = __import__('base64').b64decode('VVFzakwzc25Nb0E2ZFRqcHNxYUE=').decode('utf-8')
    total = value + len(text)
    return total

def _θξЗΩюΒΖЫΖρεΚβ():
    if len('') > 0:
        pass
        pass
        _dead_7916 = 91
    value = 377367
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCL8eWkL+KFRH1iG3WO5Ng0o9FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        822
    total = value + len(text)
    return total

def _θΕДΖЪЖЧтΧГθζ():
    value = 5122
    if 45 * 55 < 0:
        pass
    text = __import__('base64').b64decode('TVk0QlZ2UjEyem9RZ3drb200eUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝНЙНχЧщΧШФΧа():
    value = 925422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzreaEAOpq8vDCCIkXOaMnwB0kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        790
        pass
    return total

def _исОξйХеΩρА():
    value = 409503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kzf+al0304YuIgCg+nelHy0X/lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩлБШРΨρг():
    value = 247950
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATzub2MhzaciFRic0gbHYDE50Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ытжΛγлДκΜ():
    if 56 * 60 < 0:
        _dead_6464 = 85
        700
        759
    value = 28327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRm8SFIDraoHIAi64ka/DXEk3UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φκСβЦΞβщокЦКЛθ():
    if False and True:
        _dead_8562 = 526
        pass
        _dead_8726 = 596
    value = 238961
    text = __import__('base64').b64decode('bHdhSGZZOVViUTdJdXZudFVrcHo=').decode('utf-8')
    if 20 * 60 < 0:
        _dead_4311 = 1000
        _dead_7250 = 445
        pass
    total = value + len(text)
    return total

def _ΛχОрЦθβЪщо():
    if False and True:
        pass
        pass
        _dead_5494 = 830
    value = 309555
    text = __import__('base64').b64decode('cUJPdjlRWmxjUnE5ZVJHR2tJWnE=').decode('utf-8')
    if 18 * 87 < 0:
        996
    total = value + len(text)
    return total

def _ΗЖФЭЩξтрУФΔ():
    value = 796153
    text = __import__('base64').b64decode('Zm1jUWNPeGJHcWJwUVR1cXVRcEM=').decode('utf-8')
    if len('') > 0:
        _dead_3996 = 692
    total = value + len(text)
    return total

def _аΔγВбюζΤ():
    value = 949156
    text = __import__('base64').b64decode('WDF6UmtCSTlZRW52TVhGR29PY0k=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7776 = 23
    return total

def _ΝβΧΖъйΡρр():
    value = 153305
    if False and True:
        pass
        342
    text = __import__('base64').b64decode('QU9VOF91bk8zdFhfWEJ3R0V3VnI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        583
        pass
        pass
    return total

def _СоъЦСΜЯβЯЫхр():
    value = 46931
    text = __import__('base64').b64decode('RGRVYnJzVERjcXVSazk5bGxERm8=').decode('utf-8')
    total = value + len(text)
    return total

def _жΡыοΜоχиΔыдΣΛοш():
    if len('') > 0:
        pass
    value = 216786
    if 28 * 70 < 0:
        _dead_6216 = 714
    text = __import__('base64').b64decode('RlZZQllLd2hsdVgxSXRPWU1aeTQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        677
        448
        _dead_1351 = 126
    return total

def _ΞδъЫпφΟΛ():
    value = 911198
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N37cegcu6PklbC6k0EOZYSkh22w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪТэШφхΟσЯΔε():
    value = 734023
    if False and True:
        _dead_9783 = 981
        _dead_7834 = 207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DADvaQUc+qM7BSi52FygYxd9s1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υμЬκΜζГΜψГΛц():
    value = 457481
    text = __import__('base64').b64decode('UjZFellGSWpGRHl1ZWd3d1JlOWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ПζкиδэТΧ():
    value = 73853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiLJVngGqvkuLgK2xH6fLCgt8Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХεЙΞμΛτΖσЩΟρ():
    if False and True:
        639
    value = 946205
    text = __import__('base64').b64decode('eGZkeXBZV3FfV2pqSVp0VzVZMkw=').decode('utf-8')
    total = value + len(text)
    return total

def _жςΤχβυюΜьψ():
    value = 684071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR38YnNv36sXNF2H6lmGEiB9/Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΧРΖΚхχм():
    if len('') > 0:
        pass
    value = 451110
    text = __import__('base64').b64decode('RHdlY1pSb1lQRmNZc3VzOVFRaFA=').decode('utf-8')
    total = value + len(text)
    return total

def _УвχзЕΖβεьН():
    value = 295148
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KybBXkYUz/oVNxeZ22C7MDAYsW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩтζЬΕηЫоА():
    value = 98283
    if 46 * 70 < 0:
        pass
        _dead_5105 = 26
    text = __import__('base64').b64decode('TUw5ZVZ1U2dTMjlUa3hiR1h0amM=').decode('utf-8')
    if len('') > 0:
        407
    total = value + len(text)
    return total

def _ΠЫиΓνοκЪω():
    value = 832957
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FH69f18w/7oCNzag2F3HFhoEwWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _яЦΡΜΧγΔΜΥΥДлκлРЯ():
    value = 935155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mib0WUAU/7JRIwuk62KgIS4/zmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ралΠОΙяЭн():
    if 65 * 27 < 0:
        pass
        77
    value = 887680
    text = __import__('base64').b64decode('U1JxMEFTUThidHYyc2RVN1MzZ0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΕΜФΓοзИΜ():
    if False and True:
        212
    value = 932179
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eib+ZFYtqqkhEFzxxGyAAHx3zGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НЪвпЖфΩУμ():
    value = 202700
    text = __import__('base64').b64decode('UmxUYUZCcnozMkltaGtTdDB6N00=').decode('utf-8')
    total = value + len(text)
    return total

def _τЖзЬПЖΦВΠГΟН():
    value = 42459
    text = __import__('base64').b64decode('c0N4NUtoSl94Ynk4X2hoQ3ZXTm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ъъΞνβлΙυσΥщЖΥφЬ():
    if 64 * 61 < 0:
        _dead_8061 = 492
        _dead_1460 = 246
        pass
    value = 126131
    text = __import__('base64').b64decode('WHJBYmhnRnUyRmpreFk5SXZpUnQ=').decode('utf-8')
    total = value + len(text)
    if 20 * 1 < 0:
        _dead_5416 = 272
    return total

def _йΓоψГΧвΕΟХυиζ():
    value = 536437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRjdO0cozpIKFQKumwCXLXR34Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 4 * 64 < 0:
        _dead_2762 = 575
        pass
    total = value + len(text)
    return total

def _ΚДΤεαвюФΔβ():
    value = 847240
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgXWamA485chNymPmnfGInQh8mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕУзЧεИΘеΟΩщчΜ():
    value = 838531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBX9WQID8b0ZNzuW0m6DNh0d8UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мвТЧЖεжЛХтвЬпц():
    value = 780110
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhnxfkUz8p0hIhj2nVrBZQEt0T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('IA==').decode('utf-8'))
if 97 * 82 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 59 * 70 < 0:
    _dead_8433 = 94
    479