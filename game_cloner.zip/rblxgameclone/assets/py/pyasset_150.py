#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΞζςъЛΖΔЬЫТвΗЬБЯΔ():
    value = 450351
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQvSbVUO9fBUBSqW7mSePBM7zlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κьхЧьΦΗςВЦЬИРνς():
    value = 781607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgrUYHgx344AAxyE21+IZgoaxlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        28
        pass
    return total

def _дгΛъΩщБЙπτОц():
    value = 833927
    text = __import__('base64').b64decode('cWxkZ0VkclBYd3JuS3k0Q3duU0k=').decode('utf-8')
    total = value + len(text)
    return total

def _гξЛμμбншΝλΑωЮ():
    value = 630867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDvlW3A97o4VMCCs43iJPikV510='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мъуΑСπдΠροьИэμλ():
    if 46 * 17 < 0:
        _dead_7676 = 818
        _dead_9135 = 816
    value = 233941
    if False and True:
        _dead_3683 = 359
        _dead_2565 = 639
        446
    text = __import__('base64').b64decode('T2lQcktIQTlWZG40SktnY09XSFc=').decode('utf-8')
    total = value + len(text)
    return total

def _нДюλΣΚδΗТ():
    value = 440390
    text = __import__('base64').b64decode('cFBZQmFMUFpTM1QwbHRISjRJWG0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        481
        pass
    return total

def _ΩЮЬΚωЗКςΛзч():
    value = 338047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAveTwMq9q8ZGFyp3V+RGS4F/Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        738
        444
    total = value + len(text)
    return total

def _χцΑψРЧΒГβК():
    value = 154903
    text = __import__('base64').b64decode('RDByZzlSR3dBX085c3hnT3dRblM=').decode('utf-8')
    total = value + len(text)
    return total

def _ИДдζρδЩАрЙπ():
    value = 619701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDjIfUUU2a87PQWLxgCfGTQC4Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τρηЧΔэжΒхΟо():
    value = 120898
    if False and True:
        _dead_2089 = 850
        pass
        pass
    text = __import__('base64').b64decode('R3ZxTHNYcVY2b0xXTnRsMDUxdEs=').decode('utf-8')
    total = value + len(text)
    if 1 * 22 < 0:
        985
        _dead_4926 = 273
    return total

def _нЩйЩЫλθбо():
    if False and True:
        pass
        pass
    value = 467907
    text = __import__('base64').b64decode('T1hxNzBfTzVXVHQxNkhONWlWRkQ=').decode('utf-8')
    if 74 * 79 < 0:
        _dead_9193 = 845
    total = value + len(text)
    return total

def _ΣΑвъЭΠьΣиуΤ():
    value = 284107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSnBXlQd7ZI2NQLz2US3MxJ/3Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 86 * 3 < 0:
        803
        pass
        959
    return total

def _ДдρπЫΤфбнТλШт():
    value = 442615
    if 67 * 89 < 0:
        _dead_3959 = 422
        803
        717
    text = __import__('base64').b64decode('UmJWaElXelFjNk85eVl2cW5IUTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦНыφωччееΔ():
    value = 560693
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MznuYkY28qM1LwSgnUCbA3Y/tEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЭΥКρКΚΟэΠσЕ():
    if False and True:
        _dead_3406 = 566
    value = 782289
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('YTFKRzZGOVM3TmJ3eFM0MjdRTHM=').decode('utf-8')
    if False and True:
        pass
        _dead_9217 = 258
    total = value + len(text)
    if False and True:
        pass
    return total

def _φХυшпПεΧ():
    if 39 * 11 < 0:
        808
        _dead_6277 = 647
        pass
    value = 530691
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhezZQM72qYoPyKQ3XnJJi4i9k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ваκΙγιАЯщИψчμЩЗъ():
    value = 584794
    text = __import__('base64').b64decode('YkNsME1JSjlTOEdDbFRCbEtlSjg=').decode('utf-8')
    total = value + len(text)
    return total

def _бчαыхαмΗеρΖТХ():
    value = 649804
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQj1X2IDybAqFgC2/GSIYQQr8mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕψЯЧыИвΣΖдхσЮОΤ():
    value = 360945
    text = __import__('base64').b64decode('SVpsZG9XcmJDQU14SmZLeV9VVl8=').decode('utf-8')
    total = value + len(text)
    return total

def _зПςЮонΘΜ():
    if len('') > 0:
        199
    value = 460047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhC2N3Uz87gnIDec22aKJHYLtmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _НлΑΜкΡанσЗЮтΒζ():
    value = 810565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lxe0OFINybAXKCf3m0eWAyM68mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЫΩгδжΕςЦнЕщЮХгЪ():
    value = 624718
    if len('') > 0:
        849
    text = __import__('base64').b64decode('bG1VNGZGY1hnNnJlUGhfc2RwYVY=').decode('utf-8')
    total = value + len(text)
    return total

def _οпωюΑΡКяТδΘΚυτу():
    value = 119952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjrVQ1UYqIoTK1ugzVjIMCcF5UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βБФΔЧеРЙаоб():
    value = 392454
    text = __import__('base64').b64decode('emdHT3d0bHd0OFEzSUZ2Qm5yR2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΔбдβхΕλΘςιΠΖΡИς():
    value = 701699
    text = __import__('base64').b64decode('V0doVGE3UlVKclh0ckVhRzBVdDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ыЕдуАдувΜυЧмЧΣ():
    value = 505962
    if len('') > 0:
        pass
        _dead_2809 = 767
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQPoQlYo07kUPAL35UahGz8Jw2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МШтШЙνπЯΟ():
    if 90 * 87 < 0:
        219
        923
        9
    value = 405303
    if False and True:
        pass
        618
        _dead_8146 = 693
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwzIVF0KqoJVY1upkHGSYw847D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6075 = 556
        41
    total = value + len(text)
    return total

def _ΝжрΙρтχΙθГЕΞсνΜЪ():
    value = 711656
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyTnfQQQ17IXHyu1z06RbSojslQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХЦςЧωКτз():
    value = 98754
    if False and True:
        _dead_6757 = 204
    text = __import__('base64').b64decode('SzQyWUZWbG5RNGlfVHkzVVdNTGw=').decode('utf-8')
    total = value + len(text)
    return total

def _κЯЭяЙεΡщвЯψ():
    value = 33501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSvdRWIL+aIzEF2A8nixBwgX0XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НЪωШεгνΥЮΖΣ():
    if 77 * 84 < 0:
        735
        960
        pass
    value = 168867
    if 59 * 77 < 0:
        355
    text = __import__('base64').b64decode('T1d4UVNqZDRjVDFkMHhqMW5ZQzU=').decode('utf-8')
    total = value + len(text)
    if 97 * 81 < 0:
        581
    return total

def _ЯυζтвпΚряАΝ():
    if False and True:
        35
    value = 443253
    text = __import__('base64').b64decode('bkRfOWQzZjBaNWJpaGlHNlNBdkc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6434 = 87
        513
        _dead_2592 = 809
    return total

def _μФχδЗИοюдЫщЪΛхЛш():
    value = 461703
    if False and True:
        474
    text = __import__('base64').b64decode('anJLODV5SXQ4bVFnWXBGNHdtMTY=').decode('utf-8')
    total = value + len(text)
    return total

def _сΓθЩмХξвтЦυΠЗηΚι():
    value = 366066
    text = __import__('base64').b64decode('RmVpRHZUTW42RFNDOTJPYWg2eHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΙЖЙиюΡх():
    value = 465827
    text = __import__('base64').b64decode('Y1hGa2hVWEV1eEZuQTVlV0RMbUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЬзКμЩηΒηчζРμяΞЪ():
    if len('') > 0:
        _dead_6885 = 267
        557
        pass
    value = 94040
    text = __import__('base64').b64decode('SUk0Um42eF9LcVlsS1R2eDBXMDc=').decode('utf-8')
    if len('') > 0:
        _dead_5319 = 696
    total = value + len(text)
    if len('') > 0:
        _dead_5207 = 215
    return total

def _δДбшЗЪмцФЗ():
    value = 394276
    if 13 * 26 < 0:
        pass
        pass
        _dead_9119 = 652
    text = __import__('base64').b64decode('b3E1TmEwVUpEWndidV9FNldzckE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_1198 = 537
    return total

def _жΡυφμЖЬфτаΒΘЭвЯΡ():
    if 11 * 41 < 0:
        pass
        681
    value = 849876
    text = __import__('base64').b64decode('RUZzUzIxNE5NWE95aUN2T09xZXM=').decode('utf-8')
    total = value + len(text)
    return total

def _σФοχрΔкκΩΕАчχ():
    if False and True:
        _dead_1141 = 830
    value = 872970
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kna2QAMQ+IwFKgvx4limBzEQ6n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЗИΜПΣςχЪпαщМδ():
    value = 794604
    if 53 * 18 < 0:
        pass
        pass
    text = __import__('base64').b64decode('dng3Z1pWb0QzVUM5UmZfM2FvOTc=').decode('utf-8')
    total = value + len(text)
    return total

def _юуλЬЯΖед():
    value = 822865
    if 92 * 75 < 0:
        296
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCeyQ383r7EVKgyi61q9bBEl4Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωπкληψпζнΜη():
    value = 309270
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQy2TQhq15EBLTWFxkPGIxoO1D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 1 * 78 < 0:
        _dead_7190 = 784
        _dead_5652 = 293
        pass
    total = value + len(text)
    if 30 * 56 < 0:
        _dead_7996 = 834
        _dead_1361 = 163
        pass
    return total

def _εЧыоβяхΜ():
    if False and True:
        _dead_5371 = 979
        pass
    value = 406918
    text = __import__('base64').b64decode('SmtGeXFtU1lXNDFsTGRCWDR2TGs=').decode('utf-8')
    total = value + len(text)
    return total

def _чЫоξρΧπлα():
    value = 530575
    if 84 * 12 < 0:
        _dead_5990 = 997
    text = __import__('base64').b64decode('dzFSZ2VjMDFXT0ZJQVpkeWlZRkw=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ПнчАпеЙЩУμэсубω():
    value = 680277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBreT1IJ+YJTAz/0mFe6J3Y71Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΡθэЬЗуидС():
    value = 771618
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjbKa0U28rgoAAuB3VjJNwB8y14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΔфσΘФбΣβЩτнялΕΑ():
    value = 552568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Knf+RGAzrb9aOAmh+FKbMCEi6Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΗтшцΘθО():
    value = 18529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwziXnBq56wHNBuF4FWUYgM+7zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бътΔΩЦηчλпς():
    value = 697084
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgXDQF4X8axSIgSn42LDEgE621c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘИψЯΑшΦдкΙΟх():
    value = 875335
    if 79 * 33 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kxe2b1IKqvwsYhWwmQKBGRIYy2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7172 = 991
        54
        516
    total = value + len(text)
    return total

def _ςθФΙЭДΤОΟΩΩПгΨ():
    value = 891585
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnnVfFADyKQ5bheP5li4HCx65WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        625
    return total

def _ИνУρьςαЕц():
    value = 984416
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwqwRkM/1ocwFTau6myKFR988m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓтΙЭсЮИΡЕпω():
    value = 465184
    text = __import__('base64').b64decode('bGJxOWN3RG5XXzA3RHFjQkNvdWU=').decode('utf-8')
    total = value + len(text)
    return total

def _κΣΣВтκШСζДΕСΟ():
    value = 438661
    text = __import__('base64').b64decode('RmVqc1RLblJjR1RWa0JnM2toTEw=').decode('utf-8')
    total = value + len(text)
    return total

def _шЯщъЕΛΡжΠαιΞΟзΣ():
    value = 499340
    if False and True:
        775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCjcXlBrq/oMMQaEyQK4AHF43H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 11 * 61 < 0:
        _dead_4208 = 772
        pass
    return total

def _ρВшΗεиψБхЮа():
    if 57 * 27 < 0:
        5
    value = 65905
    if 92 * 2 < 0:
        pass
        819
    text = __import__('base64').b64decode('TDh0VDdGU044c2VJWWk3cnNvQlU=').decode('utf-8')
    total = value + len(text)
    return total

def _фΙЯЬρΞВμлΝη():
    value = 484184
    text = __import__('base64').b64decode('RTRPdlhvUnBuVFVvRG5fT1NCN0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _певοιЗбъаιтжОеΙξ():
    value = 409305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhbUQXZhzrsHCjmK4nTDISAJ52k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жβφзΥЛвЛсДξкоЧΟΧ():
    value = 524234
    text = __import__('base64').b64decode('WDc3djlWOGo3MXhfWGwwY2xSRjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞОфФδБχζψЕШыρэςΑ():
    value = 909122
    text = __import__('base64').b64decode('eXFNWkQ4YjZiRzNPMldqYmxuVHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗπЖλХдъΙгшИ():
    value = 707197
    text = __import__('base64').b64decode('ZHJ0aWhMaFRkV2Z2dTZndVRCZWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ДεнηδЫΙΝЩΤΗωΚ():
    value = 98657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB/XUURu+69bPC2p50/DM3x/w2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣΝΨΣЙмΑμ():
    if len('') > 0:
        pass
        pass
    value = 654639
    if 20 * 55 < 0:
        pass
        _dead_1130 = 164
        _dead_7690 = 199
    text = __import__('base64').b64decode('VjZOc0FrckRINm5USEFJRUlSQVQ=').decode('utf-8')
    if len('') > 0:
        _dead_5164 = 574
    total = value + len(text)
    if False and True:
        _dead_5378 = 536
    return total

def _ЛяьΒφЙЛκдΝе():
    value = 881462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgHsZAc4ybIEEiGQmF2fADwG8Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МзψΚεЪπА():
    value = 174779
    text = __import__('base64').b64decode('dmZPTGR0b0c4X29pb1dsMXRycWI=').decode('utf-8')
    if False and True:
        _dead_7554 = 965
    total = value + len(text)
    return total

def _щΥцΖдυАΛьνЧεыΕ():
    value = 530170
    if False and True:
        pass
        pass
        628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3/XTXg09JJVDD/23k6oLQp380s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _РΧΩςхυйςиуЯβΟ():
    value = 924665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnbHXn862ppSaxyE4VC4ZTUhsEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 87 * 56 < 0:
        _dead_2019 = 523
        _dead_3042 = 805
    return total

def _ЗЯыЩзГрεБКацηЩοΗ():
    value = 616617
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwjVVnI7xq8VbCqbkFKhOjYOzkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШПюауδΜΝ():
    value = 108182
    text = __import__('base64').b64decode('bjREaTVCRVZrTHQ3OVFsV1VVZ00=').decode('utf-8')
    total = value + len(text)
    return total

def _чщнэΣооΡцпαйβΞξ():
    value = 735610
    text = __import__('base64').b64decode('dXBLRGZTcEVUSEJjVkxwTlN0WkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣПыэНλνЫбπ():
    if 12 * 45 < 0:
        _dead_5268 = 970
    value = 971109
    text = __import__('base64').b64decode('ZXlmbFpJcm9OTlltdGZoeEtuNHQ=').decode('utf-8')
    total = value + len(text)
    if 95 * 89 < 0:
        818
        535
    return total

def _ЧчΑЧΒφμФψсλι():
    value = 202788
    text = __import__('base64').b64decode('bEVNV0dYaEtIcE05NGJ6ZTExNzc=').decode('utf-8')
    total = value + len(text)
    return total

def _эжωΙЖЩдΟ():
    value = 129660
    if 69 * 30 < 0:
        pass
        pass
    text = __import__('base64').b64decode('VnRFSlBpcERnNTVPckdBdExwV1I=').decode('utf-8')
    if len('') > 0:
        _dead_7446 = 52
        pass
        pass
    total = value + len(text)
    return total

def _ΑΠщΗлΓзС():
    if False and True:
        _dead_5931 = 397
        568
    value = 358502
    if 15 * 84 < 0:
        _dead_3366 = 811
    text = __import__('base64').b64decode('QmVVd2VZeVJGenRwOGp6ZHRhRFo=').decode('utf-8')
    if len('') > 0:
        _dead_5617 = 513
    total = value + len(text)
    return total

def _κБтвΡвΡΤпъοгяБаД():
    value = 452516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiL3aHUO24RaLD+6n2KSNwQB6Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЭвбΤцЛΑМαощ():
    value = 453579
    text = __import__('base64').b64decode('VUFjRUs1Y1pzU1Z1RDA2Mmg1R1M=').decode('utf-8')
    if 17 * 59 < 0:
        666
        pass
    total = value + len(text)
    return total

def _ΟΣΣОГΓвбвσбΟЬч():
    value = 176277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3+1T2kO14AmLz3w5HyjPxB8z3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σιыΡЕХΕοΤξιыρй():
    value = 201570
    if False and True:
        _dead_5432 = 846
        _dead_1016 = 240
    text = __import__('base64').b64decode('YlFoVFkyYXZma25pSGdwV2g3T1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞлΘыСφтЦΡЬЫ():
    value = 130499
    text = __import__('base64').b64decode('VTNaWW5zQmZ5MURaRGllRVc2dEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _φΓттеКыΠμ():
    if 69 * 72 < 0:
        _dead_9675 = 952
        _dead_8780 = 691
    value = 304623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSDjT1YGpoogawiQmGaAPg06408='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭξκΨсψвΝ():
    value = 711318
    text = __import__('base64').b64decode('ZE9GdzVodTk0SUJlY3BUa3JFR28=').decode('utf-8')
    if len('') > 0:
        _dead_9085 = 522
        pass
        _dead_1856 = 763
    total = value + len(text)
    return total

def _фОБγВςςрδМ():
    if len('') > 0:
        pass
        _dead_3468 = 194
    value = 456348
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSvsV3UG8a4JGV+XwFCDGxwLzGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΒэζйψΡьΣгЩчΙ():
    value = 340281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCjnT3UOyIo8AB77nHmIBykV8W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кчДищНрЩЮΝИκ():
    value = 545417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axqwf0YB7J5aCVua0nOgNxQX1jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лμλВКврХΟρдΙΑ():
    value = 34730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx2ySUAj+4MWPAeI4XyFFyE3sn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иММζщΒюΑБμ():
    value = 322718
    text = __import__('base64').b64decode('Tm9NamZMQ3RjaFU5ejVpWUpCU3M=').decode('utf-8')
    total = value + len(text)
    return total

def _υπьκςηВΛУ():
    if False and True:
        _dead_9682 = 57
        pass
    value = 54722
    if len('') > 0:
        _dead_6679 = 36
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISDqfENt8oElNgj16nihIhoL51o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        46
        pass
        _dead_9859 = 108
    total = value + len(text)
    if 50 * 36 < 0:
        pass
        pass
        431
    return total

def _рΦыΕлΨλО():
    value = 125939
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Djbme1YL76ctKwaR6WGqF3YX4GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γыдяΜΛЪΒтььΨΝс():
    value = 321148
    if False and True:
        163
        _dead_7092 = 861
        pass
    text = __import__('base64').b64decode('WU9KTmZJSXV5b1ZIVzJMVXN4YVE=').decode('utf-8')
    total = value + len(text)
    return total

def _λΘЙγупЭТСθΟбЕΛ():
    value = 158344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kgb8ZkUK1YAhICmcxEaUMnUd62M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 97 * 62 < 0:
        842
        _dead_6597 = 274
        _dead_8517 = 609
    return total

def _МζПнΗρЦцЦСΣδяэΚз():
    if False and True:
        _dead_3730 = 59
        pass
        pass
    value = 749737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAe1fEko+JAkLyCc23jHDi8o3VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦлДюΔυНхιΛгυκσДδ():
    value = 240688
    if len('') > 0:
        39
        pass
    text = __import__('base64').b64decode('SmJBOTd0NmxXSmNESmdLVkQ1cU0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΟНζΣщьδщφ():
    value = 586738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAq2THgTr447aBip7UGlYwcdwVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7334 = 73
        _dead_6115 = 575
        922
    total = value + len(text)
    return total

def _уαвЙμνΖЦЗюΨ():
    value = 5547
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjizOFVv9pxQHlzw4lSIIQY98X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_1908 = 269
        600
    total = value + len(text)
    return total

def _χТйςΦπγЯыπзΩΘ():
    if False and True:
        476
        _dead_2712 = 386
    value = 110212
    if len('') > 0:
        pass
        149
    text = __import__('base64').b64decode('T0k0VnpLWjZlUENiNDF0SXN1TVU=').decode('utf-8')
    if 97 * 34 < 0:
        911
        _dead_3477 = 357
        679
    total = value + len(text)
    if False and True:
        _dead_1757 = 910
        pass
    return total

def _οГΛФΤЖΓгωрΟОΚαШ():
    value = 629058
    text = __import__('base64').b64decode('V09FbUFja3RCVEhuVjBCeURUazI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΟηжВШъпΥлъΨ():
    value = 795154
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBvrZVsVqaNXEQ2S4n23IXc990Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_8201 = 11
    total = value + len(text)
    return total

def _тαΥΩеЛΧΤΥюΖч():
    value = 795464
    if False and True:
        _dead_7494 = 724
        _dead_4357 = 768
        240
    text = __import__('base64').b64decode('V2xpbkJaamJqcGZrM2JsckpOMF8=').decode('utf-8')
    if False and True:
        _dead_2660 = 970
    total = value + len(text)
    return total

def _сОЧΘЩТюе():
    value = 67352
    if False and True:
        209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzntQAVu2rlWMh2C6ny/ATEl50U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фПΧσΜЩофρюλПИмОЧ():
    if 13 * 49 < 0:
        286
        pass
    value = 464047
    text = __import__('base64').b64decode('WUlwT1h6dVRHYmZKUHVZNk1mT1I=').decode('utf-8')
    if 51 * 2 < 0:
        pass
        pass
        238
    total = value + len(text)
    if len('') > 0:
        0
        136
    return total

def _еЕΔйиζХαмχ():
    value = 29301
    text = __import__('base64').b64decode('QlBuTEY2QjEybUdVZWdoc2s4UnM=').decode('utf-8')
    if 16 * 45 < 0:
        pass
        _dead_6762 = 231
        656
    total = value + len(text)
    return total

def _ΠвГЪЯσΑιΙηψσх():
    value = 710667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyDrPlcu1qAODBq6/kelAXV47mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6258 = 83
        651
        722
    total = value + len(text)
    if False and True:
        150
    return total

def _ΚЫυтрТчяτβΙПЛΓ():
    if False and True:
        428
    value = 376777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiDgRVMwzpsCYgmSwXCHPxoq0Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧβйЮюБлοΡΚГп():
    value = 654816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQzlVHI27Ik8PwWN2kG9AXYm/Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΗэΧщρвйΘхТЦ():
    value = 137962
    text = __import__('base64').b64decode('RnNqU0VwN3p2ZHA5RmtWc09TMGc=').decode('utf-8')
    total = value + len(text)
    return total

def _чχчоГρНτε():
    value = 480900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjvsSFBr1q8lbB+v2XmKCxN90Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦμбИрЗΔДπυΚπЯ():
    value = 885840
    text = __import__('base64').b64decode('VVVFMEdVYmdYOGZkdWF5STJXNGk=').decode('utf-8')
    total = value + len(text)
    return total

def _тΩΣЧДΨжΟτΞΑψСν():
    value = 576088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Py3De0s6570WBQ2k+mzIPnMC/j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        246
    total = value + len(text)
    return total

def _ТΔЬсΓΓΠЙ():
    value = 139396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnbcSG5h8KU5EyWi8AKfZQcfwkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТГчΜΒГΡпИйлΨ():
    value = 711832
    text = __import__('base64').b64decode('Q2xNN1QwSzQ1UFFQYm9kS3pCVzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _шЧηωяμЩψяж():
    value = 818435
    if len('') > 0:
        _dead_5691 = 222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRzhdl8tx64sMCqG40/HHw0otWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δкЧΜОпГрО():
    value = 643889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In/KPHY7x/ENbymlygCjN3A2/F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 13 < 0:
        _dead_1254 = 230
    total = value + len(text)
    return total

def _фΔΘαψзβдлΓо():
    value = 8289
    text = __import__('base64').b64decode('eVBQSXgwX1NTbVkzbmx4SXhoQVc=').decode('utf-8')
    total = value + len(text)
    return total

def _моЗыνψЙαΙюыЧДΨшб():
    value = 283249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej78aUAB/JknFBmZmQe1EB0qyDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΟФиТεюВ():
    value = 359008
    text = __import__('base64').b64decode('TmVINllHOUlMQ2VQZ1dyM1VWZl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ифιжΧБыЬσефВег():
    value = 219324
    text = __import__('base64').b64decode('QnFsSFlrTlFvbXo4dWFHRkIwbjU=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ЙиξЕЭдΞтХΤχμ():
    value = 896817
    if 39 * 25 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQbFf2Np+L0hDy6SmlmaYwINs2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1925 = 603
        454
    return total

def _ΦЫзмΛЩЪДΕоЛч():
    value = 667822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx+zVFcN6YUOEF2y+FybOSM2wj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        714
        _dead_2310 = 949
        pass
    total = value + len(text)
    if False and True:
        523
        _dead_3921 = 262
    return total

def _ОΑЖΧκкοφЩейΠ():
    value = 167215
    if len('') > 0:
        pass
        _dead_7188 = 724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyPneVgrr78RGwmp52C+IiYp7lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эЗΡХШχУγΘ():
    if len('') > 0:
        pass
        pass
        pass
    value = 794393
    text = __import__('base64').b64decode('b01hNHhsOFU5eWdmUDVqcFk2VXY=').decode('utf-8')
    if 57 * 71 < 0:
        pass
        _dead_7832 = 96
    total = value + len(text)
    if 31 * 100 < 0:
        676
    return total

def _шфυуЩαΕи():
    value = 871918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fwn1e3812/FQKB2T23mjCwcBz0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТеГЮνДрЮΛοΓ():
    value = 865212
    if len('') > 0:
        pass
        _dead_9757 = 84
        123
    text = __import__('base64').b64decode('dTZoR1dFSVJKVXlFYm5Rc20ybW4=').decode('utf-8')
    if False and True:
        312
        981
        _dead_3357 = 986
    total = value + len(text)
    return total

def _ЧоπαшнРцπШЧΛЙΡ():
    if len('') > 0:
        _dead_6443 = 253
        pass
        364
    value = 135994
    text = __import__('base64').b64decode('WlBFa1ZRTENTVzBfZllXUHNKaXM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5662 = 968
        pass
    return total

def _ОзωΙРПщУэΔюЦЖφ():
    value = 853373
    text = __import__('base64').b64decode('Wmo2Vmt3SGNheVBVVWtUcnlmQ1U=').decode('utf-8')
    if 13 * 63 < 0:
        331
        pass
        _dead_8040 = 843
    total = value + len(text)
    return total

def _вСшΣΚωььх():
    value = 698313
    text = __import__('base64').b64decode('bjFLYVlLUmdUUGtMS1pTb3lnT1k=').decode('utf-8')
    total = value + len(text)
    return total

def _диΞΛЧсφЮР():
    value = 193408
    if 1 * 5 < 0:
        641
    text = __import__('base64').b64decode('S2tHTWUwcFJlUzZoeFZvV2JVOGQ=').decode('utf-8')
    if len('') > 0:
        _dead_4381 = 921
        267
        pass
    total = value + len(text)
    return total

def _ΗжΝплλрэγэΤΝΟЯж():
    value = 217856
    text = __import__('base64').b64decode('SHpXWGlEUGhHMDVMZVQzN2RNRkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟμМЗζВσсБ():
    value = 486663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lhjjfngy97EpCl2F73+vNwMp0V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8112 = 209
        839
        _dead_7770 = 123
    total = value + len(text)
    return total

def _укΗαюБΧΚаΔ():
    if len('') > 0:
        pass
    value = 807550
    if len('') > 0:
        pass
        855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxyzYUIj0f8bbh+G32e7Fwd820U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 100 < 0:
        80
        _dead_4781 = 822
    total = value + len(text)
    if 86 * 60 < 0:
        442
        _dead_5821 = 872
        pass
    return total

def _ЮΙТрщτβΠιН():
    if len('') > 0:
        pass
    value = 262529
    text = __import__('base64').b64decode('R2ROUjdrOFhvNjdfXzYzMkJybnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖшТнБΧАМε():
    value = 302002
    text = __import__('base64').b64decode('dWVYOE1lbGxFbTBvNDlDS0dFZl8=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _КЬРаνшνΓΦΤшРеръш():
    value = 548288
    text = __import__('base64').b64decode('SVJqUVJmRW93dzhSOWg5d29FdnQ=').decode('utf-8')
    if 32 * 96 < 0:
        335
        _dead_7262 = 44
        pass
    total = value + len(text)
    return total

def _фВУΝΒЪπжΙеΟνΗ():
    value = 560756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISfqZUk15pkWKRuC8nCyLgEYzGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 29 < 0:
        _dead_7970 = 470
    total = value + len(text)
    return total

def _ПфФкХЙξюВСΗ():
    value = 632405
    text = __import__('base64').b64decode('T1Fic082V205MTFjM2pvdm50Z08=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3215 = 564
    return total

def _ΜГΖκηЭВТΒΜΩΦΟΧГй():
    value = 777416
    text = __import__('base64').b64decode('Z25OYllGUzlPQXRtR3d2ZUlyVVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΧΛρΧΓοΩхЦф():
    value = 286685
    text = __import__('base64').b64decode('VUZTa2Z2M0h1UU5QT1JveHdSSWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩеΩкпуЮФх():
    if len('') > 0:
        pass
        42
    value = 771657
    text = __import__('base64').b64decode('RXhWcHlnQjBtQUcyRjdpWVFyTTc=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if 95 * 60 < 0:
        526
    return total

def _ГЪъЛЧЮУΛΟ():
    value = 520088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH63SwZs95wRaQq5zGK1ZhIu7n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛδДБЮФθηНчБθ():
    value = 991711
    text = __import__('base64').b64decode('UDJSeWhZZjZMeEd2b2lyZWhDYmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΔЯδΓЩΓХЦψσΡ():
    value = 351034
    if False and True:
        _dead_3069 = 973
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXu2RGkjqIouNl330lqlZAEeyUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 21 * 35 < 0:
        pass
    total = value + len(text)
    return total

def _ЬефΤλнОНΗΓшИ():
    value = 53483
    if False and True:
        pass
        pass
        pass
    text = __import__('base64').b64decode('T0R5cnpUREJqQ3J2Sk11WVVMbmE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7555 = 42
        794
        pass
    return total

def _ζЙΡΨΤКциаКст():
    value = 848725
    text = __import__('base64').b64decode('Rkplc0s4WHRraWQ4U2d0b0FzSzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΣΜΖРδλВВΚυ():
    value = 775756
    if 43 * 86 < 0:
        47
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET60eV8x2fAnaiOE5FOIIjN83mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шъпδУμΔМССЪβМхСδ():
    value = 735990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH62aHkDzKw8MSeVwFevFyke8zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цУлΔйВяςОφ():
    value = 148965
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACb8fAI935dWPyGO32O1MAgt1X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЮΧΖξцДηдфΙПΩψ():
    value = 773219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxD2WAMq84c7bg7x+1mxEA0D6Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΕЧЛЯζχπБΧСΨЬяπ():
    value = 794410
    if 71 * 10 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQa9aXoX//BaYgezyn+4OTYV710='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 56 * 30 < 0:
        pass
        _dead_4165 = 120
    total = value + len(text)
    return total

def _ыьψΓСκхЕΡ():
    value = 40047
    if 86 * 80 < 0:
        pass
        _dead_5074 = 606
        75
    text = __import__('base64').b64decode('Wk5fdEQwUXJtc1AzQjZlejVZb1g=').decode('utf-8')
    if 60 * 58 < 0:
        _dead_3499 = 510
        375
        678
    total = value + len(text)
    if len('') > 0:
        _dead_4272 = 491
    return total

def _МЫΓжКηтΧтВэВ():
    value = 847130
    text = __import__('base64').b64decode('bE1ybXp0QWI0Y05zRTd1NW1NZUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥэЖдεΗΔцЕ():
    value = 644805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD+xZmBpr4cGPCeQn3ecIAAA4kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юяχαΩИюХςςПΦυΚμΒ():
    value = 862601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRXdRnAK/bEBIzuS+XGxEnQ67k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЦммэВоеΓкьοПжΑУ():
    if len('') > 0:
        pass
        pass
    value = 295139
    text = __import__('base64').b64decode('ZjBfdFZLRHA3THpGVUhwWENMMHY=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_5539 = 737
    total = value + len(text)
    return total

def _жρΚНЕθвнθнυ():
    value = 217679
    text = __import__('base64').b64decode('WGF0YXM2MWdjMjRYRFVPS0JfdUU=').decode('utf-8')
    total = value + len(text)
    if 25 * 59 < 0:
        163
    return total

def _ςτРЫΦЩДшυсαщζΦκ():
    value = 76764
    text = __import__('base64').b64decode('cTIwOWV1Z25qRTFKcVRXSU9RQjk=').decode('utf-8')
    total = value + len(text)
    return total

def _εψχнΨЫэΙьδτ():
    if 59 * 80 < 0:
        pass
        898
    value = 464152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jiq0YF0hr4YRAymcn0+xAyko6z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_6222 = 219
    return total

def _ωкЪσΜцσεХ():
    value = 75380
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FALDX1cw0Z4WGF2CnXuIDQp/1jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 7 * 7 < 0:
        785
        pass
    return total

def _ΒЫξРЮГлυνЦжб():
    value = 934120
    text = __import__('base64').b64decode('emlQakRZc3VTQ2RPTGNfSkZrMnk=').decode('utf-8')
    total = value + len(text)
    return total

def _МЪΥждΝОорЯΡЪЭ():
    value = 252508
    text = __import__('base64').b64decode('b01XeTBoNWFEaXJ0SnhrUXcxTmg=').decode('utf-8')
    total = value + len(text)
    return total

def _кЙзΧΩыЬδШДсΗην():
    value = 873054
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyTdR2UG1JhbOTryznKoGXA/yUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΗнπтΘЙΠνыΡ():
    value = 469453
    text = __import__('base64').b64decode('TWxsYXhkNFFIOWlWODk1Ums3Ykw=').decode('utf-8')
    if 7 * 57 < 0:
        _dead_5711 = 746
        pass
    total = value + len(text)
    return total

def _ΩγΙфвπВΦЕμΡф():
    value = 931968
    text = __import__('base64').b64decode('ZTJJdHZ0VnpzWUdFZngzMXEyQUg=').decode('utf-8')
    total = value + len(text)
    return total

def _гΘμηλαΛΚΙЩΖЪЭН():
    value = 837368
    text = __import__('base64').b64decode('RTlkenZCaW9mVFVPNU9GaTVOMGM=').decode('utf-8')
    if False and True:
        pass
        pass
        355
    total = value + len(text)
    return total

def _ХλШъяпθЬΞΟΟΟΦПч():
    value = 435883
    if len('') > 0:
        _dead_1642 = 615
        _dead_9925 = 677
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj+0RHIj2b4lHAr2mHCiN3cO/Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 95 * 72 < 0:
        407
        _dead_7199 = 391
        pass
    return total

def _УЖπбОЭЙЫъНЮЕФζ():
    value = 440670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ci7Afn8X5rIgbAWy90KKIxMOyn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δГэгЩЛЧШΥυ():
    value = 874923
    text = __import__('base64').b64decode('dGxCUFhCREdXTUhmeE15NDlmR1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ξοБΡιΜчΞΜуЕΘΥ():
    value = 105175
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS7pTEssp4AnHAzwnGC+JiE14H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝйщЫθзюАλΨХОДυЬ():
    value = 809544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AC6yf0cD760KPxmB23KlOgx91Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        911
        881
    return total

def _ωдΣШΚοΛШз():
    value = 596991
    text = __import__('base64').b64decode('VElld3R0TnVvbGdVNHU0VVdobHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦЫЮЕмдΝΟλ():
    value = 566623
    text = __import__('base64').b64decode('T1VYV2E3ZjlZZlNDTWN4Zm10aHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ιχЬΛЭщНχΛКДЧΑэ():
    if False and True:
        _dead_2059 = 286
        _dead_5353 = 586
        918
    value = 955610
    if len('') > 0:
        126
        _dead_5177 = 473
    text = __import__('base64').b64decode('V0JSbGVHUWd6NnU1TEJkOEtrV3M=').decode('utf-8')
    total = value + len(text)
    return total

def _κδИьΤχΜαΣЫηхЫΛИ():
    if False and True:
        _dead_6802 = 573
        _dead_3380 = 388
        37
    value = 544184
    text = __import__('base64').b64decode('T1RCTU5Dc3M0YUVaVFJsQ08zOHE=').decode('utf-8')
    total = value + len(text)
    if 86 * 86 < 0:
        _dead_5062 = 752
        397
    return total

def _АюПΤюρОσ():
    if len('') > 0:
        pass
        893
        pass
    value = 490283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NA28Qmcd1pkGNxmkxHiKNS4dwEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _сГДцарψΥδЮттвфЖо():
    value = 271739
    if False and True:
        _dead_9527 = 763
    text = __import__('base64').b64decode('S2RqM3FVSDkxR2ZXT1ZXU1VlV3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ДφКътШЙпЗюκΜаκυ():
    value = 318098
    text = __import__('base64').b64decode('WFcyZzJtdDB2RG5xUWJwY09WX1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ДТЮЪуΓоσ():
    if 58 * 71 < 0:
        _dead_8268 = 226
        pass
    value = 541571
    if False and True:
        _dead_6292 = 813
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECHuPUhurroiFwOH/HWnYyAG1n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 78 < 0:
        951
        pass
        _dead_3726 = 259
    total = value + len(text)
    return total

def _щЙθФЗσςΜЫьэτΟэ():
    value = 684324
    if len('') > 0:
        _dead_2396 = 206
        _dead_6386 = 517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjzVQWUx7qsBaBqnn1mGMCgeylg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДошЭυшыε():
    value = 928625
    if 19 * 20 < 0:
        394
        577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQrha1Nt/YwCNieP0nCkCzYW1Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        374
        pass
        259
    total = value + len(text)
    return total

def _δХΓγЬΑЛορЯβ():
    value = 540236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBvMRGBoz6UEMAeaxleaATcltmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψТοиσεлхκЕщцτΑ():
    value = 970609
    if False and True:
        _dead_2051 = 51
    text = __import__('base64').b64decode('WkxyRjFPSm5SZURLQVBqZzdmSGE=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ВВФσνЗΑεΦАπΗΔяΩ():
    if 64 * 10 < 0:
        _dead_6829 = 149
    value = 517640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTjnakgbwZAzN12n5VukBzUtznQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мПШВшηΤΚгγ():
    if len('') > 0:
        _dead_8040 = 313
    value = 874410
    text = __import__('base64').b64decode('R0lKQVVfTTlvNGFXRzFmUzZwYWU=').decode('utf-8')
    if len('') > 0:
        166
        pass
        _dead_4581 = 40
    total = value + len(text)
    return total

def _ЭдαΙЬВΙЛ():
    value = 272342
    text = __import__('base64').b64decode('UlF2bFVPT2pSU25qQXpQWW1icWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ηηхΜοЖшΜ():
    value = 788516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjvNTwULqowHP1+77HeaEzwOwF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞγξιдХЬпеЛο():
    value = 87001
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jhjsb1gOrKQxEA2Nxl+iNQMswHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цХνΘΜсπТΞΤθмтΗ():
    value = 422005
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DS3VeUQ11f4xPzu56nS/LQAp7Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДКъЦΨωлэ():
    if 8 * 84 < 0:
        _dead_4035 = 832
        _dead_3564 = 971
    value = 123152
    text = __import__('base64').b64decode('aUF1bGFVTWRab05oQWFhTlFpTEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ъΤΠΦλкДσΧζ():
    value = 221182
    text = __import__('base64').b64decode('bjZHS0RXM09ZaVozeWNRRUx2QUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _АΣμГΘζΤКΟ():
    value = 741825
    text = __import__('base64').b64decode('anNBNENMbVp6XzNRRHo1aXVjenU=').decode('utf-8')
    if 28 * 11 < 0:
        pass
    total = value + len(text)
    if 41 * 2 < 0:
        _dead_1225 = 399
        _dead_2597 = 830
    return total

def _λΗΕηбэяΟ():
    value = 45750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mi3NP0YLrqc8Lgr7w1u4ZhQisV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 68 < 0:
        _dead_8920 = 214
    total = value + len(text)
    if 65 * 48 < 0:
        314
        883
    return total

def _ьтТбΨΨнΦиНШαпК():
    value = 971214
    text = __import__('base64').b64decode('aFJGUk9leHB5NTlkY3duMFVCTE0=').decode('utf-8')
    total = value + len(text)
    return total

def _δοяςлООб():
    value = 803570
    text = __import__('base64').b64decode('ZExzdkJoVW9IVnJGaEFTdTFjejU=').decode('utf-8')
    if False and True:
        pass
        _dead_9325 = 455
    total = value + len(text)
    return total

def _ЯЫЛξσΚЛВю():
    if 41 * 3 < 0:
        pass
    value = 212330
    text = __import__('base64').b64decode('eF9UY2h3dkFuRExwQmVmZ29EenQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЯЬαвПсЯчтθгμΣХΛ():
    value = 651164
    text = __import__('base64').b64decode('cHhobjdKX3RlN0p2dm0zdmdlNFY=').decode('utf-8')
    total = value + len(text)
    return total

def _бъфΑΕγсФкΧ():
    value = 613501
    if False and True:
        888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhezPXIp54QCPhn3+1GGAwgm11k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘιοΣΚνβζτмШиζ():
    if False and True:
        82
        _dead_8812 = 947
        926
    value = 875586
    text = __import__('base64').b64decode('YWFhVTBsODJ3UnBIUHRXSV9FUlA=').decode('utf-8')
    if 31 * 9 < 0:
        854
    total = value + len(text)
    return total

def _РеβξΨяΠΤфσЧςсΗα():
    value = 124636
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhXASHAGzZo0CgeUzlq7HwMM/U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μщΔвхηΡУλвθ():
    if False and True:
        250
    value = 783996
    text = __import__('base64').b64decode('SmZqSWl2c0hzNllKWkJRZkhqODk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4457 = 83
        _dead_8780 = 527
    return total

def _ΤзйРюСΙпΛСЬРτ():
    value = 348340
    text = __import__('base64').b64decode('Q2pzTWZkU1JiMkEzYUxER1hQZG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΧΦΖШсйЯσшιф():
    value = 744916
    text = __import__('base64').b64decode('aGd3dGRBS2wyTTFmTElISHZval8=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЦΑΔπУефΟПψфзЗΒт():
    value = 510240
    if 68 * 17 < 0:
        _dead_3751 = 460
    text = __import__('base64').b64decode('bmhvWXNPNW5NaDNHa1NyU2NvU2s=').decode('utf-8')
    if False and True:
        _dead_2190 = 148
        970
    total = value + len(text)
    return total

def _хлΛЗνпуКδФешαφИа():
    value = 993035
    text = __import__('base64').b64decode('ejJOajR2S2xHU0NNekZEeUJXMDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if 32 * 6 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    980