#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _лслблЙχαщЫЕτрΧΤ():
    if False and True:
        _dead_4913 = 805
        753
        289
    value = 905650
    if False and True:
        pass
        352
        pass
    text = __import__('base64').b64decode('V2c5d2NORjlOWjl6aXJMdV9LaFE=').decode('utf-8')
    if False and True:
        pass
        pass
        928
    total = value + len(text)
    return total

def _ПъΘΙΖМΛлΜθυπΤ():
    value = 875515
    text = __import__('base64').b64decode('RnY4R0wxY3hxVEd0cUFUZUh6R3k=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΛГЧςθьΗШθаБГ():
    value = 382179
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzfiSVptzbg2NDvw+WKBJyoYtEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓшмπМαйЛεκОωξэЮ():
    value = 110635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3rLWnYWzqYPOQut0AWXHTB29Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φτЯйΨΞΟСо():
    if 77 * 69 < 0:
        pass
        _dead_4049 = 610
        _dead_2823 = 591
    value = 483517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSzUZ2g3yYkQDR25y3eYJ3B8yX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1396 = 745
        _dead_9806 = 932
        _dead_7017 = 658
    total = value + len(text)
    return total

def _ОЧЪУΙΔμпщЖπщβПο():
    value = 645863
    text = __import__('base64').b64decode('ek5zN01ialJzSG9nMFVlZFU3Q3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ХюБνБπбΤмθРρθθα():
    if len('') > 0:
        661
        _dead_5945 = 696
        _dead_3354 = 905
    value = 636213
    text = __import__('base64').b64decode('RXN5ZFRDUHFTekRXRHZIcExHOUY=').decode('utf-8')
    total = value + len(text)
    return total

def _αПΩЕιИβЫЬθС():
    if False and True:
        _dead_1740 = 956
        _dead_5601 = 647
        795
    value = 66089
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ij7qOEZu9YRQPzCi0XmVDB8K4mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        632
    return total

def _нΠвΘΡαοЫδиВπмеЕМ():
    value = 610320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwGwTUMV+L1QHlin4VW0bQkcxUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 53 * 14 < 0:
        316
        130
    return total

def _ογθщρиΣИгВ():
    value = 403801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy3+XGMO5LAhPBm58U+yCwgKwH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лоЭΖΜЯПДЛκ():
    value = 4878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhbhSlJo7rEOOyau0FLGLBEqzn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БяМгυΝχчтυ():
    value = 629693
    text = __import__('base64').b64decode('VTRDZUM4SUJ0eGc0RVBJV1NCTkc=').decode('utf-8')
    total = value + len(text)
    if 82 * 56 < 0:
        526
        35
    return total

def _ИъξБЪΩηеξφηΠζ():
    value = 743825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dwi9SmQupqEnEFuE5lS2YykZ1lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωβΒθυυЦцΒψ():
    value = 185394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCbPN0cW9/BTY1rxwUbGZh82sHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 31 < 0:
        _dead_8680 = 992
        pass
    total = value + len(text)
    return total

def _γЕΩηΠΜμииХ():
    value = 239052
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCTyNkEv5JIwbgatm1+nZTE20Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φЦйυΙрΥуΥγυΟυ():
    value = 826934
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRrjeH8SpqkWAByN7webJRcE20w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жμςΒΚОСпΚкχшμΧσ():
    value = 814851
    if 7 * 88 < 0:
        _dead_6188 = 352
    text = __import__('base64').b64decode('RUVQSFZ1UHF0cFNCdlFTSDN3MnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖфФШЬшИчΩгЫ():
    if False and True:
        pass
    value = 738247
    text = __import__('base64').b64decode('Ylo1X0JUZjFnb19fN2tzNEgzbm4=').decode('utf-8')
    total = value + len(text)
    return total

def _БКЙΛЬπсξχΗЙЪς():
    if 67 * 43 < 0:
        _dead_3703 = 974
        pass
    value = 438158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jg7SSXwq85FXOCiF/1ecG3AK6Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЫжГпΨΑВЯрВШуыκд():
    value = 317552
    text = __import__('base64').b64decode('Sl8xRXp0MzNOakNNdjZkMGFteE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝςЛэΗоЪАΥькЭΦ():
    if len('') > 0:
        pass
        _dead_2491 = 921
    value = 144350
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnqyW30//4kbFVuy3XmgOiEmsnY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 81 < 0:
        5
    total = value + len(text)
    if len('') > 0:
        _dead_1948 = 256
    return total

def _ΙΠМЩлЮйΗβЙωΣияσх():
    value = 904244
    text = __import__('base64').b64decode('QnZHS0FVa2F3MnBkdkc0T0h2ZTc=').decode('utf-8')
    total = value + len(text)
    return total

def _υьιΖЬЯЮΦΖ():
    value = 169258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Djb9Z1ka2YUoah6v0H2yFXEh9Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        700
        _dead_7000 = 882
        pass
    return total

def _ΑТЫЯШΙЯΒ():
    value = 232629
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSbqY3wX/44vLBaByXuiLhwYyXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΕΓΑгВξШυУХ():
    value = 355218
    text = __import__('base64').b64decode('ZVV0dkxnVktjN2RZeHFxU0VJeU8=').decode('utf-8')
    total = value + len(text)
    return total

def _оБЦеьςηΘэмΘхсιιλ():
    value = 778349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRvhR3ss2aMWEAaM3AaUASo8/Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        259
        _dead_6651 = 957
        888
    return total

def _ФρΚπашςгωКΩΜδрο():
    value = 572554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDzuQFNs8fAOYzi3wlTFOBJ61W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡхэбдЖςНиТичЙм():
    value = 375945
    text = __import__('base64').b64decode('Znh3TTJHeHA2QXpocWxiNzFOZFU=').decode('utf-8')
    total = value + len(text)
    return total

def _НЧμωΦИпΤοΝш():
    if len('') > 0:
        _dead_6356 = 966
        pass
        919
    value = 103590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBD+fAYf6I8BHyK6n1iEPB8dsV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 55 * 23 < 0:
        pass
        935
        890
    total = value + len(text)
    return total

def _иэαщЪσбт():
    if len('') > 0:
        pass
        902
    value = 318572
    text = __import__('base64').b64decode('ZllKVnpZWl8zQl9xOGt1ak52T0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ТьбАΜΜдЬ():
    value = 663179
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCDIfV81xLo3KTDxm2K6bDx3xXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПьЛΦΝβΚΝлтΛκΡш():
    value = 63780
    if 49 * 89 < 0:
        949
        369
    text = __import__('base64').b64decode('aGhpajhjblpLeGQ4VGhNeGpjU0g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        763
    return total

def _ωТΔнΥтΗρШΥщΦεЧ():
    value = 242244
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECDWawhs0qAnFCyOw2SkFQcA/kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        527
        _dead_3066 = 569
    total = value + len(text)
    if len('') > 0:
        586
        _dead_3798 = 495
    return total

def _ΤеФБοΡσаИс():
    value = 133312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgfBZlMq+/0qaSK5zXCnJBQkzl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9761 = 453
        pass
    return total

def _ΔЧлΒЪфХб():
    value = 252865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyTQY1w9yY8zGCao60KFAAgXwjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΥΑθиξэΚйθ():
    if 38 * 31 < 0:
        pass
        pass
        _dead_5748 = 954
    value = 512304
    text = __import__('base64').b64decode('RkpOSlVjX2o3RUJwM1RKOUxNZGE=').decode('utf-8')
    if len('') > 0:
        pass
        694
        _dead_4609 = 972
    total = value + len(text)
    return total

def _тξΣкΟсΕЪΤчбцηш():
    value = 62407
    if False and True:
        _dead_4055 = 715
    text = __import__('base64').b64decode('RnJHNHptd0IzUURHX0xET2tXcTU=').decode('utf-8')
    total = value + len(text)
    return total

def _οОΑпΗЭΕъЯИЩΞ():
    value = 393029
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDnVRloA8K0KNzyh6m+VHHUX41Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        362
    total = value + len(text)
    return total

def _ηьмΞфдψРачΒв():
    value = 164398
    text = __import__('base64').b64decode('WHVyTHp0Z0dMQlpNVmlITjhfYzY=').decode('utf-8')
    total = value + len(text)
    return total

def _эмЖЦЙжсипНΨдб():
    value = 725286
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDXeb2Iy77pQODWP+kejGiEBt14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛμηζъЦеψЮПωРξпι():
    value = 255621
    text = __import__('base64').b64decode('SnNFVDVSUl9kWEZlTWpSM3FjUE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦβΣуЕβψφФΕζ():
    value = 65712
    text = __import__('base64').b64decode('UmVOT2lncjB0R2NobGNoTFJrcFc=').decode('utf-8')
    total = value + len(text)
    return total

def _хξйдеДАгΜЩ():
    value = 544706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px7PbHoS0vxQMB+Enw+AFnN9s3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3715 = 616
        _dead_3672 = 237
    return total

def _ЕюНΒщИφШъψНβΡξуа():
    if False and True:
        59
        _dead_8317 = 713
    value = 962671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhXxVnA80p4FDiyu40akLSp54WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 55 < 0:
        746
    total = value + len(text)
    return total

def _ΤШИεЧθЧнιоьΜПτ():
    value = 735246
    text = __import__('base64').b64decode('bFd5YzdGWnRlMzV2TEJWMVFrQlU=').decode('utf-8')
    if False and True:
        _dead_1139 = 960
    total = value + len(text)
    if False and True:
        _dead_5093 = 336
        pass
        _dead_6780 = 360
    return total

def _ЯУДΥкРпГжЮК():
    value = 941310
    text = __import__('base64').b64decode('dlRQMTVnQV9WMTExc0NmMTlQMkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ОуωЫΔΕЩΜΥДА():
    value = 201161
    text = __import__('base64').b64decode('VmZ0bV9udXdycmhyeXJNdEJPQmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΥаΛжгОюфΙ():
    if False and True:
        693
    value = 970706
    text = __import__('base64').b64decode('bGxFRjZEVW1rb3dYbVo1WlhLOVo=').decode('utf-8')
    if len('') > 0:
        476
        pass
        pass
    total = value + len(text)
    return total

def _ЗΘЪшоЕαИΚЙΑΘ():
    value = 957728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH/1ZX4L+P4IFD2A2ALHIigg72k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖЗψЛπΝМПμλΕЕ():
    if False and True:
        961
        _dead_5727 = 187
    value = 781190
    text = __import__('base64').b64decode('TWR3MjF4MlpSamhudDZxdGF3bWs=').decode('utf-8')
    if False and True:
        pass
        693
    total = value + len(text)
    return total

def _ΕΔРοωСΡШШФοΘγбκμ():
    if len('') > 0:
        _dead_3439 = 719
    value = 281491
    if len('') > 0:
        960
        pass
        pass
    text = __import__('base64').b64decode('Z3BpanJVUHJwRUtqeU00cmlwS2s=').decode('utf-8')
    if 21 * 42 < 0:
        805
        516
        pass
    total = value + len(text)
    return total

def _КуВЛъιРΑэъΕП():
    value = 688315
    text = __import__('base64').b64decode('VkVObmZ3QXpGOGFac05Vem9Ubms=').decode('utf-8')
    total = value + len(text)
    return total

def _енщτφЙΒВХ():
    if len('') > 0:
        _dead_5493 = 293
        _dead_4302 = 971
        779
    value = 914620
    text = __import__('base64').b64decode('Z19KclhkNTRuaDYxRXdVN1VtYmc=').decode('utf-8')
    total = value + len(text)
    return total

def _хηЫканчΝΕЬщΙΧд():
    value = 289588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCPVeUAg6fstHgmln2aDYyoN12I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧδХРэΧεХχςю():
    if 22 * 60 < 0:
        pass
    value = 180724
    text = __import__('base64').b64decode('UkZOUlVxN1VRNEd0RGZqTzJ3Q1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _шнъЧдЙΥΞя():
    value = 759620
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBewdnsM+P4GNFus5QOcMxAn7mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЪУχДГΥНεбя():
    value = 318822
    if False and True:
        677
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgnXZEUWzJ8lYhyS41WADggGx0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮЖΒнсΓπΡΚ():
    value = 575046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITzCXksv0ZsnPV2J7UWbIwM23WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 58 < 0:
        51
        pass
        _dead_7819 = 26
    total = value + len(text)
    return total

def _ДΟΘεзЩЪωΦςх():
    if False and True:
        266
        _dead_2638 = 805
    value = 95748
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA7SRH0c2JpRGCGgzFyXPB83tH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сСЗξьпйλΦлεПσ():
    if 84 * 29 < 0:
        _dead_8334 = 993
        50
        _dead_9984 = 26
    value = 623576
    text = __import__('base64').b64decode('Uk5ZWmVOSVB6RXU2ZUJWNXl2U1k=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        _dead_2884 = 400
    total = value + len(text)
    if False and True:
        _dead_2865 = 619
    return total

def _нсзмтυλксξжгχи():
    value = 683576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB3mN1Yo1p8uPxavnH+DE3Yozl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гЯξКμКσπАΨчΛТМωЫ():
    value = 345189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTi0Y0Eo+bgkaj/60g6vPQ4c7j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        511
    return total

def _ωЛФпιβΚЭочτμкюΨ():
    value = 330169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw33SmkxrqU0MFivyXSZYxIMxU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΤρχηСИктмξΛΣЧ():
    if len('') > 0:
        pass
        pass
    value = 798039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAP3RUYz5/lSFj2W0VefLHIZ6Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if 5 * 95 < 0:
        pass
    return total

def _δρσθрхκВ():
    value = 583721
    if len('') > 0:
        239
    text = __import__('base64').b64decode('bWxidDg3NzlmbDdMZUFvMDlsM2U=').decode('utf-8')
    total = value + len(text)
    if 6 * 20 < 0:
        pass
        pass
    return total

def _ЗΙГΒΨиββКдМ():
    if len('') > 0:
        _dead_1316 = 822
        _dead_4498 = 180
        410
    value = 353117
    text = __import__('base64').b64decode('QXprY0E2cFpTYkloTG1mYnJEZTc=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _УфετΠКЛΛйτΜΛΟыδ():
    if len('') > 0:
        pass
        pass
        pass
    value = 89963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgrAfgI914YJDACG20+KNih+/Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шьθцμΟΕΒ():
    value = 498941
    text = __import__('base64').b64decode('SG5DV2FWN0VMbjZld1dHNl9MOG0=').decode('utf-8')
    total = value + len(text)
    return total

def _хцνхДуКξЗЯτΤΨ():
    value = 194766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnfHZkdrzpARKRac6wS9Cww19Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъГνпгДшП():
    value = 605931
    text = __import__('base64').b64decode('YzRTdzU0SFlFM05iX2ZReG9hUnM=').decode('utf-8')
    total = value + len(text)
    return total

def _яВНΥнИΟлωσсЩязЕ():
    value = 40717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nguzf1ht+JcvMDCt+USvMSoH0mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪЦЙημΗнБ():
    value = 658549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiTxSlxh2o8VPSH18XTDBi471Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εςфΟοНφбδΝКΛфкΛ():
    value = 345451
    text = __import__('base64').b64decode('SUoyT3JtSDNUSWtkMkhhSEJ0azI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜοδХΥблζΣБΕα():
    value = 345310
    text = __import__('base64').b64decode('WVF3ckhSeml5MVRKU2I4clNpQUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЙΦНγΤрьΧеΩΨуζ():
    value = 902955
    if len('') > 0:
        995
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH3IWQc7yPAnGQGG0macOBUI42U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        286
    return total

def _εаηШΞьэФχζηцФΔ():
    value = 681159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID+yWHktrIQtNQaE42ylIzMJ9Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ТРΟЗμЧДΣяυΜЯΗ():
    if 30 * 18 < 0:
        285
        259
    value = 749697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyHGQVc1144FHCqs232gDXAZyEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        18
        pass
    return total

def _μκуЧЪБЫЪΜДΟъΧ():
    value = 455558
    text = __import__('base64').b64decode('WTZqRzVGVHNzdHpLWmJoNTBDc20=').decode('utf-8')
    total = value + len(text)
    return total

def _МоюоκпτζаЮиΠТΔэ():
    value = 468214
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwPbbwUg5pclPQC3nGKXPgIH13k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΜнЯΑККυЩч():
    value = 672427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgPoOwEw2IsSblf7mEefZxx4zT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_2741 = 536
        pass
    return total

def _ХЩХβящМιР():
    value = 928170
    if False and True:
        182
        715
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FADMQQU00L0POwS67n6TBwogvT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        177
    return total

def _ωβЕоΟΝΖЗ():
    value = 593785
    text = __import__('base64').b64decode('b0N0WHA2aFJhWUtaQ1RiamtRMTM=').decode('utf-8')
    total = value + len(text)
    return total

def _υэΠЬЭΠтЦиЙΣ():
    value = 444567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAfwfWIW5KcZCx+J7WaiPw174Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζУΩоκЬэψн():
    if len('') > 0:
        pass
        pass
        _dead_1201 = 495
    value = 576493
    if False and True:
        110
        931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyS0TGls94ASHz32+XzFbQsj3Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8451 = 54
    total = value + len(text)
    return total

def _ξτЕΒрΚΟтСΓлСζОн():
    value = 873829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCTTQ10Bx51TYhe00meSYHx5sWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЬэπιμзΤяФΤ():
    if False and True:
        _dead_3464 = 664
        780
    value = 95298
    if 15 * 45 < 0:
        287
        pass
        205
    text = __import__('base64').b64decode('dU5sdE5lX3Vha3JSVkR0eXF3R3c=').decode('utf-8')
    if 34 * 72 < 0:
        _dead_7003 = 414
        747
    total = value + len(text)
    if 33 * 17 < 0:
        _dead_1229 = 972
        _dead_8995 = 346
        _dead_5744 = 274
    return total

def _θЫγлΝΜеЬюκчοωЭ():
    value = 781667
    if len('') > 0:
        _dead_3383 = 504
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAzpa1I7+rsXGV2u7nybGnQ18mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЖЯЪψςнπωτ():
    value = 843728
    text = __import__('base64').b64decode('dkZLbEExTFAxMHZMbjhBREpzNjk=').decode('utf-8')
    total = value + len(text)
    return total

def _кΠУΓοΨθΜззйИ():
    value = 253887
    text = __import__('base64').b64decode('c2RNY1pBS3VURnRoTndEYXN3aTE=').decode('utf-8')
    total = value + len(text)
    return total

def _πШфжαЬтЪа():
    if False and True:
        959
        pass
        pass
    value = 378045
    if False and True:
        335
        _dead_9065 = 202
    text = __import__('base64').b64decode('R1F6cUQ4cjVaTlJYN1Vyc1JEUkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ъοеНЛНψих():
    value = 432390
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hwq1T1kyzbkIFRaB6VG2BjAW7To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦПпΦлЮψΒΑοωюπЭ():
    value = 188918
    if 79 * 54 < 0:
        _dead_2036 = 265
    text = __import__('base64').b64decode('TGh5djFSYXJqc3k5dUd5dGRfMU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨЕΦПЮюмКззδкЪφ():
    value = 786492
    text = __import__('base64').b64decode('b0psOWduRkdnSDAwT3RRM2lEVF8=').decode('utf-8')
    total = value + len(text)
    return total

def _лЬщОΜΙгаδеОΔχ():
    if len('') > 0:
        38
        581
        311
    value = 386097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3a2X3s8254aFDq2nHOJGwcIs14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔЫшщеψРрτьЗдпξЩы():
    value = 641304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXbHZgYyxKZRGxqW+0CKYCcb0Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΒЯццгςтФмχφφДηΕ():
    value = 630309
    text = __import__('base64').b64decode('UWd6MEFKTHRfZ1NvdTRtZHhEWXM=').decode('utf-8')
    total = value + len(text)
    return total

def _щΛщλЙКΙλΧεЖЩε():
    if len('') > 0:
        pass
    value = 455549
    if 68 * 47 < 0:
        918
        _dead_7920 = 711
        pass
    text = __import__('base64').b64decode('YktRNzNOU0E0QmF5QklSdmcwanc=').decode('utf-8')
    total = value + len(text)
    return total

def _ВЦηξфΕлΓΟ():
    value = 47969
    if len('') > 0:
        647
        318
    text = __import__('base64').b64decode('VWNZSjN0M2xiR1RBdFdhaUxTd3U=').decode('utf-8')
    if len('') > 0:
        _dead_9485 = 98
    total = value + len(text)
    return total

def _уγιчюоЙСлБγ():
    value = 328540
    text = __import__('base64').b64decode('S19VUUc4RUxVRWUyUjd4WEFQMUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭЛЦΙΡТЮР():
    value = 530110
    text = __import__('base64').b64decode('WlBjaHBGSVJjSnhRVkxXbUZnUVA=').decode('utf-8')
    total = value + len(text)
    return total

def _эыМдЙΤΟΥΖΑχД():
    value = 562446
    text = __import__('base64').b64decode('aDZiT0dLeUE5V1g4Y2hFV2cyQ3M=').decode('utf-8')
    total = value + len(text)
    if 22 * 78 < 0:
        _dead_4218 = 789
        pass
        426
    return total

def _ΡчΥТШрвШ():
    value = 485738
    text = __import__('base64').b64decode('d1F6ajNiN3dWNTBhZTNjNWhzbzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤруκДΧйЧлЯφЮυ():
    value = 445056
    if False and True:
        _dead_7288 = 72
    text = __import__('base64').b64decode('dnkyVGVJUDJuQ2lxTk85VUJDNDg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3995 = 409
        _dead_6185 = 227
        915
    return total

def _ΘΧАэъΠЖфРΓΛΩΓλх():
    value = 745405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3frOV8uyJpUbwSVmgekGT971Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛςЦДЦτТииθ():
    value = 17019
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhzmRAg304w2NyXz0VKkIhEfyms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙЗκОΕρзвВ():
    value = 415663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnnCZGY8yrwSMl/w4FCqOXUE1zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΒηξЬυтЩаφβбНЪΟη():
    value = 859250
    text = __import__('base64').b64decode('c2hpY0lkS0RPSnJHZ2I2Z2hQTl8=').decode('utf-8')
    total = value + len(text)
    return total

def _дιχΓТпξлαΞ():
    value = 761021
    text = __import__('base64').b64decode('R3VMY2xMa25rODZjdVNTaTNmMVg=').decode('utf-8')
    total = value + len(text)
    return total

def _зΕхςΨЫжξΩцξψξΕΨб():
    value = 374449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHzCTAIr8ZpbABvyz1nBYQd83jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хиАРτρЩΟэЦЭУΤο():
    value = 771738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3fTS0cIyrAQHSWT41ukDRM54zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        90
    total = value + len(text)
    if 17 * 48 < 0:
        779
        311
    return total

def _ΧΗωъКνщчД():
    value = 810253
    text = __import__('base64').b64decode('TlRjOUR3QW8zUnFPamJrM21Ebl8=').decode('utf-8')
    total = value + len(text)
    return total

def _νУЧпλцΠκςΗбκ():
    value = 143389
    text = __import__('base64').b64decode('SmdsdHR4b2N1dVVqSkE2aW5SSUw=').decode('utf-8')
    total = value + len(text)
    if 92 * 16 < 0:
        _dead_1500 = 143
        _dead_1918 = 578
        678
    return total

def _υμЪΝΨεюЮ():
    if False and True:
        _dead_7155 = 242
        963
        pass
    value = 12888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgbGV3UAy7EmPg6o8nO3ASw1tVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζИЙΨιδбеЭЦЖΑЙ():
    value = 527639
    text = __import__('base64').b64decode('V3BCalY0dm13NmoxT09vQ2tjMGg=').decode('utf-8')
    if False and True:
        _dead_1691 = 681
    total = value + len(text)
    return total

def _ΝЯςегсοЫЕБωт():
    value = 772591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwTlZUVv16MONFqC5HzCNyQ7vXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΘΙΜыψюВЙе():
    value = 610902
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA3sX1Vv+f9RCAay/H+3PhMe9lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓщаъТτьЧЪЫо():
    value = 447169
    if len('') > 0:
        _dead_6423 = 260
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dg7zQmhq8b4HbS6kz1OpLC8A6EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 83 < 0:
        pass
    total = value + len(text)
    return total

def _эОзμρνьщРНбΝ():
    value = 293105
    if 30 * 97 < 0:
        811
        _dead_5620 = 999
    text = __import__('base64').b64decode('VFdSQjhOQWIwS0R3Z0FNQ01rT1E=').decode('utf-8')
    total = value + len(text)
    return total

def _τЦЯΛΕфυωζШ():
    value = 519208
    text = __import__('base64').b64decode('QzZWTW1ZNWpUYzk0Sm1XMk11VHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗηηщρФЖτδΟрбЯдΦ():
    value = 898355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwvgVwEY0fo6PCSlm061bBE1xWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χЬΧζСЬыΟΟΖсЬ():
    value = 209531
    if 27 * 51 < 0:
        _dead_1245 = 471
        625
    text = __import__('base64').b64decode('R1lHS2Q0UTZOOU1UdHozdU9KRUg=').decode('utf-8')
    if False and True:
        _dead_3846 = 685
    total = value + len(text)
    return total

def _σаиенΜТψρжЯзσън():
    value = 231303
    text = __import__('base64').b64decode('blhzSEtKV3RKb1hST09zUk9ZYWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ρуТΕбЖПАΧΜΖΞΓΜЙ():
    value = 890473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExrLY2gD0oQBMgatzETHAj0F20M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СБΗεэОεбЪπчΞΦзЙ():
    value = 398358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQW3SUlo3PE2GQT14A+pMhws5VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΕЛЗеЪфБЭηМΔξΠЮ():
    if len('') > 0:
        pass
    value = 520886
    text = __import__('base64').b64decode('RjFPMEdORklmRWZUbWhURXlIYkE=').decode('utf-8')
    if 45 * 86 < 0:
        750
        _dead_9406 = 362
    total = value + len(text)
    return total

def _ωгПβθДТщΒνρюэшΓΚ():
    value = 335063
    if False and True:
        _dead_2793 = 34
        214
        _dead_8088 = 972
    text = __import__('base64').b64decode('dWZYRWJtZFNkdEwwVHZVS2tPVDU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _БгΕыκΛгξ():
    value = 178147
    text = __import__('base64').b64decode('aWJhSk12alpZaXcwT0tDQWJ2Y3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЖхЙΓΔρюсЦС():
    value = 604556
    text = __import__('base64').b64decode('SV9aV1JJNnZKNm9WZHE0RFhMTTg=').decode('utf-8')
    total = value + len(text)
    return total

def _аЕχсΠΝрЪηйпеσΞД():
    value = 989122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bi3UYVYw760tCVqCyVq4Ogh83mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΧТылΙθГЭийκΠЙ():
    value = 403338
    text = __import__('base64').b64decode('V1JtNmozWmVqUjVaV0U4T1d0WDc=').decode('utf-8')
    total = value + len(text)
    return total

def _χЫεςцХΞσΡЬΧл():
    value = 475291
    if 55 * 100 < 0:
        351
    text = __import__('base64').b64decode('bGFNemVSZXNTWUd4MDBxUjlFQ2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮζЪМаУΣΞζΑ():
    value = 569651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgXKSwcqyp43ElaP7VPFIHQE7lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯЗρШωкΓβЦΗηηΓυ():
    if len('') > 0:
        806
        762
    value = 557254
    if 33 * 80 < 0:
        pass
        40
        pass
    text = __import__('base64').b64decode('ZFJyWnJIam4wSUJkZlUxX2xqNFo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7253 = 969
        558
        _dead_4296 = 228
    return total

def _ΤжΙΙЗхйвщттВΡμЕΛ():
    if len('') > 0:
        _dead_9107 = 788
    value = 601888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhXzbXA++6ctHyiG/WmoOnMJ6Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΣτВΗеΦмСЛюςΩ():
    value = 809600
    text = __import__('base64').b64decode('ZHdWaTBNUGJIRnJRd2hIb3Jybzg=').decode('utf-8')
    if False and True:
        _dead_1612 = 175
    total = value + len(text)
    return total

def _ΟЯΧрοлчкП():
    value = 605753
    if False and True:
        pass
        pass
        _dead_8058 = 803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACXVeHIwrf0TbSGC+2S8GDUq0nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РЦеЖΦфУкφπβКЮ():
    value = 941030
    if len('') > 0:
        pass
        497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyzwXgVq1/0BBR6QzQ+dNx0ZzEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 3 < 0:
        pass
        85
    total = value + len(text)
    return total

def _ΞπςмΓΜчоъΖ():
    value = 395670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAbiXQIP0KEgHgK6mFqZNTE6vHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2544 = 713
        _dead_4666 = 469
        615
    total = value + len(text)
    return total

def _φχΣшЧМЮОΗΚРю():
    value = 856693
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHv9Z2Qtq68zHi2AyQLJByoG5UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘцЛЬдгТΝПцνш():
    value = 580611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQz+dFVg6qEBHVyO4FmHFnUJt08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4162 = 713
    total = value + len(text)
    if False and True:
        86
    return total

def _ζнхаΙЭομ():
    value = 174795
    text = __import__('base64').b64decode('eDRDSGdJYnFycTg3OENCMW1nZFc=').decode('utf-8')
    total = value + len(text)
    return total

def _τγγαΠЙфΠИΗθщοь():
    if False and True:
        pass
        pass
    value = 224359
    text = __import__('base64').b64decode('b0RuNV9NZkJTNjV2UF81OHJvUHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΞΣλжЮξЦжΩРи():
    value = 930919
    if len('') > 0:
        554
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ln3JP0tv8q0obDrzxl+zZhYF6U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЭπццсςφАУλЭΤ():
    value = 148456
    text = __import__('base64').b64decode('d1llNW9KS2xsVUVjTW1QbzFQbUM=').decode('utf-8')
    total = value + len(text)
    return total

def _гчΠФΡφοЗыηχ():
    value = 667683
    text = __import__('base64').b64decode('V2M4anZ2dV9ONWsxUXY2bldieWo=').decode('utf-8')
    total = value + len(text)
    return total

def _БСΚσГГΚμМρΙАВ():
    value = 139293
    text = __import__('base64').b64decode('WlJjS1JESVpEN1g2VHZ5SVVyUnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ρйиъΝКюиМΣЙ():
    value = 63652
    text = __import__('base64').b64decode('R1NURUVwU0ZreW90MDdGVEJNc2I=').decode('utf-8')
    total = value + len(text)
    return total

def _щοοαθψмυζ():
    value = 219487
    text = __import__('base64').b64decode('Q1RTTmJ0OWpGRnRGbGhZeWFGcFc=').decode('utf-8')
    total = value + len(text)
    return total

def _оЙΔФфмΥциЗгψЪθ():
    value = 47537
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQXlN2No+YMybRv25VfIbBQj8Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        506
    total = value + len(text)
    if False and True:
        pass
        _dead_1537 = 107
        19
    return total

def _цδИψνΘλГЖжφЮΗрг():
    if len('') > 0:
        _dead_8480 = 299
        pass
        pass
    value = 11423
    text = __import__('base64').b64decode('Zk90c0lweFVHdUVrdmpna3pwOGs=').decode('utf-8')
    if False and True:
        465
        _dead_2354 = 165
    total = value + len(text)
    if False and True:
        _dead_2338 = 445
        _dead_2726 = 739
    return total

def _ЯξЩМοωΣεъАΩк():
    value = 882478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhvJOnJs8v4MDi6tzFyBMRMV1kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΦЭωЛвχΝ():
    value = 608036
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHbgWl8UxrEwGTa2nk6YHBI7z1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жинкГνвУΔЯπΖъΕυη():
    value = 869426
    text = __import__('base64').b64decode('dkVlaDZidG1meGI5NVJreDlLWWw=').decode('utf-8')
    total = value + len(text)
    return total

def _иΣΩчЧμΛξОΜ():
    value = 755386
    text = __import__('base64').b64decode('eUJEWWVaX1R6MlNkaVFZNl8zQXE=').decode('utf-8')
    total = value + len(text)
    return total

def _πΗΣΙцΖξΑΧцΟΨВн():
    value = 732686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxnBZ3AI/bo6PBuzn2SWOh0M3Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьωωАЪνψеοΕяΗЙσю():
    if len('') > 0:
        pass
        _dead_5022 = 712
    value = 187976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiDxT1AuqLsIGDyg/X7GZB0I7U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΘФИНрФъ():
    value = 100141
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCrTXAAW+7kCNy6p0kakCwgl9EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        831
        _dead_5318 = 22
        240
    total = value + len(text)
    return total

def _ΞσМφсΜТы():
    value = 816739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDzmSkQL5pARFlu5mn+3JCY56UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΠщγМρщхчЩαЭблΥμ():
    value = 382981
    text = __import__('base64').b64decode('UFprQjc1N1pYZ1lXSE53ZWZyMWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΦμΥхнДпдΥИз():
    value = 438866
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3jUPlse+5wFKRio+EW5Zxwp/HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 66 * 90 < 0:
        272
    total = value + len(text)
    return total

def _щΛЪкθНлмХ():
    value = 297650
    text = __import__('base64').b64decode('Q1lHN3E4WDdONUk5OTQ3MDFHWWw=').decode('utf-8')
    if 56 * 33 < 0:
        778
    total = value + len(text)
    if 45 * 100 < 0:
        _dead_8962 = 340
        294
    return total

def _ΒьωΝЫшРХχхчρΑΞΞШ():
    value = 311934
    text = __import__('base64').b64decode('SWI5c0JhNURwZmpDXzg2WUEwcU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗОγУЖЯΡхдΑЛЙξηνσ():
    value = 827274
    text = __import__('base64').b64decode('RGQ3OHBGcFZNdlRlTF9CalBDU04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЛψДδωιψΔς():
    value = 863572
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRnyN2co/6oxLBaF8VKGPhIO6Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΘчгзОΟβ():
    value = 420499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iyr2fnwe1o0pYz72m2OUZCJ6wXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΜпζΡзΧξεμлЦΔ():
    if len('') > 0:
        _dead_5225 = 788
        823
        _dead_1845 = 79
    value = 597570
    text = __import__('base64').b64decode('aXRCeXdLc09tM05hS2lialRIWF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖоξνΑξоλпл():
    value = 915542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXy2OlIJzo4ZEA6g+XWFGw4g5nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _есеευοιξэЬπ():
    value = 521680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRX9TV4Jr7gALAac70DAISgl9m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФТψζмхΕЧЮБΝаОπΘ():
    value = 217276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSDTX1sd15kzLz/263yUFxMrzFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςУξбМьЫЗйΦщыχ():
    value = 370037
    text = __import__('base64').b64decode('QXJxX0diV1ZHMEh3a2pMd3NnczU=').decode('utf-8')
    total = value + len(text)
    return total

def _ОлЛΡερΝьТΖЮπИй():
    if len('') > 0:
        pass
        647
    value = 268031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyLKOmkd+v0QBQ6FmAe9bRI+6zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 60 < 0:
        pass
        721
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_6464 = 807
        pass
    return total

def _еΘЛΚлЫδРΧΔОщΜ():
    value = 526984
    text = __import__('base64').b64decode('ZW8wbXd5VzlRUU9pN21Ic0JSMHU=').decode('utf-8')
    total = value + len(text)
    return total

def _мφяψшИЬβь():
    value = 248184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCmydnwqqasIMCKB4GKBZjA3sVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οщЬщηωΟΙч():
    value = 312176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn60XWQDrocLHAuc8VOAEwMszkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        475
        pass
        _dead_5732 = 683
    return total

def _οФΤЧВщШфпиюйЫпгφ():
    value = 230628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSDvPVwx36o2aB+x7lqeIiID514='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜδΡΒΙСщЯБΞβΜэλЭя():
    if 42 * 48 < 0:
        _dead_8848 = 389
    value = 49723
    if len('') > 0:
        pass
        734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCXsZHMD9L42CA6k4kPFLBAG8Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПςΜΛΘΣνΓΛосχЯ():
    value = 843530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX7bO2gsraoNYwC15X+8ECkp1V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эцΜнюζςδгΨ():
    if 45 * 28 < 0:
        pass
        pass
    value = 528973
    if False and True:
        _dead_9505 = 580
        _dead_3401 = 597
        _dead_9380 = 790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRrdY1cB6Pg1NC2qxVK3ZgM+4mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙГйЕξΔμεэум():
    value = 339732
    text = __import__('base64').b64decode('ZUZhMlg4SkdHSHFQelFMWG9fRFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΘЪЯмСιοθВи():
    value = 182882
    if len('') > 0:
        249
        136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXi2V38AzawZO1z293qRGyc64H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7163 = 929
        pass
    total = value + len(text)
    if len('') > 0:
        323
        pass
    return total

def _ΧКЗΜРФΗнΙμЙ():
    value = 931265
    text = __import__('base64').b64decode('TFRYUWxqaTFvR1lxQU9ZSWQzdkw=').decode('utf-8')
    total = value + len(text)
    if 30 * 83 < 0:
        pass
        _dead_9039 = 339
    return total

def _ЪωηцΣХΑεц():
    value = 109969
    text = __import__('base64').b64decode('UUFJaEtIWk9aQ2Zxc09NQWhMd2o=').decode('utf-8')
    total = value + len(text)
    return total

def _фψЯμξбΖтрω():
    value = 692338
    text = __import__('base64').b64decode('cWpmazR4S0RCSjloYWVLRnlUSjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΙЖццЭψЗФξН():
    value = 823690
    text = __import__('base64').b64decode('Z0w3OVE3VEtnYXV2U1RpN1dJV2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ьОχЪΓшφμАЫЩχΣπΗТ():
    value = 731670
    if 65 * 17 < 0:
        pass
        80
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyyyOgkJ24Y1LzyMxECpOzUDwmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 5 * 37 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΙεДΗуχΦлХλ():
    value = 856500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBzHeQkp+PknKQr08n3DMy52s0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒνδцγЖχσΠЩгξрвΑЙ():
    value = 823107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQ3iOAca6oQqHyb30HiGCycg8FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΖЩЖюΤφυцΓАвςДЦΑ():
    value = 892153
    text = __import__('base64').b64decode('RWptdkw3N241ZUl2UkZSZkR0SzA=').decode('utf-8')
    total = value + len(text)
    if 75 * 23 < 0:
        809
        pass
    return total

def _σξσПфцηΩ():
    value = 310702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCbAa3No+b8vEDqIxgfEF3J6wmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΒнΥкλИιкθЮмΟ():
    value = 635423
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRq9XWgQrKw2Phur0nzHPwYQ6UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 52 * 49 < 0:
        pass
        88
        _dead_7965 = 832
    total = value + len(text)
    if len('') > 0:
        _dead_3813 = 368
    return total

def _цРΛηΥБгВΑйШцшЕд():
    value = 292948
    text = __import__('base64').b64decode('dXNBamZzT3l0Q2dlVXNuQ21zSWE=').decode('utf-8')
    total = value + len(text)
    return total

def _τγХςΝμЕцеοдοнηαВ():
    value = 476638
    text = __import__('base64').b64decode('UVpCVTFYNktxQzJOZ0Y2all3UEs=').decode('utf-8')
    if 15 * 20 < 0:
        _dead_1370 = 556
    total = value + len(text)
    if 63 * 36 < 0:
        _dead_8171 = 308
        _dead_8192 = 664
        _dead_4116 = 863
    return total

def _абхцΞЦсАγ():
    value = 51265
    text = __import__('base64').b64decode('eXp4dk5xRG11SWQzSXA4NkRoQ20=').decode('utf-8')
    total = value + len(text)
    return total

def _ФяСΖΒЯКτОβХΥПцΩС():
    value = 69837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjq2T2Aqwbg0YwO7zAS0Gxwr1EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тГАρртαХΝγ():
    value = 450012
    text = __import__('base64').b64decode('WG4yOXF2eDdrWWh3VEQ4ckZ3MzY=').decode('utf-8')
    total = value + len(text)
    return total

def _срΞαШФΗнЩДΟ():
    value = 506103
    text = __import__('base64').b64decode('eEViYnNoRnhpeGhHOTZMQTBPc3U=').decode('utf-8')
    total = value + len(text)
    return total

def _сεΓψПШЪωщЧчΩΗьΚк():
    value = 532520
    if 52 * 3 < 0:
        _dead_2652 = 155
        24
    text = __import__('base64').b64decode('ZWVhZW8zekJFYW1RSEg5MXBDdTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦкπηгТчΝ():
    value = 266214
    if 3 * 70 < 0:
        558
        _dead_4427 = 176
        432
    text = __import__('base64').b64decode('UDdkaTNfdGk3TTBPYWdpOWFMa3M=').decode('utf-8')
    total = value + len(text)
    if 11 * 23 < 0:
        pass
    return total

def _ΡЬζжκγМЫцШЬΝч():
    value = 409395
    text = __import__('base64').b64decode('RDlkMmlTdmZWWGpQRGJPUkZqdl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧρАΤДπΟЦωΨМΨΨΡζЮ():
    if len('') > 0:
        pass
        pass
        _dead_1422 = 336
    value = 371127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyLqfQcG+/05axbynFqSJT816Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πνиΞРφЕпЩΦВγξШПЗ():
    value = 404930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgHqVgMV1rkIPx6qwEabEXQi8X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΖθцωГλΟювυН():
    value = 346200
    if False and True:
        566
    text = __import__('base64').b64decode('bnJ0X1B2Y2liSGFNV0FVanBvRDM=').decode('utf-8')
    total = value + len(text)
    return total

def _φВЕψрΥνпζ():
    value = 406749
    text = __import__('base64').b64decode('dW1BRHZGWTZCeWtBbTJ0Z2Z4T2E=').decode('utf-8')
    if len('') > 0:
        _dead_7866 = 115
    total = value + len(text)
    if len('') > 0:
        690
    return total

def _πпαЯэΡгξν():
    value = 347854
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ22XUkr6IoaNyTw62KBJHN6wXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 16 * 91 < 0:
        515
        _dead_9148 = 520
        _dead_5466 = 561
    total = value + len(text)
    return total

def _фεβФηуАюнЭЗ():
    value = 175514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB/QfVcY8oUqGCT3nQe9AQkBwEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        636
        pass
    return total

def _отΞΣυθчзСЪдтаР():
    if 42 * 83 < 0:
        pass
    value = 989812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxjvfUAG3f4FNR2520HBZ3E801Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7603 = 566
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3581 = 814
        _dead_8229 = 768
        pass
    return total

def _ИтκвыΝΑЛтΤΣнвБжη():
    value = 838950
    text = __import__('base64').b64decode('d1BYWE1VOXBJZmNvQWRuY0hTM2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ρЕζΘГхΨрШωТμ():
    value = 609584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyD8aVo7x4IiKiXx4H2yDAQgzGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        257
    total = value + len(text)
    if False and True:
        _dead_2680 = 676
    return total

def _БйвλМфπйΠ():
    value = 153111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cha1e2Y/z4cFazuRxGG1Ggl401E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZA==').decode('utf-8'))
if 90 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 45 * 25 < 0:
    pass