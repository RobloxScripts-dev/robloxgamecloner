#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _μΓЙАКвζйη():
    value = 838063
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnnPXHtsr6kuD1aLwmKnOxF+/Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΨχΔаАΣМвιαΒΙз():
    value = 607993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAPUen4T1qcIAgub4kSnF3Z28nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΗзΘЕнβποй():
    value = 43487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHu2OkMj3YQyBRu0/ly0PHUA4j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΜζХΔπТЙ():
    value = 153487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ER3oXFo/yPEQaj6P7kOCEiAotEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9570 = 193
        153
        _dead_2021 = 302
    return total

def _ДΟΓιэхъΩΥΒΥΕц():
    value = 289164
    if len('') > 0:
        _dead_3665 = 467
        pass
    text = __import__('base64').b64decode('SVk4bjI4UUZXWmVQR3VRd2REX18=').decode('utf-8')
    if False and True:
        _dead_8594 = 51
    total = value + len(text)
    if len('') > 0:
        _dead_1562 = 422
        pass
    return total

def _ΝНΖξЛНΙеΠωΛфр():
    value = 600022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj3dSXQ+0Z4HbB+v6kSWOwE78WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хАЩΞЭьЖΣоуЗПВЛυ():
    value = 115107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhzUN3gq2/laMVmE+0CzHwMN514='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧПЧΗеИпнΦкΔ():
    value = 401107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCHxawUA5rwxNCuH2FLAZzI56n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗнνФΧайКыΖЩШΗ():
    value = 655690
    text = __import__('base64').b64decode('VUhrZFJ0ZGFQTF83OE5abEJwNDg=').decode('utf-8')
    if 95 * 92 < 0:
        pass
        359
        pass
    total = value + len(text)
    if False and True:
        _dead_8392 = 191
        439
        818
    return total

def _οюυГКдЬйжΧрΣр():
    if len('') > 0:
        _dead_1890 = 460
        598
        _dead_6003 = 344
    value = 964071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBrOewE02PEQYhaEmQelPgl2z3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        7
        pass
        pass
    total = value + len(text)
    return total

def _ξЪτвΟΜЕω():
    value = 981822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAboVFgK1K0zNVuc8GKiDQ0Yskk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ωЪμшНФеβхАЬгЛ():
    value = 84486
    text = __import__('base64').b64decode('bkhwZUFLWGg0QlpzaTBnYVdZelU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6301 = 540
    return total

def _ЙъΤДгυσнα():
    value = 844972
    text = __import__('base64').b64decode('bUVUX1pWRnh0U0laOEtZZzlNdXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΜΘнГЕаΓ():
    value = 275249
    text = __import__('base64').b64decode('aXhGVnduSHRaZnBFNkExbXRRVFU=').decode('utf-8')
    total = value + len(text)
    return total

def _нЛиαгЪΘθ():
    if 66 * 6 < 0:
        pass
        432
        724
    value = 630609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXe1dwAJ3LoiHyCAm3+pCyIp/E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цВрΖτЪУеоΝэИΝι():
    value = 665990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ijr+RVxt9IMHLl6wnFKFITQm3jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖлχыЦΙХΝТθлνΩ():
    value = 383542
    text = __import__('base64').b64decode('cWQwNDZCa1F6MHVwcDQ4X0dDNW0=').decode('utf-8')
    total = value + len(text)
    return total

def _вбΣзειхπЖ():
    if False and True:
        335
        pass
        pass
    value = 501885
    text = __import__('base64').b64decode('ck1raTdPRVZ6SWY4X3BUYW4xWjY=').decode('utf-8')
    if 25 * 40 < 0:
        _dead_2964 = 643
        _dead_7100 = 741
    total = value + len(text)
    return total

def _ДЩΜгΥвдэκψνΚАκн():
    value = 975184
    text = __import__('base64').b64decode('TzZMVzlyWFpFZ0JWN1RJR0FPcVQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4834 = 285
        465
    return total

def _ВΜζΧМχυиαχΟъυΓ():
    if len('') > 0:
        713
        _dead_3624 = 33
    value = 81304
    text = __import__('base64').b64decode('aG1WMURuNjRiYWpVenVTeHBXcXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _СТоГшлΕЮφЛж():
    value = 562471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjfCXnsY94NUPwrx7gepP3wKsEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9277 = 622
        pass
        pass
    total = value + len(text)
    return total

def _ΙфμХТΨΡпысЩЯС():
    value = 396330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnnefFAL9a4iayWO8lfDMjE/yF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΣζяЛфΧУшцблγ():
    value = 697355
    if 55 * 89 < 0:
        286
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTq1elkX14ktKl/z2kWABgh90VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪφпъφвΨρНХСΘУ():
    value = 924822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTj0SkI89oACKhaS51LDAAd6tW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υДьΘΟЕζΘδЬЕя():
    value = 581226
    text = __import__('base64').b64decode('T0xKTjRZQ1pkNTJvaFdud3BQbng=').decode('utf-8')
    total = value + len(text)
    return total

def _мрΥШЮЛЭбΔужψ():
    value = 317489
    text = __import__('base64').b64decode('d0lfaVFDN1p2ZGdtb0U0R3oxTEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪНςиαмЪεшь():
    if False and True:
        _dead_6762 = 914
        pass
    value = 272494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhDqdlI91IlXGTau+FWePiMnvGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЗΖσчрΤкαрβЧФΕЖρν():
    value = 332439
    text = __import__('base64').b64decode('aDVXTlV0Q0dRTnpzVXVxWHB5cXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΔΑЭлтΖαΘΠЫФадЭΦ():
    value = 622720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JynRRmYw858pawS1wleaNR0+9Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КμπмЧεзЯφби():
    value = 381112
    text = __import__('base64').b64decode('dUVOX0dkTkxJN3J2THJRN09Ja3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘηΡΡΡУанμΖξШ():
    value = 561836
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgXJX1kf/P1aEiGH2VmjJCE/03Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΝОЛσшφεъЛЪъ():
    if len('') > 0:
        pass
    value = 643873
    text = __import__('base64').b64decode('SlBLeGQ5ZlB0bDlkaWNXUXk1Q3c=').decode('utf-8')
    total = value + len(text)
    return total

def _РρАвсαηΛб():
    value = 67590
    if 64 * 14 < 0:
        _dead_3106 = 472
        252
        _dead_8877 = 16
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ni7LfmAVyP5WBQWBygedNRp3xX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 57 * 56 < 0:
        126
        pass
    return total

def _λнБεАπюп():
    if 72 * 57 < 0:
        40
        155
        698
    value = 877510
    text = __import__('base64').b64decode('T1RKTnVwamJPaEMzUHpfNkNNRjI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        546
        498
        _dead_4964 = 650
    return total

def _КΒбШкΗγσεеЕфΒΖЪ():
    value = 522846
    text = __import__('base64').b64decode('aDFaNGlYUTZBeGN2U09iX0JDOXY=').decode('utf-8')
    total = value + len(text)
    return total

def _КψтыЖψмχ():
    if len('') > 0:
        _dead_5248 = 475
        pass
        375
    value = 603818
    text = __import__('base64').b64decode('S1NUVnNxMGlxNVhIOGRQcFdxbnk=').decode('utf-8')
    if len('') > 0:
        _dead_3072 = 423
    total = value + len(text)
    return total

def _φЦЙЗγΑиκшΙ():
    value = 759212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgrmTwMQ1ZgLO12X3XiBFzAqskQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟзыэΜΙьΩлΤэζ():
    value = 46033
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDrcXVsRpowCHQPw3gCSMys/6Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВνнΥнхвж():
    value = 897262
    text = __import__('base64').b64decode('akplSDB1ZnJ1RGdPa3N4VnVYYkk=').decode('utf-8')
    total = value + len(text)
    return total

def _вФъШασпФΗΑνш():
    value = 389079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fwn9RHZt+f8wYjmQwFq4YyMq92Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аλΓЩьλФΕЙовΧ():
    value = 297908
    text = __import__('base64').b64decode('Y1J0NVRUS21rY1VueWFMMnZhc1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _δЖΘЬΙсδιυΣζφΗЗη():
    if len('') > 0:
        _dead_9753 = 174
        _dead_8149 = 260
        319
    value = 292947
    if 69 * 7 < 0:
        _dead_4147 = 431
        _dead_3439 = 220
    text = __import__('base64').b64decode('czBfUldFejJxem5UdThVOTBQZmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΒнуБΗЯъυΦσГεпйК():
    value = 280932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn7JYEs++Z5XBSCh/1GYH3Me3Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кЧΩШикЛМ():
    value = 12170
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgPmPFwI5r0iLAqi4UDGPgolsWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 43 * 39 < 0:
        pass
        pass
        231
    return total

def _ИΦФΓЬιΣΑПΛ():
    value = 988184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh/oaEZpq40TKyTx7FjFMSQd1D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        573
    total = value + len(text)
    return total

def _ЬхЭОеδφМВу():
    value = 18062
    text = __import__('base64').b64decode('Ul9LaWlETWhDV0RWYkthOUtJZ3Y=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _χАжΗРυЕуЦрТГΚΣ():
    value = 76344
    text = __import__('base64').b64decode('dXpvbmxKNDhCcHBrU0NvQ2xnazQ=').decode('utf-8')
    if 89 * 40 < 0:
        923
        _dead_1483 = 576
    total = value + len(text)
    return total

def _θвжψЦЗψψЧΡγΒ():
    if False and True:
        490
        pass
    value = 934581
    text = __import__('base64').b64decode('UldRemoyZlhfREdVck54aGVFMU8=').decode('utf-8')
    total = value + len(text)
    return total

def _нфШАтΣэХμΦОνТβΩ():
    if False and True:
        _dead_9869 = 418
        pass
    value = 205513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCTzQn0W9vsuOQa063SBJjU6/GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΝптЮηЭзτтс():
    value = 511323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH/LfFg03a0MGyKi2maKLgsl0UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΑЗЛДΚΑЭЬЯΤΡ():
    value = 175624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3a9OlcrxLE3DF260ge/AQF41Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΖГкСКЙΖΣНпЦ():
    value = 594166
    text = __import__('base64').b64decode('SzFRV0NMYkY1ZXlEVUVLZVhSUTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΓЮΟЙзмпΤΩтΙЪ():
    if len('') > 0:
        _dead_2146 = 53
    value = 32191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzzNXAYL07shDRaw236WEBYN8VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЛОΔψГкОЦ():
    value = 587683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQzxYn8o1YQaBQCk/GaXHCZ4zjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΩψΚβγεξΛцο():
    value = 548658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDzDVkgU0aNROzeGxnGXBDY23X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2250 = 858
    total = value + len(text)
    return total

def _СЯΡθЛВкШΑρцσЯρ():
    value = 684277
    text = __import__('base64').b64decode('Q2lPVHBpVkF3RXdOVVB4elFucXQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        880
    return total

def _ЦуцιΕοиΠδвтΝΝ():
    value = 297320
    if len('') > 0:
        _dead_8445 = 995
        390
    text = __import__('base64').b64decode('dFpKWW05eU1OSDNlR29lSVRsWFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЭЛНАΜΗπΡΘΒηΣ():
    value = 956766
    text = __import__('base64').b64decode('WDZtczd4SWNkeWdwd25uNENkcEM=').decode('utf-8')
    total = value + len(text)
    return total

def _МнМθРыдсνСмЖКж():
    value = 276936
    text = __import__('base64').b64decode('TDJKbWNad24zeXpXWVBiWXBrQ28=').decode('utf-8')
    if 77 * 87 < 0:
        _dead_2454 = 941
        0
        pass
    total = value + len(text)
    return total

def _тΠЖτΘφГчΟωΦιοΖΜτ():
    value = 225989
    text = __import__('base64').b64decode('RUNrUndwSHFpV3lKRVk2SjZWdUY=').decode('utf-8')
    total = value + len(text)
    return total

def _чШГςΨθЧнхПфυэлДА():
    value = 126802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCj0fmgR06YFDSaqwH2AZAoO6GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6413 = 484
    return total

def _φяΖЛζБΙΔя():
    value = 189319
    text = __import__('base64').b64decode('dXNfZEI4X2c1N3hKZGszMTJnZUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _еΡχΠОРсτдξ():
    value = 961536
    text = __import__('base64').b64decode('U1hyS0w4VWdVQzNydmx4REV3cko=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦρζбсζЯφΧШБδΕц():
    if 5 * 21 < 0:
        _dead_6828 = 723
        _dead_2831 = 530
    value = 240369
    if len('') > 0:
        pass
        pass
        180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAvKN3AQr5ASNzz35GbHPwc64n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δЛОэχξЗΨΛЬлшъНχο():
    value = 261161
    text = __import__('base64').b64decode('QkxZd3JUTXNlM1M0UUpFMnF3Z0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ШяφΜГЗλЧкΗЖΡВη():
    value = 815181
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTvCQUUQ7KlWOCOl5kyzIXwc9XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 72 * 29 < 0:
        _dead_3734 = 161
    total = value + len(text)
    if False and True:
        _dead_4814 = 811
        674
    return total

def _ивгΘЯψвлуμиΣСΓ():
    value = 805058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgfDfkYV/YIAaiyFwn+bByJ3tlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛδБхбπЭэ():
    value = 233688
    if len('') > 0:
        pass
        805
    text = __import__('base64').b64decode('T0VVTUtsS2dlam9lNE1kdmpnS2E=').decode('utf-8')
    if len('') > 0:
        148
        pass
        570
    total = value + len(text)
    return total

def _σψэХьςοΟνРΠхΔξΙ():
    value = 286636
    text = __import__('base64').b64decode('dzR3S3FlV3phV2pzakdmU2RSajY=').decode('utf-8')
    total = value + len(text)
    return total

def _οсΝлΑβюξΠФнΡа():
    value = 815967
    text = __import__('base64').b64decode('amlyeGFFZXFNX244SV84SV9ScDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ХрыιρνГθй():
    value = 296606
    text = __import__('base64').b64decode('SWNKRzZzZEw3am9yajdDRUpqUVg=').decode('utf-8')
    if False and True:
        pass
        _dead_6337 = 227
    total = value + len(text)
    return total

def _ЮгΘЮσΛкλΝЙ():
    value = 240510
    text = __import__('base64').b64decode('SmU2VTJwTDJxeFM2NGh1ZUI0V20=').decode('utf-8')
    total = value + len(text)
    if 47 * 94 < 0:
        _dead_4075 = 170
    return total

def _йЩΦμзΥΜАΘмфΓιρНН():
    value = 635762
    text = __import__('base64').b64decode('dWluODZuakJWMU1BUXlfYWwzN2M=').decode('utf-8')
    if len('') > 0:
        _dead_2530 = 189
    total = value + len(text)
    if False and True:
        pass
    return total

def _кюΓЖЗυΨРчЪΥЫдмР():
    value = 532664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCW3XnI194c0GAPz2Xe+YRIExlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥчэΦΠВζΗрΡД():
    value = 627951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwO1WVMI778AKluZ+W+9Jx0jyXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ичЯΙΡΘκАΛуΡрΙЯхΑ():
    value = 130401
    text = __import__('base64').b64decode('ZWc2WEFOakNTMU9NcWlJcXVwY1o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        119
        352
    return total

def _иНΟИчΨКы():
    value = 864556
    if 29 * 62 < 0:
        420
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JibIY2EUy6o3Ox+o0V7HISsbyW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 23 < 0:
        _dead_7431 = 604
        325
        pass
    total = value + len(text)
    return total

def _вΦσНФНΝЖΕξ():
    if 9 * 54 < 0:
        536
        _dead_8576 = 1
    value = 974605
    text = __import__('base64').b64decode('anpFZllJcWVqSW9GTHZZWGZlcHE=').decode('utf-8')
    if len('') > 0:
        _dead_4791 = 460
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _АЯмгДмΠζУНθе():
    value = 283903
    text = __import__('base64').b64decode('Ynp2NXVVN25yRzY2TWxjUWZxWmk=').decode('utf-8')
    total = value + len(text)
    if 52 * 25 < 0:
        pass
    return total

def _ΞЯТθлμУοΚлкГΒо():
    value = 597458
    if len('') > 0:
        337
        335
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Exf0bHYV7/grLB6b5nPDIDMt1nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΞμφΧΚппκЙЮмВΦ():
    value = 851578
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB/zSEI1774NPiOB4ky5HR0Ow2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤθΟШςζЬΚыкНГ():
    if 73 * 45 < 0:
        _dead_8593 = 406
        907
    value = 532587
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDfWbHQRxJ0Wb1uQnUGyAQg50GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТШЗфЪΒΥзμГБмОΨΝΠ():
    value = 840770
    text = __import__('base64').b64decode('TzE0X2dXMmNNS1JoU3pUeHB1TjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗκχρΗнлμαэυ():
    value = 759999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT/nX2YJ2LgOMgeE3H6mDDF9vFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 80 * 39 < 0:
        pass
        _dead_5407 = 64
        _dead_3623 = 509
    return total

def _οИΣзοΩЙОςобфХΔя():
    if 57 * 47 < 0:
        _dead_7400 = 612
        _dead_3372 = 542
        331
    value = 818769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn/MNgAf76wIDyex3l/HHCQr92E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вчЭЙζнθЙχяОТβΞ():
    if False and True:
        pass
    value = 67848
    if 88 * 94 < 0:
        _dead_8824 = 910
    text = __import__('base64').b64decode('czQ0YWlEXzdJbHllclEwX21kWnU=').decode('utf-8')
    if 25 * 54 < 0:
        644
    total = value + len(text)
    return total

def _ЗтωгθЧноςбθ():
    value = 290053
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('SUtEYzlUWUZwTHdYamJxT3AyNTY=').decode('utf-8')
    if False and True:
        _dead_7067 = 816
    total = value + len(text)
    if len('') > 0:
        425
    return total

def _ЬбщыΘΕЬА():
    value = 857366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCLxZ3AK6o0iCV+hy2HBMDQm/Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βγЙтИЛГЗЛλъΠΖ():
    if False and True:
        pass
        pass
    value = 958278
    if False and True:
        pass
        841
        773
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSjwfH5gxpkwPyeLnkCkLgoltlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _РАιΡΗПЫТФΙШυФΥлц():
    value = 502385
    text = __import__('base64').b64decode('bWh4UHhBdEkxOWxNX2ZUd0ZyWl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓэнιΡоЪНЧΛ():
    value = 198166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQDgREgV+PgGPQSi4AbCDiAc8j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9885 = 957
        648
        969
    total = value + len(text)
    if 62 * 45 < 0:
        _dead_3763 = 700
        pass
        _dead_9260 = 118
    return total

def _ВЖюπΨθψВхиχκИΙΛγ():
    value = 514187
    text = __import__('base64').b64decode('Z2JKWHdNYzkzVFZBbTUzeVBQOXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЯбνКоЕΡУвΞчσΣъ():
    if 88 * 28 < 0:
        _dead_5338 = 864
        _dead_6747 = 396
        pass
    value = 326537
    text = __import__('base64').b64decode('b3FGeW1oYTltT01xb2xEcXpJczQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ыЖнДξηТρЖι():
    value = 642752
    text = __import__('base64').b64decode('RFJTQV9aZ2dTbHVrN25NYVAzN0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙβλЛΚΛΒнаНн():
    if False and True:
        _dead_4410 = 81
        277
        _dead_8991 = 84
    value = 289378
    text = __import__('base64').b64decode('R3hoSE1RMVpodk1qZlV4djUwbnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙцпржняαЦЕΕж():
    if len('') > 0:
        _dead_3908 = 534
        _dead_9183 = 246
        pass
    value = 55479
    text = __import__('base64').b64decode('VDlmZ0hRdFVWVUxNWEY2TURXYUo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΣЫαыζΤБО():
    value = 271238
    text = __import__('base64').b64decode('c1RmQmZEM0RZNmNkQnFxdTFMZ0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤХΝΙФоеШπΨΛп():
    value = 896928
    text = __import__('base64').b64decode('eEV6RWFwNTFRNDNNTUFaU0tEaTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧхеиιЧξщτδЖΚмП():
    value = 392710
    text = __import__('base64').b64decode('QkZjUDk5cEpTd25KSVFiN3gwWnM=').decode('utf-8')
    total = value + len(text)
    return total

def _оЮПХЧЮςσ():
    value = 589120
    text = __import__('base64').b64decode('U0k2a2FaWnpIWXNhTHZ3UnREOUk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1457 = 872
        876
    return total

def _ИΝΠцωиτб():
    if 80 * 61 < 0:
        _dead_4795 = 358
        980
        pass
    value = 284496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgPRQkY33LhRPluqn0W0Bg4l120='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЦимЮιΙцαΣΓ():
    value = 221083
    if len('') > 0:
        _dead_8551 = 846
        408
    text = __import__('base64').b64decode('dWZYUTZyZE9nU0NtRGJSRzZRVUs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1301 = 174
        754
    return total

def _ЪηкΤШхоЙЪ():
    value = 624614
    text = __import__('base64').b64decode('cldnUmVheFluSUZncE56ams2cno=').decode('utf-8')
    total = value + len(text)
    return total

def _АЭкцУТДеς():
    value = 919680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABj1RHcAxqYlNTeG8HeJIS8o40k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΥнΙΑосΓяшЮлЖ():
    value = 11892
    text = __import__('base64').b64decode('akY5WUVtQXVQdnBpa21LZzdCTFE=').decode('utf-8')
    total = value + len(text)
    return total

def _лОтφξЯлЯВΡКΟ():
    value = 167096
    if 87 * 55 < 0:
        181
        _dead_5866 = 168
    text = __import__('base64').b64decode('QVZ3WndkcDJQZHVyZUZzUVdGVEc=').decode('utf-8')
    if 58 * 51 < 0:
        26
        _dead_2438 = 702
        pass
    total = value + len(text)
    return total

def _ГΑгυΚеΒΚэжЫυΡΟх():
    value = 332010
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E37sYAVq6a5UPxaw+16yZTF50jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΟхЩΕЙыНβхКоТЛС():
    value = 904012
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Egz0dFIo0JAFNhavmkLICwMOxk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΝяδЙμЖснайЗЕΦ():
    value = 180472
    text = __import__('base64').b64decode('WTlmeGt1T250dlNRNWhlTjN1R0E=').decode('utf-8')
    total = value + len(text)
    return total

def _κбνΕγΜΖΞЛЧйдΛЫ():
    value = 156304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzrTbGAUzpEHaSyMm2WeDicC114='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        983
        280
    return total

def _ЬΛьΟПАπйεηядъэЫЧ():
    value = 125416
    if 39 * 32 < 0:
        728
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AS7LQ3s336UvYyyoyQ6GDAkN1E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЙΘερеλφЩЗвΖπДйμ():
    value = 433812
    if 68 * 75 < 0:
        613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBn8R2Uz9Yo0Cz+F0USnH3F8s00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_7003 = 14
        pass
    return total

def _шνгШΙМθεЗ():
    value = 328864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P37CNnMD7Z4PAgSM6gCnGSR+/kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЕцΟкЭΣΛщ():
    value = 977653
    if False and True:
        _dead_6138 = 203
        _dead_9702 = 666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kj7PQHJt0Y5aLzWvyUGDAyk+0mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        134
    total = value + len(text)
    return total

def _фшΟЯпьΜοΤΗркЧЫ():
    value = 987404
    if 5 * 80 < 0:
        pass
        pass
    text = __import__('base64').b64decode('aGEyMG9EQjFidVVJVkVtS0dSQzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣωнΔжехκ():
    value = 860874
    if 32 * 46 < 0:
        _dead_4421 = 415
        _dead_7706 = 953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyDpPEIqy6Q0CRa00W+CNXI5sU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if 68 * 80 < 0:
        799
        460
        _dead_4061 = 104
    return total

def _ΨΒШτпΚдρδ():
    value = 496246
    text = __import__('base64').b64decode('V2pCN2VGYXVWQVVfdXdpRXVKeGQ=').decode('utf-8')
    if len('') > 0:
        650
    total = value + len(text)
    return total

def _ФσБεцъΑξрМщΩ():
    if len('') > 0:
        _dead_1667 = 435
        _dead_7612 = 40
    value = 211125
    text = __import__('base64').b64decode('eklCcVJZTVRzS1ExUGQ5V2tPekI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΛЦНхТХηΧΓΠςΧа():
    value = 78921
    text = __import__('base64').b64decode('em1nNDlEOVFUaDJUX2pIbmRHX2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑШцχэДΕΑσ():
    value = 561171
    text = __import__('base64').b64decode('WG5xTWxoWGVwbFZ6RHZQNHQxa24=').decode('utf-8')
    if len('') > 0:
        477
    total = value + len(text)
    if 9 * 32 < 0:
        353
    return total

def _ΖξΠτΛιςэψЭжΥи():
    value = 554147
    if len('') > 0:
        355
        pass
        _dead_3271 = 782
    text = __import__('base64').b64decode('c3QzNXBHbUp5bG5DcWZYX3B6UU8=').decode('utf-8')
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ьВъбЛιυСΩцяΘψ():
    value = 256688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HC78ZlQL2P8LMziZ3UTJLRMixj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПςьФЭΘΨмКΕГК():
    value = 692260
    text = __import__('base64').b64decode('aWpwYXJJN001M1hlckdXVnBZVWU=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _КΨЛΒеξαШΩЩπКпч():
    value = 753127
    text = __import__('base64').b64decode('UTJzQVNWQ084c0R4aXl5dWxBaGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬνΧъηГΦюςрФφθ():
    value = 44999
    if 72 * 83 < 0:
        752
        _dead_8041 = 23
    text = __import__('base64').b64decode('bjFaUlhJdmRjU1dZaFdVcHZFbG8=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3778 = 834
        816
        723
    return total

def _рИуДΨРхДζЖцυрΓ():
    value = 720479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhW3YFcs5LoEHDyLy0SvbQ9/5Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡРΧВнНМγхΛΖ():
    if len('') > 0:
        _dead_7697 = 894
    value = 867983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQH+dEExqqY0HgGJywS2YwMrvXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7622 = 138
        889
        252
    total = value + len(text)
    return total

def _ιτΒгЭФЧκлΩΦωΜыΥл():
    value = 516436
    text = __import__('base64').b64decode('YlhrejZBcGZuS0YwN0JCanhDTHE=').decode('utf-8')
    total = value + len(text)
    return total

def _υДЪΥΚΜрβφХтςУΦ():
    value = 132395
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ii7sXGgf8JgvbyCPnXS8H3d4/Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЮΜΛЕωοьιΙ():
    value = 738517
    if False and True:
        pass
        _dead_7571 = 800
    text = __import__('base64').b64decode('ZWRpSEVLTWw3Z2IyNzVCX2xBOFE=').decode('utf-8')
    if 52 * 91 < 0:
        pass
        _dead_2149 = 79
    total = value + len(text)
    if False and True:
        _dead_9604 = 560
        573
    return total

def _ΟЧИтПОЙэРНьφФюиυ():
    value = 407452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mnb+SUQw7YpbFjCVnVqBMwkMzHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μУЖΧЕдЪΚψцΨэСΟ():
    if len('') > 0:
        pass
        251
        769
    value = 541379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KC3JXltp9JE1Ayec7XLHLTEtxz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 44 * 57 < 0:
        _dead_5594 = 129
    return total

def _фФΙесΔнЙЙχΒхк():
    value = 641009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjzVfXI31K5WCQSoxW6mYg98vVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΡΠРгПфЩХфыЪрΓк():
    if len('') > 0:
        pass
    value = 290354
    if len('') > 0:
        _dead_4888 = 371
        pass
        _dead_2232 = 626
    text = __import__('base64').b64decode('ekM4MDE4b0xYSmNBX2RHajJUUEU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_3365 = 486
        pass
    return total

def _ЙъвЫΤхЩЯЕЪωЭ():
    value = 516609
    text = __import__('base64').b64decode('YXFZeXhJeDd0bzY5Njk5cVBWV2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΑΡДСПΡДьнЯецФ():
    value = 913436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQyxNlkP8bgMNV6K/wLCDgIX/mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лВχΓЩиνσ():
    value = 453171
    text = __import__('base64').b64decode('SE9qRG9jRVBJeEdhMFhoTUtKcUM=').decode('utf-8')
    total = value + len(text)
    return total

def _еΖКнνДЪйх():
    if 22 * 85 < 0:
        275
    value = 941461
    if 51 * 18 < 0:
        pass
        pass
        _dead_4766 = 906
    text = __import__('base64').b64decode('aUdEN0l6R05udWhqR01pSF9nWVg=').decode('utf-8')
    if False and True:
        105
    total = value + len(text)
    return total

def _ыЧξыеФΤπ():
    value = 302387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky7eSUsU2Js8NSeq61y/ZCt+5mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гМСχРжзушυШ():
    value = 190521
    if False and True:
        839
    text = __import__('base64').b64decode('d1hyRktVNWxVMEQ5ZkRCMHY3Tnk=').decode('utf-8')
    total = value + len(text)
    return total

def _уШяΘсхγιзιγε():
    if False and True:
        pass
        _dead_5195 = 64
    value = 450556
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXfDP24c/YQSYyKExFSkPXUB3H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΜΨπΖЖбуЕθσγΛн():
    value = 774997
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxzCZ3koz5ICLwPw5X6HLQAK1Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДЗЛκюρвьОл():
    value = 854676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQT2YXgQ960wIzCU8UCJMigpsD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηйЫΨТΓОςБО():
    value = 880061
    text = __import__('base64').b64decode('VFZYejR3bjB2Q19OQmRvN3E4eHk=').decode('utf-8')
    total = value + len(text)
    return total

def _НΡхйΠΟΤхК():
    if 17 * 38 < 0:
        647
        669
    value = 790515
    text = __import__('base64').b64decode('TzZJRG45aWo3akoyX1NKeng2SXk=').decode('utf-8')
    if 22 * 12 < 0:
        _dead_5393 = 847
    total = value + len(text)
    return total

def _ЮюοеУωΨψΚΒЗчшβγ():
    value = 765524
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBDyVEk76awmCALw+2WiPSw53X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4197 = 402
        334
    return total

def _АΩЛΗЪТэμαИЭΔ():
    value = 3799
    text = __import__('base64').b64decode('bjRwT0d2Z3ZVQ1hfM1lZUzlybnU=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_1243 = 60
    return total

def _ФЦιΖСαλПрη():
    value = 282911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCboe0sX2KxRLVql5wecEy0L9Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΕΣЖзЬΗцЭзσзΑ():
    value = 392130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzXwXAMJ7YRSag6c7liTEwEf3UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧОΝΖЬΨτιСтрЮщ():
    if 91 * 75 < 0:
        _dead_8461 = 521
        pass
    value = 637036
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('dWVhVHRJZHRDS0lSOHZ0U0RlTTc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2000 = 788
    return total

def _ЭαАζщυЫЙθЮΥψЯДΖ():
    if 43 * 45 < 0:
        pass
    value = 203166
    text = __import__('base64').b64decode('RTRFUnNjWjVOYTR0THNYMFlJOWU=').decode('utf-8')
    total = value + len(text)
    return total

def _лнШΓчαбΣЙΓ():
    value = 173682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDa0YkUzxp4SYlinyludAwQV/mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уμξхνьуΠ():
    value = 412383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSOzb2lo/PEtHCu6+0WFGSkcsEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τЗъβιЫЬйρНξ():
    value = 223515
    text = __import__('base64').b64decode('dWZFVTZ0aFczM0JvSHg1RmcwRGo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_1792 = 874
        9
    return total

def _ηюρшЯсБяЙЧНгС():
    value = 501901
    if False and True:
        503
        593
    text = __import__('base64').b64decode('dkVxR0FtSTgyU1NsVFpRckl6OHc=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_5897 = 328
    total = value + len(text)
    return total

def _ЕΒΓЫΤμуΑΜИπЛтΠ():
    value = 265670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRDPa2Yo6K0ACxa1kWaALR0d6mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γСЛГξεчκΝохΥ():
    value = 812061
    if 96 * 72 < 0:
        413
        _dead_6368 = 535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzbxYwA3+akKaiSF6liCFXca8WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 14 * 67 < 0:
        450
    return total

def _дЩΧΓχСрмУрТноχ():
    value = 510789
    text = __import__('base64').b64decode('V2NWY2YzUzA3T2dfdTFidFZEVWc=').decode('utf-8')
    if False and True:
        pass
        _dead_5388 = 607
    total = value + len(text)
    if False and True:
        _dead_3113 = 998
    return total

def _εΔЗΝМмΗολо():
    if 32 * 41 < 0:
        934
        _dead_9016 = 890
    value = 165206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQj9RFAh2ZAgEl+SkFW6EhIYylQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖτнвБЗЖЗ():
    value = 374739
    text = __import__('base64').b64decode('R1FHMThoSVFKZHhuaW5uN2RtZlA=').decode('utf-8')
    total = value + len(text)
    return total

def _пзЯζнгρКεИ():
    value = 524865
    if len('') > 0:
        179
    text = __import__('base64').b64decode('cXoyb0pqNVFyZWJIQ2lsVWc1RU0=').decode('utf-8')
    total = value + len(text)
    return total

def _щΜфеθВШлхЗЗлб():
    value = 340124
    text = __import__('base64').b64decode('dHhYZlJBQmNyZnBDQmoydUxVUmk=').decode('utf-8')
    total = value + len(text)
    return total

def _БтяеЖЖψλБдКгΚГ():
    value = 831086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDj9SV0VqYc0FRWN/kCTPScGvUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 41 * 88 < 0:
        pass
    total = value + len(text)
    return total

def _ВцХΒΣывзозξЛ():
    value = 646533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwjNQ0turKIIKyi66w6qESEszn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΝъэεθΧлЩТЛΕлΑ():
    value = 604489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhzoSGNsraAaFCjxxEOYOS4972I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вЙЛлΤσΚСыЮжЛМ():
    value = 149040
    if False and True:
        _dead_4959 = 900
    text = __import__('base64').b64decode('WFZJaE5IQmF5OGdMWjhtMjJBaUk=').decode('utf-8')
    if len('') > 0:
        _dead_7002 = 121
        816
    total = value + len(text)
    return total

def _йκΔΘШΖΤЙΘηδξΒтН():
    value = 953310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBD9eEUV5Lo5FC25yl6dLhUf4Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пэцхνЩяБμΛЩ():
    value = 26570
    if 41 * 2 < 0:
        _dead_6358 = 964
        475
    text = __import__('base64').b64decode('REdsRWs2RDZFczdRVnJNSExNSWo=').decode('utf-8')
    total = value + len(text)
    return total

def _θςЕЮЧушХюΥΛй():
    value = 455849
    text = __import__('base64').b64decode('azNvN3p0T1ViMm1qeG5ITkFDS0o=').decode('utf-8')
    total = value + len(text)
    return total

def _лΑΚэωХςΨыиЧΩ():
    value = 576810
    text = __import__('base64').b64decode('TU15NjY5bTNYaHJRRTdDY3ZfcmI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛтгВгЗθФτψд():
    value = 343896
    text = __import__('base64').b64decode('eVdNMTdlZ3UyTzVVaVdoYW5tTW8=').decode('utf-8')
    total = value + len(text)
    return total

def _αχμЮβμйКλΟθςвΒд():
    value = 692639
    if 67 * 38 < 0:
        920
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDjoa0kQqphabzCR+XSIMgYi43Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УяОΠЗРΝΥμ():
    value = 737584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAe8QVktq4sIPCCs90WUBHN37Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        689
        _dead_2289 = 96
    return total

def _кαуΑЫнφюμΤαгеН():
    value = 92448
    if len('') > 0:
        pass
        813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXbRaEQ0/KoXaBe08n6cYSMLsUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΗδΘПΝΠΝΗЙМλЖт():
    if len('') > 0:
        650
        _dead_5465 = 188
    value = 146199
    if False and True:
        pass
        _dead_6706 = 676
        _dead_7716 = 512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACHgTVBg2YQbYyOEmkGWGXQh41o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 20 * 1 < 0:
        567
        _dead_3086 = 386
    return total

def _еНгθЬΑΤРΗщчΞыяст():
    value = 989297
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('TmFjMWh3UG1jZjdLOUY5bFNGRUg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6779 = 72
    return total

def _ΥрΛЧМΖΥИαΥъ():
    if 90 * 87 < 0:
        pass
        813
        pass
    value = 844252
    if 59 * 2 < 0:
        _dead_5721 = 955
    text = __import__('base64').b64decode('SzE1ZWlHMUJNQXY5SU13UHVaVDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛцΙзЭυхΙХΣч():
    if len('') > 0:
        550
        _dead_9150 = 391
        _dead_8283 = 793
    value = 571189
    text = __import__('base64').b64decode('VzdncHBVNGl4akF4aGdFNWpiNHM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        478
        _dead_5258 = 482
    return total

def _НТΘЕΛчйг():
    if len('') > 0:
        635
        pass
    value = 604493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwfefGgtqZ4sMiug42GGEjwq/kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΤеΗГοАЩвюЧиΣηδ():
    value = 617890
    text = __import__('base64').b64decode('TWIzUzNwWnRUaTRoN0JTSGdVdEM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ζξЦхцСьΥΠδΧяпΤьЧ():
    value = 209786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwbSYEAAq40tNBuInEyBIyYWykc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гκχξыΚчЬЛΝψΛ():
    value = 387619
    text = __import__('base64').b64decode('TGFWM21KTUN6ZlZib2JLUFBLUHc=').decode('utf-8')
    if 86 * 15 < 0:
        252
    total = value + len(text)
    return total

def _ЛвжювУΓςΕδΕФк():
    if 58 * 98 < 0:
        pass
    value = 877968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQvpO0sV9JEvFgKv+FeWAncZ0EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΩъВЩΚчыρЮπмμЖ():
    value = 377207
    text = __import__('base64').b64decode('VGxBRGdKVmZzdVo4elNsdHNKSGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ВеΟΩжЕЦαБиσχв():
    value = 426503
    if False and True:
        979
    text = __import__('base64').b64decode('dExsOXI3WGJxWF91WkNLbW0xUnA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7766 = 706
    return total

def _γΩζйΜλяΡΞλα():
    if False and True:
        pass
        369
        _dead_4985 = 645
    value = 389017
    if False and True:
        _dead_1402 = 309
        313
    text = __import__('base64').b64decode('Q1Q1T1FVYmpuT2FXdFp2WElxSVU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3428 = 330
        _dead_3833 = 731
        _dead_4608 = 690
    return total

def _ωχωуΓΚρТь():
    value = 557575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CR/3awU7yqs1Iy2RkQHBAggQ7EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γТΥхвμЭογИηЕΝλХЪ():
    value = 661245
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQPOaUIjyLg7IwOQxnWaOQ8Wt1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗыОлψЦзбХΩΒΞуДτ():
    value = 504696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSXGZX0Br4w8Cjui2ETFCyB88kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗςчкΓЧνσαφεош():
    if len('') > 0:
        693
        pass
        129
    value = 808631
    text = __import__('base64').b64decode('eFdDd0hqdTBVbDBfaXdBQTNqdk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΚΔκхΠаΛπяζηβЦ():
    value = 302042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px7bfGIJq7ErHV+n8kWlAjUm90Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΒΔσШυΨбЭЙξЬιвΒΓ():
    if False and True:
        _dead_6769 = 615
        673
        _dead_7220 = 835
    value = 130720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjXTd1hv7fAAPQGWnlSIIDAV3n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        489
        74
    total = value + len(text)
    return total

def _ΟаΝρτβЯтФДΧΟСгΠ():
    value = 20015
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzqwUXIv6pIZAxj690+aOgka11g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΕλαδаюрЧзЧξ():
    value = 335419
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3vxT0Aq15w7LiCN/1ClNTMe3UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЮгЧΒЛωЛ():
    value = 20091
    text = __import__('base64').b64decode('a0Zrb0xRZkEyX1FucGtybGlfYnQ=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ЛΓЬЦΠоФфΣжЛ():
    value = 610249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwHMe0FgxL4sIiqJ8XeyYS456Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΙЯωюλЮΝыЯЯЩ():
    value = 827520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCzgdEsG85AbLV2vyVzEZgF+1Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эИλЗзэЧЕы():
    value = 316815
    if False and True:
        499
        319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyT2OEsu8ZAzEQmh41mcDg4D5Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚЫРжибψыφыЫРμь():
    value = 760906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyzQWXxh5L0EIAvw/H+UEwx/3Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΧЗГуΙнηЕΑΧМе():
    value = 464328
    text = __import__('base64').b64decode('WWZjbGdMWGE0ZkoyNWJxQ3NzQWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞδΦнΥωΧΧЗъЯς():
    value = 954675
    if False and True:
        _dead_4296 = 325
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAjlR2MA5IJTPCXwxVSpPzwY9WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _глΜОνАТПжБТя():
    value = 789637
    text = __import__('base64').b64decode('Zk16aUpncUJDZUxKeHdGOTlEc0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЛчАπμвΖбИЯΦαΑШ():
    if 5 * 87 < 0:
        _dead_2489 = 747
        304
        pass
    value = 928326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjvvPHYfq6cxEQarymyxFRMs510='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γгЦζэЗνЮγХΟЖшгШЙ():
    value = 750475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC70X2k42IMVbFiU/GTBNTMox2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηвфЖЫΦвДШЦΗΒΠΗιю():
    if False and True:
        _dead_8867 = 984
        1
    value = 903570
    if False and True:
        pass
    text = __import__('base64').b64decode('Q0pNMWpWSnVldlZZYzV0NUMyUE4=').decode('utf-8')
    if False and True:
        106
        899
    total = value + len(text)
    return total

def _йκпНηЖβЬΗгзγЯО():
    value = 275433
    if 51 * 2 < 0:
        _dead_5635 = 628
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AifeQ3Itpvw6aB2v8VSXbBog8XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        402
        _dead_2218 = 612
        pass
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('dA==').decode('utf-8'))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()