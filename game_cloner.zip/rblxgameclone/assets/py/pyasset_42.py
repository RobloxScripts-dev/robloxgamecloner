#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _зЬГоλκбьςтСκЫИ():
    if 29 * 88 < 0:
        625
    value = 388107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHuzWnMXpq8PO1eh90KHIjc6/mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫρжΨΞбπбзψМΣНепШ():
    if False and True:
        _dead_4831 = 6
        226
    value = 265265
    if 23 * 65 < 0:
        pass
        _dead_9563 = 693
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FifIR1QxyboAG1/1mAPIPAJ4vDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чωρΡсЯΘΖσΖЖалИΧп():
    value = 514923
    text = __import__('base64').b64decode('VnJLMVBKTW1neHFCbzhBb0RfbEs=').decode('utf-8')
    total = value + len(text)
    return total

def _вωеНρЙЛΩΦдпЕω():
    value = 298567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N37NV1MXxrEJMFeFmHLFZi4NyX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъмиΣуυΦС():
    value = 254295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhzqSHU32vwHESWM0kG0DSJ25UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕςвκΡβФКΧΖОх():
    value = 234420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwHTWAko3aM7PRqin0+HMzUJ9Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юСυΞΒеψкσЧЭпЯжΤб():
    value = 803200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCfdb3sA9ZABGT7z7waKPzMbtn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИьзоБΓлХЧбкЭл():
    if len('') > 0:
        56
    value = 309607
    text = __import__('base64').b64decode('QmxEWnBqeTBIX2lOMGpLQWpvZUs=').decode('utf-8')
    if 50 * 35 < 0:
        2
        pass
        pass
    total = value + len(text)
    return total

def _КЫИΘιχЛιоУΦхγ():
    value = 915338
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRb3RUk60a0bHSSxw1qXBHAjwGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рπюΑΜЗъЙλ():
    value = 273342
    if 8 * 14 < 0:
        665
        _dead_5034 = 591
        pass
    text = __import__('base64').b64decode('VWxsY0VqTFhIUHU3VjZvTms4eGk=').decode('utf-8')
    if False and True:
        _dead_2471 = 215
    total = value + len(text)
    return total

def _мηЧΖθчΛпΥГяЭЕΞο():
    value = 475970
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARz8YkUgrp8gPAi0xlenZQF8sGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дεοΕΕзФшιиУ():
    value = 620539
    text = __import__('base64').b64decode('d1RRQ0dUQnZlM3QxRWtVeUNuS1c=').decode('utf-8')
    if 38 * 57 < 0:
        _dead_4261 = 308
    total = value + len(text)
    return total

def _КдРеβαтζτФсхюμΒν():
    value = 239965
    text = __import__('base64').b64decode('bUtyNjNZbUp0SlZhMHU2TktqT3c=').decode('utf-8')
    if 56 * 13 < 0:
        pass
    total = value + len(text)
    return total

def _ωзЛейтЦςж():
    value = 681990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3bXfVcw5PgECxXxzGejEAwot0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФзδΗΔΚΟА():
    if 45 * 68 < 0:
        _dead_9560 = 281
        pass
    value = 187176
    text = __import__('base64').b64decode('TWFia2E2X3V6dFlBZHVTRzV1OW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΙбУйоεиаΡΜεΜнΨД():
    value = 2570
    text = __import__('base64').b64decode('RXVkR0RIWEIyTVk3OHpZOE9UWVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ψкОРЗιбмδυбУ():
    if False and True:
        _dead_5328 = 490
        83
    value = 856866
    if 97 * 7 < 0:
        _dead_5832 = 778
        pass
        479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3nBO15twf48Gwqp3EWRO30IwU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тоцξΒΤΩУаЪΛω():
    value = 955029
    text = __import__('base64').b64decode('aUQybTRCRWc0R2YySjVOeF9fdW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΒζНшζоЗΚлЧαα():
    value = 507147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxneYlY4z45bExe22XSRLhAjyXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ссоэЗСРНхΛГЪРяο():
    value = 783209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITzAZgId+6FVbAiq7HiYEQg25kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        4
        949
    total = value + len(text)
    return total

def _йбщэППρЙзаАμΤθ():
    value = 383941
    text = __import__('base64').b64decode('U3l4YVkxdWFXUnhwUG1tczY3Y28=').decode('utf-8')
    total = value + len(text)
    return total

def _пгςЫαьνДεфьИ():
    value = 424722
    text = __import__('base64').b64decode('aHc5RTUxNGpEbEJ3QXlYQUl0ZFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΤЕΑПФημΦλыΔ():
    value = 58783
    text = __import__('base64').b64decode('T0hxcmY5SjJJdlFiOHEydEtmYU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘФΟЮыοэЛсΤωцУ():
    if False and True:
        _dead_1139 = 764
        _dead_2221 = 848
    value = 454500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXzbakYj670raB326lOUOT99vGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 46 * 47 < 0:
        883
        _dead_4008 = 990
        245
    return total

def _нЕβпяΣΘХΓбχν():
    value = 717166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3jPZEs03b4aDVvy2lSvN3UX3UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΕχТςΕλдυΚΠуυθδ():
    value = 363959
    if False and True:
        753
        _dead_5189 = 210
    text = __import__('base64').b64decode('bXdlY0ZiZTU0YWl6YWNMNVB2eFo=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΠΙφΟЕЭКхлЯгΛЙЭ():
    value = 89867
    text = __import__('base64').b64decode('WTFKMTd3VFBJQ284Q1BtaDl4MHc=').decode('utf-8')
    total = value + len(text)
    return total

def _МшВЬΑэВЪχРωφ():
    value = 14688
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('UTlER1dRWFJZUDd5S29zMm9nZ2s=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЖдΠσгΒΛΚЗхθУ():
    value = 783098
    text = __import__('base64').b64decode('U3F2TWtTRzJOOFpEWEs4bVdNNTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ддμХЦьξΩ():
    value = 626696
    text = __import__('base64').b64decode('ZGNYYVNtMGsyaUFpVmJQbFg0UFI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ВЫοΣЩΕДъ():
    if False and True:
        _dead_2148 = 777
        pass
    value = 684773
    text = __import__('base64').b64decode('ZURSdGNoQmFDQ3plTjlCSEY1OWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _δиЦБΧΗζДγепΗрτфК():
    value = 239828
    text = __import__('base64').b64decode('SThBQTRXcGJEaDlHTndNbGQ1RFk=').decode('utf-8')
    total = value + len(text)
    return total

def _сСввГВнιγЪΖΞ():
    value = 175691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cx7HQwYG2Z8ZDCWI5VSyJj8+114='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 88 * 56 < 0:
        pass
    return total

def _θςбЛφЙЮΤдЮтоρ():
    value = 284925
    if 49 * 69 < 0:
        pass
    text = __import__('base64').b64decode('UnptcnAwZWEwU0htNkhSQjJFdkg=').decode('utf-8')
    if 61 * 19 < 0:
        _dead_7735 = 850
    total = value + len(text)
    return total

def _ΥчВλшуνΙЛоσЙΔ():
    value = 624282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3ntNkAR0JgZahm5xlK6HhcGz0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сυΒХχрνΤСδ():
    if 8 * 35 < 0:
        _dead_4076 = 733
        _dead_1502 = 158
        _dead_7665 = 215
    value = 676715
    text = __import__('base64').b64decode('c0xYMlFEY1B1UzJKcG9NRTg1UG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ВσαμсЦвΜЫυ():
    value = 382429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyvCPWAL26sKNTq651e8ZnEpxVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _диДщрθъкΒ():
    value = 131025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDm1VksM0/gJFxeA5VGSYAQ47EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХοΤЫΠΚφнΗΧ():
    value = 114515
    text = __import__('base64').b64decode('dXlfX05HeTZaSlFqUkpxN21SSzM=').decode('utf-8')
    total = value + len(text)
    return total

def _δςεаμγςΒΕγτΦЗγ():
    value = 638667
    if 84 * 14 < 0:
        pass
        pass
        _dead_6243 = 168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXv2Zmch1okzPwOc5EKePhQX8Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 76 * 77 < 0:
        pass
        pass
    return total

def _μЦγςνнуΧЖρбιг():
    if 43 * 44 < 0:
        979
        pass
    value = 650781
    text = __import__('base64').b64decode('Rk1PbFV6TWFPd1FEcF8yQnpKaXA=').decode('utf-8')
    total = value + len(text)
    if 91 * 72 < 0:
        937
    return total

def _яяπсθЧακжΙЩ():
    value = 688863
    text = __import__('base64').b64decode('c2pXdE9Kdk8yTXkxR2ZVbHFfYzk=').decode('utf-8')
    if False and True:
        _dead_9841 = 270
        pass
        _dead_1309 = 974
    total = value + len(text)
    return total

def _мψЛζЕтэтй():
    value = 854062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwT2QVQJya9VIx+m5Xm8LCQVszc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΓрУыρШвШΝТΣΟπΓ():
    value = 76672
    text = __import__('base64').b64decode('UWI4N1NLTzN3a2JrdV9BQ1AzYnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ОжνΝΔΗхπИтпι():
    if 11 * 32 < 0:
        _dead_4491 = 820
    value = 462467
    if 65 * 92 < 0:
        967
    text = __import__('base64').b64decode('d0hMWUU2YVNieFNvRlJ6X09RbE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΗΨьЭРφο():
    value = 595244
    if 3 * 100 < 0:
        _dead_6688 = 364
        pass
        _dead_4435 = 48
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXj2ZVQSqpsJFBqq913GHBEc7Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 28 * 87 < 0:
        _dead_8434 = 252
        _dead_2747 = 132
        621
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        516
    return total

def _θГΙρИрДуЮΞъΔΥ():
    if len('') > 0:
        565
        pass
        pass
    value = 708065
    text = __import__('base64').b64decode('dXVRWG51QmNTN3k0MFJLTXVmVTU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        79
        pass
        pass
    return total

def _ЦЪЛυрΟΓЫЪфцДХШμμ():
    if False and True:
        pass
    value = 984209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzywfHU1yv8TC16K43vJEQYV9Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГγηξШРЪεШгΕщгωъш():
    value = 792643
    if False and True:
        149
        pass
        _dead_8637 = 746
    text = __import__('base64').b64decode('TGo2TzJxMGdQdlVJTWE5TEo1TTk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7046 = 979
        726
    return total

def _зкжНэτтΧΥ():
    value = 198797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhjNOmlpqa4TDAac0X+GZwgk5js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚιтτΡСπκПηρμ():
    value = 525671
    text = __import__('base64').b64decode('UVpfekpIRDVRU2I2b1VRVGVyamk=').decode('utf-8')
    total = value + len(text)
    return total

def _жлΒΙΕЧжАΛЪ():
    value = 19989
    text = __import__('base64').b64decode('RENTYkR2Vmd5bXBJWnhYS3J3WWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΓипЖжσΖиМВΤΛ():
    value = 756204
    text = __import__('base64').b64decode('YmR5S2tKZHA4eWNOWGFZa0ljblc=').decode('utf-8')
    total = value + len(text)
    return total

def _дАΥдЧоАЗΧЯξ():
    value = 424084
    text = __import__('base64').b64decode('bnh2ZDZ4ekNTdUJQOUtOVEtqWHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ъВΣфбЭчй():
    if 29 * 68 < 0:
        925
    value = 718815
    if 57 * 51 < 0:
        375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ajyyf18j344ADRmEnkKWZnE8wnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕояρΔьνΜЧσΜуΦΣ():
    value = 165705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSayX0QL/40LYgTww1+GBTEXwU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АεАЯζΖШРΑАсΗ():
    value = 682687
    text = __import__('base64').b64decode('TF9iMm80c29HaUlLeE9CeEdRNTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ХъЙЙЦбьчиΜФ():
    value = 709837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAbGP2UvyPA0BVag0X6WAQEQznY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9947 = 867
    total = value + len(text)
    return total

def _ЖζАΚШПниΑσβζцЪС():
    value = 947843
    text = __import__('base64').b64decode('V1pJZlZQN3MyWk1oOVR4XzJCNTg=').decode('utf-8')
    if len('') > 0:
        _dead_6925 = 390
        122
    total = value + len(text)
    return total

def _μюΤΚЮΒεХаЪ():
    value = 546606
    text = __import__('base64').b64decode('Z1JFN3VONWRhU2FRdkx3Y2FQSUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟъβрТΦТхЕОЭΦΠ():
    if len('') > 0:
        357
        265
    value = 542796
    text = __import__('base64').b64decode('UHFzazBRUDN5aDNDQ1VvYWpreVU=').decode('utf-8')
    total = value + len(text)
    return total

def _афλΔщБΛЗэЗЛЮΖ():
    value = 537281
    text = __import__('base64').b64decode('T3RkeXpjMmx0Q2JfMnlxbklHc18=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯМβφэГΦПЖΒδыπΣУЧ():
    value = 634204
    text = __import__('base64').b64decode('aVRjV0dWMmNsaTRJM1pET3loOHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖъκζЗЕДΣιХу():
    value = 837277
    text = __import__('base64').b64decode('cmZrQkl0MEZRSWZKMVE1UjZ3dTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΕчςмаΨτЯЬуπΘ():
    if 77 * 25 < 0:
        890
        _dead_7224 = 458
    value = 877550
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyOyO1kGxq8pPQG550KTLBoI0Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 47 < 0:
        pass
    total = value + len(text)
    return total

def _ЖдЦΝщΣмГпя():
    if 38 * 85 < 0:
        245
        _dead_9785 = 464
        884
    value = 271340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAThRXlrqI4tLz32/FmKbXw19UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΒчπьΑУΔχкΡсЬΓ():
    value = 201099
    text = __import__('base64').b64decode('ektHRDNrbGRka0txbVJ5VkxBR0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ζсДЭьφЛэΕПΔα():
    value = 345554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pwz3ekkf/58NDl/04m+mGnU+0VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΤμНцηΔχρЙЛ():
    value = 579343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgC0aEAOr5AiIySJkAeYEyk94mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψςΩΠвоДюяΕετЛпπ():
    value = 658370
    text = __import__('base64').b64decode('TzRnNHNPd2R0SENtdFdDRHRGeGs=').decode('utf-8')
    total = value + len(text)
    return total

def _κПσСуТΠс():
    if False and True:
        276
        164
        _dead_2132 = 356
    value = 665970
    text = __import__('base64').b64decode('Y3l2WDZFWXltS0RaZzdWY011WGU=').decode('utf-8')
    if False and True:
        pass
        pass
        528
    total = value + len(text)
    return total

def _яΛΞκяΕψλΠГμαъП():
    value = 694920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CA79YEZpwYoNKQSm3VWgHBon3Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _этμХΟАХΟ():
    value = 764668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRrhS3IL3a0NCweU62W7Li4ktH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пМγζБуΕаррлφφλΡΖ():
    value = 559037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3rAOH4U5/kFHRWhx064Fwx/tWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 64 * 11 < 0:
        _dead_1430 = 371
    total = value + len(text)
    return total

def _ЯОΛсРСЖаΙτщΕ():
    if False and True:
        pass
        582
    value = 60019
    text = __import__('base64').b64decode('aFRGRlY4Z0lfV3JJSkJlQmJCRV8=').decode('utf-8')
    if len('') > 0:
        743
    total = value + len(text)
    return total

def _ИДΒаИκΖЬнМλО():
    value = 534149
    text = __import__('base64').b64decode('bkd0RWNDemdWWk9qY0lXX3pYb2M=').decode('utf-8')
    if 13 * 10 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _θαмμΓΧΙΥл():
    value = 104104
    text = __import__('base64').b64decode('b2dRa0pWZXJFVzNHdEpCWm9SZ1k=').decode('utf-8')
    if 73 * 26 < 0:
        _dead_4271 = 620
        pass
        _dead_4499 = 758
    total = value + len(text)
    if len('') > 0:
        _dead_5158 = 998
    return total

def _ΝмηКΘСщУΥтεφ():
    value = 898326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET/0QAMD+6M6BQWk7WadZhIV3Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΑΗыЕοΩθрЧ():
    value = 274318
    text = __import__('base64').b64decode('dzNLVDlNTmRITUtjQTM5a3ZvSXo=').decode('utf-8')
    total = value + len(text)
    return total

def _хζоГδΡΩшΘВρ():
    if 28 * 66 < 0:
        pass
    value = 644088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eib0RkcbyKJbPF+B+ACqPjIZxl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 61 * 70 < 0:
        664
        _dead_1684 = 673
    return total

def _УГгбΖщкШйЯвμΜЖ():
    value = 183722
    text = __import__('base64').b64decode('UkFLR3A5aVdJX1ZiYVRabkdoTjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛмУЗΖЩγЧЕΒ():
    if len('') > 0:
        708
    value = 809915
    text = __import__('base64').b64decode('VWNQbnVTQ09IdnlWMDlBb3A2RlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _жΥЙлΤξΨΠКθа():
    if False and True:
        869
        591
    value = 182423
    text = __import__('base64').b64decode('Z0NqV2lwSEtrQUlYcVhiX2dXNHM=').decode('utf-8')
    total = value + len(text)
    if 27 * 22 < 0:
        _dead_4404 = 467
        pass
    return total

def _ΛωОΚφЩГΟаяЯ():
    value = 267448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxrWaX4fzJhRPTWc+XyjZjEC810='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОζΥΖМЭΓΟξΤСАСЦ():
    value = 142883
    text = __import__('base64').b64decode('cWlySVo3aFdjQmNRRVFCbXlVU1A=').decode('utf-8')
    total = value + len(text)
    return total

def _нαщфβйЙθΖυЪ():
    value = 509633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBnzZFxq+qYzFgyP0VCHYCI5s2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪοεДνжылωбЛмΡОι():
    if False and True:
        pass
    value = 20527
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyDxPF0J6aZUYznx51GjDn0/t3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _гΥщκΧфзкΓη():
    value = 699883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByPVY3sS3I1SPgK342OzOxcs23o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βшοсΧγММ():
    value = 518493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgKzV1kR15EwNSGRxFqWORc2tEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρκΒРМΨеЦсШ():
    if False and True:
        _dead_4620 = 320
    value = 617956
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAX+aF8jz68LFz2x8m6VCz0syHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гАЭЧхЗеδнΠΗ():
    value = 192319
    if len('') > 0:
        574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQ7gbQk384IWEB2wwwKhHzcu7lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лдШΨΨΝвθΝΑехГΞщΥ():
    if len('') > 0:
        _dead_2253 = 25
        _dead_6313 = 886
        336
    value = 550536
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('YkRnOU5yY3hHVlppOVBsYll2XzE=').decode('utf-8')
    total = value + len(text)
    return total

def _хТЩвδΨрΔЗΟЖΙЧ():
    value = 38099
    text = __import__('base64').b64decode('TXVwa2RmUFU0bUlWbTdMbzFYakQ=').decode('utf-8')
    total = value + len(text)
    return total

def _οПδΣΝХχЮхχ():
    value = 163026
    if len('') > 0:
        497
        407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MA21OAMY8Z4RAzWT7HijBigu8Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6573 = 777
        _dead_5339 = 956
    return total

def _ΡιωСДаНнΣиφΥыХ():
    value = 471212
    if len('') > 0:
        _dead_8424 = 370
    text = __import__('base64').b64decode('RmVlOVhkM3NwbHdfVWJUN2RTdFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠεκβзУЕΓпкщзΛцΑδ():
    value = 453366
    text = __import__('base64').b64decode('QzRHQURabkdlcUhvOWl0Ykh0V0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΕςячφΖэ():
    value = 454382
    text = __import__('base64').b64decode('cEhfQ05FR3JfMF9PRGxsc0pscmQ=').decode('utf-8')
    if False and True:
        _dead_2042 = 223
    total = value + len(text)
    if len('') > 0:
        _dead_2814 = 782
        pass
    return total

def _γЫдЫГрсН():
    value = 248623
    text = __import__('base64').b64decode('amUxTGlIVUtIOXJoUmxEdWcxY1M=').decode('utf-8')
    total = value + len(text)
    return total

def _юЫρΣγбШфωυχΝΤχΒТ():
    value = 911817
    text = __import__('base64').b64decode('Y3NKcXZ6UkFFajByZkluZ2x1c3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΕЕψΤΥοыбгΡУΔΕμ():
    value = 726481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fym8YkkB76spPSSg+w67LBw/wHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λГЗνСПКξАСКΥ():
    value = 479288
    text = __import__('base64').b64decode('TFFmdm9ITWVCZG5VNW85UjR5TWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΣСκъΒхτλвтХ():
    value = 437192
    text = __import__('base64').b64decode('b2tXdGNQeGwzeExjbjNqQkVWcUM=').decode('utf-8')
    if 83 * 37 < 0:
        800
        pass
    total = value + len(text)
    return total

def _ЯлпхρΩлОЯЯш():
    if 8 * 88 < 0:
        478
    value = 751736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhezZ1461fghIAGgxW+KCzQr21c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮυтΠΘТηРЩиФ():
    value = 318081
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD20T1wV1YlXDyK06nm4NQ8K7FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωуЧИοцоβсΑФΧνм():
    value = 105148
    text = __import__('base64').b64decode('VXRaMWZwRElUZmdPX255eHh5aU0=').decode('utf-8')
    if False and True:
        _dead_7332 = 986
        _dead_4482 = 961
        243
    total = value + len(text)
    return total

def _ΤΞщЧУыςоФυγсР():
    value = 987882
    text = __import__('base64').b64decode('b3RhWVlKa1FNY01tWlVwTXNuUFA=').decode('utf-8')
    total = value + len(text)
    return total

def _Μгσцрαωμ():
    value = 179664
    if 27 * 10 < 0:
        pass
        626
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXjuQWZp1qoCLgeI6W6YZnAatGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7000 = 828
        pass
        _dead_7641 = 909
    return total

def _ΠεФΨσδРъγи():
    if False and True:
        pass
    value = 983684
    text = __import__('base64').b64decode('Zjl4RXFveXY5UkVJdkVyN0puVkY=').decode('utf-8')
    total = value + len(text)
    if 68 * 41 < 0:
        _dead_6050 = 422
    return total

def _ΔюкΒРХξЦЧСЗγМ():
    value = 528401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AingXXhr+oMUMAKy8kWSMicCslo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟЩνЗздЮыСэсоΡ():
    value = 523005
    text = __import__('base64').b64decode('VENJTmcwM2lhMFRiSU02aklWRFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗτδеШОтΧу():
    value = 994498
    text = __import__('base64').b64decode('QTFUQjR0cVJvYzJENUZ1RmRyRzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖЧχΘвыюνΙΕΒэ():
    value = 239505
    text = __import__('base64').b64decode('WG9tOXJDdFNzbEhSSEk1OV93OUg=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ιΓКζΥеΧнпυεщΨ():
    value = 289451
    text = __import__('base64').b64decode('amEzR2g0MHg5XzU0RzRuVlZfVmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓПΜΤΓιыπσЭЪΨг():
    value = 530083
    text = __import__('base64').b64decode('SW5abmdxbU9KUFIwUmRYd3RMdDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ъηΣФнΟαδчслΓΖ():
    value = 182159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah3SYVQ15L8aPhuHygCIGwInzVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фГΟδАΕдгκμΣшΣΝα():
    value = 441854
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LA3daAUe7P4oDgeL4Q/DO3wK02Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 30 * 5 < 0:
        _dead_8872 = 38
        pass
    total = value + len(text)
    return total

def _νПψЙξОΧьЬбЦςФ():
    value = 606493
    if 16 * 22 < 0:
        _dead_8814 = 699
        365
    text = __import__('base64').b64decode('Z1VncWRZQThFdlg1UGN5c2R1VDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΦνэиОкЕдуйб():
    value = 928822
    if False and True:
        _dead_5907 = 74
        pass
        pass
    text = __import__('base64').b64decode('TE43MTRRaUxtUTNWREVDVnRFS3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓеΖМΗХΟШЯИмЬГαЕ():
    value = 826492
    text = __import__('base64').b64decode('aU4wRG9UZVZFeFdUcWMxSGNVSnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪаΚΝκфшЧЪΑыУЗЫ():
    value = 219892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgrFegJq9PgIFwT04VO6ZhoIvXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лγΚгвμΝεМЭЦΤеИб():
    if False and True:
        _dead_5679 = 587
    value = 688060
    if 76 * 38 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDa9QmgS8Io2aD2g5lSTBgoOw1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _тшОеЛΗчΤЭΛΥμш():
    value = 814220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBvDRVY2z5JabAyA6lW0HjwC7n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠимЩхιстжыэ():
    value = 667830
    if len('') > 0:
        550
        _dead_5998 = 687
        _dead_7922 = 40
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAK2RGtp/IQGLwei5X2bDTMd6no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxxxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()