#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _йγАЖПЛунДхеβΟΘ():
    value = 873654
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EA6xZUs19LxTDyOxkHXBbRx+5WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        622
        _dead_9222 = 242
    total = value + len(text)
    return total

def _ΙДγАбсГνςкЕΧБΑΤЮ():
    value = 356452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hyb2P1UU8IEUAAGN7FfBOh15tnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΩАИШЛСσΨгъ():
    value = 481276
    text = __import__('base64').b64decode('VVpiVkx0TFZJbTJpY1NWRE1wVXI=').decode('utf-8')
    total = value + len(text)
    return total

def _теЖхЙлχКО():
    value = 963922
    if 23 * 71 < 0:
        798
        pass
        508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSfdUXRs8aQGPiuAnwOeJh0j9UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮНρεΩАвΩ():
    value = 160716
    if False and True:
        71
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT7mZwNq/LovGFmCwFm5PCB2vEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 84 < 0:
        219
    total = value + len(text)
    if 24 * 32 < 0:
        396
        _dead_2925 = 128
        _dead_7899 = 98
    return total

def _ωХΑΜыУΨйэОЗХε():
    value = 61804
    if 100 * 33 < 0:
        _dead_5548 = 215
    text = __import__('base64').b64decode('TFZSX09UaE1tbkhEQUN0RjdkTFg=').decode('utf-8')
    total = value + len(text)
    return total

def _εЕХοεсДмз():
    value = 902648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwjcTH8f8LEIKyKJ2WCaFnAZsm8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ауГАΦчΥНыη():
    value = 416355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBv3XQQ1+7A2LgaV6mOnLgst0Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζЙΓзЯβКфюЪПтΒжБ():
    value = 988138
    if len('') > 0:
        _dead_5228 = 855
        _dead_9122 = 920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgnTbXkWzIMbEgOTmmy6ISs9sTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 44 * 64 < 0:
        174
    total = value + len(text)
    return total

def _СγОρЦнЩμκΧФΥ():
    if False and True:
        pass
    value = 844873
    if 93 * 79 < 0:
        pass
        926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fj7NWggcpp0vHyLxzFmjEjE98lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 55 * 93 < 0:
        495
        340
        720
    return total

def _ЛΞλΛςΗкΣ():
    value = 306529
    if 52 * 68 < 0:
        pass
        pass
        459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyDLZ1Ju56wTIFyV212dOH0Q93Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        58
        305
    total = value + len(text)
    return total

def _иΡΦйцъоЯΝξж():
    value = 810345
    text = __import__('base64').b64decode('bW5IVENTdGRfVVgyV2tkbU01Wkg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        550
    return total

def _зξφИШгщΘΨΘΤфРσНч():
    value = 412135
    text = __import__('base64').b64decode('QThBeGV4Y3ZBcEJsNGRuQlpWTTk=').decode('utf-8')
    total = value + len(text)
    return total

def _уΛшΖлЕСθяΝΙζЦΙь():
    value = 899025
    text = __import__('base64').b64decode('WTMzQllQMGpsbEZWWkR2VmVGU2k=').decode('utf-8')
    total = value + len(text)
    return total

def _УρψΡшнБзπθο():
    value = 655655
    text = __import__('base64').b64decode('SXRWdXNNcTJuc2NTeUhUQ0NzRkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬпΣхΟВκЯьяνζρπмΙ():
    value = 311291
    text = __import__('base64').b64decode('ZFZQOERxeGMwTVBLZF9PVkZpVkM=').decode('utf-8')
    if 73 * 2 < 0:
        _dead_8357 = 520
        369
    total = value + len(text)
    return total

def _ЗλЮяφΔΒν():
    value = 295351
    text = __import__('base64').b64decode('SUZNaXp3VjBaV2g4WEpOSzdBT0s=').decode('utf-8')
    if False and True:
        387
        843
    total = value + len(text)
    return total

def _ΚдьчбНΕΔζΒμИμυ():
    value = 187609
    if len('') > 0:
        492
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnjcPlkc7rlaLQOby2aTCxwHt3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШХГαуйФиΜдΟьКЧΚ():
    if 70 * 15 < 0:
        0
        _dead_3354 = 711
        pass
    value = 899845
    text = __import__('base64').b64decode('QTJmZEpVX1lWWlU0NlFKOVVMWkc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        119
    return total

def _хΖτςжцСЯБМ():
    value = 649497
    if len('') > 0:
        pass
        pass
        _dead_5960 = 375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD/cYngX9/lVbDiNm3SgGHENsmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4839 = 556
        521
    total = value + len(text)
    return total

def _ГΦΑиФЫτгЦΒЧΙкδοΞ():
    value = 470010
    text = __import__('base64').b64decode('WjlaVWVLTVg2dzVxX2R5eXMxbUc=').decode('utf-8')
    if False and True:
        439
        _dead_4485 = 480
        574
    total = value + len(text)
    return total

def _птΞεсмΡД():
    value = 963266
    if False and True:
        336
    text = __import__('base64').b64decode('cGpHdV83bTJuT3JLWUUxM3Znb2g=').decode('utf-8')
    total = value + len(text)
    return total

def _УЖΝЖιЬЫΣШγЮют():
    value = 512274
    text = __import__('base64').b64decode('SjdwX2p4MkxSbDhVSnFpenM1bHc=').decode('utf-8')
    total = value + len(text)
    return total

def _иПЕчьпоΓελХЗЩηИΜ():
    if False and True:
        916
    value = 495407
    text = __import__('base64').b64decode('a2N0ZmhWZWdGVGMzQVlfdGpmUlo=').decode('utf-8')
    if 26 * 31 < 0:
        _dead_1647 = 858
        168
    total = value + len(text)
    return total

def _ΤбцСΛсμхСβε():
    if False and True:
        _dead_4756 = 470
        pass
    value = 900876
    if len('') > 0:
        pass
        950
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxXxYUcB/4wRNQyq63mpMjIg8js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юрσΥΔЬΓμΣоЕΙьйа():
    value = 829898
    text = __import__('base64').b64decode('SVVUa1NjZV84dXhSMnhQNHh6dGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭηςθΕМθЬУδФБ():
    value = 202438
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhrAQ3IGwYsoEluskAWYPSMQ3kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪηОεΜЭσдΨΛЛязΨ():
    if 53 * 82 < 0:
        pass
        _dead_4147 = 73
        pass
    value = 392837
    if 88 * 85 < 0:
        563
    text = __import__('base64').b64decode('aFlJQ1JEcW9lYW5GcXBjV2tkZjU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1982 = 559
        pass
        753
    return total

def _ьГрфЛΓοΡЪδ():
    value = 543438
    text = __import__('base64').b64decode('aWhfSEVYZG5UeEpQZ2JCX0NfeHU=').decode('utf-8')
    if 69 * 40 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ξХАчаьФΖэε():
    value = 417653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxnNQ1YO8KwELDeM23OGZTI37TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΜьцαΡΚъГ():
    value = 225282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABD0d1s4xKsrGD2l0FybMAoQ3UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3383 = 233
        pass
        977
    return total

def _ИаΡαЦЕπеρΝЩимΧ():
    if len('') > 0:
        708
        pass
        _dead_7144 = 918
    value = 514577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J37gaG4TrosHFh6kwHK8Mz9/xUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 80 < 0:
        _dead_8615 = 500
    total = value + len(text)
    return total

def _ΧτСЕЫюшФ():
    value = 83218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx61eGUf8IsTAwew31nIGRMQ0UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΙАΑнЯЕзбΣΦЙ():
    value = 351142
    if 77 * 16 < 0:
        275
        _dead_2851 = 727
        682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXbQZFUdx7oMOy2P/l+YNg8Q72w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 80 * 56 < 0:
        915
    total = value + len(text)
    if False and True:
        pass
        120
        pass
    return total

def _НΕЗτΠРπψПлμΣПμЛЪ():
    if False and True:
        112
        797
    value = 198774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih7NSkkD3/BXHAX64VGZNRY59WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оЪоςЦΛνΙΒМсМюЗкХ():
    if len('') > 0:
        972
        355
        _dead_3083 = 44
    value = 955933
    if False and True:
        530
        188
        _dead_5351 = 366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiTeNkAI0r5WMAuE3X+UNXYB820='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΟбχДЮΠуγ():
    if 92 * 67 < 0:
        _dead_6195 = 472
        _dead_2108 = 702
        pass
    value = 296279
    if 99 * 27 < 0:
        _dead_3577 = 631
        _dead_4714 = 192
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzvlTwIq5vk6bQmv4E7BOREJvWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιсΤчοΗчлδьь():
    if False and True:
        pass
        768
        _dead_3778 = 998
    value = 403695
    text = __import__('base64').b64decode('ZHJiOURPc0ZqMzV5YnVvZW0xdXE=').decode('utf-8')
    total = value + len(text)
    return total

def _юκъЪΟаυЬХΦщ():
    value = 632841
    if False and True:
        686
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRjvZ3IXy60zCBeT6m+DOTY6tWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        878
        120
    return total

def _νγВБцατЙцн():
    value = 288954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCrKWFc87a82bh6I30OAPjAH800='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5985 = 740
        792
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _φкΘΞΞиΔЭΩПδκол():
    value = 168776
    if False and True:
        153
        430
        850
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyHxSWsz9o8FY1v24XuaH3Ag8Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 100 * 20 < 0:
        _dead_6807 = 6
    total = value + len(text)
    return total

def _ЕОΔδЬпΓУФε():
    value = 870206
    text = __import__('base64').b64decode('VEZmVlZUMVN4aFhaUXE5c3k2RFI=').decode('utf-8')
    total = value + len(text)
    return total

def _γкΦΝМψкдψγИ():
    if len('') > 0:
        _dead_3635 = 758
        pass
    value = 892115
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCTPO24b2qkINguu+k+dISE8xmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4842 = 637
        315
        389
    total = value + len(text)
    if False and True:
        391
        pass
    return total

def _РЦωЦЫлбΑмΣΝΣС():
    if len('') > 0:
        193
    value = 486025
    text = __import__('base64').b64decode('ZXZQVEJOa2FTNklzTjFLckcwcl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖνφωДфΠπСЖΖγζκξν():
    value = 280482
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDXOagY92ZtXOTz13nmZOnM87X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖбечХβфъОΗЙС():
    value = 814118
    text = __import__('base64').b64decode('U2dVbFFuSU9HV1FuMHZRRzBLeTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΥсβψАρЗ():
    value = 640235
    text = __import__('base64').b64decode('cktxVXFpeDBic3pIczJRWkhnVTc=').decode('utf-8')
    total = value + len(text)
    return total

def _βЙρΣРδιфчЗλεЪВи():
    value = 878382
    text = __import__('base64').b64decode('bGdxRWNFVF93Z00wVXNPUWRRQkg=').decode('utf-8')
    if 76 * 77 < 0:
        _dead_6032 = 111
        _dead_7644 = 296
    total = value + len(text)
    return total

def _впγαЭЭЫΥρΗ():
    if False and True:
        _dead_3824 = 251
    value = 383088
    text = __import__('base64').b64decode('RWpaQTNNRFJReDJPMUp3WDhMaHE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        854
    return total

def _βΩнδΘеηзвЖЖРςэЕ():
    if False and True:
        pass
    value = 336703
    if False and True:
        pass
    text = __import__('base64').b64decode('UHlqVHZDV1M3Smh4RG5oTXRYaGU=').decode('utf-8')
    if False and True:
        332
        713
    total = value + len(text)
    if len('') > 0:
        757
        pass
        213
    return total

def _ΖзъпξμΗЮξРр():
    if 7 * 58 < 0:
        _dead_4355 = 660
        _dead_9262 = 97
    value = 373918
    text = __import__('base64').b64decode('ZHRCa0traXJrNlRPMUJzZnRHS2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛтεшΧΚГλΥъφ():
    value = 90133
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgnSPlMD2b05Hi2pxwHJOiQ16Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νδсзΣъΩюλЕΑт():
    if len('') > 0:
        pass
    value = 899205
    if 18 * 4 < 0:
        362
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In+3akEb6/8AOQf7mGSKCyci73s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФжпοκаΔКкы():
    value = 955642
    text = __import__('base64').b64decode('REdDZGo1NHVUTjRrSFhrTVA1N3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЭсХвпаψВЕььψщ():
    value = 523779
    text = __import__('base64').b64decode('Q3NZU2w2U216VkhDSzhtSG41Qm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛТшТΖΚμυΔ():
    value = 123912
    text = __import__('base64').b64decode('UnlfVTI4c1JCZjVQdTBCYjcyN04=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _пШТЖПβΒАхТЙγД():
    if False and True:
        _dead_2448 = 44
        pass
    value = 830200
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz7zXnYR/7kbKw2rxwa7ADx6vWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДεΛФΓΡУа():
    value = 423447
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHnSOUkIrrtSIArzwmeHHSAV73o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΛЭюΜТуΥ():
    value = 589020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Li7lWlQLqKBQEh3y8HSSAAF8zjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςιЧΥΒσдБ():
    value = 677014
    if 83 * 66 < 0:
        _dead_3258 = 657
        pass
        _dead_8894 = 148
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjW8UUIy26caCyKN60LGACc1tWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 49 * 84 < 0:
        _dead_6354 = 720
        389
    return total

def _бψЪфσρпΗЬЕΨю():
    value = 793899
    text = __import__('base64').b64decode('RkZJMTBPX08zYkVqRndtZHBQRko=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦεБΑеОЕю():
    value = 277164
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTXXZHwa1adRKwmwmVq8Gxwg6X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КθОΕЧαυйΒиΔЮюГТΝ():
    value = 238933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiDwZAkw+LtQDT+X2n2fISEQ/VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВтΡΓтψжΩ():
    value = 324542
    text = __import__('base64').b64decode('bFROcml0VjAwX2VDR0xnZm9kNko=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        603
        960
    return total

def _шзμхТπωИГюΤπкбψκ():
    value = 951532
    if 15 * 72 < 0:
        _dead_2015 = 631
        pass
        pass
    text = __import__('base64').b64decode('ZWFoTW9Ba1hJVl9WVXZKVlB6WjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ιбΔЗυмΕрЭЯпЬфθЛ():
    if False and True:
        pass
        703
        904
    value = 364242
    if 7 * 99 < 0:
        648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pz7+OwQbyqQrKB+rzXK8bSM9zkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6642 = 271
        103
        pass
    return total

def _ψЭшсГВезйχΟцχяι():
    value = 345695
    if len('') > 0:
        830
        _dead_8284 = 268
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBXBUVk+qK9aOSen22+pHhA9zHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        280
        pass
        _dead_1250 = 609
    return total

def _ЮрЪγτπфΚςΗπыжф():
    value = 65283
    text = __import__('base64').b64decode('VG1fTEZmZ1JYc0VlRGd4MUtNUjk=').decode('utf-8')
    total = value + len(text)
    return total

def _βТωςνεΔбштЙνлКЧЪ():
    value = 942210
    if False and True:
        665
    text = __import__('base64').b64decode('ajQ2Qjd2NUp1UXZIUDhLTVpmQWk=').decode('utf-8')
    if 7 * 83 < 0:
        585
        pass
    total = value + len(text)
    return total

def _шЛΗтεПБДСΚβаξаче():
    value = 989128
    if len('') > 0:
        17
        987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwbcOV0drIovFjyX7FWjERM1tVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        782
    total = value + len(text)
    return total

def _ΣщνИпуЛыепτДМиь():
    value = 302667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBnmbGYA36kxET+t/ESmOS8n4Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΠшФОενпухА():
    value = 248291
    if False and True:
        622
        pass
        pass
    text = __import__('base64').b64decode('eWlXT1phdnNFOExOTjJqOWdtU0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΒлдЮΛБэД():
    value = 11874
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lg7VS38Gp5JUAAux4H2nbC8i7Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΜЛξθδλω():
    value = 233282
    text = __import__('base64').b64decode('blM1eWFxZmFaQzd4WkRadkdZRG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЪэΩъГΙДДуΘχ():
    value = 311351
    text = __import__('base64').b64decode('eXoxMDQ0ZHhxclhBX0owanZRdG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓγсχτσТηΜн():
    value = 217312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjXSWFMerZ0EKxW3xH2DECl80E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θвИΓππщЮχΨΑгКчдЖ():
    value = 723443
    if 72 * 34 < 0:
        pass
        _dead_2280 = 407
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAbRP2gj87oBIhivmkfHJgQp3kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        484
    total = value + len(text)
    if False and True:
        _dead_2540 = 33
        _dead_2199 = 582
        _dead_7743 = 64
    return total

def _иοΗупΖЛюЦ():
    value = 861544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EC30eVgfqZoOMCq2/V+VZAQO6zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΛлМΜΚξзЦ():
    value = 817568
    text = __import__('base64').b64decode('dkNucER3dV9GT0dYTTZubVRJT3E=').decode('utf-8')
    total = value + len(text)
    return total

def _чΜθПЮжςЮЗхξЗвΦΙ():
    value = 682902
    text = __import__('base64').b64decode('VUt1WkRmTnVaZVNrU2VVV0t4U3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪуΖВзяβχ():
    value = 565884
    text = __import__('base64').b64decode('dEJjaFpMOExLcHJxVUdobXl0YkM=').decode('utf-8')
    if 27 * 13 < 0:
        _dead_3991 = 588
        50
        _dead_3355 = 524
    total = value + len(text)
    return total

def _ШβЦшЭжΧДΖьЮС():
    value = 754636
    text = __import__('base64').b64decode('SmpjSExvY2ZXTlVkZHY1QkNsWXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ξφырЩЯрΥιΨΕф():
    value = 439991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAHdZlcA/PwvbRii5lq0Ejcd7U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЮДρбАλΕΦΨΟюζся():
    if False and True:
        _dead_7232 = 327
        56
        469
    value = 646800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABf9QAForYIGbBuh/UWiEhod5no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        599
    total = value + len(text)
    return total

def _ДφХЖεиΓБχδΥ():
    if 55 * 7 < 0:
        pass
        pass
        _dead_9609 = 601
    value = 171108
    if len('') > 0:
        _dead_3277 = 37
    text = __import__('base64').b64decode('eVhmSnI5WGdJTDFIcHhsSHdqeUU=').decode('utf-8')
    if 87 * 16 < 0:
        pass
    total = value + len(text)
    return total

def _тЬЧωδХЪЖεоσΘΦКА():
    value = 512285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBvPRHc1z6YQbVuNxwa4JAx3/EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5149 = 276
        pass
    return total

def _ДБχΕОζЪζНιС():
    value = 915031
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzazX3I25IouHy2X/Vy/MgcuzVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 63 * 50 < 0:
        29
    return total

def _ЮеЪΥщысθЩЧΠ():
    value = 765856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAjjQWFh1YIQDSCV/lqqPykj6U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψщζЛдыΨЬг():
    value = 701838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHbudlYM36cWKl+VyQSgFS52tDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚπΤμЖτжаΝνГГХб():
    value = 18451
    text = __import__('base64').b64decode('SlRYamVORzlQaE0xVjVSbTVDQzA=').decode('utf-8')
    total = value + len(text)
    return total

def _αχюНχЙΞлйΤВцΝПΚц():
    value = 791450
    if 80 * 24 < 0:
        990
    text = __import__('base64').b64decode('TDZjZG94SldGdlg0TlBJUEV0Vm4=').decode('utf-8')
    total = value + len(text)
    return total

def _вτОΩΤΨΤιΦΦΣ():
    value = 182640
    if False and True:
        pass
        287
        _dead_4292 = 867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDfLanw6/J0tKR2v/VKnLAg44z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 24 * 51 < 0:
        683
    return total

def _νщИΥζδωχТ():
    value = 219903
    if False and True:
        _dead_9369 = 411
        895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBy3R1gy/asgNl2N5lmXPS03x1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мЧΜγъΧФЫΓοΔΚшΣД():
    value = 969412
    if False and True:
        618
    text = __import__('base64').b64decode('QzFkVDRFcmFqSnVmdXhrXzdxN3E=').decode('utf-8')
    if 86 * 39 < 0:
        _dead_5860 = 649
        pass
    total = value + len(text)
    return total

def _νвиΗζΣςБλЙα():
    value = 38379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS7MUUA0wZIgC1qy8mmyAwwnxWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 79 * 89 < 0:
        408
        pass
    total = value + len(text)
    if 55 * 9 < 0:
        _dead_8764 = 626
    return total

def _сσТиΙаРГЙξ():
    value = 508556
    if len('') > 0:
        pass
        _dead_1301 = 158
    text = __import__('base64').b64decode('UGQySFJmS2tDeWp5XzRHN25PYmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ψлρыπЧΡΤΥ():
    if 91 * 19 < 0:
        pass
        pass
    value = 527348
    text = __import__('base64').b64decode('QVhBOERnZ2dWUllRanFmN24zRmQ=').decode('utf-8')
    if False and True:
        _dead_9033 = 922
    total = value + len(text)
    return total

def _пΘдзШбалисμωЧЭ():
    value = 276443
    text = __import__('base64').b64decode('T2NvWWRvWHM4UFJPZjdkWDY3WkQ=').decode('utf-8')
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _щССеκЧЧζлΣΩ():
    value = 321389
    text = __import__('base64').b64decode('UXFYa1ptNWFTSVdOOGhxd2xHQ1g=').decode('utf-8')
    total = value + len(text)
    return total

def _βΕζυЛрγθ():
    if False and True:
        61
        818
        _dead_3716 = 998
    value = 759268
    if len('') > 0:
        237
    text = __import__('base64').b64decode('WGlKdVlmV1pNY2VLOTdVOW9xb3E=').decode('utf-8')
    if len('') > 0:
        _dead_3489 = 37
        _dead_6827 = 311
    total = value + len(text)
    return total

def _ыΚиМЙКУΚИцЯф():
    value = 348918
    if 76 * 95 < 0:
        _dead_6363 = 448
        269
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DADiP10D27tREwX17E+EOip9sH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _УΦЧΑшУцΙλашιуηοσ():
    value = 421367
    text = __import__('base64').b64decode('UDRNcEpTcnpRNU9jeEswRmtzdmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ςωαеΥφΜΦ():
    value = 842340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyjMSAYs0KwhFDmb6w6/ZXV77Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 49 < 0:
        324
        _dead_8829 = 999
    total = value + len(text)
    return total

def _ФςθΥμΔΚИмВгι():
    value = 740806
    text = __import__('base64').b64decode('U3lOUTdqU3NHQzVvdDNBQmxoY1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('IA==').decode('utf-8'))
if len('x') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    pass
    675