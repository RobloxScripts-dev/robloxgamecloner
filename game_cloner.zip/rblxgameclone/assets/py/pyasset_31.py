#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _рлСΥдОмΕЖπъгΖ():
    value = 377086
    text = __import__('base64').b64decode('S3FEbWxWYjVwVFNMdUZXZFV0MGg=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ьΣαЬдЧкуЪ():
    value = 189072
    text = __import__('base64').b64decode('VDBQdXh3eHZsd3NBdFZ3eXRzemM=').decode('utf-8')
    total = value + len(text)
    return total

def _ьРХьфзЯχеηΓτЕЕУ():
    value = 523736
    if 65 * 16 < 0:
        pass
        _dead_1838 = 162
        965
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXvmeXke2vguPTWx5wadJAgh8H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗкиОЩвуΣ():
    if len('') > 0:
        _dead_3805 = 209
    value = 77908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiLvZloWx6ZaM12J3gaeMC8g/kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_1914 = 803
        _dead_5115 = 377
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _шЮΦтВсмъω():
    value = 277716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXz2TVUIp4QgFBqG/WeDOHY3wn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юΦэФΞКцМ():
    value = 737154
    text = __import__('base64').b64decode('aWZ5NkdqeklMZUJtdmZxdk5RTXQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4158 = 681
        _dead_9101 = 134
    return total

def _ΩζйЫΑσΛаТσ():
    value = 686427
    if len('') > 0:
        68
        _dead_1733 = 435
    text = __import__('base64').b64decode('TThHMnRVWERRYTlqd05mbnZOUzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЛСΡΟЩτΘжΘλвρζΤ():
    value = 740125
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dw22XHcR3YwAbweVzEHCPhcW62I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮιχΖΑαγξэЕ():
    value = 442648
    if len('') > 0:
        336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DS3Od0ERza4LCxeF4XehNXcc3EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 54 * 24 < 0:
        pass
        976
        _dead_8406 = 369
    return total

def _вуαАηюбкΞλετΚЕис():
    value = 746488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aw7qSAVu14VbYz2uxQ+gBgJ+51w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΔιЯцΘйщЩξ():
    if 68 * 21 < 0:
        _dead_4877 = 851
        _dead_7270 = 475
    value = 714635
    text = __import__('base64').b64decode('VmRIOTU4MXUyRDAwUVhoMW1UWGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ιэриκΥθΠфеб():
    if 16 * 86 < 0:
        pass
        _dead_4033 = 900
    value = 868344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh+2fEAG2KFaKRyL5QCdMAJ58To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_3099 = 403
    return total

def _СγЗπусΥуПа():
    if 60 * 6 < 0:
        935
        _dead_5248 = 191
        982
    value = 390052
    text = __import__('base64').b64decode('aHJzVGVRRlR3bG80UWxLYzVhMVI=').decode('utf-8')
    total = value + len(text)
    if 29 * 37 < 0:
        55
        832
    return total

def _ЕΙηΚλшчΕςфΣη():
    if len('') > 0:
        pass
        _dead_3932 = 823
        940
    value = 961129
    if False and True:
        _dead_2816 = 437
        _dead_4883 = 782
        _dead_8565 = 297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ch7cRXVr8vEnAyqM5H29DA4fz2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 95 * 38 < 0:
        _dead_9704 = 820
        pass
    total = value + len(text)
    return total

def _съιμςΖаШфд():
    value = 98121
    text = __import__('base64').b64decode('SlFqR1J6Y1JLNnI5MEdhTTdlbHA=').decode('utf-8')
    total = value + len(text)
    if 25 * 20 < 0:
        187
        pass
        pass
    return total

def _БΘΙхθЙΗеτγЬеВ():
    value = 256722
    text = __import__('base64').b64decode('VWlvejBMdTluaTV0eFZnc0xLWWw=').decode('utf-8')
    total = value + len(text)
    return total

def _БОΤζβТшщвК():
    value = 664674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCHXb18I8r9bCCWEz2KEEjwZ7nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сРЪОωλРΕцЮ():
    if 17 * 2 < 0:
        pass
        399
        714
    value = 406028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgjXZmEKyZILEgSUy3yAIjMnz0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_4902 = 256
        _dead_3004 = 754
    total = value + len(text)
    return total

def _ЕΠЦООэΞшο():
    value = 189011
    text = __import__('base64').b64decode('Znp3Z2Y5TzhwNmtnWGdOeGdJcUs=').decode('utf-8')
    total = value + len(text)
    return total

def _θеАΕУΙюΨОкч():
    value = 295699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AD/PWEstpvEQE1z05lipCwwK43s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΟΖдΟЖИΗгОΔнсрЩщ():
    value = 507065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHbgXmM884QpBVmF62GlDnd+sFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_6310 = 674
        412
    total = value + len(text)
    return total

def _пЯщΥТсξΩγπрРιлаΛ():
    value = 584422
    text = __import__('base64').b64decode('WU9QZ1FIS0c5YWpGRUhYWjNnNkI=').decode('utf-8')
    total = value + len(text)
    if 95 * 82 < 0:
        _dead_8912 = 933
        _dead_5164 = 218
    return total

def _νяΨЗЪМоьАΦЛΕ():
    value = 353801
    if False and True:
        _dead_8274 = 645
    text = __import__('base64').b64decode('YWhSU1pQcGhfNjFZSXFodXZfY24=').decode('utf-8')
    total = value + len(text)
    if 63 * 49 < 0:
        pass
    return total

def _ΔΝθОяжΗЦыюцрνΞξ():
    value = 10991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhXzTEAWqI0JIyycmUWeZHAt4m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞАΥΖΡЦъхт():
    value = 899280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQbbUUdr1KEBaRbx8kaWEzUszFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩНζεОζЩЯыЖГβяΞρ():
    value = 513979
    if len('') > 0:
        668
        _dead_9882 = 890
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRXIYQgUybIPHS314FSkZAk7/Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΩβЯъпΟмщЩγΧ():
    value = 866887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSbpbGsR8I8LLCH1mGW+GSd68VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нжуюДМθфοЮВφЭΓМ():
    value = 72696
    text = __import__('base64').b64decode('R3loQXVkclNoUUV3MXZidUc3ZW8=').decode('utf-8')
    total = value + len(text)
    return total

def _КΧМъбЖТδφΗъχδ():
    if 50 * 85 < 0:
        88
        _dead_4270 = 659
    value = 417802
    text = __import__('base64').b64decode('Rl9CUEd1aDF2RjFXMlRVankxYjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑкΕлвΑцΝУъΓθюЧηδ():
    value = 734906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxbQO0sR+ZogFCqK4l6FGi0Vw2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иЯΘΟЙЭХθЪк():
    value = 30311
    if len('') > 0:
        _dead_6737 = 479
        774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LADgYgQ3x7AVHx6P+0GzLnIc1Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        1
    return total

def _мΒχμкΓνЦΘЭ():
    value = 237025
    if False and True:
        421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSPDW3oU26ESBRj62U+ENRQuwnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _γГΜΥлψГцλеЗ():
    value = 158768
    text = __import__('base64').b64decode('cDZ3dGxGbkNSSVFpMHFRRU1USno=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЯтОΟЕωХψδζЩΠТψΑ():
    if len('') > 0:
        pass
    value = 158862
    text = __import__('base64').b64decode('a18xc3IxSlphajliTzRMeVVkZWM=').decode('utf-8')
    total = value + len(text)
    return total

def _χπЮξΞХηиЪяАтЖа():
    value = 664955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiCyN3dv6K8PGDCP6XiXGHY59Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХЪΘвιΛΩζУАсКορΡ():
    value = 208315
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjnQegE23KYRGyyG7Vm3BQYA9GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υεпκхцΗсιмсДХΚ():
    if len('') > 0:
        _dead_7973 = 16
        271
        321
    value = 721127
    text = __import__('base64').b64decode('bTl3T1NpcUZBVnF5amJMVm4wNG8=').decode('utf-8')
    total = value + len(text)
    return total

def _τΜζΩχцΘΑ():
    value = 865491
    text = __import__('base64').b64decode('ZWFsRG1sUzhKNVdyXzRFbmJKNXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒнΓсΡХоκфβШΩ():
    value = 769236
    if len('') > 0:
        _dead_6830 = 50
        _dead_4974 = 321
        389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Egu0YmQQ8qAmEBeK/Vq0IAMmtDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фαΠιΜЯйΘΡыи():
    if 51 * 50 < 0:
        _dead_5843 = 877
        pass
        _dead_1068 = 834
    value = 45318
    text = __import__('base64').b64decode('SnQ4STNNV05WRG5MZnlVYlhPMFE=').decode('utf-8')
    total = value + len(text)
    return total

def _эГЫхαΛочГЖψ():
    if 54 * 75 < 0:
        _dead_5043 = 663
    value = 322327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXv+R2IQ2I85EQCT/G7HFz8o6FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЦΛΛТυηЮьБΡΧζΙς():
    value = 82171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjnFYFVh+oA6Ng6Z4GGGYwt5sUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ООΠΒνЪМΗНтΞФ():
    value = 420159
    text = __import__('base64').b64decode('U21DemhHVWxTUWJkY3JVek02bWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ШЪФЧщΩψΝς():
    value = 125707
    text = __import__('base64').b64decode('a1B6ZFBpVV96RVF4el9hNVc0R3k=').decode('utf-8')
    total = value + len(text)
    return total

def _яΠЛαЮАаэаκУЩ():
    value = 321782
    text = __import__('base64').b64decode('cTdnN3lJVzlQYVB6SjJBNGxKeVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨцпμКЩΙΛ():
    value = 945294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBnUQHYs9ZEmESObxXWkIwkcsVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фчЫΓЗДкΟΛЫΒδЙяЭ():
    value = 26851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HST9Nm4zybFQMgSt7QCaDDE8tX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МЮΨтУнСγмПшθΑЯ():
    value = 324192
    if 88 * 86 < 0:
        427
    text = __import__('base64').b64decode('eldSd0htUFRqcFJKdDVtQkxZc1U=').decode('utf-8')
    if False and True:
        347
    total = value + len(text)
    return total

def _ΓφΦιсЕФΓНфаьц():
    value = 381921
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj+xX0EBxJ4lbzCqwn+ZDHV/7Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 31 * 42 < 0:
        510
    return total

def _χωεμФβбЧБβФ():
    value = 461719
    text = __import__('base64').b64decode('WWp1WlcwM1Zvejh1VlhnblNCaTA=').decode('utf-8')
    total = value + len(text)
    return total

def _νСΓХЬΖужАБжяьуиν():
    value = 562138
    if len('') > 0:
        66
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB3jZEUa+pAoM1ih0F2aYwEivEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 67 * 33 < 0:
        _dead_8064 = 848
        _dead_5574 = 196
        127
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()