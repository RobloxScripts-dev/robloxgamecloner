#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _втΖдΛькоВΘΜТДΞσφ():
    value = 590347
    text = __import__('base64').b64decode('SGl5ZXdKczB4Mjhkdzdhb3lZQWs=').decode('utf-8')
    total = value + len(text)
    return total

def _яςэРиνбηун():
    value = 312844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAyyfWAVp6BQDxqvmFuKYw08t2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞкгШφЪψч():
    value = 740398
    text = __import__('base64').b64decode('TE95cGg3Q1BSaWY5aUt3dUlEemk=').decode('utf-8')
    total = value + len(text)
    return total

def _БΔΝηЪφФеХБцХΣδф():
    value = 348191
    text = __import__('base64').b64decode('UmlaNjl2aUVjUnl2cXNBR3FFbTM=').decode('utf-8')
    if 61 * 92 < 0:
        _dead_7178 = 332
        106
    total = value + len(text)
    return total

def _ЧωιГКеРЖовΣцО():
    value = 156079
    text = __import__('base64').b64decode('a0x5U3JnRDZQbGd4Snc2dFJDYTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _фλшβоΓЭйУтХЧФΙΠб():
    value = 904322
    text = __import__('base64').b64decode('VWVvSWpDNFpXSHFRcGQyUmxSeWY=').decode('utf-8')
    if len('') > 0:
        599
        587
        pass
    total = value + len(text)
    return total

def _ПяοЯцыпхП():
    value = 397826
    if False and True:
        pass
        pass
        712
    text = __import__('base64').b64decode('Q3F3UzIzNXdWYXhJbGVfRjVhVVM=').decode('utf-8')
    if 83 * 40 < 0:
        _dead_4785 = 900
    total = value + len(text)
    return total

def _еЧΟжХлАкΥΘЗАвцυ():
    if len('') > 0:
        436
        pass
        200
    value = 293261
    if len('') > 0:
        pass
        pass
        695
    text = __import__('base64').b64decode('SThOMjlOcmpRVFVfaUlRTlVEaXQ=').decode('utf-8')
    total = value + len(text)
    if 93 * 10 < 0:
        _dead_3171 = 761
        _dead_3949 = 698
    return total

def _ЛКχγσАбхДΘсяφлΙ():
    value = 498163
    text = __import__('base64').b64decode('TE50dzg3a0tqMFNwYnozOXFRaWs=').decode('utf-8')
    total = value + len(text)
    return total

def _МХТφΜИζуΨаχКФΓНм():
    value = 633835
    text = __import__('base64').b64decode('QjRSbFc2YWRYZUc1a1VxZ0tuVmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ηλиФеаΡχ():
    value = 40283
    text = __import__('base64').b64decode('ZmwxNVlJVUlxS1lSTkFlZ0o2amQ=').decode('utf-8')
    total = value + len(text)
    return total

def _АжπЬσУψЫλψ():
    value = 189062
    text = __import__('base64').b64decode('aW1meUFXa3FXTFlSaUhaQTBtMGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩщΕЗрΟωςК():
    if False and True:
        _dead_2730 = 299
        196
    value = 166291
    if 37 * 35 < 0:
        pass
    text = __import__('base64').b64decode('cElFWE1pWmNLVk0wV0JlSndSZF8=').decode('utf-8')
    if 64 * 65 < 0:
        pass
        460
        579
    total = value + len(text)
    return total

def _ΩЭцοЭΒξΜλпчОηДςΖ():
    if 2 * 72 < 0:
        pass
        831
    value = 515426
    text = __import__('base64').b64decode('eGdNSXVabWRKQ2FERk1pRTVRY1E=').decode('utf-8')
    total = value + len(text)
    return total

def _лωΦоДΝхжртеъ():
    value = 536124
    if False and True:
        628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng2zPnUjq70bLyWswUCWZi4ezX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        104
        pass
    total = value + len(text)
    return total

def _ΙβпιЫбζςуЦΝΩж():
    value = 405072
    text = __import__('base64').b64decode('eVJIZFk0eTRYOGlSaVFfUGRCVjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑΜχюΧδμπμнΠдλ():
    value = 117776
    if 35 * 68 < 0:
        _dead_7796 = 466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgThfAUd874AFRn28WaHMzMc20E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        68
    total = value + len(text)
    if len('') > 0:
        959
        pass
    return total

def _ъεЮьΙЗШσ():
    value = 208415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSXcfVM8zY5bCT2rygHIJR8fwzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΧτхχΥΝБББжГΖΩ():
    value = 277311
    if False and True:
        229
        _dead_1006 = 753
        468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHbefEsI1IcvIyKI/2acPRUGzHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘКΔβΙаиънФΝ():
    value = 606257
    text = __import__('base64').b64decode('ZzhPb2NNNlJZMUpwMGdJZnJRVUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕοθйΒъдьΘЩ():
    value = 515670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCH8PgIV/K8SYxi6616KPyAJzFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηυгЩЗаΜαθЯΥΧΗдьж():
    value = 661179
    if 81 * 92 < 0:
        985
    text = __import__('base64').b64decode('aG14ZFpTcFpaZWtoT0R3WlNteUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΦЮβыζКАиЖЖΞрεεМ():
    value = 968934
    text = __import__('base64').b64decode('UlVHbDRjNU1nMXdtck9ZcFhMY3U=').decode('utf-8')
    total = value + len(text)
    return total

def _втВЦтПΜΝΑУΤхνцБЕ():
    if len('') > 0:
        579
        pass
    value = 45334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzW8a3oO/40LDzaKz0OWGCsOx1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΣλβАΗосθДю():
    value = 227881
    text = __import__('base64').b64decode('YVNKWEp4V2VfcENrV0RsWkd6aFc=').decode('utf-8')
    if False and True:
        _dead_1631 = 497
        pass
        pass
    total = value + len(text)
    return total

def _иΑτХΜмЖШΗΙсΔωР():
    value = 88302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBvFeVM41YksMAikkEGeMHw9/X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςςχπΡЯгЬ():
    value = 508938
    text = __import__('base64').b64decode('Y29MYmRJWjV1ejhlbWN2aHFNNEg=').decode('utf-8')
    total = value + len(text)
    return total

def _σεθνςМЕχаυ():
    value = 366893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDnuT1gD7YAXCQSQnl7AADQB90A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        542
        358
        pass
    return total

def _ФбоыДбΠЦΩλ():
    if False and True:
        pass
        pass
        456
    value = 924607
    if 38 * 6 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CznKX0kowYVbPSSLxwWvYxUV53c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5151 = 114
        _dead_3411 = 113
    total = value + len(text)
    return total

def _АТЕΡζΡЯХΡрхеψ():
    value = 132276
    text = __import__('base64').b64decode('eFBDOGxoRW5iZzF0YTdkMFgzS04=').decode('utf-8')
    total = value + len(text)
    return total

def _пΔЛТбρпχνпп():
    value = 375984
    text = __import__('base64').b64decode('Z2tNT3dCWF9hT2RXTVRFQmNkNUc=').decode('utf-8')
    total = value + len(text)
    return total

def _γтЭουСψВΤьОιь():
    value = 596998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhrXWVcPxJwhOx6p0GKIYjAi0Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟНωЧΦΗυАσΜЩεΑэ():
    value = 405538
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ijn1aUtoy4kUIgjz+AegOCYgtmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        407
        pass
    total = value + len(text)
    return total

def _ψωγΥψΛнГ():
    value = 679128
    text = __import__('base64').b64decode('UlRXWjFVU0l2ZGQ4bTdiMGpfNHU=').decode('utf-8')
    if len('') > 0:
        298
        118
    total = value + len(text)
    return total

def _ωΩрΔрВцы():
    value = 881926
    text = __import__('base64').b64decode('V3Z5eFNwQUlIU25zNkIyMHhnd24=').decode('utf-8')
    total = value + len(text)
    return total

def _СΣαНυρхδμ():
    value = 295727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCHQOH881rkHCAGw5AWiEnEut1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηКΔАФδιДξΜлГЯИΡЛ():
    if len('') > 0:
        791
    value = 680002
    if 28 * 53 < 0:
        672
        457
        pass
    text = __import__('base64').b64decode('dEdmMk1nSV9XMlRHMXBWN245X0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ξПχτςΣхαфЧΩΖРкγ():
    value = 435541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBrselMf879XPgCxkX2JZzU9vEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3982 = 617
        _dead_4184 = 469
        988
    return total

def _ΛяГдДΧΑЫшШСн():
    value = 612429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IS7JXn806o8qNRi6ww6pLRoQ40c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3295 = 758
        762
    return total

def _ФтοβσΜοпА():
    value = 739202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQHFeAMP+oQ2L12V8He4LjEW0ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        868
    total = value + len(text)
    return total

def _ΠэΖцнТЮэзЪэ():
    if 3 * 60 < 0:
        _dead_8675 = 553
        _dead_3480 = 858
    value = 494717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwTdN2Q794k2DFyn/Ua3Mxp55mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        369
    return total

def _ςдоРУьεδξ():
    value = 758135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pxjjfnshp4wHHyDynQejFhR31GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨАйΓΧЯсΤαςмХн():
    if len('') > 0:
        pass
    value = 19190
    if len('') > 0:
        180
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AS7FN3cG0PBWH1ub7G+KYwF6vEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БДЕшОΨΑН():
    value = 533509
    if False and True:
        800
    text = __import__('base64').b64decode('em1idjNoZ2dQNHVsR3g0M3ZsWEo=').decode('utf-8')
    total = value + len(text)
    if 16 * 85 < 0:
        pass
    return total

def _БΤΤУβΣΥλμЗВΙφГБΥ():
    value = 919462
    text = __import__('base64').b64decode('dzh2a2hOZGVES2ZMTEtmdnhiSGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖэзЬθЛБеςмШΙγН():
    value = 945663
    text = __import__('base64').b64decode('bWZSdFJWSmd4OGdETGI1dXRjdzA=').decode('utf-8')
    total = value + len(text)
    return total

def _сЙЛАбΡЭнηεΠьЯ():
    value = 102539
    text = __import__('base64').b64decode('Y2JwQjQ2T1lvUFZFenBLUE8wWDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΨПхиτΕψεθ():
    value = 425492
    if False and True:
        719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky7Hd2Yf74ICPRv2mE+nEQEWzGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2114 = 164
    return total

def _ъζβЛκШζнκАρπσβс():
    value = 886101
    text = __import__('base64').b64decode('YkFyRkJYREdZdUVDWVYxTVlvc18=').decode('utf-8')
    total = value + len(text)
    return total

def _вθнЗνфьпг():
    value = 491275
    if 38 * 22 < 0:
        _dead_6226 = 102
        _dead_2533 = 88
        521
    text = __import__('base64').b64decode('RU9DbFc0c2h2ZjZTOXEwOVlvYkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ГρζτΖуЗэЫПγκБΓΥ():
    value = 375221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pym1O2YazZBTFCSq4n+CE3Q74Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΚγхФюοΒФЧμАΓж():
    if len('') > 0:
        459
        _dead_3467 = 906
    value = 220184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCXFQVQBrqQQaVr0+HKdGxAAzj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8005 = 227
        _dead_3805 = 360
    return total

def _рЕзАωГυψ():
    if False and True:
        _dead_1241 = 158
        pass
        565
    value = 123607
    if len('') > 0:
        894
        1
        785
    text = __import__('base64').b64decode('d0dIVWRNTExDWk4zY2FQWWFPaXE=').decode('utf-8')
    total = value + len(text)
    return total

def _εцАνΧΤмκЮ():
    value = 556743
    if 72 * 22 < 0:
        454
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByDWZV5s16YEBVuA5lOdLXIo4Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КДтэηΗΛоν():
    value = 938837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyHrZgUg150JIjuUzGWRZyB88zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шхиХэмгεμЕαКЗ():
    value = 706150
    if False and True:
        pass
        _dead_4348 = 307
    text = __import__('base64').b64decode('ZGQ0REMzb0ozRVZRblBCWEpnVEM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        528
    return total

def _ςΧзЦВФЭЦπ():
    if 16 * 64 < 0:
        981
        _dead_9607 = 665
        359
    value = 841197
    text = __import__('base64').b64decode('V0FmOVliWDZDdHhjelNOcVRUN3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚΟИЖΙЯрэ():
    value = 780306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwzJYmVsr786MFaO71WIOicfwkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦйφрФЗяΤΛУвΨΛ():
    value = 4440
    if False and True:
        811
        _dead_8205 = 627
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx7AQ3xp+P1TEzWL8VmlBQcs6EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 27 * 81 < 0:
        227
    return total

def _ΓΖΥΜζгХЫ():
    value = 53235
    text = __import__('base64').b64decode('RXhvUkhJMlNyY2RqYzBEc2hSWWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _бτΑАΥπΡСРΓ():
    value = 216936
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCzgPHA0371VOB6J5ViaHXc1yVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8177 = 707
        295
    return total

def _ЧэлщЛνгНυ():
    value = 129766
    text = __import__('base64').b64decode('bVJwX0tQanRWVHFWWGVUekRQRmU=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΓΖТΒΤДηΙΥЮрХеΤ():
    value = 764309
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTfLPgggy/8JFxa55FS7ZC8n1Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТБЗσИЕЭΛΓν():
    value = 401291
    if False and True:
        _dead_2077 = 865
        369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjfAeFZpqIQvFxqu7lC0EyYX72A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        936
    total = value + len(text)
    return total

def _ЮυΗЦΜμШДεΗκЯ():
    value = 827774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCL3ZkMOr4FXbTq5yVG2FjcptEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щпЕъΨЧιΛωщξΦΔΩ():
    if False and True:
        pass
    value = 246952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KibMN1hq+rsINB+l7UaIGBEEs3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_6766 = 295
    total = value + len(text)
    if len('') > 0:
        446
    return total

def _ΑыМθыЭеьμΔ():
    value = 99700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADX2e2se7qYwGAyvynzDLB1+zmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠъЬΓΡΞхФφВЗЙΙщΟ():
    if len('') > 0:
        _dead_2801 = 511
        pass
    value = 355712
    if 15 * 95 < 0:
        _dead_7370 = 194
        _dead_1228 = 17
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah3SW2Ih6Iw5KCG1y1eZIQAjzEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 89 * 58 < 0:
        _dead_3816 = 486
        _dead_1472 = 670
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _зБΚВкжЬЛФСΚΡςΤ():
    value = 264259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID/IY1c30I0ZajWN3n60ZTUF80Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΚΒтиъρеЗΨясто():
    value = 992770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzXDVmA26ZkWC13wwX+SHhom1D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        549
    total = value + len(text)
    return total

def _КЙξΨУτβπΥлζ():
    if len('') > 0:
        pass
        _dead_8624 = 927
    value = 431587
    text = __import__('base64').b64decode('RlE5U1dWWGR0dGlkY0lnMVZUZ2w=').decode('utf-8')
    total = value + len(text)
    if 70 * 80 < 0:
        _dead_9545 = 913
    return total

def _βщΘтТψΘΠςхςκ():
    value = 391577
    text = __import__('base64').b64decode('VWdxZWw0SWplaFh4UEJXQ016Yks=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜψЬжΩΡЙεΣγΘЕζχЖ():
    value = 679564
    if False and True:
        842
        286
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHzWd0sN7ocJHSmLn3KCJTwBvHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        924
    return total

def _ΩΠЬгΕριΓΠςцεшу():
    value = 548254
    if len('') > 0:
        946
        _dead_5059 = 944
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PC7NSnhp/4okbTC68FyqBAA58Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯξΚкецΨИклςΚωщΡ():
    if 6 * 77 < 0:
        25
        198
        _dead_3718 = 385
    value = 850070
    if len('') > 0:
        _dead_3111 = 338
        381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzjATGNpr5FUOSWx3XuaEyQ87lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПоэΙΧЬΛюТщ():
    value = 256315
    text = __import__('base64').b64decode('WVVwYURmbjBJQzlaYUpVeXBMVTY=').decode('utf-8')
    total = value + len(text)
    return total

def _πΘρπиФипοтΩИΖΙ():
    value = 400604
    text = __import__('base64').b64decode('RTNJNE13M0NYeFkzVUUzTVJ0T2o=').decode('utf-8')
    total = value + len(text)
    return total

def _οХбфйΠμШ():
    value = 790352
    text = __import__('base64').b64decode('aFFGMkUxbWNGYmhDZEFDV0M5UHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩнчКДπνИЪγΓд():
    value = 93660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NijvZ2c6+b0AGQyB3nWWBSh7x3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 17 * 74 < 0:
        586
        _dead_2379 = 646
        _dead_2729 = 790
    total = value + len(text)
    return total

def _ξсΕσΤτяωΜΜФэхФτι():
    value = 365800
    if len('') > 0:
        864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kna1d3tsxIAmAFquzlWeJXIitUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яюΩνζωжЧмλЧφрΝ():
    if 13 * 69 < 0:
        319
    value = 836091
    text = __import__('base64').b64decode('UU9zYUxfdlhBTnljdk1oV3UxTmQ=').decode('utf-8')
    if False and True:
        _dead_7778 = 992
        pass
    total = value + len(text)
    return total

def _ΨΙКΠπеψдΔΒΛφаХ():
    value = 233885
    text = __import__('base64').b64decode('aXlqSVMxOFp0UU53UU1RMDFra0I=').decode('utf-8')
    total = value + len(text)
    return total

def _θбΒЛФκЖГΑЛ():
    value = 426748
    text = __import__('base64').b64decode('VDlkYnZ2b2NRV193VG9ZREJ2SXY=').decode('utf-8')
    total = value + len(text)
    return total

def _зΒДΤрТБмЧЭπζΟ():
    value = 27446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAjjZAMpzo1UMwGn3HzEEAMAtUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СчуΜчηЛγдοрεЪ():
    if len('') > 0:
        pass
    value = 471879
    if len('') > 0:
        883
        519
        pass
    text = __import__('base64').b64decode('bDhDbXNzeURhc1poMnBnT1V5aGE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6756 = 78
    return total

def _ζГΖЕчюхлΔψмЙц():
    value = 401874
    if len('') > 0:
        771
        125
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSb9N3APzo4OFzmu2XeaNQQc1Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3668 = 10
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxxxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    237
    210