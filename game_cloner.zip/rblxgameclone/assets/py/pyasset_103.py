#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _цμаФκЬлОД():
    value = 460174
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgHNbG44+6MiOBiJ8GypACoL/mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 69 < 0:
        17
        _dead_9081 = 182
        293
    total = value + len(text)
    return total

def _зрхЦΘУψфХ():
    value = 710904
    text = __import__('base64').b64decode('dkZHSXQ1Y1cxN0l4dmljRElBcHU=').decode('utf-8')
    if 64 * 78 < 0:
        _dead_1628 = 145
    total = value + len(text)
    return total

def _ВτяρДΦТζθ():
    if len('') > 0:
        _dead_1834 = 13
    value = 665688
    if len('') > 0:
        434
        _dead_1693 = 681
    text = __import__('base64').b64decode('dElZYlNKTEF5MzZ0d19zMlhIRjM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_9329 = 702
    return total

def _πΦчΨиΟχтξνψκ():
    value = 664985
    text = __import__('base64').b64decode('YjlkQUdYRFprd2JxNE5xUGFoc0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _хржЬрαсчФΨ():
    value = 710082
    if len('') > 0:
        pass
        _dead_7711 = 133
    text = __import__('base64').b64decode('d256N1oyYzBqR0tXZTdkaTNpNHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗКΞыλζЗЯΝИСψκ():
    value = 652189
    text = __import__('base64').b64decode('azBzdlhIbkFRUkxXc1NIVXZXc2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΓΦйДьчкР():
    value = 151755
    text = __import__('base64').b64decode('RDl5OEpBd0FTdTh3X1FLVnNTenM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΚφфθхтΑиΛθФЖΝрж():
    value = 240732
    text = __import__('base64').b64decode('ZUZCZGtHd1FTVnpkSzA4R016Q1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΕΧαΜΙхдф():
    value = 267614
    if len('') > 0:
        996
        _dead_9119 = 912
        pass
    text = __import__('base64').b64decode('T3N6YjBYM1NPTDh1YTBCcUpYVms=').decode('utf-8')
    if len('') > 0:
        555
        pass
    total = value + len(text)
    return total

def _ΜЮщщοΜιМςАэФъΜКч():
    value = 856543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgrjXGMa2KcRMSm57nycMTEt7Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛщαШςΨμЗГ():
    value = 114037
    text = __import__('base64').b64decode('YlhVelRHcG1WT0luVVhZUTFubV8=').decode('utf-8')
    total = value + len(text)
    return total

def _ХбΣΗΑΜΖХ():
    value = 551763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnvoR0Ex0bkmDg2q+1SUBx0ltTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        31
        pass
        381
    return total

def _μζтеЬΧΟХπ():
    value = 293151
    text = __import__('base64').b64decode('VHFOT0JDaFJQc2VSOTlPOWpqYVU=').decode('utf-8')
    total = value + len(text)
    if 61 * 64 < 0:
        196
        _dead_7462 = 300
    return total

def _ХтγИАΩηюЧΧРΙЙнсΑ():
    if False and True:
        152
    value = 886313
    if 87 * 64 < 0:
        pass
        pass
    text = __import__('base64').b64decode('akIyXzFJUDFGY3owVFlZMlI0QUg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        637
        614
    return total

def _щΥЦсюЫЙШьбЦщβΣОΓ():
    value = 990203
    text = __import__('base64').b64decode('a0Vjb1JNYVRjTXB3MDJpQWtHb3c=').decode('utf-8')
    total = value + len(text)
    return total

def _τВяΠйΠβйωΗΧπΟОΝΗ():
    value = 497243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjbRWWka6Y4kDhz0kFKjEHF+wno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μТςуЪлεμΒΤфξ():
    value = 232653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh63e0sU16UqACepwwOxHnEXyFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛσΔОэΘфСβΚΞ():
    value = 160697
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjjNWARq8IQVCVzzxkGUEH0G5Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        949
    total = value + len(text)
    return total

def _ΧΓПЖоλЗι():
    value = 757443
    if 7 * 99 < 0:
        pass
    text = __import__('base64').b64decode('d3Z6VGp1aDJIblVid1FNaFdVeWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ηηΗОРγъζΡщ():
    if 51 * 33 < 0:
        _dead_5926 = 555
        _dead_2247 = 772
        pass
    value = 950358
    text = __import__('base64').b64decode('YktXQVdGcW9HU2RWbDg2TkpSa1A=').decode('utf-8')
    total = value + len(text)
    if 83 * 74 < 0:
        pass
        _dead_7155 = 753
    return total

def _ΠиοрΓλат():
    if len('') > 0:
        pass
        _dead_9407 = 630
        _dead_7019 = 791
    value = 99274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CR7jQFoTqa05ECW0xwC+YiEH52s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΘΗμΚИсψЙΡΠф():
    value = 346161
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHnLOUkU74YUaTWb4lCYASMc7ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞыΕЮкΛΗЩνС():
    value = 594139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyqwNkQz9LIILDuw3VySIxMV0z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СэΟыςσЭШфπь():
    if len('') > 0:
        134
    value = 467603
    if False and True:
        pass
        207
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Chb1eUUh9fAwF1ab2m+mYiR/9H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        839
        pass
    return total

def _λΜνδιтфлЩоя():
    value = 756156
    if 49 * 10 < 0:
        pass
        pass
        _dead_5229 = 826
    text = __import__('base64').b64decode('RjhVc1VaWWZ0VDN1eTNDS2htNjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΑкΝΨйшЙρ():
    value = 321644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQu1Y3AV5K4bPSqa2Q+2bBIQ8ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        675
        pass
        _dead_7483 = 206
    return total

def _БЯмчбΘИυΦМμЙιйУд():
    if False and True:
        990
    value = 95741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCv2fEAQxp8CNzuQ+FWFGR8L3nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2942 = 397
    return total

def _ЕпаΥЬАσψг():
    value = 74219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxDUT0Bu7Jc2MBm12mynNyg643g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 53 * 85 < 0:
        pass
        93
    total = value + len(text)
    if 87 * 72 < 0:
        pass
    return total

def _ΦηιВшψАХоПгΦ():
    value = 275169
    if 86 * 19 < 0:
        _dead_5172 = 92
    text = __import__('base64').b64decode('al9iTkpCRTE5YWxJTDdaREdFczU=').decode('utf-8')
    total = value + len(text)
    return total

def _ъмΚяуΖСьςшγС():
    if len('') > 0:
        pass
    value = 512394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBjvX0kN+adRNRaJ2UajBRR3zVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1170 = 750
        47
        732
    return total

def _ΘЗсπχБпЮψΟэЗЮΣЖ():
    value = 620475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAHHYXcB7LlUHTyz/AO0Nzcf9W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥЫγΧВΞкщЗ():
    value = 266874
    text = __import__('base64').b64decode('SW5QTm1hcTh0anZ6S0VxdUtKOW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕхεВфИΟυΩΝщХЦчЮ():
    value = 616018
    if len('') > 0:
        487
        _dead_5968 = 533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjjhSnc11b0mIi2p+wXFMi4s5WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3218 = 158
        _dead_3023 = 165
    total = value + len(text)
    if 12 * 2 < 0:
        pass
    return total

def _ΤτщΞМФΒςяλнζπ():
    value = 529236
    text = __import__('base64').b64decode('YVVqRUFVZmhlRjlJeEpQZWdQRHc=').decode('utf-8')
    total = value + len(text)
    return total

def _юрΤсФΝДэεЪкκ():
    value = 508366
    if 83 * 23 < 0:
        pass
        333
        338
    text = __import__('base64').b64decode('cElSWGNGRXppUEdMVjVWVUk1SUM=').decode('utf-8')
    total = value + len(text)
    return total

def _οωрςуνΓЩы():
    value = 746044
    text = __import__('base64').b64decode('S2VPbnUwTHFhTjNFbDFvUnMxTHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟμЫψΖюцбεЩ():
    value = 923306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTbhTVRp9oUsayiQ5QWUZDQisDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _хКЛЪΝЙΩτξΨЯαΕЩδ():
    value = 805819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERXvXWIdz7krNAeJx06JPSJ97Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        406
        _dead_5032 = 464
    return total

def _ГЭΜαΧΠвЖцУыДЗΓχ():
    value = 656180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhjsbEM21/gFHyqU+F6yGxEL8k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БДбΛДУΡэΚ():
    value = 482292
    if False and True:
        _dead_2325 = 665
        _dead_7833 = 122
        174
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzXbRAM0+4MnEz2S2WXBMBZ25kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4869 = 546
    total = value + len(text)
    return total

def _оΟΛЫБΗпЪЭЭсЬъ():
    if 29 * 26 < 0:
        pass
        _dead_7451 = 562
        717
    value = 954086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwXpPGMa2PgpbDus8lnJMBoL1Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4872 = 955
        _dead_3665 = 826
    total = value + len(text)
    return total

def _лцйΥНςХΝ():
    value = 980186
    text = __import__('base64').b64decode('d0lScmk4Wmp5akpoOVpNQk9nWkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦЬλιωБвШжσНЕ():
    value = 817513
    text = __import__('base64').b64decode('ejllY2I1emNMTHB1YkRzeXZObVc=').decode('utf-8')
    total = value + len(text)
    if 83 * 43 < 0:
        pass
        865
        pass
    return total

def _ΕΝмχРвΨΝ():
    if False and True:
        pass
        pass
    value = 532471
    if len('') > 0:
        187
    text = __import__('base64').b64decode('S2hxWV9iWmJYU1RGRlhJOUc1NmE=').decode('utf-8')
    if False and True:
        _dead_7761 = 880
        pass
        _dead_3523 = 554
    total = value + len(text)
    return total

def _ЙдЯРΠΨΦβЕга():
    value = 576514
    text = __import__('base64').b64decode('UXFBbFBBRkNRa1Jzd0d5SnZ1VmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _НтβκюмШΥ():
    value = 357879
    text = __import__('base64').b64decode('WVJ6a3dmRnA0TjRPcG1jWTZXazM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤзΖΝχнγΙмНыЖ():
    value = 136864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IijCOn0T07kRaFqg5EygBzAGyXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 21 < 0:
        _dead_4543 = 612
        825
    total = value + len(text)
    if False and True:
        _dead_4345 = 691
    return total

def _λΨμнЯяΖйф():
    value = 693079
    text = __import__('base64').b64decode('bE84dGdYZVFwSl8yTFY4OUFFSkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩНμИρΟОλσιΨπΩ():
    value = 990487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwbqZwBg7JAJMBiq3VieZgQcw34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФРΡБπчσУξξς():
    value = 208738
    text = __import__('base64').b64decode('ZmhwVE05VWx2WUs4RnZRcDFvZWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ГьйяЫЙτΔπηшпЛ():
    value = 312336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DC7+W18q+YdQPBmkmWGVYRc1/UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣлБкщЙЦБЖЗιΖц():
    value = 372224
    text = __import__('base64').b64decode('ZUU5ZG8yd1ZPTDZud3BkYzFaUGU=').decode('utf-8')
    total = value + len(text)
    if 4 * 49 < 0:
        669
        pass
        _dead_5547 = 195
    return total

def _мρΧИУЬσΩчεЭК():
    value = 469259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAX0WwZq164zFCuakHmxY3IlvD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ярΔХрЪЩαΕФФтЬФЗЫ():
    value = 269129
    text = __import__('base64').b64decode('YlowNXd0WWtBOEgxU0FvUjhya04=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΙΤыκΟσβΒφДЯ():
    value = 151763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAjSYElg+aQgGzy7mHq7FgYG6Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НкΧеτТЪΠЮΖΛаπе():
    value = 819158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj3LVwJo2J0qL1mxxnHCBxodyTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬνтХкоюКкйоΩφγ():
    if len('') > 0:
        _dead_5913 = 662
        759
        pass
    value = 355734
    text = __import__('base64').b64decode('ajZnd2tERDdrYkVUaXdUNk13dUM=').decode('utf-8')
    total = value + len(text)
    return total

def _чхЗЪРахξζКЬοЮ():
    value = 434444
    text = __import__('base64').b64decode('b3MxeExnVlJhWFhpRjFwbnk3Tlo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2979 = 733
        pass
    return total

def _ытЕбκθЕиЦρл():
    value = 539109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NALbZnst6I4QNiS3wkyIFyZ96mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩмλξбΣАЛφФσэч():
    value = 392198
    if 11 * 24 < 0:
        _dead_1730 = 869
    text = __import__('base64').b64decode('UVpqV3V4bmVtWVduZWVKdmZ1RWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΣΑδтАЮолъσμЕ():
    value = 788316
    text = __import__('base64').b64decode('Z0hMMGNhZTdmRzRrZXZoOHVrdTg=').decode('utf-8')
    total = value + len(text)
    return total

def _йΣтрιйδΦцΑΦ():
    value = 196217
    text = __import__('base64').b64decode('VEVGSGN1bUFKeTU1YktJRXdqSkU=').decode('utf-8')
    if 50 * 23 < 0:
        _dead_6436 = 274
    total = value + len(text)
    return total

def _Уврййгςр():
    value = 255659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgHbaVUu2IsiOCqu5F+dOzYowUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бρζΦцτОУйΧ():
    value = 409374
    text = __import__('base64').b64decode('UTBKVGE4bUdyVGxiaGZuTnVaX0M=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8756 = 862
        pass
        _dead_9356 = 934
    return total

def _щвΦпΙσСοвтΝγ():
    if 12 * 80 < 0:
        pass
        390
    value = 977692
    text = __import__('base64').b64decode('cW82bHV0Ukw3d0xrQXNjY3RVY2k=').decode('utf-8')
    total = value + len(text)
    if 53 * 60 < 0:
        424
    return total

def _ΡшсΟгΛδμΞςЭ():
    value = 121536
    if len('') > 0:
        527
        _dead_6436 = 640
        542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3zjaQAo77osCwmt0HSSLnQCw2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯГкааψγПлЖλп():
    value = 795244
    text = __import__('base64').b64decode('T3pDa3c2YmR1cVpmT0ZTWmZYWVo=').decode('utf-8')
    total = value + len(text)
    return total

def _вθывρЯкГБыз():
    if 36 * 64 < 0:
        _dead_6859 = 196
        858
        _dead_7695 = 76
    value = 822998
    text = __import__('base64').b64decode('bWRZazRDTlYwc25BM1M0MG5hRno=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔрыцςυДьΝξЛуΗ():
    value = 762160
    text = __import__('base64').b64decode('WXVZaFdTVldaZXZQZ2lzb0haSU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΞΩρυЖωεКюфτДПΗс():
    value = 489785
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ7OeEMcrLI1NCqumX+mJHUN6k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΝχЭжжыЦψшжбдпζ():
    value = 641491
    if len('') > 0:
        391
        833
    text = __import__('base64').b64decode('dTZURzd1d0xPVmVnWjcxTHJCWGE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8463 = 835
        _dead_4911 = 228
        _dead_7429 = 264
    return total

def _зλλξχСλυяηчй():
    value = 65437
    text = __import__('base64').b64decode('eWpsZVVrMktscURMcUdnb1h1OFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΔεрεξЯхЪ():
    value = 673459
    if 89 * 25 < 0:
        _dead_2032 = 265
        _dead_6645 = 408
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHrRNlc764MiNRn1+mOWLi476E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΣВМсИкУφ():
    value = 431757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ3LRG4zyJJabh300XqyZBcW40Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фλΗВШГКχ():
    value = 913479
    if 93 * 61 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSTmR3YwpqEiKFqWx3+0GjACz2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        530
        234
    total = value + len(text)
    return total

def _ΝΣΛΣΜζΠиЧξТ():
    if 11 * 84 < 0:
        _dead_2215 = 465
    value = 982238
    if False and True:
        pass
        pass
        _dead_1335 = 15
    text = __import__('base64').b64decode('dVpCS0JCb0JRaVhQYlZBaGZMWDU=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _щжΚеИΜΞФμΣψяд():
    value = 454780
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAi0PEho6IUZH1qS0HyBCzILslg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        185
    total = value + len(text)
    return total

def _нИЗΠγΤкЯ():
    value = 101653
    text = __import__('base64').b64decode('THpkMkljeUxiRG03ZmpoY2tGMzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝэЖΧхйχΓ():
    value = 395556
    text = __import__('base64').b64decode('S2Y1c2dFdTh0SU8zRjFEcnJwMWY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8306 = 462
        pass
        843
    return total

def _ДЮдЭеСцв():
    value = 635495
    text = __import__('base64').b64decode('T0Uxb2p6WG0yV2dhNk13Wmt6TzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡбФςшиПжΡΟмЧζТИФ():
    value = 218597
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXzTeGYM0Yc1Ozfz6WyePAl+6UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πЦΨχБδργοТОΨп():
    value = 500461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3rWTF9v768SKw6q/Gm5Jwwe8kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣВХΖβΜЪнΣΜКν():
    value = 978067
    text = __import__('base64').b64decode('SWVXZ3BCaXZrdmg2T2JUQkJ1eTc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _шЖΞжФΓпЮе():
    if False and True:
        pass
    value = 44131
    if False and True:
        pass
        293
        _dead_5391 = 939
    text = __import__('base64').b64decode('UlRvbkUwbm1uZHZqU2cyYnBaV3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЧОсЛφэΞхбρΞΣ():
    value = 419442
    text = __import__('base64').b64decode('cGNWM2w2YkQyTDMzdVZNV2ZETlo=').decode('utf-8')
    total = value + len(text)
    return total

def _αаΠσЩξНΦψВΤЦν():
    value = 491469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Diawdgkpr58EKDex4V/GBgEn3Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щНμеэХγΣχ():
    value = 148589
    if 22 * 53 < 0:
        pass
    text = __import__('base64').b64decode('Y29MX3BHekNKWlJZd3VVczNxSEY=').decode('utf-8')
    total = value + len(text)
    return total

def _доξβэьюγΝГЗЕьοЧЖ():
    value = 948784
    text = __import__('base64').b64decode('ZlhnQnZFUHZxMHVDTnNfVWpmZ2E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5980 = 296
        pass
        _dead_3766 = 327
    return total

def _РτЛΨλπКνхьЦ():
    if False and True:
        pass
        _dead_3214 = 439
        734
    value = 187798
    if len('') > 0:
        _dead_9367 = 829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQD1egNpy/4yAxqg5gSaJQQ6/kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 38 * 81 < 0:
        61
        35
    total = value + len(text)
    if 32 * 20 < 0:
        345
        pass
        _dead_5483 = 409
    return total

def _ΠΨПΙΜКΥдМΩ():
    if 97 * 11 < 0:
        _dead_4569 = 587
        pass
        775
    value = 978561
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwnDYHUw+4E3KSb77kWnHCk161c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_3764 = 70
        266
    total = value + len(text)
    return total

def _ΩρΝζχΑЭЪη():
    value = 408695
    if 5 * 36 < 0:
        960
    text = __import__('base64').b64decode('SXNPQ2lVQWV6bk5RYUo4QnhOcEc=').decode('utf-8')
    total = value + len(text)
    return total

def _εεςηлЧνсчЙ():
    value = 860243
    text = __import__('base64').b64decode('dXFsb203NTNpUDg4d2d4RHQxUk8=').decode('utf-8')
    total = value + len(text)
    return total

def _πβзЧΘλЛκВЭαрωΣТΘ():
    value = 1339
    text = __import__('base64').b64decode('cFoxc0xiQTFOMWtoT1BXY2xyeGo=').decode('utf-8')
    total = value + len(text)
    return total

def _НδыςιΞщιυиΞыΡг():
    if False and True:
        pass
        pass
    value = 684944
    text = __import__('base64').b64decode('R0dUVjVJTjlmd2t0RWN6RTVYX2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _НΛдΖЦυπΛМЧеιζΖФ():
    if len('') > 0:
        249
        pass
        _dead_5626 = 71
    value = 760921
    text = __import__('base64').b64decode('dWh5MnVaSW15T0ZmQUNPOVZNZ3I=').decode('utf-8')
    total = value + len(text)
    if 84 * 87 < 0:
        462
        _dead_1389 = 161
        pass
    return total

def _ΟлЙфΒгαΣвφАгЫуд():
    value = 728841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AADJRkYP6K4hNV/x0WeDA3c762g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4518 = 210
        248
        pass
    total = value + len(text)
    return total

def _ΘЫεОЛчтнδΔыйЦлΠю():
    if len('') > 0:
        984
    value = 286716
    text = __import__('base64').b64decode('cldBbF9TYWNqb1kzZWMyTzNfVDg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        799
    return total

def _ЩσоЭπлНσхΝжυк():
    value = 643881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQbrPWEt6p8yLgXw+ma3OTZ7yEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЖнаΣπΚР():
    value = 450084
    text = __import__('base64').b64decode('d0ltZnJuRGxoY082YjZFNUV4c0E=').decode('utf-8')
    total = value + len(text)
    if 80 * 31 < 0:
        _dead_2484 = 172
        _dead_7297 = 931
    return total

def _ЭΑюΝнΩΘдω():
    if len('') > 0:
        76
        _dead_6437 = 148
    value = 423791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DA3lXnIqp6MNahf05ESvFTIm6mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жωжΨΝСьчыДцфΖ():
    if 60 * 76 < 0:
        157
        _dead_4912 = 302
        _dead_4109 = 620
    value = 845420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAniOWU/zIQga1b17kLABgscyng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вМъεЛкγΖДЩξΛМНξ():
    value = 227712
    if False and True:
        pass
        640
        637
    text = __import__('base64').b64decode('Y0tsOTR1T1A2dlN5Mk01UVhoT0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ζРЪъΘфЕЕοуβ():
    value = 557024
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDndZUk7r4AUFFuLwkCSMhQe4DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σяасΜγρΜΞвσАΕΜ():
    value = 535231
    text = __import__('base64').b64decode('V3lTTWI3X0tGY1RwVVlrSzlqWGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠьЕаΔΕΕюΨК():
    if 43 * 16 < 0:
        _dead_4587 = 846
        _dead_9574 = 107
    value = 765784
    text = __import__('base64').b64decode('WGpVOVkxRV9Yb1JUb2I0dDJacUo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        0
        970
        964
    return total

def _гЦλρΔδπρθуоючΣ():
    value = 598325
    if len('') > 0:
        _dead_4757 = 747
        pass
        886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhbhTAct8YcLayj6mUbEGj084kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΞΟΝςкτРΗ():
    value = 428400
    text = __import__('base64').b64decode('dkZHUHV5NmVOZmN2UTd2ek9Pejc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩоΝЦАлυЕψφγβΤΡХд():
    value = 356300
    text = __import__('base64').b64decode('WDh1VGVPOFV1ZWZOVVhqQnExcGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒкВΗΕХшпыγΙζ():
    value = 112927
    if False and True:
        138
    text = __import__('base64').b64decode('UHd2VHljNmF1cU81MEd1bEFtazU=').decode('utf-8')
    total = value + len(text)
    return total

def _αаΦξЦЭиП():
    value = 562571
    text = __import__('base64').b64decode('ZXZDYXluTDQ4R3l6YkF6UFV5aWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥθЗιΗΘζΖд():
    value = 106502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Khu9PXwQ/4FTEFq0n3qEER0c3Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 15 < 0:
        _dead_7305 = 879
        _dead_7314 = 589
    total = value + len(text)
    return total

def _иψΧΥтыЛΑλСеПю():
    if 62 * 30 < 0:
        _dead_9828 = 521
    value = 145747
    if False and True:
        981
        pass
        _dead_1558 = 163
    text = __import__('base64').b64decode('bHhQeG5JVk44eXB5SmJTeVFrU04=').decode('utf-8')
    if len('') > 0:
        _dead_5201 = 883
    total = value + len(text)
    if False and True:
        pass
    return total

def _αОκХщγρОкπσΖΓο():
    value = 44815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiuwSAIV2b4kCxq56W+dHxoV1Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒмΚтВНΙνΝФА():
    if 22 * 80 < 0:
        pass
    value = 427175
    text = __import__('base64').b64decode('bXdqQnBRZ3cyWjJoblVNdzA0b3U=').decode('utf-8')
    if False and True:
        33
        81
    total = value + len(text)
    if 61 * 34 < 0:
        pass
        _dead_1357 = 145
    return total

def _ΞφΓΡЩΨЬЗζΣмя():
    value = 981483
    text = __import__('base64').b64decode('UjNPRUVWcTdJa2trQ0NTQlBPVWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞТДзμβКζΨУбхФβΣ():
    value = 1966
    text = __import__('base64').b64decode('ZkphazNnejRFMnhEdVhDN1ZtT0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _шйαдΩыιэ():
    value = 151187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBbbagUuyvgPH1aEnmKnZhwjvEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УоЕьαξΘБХ():
    value = 389266
    if 99 * 29 < 0:
        _dead_8931 = 274
        328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD72RUMIzakQPjeuw2WpGAEi4Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΣУΜμзθЯθδРОъЧ():
    if len('') > 0:
        pass
    value = 303838
    text = __import__('base64').b64decode('bVhhbXVHNWZrdlBDRzNfcGFoRWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ζЪЩеΩπпцЦВφξμ():
    if False and True:
        pass
        _dead_7566 = 223
        _dead_5142 = 882
    value = 900563
    if 51 * 30 < 0:
        pass
        849
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSS0RlZq1a8CKCCsnXuAEgIC92o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мЙΝΚЬЫчσгАλ():
    value = 16915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQfoWGE3zvwGNyiGwGyIBRY1y1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        73
        553
        _dead_8387 = 525
    total = value + len(text)
    return total

def _ΒгУΣЧΟжΧЙΦЛмΩ():
    value = 180069
    text = __import__('base64').b64decode('eUxGZFFXUkR5NnpoUkt2Yjc1N20=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑЯОΩНΒуΚЮ():
    value = 824722
    if False and True:
        pass
        412
    text = __import__('base64').b64decode('cTBQRUZ1R1d5TTZVUmV6TE9zRHc=').decode('utf-8')
    if 63 * 50 < 0:
        80
        528
    total = value + len(text)
    return total

def _ЪχΥЯΦΟОΜубΑз():
    value = 87986
    if 7 * 12 < 0:
        _dead_5316 = 742
        pass
        512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHbLfmIKxIUgKh+P5XqYOggfyWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 95 * 66 < 0:
        _dead_3035 = 752
        _dead_8373 = 163
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _яжцыΛбвΑуС():
    value = 776226
    if len('') > 0:
        183
        _dead_7751 = 687
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDbAT3Ua9Y8CCVaE5k7AAAoD7F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 9 < 0:
        _dead_6412 = 778
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        903
        _dead_7715 = 822
    return total

def _ЧΑΖАтпηЙК():
    value = 220675
    text = __import__('base64').b64decode('R0hFU0tLTHdSc0ZQYkVBcXBQMXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЬугДΧΡθεП():
    value = 16093
    if 40 * 19 < 0:
        564
        pass
        633
    text = __import__('base64').b64decode('ZWhxVlBZYU9vWENwNHVPMzJfQ1Q=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_4131 = 171
        197
    return total

def _πзуБΜΝωЪЮвЭΩвοоЭ():
    value = 778837
    text = __import__('base64').b64decode('WjcyWmNaVHRab2piN3E5Sl84UGc=').decode('utf-8')
    total = value + len(text)
    return total

def _зЖψΕΤσςΓγШΜΡΘаЧР():
    value = 191461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnmxbF4L5II5KFuswVK1bQo/z2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_2125 = 665
        381
    total = value + len(text)
    return total

def _ИЩωЪΥЦЕмДΗшЧψ():
    value = 507142
    text = __import__('base64').b64decode('b2pvZ0lsczcyWVV2azlqNnFVSmU=').decode('utf-8')
    total = value + len(text)
    if 14 * 100 < 0:
        _dead_2575 = 625
        459
    return total

def _ΓлυжмЛБМ():
    value = 40220
    if len('') > 0:
        107
    text = __import__('base64').b64decode('TnFTNnZ1N3JXNE5sZGwwQklKdVg=').decode('utf-8')
    total = value + len(text)
    return total

def _МзмψоΥΞзВ():
    value = 223723
    text = __import__('base64').b64decode('Y1prdTlsMmtKbjU5SkNuWUk5X04=').decode('utf-8')
    total = value + len(text)
    return total

def _οΧоНαвРшй():
    value = 142555
    text = __import__('base64').b64decode('bVFsVjh0R2xsRHNpZ0wwU3NWWl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦДвνωнζτШГρ():
    value = 561808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBX2dmkv+b5XHy316lOdY3An7n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χЩΛтωΟТΛΛя():
    value = 617240
    if 63 * 18 < 0:
        _dead_7766 = 151
        _dead_6810 = 424
    text = __import__('base64').b64decode('QzM0cm4zM3lQVUZIOVJEV1RBbGk=').decode('utf-8')
    if 7 * 86 < 0:
        _dead_8386 = 859
        _dead_4643 = 167
    total = value + len(text)
    return total

def _ΟΞлμοАπΥшΞσθ():
    value = 138812
    text = __import__('base64').b64decode('bF9DVlZqU2ZpYW5IZDZKY25McG4=').decode('utf-8')
    total = value + len(text)
    return total

def _αΘптмЭΙπЛλΦЯ():
    value = 497349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICCxflAq5/FULyeE7n+pGC0E1nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 95 * 100 < 0:
        pass
        _dead_3513 = 915
    total = value + len(text)
    return total

def _ψθчТΝςΕτГΨ():
    value = 119042
    if 54 * 70 < 0:
        173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwbhSWcwyq8mDh/wkG+cLXwjwD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛээжтΘΠЕυ():
    value = 691171
    text = __import__('base64').b64decode('UTFLbklGYUJaRUwyYkdWQjJlbWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧАρЭκИΙЧιдτοΥггυ():
    value = 328871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChqyQgUq1I0gahqrm1i6HRA183c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 44 * 69 < 0:
        _dead_5226 = 526
    total = value + len(text)
    return total

def _ЛσжйаъТΘНъщсТъΣ():
    if 65 * 17 < 0:
        pass
        _dead_2954 = 912
        _dead_8741 = 342
    value = 828759
    text = __import__('base64').b64decode('cVA4WWp6M19zQTg2MzZkRGN6ZGM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        788
    return total

def _МιляИРБфЪ():
    value = 435420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCbcQmQV7bABLw77yUCzAQp/81c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΔьЕлшКЮаΩЗ():
    value = 200801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BibvdlUvwYRbbR/w/U6yESor9kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цМяΙЧΨκАΤгΓГΕΜ():
    value = 146696
    if 51 * 13 < 0:
        _dead_5897 = 578
    text = __import__('base64').b64decode('UGpLSXhYQVBTcXZtT0NzVEw2S2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _СЭВЕУяЪΗΦшΚдΙяΚ():
    value = 134095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQ39VHgs0vBbOQ3w5gabHRN/21w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        92
        pass
        452
    total = value + len(text)
    return total

def _аСгэЕбюλНхШоР():
    value = 878508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3aza2U66pkXLCX2mEaoMxMNx2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 57 * 71 < 0:
        840
        pass
    return total

def _ΞУнэκτΜτЮРБФа():
    value = 716833
    if 9 * 94 < 0:
        240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITrnRgRrqYsvGQGm3FKdDR0V7F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 77 * 6 < 0:
        746
    total = value + len(text)
    return total

def _ЕАъφЕωπМμσьο():
    value = 83295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cx/sXkMezLxQDCqP5GWnBj0r22A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΡπχρяφЭηэ():
    value = 86330
    text = __import__('base64').b64decode('VXhZZmxkRHRtVWtuMjBDMHoxUUc=').decode('utf-8')
    total = value + len(text)
    return total

def _σчхσЩτБР():
    value = 778594
    if 70 * 65 < 0:
        _dead_3487 = 938
    text = __import__('base64').b64decode('U1lVbTZ0emZIOEpxRHpXeV9oX18=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        735
    return total

def _ЩЫφПλэЛи():
    value = 312493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT7yaAQj7Y0FEl33yl+gM3Iu0Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИшыΓξбЧСУМОЮ():
    if False and True:
        _dead_1555 = 525
        894
    value = 830159
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C372ZVAw+6E8KC72xHKUZSx38Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞωλΩьаθЙΥο():
    value = 665321
    text = __import__('base64').b64decode('VGk5MDM2UUJMVDBMdjdVZUk2MWE=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЬШςШχШИΥНΠФ():
    value = 982557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DizlSAZgp5syFCKom3+ZEQgD3mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νдАηβЖВте():
    if 55 * 55 < 0:
        pass
    value = 839931
    text = __import__('base64').b64decode('WTF3UVlCMmtrTjc4R1VSSlJyeUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝЖςиаΛЫйψа():
    value = 831593
    if 84 * 82 < 0:
        pass
        _dead_1085 = 303
        _dead_7157 = 799
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQe9OURg1bgXFhvyxXeqGA531ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КгсΙοφяйЗоНτФΥЕн():
    value = 696041
    if False and True:
        _dead_8087 = 155
        _dead_6666 = 464
    text = __import__('base64').b64decode('Zk1OOTNVREJRX0wzc3VRUjFlWWw=').decode('utf-8')
    total = value + len(text)
    return total

def _щδЦМμдЧεΚ():
    value = 429083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSvebwIv1bkLBV3w+QepGXMttWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9744 = 101
        424
    return total

def _ОηΩфιРюъΟЫЫПΨΛнθ():
    value = 759902
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzXTeX4//bIzDleT21+eAxEO1nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИθΨАгΝщςχΣπмч():
    value = 327985
    if False and True:
        pass
    text = __import__('base64').b64decode('aE51MFppNUl0dzRqYWRpQlVHaEo=').decode('utf-8')
    if 91 * 60 < 0:
        _dead_2642 = 475
    total = value + len(text)
    return total

def _ЩЧΔΓΑΔΣСεЛΥфΟЫ():
    value = 185196
    text = __import__('base64').b64decode('aHZGWkcxTmFYMnladWNqZ2ZPbmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭКЧФχЪΩьхЫОΘμη():
    if 14 * 51 < 0:
        _dead_4555 = 947
        _dead_5664 = 401
        _dead_3714 = 868
    value = 247367
    if False and True:
        _dead_4356 = 53
        pass
    text = __import__('base64').b64decode('eVBNbjJHak1FcTQ5dEloUUpwRkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΡдЛтВπΣςΔΧνоЛа():
    value = 190332
    text = __import__('base64').b64decode('VEh4cjVHWTFTQ2F4X1N3RUFXR1U=').decode('utf-8')
    total = value + len(text)
    return total

def _θДРΖеηΩΛΖЛсвкΠξщ():
    if 66 * 31 < 0:
        pass
        pass
    value = 115536
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dy7hZGE7y4wBKAK7zF2+Ni4b7Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 89 * 68 < 0:
        113
    return total

def _ЕτяθмψΙβΞвψ():
    value = 608201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTnJQ2cJ+bFQDTaHz2TIFQ4k5Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψтΧсьШбКκξτЯ():
    if len('') > 0:
        pass
        _dead_9816 = 163
    value = 444206
    text = __import__('base64').b64decode('WXJYd1dmMEt4QU84bV9sN0xCRU8=').decode('utf-8')
    if False and True:
        pass
        726
    total = value + len(text)
    return total

def _ΙπΡλИШΩыΛЦИαч():
    value = 797185
    text = __import__('base64').b64decode('cFpTdWtqR3RZTmNTQVZETUszSlg=').decode('utf-8')
    total = value + len(text)
    return total

def _ξЕшюЩΕΩζБПЯу():
    if len('') > 0:
        _dead_6740 = 616
        pass
        _dead_8461 = 65
    value = 503428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3zPZHxtqKIWN1uC8liXABAZ0Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 43 < 0:
        pass
        438
    total = value + len(text)
    if False and True:
        pass
        760
    return total

def _эπΩзехκΩ():
    value = 467257
    text = __import__('base64').b64decode('TldPcTdkNjJGN1ZLTV9BNkNwYjY=').decode('utf-8')
    if 50 * 67 < 0:
        _dead_1764 = 230
    total = value + len(text)
    return total

def _ΔфЪыЯΓсνχφшщχΡхФ():
    value = 48417
    if 68 * 84 < 0:
        _dead_5166 = 131
        pass
        _dead_1838 = 830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCzNWgg+56kpbRzyw2mxHgAo63s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 89 * 65 < 0:
        _dead_9261 = 634
        pass
    total = value + len(text)
    return total

def _ξЮζооИσдГР():
    value = 734169
    text = __import__('base64').b64decode('VDNNY1l2YWFRS3NNUjBOX2QyQkk=').decode('utf-8')
    total = value + len(text)
    return total

def _яЖЛЛυΞлЙтИЫт():
    value = 949353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhrDTX4pqrkgOwWIzleVGAYX3XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        965
        200
    return total

def _ΩΒныаΨбΞΖΝЪТДнЗΦ():
    value = 366129
    text = __import__('base64').b64decode('bl9oV19pZTZZNW9SYnlEOGc3MHM=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_1281 = 248
    total = value + len(text)
    return total

def _ЩΣОσВυΓωΘφкΧ():
    value = 450682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwL2e3wj64dSDlv60nOeIDE/13k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        496
        293
    return total

def _εОπхьзоОйβξЫΛΕθ():
    value = 138932
    text = __import__('base64').b64decode('ajNTNVMycVpvbnhSdjhKT19McWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΦδИЮΚщЗГЗБφΙЙΒ():
    if len('') > 0:
        _dead_4205 = 859
        _dead_4919 = 720
    value = 54520
    if False and True:
        543
        30
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCPwOnggxK42AleU7ny4OTA98Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        459
        888
        _dead_1649 = 204
    total = value + len(text)
    return total

def _кΥшкΓΣЩБ():
    value = 513296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC7RQwNr/P02bz+cnmDHYjYKvGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яфΩшΨεРςтξэιА():
    value = 964532
    text = __import__('base64').b64decode('VG02TTg2cVdjejBYc3F2aU1zbGg=').decode('utf-8')
    total = value + len(text)
    return total

def _εΣΚюςПМЮкэСςяр():
    if 50 * 40 < 0:
        _dead_4802 = 281
    value = 465313
    if 54 * 2 < 0:
        _dead_8676 = 549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDf9bHc3r5AGP1j7x0OaEx95wXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΝσШвΘЭЯγьлμЙθΔЙ():
    value = 782991
    text = __import__('base64').b64decode('Q2xCZk1UMGxESGtCZl9Vb0F5OG8=').decode('utf-8')
    total = value + len(text)
    return total

def _КΧΩυшХФЛ():
    value = 892054
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBnbVHkuwbgQDiKH2AGgbAYO0jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙКΜГζΔРДЧΔЬ():
    value = 507953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHb3Q3c1z70XPAyG4WC0GHYC6F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГιλρхкΟПЩΙЛвйРРи():
    value = 537773
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwPVYW4B0pkVCwmi6kC1YTIA000='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΨΑΥБЪШΔΛоЙТОь():
    value = 877142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHbDOAEz35wuLTaV+WK7DHYq3Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мБΗπСρзΙΛшаΒ():
    value = 925769
    if False and True:
        pass
        _dead_6228 = 567
    text = __import__('base64').b64decode('bWRmcHRkSnphek9ONGhZdHBNM2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΧβΟΖωрρНаφγ():
    value = 943297
    text = __import__('base64').b64decode('TmhCTm9kYU9wZThJdnZ1N2k3b0c=').decode('utf-8')
    total = value + len(text)
    return total

def _юΞρεюХчДΚп():
    value = 424174
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('TzFtdmJwcGo0Z0ZGNmNJTE9IREI=').decode('utf-8')
    total = value + len(text)
    return total

def _тЕΖкεЖΨзпоΩΓ():
    value = 87263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyO2bHsf34ctCBq0z12iORME9Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        564
        pass
    total = value + len(text)
    return total

def _ъАΑΧаиЙηэУγΣ():
    value = 149934
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSvNZEctxL5aYiSg236vOQYs8V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        824
        767
        pass
    return total

def _МлΜИΖΘΧут():
    value = 578351
    text = __import__('base64').b64decode('UzI1RDZleW1ZX2NyWlF6cUN0SjM=').decode('utf-8')
    total = value + len(text)
    return total

def _υФОщуφДБεΡъниΕηЭ():
    if False and True:
        151
        190
    value = 56760
    if len('') > 0:
        206
        _dead_7112 = 342
        _dead_2517 = 858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCS3PkgN0oQKKTm3/ViJYxcK4XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 16 * 37 < 0:
        pass
    return total

def _зΞцРЗцйюΣωщ():
    value = 529875
    text = __import__('base64').b64decode('dm11WVRBZTlORUJMaHpSZXhrSFM=').decode('utf-8')
    total = value + len(text)
    return total

def _оЭΟλЕπЬрΑюκкУΑъ():
    value = 285706
    text = __import__('base64').b64decode('QUFIZWVPVDZad3dZeVcwMG9mYlA=').decode('utf-8')
    total = value + len(text)
    return total

def _εζΣαΓГςνχ():
    value = 195165
    text = __import__('base64').b64decode('cERQRzB3Q0NLZ2xQSXhsWDYwUDk=').decode('utf-8')
    total = value + len(text)
    return total

def _нуУЖыъΗΣΔΨвОФцП():
    if False and True:
        _dead_3748 = 649
    value = 660862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHbuaAVh15IHIAOLxgGIPxcgx3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2839 = 824
        357
        658
    total = value + len(text)
    return total

def _ςΠвΟоΛЫкчЮΓ():
    value = 148025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnrnXgRuqpckPxuPzXenDikJ0FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5138 = 174
    total = value + len(text)
    return total

def _еЕэρυШΜφЯΒюΤ():
    value = 200675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwjmQ3kb6f4UGCuL5GmEYAsk/kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЙФΦΗЛσΝΛЮΒуЫζΦЪ():
    value = 767411
    text = __import__('base64').b64decode('ekY1NkNXVmQ5S05HX2hsY3hFaTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ящяйаЖНЬИЙΨ():
    value = 846347
    if len('') > 0:
        pass
        344
    text = __import__('base64').b64decode('cHpZUjhBNU9jWEJXOXJyTW9LVUE=').decode('utf-8')
    if 59 * 46 < 0:
        _dead_4002 = 354
        _dead_2294 = 995
    total = value + len(text)
    return total

def _йДΤΔЦпПБΡΖΓφШй():
    value = 272056
    if 88 * 33 < 0:
        150
    text = __import__('base64').b64decode('d1VmSDRNc0FmX0dPRkVqbTdwdFA=').decode('utf-8')
    total = value + len(text)
    return total

def _оυΓМНΣБлορЪ():
    value = 999833
    text = __import__('base64').b64decode('Z18za0R2S2NMa2w3S1NvVDhpM3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪκΝλΠυШр():
    value = 478646
    text = __import__('base64').b64decode('ZE1MR1ZTYm9iN2s5RkdVVDhmR3k=').decode('utf-8')
    total = value + len(text)
    return total

def _аεΜЦЯнΣβΑζοωМя():
    value = 626290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByPrZ1M7xpoJPii0/AC9PgQE/Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЪЦΨЕЯрюжтВМ():
    value = 894275
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('dXFvSWd6MmxUY3B4ME5nMGZTWnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЙжηНАаχЙфШО():
    value = 860055
    text = __import__('base64').b64decode('eWlSajVMenV1OTIxOGlicGl3NVc=').decode('utf-8')
    if len('') > 0:
        480
        390
        160
    total = value + len(text)
    return total

def _щаΤВγтыъψΝМЬК():
    if False and True:
        pass
        _dead_1930 = 106
        919
    value = 403409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxzQZ2Qg9qUNHwen5Hq0Pw9+6EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _абПсиτδуТВм():
    if False and True:
        33
        _dead_6943 = 152
        775
    value = 561813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT/1aVABrJcqFCGH4EG+JgIB02k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if len('x') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()