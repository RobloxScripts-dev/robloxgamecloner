#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ъΓτШЫПеь():
    value = 746735
    text = __import__('base64').b64decode('TVowd2I1MWs2ampneUU2THZfaWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ыοΓОЯкεиζВΑюу():
    value = 13936
    text = __import__('base64').b64decode('YlJQbmR4VjdQbFBVampJN2VSeFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥрΡΖγωеγ():
    value = 278536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzjXYmED2o01H1iz3n6JYBQ85kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВφЩβЗξяσΑЖηΠсЮ():
    value = 216370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IirTQn1p1aokCzWg3wWUDid5tjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6947 = 831
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        931
        pass
    return total

def _яΙИСδШΘкчλшс():
    value = 331369
    if len('') > 0:
        pass
        78
        898
    text = __import__('base64').b64decode('eHpsQVRUSjdxVk1lQWtueXQ0Rk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЬЪвυЮφνЪЗЧ():
    value = 493186
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj/PY1og3b8ZFAmu5UCBHTQs4X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΚЖъмзиЫГфρΕ():
    if False and True:
        pass
        pass
        _dead_9215 = 591
    value = 347432
    if False and True:
        _dead_4029 = 60
        _dead_3024 = 603
        _dead_8114 = 892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AD3QQXc08IcsFyC3mUOaERYF52Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 39 < 0:
        pass
        _dead_2960 = 558
    total = value + len(text)
    if False and True:
        pass
        578
        pass
    return total

def _оСйТЭΖЧζΟΛЦвΟξ():
    value = 474743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBbyfwUA/axVKTeNwmKYbCghwlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        370
    total = value + len(text)
    return total

def _ДЧъсυΤФкуβдДΟ():
    value = 588775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSj3bUBs0rE6GCC22EfEZwIs3lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        756
    return total

def _ΒЖдΧρдΙСЭσεΥНπΛ():
    value = 376903
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BB33OFULqYM5NDqI4mbFZwYgt1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8345 = 204
    total = value + len(text)
    return total

def _ΑЭРΓэщευЧтдΡ():
    value = 338023
    text = __import__('base64').b64decode('c053bnFqUjJQdXV3WFpERjV2cGo=').decode('utf-8')
    total = value + len(text)
    return total

def _πκΖιРΞΛэωεяΧΦ():
    value = 654595
    text = __import__('base64').b64decode('U0pudlBRT0wxam5JUU15TWdiN1A=').decode('utf-8')
    total = value + len(text)
    if 70 * 32 < 0:
        653
        _dead_7875 = 84
        876
    return total

def _οΡяνшΤмб():
    if False and True:
        454
        pass
        _dead_9345 = 825
    value = 226022
    text = __import__('base64').b64decode('bExXQkFXN253TVZVUXd3YUNGTEw=').decode('utf-8')
    total = value + len(text)
    return total

def _чИщρΝчЬαχЙцΧшχ():
    if 83 * 94 < 0:
        _dead_6989 = 497
        997
    value = 712065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRXsSXNu6poFNl/27Xe3bDYs1X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        538
        _dead_6954 = 732
        _dead_5074 = 185
    return total

def _δЛШγчτπΞΒ():
    value = 276326
    text = __import__('base64').b64decode('c211b0Mxa1lESDNmOWM2dXF5TVk=').decode('utf-8')
    total = value + len(text)
    return total

def _τаΜΙЪΦζр():
    value = 499931
    text = __import__('base64').b64decode('YUgySUtNSWp3Z1NFdHlkSzNRWUI=').decode('utf-8')
    if 5 * 32 < 0:
        610
    total = value + len(text)
    return total

def _ЙЗмΣφЭдΑΧФΧшΣμ():
    value = 308351
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwDlWF0R5IkWESu10li4JCoQ72U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΦЕχΒуфяю():
    if len('') > 0:
        421
        pass
    value = 224526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRfhYW4M0vg5YxaxkEybHwErtU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1024 = 88
    total = value + len(text)
    return total

def _ййиΣΧфзχσ():
    value = 918940
    text = __import__('base64').b64decode('dm02ZGs2WE44d1pBTGYyMGJuNWE=').decode('utf-8')
    total = value + len(text)
    return total

def _йкΤτокЕЖн():
    value = 882368
    text = __import__('base64').b64decode('ekN5blpWUHE1RXZiQ0w4T0kwMEw=').decode('utf-8')
    total = value + len(text)
    return total

def _МΠφιτКΘι():
    value = 628613
    text = __import__('base64').b64decode('dW55RWRXMXhsaUkxODdRcnFqZV8=').decode('utf-8')
    total = value + len(text)
    return total

def _оΟρΞδкЬΩ():
    value = 527067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH31dEEDrKxSaii37FDHIQgutlc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ймЧьзаνΩсΦМ():
    value = 139813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwHoaAIy95cZaVqZkQHCPRAp9H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9172 = 187
        pass
    total = value + len(text)
    return total

def _ΟΑщЧчΟоыψьвπΒΡψ():
    value = 968670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw3Lemg75v02L1n78UK8C3QW6kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΦβΟСΥΒΚТ():
    value = 936128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx7ySVQq54InaBuP41CmLg846m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦчкσΨУГЙΞΜεнбЧШα():
    value = 674092
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eyi0ZEYV6YpaIBaT/3rHEgE75V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яФΥαΚπωη():
    value = 510855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgjxfkMDqJIRL12VxVyHLhIl/Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЭΣαйтφΞεЙΜтςΖΩ():
    value = 391651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhvWW2QQ9PAbPC6H7FOINjw79GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 58 * 23 < 0:
        _dead_5670 = 887
        _dead_2210 = 809
    return total

def _ТΟαЕнЯъУβПгχам():
    value = 169328
    text = __import__('base64').b64decode('SjhmUDhWcEZoN09qcTVnQk9TeW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮцΠφЩπιтПξ():
    value = 720525
    if False and True:
        pass
        _dead_7829 = 196
    text = __import__('base64').b64decode('VERxMGtvNmZ1dGdSSExIc2ZKTE4=').decode('utf-8')
    total = value + len(text)
    return total

def _χζЬшвεЖвЧΝбυυΛΖΜ():
    value = 234639
    text = __import__('base64').b64decode('V2JmNDhoc2VueEF6bU5OWTZCQTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪκОσбкτтςΡй():
    value = 969409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz+yaHsa+boZCjyz217HDAQX1Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δсГθбШРГр():
    if 30 * 34 < 0:
        835
    value = 137626
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('cGk3d0Z5MVZ4SVdaUjRnc3RHMUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΖΑюΧЩуβтΙωЧпя():
    value = 178582
    text = __import__('base64').b64decode('bVByOTJyU2Y0allGbVJTRUp1WTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ФИΤЬВРωыΦλμΕγЦ():
    value = 672622
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JijiYwAN2LpUNT6I8l+9My4290k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        36
        pass
    total = value + len(text)
    return total

def _уХΧςЩΔΧеЗбαч():
    value = 574059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AC3sX39s0rEOL1+CwmWzBTUQ4kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΩПшЛвйБ():
    if len('') > 0:
        400
        838
    value = 123244
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDm9XVAvr506OyL243DGYy8OxXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЗΒΞιбуΦХлфΠ():
    value = 148863
    text = __import__('base64').b64decode('SDFqbUluM2FGOWtaajhtQmxtQmo=').decode('utf-8')
    total = value + len(text)
    return total

def _есыΠЬυγАπдВпЯ():
    value = 775269
    text = __import__('base64').b64decode('cFhkMTYySEpuMUhHbG44R1BBRHM=').decode('utf-8')
    if 6 * 56 < 0:
        856
        773
    total = value + len(text)
    return total

def _ιΝЦωЛδлαхι():
    value = 98687
    text = __import__('base64').b64decode('Z0tnZ1FzUXNua0lwNUtqUnprZDQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9662 = 738
        270
        _dead_6770 = 212
    return total

def _ьЬΩθΣΔφξθκ():
    value = 783128
    text = __import__('base64').b64decode('S2RpaXNNODRkUWpVSmhPaHd4Mlg=').decode('utf-8')
    total = value + len(text)
    return total

def _σЧΦΡПЖсюАзκ():
    value = 920545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADb9YAMO+oAVCiGL8ka0Gh8H11E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 77 * 63 < 0:
        _dead_9515 = 130
    return total

def _τНΒеТГыМδκβФΦех():
    value = 520074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lne9dwRq0osmLVq02UC8GXIF7Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШрγэΝΜкуπОΒЬЪп():
    value = 768530
    text = __import__('base64').b64decode('VWczWktPeFdjNllGa0FPZnBhbXU=').decode('utf-8')
    total = value + len(text)
    return total

def _σОцΠФшττχΠНлй():
    if len('') > 0:
        pass
        200
    value = 690197
    text = __import__('base64').b64decode('RklSTjlWaTBRdm1sc1M3Uk92ZEw=').decode('utf-8')
    total = value + len(text)
    return total

def _аТЕызδΕΣЗеΝВ():
    value = 345613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCPbW0lprPwMHD2m3wfFMHMDslc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξзоΜщφЙΛРЙБπНАΨс():
    value = 517230
    text = __import__('base64').b64decode('cG40V044cmNfdV9qcWhwTXlfU3E=').decode('utf-8')
    if len('') > 0:
        _dead_8530 = 316
        400
        407
    total = value + len(text)
    return total

def _νΜβηЬяЩАбц():
    value = 958986
    text = __import__('base64').b64decode('WDZkZFVpVE9LRmxHSVBHbVhIUDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ηдоЧВηАοХδω():
    value = 371993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lij1fGZu+YskMjaZ6XGWLjEZ9G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШныЪψΧЯЬΡΧπЦИМэ():
    value = 557679
    text = __import__('base64').b64decode('eWZETWI2R3hGcTVaZDdGNUQzbF8=').decode('utf-8')
    total = value + len(text)
    return total

def _шΚлЫυΩФνΨ():
    value = 622586
    text = __import__('base64').b64decode('V01RbmZZNEtsbl9zaW1Nbk9uNjM=').decode('utf-8')
    total = value + len(text)
    if 30 * 35 < 0:
        165
        _dead_8924 = 300
        _dead_3812 = 267
    return total

def _ЮΘЫлМктвЮччηНΡЪ():
    if False and True:
        145
        pass
    value = 119603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hwbca3U0q4knPRmKyWSfGy0O3Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘЦНжРхδνЕкЯ():
    if False and True:
        pass
    value = 968239
    text = __import__('base64').b64decode('TVJfRFlGX3Q3V1Z3cXl1UjVDb2M=').decode('utf-8')
    total = value + len(text)
    if 64 * 80 < 0:
        _dead_4950 = 383
    return total

def _ьσоЪЕЬψОПЪюы():
    value = 394947
    text = __import__('base64').b64decode('THZramtrRHhRbktRSmtIcGJlNm8=').decode('utf-8')
    total = value + len(text)
    return total

def _нЧЙТΛσмАφыεЗУΙ():
    value = 684933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mxf3YwgB04UoHD+N/FOAZzcVyDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОθжаχПХωΦЛ():
    value = 405466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDrjP3gU/fA2Hz2Eznm+BiMFtTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЗъΙΜΖΧОуΞыω():
    value = 208123
    text = __import__('base64').b64decode('T29KMlNna1M4QWEzb3lrem52RFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛτΑΟωКшсЩгТχ():
    value = 920654
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCvxWG4LzZ0PMl2smQGnZhV91GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧНμФанШхΑΞзηξ():
    if 19 * 37 < 0:
        pass
    value = 653661
    text = __import__('base64').b64decode('ZHFybzdvUTZzNVUyN05ZX01wZDQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        852
        pass
        _dead_6104 = 809
    return total

def _ЫρВсΤвчοοмБИоτ():
    value = 263036
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzrBWkNt7/8TYwKZ5nmTITYdwWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 49 * 13 < 0:
        pass
        _dead_4616 = 634
        _dead_9105 = 839
    total = value + len(text)
    return total

def _αΡоьППжψФ():
    value = 142835
    text = __import__('base64').b64decode('V1BmcE9qWDlRV3dVSm9YV3RQRkM=').decode('utf-8')
    if len('') > 0:
        847
        _dead_9486 = 747
    total = value + len(text)
    return total

def _ΛьΒΗХλΒФο():
    value = 194686
    text = __import__('base64').b64decode('ZG9PdHpOQ2FkME1KMEdUTlhFV3M=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 69 * 40 < 0:
        334
        pass
        pass
    return total

def _ъΘΣωΔХкМЩьоηα():
    value = 817624
    text = __import__('base64').b64decode('Qko5YWw5M1ZZMWhqRFh1QWIxMVI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ρΓχΧΩшШДсУω():
    value = 414002
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KS7pQXA6rbk1Lwf73lihJ3A96UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩБΘСкΡэГκЮΕК():
    value = 799996
    text = __import__('base64').b64decode('ZnhPSkMzSGVINWhqQkJnSktDV2k=').decode('utf-8')
    total = value + len(text)
    if False and True:
        278
    return total

def _вЛωлхвшΗЫц():
    value = 899795
    if 86 * 13 < 0:
        _dead_7008 = 669
        pass
    text = __import__('base64').b64decode('VXZPdGsxRm5FT2drdWJlVmx4blk=').decode('utf-8')
    if False and True:
        _dead_5203 = 68
        120
        pass
    total = value + len(text)
    return total

def _ΠщУςчσЧбΨσΜΗΩуΨь():
    if len('') > 0:
        _dead_7716 = 219
    value = 237617
    text = __import__('base64').b64decode('REJ6elRvc3drbEtJclJ2aXMwRzQ=').decode('utf-8')
    if False and True:
        580
    total = value + len(text)
    return total

def _ЯТюЩΞβЪνΕэλсΥьΚς():
    value = 844637
    if 71 * 90 < 0:
        pass
        _dead_8081 = 744
        423
    text = __import__('base64').b64decode('WmwxNzJnMnkxc1k5MHZhRHpJUWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ъΟκСЗЮаΠиΣΒФуГ():
    value = 98794
    text = __import__('base64').b64decode('RzJ3dmlZb1drTWdnTHZoQVh6OUs=').decode('utf-8')
    if len('') > 0:
        _dead_8100 = 988
        _dead_1452 = 125
        231
    total = value + len(text)
    if 60 * 61 < 0:
        pass
    return total

def _ρюλωзΛЬΘΔγхΘεИ():
    value = 590099
    text = __import__('base64').b64decode('VE5fTFJXQ1BXQVhfRTVpTVZueXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΜκτΣюъΠыΩОγьΚωд():
    value = 334969
    if len('') > 0:
        pass
        pass
        62
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex28WgQay4A0PCWhyXK2JBR8/UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΔςζПΦвΦ():
    value = 285651
    text = __import__('base64').b64decode('WTVlVlVlbVdfNE1TNTRsekdtVG8=').decode('utf-8')
    total = value + len(text)
    return total

def _яИιΨΜмлαЬθБ():
    if 72 * 13 < 0:
        917
        _dead_3696 = 726
    value = 610207
    text = __import__('base64').b64decode('Wjg2dW5COGNnN0UzS3A4bzJOS0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠШΙδΑΚПтПξЙδΦ():
    value = 210645
    text = __import__('base64').b64decode('dlVFQm40UWpWWDZlU21EZ3kyTHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝхзΒΛΘπСБαΑ():
    if False and True:
        514
        pass
        398
    value = 533475
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhzNSwEA7osJBRipxGWzGg54yDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        680
    return total

def _εΚγаΙЛмφ():
    value = 92146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHe1OVkNz7s7DjiZywGnZg8Kwng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яβоУнзεξьюйτПΩ():
    value = 375095
    text = __import__('base64').b64decode('anBaMEdTUk13dFgwaWdhTEkyYm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΘψΟλТτэВСγтщ():
    value = 709085
    text = __import__('base64').b64decode('aHRVbDl2d1ZTQzFsVk5QZzJlVUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ефγеΧяζьηΕХοюще():
    value = 895499
    text = __import__('base64').b64decode('VnFmWUJ1eUVTenpYRUR5ZEJZVTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ИσνχΜΙеЙиЯАκσЕ():
    if False and True:
        _dead_6379 = 56
        _dead_1643 = 661
    value = 135157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCPoZnI66YlaHVy7mlehHjUizHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        920
        pass
        _dead_4351 = 482
    total = value + len(text)
    return total

def _НτνеЩΡЫνгΣΤ():
    value = 329133
    text = __import__('base64').b64decode('cU1FVlNpYWpTeVc3UFBxR0J2eHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯхιВАΨΒНΠ():
    if len('') > 0:
        pass
        pass
    value = 426426
    if 88 * 76 < 0:
        pass
        122
        389
    text = __import__('base64').b64decode('T0E5M0J2RGMzNUVGaHJOOEd3c0o=').decode('utf-8')
    if 94 * 35 < 0:
        _dead_1210 = 364
    total = value + len(text)
    if 11 * 64 < 0:
        pass
        pass
        _dead_6139 = 104
    return total

def _СЧгаΦλвκΠ():
    value = 17326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQL8Y34Nz74SFzyT8kGKYSMbw0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вИНъθεΙвρХцΖΨ():
    value = 21263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRbCWEcu+pgxa16P5Ea4FTM+3T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хζфЮцΖЙΚςы():
    value = 836928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LD3ha2sc94kkPR2m3wPDOnQNsFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 78 * 56 < 0:
        796
        pass
    total = value + len(text)
    return total

def _καιВлΖЧΩкΞΜ():
    value = 723694
    text = __import__('base64').b64decode('ZmVoalRLcndhTTJKb2tzRW1ldko=').decode('utf-8')
    total = value + len(text)
    if 46 * 93 < 0:
        _dead_5504 = 974
    return total

def _оπИЪюЭофтО():
    value = 271583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTXvOgA7+PEsPFiUmFO1JyZ6ykA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЬφмШΟλКα():
    value = 901978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBmzOH8K86YbE1aRznueEil93UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыМяΜςдвΡΘ():
    value = 187299
    text = __import__('base64').b64decode('bWxac0RlUVJXVElQNzlPbTliWW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΠъνφРΞлЫνхΦЭ():
    value = 847231
    if 1 * 17 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAzTRWFq84QLaCP3nEKcYgka8kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЛБΒΓΘРγΚ():
    value = 974998
    text = __import__('base64').b64decode('d1JwS1FWZE1RaVNLN0w2SUxSVDU=').decode('utf-8')
    total = value + len(text)
    return total

def _πДВξдиНΥбΦр():
    if len('') > 0:
        _dead_6618 = 347
    value = 947888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCbuOXwY9P8UIAmA/3CzOhEqwEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РйζнНЭНΒσЛпвве():
    value = 806448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FA79Y2c126IWMzya7GSbIA8511c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡЖщПЖвςЫэЙσο():
    value = 949760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQqyN18/5JsHKx2b3lqXBSM8vXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚэΕΧΥςσςπγΙ():
    value = 52910
    if 10 * 64 < 0:
        600
        429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQjsegcg6oEbPCy5wnG3FRotzGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _гΘΣιНωΤЩζπυΦχΜΣ():
    value = 114410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXjIbXpp3a8xGACbnl28Jjd+t0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вθΖЭПΒоω():
    value = 575753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fwv3a3Mwrf8KDwSS3FGXLRI412U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗеχжΔΑβвпвД():
    value = 537102
    if False and True:
        729
        339
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXnjYn5q7bglMSm1y36WGnQC9j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чпяЩпφбМцАРц():
    value = 649096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETi3awYa8pwIaRqy8lSgFnUJ6Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩКпбΙΩЗс():
    if 66 * 39 < 0:
        pass
        _dead_2047 = 18
        358
    value = 440404
    if 92 * 34 < 0:
        pass
        664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjXNY3ohzoQNCSOS4EzHIhQt7Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΤпΦмФΞб():
    if len('') > 0:
        _dead_6838 = 624
        954
    value = 672190
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwHBPXUz+aEQKCX6+ES6NgAI/jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПОμцδУαГωцЙΓΥж():
    if False and True:
        pass
        _dead_4930 = 852
    value = 683946
    if len('') > 0:
        _dead_5634 = 834
        pass
    text = __import__('base64').b64decode('a3RLb0JOYVYyQ0xmb0pzYTRHRzc=').decode('utf-8')
    if 67 * 20 < 0:
        356
        pass
        pass
    total = value + len(text)
    return total

def _ЭФνЗоΤθΛэ():
    value = 443436
    if len('') > 0:
        996
        _dead_6217 = 566
        679
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxXWWgA0qv0abyz6nUbCGHEesj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΓоδεУΩЧΟскИб():
    if len('') > 0:
        129
        pass
        _dead_7098 = 76
    value = 939749
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHfGYFxv27oPHF7x4XzJC3R302M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΚωШижδΧэ():
    value = 184096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwvXZVw7+7w7PQeXwgaKBi8X6U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΦЪΩнΚθΧЭНΝ():
    if len('') > 0:
        _dead_1294 = 50
        pass
        888
    value = 937731
    if len('') > 0:
        _dead_7070 = 679
        pass
        _dead_8995 = 683
    text = __import__('base64').b64decode('bmc1SElGMVhlUVA0b01WQnJOTzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΖТОТΜУЫзοИγ():
    value = 794305
    text = __import__('base64').b64decode('TmtNZlhJRlJFTktSX2d2eUMybmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΝУδΙнΔωйγ():
    value = 523224
    text = __import__('base64').b64decode('VG1pZDQwUEVCZ0I2aklQNWVWcGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜНΧюЦпΤΕа():
    value = 535817
    text = __import__('base64').b64decode('T2ZnNEd6NmVXZzk4cjdGSnpIZ2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЪжΨВΓΓρκ():
    if len('') > 0:
        pass
        pass
        pass
    value = 335121
    if len('') > 0:
        _dead_7489 = 415
        pass
    text = __import__('base64').b64decode('SnZuendITDR4OHo4U3U4TzNtakY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЯЗЙΤТДΘЯРЮзЦΙОΛ():
    value = 15187
    text = __import__('base64').b64decode('ZVhqQktzZlhKYzhXUEVrT2szb2o=').decode('utf-8')
    total = value + len(text)
    return total

def _βЭΔЩκεхΝЙΥйΜΖПΦ():
    if len('') > 0:
        463
    value = 860932
    if False and True:
        pass
    text = __import__('base64').b64decode('T05XS3MzR0NFOTJfMkVpNExQTUs=').decode('utf-8')
    if len('') > 0:
        731
        106
        pass
    total = value + len(text)
    return total

def _ЗЮщτгοррΧΦψо():
    if 25 * 86 < 0:
        404
        pass
        791
    value = 162751
    if 83 * 22 < 0:
        568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXbSdlUjxpgaFiKX3QShOSwn8Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3520 = 60
    return total

def _ЪЮηΤХдсуΒЖх():
    value = 355719
    if False and True:
        _dead_6371 = 456
        _dead_8883 = 271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBm0ZVwvrvpVLym20kC4Pw4Xz1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _цχжЕвΟΑκΕжО():
    if len('') > 0:
        _dead_1186 = 228
    value = 777292
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3nndAApz7oWbhqOnH+1OjZ200A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιΧбиШЗШοστΗνвΒΑ():
    if 39 * 18 < 0:
        132
        pass
        pass
    value = 900501
    if False and True:
        661
        585
        pass
    text = __import__('base64').b64decode('ejFYRjZ4YTFmeUNBcENUaEhRU3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ТТΜΟцЦвосшА():
    value = 28583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRXTfUNs9JkmECiPmUepExE/0kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΙфДяΣгпΖΕτφшχ():
    value = 706019
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSG9e0sq8ac6PTCVxmGXDCIC6jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 77 * 93 < 0:
        pass
        pass
        766
    total = value + len(text)
    return total

def _κΒФУπψМоВΣь():
    value = 747343
    if len('') > 0:
        _dead_5082 = 176
        457
    text = __import__('base64').b64decode('em1xVTFDU1IwcFk3a3ljSThjQ00=').decode('utf-8')
    total = value + len(text)
    return total

def _аГГΓЬωРпУωгЬБγ():
    value = 296272
    text = __import__('base64').b64decode('WjFXalBGZzlQSVR1RmR1eWxtWWY=').decode('utf-8')
    total = value + len(text)
    return total

def _дЙξЛΥΘЫΒмΦУΜλЩЧЦ():
    value = 236762
    text = __import__('base64').b64decode('QkFlUTl6VmVIYlZUbjBzdUN5R0I=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        761
        340
    return total

def _ΨмχοючуΓЯΨЮФР():
    value = 997453
    if False and True:
        945
    text = __import__('base64').b64decode('Q0ZjVXNxVjFGXzdzYzdaY3J5bFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦсβФΕβφξН():
    value = 70984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESixT2gA1b8CMwWS5EzHYnICs3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        10
        _dead_4533 = 213
        pass
    total = value + len(text)
    return total

def _ΤяΞБЭДΑыνгζлНч():
    if False and True:
        _dead_1412 = 454
        pass
        _dead_6903 = 455
    value = 171519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CD2wf0I3+783DyH333ySHR8E71w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κжзлобхНеУУиЧΤΕ():
    value = 742011
    if 57 * 79 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjfWXXUX3KtTDiKsnAORHQx81Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υШБЪΚΗεАРюИςγ():
    if len('') > 0:
        _dead_2674 = 437
        pass
        733
    value = 204540
    text = __import__('base64').b64decode('VTBVUGgzUUhOMEhPVUdYalFnMlY=').decode('utf-8')
    if False and True:
        945
        _dead_6105 = 35
        _dead_7045 = 347
    total = value + len(text)
    if 87 * 82 < 0:
        530
        pass
    return total

def _фмИΟЕΟΓЮΕВхΤωςБ():
    value = 899004
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az7XSwU08IMkFQWr2QfBGDZ29Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЭзФГθкЙЖγΧг():
    value = 376798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgvvWkgJ3bgKPiio0m+WNjwo1Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗφТμΥаθβрЖу():
    value = 572851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CivgTGgb7b0qMyey8HOUIQYa0WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πйΨтΥРΟккб():
    value = 461170
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bi69OX883LkCahqo6UelZwwk6Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςзЩйυкпЩзФφγΚюг():
    value = 684182
    text = __import__('base64').b64decode('SXpfeHg1V3FGbzhpSXhJZGtfUGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦфοψΨдуХыО():
    value = 38494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXmwdkMj274uNDycxXSvLBIMxnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΩЛσωιιβηУесСπ():
    value = 864421
    if len('') > 0:
        563
        pass
    text = __import__('base64').b64decode('UmJBQ2pYbEJqVkptaElXaDRsQ2s=').decode('utf-8')
    if 77 * 1 < 0:
        _dead_9316 = 773
        pass
        471
    total = value + len(text)
    return total

def _уλφΑеПНδψЖЖεлΒ():
    value = 264088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBa9RnI7rKpWLCvz31ubAil273s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 1 * 72 < 0:
        _dead_9784 = 882
        _dead_4083 = 174
    return total

def _НГвγБйνоωπθΩЛ():
    value = 697520
    text = __import__('base64').b64decode('YldnSlFxc2R5czhuRmdpTktaWHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΝББσНЖыΩЛδтγ():
    value = 957170
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC68YngO7JEOLSzx0nzIGR966lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        538
        _dead_4518 = 870
    total = value + len(text)
    return total

def _δщСбНЪмολΩЕЮТ():
    value = 695599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAnAYVQQ044tKCCazFebDTI670Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τфЭЛНЪЖьμЖΑ():
    value = 106630
    text = __import__('base64').b64decode('dVdNMTl0aDExSmdxcHc2b29vSlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ηгЧкШЛУюП():
    value = 19834
    text = __import__('base64').b64decode('eDNVY0RLbGVjQlJ4dmplM1NMdHY=').decode('utf-8')
    if False and True:
        478
    total = value + len(text)
    return total

def _ΤζδππНстг():
    value = 588724
    if len('') > 0:
        660
        _dead_3215 = 515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxvqQHcY6LI3Hzmt+HOFEBIj8zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РюτкΟΥδΟус():
    if 89 * 3 < 0:
        859
        _dead_3357 = 547
        pass
    value = 50073
    text = __import__('base64').b64decode('SjFidDRabk1ZRlNzaVNFR1UwWW0=').decode('utf-8')
    total = value + len(text)
    return total

def _сдΠπйςΖγΗуσГ():
    if 98 * 33 < 0:
        pass
    value = 668837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiCxeQYg+ZgWahX3zUC1Nwkg8lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        197
        47
    total = value + len(text)
    return total

def _оШозхςПБЮЧροФμ():
    value = 307268
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBv8ZXoe+oQEIAClmV67ZzE68ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        507
    return total

def _иΥЩπиπξАж():
    value = 840574
    text = __import__('base64').b64decode('b3JQMzJSUUE5Y0h6M3hNRVVGSWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓэΝΩνθΒγжΒь():
    value = 948242
    if len('') > 0:
        pass
        _dead_8393 = 796
        _dead_8557 = 272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgLjN1kb2LxQAiX3xgPIOzcXwH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2398 = 578
        _dead_6536 = 866
    total = value + len(text)
    if len('') > 0:
        743
    return total

def _υЭжпяΜПγяР():
    value = 973200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3vNWGc0+acxKTei/Fe6HRY80l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΞМЙΙЬΣΠτЕЗΨЦЕ():
    value = 419946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyS2eHkXy4kKKx+2wUekJiACtGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 53 * 85 < 0:
        470
    total = value + len(text)
    if len('') > 0:
        _dead_3526 = 298
        pass
        pass
    return total

def _ΞЖХыюАΧωξъ():
    if 23 * 47 < 0:
        636
        _dead_3892 = 21
    value = 858928
    if False and True:
        _dead_1309 = 128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxjnXwIxyp1XKwKBmA6BDAoQ6j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8074 = 177
        _dead_4624 = 220
        334
    return total

def _юГзγшКσιб():
    if len('') > 0:
        pass
        pass
    value = 992939
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESvWQARt0Ko5bwaPwXiaORwlt3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        976
    return total

def _бчδЖФνЬΕФшΖ():
    value = 486629
    text = __import__('base64').b64decode('UmhydTJHcVVxZ202eXRPazVjSjk=').decode('utf-8')
    total = value + len(text)
    return total

def _юωпζδМФК():
    if 6 * 91 < 0:
        pass
        _dead_6286 = 540
    value = 235102
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwHNZnUS6J0VCx21wgG4BAkY1zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        319
        410
        _dead_2252 = 442
    total = value + len(text)
    return total

def _αΨбνпμоИн():
    if False and True:
        pass
        827
        pass
    value = 468612
    text = __import__('base64').b64decode('am43STN5ZHpuZzNXYURuWThBYVU=').decode('utf-8')
    total = value + len(text)
    return total

def _иΤнОΓζΓζГкаю():
    value = 961620
    text = __import__('base64').b64decode('TlkxcHdVR0RMYTFRYlFIUG8zRjY=').decode('utf-8')
    if False and True:
        176
    total = value + len(text)
    return total

def _ςΨцПинуπδηξаβΚо():
    value = 125514
    text = __import__('base64').b64decode('Qmlialdwck9hTDd2bzA0MUhQdl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΦΧАЙйгРЮАΛ():
    value = 781653
    text = __import__('base64').b64decode('S29pR2doajYxX0NWWnNVV3lVaHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ябмзΠδЩЗΖЫяиτθжЛ():
    value = 308180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhz0ZVsxpp8CKgy3z2aUDQQlvEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σЯΧгСχНЦюдτΡ():
    value = 305860
    text = __import__('base64').b64decode('Uk9zeGNtdUEyXzN2VHdXX2dYY1g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3795 = 123
    return total

def _ΡжωКΖлоΘдмХНтЗ():
    value = 63829
    if len('') > 0:
        43
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBbdTV0Lqa4lNS6swkGobTUrtFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        822
    total = value + len(text)
    return total

def _ΜтЖΧхфοιш():
    value = 642944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCbra3Mx7phXKQyP8VOmDAgn5lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΠЛйЪЕψΞзБлξβ():
    value = 66246
    text = __import__('base64').b64decode('b3AxSXhEVUQxQXZsRjVEdm11NUo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _щэБΦΥпрПйчα():
    value = 80949
    if 39 * 29 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwPlTwIR65oTFyKn6w/IAQQq8GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΑжЩδφЧπЗР():
    value = 135600
    if 10 * 69 < 0:
        pass
        900
        _dead_4658 = 7
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXbrWnUo/40rPV6G2m6TYH16wn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 69 * 53 < 0:
        _dead_4560 = 862
    total = value + len(text)
    return total

def _ЛΟΜсыСΚдΑζιвжΣΘК():
    value = 250503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESDjaAAh+4s5GCaH40LJAT8u7jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬοнΝюДΧЖЩΔςйωΒ():
    if len('') > 0:
        711
    value = 406903
    text = __import__('base64').b64decode('bGwzeWo5d3pkbE0zbGpJcGFabTA=').decode('utf-8')
    if len('') > 0:
        pass
        433
    total = value + len(text)
    if False and True:
        pass
        _dead_9898 = 547
        _dead_4604 = 706
    return total

def _οщкζШЮΗБуОΤЧЭ():
    value = 266030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3fLZ3M+p7sWNCeWzAXFIjci42E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧьрэδхЭУЭπуа():
    value = 268094
    if 21 * 15 < 0:
        _dead_9667 = 174
        pass
        _dead_8578 = 553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESrJQH4B7YkVaR2gzQWYPyEpwjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПЬЮДЛλрΒУσ():
    value = 399292
    text = __import__('base64').b64decode('eGQ0Z2ExREdXSzNhU2hSZnlic1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΕКдТБφъЙшΔΨГИН():
    value = 497618
    text = __import__('base64').b64decode('ZkhXSmVFQzVEajJuQnpoSFNTdjg=').decode('utf-8')
    total = value + len(text)
    if 12 * 82 < 0:
        384
    return total

def _ρДэΕПГξΨШπ():
    value = 597535
    text = __import__('base64').b64decode('Z3VlRmdTODV4X095ckFzSTJlT0g=').decode('utf-8')
    if False and True:
        pass
        962
        _dead_6877 = 546
    total = value + len(text)
    if False and True:
        107
    return total

def _ΟΠПσЛσжШασΒΗсм():
    value = 78165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD/tW2Qq0aoHCweqzQSRZB0W5n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_7020 = 587
    return total

def _шчΤοИτΨыιТΡПζΜа():
    if False and True:
        797
        pass
        _dead_9980 = 597
    value = 65545
    text = __import__('base64').b64decode('WXVxRTZhMzM2cFJIRFNuaWFweUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _цДялφΒаρ():
    if 53 * 69 < 0:
        _dead_4153 = 367
    value = 647650
    if 26 * 71 < 0:
        922
        pass
        pass
    text = __import__('base64').b64decode('RFc3RmlZY2ZqbE9DQTd0WEhCSl8=').decode('utf-8')
    total = value + len(text)
    return total

def _АюштιАпΨЫψτЯРхΣ():
    value = 556313
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jjb3RHAj+/pSGQKT31S7OBEhtFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μυошοДρдθгЫΔыΟРφ():
    value = 855070
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARjjfn4y0adbYy23nme8PgYr0Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФλχλυИΒκЧЧТСχь():
    value = 402644
    if 88 * 46 < 0:
        536
        pass
        _dead_7206 = 0
    text = __import__('base64').b64decode('RTJiaFdVM0N4SGFKOGhCekw3X2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨГγЬЫΞиτХЖδР():
    value = 125627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERbmZkkRy6sTbRyq2mTBBS8azGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πВЭΞπξΚΣΝ():
    value = 158266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDrvfgAAyp8ZMzy1nFiqMHcC0EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 57 < 0:
        351
    total = value + len(text)
    return total

def _ФСМΙоШАΟπι():
    value = 512481
    text = __import__('base64').b64decode('WVc3eWRZYjZhWE9GeEQ5OW42ak4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗфьщДΓβХыΟ():
    value = 198468
    text = __import__('base64').b64decode('aXZoM0tHdUhhdmxDa1NMZVp1Q0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ηаУДФΦФΓπΦ():
    if 38 * 46 < 0:
        255
        pass
    value = 376969
    if len('') > 0:
        pass
        327
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz+0ZXIY0vo1LyuUmn25Iz8ux1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 79 * 24 < 0:
        pass
    return total

def _гГΤЯэςХчЫННлйШ():
    value = 299356
    text = __import__('base64').b64decode('eUtHNlBqb2lnWGZMV1RQOVFKbzE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        490
    return total

def _йРшъчΖΦφΦЮОΔΔГ():
    value = 15146
    if len('') > 0:
        pass
        173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXr1N3Qf8pwvYjql6l++Oywf20c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        827
    return total

def _μΨХСηпТκрСΣΞΠУЧΗ():
    value = 395109
    text = __import__('base64').b64decode('bDlCYTZ1MTNTMXlXdVBhUmV6Y2E=').decode('utf-8')
    total = value + len(text)
    return total

def _шлпцхΨБДΣЯЬзиЗαΗ():
    value = 391592
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Enb1fHou+49baTiTyl6cHCIts14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЯαщΣрΜцХΤζджο():
    value = 905614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCG8XVcp65IxLDqPnlqqNQwc6GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 57 * 1 < 0:
        309
        _dead_2367 = 990
        792
    return total

def _νСсΚλζУИИττχоъг():
    value = 679407
    text = __import__('base64').b64decode('bENkdEtLZjBra0d6eVpWakNmcUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙβΡоυлВЖЬъ():
    value = 954027
    text = __import__('base64').b64decode('Z3VBWEVSMFdfUkZieFhOUFprNXM=').decode('utf-8')
    total = value + len(text)
    return total

def _лβνИЙЗΗΜзЙφъΦν():
    if len('') > 0:
        pass
        939
        141
    value = 978736
    text = __import__('base64').b64decode('SmV2ek5YWE80NmFZRHR3eUtKR24=').decode('utf-8')
    if len('') > 0:
        _dead_1708 = 726
    total = value + len(text)
    return total

def _ИГЯωчυчХППσЦРзΖ():
    value = 681989
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NX7If142qZIuPz/1/w+JLg0LwFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        856
        pass
    total = value + len(text)
    return total

def _υΨςъРХθβ():
    value = 896558
    text = __import__('base64').b64decode('RlF2SVB0ZU1KelJwbFZaVXZSOHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ВФкшзЖНЮпΠКьярσ():
    value = 789742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHrXVnUWzf4MIyy55nKaPQAI23w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХЮПΒЗκВВбΣВь():
    value = 565249
    text = __import__('base64').b64decode('ZG5Nb0hUWjBKZUpRdHRBSmpZZFc=').decode('utf-8')
    if 98 * 50 < 0:
        _dead_9053 = 710
    total = value + len(text)
    return total

def _иЬΝΣΗΒЭмв():
    value = 48698
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnnPO18f94MlIx+znEfJPBIW22Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иоХμьОэеΥвЯΑН():
    if 67 * 56 < 0:
        105
        _dead_5112 = 808
        _dead_8392 = 54
    value = 63746
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NATCP10Brq1WNie0+2eRDi4t9XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧαВОФЯСьэμкΘСωЫс():
    if 34 * 77 < 0:
        _dead_2471 = 725
        _dead_1465 = 831
        _dead_8885 = 606
    value = 378048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAncWWUPrbARPxy5kVOnZBcgyX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΦοωδЛаα():
    value = 215794
    text = __import__('base64').b64decode('cmNnYXRzS1JiTjRHTjNaZ2w2TVc=').decode('utf-8')
    total = value + len(text)
    if 25 * 23 < 0:
        pass
        pass
    return total

def _χΤДκΣρГЛΑΣ():
    value = 370279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn71PVcK869UMTyy2WCDFzcI/m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΩКδЧΚεΝнθЖΙ():
    value = 613071
    text = __import__('base64').b64decode('Y01lVV84SXNHRnlZVDloaXdnVkI=').decode('utf-8')
    total = value + len(text)
    return total

def _АчНΦпΦтνχτ():
    value = 613553
    text = __import__('base64').b64decode('cExIcU1lQW9MM1hVcXVQNG5RZEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ξяэΦγΣкоц():
    if False and True:
        _dead_5435 = 851
    value = 171782
    if False and True:
        _dead_8966 = 490
        559
    text = __import__('base64').b64decode('QksycVU3Skl0ZFNLQzhmWTMwd3E=').decode('utf-8')
    total = value + len(text)
    return total

def _λψιΓιрΟДξОхΛ():
    value = 939640
    text = __import__('base64').b64decode('WmFQejZOZ2UwYnFoa1lKWjZ5ekM=').decode('utf-8')
    total = value + len(text)
    return total

def _δГЦСλоУεП():
    value = 813596
    if 62 * 11 < 0:
        _dead_6948 = 513
        568
        679
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQbCeUQYwfhXIla5y1m3Lgcmzno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒйиΗЮвμаΚΒаΡСЦУР():
    value = 578819
    text = __import__('base64').b64decode('RzJ1eDZ6XzhHS0N0d1VsZkF5OG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЖулйηчюТΜφУшΣ():
    value = 318982
    if 89 * 68 < 0:
        982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DynvbXkWqZ8BLwyp8k69LgZ+1Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪγΙΧШΠЯъяТЖΣυЬΤ():
    value = 785257
    text = __import__('base64').b64decode('T2RjQ1EyWTBEbERFd1ExTmYyMmc=').decode('utf-8')
    total = value + len(text)
    return total

def _РΝΣΧФлΣы():
    value = 288951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHrXenAv0JckC1qn8EOpN3AM/Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γτρБΑΔςιтκΦЮЭ():
    value = 639948
    text = __import__('base64').b64decode('d3hOdF92RlFEZjY2dU1YUXNjVUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛьМСΝκГн():
    value = 97275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzfISFsS5LAoDA6QnHO0MAMD9k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZA==').decode('utf-8'))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()