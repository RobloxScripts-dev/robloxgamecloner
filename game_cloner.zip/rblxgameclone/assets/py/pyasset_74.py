#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ιвОшΜпΗйВΕ():
    value = 691161
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAXSZ0sj8ZwMPF3322m3HHwd5nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 43 * 71 < 0:
        _dead_9200 = 620
        137
        _dead_9265 = 991
    total = value + len(text)
    return total

def _ΚφΚюЮжθнДшжЗψъΖЦ():
    if False and True:
        563
    value = 987839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXrUT1Ip24EwLQKh4GKpDBIJ5no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _зйкыйеЦδ():
    value = 862315
    text = __import__('base64').b64decode('STI5d2g4bWRsZ3VlNWV1MEcwRHY=').decode('utf-8')
    total = value + len(text)
    return total

def _мλΝΧЧшικΝЪπо():
    value = 983750
    text = __import__('base64').b64decode('TlZGNU9yMFJ0SnoxNlNwb3NqVUw=').decode('utf-8')
    total = value + len(text)
    if 97 * 60 < 0:
        pass
        531
        pass
    return total

def _ΣЫъЙъаЮвЖΙαΛ():
    value = 161714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXfdRAkG8aIxHCap3AO9MiMf93o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 63 < 0:
        _dead_8303 = 917
        pass
    total = value + len(text)
    if False and True:
        _dead_2182 = 816
    return total

def _εюЛδЕΤυхδωδУьΞΤΧ():
    value = 333845
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3bDfnJh85gCKAic21CHLAAk/kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЧхβъПэνкжΥЬХφп():
    value = 787178
    text = __import__('base64').b64decode('cDB0VGtVM3dUWWJSN01JUWNSbUI=').decode('utf-8')
    total = value + len(text)
    return total

def _жыхцιиСгЭМ():
    value = 719286
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSrQZ24KrfgAGwHy7mCvLBUas2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НγкыΒΒЮΖΠγжКНЯ():
    value = 973855
    text = __import__('base64').b64decode('c0ZiZXVEdFczVTZyRmlvRzlYdkM=').decode('utf-8')
    total = value + len(text)
    if 58 * 64 < 0:
        _dead_2726 = 759
        75
    return total

def _ЖнΔХΩсЕц():
    value = 16433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRD8ZXU13fo1DDiFz2PFO3UI6X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔнцυиΑЛчπΩΗОыΠαΔ():
    value = 419685
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KS7dT0g17JwqNzypmHifMwl/6WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωГжБфьтςψθγмΑс():
    value = 89974
    if len('') > 0:
        502
        pass
        pass
    text = __import__('base64').b64decode('bDJjTkNVbFVTclNKVFJ2UzdBWVk=').decode('utf-8')
    if len('') > 0:
        _dead_7592 = 690
        pass
        _dead_2305 = 117
    total = value + len(text)
    return total

def _цβгΣбРωР():
    value = 869418
    text = __import__('base64').b64decode('YlRNZVR4MXNadnlCdGRyazBBalY=').decode('utf-8')
    total = value + len(text)
    return total

def _РπВоччнъΠ():
    value = 21024
    text = __import__('base64').b64decode('VHZlZHlEd2ExVWxCRVlwVUl4dks=').decode('utf-8')
    total = value + len(text)
    return total

def _ИНΕОВТйЮδШσΕΡΚ():
    value = 851590
    if False and True:
        _dead_1121 = 887
        841
        _dead_8876 = 418
    text = __import__('base64').b64decode('TG5lMjBFcmJnRzdjYmZDbnJNN2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _СΕΜДτСΧЦДСцΠΔА():
    if len('') > 0:
        pass
    value = 369604
    text = __import__('base64').b64decode('TFYxdEI3WnZYVll4MU92VW4xM3U=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3016 = 197
        115
        pass
    return total

def _ΔΔυΥφЧΟρЗИш():
    value = 698201
    if 47 * 44 < 0:
        816
        _dead_8674 = 648
        _dead_6370 = 859
    text = __import__('base64').b64decode('bmxZdnJweVk3ZVpDd0tROGpjZ18=').decode('utf-8')
    if False and True:
        _dead_5427 = 690
        660
        pass
    total = value + len(text)
    return total

def _ΗΤΕСяЗЗСΖΥ():
    value = 119608
    if len('') > 0:
        _dead_6528 = 952
        851
    text = __import__('base64').b64decode('TDdFWWJMdlNlc19LQngxcjlVNzY=').decode('utf-8')
    total = value + len(text)
    return total

def _РΝжыУюΑΣжЪиЬнυψр():
    value = 946173
    if len('') > 0:
        _dead_2941 = 128
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQjJN2Vu9JckFwS1+kCbEyJ+/Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΘЙьπЬΦЕРгГХЭΚςАΞ():
    value = 168768
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICa0WEUx75IELDiQ3Xu9IB0i7Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΖчлπНцъЬξцμу():
    value = 38225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgHcXXAK2YErb1r1wH2gEBoV72A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьφцωτΗλФΗ():
    value = 936658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lnq2WgY6z/sQbhbw+lvBHiN760U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΘЭΔΥйжцΒзВЫя():
    value = 894265
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQfbOglswf5VEgeh/HqRNjZ88Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮВΔГУΠΨЫΗωπΓжЭфе():
    value = 815888
    if 24 * 20 < 0:
        _dead_7621 = 746
    text = __import__('base64').b64decode('Y0FUWGVPc0Q5MU9pWVVYZkk2Skc=').decode('utf-8')
    if 97 * 18 < 0:
        133
        699
    total = value + len(text)
    if len('') > 0:
        976
        pass
    return total

def _νρпΣчлуρ():
    value = 587250
    if 91 * 19 < 0:
        495
    text = __import__('base64').b64decode('aVBDaF85bGFnb19FQlZ6YV9NRVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _сΔГИфИΖΓ():
    value = 176884
    text = __import__('base64').b64decode('RFpWNkRkRFk5SEZPbFdmUWZFWjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ПДПацКЦяΧцта():
    value = 44683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCHWflkT1fgSaTXz/X+pAicFvWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дхδщΩζΝПЮξя():
    value = 267006
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBywXn4hr4IHLw77wnu4FgEas1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΞκςΚДТсιδΥΦПΗ():
    value = 47800
    text = __import__('base64').b64decode('Sk9aUVdRSnoza0J4eUpWeklHdU8=').decode('utf-8')
    total = value + len(text)
    return total

def _юΘзΜνзνεςАЬσЯчΓ():
    value = 400275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwnOQXVr5IA1FQyszETCEgoGsT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        425
        _dead_4575 = 455
    total = value + len(text)
    return total

def _эΤπвΞλчоΚ():
    if 71 * 72 < 0:
        523
    value = 219557
    text = __import__('base64').b64decode('eWNpX2RnSlIwaW96TmdDZU90Vm0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        487
    return total

def _цКδлΩψκηБфдΒΖнс():
    value = 433473
    text = __import__('base64').b64decode('Z2VqNkpIdXR5XzRjSGpyVHlqUmc=').decode('utf-8')
    total = value + len(text)
    return total

def _рЦбΘБΣЩΣДвуΙ():
    value = 304529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiP1TAg2yZwEABiX8lKyOCEayWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_3871 = 687
    return total

def _λпζΔВьΕΚГ():
    value = 217812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyL3Yndopp4tFgmT5E6ZZTwstHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФемθЦмЩΣбτЗЩλ():
    if 27 * 26 < 0:
        979
        810
        870
    value = 834330
    if 18 * 97 < 0:
        pass
        _dead_4483 = 574
    text = __import__('base64').b64decode('SExJdmhzakNDM2Nxd3Y5d3lNZnE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7135 = 324
    return total

def _ВЬРτЯΡЪонΩЛиΟЮЩω():
    value = 708718
    text = __import__('base64').b64decode('Rjh1YzZnZDJjbGZmZlgyckppYjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩлγΘбКιсЯЙЩбцЯы():
    value = 257144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyXUeXoJ6pJXHQ2W60DABjY2/l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_2041 = 681
    total = value + len(text)
    if False and True:
        _dead_5803 = 217
        955
    return total

def _ФЬΤΘΑςυФХςътΖπΓВ():
    value = 991417
    text = __import__('base64').b64decode('T2wxMGpaMzdFdXpXb3lrS1NRWkM=').decode('utf-8')
    total = value + len(text)
    return total

def _мбГъыπεΡΧγ():
    value = 897018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAnMTGYr8KIHYwCnkVqEDTA17Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬμнЙΘЛΙμРЦТΞτИη():
    value = 414271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECvzf10g6oIMND277m6APzYE6Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цнпСсξΞΡЖ():
    value = 504283
    if len('') > 0:
        809
        _dead_2179 = 415
    text = __import__('base64').b64decode('aFZPY1BpemU1N19wZkgyWjNqVWY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6751 = 466
        893
        806
    return total

def _ПΙοшГБЭγκвъΦ():
    value = 205747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj+yb1IT07xbChmE92K7MjMqtGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣαЦагΡΧβΛЧЬ():
    value = 467261
    text = __import__('base64').b64decode('cllzZHhjanRibkRLX2RxZjZJWmY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        334
        pass
    return total

def _СПъΑχωсь():
    value = 601470
    text = __import__('base64').b64decode('dEhNODh2YjQwVWQ5cmdBZ3FjOFg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        298
    return total

def _гЪЭйκеφбЙн():
    value = 934944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz3dRQAXq4cAEFnx92a7NjQGvWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔγЬЙΣυβφΧΠβΨжймψ():
    value = 613584
    text = __import__('base64').b64decode('VHZyUTlMZVRnTnh3Ykp3QzdXakc=').decode('utf-8')
    total = value + len(text)
    return total

def _нκΖИжωωнΞΟрΑЪсЬ():
    value = 861791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH7vS1Awyb00G12X60yxZQok8F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        650
        _dead_2262 = 114
        735
    total = value + len(text)
    return total

def _НςтδыΙΣКЖ():
    value = 694916
    text = __import__('base64').b64decode('VHo0V0hUUHhNZTV3RUtYb3dsbDg=').decode('utf-8')
    total = value + len(text)
    return total

def _γΛТЕлФЦΦ():
    value = 174332
    text = __import__('base64').b64decode('Q3BYaVh2NldRR29zcFI0amlMUEw=').decode('utf-8')
    if 7 * 39 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΨыΨЭаαлς():
    value = 760214
    text = __import__('base64').b64decode('SnFWZG10Wktra2c4dUU5RXY0ZTU=').decode('utf-8')
    if len('') > 0:
        _dead_8607 = 729
    total = value + len(text)
    if False and True:
        714
        pass
        pass
    return total

def _ЫМЮсΥψъьщδΔБрζрЧ():
    if len('') > 0:
        197
    value = 50116
    text = __import__('base64').b64decode('dnZlTzlhWURneUZ4TWI4ZzJUUXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΥΩζЪВασσθэδ():
    value = 868789
    text = __import__('base64').b64decode('QjVIVE1SQW41MmpwazVHYTBNanU=').decode('utf-8')
    total = value + len(text)
    return total

def _πюΣφднπщКΗΜιΖΑСч():
    value = 507744
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('VXlhRTNRYkowUm5HbDc5Tm82WlA=').decode('utf-8')
    total = value + len(text)
    return total

def _πКшъΗИζκΞыγ():
    value = 912914
    if len('') > 0:
        _dead_3409 = 133
        _dead_7599 = 244
        949
    text = __import__('base64').b64decode('anNReGpXUFMwZHJPdXdObGJOV1U=').decode('utf-8')
    if 71 * 74 < 0:
        _dead_6044 = 390
        440
    total = value + len(text)
    return total

def _αЩυПътаΚсθфЧ():
    value = 239120
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACTqaH4v2IVQCCeEwAeIbAh59mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 88 < 0:
        pass
        _dead_8137 = 480
    total = value + len(text)
    if False and True:
        581
        709
        _dead_7973 = 481
    return total

def _νΓаοюΝΥКаλоЭΤОК():
    value = 603815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F368f3oK/7olbwyk4gGnIho54EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γяЙЕσЗοрΒΧзГвнΦ():
    value = 947659
    text = __import__('base64').b64decode('YkNYaXJzOFc4bEdyMWt2VXVDb2M=').decode('utf-8')
    total = value + len(text)
    return total

def _πΑжΞφλИШъНοКΓШКг():
    value = 987915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz23O25q/bkSGQ6CnUeaYSg442o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χсιеιоЬУнНχρЭρΛ():
    value = 649415
    if 11 * 54 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB22P0Vg/aIUIlupmkemGicMtn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_7073 = 67
        _dead_5414 = 942
    total = value + len(text)
    return total

def _ЛΖΧПвжγΠ():
    value = 479565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARr3QAI18f8AADuZ7XeiBQIl4U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒιζргωΠпй():
    value = 167450
    text = __import__('base64').b64decode('eDZPaVhzZ1FRbTRnUFI1UkNyY0s=').decode('utf-8')
    total = value + len(text)
    return total

def _бьЯΞйЕΗγΨЦьΠ():
    if 17 * 2 < 0:
        pass
    value = 920042
    if False and True:
        pass
        pass
        _dead_5282 = 330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj/BZwA7zb0gEFyA+32qHwM/6Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оШЧΓοпзюαΞБΣЛыΛю():
    if 73 * 19 < 0:
        pass
        pass
        _dead_8605 = 855
    value = 775561
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCD8b2MfrKcPbCatyQ6bAS933Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 78 * 56 < 0:
        331
        _dead_5929 = 862
    total = value + len(text)
    if 9 * 92 < 0:
        _dead_1481 = 347
        621
        495
    return total

def _МпψЩκЕνбβωЙТ():
    if False and True:
        _dead_1206 = 807
    value = 376239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXnqXHovraMVCF+LzkKbJxd+7Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 57 * 38 < 0:
        pass
        _dead_6391 = 219
    total = value + len(text)
    return total

def _ХζΜБΨйеκОЭЙПаГ():
    value = 748737
    text = __import__('base64').b64decode('SG9odTFPN05HU0R3ZkdHbEIzRDY=').decode('utf-8')
    total = value + len(text)
    return total

def _τЖЯλμΖЕΨΠНШъΧФВ():
    value = 88252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mw3+RXAIzpgmHgas2nGUAXAn4Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЬοйЩΠйусгГ():
    value = 967101
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ajj8b0Np/J4UKVvz8HmCYi4utXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξУИΒΜюΨΟΒзυ():
    value = 91049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBy1fEUYzf1QMlemzUG6LCYuvEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рμхδАсуау():
    value = 76503
    if False and True:
        890
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwbFXnMx8YwnPiuNkWe2FjV40UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        222
    total = value + len(text)
    return total

def _аΟδртψκРА():
    value = 764119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRr9X3U6x/sZNg2cm1nDFhct4X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΔКюΦφчξЗξ():
    value = 210966
    text = __import__('base64').b64decode('YjZRSUF0S1FDNlZxV0ZmTlJMUWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗачдшСΚшЕ():
    value = 90464
    text = __import__('base64').b64decode('amFlSElGaWFaMFdZTVFRYWY5eXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ДЗрЛοΜЕРΒЧι():
    value = 98845
    text = __import__('base64').b64decode('ZVY0UWducjdJYjE4NHJYWjFwTGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ынсΦтΤоУΜЧзУо():
    value = 574931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBbOQG5hxIsCMQfz4kO0YTwCt34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψфΥРΞΚбИΕщэχжθм():
    value = 427126
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjnUVFoA5/wtKyiqwXW0OnwpzUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыωτгξψзυψ():
    value = 665293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRq8alsd5pwCMgeI8l+7NjYu4Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΓТоΝΔсу():
    value = 732049
    text = __import__('base64').b64decode('djgyQTRjRXlybk92TTJfdHV5aV8=').decode('utf-8')
    if 92 * 48 < 0:
        pass
    total = value + len(text)
    return total

def _ΧνΙКεХχХΛ():
    value = 739002
    text = __import__('base64').b64decode('VUZLdWVvRkRpdVVPaGdBREMxaEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡрασΧхЕЪ():
    if False and True:
        pass
        pass
    value = 901115
    if False and True:
        pass
        578
    text = __import__('base64').b64decode('TzJfb2FEdGQ4UHhRN3VmMmNxUGk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _тфΩυАΝйОΜδлΚКд():
    value = 28340
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwrVNmQMqIc1MD2m8FuxM3Up60U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 37 * 44 < 0:
        pass
        899
        _dead_2204 = 634
    return total

def _ΑιβЬглρХжъч():
    value = 918426
    text = __import__('base64').b64decode('cFBpdEx5amFDRThDN0xGVGpMc3c=').decode('utf-8')
    total = value + len(text)
    return total

def _НδуПчБΤэοебωΨбФН():
    if False and True:
        pass
        pass
        _dead_1453 = 14
    value = 954521
    if 75 * 6 < 0:
        _dead_9932 = 712
        880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EivhNgAOrJE7ABiI60KIHiwo4HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΝΦэЕънΜЯЗзΜДКΦ():
    value = 657446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSzFamIx3781EQeJw1yqDjYYvWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩμΧρвЯХωйэτ():
    if False and True:
        _dead_1812 = 290
        236
        pass
    value = 4358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAfIXwE/rZwobwq67FWYYnEF4UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        369
        pass
        569
    return total

def _ΞφЧΧχЭУШΛцТ():
    value = 651077
    text = __import__('base64').b64decode('dVdoRmZMejMwWWdlYUxqcjQ2a2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖЛΜεκЯφδιθ():
    if False and True:
        136
        274
    value = 126067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQO3Q3QzwaAFLQT64mCfZg87xlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ТрυψπВχбΩЯωюйςν():
    value = 153446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXzhW1Y/yKUqKTiL33TEOhEVync='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        641
    total = value + len(text)
    return total

def _яЗΒξΠψеПцαзΟ():
    value = 24503
    text = __import__('base64').b64decode('WERHU1pPbVNGNGNHWHpKR1MyTXE=').decode('utf-8')
    total = value + len(text)
    return total

def _τВЦΗαηАУ():
    if 90 * 54 < 0:
        pass
        202
        pass
    value = 926970
    text = __import__('base64').b64decode('QUNyTW14OEVvR2hZalhJUE84Qm4=').decode('utf-8')
    if len('') > 0:
        _dead_3817 = 904
    total = value + len(text)
    return total

def _ЪйХйсΧΓуΡцРΜпнС():
    if False and True:
        pass
    value = 436247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX2zOHIVwfsSGxX7wQ+ILgJ68ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πЮТΖσΛμЗбδ():
    if False and True:
        pass
    value = 503837
    text = __import__('base64').b64decode('bF8yd3VjSUpCWlpMdEh5NV9abmI=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_7770 = 115
    total = value + len(text)
    return total

def _εΙεΛрбБКПИρЫτχщ():
    value = 100406
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwDpe1ID+qoMPSiRz3uCMjMuw18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        140
    total = value + len(text)
    if False and True:
        _dead_6811 = 947
    return total

def _ехрьЪххπνщνΕυЕΡ():
    if False and True:
        _dead_9028 = 516
        846
        pass
    value = 672451
    text = __import__('base64').b64decode('dG9Bb3RrcG5zUG1ranlQZFhHRHI=').decode('utf-8')
    total = value + len(text)
    if 1 * 45 < 0:
        pass
        608
    return total

def _жтЫαλлжкОМАΚч():
    if len('') > 0:
        pass
        _dead_8274 = 940
    value = 248967
    text = __import__('base64').b64decode('bVFjU01tMlhpVjFxWndVRFJvVXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _кΣΑЩΤряЫΛзΩΓЮ():
    if 33 * 65 < 0:
        pass
    value = 300811
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSvSbHhqq/0LPleE8njAMXMsvUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟθЕЮеПЫш():
    value = 536100
    if False and True:
        594
        pass
        77
    text = __import__('base64').b64decode('Vm1lTmt6ZTUzcWdHekNHeGNHSGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑТυΥтарγщЙηΙξΜδΛ():
    value = 534836
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCP3SHIb0voiaD663numOxUjxXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7064 = 51
        _dead_4486 = 660
    total = value + len(text)
    if False and True:
        972
        49
        pass
    return total

def _ΜΨГχΜэΤПΩтΟ():
    value = 782664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyfSQVYM7J0NIAKy2Ea3FyQtsTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хχλΥУΛюЮчδς():
    value = 643002
    if 80 * 37 < 0:
        345
        _dead_2347 = 129
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHv8Z24D+YRVDCyvxweSOx0stz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        423
        pass
    total = value + len(text)
    return total

def _кхΧщпуΕΨΒθшТΕтΑ():
    if len('') > 0:
        _dead_8732 = 685
    value = 469043
    if 55 * 2 < 0:
        163
        pass
        _dead_7034 = 836
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAPifnMqrv03Ni2ukAGvMyIZymc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 92 * 99 < 0:
        pass
        pass
    return total

def _ΞдλЦъυюΗοΦрЮΓ():
    value = 478459
    text = __import__('base64').b64decode('UjRTMkJNemR4WnlaRk9ORkRLZVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _вхЖФфπψγΕκΩъТΝ():
    value = 531675
    text = __import__('base64').b64decode('TmRfaV9TcnBObkdLeGhvTEo2UG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ДбπηЫИХοΩΡИФгыδ():
    value = 427605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAuzNnUOp7xQKSrwz2G2CwIuvVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        375
        _dead_3946 = 875
    total = value + len(text)
    return total

def _ЗВσξИΛэюР():
    value = 693163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHbjWVBv9aY0bgfw5mKGAzAasGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬЩВъΥДσМ():
    value = 589226
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAbjPWsG8fgVDQCK8gDBM3Ur/lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 17 * 74 < 0:
        pass
    return total

def _хΩΝшΥβΚтхВιчΔъ():
    value = 221395
    text = __import__('base64').b64decode('TXRzS0J3X2h3NHFDbEpVdWJwTFk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        471
        pass
        128
    return total

def _МзΡТСИУЫπЗАФΛ():
    value = 173848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXrGbwZp86ABFjik2FSdZ3Qgwn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЫΝθιΓЯВИΤ():
    value = 714312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwXqSAE+y4U7DSmC/mGmGSg5yFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 72 * 28 < 0:
        943
        _dead_2858 = 134
        _dead_5867 = 382
    total = value + len(text)
    if False and True:
        pass
        368
        _dead_5733 = 535
    return total

def _ψιьЕГБбнИчΥΝ():
    value = 555419
    if False and True:
        626
        242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Knn2Xlwr2qMiCB2kygSgGyQDtmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        926
        840
    total = value + len(text)
    return total

def _юνрадβвЭд():
    value = 707315
    text = __import__('base64').b64decode('T2JtUUZlN0FwcEZfcGxZbHJScXE=').decode('utf-8')
    total = value + len(text)
    return total

def _МΗИσгΟΒχΙЮΜрфЬ():
    value = 606073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgLpW1oArZwFLQOUwHSvBhQo9WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 11 * 96 < 0:
        pass
        _dead_5727 = 480
    total = value + len(text)
    return total

def _ηυПяρΝВФНиΖΒ():
    value = 638782
    if False and True:
        _dead_9656 = 441
        69
    text = __import__('base64').b64decode('djcxd254ZTFhdEd0bjRCSGJoTHQ=').decode('utf-8')
    if 70 * 55 < 0:
        pass
        831
    total = value + len(text)
    return total

def _ΖйσЭωБΣМ():
    value = 529131
    text = __import__('base64').b64decode('RFpoRjRyWFNNelZfRFdZbTBVRng=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛукτПζюθФρΛ():
    value = 331801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSS2RkMT+aU6L1a2kAPCHjR26Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БцΖПЛлАιΜзΖЦΡΑοΩ():
    if len('') > 0:
        848
    value = 304237
    if False and True:
        _dead_9745 = 261
        383
    text = __import__('base64').b64decode('WHcwdnppeWNadm1VXzcya1RlVUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕλЯЕщюΜйωΘζυ():
    value = 415782
    text = __import__('base64').b64decode('RWl5cmlBZ0VPZXllc3g4bDRWTzI=').decode('utf-8')
    total = value + len(text)
    return total

def _аΙЦдкГЫбΘΦβνΦфΩ():
    if 56 * 48 < 0:
        pass
        850
        773
    value = 197600
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jg3BO2Uf1fAlGTr3xnyfFjw+yFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        464
        pass
        pass
    return total

def _χБЩζАъЛξЮγфΞ():
    value = 648224
    text = __import__('base64').b64decode('eE9rdnRQRVVlQ3NwX1FQQVlqRE4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2087 = 204
        534
        pass
    return total

def _сΟΠΝРξΒΣΦ():
    value = 376755
    if 14 * 39 < 0:
        185
        pass
        730
    text = __import__('base64').b64decode('WW1tNzVPdktFRjRKeEk5NmZJcmw=').decode('utf-8')
    total = value + len(text)
    return total

def _уДψЖΔΕни():
    if 41 * 89 < 0:
        pass
    value = 653932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQX+R2UT26Q8LTuqyl2qMwMi1Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3451 = 793
        810
        969
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_2240 = 629
    return total

def _ΖБюκπИΕν():
    value = 349675
    text = __import__('base64').b64decode('eGVzaU1GYWpHR195Uml4b054Rkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪμιΨгчШυθнΖ():
    value = 686572
    text = __import__('base64').b64decode('bzY2ZktjeXBlTUpuYlNNSUhGVXk=').decode('utf-8')
    total = value + len(text)
    return total

def _χΞΠБыΡХεΑШжыωн():
    value = 835564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACrpX39r9b8mCyiU32LAEQons3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШζΡЖΞοΜЯ():
    value = 273707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSPHRFIr8YZQMSK74QOxATB+610='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛшЪΘФΧхОАфкςпοБЭ():
    value = 981397
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LD+9fwYq6pBTFyS6wwOZByEB62s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        784
    return total

def _ΒОшкΒЯЯГфεжС():
    value = 786283
    text = __import__('base64').b64decode('clV6Q1QyeEkyQWNSaFVJMkd4RFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΤωоиΗЕпзЕУςз():
    value = 643645
    if 52 * 88 < 0:
        pass
        _dead_8830 = 820
        _dead_4961 = 968
    text = __import__('base64').b64decode('UDdFcmV6MGRlT1FDSDJkZmU5Zlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗБΙΖугзвφΠфωяЩΛы():
    if 8 * 25 < 0:
        _dead_5573 = 492
        _dead_1342 = 292
    value = 600789
    text = __import__('base64').b64decode('djdsdjJZRnJfN01uS244OFRTVk0=').decode('utf-8')
    total = value + len(text)
    return total

def _εаЮξЭΓЯΧμНиШδΘ():
    value = 660729
    if len('') > 0:
        pass
        pass
        _dead_9474 = 932
    text = __import__('base64').b64decode('YVd5U2JmV19WbWZERjdwamFETjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ИλцэγΒжмδ():
    value = 483569
    text = __import__('base64').b64decode('ZndhandlWk5sTFVtSEQ0UmhKT0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ςоΑхςдΛьΙв():
    value = 124396
    text = __import__('base64').b64decode('cjJiWEU2NTV5SkNBdVRFZHRlY1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΝыΜЫтαφЭшΗГ():
    value = 497917
    text = __import__('base64').b64decode('SFIwemNFY21XampScTU3V3hLT0E=').decode('utf-8')
    total = value + len(text)
    return total

def _πГωйЬъЗо():
    value = 639561
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCDUd2VqyJ1THzyxm1mSOSN/62M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъλиЖΧΘаЯФиФЬΟйХω():
    value = 672752
    if len('') > 0:
        487
        315
        _dead_9651 = 601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDzVRXM8p/hbPFux4UObJHc30mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΗΟРЛЦАΠсζι():
    value = 28486
    text = __import__('base64').b64decode('V2l0allwSzhQd2dRYVJVc1hsUGg=').decode('utf-8')
    if len('') > 0:
        562
    total = value + len(text)
    if 71 * 87 < 0:
        775
        _dead_8804 = 419
        pass
    return total

def _ΜΝεЪеВΨэΛδΕяα():
    value = 989583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AR+wQAQ85qcCDF+vygOWBDMOwEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 96 * 2 < 0:
        pass
        _dead_9194 = 785
        544
    total = value + len(text)
    return total

def _лнГβДξυΤЧвτЬЦΑξ():
    value = 134201
    if 63 * 25 < 0:
        pass
        879
        _dead_1161 = 571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnfzPghq6b4JCSCQkAWWIXEszTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΗΕнкШЕЯρуδξдфи():
    value = 981621
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCy2QXsh05shbQ6g6ny0BDIf9EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮШφΟПаъγ():
    value = 633695
    text = __import__('base64').b64decode('eU5xejBrX1VHMHd6ZjRuMnVHeHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒПсУаΝБγςαРζЗ():
    value = 291515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx/VSwJgx/0pPiD13n/DYgYI6XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _обЫрγКЙτΘщзЛ():
    value = 379831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyXdbX8I9fpbBQ2Lz1OnJiN+7nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΟΟиΜζνФθЯΗοΚ():
    value = 98928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjjJewETzPwzOCzx2V/JYyB3y0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔиЪΓφΗиψζКщуфЫБ():
    value = 967438
    text = __import__('base64').b64decode('aDZOX1dVREdJQXRYazhOWDNnY2M=').decode('utf-8')
    total = value + len(text)
    return total

def _чΞΗζВγΕоΑР():
    value = 277456
    text = __import__('base64').b64decode('UzlVTDB1R1cyOW4xdnRJTW04T2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЬТЪьГςрΜωы():
    value = 319133
    text = __import__('base64').b64decode('QUZkN1hnSVpOWVF1NDR6VnBvUkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ТСдΖγΞλэКСшΝфИЮχ():
    value = 763548
    if len('') > 0:
        59
    text = __import__('base64').b64decode('S3g5TmE4RDlDWkYyMTl4Z3FudlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΑшСЛφΥΚШвЮΣ():
    value = 20504
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiHrQnhpr68JPyeKnk+0Oyh3tFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υЪвхАеψшоДЦΛ():
    value = 841141
    text = __import__('base64').b64decode('Q2hyREVxUFBZbWFBU2lvU3daMDE=').decode('utf-8')
    if len('') > 0:
        pass
        569
        pass
    total = value + len(text)
    return total

def _παΨлЖΛΜΞЮ():
    value = 546764
    text = __import__('base64').b64decode('aUxzb0ZveGlNb1BpeHNQQU9wMkM=').decode('utf-8')
    total = value + len(text)
    return total

def _рΠМпъΞЗαψщωФмжαЭ():
    value = 397323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiXbf34uyY4VFQCB4Ee7JHM81U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1817 = 491
    return total

def _уфΩВΤюгЧΥАнЯВШ():
    value = 237636
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD21QWIK75wsazDx20KnEgodyn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΛМτΘΗШнпвйЗГηт():
    value = 128356
    text = __import__('base64').b64decode('aWNvUTlhYkgzX29ReXVxVk1GTVk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_4958 = 957
        399
    return total

def _эΥΟНАηМТЫΡСλ():
    value = 81420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgvIZX4j+4lSBQepwA+RPXQ622w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΔΦΑщЪсΤΒблЮΙΡ():
    if False and True:
        pass
        pass
    value = 453325
    if len('') > 0:
        _dead_1928 = 289
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAHKTwAf3flVGBenwlzJOTwj6WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 92 * 71 < 0:
        675
        _dead_6618 = 382
        pass
    return total

def _ΑИшΘНσзгЗЛл():
    value = 429393
    text = __import__('base64').b64decode('aUF3UXI0UDlnWDBqVEUwMFh3b2w=').decode('utf-8')
    total = value + len(text)
    return total

def _жФεЕебηИΦДκτ():
    value = 798761
    text = __import__('base64').b64decode('eGtZTmh0dnFkSUcwQTVxcWJXN0s=').decode('utf-8')
    total = value + len(text)
    return total

def _бΟЩξдΥыοщ():
    value = 306435
    text = __import__('base64').b64decode('SlJNR1RtazFmRnFKYkdkSW5TcUs=').decode('utf-8')
    total = value + len(text)
    return total

def _БНЩπЩюΠιετСкЩΑо():
    if 41 * 62 < 0:
        228
        _dead_9224 = 528
        129
    value = 237740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyLJTGgXqLsLDwyQ3HrIITd39m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 63 * 62 < 0:
        528
        _dead_4069 = 236
        _dead_8774 = 566
    return total

def _ЭЖрИйдΙщЩΞηΗДΖξ():
    value = 206803
    text = __import__('base64').b64decode('d2t3QkM5VnJhNm55VERJdF9iN1U=').decode('utf-8')
    if 36 * 66 < 0:
        pass
        305
        _dead_4078 = 598
    total = value + len(text)
    if 68 * 67 < 0:
        pass
        _dead_4637 = 961
    return total

def _λΥιРэвмΥνСдιХσ():
    value = 263394
    text = __import__('base64').b64decode('RlI4UGZHSW91eGVxeTlfUF9xM2s=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        253
        pass
    return total

def _аυюГΒχьУυЩйбч():
    value = 150404
    if False and True:
        _dead_5190 = 758
    text = __import__('base64').b64decode('ZjZSb2tZeVV1eWc3ZjBsdnJCZU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕхйЮЧгΜΟх():
    value = 710488
    text = __import__('base64').b64decode('Q2xwWFd0N24xOVpvdUFUR0hmX3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘκХΜцшпац():
    value = 2043
    text = __import__('base64').b64decode('cFBpVGlxWHdIbk40NlY3S29ZNFY=').decode('utf-8')
    if False and True:
        _dead_7362 = 562
    total = value + len(text)
    return total

def _ΩυβАоЩеπЫΡПηЛσλΠ():
    if False and True:
        pass
        544
        570
    value = 766055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiC0QEQo54w1Lgev7AClGxN37UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΠчδжСΞаИВΩβΙΜΩн():
    value = 209482
    text = __import__('base64').b64decode('U0hLRFpGRDdoZ3NyZ2NrMHNsNk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓеΤΙЪΣδΔ():
    value = 553786
    text = __import__('base64').b64decode('b19jWl9CVHU4WGZic0RBeDczN1k=').decode('utf-8')
    if False and True:
        17
        pass
        _dead_6144 = 200
    total = value + len(text)
    return total

def _ЪΛψъΚОΓОЦΟп():
    value = 453921
    text = __import__('base64').b64decode('Z2Mwa09EU3ZvSV9BTVZjX2E5RmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΑΒоЗуэиςМχЮтБΔΩ():
    value = 314767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSTmWFBozbA6Fy6l7QaCIRMC3n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮψЕΤρσытυΒΘΟμτψ():
    value = 596711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eg70PF0w/KRRbCCM2l2bZggL4GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪПНФвыАΜ():
    if 51 * 55 < 0:
        295
    value = 63674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dy7yWHM8/45ROFqF/16YJhU17lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΔрчΙнΟуъМамΗЭ():
    if 86 * 76 < 0:
        _dead_9962 = 650
        pass
        496
    value = 506775
    text = __import__('base64').b64decode('b3FYaTRJN2RRTTBuWms0V0NncDU=').decode('utf-8')
    total = value + len(text)
    return total

def _иδшνψЫЫхВъЬΡ():
    value = 386167
    text = __import__('base64').b64decode('d1o0Wk12STk1YUFwM0ljNFF6WE4=').decode('utf-8')
    total = value + len(text)
    return total

def _γэЮρΖшЬвиΣЮЕ():
    if False and True:
        _dead_3550 = 919
    value = 218756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgbmRW4I+ps5HRihn3qVOHMJvD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        742
        _dead_9572 = 49
        70
    return total

def _ΙГηχΠΡрοШН():
    if 45 * 42 < 0:
        pass
        _dead_2935 = 358
        pass
    value = 677693
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCnhf3gv9o8QKxiw+leZHiAq9D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ывгРЙκьΘъЛλπε():
    value = 657658
    text = __import__('base64').b64decode('T052Vk9KZDJvWWFCREtzTFNSbGo=').decode('utf-8')
    total = value + len(text)
    return total

def _уηΝнНΝГф():
    value = 749873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn3xPmVt7/wtFzaC3WnCMAwK9jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КкЯκЩΝΕΜЭрΤσ():
    value = 291753
    text = __import__('base64').b64decode('d3R4QVU3TnZvYnFPUzlWQTQ3STM=').decode('utf-8')
    total = value + len(text)
    return total

def _σюГСьЭоΩРьΟЛΚ():
    value = 681299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSjgQAIL9/okKlaMxAe4EQcXx3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οймΙβΜэЗιщ():
    value = 855775
    if len('') > 0:
        703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjnhQWUW17olBQm763u0P3wV7Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЛЪЬыПпоωвΨΠК():
    value = 261023
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DB21OngA3b4nLym3yQWHIxcf1mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 79 * 21 < 0:
        340
    total = value + len(text)
    return total

def _ШфъΩΝχФИСоОΝ():
    if 85 * 46 < 0:
        834
        pass
        _dead_3757 = 477
    value = 248591
    text = __import__('base64').b64decode('ajVPMnRiOFhQaTh3Z08wdl90RXY=').decode('utf-8')
    if False and True:
        _dead_2152 = 27
        pass
        58
    total = value + len(text)
    return total

def _ЬφΗκΣΒΤуΦФρΝ():
    value = 400214
    text = __import__('base64').b64decode('RExndGI4ZmcwNHNCcjFKRWlhaDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΘйъΛрОω():
    value = 200066
    text = __import__('base64').b64decode('SGY5bmNhZnM5UElJcXFySTVCUEg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_6382 = 5
    return total

def _ЯНЧЮщжТηΗψешΥ():
    value = 984870
    if False and True:
        83
        499
    text = __import__('base64').b64decode('SWxsQ0t4OFpWbTMyeTlCamdGaUs=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        585
    return total

def _ЫЬмЦцбιΡ():
    value = 327491
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgfgbwFt76owDlamnmHGJRMC8ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рцЪσшπΞπΝγΥςξИ():
    value = 379593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwDJREYI1ok8Mhy67WGVLiopwG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔьЧхщμмЗ():
    value = 217536
    text = __import__('base64').b64decode('eVpLMjF1WFRsaFhFSmd5cF81bzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩчагΞυΙчΜΟ():
    value = 118304
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgrJRQErzYIyHFyskH6qYnA6tXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΨБΙбжЪшеЮоуп():
    value = 540567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCDVX1Ag0KFaaByR8HrBIg8QxUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΝбОЯΒЗЪνΛэсΦвΥ():
    value = 178837
    text = __import__('base64').b64decode('c3JsempxZE5jTW5lWGlBX1JSMzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ПиΟБЕхΔιρНъΞтх():
    value = 779992
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En21PVYs9PAWPQGK/WmUZTN7wEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йнπъеЬλЩεьТюφ():
    value = 342554
    if len('') > 0:
        pass
        22
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgrBWGkP/KcmYhuI33K/H3J563s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 72 * 73 < 0:
        pass
    total = value + len(text)
    return total

def _ГбΕЮЕΓМξжМВςοтΙ():
    if 63 * 32 < 0:
        156
        pass
    value = 787953
    if len('') > 0:
        _dead_4093 = 73
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATi0T2Az75sNMTe2kHy7GzwrvHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4449 = 123
    total = value + len(text)
    if False and True:
        778
    return total

def _ΚСΛηБρУπεκΗНξηΜ():
    value = 662716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fhz3XwASzYUsESa3z0WjbAkXtWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фМзчωΩэЕмоХЗΠΒ():
    value = 733535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwfAYWBhx5E0KFm32wC0PBMN4Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жфΝθхеγдКБн():
    value = 796566
    text = __import__('base64').b64decode('REQ1Vnhvdmh5UTlHVk9zTWVKWWY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ыΟвбφκΨΗιвΑЭκ():
    value = 802236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISHDVAkJ6asVKwmp8UadHSoH9mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨъщεЯбЮωШэθъΙΤθφ():
    if len('') > 0:
        _dead_2666 = 328
        pass
    value = 909515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Py7wbHRsraUbCiiF3kKaJSQJ6l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 4 * 32 < 0:
        387
        _dead_1800 = 165
    return total

def _ытЧδΗТъа():
    value = 32574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MR+weUISrI0WA1imyUamPnIqtHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡуЭГбьζеГΨυЩΕЭхт():
    value = 447939
    if len('') > 0:
        166
        972
    text = __import__('base64').b64decode('TFFnTlhfdHJyNXREU3RpU1ZuVEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭХδβΞлзΓжΡ():
    value = 633328
    text = __import__('base64').b64decode('cHlGTWhDRzlNUGFxZlBxb1l4blQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ВшρлЮσγκпΤйμЭκЩ():
    if len('') > 0:
        205
    value = 979646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH78UQkB85kWGQuhw1+AFgd70G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 78 * 66 < 0:
        pass
    return total

def _ΕψρχΗΟьμ():
    value = 366574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyHBSEho9asyMhWckXmaZg0u/WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝВщОбЦвεвш():
    if False and True:
        pass
        305
    value = 950330
    if False and True:
        121
        202
    text = __import__('base64').b64decode('ZVNhRGYzZTZKYU9QQ19mcDBMSko=').decode('utf-8')
    if len('') > 0:
        _dead_9599 = 385
        72
    total = value + len(text)
    return total

def _βъШβъδΞРмΞмεβЯΟΗ():
    value = 480549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh7GOUEc7fAbHyu57kSoFy86w3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    pass