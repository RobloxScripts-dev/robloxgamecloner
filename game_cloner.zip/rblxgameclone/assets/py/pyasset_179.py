#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _тОЛйΤΠУταлιьПβς():
    value = 304904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwHAOmgMyJwGPxm78VW6bCB6zHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БνТυюЖИЖσΕХγΗ():
    if len('') > 0:
        _dead_8338 = 901
    value = 635795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA39ZkcI2Y0yFjX63Q6oMDABwWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1381 = 124
    return total

def _ΚωИъπтэΡδЧφκшΚнμ():
    value = 368650
    text = __import__('base64').b64decode('TXMwVkdFbl9mSDNjdGlzRGlaU2g=').decode('utf-8')
    if 3 * 27 < 0:
        _dead_7109 = 20
    total = value + len(text)
    return total

def _оАιχяΚΑьСΤэ():
    value = 949347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwXGZ3448ftbPh6E5mypGwMd0n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΖВьЬьΓКИ():
    value = 17813
    text = __import__('base64').b64decode('ZVBGNEhQVWRqdWU5cV9WYkloRlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЪθЛчπЗзυ():
    value = 851778
    text = __import__('base64').b64decode('Y05Ja0ExTWNRakZCREVwZDRnaDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΨφΘБЖφΤιзХ():
    if False and True:
        _dead_9762 = 399
        475
        _dead_8788 = 137
    value = 470800
    text = __import__('base64').b64decode('TnpuZ3pTa3lnS2x2emZtQzJSTkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨДΗПτυЕвΔЭхЬΗжм():
    value = 659811
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iwriflcu/4YlND66zmeKAxYdt2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        656
        _dead_5158 = 720
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        677
        551
    return total

def _ЕюΕПЙтΞПΒыΝЮψъЧ():
    value = 328642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBbTdAgPxLIzCBrz7AaZJCF512M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υπςΩлΡΤσΒюΠκн():
    value = 932143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjXBXXtv+oYmEDuE8kyhZnIf/F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΡлЫΘΞтгΑПю():
    value = 142487
    text = __import__('base64').b64decode('a1hiVlpXMTdjN2F3SVJyX3J1NTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _МеΖΘνζΑъОъРφ():
    value = 650073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAPtPwM1+7ooMSGnxX3BF3MHt1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭθΣδμεАЗЛЯΥЙ():
    if len('') > 0:
        276
        _dead_1696 = 507
    value = 7624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jif3dkYOz4MRbhqQkVfBNwQj8ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 52 < 0:
        pass
    total = value + len(text)
    return total

def _κψΛΤΦωεЛМιςΔ():
    value = 935433
    if len('') > 0:
        _dead_4238 = 895
    text = __import__('base64').b64decode('S2s5SmhvN0VmaHk3bTE0dVFqa0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ηαДιοΠΡδнΥВХ():
    value = 732875
    if len('') > 0:
        pass
        889
        pass
    text = __import__('base64').b64decode('YXVFeUZHWDRsdDdnOGl6OWNZY3o=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЩεРюΥжГΞψΥΕρΖ():
    if False and True:
        _dead_6595 = 374
        950
        _dead_1067 = 363
    value = 716438
    if False and True:
        pass
        711
        _dead_7669 = 737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwjARH9g6Y80biCl4l27GhEE4jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2165 = 900
    return total

def _ιуЧΟхΥПρΝ():
    value = 14867
    text = __import__('base64').b64decode('TWdYbzEzY0UwTzhCdW9kdXU2b1c=').decode('utf-8')
    total = value + len(text)
    return total

def _οбχωωλДэю():
    if 19 * 32 < 0:
        pass
    value = 993707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHbQeVgx8I08Y1yCwWWCbAgK8zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 31 < 0:
        _dead_7253 = 996
        618
    total = value + len(text)
    if 57 * 96 < 0:
        _dead_6116 = 506
    return total

def _ΦЮуНηγΒαμЙ():
    value = 712280
    text = __import__('base64').b64decode('bm95MlRuRkJiYWJHYWx2MmZVcFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ψχηφΞλΗЖ():
    if False and True:
        pass
        _dead_2149 = 818
        _dead_2046 = 856
    value = 467764
    text = __import__('base64').b64decode('d0VOVnc4VnBGa2ZEVEZnaVh1RzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒβЛΒΒмγαΜяοЙ():
    value = 473667
    text = __import__('base64').b64decode('QmU4ZG41anpCYmFINVhEdnA5ZU8=').decode('utf-8')
    total = value + len(text)
    return total

def _уΥоДьζΝЩЕσуМλι():
    value = 413180
    text = __import__('base64').b64decode('djJuUndZTjZvVU1HVHBGNmV6Y2M=').decode('utf-8')
    total = value + len(text)
    return total

def _аΒΘΑВяΖΥγЧΙРыβ():
    value = 983522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAzLY34cyJ8PNh6l8mGGC3AZ3E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΞμζыΦЖΙη():
    value = 567917
    if False and True:
        _dead_9518 = 213
        826
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgzVWXcArbwuCjeM91q/HgcDsHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 92 * 86 < 0:
        pass
        pass
        _dead_4504 = 841
    return total

def _оΖζΟΩФеъΤ():
    value = 283983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAzVRXYA5JARaTm6mFPCYiQ/4FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΝΣψшΚКΣДГ():
    value = 271113
    text = __import__('base64').b64decode('ekQ2WVg0R1JhZ0dONklUc2xvREw=').decode('utf-8')
    total = value + len(text)
    return total

def _ТчφРеΟΣΘμΨΙ():
    value = 85640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eie9S2s+9ZgnHCWz0mWHHx198n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡзЕЙхтδЖаЮΩеПтςБ():
    value = 50714
    text = __import__('base64').b64decode('bUxySVIyUnIwVWdHcmdGRUJwSEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΙΦδηΟΥσОцтΚС():
    value = 186040
    if len('') > 0:
        pass
        810
        pass
    text = __import__('base64').b64decode('QWxfbjUwSVVKd2lJZjJjT1lGVkU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        81
        100
        346
    return total

def _ΞФТηιΩΡΤй():
    value = 907283
    text = __import__('base64').b64decode('Ujh2UGUzQnNjbzNYNEViVWNfX2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧВэθΝмδьЙ():
    value = 925464
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAfCV0gexJhQaBiB43GEOnI2700='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩμΒλΙеЬктΔΕвψλШΟ():
    value = 975599
    if False and True:
        12
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Igf0d2No+6sSHgWm73O6Zyw2tGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ανЦЩТψταмТэτ():
    value = 660785
    text = __import__('base64').b64decode('a3ByUG90NDR4NHNNcFhRbjJ6QjM=').decode('utf-8')
    if 88 * 78 < 0:
        _dead_6935 = 540
        460
    total = value + len(text)
    return total

def _ЧπТλσРщΨΚ():
    value = 546859
    if len('') > 0:
        _dead_2618 = 45
        pass
    text = __import__('base64').b64decode('R1lwZE1QNkxwWW1EWENGa3VhaTE=').decode('utf-8')
    if 41 * 73 < 0:
        pass
        _dead_5321 = 717
        956
    total = value + len(text)
    return total

def _чσжЕЖЦΛтηβЪ():
    value = 348092
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTbmUUlr17g7DC2smFyaHw53zHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВζчΠςщфЩηΕнсηНχχ():
    value = 425617
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT3WV1ov9ftaPB6SxgeDDiE/6XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_2098 = 530
    total = value + len(text)
    return total

def _эчЕπдЬυΡ():
    value = 117135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3fcZX0IqIc5HB6mkW+3GzB7znk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 59 * 37 < 0:
        175
    return total

def _сΤпνеθПШσнΕ():
    value = 919302
    if len('') > 0:
        _dead_9587 = 714
        pass
        _dead_1374 = 900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MniwY1MK7LwXNjWO+G+eFTEjy1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑлЩΘφфУйв():
    value = 161893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHjAVl4Yxo9XCyGHmluTJg12xzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        169
        pass
    total = value + len(text)
    return total

def _αΜХюΒжЛκΤκЫΧп():
    if False and True:
        318
    value = 397276
    if len('') > 0:
        _dead_2723 = 467
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ31fVYfpv8VbBWMkXu3Oi8D1zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъαΛбΥδφι():
    value = 540818
    if len('') > 0:
        pass
        704
        _dead_1644 = 718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E33AQXAbqo4sCjr6+1WGNSQ2xWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 10 * 48 < 0:
        pass
    return total

def _еσкχИΠΕΠ():
    value = 436986
    text = __import__('base64').b64decode('aUtXZjkxcUtGb0ZOOUs0VDZidEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _цαИΤξмъλКςθΜρЭεЫ():
    value = 133753
    text = __import__('base64').b64decode('U29tRWhJSmpxOTU1UFZ3d3d4alk=').decode('utf-8')
    total = value + len(text)
    return total

def _ХαСНФΙβν():
    if 53 * 46 < 0:
        pass
        pass
    value = 759581
    if False and True:
        808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAjtfAc/+J0xKRyH7nCZHzQW1Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΥыΕσЭαнЧц():
    if False and True:
        128
        _dead_3814 = 975
        pass
    value = 475026
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQqyO2ULxJk3KSu532SEJw8r90s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 97 * 36 < 0:
        135
        pass
        _dead_5072 = 208
    return total

def _тξΒορΛδэЭфζщтпВР():
    value = 829510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCTFelI177saHwD13Xe5G3w7zm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НзЬнιчДЮψс():
    value = 640537
    if False and True:
        595
        pass
        _dead_5341 = 598
    text = __import__('base64').b64decode('czZFbnNDdHNEclczSWlVaHJQSDk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        669
        _dead_5812 = 307
        865
    return total

def _ТйвΤЛΖгъ():
    if 23 * 79 < 0:
        pass
        160
    value = 82892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnfgeUsjrrwoPDi16mSzMXcssUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 34 * 81 < 0:
        _dead_2704 = 733
        pass
        _dead_6639 = 407
    return total

def _ЧΩΛсΘνХГУбХзγбΛв():
    if False and True:
        pass
        640
        894
    value = 23022
    text = __import__('base64').b64decode('bXdQdTFoTU1FM2h1SXZ4am5KWFI=').decode('utf-8')
    if 29 * 33 < 0:
        pass
        pass
        _dead_5342 = 176
    total = value + len(text)
    return total

def _ΑЗкσζфΘΔШΤπΟΑГ():
    value = 906722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB7yXmYr3403FAek43SJYwIowHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЪΟΩпшΟЦξ():
    value = 545979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cw3PR2kc+o5XKCOC/EGRLDMctmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8619 = 134
        pass
        438
    return total

def _мЪηЩЧЧАШЗλЖфЧн():
    if 84 * 33 < 0:
        pass
    value = 523460
    text = __import__('base64').b64decode('aWlvVlFRMFJtaWlDQWh5TzV2T2g=').decode('utf-8')
    total = value + len(text)
    if 89 * 8 < 0:
        _dead_2473 = 565
        623
        pass
    return total

def _χчЗЗφМλΡΧПчП():
    value = 48289
    if 17 * 82 < 0:
        _dead_7676 = 909
    text = __import__('base64').b64decode('UFZsNmo5OTZXVERNZ1dIdnlBQl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ТεоιИЖυςззтпΩβ():
    if 75 * 60 < 0:
        pass
    value = 336932
    text = __import__('base64').b64decode('RkxkMU9Xekx5Mjk5X0t6TnRaTHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΧЗΡЕТβЩвχ():
    value = 336689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSLSOXMX2ZgXHzeM3gPDIzEu/Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4083 = 804
    total = value + len(text)
    return total

def _ИΣНжБΘЦлтωЬβЪЛβ():
    value = 691609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT7TbVIW56UsIgGRmgSBBz976ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΟЩШЫΩΔчΠхΖΟУ():
    value = 301738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSv8a3oG+KQBOA6p3WexDHQkykE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕζъПфЮбΚнΓЩΤΤвωψ():
    if len('') > 0:
        325
    value = 384318
    text = __import__('base64').b64decode('ejdCSU1UUG9pc19EZGt0ZGN0U1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЮФΕμψшιЮ():
    value = 110999
    if 75 * 53 < 0:
        270
        _dead_1880 = 43
        pass
    text = __import__('base64').b64decode('dkJZWDdrYkpHbnRQUVhIZVBXUWs=').decode('utf-8')
    total = value + len(text)
    return total

def _кΑΛЫЩрюΓмЫ():
    if len('') > 0:
        495
        936
    value = 166985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS29Z18Rp/43IC31+mGKYwIu72A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыжщшχτΩЯγЙΔ():
    value = 342466
    text = __import__('base64').b64decode('WldlNVJvZW5EcGZ1YmpLMlQwaHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨβТШΤЗΚу():
    value = 663976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HS3zWHMY3I8tNgCg+H2GDhwj0Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΑушКκцΥ():
    value = 72624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjjpXWUbqZ8GCl250VmlECcY4Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦτЦУжЕрНοψΝЪΧβь():
    value = 530673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lw7DN38qzoIpFx6R0l6dHRYf1WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 100 * 46 < 0:
        _dead_7819 = 543
    total = value + len(text)
    return total

def _ЙФТыΦυуаМщχъφ():
    value = 133080
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCrxSm4D1YEZGSORz2CyFTwbz2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζΑЭЯκπΠПξЦ():
    if len('') > 0:
        406
    value = 327318
    text = __import__('base64').b64decode('WEI2Y3FkZGlLWGZYUzFOSUYwX1I=').decode('utf-8')
    if 73 * 54 < 0:
        _dead_8979 = 962
        335
    total = value + len(text)
    return total

def _ЦνβЬψΖЦдρЖГθΜΓρδ():
    value = 117379
    text = __import__('base64').b64decode('QmlGWldjbV9EQ3BKa0x0NEhlazU=').decode('utf-8')
    if 13 * 8 < 0:
        _dead_1812 = 641
        pass
        pass
    total = value + len(text)
    return total

def _дзУОЬαШНМлχ():
    value = 316057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhnuXQETqf4hOFa55FLAYhcW6Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЙИМΞШАБ():
    value = 631438
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxjwaHwt9odaECq00H+EFwp41FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 22 * 69 < 0:
        772
        79
        _dead_1480 = 905
    return total

def _εВΒФΤтЩеыμλΡΓНю():
    value = 451484
    if len('') > 0:
        _dead_6318 = 164
        _dead_3578 = 33
    text = __import__('base64').b64decode('Z1RRNkN0ZFQwNXJMRE9Jd2hlZEI=').decode('utf-8')
    total = value + len(text)
    return total

def _жбΖЪΗΕдΒΛσΡπжο():
    if len('') > 0:
        pass
    value = 533488
    text = __import__('base64').b64decode('TzRHX0piSjBXUm9vSVpaMVlWSWk=').decode('utf-8')
    total = value + len(text)
    return total

def _εБМνАΜОШзййЧгФΙд():
    if len('') > 0:
        59
    value = 983306
    text = __import__('base64').b64decode('TGpiUmd4alJnd1Y4Z1NPVklsdm0=').decode('utf-8')
    if False and True:
        _dead_7415 = 269
        _dead_7027 = 807
    total = value + len(text)
    if len('') > 0:
        _dead_3258 = 825
        pass
    return total

def _уΡστЗпИΙФд():
    value = 600075
    text = __import__('base64').b64decode('UmJvdTVSTFczMnFHM2pUUVNQTW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩнΧΟφЧωУΑн():
    if False and True:
        813
        _dead_9719 = 443
        527
    value = 366340
    text = __import__('base64').b64decode('bnNIbzl3dV8xbGN2UjlJZjRrbTk=').decode('utf-8')
    total = value + len(text)
    return total

def _юдХφДбγс():
    if len('') > 0:
        _dead_2687 = 769
        540
    value = 785830
    text = __import__('base64').b64decode('SFR5VnNrYkwyekdjWlZfMjNZejY=').decode('utf-8')
    total = value + len(text)
    if 98 * 83 < 0:
        pass
        585
    return total

def _ΨВψδψыΡЦΞЪη():
    value = 951636
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjfbVEVoyrsEHTyp+2/BLhMJ3U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖАъπЕНдηΔΑΣ():
    value = 534943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3zyRlka7bsqFjirmg+pNyco23w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΖΡΙοΖβΗΡХРЖвЕВ():
    value = 778570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyTFfgM49/owIjWIwW/EEg8nwn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οИПΨКаιΚЦличЭю():
    value = 471924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCHAYH9gyosxPRq0kF68EhV31E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8265 = 732
        342
        _dead_2296 = 344
    return total

def _ВσγΞοΥхαΗ():
    value = 400378
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex/rQUFq9okbCSKsxXClJCIO62U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤλВэШθΓСшаΕΚΠРжЗ():
    value = 866829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MX79e3w75vsQb1qm5mO/HwY5738='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭРХΨЬμνтεХΖχδςь():
    value = 436360
    if 33 * 47 < 0:
        604
        572
    text = __import__('base64').b64decode('TVdZM0VNbnhBZFU0SHJMYmxQRmc=').decode('utf-8')
    if len('') > 0:
        59
    total = value + len(text)
    return total

def _цЙжЧфЪΑсςатГΦΔз():
    value = 572709
    if len('') > 0:
        pass
        pass
        _dead_2985 = 162
    text = __import__('base64').b64decode('TDJUdTRNeTNYWnJYT2dNQjJMWXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮτШлФчφΦφжΙπэ():
    value = 418658
    text = __import__('base64').b64decode('WDc0akc2Nnd0cktTYzRmMWVaZFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ГφμζΛвΒлΥ():
    value = 615468
    text = __import__('base64').b64decode('RTN2ZUVaV2t0MWZaRjRzV1RWb3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _НрДςзΡАςβфεШΛюОБ():
    value = 149124
    text = __import__('base64').b64decode('UUYwX1ZlZHE4TlNSNW0yTTBoazg=').decode('utf-8')
    total = value + len(text)
    return total

def _ωкЮτрΜдφЮ():
    if len('') > 0:
        935
        _dead_8036 = 489
        _dead_2775 = 748
    value = 836503
    text = __import__('base64').b64decode('VHN3WFg1bGxtUUx4Z2V3TVloeWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ψШФвЗЕΔδΔЖκшБ():
    value = 127857
    text = __import__('base64').b64decode('UU4yTDVrUE1aa2hnU192dmxUckI=').decode('utf-8')
    total = value + len(text)
    return total

def _щΑυЫΛЦχюΛΥΧсЬας():
    value = 899708
    text = __import__('base64').b64decode('YUNZb19oakdNb0JtRHJ3YXVSSDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦчδμΑχюТТюΙΞл():
    value = 981539
    text = __import__('base64').b64decode('UkJka0NQQmxmZFZqVGRRbWtWOFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑχτнйляΒхиАτСТ():
    value = 184027
    if False and True:
        _dead_5656 = 21
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQfxbFULzYomaiiUkE6bOHF40Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рξυΓОφЯмΕГБ():
    value = 531349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pziwa1o007wsLTazn2mkEwQ/x1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔτЗфЖщГыηπνеΒΞ():
    if len('') > 0:
        _dead_5805 = 360
        pass
        pass
    value = 10457
    text = __import__('base64').b64decode('dGRJQjZOSHZ2YWx2bldTaTJrRHg=').decode('utf-8')
    total = value + len(text)
    return total

def _δΙПФΤЦспχΗ():
    value = 88392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E37XR0cw0vEAHFaS+lHCEikEwD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨβШчΤЯйуωΓξ():
    if False and True:
        pass
    value = 561694
    if 64 * 37 < 0:
        _dead_2652 = 150
        pass
    text = __import__('base64').b64decode('Q0MxZ1lZNjdyb25oRnloWGwwdUE=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if 22 * 64 < 0:
        _dead_8116 = 251
    return total

def _чκτσзΨТοжηψΔ():
    value = 431455
    text = __import__('base64').b64decode('dzJ2NV93WEVoRVV1Qk9tSE9XYXU=').decode('utf-8')
    total = value + len(text)
    return total

def _нцλτйЯηЮоςωΛψνЧО():
    if False and True:
        _dead_2663 = 618
        _dead_6432 = 844
    value = 199399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg68d349+JoIADm2ym64DgkasHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬκИРΝυΠΓβΥ():
    value = 416340
    text = __import__('base64').b64decode('eUE0SmxfS1Fib245SlRkdXdPckg=').decode('utf-8')
    total = value + len(text)
    return total

def _γчφрЬςμοηД():
    value = 979787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnvuZAkM/IshMSz7nkGiYw8F1mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БχыΘΡиΘОη():
    value = 429933
    if False and True:
        pass
        963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iib0W1ozzoszAly04UXHYiogsUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7972 = 601
        _dead_6468 = 380
    total = value + len(text)
    return total

def _фяеυМмиОΖхιТςχηΝ():
    value = 288970
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CS3MfXA4zq8REhaV6Qe8FQA8zVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юεΡРΝмμвΤР():
    value = 752633
    if len('') > 0:
        _dead_2340 = 83
        960
        _dead_8080 = 639
    text = __import__('base64').b64decode('a3gxOGppQTIyVHZNeUJmZEJtQ1U=').decode('utf-8')
    total = value + len(text)
    return total

def _рΘОβχψрЫ():
    value = 75655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHa0fW4K+oUkIAWkxU+DMD8Qy20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γτЛαΝψнУГюΗΞ():
    value = 885224
    if False and True:
        755
    text = __import__('base64').b64decode('VkF2cFJOVkNEOHFvcFBXQXZhbDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥЪοЭΤΝλνγаΧ():
    value = 694867
    text = __import__('base64').b64decode('SEJVVzczVnhZSEFRZlJaMFZOQVc=').decode('utf-8')
    total = value + len(text)
    return total

def _РпΖАКПΔΡς():
    value = 102062
    if 63 * 20 < 0:
        929
        244
    text = __import__('base64').b64decode('RjJ4M1BFM1hwYlBLbmlzZEJ6aTA=').decode('utf-8')
    if 52 * 82 < 0:
        242
    total = value + len(text)
    return total

def _βЧξЮπмЯФ():
    value = 143529
    text = __import__('base64').b64decode('UlY3ZXpscnpKc1FVQjB3OHFoSUM=').decode('utf-8')
    total = value + len(text)
    return total

def _хςΘУНщЗЪΧΜΛТΤ():
    value = 394721
    if 76 * 42 < 0:
        25
    text = __import__('base64').b64decode('T003b1RxdnF3QTMzdkRGeDhTbnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝсВАНюθρэЪхИΙυТ():
    value = 778449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxjlQ2Vu+Y9RDCKkmWO3PDUty14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥйоιНκγω():
    value = 195517
    text = __import__('base64').b64decode('TU1vQkdmNzJQSm92Qm5kUUVpa3I=').decode('utf-8')
    total = value + len(text)
    return total

def _КΨцтГПыΥтΣМΠП():
    value = 635061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgL3PVsw64YAYlqy0neXLhYYtjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣΗζПЫоΥдψЪоО():
    value = 892953
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PATqXGgd15EzayyHzkK1DikQx0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        2
    return total

def _ΜΠЖхеγУκ():
    value = 468149
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwzqSHsg2roKHAO00GCoDS1+3Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨψЛЩЖξИМЬЛЫΜщЭ():
    value = 319152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwfzV0E71bBWHCqWn3ujGwh9zzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΙэΣЯμΘВψ():
    value = 992919
    text = __import__('base64').b64decode('eGdBUm1yTkdNcF91SDlrZnJJVVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ψнЪСбζэуψ():
    value = 902405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Awb2XHYyxp9aEyeOwnq7Oi4d6lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГБηЮЯаЯΜτο():
    value = 106203
    if 96 * 60 < 0:
        pass
        _dead_3713 = 359
    text = __import__('base64').b64decode('bzBHMmYyT0pjM0ZLZnFZRDcxQWc=').decode('utf-8')
    if False and True:
        _dead_4951 = 399
    total = value + len(text)
    return total

def _ΘΜΜЕΤенКςЗ():
    value = 532545
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgayQ2Yr9L4xAFuSngWUAHU11mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΙЗГьΒΞБΒЛ():
    value = 349260
    text = __import__('base64').b64decode('Z0pmN3NtbVN3U0FqbWl2akFkQ0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑэЭАиτЫςПρЦсшυτ():
    value = 290097
    if 19 * 49 < 0:
        pass
        _dead_4833 = 733
    text = __import__('base64').b64decode('aElQYmg3c0hReGFoa05mZ21QRjY=').decode('utf-8')
    total = value + len(text)
    return total

def _НрРζΒОθПΞκОл():
    value = 94912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDbTS2Vs+poEFhWE4gGROiEL0XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 76 * 53 < 0:
        _dead_4560 = 453
        _dead_6965 = 525
        26
    total = value + len(text)
    if False and True:
        433
        _dead_7872 = 109
    return total

def _ЪФΙιδΛнгЙнфхЩτюς():
    value = 344767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgnbbGkD2LoJGzWg+1vALgkGyU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΠМΨωеδηΚΞςхеΩг():
    value = 936288
    text = __import__('base64').b64decode('RUl6M1BicWNuelNFa1FoRmxZSXM=').decode('utf-8')
    if len('') > 0:
        124
        _dead_9721 = 612
    total = value + len(text)
    return total

def _ΟРσΘΚΙΣИЦцβγйΤсб():
    value = 55917
    text = __import__('base64').b64decode('eFdibk9FUk5rTXJkOHpNWUE0X2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _иеζκбωтаШψтэн():
    value = 488379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwnsQ1Ma6qYMBSXz4WKHBQA770s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ыКεэбНΛзпΣΘΛξΗ():
    value = 737798
    text = __import__('base64').b64decode('Z25POVdZYnNUeXFTX2d4U294TTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΔδξхδηжσрΥΖщ():
    value = 990866
    text = __import__('base64').b64decode('SGg1enRxcHVUNVlDaUs1c1NYTTk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        385
        pass
    return total

def _рНΝαУЯΩΥΔЩСМБп():
    value = 606762
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fxm2WgQL04oyDVey2lrGJTMLx14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 20 * 35 < 0:
        _dead_3757 = 700
        _dead_4792 = 496
        _dead_2854 = 715
    total = value + len(text)
    if len('') > 0:
        _dead_6162 = 420
    return total

def _ΣΑΣΨзШΠСФοφТЯзη():
    value = 424970
    text = __import__('base64').b64decode('d1JWYTB4ZGl4T0g0ckRmTnk5SWc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        544
    return total

def _ΑуоΩεмΗΑσаб():
    value = 376677
    if len('') > 0:
        312
        _dead_2762 = 745
        pass
    text = __import__('base64').b64decode('bDdsMU8wOHNRYTRvajI3SzhORVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ИЖοЬДπφиЙ():
    value = 341256
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KC7tZkQwqowbPAyh/nCSIgQ1vT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πзаΜφΜэΚцш():
    value = 820480
    text = __import__('base64').b64decode('dThMMXBaY01tVlZJZkZMVlNHd2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _πΞжΠвΒшгεχςБΠчςШ():
    value = 147757
    text = __import__('base64').b64decode('clBnQzJWYTBFdHlnanBXZGRqZGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫеρυοпаьΡιз():
    if False and True:
        pass
        824
    value = 706017
    if len('') > 0:
        pass
        384
    text = __import__('base64').b64decode('QmFZcWNhS2I3UWVMa1l3ZnA4OVc=').decode('utf-8')
    total = value + len(text)
    return total

def _сΖξΓΑСВρбθъШ():
    value = 639799
    text = __import__('base64').b64decode('QmdLUV9lUHFRQzkzeWNLZk5oMTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ςРΔΑΖΖЗβкйβжБ():
    value = 577139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji7eYnYz0aIragyikXSgHyQ6sWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уπφΝнΡПъФΙЮψШΒβμ():
    value = 194146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECrgZ3A0rqIGHyaz4He1DHAqsjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νИощβЧчваφХ():
    value = 658641
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiTzTV0b0LIkbluV21KiJiQa4GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мηйνНтыΔУГо():
    value = 236664
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz7tYEkI0a4iGxyI3kHFDjAm7GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬθΝΗΚΓИμεйτД():
    value = 634663
    text = __import__('base64').b64decode('bFlZSnZUVGY5RHhXWW1IWnlfWUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΥчΜΒбΨΤΥ():
    if False and True:
        pass
        pass
    value = 954644
    text = __import__('base64').b64decode('cGk1ck9IMUhGeGxmVUJITmZGeGw=').decode('utf-8')
    if False and True:
        148
        _dead_9371 = 244
        456
    total = value + len(text)
    return total

def _уфЦκΓαуΟΠΦсивзИ():
    value = 993383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng7tQEA01/8FAFiPygO8PRIY5mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        834
        pass
        916
    total = value + len(text)
    return total

def _нιΑΨЧЦЫοЧщωмтпΟ():
    value = 88681
    text = __import__('base64').b64decode('ck5XZ21XZUZnMjhaQVBNYXY3UlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _МШβЛЛδАмЖ():
    value = 216199
    text = __import__('base64').b64decode('bFNnRkdaWlU2SGt1c3U5N0RqSGg=').decode('utf-8')
    total = value + len(text)
    return total

def _дχЬεвГщεБμцьСλΖΑ():
    if 80 * 45 < 0:
        751
    value = 514306
    if len('') > 0:
        851
        789
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FArASW4/8aVVPzj222XCF3w8ymU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΒьРавШΒсεп():
    if False and True:
        pass
        138
    value = 558515
    if len('') > 0:
        140
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzywSUsA9oANIw223XmWBxAstXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 63 * 46 < 0:
        pass
        _dead_5850 = 365
        _dead_8454 = 747
    return total

def _ΩΧΓылвωЖмЕ():
    value = 972854
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgvXYmss/Kslbwy3zGKnBhEc4FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΟΣыЮЖΕеλДх():
    value = 472977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHbndHg/rYQTPDe62gedBy16xUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УлйЮянζΓσσΨГйΛН():
    if False and True:
        pass
        594
    value = 496931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lg3LTXQu8q4VaD764WWyIXIn6T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _кыΝЖШцгУиюτАъа():
    value = 26353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARzpXFtrzZ88ET6lzXehOS4L1WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠβдЯсεψФ():
    value = 121521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRizawUg8bgVFgyqkAbIGAR49V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙУнВΦаЦУхП():
    value = 937236
    if len('') > 0:
        476
        _dead_2969 = 867
    text = __import__('base64').b64decode('U2dackVYWFJ1MUFpNFJkVlMzX0I=').decode('utf-8')
    total = value + len(text)
    if 51 * 61 < 0:
        541
        _dead_8877 = 763
        348
    return total

def _ВεΞЛбαОьζνΧЮΘс():
    value = 191289
    text = __import__('base64').b64decode('c3lrQ0lvNl9YX1V2VTdEaVZUWTg=').decode('utf-8')
    total = value + len(text)
    return total

def _бщПОчΜмξЗ():
    value = 329903
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCfsSHkU260OaiL2x2KIZBw8wmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8663 = 831
    total = value + len(text)
    return total

def _ЕТΠΝеγΜЦЫ():
    value = 261959
    text = __import__('base64').b64decode('YlpQa3JGQ21aNkhRVzYxSFd6TDc=').decode('utf-8')
    total = value + len(text)
    return total

def _дЧΚνЪΙИьΞфмΨЗчс():
    value = 951855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgPBZHRvwbAHLw2J7X+JYxQt934='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_6559 = 165
    total = value + len(text)
    return total

def _ΟΙШδρняΚμ():
    value = 941357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiDmaAEXxIoGDg37y0O3BTEO3VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 90 < 0:
        pass
        _dead_9964 = 657
    total = value + len(text)
    return total

def _йεьΚЛэТΒΔйτяюО():
    value = 194183
    if 61 * 28 < 0:
        pass
    text = __import__('base64').b64decode('eWc5cmp3aGc3Zm1yYzY0YWd5V0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ηйщПЩрБЕгТγαλ():
    if len('') > 0:
        _dead_6396 = 724
        _dead_5864 = 15
        pass
    value = 853556
    text = __import__('base64').b64decode('dU5KRVdsQW81T0ZROGRlWHlDeEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧРΨΓТШκТыяΗмλΑΤЬ():
    value = 401726
    text = __import__('base64').b64decode('Y29xY21scFFjZEtTWWZjOWdzQlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ζφυωШйψЧ():
    value = 940232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgveX3gB7f9WETiO50XADRJ6w3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΟгρйΔΝйΔТ():
    value = 199805
    text = __import__('base64').b64decode('UDZJdVdsWnQ4dmdFNVpnZFpMZFo=').decode('utf-8')
    total = value + len(text)
    return total

def _хБфЛЛдЖψ():
    value = 888978
    text = __import__('base64').b64decode('SlhOVW1RS2RCc3RJOGRJZHhsUVQ=').decode('utf-8')
    total = value + len(text)
    if 67 * 96 < 0:
        794
    return total

def _ωτψΩδψвЩΙΙГ():
    value = 726916
    if False and True:
        pass
        pass
        _dead_6662 = 705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AD7Gd1M3r6A5ExWRxlWyYCcW6Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ςΠгηьΓЯЗжцВЗГмΨЯ():
    value = 691218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH3mR2UN7v0HLAOn6XCbLAgg13w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИμΥВрβъБψθЙ():
    if False and True:
        pass
        pass
        pass
    value = 71510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxveUWgY0a9XEwfx/1yAOxJ63mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вюаΝлЩεΣφ():
    if False and True:
        306
        pass
    value = 781365
    if False and True:
        pass
        pass
        _dead_6063 = 949
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhDUPUsS54lQChq2kQfBAj01zj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3011 = 371
        pass
    return total

def _кΣτПΙЬЗм():
    value = 398659
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EijIOmgorqkVPhaX+QeVbAY36HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ΔУРЬοЦΞΩΘ():
    if 52 * 23 < 0:
        pass
        733
        pass
    value = 214752
    text = __import__('base64').b64decode('UmQzMHVRRE5iVHIyd3F5MWxYZDA=').decode('utf-8')
    if False and True:
        _dead_8577 = 644
        632
    total = value + len(text)
    return total

def _хГΘвЬЯςγω():
    value = 747281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Igb1TFYRpoxWPxyl4megCz8L7Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыτσчΗСΙθΗ():
    if False and True:
        _dead_1839 = 926
        pass
        pass
    value = 69839
    if 9 * 27 < 0:
        668
    text = __import__('base64').b64decode('dzFfTTdPcDBTbGs3Um9QRlhsSTM=').decode('utf-8')
    if len('') > 0:
        _dead_9465 = 119
        pass
    total = value + len(text)
    return total

def _мΛμΡκΜΨбНθΟщЦЦβ():
    value = 926231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwLNY1MYq4AQElqnwkSDC3wi6GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΓчοНпАычВау():
    value = 825560
    text = __import__('base64').b64decode('ZUV0RUFJbGdyOUJXZTFFNnVsWUo=').decode('utf-8')
    total = value + len(text)
    return total

def _АфΝркЫΦЦπ():
    value = 219202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IijzZlId/Z4iIDqy0UGABzMrwmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъщЛыофΣкл():
    value = 190270
    text = __import__('base64').b64decode('QkFSbzBIdllDb2tyNzFZb25wako=').decode('utf-8')
    total = value + len(text)
    return total

def _φЛΕъМΗоσГιΨΤΩ():
    value = 479065
    text = __import__('base64').b64decode('S2NLNGllS0pNOGlYUnF4d2ZrMXI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4573 = 635
        876
        pass
    return total

def _ΙХκαуτЪкЮοОьψЬТ():
    value = 78852
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjW8eAMwyYkgAwmi0H6XHjIOwUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рПыΕмΧЯмьΣΨЗα():
    if len('') > 0:
        pass
        337
        pass
    value = 156919
    if False and True:
        pass
        _dead_6076 = 210
        139
    text = __import__('base64').b64decode('bmFZVDBHbWZOX1pXZXpqZm9zaU0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΣЬВΜЦШЦзμсэХзЩΞΦ():
    if False and True:
        919
        104
        403
    value = 425875
    text = __import__('base64').b64decode('WkNITDRnZTkxSzE0dGNxcHVGNEU=').decode('utf-8')
    total = value + len(text)
    return total

def _нξВΖфσБηфΗлφκΜΩΙ():
    value = 958181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FD3eZEU7qaRTawmI+WfDBXQ5tF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 92 * 43 < 0:
        642
    return total

def _уРХуχрЖχΩРΨРэ():
    value = 869074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxvyTUMXyYAZAFuN3E+ZBX12zHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝξγУЗфтпяхπδΚЖ():
    value = 74609
    text = __import__('base64').b64decode('SDZBaW13ZHgwblBXemFMWlA5Zzc=').decode('utf-8')
    total = value + len(text)
    return total

def _βЖτΛефΛЬЩπж():
    if len('') > 0:
        pass
        pass
    value = 271665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQHiY38p8IwpCCGJnwCEH3w8yX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ОрГβτвβАГК():
    value = 663368
    if False and True:
        132
        _dead_5560 = 635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISveYn1h1YpUEC314w+yJzZ48kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 36 * 38 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()