#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _рЗйνγяπΘЭ():
    value = 9800
    text = __import__('base64').b64decode('SUpIXzAyTERWYWxfRnFtRktNY1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ШаΧрбБГЦш():
    value = 817164
    text = __import__('base64').b64decode('Zm1PZjJHZzJFZmtZZ2tocUxXQlE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        227
    return total

def _цЙκБЮЩьηбλцΖъς():
    value = 36095
    text = __import__('base64').b64decode('SkZpTjVKczN5akFwZUhjTTRGUGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠдρШьσИчДмΑΡ():
    value = 366529
    text = __import__('base64').b64decode('YzhrbzJhOV9hbnJ0YmN6OHVYSUg=').decode('utf-8')
    total = value + len(text)
    return total

def _СΒΜчΜΡрΦУΜ():
    if len('') > 0:
        _dead_6570 = 31
        pass
        _dead_4040 = 503
    value = 266933
    if 54 * 23 < 0:
        pass
        pass
        _dead_5188 = 871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCrLbHIB/IQJOzyBzUSxFSkO9zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦЩМЙгВνΚвπлσ():
    value = 58398
    text = __import__('base64').b64decode('SGV2T0tyak1WSWFlWDltU3c4Ymk=').decode('utf-8')
    total = value + len(text)
    if 54 * 12 < 0:
        pass
        413
        480
    return total

def _ЖмЙηЛИжχуФΜлΓз():
    value = 719006
    text = __import__('base64').b64decode('ZWZyRDZNS0MyV2Fub2FjRFZWaGM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8608 = 648
        pass
        pass
    return total

def _κзбЕычΒИΣщτы():
    if len('') > 0:
        _dead_2925 = 332
        pass
    value = 533609
    text = __import__('base64').b64decode('cDNHdHh2OFJBOEtFU0VPZ01Xemk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗБφλИЪфэγΛ():
    if len('') > 0:
        195
        _dead_2883 = 983
        869
    value = 512527
    if 49 * 50 < 0:
        694
        711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCW1dnsvqZ0bP1aNzm6+IQcIwH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8143 = 291
        283
        _dead_5040 = 507
    total = value + len(text)
    return total

def _ъъΑΨΒАмЩмбе():
    value = 745480
    if 28 * 66 < 0:
        534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB+3TUFp3YAhbiqB0QeqIzQhtWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖчιυЮΖВюοЖ():
    if len('') > 0:
        _dead_9369 = 66
        pass
    value = 38550
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwLlZ3QwqL8bBTCE4UTJOjQL4XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βшθζΨΙгфΓпбюЩ():
    value = 710428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz31QggNyqdaMjj0/FGHAwMhzkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХКσыξкςМ():
    value = 136959
    text = __import__('base64').b64decode('bWdFeVFMc3RTdmxxQWRyUXVZMGk=').decode('utf-8')
    total = value + len(text)
    return total

def _СЗуΗΗΨлЪШκдΡпσ():
    value = 152021
    text = __import__('base64').b64decode('RTAzN1kxS1dQX1pZd2JsX184cXI=').decode('utf-8')
    if 16 * 5 < 0:
        _dead_5576 = 674
        408
    total = value + len(text)
    return total

def _ιΕжωЯτШФζΘм():
    if len('') > 0:
        _dead_3201 = 266
        pass
    value = 958159
    text = __import__('base64').b64decode('UFdRS21TN2RhTmhqejlva0NiXzI=').decode('utf-8')
    total = value + len(text)
    return total

def _нΥЮΙθПаХМуΟ():
    value = 871539
    text = __import__('base64').b64decode('UFZOX3pBbGNJSjZBUHFvRjlzcDk=').decode('utf-8')
    total = value + len(text)
    return total

def _бГчюиΘρΥЦЕνСΧ():
    value = 837051
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh/AYnke8bsZADy6/wahHjwu80g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛωДмβρЯΒЕΕЦюξИ():
    if False and True:
        pass
        869
        pass
    value = 391362
    text = __import__('base64').b64decode('Z294SHJicDZQV3d1VXE1SXRVMGw=').decode('utf-8')
    if False and True:
        436
    total = value + len(text)
    return total

def _кγцτвяиΝΞБΝΗΖЦВ():
    value = 843260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX3PSFcP844uNiSu3FGKbQ8G4EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςπеΔΩδυηаЕΨΥх():
    value = 486569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAjlO3kK8poWbQSa3VHDLjwQ614='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λМΗκмАΛьяЮрηжψηκ():
    value = 94598
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dibjelgs2/8EY1qa7lCZPwEc83g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΕΠΛθλΣХМυΣыξ():
    value = 937665
    text = __import__('base64').b64decode('S2VVejRnY09rUUFVZlA2ZXZoT2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ηяИрИэχжΧμζΜюЗΣχ():
    value = 203206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KybuPnIc9KMbFSKM8VmqZiwWwjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 4 * 55 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _νоЧζдμΘймΕьмТ():
    value = 158142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyfMX2cIrJ4SDDCU3mGdBRcgyUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if 45 * 92 < 0:
        590
        pass
        _dead_4175 = 432
    return total

def _ΤγσчыΑйиЗэеη():
    value = 734082
    text = __import__('base64').b64decode('dV9OQU5LSWY3bmN2Q25KSFNLUEk=').decode('utf-8')
    total = value + len(text)
    return total

def _МοЫМКйΜιΑζВЦηΞТт():
    value = 242321
    text = __import__('base64').b64decode('czd2ZFJpbTFjY2tOS0xBS0UxY3k=').decode('utf-8')
    total = value + len(text)
    return total

def _йЦУρплыЭ():
    value = 365216
    if len('') > 0:
        pass
        pass
        _dead_6805 = 225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT/ASlYu/7AiajaO/kO+JjYu3n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хηВΦЫжЖδэЬтΔщηт():
    value = 54352
    text = __import__('base64').b64decode('Q0pWeEJUYVRfMUt3QkJ0UG16UkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΤΡаξφЗеοЮαιЖеΝ():
    if 84 * 69 < 0:
        602
    value = 186625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwzpRgJpyYJUEjyP4nidGikM3WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        319
        pass
        pass
    total = value + len(text)
    return total

def _ρΚΥΛβААиβм():
    value = 966774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx/GbH06q/okajWtzQLJZ3w+s3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СвьΛσЛΗФ():
    value = 493710
    text = __import__('base64').b64decode('Q1k0SUZUTExkRlJMZEZ0QWNManE=').decode('utf-8')
    total = value + len(text)
    return total

def _ыщоючуЬΒΖμк():
    value = 788200
    text = __import__('base64').b64decode('bzA2Q25KaV9SZEFaRG91VzY3eFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛкМкιзΔΗЗΡнΤΜνβ():
    value = 755700
    text = __import__('base64').b64decode('SjhNMk1aQVpDOGZ1T0U4OHNqR2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _пыβквαбΒяПж():
    value = 238173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K33yYXwe6a4BIBmpw06JNzcl9WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЭвΓΛΨНκη():
    value = 673900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERfXb3NvxKAiHwOKnViKHy8Zs20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3904 = 793
    total = value + len(text)
    if False and True:
        _dead_2622 = 587
        203
    return total

def _ЧъλмΜщψикΡЫО():
    value = 605239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ein+WAMJ0Ps5OC2c5mGpOxwG0Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        48
        pass
    total = value + len(text)
    return total

def _щΓλΓеЭцнсбΔβэ():
    value = 908544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH7xfVYI05wBbR25yViGESEO3Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΩςКФШквρ():
    value = 958747
    if 37 * 28 < 0:
        982
        pass
        469
    text = __import__('base64').b64decode('ZUlHMEVmanZ5aTVpdEdDTWJkQ0c=').decode('utf-8')
    if 19 * 49 < 0:
        pass
        pass
        pass
    total = value + len(text)
    if 38 * 21 < 0:
        _dead_7375 = 712
        pass
        841
    return total

def _εΛσμξСεΖΛб():
    value = 955018
    text = __import__('base64').b64decode('V1lTdnpDdVZsdkhkempRT2ZtUTE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8730 = 710
    return total

def _ЙΦлОиζЖΒΕΜΑμςΚыК():
    value = 19323
    text = __import__('base64').b64decode('ZFNHbDJqTnRyWWkxYzlfbU1GdW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠλθΛΠвθρХееЗ():
    value = 948167
    text = __import__('base64').b64decode('WnFoWHBhRnRJNWNObnpKcm1XUEw=').decode('utf-8')
    total = value + len(text)
    return total

def _νиΔΓωθИгδТэВΖΖτΒ():
    value = 294211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnftQnQM0KY5FRyQm3/FYCc9slw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИνΦОζΚоЫАΥУРРР():
    value = 712233
    if len('') > 0:
        135
        pass
    text = __import__('base64').b64decode('WUtrSFQ2c2Y2MW9aNFQ2VW81WUk=').decode('utf-8')
    if len('') > 0:
        187
    total = value + len(text)
    if 19 * 11 < 0:
        _dead_2094 = 0
        _dead_2624 = 841
    return total

def _ιелΑΒΔЖм():
    value = 782719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX/JaQYvzvkrFAGLxG6fYgAI/Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        385
        _dead_4823 = 940
    total = value + len(text)
    return total

def _πζъΔγЗΞπθЭ():
    value = 699095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnbcQVAcyroGLwiIx16aBAl/8GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΤнςЭλуПЗфγΩыФ():
    if False and True:
        _dead_6109 = 977
        _dead_3488 = 976
        pass
    value = 609923
    text = __import__('base64').b64decode('cFA1bXJRR09ENXB5RWl4MVFiUG8=').decode('utf-8')
    total = value + len(text)
    if 8 * 2 < 0:
        pass
    return total

def _κΤжΚНΦΡΟД():
    value = 895562
    text = __import__('base64').b64decode('Q3o3Z1V0NFFXdGMwOWdKYTB4aWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧйорΜмЖΨρпΞκЕК():
    value = 837639
    text = __import__('base64').b64decode('bTZQZXU1Mm9XOVJWT1BYakFOVno=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑхЦунΕаЮяСνцΩмКф():
    value = 73286
    text = __import__('base64').b64decode('Y1RUVnI0VW9UUHplSVJ0YWRkQ2M=').decode('utf-8')
    total = value + len(text)
    return total

def _γуΗσξьΩΞаΨπЗнΓ():
    value = 66285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAT2QEk19/kxCQyE4EGhOysL4V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΟβДПφΤΕшБЫΑΧεГ():
    value = 930050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQO9Zmdg0qI5Ilqmw0yGYjUYtT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 63 < 0:
        pass
        859
    total = value + len(text)
    if 43 * 69 < 0:
        _dead_7018 = 527
    return total

def _δеъςНБйΖхЛЪръИУ():
    value = 120916
    text = __import__('base64').b64decode('UHRVdXRIQ0lUeTlKYjIzMDNoZWw=').decode('utf-8')
    total = value + len(text)
    return total

def _хбНΞΛюΞЛМч():
    value = 345094
    text = __import__('base64').b64decode('TE0zb3ZidE9iRjMweWRUZTRVVWo=').decode('utf-8')
    total = value + len(text)
    return total

def _Сυфψгяыт():
    value = 69191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwTeXXM9740rOA62xE+3MjEe5zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1658 = 803
        pass
    total = value + len(text)
    return total

def _БоУГλΔъλΚ():
    value = 382456
    text = __import__('base64').b64decode('SXNqSG52RWExWGFxbDkxeExHTTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕβΞШШОяуφηπδиΕΚ():
    value = 242951
    if len('') > 0:
        470
        621
        pass
    text = __import__('base64').b64decode('TlJEalRhTmNaNFRjRU01ajhMaDY=').decode('utf-8')
    total = value + len(text)
    if 51 * 34 < 0:
        _dead_4885 = 207
        236
    return total

def _ВдГΟΒьЬйζДьεΞЖΞ():
    value = 374278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiWzRnMhqaUIDxWv/HnIHDQMxT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дьуВиБЙΒГΖИ():
    value = 536948
    text = __import__('base64').b64decode('VXVNQ0VyYUVDVE5lZmVON1EyS24=').decode('utf-8')
    if False and True:
        988
    total = value + len(text)
    if 12 * 66 < 0:
        pass
    return total

def _оψΝЭВБΞуξ():
    value = 89569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiX3QUAg/5ckHSSK5AfCYAYOwWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жκЬпΤεωΧчκΧζΦ():
    value = 88385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCPNYggx7qkLPyeZ4XeaDXYI8lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΗНБцδюΙβΗΣχΙσΙΟ():
    value = 313418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBn3OkYzrLsPDS6I6wSyHHIEwV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТявШΒТЮδЪτыыΒΨ():
    value = 139986
    if 40 * 86 < 0:
        pass
    text = __import__('base64').b64decode('ejFMbmdxdnhaWkFuZWVqUFRpaHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ζλχΞьμΣцКЫЕЕНЮ():
    value = 561906
    text = __import__('base64').b64decode('cXFMaEZnanRpbzQyWHhKdENORU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘКфЯэπбρ():
    value = 229072
    text = __import__('base64').b64decode('cER3RmVLN0ppMlhZcWVPT1F5dmU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        381
    return total

def _ΟЛΝъЬΖтыЫяθΨΩκ():
    value = 285795
    text = __import__('base64').b64decode('bkc3aGh3anE4SDBEeDJXeGcxZnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦэБачωεЭмПψ():
    value = 527711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NynmQUAdx/85EFr6/wCGFRcB7FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДнαυλиΗηθе():
    value = 571691
    if False and True:
        pass
        _dead_9242 = 427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fin0PAYA/bw8HSaF5QKiE30LyUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3276 = 591
        25
    total = value + len(text)
    return total

def _ξΟВЕйΔΥχτЯΡЧА():
    if len('') > 0:
        pass
        500
        _dead_8199 = 892
    value = 2134
    text = __import__('base64').b64decode('aEFaN1V4Q044RjMwd0YzZG5sSHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟВζЧеЮЖΞωφНВχσ():
    value = 307508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JALnf2YQ5/gOHSWzmAS0ARY4vWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΟΦиηΥъμ():
    value = 86688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAzDY1dtzPwgCA2RzWS1IAI/tEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ЫЖΚрънΖСγβΕδφФς():
    if 27 * 29 < 0:
        pass
        _dead_5327 = 493
    value = 513441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxXcagQt+Z5XGwa1ww61JwAlwVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _упτЩдφΑτηШеγф():
    if len('') > 0:
        _dead_5290 = 665
    value = 385550
    if 70 * 49 < 0:
        pass
        pass
    text = __import__('base64').b64decode('V2xOd1dabGVOa2REUVpkUEVMMUM=').decode('utf-8')
    total = value + len(text)
    return total

def _пщкжΨшюЧТрυξ():
    value = 279459
    if len('') > 0:
        _dead_3936 = 483
    text = __import__('base64').b64decode('RTQyOGNLNWQ5N3o1cVRScGh6THY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5969 = 248
    return total

def _ΦНЕюΔИτАχυФγЦμ():
    value = 181195
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBfsQgId0apVLgz05FGxZDN6t0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОыНΣΛκФШУш():
    value = 159903
    text = __import__('base64').b64decode('eV92b1d2SHNzSU9fdWx5d2p5Wko=').decode('utf-8')
    total = value + len(text)
    return total

def _Πμυсπусцд():
    value = 348467
    if len('') > 0:
        pass
        453
    text = __import__('base64').b64decode('U0hCTlJjamdqNHBzbFNidHRCRmQ=').decode('utf-8')
    if False and True:
        771
    total = value + len(text)
    return total

def _яλшАъρΛОΟА():
    value = 336909
    text = __import__('base64').b64decode('UnlCamJBNlM5RENSdnhhOVExRGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ойΜνΦЙьσΩζΣΣγΗА():
    value = 29432
    text = __import__('base64').b64decode('dkY1b25MRlRsaXJ3d19xc0ExejE=').decode('utf-8')
    total = value + len(text)
    return total

def _μζκЗиЖюΝДκуαΤ():
    value = 275012
    text = __import__('base64').b64decode('Rm5EcENFTF9mNXZueGtWT0swN3U=').decode('utf-8')
    total = value + len(text)
    return total

def _υΡюξЯπΦвГΡ():
    value = 784423
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyexXmNhyIQmHhuq21u7ICkixm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6209 = 849
        _dead_6624 = 472
        _dead_3342 = 530
    total = value + len(text)
    return total

def _θснХΙδνμгш():
    value = 288596
    text = __import__('base64').b64decode('aU5qVEZWSHNIOVp2ejE0bko3RDA=').decode('utf-8')
    total = value + len(text)
    if 39 * 15 < 0:
        _dead_5268 = 6
        _dead_8318 = 762
    return total

def _мерπΙРчмЬЯр():
    value = 225872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fj/tOXYrqqoibzuLwWSyOS4ozEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΡθЭοφΗηλВтΘΝΞ():
    value = 623824
    text = __import__('base64').b64decode('Y2Rac2l2dDNiZjVRMmN3cjdLaGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _οсЕφжΣзμΗκΔР():
    value = 724983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3bLZXhtpoksOw6R+VWvAC4Fsjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψυΜЮюΚхΖμΠжГчХп():
    if 23 * 38 < 0:
        _dead_5975 = 799
    value = 897611
    text = __import__('base64').b64decode('VHFJZUhGYXhkcmxRNEs1T1ZBRlY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΓШλΜеΚΡ():
    value = 626961
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgjqfUgUzo8mbD65w1iYPAAgw2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 28 * 41 < 0:
        pass
        pass
    return total

def _оυьяβΔЪЙехΓЦψщΦ():
    value = 364489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IifsXQcU7b40LwH3/FypNnwcyGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сТЭдΗΙрΤлΨφРшСзу():
    value = 420493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDixT24f66sIFSSA32mnPSIXzj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        188
        _dead_7355 = 377
    return total

def _АνΟθюиМЩБΦэΜцιУЦ():
    value = 751865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC20b0sS0IItMSmcwk+EIiIc6mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОαИФηΨИюМμгΗФΩΜ():
    if 91 * 30 < 0:
        _dead_8010 = 115
        897
        _dead_6759 = 986
    value = 980291
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fi3yZ2EQ1PwxLiiW5X6nAnEmtkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωзаСьςωεщ():
    value = 225503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hyr2ZVwT8IAGb16H+nOmFTQutkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йБΟХОΘπЕтъгКψшЫь():
    if False and True:
        pass
        _dead_2616 = 37
        pass
    value = 761365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSDCf1s8+aYzEQeqynG0MgQntkk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_3123 = 6
    return total

def _чАЖμЗЬΦγΙ():
    value = 536655
    text = __import__('base64').b64decode('d05vaGdXY1ZOdmRnb3ROVUxZaDU=').decode('utf-8')
    total = value + len(text)
    return total

def _ХъыдщΩЦНЖ():
    value = 678641
    text = __import__('base64').b64decode('Z2NQQUJwbXNubGNTaFhFbUk2c0o=').decode('utf-8')
    total = value + len(text)
    return total

def _αГΟлЕεМΟфζ():
    if False and True:
        496
        _dead_9944 = 683
    value = 108712
    if 27 * 50 < 0:
        _dead_3978 = 13
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACK3eHg/0YwZAweLmnqqBjQktGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        77
        pass
        _dead_6235 = 583
    return total

def _ΨΡЖмАИЩГ():
    value = 320528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KS7IS3Iwq6UlGAeI5kC6LCd3smc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жλдτΙΓΓЛ():
    if 27 * 88 < 0:
        pass
        _dead_8373 = 526
        275
    value = 353124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ajr9ZkE0wbw2FAONwnTJJRc+vEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΑσЛВςПыю():
    value = 185219
    if len('') > 0:
        _dead_3500 = 689
    text = __import__('base64').b64decode('dVp5TkVuX0VCaUZzeEFScHJNRjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥСχаГсΒьΗΣяυΖλР():
    value = 197082
    text = __import__('base64').b64decode('b2JxT2VSVHV3aFQxaDhrQUxfS0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩνЦΤцЩХчржςΤл():
    if len('') > 0:
        pass
        _dead_1351 = 359
        568
    value = 632277
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('QlJxbHdsQXVnVXUzZlBNeDhxaUI=').decode('utf-8')
    if len('') > 0:
        _dead_9732 = 14
    total = value + len(text)
    return total

def _ΗпраТΑОΓΓЫМΩ():
    value = 588135
    text = __import__('base64').b64decode('bWkzOFFoU3dmZGM3RXFuX0ltUzc=').decode('utf-8')
    if False and True:
        _dead_4765 = 644
        65
    total = value + len(text)
    return total

def _ΝЬЩЮЗдΓΨΔУΘмς():
    value = 613696
    text = __import__('base64').b64decode('bURiX2dsWmNGdEk1Nkl5SHlyVjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙιрλΗζЪЙ():
    value = 895162
    if False and True:
        _dead_4861 = 106
    text = __import__('base64').b64decode('WmFuSHRiV1AzVW52dTVBRlhzYmc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        187
        664
        _dead_2807 = 723
    return total

def _ψеЧΑПтРВωЙ():
    value = 940609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhvuOVJh5oAmMQX7wUy3MgYexW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рςαЗТДζЦΜХьжςщΨЙ():
    value = 634536
    if 11 * 72 < 0:
        pass
    text = __import__('base64').b64decode('cHI5RnRIeGg4d1R2RXlITERNa2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ωкбИφДςТΦΡЕШ():
    value = 416149
    text = __import__('base64').b64decode('eUFURzAzRnl4VGpXM2hpaVpTdDM=').decode('utf-8')
    total = value + len(text)
    return total

def _шГНπΓοйущ():
    value = 365354
    text = __import__('base64').b64decode('dmdYZENDUzVQWUQ5cHp5ODdpOUk=').decode('utf-8')
    total = value + len(text)
    return total

def _αЮГЧΞΤβнеъ():
    value = 338003
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3f3fQc/zrAmPT6i/mmYLBQO51k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αηЪΝκНωξзγж():
    if 29 * 98 < 0:
        pass
    value = 51176
    if len('') > 0:
        _dead_5485 = 159
        712
        _dead_2138 = 883
    text = __import__('base64').b64decode('aHdrYnpSaW5JaWtqRUlvTnE5V3c=').decode('utf-8')
    if len('') > 0:
        pass
        286
    total = value + len(text)
    if len('') > 0:
        411
    return total

def _ΗΔΑςΣТШЫЬШ():
    if len('') > 0:
        _dead_8120 = 335
    value = 765771
    text = __import__('base64').b64decode('dV83YXFHY3RvZ3B1ejY5a3M4dGw=').decode('utf-8')
    if False and True:
        667
    total = value + len(text)
    if False and True:
        _dead_3290 = 27
    return total

def _ειвΡфΩЫΛΥуаАУГ():
    value = 550054
    if len('') > 0:
        pass
        191
        _dead_1078 = 622
    text = __import__('base64').b64decode('WEJHYVg5MzNSdjdBSlZ1N1RlV1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _НуυσчКЛΓδюΒНω():
    if 43 * 76 < 0:
        _dead_2887 = 191
    value = 444315
    if 21 * 81 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyvDXHk9p6AiNSSZnUepZHQc018='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6565 = 66
    return total

def _уβθМΛΗτОσσ():
    if len('') > 0:
        pass
        215
    value = 639304
    text = __import__('base64').b64decode('TTdVejFtTVNnTXhrVmFoV0x4SWk=').decode('utf-8')
    if len('') > 0:
        309
    total = value + len(text)
    return total

def _ЯξоЕΡυБЭС():
    if False and True:
        pass
        _dead_5369 = 520
        _dead_1554 = 960
    value = 269588
    if 23 * 76 < 0:
        288
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBDNQXQ2+rkzCimmzwa2YA8Exnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΣΝκАРзыψДщψФ():
    value = 28174
    text = __import__('base64').b64decode('TTJtaVo5aXZLdFg0a3ltTnY4Wks=').decode('utf-8')
    total = value + len(text)
    return total

def _εъВЖηЧψΞтα():
    value = 155469
    if 13 * 59 < 0:
        372
        _dead_5776 = 191
        969
    text = __import__('base64').b64decode('ZDVaOXNxRjNKNllJVzhsdU9weGg=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_2670 = 2
        227
        200
    return total

def _σμажηεκΙυРΧ():
    value = 661992
    text = __import__('base64').b64decode('Z29tUEVpa1pjMF9zRnpHOHR1Q3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩςРНлДοΑтΖκΕνвЬ():
    value = 865107
    text = __import__('base64').b64decode('eW1qdEtUYkFTOXpiSmxCbFMzWEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨЙШЯбΟΤЧΒΦξмПЧ():
    value = 863686
    text = __import__('base64').b64decode('dFVMNldDSjVVM1NZQ0ZTVWJRb2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ηъΔГλЕΙπчΚΤ():
    if len('') > 0:
        pass
        pass
        pass
    value = 601551
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwjSd3szp5AFPxyg6Xu5BR0Q4UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_2738 = 758
    return total

def _ΨΩдσнΖΦΤπ():
    value = 295896
    if 40 * 40 < 0:
        644
        _dead_8799 = 102
        919
    text = __import__('base64').b64decode('QkdMSGp2d0MyWklKT19HZFk4NGc=').decode('utf-8')
    total = value + len(text)
    return total

def _щЛΦГπтЮΝΤΘΞΞΕФ():
    value = 939296
    text = __import__('base64').b64decode('a2hKVnptMGd0YlREOWwxS29PN0o=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _χΩУποМφш():
    value = 625674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQj9eEIo7pwVHDu6+gGBbQkKyHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чλНΑνΥвτмкцθкцλυ():
    value = 277540
    text = __import__('base64').b64decode('dWpRNUh6VmlxX3YzOHB1akkwVl8=').decode('utf-8')
    total = value + len(text)
    if 94 * 1 < 0:
        _dead_7933 = 854
        934
        621
    return total

def _νШΥчуЪЭζЬλνш():
    value = 273653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EC7JREIq6J1WDxqUxHuRJQYXsGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑαъΜοΦЗΕΘдΦ():
    value = 817340
    text = __import__('base64').b64decode('cW1Qb05QTmlpX0ZnSDNWOXFGaGo=').decode('utf-8')
    if False and True:
        _dead_4226 = 836
        141
    total = value + len(text)
    return total

def _ХЦэμΗνЛЩΩψ():
    value = 549441
    text = __import__('base64').b64decode('WkdtRnBXUExoYVJMd1VOcTA5d1M=').decode('utf-8')
    if False and True:
        _dead_9361 = 493
        794
        418
    total = value + len(text)
    return total

def _ΣэЭςШтйЯХΗЕеИмРχ():
    value = 309521
    text = __import__('base64').b64decode('aU1LUXJEVkx4TnNjSFBxWlZsQmo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8703 = 325
    return total

def _хиЖΨЗЕωиοЕΥмЕЭяХ():
    value = 735589
    text = __import__('base64').b64decode('dDVvdEFmZmNqQXBLd29xZHZVNTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬГЗбтΘΒБЭабΞ():
    value = 238393
    if len('') > 0:
        635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRnJUXNozYI7ECyi2F+4Ng8d01s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рМшиεΒωΡЧЪκΦΜСнΑ():
    value = 500463
    if False and True:
        pass
        374
        _dead_3634 = 768
    text = __import__('base64').b64decode('dW42TmJPbE5nbWcxZzNzQll3STY=').decode('utf-8')
    total = value + len(text)
    return total

def _эйчвθгАΟЦρюθЧКεВ():
    if 49 * 3 < 0:
        _dead_8695 = 329
        _dead_4134 = 363
    value = 169185
    if len('') > 0:
        _dead_2575 = 743
        915
        _dead_8375 = 436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IH+0OmUpqqoAK1eU0EayMS8s5mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7802 = 47
        _dead_2583 = 717
    total = value + len(text)
    if len('') > 0:
        282
    return total

def _ΛДιсАрΧп():
    value = 213841
    text = __import__('base64').b64decode('QVY3M09yQ2prY29wTGFWNThwQm8=').decode('utf-8')
    total = value + len(text)
    return total

def _бρиξΜΩйγВΝ():
    value = 73128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSr2QQcK8II5Fl264HXAJSojwX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        341
        _dead_6399 = 889
    total = value + len(text)
    return total

def _рψЙΜУΝνΘнОξжп():
    value = 975503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESHIOlw1qvgKBSizmn+nMAoEvGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цфЛΞΓьеЩχГБуΙρΝ():
    value = 248033
    if 90 * 37 < 0:
        pass
        _dead_3007 = 45
        2
    text = __import__('base64').b64decode('a2hfak1USGlWeEVGWVNUSzQ1Q1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΣΔЮΔΓцΦЯФΤЯжΡыЬ():
    value = 238786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDj9S3gR1qEzCyD32XTEHhU872M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4482 = 139
        pass
    return total

def _ΘУΣυъЫΨщεθ():
    if 27 * 12 < 0:
        _dead_6831 = 778
    value = 562002
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAf8YEc+6aMyFTyi92+1GCwX0EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΘβНΝФжθЦ():
    value = 406604
    text = __import__('base64').b64decode('VExNaFluYmlWZzNOZ0VxMmN6OWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩЬθΝвχθΠР():
    value = 371125
    text = __import__('base64').b64decode('WWtRT2hKRGw4SHlCWnRmODdvcTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣИωиτςΙМиРΑο():
    value = 195976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E369YGYBx6QvKlin0HqZJix54W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зЗΦжΨζηЬτПφйа():
    value = 251572
    text = __import__('base64').b64decode('TE9kdGFCQ0xHek8wd3lSRXZMTTc=').decode('utf-8')
    if len('') > 0:
        338
    total = value + len(text)
    if 32 * 63 < 0:
        430
    return total

def _КэИΟгΜлΙ():
    value = 284981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyPgX2U39oE2CQz7/QOlOnEq4nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΚπНΡыδЩкЕщТХЬьЩ():
    value = 548416
    if 41 * 10 < 0:
        _dead_3722 = 96
        920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyPLaUcLwfgGDhqC8n22PwwO7Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΚΙАЕΦдΑСц():
    value = 50234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwznQVMW2aY2Pl+gmm+1Ez048j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        511
        106
    total = value + len(text)
    if len('') > 0:
        _dead_3611 = 989
    return total

def _ΜΧФиζμЗΣ():
    value = 34485
    text = __import__('base64').b64decode('R0V3WWMxV0MzQVdYUUluUnRHUDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ыσποДквθτфΗФнβХ():
    if 87 * 81 < 0:
        _dead_1311 = 992
    value = 662185
    if 89 * 92 < 0:
        _dead_5978 = 755
    text = __import__('base64').b64decode('VUg0dWVlSzRNTlZ6SHpfa01kM3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ФДξυлЕΙйХйШЦбдКΧ():
    value = 73602
    text = __import__('base64').b64decode('WnFlTDBBOHhjcnNsOXRlckVSMGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΖΠαчΑΦΝлтШβдяы():
    value = 883705
    text = __import__('base64').b64decode('UjhhenJqcXlNS05uOEN1VThucUc=').decode('utf-8')
    total = value + len(text)
    return total

def _црБЩШοЮрΖбυСθсπξ():
    value = 33262
    text = __import__('base64').b64decode('cjRKdHU5WWZQWlRVRTFwQjlqTm0=').decode('utf-8')
    total = value + len(text)
    return total

def _λмΞэууΕнЮ():
    if 65 * 68 < 0:
        pass
        _dead_6011 = 668
    value = 41413
    text = __import__('base64').b64decode('STNra2xTdlZ2TzNvQWJienlrazQ=').decode('utf-8')
    if len('') > 0:
        749
    total = value + len(text)
    return total

def _нγэЖврακΠ():
    value = 77811
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET7jeHYt2/xTbxmW20KDNgEd81k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗοθЕшЩАΔБ():
    if False and True:
        542
        _dead_9910 = 220
    value = 725273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRbAan4cqaVQF1y3wFW/NxAHx2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9660 = 999
    return total

def _ЬβьВЭоШьΡ():
    value = 428030
    text = __import__('base64').b64decode('eGR5czVCaUhHZ0Vod0p3V0V6Qmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ζтьЗψΙβшδаΘвΛ():
    value = 431400
    if len('') > 0:
        585
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT68QVQ2xKYTbSCC2AOqBzUiy0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6648 = 434
    total = value + len(text)
    return total

def _чΡΙπкааξцаΥНцΔС():
    if len('') > 0:
        _dead_8576 = 399
        218
    value = 567077
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX+0O3YO8/40PC2X33GnEHMEs38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΚυлελЧИ():
    if 43 * 10 < 0:
        pass
    value = 687321
    if 53 * 73 < 0:
        _dead_1383 = 461
    text = __import__('base64').b64decode('bWkzd19DaU84Vk1FbEtVcVZRMWM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1973 = 198
    return total

def _κкΣкоσГεωБ():
    value = 23241
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3zDelsc6o4GLSyKm37BOCsY6kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7951 = 307
    total = value + len(text)
    if len('') > 0:
        _dead_5679 = 892
        _dead_5451 = 512
        _dead_7037 = 650
    return total

def _ΔыΑΣъГЪеγшχэ():
    value = 513232
    text = __import__('base64').b64decode('cVBsU1psQWRyVzMycVpRbmE3a0k=').decode('utf-8')
    total = value + len(text)
    return total

def _дηъаТыЕΡΟУΥ():
    value = 158523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnvNRnBu7Z4TCTyG+g6pFjwh90U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еьЕеШеХдХЯΘλЦчφТ():
    value = 668745
    text = __import__('base64').b64decode('dUhIZTNoT1BNeTBNUHRsRURUUjU=').decode('utf-8')
    total = value + len(text)
    return total

def _νΥъκΕърЪ():
    value = 931639
    if 48 * 14 < 0:
        582
        pass
    text = __import__('base64').b64decode('T0s3NFoyUjluQmZkRGdLdElUVjc=').decode('utf-8')
    total = value + len(text)
    return total

def _йχΝαнφЯΝυЖЩ():
    value = 19898
    if False and True:
        843
        _dead_4811 = 802
        _dead_2060 = 808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRfgS3Y96Y4MPz+pkXWjHR0a8Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 39 < 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_6620 = 96
    return total

def _рωцβζβэРиЯν():
    value = 225557
    text = __import__('base64').b64decode('c1BDUEVmZmMxbHBaMWRsM3RzcjU=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΚНюΦΖΨΩцΔξМ():
    value = 653584
    if 76 * 29 < 0:
        764
        pass
    text = __import__('base64').b64decode('cUZYbzdwVHhzczJUYUxlNGdMZzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞоΟЪЦцΙш():
    value = 33848
    if False and True:
        538
    text = __import__('base64').b64decode('d1g5R25KWjRPZkpxVThPZnZ3V1M=').decode('utf-8')
    if len('') > 0:
        _dead_4675 = 159
        50
    total = value + len(text)
    if False and True:
        38
        pass
        _dead_8198 = 791
    return total

def _лХхΘЛЗγБωб():
    value = 454753
    text = __import__('base64').b64decode('dGE3QUFkVVZpS3Bpa2tBQUdraFc=').decode('utf-8')
    total = value + len(text)
    return total

def _тжфэсэНшοΦБλ():
    value = 30403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHfRV14V5p4tFgiGyn6hFnYf4Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮπΥαюΓςΥΗПхМΠΔΦв():
    value = 221817
    if 32 * 53 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXq0XX0t5KMFAla3wEe4PjIqwnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚπПтΥАΛжРжΥ():
    value = 491608
    if 100 * 32 < 0:
        580
        379
        666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhfxREUR7/0RNhzy7WOoBSII9n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        491
    total = value + len(text)
    if len('') > 0:
        _dead_3966 = 388
    return total

def _фЫПЧπΤУξЯч():
    value = 409220
    text = __import__('base64').b64decode('SU9OV0ZPZFloTGJMSkhhWHNtSXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if 92 * 32 < 0:
        _dead_1019 = 47
        pass
        pass
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()