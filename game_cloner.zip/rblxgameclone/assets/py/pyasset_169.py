#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΤсΙсбтЫΧгΤΒ():
    value = 527690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHnWaFoU9KsPalnz5nG4BBEK8GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яσдЬσКЯыΤ():
    value = 877593
    if 51 * 88 < 0:
        9
        883
    text = __import__('base64').b64decode('eGpKUUp5bG9yQ2pCUHF4dHlGR3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒκаΧΤΨэω():
    if len('') > 0:
        94
    value = 971071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATy0PWg8/YRbGDiR6wamPDQVwHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 74 < 0:
        _dead_6263 = 584
        _dead_6449 = 760
        _dead_4156 = 336
    total = value + len(text)
    if 10 * 77 < 0:
        pass
        272
    return total

def _еЛЩΩсшюВэНωΕГГΨΣ():
    value = 681345
    text = __import__('base64').b64decode('VVN5Rkw3TWVJT0kxU2RJTXhZMnk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЫйΞΞЧиΥШМЧЪ():
    if 29 * 87 < 0:
        pass
        pass
    value = 282011
    text = __import__('base64').b64decode('c0NDUlhIT1RJM0FHeEZnQmFZZlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ъилςаЮχЖρρςΒΗфДг():
    value = 50184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDuyQlI77qQIYjeRmHqSYigD/l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1961 = 745
        640
    return total

def _ыγпτΩСяфυЯшΓ():
    value = 189486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCLue0Jt1J42ESey0EzIPDF3008='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШпЕΘяфВΤаНζ():
    value = 764413
    if 51 * 48 < 0:
        pass
        pass
    text = __import__('base64').b64decode('SXNTRGtneUJQV2NzenY4ZDg0NDE=').decode('utf-8')
    if len('') > 0:
        _dead_8033 = 981
        pass
    total = value + len(text)
    return total

def _ψаφЙεРΝзηнСМЬт():
    value = 256541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgPpYgUe75hUbgyo7wKvLXAswX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΤςΤЗΣКΣ():
    value = 299534
    text = __import__('base64').b64decode('alF6bFJURnYzdUZTRkZZNmVSWnE=').decode('utf-8')
    total = value + len(text)
    return total

def _βХюπцΔнн():
    value = 918388
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NADpYmgL2K0XIzb6/HeENigEvVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΑЪιοφЕБθлф():
    value = 633735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FD/1YXM/qrkQLxev50OSZnAEy2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΗпПкоаτ():
    value = 345822
    text = __import__('base64').b64decode('WGFRMFJSbzVkVnpVclhQQXREYVg=').decode('utf-8')
    total = value + len(text)
    return total

def _оθγсРΔψиΨ():
    value = 172480
    text = __import__('base64').b64decode('Sk1Hb0pPNjVtZndtUVVmb0ZYSHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ьηоδБУΠКф():
    value = 946490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jgr9XWs20f4saVj72Hi0InA2xUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эхОΙσТжΡη():
    value = 487072
    text = __import__('base64').b64decode('VmE2SkUxemh3cE1aclFvQzRZNWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΨГΝΑБшΞМЧΣ():
    value = 726280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3zXbFwY1aQBMg6PxQHHOhoCyGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΙКсЯЗюΠюс():
    value = 166041
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhXyPEsc+Y4mEw71xADHJnF/smQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩйροЙΠЬεаΠихφγРη():
    value = 824350
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDnjam5u6Y81Ejio6V+XPCN4yjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭхΑЭгνАЛЪΛθ():
    value = 516205
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRbNZEIs8J8LEgaz0GC7OgA49GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φиТββχжСμТТΕяг():
    value = 214748
    text = __import__('base64').b64decode('SURaSGJVVEJpVlN2Y21QVDBqZzc=').decode('utf-8')
    if 16 * 98 < 0:
        354
    total = value + len(text)
    return total

def _ΟкΞШлфΟРАΛ():
    value = 696996
    text = __import__('base64').b64decode('cWJRRmRZSjZTWGxjR1Z2Sk9rbzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΦпςаяЖζψΝПςрΧκ():
    value = 876308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCLrb1U7ppcUMAqnwnm6CzU+7EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if 76 * 30 < 0:
        pass
        586
    return total

def _ЛΣььΔХЦз():
    value = 558217
    text = __import__('base64').b64decode('VWF5cVh0U1dtWl9TQlBHV1ozN0s=').decode('utf-8')
    total = value + len(text)
    return total

def _οчЧЗψоΧδТАдλйφβ():
    value = 740740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh7OPV4OyY8RPF32mWOpHHQQtHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξдАζΛШлЯ():
    value = 224604
    text = __import__('base64').b64decode('Smk0SmJ3VEVRcTlFcU5PM216SnQ=').decode('utf-8')
    if 92 * 37 < 0:
        684
    total = value + len(text)
    if 21 * 56 < 0:
        _dead_7491 = 79
        673
        _dead_1123 = 248
    return total

def _ρηιСНыЧбζЙАΥД():
    value = 26082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD/rPXlopp0zFAmt4XPGF30Y/j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥκщтθОФЖνЙφχ():
    value = 963905
    text = __import__('base64').b64decode('S2l6MHBjaVAzVlI5Rmo5VnlVNHI=').decode('utf-8')
    total = value + len(text)
    return total

def _γφЭФΦюхΝ():
    value = 540567
    if 45 * 16 < 0:
        480
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAvQfwYWpqohFBby8GOnIwJ273g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2402 = 567
    total = value + len(text)
    return total

def _тдΛъΡвΔΜΗογυИАθφ():
    value = 382262
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgTCWXgjqfFQNgSGzVvJZTV4tF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        65
    total = value + len(text)
    return total

def _фаξгδΥΒуΙΕΙΓ():
    value = 427348
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR7JfUA4+5JQFzeqz126OicNyT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΨАΙжοΖαСдσ():
    value = 206933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh71Q0A/rbk2NSuAwnKyDHM4tEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞАгсΘΒΦпоИΥЯтнД():
    if len('') > 0:
        pass
    value = 90631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDjWYlQU6r07bxqQxU6+Mi55y1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖρΝгζεШΩЖкρыХоΒ():
    value = 509387
    if False and True:
        _dead_7941 = 134
        940
    text = __import__('base64').b64decode('TFdSa1NsbDlZSV9ISG05MVM0REQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _оШΔбζξΩХИΕяЪΣ():
    value = 582410
    text = __import__('base64').b64decode('cVNuTE52aHg3ZEU3SWpDOVhTcWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓфΔζθтιПΠуПΚγ():
    value = 793269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS7bS0E61qwsKT2V/VGbBQoq8mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЦβаιψШΓΔξГωР():
    value = 458066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IH2wYUYY0vosNyuc5lqxA3wa808='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        415
        _dead_6877 = 52
    total = value + len(text)
    return total

def _хγοераэιΟг():
    if len('') > 0:
        942
        pass
        173
    value = 744441
    text = __import__('base64').b64decode('Um1ieHJIemlha1B0RXNVZ0JiVno=').decode('utf-8')
    total = value + len(text)
    return total

def _ξвΨυТνяσхВгъп():
    value = 341061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwvDUXoO544HBVnw6mGiJwwZ8Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗЬьиЧΖиΦΒЙДщЙ():
    value = 415627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiTmZWQU3YIAP1qR3VKqLBQ5zWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φςтфхιвΔж():
    if False and True:
        568
        _dead_3178 = 887
        314
    value = 127201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhfib0Zp6oxWFzuOnUeWFTEn4mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 83 < 0:
        pass
    total = value + len(text)
    return total

def _ςΠгΦγнΒшΚбЙТ():
    if False and True:
        213
        _dead_9340 = 474
    value = 327919
    text = __import__('base64').b64decode('ZUZXd2pBTl9kcFVlWmkwOVVsMXc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        849
        _dead_6738 = 807
        _dead_6395 = 800
    return total

def _ΧφυσЮУΤΨч():
    if False and True:
        546
        116
        _dead_7498 = 475
    value = 885412
    if False and True:
        pass
        476
        _dead_5649 = 910
    text = __import__('base64').b64decode('dGlkekZXZlVMcUEyQWdBTGZuSEs=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9861 = 188
    return total

def _ΤλδатτΚκΥЛΔ():
    if False and True:
        _dead_5381 = 805
    value = 443849
    text = __import__('base64').b64decode('RmIxSEp0eFRudGFBSmRPQnowSUw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7109 = 638
    return total

def _ΤяζДΑΚнΜΙΝкδΖйΝο():
    if 9 * 84 < 0:
        703
    value = 226699
    if False and True:
        pass
        118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCj9e384pptTKyv33gaiABod/jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5926 = 96
        pass
    total = value + len(text)
    return total

def _цЬйΞрЕοыФ():
    value = 85044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dzveb2cs6YpTIF+MmXq6ISAGyjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 72 * 11 < 0:
        pass
        _dead_4949 = 267
        267
    total = value + len(text)
    return total

def _пαъХжйνσ():
    if len('') > 0:
        _dead_3647 = 286
    value = 160305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx/hSHwa5rIBDges31WGAy4JsHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΟЬχοЩЫЕθШ():
    value = 22460
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh7BRVlr2PsmFyH2mkCabScN500='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψИкПЦВΒψγЗБ():
    value = 715719
    text = __import__('base64').b64decode('UzVNRjN1a1RPeWJKQlpuZk9iVWU=').decode('utf-8')
    if False and True:
        996
    total = value + len(text)
    return total

def _ЭПΑΜЙцΓΦжξΔжΚВπч():
    value = 240140
    text = __import__('base64').b64decode('WF90Q3pzd2dfaWg0ekdpM1hVVTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ηоΕΚΗΔπпμскьч():
    if len('') > 0:
        990
        pass
        _dead_6733 = 167
    value = 959188
    if 52 * 97 < 0:
        312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITr3b0MR8KwMABarn0a4Zj0B4F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΩпдτчψυО():
    value = 922601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESbSbFsbxoQJNViAykK6NSQf4EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5740 = 317
    return total

def _ЫΔЧыЭδτςщчЭущВΡ():
    if 85 * 58 < 0:
        pass
        pass
    value = 49873
    text = __import__('base64').b64decode('QlpsYVhFMHpDQWZ4aTlPZVVUOXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚаΖΖмюΣо():
    value = 363358
    text = __import__('base64').b64decode('Rk01NHRFdmpjQVRBT05QQVRzWEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮюΛфγΘФюЗχ():
    value = 130410
    if len('') > 0:
        _dead_3711 = 386
        109
        643
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBzHZFNo6o8FICnymQG9MDYD4H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аφУВΔДУЦΕт():
    value = 337388
    if False and True:
        _dead_3187 = 573
        _dead_4148 = 93
        _dead_1915 = 44
    text = __import__('base64').b64decode('SDFOZjdDNTR5S2pybUhKUGlMZUk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _вρΡИΗβσГΧΔ():
    if 76 * 45 < 0:
        806
        _dead_4490 = 490
        pass
    value = 290384
    if False and True:
        390
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgrmXXQrzYUpPAOA2Xm7YwYZ3U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 3 * 79 < 0:
        96
        _dead_2678 = 908
        pass
    return total

def _юЕЪиЮЫдСЗщЧг():
    value = 729861
    if 89 * 67 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXvSbH4c1JEIbF6mzAeDLAgWwlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эλΙцгэбηγЫтЗь():
    value = 904605
    text = __import__('base64').b64decode('bGt5aFF3N1p1N0M0ck9JNTNMRHo=').decode('utf-8')
    total = value + len(text)
    return total

def _υТλΝΘАΞξЯЮσ():
    value = 778192
    if len('') > 0:
        _dead_9772 = 385
        _dead_1992 = 502
    text = __import__('base64').b64decode('ZE5ENXQwZDNnOFJ5QWdKT1V0VFY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6140 = 903
    return total

def _оГДНΒΗΓνЯα():
    value = 351606
    text = __import__('base64').b64decode('RVh3ZnBWZUQyZWpvcWVQZTYxUTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯКΞТμПЮЮΩε():
    if False and True:
        813
        260
    value = 199897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSPtaloGy5oCDwCwmwG9HQc8vD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 63 * 7 < 0:
        _dead_5301 = 290
        pass
        _dead_1892 = 802
    total = value + len(text)
    return total

def _ψΠКΓйΨпΝяυКаФ():
    value = 81775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAizQHstypolFQenwlSRPhYG9Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΦΓЗоАνсδΞтчРХ():
    value = 995701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByfebwQT8ZtTNyStwgOaDHwh4n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 67 < 0:
        pass
        pass
        32
    total = value + len(text)
    if len('') > 0:
        137
        106
    return total

def _ΩσγθψΖщΞНюйС():
    value = 907313
    if 18 * 96 < 0:
        pass
    text = __import__('base64').b64decode('V1VlX0pTcE5NeFVuR21pZzdfYVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΚщЖгθаωбΥ():
    value = 882598
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwzFOAUO+KIhHDq56k6oIRA1x0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡАσрОЪЭΞлρυЫΗа():
    value = 552884
    if 44 * 97 < 0:
        114
        _dead_1477 = 611
        _dead_1224 = 114
    text = __import__('base64').b64decode('WEltaFlWTXpLaVVtajJMSmFsRUo=').decode('utf-8')
    if False and True:
        pass
        362
    total = value + len(text)
    return total

def _ЗνΣПΑΣΠεκЛЩоНьй():
    value = 960796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiLTdwUzrfsyHVyMm2G/AT0Ky2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΠЮзнАХτГщВАЭι():
    value = 29139
    if 21 * 75 < 0:
        45
        140
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3zUbWkD66laMl315FqTYxwV02o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        14
        pass
        _dead_7309 = 722
    return total

def _ξΧъиыΞΨмЭФЫ():
    value = 887719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXzSSwQj+fg8YwSCzmWoDAk7tkk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εГηΥχИчμКνШьΡпг():
    if False and True:
        pass
        _dead_6773 = 432
        309
    value = 590777
    if False and True:
        _dead_1497 = 590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDX+QEUXypIVAgT2326KAjB86mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒьπδуТσκарД():
    value = 90923
    text = __import__('base64').b64decode('eTFqWlJJVkNsbHJ0QjhKWmRWTHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΡΨεщгЙпуУΕ():
    value = 477193
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz7mYgc266coDiSiy0CSLCMCsnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        853
        pass
        _dead_9146 = 968
    total = value + len(text)
    if len('') > 0:
        _dead_1892 = 833
    return total

def _НσβιτъСΠΞγт():
    value = 976647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P37cYl8GyvxXGRqOyXyGLBF57Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        21
        _dead_3008 = 92
        _dead_1559 = 739
    return total

def _рΛЭφφВбЭИΥΒ():
    value = 207797
    text = __import__('base64').b64decode('V3pGMk5nVTZPcGJLTTNsVDQ3aWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕИдчлγΘпа():
    value = 538443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR/TTXwO6JIODgaa4nW6PXU7tmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕчθМСЯгξЖΒЬМχо():
    value = 339936
    text = __import__('base64').b64decode('YUdXR05PYTg4VXRKMWpNTUxjVkY=').decode('utf-8')
    if len('') > 0:
        _dead_7625 = 966
        _dead_3308 = 259
    total = value + len(text)
    return total

def _ΑΡшЫщГΠζΩЗΧ():
    if len('') > 0:
        pass
    value = 583630
    if 99 * 4 < 0:
        pass
        219
        pass
    text = __import__('base64').b64decode('RGlYc3ZCRmEzdHN5ZldoM2puN1M=').decode('utf-8')
    if len('') > 0:
        195
        726
    total = value + len(text)
    return total

def _οΩГШθшЦиЦΙЮФγΡ():
    value = 995568
    text = __import__('base64').b64decode('QTRSNTIwTDA2YU5USzJUcGVCWHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΡуψхЛΧрΔΧσαфзΦΦ():
    value = 652365
    if False and True:
        863
        607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSXIRGMYzKsZOw2t7mKebRQJ0mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΗκэχЦфΣΕΛβυцθΘэ():
    value = 432664
    text = __import__('base64').b64decode('RlBVN0NOVEl4NzVYRktGMUxNems=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_2806 = 223
        923
    return total

def _φΩЫΦОыооοβнφШηо():
    value = 370869
    text = __import__('base64').b64decode('Y0ZNd0pRdWdJTVphNWRVYm51Yms=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1973 = 592
        pass
    return total

def _πλыФΩпбφзЯ():
    value = 652846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD/3f1tv6Pg8Eyqqn13JGwM3/U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _итΘМКЙЫΕПЪМμъюω():
    value = 164920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXnVakIq7bs0blut7niGIw0c1mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зОЯДьΦεΒΖτη():
    value = 923155
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ki3VXwYs26YFCQyxylCWFS88x1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΕΖЪΔЦТхюΓУ():
    value = 433316
    text = __import__('base64').b64decode('VDFTMWF1X3ZtUV9XSTZrRlFPRm4=').decode('utf-8')
    total = value + len(text)
    return total

def _θБлΘωаЪвβЛμЙЪШПΚ():
    value = 785805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwzBZHsX/PgNCyKkwlqJNS4nylo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΒЖЧελбЩ():
    value = 601466
    if False and True:
        212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSnqP3oy+owPKyzxxH7JZRE26mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        327
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_3687 = 125
    return total

def _ΟΜеΥОЮщыΤуи():
    value = 295685
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD69fF8Y+5oQHz6H+Ea2DQwFymo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 23 * 64 < 0:
        pass
    total = value + len(text)
    return total

def _ΤМκΝиΛФфхςυбы():
    value = 583036
    text = __import__('base64').b64decode('UWt5V0VraDUwX0M4NEZHTWE4QTA=').decode('utf-8')
    total = value + len(text)
    return total

def _γЛмςоθзΚΓμЫзНЮ():
    value = 771357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwXwdlAx7vAZEgGh6062PQEXzkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΞχψщςувПЕμЬ():
    if len('') > 0:
        pass
        828
    value = 137653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhDVUV037rwXECyi8F2DYAQA/Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λсΩТνРУΠυЭγ():
    value = 413706
    text = __import__('base64').b64decode('eW9NRWM4RUtfMXZGdno0eF9md28=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦλЙεεыθьιг():
    value = 145740
    if len('') > 0:
        _dead_9298 = 903
        26
        pass
    text = __import__('base64').b64decode('VmJpc05haWRqUjBqV3VyeGVaQjI=').decode('utf-8')
    if 77 * 4 < 0:
        620
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЯКфθΥхΔыя():
    value = 169535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARfVPkFp0qENLhqZ4n+6MjQDsl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠщΙюяйГФψчш():
    value = 51899
    if False and True:
        pass
        _dead_4621 = 453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHf2OAVt5qQCNwWrxACcPQB8xzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑгЖДтφКΩиБЧШш():
    value = 434914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NznXe1Yy5qZUESGS+H+mPiAbxT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦБΑχсшζΠζΥгπ():
    value = 299511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhDDVmsKp7wiMiDz0XivBSd37j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _επψЕεΗХпъΩΗСиφ():
    if len('') > 0:
        834
        pass
        _dead_5673 = 342
    value = 821175
    text = __import__('base64').b64decode('a19xZEc0OG9YaTgyZHNiYXlVUGw=').decode('utf-8')
    if 49 * 52 < 0:
        pass
        _dead_7540 = 901
        _dead_1686 = 372
    total = value + len(text)
    return total

def _жбкμшудаη():
    value = 687114
    text = __import__('base64').b64decode('T1dUbnhzbzA0d0xFTlNnUG9RaXo=').decode('utf-8')
    if len('') > 0:
        354
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΞАΙБΜсрΙμ():
    value = 812624
    if False and True:
        _dead_9747 = 36
        pass
        _dead_1712 = 737
    text = __import__('base64').b64decode('cGxLOTdhTm1lT0FWRWd0Q0RYaTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ДЗτΕМнлДЖ():
    value = 163595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT/hO0sS8btWNVz24GO5P3N+vVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣэΩшЮΧюьчрΟЛΔ():
    value = 124898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTXDPwBoxJgKCFu2mH2XEyR3/F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПζмΦЖуыГЭрπστΗ():
    if False and True:
        _dead_9600 = 930
        _dead_2291 = 309
        724
    value = 589244
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DA7BNwEgrfBQFzas6mWqB3wA4jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _уЖюкτγΧχκгщН():
    value = 294387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCvrXUZp3blQKhqq/XTGZj86zFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мЭΧΓψиΓφπлтгχъ():
    value = 925193
    text = __import__('base64').b64decode('REIyNlAwM3FfeWNnbXRMVFNfSlk=').decode('utf-8')
    if False and True:
        860
        _dead_1957 = 534
        520
    total = value + len(text)
    if False and True:
        pass
        _dead_3907 = 816
        744
    return total

def _лΧεΖшξΥδΗδξ():
    value = 719114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IijST3Af6/0sLzqh3HGVF3Ug/mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        705
        pass
    total = value + len(text)
    return total

def _ыΒλΜΛцРЛпНιЗЕЭВщ():
    if False and True:
        _dead_4193 = 811
        pass
        pass
    value = 590802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDXtdFYL9JouDC662E+4GXZ6xVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФЩмжοиψгв():
    if len('') > 0:
        _dead_3189 = 210
        _dead_1295 = 637
    value = 863262
    if 44 * 60 < 0:
        _dead_1301 = 624
        pass
        125
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRzzOgQV74siCSKizGWaMRoK808='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _оθΕΝωДЛεЩрΚхшИξЯ():
    value = 202308
    text = __import__('base64').b64decode('dEgyYVA3Sm1rQ2s3UDl4clFETGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞОρδΓхсμФψ():
    value = 588071
    text = __import__('base64').b64decode('Y1ZXQVRtUzFmS1RPeE1KU21IU1o=').decode('utf-8')
    total = value + len(text)
    return total

def _βμхщНпОφЖπырю():
    value = 903554
    if False and True:
        pass
        _dead_8695 = 763
    text = __import__('base64').b64decode('VldJbzJUUTgycEcxRXJ6SXg0c1U=').decode('utf-8')
    if False and True:
        _dead_7271 = 333
    total = value + len(text)
    if len('') > 0:
        _dead_6144 = 929
        _dead_9657 = 782
        pass
    return total

def _чΚμрυΘщρьκЫовτ():
    if False and True:
        _dead_6483 = 977
        pass
    value = 222975
    text = __import__('base64').b64decode('UERzWFR2M2pWcHlocjFDZlN2VnY=').decode('utf-8')
    total = value + len(text)
    if 11 * 66 < 0:
        _dead_6193 = 493
    return total

def _ΡйХΜИεΔьпС():
    value = 720948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBz9a1w+qKwqPwylylOxPnAX/FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒааΑХРьπЮптκР():
    if len('') > 0:
        pass
    value = 371689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kn6yOV8e1IwONSeF5makYy83s0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΜΝкΩнАο():
    value = 939995
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hzz2awce1bIbEiivywK2JjIntkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        213
        394
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΨζβыΚРЕЫ():
    if False and True:
        pass
    value = 485995
    text = __import__('base64').b64decode('UTJyQ2RkRGNCUUhqZHdIeHFaSWY=').decode('utf-8')
    if len('') > 0:
        _dead_4012 = 406
    total = value + len(text)
    if 46 * 50 < 0:
        pass
        _dead_9408 = 765
        154
    return total

def _цЬΧΘфΤЛβ():
    if len('') > 0:
        pass
    value = 318567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxjSVGZu1KcUPjWR2HqmJzIH9WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 46 * 22 < 0:
        949
        107
        pass
    total = value + len(text)
    return total

def _ЙζЪΔяСЧФσнο():
    if len('') > 0:
        pass
    value = 740886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXzKOgU6powKaD+gw0K1Yh0fz1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9393 = 962
        _dead_7978 = 706
        _dead_7610 = 728
    total = value + len(text)
    return total

def _αцΦπνНЬниУммвΙλη():
    if False and True:
        pass
    value = 926403
    text = __import__('base64').b64decode('Z1JnWDFjSzhBa3ZTMzd0RmMwNXI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        55
        _dead_2766 = 41
    return total

def _ΨηγтΚкυΠΚГж():
    value = 607354
    text = __import__('base64').b64decode('bFNPZTE1YlY1QWJsVGpzWFd4UUs=').decode('utf-8')
    total = value + len(text)
    return total

def _юΜиЫΩлЯΥц():
    if 79 * 25 < 0:
        pass
        39
        _dead_8058 = 526
    value = 440285
    text = __import__('base64').b64decode('REltVHlWVEVldVlIdzdkWXA2THI=').decode('utf-8')
    if 80 * 55 < 0:
        _dead_6880 = 755
        pass
        _dead_7331 = 480
    total = value + len(text)
    return total

def _ыЧψζσΤλЧДςβГФιЙ():
    value = 89082
    text = __import__('base64').b64decode('ZUIwMjhIT0FEREdmbUFCd1d3WVE=').decode('utf-8')
    if 57 * 87 < 0:
        pass
    total = value + len(text)
    return total

def _уΤρΗИСьаςΔгП():
    value = 902870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH/rP34b0r8yDDuq5lOjGhEW5Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НδКАщΕЗЯδΞъжЙд():
    if len('') > 0:
        _dead_3853 = 547
    value = 834352
    text = __import__('base64').b64decode('VnNYSlVGbExZV3B2SG9SYTNEeW4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2706 = 619
        706
        _dead_7378 = 846
    return total

def _υЗΞπъБжΚΕчыΩΡΑ():
    value = 896473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSS3RncIyr0UBRmWyX28bSoI1VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОΞдЛΒяИкΕ():
    value = 870226
    if 53 * 95 < 0:
        788
        460
    text = __import__('base64').b64decode('VVEyZFVwd2JPQ2prSnRNOEVSZzU=').decode('utf-8')
    total = value + len(text)
    return total

def _уСγιУΧПяβЮ():
    if 52 * 23 < 0:
        pass
        _dead_7449 = 550
    value = 267586
    text = __import__('base64').b64decode('cXYyb0pYR2w1RmI0QjdTajBsb24=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗКОΙεξнвνаπε():
    if 99 * 88 < 0:
        pass
        630
        pass
    value = 229348
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwnPXFo3x4UAYxyy6le9ECQCsWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9116 = 888
        _dead_1390 = 237
    return total

def _чРУЪУΑмξΞνΝаΕ():
    value = 757540
    if False and True:
        pass
        111
        430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxrgP38c84ExIj+E5A6WAAsi00Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8464 = 439
        _dead_5567 = 459
        pass
    return total

def _ρΟεξυкΟα():
    value = 761326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAHWPFMezpkkHg2q42ecP3Ec83s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧνΘпэθЛψΒ():
    value = 288757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBnvUVMo2IYTKCC0wgOvBCMLyl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φДΨЗъруФтσс():
    value = 950327
    text = __import__('base64').b64decode('Z19ncnNkVjdxcWNKUUd6S0dVRHY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        922
        _dead_7223 = 219
        pass
    return total

def _ΕωкΛхΞΣхщΦт():
    value = 890368
    text = __import__('base64').b64decode('SlYwbWdOYlBRVEt2Qnd2amlSeTc=').decode('utf-8')
    total = value + len(text)
    return total

def _РеΝЦзΖΝχЭθ():
    if 83 * 27 < 0:
        pass
        _dead_3035 = 874
        pass
    value = 474444
    text = __import__('base64').b64decode('d0FlaVBhenBhZWIzX0ZjSGFzTGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ъТσΨΟαшлΒМТρМ():
    value = 919985
    text = __import__('base64').b64decode('aVJUeVgxUXFrazczU0hMeHdoVlo=').decode('utf-8')
    total = value + len(text)
    return total

def _гнεпФЕЬЦΚγъΧ():
    value = 722411
    if False and True:
        321
        _dead_9369 = 383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MinbPAAIzrg8NDe7zVyHHAwowT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        47
        pass
    return total

def _ЬЯπнιЛФχΥ():
    if len('') > 0:
        _dead_3005 = 220
        _dead_7918 = 646
    value = 515109
    text = __import__('base64').b64decode('RndFREwyN29iQTNsU3loQmljalE=').decode('utf-8')
    total = value + len(text)
    if 63 * 36 < 0:
        pass
        _dead_1731 = 595
        842
    return total

def _ΓЖсΨΛΣηцΖк():
    if 83 * 1 < 0:
        172
    value = 712946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxDcf1477asZPCjw4VCTNQZ50Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖνΦвΘВΠΘΙЙК():
    value = 792340
    text = __import__('base64').b64decode('Rk85VmxhNWwyNUREOW83U0FqdWg=').decode('utf-8')
    if False and True:
        pass
        _dead_8043 = 659
        920
    total = value + len(text)
    return total

def _чкИΑгςрζГЪфтойл():
    if len('') > 0:
        _dead_6122 = 752
    value = 226229
    text = __import__('base64').b64decode('SlNZdFhEUGRjMjQzV3pYNHVyTnA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        326
        476
        _dead_5282 = 62
    return total

def _ХрΙЦγΑЗЯ():
    value = 516464
    if len('') > 0:
        584
    text = __import__('base64').b64decode('YnFMX3hvN2VLa2h6ZDJkQ3d0ZUs=').decode('utf-8')
    if 76 * 42 < 0:
        _dead_4220 = 355
        pass
        pass
    total = value + len(text)
    if 2 * 38 < 0:
        308
        _dead_8659 = 328
        _dead_7660 = 143
    return total

def _ξЭΚХΥурр():
    value = 462142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx/Cd1ceprAzPhmi7H2TASgN9n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кςеθкΨΔкЫφΧбЯοεЭ():
    value = 248649
    text = __import__('base64').b64decode('dlZ4SnMxXzFXcG1JNGF3aVFGeTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗψφΤсθЧЬΘ():
    if 3 * 67 < 0:
        pass
    value = 903449
    text = __import__('base64').b64decode('c1pFWHRqWUJsTFBGdV9PT2VJM3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΒРюйυешэμοи():
    value = 297608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PX7rZ0Uep6oAOSyG21SkYH0ZskY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒηцιΛμΝХ():
    value = 901666
    text = __import__('base64').b64decode('cVdzdldYTVVYT00ycnRvMHRZbnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ιгхЮЗλъЕЪПЗΔςИ():
    value = 436425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTrVQHU4r/gsYjap7mKGYBwdtDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гχЦНРβεьбΕЖΥДЗ():
    value = 12935
    if 59 * 69 < 0:
        _dead_1809 = 169
        _dead_8791 = 332
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nn/pe1o9zpobayS16XS/FTYByVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лрυбЖПΧЬшВОΠц():
    if False and True:
        pass
        238
        100
    value = 621801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQjtO0kzxJ4QNgG792SKE3Q/yW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_2856 = 300
        _dead_4557 = 817
        915
    return total

def _δкоЫΘΠБнТдηНЩы():
    value = 259370
    if 43 * 58 < 0:
        _dead_5493 = 562
        _dead_3878 = 615
        _dead_4459 = 209
    text = __import__('base64').b64decode('eHNGbElVYnlCVDNpNUtMWVlCQzk=').decode('utf-8')
    if 55 * 55 < 0:
        _dead_6930 = 371
        pass
    total = value + len(text)
    if False and True:
        775
        _dead_2651 = 193
        _dead_7311 = 513
    return total

def _еЦюыЖεХХИЧЕΗэ():
    value = 239298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxbgfWQ996ICMimO7ACeHw0Mwz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψуεДХщМЪтΙПКвуеψ():
    value = 332148
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3foVnsWrP83GAmNnniZBD8L80c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιυзаΚξδχ():
    value = 838898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3nDR24c870tMSab23mpPncXy2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 42 * 63 < 0:
        pass
        pass
    return total

def _ΥпΘЧОЛθДЪЫεн():
    value = 624057
    text = __import__('base64').b64decode('QnFZeUNLNEpEX0xFRm9DUDBzQ2o=').decode('utf-8')
    total = value + len(text)
    return total

def _пλкψΜτааЗеΨлмΒе():
    value = 258215
    if 71 * 63 < 0:
        571
        492
    text = __import__('base64').b64decode('VkZsdEtHWEJoMTRacnh3TXoySks=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        612
    return total

def _ПιγΨμΑΠτΜΦρΓΣΙ():
    value = 359191
    text = __import__('base64').b64decode('bmZhNlVKUkhnNjNKYzNaTzF1NnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _νцСзДΙγб():
    value = 948193
    text = __import__('base64').b64decode('ampXcWlmRmZIazVIM1UzWWdUMVg=').decode('utf-8')
    total = value + len(text)
    return total

def _σкщсбΖΘйσΧ():
    value = 188191
    text = __import__('base64').b64decode('R0NUcWpaUmQ1cFJvVzdxTEQ2VWc=').decode('utf-8')
    if 75 * 55 < 0:
        _dead_9201 = 622
    total = value + len(text)
    if False and True:
        _dead_1921 = 534
        _dead_1203 = 898
        414
    return total

def _γΨжшэБЧζЬαэаМ():
    if 21 * 58 < 0:
        336
        _dead_8603 = 59
    value = 216872
    if 49 * 6 < 0:
        822
        _dead_2602 = 982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQrQaFlv1qYxNB+l5mG6FgAXsGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 66 < 0:
        682
    total = value + len(text)
    return total

def _КчΤΕЫЪΦч():
    value = 295098
    if False and True:
        _dead_1210 = 575
    text = __import__('base64').b64decode('UXF3Z0kxRjhhd2NnYXN4UmZEMmU=').decode('utf-8')
    total = value + len(text)
    return total

def _хгКεеνэаЮЧΙОρунη():
    value = 840222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBXrY0QI0vwkb12K/UCbHhI1sWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РхΨΒиЯьΔхй():
    value = 675408
    if 77 * 31 < 0:
        _dead_5447 = 87
        342
    text = __import__('base64').b64decode('cEtGcE9lTHhlMXVJTEU3dmVhWlc=').decode('utf-8')
    total = value + len(text)
    return total

def _θЙΖΡΩрзБуРЭЕΗ():
    if len('') > 0:
        pass
        154
        _dead_3476 = 726
    value = 634720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSzXeXxr2IozCFug5FOCEio8yG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        586
        _dead_6067 = 818
    total = value + len(text)
    if 66 * 89 < 0:
        262
        _dead_2453 = 873
        _dead_8523 = 638
    return total

def _λЖΙтХΙэКζыγНЧ():
    value = 148916
    if len('') > 0:
        269
        pass
    text = __import__('base64').b64decode('b2VQdUlZa3V3bnVFTWZaOVJaTWQ=').decode('utf-8')
    if len('') > 0:
        _dead_3435 = 795
    total = value + len(text)
    if False and True:
        pass
        177
        pass
    return total

def _ΔЭКфСφЛТхеЗДиη():
    value = 538468
    text = __import__('base64').b64decode('U3RUbXFTajRabk50VExCYzJfMF8=').decode('utf-8')
    total = value + len(text)
    return total

def _θΚφΙзσэжχδλм():
    value = 348990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB7oXwQq1aFWHwuZ0XLJLHN+vTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_6785 = 819
    total = value + len(text)
    return total

def _ъйΘιоΡЙцθΦааь():
    value = 492635
    text = __import__('base64').b64decode('cGl5RjdXSmloYjlBc1BnVnZ6QnU=').decode('utf-8')
    total = value + len(text)
    if 73 * 33 < 0:
        258
        _dead_1815 = 854
    return total

def _ПαйΝйχςЖΣъ():
    value = 423983
    text = __import__('base64').b64decode('SkRrVllJTHJCcmZnM083ZVFIanI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_9878 = 261
        pass
    return total

def _дЦПΥΗζЕρУЪУкη():
    value = 132947
    text = __import__('base64').b64decode('UnVCRlEzRjZwMkplY3FkMFk0M0c=').decode('utf-8')
    if 12 * 71 < 0:
        pass
        _dead_2061 = 946
        644
    total = value + len(text)
    return total

def _взКДРςжЭ():
    value = 191644
    if False and True:
        _dead_3716 = 912
    text = __import__('base64').b64decode('VDZLTkEzZlJNa2hCdlpQa29ZUWc=').decode('utf-8')
    if len('') > 0:
        _dead_7756 = 478
    total = value + len(text)
    return total

def _ΑμЙΔЬСхоитΗЩСжИ():
    value = 537348
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADbJYFsM6fkEayaCxAWdJ3Aot08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фοНγψфВβςоΞαпΦΩ():
    if False and True:
        476
        pass
    value = 677722
    text = __import__('base64').b64decode('dXo5RG9NZjgzTVFfUDlwV2UwZ1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤдΝΤкπΞΡαШτηБΙΩγ():
    value = 845401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD7rVEQb2P85IxmQ33WGOCQ86WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        874
        698
        _dead_3856 = 722
    total = value + len(text)
    return total

def _ЛГеЪЬιΝТН():
    value = 94985
    text = __import__('base64').b64decode('ZWh5NW1QMGR4cUR3ZUNkNTdTRnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΥнятξΧуΙМзщ():
    value = 34730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAvbRHtqz4cxPgeixnvCMzED/l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝЗИΡШэΛζ():
    value = 655990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K33Ta1Jp5KQ6MVup8mSABz0103s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κФЫДΓηйξΩЦΛшθю():
    value = 645435
    text = __import__('base64').b64decode('bmpVZkJ1TjM4RUM5WTNKb1cxeHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _шθАГδЮСεСΥιΦзТ():
    value = 28457
    text = __import__('base64').b64decode('YVNfVHZDOEdic001ZXROVXNPMFU=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4717 = 285
        _dead_6127 = 798
    total = value + len(text)
    if False and True:
        pass
        89
        56
    return total

def _εηщЙηщИЧфΩΦν():
    value = 723433
    text = __import__('base64').b64decode('SW9OZlRVVkc2NEgzdEY2b0tGZnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫНΒξидТΚЮΠ():
    if 99 * 98 < 0:
        539
        163
    value = 8539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCj8SUgN670HNF6Nx1+KNyk2vXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 60 < 0:
        pass
        _dead_1505 = 242
        90
    total = value + len(text)
    if len('') > 0:
        340
        _dead_9371 = 325
        _dead_6888 = 597
    return total

def _ψГХтъеНγрαК():
    value = 488123
    text = __import__('base64').b64decode('V2w0bnVlMFIzNjdaTFd0bWNBZDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΟАсΘРХййπδχ():
    value = 937293
    text = __import__('base64').b64decode('VjgxTmNjck40OXd2TEVVUENHdnA=').decode('utf-8')
    if False and True:
        pass
        507
    total = value + len(text)
    return total

def _ΖΗъТМЖνь():
    value = 639086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IivyP2MBrp85OCah8HeJEQkIwUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βоσΘЗυΨЯςВРΗ():
    if len('') > 0:
        _dead_6736 = 94
        pass
    value = 843586
    if 62 * 49 < 0:
        pass
        600
    text = __import__('base64').b64decode('T056S3pJR0Y4UjBNeWZyVGxaZnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ιХсаΗкΔНАыЫоκТζ():
    value = 117285
    text = __import__('base64').b64decode('c3hVMHZyVldGeG16N0JSQkJUZ3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΜШЯξКжъΙйКвБ():
    value = 966985
    text = __import__('base64').b64decode('WXVueW5YdzJMQ1pqY2FaYmh3bEY=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ωГйЬьΤНΘэζιО():
    if 41 * 27 < 0:
        _dead_9911 = 191
        540
        _dead_3165 = 841
    value = 13882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjzTZ3cU/6oGKyr7wHihNS14sjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 49 * 60 < 0:
        pass
        _dead_4234 = 776
    total = value + len(text)
    return total

def _κδуфΦΖςηι():
    value = 693857
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3y1T15q0qkOagOS5FjDYHYk1Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        759
        865
        pass
    total = value + len(text)
    return total

def _ЕнΞБКΣрωηКчмΠЙ():
    if False and True:
        _dead_8974 = 476
        428
        pass
    value = 281394
    if 75 * 95 < 0:
        _dead_4803 = 709
        534
    text = __import__('base64').b64decode('VzM1NEdoa01UVXhnX0xndU93UjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨьВяЯβАжОΝБ():
    value = 441828
    text = __import__('base64').b64decode('ZHJLSDRjZTFrY2RySUJ4YXdtaDE=').decode('utf-8')
    total = value + len(text)
    return total

def _аЪьнюРσя():
    value = 728905
    if False and True:
        pass
        pass
        859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICvXO3UB3L5RAhma6m+eFR8Z6zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αЪξΞиЪэоКзψπ():
    if False and True:
        pass
    value = 738461
    text = __import__('base64').b64decode('SzNheUlVZURncnQ5RWtMSzgyWkk=').decode('utf-8')
    total = value + len(text)
    return total

def _бчДЖзΜηрδ():
    value = 121353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NibPP3Qw14AFNSip2VSjJHU1wng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖЪФмδΡЩΒФυΞзДξМ():
    value = 192595
    if 79 * 46 < 0:
        701
        _dead_7481 = 826
        _dead_7907 = 922
    text = __import__('base64').b64decode('VVNwUHk4MFpIeXZTV3Y5R1hqNTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _σеχкσΕηТΞКλρΞАЙ():
    value = 870757
    text = __import__('base64').b64decode('djJZd0NKZ2NYd0lvWFF6RnU0ZlM=').decode('utf-8')
    if False and True:
        _dead_6934 = 666
        pass
    total = value + len(text)
    return total

def _шψεомЭиЩ():
    if False and True:
        pass
        936
        pass
    value = 733658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3/1WlUwraQlL1eEyQ+6ESMJw0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФРΖьгΧфΔ():
    value = 768729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzmzYkMp6PA6YxuSyXCTLTQLsEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вЮбΔЦбЛφэиаЩОпЮ():
    value = 866606
    text = __import__('base64').b64decode('eEpHdkc0X3IySXJmdGV5S0dfdDU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        73
        pass
    return total

def _ςЖЙΖМуιЛΨАЛςροЧη():
    value = 581150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBmxSGAJyIY8KDWomHKZMhUivEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('cg==').decode('utf-8'))
if 33 * 46 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    pass