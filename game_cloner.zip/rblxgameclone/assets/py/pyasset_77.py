#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _κюхТжшσЭΡζю():
    value = 395913
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lhi1SXVg0a87IliX4k69AQwF6U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιλΙПζχЦθжуΖАαγΛ():
    value = 182061
    text = __import__('base64').b64decode('WU5YeVNzclVxZzA3aFpQbEZGRlE=').decode('utf-8')
    total = value + len(text)
    return total

def _шЦΕΠауΩαΞхσЮхЯэΩ():
    value = 893746
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgrqYmYA7p4uK1yR2mm9MxAVtEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φВηΗъΛуλΗЩΦμжΦО():
    value = 731686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBjBUXMu040CYxuGznCcOC4q0FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        676
        _dead_8301 = 297
    total = value + len(text)
    if False and True:
        pass
    return total

def _λΩрАщлэуп():
    value = 730019
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3/QQmUX2ocnIAP60g7AYyo8sEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αщΠьδтχщγдЦ():
    value = 162615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhjcfVsj2Kw1PCH263LCLXwd4mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уРхШΕШщоиλΒЦАΡ():
    value = 133609
    text = __import__('base64').b64decode('SEFxc1dYMHRjZkdkSURCSmxHQTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪЦЭεвΜЩΩ():
    value = 997378
    if 20 * 31 < 0:
        pass
    text = __import__('base64').b64decode('UnpsR1hZaHdNN0UxU2U3TzZjODQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡщЙьВιςЦъςΖХЛ():
    value = 420745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jgq9egI+6P4GaCaHywC2bSsM8Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςЮβГБμοОсΧωОεх():
    if len('') > 0:
        pass
        _dead_1221 = 818
    value = 146825
    text = __import__('base64').b64decode('YzIzNTdxbFU5VVhkY2toTHZZOVA=').decode('utf-8')
    total = value + len(text)
    return total

def _сСψωеИЩХЯΟЮщΩОП():
    value = 421662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bz3VXgkpq/BRCRei7ESvBiYetHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВШΒψμΝвιСΒо():
    value = 770247
    if False and True:
        pass
        945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3bqQ11h/IoWFSi6z3q7ARU49XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κюоαГЕЛΤ():
    value = 35347
    text = __import__('base64').b64decode('cFNPVDFxbmdqSlFId3pVeEdyWks=').decode('utf-8')
    total = value + len(text)
    return total

def _мδυгщΑфлйфчпЭΨЮ():
    value = 648208
    text = __import__('base64').b64decode('ZXFRNVlyMk9EMmVQejN4c2dnR0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ВПсъэВдΧЭ():
    value = 863822
    text = __import__('base64').b64decode('eWZza3cxb1VTUnprYktLVHRFUGg=').decode('utf-8')
    total = value + len(text)
    if 37 * 89 < 0:
        _dead_9090 = 608
        _dead_3603 = 397
    return total

def _ЫΜдфΖΥΘνэ():
    value = 104315
    text = __import__('base64').b64decode('cDBXQnQwMkFfcEFIVlJHbDRkTW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΕУцхςЪМΞюуКΣΜ():
    value = 760923
    if len('') > 0:
        _dead_8817 = 219
        _dead_8001 = 969
        754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fgr2W3o19P0AC1iIzHyxHXUesDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΓйюмПΦΗЕяκ():
    value = 377856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAHQUVcXpqonCyz3kHm0DisM8mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юхХЭхоНΡΗнйКФЕЯ():
    value = 275982
    if len('') > 0:
        _dead_8755 = 954
        pass
    text = __import__('base64').b64decode('V3lQZUc4aGpDTVVWajlsN2FaMGs=').decode('utf-8')
    if len('') > 0:
        _dead_6833 = 853
    total = value + len(text)
    if 69 * 88 < 0:
        347
    return total

def _ΑЬΗРЪмστЛУΣ():
    value = 159944
    text = __import__('base64').b64decode('WkJaTm5vdWhOaFRVNWtjNTRqWVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫШмдμεДХΠХАωгΧβΖ():
    if len('') > 0:
        pass
    value = 818702
    if len('') > 0:
        pass
        _dead_6080 = 344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyDNYmUj+ZEHLwiB51iKO3F/5lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЫθНνβθк():
    value = 363349
    if 3 * 74 < 0:
        _dead_3969 = 474
        724
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETWyOlko87gEbSnymQahIRM+yE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДлνХЯδЬν():
    value = 27028
    if len('') > 0:
        545
        _dead_5631 = 489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NynPPmY+8JsFIBqs50HJAAt6wT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 61 < 0:
        pass
        _dead_5520 = 177
    total = value + len(text)
    if len('') > 0:
        _dead_8212 = 79
    return total

def _ΩпЙНаВДΤβΗЗζй():
    value = 239412
    text = __import__('base64').b64decode('TjMyRnBDR2lkSlVza3A4Um1vaWU=').decode('utf-8')
    if False and True:
        _dead_2566 = 699
    total = value + len(text)
    return total

def _ψюЪЙηЗгΓЕБцααюχ():
    value = 436880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzrpTF8/1/kBBVvwzmGCYhI10D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИтΝОφмКβ():
    if False and True:
        _dead_6981 = 792
    value = 96101
    text = __import__('base64').b64decode('WHg4cE1ld19CckFqWmVLUVpPYkw=').decode('utf-8')
    if False and True:
        pass
        8
        _dead_4804 = 975
    total = value + len(text)
    return total

def _дьСЭθфцОνρПΩДлж():
    value = 79262
    if 57 * 64 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx+2WVcJ9ZBVLDWV2U/JPQMh21w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 93 < 0:
        _dead_3941 = 285
    total = value + len(text)
    if len('') > 0:
        287
        pass
    return total

def _ШсξχгθЯЮΑΠ():
    value = 380562
    text = __import__('base64').b64decode('U0Nmanh5NkdhU1JMZEFKNGN5WEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖеХКЫΓЯΖЭьΡсНζΓρ():
    if len('') > 0:
        pass
        _dead_5915 = 355
    value = 350082
    text = __import__('base64').b64decode('ZU02ZUF6WUFUSkphVlEyRkd3Q0w=').decode('utf-8')
    if 28 * 86 < 0:
        2
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_7786 = 783
    return total

def _ЛЭλЩИθУъκ():
    if len('') > 0:
        _dead_6787 = 373
    value = 348591
    text = __import__('base64').b64decode('VWZhZTVxaVg2eGZJcUEzTjdRS1A=').decode('utf-8')
    total = value + len(text)
    return total

def _бΡчΝЦжыεрοΜГц():
    value = 511208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MieyflIW2atSbRv3n3TIJj8Dy3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΧιψЫΟВψΝЕ():
    if len('') > 0:
        _dead_8319 = 525
    value = 602278
    text = __import__('base64').b64decode('aVA3a3Y1TkJaeWZfOEVZbk5zOG0=').decode('utf-8')
    total = value + len(text)
    return total

def _фшζяΠςρзНΦ():
    value = 731653
    text = __import__('base64').b64decode('RGRxc2xkVkgxQ1pIeWRKU3Q4dVA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        589
        pass
    return total

def _ΛιΡЫΤЧчуΩιЮвπΜ():
    value = 677104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTvgfAYp1JcEPiSa/1SoFhIDvGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 66 * 46 < 0:
        pass
        pass
        127
    total = value + len(text)
    return total

def _ГΣвΑКμНχэσвπКаЪь():
    if 3 * 63 < 0:
        pass
        pass
        278
    value = 283343
    text = __import__('base64').b64decode('R2xyamxFdnhkVkhqYUFlRkJpcnI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_7972 = 183
    return total

def _ЮыпЯлМИνЯАΩцΓβ():
    value = 563879
    if len('') > 0:
        pass
        _dead_1562 = 845
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiLqPFts8rFVECH6nlSgOQEG7Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УωбсΣγΥптСρ():
    if len('') > 0:
        137
        _dead_1566 = 991
    value = 943876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCPuPWAL0oUgag6mmlqcMxois30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΩюъσгЫНЩξлξΓзЯψ():
    value = 881259
    if False and True:
        _dead_3839 = 169
    text = __import__('base64').b64decode('WGdNbHdEN1luNzRRWTNuSVNWOVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ДюιΨеΟЭЭχ():
    value = 894337
    text = __import__('base64').b64decode('em9idDdYUlV1aTRBYkNZd0dVZ2U=').decode('utf-8')
    total = value + len(text)
    return total

def _σлςζГςшш():
    value = 234530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiXNQglt74cnC1ug/G+fZHM1ykM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΤΨящЕЮΥνЫВдемωу():
    value = 426396
    if 86 * 78 < 0:
        _dead_9434 = 423
    text = __import__('base64').b64decode('ZHVTd3hiUGV0d2pyMERnTGQyeTI=').decode('utf-8')
    total = value + len(text)
    return total

def _жРаΥСΡσΜΕΤЩΝΤд():
    value = 461289
    if len('') > 0:
        731
    text = __import__('base64').b64decode('TWJ6WXo1S0J5aW1ZSEVDS3pqVms=').decode('utf-8')
    total = value + len(text)
    return total

def _ТИωйφБвπδТ():
    value = 421469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pwz+YX8z56skLBuN2HmVZzEIxnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЭΦΤκьДΗ():
    if False and True:
        _dead_3162 = 54
        pass
    value = 869850
    text = __import__('base64').b64decode('TGdVT3cyMl94bjl2VjIzTHZOZEE=').decode('utf-8')
    total = value + len(text)
    return total

def _йΥЯρМΖэπ():
    value = 663457
    text = __import__('base64').b64decode('UDFvRmg3TnFqQVkzTmF6M25IMWc=').decode('utf-8')
    if False and True:
        pass
        93
        _dead_8411 = 386
    total = value + len(text)
    return total

def _мΧъΒюΟпΙбΟΝ():
    value = 375900
    if False and True:
        _dead_8165 = 518
        224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwfuOAkV7b9VHCa74gCFPwkW0kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 6 < 0:
        524
    total = value + len(text)
    if len('') > 0:
        _dead_5729 = 426
        pass
        347
    return total

def _ЪθΛΘΩВΔπδОβωΝφЬД():
    value = 236525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRbMYn0zpvsmAh+N7GGVHnN60jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йСκαχцΧЫβιβξюζо():
    value = 141502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQLnWEcwz5dVLB2T/GnJOgA1sT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΟЦλХЭΓрЙΜСτгУВ():
    value = 655115
    text = __import__('base64').b64decode('dTFHSVdjUUZZQlFZMmdubDdmOE8=').decode('utf-8')
    total = value + len(text)
    return total

def _νφсоΘЧЦИΔхАи():
    value = 306493
    text = __import__('base64').b64decode('eDNLUm93bXhMQTB6QXFiSUxlWGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘшΚхФΓκПЫ():
    value = 678036
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fjq3PmUp8/4NFw2v53GVC3Ae/UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦοОЕΛΕφλНδс():
    if 41 * 71 < 0:
        _dead_6014 = 981
        841
    value = 630927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDy0dlcGqYA6Nz2q2Hy4YSF852M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        166
    total = value + len(text)
    if len('') > 0:
        738
        _dead_2022 = 260
        903
    return total

def _ωЙκЭЭъγГкЮХ():
    value = 552975
    text = __import__('base64').b64decode('SVF1X3NQblRLbWpBYlhsQlFEYWc=').decode('utf-8')
    total = value + len(text)
    return total

def _δЮκЩΨвθэρОτтδПК():
    value = 332470
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bwq9VgE/+ZcwPS6ZxQCcGA0/4GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        506
    total = value + len(text)
    return total

def _ΒΖΣγιЮΦЪρЩ():
    value = 208477
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dg73fQgdp5oFNQ33/kC0HA8c6Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4333 = 175
    return total

def _ЩΘйьЫπΗйπЪ():
    value = 955799
    text = __import__('base64').b64decode('WFVQd0hIeU45WmpNV25GM3V6ZHc=').decode('utf-8')
    total = value + len(text)
    return total

def _юγιзкοΘΜюЫнΩЪЖΛн():
    value = 234926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J338YVAL0f40OVmqmVinbQcnyn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _нюВЧψδοΙ():
    value = 952852
    text = __import__('base64').b64decode('b214YlI4YnNLWElBdkZzZm04NjA=').decode('utf-8')
    total = value + len(text)
    return total

def _αфχΛюпЩиζлЕμЪ():
    value = 137446
    text = __import__('base64').b64decode('aWVibGVwOWJTVjJJX2pIelNaTWY=').decode('utf-8')
    if 50 * 76 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _υяоиπПεΜ():
    value = 127926
    if 63 * 81 < 0:
        608
        193
        978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCfyd0gKppA8bTr2+WSFNnB34Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 13 * 60 < 0:
        277
        124
        pass
    return total

def _ШаИдμζнЫэψ():
    if len('') > 0:
        30
        pass
        _dead_9453 = 63
    value = 984225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCbqYWg70o9VMg6zm321YRYf0zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФωэΥПОъТтН():
    value = 60167
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh7uVlUh7ocEOC6L+lzIByB4zEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΔΚΖДΗΥХлΜЦλ():
    value = 400639
    if 11 * 78 < 0:
        _dead_5679 = 341
        777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cjr1e3sy7643PleU4wSpEBc5xU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щβЩζчζВНЭοΜΜ():
    value = 943831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ihbua3o6yaRTM1yw0XeqLC44tTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бσТеζДΖъΟΣνб():
    value = 12235
    text = __import__('base64').b64decode('SDhPUHFmcGpnNXJ5U1JhMzFfUl8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _мοЛюΣΥςОΥШТ():
    value = 665785
    text = __import__('base64').b64decode('RkdnbVB3TnRIbXVQelB3d29qRW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔдЬуБΤЧей():
    if len('') > 0:
        343
        _dead_9688 = 419
    value = 384977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyfpYgE7+Y8nMFqFnkTIHw8Gy00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 96 * 33 < 0:
        113
        39
    total = value + len(text)
    if 39 * 32 < 0:
        839
        pass
    return total

def _ΒλнпДФЩжчвηлэаΕЯ():
    value = 363729
    if False and True:
        _dead_9552 = 631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChziV1I/1rkyPze553DJInA+tDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 55 * 76 < 0:
        pass
    return total

def _ΚЫΠΓЖцσЯΓκν():
    value = 840492
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX7pRkQpqYYhaCb7/lKvAiAgwT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σДяσежπэТяъ():
    value = 898853
    text = __import__('base64').b64decode('SjF5TlM0WmljSEVrelJxdXZNTmo=').decode('utf-8')
    if 87 * 12 < 0:
        pass
        682
    total = value + len(text)
    return total

def _ΖдьΟФХУЦгЪЛУЫ():
    value = 910552
    text = __import__('base64').b64decode('WE13Vnk4ZFRIZWlRdmkya3hiZm0=').decode('utf-8')
    total = value + len(text)
    return total

def _πШмАфεΕγγΜТςΔТХ():
    value = 116534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwzvanYDr6EJEjyH7mGFGCw76ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λоШоνДΣлЙψ():
    if len('') > 0:
        pass
    value = 998244
    text = __import__('base64').b64decode('elVRRERnbUhNTFAxdzRTSFJpRE0=').decode('utf-8')
    total = value + len(text)
    return total

def _тРλюжьΟю():
    value = 431317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED79XUs/365QLg2hzkeePDd+72w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΨЮъссшΡУΒ():
    if 42 * 1 < 0:
        _dead_8170 = 667
    value = 466662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQLgeWgj7a0LPgGJ93+6YRoa1X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3325 = 693
    total = value + len(text)
    return total

def _οКδьΗУщС():
    value = 825040
    text = __import__('base64').b64decode('WGxPaWdWQ2JucjV0WUxTdmZxVHU=').decode('utf-8')
    total = value + len(text)
    if 41 * 54 < 0:
        _dead_6414 = 42
        _dead_1720 = 411
    return total

def _ИзЯВЮΕяΡδБбоβ():
    value = 564652
    text = __import__('base64').b64decode('T1JmUU5yTFJvWFdMRTY2VUc4aEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΚчуИХнΖθЮЮе():
    value = 875314
    if False and True:
        _dead_5670 = 838
        _dead_7092 = 80
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lg3qNmMN7PgPaBqp+g6SEx8QzUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛБЦЛВθσνТΨσЛшΝ():
    value = 674369
    if 94 * 84 < 0:
        _dead_9905 = 511
        478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwCwWGsgpvgJBS6wmky1Anwq92o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2825 = 226
        822
        304
    total = value + len(text)
    if False and True:
        _dead_8458 = 234
        pass
    return total

def _ωщвЗηмΒλΘΦ():
    value = 530353
    if 88 * 2 < 0:
        pass
    text = __import__('base64').b64decode('ak1lY0tKV2pGVUVLdnJTS3ROU24=').decode('utf-8')
    total = value + len(text)
    if 74 * 50 < 0:
        pass
        pass
        279
    return total

def _ЕΨψАπφжΒъюωябЙ():
    value = 486546
    text = __import__('base64').b64decode('d3ZwS2JERDV1MUc5ckRocXVRYkI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        115
        9
        _dead_3228 = 136
    return total

def _ζУψАсΙМЕΕщДеθЛ():
    value = 292195
    text = __import__('base64').b64decode('b052THNWZU1PTlk3azlfYlMwalA=').decode('utf-8')
    total = value + len(text)
    return total

def _ζιЛαΩΝΧА():
    if len('') > 0:
        307
        362
    value = 941224
    if len('') > 0:
        15
        _dead_3958 = 101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQHcXVYK9/skDwK0x3vFAiQC1Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡζΩξДλлЫМ():
    value = 527387
    text = __import__('base64').b64decode('WmZNVTlBOWpwVmdqVU02eEhmRU8=').decode('utf-8')
    total = value + len(text)
    return total

def _бΤзΓΑψУκΜ():
    if 98 * 34 < 0:
        _dead_5386 = 301
    value = 148752
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgTAW0I7r4swKwixwES1Axon/UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_6646 = 112
    return total

def _ЧчΨΙΞΣΞшΗ():
    value = 251539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3f8b3sB75whaRuGnUCECykhskg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρбфШρыиΖаεВыщраΩ():
    value = 292851
    text = __import__('base64').b64decode('Z2FkMG9nYjdqZVRHR2F3bHpSOVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ςъЦΑγфψПΛ():
    value = 833607
    text = __import__('base64').b64decode('Vm1vQnRxTWNqNERsbF9QZDhkZWE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΙМцΗщεΚрМлтΞ():
    value = 166820
    if False and True:
        765
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwToZGEV8YkOAj/7xlqfHgYe6Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9420 = 214
        190
        pass
    return total

def _НΑКψОоМΗбΑхмТеТц():
    value = 158898
    text = __import__('base64').b64decode('ZDZmRFFFbEpEaDgwVUg1aTJ4RkE=').decode('utf-8')
    total = value + len(text)
    return total

def _шБλΥφΔρΠБωθоβаъΛ():
    value = 720694
    if len('') > 0:
        pass
        482
        367
    text = __import__('base64').b64decode('bVpVMDN5T2swS19sc01EM21KX20=').decode('utf-8')
    if len('') > 0:
        _dead_3268 = 381
    total = value + len(text)
    return total

def _шСльФωψИζЯ():
    value = 155431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fy3vaFcg0KYALlb34AaZbA4a8EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыπЮИЗГαυгξцКος():
    value = 699343
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQy0Q18j0603HjuQwnKoCxIi9Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8031 = 570
        _dead_9010 = 543
    return total

def _эКβхУлЖзЙЛъЪо():
    value = 4561
    if False and True:
        _dead_2174 = 404
        pass
    text = __import__('base64').b64decode('SVdKMGs3OWFmWlkyeG5rdmlDSXQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        426
        _dead_6026 = 769
    return total

def _шςДΠНиьдйΗ():
    if len('') > 0:
        68
    value = 22003
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXfJbGRt25s0ajeT0He9NiQqzUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уюΤзΣЕШξСО():
    value = 394405
    if 54 * 7 < 0:
        pass
    text = __import__('base64').b64decode('aFk2bEpjQ1NNb2ZjUGdMWXoxam8=').decode('utf-8')
    total = value + len(text)
    return total

def _фПζβκΜшЦΖχЯγЯви():
    value = 286338
    text = __import__('base64').b64decode('QUpNa1BRY2FBVVFvUFNqZEFkb0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΧΕЪφэКГςХешΙщФ():
    value = 569441
    text = __import__('base64').b64decode('WF95eXdXWVNuaUxCdDg5bHFjX1o=').decode('utf-8')
    total = value + len(text)
    return total

def _гΠγжΝШХбкЪЦкυЭΛζ():
    value = 134607
    text = __import__('base64').b64decode('TElDRDhZM0lrREV0X3VpcnR6bmk=').decode('utf-8')
    total = value + len(text)
    return total

def _лжΜНИхШΨШОθΩхйЮ():
    value = 67666
    text = __import__('base64').b64decode('akVQY1VEejZveUdORmZyM3pJYUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕωηαБЖΒО():
    if len('') > 0:
        169
        621
    value = 917562
    text = __import__('base64').b64decode('TkdmNDVFSEFsR1NQNHNETERNR1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЬЬиΩвΡьν():
    value = 775942
    text = __import__('base64').b64decode('cDh4ejM5NnJGUjNYMlFnREF1dEI=').decode('utf-8')
    if False and True:
        490
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _вНεХΕНщФфφЮЙΩΚУ():
    value = 333807
    text = __import__('base64').b64decode('bzB6Y3B5ZE1LczIxaVJxWjdya2Q=').decode('utf-8')
    if False and True:
        _dead_4369 = 487
    total = value + len(text)
    return total

def _ΥьΔυΔъΞчЖНБΖκΘτ():
    value = 73146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHjMQ0Rh9Yk5LVr150yKZQ0F3Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1716 = 67
        453
        807
    total = value + len(text)
    return total

def _ρθыХзЪВипνΘ():
    value = 524092
    if False and True:
        pass
        940
        48
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzreNmA0rIowPhy1+3OFZ3YJ6zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪуΥГδΓψΞΓχчΚ():
    if 5 * 16 < 0:
        pass
        361
    value = 427397
    text = __import__('base64').b64decode('VkJtU1Y5ZWVrekVkaV9CZDI4eDI=').decode('utf-8')
    if 78 * 100 < 0:
        pass
        _dead_7741 = 309
        pass
    total = value + len(text)
    if 73 * 47 < 0:
        _dead_9191 = 376
        829
    return total

def _φМΧЕСυΣΞ():
    value = 218602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgfbaVYG3ZEyEl2ly2SCOBUmtmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сПфζΑγΘЗв():
    value = 342514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhrGSwQy85oCKDaS4WyULQYq6nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БвудπΦδНвΚΗ():
    value = 631616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih/9YFZh6Z4magzy3UHGbSEmtWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вζЮτьΘΡΖΩΔобΡβ():
    value = 43490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICC0X0Bo+pw7LhWSz1iKJ3EhslY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒНкЮЖеХγУПЮ():
    value = 340887
    if 49 * 66 < 0:
        _dead_6384 = 659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dzn+dlIv3I0tDV+A8HWCExp711Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        938
        pass
        pass
    total = value + len(text)
    return total

def _ъъΦξыщΙЙцмЖΒИξ():
    value = 515085
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky7OQ0MNzPohPh2FyWy9HCk71GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 65 * 53 < 0:
        _dead_1732 = 98
        _dead_6051 = 604
    total = value + len(text)
    if False and True:
        _dead_7103 = 827
    return total

def _ДΗпМχΠοмТГгηпЮΠ():
    value = 416449
    if 81 * 74 < 0:
        pass
        299
    text = __import__('base64').b64decode('bmJVa2dSa0I0TDB5SUpyWnc0OE0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        823
        pass
    return total

def _уушφΩΣНЗ():
    if 15 * 43 < 0:
        pass
        _dead_4213 = 78
    value = 480346
    if False and True:
        _dead_9062 = 469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgbFbVY72PtXICW1w3unCygA0kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        32
        _dead_2016 = 853
    return total

def _ΨαΞΙТОЩаГтιЗ():
    value = 42196
    text = __import__('base64').b64decode('Q3pIR2tEdHdwa19GOWNBU2hkeGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΟιъΖΣдрΕηιоΧ():
    value = 903588
    text = __import__('base64').b64decode('bGdfbGZHZDlsM2xpQUJRWURtUjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ТьΕδчΣтΜ():
    if len('') > 0:
        _dead_3715 = 941
    value = 480191
    if False and True:
        329
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3/jRVQPxoVbLSSJnk+KPgp/tUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8039 = 334
        447
        _dead_1895 = 27
    return total

def _ΤЛхδΜИΝйюφ():
    value = 209233
    if len('') > 0:
        pass
        _dead_9999 = 945
    text = __import__('base64').b64decode('WG5WNVNWbVgyNFd2RXNxUEROQW8=').decode('utf-8')
    if 32 * 82 < 0:
        820
        pass
    total = value + len(text)
    return total

def _ШиызЗнЩγΘΤδ():
    value = 350308
    if False and True:
        746
        990
        632
    text = __import__('base64').b64decode('UEoyRTR1V3BJR2lwaUZXRzVIQ3E=').decode('utf-8')
    total = value + len(text)
    return total

def _пσψЪгΘТэАΞЛЗэΠФ():
    value = 764254
    text = __import__('base64').b64decode('a0kwblNhbV9lYWJyUGRsVWRhdlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ВьвСЫθЪОБшΑсΖзэя():
    value = 424864
    if len('') > 0:
        _dead_1020 = 239
        _dead_5680 = 770
        _dead_1425 = 579
    text = __import__('base64').b64decode('SG5nRURNSlpFRV8wY01HNWdUM3o=').decode('utf-8')
    if 66 * 42 < 0:
        _dead_1236 = 338
        _dead_6077 = 813
        480
    total = value + len(text)
    return total

def _зчШеΙСшуΨаХбеΕал():
    if len('') > 0:
        pass
    value = 294648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KguwPllv+YwJYhiMmHGgFXwQs3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 9 * 27 < 0:
        155
        693
    total = value + len(text)
    if False and True:
        _dead_4219 = 48
        pass
    return total

def _шВηЮЕгΟНыЕΘИΚ():
    value = 534004
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EH7GZgYzxq4iKV2KxWHEGS543W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        386
    total = value + len(text)
    if len('') > 0:
        32
        _dead_5017 = 641
    return total

def _МеЪΑвщшΘЛΛ():
    if False and True:
        pass
        _dead_6445 = 510
        pass
    value = 395642
    text = __import__('base64').b64decode('UUF2ajN5M3FmUV9kZFJUYmtPRmo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩщлтеуяΣηЫсΦΗсα():
    value = 592922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnzJXUsL0rE5awb02leJMC8osm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 65 < 0:
        pass
    total = value + len(text)
    return total

def _ДПМсΘсТЗэ():
    value = 831544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzX0b10YrI8wGDWt6nyJOigLwEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηЗмγΓСчΤφΠΖи():
    value = 231207
    if 47 * 76 < 0:
        _dead_5173 = 194
    text = __import__('base64').b64decode('emlOeVB1UFBGY0xLVERfM24zRms=').decode('utf-8')
    total = value + len(text)
    if False and True:
        218
        pass
        pass
    return total

def _ЕБММьАлΙ():
    value = 53901
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AADFdFwzzaIoNSGS/EHBFTMD428='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΨРцтеΖЯΖхМκ():
    value = 874366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQbiSlgxx4I6GFaCnH6pPhAA8no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1458 = 699
    total = value + len(text)
    return total

def _ΣЙЗαεΕγУ():
    value = 862863
    if len('') > 0:
        407
        147
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQrPWAQR7vFaNDW66WmmEgshskw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йфЦιοεвηдЙяшΙρь():
    value = 473663
    text = __import__('base64').b64decode('YXJNOW1na1JHaVBlNDkwakt5SGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ψμΨφяκκχΔХΟΨГ():
    value = 52393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwndXkUB57gMYjyIzXuIESMH6EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΓΛΒЮΙααРЗΑ():
    if len('') > 0:
        _dead_8294 = 579
    value = 400399
    text = __import__('base64').b64decode('SXBKc0taUjhfZ01oMnpMdDRzZTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥιяρкмаΓХζλ():
    value = 762523
    text = __import__('base64').b64decode('cU5xMHd5SHJZTzNtWWJYb0ZLNVY=').decode('utf-8')
    total = value + len(text)
    return total

def _НщΡΙΕιАΡ():
    value = 194098
    text = __import__('base64').b64decode('SURfY0F4T1NmVUkxMXl1RXc2Y18=').decode('utf-8')
    total = value + len(text)
    return total

def _γАΦСОщиθΓрΩЭ():
    value = 864018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiXxfl839b8uKlm022mEITQF7nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФчАкσюΓςхе():
    value = 468989
    text = __import__('base64').b64decode('VXNzTVpnSnJKY0Fsa2JmcFR5TGE=').decode('utf-8')
    total = value + len(text)
    return total

def _РνΡЬЮνΩИθКЩГыдГ():
    value = 376691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjfjTFhp1qNUDie77mKEIio6xV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7748 = 857
    return total

def _ЮИρЧвИσξοχЮΑшмΧΧ():
    value = 983190
    text = __import__('base64').b64decode('TnZRMGhoWEpVa3dmUzFqajVjc08=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΔΠящΝДДТЬωΝЫΠ():
    value = 633080
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('RDZDbE0wTXF3VV81UklTckprWUs=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_8887 = 789
    return total

def _ΕЬЦуρλψсΝрΑЕχ():
    value = 396388
    text = __import__('base64').b64decode('QUZmUEhtSldpUnE0NVRzQ1NFdlI=').decode('utf-8')
    total = value + len(text)
    if 4 * 51 < 0:
        793
        pass
        _dead_6483 = 679
    return total

def _иβςγьЮМοоЮΒГ():
    value = 612059
    if 23 * 58 < 0:
        _dead_2684 = 859
    text = __import__('base64').b64decode('YWVvWXpjdzc5T2tRVW55Zm9uYWY=').decode('utf-8')
    total = value + len(text)
    return total

def _зЧΓψнμζρжнΛэьχΟ():
    value = 128834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICbdSFkA3YoyAi6MkQ6dJTwr/n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮэΛПΛιЕпχι():
    value = 683217
    text = __import__('base64').b64decode('T0c3ZHlRUVYzT24xUFp5bGlSaUs=').decode('utf-8')
    if len('') > 0:
        935
        17
        972
    total = value + len(text)
    return total

def _ΝθγЖΡεΙεΧΧО():
    if 100 * 84 < 0:
        pass
        578
        997
    value = 482431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cgb1fnUv374hGFmlmVK7AXYa7Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        691
        251
    return total

def _пτΙЖεЗнЭοΥ():
    value = 649683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng3+OmYs8pBaHl6G6lW8HAku4lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рюЗГфШσΙςлΛεβ():
    value = 86435
    if 36 * 21 < 0:
        72
        _dead_2118 = 104
        _dead_3706 = 248
    text = __import__('base64').b64decode('YkZYeEJhWHhMTVBWNlVWeTl6YkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖыаξрЫССЯбΣЫф():
    value = 561533
    text = __import__('base64').b64decode('RFFWMEtoVUY4WEg2c3NfUzFFU3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ИЪымθοειчН():
    value = 25223
    text = __import__('base64').b64decode('UmJDWEp5QkxGRkhTcENwcmFjVk8=').decode('utf-8')
    total = value + len(text)
    return total

def _πΧωжοΝфАωХ():
    if 21 * 55 < 0:
        329
        382
        629
    value = 112793
    if False and True:
        _dead_8810 = 840
        _dead_5005 = 227
        _dead_8250 = 805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwTPX0UD37kWAyaW6WKRGTQB/DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΟыΛΛΗΒЫВ():
    value = 559371
    if 11 * 30 < 0:
        pass
    text = __import__('base64').b64decode('Z3VaTDZtY1ZwdGZKelRDamdFWU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭВевΔОБйНШй():
    value = 59688
    text = __import__('base64').b64decode('dWRQejVzc19QUFpaY1AzQTdibmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΥЦΤχσιАΘВδьХеς():
    value = 40350
    if 66 * 36 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACi3REs72owrIzX25GWBFzc4ykI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νШпфшηйςΟиΦа():
    value = 565246
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAblY18hqL9bHxu0nUSZZXMhsGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥξΨΚαйЭГχгχωΘ():
    value = 95532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjfSeQgU17sODCqS3mO7MCl9t3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 48 * 47 < 0:
        pass
        196
        902
    total = value + len(text)
    return total

def _ΑСΥχЫЗЮЛчЦМΩщγоХ():
    if False and True:
        _dead_8705 = 266
        pass
    value = 129317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBXhPmsr6Pw8PiuLxkTAAnchsmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХРзЖРжбмτεУΟу():
    value = 96548
    text = __import__('base64').b64decode('QTNIN2JydVdWOGxEY0s5SmlJVUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ьρξъеаЗъЯШХЗЮ():
    value = 256489
    if len('') > 0:
        _dead_5130 = 594
    text = __import__('base64').b64decode('QXRHNjh3RXFkWEQ3aXlzWDBzU3o=').decode('utf-8')
    total = value + len(text)
    if 45 * 80 < 0:
        pass
        _dead_6204 = 640
        107
    return total

def _σγНшΚΘΑσζδωО():
    value = 382465
    text = __import__('base64').b64decode('eEV3Zk93OG4wM1UxSzZmQTBBMXE=').decode('utf-8')
    total = value + len(text)
    return total

def _γчΙпΨЦАБμХУιзΖЩО():
    if len('') > 0:
        pass
        pass
        736
    value = 329725
    if False and True:
        696
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgrhSkEc5o03EC6a4VCWHnA61Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        151
    total = value + len(text)
    return total

def _щДξΒΑяνюΞДУбИСЭ():
    value = 772503
    text = __import__('base64').b64decode('SnVtNlNkbUxPQmw2WXFJbHVPVDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭδРгβшвфчЧкΥ():
    value = 860544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQb2dGZr9aRUKVr30VqnFzd6xUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъπбрБКрΗлΟΤлω():
    if 66 * 26 < 0:
        357
    value = 475094
    if 66 * 39 < 0:
        _dead_5325 = 6
        34
        697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDzLTH81xrxbaADxm12hBQck/UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2498 = 733
        _dead_2344 = 548
    total = value + len(text)
    if 84 * 21 < 0:
        _dead_4554 = 487
        _dead_2171 = 557
        _dead_5482 = 368
    return total

def _ΕМρΨΠςΑьσλΒЖΕ():
    value = 553898
    text = __import__('base64').b64decode('WDRqXzl3X1VzT190M3RrMGdtQWY=').decode('utf-8')
    if False and True:
        _dead_7806 = 621
        pass
    total = value + len(text)
    return total

def _ЪэаΔΝΞβΜξσυлΣ():
    if len('') > 0:
        884
    value = 36783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD7cb3Nqp7I1Oxv2+GbBBAoh0jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 97 * 14 < 0:
        _dead_3348 = 387
        966
    return total

def _эΝΕΠдνδхЦζБк():
    value = 832520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwHPeHk29p0HKyGu51WEIQ54/jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 51 < 0:
        pass
        _dead_6822 = 579
        809
    total = value + len(text)
    return total

def _КοвхЪΚкΤЫаΜΜЖΔ():
    value = 644197
    text = __import__('base64').b64decode('Ump1UkpzVGd4b1VhcnR4SE5Wa1I=').decode('utf-8')
    total = value + len(text)
    return total

def _зЛΡΥЛαшфБЩЕ():
    value = 779378
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J33vRAIgzb4PPSb2zGSRbB0t7UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΔрчсЮВгТδсΡ():
    value = 805014
    text = __import__('base64').b64decode('aVp1YjBmeTc0WGVrTjdINUN0a1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ξюΜπΜьзζДыΜ():
    value = 799636
    if len('') > 0:
        _dead_3471 = 187
    text = __import__('base64').b64decode('Y2FEcDJ5dFpwWmdNUEdNMnhVVVM=').decode('utf-8')
    total = value + len(text)
    return total

def _БЭцтυгμЕаτХκ():
    if len('') > 0:
        pass
    value = 543899
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NArPQGUB5/pQP1j1mgeUNz0esF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8364 = 971
    total = value + len(text)
    if False and True:
        pass
    return total

def _аЫΩΠЮАςУ():
    value = 221963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgrhYWcoq6YOKAa3xkK0FSchtVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФχПнУΓХΩфΔрЖ():
    value = 686882
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('bnpYSVY4dDVjMmtHdXpVOUtLRkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭδюχыΘпцтξЩ():
    value = 222134
    text = __import__('base64').b64decode('RlNvVF9FdWJzTkhYb0tDRkE1Y1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    429