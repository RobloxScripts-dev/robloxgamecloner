#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _хπуΘΝΤςΠдΥ():
    if 93 * 100 < 0:
        pass
        450
    value = 591058
    text = __import__('base64').b64decode('eXp6QVIwcFRVVVJpNWVMczhubEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑρЗΝΧУλΞЪεΦ():
    value = 159887
    if len('') > 0:
        507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB2zfn0X0ZJTKliQ8UTFHXY23EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 44 * 37 < 0:
        _dead_8530 = 869
    total = value + len(text)
    return total

def _ψУЫΡхοπЗхΕ():
    if False and True:
        _dead_1588 = 475
        948
        _dead_5207 = 893
    value = 217403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiXsSEdt6YU7KC23nWC1bDw4yWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыζкмПΤюЦнλфЗ():
    value = 607483
    text = __import__('base64').b64decode('RGJBcWlzN3FhbmNwOWt0S0ZYMTU=').decode('utf-8')
    total = value + len(text)
    return total

def _σьРжζьγЮχκн():
    value = 172135
    text = __import__('base64').b64decode('V09qRUU0UWM3M3FlenN2cGF6d3M=').decode('utf-8')
    total = value + len(text)
    return total

def _КσыΩΚаЙЖКСΛШιАз():
    value = 10969
    if False and True:
        684
        605
    text = __import__('base64').b64decode('a1ZMUF9Gb2JMUmhYNFJZQWhWckY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _τιвящЖнъ():
    value = 998592
    text = __import__('base64').b64decode('WTc5aDR6Ykp6ZU9sZkRMWVNsaTI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _рЪΒΘψσДнЙеШЛιК():
    value = 322498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQDBTUQp16xaaTjxwFCIYSt+1W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 88 * 14 < 0:
        pass
        pass
    return total

def _σЗδδХκТχш():
    value = 574106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwnpVgJqybAwaReQ4WSCYDM9/D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВсιΥχДχжгΠашСΞО():
    if False and True:
        _dead_4197 = 163
        _dead_7570 = 484
        204
    value = 186326
    if len('') > 0:
        _dead_9556 = 592
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Agv2dFk9x6Q2EF2Ry2KALCwqtkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 73 < 0:
        560
        _dead_9740 = 698
    total = value + len(text)
    return total

def _зсζБМΛьΕ():
    value = 668908
    text = __import__('base64').b64decode('azFWdTQzRE9lajJjbGQzRWpmQzk=').decode('utf-8')
    total = value + len(text)
    return total

def _УняЯНтδΣ():
    if False and True:
        _dead_1323 = 418
        pass
    value = 456540
    text = __import__('base64').b64decode('TndkN0xrekpHWkdFOWd4ZTQxNFE=').decode('utf-8')
    if False and True:
        _dead_1231 = 522
        _dead_7419 = 439
        811
    total = value + len(text)
    if len('') > 0:
        _dead_3620 = 958
        pass
    return total

def _πΝсоφДσΑδμЦжαψб():
    value = 56876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ7VOn89qJ8ZIza1306pHHUX8GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΙйτΟΡЩμΦζОиГФΦ():
    value = 527072
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiTtZQMxxoU5NCKM3Fu+HHQD3ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 54 * 90 < 0:
        _dead_8263 = 802
        _dead_1779 = 424
    total = value + len(text)
    return total

def _ΕΛрΣбАςШоΛρСΥЩбι():
    value = 56007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3j8eGYK9oclbB3xzlyyJXY57kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιВчΠΩъЕτςΟуыΟΕ():
    value = 568611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHjcW3001aYrNCaJ5FS8OT8A4D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лαΛλΨЧΠа():
    value = 45760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBDcV1YA07AULiic/V2UHRQrzj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕλγдьхфОгКωХоГΗ():
    value = 302521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwW0fUQcypkhLCCB3k+BIT0p1j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςГΩНуЛХΞфЪΕΒЮВиω():
    value = 770584
    if False and True:
        _dead_3274 = 147
        712
        922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LymzS18d+ow5Nzq623HHYwIj708='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 11 * 12 < 0:
        pass
        0
        249
    return total

def _ρЬДΙΦЗιΙнЪΖГΚвβ():
    value = 783541
    text = __import__('base64').b64decode('cFM4WUVfY1ZOaWRjRHRvaDFzeUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ξπΛλПСжΜΠΔΩПθΘ():
    value = 853189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXvDfXsTqoBVBQSr51mKJ3U2/EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠХΔСςаΡΛνт():
    value = 495038
    text = __import__('base64').b64decode('bzJNT3pFWDdSNkxvUGU4aFU1OHY=').decode('utf-8')
    total = value + len(text)
    if 38 * 18 < 0:
        pass
        715
    return total

def _ЪврΜРЩΛμΟΝΛРξ():
    value = 321254
    text = __import__('base64').b64decode('bUJqOFpqeFN5Zk5ha1Nsc1JubEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΠβбьσΦΣ():
    value = 317387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ajr8fkcu+/8mNgCuzGKfN3QY9T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧυΓЧνщπΩΕбΠπξτ():
    value = 494505
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgrnZXsD3IwTbz+3zFyhJXN7408='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΖбЭυЪЭΖОτЯ():
    value = 138383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ez/sW0U89KMTNACHmmWgLC8ptlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οоξυΩιπΓτъг():
    value = 706172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjvBeHMTyJAmLgKynX3DLR8Vsjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        666
        _dead_3635 = 16
        _dead_9595 = 842
    return total

def _иΒФτΝΓъЧЙμΣШФ():
    value = 683814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh70T2Zrq4paOR+Pmn6cPgcf7F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НтЪАсЯэΨБЗКф():
    value = 320722
    text = __import__('base64').b64decode('aUxxbDI2c0lDQnVYbEpyZ3lPVjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ШκсγсЕαЕли():
    value = 568544
    if False and True:
        _dead_8803 = 892
    text = __import__('base64').b64decode('Z19jdDh1R0c0TjgwendHYlZLNlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗдГΔЕгЩφμηлδ():
    value = 455242
    if False and True:
        pass
        _dead_6996 = 215
        _dead_6357 = 25
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARvXdGs1zpglFQWkyVSUZHJ902w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8700 = 364
    total = value + len(text)
    return total

def _фΨξωВΕХвЪЗй():
    value = 552940
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzvHZ0QT/ZAuOCGi3V7BNSws1XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΨΠΓΖΥΝШэ():
    value = 62228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECPdPl8oxv4oNzf1wlivIHQO01c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЛтΑπУэЦζ():
    if False and True:
        427
        _dead_3999 = 540
    value = 805440
    if False and True:
        pass
        _dead_9450 = 69
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bwn2R25hrZ4HbSaFzUy3FTI3vDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧОΣΖлСЩλЭοξП():
    if False and True:
        pass
        _dead_9778 = 966
        523
    value = 903362
    if len('') > 0:
        pass
        180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBvKb2IQ04YpCxaB0kSeCzx7yHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        419
    total = value + len(text)
    return total

def _ΒζΜэВΚГΤΨςΓΟиπо():
    value = 902880
    text = __import__('base64').b64decode('SWJRcHdVZ0o2TG1ITGhydGNuX3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦЩΩабпλФαЧзνяеШп():
    value = 804744
    if len('') > 0:
        67
        pass
        671
    text = __import__('base64').b64decode('ajkwOWVwenZPOXZuN2JxNmtORTc=').decode('utf-8')
    if len('') > 0:
        pass
        19
        pass
    total = value + len(text)
    return total

def _цδηвзΛυΗйΣΝоЧΛ():
    value = 733790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Czn9WUUX3/xQKje3n0S7FxI7vWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 88 < 0:
        _dead_3767 = 201
        _dead_1408 = 606
    total = value + len(text)
    if 9 * 46 < 0:
        pass
        11
    return total

def _жЪгυъχшπθш():
    value = 616232
    text = __import__('base64').b64decode('ZWJuTUNkM2swWm5IcHhjbE1GZHU=').decode('utf-8')
    if 99 * 30 < 0:
        613
    total = value + len(text)
    return total

def _ΝΟьЫΡθαΙΚДΦй():
    if 3 * 81 < 0:
        223
        _dead_3712 = 722
        71
    value = 64994
    if len('') > 0:
        995
    text = __import__('base64').b64decode('U205ck9xSFRSZWRBdGFBNVNZVnA=').decode('utf-8')
    total = value + len(text)
    return total

def _зΑЙибΙΣЛоЫ():
    value = 466588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BizVNnUj5vpSFgGkwm/GPi0a82o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΦСХюиНрΜюУЙεшεζ():
    value = 293391
    text = __import__('base64').b64decode('R0VuUGRlanN4NFJlY2QyMHoySl8=').decode('utf-8')
    total = value + len(text)
    return total

def _лфΣшОμζръАХьЗΗх():
    value = 928972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXj9aAU8xp8ZNVbwzFilPgc1yk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΒΨоΧцаΦтΤя():
    value = 570123
    text = __import__('base64').b64decode('RVlUTUpsRmZOUld2amNkMnl4T18=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩРъНЗΚКф():
    value = 612182
    text = __import__('base64').b64decode('UXRuR2tTUmp1ZDZzQ2ZfbktKSGE=').decode('utf-8')
    if 65 * 60 < 0:
        _dead_5665 = 947
        837
    total = value + len(text)
    return total

def _еЙйσζβщοπ():
    value = 85613
    text = __import__('base64').b64decode('aGpZMkRLd1p0X29nMkpjN3F0WUU=').decode('utf-8')
    total = value + len(text)
    return total

def _цΛЩλΠΑтΗ():
    if 10 * 38 < 0:
        pass
        451
    value = 331858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxjOVGgY+f0yFx2u+16VPnUe1zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        274
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _υфХΤΩгЗκγмΣ():
    value = 802711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kii8ZwFp/a0ALjWO4U6EFnIs02E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βψτжяЪσΦ():
    value = 366041
    text = __import__('base64').b64decode('TDZVUm5jRnpTOERya3M2a1pLYnU=').decode('utf-8')
    total = value + len(text)
    return total

def _τππзεЕьшвЕτа():
    if len('') > 0:
        _dead_9437 = 987
        _dead_2132 = 737
    value = 197303
    if 36 * 65 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyHVaVoo2JsuOQOtwXeULC8A01s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щКЯэΔПезжЛЮлзж():
    value = 818702
    text = __import__('base64').b64decode('Y2xhTXpkSEtXVWt4cWVNS2tLTmk=').decode('utf-8')
    total = value + len(text)
    return total

def _соΣγΤЕштЩυΕгΚ():
    value = 827165
    text = __import__('base64').b64decode('R2NGZkI5Y2NoVE9Yd25aNWNyTVM=').decode('utf-8')
    total = value + len(text)
    return total

def _μΝΩвТсАЛρОчγεеρ():
    value = 521551
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQC2YH4G1rIBIgO191CaFzR40m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КγУШτИРРоξωΩΙГ():
    value = 732476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ei6yOkssx6INYgig+m+0MB01y0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λρΧмηΘЖэЮэьчюкΩ():
    value = 195870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAzSQGM3z6c1FCWO+FSTDQc670I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жζΜвПИшДХРцСФ():
    if False and True:
        pass
    value = 7867
    text = __import__('base64').b64decode('VXhaQXpLQXJRdHVjT2d4NG81dFM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        37
    return total

def _ЪыДτΨШεйηШАβ():
    value = 572064
    text = __import__('base64').b64decode('ZUNabTZCZk5LQ3UzTXQyRmJLSEk=').decode('utf-8')
    total = value + len(text)
    return total

def _фюлΛΓЫΦЗΓйΜаπЛЧЮ():
    value = 904841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3rTRUUd3b5QGDi62UajBgMV6Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фАΤЫδμΗНПιЪιКуΟΔ():
    value = 864339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCbwUXIX74ASMz2Im3O6IxYp/EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣβбМφлζΣΝεδ():
    value = 108354
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDrwTWA88qctYga623PCLT8u8EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΔчКНεЭНБВηκуОЪч():
    value = 700241
    if 9 * 36 < 0:
        683
    text = __import__('base64').b64decode('VXV5WmVibnNvOW9Zako4VVo1SnM=').decode('utf-8')
    total = value + len(text)
    return total

def _нЧТυψШΝХуγ():
    if False and True:
        _dead_8675 = 915
    value = 299472
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eg3hfUAu1Ks2LVqsmXG9YxY30zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 71 < 0:
        322
    total = value + len(text)
    if False and True:
        _dead_2773 = 310
        pass
        pass
    return total

def _ЭφγτχМΠЛЧЯμσ():
    value = 746930
    text = __import__('base64').b64decode('UlVaTlNrdDdQWkRKdE9nRXVnQzQ=').decode('utf-8')
    if 15 * 84 < 0:
        336
        pass
    total = value + len(text)
    if False and True:
        pass
        704
        _dead_1318 = 297
    return total

def _зΟгЖЬгЮшΣЙЬρБξ():
    value = 660173
    if len('') > 0:
        _dead_9478 = 282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXzAaWg92vAUbQKM+FGAbAt/xmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΛЕгуТθε():
    value = 261108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjrcbVUT1qY1OR6m0n+YH3UB908='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9900 = 39
    total = value + len(text)
    return total

def _щдΕБтфяЭαСεΛ():
    value = 445390
    if 1 * 70 < 0:
        _dead_7778 = 850
        492
    text = __import__('base64').b64decode('UkVWbzdQbUVzazQ2QXdNc1ZKN3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ДОφоΠбмπоз():
    if len('') > 0:
        pass
        pass
    value = 80416
    text = __import__('base64').b64decode('SExMX3BOY25VR2o4TXNCd2FteVg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        505
        _dead_3301 = 206
    return total

def _γΝνшκΗΠΣеИКО():
    value = 719878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzbWYF0a+4IOOxaGzga4LSYtzTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΜфгСщβгеτРΓ():
    value = 194775
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCTISURs+/ANFjaGzW+0IyMI/Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΕαБдЩмжτбεΞыΒ():
    value = 121649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX/+aUgxrJgaABeuylOHIy04/kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮаΥЕУνхσ():
    if 5 * 91 < 0:
        _dead_9020 = 718
    value = 711706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQjgVkBr0fAULln77GO/OQMN020='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ξСХВСКΝЧьъ():
    value = 62100
    text = __import__('base64').b64decode('Q3FQZzNnY3ZWdFZpM3JwRE9Ld0I=').decode('utf-8')
    total = value + len(text)
    return total

def _КοδπΞζΓФэбΚ():
    value = 353008
    text = __import__('base64').b64decode('ZHlTWk9faXV1WklqcDNYZVR2blQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝЖХоНОжΚ():
    value = 47815
    text = __import__('base64').b64decode('RVliNWtrSGs0cldtR3ZfZ1hiaXg=').decode('utf-8')
    total = value + len(text)
    return total

def _УйΥпЛрмьЛщξ():
    value = 996555
    if len('') > 0:
        pass
        _dead_3792 = 335
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An7NamQYrKI3MDmU+X6kAnML414='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЗШтψьχшЫχПΗ():
    value = 18786
    text = __import__('base64').b64decode('c2xvX3pjM2hCOTZMUmZoZHZEcVg=').decode('utf-8')
    total = value + len(text)
    return total

def _лψοяλЩГУ():
    value = 646938
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3a8Swkh664MESuT4kO0ERID3Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8553 = 249
        703
        266
    total = value + len(text)
    return total

def _ПΥэΤАПςΞщ():
    value = 300988
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ayu2eAAbrpAzEjm50FGUBCgf9G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧЕУфФΛαКΡл():
    value = 643542
    if 56 * 74 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISzBf3dr+oYTageC2QW3BnMY6mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4546 = 354
        pass
        580
    total = value + len(text)
    return total

def _ЫΥОψΤхΝФжаωИ():
    value = 769838
    text = __import__('base64').b64decode('QTRZS0FGd0ExV1dGd1M3ZjREUnY=').decode('utf-8')
    total = value + len(text)
    return total

def _λцΟρБΜзткчБЕν():
    if False and True:
        pass
        814
        258
    value = 698489
    if len('') > 0:
        _dead_1982 = 708
        pass
        _dead_6630 = 232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC2xZXcG3PwaPlip71mTMigqwWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        841
        894
    return total

def _μθБЙЭКЯζЙряε():
    value = 356246
    text = __import__('base64').b64decode('TjY3OGpiejhhSGk2aHpKd1I2eGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ФσΠξΗβΕКΓΡΞδйКЩ():
    value = 612994
    if 100 * 66 < 0:
        _dead_2056 = 304
        _dead_1774 = 989
    text = __import__('base64').b64decode('eW4wZHNHWm0yU3VRX1h5VXU1Nkg=').decode('utf-8')
    total = value + len(text)
    return total

def _лΙοгнοмξнζδМкυ():
    if 71 * 30 < 0:
        5
        _dead_3955 = 315
    value = 674343
    if False and True:
        _dead_1733 = 713
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxjCaF0W7rE0MAOsy3OEAwIu5mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        152
    total = value + len(text)
    return total

def _ΛчΕКХΞчζрЩΧα():
    value = 926858
    if False and True:
        87
        _dead_8553 = 435
    text = __import__('base64').b64decode('SmZrQnVrRmx6X0lQMzNpX25oM0w=').decode('utf-8')
    total = value + len(text)
    return total

def _РхЭшяΘщξΒγОгЦЙ():
    value = 526718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fn+2SGQU75csAlyM5mOWIjAF6n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 80 < 0:
        pass
    total = value + len(text)
    return total

def _ΠυΘМЕβЕЗршшщυΓев():
    value = 501589
    text = __import__('base64').b64decode('am4wZFFzblExVmIzRkw2a29RQlg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙκфЙКлдЮφ():
    value = 474768
    text = __import__('base64').b64decode('TGJoaWN4VWR1ZlJqOWxZbGhtcUs=').decode('utf-8')
    total = value + len(text)
    return total

def _εбУςαΑΘυφЖι():
    value = 705036
    text = __import__('base64').b64decode('aTJ2Zml1VWFXUHA1OUI5Nll6RzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΕΝеТψΤΛэ():
    value = 474336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAW0RWgzq4Y5Ih2F3VqJFQQpwFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7350 = 699
        pass
    return total

def _эЩхГςВΒжУБνΗчШшж():
    value = 4495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjzdT2Y2qP8mFCOA/UCoFnUnvWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Сзфξфзьεφ():
    value = 812067
    text = __import__('base64').b64decode('aEZ4WDcyaHNxMlRxNVNmSk1ZV2s=').decode('utf-8')
    total = value + len(text)
    return total

def _τТΜκυΕЖΝпτЬ():
    value = 67678
    text = __import__('base64').b64decode('TzFwM1FlVGttN19NYmZHWFJoOFg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        719
        pass
    return total

def _κΝΤМΙщвΖΕффθΣТεщ():
    if 32 * 67 < 0:
        _dead_2226 = 811
        _dead_5613 = 286
        _dead_2519 = 78
    value = 347098
    if 68 * 48 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz3QWUQuwZImaVmIxQTBOA16vUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЫΑπОΩκδкУθоэγ():
    value = 112336
    text = __import__('base64').b64decode('c1oyVlVEQjJpSndZR2x3c3J2dWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΖЙДπхΠμжАЮоεВθ():
    value = 380178
    text = __import__('base64').b64decode('czc0RnNuSEp5akpiSlNUYzdMZkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΦАгЩвнΥРьχ():
    if len('') > 0:
        102
        910
    value = 468218
    if 5 * 94 < 0:
        _dead_6498 = 666
        pass
    text = __import__('base64').b64decode('VUw1ZVN2Z2x3bnJHV1pIbW45T1k=').decode('utf-8')
    if 17 * 34 < 0:
        _dead_1621 = 683
    total = value + len(text)
    return total

def _ωЮьμφζдΩтαМцΚΜμ():
    value = 223532
    text = __import__('base64').b64decode('VXR0UVRzVk1jeWhrNmFSdzl0ZEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ъΥεΥτХЭыДНС():
    value = 344987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('My7caGEv1q82aFmR+USAABQG3js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑхвеζαыγЯГАΔΕр():
    value = 889876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pz7XRQcD57g2KQuazw/BLTV7tl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΥНξйбоσУΔпСι():
    value = 506339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgniYHo3qL8yNj2w+HiENiM36U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИφΗхЩЫφΑЯехх():
    value = 658292
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgTcTVMMqr0OMgGb0FSzYQI/x0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъхΝЙξчЕглΠйΤЪτ():
    value = 955936
    if len('') > 0:
        619
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnvnfFo6y6EOGBu65VPIJA968HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖърЦζЪαλρεб():
    value = 31090
    text = __import__('base64').b64decode('dmtKNmVCVE5Sb2ZzSXJ6dkhqa2g=').decode('utf-8')
    total = value + len(text)
    return total

def _δТсΠяΓКйгСΔχφΓбв():
    value = 552816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSfbPlUDyJoFNzCn0VuHOHUbslg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 39 < 0:
        717
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_5328 = 462
    return total

def _ЗМцδхЩиφ():
    value = 46218
    text = __import__('base64').b64decode('WlZERTlDVEhxbzJQWnlZcGF0UEg=').decode('utf-8')
    total = value + len(text)
    return total

def _йΞъΤХΝοΤиЖнΘ():
    value = 149045
    text = __import__('base64').b64decode('RGhKRkpaaV9zTXBRMllQYjV3OTM=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΞВЭΘэТΛэΠЛΨωΖым():
    value = 921766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQ33Vl0h8r4nEyG20E+nFhUNyGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣθΧρνлУΒАεХΡтΩнΥ():
    value = 531091
    text = __import__('base64').b64decode('cW85cjExMzFDVHpWTHFoZV8xTkY=').decode('utf-8')
    total = value + len(text)
    return total

def _оБЪьЫΞйΓγп():
    value = 550715
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzrjZ0I3zP08LDu28GaXLHAAtGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εГΘоКδоъτκ():
    value = 644910
    if len('') > 0:
        _dead_5110 = 777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jw61ZHgh/Pk5bleAx1C0HXMgymA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эМτбШСЪΔ():
    value = 593090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwPzeQMeqoo7Gz2tyUS3Zgx2tjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        225
        _dead_8280 = 348
    return total

def _гОЛЕΨζВжФц():
    value = 852686
    text = __import__('base64').b64decode('bzFvekpxczIydUtaaWlWUktkZEY=').decode('utf-8')
    if len('') > 0:
        696
        308
        pass
    total = value + len(text)
    if 51 * 17 < 0:
        145
        pass
    return total

def _ЛγйЮΧЦεЪψЭΓΜ():
    if len('') > 0:
        _dead_2602 = 11
        994
        pass
    value = 749307
    text = __import__('base64').b64decode('eHhtUWc0WEloYnFJNVc2YURXWjM=').decode('utf-8')
    total = value + len(text)
    return total

def _грЯГрнВнΕс():
    value = 490585
    text = __import__('base64').b64decode('ZDJZbVFFYXRJTkw2VFFKNEp4Vlc=').decode('utf-8')
    total = value + len(text)
    return total

def _рλΕφζЩБκΗΧΑχ():
    if 60 * 55 < 0:
        _dead_8679 = 758
        592
        726
    value = 642176
    if len('') > 0:
        _dead_5098 = 984
        _dead_4986 = 38
    text = __import__('base64').b64decode('cWlCZDVIRUtSVHpGQlNGNnlZSlA=').decode('utf-8')
    if 27 * 78 < 0:
        pass
    total = value + len(text)
    return total

def _ΘЫωγΨζΜнч():
    value = 536657
    text = __import__('base64').b64decode('TGNtWmxvdGNfZUQwc3I4dlBCS0Y=').decode('utf-8')
    if False and True:
        _dead_5573 = 992
        _dead_8395 = 687
    total = value + len(text)
    return total

def _ЭЙрДλПΩυτКЛ():
    value = 12074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj7JOnwNwY8kbx+06XWlGS4Ht3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 80 * 89 < 0:
        _dead_5672 = 318
        445
        771
    return total

def _РζСΝШхШΦвИΠ():
    value = 492640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADXhR1QUzacoKzC35HKmP3MB9mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гнэаеΤТИЩΩА():
    if 45 * 80 < 0:
        pass
        225
    value = 398626
    if 92 * 74 < 0:
        pass
        201
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSTDNwApy78iNAWL0XWgZREJzmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 5 * 97 < 0:
        pass
        pass
        pass
    return total

def _тΔоТΨМαькдЧ():
    value = 489869
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Din8aUQ98IAVHAmB+AC+HzwO6Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_9435 = 120
    total = value + len(text)
    return total

def _щΙдΘвОпα():
    if 26 * 4 < 0:
        _dead_7147 = 712
        _dead_5138 = 461
        pass
    value = 676830
    text = __import__('base64').b64decode('eGZpa1p4VXRyOGNSSVR3dFVtdnY=').decode('utf-8')
    if 62 * 54 < 0:
        pass
        _dead_5611 = 389
        pass
    total = value + len(text)
    return total

def _μΣоцаΩюйСуρ():
    value = 385003
    text = __import__('base64').b64decode('T09wc3NEVGFIZTVFRDFDUzFZNXI=').decode('utf-8')
    if 64 * 40 < 0:
        _dead_1253 = 569
        _dead_4562 = 175
        _dead_8895 = 830
    total = value + len(text)
    return total

def _ЧсβΜгΩЬХΞ():
    value = 900760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz3TUXAW6KMxL1mJmAO+Ox0iyFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΜΛцкрΩрОмшИ():
    value = 589060
    text = __import__('base64').b64decode('eWFCYnVLc1pXOG9EdzVuT0k0OWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓШдΗЬПвλЕС():
    if False and True:
        _dead_9418 = 895
        pass
    value = 303791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHj2W1MJ6r8RKDWnm3CEIA0n90A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        710
        _dead_4490 = 128
    total = value + len(text)
    if 49 * 44 < 0:
        pass
        pass
    return total

def _ωΞγΓхΠЮхνωθπЕцΦЧ():
    value = 501007
    if len('') > 0:
        pass
        _dead_3978 = 136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQrxPFco56oADQq08EG4MQoNzz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 16 * 48 < 0:
        942
        237
        67
    return total

def _бΩтаβкшβΝΦХ():
    value = 323287
    text = __import__('base64').b64decode('b21VSE81WXJEVFMzZERGUUxsT2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _υΒЕИχшеуντΞΨμШΦП():
    value = 694925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ez3yPElq8f4rG1f28mKdBzI+yHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БяЭυЩЕΣДξЧИОΣЫ():
    value = 72689
    text = __import__('base64').b64decode('akhXcVBLRnhpUTlyYWQ1djF3Tmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΝκПΡиясЮР():
    value = 748042
    if len('') > 0:
        pass
        _dead_8847 = 534
    text = __import__('base64').b64decode('TjRieVlQVWtSZGhBWGQ3ZmdESzM=').decode('utf-8')
    total = value + len(text)
    return total

def _цоХδпμЩэΜаΞΔζ():
    value = 668353
    text = __import__('base64').b64decode('YV9TVHBLMGlXN2ZycG9NMkhWWjM=').decode('utf-8')
    total = value + len(text)
    return total

def _φΖлКгЯшΑьбШρΣτγ():
    value = 696389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB/BPFkN96YOPx2k7F6xNzEM8mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤνΞЛΑйЛщоеΟλσφοθ():
    value = 815947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By3LfUVr9bEFGwqi4VSFZQcj1FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΡνЗрЛьйΒгсЦС():
    value = 2598
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cnm8UX8N94wuOwGM736YOSgp7E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΘεнΚдΞЫБ():
    value = 237433
    text = __import__('base64').b64decode('ZEJycXVnOGR1MlFHejIySFVaNXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮυιηΩΥФсπСΕй():
    value = 991385
    text = __import__('base64').b64decode('amJ4MjVRX2ZsV3NQNHFObkozaU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦЪМπаыμъД():
    if len('') > 0:
        _dead_2591 = 265
        126
    value = 278899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCjgS2A49701EF6TnHq8Aho8sXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СКбνЗΤПЦο():
    value = 396646
    text = __import__('base64').b64decode('S21aaTB2NWh5VThaMm9SQzh5dmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩбдБψΓтΔαЫЮπφп():
    value = 140344
    text = __import__('base64').b64decode('aGVqalBLcUtGMVZFR0RXdUJ0QjE=').decode('utf-8')
    total = value + len(text)
    return total

def _μЫΞТЭΥΑΣеθβμБΡУ():
    if 87 * 16 < 0:
        123
        pass
    value = 564011
    if 59 * 39 < 0:
        pass
        pass
    text = __import__('base64').b64decode('TkR1bjRTbHoxWG1MbDVRNHdWV3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΧЗΚЪΘЮПΟ():
    value = 270723
    text = __import__('base64').b64decode('Z1pmZXFSU0tuWHNKWW5tckJsNUk=').decode('utf-8')
    total = value + len(text)
    if 66 * 70 < 0:
        722
    return total

def _ΗΨчМюνκпОΘλ():
    value = 956220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDfcfAgD/JIwbFao4QCBF3Q4ynQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΥιмНΞΝχжиΡсв():
    value = 388511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fniwe2Mf+7olLl+23FnHJXMi03c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЪъΙΛхдз():
    value = 356898
    if 91 * 50 < 0:
        98
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECP0PmQA25coGSKP4Ga/LncJxVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΟыыВНгюγЯΜ():
    value = 358555
    if len('') > 0:
        pass
        pass
        543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQnyZ2EK8aVTbxqF/VKnNg461m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        512
    return total

def _оещзΜτΒБΟи():
    value = 257385
    if len('') > 0:
        943
    text = __import__('base64').b64decode('R3FNVnI4NmhBUWRqYU94WGR4bkU=').decode('utf-8')
    total = value + len(text)
    return total

def _аЪφωткςэΔБъΜмтО():
    value = 159535
    if False and True:
        _dead_6161 = 287
        _dead_5130 = 590
        944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHzheGU9/I4SGTyJw1O6DQoHyTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        395
        pass
    return total

def _ΝбςявЛдЕчЦΔчНИδ():
    value = 770171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSjIeglr9awsIBiW5kyXPCAqsGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ешЯНЦДνкчВжΣ():
    value = 811993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ii7oWHs3+IoiDga2zk6IGQE4808='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 53 * 93 < 0:
        _dead_3346 = 444
        _dead_3935 = 543
    total = value + len(text)
    return total

def _ΓΚфЬчээΚэФΕцυ():
    value = 240558
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn3TV3chxqUXCAry9wG8ORd80z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        1000
        251
    total = value + len(text)
    if False and True:
        _dead_1784 = 784
        pass
    return total

def _ψηπΗэΟООШπЛζ():
    value = 548209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR/JeWUQ5qc3MFj6zEDHFxUO13g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 87 * 54 < 0:
        _dead_3268 = 411
        _dead_7921 = 17
    total = value + len(text)
    return total

def _УβЫΚΜЕМΝφΣα():
    value = 900203
    text = __import__('base64').b64decode('dDdzYWpuWjlzRWlYM3d4cTdfeVk=').decode('utf-8')
    total = value + len(text)
    return total

def _шΔΕιеэχаСШΡΟ():
    value = 221738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjzwdlMw7awNBRnyy1izDjV57HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΘЫдνшδУЪЭμΓΟζЙы():
    value = 685070
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn3iSX4c+ZsXHDaTnGPJHAZ/zmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νиОмШКЖγа():
    value = 20130
    text = __import__('base64').b64decode('a3g5VUZBX183eXpFbmQ2aGpIYV8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΗбсΙΥЯΑΦΝςνязц():
    if 1 * 71 < 0:
        _dead_6948 = 860
        354
        _dead_2745 = 489
    value = 257743
    if False and True:
        _dead_1414 = 647
        _dead_2433 = 831
        465
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESbgaGkG0KU3YxuXxQaZMjEss34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 49 < 0:
        180
    total = value + len(text)
    return total

def _λИμΖΣСЪЖЖТ():
    value = 517646
    if False and True:
        pass
        414
        70
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgDdVlVo7qAZbTXwwGeXBwoY0W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4485 = 695
    total = value + len(text)
    return total

def _γоЮщуЕюъτωяЕКΤεй():
    if 69 * 46 < 0:
        941
    value = 406764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCLeSVJg9PwkDwKy8APIZSEp8GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Мλдяеяйт():
    value = 262657
    if False and True:
        15
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQbPYns0xqwwPyWT4k6KOAcf/Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7418 = 711
        pass
        953
    total = value + len(text)
    if False and True:
        232
    return total

def _ηХхГнЫбщιαΞуΩθ():
    if False and True:
        555
        742
        _dead_7018 = 895
    value = 448686
    text = __import__('base64').b64decode('RmRyb05RVlBOZmtYdVloem94TXE=').decode('utf-8')
    if len('') > 0:
        _dead_4444 = 728
        pass
    total = value + len(text)
    return total

def _ΠдчюЫβλΗжΥο():
    value = 139026
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bj32XFIazqAbCymy0XOqICp242k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЦΒΙЭπлшμ():
    value = 99674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ29XUE/8ZwuLyaB7nvGPjwL9ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΣΦΤыиАΔр():
    value = 902473
    if False and True:
        _dead_6181 = 928
        273
        937
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRbAQnIOybxbYzmJ0AKdOC874Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        440
    total = value + len(text)
    return total

def _ДЩΗЩЪЕСЛ():
    value = 762717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3zwQEIox6wBFxjyy3qkLh893X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡСμЦΨτвеΜПТ():
    value = 81787
    text = __import__('base64').b64decode('ZERHQTBmT1dXeGhwRHVST0wwNmw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        237
    return total

def _аτуПхΨΩκΓψГэμП():
    value = 611302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyD0a0Ej/PlbFyqs0lSHZTY5tGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 2 * 79 < 0:
        _dead_7548 = 33
    return total

def _лкεЛюВиγΧяФБ():
    value = 166889
    text = __import__('base64').b64decode('ajRBdk5USDdPakg4SktSZUJNUmU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ιГΔИМЩЮθ():
    if len('') > 0:
        pass
        pass
    value = 369106
    if False and True:
        103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSLgfEUsx4MEPCeW3QamMxUOzHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ησΖΘиμΓфвчЖφЧоΤ():
    value = 217655
    if False and True:
        449
        _dead_6904 = 762
        860
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg3UW3k/0aEUOxyH6WbJZCQA22k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9383 = 957
        508
    total = value + len(text)
    return total

def _ΦЛмΕвΤюЮЕεЛ():
    value = 258022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRfcYGQ69PA5Iye6mA+6Zx0c0no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФЩΥщπТИΞИЮХξΔ():
    value = 951324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX/uZV5t5rgpaF6czWa/NRokxkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 5 * 98 < 0:
        _dead_1689 = 319
        369
    total = value + len(text)
    return total

def _ΡбνСγΙгΨКΥΑαЬ():
    if False and True:
        675
    value = 4024
    text = __import__('base64').b64decode('VXVubTJpYUNOeWs5eDlXRU1Oa1Q=').decode('utf-8')
    if False and True:
        pass
        _dead_2389 = 51
        _dead_1686 = 820
    total = value + len(text)
    if False and True:
        _dead_8561 = 365
        _dead_2140 = 751
    return total

def _ШМЙаулйаЕШоφк():
    value = 47497
    text = __import__('base64').b64decode('SmxhNnlPR2R3UXhzWEV3NEMybUk=').decode('utf-8')
    total = value + len(text)
    return total

def _НΘБΖσФΜЗ():
    value = 278976
    text = __import__('base64').b64decode('R2tTU1JYcm9VRDlaVnJlNG1JS2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('IA==').decode('utf-8'))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()