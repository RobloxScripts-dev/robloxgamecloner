#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΩТЪПДйχΒаΖа():
    value = 48528
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATXtUUcLxroAGSix332JCwgg7T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΖЫΥаΩКчτШвЙу():
    value = 218778
    text = __import__('base64').b64decode('ZjNaWGtoeXhGSER2VzhNbjFZaUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЗДКΚНЧκυ():
    value = 461183
    text = __import__('base64').b64decode('WUd6d05EQzhzY3NfM2dOOThRVVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑВеΡΓκнΧχФкφΡΜжЗ():
    value = 65494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICbJXnk1+4tbN1er8QC3IXA322k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яэЮΚюЦΛц():
    value = 27320
    text = __import__('base64').b64decode('aktNNFRza1dfRlFUVzZUWnhGWFo=').decode('utf-8')
    if len('') > 0:
        285
        pass
    total = value + len(text)
    if 91 * 60 < 0:
        _dead_1478 = 83
        731
        _dead_8020 = 666
    return total

def _эыЮяΝЦΚъυχйΕА():
    value = 276065
    text = __import__('base64').b64decode('aEg0ejJQMVZfckZCUndYR2hNaWM=').decode('utf-8')
    total = value + len(text)
    if 39 * 27 < 0:
        883
    return total

def _кΩΔΩγλζцδб():
    value = 998310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSa2OEEN1aYKIiqn71eyBXMi4F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _беαθΝρФЬдсΞбв():
    value = 163010
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LD7ATGkL2vs7LgCF0GSXZwgQ/Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗθаБвΧажοслΕ():
    value = 13519
    text = __import__('base64').b64decode('YldyZVBVaEN6ZVo3YWJGRWMzYkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝХΜσкθΤЭΟяΑЙΜτвВ():
    if len('') > 0:
        _dead_1158 = 571
        14
        _dead_1950 = 216
    value = 782003
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CijsWF9h6K05YwCaxH6eJHEc0T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4879 = 1000
        pass
    total = value + len(text)
    if False and True:
        682
    return total

def _ДΦξывЮЮЧζэЭΝДм():
    value = 829737
    text = __import__('base64').b64decode('SkpOYURPY3dNVmdud3dyWHVLMng=').decode('utf-8')
    total = value + len(text)
    if 90 * 38 < 0:
        _dead_3839 = 457
        pass
        pass
    return total

def _ΛАвΡАПσжрсΝЯиэΚз():
    value = 694154
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnbsaWILr7sCKT+BwgGVY3It/nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        238
        _dead_2146 = 399
    total = value + len(text)
    return total

def _ΣУэЙεмγРМΙЪπ():
    value = 580316
    if len('') > 0:
        749
        _dead_7720 = 216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3fiRlM6yqtUNFma4UOiOBorzls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛБтЮНΓшΥЙКЖОтГН():
    value = 793474
    text = __import__('base64').b64decode('ZWZ2Qk9nemh6ZlFNRklteEM0S0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ωАεхьηΦΣΣХуιеερЫ():
    value = 827490
    text = __import__('base64').b64decode('SzV2Q3l1b1Q1dWxrTHlKMlpmdUY=').decode('utf-8')
    if 9 * 5 < 0:
        _dead_5889 = 209
        pass
    total = value + len(text)
    return total

def _лΣαМγАМρΗνЫЙИΘФБ():
    value = 465381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB7vW0QNxPoQbQCu0l+AHnYlvFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΜчΗΑχψΔςφЪΛηЧΩ():
    value = 708399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCnTRHwvqacmDRqCkV+FDBIX5UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 82 < 0:
        484
        970
        _dead_2761 = 596
    total = value + len(text)
    return total

def _гδХρпΒΧчй():
    value = 743663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSWwOn0Y144OYluPxQ++Ghc50ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нπψуяИΨыεМНΛΩξБ():
    value = 248221
    if 53 * 85 < 0:
        _dead_6915 = 896
        _dead_4632 = 784
    text = __import__('base64').b64decode('UTJoOEpBb2VrQ09iaDhKWUdRN20=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΨЫφфΧсФн():
    value = 822689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnjwXQAMx447az+00nHJBHM27jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξхξжςЖжμгΨк():
    value = 722656
    text = __import__('base64').b64decode('c0ZBMkx0UDlTeVNBNGlNV1VLY1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ελФГЧΒлοо():
    value = 589928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCX8XwQ4qKYhKBeW5lmEOHMIw1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜвΣрНЪЙΟшлΩΜιи():
    value = 543030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgnQfWsuzKICPyW38Hm+Nh146Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΖЛэΤξсΧЭрΤеκθ():
    if 44 * 18 < 0:
        pass
        pass
        pass
    value = 117203
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQ7waWgc65srbRaHm1iWbD8N6ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        622
    total = value + len(text)
    return total

def _ИΓυβφΓьΠМф():
    value = 970614
    text = __import__('base64').b64decode('YnlFcDRvX3k0M0pIVHp3T0xjTlI=').decode('utf-8')
    total = value + len(text)
    return total

def _ξТьΟИψΨП():
    value = 507267
    text = __import__('base64').b64decode('VlFGVXFJaHFpQUFmVVBNd0VvMGM=').decode('utf-8')
    total = value + len(text)
    return total

def _дνиаαΕьзΙЙоΡμ():
    value = 110100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgnQWV4j7vk2Fgn0mW62PRw3yno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εИЭкγςωΖρΕщжΕР():
    value = 911108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3jHRH4p94YTaD+p2HGJNXN30WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗпσΩШЕиτΑΙфИШ():
    if len('') > 0:
        pass
    value = 202255
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InnVRlUqrv0CKD3243GyMXAosDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        281
        _dead_5149 = 643
        _dead_7398 = 400
    return total

def _фнαрΓЮΛΓ():
    value = 436670
    if False and True:
        pass
        309
    text = __import__('base64').b64decode('aFBOb3BPTTU4TXVzVDF5ckpfZWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _щΩоαδЙμοΠυЯβΔφ():
    value = 19822
    if len('') > 0:
        _dead_9636 = 571
    text = __import__('base64').b64decode('dmhTN1BPWXE3VHppMmNaZHRTWHA=').decode('utf-8')
    total = value + len(text)
    return total

def _йюуζξεШЬЩЧлΝξτъ():
    value = 22533
    text = __import__('base64').b64decode('TWhscGFic0s0YzBiM3ZlaHZ0c0U=').decode('utf-8')
    total = value + len(text)
    return total

def _бЧιтИπτκЙνΗ():
    value = 581956
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgbTWVls34MRYxWr+lClGg82/GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7201 = 849
        _dead_3045 = 504
        pass
    return total

def _цΙΚφψδΝиЯΗУУι():
    if 79 * 6 < 0:
        _dead_9836 = 215
    value = 828926
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAfPSHpozo0uCCaT+kCDOAEQx10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_5390 = 1000
        pass
    total = value + len(text)
    return total

def _зμολКБΝοςсγМцω():
    value = 907997
    if 47 * 65 < 0:
        pass
        pass
    text = __import__('base64').b64decode('SUo5NUk3cnFUbGd2dExJemZBU0k=').decode('utf-8')
    total = value + len(text)
    if 61 * 57 < 0:
        pass
        _dead_3244 = 713
        153
    return total

def _ψшщФщΤΩΔюιυэφ():
    value = 90922
    text = __import__('base64').b64decode('dnVxYjVkTVcyeGpmVmVueDFkekg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬБЖлЪсΓе():
    value = 866817
    if 94 * 38 < 0:
        pass
        _dead_8947 = 974
    text = __import__('base64').b64decode('UUVyc2pFeGVKTkhCbzZseUZ3MTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΧчСШЭςЯЛθГюнο():
    if False and True:
        551
    value = 939328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiPHd24X7J8tECuN5WGzOyMBzD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖАχЬЧΔеДТΝъШ():
    value = 430973
    text = __import__('base64').b64decode('VkVTc2h0RzJsQ2JSWnk3bFJ0ekE=').decode('utf-8')
    total = value + len(text)
    return total

def _ωςуυЧпВδжνΩд():
    if 19 * 6 < 0:
        187
        227
        _dead_6324 = 702
    value = 362375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgT+YGQT6/omNlmHxASBGQQnwH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИЧЛЪΞХгРχμЖгХиσΧ():
    value = 767669
    text = __import__('base64').b64decode('bmJ6dGdEUG50QTNkd005N0tmZ2c=').decode('utf-8')
    total = value + len(text)
    return total

def _пщЭуΦгДэ():
    value = 230788
    text = __import__('base64').b64decode('WG5WX0VkX2RIb0pHd0JnZGljR1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЪпχЮχωΣгОι():
    value = 475734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjfLPXAWrJE6Kj+CmnK3YS577Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρДъΝТΨΕК():
    value = 630015
    if len('') > 0:
        234
        392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NA3XYXMh0qETYgKy8EGVJDcWtmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φхκμπЖбζФЯШφщΩψΥ():
    value = 62641
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwzoV0ccwfFRKSeNzgKYO3Q1s3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦьιΟйъЭфΑЩЭωΔЙΒΠ():
    value = 812630
    text = __import__('base64').b64decode('djB0aG42TG9fclo4bHc0dUljcjY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        378
        670
        pass
    return total

def _рФΖшяΑυκоΧПγΡ():
    if False and True:
        pass
        pass
        674
    value = 917874
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgHteQk8/JwbC1+p91rDbAJ5zXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЬрЛЪννЙ():
    value = 777669
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B37uYWQAp5sLKjCQkQeSDB0F7Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эγμςвдιеыζΤыΒхд():
    value = 498266
    if False and True:
        145
        _dead_1633 = 253
        265
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQXlW10Q2vAqHDCyn3W1GQkn5lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7919 = 761
        pass
        _dead_5121 = 886
    return total

def _иΠΨфαИΜэрЫ():
    value = 819867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ai7nSHA95JgVCg6axH7EMD940lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΜςΛГяηψЮΩΡД():
    value = 597226
    text = __import__('base64').b64decode('ZDlTOE1kSHdhSnJDY0h3X1lnakc=').decode('utf-8')
    if False and True:
        383
        _dead_9933 = 167
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_3064 = 869
    return total

def _ечЗΞνлθохρШΚω():
    value = 919446
    text = __import__('base64').b64decode('b3E1cWt3TDRpd1pxbGY5dHUzRmY=').decode('utf-8')
    total = value + len(text)
    return total

def _θЫοЬМгсцοБΜ():
    value = 260020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz/KRlg9qK4CY1+X2m+jHTU37mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬγйЧμΒЖщоζи():
    value = 716638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz3hZ2tg6fEKDyKs2l2mExx34Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГйПЕхχωθЦκηΕИХ():
    value = 642923
    if len('') > 0:
        _dead_4201 = 494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwPIWAMb0bgXbA36/WWYPSgi1Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1437 = 953
        pass
        _dead_6172 = 87
    return total

def _ооβОМнУАεΤБ():
    value = 76636
    if 78 * 25 < 0:
        859
        647
        _dead_8973 = 579
    text = __import__('base64').b64decode('U280ZzgwRm0xSE1xZkhsVjZlSzM=').decode('utf-8')
    total = value + len(text)
    return total

def _лΧйЮΞнτΠБЫαЮдэζ():
    if len('') > 0:
        pass
    value = 762168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CifnbWgqqKs3Fxyu/1ufBgcAwW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΩСΔХΝοδθ():
    value = 316353
    text = __import__('base64').b64decode('YlkxUTRFVnRnRWhEUzNoX2pWWDc=').decode('utf-8')
    total = value + len(text)
    return total

def _жВψдчцδΤζхЬΞХΣ():
    value = 649105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwniPkkjrIExBSOXyl+RETc902M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣлЗааУЩσЫЯтΔюй():
    value = 691053
    if len('') > 0:
        pass
        pass
        _dead_1183 = 913
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDrnbwE634k0EAya3H+dZSp85V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        444
    total = value + len(text)
    if len('') > 0:
        _dead_6957 = 283
        844
    return total

def _ΓъΧЙвЯωωЕ():
    value = 97695
    if len('') > 0:
        _dead_2587 = 327
        802
    text = __import__('base64').b64decode('SzdUVFpPYjFjYmE2aURseENWVU0=').decode('utf-8')
    if 64 * 27 < 0:
        1
    total = value + len(text)
    if 65 * 23 < 0:
        pass
    return total

def _ΣгСэлπоСυЖεчКγС():
    value = 628674
    text = __import__('base64').b64decode('dlR6ZjJnQW90T1I1cjJKOFhzVXA=').decode('utf-8')
    if False and True:
        330
        795
        _dead_3337 = 222
    total = value + len(text)
    if len('') > 0:
        _dead_1967 = 756
    return total

def _ФγΙРирΗТшζ():
    value = 498087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSzsdAQP1apVYh+am065PSsH9EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιωВвηΟυЧζХчΔяБωу():
    value = 63490
    text = __import__('base64').b64decode('bEVPMkxvOW0wUmFUNDZzVUdxNDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ξеГдΘшπякκε():
    if len('') > 0:
        pass
    value = 243275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7Pb0Io95gtPjmlxUPAPHYn9zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΦОΛпσАζощннψй():
    value = 374425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwTWe2hu3I4mazyU5XyYAgs3zGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЧВψШУΥςБ():
    value = 41900
    text = __import__('base64').b64decode('eHJZUDN4OEJCUkVnTnV6TDkyZno=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΝыАΞΜοцВδЕЛρ():
    value = 886945
    text = __import__('base64').b64decode('RFc2em5wZEpRV21CWEh2NElSYzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖςэΒζτцЗЧЩΒβ():
    value = 561751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jg3dSQI/1LtQCTen3AWyBC4J4Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΕЫаΑРΩхМК():
    value = 898312
    text = __import__('base64').b64decode('QXdpdXlDU2psT3MxYUZsTkw2b1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ОоЛйюДФО():
    value = 419344
    if len('') > 0:
        906
        _dead_2881 = 717
        _dead_3419 = 343
    text = __import__('base64').b64decode('a3JkOXRwV1hlVUJRSTRaRDA1R1I=').decode('utf-8')
    if 51 * 67 < 0:
        288
        496
        366
    total = value + len(text)
    return total

def _УйηΗδσπθ():
    value = 533956
    text = __import__('base64').b64decode('aG9kUnZUaHBMMWM3MG5sNDlZV3k=').decode('utf-8')
    total = value + len(text)
    return total

def _щцτπйАЕΠΝΑΜРРЬΦ():
    value = 487508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E37VRmgo+4sUFxz0+UG3BjJ9snY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        836
        pass
    total = value + len(text)
    return total

def _ьθЖЦьСζΖΗтΠтλХф():
    value = 743780
    text = __import__('base64').b64decode('VGZ0T3l5TlV3TTlibkptcHF1aU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЖθГЪыωщхμ():
    value = 754862
    text = __import__('base64').b64decode('VEFSMWEzVE4zNUxVVVVQNkMzblo=').decode('utf-8')
    total = value + len(text)
    return total

def _бчΠτΞЧОУζ():
    value = 504064
    text = __import__('base64').b64decode('SXE4Z2VFSE4yb2dITUN0SkVGUmo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝДяПλОΦΞΕРς():
    value = 267380
    if len('') > 0:
        _dead_2609 = 341
        pass
    text = __import__('base64').b64decode('bkEwYW5XN2s5Nmx2aHBYYVlpMm4=').decode('utf-8')
    if 19 * 31 < 0:
        487
        _dead_4728 = 667
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_2285 = 139
        _dead_9400 = 48
    return total

def _бΣΧцΙΡοфεрΝжи():
    if False and True:
        _dead_3599 = 874
        415
        _dead_9350 = 928
    value = 87453
    if 18 * 98 < 0:
        _dead_3706 = 897
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiHWa0Yuza4GACOJn3eJLCA3x0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_2314 = 488
        672
    total = value + len(text)
    return total

def _ХΧΚЙΙηΝμΚ():
    value = 397659
    text = __import__('base64').b64decode('RVVMYUxucTVSaHA5bkR4WlJCMnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _лПоКВИηΡШκκжыЦ():
    if False and True:
        pass
        pass
        pass
    value = 531543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICDJenA4xL8NPguszUypMQIK1Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΠПρΣθТКЮΠшсσСМш():
    value = 408932
    text = __import__('base64').b64decode('VlFIQnRtTEZxbHhnYzVKYXpHdlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ζХоοΜΑМΘυФЮзЭсμ():
    value = 386958
    text = __import__('base64').b64decode('VjhvWndaY1BjTHJRMTk3Q2VIR3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫДΣΚЫуοθВΧκЖζ():
    value = 826831
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT78TFMW3b8TCzC3mmyUOxYM4mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΟΗεВΟмАι():
    if 75 * 93 < 0:
        _dead_2583 = 882
        927
    value = 210529
    if False and True:
        pass
        191
        793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAu1NgFr0oEvKB653FOKGhIV1jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εпεЖΞЕЙΩЙΘτлиьс():
    value = 204493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRi9PUke6oNXCQnxzg+HFSMawkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if 54 * 2 < 0:
        _dead_3281 = 23
        _dead_5749 = 884
    return total

def _ζИГυωΤαΖы():
    value = 892783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhfLeVsJyfwbMhmK5HSnIwwryUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рζΥεΚЬΙззЯФΘы():
    value = 798668
    text = __import__('base64').b64decode('dDloNTNiaEpoYnNoRlEyTENZNXc=').decode('utf-8')
    total = value + len(text)
    return total

def _нйъпΖαζм():
    value = 766559
    text = __import__('base64').b64decode('YmtyV2I0SnJ4eEhpVmdwZE5zX2g=').decode('utf-8')
    if False and True:
        2
    total = value + len(text)
    return total

def _ΠбХΓΤцкКεΝшΥяΔ():
    value = 584289
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Myvna30p/Zs3YhaP8FivNg0o72Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψιΟЩРξцυЯΟЫσыΚБ():
    value = 478982
    text = __import__('base64').b64decode('WUpmbTJUOEhCQlFJZHYyRnF2dU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥςΧШаΙΔΜΛБ():
    if len('') > 0:
        pass
        862
        pass
    value = 51481
    text = __import__('base64').b64decode('bDhhMDE3WWNxUjlUT2lJc1NBRFM=').decode('utf-8')
    total = value + len(text)
    return total

def _сЖФзуаπΒщΖωчεζГΤ():
    if 50 * 42 < 0:
        _dead_2478 = 904
        _dead_7941 = 821
    value = 175991
    text = __import__('base64').b64decode('d1FaUUJpdVlBU2laT0N2MnVtdV8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЪΜκИФЭΦФиЦ():
    value = 824664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzazamFh3KUgYjmKwA+kbCF+xW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иπΙтΠΛХρыЮЦЧгΘЮ():
    value = 30165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQXCPQcb5KMXPj2w3GGaCyo36kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΗδРΘγчΦЯ():
    value = 253853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JATQd2Bg060zDQ6p8g6mNwYox2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧжюнтЙИαыЯЪКμΦ():
    value = 686421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fh32WQQJ154CHyiz43KEbDR//ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 54 * 88 < 0:
        _dead_6079 = 892
    total = value + len(text)
    if False and True:
        112
        pass
    return total

def _ВΑΦΒмξчыυклΥеО():
    value = 605067
    text = __import__('base64').b64decode('ck9uZlliSDVVeE5fd21nd1FRZ3c=').decode('utf-8')
    total = value + len(text)
    if 67 * 63 < 0:
        pass
        927
    return total

def _ΘΩгЯΥзьγЩΨЮΡЛЕ():
    value = 747201
    if 87 * 61 < 0:
        pass
        pass
        _dead_9983 = 386
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Exf0VAhr8aBUaA32n1WAICMd118='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 78 * 7 < 0:
        71
        348
    return total

def _ТΒНπЦъςжЧ():
    if len('') > 0:
        429
        886
    value = 883752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IArKQnAK96ElGT6AxlKkEHIQ1Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λοΘаъайЬяΒКВВ():
    value = 353663
    text = __import__('base64').b64decode('RW1lYjZOYnNpUGZZWkp1MFc0UnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΨЩяΗκмвРδк():
    value = 973600
    text = __import__('base64').b64decode('UFdVNklTMkZ5dUlNSUROeFREVG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ιДиМФζЦцУсщЯη():
    value = 730592
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHrbZVo/+5o8FgK6+kGCLh8l1EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЩРΛφпΒπпСЕф():
    value = 738200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzfQUWA477subwKay3HCDjR/wXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тчμъВωΨμΛЩО():
    if len('') > 0:
        129
        _dead_3106 = 659
    value = 501973
    text = __import__('base64').b64decode('c3R6MUxDbDNLbFUyNDRDV25aRDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΝЬзαΔςΣчΤεμф():
    value = 819010
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzfoRV4oxqIuEiP64XrEIBIj03w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 71 * 15 < 0:
        pass
        843
        39
    return total

def _ОЩΞБΕфюΩСК():
    value = 712238
    if False and True:
        _dead_4905 = 502
        55
        630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESHXf2MyrKdSAgn091emBikt7Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗиδНΗЕрεйцмυиρζ():
    value = 451717
    text = __import__('base64').b64decode('UEtZV0VkdUptcWhFNFdsNjg1Nkg=').decode('utf-8')
    if len('') > 0:
        _dead_5833 = 592
        pass
        562
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΩωНХУΒЦζΞЙиЦγ():
    value = 735495
    text = __import__('base64').b64decode('VFlkempkYUx5b1QyV0tWR0JpSzg=').decode('utf-8')
    total = value + len(text)
    return total

def _эНШйΩλΜβхбλΦ():
    value = 329400
    text = __import__('base64').b64decode('anlsazg1WG9oUUFRRHJra1dmMFI=').decode('utf-8')
    if len('') > 0:
        646
        _dead_7779 = 128
        pass
    total = value + len(text)
    return total

def _ΨЩыиΙΨюυεюδуΛ():
    value = 462442
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBXwRQgy55kCDz2Xm06mGHd+yk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЧзβνтИЪм():
    value = 531972
    if 15 * 91 < 0:
        946
        _dead_2944 = 104
    text = __import__('base64').b64decode('SnJXcUVnckdaRXdpWDFkRGRNaHc=').decode('utf-8')
    if len('') > 0:
        _dead_2021 = 80
        912
        680
    total = value + len(text)
    return total

def _тРφшжГОЬΦЮΥээ():
    value = 621195
    if len('') > 0:
        458
    text = __import__('base64').b64decode('WU5lOUZsUUpCNE8yUl9GRGRRMW0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2721 = 946
        892
    return total

def _λъρпΤИРъЩцЗΞПκ():
    value = 385796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCrcQkUO844rLiiTwWaaHwwf5zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦЫчτΠκζу():
    value = 410065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAazOmY9p5ARKjCQyX6yPj8Z8T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 23 * 5 < 0:
        155
        pass
        pass
    total = value + len(text)
    return total

def _еиЦΤшЛςИ():
    if len('') > 0:
        301
        _dead_2773 = 452
    value = 544583
    if 53 * 65 < 0:
        pass
        590
        686
    text = __import__('base64').b64decode('bXZuMEtGNjNmNXJIdWZpeXZQTlk=').decode('utf-8')
    if len('') > 0:
        _dead_7977 = 5
        _dead_8968 = 258
    total = value + len(text)
    return total

def _нуМРμΔετΤζΖцюθ():
    value = 725981
    if False and True:
        _dead_4838 = 141
        _dead_1227 = 251
        _dead_1593 = 185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Awa3Q1Id+7sbGFax0nqbPCB47Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПфαВЩЛμКЙЦ():
    value = 957099
    text = __import__('base64').b64decode('Vm1RUWZnMGlzTjlTWHZlR29lb3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣЬσИΝΞАУэхжΨНζΨΞ():
    if len('') > 0:
        pass
        pass
    value = 691021
    text = __import__('base64').b64decode('RUU5U3NvcWozQk52anRqVVVCZ0s=').decode('utf-8')
    if False and True:
        186
        866
        15
    total = value + len(text)
    return total

def _БΦмψχПютЯ():
    value = 654858
    text = __import__('base64').b64decode('R3BEajducFlubldpbDN2MzU4WkI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _δυзβЧКзφ():
    if False and True:
        pass
        pass
        803
    value = 130144
    text = __import__('base64').b64decode('bDAwcVpKUFNGRHV6dTMyN25sckE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЯНСΟшОощωНΙ():
    value = 334373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHnCXnof7YUmaQuAm1mSHnUA43w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        871
        _dead_4513 = 393
        _dead_2170 = 335
    return total

def _ΟλЮφкΓФаγцЯ():
    value = 603977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXbhem4tz5cwNxiKw2eqOSs87Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΗиγТξэΤ():
    value = 502320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jj/FXXoUzZ9TEBaW8mOJDHx93D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        32
    total = value + len(text)
    return total

def _якГΧΟуηςΠыΤяН():
    value = 299159
    text = __import__('base64').b64decode('WU10Y3M4b3NmS2dZdjZHRk1qRnM=').decode('utf-8')
    total = value + len(text)
    return total

def _δξйΕΛВιфΖΒΖЯЖψΡτ():
    value = 604915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyK8Y34K77kgIj3xwVeWOCE8yXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υдСЕγоВтΔы():
    value = 58314
    text = __import__('base64').b64decode('azNmYUhQV2JUQXR2dEg1bXVTRHU=').decode('utf-8')
    total = value + len(text)
    return total

def _мПЧыкΧцβтτ():
    if False and True:
        pass
    value = 937523
    text = __import__('base64').b64decode('UWZuMF9iUDFuSmFQWXNhQUIyNUc=').decode('utf-8')
    total = value + len(text)
    if 96 * 9 < 0:
        pass
    return total

def _ьСΚЪΑΤюсШσ():
    value = 8873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgTCWGMV7pk7bSCr5XiBAnIWzjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χуьМΦγЩφГρР():
    if 73 * 93 < 0:
        861
        pass
    value = 352814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCnqYAEPzo8ibSmz+EG0JCw7vH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΜξκТΡΨΨθΨ():
    value = 633258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRDjTW4P0408KwiLn2meGnN93EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЦΖяшиΨКψξМф():
    if len('') > 0:
        _dead_4261 = 824
        _dead_5708 = 670
        pass
    value = 194523
    if 22 * 46 < 0:
        _dead_9010 = 922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhbGWnsYraMCFyLz50OmBwkt/Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΨΙθΛηНРξнЩшъМΖΠъ():
    value = 819973
    text = __import__('base64').b64decode('enEzcHBlamNHeXlQWHlqcURiSTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΧηηЩьΙхЙамξ():
    value = 91410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhrzfFIx+5gUIiHzzg6zPwo84UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΧялсШπσЖβςΤζΑТ():
    value = 691821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DinrO1wAq7gKGyGPnHG5NXMqwEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        482
    return total

def _ΔΓяΙЖΜтЗНφлςΠ():
    value = 243848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxmzQUkB3b0KYyen70SCZRcMwV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БиχфξвαэΡΓТΘВΤΙ():
    value = 344253
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx+xSmgrr6cOOwuq4GmzOHA85Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рДцγфΑАъШЩθ():
    value = 312511
    text = __import__('base64').b64decode('aEZ0VkV6QVhXUnBScmh3cVZaUHE=').decode('utf-8')
    total = value + len(text)
    return total

def _σчэΜЗЭБЧΨУБαрζйр():
    value = 714691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxnrQwgX+qQ2DiWK3AC3GycD514='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠшЪγлλΚΝДπБφЛТуШ():
    if 27 * 11 < 0:
        _dead_2157 = 944
    value = 924426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETnhNng807IrGxiT8nq8MAoi61Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эжЗσβУНΙρΜфшЦмфΨ():
    value = 985734
    text = __import__('base64').b64decode('SkdMQTBDZVB1aUZ6MWpkNndoOFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ШэхβΥСЮРΛЯξЖмн():
    value = 368203
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgjtPkks5rBUNRb25FCAGn0O500='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9860 = 665
        pass
    return total

def _σХμΞцЯКННμмνхΠЮ():
    value = 845885
    text = __import__('base64').b64decode('WFN0b2lnREtUYldiMFVuejdXMnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΒαΘДюСЯαчлΚдΚ():
    if 63 * 7 < 0:
        _dead_9617 = 937
        pass
    value = 876529
    text = __import__('base64').b64decode('ZjU1RFBKRjhmRW9wa1hrc2IzNEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ιэΥыφтΕыюωΜΟэΦ():
    value = 613728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCrASHg834sXCgawmnKjICQ4t0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        532
    total = value + len(text)
    return total

def _ωΤМψпНОШИРМИИФмр():
    value = 387111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyjFdGIGz4UIMzyQxlGDBS4I9lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βъдоΣυэХТςΙБип():
    value = 182469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBbhWXku0vk5Ej+k6Vy9IAYWy2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВдЫШЕюфΛΠλбК():
    if len('') > 0:
        _dead_1906 = 136
    value = 559671
    text = __import__('base64').b64decode('bEp6ekJDbWtyMXZHdnl5MVBvU2w=').decode('utf-8')
    if False and True:
        32
    total = value + len(text)
    if False and True:
        _dead_4122 = 261
        _dead_8095 = 371
    return total

def _ρυζψдОωМйШЬΗΞξЦ():
    if len('') > 0:
        _dead_1149 = 382
        pass
        625
    value = 778258
    if 58 * 1 < 0:
        992
        537
        pass
    text = __import__('base64').b64decode('eFFxcVhDYjNCOTg2NmJpb3BFVGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩзΗВНюτΠΟζ():
    if len('') > 0:
        132
    value = 32619
    text = __import__('base64').b64decode('RTVmYnBUR1JrbGFJaGRaMHpqczc=').decode('utf-8')
    if len('') > 0:
        648
    total = value + len(text)
    if False and True:
        _dead_4880 = 930
        _dead_3264 = 228
    return total

def _РγЪηΦЙцч():
    value = 506701
    text = __import__('base64').b64decode('bzVpZlZNZUJObkpBRFh4WEZkV0E=').decode('utf-8')
    if 76 * 100 < 0:
        753
        356
        506
    total = value + len(text)
    if len('') > 0:
        249
        pass
        pass
    return total

def _ЦΝИйнγυρσЫГ():
    value = 298390
    text = __import__('base64').b64decode('UmMwRldxRldWdWRjcm5RTktQaFk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        499
        771
        pass
    return total

def _ТлвХрЮцβпρνт():
    value = 104752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnvXQ0Rs7YcNLAOR/kO8OHA2ymE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψбΑησΙвЯЬЕξλεЭю():
    value = 539546
    text = __import__('base64').b64decode('YTdqQzcxaUJjTlEwemN1dzEwVFQ=').decode('utf-8')
    if False and True:
        pass
        pass
        156
    total = value + len(text)
    return total

def _ΞηκнιΚЪλЙЪ():
    value = 69333
    text = __import__('base64').b64decode('bFVsc0poX3BsRXNaWUV4dTNtdFk=').decode('utf-8')
    if 44 * 86 < 0:
        488
    total = value + len(text)
    if 33 * 79 < 0:
        _dead_8573 = 997
        pass
    return total

def _ΜГΛпеνПΔЭσРΒяЭД():
    value = 81837
    text = __import__('base64').b64decode('d29WOG9jaUhhaE9ZajR4WENwdlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _бГРΕПщсъΡ():
    value = 728958
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3jNSmIY7aYbIia07QbGGRAo7Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕГρλМΒΜκιртΧАΚΠ():
    value = 516263
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSPSakUgrKUWLi6GmH6hYgQ2t0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШζυкνδхκΓμξт():
    value = 572595
    if False and True:
        pass
        _dead_9102 = 683
        pass
    text = __import__('base64').b64decode('Y3lMY0RpSUoydVFfUDRWUkkyZDQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΞΤζйзфусПафιΠΔВ():
    value = 415774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACq8OWArrpIvYwy1+VO8Di8szGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4486 = 398
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
        337
    return total

def _юΘшъЮъπеХНΖΔЫ():
    if False and True:
        pass
        338
    value = 247814
    text = __import__('base64').b64decode('bG1IaGRzeFZ0QVdsdER6NExDWWU=').decode('utf-8')
    if len('') > 0:
        _dead_9620 = 313
        _dead_5225 = 544
    total = value + len(text)
    return total

def _ЬΥЬДΦтιΟαсШСд():
    value = 657934
    if len('') > 0:
        266
        947
    text = __import__('base64').b64decode('ZnVfRzJreXUwSmxaR05nTFp6UDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟвЕЕОТжε():
    if len('') > 0:
        _dead_9493 = 522
    value = 875001
    if len('') > 0:
        _dead_7171 = 387
        _dead_4251 = 811
        100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw3cdksS0fsqIF6M0gezJzc69m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7208 = 739
    total = value + len(text)
    return total

def _ΨΟΚЛЯбаΓОзβ():
    if False and True:
        635
        pass
        pass
    value = 846548
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxzoPkRvqY8JNSW03FucIwJ7s3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        228
    total = value + len(text)
    if 91 * 68 < 0:
        _dead_4290 = 567
        pass
    return total

def _шХПΗΖЗжМυ():
    value = 988742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSfxbAEIyI0NEDeV52O/DC4+1W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _АщхΗιичηОΟξхмНЕΓ():
    value = 157759
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('TjJzeVBidkRtNm9RTmZIdE5mQjc=').decode('utf-8')
    if len('') > 0:
        777
        846
    total = value + len(text)
    return total

def _ΔυНУζСζΙε():
    value = 91457
    text = __import__('base64').b64decode('eGd0cGlpQjl2NVN5N0tRQU9CV2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ййдφКДγιΤΣмЯΗ():
    value = 838630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESrddFk834INFCD05nipbTA772k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эгΥВфψιЛΝИЪБП():
    value = 688429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjjHP0Uc0p0JIF+P23CqNT99t3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫлρΙьпΗУЯжχТЯюч():
    value = 614364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LT7OSkg7qbs6FyCPxX2FJzx58kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1584 = 998
        _dead_2382 = 408
    total = value + len(text)
    return total

def _ΖддΔκΤлмКЬЛθλТ():
    value = 912297
    if len('') > 0:
        89
        743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyG9UQUgpq88ICKn8FKbFSwB6k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7623 = 363
    total = value + len(text)
    return total

def _νэωвΘИΚМΗояεЩхЭл():
    value = 884003
    if False and True:
        pass
        374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQzMVggj0vE3PCao0FfIGQksw08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        434
        pass
    total = value + len(text)
    return total

def _ζΨπΧуДИпмшБΩЕθ():
    if 87 * 69 < 0:
        743
    value = 244946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTzBTQER2vsCO12i7mWbAxAqyX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЦθнКпьМДР():
    value = 499965
    text = __import__('base64').b64decode('eFRhazZOd3FLclI5Q1hQTGVYS0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΩЛЫэΞТΡфγ():
    value = 753319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjnBVwI/2vo6YheC0mWqPQEK4mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 75 * 32 < 0:
        _dead_2811 = 851
    return total

def _ЗГΖВЬтυθ():
    value = 842132
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aw3Qd3kS7L4sADyHzVWdPD98sG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        180
        _dead_5469 = 947
        pass
    return total

def _τΧУоΚДяОηКИΒΚ():
    if len('') > 0:
        pass
        pass
        476
    value = 798915
    text = __import__('base64').b64decode('UEhuQTZPdk11UmxFaHJpZkgxRGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗНйΦΚСΩνфνΙб():
    value = 232987
    if False and True:
        _dead_1191 = 138
    text = __import__('base64').b64decode('Uk1UbFZtcWgwSWpOMlZHUVh5WEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖοπЦΤтоГцггΠи():
    value = 159141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESriQXkpxKwPMAqbmwWZBwIj3UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΘлУρЙΗΝзеИΔйΙκа():
    value = 790889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQy3O1kVwaUwbyGa2nu5HyIExmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _деΟНтΠпθμАэνф():
    value = 94213
    text = __import__('base64').b64decode('cEFKOXhQOUVjVDVrWVhCVlJNd3g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        643
        pass
    return total

def _ЙΗδЖьςςλ():
    value = 68137
    if len('') > 0:
        pass
        pass
        102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bi3uSEUh3bkTFgOa2QO3PHJ3t0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΨиβγΦмТΖДγ():
    value = 1494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgPSPlcv0JszMjau7gKFN3QIyGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щЕЛКδКευюΑθΥΔΞψГ():
    value = 290074
    text = __import__('base64').b64decode('VEZrVEQxT2w1WHdMcHp0MENUb1U=').decode('utf-8')
    total = value + len(text)
    return total

def _БΖвснσψУчλбсШое():
    value = 637621
    if 93 * 15 < 0:
        240
        pass
    text = __import__('base64').b64decode('ZGNLdl9Nc21sbkQ1WnRPX0xhY2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΝхαςΔΗζУщ():
    if False and True:
        _dead_1258 = 122
        pass
        55
    value = 504100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiTJWgY96bFaEwnw+mDHMXYh10M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θπαВЯσΛΩчзЩεΚК():
    value = 16157
    text = __import__('base64').b64decode('QnNPeW5IWkdIZEhYMWxWNXZEN3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΛлΨΞсδΩВхвДНС():
    value = 794189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KynLSmYPxItQEB2721G5JRAhx0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΑНКВΨτЩЯцρΠ():
    if False and True:
        733
        148
    value = 720823
    if len('') > 0:
        pass
        608
        _dead_8853 = 503
    text = __import__('base64').b64decode('TlRTbTlGc1UzVEFQNG5kUXo1THg=').decode('utf-8')
    total = value + len(text)
    return total

def _тΣЪΔлξυУΟНКκч():
    if 87 * 14 < 0:
        pass
    value = 107270
    text = __import__('base64').b64decode('Rm92T1FTbUxjQ2lqUDRpV1Y4Tms=').decode('utf-8')
    total = value + len(text)
    return total

def _еΦГλμζЫВξμбφ():
    value = 635107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej7BXGsI7J8VABia/UbFNj0+sls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡИЧЫЩЖфИлОЩΝкшΦК():
    value = 239453
    text = __import__('base64').b64decode('d21VT0tvcU9jMHQxbEUyRHNfejk=').decode('utf-8')
    total = value + len(text)
    return total

def _оАЖГмЦμλрΓμсЮΖ():
    value = 637249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyD9eQZorb8FCjWpzQXGORcq0ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯςбЩΜνхсμΟΦ():
    if len('') > 0:
        pass
        777
    value = 824322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwztZmUD56sMAwqswke+JDc7yFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4665 = 466
        pass
        pass
    return total

def _ΘΕβΒрρЬΘЫς():
    value = 135192
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NC3CQ3VsxL0iaSWb/3O2MRIawn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΤΟΥфКЛοх():
    value = 322812
    if len('') > 0:
        _dead_6241 = 857
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwO8Olcc9KktYy2r6XmvAzYn9kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗГАΖΦЮΔΓХхШы():
    value = 838058
    text = __import__('base64').b64decode('aWdpUENSVDlrSEE4alBjdmRDcnA=').decode('utf-8')
    if False and True:
        _dead_1144 = 674
    total = value + len(text)
    return total

def _ηξыЪτλуχκжΙсЩρ():
    value = 4509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED3MZUMg7ZIzDSmk8ECjOiYHtm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if False and True:
        403
        _dead_9561 = 993
        _dead_4121 = 943
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()