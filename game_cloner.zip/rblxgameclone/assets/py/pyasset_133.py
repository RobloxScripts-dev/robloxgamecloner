#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _мλзНιЬГРКиЩшшρ():
    value = 780203
    if 91 * 47 < 0:
        pass
        807
    text = __import__('base64').b64decode('ZEtYdk92WVZVdEV0SjQyNUlWVG0=').decode('utf-8')
    if len('') > 0:
        _dead_8826 = 300
        173
    total = value + len(text)
    if len('') > 0:
        784
        pass
    return total

def _ΩΔЪςεεηΑΖЦФ():
    value = 711591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAzHSVMS+owIbySE/l2RPg0iyTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8239 = 419
        pass
        542
    return total

def _ΥХνψИНΥжПнСΕΤΡ():
    value = 433263
    text = __import__('base64').b64decode('cTdJajlEQnVGX1NKY2EyeHlGd1A=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _тыКЫЮψкζΠФτр():
    value = 481583
    text = __import__('base64').b64decode('RG9hcDBjdHNueERFd1VMRG1Cb1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ψуδΗтюυςЩεЗ():
    value = 887696
    text = __import__('base64').b64decode('eWNtT1o1a25zRVdFU2RvX1NzNnA=').decode('utf-8')
    if 18 * 86 < 0:
        pass
        396
        pass
    total = value + len(text)
    return total

def _πξΚΟдΙяФ():
    if len('') > 0:
        982
    value = 111972
    text = __import__('base64').b64decode('VmdzWDJvellZa05iYUV5aG50RVI=').decode('utf-8')
    total = value + len(text)
    if 55 * 13 < 0:
        871
        806
        pass
    return total

def _φТЛΝояΟιрЕμ():
    value = 223804
    text = __import__('base64').b64decode('d3RoVENSUDQ0OHJkbG0ydWh2ZGQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4163 = 211
        _dead_5265 = 601
    return total

def _ΤψξбΚЮιρу():
    value = 369395
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fhb+Omlg6PoiaQ2G5EG2FhE+0kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΟκφдΧбе():
    if len('') > 0:
        438
        _dead_1124 = 385
        _dead_3030 = 370
    value = 281283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB7sSVcA+7sOMQys8VyIJhEJ9Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аυδЛΝιΡЮΤ():
    value = 668311
    if False and True:
        _dead_5727 = 287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQXMfwMb7fg7HhiAxV+zZ3UO8mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7920 = 898
    return total

def _ИγрχАЛЛΧ():
    value = 177518
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lxy3fH0o06QpNhzx606vZDEqvW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_5141 = 276
        _dead_1494 = 347
    total = value + len(text)
    return total

def _ьΩΨЗЖΓΒψΛмзν():
    value = 473610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSXoRWkSrIY6CAqzkWyBJQQnvTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВβруτпщЭ():
    if False and True:
        _dead_3245 = 736
        87
    value = 729889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQ3pfQht9YIObRml317DMBwewzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΙдΑΣцТТЫЬΕЫθ():
    value = 645450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgLUSwUGybkqGD6azle2YT01zmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςτАХчυАΟΖж():
    value = 40802
    text = __import__('base64').b64decode('R1lVZ1d3T3RhYklGbzJKUGQ4MDY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        23
        173
    return total

def _αΦΥψЪЩфΙбΝΝοыиф():
    value = 105053
    if False and True:
        430
        _dead_4998 = 219
    text = __import__('base64').b64decode('SVZVZ2VwanlfMjFWcXRIeUtZMGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЬаЗπчξΜха():
    if len('') > 0:
        _dead_8334 = 246
        pass
        pass
    value = 821062
    text = __import__('base64').b64decode('c25COTB0VU92NVVkRThxbm5HeW0=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _зμуХмыЪэΦΒ():
    value = 591303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB3MYUNpyvxSDDDw2kbIPBU470E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λфрКюзтЯъАаζылп():
    value = 903673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC6xaGVg65pULyeqwEOkPDUGw2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΡйШΖЬνИΟτЛсз():
    value = 560398
    text = __import__('base64').b64decode('TUlubVU4RDJ4T2hadVNlZTlrYmw=').decode('utf-8')
    total = value + len(text)
    if 27 * 24 < 0:
        _dead_2459 = 387
        _dead_2516 = 425
    return total

def _ДСыДЗтЙνЭрΧΙ():
    value = 107305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiTFdAM3qfoXKwiZ+EWGZxQH9jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        237
    total = value + len(text)
    return total

def _ΒыΤбβГжΩλУАβцДια():
    value = 969322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lxjxe1QY6aYbFz6onAG2ZgAEtH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪφβζοтЮξьΠ():
    value = 98484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXjrXGJoza0NOSaNylKebQZ+tDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τλЫηηЖΠΞρПΤДЖфхЧ():
    value = 922199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cx/FOXUJypohFyeSwwKzbXE+9X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υγμЪΖΞКЬнЗΣΗИО():
    if False and True:
        361
    value = 537318
    text = __import__('base64').b64decode('aWo0OEJUWERIbVRFNUVHd0ZWQzI=').decode('utf-8')
    total = value + len(text)
    return total

def _πЬэКЯЯйΒοфЙАΣ():
    value = 474521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDXPeFssrr0LFg2m2HuKMgl79ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        599
        779
    return total

def _рЦоμξдΛГп():
    value = 891477
    text = __import__('base64').b64decode('Sm13d0JuVm5BUThTb3lyZmNlWmg=').decode('utf-8')
    total = value + len(text)
    return total

def _РΓττаιэктκщβπΑΧц():
    if False and True:
        pass
        pass
        _dead_7739 = 402
    value = 84924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDXuXgQa3IY6Iw606V2yFzwJ73c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 47 * 40 < 0:
        267
        839
        402
    total = value + len(text)
    return total

def _ηζМЗФδΙйΑχςЙΤЭИь():
    value = 44439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXr2ZGEO+fslbT2G2nevP3UQ7Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙπζΒυлΛςЮ():
    value = 920250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDfraFsY05BVEAuMkVuJOS8+8jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωМΨΘΡΕшчζ():
    value = 692496
    text = __import__('base64').b64decode('UUdaNnYzX0EyV0hudGpqV1QzX18=').decode('utf-8')
    total = value + len(text)
    return total

def _ςРАРЙЧАΣΘΔ():
    value = 503758
    text = __import__('base64').b64decode('eU5seTR4TjN2OXZEWlNzbFViZ0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΨУΞфλХΠШΑсхμ():
    value = 719589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDXbSnI397lQL1qonwXHMCQh5zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦлцтΜΒΝкΧПЛφз():
    value = 144578
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzneWEEeqoIiLAGJmVm3BHQMzHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΑГьуμБЦωЬсγхΕцб():
    value = 579530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dnb8agUs0aMpAj+F2HKfAXx72zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        656
    return total

def _еΡчЫΑΨΚΠмгШτΖоΙ():
    if 77 * 48 < 0:
        pass
        511
        165
    value = 612472
    text = __import__('base64').b64decode('WlhZa1NLRXMzeVV5NVJzblAxRTI=').decode('utf-8')
    if len('') > 0:
        372
        73
        _dead_6045 = 966
    total = value + len(text)
    return total

def _ЧСьβοфАГΤарΤИΛ():
    if len('') > 0:
        pass
        _dead_4837 = 260
    value = 941011
    text = __import__('base64').b64decode('Z29XRHBQNVdRN3pzTnVfOGwyX1c=').decode('utf-8')
    total = value + len(text)
    return total

def _цХыΘΛВХΜК():
    if len('') > 0:
        _dead_8366 = 178
        pass
        774
    value = 162434
    text = __import__('base64').b64decode('VVVIN3RpcXhfTE0yYnUxNVJnY1E=').decode('utf-8')
    total = value + len(text)
    return total

def _χрнΗΞστΤ():
    value = 393998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRXPRmMW7fATMQu00mCDIwYh3U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_1401 = 226
        pass
    total = value + len(text)
    return total

def _чρΟΖγМνэαЭщсМз():
    if False and True:
        pass
        pass
        574
    value = 876129
    text = __import__('base64').b64decode('UVdiVGJyQ1p3UmxienYwbU1OS3k=').decode('utf-8')
    if 51 * 57 < 0:
        pass
    total = value + len(text)
    return total

def _ЮаДЬЙΘцΜΖγт():
    value = 642261
    text = __import__('base64').b64decode('T19ScmRmVXl5c2U2cDV0OU9BRF8=').decode('utf-8')
    total = value + len(text)
    return total

def _κΑΣζсγйЕРγоβ():
    value = 192244
    text = __import__('base64').b64decode('QTl0SnUxVFZPaDg2MFljU19vUXU=').decode('utf-8')
    total = value + len(text)
    return total

def _υηΛωжжΗΛеЖПνЯ():
    if len('') > 0:
        271
        _dead_1599 = 302
        pass
    value = 419023
    if 65 * 99 < 0:
        _dead_9018 = 250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwW8XkEKwbkVCwWb/W64HHUrx2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_8941 = 860
    total = value + len(text)
    return total

def _тЪКΒЦмпΓИЧДФЦПтч():
    value = 619009
    text = __import__('base64').b64decode('b0N1U3RxYm56WTNtU25aam82eEE=').decode('utf-8')
    total = value + len(text)
    return total

def _мγЙНΨкОδЕΚι():
    if len('') > 0:
        _dead_7509 = 910
    value = 328684
    text = __import__('base64').b64decode('cFp6UWsxc25mR0pQZWdNeUdBMWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ПμрьОγμИ():
    value = 590029
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgHSX1UG9KE5Nhew2GyUOH0Wz2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лчЩΤСэΓОχЭюФ():
    value = 753165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzqwN1wKrYVWawuU/VKvEx13wWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8791 = 20
    total = value + len(text)
    if 74 * 23 < 0:
        813
    return total

def _ПκйВБζОЪФΟΘΘ():
    if False and True:
        _dead_3725 = 987
    value = 564837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyHiQHdsroIWLQyR5USVJHx44kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 50 * 23 < 0:
        pass
        pass
        99
    return total

def _ρынΨπЬДЪΖхΕей():
    if 98 * 82 < 0:
        pass
        pass
        pass
    value = 329887
    if 40 * 38 < 0:
        805
        _dead_1884 = 841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRjVfnga240ibTac/m6GbS8V00Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μфδбΤςмЖγπрΘл():
    value = 168626
    text = __import__('base64').b64decode('T3p3bEQ1UERHcDQ4d2RMVW11R2w=').decode('utf-8')
    total = value + len(text)
    return total

def _КνфΝθбΒъφщмςЧτЮ():
    value = 384593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3jJamMM5/krFl7y+FHBHQYg4ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЖΨКθЬхъδньτ():
    value = 133149
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgbCdggb/aY6MBWIkFiJLTMM920='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΘπлЗЗγШλΚυΔЧХ():
    if False and True:
        pass
    value = 761889
    text = __import__('base64').b64decode('TkVrdW9jU3pwdGZhYUxJYzhzR2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ВЖцнβбеΒВ():
    value = 394430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjnlfWYvrowLFwGB7F+2JC8h3FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘгЙЮЪЦФΝэκе():
    value = 684594
    if 90 * 97 < 0:
        _dead_2577 = 323
    text = __import__('base64').b64decode('eWxCaEQweVJjZDJsTUd5SkNaVWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯЙгξсвΣΖμбхгηц():
    if False and True:
        751
    value = 659615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwnvelkK7oQiFFivkF2jDhoNt0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 5 * 57 < 0:
        383
        pass
    return total

def _ΨΟΚΙΣθδВиσ():
    value = 75890
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTbUQHYe7KkaaC2ExQW3OXI59Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖКβΑΣδдБκθУКПкυ():
    value = 668625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FH7ddFo86b1RNSuzzFCUMjV99Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρтσИхДωΚκОхΙ():
    value = 950691
    text = __import__('base64').b64decode('WlR4ZlRhcWJhdnBFM3Qyb19IRDk=').decode('utf-8')
    if 56 * 67 < 0:
        777
    total = value + len(text)
    if 79 * 57 < 0:
        pass
        925
    return total

def _аЦηΣΜΙшЪΧтцζмδΝ():
    value = 212283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDvGfwcOzIQlGAr6/2WXFXUi1UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АеюмтΥЙОэξКсΥ():
    value = 238220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXjIalApxIAAaQig3XvCBQkL6H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иοςΧИιТтЫΑΡВО():
    if len('') > 0:
        435
        pass
    value = 363834
    if False and True:
        _dead_4422 = 274
        842
        90
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTzVWUIRqqcTNwOt3gKiO3x8z2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 78 * 15 < 0:
        _dead_7923 = 720
        pass
    total = value + len(text)
    return total

def _ЭЕЧрθΩξψбрΛαЧ():
    value = 801385
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwfJQwQzyY48GQj08lKTPxwJyG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        612
    return total

def _σЩΗЕШЙФΜΔ():
    value = 110892
    text = __import__('base64').b64decode('aDFxOXdjUHp3eEhodVBDVW9sYTA=').decode('utf-8')
    total = value + len(text)
    return total

def _СЙлΓпЩЮНΥяИыΗПνΣ():
    value = 437990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSf0e3wY87gSDQSp0l6WFRJ/skM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8673 = 187
    total = value + len(text)
    return total

def _ΖЪХеκΦшйΛн():
    if len('') > 0:
        pass
    value = 608923
    text = __import__('base64').b64decode('bE9SVmNRYlhSSE80bURNTGxKNWs=').decode('utf-8')
    total = value + len(text)
    return total

def _σΦюЭуΟРΟΕХЭыЛУΧЮ():
    value = 757175
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn3AQHIh0rkGLCT20QXGIC03wjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6490 = 88
    return total

def _ΦЪЬМлцтΗ():
    value = 540135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FH+3fQkurqcWH1+7kWG8AgN40D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΦТюТХιякΝНυ():
    value = 247509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRXndgcj6awRFhmHx1GeEgoVtEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЖШΚΚьЫу():
    value = 542838
    text = __import__('base64').b64decode('d01IcV9lSnEyNUJCWHJqS1BiaW4=').decode('utf-8')
    total = value + len(text)
    return total

def _τδйξΣюеΟЕ():
    value = 848118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiHpbWED2LFWPDWo4FXFAQAK/Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        659
        846
    return total

def _рΦФθлмйцΖΗОςЬθ():
    value = 720810
    text = __import__('base64').b64decode('aGNXaTB6MXdMRzZPN21ZT2xoMzQ=').decode('utf-8')
    if len('') > 0:
        _dead_4981 = 20
        _dead_8343 = 139
    total = value + len(text)
    return total

def _дцЭψбΦΔоИΝтТЫΣЯГ():
    value = 108815
    text = __import__('base64').b64decode('anh5QUlQX3pBYlRKczhMd1pFOXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ХβпыπСЛээдη():
    value = 902487
    if 51 * 47 < 0:
        _dead_3954 = 609
        797
        pass
    text = __import__('base64').b64decode('cGszWnFRV0dnSml1YzYyY0ZyNVo=').decode('utf-8')
    if 11 * 45 < 0:
        342
        _dead_7511 = 837
        169
    total = value + len(text)
    return total

def _ШкГОΔφРΕΑыζ():
    value = 57287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FATNVmAS/5AOaQ6O70WzbXYb3m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 23 * 82 < 0:
        143
        888
    total = value + len(text)
    if 84 * 88 < 0:
        _dead_7373 = 58
        30
    return total

def _ънфыΦЦЮвΧ():
    value = 68482
    text = __import__('base64').b64decode('WDlPYmNFendZY3dNSG1DVVpBNXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ытЫЪььЙкШчнфιΣю():
    value = 14775
    text = __import__('base64').b64decode('VjZQVk1faDhQeXdHWkh2NHlqMHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝιωΟΥςкΧμЙьа():
    value = 363219
    text = __import__('base64').b64decode('RUJpMW9KY1cwZVlFM1J0WlF1ZVc=').decode('utf-8')
    total = value + len(text)
    return total

def _чБЮшЖΙЮΖ():
    if 13 * 32 < 0:
        986
        712
    value = 682202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Khv9UVMN/Zc0ahaL0WGgEDULvWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыфψКПΔщΒкФцΛΩ():
    if False and True:
        _dead_4663 = 520
        _dead_6272 = 953
        362
    value = 706109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCnzbAc69qdWHQOi/E6qBQM96Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟλшυяцЙΟяοк():
    value = 565975
    text = __import__('base64').b64decode('V0Rsd3pDWURUVFlNajZVRHpKZUo=').decode('utf-8')
    total = value + len(text)
    return total

def _иλνψГΦеΣБх():
    value = 382198
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAi2VAcj9p0oHDy7nXehIwIZz0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        13
    total = value + len(text)
    return total

def _ЭГΜАнцЭσ():
    value = 907930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAz2RWEN/Y0hMg6c/kChPR09sk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΔρЭЖτΖЮщчНыТΟлм():
    if 19 * 22 < 0:
        294
    value = 338867
    text = __import__('base64').b64decode('dGRMZ3VCVlhQVXNBMzdXN1c4d0k=').decode('utf-8')
    total = value + len(text)
    if 65 * 78 < 0:
        _dead_3284 = 889
        928
    return total

def _ΙΔΒΥажΛпГККΧКЮο():
    value = 281684
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQnJR0Ec9ZcXaj2E/FuJDg8tznQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πωΖΠΑΣΛзαябКРΓςм():
    value = 583001
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSfbSEI2+rIGKyqqwWa5HTwC5mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 84 < 0:
        pass
    total = value + len(text)
    if 30 * 95 < 0:
        _dead_7038 = 518
    return total

def _лШΘяΟМсГрБю():
    value = 924748
    if 24 * 98 < 0:
        182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LT/MWl0ax5gvIx6R3GyDDAIG0Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПЕЗйΕςКΞχФιΝ():
    value = 239295
    text = __import__('base64').b64decode('RmVtOGdEcEhES0ozV1ZxanZ4NlQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        956
        728
        pass
    return total

def _ЮьΕθδεюШςβΣΗ():
    if len('') > 0:
        946
    value = 606793
    if len('') > 0:
        _dead_3799 = 895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHfUOVxv9PsCNCmM+EKcGHUn0DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9900 = 885
        944
    total = value + len(text)
    return total

def _ыπОφТшηФмЧΙпι():
    value = 423001
    if False and True:
        770
    text = __import__('base64').b64decode('Yl9ETTFpRTRDaHM0b3JFOFBnSnM=').decode('utf-8')
    total = value + len(text)
    if 55 * 33 < 0:
        _dead_6847 = 387
        pass
    return total

def _щПэΜнЬШГΑРΜЭюНХ():
    value = 207404
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCbJOgQqx5IbNijwn2mSAzUn3Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЕЭφЗшЬΞюθαΖпе():
    if False and True:
        pass
    value = 886008
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ND2wSlNo+pwQHliCwQXGLhUK80Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΕВΣΦКЖКйχСТ():
    if False and True:
        pass
        _dead_9502 = 562
        35
    value = 224748
    if 48 * 53 < 0:
        _dead_9209 = 869
        pass
    text = __import__('base64').b64decode('bW5BYTFrS0Q0NnJBYTdlYmx0SWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩχφПΜΜΟфαΑψ():
    value = 901243
    if len('') > 0:
        467
        487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDvTP3ttz7IEDQ6U+Xm/LQgK5j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8615 = 637
    total = value + len(text)
    return total

def _δАуЬДеΘΟзЯ():
    value = 268678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3/CR2Br064tDFa26W6jICQet3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψОξМΞΑнС():
    value = 48589
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('YzM2STFsdlkzUF9jczR4TjlHbWg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        888
        _dead_7544 = 120
    return total

def _вЗПДΛЕΣЩΖΗГΦНφъΣ():
    value = 509761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HA7BXmAx06koale6nlqXZBopzkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МφмтβποрυЛЛρλξ():
    value = 381368
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQruVEYby4YLEhuk5kKBPi0L1EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оыйφиιφд():
    value = 86992
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzX1OHkWp6IADAKQ51ivJycmvUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΠЩлγПβΦшв():
    value = 889907
    text = __import__('base64').b64decode('amYwQ0JsZVlqdG51Vm5Pa041eEk=').decode('utf-8')
    total = value + len(text)
    return total

def _лΓγЖЖСΡЬулЛаχ():
    value = 800984
    text = __import__('base64').b64decode('dEVMUm1zRFl2SWhTVV9xT0lMVVk=').decode('utf-8')
    if 22 * 76 < 0:
        _dead_9522 = 721
        179
        _dead_9725 = 276
    total = value + len(text)
    return total

def _ГυμАΜКмТшεБη():
    value = 1376
    text = __import__('base64').b64decode('cWtkeTBwODdaVlZnRTZCVXcwejA=').decode('utf-8')
    total = value + len(text)
    if 73 * 59 < 0:
        _dead_2482 = 859
        _dead_5136 = 318
        pass
    return total

def _ТУавдοвυφΕΥбю():
    value = 587147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgvVZXlo/4AQAgX7z0e2IBUu10A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АГφΡитГΓяЕΖΘη():
    if len('') > 0:
        pass
        150
    value = 971973
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCnuZWVuz5AnCAKm91nCAHc24m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШπтхВΒзφΨйδΞλ():
    value = 518757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCrSXmcO8a0WNCeq4mK1HAEgw1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιΕΡБОНАΛπ():
    value = 761200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3vNPQZs/bIUOBW3mG6XFQt7wWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        211
    total = value + len(text)
    if False and True:
        pass
        613
        _dead_5055 = 998
    return total

def _АΡбςοΤΡВληЬюι():
    if 67 * 14 < 0:
        208
    value = 860238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgvqYWIe36cGaRaA5F+cASI3sWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5131 = 688
        _dead_4250 = 980
        526
    return total

def _ьОΑΘШбВΛ():
    value = 831097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSDyRn8+3aUFEyGznW+oDDd95Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _υъХΤδΦХΗОτ():
    value = 451387
    if False and True:
        _dead_9932 = 22
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NX3hWQYA9PwIIhyu3U6KMhUo8Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δЫгПЙоΙЯλнМιЩчм():
    value = 244752
    text = __import__('base64').b64decode('dmltTGttVkxuRU9WNmh3ckVOVlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ППΡпΗχβЩ():
    value = 456319
    if False and True:
        _dead_2745 = 524
        pass
        _dead_7340 = 326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwTQPnAJ0Jo0Cz36xw6/JSQt6Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 75 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЪΝΝΓфШМαχ():
    if False and True:
        _dead_9953 = 111
    value = 183888
    if False and True:
        pass
        262
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FADnPQAT5rElYwX3kGyRIQItz1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 68 * 77 < 0:
        _dead_2979 = 430
    return total

def _ρλφΜХюРн():
    value = 948159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EybvOnQWzo5SNRi2+AKCJnQG4zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χГΔΚвнрΣЩУΓЗΟд():
    if False and True:
        _dead_8652 = 53
        pass
    value = 640267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD3qRmcDrbErYh+L2kaUMQkV6ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξъπТОλХΖЫЦоэι():
    value = 933215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSvsXlQr3Z8sMSiE/1myYCo29F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жюКеΗΣρЧЖΒβ():
    if 73 * 77 < 0:
        pass
        _dead_2942 = 148
    value = 399810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASGxaV4V7K0CPxm621GmLiI/70g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λйτХοАиφтξОВТαχЛ():
    value = 369383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kz/9Q10jwbhaMTymwQ6xAAF+120='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        883
        pass
        111
    total = value + len(text)
    if False and True:
        864
    return total

def _ΠхεАсНρΞва():
    value = 239011
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQvCb1xt5qo6DBqum3LFMzM30Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚМЦъТεбИ():
    value = 5287
    text = __import__('base64').b64decode('cGlIMmo4amNXMFEzdnJkX240Wnc=').decode('utf-8')
    total = value + len(text)
    return total

def _щЫΒεокΙСЫПщуСЫеχ():
    value = 201210
    text = __import__('base64').b64decode('R3o0aUF6OUJzWlR5ckR0QzhvTTc=').decode('utf-8')
    total = value + len(text)
    return total

def _λфΥΣсПςш():
    value = 654788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw33YH9q7oNSEQuxkAbBNh184XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        288
        pass
    return total

def _ИееоΠэыγΖМ():
    value = 997969
    text = __import__('base64').b64decode('TEVSVzBIeG55dVhDc0dGRVdnYkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _жрδΕеΞαяΟфОНфн():
    value = 907967
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3vFb1wW1Y8ZAAr12XWiOCR3tlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вγΛЬКчυю():
    value = 487102
    text = __import__('base64').b64decode('QWxaUUswTWpoSDlFMlJMS1k1STE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7534 = 671
        _dead_2776 = 726
    return total

def _БюζЖШΝеΔ():
    value = 860279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQnQX2Ee6vEADVuk51OWDg821jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫАωΓиΖΔДτ():
    if 93 * 38 < 0:
        pass
        _dead_1940 = 106
        pass
    value = 904523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCfPaUsT3a4gAjeP7FygJgx3s3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓюχβПЪΖΔο():
    value = 673735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnnNOgg79IxVPTn1/F+oHSM992c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6980 = 44
    total = value + len(text)
    return total

def _ΒπНЬνгθлΠΓжΗμ():
    value = 116054
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgHcUUA/rPgTI16K+E6IJCIW7X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дαχЗπδЛТяЯ():
    value = 189973
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('SnFCMUZOTnVGRm9VVl90eUk2aTM=').decode('utf-8')
    if len('') > 0:
        _dead_4093 = 14
        598
    total = value + len(text)
    return total

def _ΠΞαХГсчЬΥ():
    value = 515544
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En3cZARv3asKBRiT+EabExQYsEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γυτХεпαВДγΜτΓ():
    value = 681992
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSzrQHIG8/EOFBim2lSVJw8m60w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЙЧкцпЕπЩЪ():
    if False and True:
        pass
        _dead_9792 = 690
    value = 583420
    if len('') > 0:
        _dead_4967 = 541
        _dead_1568 = 984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lgi1XElurv42IguH5XiIEAYOzW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ШьΛτЭαНЙ():
    value = 464752
    text = __import__('base64').b64decode('QzdTeVZ3cHZLMXUzRlBwUndvRjI=').decode('utf-8')
    total = value + len(text)
    return total

def _τνТРΦюΦйфΓΣαΩ():
    value = 145165
    text = __import__('base64').b64decode('eG1kTHdhZGl3UWoxbllhUzNRN0g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        640
        _dead_9759 = 242
    return total

def _κΝвСФπδшЛ():
    if len('') > 0:
        pass
        _dead_8984 = 56
    value = 792882
    if len('') > 0:
        _dead_4655 = 465
        957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By3QSWYf6rhUPCiS2WCoAz83yUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξψЬΝШБКЧ():
    value = 458566
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhfxeHtr2JFQCTiAxWGKPAZ3020='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χкΑβΞКοфзмЗиЛ():
    value = 42922
    text = __import__('base64').b64decode('aVA1MEJkOGdwQ0kwYlQ5X09VQVo=').decode('utf-8')
    total = value + len(text)
    return total

def _δοлЛСЦчР():
    if False and True:
        pass
        _dead_4085 = 547
    value = 859790
    text = __import__('base64').b64decode('dFZXRkh1N0RqNW5OMV9JcXljamg=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_1567 = 148
        pass
        pass
    return total

def _υΞΜΨЦЫЫςσΘъгСς():
    value = 930180
    text = __import__('base64').b64decode('Z09fRmVXYUFoSU9GMXRQM25zbFc=').decode('utf-8')
    total = value + len(text)
    return total

def _лνβοктΒКΒΔ():
    value = 861449
    if False and True:
        pass
        pass
        940
    text = __import__('base64').b64decode('UllrSHdFSWZ4bUFZZVFUQWsyQ0Q=').decode('utf-8')
    if len('') > 0:
        507
        _dead_6335 = 241
    total = value + len(text)
    return total

def _СЖΣЮЬрχИΧмЫβЭьΦО():
    value = 117433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSrgS3AM05AFHyGNz2axFT8H118='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЦеζЭШΘκНΗιφ():
    value = 915605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhrySGQx1PkQFRm03VunMhYn/Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9920 = 302
        pass
        pass
    total = value + len(text)
    return total

def _ζЬВΒΔГοΚ():
    value = 46240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzfIZggJ8ZcWaC2X/maeMHIB/DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΑηищаЦψЧ():
    value = 362793
    text = __import__('base64').b64decode('VnlmSExUR0RWanBaUTh3ejhvRFE=').decode('utf-8')
    total = value + len(text)
    return total

def _йΡМЛπвΡЙδιпэыобК():
    value = 768782
    if False and True:
        _dead_3600 = 374
    text = __import__('base64').b64decode('dHlzN2RkRFVIVExkckRBTlZYSFY=').decode('utf-8')
    if 60 * 52 < 0:
        _dead_9524 = 251
        _dead_9536 = 806
        743
    total = value + len(text)
    return total

def _αьΚЕξФСпπЩЙдЦЭτа():
    value = 940432
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3v1UVYj37skOCyl+nDEYTF23jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧτηΝβГВаψГηБΙ():
    value = 730124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSzjOVgtqvpSEg2R6ma0bBoj514='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 88 * 44 < 0:
        _dead_7891 = 494
        pass
        3
    total = value + len(text)
    return total

def _ЯΨНтΔθуйуХАΗ():
    value = 472621
    text = __import__('base64').b64decode('VEFqRmJHczhlRklHTTM3Q3RUbnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫуΟιэΣыΝΠНΡΧρτΦ():
    value = 662475
    text = __import__('base64').b64decode('dEZVaTNqMzdaVXlzNk12djFXbnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _μбоТβΥВρτΛЧΔ():
    value = 644964
    if False and True:
        204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT7yXAU40b4SGRyF63yyHg0tvH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шνДчЙФеτСАЙξмй():
    value = 441008
    text = __import__('base64').b64decode('Z1hsam1DVVA5eV9yeFRhcXppZ1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΖЯπЩξЫш():
    value = 117169
    text = __import__('base64').b64decode('amdFMk5ySjlSZzdRR183d1NTc3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЫЗдΜоοъ():
    if 47 * 88 < 0:
        67
        pass
    value = 926946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nyf1TQUJr5swGDCa6gCIOxF5yHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΩРΟΣБνΝз():
    value = 946271
    text = __import__('base64').b64decode('WkxMaEZ4Vnp5bXhTbElGNEl4aWs=').decode('utf-8')
    total = value + len(text)
    if 28 * 48 < 0:
        454
    return total

def _ΓΚШΣНйΩэφХΑ():
    value = 293107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX7CXnZu754iHyKi8GSCbCkf9Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΞκУъббπ():
    if len('') > 0:
        _dead_4247 = 366
    value = 370674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjjtR1Jvx6cULj6Sn3mgPAAm8VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γрΣТНςиΨσЙЖа():
    value = 612905
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyPvYgQ0xPhXF1mwxlTCHSA842k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηцЖΟμмΣЪ():
    value = 506749
    text = __import__('base64').b64decode('VmM2a2VLdnpzdHRrcjZ2bFN4anA=').decode('utf-8')
    total = value + len(text)
    return total

def _οωЩκСНχΩ():
    value = 357751
    text = __import__('base64').b64decode('TW5tZENVd1hlQ1hmR3lvcFZVTzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖςдΛΠΨчΚэΠΩ():
    value = 929664
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hyb0X2Aa9qkMHT22z2+DA3Q+5ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖУΖНΖГЙкд():
    value = 615107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ig7teGMGzKI7Yzul/gGWYT8p4k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕηчвжфГΞяАΚо():
    value = 985528
    if 36 * 58 < 0:
        42
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyL0bQMPq5gtMziU0mS+AyM13XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 10 * 90 < 0:
        pass
        pass
        _dead_3328 = 225
    return total

def _ΙЗфввиΖЦЗщЕ():
    value = 944529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXbmamUa+IokYySR4WmAEXQ1smI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7365 = 374
        _dead_7328 = 312
        427
    total = value + len(text)
    if 56 * 95 < 0:
        264
        114
    return total

def _σξсхηΗαγМЫ():
    value = 799408
    text = __import__('base64').b64decode('dnFvZ0doUUFOWEpVYk5VZXV4WHI=').decode('utf-8')
    if 2 * 2 < 0:
        919
        _dead_2685 = 795
    total = value + len(text)
    return total

def _ηщпщмЩуФкЬΕЕР():
    value = 416279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz3welNu0LAWaiuu4nSxZjM/814='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΦЖЕαлηκИλтЗ():
    value = 20835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ei32aHsz64cQDV+H0EGJGAB770Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΘтΒμОρБЕйΩшхΓЩ():
    value = 706770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTWxbGMKqIoUbjiw7XXCESAd/T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 66 * 71 < 0:
        _dead_5559 = 615
    total = value + len(text)
    if 17 * 5 < 0:
        523
        _dead_7317 = 151
    return total

def _ιΝУΛΙΞπиΓл():
    value = 793860
    text = __import__('base64').b64decode('UWRSN3RpOVFkMlJYQThaUkR2TjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑбПжсЧЧФСΟ():
    value = 236362
    if 8 * 19 < 0:
        pass
        _dead_2845 = 870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I32xQgkd+78aAxaA5AO2I3w/9UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2682 = 97
        875
    total = value + len(text)
    return total

def _лДΔιΕРЦЯсΧΡΥΝ():
    value = 708255
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgHKSUYOr5A1HyGu4GHGYQp70z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        197
        239
        779
    return total

def _ЮΨπагΠЕйτΨА():
    value = 660569
    if False and True:
        627
        pass
        _dead_4151 = 397
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzrWZngB8a8SNV2m6waKHBYf6Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВйВЖЦыΥχερлзУ():
    value = 114863
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQXdUWVgq4UIYwChnGCmJ3IpsEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9235 = 795
        312
        218
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΙΒЕσшΜЖд():
    value = 607955
    text = __import__('base64').b64decode('WGdDdlVZNzNDOW9lYkE0SUdqUnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΤπИδЙЙНя():
    value = 627659
    text = __import__('base64').b64decode('RU1ER3hqMlB6YzZlb1BaX2dseGE=').decode('utf-8')
    if len('') > 0:
        pass
        296
    total = value + len(text)
    return total

def _кΞΔΛуфΤοаΜОЩΕΦΟΒ():
    value = 283059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxfUZwIOx/4iaxX0wl21OgQq/U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒДвηλДδΥВхзηΩНΤД():
    if len('') > 0:
        _dead_5400 = 357
    value = 734755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhryPmc25r8Oah6g0nKxbDY84GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3971 = 337
        _dead_9550 = 56
        _dead_9489 = 58
    total = value + len(text)
    return total

def _ИИмκяσΦяЬЭс():
    if 32 * 68 < 0:
        pass
        159
    value = 91036
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3rWXAgW0qEmOBWs4GaKE3I9wUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        58
        714
    total = value + len(text)
    if False and True:
        800
    return total

def _ςелечЪχΒξрνя():
    value = 685386
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyHbOQVq16YZMwmtxWK5NyY8tEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙДΚΕχЕΙαΡАθГνйЗр():
    value = 146082
    text = __import__('base64').b64decode('TnA2bXdsazNIUGlrZDhQYmFMdUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪЛсбΚζΛφрΗЦΙшсς():
    value = 834266
    text = __import__('base64').b64decode('T3hDRmlqWHJzT2tpdUNwYnJ5dTM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5339 = 520
    return total

def _яьΛРμΠщхβЧв():
    value = 995875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQnpSVht2KsJEwax4lWBFQB+xUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уяΣμпкЗэнт():
    value = 82311
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARzJQUMq0PECMhyl+Fm3ABo2wTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рИНМЪюυНμΗлэвЯςи():
    value = 898489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAjeWAE8+4tSYzuV7FGSBC9/z0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜцοдΞΝмψΤрΨπцΝФт():
    value = 323330
    text = __import__('base64').b64decode('TmVDZGJ5b2lXZmNKb08xRDI5c3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _бяΑφΖвЧШГκγЫ():
    value = 314139
    text = __import__('base64').b64decode('SnBQbjNXcHE2WEFLWmRuVExIUmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()