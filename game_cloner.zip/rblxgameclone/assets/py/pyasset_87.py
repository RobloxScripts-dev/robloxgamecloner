#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΩΝэΦΡПчζсΓΡΕрΧρσ():
    value = 392261
    text = __import__('base64').b64decode('ZmRxc1hMOXhpdl9mWHpZX19icG8=').decode('utf-8')
    total = value + len(text)
    return total

def _βАОЮΚЙЙς():
    value = 138888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQHLTAkY8IUJCCCOzXWADAcD/kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3064 = 494
    return total

def _зλωГхεбвοΚνΞ():
    value = 345560
    text = __import__('base64').b64decode('eE1uUDFwSktnOG5FM0c3RW9qQ2s=').decode('utf-8')
    if False and True:
        _dead_1799 = 581
    total = value + len(text)
    return total

def _ъΗеΜнρЦСузр():
    if 30 * 30 < 0:
        pass
        pass
    value = 342862
    text = __import__('base64').b64decode('alBobnhmc2pZckt3ODdaaURTQ08=').decode('utf-8')
    total = value + len(text)
    if 34 * 79 < 0:
        pass
        454
    return total

def _ολтЯραΘуΧ():
    value = 936376
    text = __import__('base64').b64decode('WlRGcnpvTWR2ZlZTaHBiODR6Wkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ХяΕρДςУψΧвπы():
    value = 414494
    text = __import__('base64').b64decode('allicWFpQlpWY1A2UTQ0M3dVQjQ=').decode('utf-8')
    if 1 * 72 < 0:
        226
        pass
    total = value + len(text)
    return total

def _ИЩвгФНЖпыФς():
    value = 853008
    text = __import__('base64').b64decode('REljWGpma1ZSOV84YWluX1JJeEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ιцпмдзгСиνЯфψЬ():
    if len('') > 0:
        _dead_4324 = 349
        114
    value = 335708
    text = __import__('base64').b64decode('VExSemVqRGV1SmFramtseXVkbTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _φэηКσμΒΤΔФΣχ():
    value = 533350
    text = __import__('base64').b64decode('SHJpZ2ZLeE9RMk90MURsc0dTVDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ζщСΑΒФМРΚэ():
    value = 645310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn61e0hsr4QwCCiLzEaAGigk8Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВэΨсЖΥКΜΩФΟγФПγа():
    if False and True:
        _dead_8579 = 865
        190
    value = 135226
    text = __import__('base64').b64decode('V2FpU1FBM3RGVXJOQUdYbTdSMzA=').decode('utf-8')
    total = value + len(text)
    if 84 * 60 < 0:
        pass
        _dead_9159 = 795
    return total

def _щΥБΚщθчЕΑφМеλΕчС():
    value = 842236
    text = __import__('base64').b64decode('UjNWNENfQnhhOWJMalJfNXZxaVI=').decode('utf-8')
    total = value + len(text)
    return total

def _юΝςхфуиδΥΜαψю():
    value = 478384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NniybFkvwZ4mDgWL60yzCx15128='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АτяъΜκяα():
    value = 738647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxDSbXMY8psWGDezmEzDOxV+4W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _τяЧФФьρэзθΖЪ():
    value = 893306
    text = __import__('base64').b64decode('Y05IemN5dk5QVE1QTUNhOWxOOEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΥКΧΘφюЛЭΤХμα():
    value = 712904
    text = __import__('base64').b64decode('Vlpqd3YxeWJBRVhJRkpCRmlROUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ιЩлΨβΩΧφ():
    value = 662384
    text = __import__('base64').b64decode('UEpDZldpR2xnMkFOYlhMYXpWM0s=').decode('utf-8')
    total = value + len(text)
    return total

def _битαΔΥзβкΕηтΒМ():
    if len('') > 0:
        _dead_7959 = 177
    value = 376151
    if len('') > 0:
        876
    text = __import__('base64').b64decode('c0Zwc0FZNVdnZml6dmJoancyZTM=').decode('utf-8')
    if 93 * 41 < 0:
        _dead_9721 = 688
        pass
    total = value + len(text)
    return total

def _κЮМЭΦιοОАΧсΛфН():
    value = 479427
    if False and True:
        _dead_1413 = 43
        pass
        _dead_6047 = 591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj/sbWcd/6ElahmhkHiJYhItwGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 51 * 81 < 0:
        pass
        _dead_1358 = 487
    return total

def _фшιЛэпΕΚΒθдκкζ():
    value = 864524
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MADuQ3kKyZ4kDyj35Uy3FxUX7zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΞтБсЙΓЕЛЙκ():
    if len('') > 0:
        440
        _dead_3630 = 359
        586
    value = 1854
    text = __import__('base64').b64decode('eFdSMXZXbzlyRkYxUUIxdGtwUlE=').decode('utf-8')
    if 10 * 28 < 0:
        181
    total = value + len(text)
    if 39 * 2 < 0:
        pass
        207
        pass
    return total

def _ΟъТрΡΚзэΟΔ():
    if 66 * 95 < 0:
        569
        _dead_9957 = 617
    value = 897323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgbuZ3Q4rftQHiqs2kWYPS4p7Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 12 < 0:
        pass
        823
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2993 = 268
    return total

def _ОжΝΩτΣΔνзπбпАΣ():
    if False and True:
        _dead_4490 = 166
    value = 11977
    if False and True:
        401
        _dead_9086 = 768
        pass
    text = __import__('base64').b64decode('b3NHdk91QzZKOGlGQTB6c0lOODk=').decode('utf-8')
    total = value + len(text)
    return total

def _чвθτГСσжНΑ():
    value = 516116
    text = __import__('base64').b64decode('QTQyOEExRnBOakY1Uk5HSFZJZnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ωДччэшхυ():
    value = 151366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiDubVkNzKxbaiSPnW6bPAMN8kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οаГЛпΜЬη():
    if 54 * 32 < 0:
        251
        _dead_2302 = 956
    value = 794406
    if False and True:
        _dead_9041 = 587
        _dead_6516 = 295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwnlenUsqKwOIxai3g7CEBIfwmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КбзЬЖРωЮ():
    value = 497856
    if 67 * 97 < 0:
        _dead_7066 = 651
    text = __import__('base64').b64decode('bUJWXzdCa2VHbTBjRGJjVDY3cEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔρπБМЬЬλщАπελЦЛЙ():
    value = 560594
    text = __import__('base64').b64decode('cTVJcFE1SnJIeGhZeDdHUXY3Mmg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8408 = 273
    return total

def _яЕоΩαВсДРω():
    value = 153129
    text = __import__('base64').b64decode('QlJtakxqZ3dLX2J0c3NackQ5Qkk=').decode('utf-8')
    total = value + len(text)
    return total

def _χиΗθуσΞΑσ():
    value = 45640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgnJaAcv3JEXaAbx90adJTAX4kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дФЮςΑАΨιыИШΞПηь():
    value = 477742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jzq9XnAM8ZcMGT6F706SIj0htT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αпкζмЫФΥХКγЧΣМл():
    value = 38243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQzFRkM0364JFBuZ91OZZBw17WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 64 * 79 < 0:
        _dead_2927 = 836
    return total

def _σмΚдщΔσθΓХμφξ():
    if len('') > 0:
        829
        _dead_5842 = 648
        pass
    value = 69844
    if 36 * 15 < 0:
        720
    text = __import__('base64').b64decode('UTFmcEFzR05jWm1qWVRtYWdjalI=').decode('utf-8')
    if False and True:
        460
        151
    total = value + len(text)
    return total

def _ωβпБλрεуАнΟ():
    value = 755888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwbvQ0Fo9pELMV2qkVGbZ3MF0jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жЬΝшхъОЖткИсигеЬ():
    value = 785364
    text = __import__('base64').b64decode('Vk1vN0NqUl9DMjZ2NllxbE5Pa08=').decode('utf-8')
    total = value + len(text)
    return total

def _χЩЮΑΨыЬξ():
    if 2 * 85 < 0:
        _dead_5051 = 544
    value = 627484
    if 31 * 1 < 0:
        pass
        180
        _dead_3552 = 707
    text = __import__('base64').b64decode('b19MMVNoUTBBTm93ekJaTFBtR2w=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7256 = 255
    return total

def _ъюЭΟпσοЛΡοΖцΡζξι():
    if 34 * 46 < 0:
        44
        pass
    value = 887796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSuzfH0J6/xWIDmVkEe8FRAj6H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8847 = 572
        312
    return total

def _еСЬОиЬЙФμΣΖεΕΜЫ():
    value = 607317
    text = __import__('base64').b64decode('SEtUM3VTZjBYa284RWFOTmtvdnE=').decode('utf-8')
    total = value + len(text)
    return total

def _чθУυτΧЛя():
    value = 336197
    text = __import__('base64').b64decode('Q3I2YnQyTzVXM3lhSUJGSWZnazE=').decode('utf-8')
    total = value + len(text)
    return total

def _ьψргмοзчЛε():
    value = 21261
    text = __import__('base64').b64decode('T1hfZnpYZlBBYlRZQzlYVW9VMTc=').decode('utf-8')
    if len('') > 0:
        806
        _dead_4214 = 888
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _ьΝΖсΓΠΣΨрфβсмΔК():
    value = 662695
    if 5 * 27 < 0:
        73
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSXvaEMerv0rGwSB7Fm1DiYHzUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        355
        _dead_6137 = 145
        _dead_1036 = 828
    total = value + len(text)
    return total

def _ΠхНГЯρΙЫуЖρΕ():
    value = 308279
    text = __import__('base64').b64decode('bktFaU9lN3AwMkJrRmxNNHRWdGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΚДКюннИяРΙΧ():
    if False and True:
        pass
        827
    value = 674319
    text = __import__('base64').b64decode('TW95WmNzYUFXaE5vT1BiREhsV0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡуЦЪΣζАшοτкеΔΝ():
    value = 168441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRXnXGEyprEBHw2l72KpHD94108='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тςрΗЯСкЯςТщф():
    if len('') > 0:
        617
        197
    value = 136438
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAvUXlUa85BTORag21PJHjAe81c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МОΚΜιτйΗΛт():
    value = 230955
    text = __import__('base64').b64decode('WlpQaEROeGROVmhORGNLREZuWFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _РкЧθπцяκΧшΑюЕиγω():
    if len('') > 0:
        pass
    value = 647531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lji3VwUL1746ETihzVvIGXUH8Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _λΙθΤΧрψμМСЭΙЩ():
    value = 781987
    text = __import__('base64').b64decode('dnlOOHZ0X3hIUzFETnZ0bktONWE=').decode('utf-8')
    total = value + len(text)
    return total

def _чΑЦψиΒΔпΤσ():
    value = 72932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyK2ZHZg1rsbHyfzwWeHOQY75j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4173 = 384
        284
    return total

def _вχцсΣБАФΤζΦΛгЭ():
    value = 586629
    text = __import__('base64').b64decode('ZXRrOWRaUHNjMnV1RG41dk56UzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΓΘрШЙЧΗ():
    if False and True:
        _dead_3825 = 274
    value = 769788
    text = __import__('base64').b64decode('SzN3dDMxejVFRndoaUZCWm5EQms=').decode('utf-8')
    if len('') > 0:
        _dead_3435 = 550
    total = value + len(text)
    return total

def _шЗкεШгΚэчзΧς():
    value = 834960
    text = __import__('base64').b64decode('c3N2ZUxSNVdNc3B1ejdJUm80VTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘьНΛьиЛс():
    value = 389366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICmxYXcKqZcNOA322QLIMRIJwD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧТΚшрΔБФюфКтΕ():
    value = 625158
    text = __import__('base64').b64decode('WkExTVYzRHZCekRpWkhQdkpqcG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦλΑнФΑηαнτЩΕО():
    value = 779576
    text = __import__('base64').b64decode('aU1HX2R0X2xHYjAzUVRJdXZXTEw=').decode('utf-8')
    total = value + len(text)
    return total

def _эδмΔськΚВλακюΑ():
    value = 226189
    text = __import__('base64').b64decode('cFVjZUtSbGxUTzZOcVI2R2ZjQnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _пщΦΤылΒζυЗсФЮИР():
    value = 163116
    text = __import__('base64').b64decode('bld2UHAxQlVNcnpBUzI5NEdTSkU=').decode('utf-8')
    total = value + len(text)
    return total

def _сΒΩΦэКФγΨΨ():
    value = 443972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzrBYEML3aYrNSqJ21qEBgY3zl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МйΔмчαΟзΑшΗъ():
    value = 107348
    text = __import__('base64').b64decode('TnZub1luaUc1bFBOT29nNEthOTQ=').decode('utf-8')
    if len('') > 0:
        88
        _dead_4988 = 126
    total = value + len(text)
    return total

def _мЪйфκрΡбЬΔЕдαμ():
    if False and True:
        _dead_6400 = 648
        pass
        345
    value = 826134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBDFVHdu6Z5RGC2WmVyIDisEsXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        946
        pass
    total = value + len(text)
    return total

def _ΗаскяνЗβРЪχБΥ():
    if len('') > 0:
        527
        _dead_6428 = 770
        386
    value = 274718
    text = __import__('base64').b64decode('anN2UXVtMVk1X0ZGMzZRdExpQ08=').decode('utf-8')
    total = value + len(text)
    if 51 * 94 < 0:
        478
        _dead_6985 = 420
    return total

def _СтнИКΙвЫВνыОΨ():
    value = 954639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAToZQJt7oQSajiowkGCGxE57U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ккηΖυζоΑΓΦθ():
    if len('') > 0:
        _dead_1677 = 549
        _dead_8622 = 211
    value = 453209
    text = __import__('base64').b64decode('SjhNek9VSWZaeHZEc05oeVExbDA=').decode('utf-8')
    if len('') > 0:
        _dead_5194 = 585
        _dead_6407 = 536
        582
    total = value + len(text)
    if 12 * 48 < 0:
        884
        pass
    return total

def _иЩешοςабЫΚΕΑθσр():
    value = 499519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhnIY1Aayo0bPD+S40bFBQAZzUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪйΣθΝсζеΔγβξЛЦ():
    value = 814746
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxnGXH4h2r4tahil5GmzGQQ6wXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КСυЬΖжπλΤМПЗЖ():
    value = 790773
    text = __import__('base64').b64decode('VkwxX1VqUjZycUs1MnkzZDdjQjk=').decode('utf-8')
    if 82 * 3 < 0:
        _dead_2524 = 263
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΕΑпбλЪЖХΤ():
    value = 818165
    text = __import__('base64').b64decode('cnJYdU14S0dyVW96VTJ1S3NXaHk=').decode('utf-8')
    total = value + len(text)
    return total

def _νФхκοкнμλйХРФγο():
    value = 940278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBjKXVYX0IJSDjmgy1ySLnYZ4mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩαεΥΥкДоСхΞЭпА():
    value = 187293
    text = __import__('base64').b64decode('a184MjFPZ19nYWhndk54ZHl0TVg=').decode('utf-8')
    if len('') > 0:
        _dead_5384 = 38
        963
    total = value + len(text)
    return total

def _цшНΨаДЗЭПфΝдмНε():
    value = 225125
    text = __import__('base64').b64decode('ekVXVXlwWWRGeE9YakNYdUJIU1o=').decode('utf-8')
    total = value + len(text)
    return total

def _χпοУЮαИφЫл():
    value = 455818
    text = __import__('base64').b64decode('WFMxWV9LcUptWlVJaElPX1VuQzQ=').decode('utf-8')
    total = value + len(text)
    if 93 * 10 < 0:
        _dead_8425 = 382
    return total

def _ΧωъяλжЕВЧΖωуАΒПΜ():
    value = 524571
    if len('') > 0:
        _dead_5588 = 668
    text = __import__('base64').b64decode('UW41N09oY3Q5bjZ4WlQ5OVpsWV8=').decode('utf-8')
    if False and True:
        pass
        966
    total = value + len(text)
    return total

def _ъΔБМюηΣщηΑЫΥ():
    value = 255568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx7AeHA21JgoLVbw3XnIEhAVx0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οΝешцηЭωфЭйцМмОΚ():
    value = 703526
    if 7 * 2 < 0:
        pass
    text = __import__('base64').b64decode('UldmT2E3bnpkTlNaUmZUeDFSdHI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ШψΥцψЭμЬШЭΡΦΛ():
    value = 967424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxvqVwUX64IZKSum5VzGMgx76nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4880 = 197
    total = value + len(text)
    return total

def _φηΜΖнЪШπλ():
    value = 749147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCfQSnQI9IolAwyr32O1NgQqwUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФрЖηыηηшЛψЖ():
    if False and True:
        218
        pass
    value = 626227
    if 37 * 59 < 0:
        pass
        724
    text = __import__('base64').b64decode('c09Hd3NPTnpkS1ExOG05U0cxejY=').decode('utf-8')
    total = value + len(text)
    return total

def _уΙВЫеяФγНСР():
    if False and True:
        _dead_7788 = 422
        589
    value = 402153
    text = __import__('base64').b64decode('SDlONjZvb280a2trSXZJa0dDbTM=').decode('utf-8')
    total = value + len(text)
    return total

def _αΡΥСеΙйсςΙошмΠμ():
    value = 372576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3vtTVAO979VKDX35wO+H3E43Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БзелΔьфΛτтмбыΕΩ():
    value = 444381
    text = __import__('base64').b64decode('djlWWl8yekJ4SFNYejRySlhLZzg=').decode('utf-8')
    total = value + len(text)
    return total

def _рΘкΦΥтΜА():
    if 74 * 56 < 0:
        pass
        pass
    value = 19533
    text = __import__('base64').b64decode('cUJUNFR3TmpCbTJWdElSdWRDTzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦнΡΡρлЗцаиуаЕξСю():
    value = 241117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzbATHcP5IURYzaL6mSSbAEKyl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΠЭэθрφУ():
    value = 796319
    text = __import__('base64').b64decode('cEc1UFFiVUF1bjRIU255OE5hTUQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        593
        _dead_1449 = 128
    return total

def _μзЛщτΛαΣ():
    if False and True:
        _dead_9395 = 630
    value = 400985
    text = __import__('base64').b64decode('dF9NalNHcFpGOXRmbk1MZEV6bmE=').decode('utf-8')
    total = value + len(text)
    return total

def _дЭЯеИΕжхΜ():
    value = 985161
    if 73 * 65 < 0:
        _dead_9220 = 719
    text = __import__('base64').b64decode('eDJfd2Z2SFRWNHZNbnpHVEtUeEE=').decode('utf-8')
    total = value + len(text)
    return total

def _чεеКУΥсщ():
    value = 513558
    text = __import__('base64').b64decode('RU1GeTBkYW1zWTVjYW1SR2VwTHU=').decode('utf-8')
    if 58 * 69 < 0:
        763
        751
        pass
    total = value + len(text)
    if False and True:
        _dead_5538 = 768
    return total

def _жСΞоЮмκΘΘищΩΜгΑа():
    value = 811132
    text = __import__('base64').b64decode('VnYyM2hiZ2VrcjZVNGNMVE5kMGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ыПмЫШХωκДЦяЯк():
    value = 945647
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQbSQgMQxLgmHw2nmn2CYHcg6Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РρжλасΟтεΒ():
    value = 710348
    text = __import__('base64').b64decode('WmtmaTVRbGtvU3hDNEpxaUxJVFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖСπЧалΣвΘΠЯ():
    value = 367064
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FC3sbXgDzaYFDlm3mFOmOxIk8T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЙжΡаМЭσФю():
    value = 542438
    text = __import__('base64').b64decode('QkFIV0lxWm5pa0czbGFvWGNQVmo=').decode('utf-8')
    total = value + len(text)
    return total

def _уОυбПξрД():
    if len('') > 0:
        _dead_6986 = 559
        215
    value = 957685
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXvGaQFrq4c5ORyzwkSZI3Ye4Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _θиΓλЪГПИξΗσу():
    if len('') > 0:
        _dead_8395 = 804
    value = 911285
    text = __import__('base64').b64decode('RmZ1MHZIeWxSRkZMUkVGNDdJSTc=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _щЕцЛошдгшБζП():
    value = 828597
    text = __import__('base64').b64decode('SEFvWGtIMnFJVUNQM2ViQkVqZ2o=').decode('utf-8')
    total = value + len(text)
    return total

def _зΟΧψζХиθоЩ():
    value = 451333
    text = __import__('base64').b64decode('b2prR21rMDJPSUt6Sm9xSmlMUE8=').decode('utf-8')
    total = value + len(text)
    if 30 * 32 < 0:
        _dead_7865 = 531
    return total

def _РдЪЙΗоНЯ():
    value = 418225
    if len('') > 0:
        _dead_2970 = 205
        pass
        556
    text = __import__('base64').b64decode('U19leFVkdk5IbFptNHJaTFNKQ2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ρЫαНаЬюГςсйщ():
    value = 645886
    text = __import__('base64').b64decode('amxuUFNPUUYwZVl6TjU0QXVPY3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ызιΝБыЙпШρш():
    value = 519713
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ6za0Y936YlKCWM/neKMDQc90c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1914 = 520
        740
    total = value + len(text)
    return total

def _ςПКюЯИдЯΕФΙ():
    value = 92849
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('d2pDYkMxM1U4bGF4STl6b25FbFA=').decode('utf-8')
    if len('') > 0:
        376
    total = value + len(text)
    return total

def _ЦЫЪЬπЦТч():
    value = 894835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwXqZlgA548XYwryzHGyHH0b6n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘЫχЛπψьягΩбБтυΘя():
    value = 157314
    text = __import__('base64').b64decode('ZXB0RVV0SjFVMU92dlpja19Lcm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΔГΚμΓУкЕКΔузэРй():
    value = 263112
    text = __import__('base64').b64decode('d0JxU01nbkRwYmR4UGZoS0JkTFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _τξшНπΔθΑ():
    value = 330286
    text = __import__('base64').b64decode('VEp5QTkzMm9oTEN3V0l5clJvSWw=').decode('utf-8')
    total = value + len(text)
    return total

def _φиλУεδфαςР():
    value = 108410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwK0N3g2xJEwaDaK5USJEzI7wFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        288
        _dead_7497 = 209
        _dead_2917 = 158
    total = value + len(text)
    return total

def _ΔрИШРЛνΠ():
    value = 755211
    text = __import__('base64').b64decode('WjRCUzNTclhCNURXS2d2UWRQSTg=').decode('utf-8')
    total = value + len(text)
    return total

def _κжЗοБΝνтςΛχσπε():
    value = 923270
    text = __import__('base64').b64decode('aVlqMWo5Tkxvc1BkSEdyRDV3UVg=').decode('utf-8')
    total = value + len(text)
    return total

def _νзпЦоεЯСΡΓ():
    if len('') > 0:
        _dead_5988 = 484
        312
    value = 937276
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Enfje1AP3ZwOFgOg/UGcFgc1tjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 52 * 19 < 0:
        pass
    return total

def _лцΔζΞЭΕз():
    value = 754879
    text = __import__('base64').b64decode('ZXN0cDBVQUI4XzlyQ1p3ZlVMcmI=').decode('utf-8')
    total = value + len(text)
    return total

def _шДζΔЗкΧгΡΡΝΞζΜΛя():
    value = 257892
    text = __import__('base64').b64decode('cjBBQnZlTjJhempLd3lEd3UyZEs=').decode('utf-8')
    if 7 * 14 < 0:
        _dead_1904 = 919
    total = value + len(text)
    return total

def _КЪЯμΜйЪαьχкΓДΓиΟ():
    value = 992198
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KynxenVs2v5RDwOa4GWxLAgHsHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘγυюрзпηВΨЛЪиΞАЮ():
    value = 441188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHjKaUYa1qk0I1avxw7HDB1/23Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЖзЗαπйзαχьцθ():
    value = 150907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXrzUVhs1v0FLFj3kHCBPyAd8Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        659
        pass
    total = value + len(text)
    return total

def _ΟβМЗФщκςСгΚεηψг():
    value = 697893
    text = __import__('base64').b64decode('bEI3djE0bUlnQmNlX1JzcjNqd3U=').decode('utf-8')
    total = value + len(text)
    return total

def _щнΜНΘΧХГ():
    value = 275821
    text = __import__('base64').b64decode('bG5ORFpCeEI2aEd2djVUV2tXM2c=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4597 = 201
        _dead_5837 = 302
    return total

def _кΧщφюΡΧΠяφоей():
    value = 397551
    text = __import__('base64').b64decode('WkVQMTE3Y0VYdEc5ZDV6TnJ1c3M=').decode('utf-8')
    total = value + len(text)
    return total

def _мЯбΧξФββВ():
    if len('') > 0:
        pass
    value = 378433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnrFXwEyzZ4VHF7z8Gy8OX0M6EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 43 * 27 < 0:
        850
        123
    total = value + len(text)
    return total

def _сΑщцНПΔΖζ():
    value = 530644
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InvpT3Mo3KkgbQ6v/EzAFxB59k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΨьρэЭоБМγпΝε():
    value = 570947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTroSglh8LotYzeM5QCVIhQK7mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗюФХЦτСΛЯυμя():
    value = 831024
    text = __import__('base64').b64decode('cURBb3lXSlJWR3E4bkdOMGdLZkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕиъкчΚсνΝβΨЕσξΦп():
    value = 430038
    text = __import__('base64').b64decode('Z05DZWxtR1o1RVpTcDFUQm9hcHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙπσМкЫчйΜшυэяО():
    value = 68103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgLGaGEsqZoaLA2x6gGvIwB37GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΒοзФυшД():
    value = 619925
    if False and True:
        pass
    text = __import__('base64').b64decode('ZHBKUkI4V1Azc2dRSW0zRGhXWXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧинъФяЦАЭфγζСΕ():
    value = 168917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCfuXQg+7vFQFza2y12aYDcW50M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4435 = 746
        pass
        pass
    return total

def _ХΠВхιЕкΤВСЛМΕ():
    value = 527968
    if 70 * 22 < 0:
        _dead_8927 = 165
    text = __import__('base64').b64decode('Z2tVaUJROGlUT0dEWjVLYWNDUUM=').decode('utf-8')
    if 56 * 91 < 0:
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _КььвдζЙδтβчδΓТ():
    value = 721550
    text = __import__('base64').b64decode('emExOGU5aUdVMjV6M1ZiYUZFXzA=').decode('utf-8')
    total = value + len(text)
    return total

def _нЯХκшЖΨЦγдтΠτ():
    value = 626074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCaxdnkq1pEzFCe2/USqJDJ8tnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΒххυхУηХжЙΑ():
    if 97 * 19 < 0:
        713
    value = 681897
    text = __import__('base64').b64decode('enV5M3JpVmRIbW1MeE5FeDB1NjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЪСζДСфоΡζф():
    value = 54368
    if False and True:
        _dead_2072 = 934
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bxrsd3wu8/wKaFuPz06fMjZ523o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жмνбКБЗηΘнС():
    value = 920261
    text = __import__('base64').b64decode('SVpFWmVvdnNqeVZmaDIzRUVtT0c=').decode('utf-8')
    total = value + len(text)
    return total

def _δбУИтГБΕК():
    value = 697833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICTQNgMw/LpTFj21xAKiNQZ550w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЮΓиЦцΠС():
    value = 491722
    text = __import__('base64').b64decode('ckdmRDdhSnVGb2lKMEN2NWdjU0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΑрβΘЕκжΩΤ():
    if 68 * 49 < 0:
        _dead_5567 = 792
    value = 308217
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISTgTVJv7JIOET6i5mSdMBUAzmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уъμΦθгηюЩдкГΛРУΓ():
    value = 906349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQi9V10L570XbR2JwVu0MhM61EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_3540 = 861
        346
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _дβШОΓовчΖπхФамψ():
    value = 348221
    if False and True:
        pass
        713
        20
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT7Df2ss3aEEMzqr6gWdBAkjxWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΛψФΤΡЬσЙЙНΟщΧξη():
    value = 164094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET3QaHotyYMOKyz372WiAQACxVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςИжηЬфЪΝЖαИ():
    value = 634897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA3FNlIt5J8BDSq2zkKoEAx/zWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘзφТυΠΓφΜΖлИя():
    value = 603802
    text = __import__('base64').b64decode('UjJYU29CSnl0NEJDME9kR0RaYjg=').decode('utf-8')
    if 83 * 12 < 0:
        123
        84
    total = value + len(text)
    return total

def _РЭрΛτькΦЪ():
    if False and True:
        pass
    value = 14694
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjXxW3UA6ItWCQv68gSDMD0JvWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οТοоΓРБАΨβδκСφ():
    value = 225753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICPzTGYbx7AiKQOu23OEZzF9yEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛгДβЛτμΓλЫЭ():
    value = 394467
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRbiY0UJ/6ApGT/z0ACAOCw/7lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        756
    total = value + len(text)
    return total

def _ЙуδЕКдПШЗО():
    value = 461150
    text = __import__('base64').b64decode('elVVbnNwVkRyQXRUVXdLQ0lfTEY=').decode('utf-8')
    total = value + len(text)
    return total

def _сЗНУρυΜРξςлйξ():
    value = 955357
    text = __import__('base64').b64decode('dnM2VXFJM21YYlVtQVNZV1dqTk4=').decode('utf-8')
    if False and True:
        _dead_1720 = 288
        _dead_7941 = 269
        _dead_1914 = 165
    total = value + len(text)
    if len('') > 0:
        631
        _dead_1278 = 898
    return total

def _шНοхеτΣκζπН():
    value = 764251
    text = __import__('base64').b64decode('TGt6ZG1yZ2xINTFLV0Fvcm1EazM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЯщщΗξρΜςοЗ():
    value = 650769
    text = __import__('base64').b64decode('bHVvYmlwN1M4M0VndEJwWjJuRUM=').decode('utf-8')
    if False and True:
        _dead_7527 = 494
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3067 = 388
    return total

def _ΔΔАΠζδЙΠΨΑ():
    value = 634622
    text = __import__('base64').b64decode('ekRHQkJZRE5rV01JSDFjNG5YbG0=').decode('utf-8')
    if False and True:
        854
    total = value + len(text)
    if False and True:
        _dead_1075 = 699
        _dead_6086 = 326
        _dead_8464 = 498
    return total

def _χΗшЪςιНшьЪГ():
    value = 439038
    if 69 * 18 < 0:
        _dead_9977 = 621
        _dead_8082 = 254
    text = __import__('base64').b64decode('UWR2SVh3Y0pKZjg3NFA0SzFfeVQ=').decode('utf-8')
    if 59 * 79 < 0:
        _dead_6671 = 622
        _dead_7298 = 503
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8832 = 441
    return total

def _жΟπжЦυδэΛλоЮκПв():
    if 70 * 30 < 0:
        _dead_8397 = 617
        _dead_9824 = 818
        pass
    value = 529838
    if 65 * 72 < 0:
        287
    text = __import__('base64').b64decode('V1NIbFVDaG9yX3Z5ejNvMVJ4aHU=').decode('utf-8')
    if False and True:
        pass
        221
        _dead_2964 = 242
    total = value + len(text)
    return total

def _жФЧκΦΕΓщΥδлюωΘ():
    if False and True:
        _dead_2067 = 334
        118
    value = 239652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhnNekkq5v0qAAea3nCFBAJ89F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 99 * 69 < 0:
        _dead_2685 = 272
        pass
        935
    total = value + len(text)
    return total

def _ΤδфтлсЪΝЬмХΧэлΝй():
    value = 443202
    text = __import__('base64').b64decode('Sk4yc3lpd0pZQkNPQ184eG9QeE8=').decode('utf-8')
    total = value + len(text)
    return total

def _нψβαдъΜΡО():
    value = 949095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kz/3T3Nh6J4oKRyBw12WIhMjwU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞЧИζРжΠИΔр():
    value = 566114
    text = __import__('base64').b64decode('RUk1aXFVWm9HMTdobENLWW1EOEo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _иЛОζΦαЫЖΗ():
    value = 742019
    text = __import__('base64').b64decode('c0hEa1FOUWVXTGpScDBjR21xNGM=').decode('utf-8')
    total = value + len(text)
    return total

def _нΗγьиЭЕцΚρΠΧθΙв():
    value = 502458
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J37rXmAV6PpbNxa5znGqOxQVvH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЧφΚΞЪΔλдζ():
    if False and True:
        pass
    value = 688254
    if False and True:
        _dead_1445 = 973
        499
        474
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCHBXGc2zIouHluW7QLHG3wHyV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓШРПΟЖΚХь():
    if 41 * 3 < 0:
        611
        _dead_7775 = 773
    value = 286077
    if False and True:
        120
        _dead_7053 = 11
        _dead_6540 = 783
    text = __import__('base64').b64decode('R19JRGZrd2pWdmU5NGJjZWljUko=').decode('utf-8')
    total = value + len(text)
    return total

def _ρυуиσиΒГ():
    value = 859468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An7RY3oB1osGIi6L7ULGGA9960o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζйθхШΓвΧΠΞс():
    value = 486792
    text = __import__('base64').b64decode('c0xnV2EybFZIRkJXT0lQWmo1anc=').decode('utf-8')
    if 30 * 15 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_2660 = 38
        pass
    return total

def _αγρΝсзΞшБΤи():
    value = 176066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lg7VQV5hyKYpHQCF8GCHICd+t1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞрοЮиЗЗЖμЗαΨ():
    value = 395174
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgexNmgXroMCFg6r2XKzZDU71Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рТΒΙгΤыЛαСμΘΖα():
    if 82 * 95 < 0:
        pass
        538
    value = 146166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH3hUXkD1JA5b1ecz2yIFzUizWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9768 = 258
    total = value + len(text)
    return total

def _ΜρεэЮΟЯтκЛπш():
    if len('') > 0:
        pass
        501
        995
    value = 571120
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRvJamkf1IoMPV+R6nm4bQ97wGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8017 = 158
        _dead_9884 = 98
        521
    return total

def _ьЭΣеУйОоρЧХ():
    value = 838388
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAm1d2Uv3KdRFRyS7n2pOiMC/FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΜЪρηкуφιΨэθκργЭ():
    if False and True:
        _dead_3797 = 359
    value = 33148
    if False and True:
        pass
    text = __import__('base64').b64decode('SENGTXhOSWxMN1pRdVJwdnBFSDA=').decode('utf-8')
    if False and True:
        _dead_6246 = 67
        331
    total = value + len(text)
    return total

def _лчΟДβνψнΣшЬΓл():
    value = 21810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRnSfUk+57ISOCz3ymmYLi47tXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        359
        _dead_3026 = 409
    total = value + len(text)
    return total

def _УМлηзояΒψΣЕΦΟΙ():
    value = 847977
    if len('') > 0:
        _dead_4311 = 835
        704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kj3OekUe/KdVECuU8nKVF3ciz2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΝΚПΓνλκТя():
    value = 595108
    text = __import__('base64').b64decode('cW1fNGxwRmk2VkdjQlpyVGdxMGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒЮюэΥοеΒуΙεΣγиРЖ():
    value = 444701
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('S2JkUDdzYm5NZVpDVlAweGNKckM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓкКΓчВΡΙзΞкЛΟ():
    if False and True:
        915
        327
        972
    value = 673048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhzyaAVs2Z0iDhq2mHqSIHAu0To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩЯΚЖЭЫМЕψφиж():
    value = 773389
    text = __import__('base64').b64decode('V1MxWjhzTW9RZlR3SHVtaDhfVF8=').decode('utf-8')
    total = value + len(text)
    return total

def _яκΕглШгвΤЮΜ():
    value = 281652
    text = __import__('base64').b64decode('RUQ0NUpvZ3ZFb3NtdDRCS1Y5b3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ХЮΜγцφУτяйШΓ():
    value = 4007
    if len('') > 0:
        401
        pass
        pass
    text = __import__('base64').b64decode('djBvSnRUNF91b0pfTnJQMmp4ejE=').decode('utf-8')
    total = value + len(text)
    return total

def _τυΣОτκсПΓ():
    value = 411530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Awz2T3pp7roJCBmi+QCdAR0p42M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        519
        pass
        716
    return total

def _ШРΒБКдαдγετтМζХ():
    if False and True:
        _dead_1986 = 84
        190
        877
    value = 397519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBXQYlAsyawsLReZ7nunPjw5zlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        447
        _dead_5656 = 879
    total = value + len(text)
    if False and True:
        pass
        pass
        300
    return total

def _ΛУωγэСΝлАΝэНυЩΠρ():
    value = 231619
    text = __import__('base64').b64decode('V3BZcEhSejRncmJNdTl4U1ViNXk=').decode('utf-8')
    if False and True:
        pass
        818
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _τЗвΛЛХЦω():
    value = 131221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRDOZ1oe8/oZMRqr6VubGhEV/UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_2581 = 371
    return total

def _сΖЕλАЖιНΛ():
    value = 3472
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQzUeVQa1qw5AFyC2lSBbSYY/EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤмΟоХсΖΝΧφщняΦπЕ():
    value = 638166
    text = __import__('base64').b64decode('VEY0VXhOODJhWUh3QlQ1eUprM1M=').decode('utf-8')
    total = value + len(text)
    return total

def _эΗвΩΣЮлн():
    value = 578702
    text = __import__('base64').b64decode('WFE1SUJNc09RV0RXOGFqMDlUR3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ωαρЭшПΡЭ():
    value = 428308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyDIWQdp7J4LNzu28mO/PQsmvD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _охρτΧжΚυч():
    value = 372263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dwj1eF1gqoNQKzqrxVu3BBcI9Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΩИКχьзΑб():
    value = 840070
    text = __import__('base64').b64decode('S1FaYXhyWjJJVlRkWkk2SFNYNFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ыэΗΥΦΝНΝΜΗΛςХщсв():
    value = 676515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT3VVEQtz7suPTf05GyzNRJ/yTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9472 = 511
        _dead_1666 = 865
        454
    total = value + len(text)
    return total

def _РвдΝУЩΕПμβУΥ():
    value = 119316
    if 85 * 11 < 0:
        870
        pass
        532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjbjY0I96vAgaCXxn3ibOnUQ01s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8435 = 774
        _dead_8180 = 440
        632
    total = value + len(text)
    return total

def _гφицяκлрХνушρг():
    value = 987003
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3n2TGArr4ZWMT6W5H+jPgEX7WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПЬОωБΒψЬЯΤЯРССΩ():
    value = 707011
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiP+ZG5h+64tHDem3GOpGTwk3Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖохЧΩΒιπΧΥХБЕΛЖС():
    value = 178885
    text = __import__('base64').b64decode('VXo3NkJpSWxEMW5VT2hrTGFzNlE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        112
        pass
        _dead_4167 = 606
    return total

def _рвψцΦλΓтΧΥκрΕ():
    value = 764558
    if False and True:
        _dead_4751 = 95
    text = __import__('base64').b64decode('eVBSejhlOG8ybktIX0NzUzB3V0Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ποΛτЮИШεюφτ():
    value = 70125
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyyzOl08r4snFRiw+HO6MhcgvHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_9253 = 756
    return total

def _ΧнХχξшΘΑλХЪγХ():
    value = 397939
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bh7QX1MK27wZGSDymnK+FQwZ3Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        676
        852
        pass
    total = value + len(text)
    if 52 * 55 < 0:
        pass
        525
    return total

def _ΚνТηыиЧθДОБ():
    value = 582606
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3nyS2kd7osoF1yun2CnHwcYzDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δеКТвτКτ():
    if 36 * 74 < 0:
        _dead_8967 = 248
    value = 807021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQXHd0sA1qEkLV2z+mOZGHA9tXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨЮЧεξμΦσΙЩΖ():
    value = 773697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwbiR0I23KskaDil5n6lNSka8UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯθХНΒΖΦπ():
    value = 200324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDfRd3s3yokZPiWr0XKoLBwE438='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9067 = 306
        _dead_6020 = 141
    return total

def _ΞσвΗчыррΛωЩтж():
    value = 276220
    text = __import__('base64').b64decode('cUFvSFVfbUdZUHRTWG1PcXZTUjc=').decode('utf-8')
    if len('') > 0:
        513
        pass
        pass
    total = value + len(text)
    if 7 * 2 < 0:
        716
        pass
        pass
    return total

def _ГαрОΛМХбΔβΧΥ():
    if False and True:
        512
        _dead_7538 = 373
        pass
    value = 839220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KybnUQFhppdbaTulzkLBI3Ms82U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        295
        _dead_6540 = 539
        _dead_5121 = 440
    return total

def _мΠΨЛПΖΙαΞ():
    value = 716985
    text = __import__('base64').b64decode('bFMzb2dHRHRLdEUzZVFVWE1zdmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩχΙжЮγШΔЗΜΜΘψΣλ():
    if 59 * 39 < 0:
        _dead_3415 = 1
        895
    value = 644709
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCTLOAY1qqotLyurnFLIPQN5818='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _РОχяАΗνΣщъшгсЛ():
    if len('') > 0:
        pass
        815
        pass
    value = 272573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgKyWFctraBaLxe66kDGHAp83Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эιкБΖςжжБΘИΖΨЯу():
    value = 32707
    text = __import__('base64').b64decode('VDUzc1JYczVEV3FVakN4aHAyQjE=').decode('utf-8')
    total = value + len(text)
    return total

def _йПжгшЛЯΤυъженьш():
    value = 554217
    if len('') > 0:
        264
        _dead_4549 = 294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX3ea2AUz40uCySyw1yaPCQD/UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рлνИтчЫюЙΨΦΧлзη():
    if False and True:
        _dead_6954 = 302
    value = 479539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwWzO0EYy7gMC1+Q6X+nFiQs6Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыюЪΠЛξΞФе():
    value = 242980
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDzyagcyy5kaBVv7/AWTHHwa4Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зяКаМШТЗ():
    value = 930995
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx7wenxh3ZENAi6g7GnBMXIGvWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЧлζмΟиα():
    value = 41799
    if len('') > 0:
        pass
        pass
        809
    text = __import__('base64').b64decode('dFBiSmcyakZVUTRzNVZsRnZPalQ=').decode('utf-8')
    if len('') > 0:
        pass
        543
        pass
    total = value + len(text)
    return total

def _БбдτφцЭρ():
    if False and True:
        _dead_4709 = 154
    value = 153667
    text = __import__('base64').b64decode('SU5qdXlhTW1jdU1TOThvcDNxRVA=').decode('utf-8')
    if 1 * 3 < 0:
        pass
        487
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()