#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _χΗАΩчςьрМлδЕΩμ():
    if 46 * 83 < 0:
        860
        450
    value = 894225
    text = __import__('base64').b64decode('RVdZV2V2TVNraWpjelVFQXpNZms=').decode('utf-8')
    total = value + len(text)
    return total

def _ьζΜЩΩΣΕх():
    value = 187802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRXqd3IsqrohNAOvn0CiOj0I21w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΕнΜыхωχЩЦμΥО():
    value = 981690
    text = __import__('base64').b64decode('QnVLY1pHQXFFcHFXcnN1ZTNCUVk=').decode('utf-8')
    if 12 * 20 < 0:
        496
    total = value + len(text)
    return total

def _ΦΧΦрКαЗйфεЕτεΘ():
    value = 276818
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBrJPFUcrqUraVa27QK+Ai44z0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΝυъТνНяЭζ():
    value = 329730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITbTb0Qa/6w6KDjw3Ue6LQQs6H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥяΦЕπΦмьΜг():
    value = 416545
    text = __import__('base64').b64decode('amxHRkdiRXhaQ2kyb0d4YnNBemM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯЫУθρЧжВξЮ():
    value = 226394
    text = __import__('base64').b64decode('T0NLdk03TVZuSjI4d1d0WWNGMTk=').decode('utf-8')
    total = value + len(text)
    return total

def _πючвΧЭНΞЛРομλЮ():
    value = 518770
    text = __import__('base64').b64decode('QUJmMkZ2UmsxNkZnWnd3UkFDZjI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        786
        339
    return total

def _ЩЙδРДУшυФзΘηкюЕ():
    value = 882415
    text = __import__('base64').b64decode('enh1eXBjdnc3WFJ5QlVXN1NjZnk=').decode('utf-8')
    total = value + len(text)
    return total

def _БΩИΝξПζЬ():
    if len('') > 0:
        pass
    value = 441774
    if False and True:
        395
        _dead_4631 = 430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSvdZl4byJsEaBfw43CeZSYN40Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 63 * 79 < 0:
        pass
        986
    total = value + len(text)
    return total

def _пуΘΦζъеь():
    value = 21841
    text = __import__('base64').b64decode('TzcyblhMRzRHTVR4ZWV0WGI0RDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ОЪЬИΚНГрэαλУ():
    value = 162640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBbuW3UWr4MaAgi28mWeLAErzWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 61 * 39 < 0:
        pass
        _dead_5025 = 436
    total = value + len(text)
    return total

def _ЛΨбиЛΙαшмУΡрИБ():
    value = 454881
    text = __import__('base64').b64decode('a2FrelcybnBZMm1mZGY1ZTh5Qmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥζΦΘναБВΝΡЫγ():
    if len('') > 0:
        207
        404
        pass
    value = 175639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDzjelYt0YlaaTWu/n6JGTYjwVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        411
        pass
        _dead_3726 = 590
    total = value + len(text)
    return total

def _ΞчγρКйЭКξ():
    value = 648756
    text = __import__('base64').b64decode('TEpDd19uYldBUHg2YXNIUU1RVkU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        64
    return total

def _ΕΖЦвΜκρΕр():
    if False and True:
        595
    value = 969486
    text = __import__('base64').b64decode('QWFoWXlEdkU4X3lKeElJbzFVSU4=').decode('utf-8')
    if len('') > 0:
        625
        178
    total = value + len(text)
    return total

def _РяΦциιΓМφ():
    value = 877726
    text = __import__('base64').b64decode('cVZCejdxUnlCRnhHWndkRm14Yzk=').decode('utf-8')
    total = value + len(text)
    return total

def _уΣрΧЛПΖб():
    if False and True:
        _dead_7473 = 898
        pass
    value = 359079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHrDR1sKy68lOzb37n+xZgoevU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥγиаΝНуοΙ():
    value = 387032
    if 59 * 38 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyH8X1Ng9oskDV+lxgS6OwAXs1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 10 * 53 < 0:
        663
    return total

def _ДПзΥШЫυΣΞ():
    if False and True:
        pass
        _dead_9231 = 650
    value = 819403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyzOfkEsqYwHEASR2nTGYx0g7Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зςυбΥПцЛъαй():
    value = 297730
    text = __import__('base64').b64decode('UmVVNERoZlRHUm1BNVk3WmxtX0Q=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЮλΡЮЗсаΩΖΥφц():
    value = 897348
    text = __import__('base64').b64decode('b0FaOGw1VDJpUnBQaWo3WmxfU0Y=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_9097 = 839
        pass
        80
    return total

def _ΔДΖчИηуЬτΦО():
    value = 471399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh32R15v8YFXAwq3ynCeDSwhwWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 35 < 0:
        pass
        39
        419
    total = value + len(text)
    if False and True:
        _dead_9122 = 682
        455
    return total

def _βжΔъТιЧΧаΚΘ():
    value = 199552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTbUYVkM+ro0HDW3/HiFEQgu6ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if 88 * 61 < 0:
        _dead_2655 = 123
        160
    return total

def _СДηчуВхШзΒΨйщθθ():
    if 51 * 5 < 0:
        pass
        _dead_7830 = 874
        172
    value = 879960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCfvWHMD//AWHwOHzEGHHTAl1ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аМоЬЬЮΧМюИ():
    value = 462515
    text = __import__('base64').b64decode('ZTlsbG56eWhsRTQwZDcxZ0ZVaUw=').decode('utf-8')
    total = value + len(text)
    if 31 * 41 < 0:
        _dead_8552 = 23
    return total

def _ΩоαРШΞτεζЮКπυе():
    value = 846478
    text = __import__('base64').b64decode('Rnc3U2w5YnBiVGpiMEphbWtKemM=').decode('utf-8')
    if False and True:
        _dead_9846 = 334
        _dead_3656 = 750
        _dead_7586 = 103
    total = value + len(text)
    return total

def _ФωНρμΔЪπι():
    value = 482505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyvqfWQf/b4tCgmWzWCxMDI5xWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4822 = 817
        pass
    total = value + len(text)
    return total

def _МИΗнТТηλюхрВΒдΗа():
    if False and True:
        pass
        _dead_1564 = 770
        pass
    value = 512516
    if False and True:
        pass
        pass
        9
    text = __import__('base64').b64decode('ZVY3eVZFOW1zY2lybWgwRGVXUUo=').decode('utf-8')
    total = value + len(text)
    return total

def _тЛРчЮΟΣΘΤΠΑ():
    value = 823441
    if 80 * 16 < 0:
        508
        pass
    text = __import__('base64').b64decode('cnJZV2JxNXFfWmt6Rjl1ekJlMXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪжЬΠзЫДυ():
    value = 453398
    if False and True:
        _dead_6598 = 158
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDXibQAt/6IFAFub8HukbQQp3j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9725 = 564
    total = value + len(text)
    return total

def _зεΡεЫφπαпжШыυσЬ():
    value = 815543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw7gRnQe5pkQPheU5kepPDcm0Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7163 = 145
    total = value + len(text)
    if False and True:
        _dead_2456 = 625
    return total

def _цΘЫννхЕхΡΥШΥРСνР():
    value = 737161
    text = __import__('base64').b64decode('dGVSMlpPaExJUFdrWTFub0xIUGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑЫσсγΝεнФΖЦУΥζΩо():
    value = 518935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAndaFxpxPAAEBuE7kOlYyAM8H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_6478 = 52
    total = value + len(text)
    return total

def _τхГτИЭПДγΗЬйψг():
    value = 313895
    if len('') > 0:
        _dead_6285 = 243
        pass
        678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw79eWEx9KszFQuOnFnEYQkb1WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сЫδЫκлчВΗКЫвν():
    value = 513086
    text = __import__('base64').b64decode('cFc1R2dkdGNtdkFOblVPUm5naFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΚΣβχрδΚЖЙρΘΓχ():
    if 60 * 85 < 0:
        _dead_2312 = 240
        114
    value = 139721
    text = __import__('base64').b64decode('TnJxNmNqclR0RlROZkpvaU9TWFY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9358 = 527
        _dead_3278 = 314
    return total

def _ςИПΡΘεΖЫнс():
    if 39 * 48 < 0:
        _dead_9838 = 691
    value = 172018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnviOUQX/4RWPjyG/1HJHCME9z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 20 < 0:
        pass
        _dead_3198 = 537
        _dead_8398 = 737
    total = value + len(text)
    if False and True:
        997
        376
        _dead_5874 = 451
    return total

def _ΑΚγЫλρΖΧДхуЦ():
    value = 552564
    if False and True:
        583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Awz9XUBtyLIADg6uzmCzBgwkxX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        547
        276
    return total

def _рΦеζЗдХθУХдμГДЮи():
    value = 951100
    text = __import__('base64').b64decode('UUx0TDdJN3A4a1NhR2xmaVM5OVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΛИκуУΠц():
    value = 66973
    text = __import__('base64').b64decode('dWhtdWV2NUNuNGNzTm85UjJaQUo=').decode('utf-8')
    total = value + len(text)
    return total

def _иΗБИΧθаЕзиςωГ():
    value = 671734
    text = __import__('base64').b64decode('R2tEckc4cXQ3bTFoR0trNm5iME4=').decode('utf-8')
    total = value + len(text)
    return total

def _ШоΖθΘюΓЦΓχαюПАωф():
    if len('') > 0:
        _dead_8976 = 467
        _dead_7972 = 583
        _dead_5332 = 288
    value = 621225
    text = __import__('base64').b64decode('VEcwNHowSHF3X1d0ak81eFNfSGs=').decode('utf-8')
    if 41 * 48 < 0:
        pass
    total = value + len(text)
    return total

def _τЫсλтτΑнжэшΝ():
    if len('') > 0:
        688
        pass
        924
    value = 544781
    if len('') > 0:
        241
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bjrwf3oBr5I5KRiJzAGKDRwW0kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        640
        _dead_3960 = 474
        990
    return total

def _ΗαьШΦΑΩШΟΒΥρЫυоθ():
    value = 566570
    if 83 * 10 < 0:
        262
        pass
    text = __import__('base64').b64decode('bkhOQ3JxQ2VaR0ZpTFNxTnYzRE0=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _фξΜоηΠησ():
    value = 588993
    if len('') > 0:
        pass
        pass
        _dead_5529 = 565
    text = __import__('base64').b64decode('WFRKalZlaXl2T2tWUVVsOHc2OFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧдГΩικΗфсЩЪμΗйγ():
    value = 803287
    text = __import__('base64').b64decode('cnFUdWRZRTMwWHg3MU9KRmJ1TVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΥрΘПΚλκГΩα():
    value = 485899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADbpWkYv9KoFHTan5mKbZyoqyX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 66 * 3 < 0:
        pass
        970
        718
    total = value + len(text)
    return total

def _ΗηυΞСΓλдΩыγФΛЯ():
    value = 183575
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('Z2I0eGEyajZGUVluZTYzZmNzdU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΤμψЫεΖцЯΔ():
    if 80 * 63 < 0:
        385
    value = 181177
    text = __import__('base64').b64decode('a1FIaEZ2SDYyOWxkNVBIRTZWRFY=').decode('utf-8')
    total = value + len(text)
    return total

def _λЭИξкΡτδвЭщЙш():
    value = 327061
    text = __import__('base64').b64decode('SHRjSlpsemhNT3FTVWttQ1VwTUw=').decode('utf-8')
    total = value + len(text)
    return total

def _зενωыяСΡΡъΡЙΝлуΝ():
    if False and True:
        pass
        pass
        pass
    value = 219282
    if False and True:
        pass
        _dead_1364 = 825
        979
    text = __import__('base64').b64decode('bVVPX3BwZXNCb1k0MTlkUXRmMm4=').decode('utf-8')
    if False and True:
        pass
        pass
        387
    total = value + len(text)
    return total

def _ΓЮуЫЩНδюς():
    value = 509057
    text = __import__('base64').b64decode('ZTcwUU5jZk1RM3JpSkZRN1FQemo=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЖЬδХБлдПХΡшБ():
    value = 535715
    if False and True:
        pass
        _dead_9256 = 490
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSHNa3Ifq/EXFg7zwgSHMyE1820='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЩΨΙΕшТρΥι():
    value = 217209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgvlYXIK3f4TAjiEykKBBxw25UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΦйХζТκЗбйη():
    value = 856205
    text = __import__('base64').b64decode('czF2dTdoREV4ek5qaGJwS0pJOXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙйεУπИЩмДАΤЕЙк():
    value = 608763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B32xPXcW3Ls6NRWGwUKgGzMBtno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕпМωΚΜРМйИИЩη():
    if False and True:
        pass
        285
        153
    value = 959613
    if False and True:
        467
        _dead_7411 = 584
        575
    text = __import__('base64').b64decode('eUcxZFdnQU1MUllUWFN5NnY0N24=').decode('utf-8')
    total = value + len(text)
    if 92 * 63 < 0:
        636
        pass
    return total

def _мΨΨппнЗθχюь():
    value = 293319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCm9PX0Kz68XbgGa3gKbBQgOsl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕдηефβφХИеИщΛΕΟ():
    value = 857881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwPjfUgDrYYQKjr661qiNTw5zWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _сΔЩχΙдпβЧЛζΛфьыЖ():
    value = 219453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgzvO1wS6qsNGQik0HW9NSAX7EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 16 * 73 < 0:
        _dead_4587 = 629
    return total

def _ΧВбΗΥθξΒοВГβЕ():
    if False and True:
        pass
        _dead_6283 = 709
    value = 561776
    text = __import__('base64').b64decode('R1R4OTlUY1YxSGxiM3RxcVpKSXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖопъπшСязкЦЪРυсΚ():
    value = 499745
    text = __import__('base64').b64decode('UGUwd0J4dkxqOVM1RFhONjEwdGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛьτФЯШсβΨχΛБΤш():
    value = 541454
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lnz8R1MDrJs6GSKGkXW8JCEE/Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬюМСβОхγγγ():
    value = 823082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MR7lV0A23ao1C1+Kw3WRNzAcyDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БрςνФцютΞ():
    value = 516330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTXXXXwOqKxaNQuF0gXBLicGyEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        510
        _dead_4968 = 540
    total = value + len(text)
    return total

def _ξΗШλЪωИΖΞμъМΓσа():
    value = 745993
    text = __import__('base64').b64decode('RFI0N1lVM0pmUk96SWgzUHNUdmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ШакΧΗмкιШσξьЕΦΑА():
    if False and True:
        pass
        896
        259
    value = 244499
    if 55 * 33 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AC31akQ2p/8CMgqXxQDIDXc2vFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        607
    return total

def _иГтχφΓкГкηΦфβЙ():
    value = 94747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LznxagYjpoIGKw26yl+zPhAe3WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хкЧирЮУΞ():
    if False and True:
        pass
    value = 944942
    if len('') > 0:
        pass
        891
        652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgnQe1gVz/4nFCm5y2XHBAsf1Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 55 * 78 < 0:
        pass
        696
    total = value + len(text)
    return total

def _ΙψΔпфЭИу():
    if 65 * 2 < 0:
        375
        _dead_7747 = 422
        _dead_8522 = 148
    value = 7867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDjtQW4QqbsuGzD0nWzGZhp652Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 82 * 11 < 0:
        107
        pass
        504
    return total

def _ΣаьηηΘζпΤΣΝтфορ():
    if False and True:
        pass
        104
    value = 630734
    text = __import__('base64').b64decode('S2E2XzFNMk5QNEVyVVBBUUVkVFE=').decode('utf-8')
    total = value + len(text)
    if 32 * 86 < 0:
        pass
    return total

def _НξΧэмАυДθΕυгЧ():
    value = 558252
    if 46 * 31 < 0:
        _dead_1659 = 697
        pass
    text = __import__('base64').b64decode('SjFnanVsTmdsUVRESzA0TlV2ZVM=').decode('utf-8')
    if len('') > 0:
        _dead_2749 = 620
    total = value + len(text)
    return total

def _аПΤΥхПбэ():
    value = 401715
    if 19 * 27 < 0:
        pass
    text = __import__('base64').b64decode('WldlWGxFYmw5Sm41cFE1S1RwaDA=').decode('utf-8')
    if False and True:
        _dead_3855 = 634
        _dead_3333 = 983
    total = value + len(text)
    return total

def _еМΞΧЫΒцΩΖУфΨΤ():
    value = 436046
    text = __import__('base64').b64decode('d2hvVTdkZ0NtYXA4TEZEQVN2Skk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        199
        _dead_2846 = 935
        827
    return total

def _ψйξΜУГΒэρΡφσ():
    value = 327187
    text = __import__('base64').b64decode('VmZhWHRkZ1VBd0NZX1RDQVJDa00=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜφЯрхюΒчмРЮрΓсжЯ():
    value = 201739
    text = __import__('base64').b64decode('WkxVcFd0dkZ6ODZKamRFdFhQdlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _хжШтΛАΡАВπΔ():
    if len('') > 0:
        _dead_5370 = 453
    value = 606392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz7GaFkU+4EWMj3yxwKRJTA/7jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вεлЛβχγΩΞνэЦΒя():
    if len('') > 0:
        569
        768
        827
    value = 246035
    text = __import__('base64').b64decode('TEtjRlhIbEVGMTFsaGllal9ackc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑяйΔЗТφнйуμδФЖ():
    value = 358207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBzKd2kKzvAXElm1+EKTOS484Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        504
        pass
    total = value + len(text)
    return total

def _ΖψНкщЛДтςΕφП():
    value = 132359
    text = __import__('base64').b64decode('bmpVZHJ3aU04Z2t1c2RyVVZXVkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _уНΡηΕэΚуΩβ():
    value = 708807
    text = __import__('base64').b64decode('TThKMkIxYm5KN2ZnX2xhMDJ5Q2s=').decode('utf-8')
    total = value + len(text)
    return total

def _йιЖδΨбюΔЙУЗΒш():
    value = 898547
    text = __import__('base64').b64decode('emI2SmxnUDRMSjlXSVpTVFJhZlI=').decode('utf-8')
    if False and True:
        428
        pass
        _dead_2798 = 568
    total = value + len(text)
    return total

def _ышΖакРпЯцаγщГψЬψ():
    if False and True:
        pass
    value = 30373
    if False and True:
        _dead_4584 = 955
        165
    text = __import__('base64').b64decode('VkxCeFlZNWJVR0FGRGY0ZjdEbm8=').decode('utf-8')
    if False and True:
        222
    total = value + len(text)
    if 77 * 85 < 0:
        465
    return total

def _ъЮΝГыфчмФНр():
    value = 387529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyvzO0Mfxv0HDB602FKyZQQD8E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эПνщβжЛιΞ():
    if 11 * 74 < 0:
        967
    value = 504938
    text = __import__('base64').b64decode('ZXRMVW0xWHRNSFBqam93WkxRdUc=').decode('utf-8')
    total = value + len(text)
    return total

def _НМСЖΑяКЪо():
    value = 80379
    text = __import__('base64').b64decode('Zm5vckFCMWg3REpONGQxX3pXZUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛАΗΓεΔчЧσςзαλЯα():
    value = 194567
    text = __import__('base64').b64decode('TEZqZEFLamxLNzBibVBqS2xObGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜηэΧУаНΥфδΑФιεж():
    if len('') > 0:
        221
    value = 743725
    if 94 * 55 < 0:
        623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3fzX3Mc64A5OwaaxQaVDgQCwXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 54 * 1 < 0:
        _dead_7441 = 48
        _dead_9235 = 693
    total = value + len(text)
    return total

def _ωΠΒЕълτЯяЕ():
    value = 512483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBq0ZWMz86c6bjCq2nidBSIGzEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьЩΘυЩБΤЩΔсσΟβЩцМ():
    value = 845923
    if len('') > 0:
        pass
        834
        pass
    text = __import__('base64').b64decode('bUk3cWY3czJYVUtIUzN2UWpYazY=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_1772 = 388
        _dead_2783 = 840
    total = value + len(text)
    return total

def _εЯМНзΜэΝ():
    value = 810429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXzidlVv5IAMIyX06w6VCzwAyV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 82 < 0:
        _dead_5498 = 982
    total = value + len(text)
    return total

def _ЗидωЬλВΣΠБгЯ():
    value = 880344
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxfTQl4K3ZAnOQWv33HILBMGwEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЪмФШМлУшμΑПπбБ():
    value = 431798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiHDO2UJ0akVLyyc33KYED8nsWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КдΚоξхωлВψжмιш():
    value = 483137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhjBYFQg/78sBR2lz06WMiR73mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αвυυрαЦЦζзЖ():
    value = 500688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRzXWUUo5o4majCW6UPCAA4W/nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εШбИΞШоΩθьъБ():
    value = 508466
    text = __import__('base64').b64decode('cXFTNHpCVVptdE1YNFQ5ejR4NUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ФгМρΟΒЬςΙψ():
    value = 598741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MifHTwBo9oY2LDiu4l3BYysovVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 20 * 43 < 0:
        _dead_7883 = 289
        796
        _dead_6014 = 512
    return total

def _КЬШЭπжΕэΑθщНЪι():
    value = 711066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQzLX0Mh//stOVuq70CVHHM5yVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШВρλВуΛΠЛАΣ():
    value = 254120
    if False and True:
        428
        _dead_8765 = 566
    text = __import__('base64').b64decode('aHJ3Ynl5QU9id2l1Y2VlTktBdEc=').decode('utf-8')
    total = value + len(text)
    if 54 * 91 < 0:
        995
    return total

def _АаδРсикΚЩя():
    value = 920911
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhXCTVUhrqxWbTz693icAwF/xVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕЕПНВыНЕоцПКБΖН():
    value = 296264
    if False and True:
        _dead_4948 = 424
        416
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhnIXmUcyZsPNSn0nE6BYQIW5VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νЮΖιФζαикЪΡЖζ():
    value = 415339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nnfzd2E21r1XM1f7wHeTO3MI9HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НсРэсШβθδрОφП():
    value = 883875
    text = __import__('base64').b64decode('aFoxS0dDMXdkcWcxc2QxVkpjVDY=').decode('utf-8')
    if len('') > 0:
        412
    total = value + len(text)
    if 49 * 49 < 0:
        _dead_9161 = 13
        _dead_8375 = 900
        pass
    return total

def _оПЭηеъΝиτФчоζν():
    value = 740879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjndNlw0p7wJNgv74kKiJCgc6Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΥьдΚνЗмΞπκφαИ():
    if len('') > 0:
        pass
        431
    value = 562049
    text = __import__('base64').b64decode('WmtGVGRkcUZrYnFyRU5aVjhVWk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙНМТοΖΗΚьρΖΚЩΗ():
    value = 997351
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiPqSVQvrK8FMBi53ECcOBoC4Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рμшлΦЕζеΘΥΠΥЦ():
    value = 624204
    text = __import__('base64').b64decode('WFRyTGNaYkhOZWtWdFNVZFVSbjY=').decode('utf-8')
    if 14 * 68 < 0:
        454
    total = value + len(text)
    return total

def _γΓΥЛЗЗпзΒЬρ():
    value = 94311
    text = __import__('base64').b64decode('cTVOQ2Q4VFEycmRadk1aaXRzUW0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4387 = 919
        433
    return total

def _δкΛΦвЮУβз():
    value = 862845
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyHqW0A3roEbLyG2wmS6OywH92I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 80 * 90 < 0:
        pass
    total = value + len(text)
    return total

def _дΝΧкχфмбГуСΗпθε():
    value = 418533
    text = __import__('base64').b64decode('cDRUZGdoa1NBMW1lQ2k1Qk5Xblo=').decode('utf-8')
    if False and True:
        _dead_5401 = 906
        pass
        _dead_9871 = 205
    total = value + len(text)
    return total

def _τιТкПβЩтяудБθΤ():
    value = 468894
    if False and True:
        922
        pass
        _dead_8818 = 821
    text = __import__('base64').b64decode('anpjTFZ6cWYwRGt1WmdVSUQ1RU4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3114 = 973
        pass
    return total

def _ГφωσςАΨдηр():
    value = 421927
    text = __import__('base64').b64decode('VnFWaGFYd1hQdjF0YUhQakhDSkw=').decode('utf-8')
    if False and True:
        _dead_7985 = 376
        67
        280
    total = value + len(text)
    return total

def _вΗΦЛбπЪΚИωΙлпΦΜ():
    if 72 * 5 < 0:
        pass
        _dead_2629 = 378
        pass
    value = 708245
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH3lTV4e04BTPFi00lSoITJ952Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫсЦпДμιΔю():
    value = 437510
    if 53 * 88 < 0:
        _dead_6198 = 473
        _dead_1912 = 124
        _dead_4489 = 218
    text = __import__('base64').b64decode('TEFlRDFfYlpHaUlBbk1RWlVRcFA=').decode('utf-8')
    total = value + len(text)
    return total

def _сфчНΛпЛЗЧξΟоЧЭе():
    value = 102045
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyqyQgBh6747PyOn3VuTBC8jvTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        132
        _dead_8674 = 296
        298
    total = value + len(text)
    if 21 * 100 < 0:
        392
    return total

def _ЛкйъвМЦБрφΜОгες():
    value = 195474
    if len('') > 0:
        pass
        _dead_8494 = 658
        _dead_7322 = 683
    text = __import__('base64').b64decode('bWo0aWRoZ05vNmxHenNuYW83NmI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _λьΝЭΨΞГв():
    value = 184369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgXLQ38M+/wwbAG6wH+vPQMd3Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 13 * 75 < 0:
        pass
        225
        212
    total = value + len(text)
    if False and True:
        776
        _dead_1706 = 356
        pass
    return total

def _ςκтыГφЖΖΙ():
    value = 454384
    if False and True:
        503
        pass
    text = __import__('base64').b64decode('QTRFVkQzSzYwQWszRFRHOHNBT04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩДοЕЫУχЩШхфмνβΨ():
    value = 520681
    text = __import__('base64').b64decode('enc1TE1ZOE9kY19nbE1MX3FzeHI=').decode('utf-8')
    total = value + len(text)
    return total

def _οпΧГЛЦΑТоδ():
    value = 97459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3rvXWBt648gaSCLnVDENiwQ10M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Нςиеοπξу():
    value = 699432
    text = __import__('base64').b64decode('a1owT3JLeTZYNFBoZ2d2NjVEczU=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΞνАЯΚфэбΜ():
    if False and True:
        pass
        _dead_7489 = 414
        pass
    value = 69878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQPMV2Fhrfk3OTuq30G/YgYl3GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΖΟРкзΛжΩЛ():
    if 93 * 89 < 0:
        3
        862
        _dead_8786 = 554
    value = 719934
    text = __import__('base64').b64decode('dG5BMmlWSlNqRDcxM3hhWVdkR2M=').decode('utf-8')
    total = value + len(text)
    return total

def _δМηΕξАЮΚеШр():
    if 26 * 64 < 0:
        887
    value = 234293
    text = __import__('base64').b64decode('SDEyS2h1Y1BOdjBBcXNkSTBrdXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦйπзγΛьйзЦλ():
    value = 770305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HA7gWHI79LkqIyj6kE6zHzIO8Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вαΘнαΝДвε():
    value = 225528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwzdS24R6fAnBSGW0EXCPh178Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩаХΣυЬШтΕФьΡΠДδЧ():
    if 85 * 6 < 0:
        pass
        994
        pass
    value = 436642
    text = __import__('base64').b64decode('eHFEOUJNTlNOaUR2azAyNlozYjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _мωвахНΘχΜσΕЙΝФσ():
    value = 831425
    text = __import__('base64').b64decode('enJyT1FOTVZXbzI2dFJ3dHVDa3o=').decode('utf-8')
    total = value + len(text)
    return total

def _КЯΚτтςЬЕч():
    if 37 * 64 < 0:
        _dead_3562 = 789
    value = 80260
    text = __import__('base64').b64decode('c3NMYmdUb3N6TWxrQmpHSG42RVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ηКмИХуρΕДο():
    value = 305022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACfsW0MI174UEheBzFmlHSsQw0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΜАΘεκхΙΣβт():
    value = 144424
    text = __import__('base64').b64decode('T0p4Q3VBQ2xTbXlUNFpBWUM3Y20=').decode('utf-8')
    total = value + len(text)
    return total

def _жΨΖνмЩЭΥΙХβИΝб():
    value = 802396
    text = __import__('base64').b64decode('VW5ibEJBcXBKU1R0UDlGb3JXUEk=').decode('utf-8')
    if len('') > 0:
        _dead_5258 = 147
    total = value + len(text)
    return total

def _ΠБЗЧΧθФΟ():
    value = 118682
    text = __import__('base64').b64decode('R1lRWlo4V3ZJNDRock5DX2I4eUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜЗЬΓбоμъηΓ():
    if len('') > 0:
        _dead_2630 = 263
    value = 971910
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyfMf1sLxJhXAl2uw0+fBXcg/kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЖΙυρТНκ():
    value = 513103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhvWa1Aa1/gQFCqP2k6UYHY54Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΚЬвюТγτΙБνκπ():
    value = 949924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzbhQlgLrKobOQag8mOvYg0m0lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧНцЕιНЦα():
    value = 678418
    if 2 * 63 < 0:
        607
    text = __import__('base64').b64decode('cFlYeUpPcVBRb0dIWnoxdWpzNGE=').decode('utf-8')
    if 6 * 29 < 0:
        563
        971
        pass
    total = value + len(text)
    return total

def _ζσСЖαъΛНςΗь():
    value = 735749
    if 96 * 24 < 0:
        137
        _dead_2124 = 531
        _dead_3480 = 223
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LArDaEYa2ro3D1r7xWGCOg8Z/Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βВΖαΞКюζ():
    value = 782066
    if False and True:
        459
        pass
        969
    text = __import__('base64').b64decode('eEtvWHBwX3BaWHVHVkpwX09GT1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤяχНшιЦΑζΔΜ():
    value = 907202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRDHRkkM8LkVCwSKx3GVOgAstk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _твщбνφшцв():
    value = 721675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDbeRWkG76w8NSGKxGOhEQkf4U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 76 * 69 < 0:
        456
        _dead_7574 = 422
    total = value + len(text)
    return total

def _еξвэцςθЧщЪФ():
    value = 351185
    text = __import__('base64').b64decode('RkNrZ2doRVRLUmU2NU9JcmRHNGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗмΕкχГОναБΚ():
    value = 452596
    text = __import__('base64').b64decode('VWtnbHBqcXB6WUVHN01HeW9VSkg=').decode('utf-8')
    total = value + len(text)
    return total

def _гΖИυφхШВΧΘАωΑПΔε():
    value = 72851
    text = __import__('base64').b64decode('TWpLSzVMNTJTMHZ5OXdIUFJYb2c=').decode('utf-8')
    if len('') > 0:
        791
        74
        pass
    total = value + len(text)
    return total

def _ИШЯХыщфйτΨю():
    value = 121927
    if False and True:
        pass
        _dead_3971 = 72
        _dead_2532 = 145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgK1awM7yKRbHlq6w1+3YQc6/EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_5557 = 587
    return total

def _ωφγьюЫΨΜΟΨНЛф():
    if False and True:
        pass
        _dead_5699 = 744
        445
    value = 981536
    text = __import__('base64').b64decode('RjBJcWtZb2c5SlBDRE1hVzZ6Mm8=').decode('utf-8')
    total = value + len(text)
    return total

def _чΨЮΠЮШчщЮΓξγыВΠ():
    value = 900063
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3rPeQE/0J47ahWy3nWgYhEAzjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫξΝсЩΚкπ():
    value = 858501
    text = __import__('base64').b64decode('T05WbkwwQV9NaU52MWJOcTdDR3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦβηΚАΙιΒРΕЙтχгс():
    value = 778020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnfVOQRu950IGAaF0lGUAy4kzn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕμзΘФΗΟΡъ():
    value = 334266
    if False and True:
        438
        pass
        _dead_5109 = 101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxXdPUAR2ZxTMDr3zH+JJhYh93s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГεХΡЯρПΜδГхЕοΥ():
    value = 100914
    text = __import__('base64').b64decode('WHcxUEx5ZGFFNWxkRVFfWG1zZGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЕхиБΖτΛΔПхщэ():
    value = 462728
    text = __import__('base64').b64decode('Q2NHQXhHMk5BNk9EeDhabmF0cmY=').decode('utf-8')
    if False and True:
        pass
        _dead_3853 = 147
    total = value + len(text)
    return total

def _ъДΝЯшΙΘλφВюβЪ():
    value = 761602
    if len('') > 0:
        _dead_4976 = 650
        895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT7gPF4v8vshbQKo60KUYC080Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΟСбσЫфъкх():
    value = 385413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PATQfwU3x58ubzeEmkeVADUW8TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БчФчΟΡЦΩ():
    value = 493460
    text = __import__('base64').b64decode('bGVwRjN1bWc5TlZCWXN1S29RUFc=').decode('utf-8')
    total = value + len(text)
    return total

def _пъΨШΧωТЯЙξ():
    value = 208533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSvFXgUc1phSPB3z9wPDbBYA40E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αДΣΖхШясτаУпДβΔ():
    if False and True:
        _dead_4117 = 541
        _dead_9770 = 995
        pass
    value = 435955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD60QF8drrFQNwul/lyiDQ8CtHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПжΞЧшζθыЖпЭтΩ():
    value = 862612
    text = __import__('base64').b64decode('aG9FSGU4Y0N0c0ZDNUJRWXNYZU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ψщнμΦψυΒНηщОξΜ():
    value = 254045
    text = __import__('base64').b64decode('ZEQ2OTFzZl9ES2pxWG85YWp1enQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ξτНΞугЮуΥФλΔЛ():
    value = 930231
    text = __import__('base64').b64decode('ZWJ1dzZxWURHYld0RkszNHRXY18=').decode('utf-8')
    if 85 * 1 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЙωεΒщσΠоОФΧРС():
    if 70 * 38 < 0:
        _dead_6931 = 232
        pass
    value = 457396
    if 27 * 96 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KS3ubFc2q4U6MCiq4m66MHECsnQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 13 * 37 < 0:
        837
    return total

def _ΦюЩСΗωГЗ():
    value = 65717
    text = __import__('base64').b64decode('WnVST0VQdkgxYW1ETUxidWJfU3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _фнηлθΡτЛζьΥγЛиц():
    value = 538576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXnQbGkapoYCFzaS/3+ILHIu7Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚгΔΑΞЧσфвυфζΙ():
    value = 718437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISL1RWVvqK4oNQH72GeUGXcixXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чςшхЪнЦΞщрЭοσьΓΩ():
    if False and True:
        _dead_8713 = 618
        995
    value = 152823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyrieX8w/fgFHR2ynHKKJhM81nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2633 = 835
        pass
        pass
    return total

def _θσтΦщξщэТζεРтα():
    if 52 * 31 < 0:
        pass
    value = 210737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgzLZnwI9boaEiWB30WRM3Q//W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΗпЮιюРΦΩΔЛΘΨАЮБ():
    value = 259255
    text = __import__('base64').b64decode('ZWNMR2FaZDI3OXdEdzk3dklFQU0=').decode('utf-8')
    total = value + len(text)
    return total

def _вσπкълΙψςсΕБ():
    value = 489241
    text = __import__('base64').b64decode('c2dWaDlHZXkxSlJPZ1NrbmtMeDM=').decode('utf-8')
    total = value + len(text)
    return total

def _МзρЪуξДρЯьΑШ():
    if False and True:
        373
        _dead_1765 = 580
        pass
    value = 476552
    text = __import__('base64').b64decode('Q1FXa05KQ2sxSlRXaEtWRlFvT0E=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        759
    return total

def _ГΡΣмбШΖЪйЕЧЯΩ():
    if False and True:
        897
    value = 267152
    text = __import__('base64').b64decode('dWY1ZUtyVXNGWmhYaHNpR0RyOGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ХПтЙΥтςφШг():
    value = 38052
    text = __import__('base64').b64decode('UkxRNklpWU8xMWVBYzNtX0VFY1A=').decode('utf-8')
    if False and True:
        483
        119
        424
    total = value + len(text)
    return total

def _τΒАцЫιΩыΛмФСΙΤ():
    if 54 * 17 < 0:
        _dead_8154 = 10
    value = 594509
    text = __import__('base64').b64decode('Tk9zbDdab21JbTlXNjV3TWVoeDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _дΔЗтιμρеξβд():
    if len('') > 0:
        _dead_8766 = 612
        _dead_7293 = 221
    value = 62675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAfDOgQ+zPEXMB2I6QPJFQoKx3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 49 * 4 < 0:
        pass
        119
    total = value + len(text)
    if len('') > 0:
        418
        957
        pass
    return total

def _дТρрООβσубλЗ():
    value = 480692
    if False and True:
        759
        229
        pass
    text = __import__('base64').b64decode('RlVoelJPTEJpYV8yQzZoaklZaEw=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ожрΧЬκЯΠΝΣΔ():
    value = 357212
    if len('') > 0:
        pass
        pass
        _dead_5187 = 153
    text = __import__('base64').b64decode('ZnFqbjlNSjJpUXZYZjM3OVNQZ2w=').decode('utf-8')
    if False and True:
        pass
        201
    total = value + len(text)
    return total

def _ΘйΔяЖяωЦγλ():
    value = 20906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQTvR1cM3ZIEODaV/w+GGgE79mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГБΡеПжηцэζЭШэп():
    if len('') > 0:
        551
    value = 285826
    text = __import__('base64').b64decode('c2RpTXVtX0VjNFhyZFN5MndvQ0s=').decode('utf-8')
    if 23 * 74 < 0:
        _dead_6617 = 31
        794
    total = value + len(text)
    return total

def _ЦςмЫΛκοЬщэХ():
    value = 211532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyrrPnsd2K1REiKu90XBZTUpy3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5167 = 710
        _dead_4881 = 319
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _цιΨΠФРσИ():
    value = 138013
    text = __import__('base64').b64decode('Yk54eHNFdmRFbTNiajdoMnZWMFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ОψАψКиΦМΤΠбЪοзιв():
    value = 833956
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRjdfEQL0KAQLhqH2EaBPwt24Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εКУκμшυεЙКфΙΖюς():
    value = 864368
    text = __import__('base64').b64decode('QUJXbldCZmF6dzJTQjU3OHhzc3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬИΘζΚΒΙεяЛΣйПбУВ():
    value = 6816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnbhYWMh0bEvPBiB5Wm9NiIK3Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        522
    total = value + len(text)
    return total

def _ТΠюεΖНЙЗйιΛФ():
    if len('') > 0:
        pass
        _dead_9975 = 418
        _dead_7335 = 194
    value = 929352
    if 88 * 71 < 0:
        898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NA68TF4yyIsJGAuy6XiVGhAVwW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        612
        _dead_8052 = 504
    return total

def _ЧЪλΘцвλκЪΙцЯΞφ():
    value = 877741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTXmOnBuz4Y3agu1zGOXEXV8smY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фСкΦηЙΒЖυРιЛς():
    value = 507511
    text = __import__('base64').b64decode('SkFjd1VIeDhDMTcydHhEVG9adkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΞЖηШЖΔΘаψυΨж():
    value = 279130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fi3FTXoj0q9REgebmWaRPgMbs10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ынκызрфЛιншн():
    value = 59704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAHwd3M41YUTPxj12GXENnII530='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('bQ==').decode('utf-8'))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()