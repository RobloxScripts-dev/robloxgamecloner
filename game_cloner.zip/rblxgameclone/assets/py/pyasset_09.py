#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _яиΡΩτσЙΓΙрМй():
    value = 916714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mnfha1Vh8owEHDyF0g+2Oz8Fx3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛфЧνдугУаЧλ():
    if False and True:
        372
    value = 686851
    text = __import__('base64').b64decode('eHNsVzRPWXRXSDlLN1FBTVFweXc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _юΞыГЩЦΟαΙйСТω():
    value = 879006
    text = __import__('base64').b64decode('QVB5RWxsbXdBeEMzeUR6TDFqNlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _НхРζжрΚοАл():
    value = 778654
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCS8e1sB64UPCQyx0n6hZCl+3Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пολπΛΙэοΘ():
    value = 404817
    if False and True:
        pass
        pass
        73
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nwn0O0YP/4IXMir6zlyKATQD3WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ατΞοУαΨΡξчΗΑХβοΙ():
    value = 66372
    text = __import__('base64').b64decode('SHdRSWlpVVNrUG9pUGVzRGtRaHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦπзеЯΞΠмΑЩйюΕπяΖ():
    value = 536740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az/KVAkUzZcUGRzy7EGmG3YQ/F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШЮγпНΒПщЫΦь():
    value = 252896
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCjReWIY+vkOGR60zWSWY3UdsGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΗΕЬщКГΓΧЫаΤξФя():
    value = 774420
    if 93 * 10 < 0:
        594
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXvFUXwe8PAgLiOr6kOqJzUQ6WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 92 * 89 < 0:
        pass
    return total

def _вΖΜлΒΘτλШ():
    value = 976855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyzReUUVwfw2Nzv261exPi0a4nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥыЛРΞΑΓтБнХ():
    if False and True:
        _dead_1364 = 513
    value = 555935
    text = __import__('base64').b64decode('RDVFYzBjY2F5bEszQlp1OVBJMDI=').decode('utf-8')
    if len('') > 0:
        _dead_2290 = 668
        pass
    total = value + len(text)
    return total

def _щΖУбНΠΠΘдспЯЧП():
    value = 353481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSCzfAZu54MEblv3x12XbSIW4mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣээЪΧΧтροГΔκψлЪζ():
    value = 839271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwP9Z2Ey6JAvHVyKm3e6ACod9Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юкψΨΒηζμскηИξΓвΨ():
    value = 7449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj3HO1kb3P88LAuNzwSgIjYrw2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΝΒЮсЕΥИμτΞЧΔЙыγ():
    value = 818013
    text = __import__('base64').b64decode('Vk5zYzZ1T18yNUlFellFMEdGTzM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        702
    return total

def _пбρЕζЭеяγЙαР():
    value = 516212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjjLfWso2YsSOwegnVKBDA0Z0W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 84 * 19 < 0:
        pass
        pass
        911
    total = value + len(text)
    return total

def _бЮвТИΔвθ():
    value = 812084
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx3lYFMo7/lVMwO02V+kDRYs630='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΒФкКвЬЙтΝ():
    value = 96080
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pzexfms36vhSIAKMwmSbIDx8tGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΓЯзНьψσъХЭБσВφΑ():
    value = 972731
    text = __import__('base64').b64decode('Vk9jNENMTkZoVzFvT3BKVmYzVEk=').decode('utf-8')
    total = value + len(text)
    return total

def _оΗяμΛКοЦчΓΝтΑ():
    value = 440426
    text = __import__('base64').b64decode('c0RQUzdmS19Dc25kNFZOTEhRaWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧФΦΧΧЦΔμρУΞзδЪ():
    value = 294797
    text = __import__('base64').b64decode('T25tZXRlYjdjSFQyeDZiWFVncXI=').decode('utf-8')
    total = value + len(text)
    return total

def _βбΝΔАШЭν():
    value = 814541
    text = __import__('base64').b64decode('R3RPd1VrMmRvMHlyZUw4QWFRYmw=').decode('utf-8')
    total = value + len(text)
    return total

def _оωλψЛΧΤψЭнξγωΥФΠ():
    value = 196958
    text = __import__('base64').b64decode('SGVua0dhVk1hYVJZeTlXb09ueGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΖηΥюПΜдзМл():
    if 5 * 71 < 0:
        _dead_9734 = 266
    value = 292142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCzPW0AM8bkkGRak2Qa0DDMr6zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        56
    total = value + len(text)
    if len('') > 0:
        _dead_8708 = 569
        _dead_5401 = 845
    return total

def _ЬνιΩШАЫΑ():
    value = 255260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSf1f1ksrqoMEzWGynq6FiY5/mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЦЕΧЫУψЕСфχ():
    if 95 * 50 < 0:
        852
        _dead_9684 = 883
        722
    value = 669553
    text = __import__('base64').b64decode('WjJZdWsyb1RBZmRlU2Nrc1lCWXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _УιзяΘΜΥдЕΙ():
    value = 344156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCSzfHAeyIoZKDep6X6qODN33Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςτъυΣτБУЭнΨρ():
    value = 568705
    text = __import__('base64').b64decode('dG9ocVdPNkw1WnNsc1cwTDJLQWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ГςЦнЙΘηыυθфαъиσ():
    value = 45764
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXqyPFVh9bsnMgOP+QWULggq/Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТсνъзΨΣΥЦМαΝЭ():
    value = 637171
    text = __import__('base64').b64decode('dU5CMjNHMGZZUm54RDRaa2xVcDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΨтКепВΘοΒΥБ():
    value = 305205
    text = __import__('base64').b64decode('dkFYQkpsVmVoR2J1VWxFTlFWRDg=').decode('utf-8')
    total = value + len(text)
    return total

def _шλяΙζμΡДΞдЧαΤЗ():
    value = 117075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwX1OmIxxqo5NBm6nWeGMXIatmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΓγτЧЦЗй():
    value = 492155
    if False and True:
        327
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyK2N0hrzYE1KgaP7n+WESsb9mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 23 < 0:
        _dead_8155 = 924
        629
    total = value + len(text)
    return total

def _зРоООТГΒшЩХЧ():
    value = 844001
    text = __import__('base64').b64decode('Vll0V0dmb1FTc3Rmbl9JTEZSbTI=').decode('utf-8')
    total = value + len(text)
    return total

def _вцΥΜУβУаУиЦЬφцΛ():
    value = 98427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCPsTQgfy7s3FVmP72GyMwgQ40Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ττιΓЦаωкДσкза():
    value = 443157
    text = __import__('base64').b64decode('WGM4eVloZXVyRWNteFpXNTRMdEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓИγλЙΣΦκРвθΣоνΚ():
    value = 643224
    text = __import__('base64').b64decode('TEkyY2R5eU9zUExKSjFFMkl1dzA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8694 = 396
        pass
    return total

def _ЯφфФфЦθυΤЧШаΚΩ():
    if False and True:
        192
        pass
    value = 566093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhDNZ0cKy5kzDly56nuiGAQm5nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бчУЙΥЬаПηеЧжΔИΣЕ():
    value = 876039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mnf+REYW3Z46EVv33neaZisn02c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΔΥτυσΠъΣΕШБΘ():
    value = 534416
    text = __import__('base64').b64decode('THM3Y1BxaUlVR1JUb2lRYVNNRXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _χΧΥмξδκΜфΓ():
    value = 443333
    text = __import__('base64').b64decode('SGt4bTNJRHpsSHJnSDNmRDIzSFc=').decode('utf-8')
    if len('') > 0:
        _dead_5868 = 142
        _dead_6083 = 358
    total = value + len(text)
    return total

def _κэιЪвяΗТφΧчΖЛι():
    value = 434421
    text = __import__('base64').b64decode('ZGdoRmFzSE4zN2dfeWxYZmpWM1M=').decode('utf-8')
    total = value + len(text)
    return total

def _НΓΞКмОДупσ():
    value = 169610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgjrSlgbyKkJMx2TyWWvMjw720g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιμμаιΓпΤ():
    value = 329974
    if 58 * 51 < 0:
        pass
        594
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAHlOVYj9vEOLAK2x2ShI3IDxkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νλαРΠνΛνΤйтι():
    if len('') > 0:
        _dead_3709 = 81
    value = 31813
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCnTZHcL+5E2CF2F6XuDJzF74UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΗщΙρяΧЛΞсχθр():
    value = 107756
    if len('') > 0:
        334
        604
        pass
    text = __import__('base64').b64decode('bDZCNnJNT3pkZ1F5eWlMakpmWGk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1022 = 222
        609
        _dead_2431 = 974
    return total

def _уяγΒδдтяЕЕшлНОЖз():
    value = 357408
    text = __import__('base64').b64decode('R3E0cXhqaUVqR3NCV3NJdWJhR00=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΛуЙтωФЛщРιφтθЫ():
    value = 283340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg7ASEsM7vEyC1y2/VGgPAEZ9kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7331 = 107
        pass
        _dead_8672 = 432
    total = value + len(text)
    return total

def _ежкэφХмДχλщп():
    if len('') > 0:
        _dead_3790 = 597
    value = 478672
    if False and True:
        268
    text = __import__('base64').b64decode('R21sa3N0ZlllYlJBV1RrY0pxb2g=').decode('utf-8')
    if 23 * 33 < 0:
        710
        pass
    total = value + len(text)
    return total

def _ΥττΦЪεЙΑωΦж():
    value = 290865
    text = __import__('base64').b64decode('R0R0cHVfdFJqZEt2WkJ0dnB5aGo=').decode('utf-8')
    total = value + len(text)
    return total

def _τΔГяОοяχ():
    value = 58456
    text = __import__('base64').b64decode('UTNUUkJaaVN5cXN2a2RNZ2J6VWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗαρеΝΨΒшοфΓΤΕ():
    if False and True:
        _dead_2399 = 95
        421
    value = 125231
    text = __import__('base64').b64decode('dTRjMzhtTk84aVdCdmpjang4dmU=').decode('utf-8')
    total = value + len(text)
    return total

def _лΙВοΑзΒхλГДζΟв():
    value = 458280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRvbR3Yp0L1QNTySn0XBHHYN62U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΙδзεЕЩЧΡЭАπφΨЬЖ():
    value = 625365
    text = __import__('base64').b64decode('UHFaRnpzcTd2ZVpCRWFmVEpIa00=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _σλφΨхμбβφξχΠСпд():
    value = 978412
    text = __import__('base64').b64decode('S2FkUEtNVVJfVFlVRHBQSXhwSlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ПчΟЫΕΤНЙыОЦ():
    value = 978957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBvlOFQa+oUhN1zw+QK/PnMetHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βрχъΝджτρъЛН():
    if 76 * 67 < 0:
        597
        _dead_6814 = 99
    value = 479284
    text = __import__('base64').b64decode('aU80Ym1BbFRfMEpvM0FETWwyckY=').decode('utf-8')
    total = value + len(text)
    return total

def _εйσЛΖΖЪσЮГΞЭвΔΛ():
    value = 2369
    if 24 * 51 < 0:
        pass
    text = __import__('base64').b64decode('R0lYZzJhSk03NnJsdzg5cklFUzA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7572 = 421
        _dead_2123 = 881
        _dead_9116 = 67
    return total

def _ИΔФкУЖωчдрЙ():
    if 25 * 100 < 0:
        _dead_7683 = 573
    value = 202831
    text = __import__('base64').b64decode('bTB1MXRtQkJrbE04Y3pQRGFQUEI=').decode('utf-8')
    total = value + len(text)
    return total

def _δИДЕчδΤДо():
    value = 228410
    text = __import__('base64').b64decode('dGxyNGU1ZXd2Z3VOaWNCYUpDWWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΤЛΡΞξяЗΒΦвЭΩ():
    value = 562542
    text = __import__('base64').b64decode('SzFHc05oZnE3TWhwMm0zbEw3b0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _вВЙюΔКηВсΖηρτ():
    value = 743387
    text = __import__('base64').b64decode('RnU0cG5JZVpCV25JZFlNekttMHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛлΜсисΘНщдЖΜъ():
    value = 102086
    text = __import__('base64').b64decode('eldzb3p6T29yVEdHNE9Oa0toYXE=').decode('utf-8')
    total = value + len(text)
    if 44 * 46 < 0:
        740
    return total

def _ъФъмХщλΜ():
    value = 835737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRzFeUs98owBDRaawl6jMhcB808='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗЧЙΓЧлееЖЯлΩйЕ():
    value = 678723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHzHWksf0pcrACGQy0zBEwEmw0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΨэξυФэнδ():
    value = 511993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MArzVnhu9vEKHgm2+V2bLDYQ0Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _рμлэςдβРΕχдв():
    value = 127917
    if False and True:
        _dead_6298 = 731
        _dead_7108 = 90
        pass
    text = __import__('base64').b64decode('TXIzYm5VQ2JpeVU1VlltWGR0OVY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3174 = 365
    return total

def _яНηшфцΟС():
    value = 992408
    if 54 * 37 < 0:
        pass
    text = __import__('base64').b64decode('QjJxZ1dXUkhEVjI1YlVEM0NqaFc=').decode('utf-8')
    if len('') > 0:
        _dead_7545 = 211
    total = value + len(text)
    return total

def _пивюλΚЩйХэщК():
    if False and True:
        pass
        _dead_5463 = 740
        pass
    value = 892463
    text = __import__('base64').b64decode('bk0xODlONnVFS2ZsUkQ2YndGNkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _τаОЪэΔщЦКγΕ():
    value = 332394
    text = __import__('base64').b64decode('anlaY2RnYWdjYjk5clcyVWtjZDA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        365
        608
    return total

def _ЫΔьΝΙΣΣδσ():
    value = 839174
    if 34 * 85 < 0:
        pass
        _dead_3652 = 312
    text = __import__('base64').b64decode('Q1Bnc1hsVXFXa3Y2OUhWaV9YVHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΕРΡАςАЗьΠμΧιχо():
    value = 721702
    if 4 * 21 < 0:
        261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRryO24S/f8ZAB+1+2G/PQAN3UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        179
        831
    total = value + len(text)
    return total

def _νыΦбяωфКχьΗМΠЕ():
    value = 894691
    if 33 * 36 < 0:
        _dead_4975 = 757
        _dead_5755 = 564
        pass
    text = __import__('base64').b64decode('R0tMeDVWbFhibVZGNkhabnBpWmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΘΒθΑΛФо():
    value = 27697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj/CVHQ+x5g1KSOs5V3BFXAMt0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΘШВяιΔΣГ():
    value = 741108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3/qaQAd54EZCRuI+1qXMxc51z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        740
        _dead_3023 = 464
    return total

def _ΕмядХγχХлРΤу():
    value = 765234
    text = __import__('base64').b64decode('Rk9HWjd0Ums0bHVwVzJuYjJ1UzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ФλδХДΚατηκηεэ():
    value = 340089
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSjCSnIs0qYSKVz28FmjPTMq1mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧъХιφζкΒ():
    value = 357722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQvLOAAtyI42Cwin2lCyJiAX7V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_7617 = 692
        pass
    return total

def _аРЙТΨЕΦзΖУзεΙ():
    if False and True:
        461
    value = 833560
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD7IWGMr16onGC6x0A6gBiF35UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        436
    return total

def _ашιλСХΒмπυΚωЦΞΞ():
    if False and True:
        114
        _dead_3717 = 153
    value = 871710
    text = __import__('base64').b64decode('V1BjazU0cmRiRXpsRWtIdnlkQnA=').decode('utf-8')
    if len('') > 0:
        44
    total = value + len(text)
    return total

def _ΗτψАςΔΝζΠЩΠ():
    value = 639334
    if False and True:
        131
        pass
        _dead_7105 = 377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT78P3ooyaYqExe38m+fJSwl8Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        119
        _dead_6841 = 666
    total = value + len(text)
    if False and True:
        pass
    return total

def _шαщяβУЬΕνЫδЩО():
    value = 84790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTu1Okgj6v0HLD+pmk6eHAYG6G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сПтсΕΘΤЭ():
    value = 419758
    text = __import__('base64').b64decode('VXd2RU9Hbmk1THFUaTNOZlJ4Yzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝхΨνНψмэ():
    value = 592186
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRr3R3cz8f8wOBiS4nCBBQIdyWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7618 = 635
    total = value + len(text)
    return total

def _σΦфЫΒэΞРΡητъш():
    value = 44434
    if 93 * 53 < 0:
        176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyThNkQorL0INQKiy329BxA8xlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        621
        670
        pass
    total = value + len(text)
    return total

def _μΧΘшΗцΤчψИλОνΠΖэ():
    value = 313788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyDLQnMR35A5PCSk4w/BMxR+5kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖЪОΜешыЭыΖюςρЪш():
    value = 895739
    text = __import__('base64').b64decode('WXlJbzA3T1h0emdCN1FDTGJsSkg=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΗГПΒοπзьхфПβυΜ():
    if 24 * 16 < 0:
        _dead_1449 = 541
        139
    value = 470601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NATRYAhpzptbbDmb5HyjAREA03Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΛΑЦЭποР():
    value = 139463
    text = __import__('base64').b64decode('QzR2ZEY3dkxRaEpIbDd0dEx4alo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
        85
    return total

def _αъρдЦνКоАΑρ():
    value = 415470
    if 52 * 34 < 0:
        _dead_7768 = 594
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DifKZWgX1q8WPVv6kH+9LCA65mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8634 = 560
        pass
        pass
    total = value + len(text)
    return total

def _ЫΘκρыΠиΡαнЪчп():
    if False and True:
        _dead_9899 = 899
        45
    value = 505225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQHOSlMcz40oAlqw4ASfMDx6sEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρчбΟΕцхρ():
    value = 407643
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQu0RFkP16EQCT/72nq/YXwa/X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('cg==').decode('utf-8'))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()