#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _БЙΓΕЖφЭп():
    value = 140951
    text = __import__('base64').b64decode('REtETl9BNUxjM1loZktfa0VXbU8=').decode('utf-8')
    total = value + len(text)
    return total

def _кЪкφξΙшθж():
    value = 291207
    if 28 * 63 < 0:
        780
        951
        464
    text = __import__('base64').b64decode('ZU03NXljUEZOQzlsT2xPdE9Rb1o=').decode('utf-8')
    total = value + len(text)
    return total

def _χΝвЛχθЗιχЕЙ():
    value = 522857
    if False and True:
        458
        _dead_2876 = 81
        616
    text = __import__('base64').b64decode('a0lSTllSbEFSdk14QVFlZDVBcWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ДьΛζпΘΟфΨΒЬъЮ():
    value = 434164
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQPoTWMvxKNUYgumxVOVLCo6yFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗοгШйщΦаτТψЬςЪР():
    value = 880166
    if False and True:
        pass
        _dead_7248 = 561
        146
    text = __import__('base64').b64decode('eXBJMEd6TFlFU1RWWHlXeThCWlI=').decode('utf-8')
    total = value + len(text)
    if 83 * 2 < 0:
        _dead_1989 = 391
        _dead_5951 = 841
    return total

def _ΗЧщИЦΔΔшИλЬШΕΑ():
    value = 212068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NR/oRkQX7qczHF23zUaCFXYew0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔОЩщаЭФЙБΗтьΙшΖъ():
    value = 102760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwXWalY08PwgAi2zzWXGNh8H6lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шптβυουЕКяК():
    value = 211339
    text = __import__('base64').b64decode('VUJyYmxCVDhONURMUE5ZaUk5Y2U=').decode('utf-8')
    total = value + len(text)
    if 8 * 24 < 0:
        93
    return total

def _ιМЕЙΖχчΧ():
    if False and True:
        pass
        pass
    value = 320158
    if False and True:
        454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBnDe0YPqfk7FDuE/nfEPQR24n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 60 < 0:
        _dead_7969 = 595
        _dead_1007 = 262
        463
    total = value + len(text)
    return total

def _ОВмςэΡРυчΟРαЙΡθц():
    value = 997061
    if 17 * 35 < 0:
        pass
        _dead_2132 = 674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCj9WmMyp4IFbCin6mPEOw06wT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        182
    total = value + len(text)
    return total

def _ΕνШδдеξзΔΩ():
    if len('') > 0:
        pass
    value = 352511
    text = __import__('base64').b64decode('aWkzTjlxT0JNbWdCa3dLU3ZBT3Q=').decode('utf-8')
    total = value + len(text)
    if 76 * 28 < 0:
        _dead_3247 = 541
        pass
    return total

def _ΝрщφЖεεΞяζςυй():
    value = 891432
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSrKWnY7+Pg2ah+x2HC4GTd4x0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДЕьтАЬΜъцГγ():
    if 75 * 80 < 0:
        444
    value = 409889
    if 23 * 51 < 0:
        1
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3vKQEgN+qcZDTavwnqjDBIg0Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙяЛΕхьΒσлЬфЗΣр():
    value = 97602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAjVYkMw+qUOAjeBkF2iHA0f4Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДωифΖЩфοδκΣζ():
    value = 234054
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhDWeF4YprA6LVuS3FyTNwkKz3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πφνиρλθтЬсΕΗТы():
    if len('') > 0:
        pass
        _dead_5018 = 260
    value = 854519
    text = __import__('base64').b64decode('Z1Bnb1pxRlo3YmpGUm5lbDdlQTg=').decode('utf-8')
    total = value + len(text)
    if 6 * 33 < 0:
        _dead_7981 = 390
    return total

def _ЫАчΜΛΔбОΤЙχСТΧΖ():
    value = 13954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MA3+V1Uu8KE0ayKa3EKhNnM6xmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зθδЯкгθζμηιКШлκ():
    value = 117265
    if len('') > 0:
        47
        59
    text = __import__('base64').b64decode('RmFlV1dpMjQ2aDV2RHJYc004V2g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _НσДεΤъьщΣΦиΘлВ():
    value = 442917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhXmeEk2z5wVPj+b626vZgQf7Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сρЪπвΙλФсπк():
    if 94 * 39 < 0:
        pass
    value = 84771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mzm1RnttprIAbjqX+ACBCwJ//T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФуΗхχкиЕΨЫΑ():
    value = 640330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS7dRVcxqJcyNgbw31K/YhEA9Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙРАоαсρщзαЪψ():
    value = 456521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTnxZncv96pRLAz7mQaYYB0Gy2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Πχουвщςωоπς():
    value = 606324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BD3LaEsQ87s3KVi7w0O8MyAkzUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εКРУΣГМУΨгдМυ():
    value = 890824
    text = __import__('base64').b64decode('TUQ5cnBIOVFkRzZaN2ZFbFJsN2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _НВрΝΚвρφН():
    value = 653853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxzKVAQ87qMqahXxmgChLB97wX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фшЫΗζУсиπ():
    value = 831021
    text = __import__('base64').b64decode('VDVWTGNVcTlLMGhuTTdyaTBvRkM=').decode('utf-8')
    total = value + len(text)
    return total

def _оΗЦΛитλЮсХραΚζ():
    value = 350585
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX3db1M2zIUZbQewzFqvbBol91Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 12 < 0:
        313
        _dead_2287 = 881
    total = value + len(text)
    return total

def _оЖΚвбσфшΘπΤΒЪχω():
    value = 791427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAbIYHsxqZ5WbCK032a6ODcn0mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩъаπэКЙОЧВХ():
    value = 180728
    text = __import__('base64').b64decode('a2dTangxZGJJR2tPNmV5clU0bU4=').decode('utf-8')
    total = value + len(text)
    return total

def _υРΘΝбχλΗвФоΘяυЛ():
    if 60 * 32 < 0:
        942
        pass
    value = 413172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRjdZX8oya0KECOOxF2nFnUr9Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧθΨεяφНφмшжяй():
    value = 386209
    text = __import__('base64').b64decode('cFhJaHI5NXJSUnRJSDd5UTdQUV8=').decode('utf-8')
    total = value + len(text)
    if 99 * 91 < 0:
        370
        _dead_3078 = 446
    return total

def _ЕфδЬуДуλсЙςεНчΠЧ():
    if 75 * 44 < 0:
        pass
        286
    value = 649411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD28bwAarZ4NKx+s6U7BHCQX0U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λаЩзΔауχвгнζςУ():
    if False and True:
        pass
        _dead_3438 = 942
        pass
    value = 80997
    if 48 * 56 < 0:
        pass
        _dead_3479 = 641
        326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnzwWUkT6KAxNFykxg6qEnYf0Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        784
        _dead_5712 = 65
        _dead_8478 = 378
    total = value + len(text)
    if 87 * 56 < 0:
        77
        pass
        pass
    return total

def _ПΗΚΦΥТΔыιЯХ():
    value = 927451
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzzhZWkXqqwuDhuawlC2Bj88wGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _яХφЩдЦгжΖνС():
    value = 928806
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAXKawYM0aMMbQ6uwWKJDgMqtUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 88 * 55 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΛΖδσЕψΙЫνχαυМЗψδ():
    value = 582924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR7DXEkS06EXCDiFzXC7YBE3vHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВвСчУΤροςκμТюижθ():
    value = 35662
    text = __import__('base64').b64decode('dGFwcjdGR2NSZlEyelJzaERhbk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞφюфэΝЗЗиπЯМΗΧ():
    value = 472208
    text = __import__('base64').b64decode('aTIwWTdyZDNXYXlFbjZNaGVPaEI=').decode('utf-8')
    total = value + len(text)
    return total

def _йτιФНЙШΧо():
    value = 70517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDawZks+1YQUKj6X/0KYAj99sls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хуγΔβиЩτξЩК():
    if len('') > 0:
        _dead_3084 = 865
    value = 575900
    text = __import__('base64').b64decode('cWM1MHZXcWl1ckdoaDFRSHhjSDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ηяиλсЬЙЫО():
    value = 51323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LC7MTFQIrZE2KT7w/my/Bxop/GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рФИχвξθΧ():
    value = 469267
    text = __import__('base64').b64decode('TEdndVNrRHlSSmNOOUNUd0loN2M=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9727 = 479
        923
        199
    return total

def _ИвΖКεμΒняДζΑβ():
    value = 80664
    text = __import__('base64').b64decode('cUJaZFZxSnN5Y3h3bWV2MXlWTkU=').decode('utf-8')
    total = value + len(text)
    return total

def _бΚчΡτЗΜΧЩЬин():
    if len('') > 0:
        _dead_5728 = 274
    value = 417633
    if len('') > 0:
        _dead_5399 = 21
        565
    text = __import__('base64').b64decode('UVhVSGtqV3NsT2NGMDZ6TXExNEw=').decode('utf-8')
    total = value + len(text)
    return total

def _ψмяБτΚπρΨρΞΨΥΞσ():
    value = 139345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQi8XHgy05ElOFeTwEK4OAEEtzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НЯбыЦΨρΩиΜкюΑ():
    value = 333655
    if False and True:
        _dead_3329 = 201
        _dead_5499 = 507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHvce30V1/tRK12JzEeaPjIOtnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΜЬгΘквφА():
    value = 929521
    if 24 * 94 < 0:
        _dead_1044 = 46
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgXFeENp06YoHySH/w6KEy4A/l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 11 * 20 < 0:
        pass
    return total

def _ЙωьγШЖзТφΞшΕРστ():
    value = 732448
    text = __import__('base64').b64decode('eXd1R1JfaVdPSjUzTkZNYVB1d3k=').decode('utf-8')
    total = value + len(text)
    return total

def _мАΡеЙиπΥЗцΒщ():
    value = 509841
    text = __import__('base64').b64decode('cDIxUzExZGlxUWNPUDFWRWN0Q3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _юΧξЬолΔежу():
    value = 615570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRvhRkZg0p1aaQ2h3k+RGx0//X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΧдмэШзΧμц():
    if False and True:
        761
        _dead_1748 = 330
    value = 593706
    if len('') > 0:
        _dead_7507 = 264
        _dead_9563 = 964
    text = __import__('base64').b64decode('elhtX3pTc0ZKX0ZrbGFjd3h2SDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕмЮηπюΖЫσΑΖиσ():
    value = 674284
    if 93 * 67 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx/jSn8q1J8zFSizz3CjbBUu7WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 24 * 54 < 0:
        _dead_8843 = 269
    return total

def _юΥОЕадΩΤσНδΞЭςΗ():
    value = 28678
    if 28 * 99 < 0:
        178
        pass
        696
    text = __import__('base64').b64decode('Rk1CRUJsVVJGVExJMXJMUVREdmc=').decode('utf-8')
    total = value + len(text)
    return total

def _дУдтψΙυΓуΙφОξΛМΩ():
    value = 421792
    text = __import__('base64').b64decode('VEhCWkRqMWxFektKWThJa3pfS28=').decode('utf-8')
    total = value + len(text)
    return total

def _αΖΑЮμорИΘгξв():
    value = 535590
    text = __import__('base64').b64decode('dkJuSGI4U2tEcVAwWWhTcjZtZTE=').decode('utf-8')
    total = value + len(text)
    if 37 * 77 < 0:
        pass
    return total

def _κИЙншВРРШШв():
    value = 260258
    text = __import__('base64').b64decode('QzNxcHM1VGVOTkJCeUlZUWhMRVg=').decode('utf-8')
    if len('') > 0:
        _dead_6536 = 736
        240
        _dead_8219 = 26
    total = value + len(text)
    if len('') > 0:
        243
        _dead_8815 = 35
        _dead_7859 = 278
    return total

def _ЧШеЧълΗΣЭгСΩнЩы():
    value = 446404
    if False and True:
        pass
        _dead_8641 = 372
        _dead_7707 = 954
    text = __import__('base64').b64decode('WkZNbzJDTDVETFVXTFg1TVhlSnE=').decode('utf-8')
    total = value + len(text)
    return total

def _НумтχгпТΗ():
    value = 776939
    if len('') > 0:
        pass
        958
        51
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh70PGgp8P4BLjWH3FmvJHYA0Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        856
    total = value + len(text)
    return total

def _ΦйиκЮаΒбжтярБДП():
    value = 732322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3nqOFkz040RIgm6wmeaHhAjwEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юьΕЩββΜχ():
    value = 452126
    text = __import__('base64').b64decode('YnpvMDh0WTFrTk95MkEzVmNGNGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧюГлОπжЗδвμшр():
    value = 371698
    text = __import__('base64').b64decode('VFlFZkJCNlR1VG5kQkJPVW9Hdlc=').decode('utf-8')
    total = value + len(text)
    return total

def _пПющΘςςвОААС():
    value = 879391
    text = __import__('base64').b64decode('TzBwRldoX1NpOHVJS0hBQ1dTYVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ιβφΑКНОе():
    value = 907165
    text = __import__('base64').b64decode('YzV2aFJsdHVYclVCV09Lc3dIcVE=').decode('utf-8')
    if 24 * 37 < 0:
        _dead_6119 = 493
        _dead_3810 = 322
    total = value + len(text)
    return total

def _КθПВХкΨы():
    value = 75578
    if 24 * 2 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhDrVF8B5JdRNlak8QGWMy0u230='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 51 * 86 < 0:
        _dead_5030 = 159
    return total

def _ΝυжюΛΑοкЙζζΕκнЭТ():
    value = 414282
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DznIRAEA9JISCzCJ60GHNhAOs3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        737
        pass
    return total

def _μωОαЯΗЖфΑф():
    value = 621384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTnDWFoqzYZaKF2v21OnNwQB3Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΕξДкЩΤО():
    if 16 * 19 < 0:
        _dead_1604 = 8
        pass
    value = 234912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lxu1eWEY1rgqGzei73DFPxQIs1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 47 < 0:
        _dead_5585 = 245
    total = value + len(text)
    return total

def _ΚБЖΟИБЫΞΒ():
    if 27 * 88 < 0:
        pass
        _dead_9592 = 861
        857
    value = 268167
    if 8 * 84 < 0:
        _dead_3311 = 491
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQbOYlcAxJEKGB3y7nu4EQM+s1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςЬδЩПλкрΥΕг():
    value = 641626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiLGe18rqLxQYgDy8HqqGnwW7Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γюγИΤмЙк():
    value = 985790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT3SOnlsrIRWCy6g5WbGZA8t/To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψπьΑΟЖΥτΩ():
    value = 21185
    text = __import__('base64').b64decode('VU5tV3cySUE0OFF2TFF5UXJzMDE=').decode('utf-8')
    total = value + len(text)
    if 82 * 55 < 0:
        _dead_6298 = 627
        _dead_6375 = 165
    return total

def _ЫбΑнЛнБτйπξеб():
    value = 749981
    text = __import__('base64').b64decode('STdoZmFURk1jOVd3THRCOXVKejE=').decode('utf-8')
    total = value + len(text)
    return total

def _φΘФЧυЧΡшДт():
    value = 330841
    text = __import__('base64').b64decode('SEx2SGgwUUZ5Q3FsNkNJTHFmVmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯсιουΒΞΒе():
    value = 717014
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCnNZwhr9qUuPjmP5we7Cyh60Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βДιЦоьяСΠΦΤЧζΘχ():
    value = 636497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnvKancVwasTYyfy2kSVHRoFxmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мЦΥΨЭыМΣςβ():
    value = 841491
    text = __import__('base64').b64decode('Vk0wTFZna3ZnMDZVZktaRU9KNlU=').decode('utf-8')
    if False and True:
        _dead_4289 = 112
        _dead_8223 = 610
    total = value + len(text)
    return total

def _ΠВκЛжДЭπΞ():
    value = 401405
    text = __import__('base64').b64decode('WVVmekJ6REFVTlBjeE8zT2M4amQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ВуэоΜЦυγщоцМъцη():
    if False and True:
        621
        _dead_4616 = 772
    value = 557494
    if len('') > 0:
        _dead_6562 = 462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAvLV3wXqrkJHDqrzGO7IBIe62U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΝЬУюΧщΙΩПΞκВΛνГ():
    value = 84623
    text = __import__('base64').b64decode('ZVpSRWIyUEFxckNjd3IzMXhhcTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯШоζфΟыτλюιУН():
    value = 608426
    text = __import__('base64').b64decode('Q3BYcWRaS1B0QWxHTENWZzNrQjA=').decode('utf-8')
    total = value + len(text)
    return total

def _аУμωяЦθΙΟζΡЮπ():
    value = 988769
    text = __import__('base64').b64decode('Y0tZVjJ2T1ZQWk5za1RtOVAzcEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ХтЩμЭбтΙαОшПчУΩ():
    value = 638386
    if 69 * 92 < 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('WVByYjhKc1NHdHpwOVFEeFY5Nlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΚФΨψωΞΓΛ():
    value = 672284
    if len('') > 0:
        _dead_2214 = 206
        pass
        _dead_8400 = 338
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzrGR24T060WKQb3/EWCDBQOsX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юДнωΡпБУ():
    value = 179844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQn0XQQK2fAHHD2P+kyCbDF47UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΜχМяΠρмπωжАωЭЕ():
    value = 408706
    text = __import__('base64').b64decode('eWNrSmtTYnNlc2hsNzhpczZUblE=').decode('utf-8')
    total = value + len(text)
    if 24 * 82 < 0:
        305
        177
        _dead_5068 = 309
    return total

def _κчΙτΣΠекρсЖπЬΝЪт():
    value = 706846
    if 58 * 13 < 0:
        _dead_2363 = 992
        pass
        _dead_1457 = 751
    text = __import__('base64').b64decode('dm8yTFJTM3JRRTQzMjJuTWFkRnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΦЖоΧжΥζΛΙΩыΘВ():
    value = 730595
    text = __import__('base64').b64decode('Y01laWtLYnFyUWRiYzljNElwRUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫдЯЪδΑИпйпОоИ():
    if len('') > 0:
        _dead_8834 = 623
        730
    value = 844014
    if 4 * 77 < 0:
        157
        pass
        257
    text = __import__('base64').b64decode('TmdnNVdlOWNYSVRJUUlOVnlhRnA=').decode('utf-8')
    if 40 * 77 < 0:
        _dead_6713 = 960
    total = value + len(text)
    if len('') > 0:
        99
        _dead_2678 = 834
        _dead_5866 = 930
    return total

def _ЭΥхαεΕЧθγΞбЙμ():
    value = 974992
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyOwXlIt8Z87GwKP/GmHHgs501k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сαЧМωΣиЦш():
    value = 357260
    text = __import__('base64').b64decode('bTdCZTJwY1VVN2hQVTNCQnN0bm0=').decode('utf-8')
    total = value + len(text)
    if 60 * 91 < 0:
        657
        pass
    return total

def _μщεδΩАЦгψ():
    value = 292372
    text = __import__('base64').b64decode('eEU5NDNGajlCUDFJQVlLMk5veGs=').decode('utf-8')
    total = value + len(text)
    if 28 * 6 < 0:
        _dead_9958 = 959
        584
        _dead_5823 = 118
    return total

def _ПΖρЙιΚΡΤАТЦю():
    value = 962517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LybOaHoo+bgKMwH2+kaRZ3c89Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΥωьπюрИΓςΦ():
    if 56 * 38 < 0:
        22
    value = 353204
    if len('') > 0:
        _dead_6129 = 697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3u9PFA7rpoNCQmU7UC8AyMD0zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 65 * 73 < 0:
        pass
    total = value + len(text)
    return total

def _еуЗΝυцαфκрςЛχЭΔ():
    value = 513903
    text = __import__('base64').b64decode('cnNRN3NiU3BESmRwNTlUR2ZMUE8=').decode('utf-8')
    total = value + len(text)
    return total

def _УЬвдКьπζΝΧКдΝΠι():
    value = 423709
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Anv0Sn4uzPlWEw2wn0DFOxE9yVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _иΦЩйΙхΣЗΚЯλиΨ():
    value = 925894
    text = __import__('base64').b64decode('RzZIb2lWaGRybkhsVGFCNlJqU2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _шЪθеΔДЗςТε():
    value = 801627
    if len('') > 0:
        563
        504
    text = __import__('base64').b64decode('c3E1SmFHNzlMc3VURnRYUWJOSlY=').decode('utf-8')
    total = value + len(text)
    return total

def _ДκЮкςЗЭКσΒъсΙ():
    value = 171043
    text = __import__('base64').b64decode('Qkl0eWtKVEZaWXJlR0FTQUVhN2w=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9994 = 846
        572
        _dead_1502 = 34
    return total

def _εχгθсΒΚгΔΥыОчθ():
    value = 86417
    if len('') > 0:
        pass
        49
        _dead_4607 = 317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3ndP18z7a8iFDelkXnJMjQF5ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 14 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _цЙЬεБθιζς():
    value = 97555
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kz/zZXMyx4YBIl2b2kHCDSY1vH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟШйРМЪтΟΛО():
    value = 714162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnjuQ3IM2KwgIwWxn2DHIgJ4z0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жуΤΤъχΞЯΠ():
    value = 206588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgfBT1xp8YwlKQWww2WhASELwkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПЖδΨυВζψσхДБю():
    value = 506288
    text = __import__('base64').b64decode('Zk4yQUlIZ2IzRHZnYndRSUlEcUg=').decode('utf-8')
    total = value + len(text)
    return total

def _φΤлНΣφυдτυЗΛΡο():
    if 69 * 7 < 0:
        pass
        pass
    value = 981449
    text = __import__('base64').b64decode('YVo3QmtKMVVwR3d6blQyS2t5b2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩοΧγтΧλΓ():
    if False and True:
        _dead_8106 = 579
        pass
    value = 257673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3i8agce2IUmFBWr5gevNSIV71E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АτМчцАΡνψΔйя():
    value = 828878
    text = __import__('base64').b64decode('Z3FlT19lSTRlVHIxRGhtckJzdGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬшχФУΑФРΞЯδЗЩΑюш():
    if len('') > 0:
        454
        250
        _dead_2413 = 750
    value = 59293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj7vVHwc1/lRHjmc7W+2AiwHs2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _моΗΖΙЛφφξΙλΠοЛ():
    value = 586295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjX0UV0S0pcLOD+U3WmiIQAd4Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жЙγпТмΦαζ():
    value = 64860
    if 34 * 18 < 0:
        704
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgG3ZkFg2bA1Khyw8X+8BSY+9Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮЦΞбВΥдΤчΖθюДм():
    value = 841510
    text = __import__('base64').b64decode('VGZsZmNta2s1NFVhZlhhM21LX2o=').decode('utf-8')
    if False and True:
        pass
        _dead_3992 = 47
        _dead_5217 = 224
    total = value + len(text)
    if 76 * 10 < 0:
        _dead_8462 = 644
        _dead_7941 = 738
    return total

def _ΓвΒτΚИΡΙΞъеηпаλΞ():
    if False and True:
        pass
        pass
    value = 930340
    text = __import__('base64').b64decode('cXR4T1JlVkgzdDdyU1ZIZVN3WUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟЬнρзОΡСΟ():
    value = 263647
    text = __import__('base64').b64decode('aDE3X3ZKQWJ6Q1JObGdiN1NCZGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙδμμПЙТχΓ():
    value = 62513
    text = __import__('base64').b64decode('RmxMYnFCVGltOHREMTkzNTJ5QWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΕЮуγчΨΞζ():
    if 51 * 23 < 0:
        _dead_8521 = 587
        pass
        pass
    value = 662838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzXld2sU1YwRaDebnwPDLRwF8kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧθДХΞщΞаΙΕт():
    value = 612894
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Li3OTWsM5K8JMS6NxQKiZRI48kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        337
        _dead_7735 = 765
        _dead_4318 = 330
    total = value + len(text)
    return total

def _цψβпЦсХвκюΡφШ():
    value = 184828
    if 33 * 20 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgjWSUAG85sJajahkAC3LA0QzXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШЬЙкАθσкУυπЭз():
    value = 841857
    text = __import__('base64').b64decode('SWVlUVZNQkdTeHdKM1ljMTlOMzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧыМφъсйςуРΣщю():
    value = 934062
    text = __import__('base64').b64decode('QXRuUVdGTTl0RFVjdlVqWXdnVXE=').decode('utf-8')
    total = value + len(text)
    return total

def _кВρЦЪчею():
    value = 607739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FinpSEkK0r5WaS2x50eGIzEL1z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 3 * 35 < 0:
        _dead_8620 = 277
        pass
    return total

def _РΔиыΥюудΦШтυρ():
    value = 339364
    if False and True:
        _dead_3418 = 496
        809
        _dead_9229 = 732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBz8SmUhwbhVNwO00XSmHRwC3nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рυαАЫШиβΛМЛωоΣФ():
    value = 704103
    text = __import__('base64').b64decode('Vkw4R1hiT0szY0lXZzdzdHhlQUs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        997
        67
        868
    return total

def _яцωМδΝшχСИΛфШΔκΙ():
    value = 389349
    if 66 * 47 < 0:
        pass
        970
    text = __import__('base64').b64decode('azZDUm1icUZMdmJMVGhJWVBuUWo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΤΣΨΗЦΞπВХ():
    if 59 * 60 < 0:
        _dead_6634 = 221
        pass
        _dead_8971 = 62
    value = 719299
    text = __import__('base64').b64decode('SkRLX2VJZzlzSzNaS1pUdTJSU0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ρζςΠγюхИβΛЙФНЭся():
    value = 88719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCvmfARp1403FwOg+kKoZCwf1nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εРЛΞППυНσρЛΑЫВ():
    value = 602352
    if len('') > 0:
        _dead_7740 = 815
        pass
        938
    text = __import__('base64').b64decode('aDlCM0xSbGc1ZElrYnlTbnkydmo=').decode('utf-8')
    if len('') > 0:
        _dead_5796 = 154
        pass
        381
    total = value + len(text)
    if 10 * 83 < 0:
        pass
        pass
        pass
    return total

def _ьДΙВТΛДΘшαΚшоκзη():
    if len('') > 0:
        _dead_6207 = 722
        pass
        pass
    value = 732675
    if 68 * 50 < 0:
        584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiezemNg0aoTbCuy/EaRLXE/410='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3734 = 53
        pass
        _dead_7435 = 238
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΓβξαΥЗПЭеζΓэΨΝй():
    value = 85683
    if len('') > 0:
        pass
        _dead_1058 = 324
        _dead_9971 = 47
    text = __import__('base64').b64decode('c2h0SUN2M2xiMWc4Q2hBYnJoVDg=').decode('utf-8')
    if 48 * 86 < 0:
        788
    total = value + len(text)
    if 79 * 97 < 0:
        _dead_9640 = 482
        pass
    return total

def _вЧξΞξΡИЭуΩЩяЙα():
    value = 320945
    text = __import__('base64').b64decode('RDVsNnY3VFI5WWY5TWRGTWVreVY=').decode('utf-8')
    if False and True:
        59
        763
        pass
    total = value + len(text)
    return total

def _бτБчΤυΟОчцαЕΓбР():
    if len('') > 0:
        _dead_6190 = 196
        pass
        609
    value = 831178
    text = __import__('base64').b64decode('Zl9YM2djRmdVc1N3SGhueFdGaXE=').decode('utf-8')
    if 36 * 55 < 0:
        6
        364
        753
    total = value + len(text)
    if False and True:
        _dead_4406 = 603
        846
    return total

def _ПΞКЕхαцШΥΖ():
    value = 505885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgTFVmI+0KI7Izn0nFGkISktslk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΠΙнуЬΧЦыΦЫЭмΙ():
    value = 69978
    text = __import__('base64').b64decode('VW15SjZDTDU3SE5UcjhscU9Ld2E=').decode('utf-8')
    total = value + len(text)
    return total

def _φжБЕщфβΔпΙα():
    if len('') > 0:
        pass
        154
    value = 611210
    text = __import__('base64').b64decode('bkZkU216YWNRNEx0YWdXV0VRMkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟηПкНβРонμ():
    value = 628486
    if False and True:
        _dead_7271 = 856
        424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C33ReFk76oABagO13U+TIAM27Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2344 = 24
    total = value + len(text)
    return total

def _ЭЪиЙΙВПнЭφЖЫτЮ():
    value = 741854
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3zqXgM91IYqbgeX+X+IPTAi8lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УσйΦΡХΠдрЙДΨЗЪιГ():
    value = 77254
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwDSXGA7xLg0EDCzy0eUFn0myjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЗБДεΒзΑεφ():
    value = 117891
    if len('') > 0:
        _dead_3549 = 991
        pass
    text = __import__('base64').b64decode('cXN1QXo2cGwxUmVFNFJoYWFocjI=').decode('utf-8')
    if 48 * 98 < 0:
        _dead_1166 = 165
    total = value + len(text)
    return total

def _τтЯΤΥκЫьк():
    value = 448078
    text = __import__('base64').b64decode('Y3JCZU11ZFUwSmJmMjhJMWRuVng=').decode('utf-8')
    total = value + len(text)
    return total

def _πАΝЩщВлАχν():
    if 48 * 29 < 0:
        pass
        _dead_6939 = 24
        289
    value = 109124
    text = __import__('base64').b64decode('c0VKWWl2VkRPaDNyZm9SbmlUSlc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        488
        _dead_4668 = 869
    return total

def _πΚΤКцЮγγΣйλΡАжБσ():
    value = 278985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AifleQdu9ZAmLDu563qpMiE86HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΟΦηшьηγ():
    value = 212320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cw7xPEVtzoYmOyD142O8OCI+9T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 91 * 16 < 0:
        pass
    total = value + len(text)
    if 57 * 29 < 0:
        _dead_7652 = 390
        pass
    return total

def _ζκьκъЛмЦЫΖЗ():
    value = 435945
    text = __import__('base64').b64decode('eVg4WDVhVldsZE1qUkVfbWhXM2U=').decode('utf-8')
    if False and True:
        769
        _dead_7038 = 578
        pass
    total = value + len(text)
    return total

def _ΠΗюΝΓНГйлъзΦςΘΣ():
    value = 635089
    text = __import__('base64').b64decode('TUl1ZWNEbmNKTmlZUGFWWVhlS1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЙЛьиЮЗЭВ():
    value = 643028
    text = __import__('base64').b64decode('VkpPbDg0TVV6QlpaU1FDdjRoQ0c=').decode('utf-8')
    total = value + len(text)
    return total

def _λΚΒнΨАЗιоΕκινΩε():
    value = 823336
    text = __import__('base64').b64decode('YnZEdklCMmJSeGVPT1JEWGpVQ3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _оΤПςЛеыЬσМΙдΗΞγ():
    value = 108486
    if 40 * 2 < 0:
        107
        355
    text = __import__('base64').b64decode('SEVMblR2N2RRcnhtYUFvVzI1c2s=').decode('utf-8')
    total = value + len(text)
    return total

def _νвЯΥΞфΦΖЩΓТБПзΠы():
    value = 236136
    text = __import__('base64').b64decode('dlcyb254cHF4TVFMdXdpek5jS3Y=').decode('utf-8')
    if 86 * 73 < 0:
        424
        _dead_4091 = 100
    total = value + len(text)
    return total

def _ьщЮαиЭэдο():
    value = 768133
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dir8Z3sh6/k1KBuv5lqSNjYa5l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 22 < 0:
        846
        _dead_4762 = 958
    total = value + len(text)
    return total

def _ГΦВκΖЙиΟΕ():
    value = 543943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB/zQmMM9o4hHz2iwmG9YiAG6kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шНйδγυΙΛЯБЩВ():
    value = 882807
    if False and True:
        _dead_6234 = 463
        pass
        852
    text = __import__('base64').b64decode('cFQ1SjZPV3BFekhXM0JWcFFPeXI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9448 = 221
    return total

def _ПψΠГдъΝυчЗуЦ():
    value = 800103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BD7VP0sj8YEyESmk42CWbTAly18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χςδδσыΟМИТЙз():
    value = 277836
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('ZVRBb2tycVFJYVRaRldnYVdvWEU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6017 = 796
    return total

def _ЗИНΤНρΘζεзΣОЦ():
    value = 137706
    text = __import__('base64').b64decode('Sm14TlBLX21UbEFXTHhXN3dtRlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙнаΤФтЖγ():
    value = 479404
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRbyY0Ij+JIBIBb1wFiYDnUAwGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 87 * 25 < 0:
        918
        pass
        pass
    return total

def _ΛΠбЧхΔГмιφЮэω():
    value = 89051
    text = __import__('base64').b64decode('UFR5WmN0U3hCMDhrVjduakRXcTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΕУэуЭχЕиπτзи():
    value = 598673
    if len('') > 0:
        726
        _dead_5977 = 522
        pass
    text = __import__('base64').b64decode('SnRRY3FIQzlucWFqVzk0VF9VRmU=').decode('utf-8')
    total = value + len(text)
    return total

def _бБьιТЛМαΙ():
    value = 475936
    text = __import__('base64').b64decode('QVNwM0xaV3UxU0FKcloyRHZMcVA=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 72 * 73 < 0:
        pass
        557
    return total

def _ЩТΡλΖηдΚΣςщΘΨΟ():
    value = 732068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXjSY3wI1awuHB+v9w+kP3Qk8Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юпБщοОμГψΩйеГэΛ():
    value = 180038
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwqxW1Uy768WDTaUwHSqZDE191c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜВфмкξвДщЙζαΩЪв():
    value = 151648
    if len('') > 0:
        _dead_2530 = 240
        904
    text = __import__('base64').b64decode('cnJ2ZGdqMjdsQUY0N2V4cDlmWU4=').decode('utf-8')
    if len('') > 0:
        _dead_7729 = 779
    total = value + len(text)
    return total

def _ШгПρфхэСοцкЧЫωΣп():
    value = 264490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LH/AdGU6xJ8ZbyGInnLCODEVyz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τМΔлтΧΘξяς():
    value = 143358
    if False and True:
        460
        _dead_1427 = 24
    text = __import__('base64').b64decode('WjZCUk1nS0UwS1Z6ZzhlRTZKN3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝφΑκπгδХα():
    value = 278066
    if 82 * 3 < 0:
        _dead_8893 = 693
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3jRb0th/PBRMiL1nHvAOzB6/Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        541
        _dead_5497 = 48
        pass
    total = value + len(text)
    return total

def _рлОРИлЖитЕηС():
    value = 319364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cnq1aV4srqYCLQOR3mGmIw4l200='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πОΦνχθγΟкд():
    value = 172907
    if False and True:
        361
        955
        _dead_4003 = 989
    text = __import__('base64').b64decode('YmlDQU1WWUNKSXc3NDAxaUVKV1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЧΥΡенεΣаы():
    value = 150736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTa2O1UTya0mYiiX+Xi6BHIjzkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БвьфΖЭФАквΥНΟаς():
    value = 777669
    text = __import__('base64').b64decode('clZOaFF5Y01lV0lXWXdva3UzMUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΓκιπςΓνфΒςФШЙσя():
    if 62 * 34 < 0:
        54
    value = 779538
    if len('') > 0:
        _dead_1734 = 677
        _dead_4450 = 52
    text = __import__('base64').b64decode('WDhNek9GbUZvZE05dlE2elR1MnY=').decode('utf-8')
    if False and True:
        pass
        pass
        403
    total = value + len(text)
    return total

def _юΘЭσпфКЫЦοУИΞВ():
    value = 827437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nin9a1wu57EAGAiF+UeVHSwp1Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6565 = 31
        708
        561
    return total

def _ΗъΕлδЮπФΘвСвΒ():
    if 27 * 54 < 0:
        pass
    value = 90099
    text = __import__('base64').b64decode('WDNZMUdzSXJ1UjVDdGhVSkt0d0I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ъτΡγоφΠЙкτз():
    value = 688458
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRz2a39t1rkpDyfy0V62ZQMbtGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7817 = 451
    return total

def _θаЦΠΑπЬωυяцУΔζ():
    value = 20594
    text = __import__('base64').b64decode('UnlXTHNIVnZucFlIUGk2YnowdVY=').decode('utf-8')
    if False and True:
        89
        _dead_8416 = 469
    total = value + len(text)
    return total

def _ШεУνεвтХΟТΤηжυ():
    if False and True:
        816
        pass
        _dead_8067 = 323
    value = 743526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jj/AUUUB05EaaRXx52G3IHQAxVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лыЮбΗπΜΟв():
    if len('') > 0:
        _dead_4514 = 713
    value = 606241
    text = __import__('base64').b64decode('R0Fmd1VIVDg5cGdGZEN3TjF5S0s=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _κКВАдςцΩσЬΠβΔΩπ():
    value = 5023
    text = __import__('base64').b64decode('YkZ0Wms2eG03cVAwS0xWa190eHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬнΘмТλШГΞ():
    value = 90576
    if len('') > 0:
        981
        pass
    text = __import__('base64').b64decode('aGZhd1Jfd3ZXSHZ3N1Q4WFNFUU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        729
        pass
        965
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()