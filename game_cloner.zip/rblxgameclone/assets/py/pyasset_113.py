#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _жЮшШБΘμΥРыψбГв():
    value = 486791
    text = __import__('base64').b64decode('cUxITTU1SXlQQ194TldpZ2JQSEE=').decode('utf-8')
    total = value + len(text)
    return total

def _щсΡЭΜβРцЧ():
    value = 939428
    text = __import__('base64').b64decode('QkZJd3pka2dfYm9IeU5PRTY5N3o=').decode('utf-8')
    total = value + len(text)
    return total

def _θЫΠРЫПψЮХЬ():
    value = 971140
    text = __import__('base64').b64decode('VUk1d0tJQUtnNlQ5djhoUG5VV00=').decode('utf-8')
    total = value + len(text)
    return total

def _БζΦрΩλΓУΩ():
    value = 718602
    text = __import__('base64').b64decode('czNMNERXaWlSNEZDUVBIU0JVYjk=').decode('utf-8')
    total = value + len(text)
    if 13 * 76 < 0:
        465
        pass
        964
    return total

def _θΠКμьтчρъРεоЕМ():
    value = 620429
    text = __import__('base64').b64decode('bDRyMnRkdExPZHlpaE1RMHBHRzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ξФЖΝИжΘДкиΔЪУЩ():
    value = 675280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzXlXHAIwYsmEVj6wnGdOBYM8j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        702
        _dead_3812 = 189
        _dead_9804 = 122
    total = value + len(text)
    return total

def _УюδΖнЗΓΚΞΛ():
    value = 486069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAjQeVVryo4ELgyA8HG7JQ4sx0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КчΗθХМαПшЧРеχЕ():
    value = 434643
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnjmO3AS+YUnNCOl5W+jESo96Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лτОЯΑΜыΓЛТРΟ():
    value = 444183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChX1Q2MO8LgUNh6G7weBHiIKzW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψъЪΟΧЧςΨ():
    value = 614675
    if False and True:
        _dead_4987 = 494
        164
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bza2Om4M2KcsaxmS2VXCGDw9/ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1047 = 668
    return total

def _ΩΖепАТΙоΟ():
    value = 213965
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCD1dwAD+YMrElyK+F+mGRZ30XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 91 * 21 < 0:
        pass
        153
    total = value + len(text)
    if False and True:
        _dead_9946 = 259
        656
    return total

def _λτΣЧоНδЭОбшβζЮη():
    value = 477537
    if 29 * 35 < 0:
        _dead_8242 = 60
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAzJekEPqr8uCRr670K4JxQc0zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 68 < 0:
        pass
        _dead_8476 = 298
    total = value + len(text)
    return total

def _УΕщнΙζκΩΡРθЦеερ():
    value = 573274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgvgQAM/+4cTMDmBkXGWHj0E3ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΟЯЭИИΔЕШΨКскΦΒ():
    value = 48518
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBvUREFvwas8MgT18l3JMQIszjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ожхЙΛглεЦБςОΟкΜ():
    value = 439663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mgu3RgUd6683ET6mnHqyBAE53Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        645
    return total

def _АклнΗνΓΕκОИьАπρ():
    value = 304809
    text = __import__('base64').b64decode('dFZJN0ZjT1NOd2N3eEFoN0tSZkY=').decode('utf-8')
    total = value + len(text)
    return total

def _фΑпрЛΞщψФипΕ():
    value = 1478
    text = __import__('base64').b64decode('aERTanlpUWdVUHpxRnc1NVRETlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ρшπΑЖФθыпΘ():
    if 6 * 10 < 0:
        _dead_6890 = 633
        _dead_1412 = 53
        116
    value = 950566
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjq1TEgvxKYNCRmT0WaWGCkLvUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θРχнАрИтЧыРΩ():
    value = 243439
    if False and True:
        _dead_3363 = 920
        _dead_1669 = 12
    text = __import__('base64').b64decode('ZlVQcW9HbXB2bGFoTWpUVUJUVGI=').decode('utf-8')
    total = value + len(text)
    return total

def _φЬФэΓφλдМ():
    value = 605795
    text = __import__('base64').b64decode('cXNfU09paVJ2QkJpck1FdWtYd1c=').decode('utf-8')
    total = value + len(text)
    if 12 * 20 < 0:
        213
        766
    return total

def _ΗщЧΒυщАЦνβΛЭσэЙτ():
    value = 210526
    text = __import__('base64').b64decode('dVY3Q240SVJscjh5bllIYXQ4OEI=').decode('utf-8')
    total = value + len(text)
    return total

def _цλЧΔΝжΡИУΧ():
    value = 114040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjvmOUk/7q0nNyuImwaAC3I702Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΞΟηΦБкйυЬщПΞ():
    value = 992807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCvgSVsd8ak2FTn7/nq0ZjQV7Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8302 = 350
    return total

def _ХΚчηЪΗГэωХ():
    value = 2768
    if 83 * 64 < 0:
        pass
        pass
    text = __import__('base64').b64decode('dDBidmVtMXNTamhYcWpESjdwUWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ШьыКΕνжΝЫσБИιт():
    value = 158821
    text = __import__('base64').b64decode('cHJRZkhWWU42M0N1S1VzR0xxVUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΞхьЙуЮθьЧ():
    value = 589398
    text = __import__('base64').b64decode('TEtMRExya2UxZUpwdUlPN28xUXM=').decode('utf-8')
    total = value + len(text)
    return total

def _χΥοφΝαмη():
    value = 768710
    text = __import__('base64').b64decode('dnpPTGFuZHhDN0NwcUVZQ2hqeDI=').decode('utf-8')
    total = value + len(text)
    return total

def _γФгοβρмΥвΨΛК():
    value = 955153
    text = __import__('base64').b64decode('TWlLWnFrelVSSF83Vmk0d1AwOXc=').decode('utf-8')
    total = value + len(text)
    if 66 * 15 < 0:
        61
    return total

def _ЯДнЮΤςκШЖλуБΗσ():
    value = 780004
    if 72 * 21 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBqyalcKxpICPj/y6UWHESs53lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        494
        365
    return total

def _кμζОΧнρλтωяНЙТд():
    value = 820817
    text = __import__('base64').b64decode('TFhEQUNIMFp0Zm1zMWlRSlR1c0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ДωΠΗМлэβап():
    value = 53386
    text = __import__('base64').b64decode('QldrWEtXOXFhVlFJWUN3aHlqbVM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1685 = 562
    return total

def _ТλЮΩΞИжαΘЕуеΘ():
    value = 363063
    if len('') > 0:
        10
        pass
        pass
    text = __import__('base64').b64decode('YjFtT1RXMkxXM3NRSnRSY1RpTWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _РΚΚτЩΓЬЩΓъЛЩ():
    value = 346052
    if False and True:
        _dead_6386 = 957
        _dead_6568 = 712
        pass
    text = __import__('base64').b64decode('T2JFNFhHX19rZ2pmM3Y4T3VZN3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЦΓШМττΜεаУЗсμ():
    value = 46593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRb0YHsey4IALVaM7gW6JhwB0zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟζЫΦТЮляγ():
    value = 498205
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwfgfmIGwYAtICKo6X/CBy4oxkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΙΣгВлЬδ():
    value = 333244
    if 34 * 53 < 0:
        _dead_5887 = 303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxvCT0g4xPw6ETmJkHylYz0uz10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 1 * 4 < 0:
        _dead_9943 = 646
        886
        _dead_3188 = 153
    total = value + len(text)
    return total

def _ξйХуупхηГεШΔаНэ():
    value = 82033
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQ7BXwdrr54uNT6M5k6SHDwnsz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УмДПЪнΕΙЖ():
    if len('') > 0:
        pass
        _dead_1540 = 415
    value = 389696
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAPxP3YI56E8Ejqu8nqKGSoK8Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2895 = 26
        551
    return total

def _дΕШйΝφяу():
    value = 49954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDmzeAES2aNUaxjx60WJJjMBy38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΕБжГЫЮΝΚηΡζυγ():
    value = 980572
    text = __import__('base64').b64decode('ejl6Nl83VUNnblgyQ1VQME12WlY=').decode('utf-8')
    if 61 * 4 < 0:
        294
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЛΧΨΨξъΤяξΞ():
    value = 488626
    text = __import__('base64').b64decode('VzNtZFo3ZUtoanRiWUQxV0tITU0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        587
    return total

def _ьλьиΓΧδлΓМБνΒΦ():
    value = 402359
    text = __import__('base64').b64decode('SVdIYWMzODE1d1hOZENuNzdPSE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ФСЧВΥЪкςзрБωο():
    if 54 * 12 < 0:
        234
        _dead_1552 = 983
    value = 843856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSqzWwUy2JBVFBa68Fy+HxYbxkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДЛАЧвΨοМУюЩΛ():
    value = 881802
    text = __import__('base64').b64decode('UnQzOUxvQnZuSGxGR2VFa25kSG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩςξУЦжΛЦηлыЕλΞ():
    if len('') > 0:
        _dead_2805 = 374
        pass
        114
    value = 520644
    if 57 * 61 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyL9bVc23L8ELgeJn1uRMzQ48W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κхΘЙШяФхДρΕя():
    if 3 * 5 < 0:
        pass
    value = 871833
    if len('') > 0:
        pass
        pass
        _dead_8764 = 959
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRrMSFA2+oU5aTuc7l7BHjIl4GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 9 * 18 < 0:
        _dead_9754 = 486
    return total

def _сχφЗвфХЙφрлЕКашπ():
    value = 702271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzW0O3I25PBVFCf35kC5AAgq4Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩВλωпоТй():
    if len('') > 0:
        pass
        pass
    value = 920492
    text = __import__('base64').b64decode('VU54MVNBMU1Lc1FhMnc1UV9hVk8=').decode('utf-8')
    total = value + len(text)
    return total

def _УйοЛαбкΜБдНΡΔмΒ():
    value = 903507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBqxVFk9q/8rMyiVynPIYnAJ0kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8071 = 76
        pass
    total = value + len(text)
    return total

def _υИρТχхσЫοЕГζυ():
    value = 461476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3zyd1c66vgFbgqpkUyyIDN37kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яПНΘКΤвАООΟЧеχΓО():
    value = 500830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxbDTAYar/4yHCaC8V7EJB0t/Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СУФκτвЧсκлтΚΓАРу():
    if 8 * 8 < 0:
        875
    value = 84541
    if 4 * 11 < 0:
        pass
        _dead_5281 = 309
    text = __import__('base64').b64decode('cDFQbkRrRFZGdVV3aHM3MmdFWWc=').decode('utf-8')
    total = value + len(text)
    if 62 * 96 < 0:
        _dead_8998 = 651
    return total

def _ΜτΛсΩщЩηдη():
    value = 613776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ki39XAEcxLoiIyb6x1WVLT0s70g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХφΠяρΡΝЦηΝηΚ():
    if len('') > 0:
        pass
    value = 151712
    text = __import__('base64').b64decode('dTloTFBMcl96WHh3RFkzY1A1VjY=').decode('utf-8')
    if False and True:
        218
        918
    total = value + len(text)
    return total

def _ΨνιиΚовσωΛЖлΨν():
    value = 913819
    text = __import__('base64').b64decode('bjZ4VkFwZmU2ZDVYQlFRUkhKVEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΧςЬВРНЫоφ():
    value = 501760
    if len('') > 0:
        pass
        pass
        _dead_7983 = 516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSXiRmIVyJsEFCa0mUHHYTQD42k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γБкρьЪρЙЮЖнЙμ():
    value = 488375
    text = __import__('base64').b64decode('eDFVTG1La2swOTVQVnhLb1hpbVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΧΥαΙМηГяσΝ():
    value = 281026
    text = __import__('base64').b64decode('c3hTQ1ptcnpySThGYWRwNDhWelo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _МΣΩЕРюξшυΩИ():
    value = 870187
    if False and True:
        759
        _dead_3911 = 25
    text = __import__('base64').b64decode('Umc1Z0o2RFR4QldrMGp6VVFmZDA=').decode('utf-8')
    total = value + len(text)
    return total

def _вδΡφмυуеΡθΥδ():
    value = 893935
    text = __import__('base64').b64decode('SEFjMVhFNG9VV1NuX2I1WERMTHo=').decode('utf-8')
    total = value + len(text)
    return total

def _зЛκРлпщЗκδΣТζΡК():
    if 61 * 54 < 0:
        536
        _dead_9382 = 907
        87
    value = 134554
    if 65 * 49 < 0:
        pass
        _dead_7701 = 268
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HS7QVnM7rLoCMwH1kEaHYSAI/m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 94 < 0:
        pass
    total = value + len(text)
    return total

def _ЕЖμβгσΣвь():
    value = 127654
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj7rXXctrY1bO1by3lyaOxIG8Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        926
    return total

def _ьсьмзРνаЩΖωΑжмτц():
    value = 657225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXfxfkAY3Y0wAhis0WacB3Ir7UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖбΦкξРгγК():
    value = 763943
    text = __import__('base64').b64decode('SGZVeXJNSXc5OHNiNWJ2NVJHdU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑЦοΧяУъЮСъηАЬиьτ():
    value = 255140
    text = __import__('base64').b64decode('UUFWV0ZsMTdpYTJUUmMzOE0xU1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝσяαΧΚβэюЙδ():
    value = 722818
    text = __import__('base64').b64decode('VmVDdHh2cE9fVllCU0RlNlZ5S2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙАαэмΦдуАмеρρс():
    value = 78163
    text = __import__('base64').b64decode('bUo4ZXJPeFNPM0tWaFpQZm51ZWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΝΧшдΤнвδиΨи():
    value = 849807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnjeZ2Q3pp0rCgux61iaFXAHy2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1199 = 724
    total = value + len(text)
    return total

def _φΘэκаΩуΟνААфБи():
    value = 583902
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyPIPQEop4wRESeV/mmfNjcu/Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 97 < 0:
        pass
        pass
        _dead_8221 = 220
    total = value + len(text)
    return total

def _фΔπΦЧЯлμыωνЮζαйγ():
    value = 219545
    text = __import__('base64').b64decode('Z05YRFlSQTNqREV6OHNGVXNyQTk=').decode('utf-8')
    total = value + len(text)
    return total

def _тΡΔΕψцхπОΨя():
    value = 130001
    if len('') > 0:
        pass
        774
    text = __import__('base64').b64decode('Q3ZHNk9VdGhUQ0lqMEJsOUNiSGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ωτΨХΝсЛхλΕ():
    value = 675619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dge0QEUz3/0bPi374QaRLRY1tVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗЬοЭΠпαоμбΝоЧ():
    value = 589362
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXnmV0kA6/ERDFq6wgCmDAQbxk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4179 = 619
        pass
    return total

def _ΔЩΞθμАΕФз():
    if 36 * 59 < 0:
        624
        400
    value = 741312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyzJPls49PhQajCR31+BAAg7wkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _стрЬГκЫэ():
    value = 51639
    text = __import__('base64').b64decode('bW1LdlBGenRXTV9PMURENDRWUU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ωЖЕφКпγνЛп():
    if 96 * 77 < 0:
        pass
    value = 94863
    if len('') > 0:
        _dead_2739 = 532
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED/MSW5r6o9VOz+o4lHABhcl1Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚфздΤξЦЭΚΞ():
    if 89 * 42 < 0:
        _dead_4997 = 943
    value = 498235
    text = __import__('base64').b64decode('SkxjbDlKbkpLVzdFSXdobldyTUI=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _χνгρΒαБяуЛ():
    value = 961742
    if len('') > 0:
        pass
        _dead_8248 = 810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCzzf0QbyoUaPTqT5ETHPRoCtH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΤКЖΖΓахν():
    if len('') > 0:
        84
        pass
        _dead_7845 = 977
    value = 263135
    text = __import__('base64').b64decode('c1dkRVJJZmFfSVcyNkdBdlBDMUo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΛρеγщΘЬожΩн():
    value = 417202
    if len('') > 0:
        pass
        _dead_6414 = 821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgDQPVhpy7sxMFyKzgaiEBEOy0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘЗЙΛγуτОаИπαЫ():
    value = 995869
    text = __import__('base64').b64decode('V0Y2aVU3OXVZMmZqUGlIblZxanY=').decode('utf-8')
    total = value + len(text)
    return total

def _τНΨхНΖьΒ():
    value = 505948
    if 86 * 72 < 0:
        pass
        pass
    text = __import__('base64').b64decode('THJWMHhKdDlOYlFXMGwyTnYzbXk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9627 = 50
        731
        pass
    return total

def _ΠАБЫΚδБыаоφЯ():
    value = 923574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn7iQWIAxKZTOwKS7lyJBgYa1z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 53 * 91 < 0:
        630
    return total

def _зНРαАаЖΥШуяцΧь():
    if 30 * 62 < 0:
        680
        pass
        _dead_6341 = 653
    value = 78628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwvQPwkQ6r0LDAmH/n6IGQc94ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧвеΓΧеЯАш():
    value = 182210
    text = __import__('base64').b64decode('ckZWUHRtR3AyNmF2MUxsQ0tzT0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЫчяжΒЕрμΛьХ():
    value = 491479
    text = __import__('base64').b64decode('VmZmZUpWWTYzV2dLMTB0UFcwaTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ХФйςαщВβΘэΙτН():
    value = 14610
    text = __import__('base64').b64decode('YW1vR2FfMnh2TEJOamQ1MHRWaDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ТωдЩЮΙΓЬЗЬНПΧУ():
    if False and True:
        pass
        pass
        pass
    value = 902366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCfBbQkYzrkbbl+W70CzNjEkyjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БтζуδгЬЦΒЯΙэпΚЯ():
    value = 993030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH+3amYdqKspGCGw3ECzDT1+zVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηЗьυхнкυΑΝΔαΓΠ():
    value = 648161
    if False and True:
        _dead_5243 = 154
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCS3RX1tprwODSuz30CHFQIp830='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 84 * 73 < 0:
        pass
    total = value + len(text)
    return total

def _λлΔμΘяΚеΙγΤегИΡ():
    value = 957856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwnFSXk+qP4GDyOamm+KGzAG928='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪλΚΑьδΗς():
    if False and True:
        712
        276
        _dead_4902 = 981
    value = 327282
    text = __import__('base64').b64decode('UkU0NVVDR0FYX1I2N3dqWWNwTko=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙθЭДФпΧУкООФιΜ():
    if False and True:
        pass
        307
        _dead_9193 = 202
    value = 943321
    if len('') > 0:
        800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ehr8eW4s6q9TagywwwTIJy8O/HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5558 = 400
    return total

def _йцЪЭеПгп():
    value = 725203
    text = __import__('base64').b64decode('amNCVmxtSkw2TUFTSEhhM0d3bWc=').decode('utf-8')
    if 3 * 8 < 0:
        _dead_7167 = 947
        817
    total = value + len(text)
    return total

def _пФдηΛОТХжУ():
    value = 952728
    text = __import__('base64').b64decode('UllPZGFPTWdlVGNDT0xnTlNFVFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥЬμεРΙЛЙю():
    value = 715728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXr8OEdp7KUvID/7mWOhbXF7tEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪηБхВκμвэψБцс():
    if 19 * 96 < 0:
        pass
    value = 406534
    if len('') > 0:
        889
    text = __import__('base64').b64decode('dFpqUmxLMUgzT2RhNHpYUnVob3A=').decode('utf-8')
    if 47 * 81 < 0:
        pass
    total = value + len(text)
    return total

def _ЩαчКдιΙΕМюЧЫτюд():
    value = 365571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSjzf3RsxI5bbiOMzX+VZXAmsXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 89 * 66 < 0:
        258
        _dead_7105 = 176
    return total

def _дФЦЮΘρπЦЪγЙΑЫ():
    if 7 * 20 < 0:
        166
        _dead_9454 = 329
        _dead_8169 = 316
    value = 742825
    text = __import__('base64').b64decode('QTg2bXRWbXR2UjVJcWpCYXdCX2w=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_1280 = 32
        pass
    total = value + len(text)
    return total

def _μВθеΙЖъΤμцξфΑю():
    if False and True:
        pass
    value = 624852
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICDUTQY7x6FROFyg7me0ZQ44/Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6770 = 578
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4567 = 822
        _dead_9847 = 343
    return total

def _ΧΗСшьΙΝηЦΕУτγ():
    value = 861439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwDKV1M3+fhVPyGF8lnJbXM3z0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДОΡφΓЯΠЕзЛРЪГπ():
    value = 576229
    text = __import__('base64').b64decode('aTFJRng1WmpNZHZfWGluZThLSjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙΦЗΒνΜΒТ():
    value = 175791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwftZVkWwZcoDD360QCeEg0EtG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒμΖΣψуыΘыμ():
    value = 151370
    text = __import__('base64').b64decode('anhGdjVQUmh4Ql9pdk1PSUE0S3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤθψьбтΘБЬчΜ():
    value = 780958
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LifPbUA69v4yOT2m5lqYAjY+xkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        73
        pass
        677
    total = value + len(text)
    return total

def _φΧΧжςХΨщδκу():
    value = 467113
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED/pQ0cW2bIFLRmS+WKIDjEI00I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        154
    return total

def _РГШдОψубхУЧΚ():
    value = 109506
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('a2dQVXhLT0VxQ1RqVF9KQ2VkbGc=').decode('utf-8')
    if 90 * 8 < 0:
        pass
    total = value + len(text)
    return total

def _киДβЕΒΡЯпнцззΟкΥ():
    value = 290728
    text = __import__('base64').b64decode('V0xPR2xab2RiUTVOSWtsRlNHSFA=').decode('utf-8')
    if 62 * 9 < 0:
        pass
    total = value + len(text)
    return total

def _ΕυγтЩσкΛΡφТг():
    value = 963258
    text = __import__('base64').b64decode('dTJHMWhEOEk1ZlNoTmVOUkZYck0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣПЫΜφтьяЭΣцδ():
    if False and True:
        _dead_7150 = 59
    value = 530065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyDzXGNpzI0Zbl6a526ZHxYcwT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДδлфоΑдΗυ():
    if len('') > 0:
        710
    value = 788644
    if len('') > 0:
        292
    text = __import__('base64').b64decode('VTJwdzhfRUVKQ2g4d0Z6ZUVNcGU=').decode('utf-8')
    total = value + len(text)
    return total

def _τΤГБнАНУдЬЗлэδΗ():
    value = 837566
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAvBQ3gh3P0WBSygnX+kDgwp73o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΤЗζНЖОУθяиγХф():
    value = 695004
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgvCe1Zo9JhWKynz8kSAZHQkskk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εБΨΑЗоΕСФΕЭΨΩΧЫΜ():
    value = 775733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCjsNlw65LsmPiec8nCiMTEAyjk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИμтыЖПЯΥογσθъТ():
    value = 500234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxXWTAhs27IXNzez6mapHgoO/UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩэΘΨЗщΙВΠВ():
    value = 31893
    if False and True:
        325
        951
    text = __import__('base64').b64decode('UGlpMjRydFNVNkU3Wl9jaFVCdGc=').decode('utf-8')
    if len('') > 0:
        _dead_1001 = 556
        pass
        984
    total = value + len(text)
    if len('') > 0:
        _dead_7465 = 580
        pass
    return total

def _иΒкуγСΠвΑдшДΥРτя():
    value = 270310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3v8P3oD8KAHbjmWxwWmHS17s2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓПтРΒЖЗθРψЦУИр():
    value = 289859
    text = __import__('base64').b64decode('ZjFUNnlraDlvcFRidVRHX0RLOVU=').decode('utf-8')
    if False and True:
        _dead_1229 = 409
    total = value + len(text)
    return total

def _мзхΛдΓУΘσλнУС():
    value = 200758
    if 8 * 66 < 0:
        413
        _dead_3198 = 157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhXtYHoI9qQoG1j73lOjBAId7X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚыэыΝПДэфΦХ():
    value = 634857
    text = __import__('base64').b64decode('TjJ1MmFZdzRaMnVfTVdkVEpZNUc=').decode('utf-8')
    total = value + len(text)
    if 62 * 81 < 0:
        _dead_5458 = 843
        277
        pass
    return total

def _эНαЯюКЖШГЫΛъЕβ():
    value = 875608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwjiVAhur4lXKF6R4mO2FjcC0Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8612 = 627
    total = value + len(text)
    return total

def _кπχγжΣΡлκ():
    if len('') > 0:
        _dead_6808 = 547
        pass
        pass
    value = 13354
    text = __import__('base64').b64decode('U1NNb0RYblVhYV9SdGIybzE2UXo=').decode('utf-8')
    if len('') > 0:
        651
        _dead_2149 = 328
    total = value + len(text)
    return total

def _ΒОρШАΑОαУч():
    value = 479906
    text = __import__('base64').b64decode('TVFtek5aaGtVWU0wNHdXTWRiYm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΗζЪλчΟо():
    value = 254401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnyzPGYwyPoFKRan5HnEMDclxUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΟйЬτжΧЧЙ():
    if len('') > 0:
        764
        pass
    value = 356944
    text = __import__('base64').b64decode('ekZWT1lxdzM5RUJiOWxGOVlVcHc=').decode('utf-8')
    if 48 * 7 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _πтΚеΒМГМчФ():
    value = 972316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwTmTEgcrZ4POFevz0SvbScCzls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦнЮΩГГнДω():
    value = 922445
    text = __import__('base64').b64decode('ZVRLaXhrdWtuX0piblBzX0lVOUM=').decode('utf-8')
    total = value + len(text)
    return total

def _СмΣσЫαРΝХΓΘФΘψ():
    value = 590221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCndVgYozKU8LQ2a0Q+6PRB/y1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΨΘςυтΠПшΩьεαЪЭТ():
    value = 576833
    text = __import__('base64').b64decode('Qzc0NE8ydXVreXVyZ3VReXFLZ2g=').decode('utf-8')
    total = value + len(text)
    return total

def _рЙΠВΖцΥБбΣ():
    value = 348554
    text = __import__('base64').b64decode('R0RLbk5SellsVDRyR2V2N3BsRnE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        493
        579
    return total

def _ТςσдЦΡсρбΡΖвξμ():
    value = 665590
    text = __import__('base64').b64decode('b01wd2lfY1RWdlEyS0Q1NlF5RGc=').decode('utf-8')
    total = value + len(text)
    return total

def _дпΩГλΨРΗυбъΕр():
    if False and True:
        468
        999
        873
    value = 359542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITfwfGE084EwPVmx/UaEHQ17yVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_8563 = 397
    return total

def _ХΔДΗбГрбΒζГФΔ():
    value = 413976
    if False and True:
        _dead_3304 = 444
        887
        _dead_5693 = 678
    text = __import__('base64').b64decode('VmJwWmFRUXNLbVh6QU5lNnhBeEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ωЖеΥйΒσПΔθЧ():
    value = 602562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDfiRH4N+qJbPly392CEZSEM71Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        484
        _dead_8263 = 843
        _dead_4086 = 209
    return total

def _ютХаПΧζМнЦЗРядτ():
    value = 787705
    text = __import__('base64').b64decode('WDJ3ZjRLRUE1MVladF85b1NHTms=').decode('utf-8')
    if False and True:
        _dead_2820 = 477
        pass
    total = value + len(text)
    return total

def _жΨаσιвлжΓГ():
    value = 36274
    text = __import__('base64').b64decode('emVSaUFzNjREVVhnMGVpaWhlc1I=').decode('utf-8')
    total = value + len(text)
    return total

def _βΡЪБΜЛйΟрбяОα():
    value = 886106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAPWX2Y72bBTIhaT4kK4OQl99lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΗЯμчρИк():
    if len('') > 0:
        706
        pass
    value = 423815
    if len('') > 0:
        519
        940
    text = __import__('base64').b64decode('aW1QbkxKRDJHbnJjWjBVa0RnNUE=').decode('utf-8')
    total = value + len(text)
    return total

def _εБйЧΝхψΦΤ():
    value = 867162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3rxWVQBqJoqIwSb+X2xCyp4tT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5803 = 373
    total = value + len(text)
    return total

def _ΨλоЙΚΨфγуЫа():
    value = 660114
    text = __import__('base64').b64decode('S1NhYmZIbGplZ3RuRlRLODZNWDI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_4795 = 74
    return total

def _йчΑΑШрΜςС():
    value = 115090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAfSQUNr5vwqNCyN53OdI3126jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 28 * 50 < 0:
        505
        _dead_8035 = 437
    return total

def _ЯΛоπΑЛЯηВδνЙΞψθ():
    value = 585230
    if False and True:
        373
    text = __import__('base64').b64decode('aGxFWWFjSW1BRF9qTjdmb2doc24=').decode('utf-8')
    total = value + len(text)
    return total

def _ικΧппшΝй():
    value = 787225
    text = __import__('base64').b64decode('cWhpUTlURW5tR3ZLU3dUMXBjTHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ξЩΔЗΡЕыЬΞπлйτ():
    value = 380010
    if False and True:
        _dead_9754 = 980
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQXeflhhzpkACyG34gDHOC0A0Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩПбΝχσоЯθςηΒυ():
    value = 96699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyboWgc97qMHBSqX/V23NSF/0z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЕαΛСΚюухжЙмьσΛ():
    value = 268944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjnIOGcLzqEQNRWg0U6UIwQ56nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        787
        _dead_8099 = 133
    total = value + len(text)
    return total

def _ИчЙτВΒυф():
    if 63 * 100 < 0:
        85
        _dead_8322 = 50
        pass
    value = 730811
    text = __import__('base64').b64decode('UE5qclZOd1kyZWZ5UG9QX2M2Wk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΚΗθРХΙЪΣРэеФдκπ():
    value = 575445
    text = __import__('base64').b64decode('cDJGUG5Zc0VCWVhfMzdyelNuTVQ=').decode('utf-8')
    total = value + len(text)
    if 73 * 45 < 0:
        pass
        418
        pass
    return total

def _щшρшΧлнЯэаΧΣьΜМ():
    if False and True:
        328
        _dead_1364 = 829
    value = 368916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRnealUyp44kOzmEw26WLQgi6Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 20 * 51 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _бσΚяωβНцΠΚλ():
    value = 375280
    text = __import__('base64').b64decode('UU5Wc25GblpCSmJIMkxmT05FaXM=').decode('utf-8')
    if len('') > 0:
        337
        pass
        _dead_4033 = 949
    total = value + len(text)
    return total

def _ЫьщΨΟлЯΘΘ():
    value = 71132
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H33LYEkQpoNRCS2BnWKAMyMqwVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φТΝВжДдΡ():
    value = 235200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT7mXkgr748ECRmQ0QelGDY13kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜιαИадкΥГΔзΥэ():
    value = 837975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fiz8f0UV9bgyKiGl+kWzISB6y2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σщμДЩηΩЦ():
    if len('') > 0:
        _dead_2663 = 798
        _dead_3664 = 45
        pass
    value = 407341
    if False and True:
        pass
    text = __import__('base64').b64decode('YjJaZDdoWm90NzQ3RUtIMlp0enI=').decode('utf-8')
    if 79 * 89 < 0:
        582
        pass
        108
    total = value + len(text)
    return total

def _ΑНΦбыρрЛЗАЯΖ():
    if len('') > 0:
        pass
        34
        999
    value = 869686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzXUP3A8150nEgCL+ESBBAp2sF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7018 = 957
        pass
        824
    total = value + len(text)
    return total

def _ΕБθпΛяΧоεкΚβγ():
    value = 336239
    text = __import__('base64').b64decode('Uzc2S1QyYWZBc2NHYlZza3FSNlk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ηЫнЙζΦξςР():
    value = 736396
    if 71 * 89 < 0:
        _dead_5645 = 226
    text = __import__('base64').b64decode('d0Uwd0pBUHZsZFZQTXlLcTRGME0=').decode('utf-8')
    if False and True:
        _dead_6644 = 606
        pass
    total = value + len(text)
    if False and True:
        pass
        905
    return total

def _РΖρэЪЩиΛяюУ():
    value = 538356
    text = __import__('base64').b64decode('ZXpwZVE3bkpycEFvNWlUQ2UxVk4=').decode('utf-8')
    total = value + len(text)
    return total

def _φκчабЧЧХωЖγνωбОК():
    if 17 * 18 < 0:
        351
    value = 751571
    if 19 * 34 < 0:
        323
        120
        _dead_4904 = 710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiLmbHpt874iPjurxViGFRF3sDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥБЩИΛОΑΤфыΑщЦюра():
    value = 266403
    text = __import__('base64').b64decode('ZFRQbTNTX0x0ZzZrRFFsdmFWeHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΩАнΛшτдАΟΖБΙз():
    value = 207638
    text = __import__('base64').b64decode('YWFabm1CRlM5cmc3cnloNHNxV1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _дтΒΞΗЮΗΩНпЕ():
    value = 766982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISroRUUjyfEbai2QnHTFGSYLyjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θгМςαψЮмψθбΨ():
    value = 106396
    if len('') > 0:
        _dead_2754 = 915
        55
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz30a0Y2raIUPzWrynmGNyM+0nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βΜΒβζΤрс():
    if len('') > 0:
        _dead_1146 = 915
        _dead_5917 = 926
        _dead_4035 = 40
    value = 392731
    if len('') > 0:
        432
        _dead_8735 = 139
        _dead_7342 = 845
    text = __import__('base64').b64decode('SDZCSVdnUmd0QXhGZnQwSk9DRFk=').decode('utf-8')
    total = value + len(text)
    if 68 * 83 < 0:
        _dead_2459 = 76
    return total

def _φΨеΩιΥπеВΦΛжι():
    value = 28101
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyDyRnMyr4UTPh224FWdNgIu12A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΔЬПΒкνκЭΠАυКЯ():
    value = 318994
    text = __import__('base64').b64decode('S2tMSElxV0VBUnlpNUZDdjVUUlY=').decode('utf-8')
    total = value + len(text)
    return total

def _хяжыщΧъб():
    if len('') > 0:
        263
        pass
        799
    value = 955048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ij7JW0UIrqoPBTWOw3u2Ji4ZtEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧалЧψиΟΟξщГэИ():
    value = 426796
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnbceV0T7YY6PQq14Xu3HxQ45Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υοβлъЦθπдНξуФз():
    value = 952593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DA6wR18a6fAGNxi0wE63MhIIxnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψйιΙχΙЭΙ():
    if False and True:
        pass
        pass
    value = 155867
    text = __import__('base64').b64decode('cnJUU2NqRmNKSUs1T29YaHpjVGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗчбφГσθХ():
    value = 868202
    text = __import__('base64').b64decode('UGVmbjMwZGozUnBDVWVXZ3JXclU=').decode('utf-8')
    total = value + len(text)
    return total

def _уσхдοξΨАъЗηПьκζ():
    value = 957813
    text = __import__('base64').b64decode('SGM3UnBtYTZJTDdjWnFrcmpUb2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑτВжποччψ():
    if False and True:
        pass
        pass
        870
    value = 798354
    text = __import__('base64').b64decode('TFN2WlBfc0NwcWtRMDB6c1NzX3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΔКуδςсТΧаЭшςΛξ():
    value = 838781
    text = __import__('base64').b64decode('dUpscklWNjA5YzJNZFlnOThxOXY=').decode('utf-8')
    if len('') > 0:
        pass
        398
        pass
    total = value + len(text)
    if False and True:
        _dead_1971 = 338
        pass
        _dead_1560 = 124
    return total

def _БδЬюΩνОЦхИΗдЗξΠп():
    value = 532601
    if False and True:
        792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACK3S2Bs9aMKCVeFw36FHAAi42w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗлШασшβЦ():
    value = 633687
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgfVbXsS9vBUClqa3HHJDnAb60M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДχΔΩΗЦияΒлΥИδыε():
    value = 460770
    if False and True:
        pass
        963
    text = __import__('base64').b64decode('eXVzNUxqbjJuSXRjd2g2UktNVVE=').decode('utf-8')
    total = value + len(text)
    return total

def _мΥΣСуУжΙΚХьпΖΗ():
    value = 827830
    text = __import__('base64').b64decode('ckZjdFcxY0FXT3hqQTRmcEFpcGk=').decode('utf-8')
    total = value + len(text)
    return total

def _БοжσΔαου():
    value = 133178
    if 12 * 9 < 0:
        pass
    text = __import__('base64').b64decode('SW8yQkphd3BnR1pNRENxam04d0Y=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3799 = 617
        383
    return total

def _дЙбэхΙШйНιшΘюОрМ():
    value = 572339
    text = __import__('base64').b64decode('TEliUlBqbTIySGY4Umtod0FXVnQ=').decode('utf-8')
    if len('') > 0:
        _dead_9001 = 746
        951
    total = value + len(text)
    if len('') > 0:
        12
        pass
    return total

def _ΜζуΖПΟξиЫЯХФгΛЕЯ():
    if False and True:
        395
        _dead_2284 = 642
    value = 992660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQP3Z0AN2KA5aD+A7gCmYCwQwGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИЗπΧΝΙασнГАЕΨвшΣ():
    value = 531677
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnzRRQlu1KNWNgeJ8U+2M303zl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _καΗΜэиЬТΓ():
    value = 851418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mgj3eWsU0rAAHDeJ0E+1LSkZ4kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уеЪδоΑΩаУβ():
    value = 765863
    text = __import__('base64').b64decode('cXNfbk83SEc2UmxPcExXSXNCR0s=').decode('utf-8')
    total = value + len(text)
    return total

def _МЬэжωзЬιДЧ():
    value = 498206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTnqYQQa3K8ZaSL78FGSExQn92s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕςЛЫΜОхФюЛВ():
    value = 503652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSjyX2c08aYsbAWz6VzBBRc6yGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        360
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('cg==').decode('utf-8'))
if 23 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()