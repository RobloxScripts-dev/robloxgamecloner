#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΖгъωчΛδвφтθεРью():
    if 45 * 60 < 0:
        _dead_7629 = 868
        _dead_8538 = 931
    value = 516509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRzua0hgyrkLOBiQ8mKzOQwX6Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зщЯиΕΕЭШсμΔυС():
    if False and True:
        556
        703
        244
    value = 349796
    text = __import__('base64').b64decode('c2EyUFBhZ1Z6bXFKTVdLRzlPNUM=').decode('utf-8')
    total = value + len(text)
    if 59 * 71 < 0:
        _dead_6295 = 924
    return total

def _ΞВыЯδУΥΚжРΦν():
    if 3 * 19 < 0:
        142
        _dead_7805 = 788
        664
    value = 267708
    text = __import__('base64').b64decode('YmxyV0tWSlRISktfUlRFZWQxZXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ясΗκЕχπΨк():
    if False and True:
        894
    value = 7279
    text = __import__('base64').b64decode('Y3REV2pUQ3VRaEVwNVN6V2hlM1Y=').decode('utf-8')
    if 51 * 91 < 0:
        490
        _dead_7049 = 605
        _dead_5681 = 982
    total = value + len(text)
    return total

def _УчβМΤжЩθКθαπΙи():
    value = 205851
    if False and True:
        pass
        _dead_2026 = 849
        pass
    text = __import__('base64').b64decode('S2FUQ2lxazZkRWdzV1RqNlRmQjY=').decode('utf-8')
    if False and True:
        260
        986
    total = value + len(text)
    return total

def _ГеКαηАЮшΔςж():
    value = 551228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dnj1ZwASyZ4KPxyv6wHBZTEBsUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 19 < 0:
        _dead_4489 = 658
        _dead_7334 = 402
    total = value + len(text)
    return total

def _ιΖЩъΛΠΤηъ():
    value = 349872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh3BWHsWqL1UODWl3QazMxEMvXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡσιивνюЬИЗγДΔ():
    value = 354617
    text = __import__('base64').b64decode('Zmh5RUp3dV9ZTDRqdlkzRkVER2M=').decode('utf-8')
    if len('') > 0:
        165
        pass
        576
    total = value + len(text)
    return total

def _МηΞчМущДσΝДηЦχ():
    if len('') > 0:
        434
    value = 719619
    text = __import__('base64').b64decode('dWVHYTVTZlh4TXRYcVBHWjFUa2M=').decode('utf-8')
    if 66 * 70 < 0:
        225
    total = value + len(text)
    return total

def _КОЭυщЕντΘΤπбг():
    value = 164557
    text = __import__('base64').b64decode('b09nV0ZDTXIwRFZwUmpkcWltRmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ψщψгηусъъИ():
    value = 125263
    text = __import__('base64').b64decode('Z2JNSE0zenBuQmRKMmQ0cVFfYks=').decode('utf-8')
    total = value + len(text)
    return total

def _βяЫТΥωБυΨтьΝйΕΛΠ():
    value = 705619
    text = __import__('base64').b64decode('dGpWTURiUnRHd0xrNjlXYWxhWVk=').decode('utf-8')
    total = value + len(text)
    return total

def _γθβчΖΥчыΨ():
    value = 461885
    if len('') > 0:
        pass
        89
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTXgenA99otXEVfznFiHDhN48jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 63 * 48 < 0:
        295
        pass
        627
    total = value + len(text)
    return total

def _тсАΗзЫзд():
    value = 812459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECP3R1Vq+6AKEhmUnnCVIxYgtEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯСωЮΙπАмΦψкζгΦ():
    value = 885480
    if 86 * 37 < 0:
        642
        pass
    text = __import__('base64').b64decode('c3RJUWxndXp1SnMyQWp0QVhMREo=').decode('utf-8')
    total = value + len(text)
    return total

def _цΣΞΦФεκсζи():
    value = 443091
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz3LbWE82II7Ewb23lucOREI/HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        760
    total = value + len(text)
    if 17 * 89 < 0:
        433
        801
        313
    return total

def _ХΖдыГΣУΙΙОкЪНШσΙ():
    value = 678783
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('UGpNWGVCWnE4dTV3N01HcjJ1TlY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩΦэεΥеφуπο():
    value = 155101
    text = __import__('base64').b64decode('R01QZWxURlFkUkpJdnpxVWdyYzg=').decode('utf-8')
    total = value + len(text)
    return total

def _ИьθΓОжφΦмиΡΩ():
    value = 696917
    if len('') > 0:
        _dead_7759 = 415
        103
    text = __import__('base64').b64decode('bTZzUzd5OEFEMEJRUm1KekxrUk4=').decode('utf-8')
    total = value + len(text)
    if 32 * 23 < 0:
        652
    return total

def _ςΝιЭЙконУыЧХεΤ():
    if 97 * 52 < 0:
        _dead_7626 = 449
        pass
    value = 96033
    if 35 * 68 < 0:
        _dead_3110 = 528
        pass
        pass
    text = __import__('base64').b64decode('RWRpbm02TG9HR29lQ2FNb0VXY18=').decode('utf-8')
    if False and True:
        pass
        _dead_8754 = 180
    total = value + len(text)
    return total

def _оЛΡвΚшлЖζΥ():
    value = 595085
    if len('') > 0:
        _dead_8263 = 676
        pass
        pass
    text = __import__('base64').b64decode('Z29hUjZPRFFBajUwa3hYSXFYQWQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5769 = 167
        _dead_5952 = 959
        _dead_1669 = 69
    return total

def _νНеТΥДДψХΛνыβ():
    value = 472348
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh7JYUQSxvgiIiySzFKaMQw9zUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ρΔψТИΠΜτб():
    if 65 * 98 < 0:
        646
        pass
    value = 153362
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCezOWsG/5tTDTD3zUyKLisQ5lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        613
    return total

def _ιГΒΝχΟЮΕжΨνиζУ():
    value = 934554
    text = __import__('base64').b64decode('RzZESURXYTlMT0dXejRIQ2NfcFg=').decode('utf-8')
    total = value + len(text)
    if 56 * 82 < 0:
        506
        pass
        531
    return total

def _βππуξБρнΛυΦ():
    value = 806428
    text = __import__('base64').b64decode('cmNERzQ4bTQ4c1pnMXhITWdoTUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _шгОκΔмςАΩшΨ():
    if False and True:
        pass
    value = 420208
    text = __import__('base64').b64decode('eDJyQ3NXVUdYOUpXcHVPU0U5RGs=').decode('utf-8')
    total = value + len(text)
    if 56 * 83 < 0:
        pass
        _dead_6966 = 75
        1000
    return total

def _КτΔуΩЗНΛΝЖ():
    value = 81977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgnwdmE6wZguHweT7nKVZhV/1z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыЪΣзЬбςЧЛДТΞЦνб():
    value = 30932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eye0enIzrZ1RKAi773C6GwAX91Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ошиЫлνДщδГыу():
    value = 776301
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDi8YlkB+fEpNx+0z3i/EjE2szs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦэаЛΨοыЙЫлγΤχβФ():
    value = 713367
    text = __import__('base64').b64decode('RGRVcHBJNVA4UFl6YjU0MXE3Z3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧζьγχψядΧхиΗ():
    value = 546549
    text = __import__('base64').b64decode('TFJTRlBLS21JbHRGWXE2NHYxN0U=').decode('utf-8')
    total = value + len(text)
    return total

def _βκНАъфΓΑψΜ():
    value = 685860
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTzlYVQM24YaCyuZ0l6yGXc39Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨЦлξΡΥευП():
    value = 849727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISfBaAceyZIWPhu6mV6aAHw+6G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЫΟМμкАδЛτЬΚ():
    value = 671897
    if 71 * 55 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxnDO2cv+6dbYxi6+n3GDAh21lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5410 = 431
        pass
    return total

def _ωбНБωпЩχК():
    value = 70575
    text = __import__('base64').b64decode('eVVBeFMyYXdjNExoZTg1X1lRc2E=').decode('utf-8')
    total = value + len(text)
    if 26 * 9 < 0:
        _dead_4936 = 835
    return total

def _ИЬЯΣЩςоРАрΙйδУΗ():
    value = 378630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSfqVAcQq7FbMjDz+UW0YnE81l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗеΘЛΝЗНРε():
    value = 809108
    text = __import__('base64').b64decode('ZTBOaWVsNFNYblh1d21QZFVJM3o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        811
    return total

def _УξψщψфТΨΗКБΝюмуΚ():
    value = 528688
    if False and True:
        _dead_7018 = 174
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzXHP2U/rLIuY1z650SeLRIYsTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 44 * 92 < 0:
        _dead_6770 = 596
        pass
        pass
    return total

def _цЛСΘаμЪΓЭΑПдΜчΥ():
    value = 756116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mwi9S0Qq0vBbPji7wgeTGScA11g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        84
    return total

def _СΛδΖьΙЧэεφцаΡυЙ():
    value = 573489
    text = __import__('base64').b64decode('eWF6N0hGamt6enhJdGViVEtTeWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ДыьоВηВζщωЯаφэ():
    value = 185079
    text = __import__('base64').b64decode('c1lLNU5PMHNfaFo5RlpZNUpjdVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ωεКЭнχюθюЭΟΕ():
    value = 74930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnvVWl0xyvwmIjiZ6Q6cOjYj3H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νМΛЗйςΒНМΤΦб():
    if len('') > 0:
        921
    value = 633468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTnxa0YTrIcqOAemywSUHww5xno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΖλМθкαЩЧΛγуΜΡ():
    if 5 * 12 < 0:
        _dead_5896 = 798
    value = 593923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXi1fHcer4ATbCGx8nHBE3I6zVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нщβΧяΗЖγктп():
    value = 721438
    if 73 * 83 < 0:
        219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETvHPEkDyKEwCzWhkUW2IAB67kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        397
        pass
    return total

def _φΥηОЭδδξПРбΘФ():
    value = 510486
    if len('') > 0:
        312
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCbhV30e/a0bHyKGzFuWYw8Xw2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        993
    return total

def _υЦМζЭουЫбХΝΤеф():
    if len('') > 0:
        551
        _dead_7639 = 45
    value = 967928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCmzQVQ4764iGRWl7FWXOyAf9Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 34 < 0:
        pass
        _dead_1284 = 173
        978
    total = value + len(text)
    return total

def _ΜИιΣлψηрНсβЖадОγ():
    value = 787960
    text = __import__('base64').b64decode('cmNUVkxtVGhLOVBldnBQYUI5NWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ыНКЬΩсκВαшΥδ():
    value = 824771
    if False and True:
        43
        pass
        _dead_4789 = 909
    text = __import__('base64').b64decode('RkhYMVJhTF91Y2RZNHVtTUo3dnA=').decode('utf-8')
    if False and True:
        pass
        pass
        293
    total = value + len(text)
    if len('') > 0:
        _dead_7191 = 135
        pass
    return total

def _эАΑОРтΞΣЛй():
    if len('') > 0:
        996
        419
        728
    value = 742851
    text = __import__('base64').b64decode('Z1hrUXFwWnhEalJ4dklvN1R4eEo=').decode('utf-8')
    total = value + len(text)
    return total

def _КпκХжпΒΑсβТΕ():
    if 78 * 46 < 0:
        _dead_7706 = 740
        245
    value = 128372
    text = __import__('base64').b64decode('RXlHQ0ZBS0RRUExLTzc2X2Q1RkE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨαЪγΗυΠсжΡйЦЗкΥ():
    value = 692589
    text = __import__('base64').b64decode('Q0o4TzF4NXQwNncyTk45MzRnUnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘэЫОщЬэσΡййτΞ():
    value = 434390
    text = __import__('base64').b64decode('UzJQZ3p3Qlc4SUdiV1NWQWV6N0s=').decode('utf-8')
    total = value + len(text)
    return total

def _юΓэЗΠиДσъΛ():
    value = 425221
    text = __import__('base64').b64decode('ajNhYzdicHNhMGsxWTRTNUxFT2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ПοθУнΤцξ():
    value = 596270
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSn8Zlk2/YkAF1aT22G7FigN20I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щЕΙΨжаЧьΞ():
    value = 476033
    if 29 * 90 < 0:
        _dead_8577 = 61
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx3oXEMDz4tXAwGE+3iVFioasTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2511 = 662
    total = value + len(text)
    return total

def _ЧΜкгЫγЬιΛξВΧж():
    if len('') > 0:
        pass
        _dead_8918 = 938
    value = 465192
    if False and True:
        _dead_3163 = 555
        245
    text = __import__('base64').b64decode('WHg5c1VoaHRDbjZZUDZYVXJuWnQ=').decode('utf-8')
    if len('') > 0:
        pass
        341
        _dead_9421 = 626
    total = value + len(text)
    return total

def _ьμЕψβлоΜ():
    value = 488794
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDiwT19g9qwoaQS1nQfDFy1/6Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лСаςяаΝШбфΖΛщΙ():
    value = 928149
    text = __import__('base64').b64decode('bzZKdHZIYkNQUG44S1A1czI1eUM=').decode('utf-8')
    total = value + len(text)
    return total

def _χγσцтпсЛΙлЮΗ():
    value = 450184
    text = __import__('base64').b64decode('dk54dGlxNkpVR24yc09tWkNVNGk=').decode('utf-8')
    total = value + len(text)
    return total

def _МτεςШЭΦΣΛГΗςΑ():
    value = 645532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXv3SXQp+q07aVan2FqpGAshtEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХνЮνιЧЛΩΟΙκΕШМРч():
    value = 590374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzvOXkMAroUxHj6i8VW3Gicjtm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цЖΘςмΥΛωпΚΘυн():
    value = 801475
    text = __import__('base64').b64decode('amhRbnptUDBpMm91RUZjWXpWQ1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮюЬνбзфЕхηΤζΒ():
    value = 438783
    text = __import__('base64').b64decode('RVljUlF1ZDJjNjg0dGxWWkZfU2w=').decode('utf-8')
    total = value + len(text)
    return total

def _εкλИЖИΘΩΦξ():
    if False and True:
        1000
        _dead_9242 = 847
    value = 716763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ay72RnIpyrgONDqo33+CCzIhtWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 80 * 62 < 0:
        _dead_2643 = 592
        pass
    total = value + len(text)
    if len('') > 0:
        502
        _dead_2628 = 967
    return total

def _ВТδЖΙсκжВτΙмΤХΗ():
    value = 776614
    text = __import__('base64').b64decode('U2ZIZmhTQldZekdwbUwwRkhvUmo=').decode('utf-8')
    total = value + len(text)
    return total

def _эιСΒΦУьсЖэв():
    value = 366771
    text = __import__('base64').b64decode('TWo1YV9EUXFXaUw3c0QxME1MS08=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥеРΗΠцУαθωдΗьХγ():
    value = 204535
    if 97 * 46 < 0:
        pass
    text = __import__('base64').b64decode('REh0S2xvN1VlWjJSdG4yN3M3TjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΙЮЬτУрГυТУм():
    value = 56512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHv3b3cLqPwxKyCo+FuyAhR4y1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9919 = 747
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        552
    return total

def _ρгГΜΤσНΠλяЮΙчЛ():
    value = 426216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH7sf0khxpgybRim8n2jHTd3tEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΜΔΚочЦφ():
    if len('') > 0:
        640
        pass
    value = 33008
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSfCS1I3zYtQPD6SxG6SEioX/To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟщΤИθЕпΒΚПЕдюк():
    value = 705966
    text = __import__('base64').b64decode('ZjNoWVZkblpyYXJzbEZzOENxVEs=').decode('utf-8')
    total = value + len(text)
    return total

def _θχΖьςнУФишπСΓ():
    if False and True:
        _dead_6953 = 392
        pass
        _dead_8937 = 153
    value = 157702
    text = __import__('base64').b64decode('QTJFMEF6ekNSbDBBT0pGVUFYNTU=').decode('utf-8')
    total = value + len(text)
    return total

def _пзтεψΙйУ():
    if len('') > 0:
        741
    value = 567798
    text = __import__('base64').b64decode('d0xtRGthclRLRnVEc1ZTUzVPMHI=').decode('utf-8')
    if 85 * 31 < 0:
        587
        pass
    total = value + len(text)
    return total

def _ОКцЛсЗΨΟБкΦ():
    value = 393045
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxjnR2Iu25EzODf0ywCTYgQC1To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕХаεΖΡψгзиμΕ():
    value = 844142
    text = __import__('base64').b64decode('b1BMUEExUUc3UHhOZXhJS2xyVnk=').decode('utf-8')
    total = value + len(text)
    return total

def _μПЕΔЬАВтУ():
    value = 468563
    text = __import__('base64').b64decode('YU9XMkE1NzVwUEtVYmRtUllWMW8=').decode('utf-8')
    total = value + len(text)
    return total

def _чйнжυБμωып():
    if False and True:
        pass
    value = 876969
    if False and True:
        222
        pass
        pass
    text = __import__('base64').b64decode('Tm1RdDY0MF9wbm4ySWRidV9rdUg=').decode('utf-8')
    if 41 * 90 < 0:
        522
        _dead_5446 = 993
        pass
    total = value + len(text)
    return total

def _ΚнΩσΜψФриЯκ():
    value = 229081
    text = __import__('base64').b64decode('T0ZQbVNPWmlVNW1QMXlRZnN6QUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ъγьЫοЗЯν():
    value = 347156
    text = __import__('base64').b64decode('QjNpd2pvRHpPYlg0aTJwYmpaR08=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        117
        _dead_7560 = 395
    return total

def _ВВЬшАЖΖωп():
    if 57 * 52 < 0:
        pass
        pass
    value = 54645
    text = __import__('base64').b64decode('dldGdmdBdEltdXBiclo0am82VnQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _охγΔВΠΓσΗΞΛаЧ():
    value = 759700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCrseksWy6EwAwOU8GLIBHIA/Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЯγЛТЪмЖαЬлΓпют():
    if 91 * 33 < 0:
        392
        99
    value = 92154
    text = __import__('base64').b64decode('dmZFSXdHWDVvOGpOczdySm5ScEY=').decode('utf-8')
    if 9 * 45 < 0:
        219
        182
        pass
    total = value + len(text)
    if False and True:
        710
        pass
        102
    return total

def _ΤςκХвТмΧпЮ():
    if False and True:
        784
        38
    value = 696706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lwm1PgYQyIxUNyyF2gaALAR2s08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьγγчыйχΒпОΙ():
    value = 66544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBftbXkKzfwOLAOG8ni6ZiN923k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φШΕаιΑЪЗω():
    if 27 * 72 < 0:
        pass
        pass
    value = 276916
    text = __import__('base64').b64decode('eDY3eGRXZnNrZngzZFJUQmxLN0Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        330
    return total

def _ШецбЯаВК():
    value = 587725
    text = __import__('base64').b64decode('QkpfZGVqa2c1eFdveEFET1VSbzA=').decode('utf-8')
    total = value + len(text)
    return total

def _хοξθΤθЫωоΝдτΘГτυ():
    if False and True:
        pass
    value = 565530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDWweWAYr6kCPgeoz0aJHgoC/j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 99 * 53 < 0:
        _dead_7594 = 765
        660
        _dead_7943 = 805
    return total

def _κрЯνИъΓΓсΓχεЪ():
    value = 263626
    if 51 * 19 < 0:
        _dead_6112 = 488
        _dead_1131 = 486
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQvITwE/+pwmLSeizAacCxAr5nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЬΧещΣУαрнСЫΞπ():
    if False and True:
        831
    value = 480392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITjMf3Uc0YNTOyivwQWCHiw38kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЬΖφΟΓΝОζБ():
    if len('') > 0:
        pass
        pass
        _dead_2030 = 871
    value = 575259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwTBR1wpyfkQDhr353/CIQwLs34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хмΕωзъηЬ():
    if 57 * 55 < 0:
        4
    value = 51602
    text = __import__('base64').b64decode('WFk0S0ZlWDA3c0NiX3pnX0Nqank=').decode('utf-8')
    total = value + len(text)
    return total

def _шПтνьнΑΥдЛЗЦΝГΤю():
    value = 789009
    text = __import__('base64').b64decode('Z19GRWNEdlFJd1FBZWduc1B4cTk=').decode('utf-8')
    total = value + len(text)
    return total

def _чъШдψΜΣфΞяΧЭщζς():
    value = 750081
    text = __import__('base64').b64decode('Z19mbEFDQm5STVFPa1hIbUFCeVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮгηрыτПΖΓ():
    value = 894016
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwD3SHU+0f4oNCawywSaLAo+70k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЫщфЖНςОРςΥВΤ():
    value = 842346
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CR3nWVYSqZsuGwO5mWOfBx8j1Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ррΥиΡΜЩΛ():
    value = 886739
    text = __import__('base64').b64decode('SGpMMzZmWlY0ak50YnpoN1lHbUc=').decode('utf-8')
    if False and True:
        pass
        641
        997
    total = value + len(text)
    return total

def _ЬξΝΤξтсυζβα():
    value = 656671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwXPXHAT2IAtGBmawF7ANxw1yFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИВРεтжБΑБΒμьЫν():
    value = 296402
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyPxSEAcq/sVEAGgznyIMBEa8Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        993
        46
        pass
    return total

def _пψгоДЙΡйξΗ():
    value = 224895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQfrPXsu1KA1MAaq3ACiJCx9z3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юηπирЛΠо():
    value = 449356
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB3DWmBt/IwkbV+vxF+FMhwk11w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лиьЩыЗеТуКςчθΟοΗ():
    value = 480511
    text = __import__('base64').b64decode('QXdEYjhBU1o0bGVhQXpKdmI0dWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΓйЗβЕфψ():
    if 1 * 93 < 0:
        _dead_8349 = 718
        _dead_4874 = 13
        pass
    value = 691742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiLRZkcwxoQiazyV2FO+CykV4no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7027 = 59
        pass
    total = value + len(text)
    if 99 * 14 < 0:
        _dead_3506 = 41
    return total

def _θΛχьнЧΨрΕ():
    value = 485496
    if False and True:
        _dead_9661 = 975
    text = __import__('base64').b64decode('ZkRHZXZVTmlETGJYcFNjZFlIc0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ПщΝУЗКЧΜ():
    value = 965615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MA3pWldv/54CPxi131WnADU12zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψчЭνΓξγЬξусΥβпΝζ():
    value = 557518
    text = __import__('base64').b64decode('eFp4dnpnVzdWcHhiU2p1RlRmc20=').decode('utf-8')
    total = value + len(text)
    return total

def _лЮКψΔювΚжЩЫЛз():
    value = 2547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DB/8fl0Drp5XOSSZ22moEC4iynQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 46 * 29 < 0:
        596
        744
        pass
    return total

def _φАγшςΠЪχЧΘ():
    value = 238883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDz8bWcJ0oEyGSWS6VmzY3YLylc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΙяΣυдТΑЪψκмПлсΜ():
    value = 329168
    text = __import__('base64').b64decode('Z3hRUnFKeDF5aDA0TGZkbnZYWjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙцΦψδВНешзΣΦБε():
    value = 600589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBzcTWIuwZoKAgqC+2LGZH0D8mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΛДζьбσλ():
    value = 579245
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDn0bWUYzasnFjeunGOzAigQx2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡНΒΩοЖйТФα():
    value = 725350
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiPHXwBrxLoNahyR6WW6ZXI192Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4524 = 351
        _dead_6239 = 665
    total = value + len(text)
    if False and True:
        _dead_7044 = 986
    return total

def _сНТжЯШдΗΟ():
    value = 316767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pw3vWks7p5EsHlaS7Xe4FyoZyX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΝГЛявЯΜΛβ():
    value = 765712
    if len('') > 0:
        pass
        _dead_6945 = 891
        672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAXPN1dp0pgWPV6Vm33HNSYh1Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1400 = 109
    return total

def _ιшалΕуюΛеЪяРщΘΗ():
    value = 651026
    text = __import__('base64').b64decode('T2tNdmFRNHNpdGlHSDFMOWtVOUU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        100
        pass
    return total

def _пПΘςμΛАкрГΓμσккΥ():
    value = 510153
    text = __import__('base64').b64decode('eEVjd0c3bVJ2VmtDSTFORl8wT0M=').decode('utf-8')
    total = value + len(text)
    return total

def _юΣτцЗюяХ():
    value = 760530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSOwZgMo96kFFBrywm6HHgkX3Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 88 < 0:
        _dead_2462 = 217
        _dead_1359 = 835
    total = value + len(text)
    return total

def _лЪΖζиуКвΡцΣνΞ():
    value = 277740
    text = __import__('base64').b64decode('eG5OdHBLb0RTbHFsZm1QTm5qem4=').decode('utf-8')
    total = value + len(text)
    return total

def _ζжΕξθΝжПЩуςИΩп():
    value = 57120
    text = __import__('base64').b64decode('VnVCa2lySWhfZ21KRXNBMjAxSTM=').decode('utf-8')
    if False and True:
        _dead_2231 = 530
        pass
    total = value + len(text)
    return total

def _εμΒΟкρΟНμεε():
    if len('') > 0:
        936
        351
        551
    value = 232245
    text = __import__('base64').b64decode('WUl1UVZNbkhpWnFzYjI3TjJVNDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥпШΕςнΨзЗΨШ():
    if False and True:
        _dead_9634 = 99
        _dead_9080 = 230
    value = 692671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXzmTGhu3YkENAmwyluYMy8ftUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        707
        pass
        _dead_4194 = 457
    return total

def _ΛΒβЗЯьДΓУ():
    value = 46630
    text = __import__('base64').b64decode('eEQ1Q3VjY3lQNDM4RWZaUTFRanQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ФфкΓΜЪжБσгэΞ():
    value = 210879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxjLSwMs0b45LQSi5GmXCw4Ism0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮζэЕΚвψΗλνЧβлΓЪ():
    value = 990473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjvMXmMh+pASFAKq/U6VOA8W1Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъρΙсΝζОЧШΣλПъБε():
    if False and True:
        pass
        579
    value = 25457
    text = __import__('base64').b64decode('eURwcnQydklZS3lhUUFMMWRSTm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΧЙьλХпΛйЗπСИцФΘ():
    value = 208358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwbdQAgv0bkwEQypylnCMSIatmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧНыХмτΜωшΙФπсΔΗ():
    value = 201410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXzoXkER1qIgCh6n5WSdECEa12g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХЖрΒЗиααеЖ():
    value = 80958
    text = __import__('base64').b64decode('V3BJWV8yQUdjNjRvZVRYZWVfYTY=').decode('utf-8')
    if len('') > 0:
        _dead_9795 = 477
        pass
        763
    total = value + len(text)
    return total

def _дΩнщΝяНйГΑпгδЕ():
    value = 943066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxX1SQEa3Y8UOSqmmXWjGCAgwn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓГΘлъЬΙЛФеГπПБГ():
    value = 579049
    if False and True:
        480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCfwPQIM+YoaEDqvxXmlBnYAy3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 11 * 17 < 0:
        _dead_5734 = 81
        _dead_5072 = 374
        pass
    total = value + len(text)
    return total

def _фγθιЩЭΨНЛрΑ():
    value = 643384
    if len('') > 0:
        937
    text = __import__('base64').b64decode('S1d6YjQ3QTYzN2s5Q2JkUkJ5YTc=').decode('utf-8')
    total = value + len(text)
    return total

def _пЕωιРнμЕП():
    value = 706827
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSXwY0IvrJ87Gz6A32WSMSAX8WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λμУηЬЖФτМьΜр():
    value = 464669
    text = __import__('base64').b64decode('WHpQRVJFTDc0N3lyRndvOWpVS1I=').decode('utf-8')
    total = value + len(text)
    return total

def _χΞбΑΡνΒнкьЧμвШ():
    value = 737536
    if False and True:
        919
        _dead_2421 = 849
    text = __import__('base64').b64decode('Y2hJU0xmNWRjdjJDTk1GMkxEZmw=').decode('utf-8')
    total = value + len(text)
    return total

def _пΦфΝΤξδЛьΑΙι():
    value = 921587
    text = __import__('base64').b64decode('THN2SjFWM0h4NFVVbGUwczlXSmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΟΦЮΞμθΥ():
    value = 551925
    text = __import__('base64').b64decode('cHY4M1ZsTW1RM2lBUlZBRUNFWHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙκиνηгОυΓΚЧωΒ():
    value = 278613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3bnSlAUyI4GaCy23ne7ZX0OxX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δлσνψδωζπцТдпξ():
    value = 381128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA7xOlku5/0VIiqsz1yjLHEbvU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цЬδаЕρΨΜοκαЮШ():
    value = 250777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ahf3TwZq+qAzaBmH4FqvYxEE9ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лгехΝβГδ():
    value = 739457
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('ZnlSd25JNEdhangyRU1OaHZVTUs=').decode('utf-8')
    if 57 * 94 < 0:
        _dead_8025 = 855
        pass
        _dead_1164 = 62
    total = value + len(text)
    return total

def _гμΗсЬмфбιЕΩз():
    if False and True:
        146
        _dead_4699 = 745
    value = 489795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjzyP3gzr68bPx777X6+BQMnwFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2361 = 921
        _dead_4708 = 528
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΒхψэцωΝφФщΞЕθР():
    value = 993544
    text = __import__('base64').b64decode('aldZTWJMZlpiWkRfQmp1ZDhHWXI=').decode('utf-8')
    total = value + len(text)
    return total

def _τΟαЩДзΒьнψГΘФθ():
    if len('') > 0:
        pass
    value = 869205
    text = __import__('base64').b64decode('RGVXWk9sR2ZkeURHV2R2a284N0c=').decode('utf-8')
    total = value + len(text)
    return total

def _нбξΡорЕωеΒиζл():
    if len('') > 0:
        pass
    value = 150443
    if 21 * 5 < 0:
        _dead_9121 = 289
        _dead_2113 = 624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgyyXAIo64MCIi2r42OVDh8HvH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мШλтЫкνρρСΦцκбτ():
    value = 262802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('My3oeUI66v0kHDWG60y4OwkE0kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еλΤыιρОнΦюшζыΦ():
    value = 949037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DS3yNl4o9PtaAFivnWmnIgkIzlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΡцИЬЖюЛ():
    value = 137491
    text = __import__('base64').b64decode('aUxPVW1PdHJkcVJNeGs4aXpqa2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ыьξЯЦμябΓΒμНυбτυ():
    value = 64621
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBvqX3Nh0qYxCxn351DIICAVtGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩнψΞршΨпвЬцΠАτ():
    value = 857620
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyG8awAt7p8Salf0wQHDMzUK70c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 33 * 11 < 0:
        pass
    total = value + len(text)
    return total

def _тΗГθфэФΨгВ():
    value = 830707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fi3oSUML+LpWbTb22w+4ICotzU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫτΜЧνΗνЗйπ():
    value = 538912
    text = __import__('base64').b64decode('YVJOMU94bzBSUjlrVnlJZ1JLN3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ИрΦЙЗΨаДсοчμ():
    value = 225484
    text = __import__('base64').b64decode('WndFWEViNXZHZ3VGU3hHc0NGR1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛηψщфТЖΕкψνςΛ():
    value = 120494
    text = __import__('base64').b64decode('bUp1RXpVQWhtWjl1U3dib1dwTmg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        621
    return total

def _ПтыΒΡΕςΔΨςΥξЪ():
    value = 375938
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR7dVns2qqwzCRf3xWKdCw433mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓэΠОчеКХκ():
    value = 366921
    text = __import__('base64').b64decode('QVRjZ2ZnVjRpUFNxTnNQc0t1aW0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        688
    return total

def _дфηΔΤΑзЕиΨмДΠ():
    value = 59885
    text = __import__('base64').b64decode('cTFBdE1seFJqMGxBNUt0b1hTcm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΒщКУуЭπЖгУιНκ():
    value = 777656
    text = __import__('base64').b64decode('c1p0Z29ZeDFidm4xMUdTY0dYSjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ХциΗчМЫβΩслΩ():
    value = 474709
    if 97 * 12 < 0:
        937
    text = __import__('base64').b64decode('cTh5dEhadEs0aXkxejJ2cGxzN2s=').decode('utf-8')
    total = value + len(text)
    return total

def _τвГЫжоψчД():
    if len('') > 0:
        pass
        537
    value = 478720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBDrTFVt34YUMRyMy2yXBh184Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЩЗθΦΟΟдъ():
    value = 50845
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSL9W2gh+6w6YlqF/F6lEhUE01c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 2 * 93 < 0:
        _dead_4057 = 405
        pass
    total = value + len(text)
    return total

def _ΝЮΜУЪЯΠλОΞОΔηШг():
    if 51 * 90 < 0:
        pass
    value = 287337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBa3fgU1rp82b1ekkQWpIS0X1H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬχъμЛЦЛξиΥ():
    value = 958735
    if False and True:
        _dead_1421 = 171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jhb1SkUo2/AEKlms/nexMhoV9jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩγΙтШЫΜзъби():
    value = 410616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAT8Zkhu85woMiKl4Q+AADc5sT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧРФцΒуСΤ():
    if 80 * 22 < 0:
        748
    value = 209466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiK8ancby/FQFSag8kWZMD89710='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        294
    return total

def _χΗεЮХΟθξσγСγо():
    if 3 * 20 < 0:
        81
    value = 277808
    text = __import__('base64').b64decode('Qm5Sa2NXX1lVZmJ4ZE55MGZnMUU=').decode('utf-8')
    if len('') > 0:
        _dead_3027 = 377
        _dead_5144 = 42
        _dead_4905 = 315
    total = value + len(text)
    return total

def _ЮПдΞτχНθξъНуУй():
    value = 385013
    if 9 * 13 < 0:
        pass
        80
    text = __import__('base64').b64decode('RzVqdEJPNWV0Q1V2U0habTBLZF8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7573 = 129
    return total

def _θΗМупэжуλяуфк():
    if len('') > 0:
        _dead_9196 = 544
        629
    value = 153344
    text = __import__('base64').b64decode('aUlKSzNEOU1HYTc4R1RKYTR5M1Y=').decode('utf-8')
    if False and True:
        _dead_8912 = 636
    total = value + len(text)
    return total

def _ΚкДΣЕФτЛЕπСцΗφνз():
    value = 647442
    text = __import__('base64').b64decode('U1Q4M2ZKcjZjajRrUFdIYms5dDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ОКМυεнπФσωΔ():
    value = 790871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBmwQ1wK1IQyM1v66WakMy4cz2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥυΡΔмЖεγхСгΩΙΑι():
    value = 533279
    text = __import__('base64').b64decode('YVdHOVk0ZWR3dHF5cEdsbnVnbmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΟВСМвьΗΖщβИВζЮ():
    value = 889114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgfnX1ky+6slPx6ax1qCFXEMzzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗПАψΔΧυμΥШНХ():
    value = 544961
    if False and True:
        pass
        768
        pass
    text = __import__('base64').b64decode('bFVzU0xjS2dHVk5vSG53SUxWRWw=').decode('utf-8')
    total = value + len(text)
    if 99 * 18 < 0:
        pass
    return total

def _νΣЮεΗФэчιп():
    value = 24979
    text = __import__('base64').b64decode('dURhMWs2WjhTSUJHVDI3ODU1eGo=').decode('utf-8')
    total = value + len(text)
    if 86 * 3 < 0:
        pass
    return total

def _υКΟτΛФοζΨΤыЕЛ():
    value = 483982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgPTXQEW6bpQaDmznUzCEzEl0jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШбηΖΟУφТйΓЦэΚ():
    if False and True:
        _dead_2181 = 803
    value = 979107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwfSN0sd840UDT26zmScFyMVzXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮьΚщЕшкηλ():
    value = 691769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQq3QFgc+LItHj+K7ESaAg8F7kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        944
    total = value + len(text)
    if len('') > 0:
        426
        _dead_7852 = 225
        _dead_9979 = 276
    return total

def _КжπСζСιЫΠФΦшΖСΜ():
    value = 524844
    text = __import__('base64').b64decode('eFhQdFlDd09XT2V5aEhnVzBjejg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4648 = 692
        pass
    return total

def _дъΓΞπбμυαΦΜΩ():
    value = 441086
    if False and True:
        482
        587
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICPRe3BrxIwCCyaJmgazEywdwjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6220 = 523
    total = value + len(text)
    return total

def _хвΖпΗмИп():
    if 77 * 54 < 0:
        _dead_8812 = 68
        pass
        150
    value = 952016
    if False and True:
        _dead_5303 = 14
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BirvRlAhzoUsF1eb/1udE3YL5zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бЬкφеΒπБНСβр():
    value = 201953
    text = __import__('base64').b64decode('WGdxZFB6T2drbEJuSWt1OElIYXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΣЦягΛφαлк():
    value = 767091
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhrlQXhsq4wRNz2FwEyeIgAq7l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тαδΡиΣΒΣΙнψиб():
    value = 273122
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXrJfmIb8ZxXGVyu+1uEDDE7sFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УкъобпΟтсжхφЮ():
    value = 618323
    if len('') > 0:
        pass
        _dead_5547 = 138
    text = __import__('base64').b64decode('V2lIUjlnWW52bVo2VFBvQUNMeGI=').decode('utf-8')
    total = value + len(text)
    return total

def _АΩкαЪνΘбχЫ():
    value = 565175
    text = __import__('base64').b64decode('RnhFbmJUc25JV3RXM1BUQU8wOEc=').decode('utf-8')
    if 51 * 56 < 0:
        _dead_8264 = 623
    total = value + len(text)
    if len('') > 0:
        _dead_7292 = 124
        _dead_2468 = 32
    return total

def _ΔШδΨυΩΤОщйΤΚχ():
    value = 922007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjnLXAI977IULDWE2FK/DXwM9D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 50 * 46 < 0:
        _dead_4344 = 938
        _dead_6413 = 21
    total = value + len(text)
    return total

def _УΠδБйдОЩя():
    value = 426875
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3bed35p77AGEzutmAKyHgx/6UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЕсθκтПъоθΕЫτοщм():
    value = 236178
    if len('') > 0:
        pass
        13
    text = __import__('base64').b64decode('ek9adWNfTTI1UnpXVFdLclI5ZWo=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        114
    return total

def _ΞЦИωзыЫΘдБ():
    value = 882510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DD7ra2gJqY0xMC265FWnM3F/710='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖЯсΜвуФдЬΓСмя():
    value = 511280
    text = __import__('base64').b64decode('TERqM1dzNkRMaXhhdUJiRDlLdEw=').decode('utf-8')
    total = value + len(text)
    return total

def _щλξρΥμЖД():
    value = 676372
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA7FXX4rqaRSIlulymOmI3cI1Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЪЦНДφρБэСХчЪΦ():
    value = 750488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXbbYlAs+78bOyeHmmCHEBME1To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σЫйΝьчУйьωБД():
    value = 249813
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChfreFJp7P8iLRmOxwW8Gys101o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _шРТφΡΩжρбΣтсЭΟΤ():
    value = 527745
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCW8SAFh5PstPg6M/V6bIB8tzz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛοЗЪтлνбνΟΔЧ():
    if 45 * 31 < 0:
        pass
        pass
        863
    value = 180224
    text = __import__('base64').b64decode('WmZzZ1NRUEdQc1QzczhyRlZhbVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ВшЩщωКНΘдΛДеΧ():
    value = 443359
    text = __import__('base64').b64decode('WnZWOVFQbGlITllzT2hHT3hQUkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('dA==').decode('utf-8'))
if len('xxxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()