#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _уΕΨΦΙαΟПбФΛΕΝбМК():
    value = 773699
    text = __import__('base64').b64decode('TDZaODh3UVQ2b1E5UTFxS053YnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ζЦΕεЦЙУΠе():
    value = 740902
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID+yeHoY2J4hDFqU/H+nAgQVwlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еЧΛΡОνΟΧСВц():
    value = 54257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cnn1bHISrY4vCQuG5n2ZGCIkxkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΩβεΜΚТАоТγΗΝθθψ():
    value = 200476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISq8fVAfr/9aawqRxHqhHhUL5kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иλΧρσГрΑаКПйΗШ():
    value = 657452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiL1eGIz+5otCxmi5gG9Ygcb6Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_9036 = 412
        905
        460
    return total

def _ЯζсчЗТςζъσБΙΚ():
    if 15 * 60 < 0:
        886
        pass
    value = 110893
    text = __import__('base64').b64decode('dXpYdWxZbVNnaU1jdFRrSGt5ZkU=').decode('utf-8')
    if len('') > 0:
        _dead_7021 = 566
    total = value + len(text)
    if len('') > 0:
        166
        154
    return total

def _ηмШжВРΥΚР():
    value = 499223
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fyf0ZGA25pASHgn7/lq/NXY+0Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        283
        pass
        pass
    total = value + len(text)
    return total

def _ΟθЪгГряξΧГΙπ():
    value = 735901
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICf3TXUg/KkXMBakmw+YJwE76T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣВсмΘψΠΠрφМΕ():
    value = 290812
    text = __import__('base64').b64decode('eEtFRHlNdDFPR1V6MklEZ3J2VlI=').decode('utf-8')
    total = value + len(text)
    if 75 * 31 < 0:
        500
        pass
        710
    return total

def _ЖρΠυРпΦΔΧкНЪυЮεЬ():
    value = 370082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxayVl8w9IwGOCOP51yoAgYJxzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 63 * 17 < 0:
        711
        pass
        pass
    return total

def _зΙψАбγзКΠΖЧвК():
    value = 777494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAHvXAgvzfwaF1yh/Wy5DA185UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λνλИЗйφΗΤдфЭжΞ():
    if False and True:
        960
        pass
    value = 547712
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnixRAc16a9WMluX/li0FRwBzjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4838 = 225
    total = value + len(text)
    return total

def _ψΞυлПннΗтУьгЙ():
    value = 932041
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATy1XHMT+YQXLD77/0WFGgYc3jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 55 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ИйΕθцыτЯωвхΝΡвφ():
    value = 83335
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCXgdAA60PgRKjyRkW+VYXck3WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФПДчΚЮЖΜъολг():
    value = 735232
    text = __import__('base64').b64decode('Y1BQcjZMdFhUZmtlaFNKUDFwWUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖААΑбγтдΒε():
    value = 539066
    if len('') > 0:
        543
        pass
        302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxbQVlA77LIaNV2J6gK1HDUtyVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑκΙоДМвЦмΒЖΥ():
    if False and True:
        pass
        66
    value = 926267
    text = __import__('base64').b64decode('eGl0ZUlDNXJkNkFCbk9LdldiYTI=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6991 = 190
        _dead_2864 = 581
    total = value + len(text)
    return total

def _ЛЖπНвНьйп():
    value = 763032
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECOyb0APqJ0mYh+q9wKeLCAZ3lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЪЕΕГфЧбАΞЬсл():
    value = 521717
    if len('') > 0:
        189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CATjflMe+IUXNB+76l2YZCss5WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΣвλжρφЮνξиΚχΝ():
    if False and True:
        pass
        pass
    value = 95771
    text = __import__('base64').b64decode('dXB0MWRIUkszVE9nNjhXWXpMR0U=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _πПзТЦЧэΨχИХ():
    value = 503384
    text = __import__('base64').b64decode('THdpQVJ3YW16cjFRY005YU9valc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩзςωъφΞдХХςΞиΛδ():
    value = 836229
    text = __import__('base64').b64decode('bHU0emVxMUVjS0NFbWVkQzlKTkg=').decode('utf-8')
    if 68 * 66 < 0:
        704
        270
    total = value + len(text)
    return total

def _ΕεΦπφΤΟйςεΧВ():
    if 37 * 25 < 0:
        _dead_5647 = 559
    value = 98127
    if 26 * 55 < 0:
        pass
        _dead_1209 = 900
        _dead_9132 = 448
    text = __import__('base64').b64decode('a3VXaDNYeXNlZ2dDVXI1MVVQeWI=').decode('utf-8')
    total = value + len(text)
    return total

def _θτДУфκеЧ():
    value = 503003
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhnKa1xh+acJDlrxnm6eLCgZyj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 63 * 7 < 0:
        _dead_7728 = 479
        pass
        976
    total = value + len(text)
    if 11 * 15 < 0:
        _dead_1350 = 935
        pass
        _dead_3729 = 933
    return total

def _ΣΞаΘΛΦзЯсЭю():
    value = 847570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Di7rPl0bqq5XbAChxgO6ZTE6tl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΓЫΕρХδФГ():
    value = 379372
    text = __import__('base64').b64decode('ZGduZTlUZ3JjT28waTYyUmNvN2k=').decode('utf-8')
    total = value + len(text)
    return total

def _βБКθβьΔΥΡπ():
    value = 751838
    text = __import__('base64').b64decode('SGg4WDhyOGpVeDlScElfb3NmdFY=').decode('utf-8')
    total = value + len(text)
    return total

def _РБЙΙΝЕιйуΧайΑθвΣ():
    value = 132205
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz+xa10+r5sUPi6v30e5FhUb4EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БесΠυрΝΒБΗ():
    if False and True:
        877
        pass
    value = 929390
    text = __import__('base64').b64decode('bUt1ajFZd0F2MjBGWmdPS0ROWGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛНπЧЩбСλωςμДс():
    value = 475775
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('TllNZTRrSHdWWmZLc1NaSVFYcnA=').decode('utf-8')
    total = value + len(text)
    return total

def _фΟΙяιαΤьΕп():
    value = 833152
    if 12 * 17 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB/tTHVg5r8PBRiN/UevBxcFz14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЫмχξκДπыλφΒΗФεЩ():
    value = 908854
    text = __import__('base64').b64decode('VzVhYUEwSkVDSzBMNFdKcGttM1U=').decode('utf-8')
    total = value + len(text)
    if 80 * 26 < 0:
        _dead_2906 = 369
    return total

def _ККхψλьюсψЙЩΦз():
    value = 252586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBvAQ3s/1pshPyia/2y8ZRUo1Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9536 = 441
    return total

def _ΒнэЫЬДωифδнжπдΞτ():
    value = 554331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg3sWwVty68HLQWw726qYhwDzTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рМδΜМΡПл():
    value = 585029
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQXqT11v34oTChn7+1exHgEb9kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αεЕΜΘτбΔхΔΣιεЧ():
    value = 469447
    text = __import__('base64').b64decode('V2x3empYYzZOX2VEbVRXd1BMM1E=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        948
        _dead_5555 = 194
    return total

def _ΟΩθЗрЛΞАърΠ():
    if len('') > 0:
        pass
    value = 34468
    if False and True:
        38
        421
        149
    text = __import__('base64').b64decode('azJkNjZWMmw1d0c3ajNHbGxyQU8=').decode('utf-8')
    if len('') > 0:
        894
        640
        _dead_4804 = 678
    total = value + len(text)
    return total

def _СЬΚΧΞыБρπр():
    value = 911628
    if False and True:
        99
        8
        pass
    text = __import__('base64').b64decode('ZjJJQnkzVkhBNkFJWHBoQ0Q0eFE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        228
    return total

def _λΦугζγμУ():
    value = 170460
    text = __import__('base64').b64decode('ZldPWGtrVHFTTG9QY3FvaWl6aUY=').decode('utf-8')
    total = value + len(text)
    return total

def _хθшΓτπЪъΒОПЮΗ():
    value = 160063
    if 19 * 64 < 0:
        678
        _dead_6288 = 904
        873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyHBW0cS1ak3EBms32bJBCA701w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _χμΞНΔΗбЕр():
    value = 925515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQXNPUVgroE6awiM5E7FBQos02E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еЪЩυоцИαиЕДЖ():
    if 79 * 22 < 0:
        171
        _dead_4349 = 6
        _dead_1641 = 50
    value = 206445
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjfMfnVsrbEBDBaKmlSbEQt61ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цαЫОΤωгνΣсΛ():
    value = 727603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyjgOQAN0ZhTGAH3/nmjBzI51Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3002 = 323
        pass
    return total

def _ψмκЛςоΤНφъг():
    value = 667422
    if False and True:
        _dead_8406 = 106
        _dead_9479 = 312
        41
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXb2UVgxqPg0GSaC4HiiNQ127U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 65 * 42 < 0:
        220
    return total

def _ХηΧςβЙΠЧЬφ():
    value = 203945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh3rZAcd0pErNiW14l7FYDAV3lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        839
        39
        613
    total = value + len(text)
    return total

def _пФлυΞΤДФтцрщΩ():
    value = 879588
    text = __import__('base64').b64decode('T09PcW9keF82RkdlaU5Tajd6Yzc=').decode('utf-8')
    total = value + len(text)
    if 12 * 62 < 0:
        _dead_4328 = 355
        pass
    return total

def _ВИΖρΥЭьΗΓψбτΒЪиΓ():
    value = 121805
    text = __import__('base64').b64decode('Y1Z3eU9Qd3lpaEk3UENBaTdDX1o=').decode('utf-8')
    total = value + len(text)
    return total

def _цяΦπИρЪжΝЩ():
    value = 347213
    text = __import__('base64').b64decode('a2tPZXdBWDFJTXNnRGdLMUpfNnE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        535
        pass
    return total

def _ΜБФЕпмψΤΘ():
    value = 577299
    text = __import__('base64').b64decode('SjRaVFVDVWNMNGdMMEMzck9MeFo=').decode('utf-8')
    if 52 * 15 < 0:
        974
    total = value + len(text)
    return total

def _ΧθьЗηвТМΞ():
    value = 45309
    if False and True:
        _dead_4650 = 955
        _dead_7025 = 410
        466
    text = __import__('base64').b64decode('dF9oaWFmeXFlb3hZb09LdXI3Sm4=').decode('utf-8')
    if False and True:
        pass
        _dead_1529 = 995
        _dead_7845 = 111
    total = value + len(text)
    return total

def _кΜΕΠΚЛθжυьγΗЗ():
    value = 372605
    text = __import__('base64').b64decode('SWhFRmVKYnJqUWd5S0ZJSTFWV0c=').decode('utf-8')
    total = value + len(text)
    if False and True:
        657
    return total

def _ΖаμΘЯДННБК():
    if 65 * 37 < 0:
        pass
    value = 898127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAHjQUge/K0HAF6imW7IPHA7x00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мъφΠшАкм():
    value = 568031
    text = __import__('base64').b64decode('TVpGaW5jbnNvRE1SODFjZ3IxZXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ВжΒхоΝΧаЫфОБ():
    value = 75912
    text = __import__('base64').b64decode('Slc1aTgxcjcwVENuS0kzM3pGNDU=').decode('utf-8')
    total = value + len(text)
    return total

def _ыгЮмЧθπеΩζΤЗσ():
    if False and True:
        pass
    value = 443257
    if False and True:
        414
        pass
        430
    text = __import__('base64').b64decode('azBmZWlpc0RiTUh2ZWdtX1FhR3I=').decode('utf-8')
    total = value + len(text)
    return total

def _КΑΚΒМΛζяΘХсрм():
    if len('') > 0:
        pass
        pass
        954
    value = 231595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSzlTVUQyJc8byn10FWjNScNxz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 97 * 4 < 0:
        _dead_1077 = 202
    total = value + len(text)
    return total

def _αАΑЩоуСЖьΟΤ():
    value = 618672
    text = __import__('base64').b64decode('RjhGQWljTllpSGt5ZFZaUVJ0Rmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΞнΗΓцφθТνΠЧЖΖ():
    value = 831241
    text = __import__('base64').b64decode('WmF1QkxZQ0pOZGp2QklKQzFvWnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗчйΧЧΓгνΡЯЙΓΡΙ():
    value = 703605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRa1N2442LASFCD34HvAGw0evTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψйΥгαΒρлΒΥьοξмзΩ():
    value = 606630
    if len('') > 0:
        173
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXbqXQlgq44mHSKz6Uy5FXYD6no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        734
        _dead_7007 = 905
        pass
    total = value + len(text)
    return total

def _ПοНщПИшοВрД():
    value = 530044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSyxRHcS5qEILhiImE6gHikZwF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чМΥнКθΔΧЦκηОν():
    value = 367795
    text = __import__('base64').b64decode('eGZQcWlwTWhsRUxtYlVKU3B5Z2M=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        804
        pass
        _dead_6669 = 24
    return total

def _орИΙξЪβэЕμ():
    if 98 * 79 < 0:
        pass
    value = 608268
    text = __import__('base64').b64decode('ZVM4ZW1lXzJFejY3QklycEFxX0E=').decode('utf-8')
    if 47 * 15 < 0:
        _dead_7022 = 685
    total = value + len(text)
    return total

def _ρкеьНαоиζъА():
    value = 606563
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hxy3VAcP7aw2GyW25GHDJysl9kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖНτЭьЮШБнэц():
    value = 152491
    text = __import__('base64').b64decode('dEV5eVFJRG0xRFZEcDg0UElHYm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ζζηбпйпΛη():
    value = 497603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N36wfggI3PAOMiuIn2+jEwkk/EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧττчξΩеΘΠЛ():
    value = 507525
    if False and True:
        _dead_5621 = 260
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTvWZlo6q5hSIwiznASqDTYsz2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΖΥЯΖАаПюУИВИΔ():
    if False and True:
        _dead_5787 = 179
        _dead_6040 = 280
        427
    value = 422273
    text = __import__('base64').b64decode('Z1I1TVhBVTY1QnZpZ2V4MGdaXzI=').decode('utf-8')
    if 14 * 33 < 0:
        426
        _dead_3992 = 232
        _dead_4967 = 573
    total = value + len(text)
    return total

def _ΤΠЬσηЗЦлУαε():
    value = 548540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnrMWUgD/JwRFzyh4WKIbRQm0jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПδπΨχТεяЕяιψЖ():
    value = 284661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERrCY0EWzKUALzq58HikBjYOxUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζЖΜεаξХПаξКΟюΗΜщ():
    value = 86696
    text = __import__('base64').b64decode('Vk8zMHJRZXBnaDJDeHdNVnRKR1A=').decode('utf-8')
    total = value + len(text)
    return total

def _χЙυЗФТюь():
    value = 594202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3fgOFcI8a8bNCGPz1ScCyIL70g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒсбωΡлΙωЪждψХ():
    value = 251977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH/MY1kgqpI2MFqKyWPGPTwO4UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πχКвИЫтιсψωОцΥХΙ():
    value = 607646
    text = __import__('base64').b64decode('V2Z3aERfdzhYU1lnWUZjeGxEb0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _УчΖдЪЪюφ():
    value = 221672
    text = __import__('base64').b64decode('RUhfdTk3SDV6c2ZUQzRSQVQ3d0g=').decode('utf-8')
    total = value + len(text)
    return total

def _йжλюаΓЭЗφ():
    value = 165532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyrvZVNo6IAnalyKx0egAgQ18Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        236
    total = value + len(text)
    return total

def _ζиΡНΜφγσтΟ():
    value = 668260
    text = __import__('base64').b64decode('ckk0SkhZQ3RqRkdWSEFxWHdXaXI=').decode('utf-8')
    total = value + len(text)
    return total

def _φГйΛшъΒНΣиΟцЯ():
    value = 178187
    text = __import__('base64').b64decode('SU9SRFdUUlVOMkNMM1ZJVlJuaWU=').decode('utf-8')
    total = value + len(text)
    return total

def _αΕαςчШριιцΞ():
    value = 579618
    text = __import__('base64').b64decode('ZEdwZHBiZE8xZ0czVmpqMUJOYV8=').decode('utf-8')
    total = value + len(text)
    return total

def _εΔςΟЭяяОΑЙΖνΟчΞ():
    value = 333501
    text = __import__('base64').b64decode('bUFuZVVCRDJ3cnB6cVROTng5Y2c=').decode('utf-8')
    total = value + len(text)
    return total

def _οШτΤΔЯΘй():
    if len('') > 0:
        pass
        pass
    value = 488948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISfoZGU6y4wlbhWm5g63DjMHzz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬнΖζКоΓТЙηδν():
    value = 197219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBfNWwkD74IrEAKSmXmaBQAE3Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пςκзЗκΩПЯъΤрοйюΚ():
    value = 992933
    if False and True:
        683
        262
    text = __import__('base64').b64decode('elZrTzExTE9SaHJNNUx4dE5VVVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ФσЛмтπУмУБπ():
    value = 257770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwixPEQ67YIqLQGN/Gm3Fx8G1mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΦЬдεСШБβΕЭЦ():
    value = 154056
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HX/pQHUx5psRF1qA3FGRJXAe510='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГФΙЖвЛЯςИσςωμРεη():
    value = 793413
    text = __import__('base64').b64decode('UWxDUFBqd3RIdUltWVJtbVk0ZEs=').decode('utf-8')
    total = value + len(text)
    return total

def _йςяПъшΖΡ():
    value = 510945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECHMegdtxJ0Sa16ymFe5LXx+6X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΛЮФαΦβтЪςхςЕ():
    if False and True:
        685
    value = 111044
    if len('') > 0:
        pass
        771
    text = __import__('base64').b64decode('RFF6QTdtaWEyaWlaWVBOMTdLNFI=').decode('utf-8')
    if False and True:
        979
        263
    total = value + len(text)
    return total

def _ЛМщΣЖИфФ():
    value = 881044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxXSOFMM6KokChW2/H2WJBx/t3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΣЕПбКЖМσ():
    value = 347466
    if len('') > 0:
        pass
        _dead_8659 = 709
        _dead_2258 = 48
    text = __import__('base64').b64decode('Rk1GdWgxXzV6SmdKeld4TFhYbnA=').decode('utf-8')
    if 59 * 93 < 0:
        609
        626
    total = value + len(text)
    if False and True:
        541
    return total

def _эыДκΙТрЫΑСΘ():
    value = 539041
    text = __import__('base64').b64decode('aDBxVjRaQXkzZ0g2bkZ4cHg0YVI=').decode('utf-8')
    total = value + len(text)
    return total

def _СεζаУТΦνλб():
    value = 170786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCrpUXBp//hXAjymzH+AbHwCwz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κηинΨΧΦЛΠΥΝααПΥ():
    value = 660653
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('RHFmSGM0RThUSjA4aWhxY2JLQkE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        808
        pass
    return total

def _чПμζιБъВΤаАτηю():
    value = 732498
    text = __import__('base64').b64decode('RWhFWEkxZGY4SVN0M3NXb1kweDY=').decode('utf-8')
    total = value + len(text)
    return total

def _цЮЭСЫЛρДВЭРтΔЯ():
    value = 836092
    text = __import__('base64').b64decode('ZUpybUlIY1hVQWNuOFVuYTBSdXM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3747 = 912
    return total

def _ЪыЧКИΩθμ():
    value = 919596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn7uSEQD2LkhMTiU6VeEFisCxkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΡνОΦЯψыюΚЗκЬ():
    if False and True:
        _dead_6158 = 113
        _dead_6633 = 97
    value = 491155
    text = __import__('base64').b64decode('SWFacjY0THhvek9EcUpHc2Q5OEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦЪЦλθкКшЖΑ():
    value = 76963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiH1fgQx2rA2AlqPkFnAECx/xXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λФΨТκγιβлМеЯΟ():
    value = 377085
    text = __import__('base64').b64decode('SE5fcXFVcmdwVkpSN3N4WU8zUnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΕςЪλйζоΗνЖШщρйР():
    value = 67761
    text = __import__('base64').b64decode('RUFwUFBobGhuVWFwdTZ1cXg4NTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗФΗтПйτыρзΕь():
    value = 202662
    text = __import__('base64').b64decode('QWhzRktJZDN2d0xraVRKMFNKV0w=').decode('utf-8')
    total = value + len(text)
    return total

def _μσδЧвРВЗΛΦьξ():
    value = 529529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx7ObHMy36wGMCuB8E7HJyAJ4Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κυθΟηКΥчοр():
    value = 450718
    if False and True:
        pass
        705
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aw3HTVQOpqkZMlyt+leZIig642g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝзθыуъЕсчπЭУδ():
    value = 16483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HATPaHxo/5AINT+1y0bAAnAOtz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШσцГЮΟδЩ():
    value = 318640
    text = __import__('base64').b64decode('WnpyX1lIa204Y2ZtU0JVQlpaUEI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _РΟοΩυГЧфЦ():
    value = 67745
    text = __import__('base64').b64decode('Q0dNaHd4SnZneGhNQWpPcm1uZTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩКейбфσГΥΣχлΕΩ():
    value = 66557
    if 46 * 28 < 0:
        _dead_4955 = 633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj3+OmIo5JsoLgCF5WmaYTZ2ykE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚчψитуΕВбωЯЪΨпιр():
    if len('') > 0:
        449
    value = 324360
    text = __import__('base64').b64decode('RUdLR1RibDlucWhOeUtRa3BuNWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΛцνΞμЖх():
    if len('') > 0:
        _dead_8482 = 753
        157
    value = 191082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACT2eQIV65k7FCGJ/AelMid3s1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шГеαπμφПбюжςзφν():
    value = 780729
    if 54 * 9 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CT+0PXo39YUZAg6v+wTCMSY6vG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΣЦΞиτΛрςХсз():
    value = 216138
    text = __import__('base64').b64decode('R18yM2lTUjloOF9JeEt5YVBlelg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙιрХУБынΒЫΚ():
    if len('') > 0:
        _dead_3734 = 427
        pass
    value = 94792
    text = __import__('base64').b64decode('UTlDcVUyWEdZYmJ0SnFUNExjelA=').decode('utf-8')
    if False and True:
        158
        _dead_2837 = 479
    total = value + len(text)
    return total

def _σηφρзεюИ():
    value = 488232
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR3rPXAx3ZwZETr06nWTGRUt6zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        354
    return total

def _ьρθщПΚπΖцΧУРΚя():
    value = 128765
    text = __import__('base64').b64decode('b1pHUzl5VzdLWHk5MFBWSnd4dlY=').decode('utf-8')
    if False and True:
        532
    total = value + len(text)
    return total

def _ΨгщηγъαюЛμэ():
    value = 129228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHbzZlZo7awWawmH5H6bGy8qy2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛКΖэВΚГΨФ():
    value = 864576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB7GekA087pQbVz35VyaECID1Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 51 < 0:
        _dead_8627 = 131
    total = value + len(text)
    return total

def _ΝΥπыοХтλσИТ():
    if len('') > 0:
        274
    value = 594282
    if False and True:
        106
    text = __import__('base64').b64decode('RFd4WGZ0NlVxRjR1c0NGOHE5MDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ШωЙТмΗСок():
    value = 59147
    if False and True:
        _dead_5140 = 564
        193
        _dead_4468 = 482
    text = __import__('base64').b64decode('dHU4dzNkU2hkSjQ0bHo3eWNpZ3c=').decode('utf-8')
    total = value + len(text)
    if 55 * 83 < 0:
        _dead_9097 = 75
        _dead_4263 = 368
    return total

def _ΨКψΒэСчПλγИ():
    if 88 * 61 < 0:
        pass
    value = 510522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCHGSmA0zbAuFAKbzUGSOT0XvDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        816
        pass
        pass
    total = value + len(text)
    if 41 * 79 < 0:
        892
        739
        pass
    return total

def _ιйγЪτГΘя():
    value = 397696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bgm8YXk35LtQaB6I8VC4JQEu4jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΗвУΧйИεгφ():
    if 40 * 93 < 0:
        18
    value = 622481
    text = __import__('base64').b64decode('Ung0VTlKTUY3X2gwUzB5WURKN2g=').decode('utf-8')
    total = value + len(text)
    return total

def _гРζдΟТэυТмюгμιν():
    value = 305427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCr9SXMP1P0SbAKb4USgJgkutz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σςΕЙэйБЮГьБаЯЛ():
    value = 911724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzW9SwYL3/8HHiSHyQ6jEgQH6EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖоοζбеЦчшфшσсЬжσ():
    value = 967086
    if False and True:
        _dead_4151 = 318
        pass
        710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CizJTHYYr6sILze6mnSWPDUL4Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8134 = 913
        pass
    return total

def _ΡεενаюЫщчηψθА():
    if 93 * 43 < 0:
        390
        pass
    value = 171896
    if 67 * 49 < 0:
        _dead_1008 = 281
        471
    text = __import__('base64').b64decode('R3F6TUluZk5MYnFPNlNBbTB3cUE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4047 = 455
    return total

def _ЬщσωфЙдиМΨкфκт():
    value = 823216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDzbdAMt0YUrPV6RzV2yZQoQyFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЪυПчТξΦ():
    value = 780269
    text = __import__('base64').b64decode('bnRCRldvVElRYUp4X2pTSlVhOHY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9947 = 699
    return total

def _эιξσΖΚфЩюΜωЛРзΓе():
    value = 381269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3r9bGYj0K4nLSCF7gadBDQk5n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΖГщθΥунНеФя():
    value = 6398
    text = __import__('base64').b64decode('bVNkWDVheXlzaXFXQVBtWVNqRDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΞΡуζАНХхщэ():
    value = 626412
    text = __import__('base64').b64decode('cDNoMmN0VHNFeEhNNXluZ2Qzazc=').decode('utf-8')
    total = value + len(text)
    return total

def _чАФдκπОψ():
    value = 947388
    text = __import__('base64').b64decode('VnNldE44dzRJOWpWclByMUx1RHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧдΗХΦΝΓΙ():
    value = 644537
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgyyRQU9rLozDDCFn32YMSsAwWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        270
    return total

def _ΒЛЯоκβφζζψξβΗ():
    value = 345102
    if len('') > 0:
        pass
        837
        _dead_9920 = 128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axy0Y1My9r9SNyCK/0CcbQ07xkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΝωΔΕйнЙОΠРΥΟιΡ():
    if 39 * 70 < 0:
        pass
    value = 584329
    if False and True:
        597
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jhr3amU+9PsBLTaq4A7DHxEgxn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_3242 = 409
        740
    total = value + len(text)
    return total

def _κΡβщМΦГФб():
    value = 561951
    text = __import__('base64').b64decode('Z05mRjIzMEVCTEdFYVZTSDFKU2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЗВγΟчющш():
    value = 36543
    if False and True:
        pass
    text = __import__('base64').b64decode('akhvREcySVZfamhWa1RqVFFINTQ=').decode('utf-8')
    if 56 * 77 < 0:
        pass
    total = value + len(text)
    return total

def _рзφΖΣΑωФжψΓУМвЖА():
    if False and True:
        pass
        pass
        _dead_1059 = 192
    value = 437712
    if 8 * 56 < 0:
        pass
        pass
        _dead_6410 = 969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByLTP3ww6/w7IA720VqjEB0Ds0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _АЮКНΧΝлЪ():
    if len('') > 0:
        pass
        _dead_1610 = 744
    value = 560765
    if 69 * 99 < 0:
        357
    text = __import__('base64').b64decode('dldhbElWUm5nZUo3bHdpWmltekU=').decode('utf-8')
    if False and True:
        594
    total = value + len(text)
    return total

def _ДйНΒυΩΙпэη():
    value = 497196
    text = __import__('base64').b64decode('V3FxaFJ0eElGajdIN1kxSlU5MVc=').decode('utf-8')
    total = value + len(text)
    return total

def _НГσрчξτЖΖ():
    value = 879731
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCe1e0QR6LAlECitzwCbBnc+9T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 96 < 0:
        _dead_3218 = 873
    total = value + len(text)
    return total

def _хβΑИжэфдΦΚψ():
    if len('') > 0:
        pass
        _dead_2085 = 886
    value = 239738
    text = __import__('base64').b64decode('Y1hzblZtcGdCN2gxNXJqblJyMmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ТаμдфЦпГ():
    if False and True:
        291
        627
    value = 495302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChfxSVcfy4VTYlaO+3KHByJ+xzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖμтсБрНδ():
    value = 370258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCz8bwgP1L1VLjac6VioOCguwT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _КщΞΡОσΡс():
    value = 998879
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRn0WkY79aMzbg6Rn36pBxB5yFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓЯБψμΗМψΙΣΚΧοПΥφ():
    value = 74777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQT0OnIT7awPEAm753LIZiF6t1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΧυΟвшпидЫνУщψγΦ():
    value = 7582
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('b0tOaG1fb3VKbFRIZDZUUVVQaUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓξφΙЖΘЯΣРυФд():
    value = 260527
    if False and True:
        _dead_6271 = 299
    text = __import__('base64').b64decode('V2VNWjlSRDRWUHBBY1RzVlRrRzQ=').decode('utf-8')
    if 4 * 29 < 0:
        pass
        _dead_8701 = 387
    total = value + len(text)
    return total

def _ЕΓΛЯψпаЕКγ():
    value = 677656
    text = __import__('base64').b64decode('RDlsbUhMZ1dfdkRyOVJkWVFCVlE=').decode('utf-8')
    total = value + len(text)
    return total

def _щЭрσПсαОωВтΘ():
    value = 274389
    text = __import__('base64').b64decode('djNzdmwzUGkxYllCbFh4bVMzb0o=').decode('utf-8')
    total = value + len(text)
    return total

def _δυшενеΧαо():
    if 62 * 4 < 0:
        pass
        118
        _dead_4922 = 92
    value = 767337
    text = __import__('base64').b64decode('Z3k1QklJRTl6MTM5QmNJNzlfcWg=').decode('utf-8')
    if 42 * 9 < 0:
        pass
    total = value + len(text)
    return total

def _ΧρЙДжоЖξΠЧΝуκλΛ():
    if 9 * 70 < 0:
        459
        516
        _dead_8931 = 253
    value = 357546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDjqaUMj174Xal6r8FiTbB0+8Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эюЗΤΜοΠНφХγю():
    if len('') > 0:
        pass
        457
        pass
    value = 736826
    text = __import__('base64').b64decode('TW5GeE83aUxNMDBDMVZWYlAyVmo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _еΜБτΙΑэПГДψ():
    value = 154538
    text = __import__('base64').b64decode('eGpBZXpic1laeEVYS21wVk1rNUc=').decode('utf-8')
    if 20 * 60 < 0:
        893
        998
    total = value + len(text)
    if 82 * 7 < 0:
        18
        pass
    return total

def _ХΗρеЪевΣΙνлΦСтАδ():
    value = 198566
    text = __import__('base64').b64decode('VGg5c3luaUROb0tMX2hVeWJiSjQ=').decode('utf-8')
    if False and True:
        pass
        174
        _dead_4650 = 777
    total = value + len(text)
    if False and True:
        _dead_4388 = 738
        669
        pass
    return total

def _ΒΡФнΡαБΨΔΓчκтπ():
    value = 594632
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3bUXXAg2IQtawqKmwabJQp4zmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        234
        pass
        592
    total = value + len(text)
    return total

def _ητйΩЦАъЙтТЕΣπξ():
    value = 217435
    text = __import__('base64').b64decode('WmF1MmV2Wm5iMTdUUl9IX1V0Y1U=').decode('utf-8')
    total = value + len(text)
    return total

def _φσШшφХκаъЕ():
    value = 366064
    text = __import__('base64').b64decode('U1V6dmlLMmRaVHVvdzBzVGlvVlI=').decode('utf-8')
    if len('') > 0:
        554
        _dead_3427 = 45
        _dead_2925 = 454
    total = value + len(text)
    return total

def _τуыγоδсциеψωТУΟэ():
    value = 566966
    text = __import__('base64').b64decode('Q3Jua1ZRYTloS0RBcHNOUGRteUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΟεшΠαςΨπ():
    value = 343378
    text = __import__('base64').b64decode('TzB2RG55QXdPV1J1QVZmSXRuTTA=').decode('utf-8')
    total = value + len(text)
    if 77 * 58 < 0:
        _dead_7104 = 212
        684
        357
    return total

def _μъОэοЭΙоθζΧщθынψ():
    value = 483216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATjeT0sSqI8OCCvy7l+gPj83zkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6664 = 409
    total = value + len(text)
    return total

def _ЬΑΗКрξζНБηъхΑχ():
    value = 330750
    if 43 * 34 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3rzWwcT5LIXYyGM6nuWCyIo/Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        541
        _dead_3362 = 685
        _dead_8952 = 219
    total = value + len(text)
    return total

def _аΔςжЬαδΦΝсР():
    value = 514233
    text = __import__('base64').b64decode('aHYzWkFiVXhkeE9qX2xxenN5UzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝκТσШФпν():
    value = 628705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgDSd3QX7PwONVu5x2OlFnAM7Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЙьδΠсΧи():
    value = 227032
    if 43 * 79 < 0:
        86
        994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FynWengO24wmCAS5wg6RBxF9/Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        382
        _dead_7908 = 982
        _dead_2168 = 132
    return total

def _ΝЫΠςюйЭαЖзφЧδΔ():
    value = 232275
    text = __import__('base64').b64decode('dGVUa3lyYTd0RER5bHU2Qm9LaDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛЖШΝмтΚεх():
    value = 144544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAnsV38fqYogAjeH92PHbHwI4Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΛοкΠфМГшАПΟιЗй():
    value = 896005
    text = __import__('base64').b64decode('VWN1M1VjaHRDam5Ud3h6RVA1OUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭаАшΡеэΞпС():
    value = 439871
    text = __import__('base64').b64decode('WENEVUxBYlMzeEVNY1dRZExGMEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΓнψΗСфРΟ():
    value = 152765
    text = __import__('base64').b64decode('RUQ5MnNDNXRuWFVYTU5ZaHEyb2I=').decode('utf-8')
    total = value + len(text)
    return total

def _еуΩаЯαИφу():
    value = 525606
    text = __import__('base64').b64decode('bDBXaDVQQU9tdWZhaVFXaWxiaDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ШзмОΩξΤщΜΚ():
    value = 718622
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS7LW2kg37hUCi2x31i/GD0/0ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3802 = 820
        _dead_8591 = 756
    total = value + len(text)
    return total

def _щκΙεΨфчЪφθΤШвВЮ():
    if len('') > 0:
        494
        101
    value = 264563
    if len('') > 0:
        _dead_2648 = 271
    text = __import__('base64').b64decode('ZDJTZjA2akZ6cUJnZnRyZU1LMTU=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_6849 = 52
    total = value + len(text)
    return total

def _γΣυтаХρκХя():
    value = 200704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NST1aWY83LoFawOm62+HGHMK9Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рβтяλлςΟκТΧГещ():
    if False and True:
        _dead_6948 = 567
        _dead_2289 = 978
    value = 554743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCPJf3QB1vsFAwm2wWCnHBEawlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔфЛяΜΟυЭθΗКψ():
    value = 880574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQziaWsdx7sTLguWwXuGLjMHz0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оеΘчхЧкΛПΦψыЕΣ():
    value = 526040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnzTd1cB6rArIzqt+k7HBHwE81s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηЙΛЙфζыЧ():
    value = 856680
    if False and True:
        _dead_1228 = 23
        _dead_5158 = 708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR68b3kU7LEGHiqz30CXPhY9vD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖкфххЬПυκвфТΦ():
    value = 805892
    text = __import__('base64').b64decode('bWpxUnBOZldPY0l1aFBmdXhDc0E=').decode('utf-8')
    total = value + len(text)
    return total

def _юΔкТξлШε():
    value = 88095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh3wemsR7q0AOVz0x2WbBDwN3T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΙЬуψЩаεЯВЩΝаΜе():
    value = 456915
    if 70 * 76 < 0:
        pass
    text = __import__('base64').b64decode('a1NFa0hMRl9nZEJkclZSRnNjVlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ьуОУκτКЖ():
    value = 520115
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXu3WHQAx60JMTql/VWdFyl+8Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 12 * 35 < 0:
        pass
        791
        767
    return total

def _сюθИΔПкπΧΦσΣВΝχΜ():
    value = 946244
    text = __import__('base64').b64decode('Sm1RV0RoRVpKYkdRRGU5UDJDZlk=').decode('utf-8')
    if 36 * 73 < 0:
        pass
        pass
        _dead_3519 = 324
    total = value + len(text)
    return total

def _ΑЩφθжΤХιΙφ():
    if 22 * 32 < 0:
        _dead_1388 = 337
        _dead_6771 = 372
    value = 989667
    text = __import__('base64').b64decode('cGkxNFp4SXNUdlhQb2J2S0pYVVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΙЮБΨΣшЪχΞх():
    value = 323476
    if 71 * 36 < 0:
        pass
    text = __import__('base64').b64decode('c043TlJWRFdIMDhUeExkZzRKOVk=').decode('utf-8')
    total = value + len(text)
    return total

def _υωызКпτΛзГ():
    value = 976500
    text = __import__('base64').b64decode('VWUwTjdRdk5KTU96NzhhcWV5V2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔБьΛцκαфюиΡ():
    value = 287147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTvhXXQQzIYGOBq55nCZMAElvDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6683 = 866
        516
        220
    total = value + len(text)
    if len('') > 0:
        _dead_9114 = 683
        _dead_9557 = 943
    return total

def _дрσΧЯЦЦЖφЧЬЩчχη():
    value = 240790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LD3MPGU02fwZPyu0kQ+2FTU58GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αςЮΞдЛпйФуЗъ():
    value = 396259
    if 55 * 71 < 0:
        pass
    text = __import__('base64').b64decode('c01EUWV3Wk1qRzRVVDdyb0dsOGE=').decode('utf-8')
    total = value + len(text)
    return total

def _бΡСбэдЪεδЫлςс():
    value = 640505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jx2wPXUY9/EQIBaL+EyUJDQcyGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωποцβКСΣΝ():
    value = 313746
    text = __import__('base64').b64decode('a1lyU09wVFJiZmF3OGUyOEt3WUg=').decode('utf-8')
    if 66 * 33 < 0:
        pass
        _dead_9443 = 611
        pass
    total = value + len(text)
    return total

def _яЦχДДΥπШДΥιчη():
    value = 231888
    text = __import__('base64').b64decode('VUNaOEROdUQzQWVadVVtVGY1Z1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΝςцфПЩСσЧΤьЖ():
    value = 414128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LS3geXsh/YJUBSm1m3vABAMr5Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЖЮδхпγΒΨ():
    value = 825989
    text = __import__('base64').b64decode('ZEEwZElrNmxhYkJGZkdBWTdhWmI=').decode('utf-8')
    total = value + len(text)
    if 2 * 85 < 0:
        _dead_1304 = 97
        219
    return total

def _ЦККыΓΖтеΝшΛцц():
    value = 831469
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDrSXnsJ0v0hHB2K2lOhHHUC43Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΖΠπжσθΙΞΖΟмРΕ():
    if 79 * 11 < 0:
        pass
        453
        pass
    value = 331388
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBzPXmJs16k5Ii6NwHuJFRoC82k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 52 < 0:
        pass
    total = value + len(text)
    return total

def _υξИαΘАΙвЕτυДмш():
    value = 432197
    text = __import__('base64').b64decode('a0pSWEZWWlUyZHNfT3U4RUlGSkc=').decode('utf-8')
    total = value + len(text)
    return total

def _уγКΝЬЮοмξЯцυж():
    value = 119694
    text = __import__('base64').b64decode('Q0ZBWFljVWJLWXZIMTZuYkFhZkc=').decode('utf-8')
    total = value + len(text)
    return total

def _иηΩнлнυςΦ():
    value = 557252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwXzVAELzYtRGAP34GSoGXYH00Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БкТпФτьБО():
    value = 973081
    if False and True:
        pass
        _dead_2610 = 961
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDfKX1AD0adSbVfwz2KqBil/9mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        459
        971
    return total

def _хζδМθнхБЯθυЕ():
    value = 95056
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kzb9WQUq1roNbgG17m+TPAQcyUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΩξюΗΛαЫΝΡΩ():
    if False and True:
        _dead_5448 = 573
    value = 584112
    text = __import__('base64').b64decode('VjJWbHNqbDM1OVlUT0dsbGhNYWM=').decode('utf-8')
    if 86 * 52 < 0:
        _dead_4562 = 970
        397
        980
    total = value + len(text)
    return total

def _ψюОβΕгΒεΣζшлЛ():
    value = 139537
    text = __import__('base64').b64decode('V0pRcjV3VHlaTUtidlBpS0cyeHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕкΥωаРμρεЮξ():
    value = 757199
    if False and True:
        pass
        120
        _dead_9279 = 297
    text = __import__('base64').b64decode('ejlFV0JIVzFJb3lob2pmNFFaRVM=').decode('utf-8')
    total = value + len(text)
    if 58 * 85 < 0:
        pass
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZA==').decode('utf-8'))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()