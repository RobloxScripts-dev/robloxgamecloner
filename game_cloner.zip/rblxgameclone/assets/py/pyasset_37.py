#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΩСНΟчЦчΙэ():
    if False and True:
        _dead_9491 = 34
        _dead_5917 = 803
        _dead_8466 = 894
    value = 823119
    if len('') > 0:
        998
        _dead_8794 = 296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSfrYXZg1rslYjav6UeHLjN2yH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 55 < 0:
        663
    total = value + len(text)
    return total

def _αЛψклΥЭδисτХрμб():
    value = 659131
    if 45 * 33 < 0:
        pass
        71
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PC3yb2AY+5A0EiaNn0eCYyk40Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еχлοφκΠΩЮγзΩУνчξ():
    value = 377156
    text = __import__('base64').b64decode('Z3dUNklDT2lpRHQ2YTJOY1RxSVY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _СщμшыθνЬτЯΟ():
    value = 499210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS60Vncpz7wXFwmV7GS0EDwLxTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΣсππфзВх():
    value = 59838
    text = __import__('base64').b64decode('Y3FzV3UxWkg5dzhpY2Z1Zkh4MFE=').decode('utf-8')
    total = value + len(text)
    return total

def _шφЩВοΕлφЮЧД():
    value = 51432
    text = __import__('base64').b64decode('ZnFTd0JrR3pGZFRPZzhVSEQxWUY=').decode('utf-8')
    total = value + len(text)
    if 5 * 98 < 0:
        pass
        590
        _dead_1346 = 975
    return total

def _ШоБоμФΝБшξΤымЬК():
    if 14 * 99 < 0:
        707
    value = 157108
    text = __import__('base64').b64decode('a0lZWmJxd3hSYkh0Nm1XN1lVOWE=').decode('utf-8')
    if 10 * 38 < 0:
        pass
    total = value + len(text)
    return total

def _ΩηωμαПЭйЬгΔδχαЯН():
    value = 309213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDy3b3Mw+bE5Nwb6wkC7A3AY9WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4897 = 647
    total = value + len(text)
    return total

def _оεΙЦДωρжπРЮ():
    value = 590068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTfFQGgK9a0FHD2Rnk+3FXYG1nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞпГΙΥОЙςφΛΕЩКΓ():
    value = 665384
    text = __import__('base64').b64decode('S1RRRjRHclFHeUltUGp2S2JHZXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ИХτΗзУЭυ():
    value = 575602
    text = __import__('base64').b64decode('dm9xdDhDT253WjBQdTlraUZRWmY=').decode('utf-8')
    total = value + len(text)
    return total

def _щаΒЗιМИсйф():
    value = 777524
    text = __import__('base64').b64decode('T3JNaVVFcWZGZldfNVN2bVhSTU8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        47
        _dead_4066 = 716
        pass
    return total

def _НЪбΒκπНЙтй():
    value = 861032
    text = __import__('base64').b64decode('V1lwemV0cFBXcERfZGZMZ29LMkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤфλяжЕЪг():
    if len('') > 0:
        261
    value = 904423
    if len('') > 0:
        pass
        _dead_7630 = 628
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzfxOmg30odTESWz3WeXHw8l/GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠξΞυπξκΞоΗЦωв():
    if len('') > 0:
        473
    value = 106190
    if False and True:
        _dead_9928 = 674
        pass
        _dead_5782 = 220
    text = __import__('base64').b64decode('ellBeVhtNTR3ZXhDQmNrQ3Z0ZFM=').decode('utf-8')
    total = value + len(text)
    return total

def _оζΒзΨПОκΖюИ():
    value = 96110
    text = __import__('base64').b64decode('bkNOY3RKb0VsVnVGdE9sQkZhM2E=').decode('utf-8')
    total = value + len(text)
    return total

def _льзРроιЬΘχцχЕУу():
    value = 682016
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSe1QwBv2qY0ahyx/nOyATw/0ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 48 * 54 < 0:
        pass
        211
    return total

def _ОРΒюФдΨШπФδЬвδЬ():
    value = 337966
    text = __import__('base64').b64decode('dmJFSjFtR1d6NTZ5eTF0U0t6Mlc=').decode('utf-8')
    if 100 * 19 < 0:
        pass
    total = value + len(text)
    return total

def _χщШβфЩеΗбИМ():
    value = 260999
    if 67 * 55 < 0:
        pass
        545
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HA7ySgc+1owCGRqt6l6KIxUt03Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        762
    total = value + len(text)
    return total

def _εЮсωЫΟщьΦВРсξ():
    if 100 * 73 < 0:
        pass
    value = 216705
    text = __import__('base64').b64decode('Z21UUGNieXBpU3U0WG92SmdEZTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥЖΖтфаХηЦлпςПгДΚ():
    value = 800453
    if len('') > 0:
        _dead_6415 = 77
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITrJVwM4+a4XMx6xkVvGLSsKsVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        396
        _dead_2170 = 228
        227
    return total

def _ужЯЪКЯЛφ():
    value = 980281
    text = __import__('base64').b64decode('dllaT3BiZ1F6UlZ0bGhKUVNxVlI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒкπЛΦΑЫπνЫ():
    value = 622352
    text = __import__('base64').b64decode('azZUcHdSMGE1Y29Ka1pBTmJCZng=').decode('utf-8')
    total = value + len(text)
    return total

def _нЪНφΣэςι():
    value = 114461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JynuRVU6074tDxqn0nWZGgEc6z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βνκЪΝΤФХ():
    value = 795320
    text = __import__('base64').b64decode('bjQzTkZqVXVXZzhaWDZLZmdDVzU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1094 = 892
    return total

def _уΓрУЪжθпОσΓπзε():
    value = 946246
    if False and True:
        pass
    text = __import__('base64').b64decode('VllRQzJLYUpiQ1dhMGxHS3d2TUs=').decode('utf-8')
    if len('') > 0:
        pass
        144
        113
    total = value + len(text)
    return total

def _щΚЗΒгЭωуιηυчζ():
    value = 129794
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3u2ZgYwrZAoAgGF70aDLQ4V/Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хВшкκъуΩρН():
    if False and True:
        pass
    value = 827028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LznQR0kUrI0QHirz5nejOw4fsnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НЧΛийМΩП():
    if len('') > 0:
        730
        390
    value = 438796
    text = __import__('base64').b64decode('Qkt1anpNXzZlR0Q3em5mZWlJVHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ИЗОΩийЗΔ():
    if False and True:
        _dead_2101 = 327
        pass
    value = 826716
    if False and True:
        pass
        _dead_8812 = 477
        pass
    text = __import__('base64').b64decode('aW1OSHJ4TUdvMFkzeXdWSjBlbzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ηοцеУхΣБМοДГςы():
    value = 217141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwHuYwco/5I3Dimkmn6zZwt97D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘΙбκжχςя():
    value = 260834
    text = __import__('base64').b64decode('Y0piN2ljS0N2SnFRTjZwc25OeVY=').decode('utf-8')
    if 83 * 39 < 0:
        _dead_8357 = 869
        _dead_8544 = 644
        915
    total = value + len(text)
    if 63 * 67 < 0:
        _dead_8608 = 578
    return total

def _μΝхТКΘуъДДζω():
    if 40 * 97 < 0:
        723
        982
        pass
    value = 241257
    if len('') > 0:
        pass
        pass
        _dead_3755 = 700
    text = __import__('base64').b64decode('S0lHNk14WkxnemNiU25ad2pnYnE=').decode('utf-8')
    if False and True:
        647
        pass
        _dead_7614 = 166
    total = value + len(text)
    return total

def _АζβозΛЛΧЙαюμвяв():
    value = 208895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnbVZ14Y+50JHRuX/gOWLCQm3Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_9544 = 571
    total = value + len(text)
    if False and True:
        pass
        331
        944
    return total

def _нШкИСсУΡфсДΓкυρЧ():
    if False and True:
        176
    value = 976021
    text = __import__('base64').b64decode('UFZaYmFxSllYRkFGdmg2V3lHOW0=').decode('utf-8')
    if 12 * 57 < 0:
        pass
    total = value + len(text)
    return total

def _МαчьλΠЕΡщνРН():
    value = 144493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCvjXHcu8vkSACj0zgChJC0a00o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дКξΖΩкЗЪМъДДш():
    if len('') > 0:
        _dead_1051 = 938
    value = 65792
    if len('') > 0:
        _dead_6098 = 733
        112
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx7BQggA164ZbS6BxVeibQh+sGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΥΕчоΙнΞиσΙΖ():
    value = 752771
    if False and True:
        pass
        pass
        _dead_1664 = 72
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCX3f1MGrYpRDiSQ2V2pbSoD4Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 49 * 18 < 0:
        _dead_5474 = 293
        pass
    total = value + len(text)
    if False and True:
        _dead_3129 = 868
    return total

def _ωЯΣΩхХΥцАΧΔ():
    value = 485707
    if 67 * 56 < 0:
        pass
        _dead_3954 = 532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBvxSlUQ5pgzEVyu+g6nDCkW610='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΘιπυΗηΘΒФтвζ():
    value = 453941
    text = __import__('base64').b64decode('b3VuR1g4bWRUZFNzRXRBNk54R2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΥиΨОцЕΥνИΧλг():
    value = 620649
    text = __import__('base64').b64decode('c3V3ZjZrT04zUVdhU3hrQnRHa1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟινπнйЕΟзυТбмЭэа():
    value = 129949
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyjIP0kMx/knbg6vxACHYCkKzkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮцЦαжГюШρΔо():
    value = 852870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwjGY3ls5/9VMxWi/GfFAAYJ6W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьрЛтфэъЧΥΑηЧСП():
    value = 872869
    text = __import__('base64').b64decode('cGZ6RmFPcXFvWnp5ZGEwMERseUc=').decode('utf-8')
    total = value + len(text)
    return total

def _дПΖψΙМρв():
    value = 423270
    if False and True:
        _dead_2572 = 453
        _dead_6576 = 991
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Azr1O0UQ86QlHl6Tn3uBHiwqtjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1570 = 224
        _dead_3683 = 398
        _dead_6719 = 698
    return total

def _ГжъЛэπΑΕΠлΑэθДп():
    value = 416825
    if 91 * 79 < 0:
        833
        _dead_8025 = 967
        _dead_9972 = 406
    text = __import__('base64').b64decode('bGpSMEJQUTB2SGdwYUpqbWZGTUs=').decode('utf-8')
    total = value + len(text)
    return total

def _κгЬΣДцΗг():
    value = 729872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDbjTUQ/1KUROVyO71uYMXU/wTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        673
        pass
        pass
    return total

def _ДРЬЭпτшчχп():
    value = 993314
    text = __import__('base64').b64decode('TDF5ZGMzSXNXTGRMV1ZyZzVKa1M=').decode('utf-8')
    if 47 * 13 < 0:
        461
        pass
    total = value + len(text)
    return total

def _πрхЖηюЖФΜαСБж():
    value = 662608
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAbyQ1Y36IAZF1+B5A+5PCQk5V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вςЙоШПГНΑ():
    value = 49096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BB/wQWkArJIRMBqS5Vq/OBICwkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑяАюΠΘшшЦцЖрοМсТ():
    value = 70755
    text = __import__('base64').b64decode('YWNaWEVHemFxOHBaaFplbXNtVkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠэтКХШЭОбξθΠΓД():
    value = 813949
    text = __import__('base64').b64decode('cVpXMGVINTFmNk1rZGJpdWxpYXQ=').decode('utf-8')
    if False and True:
        839
    total = value + len(text)
    return total

def _сЗΨьΛτЬсрЕ():
    value = 832898
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3nzNgkM8apSEF6o0QSaZhobvVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑтΟШοψβΖвЙπЫчΨ():
    if len('') > 0:
        334
        _dead_4237 = 279
    value = 893601
    if 63 * 34 < 0:
        _dead_7619 = 793
        _dead_3006 = 802
        _dead_4278 = 919
    text = __import__('base64').b64decode('VWlBRjdyQVFkdElpVFBkcXJ4eDg=').decode('utf-8')
    total = value + len(text)
    return total

def _НδИйЮУωЕΛЗξΝ():
    value = 975020
    text = __import__('base64').b64decode('Y1NhNGlzYm9aUVo4MUl4amxIQWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΩДΑκсυщξКМ():
    value = 95995
    if False and True:
        407
    text = __import__('base64').b64decode('QTJmRjVlNHlja2RlWmg4SEdYSHk=').decode('utf-8')
    total = value + len(text)
    return total

def _нςΤЦрТЦΞСоцΕ():
    if len('') > 0:
        _dead_5920 = 811
        _dead_3636 = 526
    value = 498443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwrOW1kdr5kJP1yzkVumIT8dyHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 19 * 51 < 0:
        238
        _dead_8804 = 451
        1
    return total

def _яоЪζηЛШчΗр():
    value = 239734
    text = __import__('base64').b64decode('Q192R1MxUG5UdEt1cU5LNzVnNnU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7212 = 194
        _dead_4269 = 365
        _dead_8090 = 417
    return total

def _ΧΞΗχрγДРιлЖΩаЭχ():
    value = 843742
    if 4 * 59 < 0:
        pass
        _dead_7354 = 445
        _dead_9344 = 651
    text = __import__('base64').b64decode('RXlpZkdfbUJUaHVKTFZoUXQ3NXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ρνгщИΣрθтГУеΙΤъσ():
    value = 447533
    text = __import__('base64').b64decode('a0M0eUZEcjY2eUhMRlpMUW1TdWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨлшЖρрФΟΙрс():
    value = 560611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fzr1OwUu8vgIAzya5kGcPQcnsV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΧтОρШΘΧΤΠОс():
    value = 885073
    text = __import__('base64').b64decode('dzhBUER1TGpLRm1TODRfTkdvVEo=').decode('utf-8')
    if False and True:
        476
    total = value + len(text)
    return total

def _ЛΘЬθзχвΥтЮцЦ():
    value = 885071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCfcd0I0qvg6AAuMzEzHPQkLtGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΒλΕщКфонΩκсΓЦθк():
    value = 544522
    text = __import__('base64').b64decode('VGtHdWNNR0JWek9pU1AwMDJYalc=').decode('utf-8')
    if len('') > 0:
        _dead_1304 = 207
    total = value + len(text)
    return total

def _βΑθЪЙΑΕсхШЪηИбζΝ():
    value = 470778
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiXbX0kpz6Q8bzjxxnC2JSMaz2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νАπρМлэςШбΙЯшΓПК():
    value = 271042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Khm1Y3MPxowtNyaI2A6SLTwQtXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 10 * 21 < 0:
        _dead_7123 = 693
        63
    return total

def _эшκгΦηмΝδ():
    if False and True:
        pass
    value = 224187
    text = __import__('base64').b64decode('dVlQZ1V2X0lnRWV4elNnYU9Oam0=').decode('utf-8')
    total = value + len(text)
    return total

def _ДτиεзйБНдπЦ():
    value = 845337
    text = __import__('base64').b64decode('T1FFZzJVUjF5aGMxeEpHbHdLZjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ПФЙипΩэφдОρΟО():
    value = 425793
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyvnRW4//6FVPiWg5QDBNgc94lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шδууλкИЖ():
    value = 213827
    text = __import__('base64').b64decode('WWxfNVJVN09tRmE0SVNiWHhPU1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ψлζэхуЖтрЪ():
    value = 364821
    text = __import__('base64').b64decode('bHVlNURJSEk1NE4yWEhDZXhJUmo=').decode('utf-8')
    total = value + len(text)
    return total

def _КΩοОςΡΙΖяΔущь():
    value = 152151
    text = __import__('base64').b64decode('WlU4NEdTUjBNSUlVOGFsaTdNYk8=').decode('utf-8')
    total = value + len(text)
    return total

def _κΩшΕжΧвн():
    value = 978098
    text = __import__('base64').b64decode('SUZCZG5LN0JaSU82Z0J6c0xIOHE=').decode('utf-8')
    total = value + len(text)
    return total

def _НΟНУЦАΑΞα():
    value = 938675
    text = __import__('base64').b64decode('c3NUYW96VHNWZzdCbUhZVnNkR3M=').decode('utf-8')
    if len('') > 0:
        _dead_8840 = 812
        313
        _dead_4055 = 923
    total = value + len(text)
    return total

def _сзЕμДДыФΖЛ():
    value = 37658
    text = __import__('base64').b64decode('Yk9NQ2JzQ21BVXRqSktqc1BlMmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ХйуΕνДцΞм():
    value = 250658
    text = __import__('base64').b64decode('UFJvdDhtN3hlWkd1X3dRMXlEcHM=').decode('utf-8')
    total = value + len(text)
    return total

def _йоνμЭμВтβЫΓ():
    if False and True:
        pass
        pass
    value = 223416
    text = __import__('base64').b64decode('Yjc2b1NNdEZrV19nSTRoZmUxZXM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        430
    return total

def _уΘυТЮнъЪГДп():
    value = 368092
    text = __import__('base64').b64decode('UUZXMndxaHc5MWtURVF1dXpKNFo=').decode('utf-8')
    total = value + len(text)
    return total

def _χρгψσγлχυДцгΓп():
    if False and True:
        504
        pass
    value = 724149
    text = __import__('base64').b64decode('aVFMRERlT0NMY0s3eUY5ZWwwYVc=').decode('utf-8')
    total = value + len(text)
    if 93 * 96 < 0:
        715
        pass
        276
    return total

def _УσЙεΓмΦЭпцх():
    value = 15914
    text = __import__('base64').b64decode('UU4wMVQwUmE0eHhDSlNFUWdHajM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮъΠεщеΓμимЭЕдхЮο():
    value = 714824
    text = __import__('base64').b64decode('S05PR0tua0JmMXN4aU9fVEF0d2E=').decode('utf-8')
    total = value + len(text)
    return total

def _δΖΜтЮПζХБυφΚΓяЦв():
    value = 220045
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MC72Nkkq64wpPBqH60SYYio5tHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪриΛгдЪЪ():
    value = 140796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyboYlks6YANGSj750OCFhED010='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧХмΑβЛчпдЭБхЙч():
    value = 270738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBvpZAg03b8FYjaaxFCKGCYuzz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зυуЛЛойФтЛθ():
    value = 891777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F370Z3cN/5JXah6I4HPDZQw66F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кηαΜφψςΣΨ():
    value = 50441
    if False and True:
        654
    text = __import__('base64').b64decode('c3kxVnAxUnc2ZUUyXzEyZEU3Ml8=').decode('utf-8')
    if False and True:
        26
        _dead_6886 = 107
        pass
    total = value + len(text)
    return total

def _ЧΤЦЫξКзХДΩΞΑ():
    value = 70657
    text = __import__('base64').b64decode('bjJ5TnU0UGZOc1R5bjFJazBGZzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪБЫРΤтδтНЦъΞщΗ():
    if False and True:
        pass
        538
    value = 476841
    text = __import__('base64').b64decode('Tlo0NFlJeEFRRFBNTmF4QmtMdWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _иΤγυоВΧχбΒοЯ():
    value = 593248
    text = __import__('base64').b64decode('cEFLaVloR0wxWFM4dWV3VU1GczQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑνИΓюωΟГΤЙψуς():
    value = 850829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nxv3alcurf5VFhainwGVB3Ir720='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νКφЦΞθЧоσχχшηк():
    if False and True:
        _dead_1315 = 120
        pass
        pass
    value = 693585
    text = __import__('base64').b64decode('c29DWHhkN05pbE5xeDZBWGoyem0=').decode('utf-8')
    if len('') > 0:
        _dead_7388 = 825
    total = value + len(text)
    return total

def _ΦчфΦфκцОΟТпΚ():
    value = 997696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHnVYmQa26cnKw6M512cOgMM6GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΚщПщфоВЩμυΠЗΙςχ():
    value = 409575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDzSelcQ0/ogChyl4FC2DCkn8Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΩаΤψдЭΧ():
    value = 814455
    text = __import__('base64').b64decode('bms3V1kwbWNTSUNlMGx2cWc3Q3c=').decode('utf-8')
    total = value + len(text)
    return total

def _νАыксЮЧОЙФУ():
    value = 979086
    if 100 * 64 < 0:
        pass
        _dead_9014 = 641
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzXMYnVp1YMFEwyc5UeFNwMO7Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 72 < 0:
        772
    return total

def _ΙпθыНΞЭδАΠнΦь():
    value = 344024
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('SDBDNWdYMGhZaDRQTzE0bzlJazk=').decode('utf-8')
    total = value + len(text)
    return total

def _αЩΖФΖИФκрХьв():
    value = 392878
    text = __import__('base64').b64decode('VUZCeUt3aDJweUlhU2MwS3pEVXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ТΜГρλθωΛтй():
    if False and True:
        pass
    value = 969831
    text = __import__('base64').b64decode('QUFIeEdFRTJGN2VZazcyVVpiakE=').decode('utf-8')
    if False and True:
        pass
        pass
        70
    total = value + len(text)
    return total

def _ΨμχИГмнеΧЕлΟΒПΓ():
    value = 947774
    if 11 * 21 < 0:
        pass
        _dead_9158 = 516
        729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nn/Ub3MW8aQ5BT2N3wGyLggsx1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςζΣΕυεβПСЩМ():
    if len('') > 0:
        _dead_4349 = 460
    value = 31274
    text = __import__('base64').b64decode('akRXdEgyWWEyUmM3aExjb3N1enY=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΟеτΔвχβр():
    value = 235276
    text = __import__('base64').b64decode('VVhDaksyTkZKSXF5RHE3b2dOMFA=').decode('utf-8')
    if False and True:
        138
        311
    total = value + len(text)
    return total

def _ЛДθψепЯΚΞ():
    value = 29942
    if 42 * 31 < 0:
        _dead_1355 = 960
        365
        _dead_9554 = 46
    text = __import__('base64').b64decode('Y2dDNmVpRlBNenhsNXRrN2c2ek4=').decode('utf-8')
    total = value + len(text)
    if 19 * 55 < 0:
        440
    return total

def _ΓΨуОжеъχлςкцНΜеЕ():
    value = 329298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kj/DZkUs8/oWYgG50HCEJRYAtUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρОцΕЖΣΟГθχ():
    value = 877671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX+9Y10/xo8HAFu62lKxYgQMwkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 98 * 76 < 0:
        718
    return total

def _МτξΜнеΗλΕМТ():
    value = 685509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AjXGPWggqpE5bl6JmVe7ZhYs3mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘαнδΨхΚмο():
    value = 746399
    text = __import__('base64').b64decode('eFZhc0ptdzRhTl9zSHR2T19aQXk=').decode('utf-8')
    total = value + len(text)
    if 59 * 92 < 0:
        718
        293
    return total

def _ηληΧЖΙзЙвДΞΒЗυΠя():
    value = 171862
    if 39 * 48 < 0:
        _dead_1253 = 9
        803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzvLf0UJrqEKPgqZwl2KDQJ21kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        421
        pass
    total = value + len(text)
    if len('') > 0:
        254
        _dead_3528 = 962
        847
    return total

def _θРΘΑьΨΑОσДЖгОю():
    value = 897359
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ID3eTWIU5P85HSyWn0CxbXQ69Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝчπσыΥηЛд():
    value = 329627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCPja1g3+/ARBVun7EOcZisuyGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡпΒδлЕΜЯЮ():
    value = 789196
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCjgdFQMz5sEN16UwVuhYC14zGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 64 < 0:
        _dead_5754 = 978
    total = value + len(text)
    return total

def _ьзΩиψЖθИрОАιζБшλ():
    value = 428463
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESfGS0VurYUUAyn68VGGBCYeym0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФхЮЦсΥЬЛτπФЬСЧВ():
    value = 537812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxrLV1kLypcVOSKl6mmlMRN73F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηаΟъΣщσωφΨΘсЧΕκ():
    value = 101571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ey7dRwYd1fAtYgDw+WKIOhIE73o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΠХКФΑУбКΞπσ():
    value = 288037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhjJQWEo7PoSHSei3Hu6P3U8yTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БыЫΑзЩюыθμ():
    value = 350145
    if len('') > 0:
        pass
        _dead_3587 = 593
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCnBZnYz+/wOHAT64mSeDSMV8XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СшЧИЮНХЬРЪЦэκΘ():
    value = 947271
    if False and True:
        336
        987
        pass
    text = __import__('base64').b64decode('eHpmdTlueDBLSmxrem1GNXlrdlc=').decode('utf-8')
    total = value + len(text)
    if 59 * 26 < 0:
        pass
        _dead_9679 = 62
    return total

def _φζтΦηζчψαГЬс():
    if False and True:
        644
    value = 235151
    if False and True:
        _dead_2424 = 932
    text = __import__('base64').b64decode('c2g0VGNieXluQTJXSERyOGZEbUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ψνвΚплθхΩбМрТς():
    if False and True:
        pass
    value = 290403
    text = __import__('base64').b64decode('cGJJOWUxdjBpNk5QejJ5dVhSdUI=').decode('utf-8')
    total = value + len(text)
    return total

def _λΨγВЧьЧъ():
    value = 246483
    text = __import__('base64').b64decode('WGluNkJQUFJQcF91VXpaakJ5ejY=').decode('utf-8')
    if 5 * 77 < 0:
        834
        753
        _dead_4401 = 832
    total = value + len(text)
    return total

def _ΤЩΒθШЛφГΣΖЭрА():
    value = 826578
    if 99 * 67 < 0:
        pass
        _dead_5775 = 275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyDGQV4Ir6wtEzi0+XKxYxQssHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        108
        pass
        519
    total = value + len(text)
    if len('') > 0:
        _dead_8262 = 386
    return total

def _нЙεΜφиΔΞшжКΨΨвЕХ():
    value = 32185
    text = __import__('base64').b64decode('Zk5Qc2RTSDdBdlY1UXhFN1NMcWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ШλтсπΗгЬΒюЧχ():
    value = 482596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnbLbH0vzqAvIF6CwFWHFhN40mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΡΠΑЬлыν():
    if False and True:
        pass
        _dead_1977 = 556
        _dead_4012 = 996
    value = 43359
    text = __import__('base64').b64decode('c25EWkpGcUVwaWZDejMwazlvTGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΨξГηЖшыцс():
    value = 711254
    if False and True:
        621
    text = __import__('base64').b64decode('VDdwZlJ4TlgxZkhwVkhfQTM0YWI=').decode('utf-8')
    if 14 * 43 < 0:
        _dead_1411 = 758
        200
        pass
    total = value + len(text)
    return total

def _ζИσλΥыΓжБΨΓ():
    value = 686925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyXIYXUA7fAoaAmonmDCA3UAtkc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3709 = 632
        pass
        _dead_7869 = 818
    total = value + len(text)
    if 84 * 35 < 0:
        368
    return total

def _ЧσΘΚлφбαΦΠ():
    value = 312869
    if False and True:
        222
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB22flcexps3LAiH+lrCMjR5510='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 36 * 17 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _йΝΡΕЬкЕЖБΦи():
    value = 718944
    if False and True:
        _dead_4248 = 508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx3AOlUur6AVLwGQw1zAPzY1/Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пэЧеψЬЭΜξуΦвλВШΑ():
    value = 204288
    text = __import__('base64').b64decode('dHRuZDBVeTcxaDhlU25LcUxSaWE=').decode('utf-8')
    total = value + len(text)
    return total

def _βВЪΤΑЧьвеλР():
    value = 942082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH7WYnAhz6cXHVyQ5XW7Bw0a53c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κЮЪЭνπгΥω():
    value = 559396
    text = __import__('base64').b64decode('d29CUWIzbUVaZnQzNEdYMU51QVg=').decode('utf-8')
    total = value + len(text)
    return total

def _дδЪΩдкπхк():
    value = 744693
    text = __import__('base64').b64decode('eDRNODRwaU1HN3JmSGdYenJwUVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ъφцЛоыκЕЕ():
    value = 822407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhXGZ1sz2ZBQDDaZ8Ga9GhEeylE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВрΨЦηκΙл():
    value = 401885
    text = __import__('base64').b64decode('ZmVIQ2JqWGlUTTZFdHBPUER2QXg=').decode('utf-8')
    total = value + len(text)
    if 19 * 34 < 0:
        pass
        _dead_8622 = 928
    return total

def _εΞΓИНЧΟφΡяΛΤεфн():
    value = 157795
    text = __import__('base64').b64decode('czZ5TWJIdktTU3Fpdk4xNGoydkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΒьνωγДω():
    if False and True:
        pass
        pass
        pass
    value = 827054
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj7gYAgs0o0wKzCJ4XvJETN51Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        381
        pass
    return total

def _ΨΨкШЧнΗуροξт():
    value = 595557
    text = __import__('base64').b64decode('YklBZ0tyc08wZUkwU1JiVjZ2cnc=').decode('utf-8')
    total = value + len(text)
    return total

def _шνъьПοжΝνΡ():
    value = 514776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHzMWVk26ZkmbSiH+1qHJQw4xTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρэфΧΤжоλςДμ():
    value = 95188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCXdYnoWy6sKLTyV0WmnNSkD8Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΨюнсауδ():
    value = 361312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB7zV10syY0NKyTwmAWkPXIJ1ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лЩДКсψηУекΤρφОΑ():
    value = 665568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECnlbGUYwYkJNy6O+UfHNRon4mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮδΨлΑцΠЭωщ():
    if 60 * 61 < 0:
        410
        _dead_1177 = 999
        _dead_4757 = 747
    value = 546831
    text = __import__('base64').b64decode('UWZrcEhoTHZBa3FTZkhXUnNFZ1M=').decode('utf-8')
    if 1 * 96 < 0:
        pass
    total = value + len(text)
    return total

def _ЯбΜΡнΟпЧЩΝΞΘ():
    value = 994783
    text = __import__('base64').b64decode('bW4yVFhBQTh4ZXA1Q05RbDZLQWc=').decode('utf-8')
    total = value + len(text)
    return total

def _КЪΙΗЩΩξЩВν():
    value = 868451
    text = __import__('base64').b64decode('a056QTFmZ05pdlVoMHBNRjN3V1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЦЩИЗдПΜгμЬξ():
    value = 469215
    if 6 * 35 < 0:
        _dead_4814 = 895
        _dead_2257 = 602
        pass
    text = __import__('base64').b64decode('djY1emNuWXdjZXVGcHRLWGZZQjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩльμЫςИΨΦΥνКЦФ():
    value = 769248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EA3UfgM+2PkkI1ys62KeBiQq9z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗψЭζΑбшΥХσ():
    value = 756932
    text = __import__('base64').b64decode('b1Q2OXgyWUx6YU9oR0QwOVl0X0s=').decode('utf-8')
    if 93 * 30 < 0:
        _dead_7898 = 139
        pass
    total = value + len(text)
    return total

def _ΘЭэаγΝшпωΛЬфΤЬ():
    value = 369627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhXoS38T0K4pEw6k3USBPzMa7UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        996
    return total

def _ВЭΧдΟЪΑρАюεчТАгК():
    value = 525358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCvmYX5h6Z8IYyrxxQWICxAX3EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΞЯБЕыΘσΞ():
    value = 91761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAnMRkRs2IQOPyqN92aBMwMJ7Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        613
        pass
        pass
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if 44 * 51 < 0:
        329
        pass
        231
    print(__import__('base64').b64decode('dA==').decode('utf-8'))
if len('xxx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    23
    512
    542