#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ерρΜтЙСсяψΠ():
    value = 549455
    text = __import__('base64').b64decode('UHBNWG9ocXl1NTl4YkxCcXhTVmk=').decode('utf-8')
    total = value + len(text)
    if 7 * 14 < 0:
        pass
    return total

def _КιΜНОафΤдозΣαΠЬΑ():
    value = 846813
    text = __import__('base64').b64decode('Y2xlaFh2YmRoQkh4ZnpZQnY1YmI=').decode('utf-8')
    total = value + len(text)
    return total

def _юШьПχφΝчП():
    value = 694985
    if 86 * 55 < 0:
        714
    text = __import__('base64').b64decode('RVhEMnFsOFlVX0MxQVZhS0hJQU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜЧοсгКхЙъεШ():
    value = 206955
    text = __import__('base64').b64decode('Sl82bWJ6NHEwVEVZWG9YNjhqbDI=').decode('utf-8')
    total = value + len(text)
    return total

def _жΚΛежЬиφΗΒιΨК():
    if len('') > 0:
        pass
        pass
        874
    value = 66334
    if 20 * 88 < 0:
        575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3rdYEgr9ZEnMwSoxE+1ZxYo/ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νнφВγчуΗцрьΕДэ():
    value = 178544
    text = __import__('base64').b64decode('YWtlOThsUWNxZkJuTmtSX3JFQTA=').decode('utf-8')
    total = value + len(text)
    return total

def _тьТαКφΦУΗБшΒΥψПσ():
    value = 560722
    text = __import__('base64').b64decode('Z3lfR2NLTmZsU1JlU1pLWlVGZlE=').decode('utf-8')
    if False and True:
        _dead_5150 = 391
        pass
        409
    total = value + len(text)
    return total

def _АСΙωйΩЧπΧ():
    value = 753564
    text = __import__('base64').b64decode('ang2YzNpbWlBM08yNUt6cFBqdUM=').decode('utf-8')
    if 66 * 78 < 0:
        pass
    total = value + len(text)
    return total

def _нйυΓОЩκΗДЮБοΤοΥΑ():
    if False and True:
        466
        323
    value = 711289
    text = __import__('base64').b64decode('bjQ3dGNkZ1dkTUltY0c5b2VuN0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _φбьюγρзиυУΚΩ():
    value = 806050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ij3gWEM+yYkbFyCn/gaEYSt9yzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1146 = 980
    return total

def _ΞпфΔςзДΦжγВхσЙЧ():
    value = 443375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDvAaHsxx4wlCg6q6Vi+FnYftms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОηυηςςηΑυχψΒЧСΕ():
    value = 677027
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzfWOEdo07EbIzm3/EOKIxAlzFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЦЧξзπЫГЯбθΤП():
    value = 480730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwvpXAUJ7/8gDzqK/g7CMyEN4Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νЗΛφрΤще():
    value = 5156
    text = __import__('base64').b64decode('eTNPempPQ0VIOUlHV3pDVU9fRE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥЩабиοрΔД():
    value = 431913
    text = __import__('base64').b64decode('Tzd6MjN1R05lRmJlcnJMWGVBV28=').decode('utf-8')
    total = value + len(text)
    return total

def _еΡхяΔξРПχΥ():
    value = 821166
    text = __import__('base64').b64decode('d2xtNnFmcmZPNWxYTkRwY3J1eW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠлаΘЯЖнУσΛБτЬчб():
    if 32 * 52 < 0:
        pass
    value = 651626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyW8OGcRrqQQLRqJ7g69HQgDzT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 81 < 0:
        958
    total = value + len(text)
    if False and True:
        815
    return total

def _юσъФΟЙΞЖν():
    value = 410512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwHDdl9h9/0RFFi60E+yBQ4QvUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χмνиχЙВω():
    if 28 * 92 < 0:
        pass
        pass
        pass
    value = 839655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MST8SwU97qQEKhuM43+aFzQs02E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭхξЫЕμЭΒΣЛΕλ():
    if len('') > 0:
        pass
    value = 409964
    text = __import__('base64').b64decode('aWRWRzJfRndFY2lreU9vZzZPRVo=').decode('utf-8')
    total = value + len(text)
    return total

def _НΨвАНдЮфтыαΟ():
    value = 371206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITfHWgUy7L0NAB3x+k+kHgI+8zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θσъΘБηОпЬθΞΦ():
    value = 183123
    text = __import__('base64').b64decode('VHlZX2hoTjVMckw5N0FBa1lndUk=').decode('utf-8')
    total = value + len(text)
    return total

def _υщсегιφвυλΚΘΨ():
    value = 622755
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAfAQG4rr6EsOwuQ52eRBnAWwEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗνтБШΝΤаоλεжΣмоΛ():
    value = 22998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh/weXMe/LwaESz3kVWXA3EE/UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δэЧФЮЖзЖвν():
    value = 491565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCTxQ386rfwhFwPykFiZP3QtwHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        219
        _dead_7103 = 651
        pass
    total = value + len(text)
    return total

def _βЫЦълηОяΞЛзΖчΜυ():
    value = 637406
    if 82 * 4 < 0:
        pass
    text = __import__('base64').b64decode('RjJIYVBGbHpFdk9UZkVEZjZ6MWo=').decode('utf-8')
    if 97 * 26 < 0:
        334
    total = value + len(text)
    if 62 * 84 < 0:
        pass
        872
    return total

def _чΧωехρκюΧδκ():
    value = 579089
    text = __import__('base64').b64decode('RVlsYTFiMU4yd2tHTW5zY1JyY2g=').decode('utf-8')
    total = value + len(text)
    return total

def _σφΓκΛХДКЦδΕ():
    value = 605323
    text = __import__('base64').b64decode('UElXM29zWmJmeFFNbU5mRER4c2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥчудνιЗпЬψΚЫХω():
    value = 417069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzbVOQE40vgHbzml7WfEBjZ7vVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЙБηАμщи():
    value = 327241
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AR/lWGEe1YIlGTWJmVK9Ygh87nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 67 < 0:
        pass
    return total

def _АаΗямвфΛ():
    value = 71860
    text = __import__('base64').b64decode('cHBCQUh2T0hWaUpKSkxub0djVlE=').decode('utf-8')
    total = value + len(text)
    return total

def _аΓиσЫΤМсЭτψ():
    value = 824802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhrPaUIw6YU6Ig30nkO1LQ4L41E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3867 = 719
        pass
        pass
    total = value + len(text)
    return total

def _ЕиоГюфΜЧЯζСΚЙς():
    value = 361057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgaxbV0L1aIoDwiE6geBGBoA3k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΒπщЬОЧΑЮλνλΟΘчН():
    if len('') > 0:
        _dead_2239 = 833
        pass
    value = 474514
    if 24 * 68 < 0:
        pass
    text = __import__('base64').b64decode('Y3huNFNQTmNtaElzT3hZbTlnNDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ςγщπъυХΥНΝНκΨщΤф():
    value = 707018
    text = __import__('base64').b64decode('U2VLQk9IamxKR1FmZ1VYWlJzTm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦДЦМюгβоπ():
    value = 661190
    text = __import__('base64').b64decode('clVOdnU3TWp0TVhhakF4UUgzUW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЬΚΑρьΖВищ():
    value = 628845
    if len('') > 0:
        978
        412
        0
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCrCOlwLyvw1NFiPwk6DGyEK1mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φЛФбЛйβтιНΓΠΖ():
    value = 203835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzvSWwEMxqItMFum7lGcEAc/9UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΓГζΙЭΤэЩДЛПиНд():
    value = 118783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhexOXA7z4swCF6m0UWnEwYE71k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        584
        _dead_8634 = 753
        931
    return total

def _ЗмДкПΤПνΑΝЫΝкΝНς():
    if len('') > 0:
        pass
        _dead_6450 = 260
    value = 342408
    text = __import__('base64').b64decode('d05tdnY1MEtCVFJ2OVJ0Rm1lU3c=').decode('utf-8')
    total = value + len(text)
    return total

def _бкωнуЖвμδЪΟьжыюβ():
    if 47 * 84 < 0:
        19
        _dead_4104 = 150
        pass
    value = 71353
    if False and True:
        _dead_7628 = 497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3nyQVUv6aMILV+0mk+TJxIesG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εкШЙфРξΩΟΚ():
    value = 569325
    text = __import__('base64').b64decode('TGJvMklFX0g2UjNqSzNjd284NEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ςуЙбИυπΒщιеι():
    value = 161388
    text = __import__('base64').b64decode('azNqNU95TUVic2V2dHJtREJYVjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮыμыψтчΧ():
    if len('') > 0:
        pass
        _dead_8086 = 24
        _dead_2853 = 744
    value = 405769
    text = __import__('base64').b64decode('ZHZwWkpCZGJNMzRuRTVwaHhYV28=').decode('utf-8')
    total = value + len(text)
    return total

def _АρФφукΞг():
    value = 606120
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACbeQWRp5/wQOwOW2n3JGQ989Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гйЩΤНβТδПΣΔεοθΚ():
    value = 668588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXa9XUENp6YJDTiGw0CIBX0J9Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 76 * 13 < 0:
        284
        pass
    total = value + len(text)
    if 86 * 56 < 0:
        _dead_2454 = 514
    return total

def _яхыλΔюЮМВжΓιΙКн():
    value = 111640
    text = __import__('base64').b64decode('ZkNMZ3hKSTc5ekc4b2JtU3BIVko=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥЫΙΘΘοΓΩшккξХЗхе():
    value = 513536
    if len('') > 0:
        pass
        _dead_3433 = 54
    text = __import__('base64').b64decode('WEV6cHZlcWhRaHc0SU1UUmNRdHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭлйΩΘщЬαО():
    value = 72487
    if 80 * 12 < 0:
        226
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ji7DfEVgyoxUDh+r0nqeLAoN1Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 99 < 0:
        _dead_3688 = 844
        _dead_6692 = 600
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _РиъГΓЗΗиμууΓγжЗГ():
    value = 188402
    text = __import__('base64').b64decode('RE9ES0dRRHNpQ1BmckhLSUJZNlY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЛАкЯбΜПπбδЩЯрιцЪ():
    value = 565882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwC8R2YXr6MKAy6C61m5Jik303g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вВмТзрςТ():
    if 100 * 91 < 0:
        531
    value = 990539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT+wb3YK/LgPLiOL7HSSbQ574kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 28 * 23 < 0:
        _dead_3444 = 893
        953
    total = value + len(text)
    return total

def _ШθψΛηФнδЪ():
    value = 325323
    text = __import__('base64').b64decode('cG5POGpQdFFJY051ckJ6TFZiYnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЩКσΝΜΕΘчΧζ():
    value = 176299
    text = __import__('base64').b64decode('SzlNS1ZxZWpBYXhQa29mbWZSWXQ=').decode('utf-8')
    if 84 * 91 < 0:
        625
        pass
        _dead_8937 = 239
    total = value + len(text)
    if len('') > 0:
        _dead_3533 = 701
        349
    return total

def _ξвЧБΝЖΔΚюБпжзчиυ():
    if 6 * 82 < 0:
        pass
    value = 40781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyntXEFt6os5Iwq12WO8AnMd3kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыцфγΝнэпΜя():
    value = 538770
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAvKbUEx5rshIxWE/m6JGScc6VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΟпβκоψЫΒбОЖьΝ():
    if 50 * 10 < 0:
        _dead_7836 = 940
        _dead_4454 = 898
        538
    value = 737971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH3HXHIX7K8OKzv1mgGGBXMXw2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _βΦцЦФхоοцУΤРνш():
    value = 811998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ND3yRnYb3aoVGx+o5V6eEx153l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОБфΛТахΩγОып():
    value = 134601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pw7QNlsqwYk0YhmP8Hu2F3MW130='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЦХΡψфιΨ():
    if 28 * 53 < 0:
        pass
    value = 210225
    text = __import__('base64').b64decode('azY2aWlWUHFQV1REaW9rd1pobzk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        992
    return total

def _ΦЧηФξВфΛΦι():
    value = 133960
    text = __import__('base64').b64decode('QnE4cml0el9ZVFYxc3ZDZllfRE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯюΟΧАлИдВж():
    value = 130478
    text = __import__('base64').b64decode('SVNac3VDQ3lrVnZ3bHdRUnVOSWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖβαΔΗρχОБαХεщТ():
    value = 680910
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRv1OgIP0LAGaiz35wSbEQx39Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сшΞБδφΛουйАιζБΞ():
    value = 114724
    text = __import__('base64').b64decode('UWR4eThNQW9wUkJuX29aSW5vOXE=').decode('utf-8')
    total = value + len(text)
    return total

def _КιЪГеΖйΜЗзΜε():
    value = 756131
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQTiWHUd+5EmKyaCmAKGZX0E52w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        141
    total = value + len(text)
    return total

def _ςηΝσЗοΩχΓыФυЭЕОШ():
    value = 727264
    text = __import__('base64').b64decode('Ykw2NE1xRXJXVXRqdG1xVFI2WkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΨαларγπВβк():
    value = 250383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCHsYHMt8ps3CDmnn2aIbHN9z0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗрЯэфХβμЛτΤЧ():
    value = 439834
    text = __import__('base64').b64decode('TlJMZHkwRUhwMWdIS01iNXNmOVU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        551
    return total

def _ХεΟИρБΒБδΔ():
    value = 938560
    text = __import__('base64').b64decode('bm9WamhibDliSFVYZFdyb2hZRGY=').decode('utf-8')
    total = value + len(text)
    return total

def _яхωяΤξчзхЬЧъ():
    if len('') > 0:
        _dead_8455 = 500
    value = 806151
    if 99 * 22 < 0:
        pass
    text = __import__('base64').b64decode('b3NkNHBzenptWVJQczBvbTZsTUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙШΛЦээων():
    value = 415231
    text = __import__('base64').b64decode('bzdoMjJod0ZnYTVqYzNuUXhEWnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝБФЫЖоЩГΘβЩηπ():
    value = 261207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Egezan4vqa8uKjiAw3epYS04yTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪзΠйрΟΗκκкЫЪ():
    value = 71662
    text = __import__('base64').b64decode('cHN2emNuZG4xVUVGUEd1SFdLcU4=').decode('utf-8')
    if False and True:
        pass
        _dead_6809 = 73
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _πΝИΝщЦΖнШэ():
    value = 456734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AA7yYgQ2/ZEZPlv1wHegAC0n0l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘмψЙδГΓьΣФЭ():
    value = 160124
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwTbYEJtzaQtKlypnXmGHhIKyTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2956 = 610
        675
        pass
    total = value + len(text)
    return total

def _βΖлφΖπРзх():
    value = 344656
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3fLZkQa0qcLHxis+UWGJRA87Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙЧЛζπΠНЮη():
    if len('') > 0:
        pass
    value = 217988
    text = __import__('base64').b64decode('QzR6QlA4YUhvWkg0N2swZG1EOFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ςυЬяζΗΕчг():
    value = 75581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwbjP2k8y4oCYjya23uaDTY5tUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЧЦфΙΒмλ():
    value = 885270
    text = __import__('base64').b64decode('dkROTU5nZ2tFakZLMmRCZGxtdW0=').decode('utf-8')
    if len('') > 0:
        451
    total = value + len(text)
    return total

def _ΥДмβζВμлγΡЕ():
    value = 18546
    text = __import__('base64').b64decode('SHFIZEFIa0E2YlNWeFEyblVBc0M=').decode('utf-8')
    total = value + len(text)
    if False and True:
        677
        _dead_1838 = 356
        _dead_4298 = 811
    return total

def _γΟкШГЬЧщияюМИ():
    value = 438081
    if 41 * 96 < 0:
        pass
        _dead_1935 = 377
    text = __import__('base64').b64decode('amtXVThWSzNaU2hzWUc1OFVJaG8=').decode('utf-8')
    if 96 * 74 < 0:
        pass
    total = value + len(text)
    return total

def _ΒζЬθΖΜЛЪηЯКΜκΜω():
    value = 270744
    text = __import__('base64').b64decode('VlQ1eGRrQXd6WkZwRzQ2MkZFZno=').decode('utf-8')
    if len('') > 0:
        _dead_6260 = 347
        712
        pass
    total = value + len(text)
    if False and True:
        _dead_3448 = 464
        pass
        _dead_5404 = 537
    return total

def _δσЧжЖЩЖЩΩιЧщъΥдн():
    value = 681627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgHTdnI6yq8PbgK22wPBIX0a/kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖхНэΛλψσуΜЮЫкΘβν():
    value = 664258
    if len('') > 0:
        pass
        pass
        229
    text = __import__('base64').b64decode('dVc1bk9RdWRXSzdzS0NNSm9YZGQ=').decode('utf-8')
    if 92 * 31 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ыяйиηаπξЗ():
    value = 406337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCLCXVk204k0aVr28lXAMTQi7Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 4 * 49 < 0:
        _dead_9424 = 828
        pass
    return total

def _θωΔПΥΩΖнζχЛ():
    value = 975411
    if 17 * 24 < 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('ZkZyYWpBcU0zdnpmNTB4QnlsWnI=').decode('utf-8')
    if 69 * 39 < 0:
        417
    total = value + len(text)
    return total

def _ЬΚышуыΜзОυсХΠк():
    value = 631129
    text = __import__('base64').b64decode('TFY2UjFWVFpDRVpnR09IVVNISEc=').decode('utf-8')
    if len('') > 0:
        944
    total = value + len(text)
    return total

def _ФГаЪэΝφΙИЫ():
    value = 973722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjjrQ0dt340tDB+Q/WGmEnc78T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЮуВИсХФОΔб():
    value = 583711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiPhRFYD1IkSCz6E7mO+bTUIz2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ΦαшСЭдοΗ():
    value = 594634
    if False and True:
        pass
        _dead_2243 = 887
        337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESLpSVA93KIIaAWW/ASvLiA3vUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λъΚГШеΠΗюτΖя():
    value = 443649
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AybuNkc456VSCxuAzkylEHM+3nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨЙΡЛΗοпнνхЖζБ():
    value = 434518
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('WW9NX21OUHdoNHZISHFuN2ZPM1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΤкБцагζκτγ():
    if len('') > 0:
        986
        _dead_3765 = 981
        _dead_1910 = 298
    value = 222570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzvKOkYx/54EPT6t/HqyZzwG13k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠгΗτцллγ():
    value = 639307
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('V1VFbXJieGdaZDl3OEwzTHM2dGs=').decode('utf-8')
    total = value + len(text)
    return total

def _γΤФдΖηйнг():
    if False and True:
        _dead_7935 = 18
        _dead_8427 = 6
        250
    value = 53522
    if 31 * 30 < 0:
        40
    text = __import__('base64').b64decode('Ym9ob0F1T2VHSnFhazRJOE96eVM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _цРэпκКОΞς():
    value = 526255
    if len('') > 0:
        173
        410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MC3Wb3Qj2KQqHQKG5EOaBXUes3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 94 * 60 < 0:
        pass
    return total

def _ЯчЭфщΜψВдСΑЕεПц():
    value = 990855
    text = __import__('base64').b64decode('UmRORHJOb1doZ3NzNnpfajFBTVE=').decode('utf-8')
    if 87 * 20 < 0:
        161
        pass
        _dead_5628 = 403
    total = value + len(text)
    if 10 * 1 < 0:
        pass
        _dead_6868 = 48
        pass
    return total

def _ШυУЦжцЬР():
    value = 756254
    text = __import__('base64').b64decode('WmhLZGdPT0k4ZnRUVEgzbW5kUno=').decode('utf-8')
    if len('') > 0:
        238
        780
    total = value + len(text)
    return total

def _ΜЩГΤΣПпвцмелВ():
    value = 129293
    text = __import__('base64').b64decode('aUl5NXFTSmdrS0hNQjM5UklNRXo=').decode('utf-8')
    total = value + len(text)
    return total

def _сΗЖεблξкμδд():
    value = 749236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDmxYHcy+6oPFyS5x0WVPxF2yFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΕλυеТΒТЭΟΠΒЛя():
    if 58 * 43 < 0:
        pass
    value = 610036
    text = __import__('base64').b64decode('dkxWbWVzU0t1M1ZwZ2xmVTdKWFg=').decode('utf-8')
    total = value + len(text)
    return total

def _δшЧΕТтЦΘаэрфκпчщ():
    if 34 * 43 < 0:
        388
        919
        pass
    value = 12602
    text = __import__('base64').b64decode('Z3J2YXNVajZfVGdoSmlIQnBpdjc=').decode('utf-8')
    total = value + len(text)
    if 60 * 19 < 0:
        _dead_7544 = 151
        403
        589
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()