#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ЕФΡжΥТΨΥδЫБйД():
    if len('') > 0:
        pass
        741
        pass
    value = 308667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQnwZWYprKtVFFuKkFOSOAF2yEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΛНτβρОВАτΧбΟΓΦ():
    value = 278624
    text = __import__('base64').b64decode('d3hucE5melN4VHBoVUJuenJCMDg=').decode('utf-8')
    total = value + len(text)
    return total

def _мοХОрψЛсΜБлЗιеПτ():
    if False and True:
        _dead_2273 = 328
        _dead_5766 = 669
        _dead_9156 = 446
    value = 256235
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lji0QUscyYYSHlatxwShZHcew3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖЛΠцеδХЗБθ():
    value = 816925
    text = __import__('base64').b64decode('dU9yY2Y2ZmdBMmcyV2dSVFhTSnQ=').decode('utf-8')
    if len('') > 0:
        _dead_9539 = 792
    total = value + len(text)
    return total

def _яΓСЪδгБГ():
    if False and True:
        pass
    value = 702652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBayVncTz/85BT21nV2pGiYnx1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_5526 = 86
    return total

def _δцξΔοъяαЩЙχΒюЭπ():
    value = 8267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ki7UOgEL+acaOVep7k60MycJ13o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡζлΜюΞΨη():
    value = 619353
    text = __import__('base64').b64decode('TWxXZ3RteGdmMGlSX0tIeTl1SWU=').decode('utf-8')
    total = value + len(text)
    return total

def _аΣФеОζΤСομςчсЬπφ():
    value = 190588
    text = __import__('base64').b64decode('bTJvR2hRZ1V1N0NFdmhYWXVIOV8=').decode('utf-8')
    if len('') > 0:
        385
        pass
        _dead_1393 = 488
    total = value + len(text)
    return total

def _νРθуΛщΧгαЬκБВΓ():
    value = 271710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3jjTVUR2qQMED6253mXBQkh4Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΟдΜТХηЖЖюΘнΗ():
    if 85 * 77 < 0:
        _dead_4148 = 758
    value = 358318
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('WEVfNENNc28zV2tyN1h0TERoR1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЛЯЬηΑΠЗДγ():
    value = 989584
    if False and True:
        65
        _dead_2621 = 465
    text = __import__('base64').b64decode('T3d2T1BxbjBGSHNSODI4RU9ubUs=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5470 = 824
        _dead_5462 = 373
    return total

def _βμΠιΥВΘιΖОю():
    value = 867588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzbVW1Iv5oUbFBuI72PCOjQ3tEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫωΨпяιКЗиЧΝζ():
    value = 36951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ3VXWQ0rLE5OQyNkEyoIAIc/Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8982 = 76
        _dead_9776 = 996
    return total

def _αρоэьΕъЫξоΟРШψшЖ():
    if 30 * 49 < 0:
        pass
        13
        281
    value = 464225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCrbeFAL6o4OOBu072GfYyMcw0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 96 * 57 < 0:
        169
    total = value + len(text)
    if False and True:
        444
    return total

def _ВΥмχБχΖιξ():
    value = 74900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NS3PWXQe0qIiABmA73SRGDMc8H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮЭΒуВОβРОБЧеБ():
    value = 660555
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISK9bXQW1okHLl2gz0OxORMi8GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 7 < 0:
        _dead_7601 = 267
        _dead_4989 = 892
        _dead_9549 = 615
    total = value + len(text)
    if len('') > 0:
        _dead_2043 = 566
    return total

def _ΘυМэψζβΜЧΤхφтλφ():
    if 5 * 6 < 0:
        _dead_3872 = 958
    value = 969319
    if False and True:
        _dead_9237 = 170
    text = __import__('base64').b64decode('TUhEaE5ZSVRBQ0V2Rk1xUlZXMmM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2534 = 271
        _dead_8709 = 637
    return total

def _ФвΦПУШлΦΡ():
    if False and True:
        pass
        _dead_6907 = 246
        560
    value = 172657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnnFV1hvrIEaFzeU/Gm7OwA6xW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χсМβιδХФΔ():
    value = 735924
    text = __import__('base64').b64decode('WmYxWnRrQnNqVFJOQmZ4TXlITGI=').decode('utf-8')
    total = value + len(text)
    if 26 * 100 < 0:
        pass
        _dead_6593 = 374
        721
    return total

def _ΖΜΦЧαиеРΡ():
    value = 424338
    if 12 * 21 < 0:
        489
    text = __import__('base64').b64decode('YnVZdWU0YUF2MnIzd1BmZVBWUks=').decode('utf-8')
    total = value + len(text)
    if False and True:
        167
    return total

def _αЭкгълφΦдΓлрджЩй():
    value = 752050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB7LdgkN3JsECxqI+niDAiF34kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _элΥЬγбЩζУжΒ():
    value = 193690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjbAN0US9783LQ634AGxEXN+814='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 78 * 46 < 0:
        954
        pass
        584
    total = value + len(text)
    if len('') > 0:
        pass
        942
        pass
    return total

def _УНыиΗνЗгФμр():
    value = 501159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXjDWAEJ6vkxCSWRnH+hIQkl0GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕЫСЪφУЫВχ():
    if 34 * 3 < 0:
        _dead_5372 = 73
    value = 816041
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQ7wbHQMqP0xCFqpwAfJGHQE00I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        596
    total = value + len(text)
    return total

def _ΟФΜАΩгИЩжЮΞ():
    value = 91401
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQO8UV1p8ZoOLQKAwXmnNyl4yV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥГΜσΠыбс():
    if len('') > 0:
        _dead_9224 = 13
    value = 570744
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiLmVGk4qPAKPFiKxQWUN3YNz0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖрхнПЭΖПЛ():
    value = 780121
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjzAeWQM0I8HaQ2TzUKdBBEZ4jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТуоΟбшдζо():
    value = 900766
    text = __import__('base64').b64decode('S3QwX0FidTJMX0xGTVBoMk5UMnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΞИΤИЛπΑоΝςэуйΘ():
    if False and True:
        _dead_1023 = 797
        pass
    value = 60152
    if 49 * 12 < 0:
        pass
        _dead_4151 = 593
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BibcRQkX+fFRMQiR6WS9IQYGtn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эπψпТΜГΕНпяαφ():
    value = 768569
    text = __import__('base64').b64decode('SnpmZVUwRlA1RVdtVzhmU2Q4SDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨηеДΗхПмΓПЫΗЛэ():
    value = 65344
    text = __import__('base64').b64decode('bk0wOXBJa19qV0RvbXptQnhMSnQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _нмРьъмυιЫ():
    value = 993462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBbHPEcvz6UMYgGC4GOSIQoo4UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΘДΔρЩцζξЭμржЛ():
    value = 189181
    if len('') > 0:
        440
        161
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXiwSWIa+r4MFyyc0UHCbAB/tFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 30 * 11 < 0:
        333
    return total

def _сЩэΗтЦΟΝ():
    if len('') > 0:
        678
        pass
    value = 675665
    text = __import__('base64').b64decode('d0k2b3I3NTBkSHFUeTk5OXVpejI=').decode('utf-8')
    if 23 * 82 < 0:
        _dead_1995 = 453
    total = value + len(text)
    return total

def _ИцηыΞьБн():
    value = 234178
    text = __import__('base64').b64decode('Q05qemlVcFVWRmY4dUp6aDc0REU=').decode('utf-8')
    total = value + len(text)
    return total

def _дδψчυΒМЫШξбΛ():
    value = 147655
    text = __import__('base64').b64decode('SjlGV1FrZFNlN1JNQ2lXQmFhV3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗуЛβХΨдυР():
    value = 335983
    text = __import__('base64').b64decode('cjVPZjdZOGI4U0xFa2NwbE9wcnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΑфъΩβΩκκ():
    value = 813887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyawaUcP7Z0FaQq3zn6fZxYFyl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СФшысΙЗζρΙΕαфιл():
    value = 408858
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cg6xOEQcp6QqDj2Kz3uzIjYn1Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΚсМОΚδОΣгэдЕ():
    value = 787489
    if 76 * 49 < 0:
        pass
        927
        pass
    text = __import__('base64').b64decode('T2djNUNLcTgzZU1DR3ZUbTQzS08=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦЧКаΘΔДοΧМЙПΔеελ():
    if 55 * 100 < 0:
        pass
    value = 378447
    if 65 * 19 < 0:
        396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhXpY1YTq4slMh7y40CkAgsgxVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 24 * 16 < 0:
        pass
    return total

def _οиΗωψфΑпи():
    value = 627681
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyfPWkhpz/kXMBqx8HigLXQ2/V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6159 = 679
        pass
    return total

def _оОεΜδрПρρиПЮΠλσж():
    value = 195443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRu9NwUQ2/4vLSGxxWnGYws361s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψеЗΩыЪΗηΧΜψ():
    value = 315345
    if len('') > 0:
        645
    text = __import__('base64').b64decode('c3FBYXpGdzBRWnNudVY3NFFJSDk=').decode('utf-8')
    if len('') > 0:
        _dead_2172 = 304
        _dead_7912 = 341
        _dead_2267 = 794
    total = value + len(text)
    if 47 * 28 < 0:
        _dead_7767 = 964
        272
        587
    return total

def _σξξγΖΞλΔШ():
    value = 215379
    text = __import__('base64').b64decode('cjR3SUFBU3pJTmhRbXNsd1IzNE4=').decode('utf-8')
    total = value + len(text)
    return total

def _УкπэμбъΧ():
    if 77 * 51 < 0:
        _dead_9272 = 510
        777
    value = 731456
    text = __import__('base64').b64decode('SU1zWlA4NU5yXzJJdVJHMnFoSjY=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЦΥКЯфЮΓΚψνОА():
    value = 912730
    text = __import__('base64').b64decode('TVlHVmFzVzEzT29LSW1hVG9uTkc=').decode('utf-8')
    if False and True:
        pass
        587
        _dead_9574 = 597
    total = value + len(text)
    if 2 * 67 < 0:
        pass
        _dead_1381 = 409
    return total

def _хηωοοΠΚξщхοУв():
    if 75 * 8 < 0:
        745
        910
        pass
    value = 548502
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICr2OG4q65g6BV6nxV2lPnd55zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        347
        pass
    return total

def _ΖτЦφψΗЕοш():
    value = 933966
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB7hWFdu340kHj+2w1WkFzEQzFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΞКΔΗΕΛжюΣχлΟййУ():
    value = 954450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzrdZnsey7lUEjWh3GHHBC0V4n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        43
        pass
    return total

def _иΙΓгмФφРаΚЮждНГп():
    value = 810367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACXVPmcU1qACCyqgx2bALi0JtlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШСвΦъэКыйЙаЦηχСΤ():
    value = 377486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgrhRwQeqIcUPRuimXeeMTM79z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦдвьΚпЩЗΚη():
    value = 126160
    if len('') > 0:
        pass
        _dead_3358 = 672
    text = __import__('base64').b64decode('WVQ3RGZ6d29RY1FTQ0tVdjlkSWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ХфΒТэьАжСΔ():
    value = 524017
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR21NwUa75cRMTan4F+2JgZ8yjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лγΨНΒΣаΡж():
    value = 143111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHvhVGk21YMZMia0ykyiCwQd12c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _умВыΗшΑЮмяРЗ():
    value = 756783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSr3OAM/1r8MGwW3/F2/I3QB3nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΞРμρзоДδΗΛ():
    if 64 * 25 < 0:
        pass
        819
    value = 425972
    if 23 * 36 < 0:
        pass
        _dead_1977 = 588
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky3vb3JqrJxbaiizn1GkBwgXt2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 84 * 23 < 0:
        _dead_2899 = 118
        _dead_5889 = 895
    total = value + len(text)
    return total

def _υнъъΝσΓοДΞФχБκ():
    value = 886571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn/mRXtg6qoHHQeh+1iBHyIQ4UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨЭбАΝΖωЭйАмΩЪхΑΖ():
    value = 979755
    text = __import__('base64').b64decode('S0ZzUWRUVmJ1aHVnZ3lyRk9IVWE=').decode('utf-8')
    if False and True:
        _dead_2976 = 585
        _dead_4782 = 291
        _dead_7366 = 704
    total = value + len(text)
    return total

def _жфЖθζΨτЯщтгΖΑЪοМ():
    value = 936773
    if len('') > 0:
        _dead_4439 = 703
        _dead_6917 = 823
        pass
    text = __import__('base64').b64decode('UVAycldFZlNUOW5KY2xFM0dreXk=').decode('utf-8')
    total = value + len(text)
    return total

def _юξфНυΠΗΔЭκΡИЫ():
    value = 287444
    text = __import__('base64').b64decode('a1k1WXF5YXg5TzA3WU1LNGVPcmo=').decode('utf-8')
    total = value + len(text)
    return total

def _нΡσьСΦРλΡ():
    value = 97549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARDMb3A7+74PFwXxwkyYDB8NwGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βθПмМтшЩЧΖβΟЩ():
    value = 896205
    text = __import__('base64').b64decode('a0JhenBGNWJ1RHI4VXpLZlkzZHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΤяиМбэμнЭпЯМнГЬ():
    value = 884261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBbsNkAyxPovNlf2/G69HBYr3kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВχςλΦАаи():
    if len('') > 0:
        455
    value = 786382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3nGY1QYyIsQCRen5mm0EQ4E7HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔαЖтχржыΓαИλжд():
    if False and True:
        pass
        pass
    value = 167357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgmyREdtyo0MDj+Z0nvCBSM5yE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 87 * 35 < 0:
        223
        pass
        217
    total = value + len(text)
    return total

def _яИЩΟαПЕΓρТмΝω():
    value = 974501
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nze0YVcA04EqDVeAzE+BGi036G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 59 * 17 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ΩεоΟВτЩкνΞЖδθуΟ():
    value = 267812
    text = __import__('base64').b64decode('TlU4bUU4cm1xel8wU2VzaUlLNEc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _чρςΜМσжт():
    value = 506190
    text = __import__('base64').b64decode('YXhacWdheERENDlCaG15bVVlUk8=').decode('utf-8')
    if 40 * 31 < 0:
        979
        _dead_7512 = 1000
        pass
    total = value + len(text)
    if 30 * 45 < 0:
        pass
        922
    return total

def _КРΞкайΤЙ():
    value = 317088
    text = __import__('base64').b64decode('THE5SHUzTEFkcDJmX2ZsTTY2YjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛρицЧкΧЬГНмαтй():
    value = 373757
    if False and True:
        382
        pass
        pass
    text = __import__('base64').b64decode('ejN5bmNDR3M5SVRhYTZPa2F0d0U=').decode('utf-8')
    total = value + len(text)
    return total

def _иЗРΨкХθΧфΚжрэΔГ():
    value = 735652
    text = __import__('base64').b64decode('Y3l2MmoyRWxIOXBCNVJDcEZhS1E=').decode('utf-8')
    if 5 * 67 < 0:
        516
    total = value + len(text)
    return total

def _ςξБξФΑΖж():
    if 69 * 18 < 0:
        _dead_5000 = 491
        418
        _dead_1333 = 913
    value = 291064
    if False and True:
        pass
        936
        _dead_7492 = 668
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBbxTwRv7vkOC1+6kUSVDQMLzk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6805 = 556
    total = value + len(text)
    return total

def _уΛУСζΙпΗЗа():
    value = 212921
    text = __import__('base64').b64decode('TVc4eUpIUFQxWVc1T29weXNKajc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        886
        pass
    return total

def _нζΑОлΚХчИ():
    value = 742219
    if 79 * 5 < 0:
        988
        31
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DinhV10x0KNXPDum3g69P3AHz3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5751 = 452
    return total

def _РσмςккΜлυЦзΘ():
    if len('') > 0:
        _dead_1843 = 939
        _dead_4765 = 414
        _dead_1177 = 975
    value = 60612
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESfdSkAz//EgEFqJkGG3PzUV9j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6282 = 859
        953
    total = value + len(text)
    return total

def _ΜнМλλАъСаνЖПν():
    value = 949497
    text = __import__('base64').b64decode('d0VxRTJhbnYybVZXZEViMDVlZ3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕЙЖВДΨнπъδΑζдλи():
    value = 269183
    if 31 * 49 < 0:
        _dead_4263 = 41
        pass
    text = __import__('base64').b64decode('VkRBTlVwcGYyME14VUxKbUEyREw=').decode('utf-8')
    total = value + len(text)
    return total

def _μсэΡΑλζЮ():
    value = 56641
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQv3T3Y4zb81HAqz/wCXJjB/1F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыьυМлроцτΩиЕЖЪ():
    value = 893473
    text = __import__('base64').b64decode('elJpel9JcW5JYmtXME0wb01tUWo=').decode('utf-8')
    total = value + len(text)
    return total

def _γСΙФμчΤτзЛθΗ():
    value = 894043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DC3ybEgt7JcaMhqR+QTAEgkH9WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗйМЪфКчΣΔ():
    if len('') > 0:
        pass
        _dead_9706 = 699
    value = 177599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX3iOXlo1JcxPR6I5GKHITEq5W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЮοЮχΠдъοчΜΥмЙΦФ():
    value = 870060
    text = __import__('base64').b64decode('alhoTkVQUEVoZHhvUkpIdTh3elU=').decode('utf-8')
    total = value + len(text)
    return total

def _уТбΧщζРШΘАςз():
    if 29 * 52 < 0:
        _dead_6627 = 510
        276
        pass
    value = 310796
    if False and True:
        _dead_6034 = 488
        pass
    text = __import__('base64').b64decode('bUJ4X2NzazlsaWM4NHZwWThkX3E=').decode('utf-8')
    if 84 * 28 < 0:
        pass
    total = value + len(text)
    return total

def _ΝъЩЦКΛΞГΟΙΧр():
    value = 554622
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASndb0ES6IRUagqgxUOVDCYf8GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4096 = 476
        pass
    return total

def _ГжпТпοтзоΘжΚдΕ():
    value = 57529
    text = __import__('base64').b64decode('anVnNXd1dDZPNUxMX3FpcHVaSlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ыЫΩВдъκνξюэщλ():
    value = 580007
    if False and True:
        294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDzmbEE9x6ZSbVe2kE+zYREFw3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 59 * 85 < 0:
        213
        pass
        130
    return total

def _ζЗШΝаΔΠш():
    if len('') > 0:
        pass
        277
    value = 900495
    if 55 * 29 < 0:
        315
        _dead_6140 = 977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzzDRXwzy4BSby6Sn0+ZHQcdsXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йзπΦЮυрζГтН():
    if False and True:
        pass
        pass
        pass
    value = 348347
    if len('') > 0:
        292
        pass
        pass
    text = __import__('base64').b64decode('STVJMGlPNGNOWmVnbjNHVEdmN0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕъЬТчБЬΨυАΙЗаЮй():
    value = 421218
    if False and True:
        _dead_6450 = 257
        583
        pass
    text = __import__('base64').b64decode('Z3JLeTJZQ19EM2VyaGx1ZzdxcWg=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_2537 = 959
        703
    total = value + len(text)
    if 4 * 37 < 0:
        _dead_7096 = 153
        _dead_3301 = 945
        pass
    return total

def _йЪаτΓψκςтσιБβΞдΘ():
    value = 529436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABXIYHwy1405CCua73mDLRN67mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сειиχΚЙρλпЫиβ():
    value = 22419
    text = __import__('base64').b64decode('UU5IeTg5Q1VuMm1pUWt0MGEwU2I=').decode('utf-8')
    total = value + len(text)
    return total

def _υоΛΥТьЛАΩΡνйй():
    value = 704892
    text = __import__('base64').b64decode('U003S0t3b3dDRjJlX21aRnlrYlI=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        768
    total = value + len(text)
    return total

def _хПэШσΖтзΠэρΤбςП():
    value = 975136
    if False and True:
        964
        953
    text = __import__('base64').b64decode('UHdfVEw3dUxWdUpFZ05IVUxiM18=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΘдпзΗБοЮусЦжαφ():
    value = 832144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dg29VFk37Z8gE1mN8E6cIQd4wl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЫщΚτрρωЧыβГйΚР():
    value = 822479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHjsO14vrZsBPxyLxn+RIjMNt10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υЪБВТπμИ():
    if False and True:
        pass
        pass
    value = 948104
    if 90 * 48 < 0:
        pass
        pass
        _dead_2773 = 903
    text = __import__('base64').b64decode('TVBXaVhJb0JwVWh0bUxJdnIzbEE=').decode('utf-8')
    if len('') > 0:
        _dead_8647 = 579
        396
    total = value + len(text)
    return total

def _ХхжμммδВЗвнь():
    if len('') > 0:
        _dead_2208 = 664
        _dead_4489 = 722
        pass
    value = 169997
    text = __import__('base64').b64decode('bWp3SVl4UTZsTmYxMlpMdnNZdjY=').decode('utf-8')
    total = value + len(text)
    if 86 * 25 < 0:
        _dead_8316 = 215
    return total

def _ыГртзςρцДсΩжщ():
    value = 612624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTf3Q2cN+4sUIha053y3IzMgx00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙФТΔΕπΚЯыкТΚΗБцα():
    value = 740119
    text = __import__('base64').b64decode('Uk1IT3lBMW1UdnY5S0M1TGdueTE=').decode('utf-8')
    if False and True:
        _dead_4235 = 783
    total = value + len(text)
    return total

def _ΑоυрΣλЙмΥΖΓΒЗΛ():
    value = 54694
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCbQYGIRp/lQbguaxETCZwgH53g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _νэъΗгηщλЯчАц():
    value = 696513
    text = __import__('base64').b64decode('akIzQzhQX0JfaDFic1JJVzFIMTE=').decode('utf-8')
    total = value + len(text)
    return total

def _αЧсиУЬЭаΙθΕ():
    if 12 * 32 < 0:
        _dead_5210 = 925
        _dead_3873 = 893
        pass
    value = 496603
    if False and True:
        pass
        _dead_2197 = 380
        _dead_9973 = 736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bw3JXFxt2KwobSu04XvBInQq52A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьЕщщЧииЕΟρΘΜΟ():
    if 4 * 3 < 0:
        446
    value = 371152
    text = __import__('base64').b64decode('Z0pDV1BEZEtMQkZsUXdwZjN6Nnk=').decode('utf-8')
    total = value + len(text)
    return total

def _нФΔΩΒршврщСЗЫ():
    if False and True:
        _dead_9464 = 694
    value = 95412
    text = __import__('base64').b64decode('VTJaTjlQX19WX3lkYkVYY3BPX2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛюЛЙΗωηΛ():
    value = 177154
    if len('') > 0:
        _dead_1654 = 377
    text = __import__('base64').b64decode('dTJpZHAyNUN5UjRSQmtYbFB0ckI=').decode('utf-8')
    if False and True:
        pass
        _dead_9262 = 387
    total = value + len(text)
    return total

def _НУЯъыДЯυφγдШУьнΔ():
    value = 590870
    if False and True:
        178
        _dead_5954 = 93
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTyxdAYb1os8GQix8G+IOhMitzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЦяζшΒτЬνэрΖ():
    value = 821657
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iyz+VHAdy786LQ63/Xy2Myt4wXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТНЫΒψξπДα():
    value = 535460
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSLlOH9uzoU3a1aR0ljBOCML6Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑгαπсφτζΝнЧ():
    value = 296398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MivBO3QpyZooADuhmG/JNTJ/9WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΤεχμДуИΝуχхς():
    value = 683808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ljvxd3krrYxWFjD7xl6cGD8hx1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψСιχοиДНЙАС():
    value = 63858
    if 2 * 91 < 0:
        621
        _dead_2764 = 615
        _dead_7004 = 285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzXTeGUP8v4tFV6wzGOnIXAivHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГωφжюТΓФςЭнΙлхВ():
    value = 82769
    text = __import__('base64').b64decode('Q1ZfVkxpdHNrWGUwZ21UYUk1QlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦлыжλΨоτφЖψЦЖЖЧ():
    value = 521051
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IirTbGkszY0RDxWgm1jEOjUa40Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОпβагТωΦΔης():
    if len('') > 0:
        338
    value = 607960
    text = __import__('base64').b64decode('emNtbGhuT1ROZkhta21vY1VhUlI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЯБωнΕΥУБ():
    if 1 * 65 < 0:
        715
        _dead_4285 = 788
    value = 848634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQDgbFcW3JhTNBeEwUK+OiAAtXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уξаТβλйΓΑΣа():
    value = 338365
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXmxSlMj2qkpP1+740yJYRUD7Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1040 = 829
    total = value + len(text)
    return total

def _ΓσφЯХАжЦЖκуΤ():
    value = 212335
    text = __import__('base64').b64decode('emxVRjJkNk5ENm1ZeXFrNDM1emY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓиοΞλцэπцЧМчЯεФ():
    value = 102421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nyj8ZFUa3602FguZmwK9MAsD0Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        997
        pass
    total = value + len(text)
    return total

def _ВЫχΡцЧнВЦζЭлΠДх():
    value = 361590
    text = __import__('base64').b64decode('QTVhUEF0WEI2QlZNNjRHVGRtZ1o=').decode('utf-8')
    total = value + len(text)
    return total

def _σЦοцдаОНΨ():
    value = 841063
    text = __import__('base64').b64decode('eDd3TG9VVF9oaTFWel94dm5PVjA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥэвФκуБΜσμ():
    value = 890710
    text = __import__('base64').b64decode('REczSTFBSXV3YVB6M0J6RjJUWlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΧдЖЖБΔλ():
    if len('') > 0:
        pass
    value = 330886
    text = __import__('base64').b64decode('Y01vNUxiaHlUNVZjNkd3ZXBiMzU=').decode('utf-8')
    total = value + len(text)
    return total

def _щЕзΣсЯМф():
    value = 363734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj7RPQM62/k2MSWW7XKoYg45wWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦзΑηКЧцφΘτλ():
    value = 157667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jnj1aGIywZ8Ja1vy4HGWZQQp82s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 72 * 83 < 0:
        0
        _dead_6666 = 748
    return total

def _щуΧΚΗΩбЕДΔ():
    value = 967812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCXpTVUBqJ0iaDyn31u9IyQ5414='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЭьБΧςεπΔνЫГΗε():
    value = 216761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBvoa0gB16oSbj+wwFSBY3Ec9Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιВΣΦΚтΗΛΑ():
    if 64 * 10 < 0:
        pass
        321
    value = 366878
    text = __import__('base64').b64decode('TUh4X0RkWGxuSHNnTUdzWmUzZHQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1128 = 470
        pass
        499
    return total

def _нΠеьхэЙоЗμαφ():
    value = 758907
    text = __import__('base64').b64decode('T3djMkdSU1JhOVZRWmV4VVlNaEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥзΠФЗΡοЯЬΔΤД():
    value = 603829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3zKen0azaQXNweizF6RYQ0n/TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΧлрЖТбъοьΨΘм():
    value = 138717
    text = __import__('base64').b64decode('ZDNQQTJsMmJrNXp4QU9IR184WFA=').decode('utf-8')
    total = value + len(text)
    return total

def _υкОХьрΜдкσПнςΚи():
    value = 396905
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhDgV2g4yo8OAjWLxHHGOA0rwEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9652 = 813
        _dead_1529 = 211
        _dead_6249 = 814
    total = value + len(text)
    if len('') > 0:
        842
        89
    return total

def _ЧчΒχЭθвЧ():
    if 2 * 71 < 0:
        48
        28
    value = 328868
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiWyd1Jq+f1SCwqH3QXJJhoGtUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыфэкΒПяяσψбЩю():
    value = 314455
    if 19 * 81 < 0:
        pass
        774
    text = __import__('base64').b64decode('VlpCeG9QSXJlV1NPSFFqM1dTUkE=').decode('utf-8')
    total = value + len(text)
    if 1 * 92 < 0:
        pass
        pass
    return total

def _αΖΡΞжЪМΠфεХεΛД():
    value = 616377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwTxPHsQqf9WCliH/U+zHAYq1jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫоДДыχЖф():
    value = 6175
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pw3uN248zJ5aEwj290eeNgwW12E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υЗΕΥыΖψψΞ():
    value = 542366
    text = __import__('base64').b64decode('YUtVVzlYUVdqaGNESWZKUGhycnc=').decode('utf-8')
    if 78 * 22 < 0:
        pass
        _dead_1722 = 260
    total = value + len(text)
    return total

def _χпЬМθымρΜМξτμΤ():
    value = 151525
    text = __import__('base64').b64decode('ck5uTUJYU0dfcjBvNmVlQnI4bmg=').decode('utf-8')
    if len('') > 0:
        pass
        975
    total = value + len(text)
    return total

def _абОйШЧαЧΒ():
    value = 959446
    text = __import__('base64').b64decode('Qmt1Z2xLZW5oMmVPZXl2TTVtOFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ωадсбртο():
    value = 422319
    text = __import__('base64').b64decode('VkdJTmYzVTlnWVdnM25EOGVpbmU=').decode('utf-8')
    total = value + len(text)
    return total

def _τЩпλШГьΟ():
    value = 738896
    if False and True:
        pass
    text = __import__('base64').b64decode('UWRTRXQ5UWlkU0pUTkR1WG5TZE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЖпаАγшβзδыνкнЛ():
    value = 266605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cjb+RUML7f9VEziI6kCcPCIjw3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧДхДωоπщсο():
    value = 90690
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQnRXlhqr7gvIjWC237AZHIGzHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣΟФΨΑфΓшζхфΨЪШШ():
    value = 946466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fn7RXEkDp4ssCl/7/wO/DQsDwXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρэνΗКтэИθΠдΑЬе():
    value = 216394
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSfyam5trYYpOQ6UwECaNRYZ/T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΔРВНфδЪφцшдьЗЪυ():
    value = 37039
    if 10 * 40 < 0:
        pass
    text = __import__('base64').b64decode('aGxuYTF5RzRyY1JXX2lwQjUycEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΠаЪνъβкνНХЦС():
    value = 247208
    if 70 * 95 < 0:
        321
        pass
        pass
    text = __import__('base64').b64decode('T3JQTUN2MV9wMThhQlExZEFJcW4=').decode('utf-8')
    if 83 * 23 < 0:
        _dead_5820 = 977
    total = value + len(text)
    return total

def _ШНχЭΔжЫуΡχΙ():
    value = 296916
    text = __import__('base64').b64decode('YXBBZ3NSREpBbGc1OF9rYnNxbWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if 53 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()