#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ЬЩлνхБχεΖτчеГΓ():
    value = 438161
    if len('') > 0:
        _dead_7541 = 96
        672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAWzYXcNz603Ax2o8HyBEywm42w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εеПпТфЙδΕощФВ():
    if len('') > 0:
        _dead_7305 = 610
        pass
    value = 130621
    text = __import__('base64').b64decode('TmVlMFZwT2dQNjRBVWlqNlExSms=').decode('utf-8')
    total = value + len(text)
    return total

def _кγЖΝψυμφΕАΞθυΥп():
    value = 801592
    text = __import__('base64').b64decode('cnZDTlRGeDN1UnE3c3E3OWxnYUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔβЖРμυгьζβΝλЮξЬ():
    value = 866164
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnbCe3o95qFUFVipxGmDPAoM7mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡЕЧГуШΩΧгΚ():
    value = 806933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwC9QQgR/4wsAyGawXOXZg816nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 96 * 10 < 0:
        _dead_4089 = 823
        125
        _dead_5490 = 593
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _УуρδυηЫπΠ():
    value = 37809
    text = __import__('base64').b64decode('QUR4aVg1TGxvVFBmVUZIM0JGZ2k=').decode('utf-8')
    total = value + len(text)
    return total

def _БвОФΞяМПЛ():
    value = 284290
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('RVNlZDJ4ZXRQTEZzSWNmVlpoR3o=').decode('utf-8')
    total = value + len(text)
    if 7 * 39 < 0:
        28
        998
    return total

def _чЩЛМмКχРйпфΟг():
    value = 983372
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCrzb2UbxIkZbxuw+n/DZBo5sn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 6 * 55 < 0:
        _dead_3252 = 259
        pass
        846
    return total

def _ЩΖншΦκЧДМОΧЪыдξ():
    if False and True:
        pass
    value = 650952
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kn33YmsS+44UNS76/g+XBA457WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩвЯρмΕАΞλ():
    value = 804871
    text = __import__('base64').b64decode('cWUzaWR5QmpzSGFqWENoVzhVX0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЩУнοлЛЕξЩ():
    if len('') > 0:
        _dead_2559 = 991
        197
    value = 206959
    text = __import__('base64').b64decode('SGxpSFpOMmlIMmNmdzN0aHNlVjc=').decode('utf-8')
    total = value + len(text)
    if 65 * 52 < 0:
        _dead_8723 = 988
        141
        896
    return total

def _ηзΓОЗθΓв():
    value = 790549
    if len('') > 0:
        310
    text = __import__('base64').b64decode('UnU5ejBLdmh5YWJ3WVRKdUdEbFg=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _χЪсйξΩещЧ():
    value = 919985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwnvOV4TzYUlbRWX/mHFJw946WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΧθШЫФХωшφЪΧ():
    value = 949057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSDvW2Y78pAoBReT0UyUYjc96mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПζаУээеЮ():
    value = 12001
    text = __import__('base64').b64decode('UEtpTzR4S1B6ZFYyMldPOFpUUVE=').decode('utf-8')
    total = value + len(text)
    return total

def _юшнНΟοΘЩАЧН():
    value = 341388
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiToWFM00IkQHAiax2a/LQ5/vV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηЯψρшЪЬΔТЗЕжюК():
    if len('') > 0:
        pass
        111
    value = 677776
    text = __import__('base64').b64decode('T1FCaWFNV0dTYmIxTGFUYzJPYUg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        473
        pass
        pass
    return total

def _ΡяΦЗωγТл():
    value = 187551
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky3KO2cp9qoFDja6+1CkNg0k4Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аςКΡоξфЯЬщЕмУюζΛ():
    value = 235109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSzdXX47qrtVN1e3mF2TMT8itVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΤйкπйяжΜъζЗΟΛ():
    value = 895739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQ7jb3kT654oDSGg0FKAEQsCyzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭеΙИςЖΟεВЖЧ():
    value = 151439
    text = __import__('base64').b64decode('Wk40cmRWVkRjaHhCbjh3V3dydG8=').decode('utf-8')
    if 60 * 9 < 0:
        451
        50
    total = value + len(text)
    return total

def _ФΠαρоыνΡйςиο():
    value = 622250
    if len('') > 0:
        828
        pass
        _dead_3657 = 783
    text = __import__('base64').b64decode('ZER1RV9reVd4TnJFRldyNVNHTng=').decode('utf-8')
    total = value + len(text)
    return total

def _φΥНзΕиσψБКЪУΓΥю():
    value = 767122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByfPZWYQ+oA5BSvw+l+KO3YL1U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥЙциХянЬΕ():
    if len('') > 0:
        _dead_6393 = 959
    value = 644616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyW3bXxoras3KhWH8VGxHSkZ00M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θλШыβхоΥйгΕςν():
    value = 618006
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyLuS3o604sNLQWo20yRYQZ51WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βθισςяЬΤεЛΨω():
    value = 981081
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3/HN2cxx6cuLTm6xVudOBMAxWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мρщъολΦпιуз():
    value = 229382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDXxRwQ9zPoWaCKO3GTHHi4ZwUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4235 = 514
        _dead_8721 = 962
        _dead_3016 = 723
    total = value + len(text)
    return total

def _СεφйΚгрτΧρ():
    value = 173176
    if len('') > 0:
        pass
        364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyS9Y0tv64MpODe1y1qSOD8r8Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_7946 = 626
        pass
    total = value + len(text)
    return total

def _руφхςяηфεмтЦ():
    value = 349084
    if False and True:
        322
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgbTb3kcqLIzMliIm1iJZBICsHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞдυяЬТъΣДЯχνω():
    value = 268358
    text = __import__('base64').b64decode('bjRDQ2w4bEE5ZkhCcTd6QzZiaTc=').decode('utf-8')
    total = value + len(text)
    return total

def _заκργΣΓΟχΘΘМНПυ():
    value = 482372
    if 91 * 37 < 0:
        _dead_8409 = 527
        746
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mnq1S3AI3LspKx6l7kGvIxIi6E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΩякЙыъΚ():
    value = 82616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyfrQH8XrYEzCx+F7W+9BSYa1k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЕЗμΞяεс():
    value = 892340
    text = __import__('base64').b64decode('TGlEZDQ1UmhXR0Y4ZG03UUg3Rkw=').decode('utf-8')
    if 92 * 43 < 0:
        pass
        _dead_3986 = 747
    total = value + len(text)
    return total

def _оΠΓκшЫКсΛγΓКΜъц():
    value = 30755
    text = __import__('base64').b64decode('ZllJVnBFa3ZqWUZld1dYeGRMWEo=').decode('utf-8')
    total = value + len(text)
    return total

def _яюΦрσщшуЪеЦ():
    value = 283649
    if len('') > 0:
        _dead_2255 = 321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQKxa38LwbELCCasnALGNS0cwEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 3 * 77 < 0:
        _dead_4157 = 532
        pass
        _dead_1385 = 746
    return total

def _гкыΤИΡФц():
    value = 2421
    text = __import__('base64').b64decode('dTBtSUFNSVRGZUVBYkJKbkRIY3o=').decode('utf-8')
    total = value + len(text)
    return total

def _μЭΡΞЭρΩωИйς():
    value = 547569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx+9Q3Q81Lw3BR/67HugNhQatn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧχХРЧθμЩΠΞ():
    value = 308646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQnnSWcT7LA1NyuG5FiDDCk/3V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 23 * 65 < 0:
        566
        536
        207
    total = value + len(text)
    return total

def _ОЦОαТψРойАщ():
    value = 590343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxX9QQkdyIMnbSKLy3WTLRAky0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        985
        pass
    return total

def _ΕλΘуюЦυЗЙλыβИхл():
    value = 727121
    text = __import__('base64').b64decode('emhjYzBRMGVzazZXbGZpMTFtcHI=').decode('utf-8')
    total = value + len(text)
    return total

def _РΔИΨΔνОЬН():
    value = 20418
    text = __import__('base64').b64decode('T2dBbktIUlpJVThEdzFvcWZZV1I=').decode('utf-8')
    total = value + len(text)
    return total

def _СшЧГфαοьищο():
    value = 912944
    text = __import__('base64').b64decode('UE9wSzdRZXcyalZINWIwRFpNY1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ВЗФшΖθиюхрΤχ():
    if 72 * 5 < 0:
        pass
        5
    value = 62738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSqyelYt9IYkDzeP7FrALiZ94UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 39 * 53 < 0:
        _dead_4245 = 451
    total = value + len(text)
    if len('') > 0:
        _dead_7895 = 105
        pass
        _dead_7978 = 909
    return total

def _аВупΣцыКλйМ():
    if 48 * 47 < 0:
        _dead_2098 = 932
        _dead_4547 = 296
        pass
    value = 143604
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('eDJSWlUwd1ZPR1YyT3AxVFBOa3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗлΕФЩАВοЩАΜγκΟЩΙ():
    value = 242216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyH8fVcg2Y40aCiGyVCINTYFvEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИЫхзЫцΥΣ():
    value = 385743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSS9PWQ9zP9XOAuq+geFLiAK3GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕйЦБытηсОдςΕ():
    value = 809589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzXdfns/8KwVH1iK3HjHHQt20Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        538
        _dead_5728 = 296
        pass
    return total

def _ыξνПΜтΝΡΝΨ():
    if 90 * 54 < 0:
        pass
    value = 288192
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzmzY3s9+Y8TFgKh6U68PC1811E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        184
        _dead_3589 = 841
    total = value + len(text)
    if False and True:
        120
    return total

def _ДηΡЭьΦпφвРЗЧЮχ():
    value = 67202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyH8O1wJ87oWCTiH4WnEGgB83Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РзУЪОьщχΨУщуе():
    if 80 * 63 < 0:
        12
        170
        pass
    value = 611961
    text = __import__('base64').b64decode('QVFUSTRLUWtaQ2RJQ1VvTWxuRU0=').decode('utf-8')
    total = value + len(text)
    return total

def _иΝъсЖГΕνУΓΠοΟ():
    if 52 * 52 < 0:
        114
        587
    value = 713846
    text = __import__('base64').b64decode('RDQwUVI3VHFFVklNOXBzRllvbGg=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΔыμХуЯИЬЩΛЗΞ():
    value = 21724
    if False and True:
        816
        235
    text = __import__('base64').b64decode('YWp0RU5wdnNfek5iaUw4QVliZ0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΟйΙΟещпΛο():
    value = 346944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSL9RFYO9YwobhyNnUWaAy0k1D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρбЛпОыъЗкВυ():
    value = 452803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwHeUWEu54wKIBuAxQGeIwsqzno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        663
        _dead_7492 = 705
        pass
    return total

def _ΞеδоОУσИЬиЬ():
    value = 489797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCzUXgMR7/EyCDyz2g7CMSMMwX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σχЮωρЛЙаΤыδ():
    value = 558505
    text = __import__('base64').b64decode('YzhQTTRLUFo5cmttblVXVV9QR1o=').decode('utf-8')
    total = value + len(text)
    return total

def _щКЬЗΩЮжЫβжшЗΑЭ():
    value = 721746
    if len('') > 0:
        pass
        24
    text = __import__('base64').b64decode('cWhEanVfV29pM21Za0NBekVYYWo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        638
    return total

def _АχκδьнΦЪ():
    value = 740672
    if False and True:
        _dead_9642 = 798
        913
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LATnTEcAwaI6ajy392/BJHAW22c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕοιзζωЦΝσδΗГг():
    if 8 * 5 < 0:
        287
        633
        pass
    value = 434885
    text = __import__('base64').b64decode('dEg5c3BxUWNRTm8xdHY2V1dHTm8=').decode('utf-8')
    total = value + len(text)
    return total

def _υωБЭΠχИοту():
    value = 981630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhyxN0Ms/f00PQq3y2LBbTMK12I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΠΒюВΚХаЕαπщ():
    if len('') > 0:
        _dead_1438 = 651
    value = 762516
    if len('') > 0:
        pass
        _dead_6781 = 740
    text = __import__('base64').b64decode('WE5teG80ejRJNDhWeVZvY1FfdGw=').decode('utf-8')
    if len('') > 0:
        767
    total = value + len(text)
    return total

def _ЪфαгзΒпБςыПх():
    value = 103023
    text = __import__('base64').b64decode('b00zenpBQnlaNjcxeWJvdzNDb0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΛЕаψхЭрκьдВцд():
    value = 67787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhzKXHwXr6RUIz/253DGHHcY70U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        36
    return total

def _ЧиЯΛпмΩΝЬθИΤККН():
    if False and True:
        720
        pass
    value = 999385
    text = __import__('base64').b64decode('ZkpFV081aGlpMzJPdVpHYWcyTkg=').decode('utf-8')
    total = value + len(text)
    if 75 * 98 < 0:
        pass
        841
    return total

def _λΓοШЙΨаκηε():
    if False and True:
        _dead_6754 = 833
        _dead_4859 = 841
    value = 454235
    text = __import__('base64').b64decode('SU1sY2tFRjdGd0hJTWxNNGNlamQ=').decode('utf-8')
    total = value + len(text)
    return total

def _δйоξЛзЕяювШ():
    value = 555011
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB3zZwESzq0mbTWq7nnEEXd2/Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 75 * 36 < 0:
        pass
        518
    total = value + len(text)
    return total

def _ПДЙАасГΨ():
    value = 150101
    if 32 * 43 < 0:
        34
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fgr3WANg5otQOB+JwVWjPS45zWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 81 * 53 < 0:
        pass
    return total

def _ющВлУЮγΗэШ():
    value = 606099
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzzTZFQO//8wNhWnmGGHBAx30Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μшνεΙβЭЖЪΞбЙΥγ():
    value = 621896
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eifbe2QG550uMwCq21uaEAID/FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 53 * 9 < 0:
        _dead_2569 = 623
        pass
        413
    return total

def _ξΛэЭγнΩАЪοПνγΚ():
    value = 935947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwKwSlgJr7AKEiSpnF3BGBAC41g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 61 * 28 < 0:
        pass
    return total

def _λΣΠνЫΡЙеь():
    value = 421976
    text = __import__('base64').b64decode('RE90aWxESlpLcEJEN2xQc1Z6RDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΙОχВΞфΠЙψ():
    if len('') > 0:
        _dead_1188 = 509
    value = 305268
    if 43 * 97 < 0:
        pass
    text = __import__('base64').b64decode('QVhQd0RycXZBcXZuUjBrOGw0SDA=').decode('utf-8')
    if len('') > 0:
        154
        _dead_6388 = 960
    total = value + len(text)
    return total

def _λЙФΑΤΡЖε():
    value = 421752
    text = __import__('base64').b64decode('eW5yNG83TFVEa3pjR2RycmJvTXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЖλΝИΓШУшАЩПγыθ():
    value = 878723
    if len('') > 0:
        3
        214
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ly32PwQawf9aHRWZ4H2BDHE7zkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 75 < 0:
        pass
        _dead_6639 = 131
    total = value + len(text)
    return total

def _ΙΨαфΔχСθΤяΞ():
    value = 269737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iir3eHc/6bIULiGhnUyfFS4b4GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗнуъГοЬΗШγщЯ():
    value = 196274
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQb9N3No/YMBNyv6ygCnISwqwWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΣλυπСВпКΠОъΒюШ():
    value = 792500
    text = __import__('base64').b64decode('TWh4WE1TYmNvcktKUUh6X3lIVmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΗχΒижВхω():
    value = 766462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX/Ja2Eg/6kzACuU6wOeDAkD51s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оСРψзπΦРЗяДσ():
    value = 742997
    text = __import__('base64').b64decode('eGxRY1NOTUpCSFBuOTJzaHhfa3M=').decode('utf-8')
    total = value + len(text)
    return total

def _уΦнШλσΨСΩμм():
    value = 976356
    if False and True:
        _dead_3504 = 387
        700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwXySnsK9r4hDjXy5wCYDTZ+4Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        420
    return total

def _ВζУэΑПρИЗΕЮΗ():
    value = 106695
    text = __import__('base64').b64decode('QzB0X0xFSk1oNHhfQmgyWVh6N0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛσςπΕπщяВσΟЗЮτ():
    value = 961010
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pzi2d0Au8/kINF/z3FyvZhQVt1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        120
    return total

def _ΡиЭδΩπςδЗСФΔλа():
    value = 974472
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhfNXkAu+79VNg6J9weBOgN85zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΟрыΦпΑΜбθς():
    value = 845933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXexNms88bBQaAyr4FiCI3w+xn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩфЯДАзνΙсмΗЕ():
    if False and True:
        pass
        pass
    value = 895723
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHz3fWkc16ImIxeQ5mOzZHUNxT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧаТВζΧοΓЙλΞδΠд():
    value = 122471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fn72S24ayf0KAiGp4QCgJAcE0zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬσЪуεΞыτЭταЫ():
    if len('') > 0:
        70
    value = 528545
    text = __import__('base64').b64decode('SzJSd0hIa3NZTWRjM3BiWHA3TVQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ЭлΣЖКσΨЕЫΨςργи():
    value = 665580
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESnJSHgAq700Dzaz5VmTJgp/11Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑρЖщΕнσςтσ():
    value = 743869
    text = __import__('base64').b64decode('ZHJ1c1VzOU5SRXJCU2IyUVR1c0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΣЧОУχДщ():
    value = 707242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiLrPgQw9pcuBT+mz2HAbQId7Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яиβУΖδЯюΠгЮбУшч():
    value = 23030
    text = __import__('base64').b64decode('blB6ZVRhcldiRmM1Ykw5VjFfZ1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ςΕΥюβεкξ():
    if len('') > 0:
        _dead_2823 = 388
        60
        pass
    value = 980641
    if 31 * 28 < 0:
        pass
        _dead_2382 = 989
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EznMZkVg5K1aCA6cmEehEXIY9E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        370
        _dead_8807 = 806
        pass
    total = value + len(text)
    return total

def _ΑζВнΨтνΔеМЛπ():
    value = 349599
    if len('') > 0:
        _dead_2811 = 300
    text = __import__('base64').b64decode('WlRxeG8xYVNaUW0xTkloY1lhSzI=').decode('utf-8')
    if False and True:
        _dead_6719 = 664
        322
        pass
    total = value + len(text)
    return total

def _ЕЭлзсΧτоЕоЪ():
    value = 213351
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnfQR3QX5/FXLCKT2FWZIBcGx2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хτНъфΥοЛГστТΟΧ():
    value = 107025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCnbOX0P2owxKiL62niYZgIQz18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΗцΙЗΩйзασ():
    value = 828985
    text = __import__('base64').b64decode('Slptc0k0ME9iSW5NY1NORWdubV8=').decode('utf-8')
    total = value + len(text)
    return total

def _τъмΥΓяАзьНΘыΕΧ():
    value = 672834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiPWSmcS8b8qGw203AWvETI91Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эНιНъвζлΛМΗτфνЖ():
    value = 761796
    if False and True:
        _dead_6975 = 821
        pass
    text = __import__('base64').b64decode('aXRQREN2UGRLdTNSWGo4SzVUNTY=').decode('utf-8')
    total = value + len(text)
    if 16 * 96 < 0:
        pass
        _dead_6502 = 462
        pass
    return total

def _ιоΖЪΖВдτπ():
    value = 343183
    text = __import__('base64').b64decode('WlZOeDlLUE13eEhpdGZDczlvMWU=').decode('utf-8')
    total = value + len(text)
    return total

def _υТЫЮхЬЙъРЭфеσΕ():
    value = 778795
    if len('') > 0:
        _dead_5742 = 212
    text = __import__('base64').b64decode('VjVyU3ZsSFBoVUEyR2ZkcVJSTHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒЛчяяρПζΩЕΓчжκи():
    value = 974017
    text = __import__('base64').b64decode('TmdQaTlzdzA2OHlLU3BfU0Z5eEI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5013 = 337
        991
        769
    return total

def _хιьΣСωβэ():
    value = 999058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRjIYFkD76UMEzuq4kGgIykB50M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЕχхХνлАνΓΜδ():
    value = 276031
    text = __import__('base64').b64decode('WDFYcURoU1VYMGdWUWcxcGRJWmg=').decode('utf-8')
    total = value + len(text)
    return total

def _εпπЩΗЗЮН():
    value = 493740
    text = __import__('base64').b64decode('Y2liS1B4ZGRncXZjX2dCNnY5NFY=').decode('utf-8')
    total = value + len(text)
    return total

def _мγσМΧкφγςуΡ():
    value = 212223
    text = __import__('base64').b64decode('TzJRYjBIRjc1WGFQX3NJUEpNS1o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3906 = 522
        pass
        993
    return total

def _ΦβКΒиιΠлκ():
    value = 225060
    if len('') > 0:
        _dead_2201 = 350
        _dead_2821 = 255
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jg20WQEs8Z8TLFir0mG1GhUc4UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 20 * 88 < 0:
        _dead_5835 = 644
    return total

def _кΤДΜσΤэЙБζЩ():
    value = 743892
    if len('') > 0:
        216
        718
    text = __import__('base64').b64decode('YUZZN2xicXNCM0ZnWUVEdm1lRTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔσБыρЫНδгьΧλΝΡ():
    value = 382768
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('QU9yaDNVMzZJb1lnMlFMOG9OTnU=').decode('utf-8')
    total = value + len(text)
    return total

def _πлдЕЬвЫтκ():
    if 65 * 80 < 0:
        236
    value = 86158
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3ztb2g9q6YnMTa14EW0PhAu/mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        314
        _dead_7053 = 599
    total = value + len(text)
    return total

def _ΘьβΘΣΡΠоξчμυ():
    value = 634254
    text = __import__('base64').b64decode('cDFEZjNONEl2ZmJtYWdYZUF2dkc=').decode('utf-8')
    if 60 * 83 < 0:
        _dead_2750 = 971
    total = value + len(text)
    return total

def _ШξГяηЪпДΙμОзкУ():
    value = 667086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JibybFUG8YUqGxuly0W2HBIY9EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝиЫжψΞрλθ():
    if 9 * 9 < 0:
        90
    value = 708412
    text = __import__('base64').b64decode('WTZsY3pLUlAzTnB2S2g2N05wWDQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        203
    return total

def _ЙшРкΕАпμΞтСνξАΒΘ():
    value = 877358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzjsVFotyJcpMQWqmWWBGH0n3EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чγΩΞΕУлΓе():
    value = 685021
    if 40 * 42 < 0:
        _dead_7287 = 909
        pass
        pass
    text = __import__('base64').b64decode('dUkwY2R1TjBXX2lsOEF0VW1WakY=').decode('utf-8')
    if False and True:
        815
        pass
        165
    total = value + len(text)
    return total

def _ярΝцбзсИхμ():
    if False and True:
        383
    value = 20835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bz/tP3cp0b8wACaT7m6FFncl6UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТАσΠΙμПφп():
    value = 91909
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3jNQggUrasWODCc3ACTCyIj91E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΟДцрВФΣЬΘеЭ():
    value = 100313
    text = __import__('base64').b64decode('bmtUNFFGVzR1MlBsYTNnalJFUEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ъωбТΛЙЙσ():
    value = 744985
    text = __import__('base64').b64decode('SU9DTTRad0NpTXAxUkxzeFZMMDI=').decode('utf-8')
    total = value + len(text)
    return total

def _цκээξЬΙх():
    value = 886911
    if 32 * 2 < 0:
        _dead_8283 = 879
        _dead_8206 = 653
        _dead_3819 = 527
    text = __import__('base64').b64decode('TFg5cUYxc1h4R25CRU01SUkwN3A=').decode('utf-8')
    if 82 * 63 < 0:
        _dead_6992 = 505
    total = value + len(text)
    if 73 * 96 < 0:
        _dead_2886 = 725
        840
        pass
    return total

def _ΛΑпΒζΔФДςк():
    if False and True:
        pass
        pass
    value = 438632
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Awi1Ynsgx7IWCSWomXi2HHcLtFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΨаяаςЛΡεяуωЮΣ():
    if len('') > 0:
        _dead_1349 = 590
        pass
    value = 736370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3/jW0s2yfoHDR6t2Ey4HQEgs0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7664 = 755
        731
    return total

def _ЮΣбηβΡДβШ():
    value = 980978
    text = __import__('base64').b64decode('d3AwajRHVmRKUWpUUHYzeWFhMGY=').decode('utf-8')
    total = value + len(text)
    return total

def _υФШъьфЦдΒтσΤЫч():
    if False and True:
        494
        pass
        97
    value = 324751
    text = __import__('base64').b64decode('Z2FkbnAxWGc1N1dRUUhtWGpJbXY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖνПρζρпГτΦМΧΧкς():
    value = 964136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAH2O1ho6LlWEQGZwmadDSl7ymw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭκΣешΜэаЫЕьψ():
    value = 106877
    text = __import__('base64').b64decode('VnFPanoyTHhJbjFuX3VGRmYxN2s=').decode('utf-8')
    total = value + len(text)
    if False and True:
        537
        pass
        _dead_9887 = 420
    return total

def _ΓИΗОоСЬПЭЙфЪЪνΜш():
    value = 475710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBXrWVUd8a8TAAa1kEWBPS8Azm8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘНΗθнЛεЖЧзΘэΥμΛ():
    if len('') > 0:
        _dead_1678 = 163
        pass
    value = 781075
    if 65 * 50 < 0:
        _dead_5400 = 199
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSzDOVkU7rkRAza60Q/DLT0A81Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 68 * 3 < 0:
        681
        pass
        _dead_1710 = 534
    total = value + len(text)
    return total

def _σзΚиуЦэΝК():
    value = 94607
    text = __import__('base64').b64decode('bWFjYVNQTG5pOFg3ZUUzNTVkU1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕФΨπψЙоаτηиβУ():
    if len('') > 0:
        29
    value = 836130
    text = __import__('base64').b64decode('YWFManNEX2E2M09waUl1aE9IVzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΞγЙАΨФлκΞРбΓМγΖ():
    value = 112523
    text = __import__('base64').b64decode('eWJjQmVianhLV3dhVXd0a2RsNHY=').decode('utf-8')
    total = value + len(text)
    return total

def _зμΛъΥдлπИΧПб():
    value = 485854
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT3ba3cey6FWEgyZmXnGZi01xV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΧбαцΞяΙЩЕПви():
    value = 365134
    if 33 * 36 < 0:
        _dead_1425 = 540
        722
        848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERbFa1Q90L9VDyKu7lyoZC06z18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 37 * 12 < 0:
        _dead_4323 = 973
    return total

def _ΑςχЦвъΘΘ():
    value = 797937
    if len('') > 0:
        626
        _dead_6575 = 689
        81
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECX9ZUQ4//8WEymJy120Hy0Oxkg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λсεΦΨгйиΞΖκНΜ():
    value = 974088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mgrda3A68Z5QESWukXi5Fiog3mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШЛлЯхυβΧ():
    value = 58409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAe3ZmAb0PwvDxa0/2GeGRIo1WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θТчилΓиЩшΗυδΧψ():
    value = 221221
    text = __import__('base64').b64decode('eWF6Um1acmFCajU5WFpjaWdwbVo=').decode('utf-8')
    if 71 * 16 < 0:
        pass
        559
        pass
    total = value + len(text)
    return total

def _ΞГвфΦЯАΖшΦψ():
    value = 582899
    if 9 * 74 < 0:
        _dead_5833 = 373
        pass
        _dead_5957 = 670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAXyRwIp0JlSEDz770WzLBc13EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2297 = 485
        _dead_3034 = 543
    return total

def _ΦΣγΖШφХэΡООцвЙπ():
    value = 279105
    text = __import__('base64').b64decode('T05OS2J5MEZzbllxSWVldGwyYlo=').decode('utf-8')
    total = value + len(text)
    return total

def _θЕСΗтМГζн():
    value = 905236
    text = __import__('base64').b64decode('RHhaNmNzN0gxZnhIUWQ3aVZIWWE=').decode('utf-8')
    total = value + len(text)
    return total

def _еυΦЫбΖТхΕНхРзΝД():
    value = 897227
    if False and True:
        pass
    text = __import__('base64').b64decode('STRCNXFLMTdESmhYdXJJSGJkR3Y=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7915 = 479
        793
        pass
    return total

def _ыΩЕφапΣЙ():
    value = 140097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAHHZ3417aIsIAetmkLIMyl8sms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υсξчσШδябΖъΛνρж():
    value = 334163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASvmNmERxKoEbCK3+nixEAYE6Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τнσсγΑСΔЖоωьπΜЙ():
    if False and True:
        800
    value = 822289
    if len('') > 0:
        764
        _dead_9627 = 828
        289
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITzcNmUs+KQtalyA5kfGEBcp9Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 80 * 62 < 0:
        _dead_6398 = 454
        pass
    total = value + len(text)
    return total

def _ΞΟΡυιрИЗупΠНξпдΦ():
    if False and True:
        187
        pass
    value = 804716
    text = __import__('base64').b64decode('ZnZ4Q1k3Ym5HT0NoMVZqdWNoaEY=').decode('utf-8')
    if 90 * 82 < 0:
        290
        _dead_6300 = 430
    total = value + len(text)
    if len('') > 0:
        215
    return total

def _дοбшЩυпК():
    value = 271794
    if False and True:
        pass
        pass
        300
    text = __import__('base64').b64decode('VWRtSVZNWEZzRklQTTlfZDZjQ04=').decode('utf-8')
    total = value + len(text)
    return total

def _τуМЗπаФονπЛΑτ():
    value = 509730
    text = __import__('base64').b64decode('aHJvVnJHSDRPRDZFQ1V1ZEphNjM=').decode('utf-8')
    if 54 * 98 < 0:
        579
        _dead_8879 = 29
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_2484 = 568
    return total

def _РξзВθЗЖΟ():
    value = 938848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgjLQQEKqp8TMV+kmUCzNis59mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чъжθωшъЧοТХςЧЮΩσ():
    value = 6106
    text = __import__('base64').b64decode('d1VXZGdhZk1Ra2c5bXFSemEySDA=').decode('utf-8')
    if 55 * 41 < 0:
        pass
    total = value + len(text)
    return total

def _мψющЭЕЯтιфС():
    value = 498232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NinbVHMg2Y4aaQb3xUOHBX0+xmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 65 * 72 < 0:
        pass
        pass
        _dead_2257 = 570
    total = value + len(text)
    return total

def _уъχΦνκПΠОΖДМνЙψΒ():
    value = 274251
    text = __import__('base64').b64decode('Vmx4RnhjakJmbEhzcFhkTnRfeVI=').decode('utf-8')
    if len('') > 0:
        276
        pass
    total = value + len(text)
    if False and True:
        809
    return total

def _ΓκкдγсъРишΗ():
    value = 262119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PR60eWQe9bIwEgiK+geGMTcByXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        634
        _dead_2994 = 174
        _dead_9534 = 863
    total = value + len(text)
    if len('') > 0:
        _dead_1088 = 522
        625
    return total

def _сьΞТЫдοςШШφοЕХΓЭ():
    value = 156516
    if False and True:
        pass
        87
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCj0YmQ2+owGKQinnV+5ESI21mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШщεВΘЕψГыхъπτ():
    value = 255258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQ3mW3s7za8TKyqlm1LHMhEd6Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΚтОωЧΧжьЗЮ():
    if 16 * 90 < 0:
        _dead_6788 = 884
        pass
        734
    value = 366725
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CT/2b0Ut2qobOSW6mlyBYBQC42o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        994
        _dead_8558 = 460
    total = value + len(text)
    return total

def _ζщΧскνПΔЪ():
    value = 187371
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSnWX0Zt97IJIg6H5F+0MXYJxls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 17 < 0:
        pass
        548
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΚβΟΓδφΛСАпςюУш():
    value = 284144
    text = __import__('base64').b64decode('VWo3eG4wc0MzUmdFQ1RZaUNPaVo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΥЕъΥацΙΥΨφШжА():
    value = 56247
    text = __import__('base64').b64decode('TG1pMktHa0hWUktzOWlObnJrc1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ПζшΡЛМΥΖхфΩΩΕ():
    value = 206808
    text = __import__('base64').b64decode('dUg4Yk16WlJDdk9nanpzV1ZWOHo=').decode('utf-8')
    total = value + len(text)
    return total

def _сσдиЪкСЬιщкφ():
    if 38 * 36 < 0:
        _dead_1367 = 367
        _dead_8416 = 46
        64
    value = 901993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fy7wfgET9vsbGQyRmVS9PwN241E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 52 * 64 < 0:
        362
        _dead_6029 = 893
    return total

def _σАТЖΧΧΩъΗхЕЛσ():
    value = 315471
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyTGbAEjppoCA1z0/ljAEnw+8kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7037 = 140
        _dead_5862 = 331
    return total

def _ъЩΖаТУГνΡяλΦ():
    if len('') > 0:
        288
    value = 683820
    if 28 * 52 < 0:
        63
        _dead_6701 = 949
        pass
    text = __import__('base64').b64decode('dkZud19hY21pa0dWaEljVVh4bkw=').decode('utf-8')
    total = value + len(text)
    if 25 * 37 < 0:
        961
    return total

def _χЯЕчχΧьЯΙзсдсΩС():
    if 85 * 43 < 0:
        pass
        _dead_2444 = 407
    value = 279375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQPBfHkWz/EILwb25ASpbTR3s2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1990 = 148
    return total

def _ΧφςЖδКяЖκяяЧΙяЙЧ():
    value = 994897
    text = __import__('base64').b64decode('VXBvUEJMUElTUjFXRmJ1RWV3WHk=').decode('utf-8')
    total = value + len(text)
    return total

def _РδΜНиОΗпЬСΙΘуГΔΝ():
    value = 599627
    text = __import__('base64').b64decode('c0VaVHBPNmswX0x2VEt3VXl6Tl8=').decode('utf-8')
    total = value + len(text)
    return total

def _κφΟΔΞхщзаψνЦυж():
    value = 476008
    text = __import__('base64').b64decode('ZVpjc0hYM0dZMTViamVnMjI3bnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЭяΨαщΩΦбπУΞσЦФψ():
    value = 310031
    text = __import__('base64').b64decode('TTFOeGRuWmZSb2syQmJNWmpFMDk=').decode('utf-8')
    total = value + len(text)
    if 89 * 71 < 0:
        pass
        283
    return total

def _σИβХδЗυΧТйυΣбι():
    value = 949882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSX0W1423PkHCAyr/luJZw0A4nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПψΤВΥэЕυкΨзπ():
    if False and True:
        149
    value = 324148
    text = __import__('base64').b64decode('al9NVmxZX0VMeEtQYnBUYXBWbmg=').decode('utf-8')
    if 20 * 47 < 0:
        64
        pass
        _dead_7402 = 715
    total = value + len(text)
    if 84 * 26 < 0:
        pass
        _dead_3176 = 209
    return total

def _ΜГΗφΘХΖвζшнслΞ():
    if 33 * 80 < 0:
        pass
        981
        pass
    value = 461690
    if 38 * 22 < 0:
        670
        _dead_9201 = 689
        _dead_4295 = 487
    text = __import__('base64').b64decode('cUx2TnFoQWlBb2tPazlZVXRvRzc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        127
    return total

def _ЩчДВЦιυП():
    value = 59675
    if 11 * 31 < 0:
        399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDfDVnkB7v4FFlmb7H3JbRp29lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 83 * 83 < 0:
        498
    total = value + len(text)
    return total

def _πτьУΛЮΡλУЭιΓ():
    value = 832160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDn0fnhqrpwJF1+B2E+/ICYO71w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤωιПβΑяДαΒ():
    value = 604240
    text = __import__('base64').b64decode('QlR3dkhnNU9CRDlXUzAxbVBlR3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ешЬβГМЭΩзΨΣсеэΠ():
    value = 408541
    if False and True:
        pass
        _dead_4054 = 270
        254
    text = __import__('base64').b64decode('SkdkVXRGaUlrRkZuNkRnbm1VWHM=').decode('utf-8')
    if 72 * 90 < 0:
        66
    total = value + len(text)
    if False and True:
        139
        _dead_4921 = 206
        271
    return total

def _ΩЯθККЖНйεσ():
    value = 398944
    if 73 * 95 < 0:
        _dead_3373 = 7
        685
    text = __import__('base64').b64decode('a1NKWHZjazliV1Zrd2hsbk9UdnI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2002 = 109
    return total

def _ξзσυΕвэλΗЖξ():
    if 2 * 99 < 0:
        _dead_9890 = 593
    value = 96007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRfRUWYu/LgPKyOo4mGjJCcg1G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        579
        _dead_8383 = 343
    total = value + len(text)
    return total

def _эμΟТΜςАПвΗΒυеЧ():
    value = 158920
    text = __import__('base64').b64decode('UnBXd1oxV2VUMTlzbTlkUWFzOUU=').decode('utf-8')
    total = value + len(text)
    return total

def _нгЦтЬэйд():
    if 17 * 37 < 0:
        pass
        pass
    value = 666025
    text = __import__('base64').b64decode('d3owbjZDOXU4M1M5RWJudEJNal8=').decode('utf-8')
    if len('') > 0:
        232
        601
        484
    total = value + len(text)
    return total

def _нΦгЖыцΝΨΞΔγЮйЩΦ():
    value = 530905
    text = __import__('base64').b64decode('c281S3VaNm1WMkN1QVNBZVR0Y04=').decode('utf-8')
    total = value + len(text)
    return total

def _кньЩэΩйДИЫαКτΗшι():
    if False and True:
        pass
        _dead_4997 = 282
    value = 440513
    text = __import__('base64').b64decode('YkZmUnVrMllMYnY2bkoxN0R5b0U=').decode('utf-8')
    total = value + len(text)
    return total

def _λρЫСκНτбРЮДΗο():
    if 90 * 31 < 0:
        _dead_7894 = 381
    value = 183914
    text = __import__('base64').b64decode('WXRSSjRfck9KaElPRFNNVXFjd1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬъοРюшμЕеИχРпΨЛт():
    value = 632637
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxzUY0ce6P87MVqb/lO3IyQW62A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΓэциъЯπφνНйοаΞ():
    value = 334484
    text = __import__('base64').b64decode('RXY0Wk9FcmlCdHo5YXdGT1JySXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΒъбνБэи():
    if False and True:
        _dead_8001 = 287
        398
    value = 373561
    text = __import__('base64').b64decode('dzBhWDdXb3ZsMnRiaWVPVUd0SWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΙзЧΝСΝТъ():
    if False and True:
        821
        pass
    value = 788995
    if len('') > 0:
        _dead_7611 = 290
        266
        pass
    text = __import__('base64').b64decode('TERnQVNOaDJIaUN0aWo2YXREX3I=').decode('utf-8')
    if 55 * 59 < 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_9903 = 287
        pass
    return total

def _ъПΝЖΜтρэΗΚΥ():
    value = 945056
    text = __import__('base64').b64decode('ckFiaFJDSW16QUY1WnhLVUVnWmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        _dead_1644 = 147
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('x') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()