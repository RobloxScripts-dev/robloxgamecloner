#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _гкζΟθбΑΩΥэ():
    if len('') > 0:
        pass
        pass
        pass
    value = 598659
    if False and True:
        _dead_2058 = 674
        pass
        795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABzrTwA88Zc6bS2C73eFJSl31Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΓИнΣψдВΠвαЪςС():
    value = 514088
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyXcbF4jzqJSNDmsymKjJQMAs18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψФγЛΦГнΛС():
    value = 602949
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyjQbUYczawpCiamx1C8NX0ixj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 78 * 63 < 0:
        758
    return total

def _ΡсΦЕδΑεδΝыΛφГНпл():
    value = 558360
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBzpeXA/15gkHSWEzwfCJwwc01o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΦγΙРцσρΖΧΝЫ():
    value = 946183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnnyOEAW3JgzaiqJnUGVZzQ/zUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сМΒцνШВбчοηΕАг():
    value = 144280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MR30ZlU7/7wACj2Zn36UACp//Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υНгνЖрπΡηД():
    value = 915661
    if False and True:
        pass
        pass
        263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRvSZ0Vhr/gmbTv25XOpPTY8x0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚθΨωИОЭυΡ():
    value = 686512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhroXHIDpv1XGTWU6VOXbCQMy3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τъξσТΞЭμκκвЙσЮ():
    value = 409652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pwf3QVUg5oA1MimvzneXMyYIvGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡеΔаνГЖачээΛоЙ():
    if 71 * 33 < 0:
        pass
        pass
    value = 496897
    text = __import__('base64').b64decode('SnI4dkthNENEampwZmpKUVdEa0E=').decode('utf-8')
    total = value + len(text)
    return total

def _νыЧэБΦОч():
    value = 773615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgLNfEIQ2PgTAxmczkCEMC0+smE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4706 = 125
        _dead_4262 = 686
        _dead_8301 = 772
    total = value + len(text)
    if len('') > 0:
        508
        pass
    return total

def _ΝπвАΑкРтцζИчЬдΛ():
    value = 641418
    text = __import__('base64').b64decode('c1BuOFBXNGdVako2YkZEeDRZcDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡтΓχзЙЪυΜ():
    value = 268187
    text = __import__('base64').b64decode('bEcxSU1oYXpFN1VzYmZ4SDliVnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ξжЪЦдогп():
    if False and True:
        373
    value = 885111
    text = __import__('base64').b64decode('amhtdWJXRXBLQTJMdklreF9GUGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞнеβξяΝБΙнΕΦадΜЬ():
    value = 661777
    text = __import__('base64').b64decode('cWlOYWZZdnFrdXkyUGN0M0E3cHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _шдЙДςФрΗγη():
    value = 192396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAzSWVkRq7sgaDqCy2HJZwgrvWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩκθнФчнея():
    value = 711467
    text = __import__('base64').b64decode('U05PbktoM2RleXJsU1JwSHZ2dkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪМρΛεЫТιУдБГρу():
    value = 752766
    text = __import__('base64').b64decode('dFNGQ2R6WjJhN2JOeDlrbVp5RWs=').decode('utf-8')
    if len('') > 0:
        _dead_9298 = 499
        149
        595
    total = value + len(text)
    return total

def _зχМτбωΦЧЛ():
    value = 392590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQvFOnsw0PAwCxeo+EPCFSp73Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шγγξЧΣГФКХя():
    if 27 * 90 < 0:
        _dead_5643 = 438
        129
        _dead_9570 = 727
    value = 310620
    if 26 * 10 < 0:
        _dead_1964 = 472
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDfyWnwwqoQhKRaqmn+hNy8gs10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1656 = 194
        362
        668
    total = value + len(text)
    return total

def _ЧЛНΝхΛьΤЪь():
    value = 432526
    if len('') > 0:
        _dead_5859 = 188
        _dead_1589 = 357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH3zUWES+74xHxmlwX3BbQg51H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        633
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_7936 = 316
        _dead_4975 = 758
        pass
    return total

def _иΧйжЭΕΔΛрРгΛλπγЯ():
    value = 542785
    text = __import__('base64').b64decode('VG9OY2piSm9RTXhTcDhVcTJINlk=').decode('utf-8')
    total = value + len(text)
    return total

def _гсюΞЪЮтеиРωшλш():
    if 67 * 21 < 0:
        _dead_1092 = 687
        _dead_2099 = 129
    value = 819713
    text = __import__('base64').b64decode('VVAydmZrWGxfd3U0YVZUZ2d6TUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙζΑЛИмЖОвΜΡлй():
    if False and True:
        pass
    value = 20640
    text = __import__('base64').b64decode('cjFFNklQZEdlZWRsaU5QSmV1bm0=').decode('utf-8')
    total = value + len(text)
    return total

def _чсфьКΡТтВнρмωччД():
    value = 496394
    text = __import__('base64').b64decode('cW1CV1M0S3RDQW9hNUpGd0t1TW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΜПжЯπΠΓБщ():
    value = 891720
    text = __import__('base64').b64decode('eDNHaUFCR0JHSE56UjVCMG9qMTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ςгжλχβекΟσ():
    value = 553243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAbFUXNh3L0BbiyImV6BPwYWsEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΕζΠлρдХυЦъγЙ():
    value = 181969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBzGbGc/qv42FSSyxmS8MTYD41g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΨДΣййΞЮЦЮ():
    if 30 * 98 < 0:
        206
    value = 313779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyvSXEEu6ppbHh6s5V/GACog1Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖюΖςьюПαчΕЛΖΤ():
    value = 29340
    if 23 * 47 < 0:
        867
        _dead_2415 = 342
        pass
    text = __import__('base64').b64decode('VXNaUG5BaGdjMG03V0RmSWl2aG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΡсΠθГБφЮΨΕ():
    value = 989769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHrHQwYs864UFQe063ibGQsA7Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 12 * 96 < 0:
        500
    return total

def _γважжкмп():
    value = 463216
    if False and True:
        828
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jwe1SHcQ37kzKzyJy3yKAioQ4T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 65 * 69 < 0:
        391
        pass
    total = value + len(text)
    return total

def _ШлОооСΔΟЕδЪЕнκЖ():
    if len('') > 0:
        _dead_9502 = 28
    value = 27768
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhbpbFU82ZEWPQeJ8VuAJD1/wVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 60 * 69 < 0:
        pass
        _dead_5482 = 576
        _dead_5613 = 266
    return total

def _ΠИφИιθхζωΖХ():
    value = 223757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FArbV2sT0aQ6L16qwwe7Z3Yq1FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФжЭяЬΒΙγиΑплΡνдр():
    if 95 * 92 < 0:
        _dead_1001 = 379
    value = 265609
    if 7 * 73 < 0:
        720
        _dead_6922 = 592
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Di7BfkAg9oMhACGOmlS7OX129EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьρбЪοΦхШνТеКАЕ():
    value = 298315
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyP0R3ou+KdXaxyT/EWFYg0qxTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΚЦчωдНТΜΜξ():
    if False and True:
        _dead_3588 = 905
        pass
    value = 658917
    if 37 * 51 < 0:
        _dead_9584 = 0
    text = __import__('base64').b64decode('Y05oNTRid1dTZTQweHJqVVN5MXE=').decode('utf-8')
    if len('') > 0:
        439
        _dead_8175 = 775
    total = value + len(text)
    return total

def _тβтИΠωтΑ():
    value = 822438
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChDxVHhhqZgFCgWmkAeqEggo0k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 3 < 0:
        _dead_4006 = 974
    total = value + len(text)
    if False and True:
        _dead_1388 = 172
    return total

def _уВъνΧπсΧьБΔКВИ():
    value = 79613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwLVb1or2Jc2CC77mXOzLR8b/Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гъФΤеуьЙеΡКМЦуЪ():
    value = 555842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQvAbWQj0IQWHVvz3WCbLiAg7Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕЗΟκОтΙςΠм():
    value = 432653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSfUPHY08LosaR6u0VK9DTMA3no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лκШтыΝГι():
    value = 464442
    if 96 * 5 < 0:
        _dead_5989 = 648
        pass
    text = __import__('base64').b64decode('TDNXc0FENmZXdjhNNUM0UEdMcXc=').decode('utf-8')
    if False and True:
        pass
        _dead_4847 = 35
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _вΥгΤуьУшΓΠГτуяР():
    value = 318429
    text = __import__('base64').b64decode('WXJ1clI0QjlGX0p1TDVjYml3WUE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7623 = 811
        647
        990
    return total

def _ЬуΡЧΡкφэЖуроΡ():
    value = 108905
    if 94 * 13 < 0:
        pass
    text = __import__('base64').b64decode('Y2VnMHJXRGdkeFVKcnF3dlZNZkE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        861
        pass
        990
    return total

def _БΧшкΘЫОЬднз():
    value = 194170
    text = __import__('base64').b64decode('VDRUdV9uNXgycjRiM1kyU3dRZmU=').decode('utf-8')
    total = value + len(text)
    return total

def _яюКΥδГχз():
    value = 714982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjbCRHAT0rssLgePy1WDZwwizn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        163
    return total

def _ιΚςΘσχИиЕιЛ():
    value = 3103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh/BP2MQ2IEXFi2o/GmjYCkZyX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 21 * 48 < 0:
        pass
    return total

def _ШРγΓΟПΡς():
    value = 224102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JirbOVc46ZgyIiOC22WbJiAh6Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜКиθосъΖнФλ():
    value = 353877
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBb3OFsN1ropFSX6kH+VJTAA/EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЭьЩπγздχσЦБΦΒς():
    if 71 * 24 < 0:
        _dead_9100 = 773
        298
        _dead_8882 = 515
    value = 105127
    text = __import__('base64').b64decode('VVE1NTd6SW56TWlwdEgwdkJTSW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΨЫцуйНΛцψιΛΑЧ():
    value = 571893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR3jQHU32P88aDyBmniIGQkf1kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ГΖВЯюΞХЬ():
    value = 463650
    if False and True:
        pass
        518
        pass
    text = __import__('base64').b64decode('bkdSTkY4QXJqZjNmV040bVF5UHo=').decode('utf-8')
    total = value + len(text)
    return total

def _χΤΕεЖΘМμЧЕфлνРБ():
    value = 86169
    if len('') > 0:
        pass
        pass
        _dead_7829 = 513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR7OYAIPzZcVPiCo51O/OQwr9UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙХжΔΙаΑкшΔ():
    value = 382537
    text = __import__('base64').b64decode('VFlOS2FMaXFvVnVFS3haYldYVXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ξειвЖОЬζ():
    if len('') > 0:
        620
        pass
    value = 185211
    if 20 * 34 < 0:
        pass
        pass
        _dead_9433 = 970
    text = __import__('base64').b64decode('b1g1c0ZQdkV5VTBaNUd2ZTZIYkI=').decode('utf-8')
    if False and True:
        _dead_7193 = 569
    total = value + len(text)
    return total

def _ΞЙτъВяПЦΕΦШ():
    if 40 * 92 < 0:
        pass
        pass
    value = 353273
    if False and True:
        749
    text = __import__('base64').b64decode('anFfRzROZW1xMEMwSzZPcHdZbkw=').decode('utf-8')
    total = value + len(text)
    return total

def _жρηВЯξЮРΞПющжГ():
    value = 482146
    if len('') > 0:
        893
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lwn0PQk83KsOAyacmgKoMBI7wWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цПψγΣΘωΥΦΜТηИΗЪ():
    if False and True:
        565
    value = 260418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjnDZgkG+YYhMQiU4VHGMzwo5zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 81 < 0:
        _dead_7245 = 95
        _dead_5413 = 546
    total = value + len(text)
    return total

def _ЪКιΑΙΚΠчοЯзΜхλΝ():
    value = 364599
    text = __import__('base64').b64decode('TFZEZXM1eXh3RGtDMHhVOFlwbWU=').decode('utf-8')
    total = value + len(text)
    return total

def _γухЫтоОУξΚяκрФ():
    value = 485964
    text = __import__('base64').b64decode('SkNjZXJtWlB0TjdiazZncW04aEM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩРπэДбΑХЯξ():
    value = 552077
    text = __import__('base64').b64decode('c3AzWnZ4c0MyYjJDMkl3N1JBbjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ьТКδсΟΣБΦΕы():
    value = 529413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBjiZ24q1LEIKge5mgW6NnA94X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2274 = 376
    return total

def _ωмФКкεЭЕξЗЗγеωМБ():
    value = 577251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXvtaUQc24AAHleP+lqADXcl7Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яшжβшδκφшОКЦΜΟкψ():
    value = 579224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyzSWAgs2aMnPAqV2kGbYnN57E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψшΤαяшяνβΚцΖΒΣЛΒ():
    if 77 * 35 < 0:
        _dead_7988 = 633
        _dead_1126 = 527
    value = 165707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAjwTGMOx70ZGzqb72GEGCI/zk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬШφςμьΗДδ():
    value = 868319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChazPmMv1poPMgGL8GGVNwl4yj0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΧδΝщТЩц():
    value = 308654
    text = __import__('base64').b64decode('QkdpdEZIZWs5cktpNnRzQnRadzg=').decode('utf-8')
    if len('') > 0:
        _dead_1463 = 278
        94
        pass
    total = value + len(text)
    if False and True:
        364
        862
        726
    return total

def _οΖхКзΣΕςλчГЭΤαΖ():
    value = 477480
    text = __import__('base64').b64decode('b3JCTTZFSzJzVTF0TzZiMzJIWWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟВχХΙйΒι():
    value = 340074
    text = __import__('base64').b64decode('VW5jc3ZveXZXQ1RQZnY5bEQ0V08=').decode('utf-8')
    total = value + len(text)
    if False and True:
        333
    return total

def _οτΕуΕЮьχ():
    value = 252161
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRDtWVoI+/8WalysmXWCECgZ2zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΔΥэЧΥκЕΛЗМΕшнХ():
    value = 950080
    if 2 * 82 < 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('V0ttSV84NU84MFc5c1lNU0lURjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ШощΑФХРяηЦΣЭψδ():
    if False and True:
        pass
        _dead_3138 = 800
        pass
    value = 714164
    text = __import__('base64').b64decode('U0t3Y3RSZUs3RWNXV3J2U0xIZWo=').decode('utf-8')
    if len('') > 0:
        pass
        207
    total = value + len(text)
    return total

def _ωΧρσπξΩхπеΛΗъ():
    if len('') > 0:
        589
        640
        _dead_4948 = 876
    value = 898190
    if False and True:
        54
        pass
        _dead_1096 = 269
    text = __import__('base64').b64decode('c3M3bEJ2eHVWc3hMY3BTMEhRWXA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΝцьтсъаΦжЙ():
    value = 13278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQLof0k/2LAaLBiu8V+gMgN24F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞьэΓδЬПЕутЕΛΥ():
    value = 385274
    text = __import__('base64').b64decode('UExtdTlsS0hEcEtvUTBRZ0N5c0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _СθЬЫψΠξзтшΒ():
    value = 372807
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fwz0QGs3prEJAwinxwGlDAMK/Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РИЯРЙзΛψκΡΠ():
    value = 604385
    text = __import__('base64').b64decode('ZklSQlAyTmZ4WkdGMm1WaXl5NTI=').decode('utf-8')
    total = value + len(text)
    return total

def _αСВМЙσЭуλ():
    value = 774135
    if 2 * 5 < 0:
        673
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAPeeQcM9YMpIiWQ3A+mPAkV1Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8183 = 716
    return total

def _ЖΙΒψДкΕЦχКμξЫЪΗ():
    value = 769513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQTQRmMq671VCw2lkUHEDnUesmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оπхρθОрЬΚлАχΖчΚΗ():
    if False and True:
        pass
        pass
    value = 207104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwfKN2kK1aBSDCWJnXvEGT8D6H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5377 = 319
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_2015 = 424
    return total

def _θйЖцΣххЖО():
    value = 23413
    if len('') > 0:
        _dead_8281 = 721
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzfePwUW1a4tC1+LzVS4DTIb1nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 44 * 38 < 0:
        _dead_7660 = 747
        _dead_9932 = 603
        495
    return total

def _АКΚъчΛхΑχ():
    value = 205793
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('SFpBU1lGTkR0OEJUbDBlWjhGTnI=').decode('utf-8')
    total = value + len(text)
    return total

def _щзΗпΜОТтЪΔβ():
    value = 550217
    if False and True:
        523
        _dead_6884 = 278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwrNbWIvy54NH1m07HKlbA0BzXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΥΞΤыψОυΘуЮСΑф():
    value = 242829
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR7oXEYV35E1DT/00QfJOgkAsz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δξΥПζςΟФχΡссΘξ():
    value = 529745
    text = __import__('base64').b64decode('d3NVODdpUTVTbWpDVXgyeDVSdkY=').decode('utf-8')
    total = value + len(text)
    return total

def _ιπρΩκГΜжρнЩцдмψЭ():
    value = 732513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyPRWWAM+bguGQWOwnmkDCAi800='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΟΜμтΠΓсЩГ():
    value = 389494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQWzQlI8r6YnbguswlSFHhIY4Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4237 = 332
    return total

def _ЕρиτСТνнКш():
    value = 502537
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jhe2OH0p3foBFSGa4lueODE86UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗλφΒлОΥрюАуΣηМ():
    value = 255931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxXOeFgR2IEiDSCNnUOkZX0HyHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШΥΘряΗυАечΑуЬцЗ():
    if len('') > 0:
        pass
        _dead_6209 = 551
        pass
    value = 119612
    text = __import__('base64').b64decode('SHRvQXhrU1RtT2dSc3hORnR0eDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ДШΠНЧОνгШОЮΩ():
    value = 236919
    if 16 * 22 < 0:
        _dead_5478 = 705
        _dead_4754 = 345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQbSZQIx2r40Iy2Qz1+qLQEDw2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ужΘοуБζΖЛΦщиШБαК():
    value = 643625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E370aX0p2/lXaluL/VKeMBoK6ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        952
    total = value + len(text)
    return total

def _зΠсщрροХηΛБХκяЩ():
    value = 85951
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwK8ewUUrocPHVyozAOkNggV60M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        24
    return total

def _μΨшςΤдяуσнΖйкΖ():
    value = 824475
    text = __import__('base64').b64decode('dWRGclhvMjdmdXJOSWJrcUJyQTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΩηζпзΓψΘЪС():
    value = 207784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXbpW3Jsq6oALTu63Q6jBCgK4Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΤΕЦЬьβкαΘ():
    value = 359219
    if 68 * 59 < 0:
        _dead_7816 = 941
        pass
        _dead_3145 = 676
    text = __import__('base64').b64decode('QTJnQnhibjNmRHByajdYWU1UR0c=').decode('utf-8')
    if len('') > 0:
        _dead_4806 = 283
        pass
    total = value + len(text)
    return total

def _чυФяЛГΘщхФьЮΝЭфэ():
    value = 410260
    text = __import__('base64').b64decode('QkZVM0M3dTRIbl8wMkF1UkpMOU8=').decode('utf-8')
    total = value + len(text)
    return total

def _сцСΘЙΧσОКЮΝВЧьЗξ():
    value = 895667
    text = __import__('base64').b64decode('ZFhrWno2dkM5T3NaakJKN2xST3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _щыиьΑЗДΩрФΒ():
    value = 171269
    text = __import__('base64').b64decode('U2JoSXVLc3ZWdE9ocnY1RkRvMjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ωэΝοοыΡн():
    value = 587798
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQPRQEAAyfsiMA6E0VypDiQptXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 41 * 13 < 0:
        _dead_9168 = 329
        _dead_8008 = 933
        _dead_7016 = 908
    total = value + len(text)
    return total

def _ШоАОтЖдЕΚРΖυд():
    value = 898704
    text = __import__('base64').b64decode('a04wNkhLVG4wS2xFbk13X01udDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЦЮвЙγκЕеЫчн():
    value = 734970
    text = __import__('base64').b64decode('dkg4ZE5TeVZ0U0xEc2o3MlR5RmM=').decode('utf-8')
    total = value + len(text)
    return total

def _КρАΨЩΨХΣθ():
    value = 99876
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3ftdn0vz607bASuw0W+PSR7zW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 78 * 33 < 0:
        542
        pass
        pass
    return total

def _АθΨυчβрΨМθΨξЭ():
    value = 311379
    if 87 * 35 < 0:
        _dead_1153 = 565
        739
        _dead_3843 = 735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAe8TFgwx5FSCByhywWBOQsCsUI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЕнΒΑоΑфε():
    value = 882206
    if False and True:
        _dead_9634 = 342
        pass
        686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDbqW1A25pg5bD6zzEfEAx0GyE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 2 < 0:
        488
        _dead_3061 = 386
    total = value + len(text)
    return total

def _ЕлЯШбκЛφΑДЫШηδц():
    value = 620898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwnRYwg4pp8QMgaZ6UeENxIbtjo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тζЙЭвяуВюΠРδ():
    value = 159226
    text = __import__('base64').b64decode('WVZXVFF2bnZqV3ZoTUg2cTJwSms=').decode('utf-8')
    total = value + len(text)
    return total

def _δцВΑмαфбΥΜΝысн():
    if False and True:
        84
        184
    value = 732013
    text = __import__('base64').b64decode('ZWZLUUZKVmZzUXZzT0s5ZEh0Z1M=').decode('utf-8')
    if 73 * 69 < 0:
        _dead_8635 = 88
        _dead_4096 = 446
        _dead_1723 = 913
    total = value + len(text)
    return total

def _υЗεАвждууЫηФЙΖ():
    if False and True:
        _dead_9242 = 367
        256
        _dead_9080 = 916
    value = 225013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX7gY2cT7PwZDiX65lmYAhoQt0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΗвкζДθΔяФеΒтΚ():
    value = 847893
    text = __import__('base64').b64decode('V2ZxN3BncnhFZTd6eGNwcE91WGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ифСβцзУР():
    value = 403383
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQD+dnMU1IULNAaLzwCfFQ0Y3Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 71 < 0:
        _dead_1270 = 198
        pass
    total = value + len(text)
    return total

def _υОРФЙεΚЧΣΝΤЖχυ():
    if len('') > 0:
        _dead_5672 = 828
        pass
        867
    value = 18217
    text = __import__('base64').b64decode('R0ZRSjRnakJacTdSUjVtcG5MS0s=').decode('utf-8')
    if 83 * 62 < 0:
        _dead_1481 = 598
        196
    total = value + len(text)
    if False and True:
        _dead_5490 = 538
    return total

def _МХΧΧЙΥъшψοюΚ():
    value = 21812
    text = __import__('base64').b64decode('Z2tpTUZfVzRCUWRjY3dZMDc5NHc=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_9220 = 88
    total = value + len(text)
    return total

def _БыКмлΟмξΞρЪФΒ():
    value = 168917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NirhVgAw1JAxay6s/EyFGQcOsWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _дЭωрΨΒЖЬυМгΕΥегх():
    if False and True:
        _dead_5133 = 287
        pass
        _dead_7739 = 695
    value = 792146
    if False and True:
        _dead_7171 = 36
        705
        pass
    text = __import__('base64').b64decode('WUZLMFhIdXlIR3ZQd3hVR2hoc1g=').decode('utf-8')
    if len('') > 0:
        _dead_8734 = 567
        199
        826
    total = value + len(text)
    return total

def _ЙΑΑЭΙЦяψИΑНБ():
    if False and True:
        697
        pass
        pass
    value = 625018
    if False and True:
        pass
        _dead_5990 = 744
    text = __import__('base64').b64decode('TnZOaEplT0k3cDFja3lkTmdCWnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪδΥχЩυΕлΝрнμζъою():
    value = 231384
    if False and True:
        _dead_6425 = 812
        441
        930
    text = __import__('base64').b64decode('RUNKTkhWdGRBSWRjSnRjMEswTTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΧΟЭΩΕцп():
    value = 603264
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nhv9Y0sP9f4iHi6qn1OoA3w79Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лεΘЭЪΙДςНецйНШΖЕ():
    if len('') > 0:
        _dead_6667 = 923
    value = 223048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCqyV0chzpE6DzuU+2OlNisj22k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 78 < 0:
        879
        982
        591
    total = value + len(text)
    return total

def _ΚдΓΝлыйоЧфΙчп():
    value = 506458
    text = __import__('base64').b64decode('VWZIMnpOdzM0OFFPVEM3eXR6U1A=').decode('utf-8')
    total = value + len(text)
    return total

def _кδЧБμФπЮбΩτжЭиν():
    if 63 * 3 < 0:
        _dead_2077 = 45
        571
    value = 135936
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EybJWUcAzPwGBSOJxn+xbSYGs18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДоЬΨОхсжЫх():
    value = 916330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECriVks4yawsLlqwxQ+9ORMf6Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΖвАчΥРςэьχЖлΡς():
    value = 51480
    text = __import__('base64').b64decode('U0d6ekRyWnVqQ01PZUJadERMRTk=').decode('utf-8')
    total = value + len(text)
    return total

def _МДθЬмψИΛаΠβдασ():
    if 7 * 77 < 0:
        679
        352
    value = 336140
    text = __import__('base64').b64decode('eW5CRkVZTTNPOVlhN0hGM3hYeFU=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if 60 * 28 < 0:
        933
    return total

def _тωςкпйъιУнвβОΧ():
    value = 738142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cz7HZ0UN7aAOOT2M32O4DgIo414='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        799
        _dead_5834 = 73
        pass
    total = value + len(text)
    return total

def _ТχφКщдНсΓ():
    if 10 * 32 < 0:
        pass
        494
    value = 784402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBXUa2YpyaJTIwuLxXWDJCYc4lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДαжρΛДмΧв():
    if len('') > 0:
        _dead_1435 = 51
    value = 19320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cn23ZXIKp5EFPCKg2FOhBDI76lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        735
        20
        876
    total = value + len(text)
    return total

def _хΥεяΦΚνяП():
    if False and True:
        pass
        124
        pass
    value = 966788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KivAOWA11fAtGSSgxA7GAAMC1lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        264
        pass
        pass
    total = value + len(text)
    if False and True:
        783
        _dead_6578 = 82
    return total

def _иУβΚκλрρμПΖЗ():
    value = 176702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ez+9fwAfqpBXNy6V3AaVOzUBz0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хλφкЕςдХЫδΙΡбξу():
    if len('') > 0:
        pass
        _dead_3667 = 167
    value = 209624
    text = __import__('base64').b64decode('ajF0MlhSRjBXWTg0dE02SWk5aVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓχδяюГΧЦИР():
    if len('') > 0:
        _dead_1598 = 459
        918
    value = 455662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jwf9RVMd3IYBDB71z37DZREIwD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аеЮкΨСαЕИγЬ():
    value = 617728
    text = __import__('base64').b64decode('WHQ5ZnFIRFdNZzF0MTdqa0xmQ3A=').decode('utf-8')
    total = value + len(text)
    if 85 * 3 < 0:
        _dead_5788 = 719
    return total

def _αеяξΨΔЫаπΩ():
    value = 589021
    if False and True:
        12
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DirHS0Rt6f8UaQeL/VynbQ8i4zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЧЯΟшΓъЩЛ():
    if False and True:
        _dead_4501 = 471
    value = 425454
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjfKPXov5JkxFwiIwFfJLAd44GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γΒΝвΤηΘζЦρΡаυУиу():
    value = 66527
    if 25 * 10 < 0:
        659
    text = __import__('base64').b64decode('Zk5nZ3BBTUhuckNPaFhYeFpVUWQ=').decode('utf-8')
    if 37 * 44 < 0:
        217
        195
        425
    total = value + len(text)
    if len('') > 0:
        _dead_3713 = 660
        556
    return total

def _яМГΛаΛБμ():
    value = 143522
    text = __import__('base64').b64decode('eFlhNU45OUVEZTBHVkw1MFBMeFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЪΜЬΥαΧοМΚвΣЮВХ():
    value = 77131
    text = __import__('base64').b64decode('bDU0Vm5IMm1EM25kNUliSE9fOUw=').decode('utf-8')
    if False and True:
        527
        _dead_3122 = 729
        358
    total = value + len(text)
    if 97 * 11 < 0:
        pass
    return total

def _ΤΣΖβяΛрЦЩЧ():
    value = 522436
    if False and True:
        249
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBzlO2Q/1qYlayi78k+hFhEEs2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 42 * 90 < 0:
        pass
    total = value + len(text)
    return total

def _αΦθрфΜκлγξоΨРρ():
    value = 762105
    text = __import__('base64').b64decode('ampyUzBqb1dBZTdFclgwZDAxOE4=').decode('utf-8')
    if 26 * 36 < 0:
        610
        pass
        pass
    total = value + len(text)
    return total

def _δИБеЮαиσσФ():
    value = 780523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nxbed3QeyKcmKTi2/nGzEQ0W/ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κРкТδυχа():
    value = 94119
    text = __import__('base64').b64decode('ZzdCdmhjSUN6ZDNUWloyaG9xRXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΦΒДцνγВАЩγαυсεΗ():
    if False and True:
        375
    value = 122978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KS3WO0Et7PETCBuryVrJYT0B110='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝαρЛΗβΕь():
    value = 972514
    text = __import__('base64').b64decode('V1pRYUNvbHF0UF82NDBuY3JqWWY=').decode('utf-8')
    total = value + len(text)
    return total

def _δФζЯФшыρΣкыШγмф():
    value = 189824
    text = __import__('base64').b64decode('RDN3ZXdjSEtoMlBLVmdTbkdvNnQ=').decode('utf-8')
    if False and True:
        _dead_7148 = 70
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5610 = 76
    return total

def _ΕюВйМЩВπъρΖы():
    value = 690073
    text = __import__('base64').b64decode('STZQRFNJVGZwaTN3OXBRNG4zWm8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ТМАУхРрγф():
    value = 86747
    text = __import__('base64').b64decode('dFVlc1M5V3RyT2pPaEFUbTZHYUw=').decode('utf-8')
    total = value + len(text)
    return total

def _θУΛΥηчЮΟыΞхω():
    value = 610389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHzcegEG0fEhDVrw+GmDPCw4tD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цэОНйΑъΛфН():
    if len('') > 0:
        _dead_3977 = 950
        674
    value = 637486
    if len('') > 0:
        _dead_7045 = 430
        _dead_5966 = 803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAfNQ2ko84YMGTmU4kK+Cw4sykA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 22 * 10 < 0:
        177
    total = value + len(text)
    if False and True:
        665
        783
        _dead_5372 = 231
    return total

def _нЬРφфωГπЩц():
    if False and True:
        _dead_3076 = 861
        _dead_9119 = 786
    value = 138713
    text = __import__('base64').b64decode('dWpJTmo4M2V0cmxPNzJTY19Rb0k=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _εщСΓπΣμΤа():
    if False and True:
        875
    value = 746211
    text = __import__('base64').b64decode('TU9vQzVyTlhmcW01YjZqRE9LMXI=').decode('utf-8')
    total = value + len(text)
    if 78 * 33 < 0:
        _dead_8025 = 210
        pass
        _dead_3462 = 532
    return total

def _юηλДΕЦзΥΤЧ():
    value = 283954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSi2YVVr96ILEzu7wkCYJBEn6l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        791
    total = value + len(text)
    return total

def _жειΥΝЕνйЖъГРΑ():
    if False and True:
        pass
        _dead_9730 = 620
    value = 952876
    text = __import__('base64').b64decode('ZzVKeXpCTmFjWDAyZGJfZE01bFk=').decode('utf-8')
    if False and True:
        _dead_6310 = 313
    total = value + len(text)
    return total

def _ОЙПбθψЬΙρл():
    value = 842662
    text = __import__('base64').b64decode('TXlMaFNYNlYySHY0ckdzM1NySjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ηсδΦΙжИχЛЦдИ():
    value = 12735
    text = __import__('base64').b64decode('TDE5MmJwdzRITFVMajZxMFhpUVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣдтЫιлΚэГъΗΔФκэ():
    value = 885749
    text = __import__('base64').b64decode('YVNOQ0FXbnNMMG9FamEwZERkbWE=').decode('utf-8')
    if 14 * 97 < 0:
        _dead_8476 = 566
    total = value + len(text)
    return total

def _ΣСсЪкЭΤψнгЪхт():
    value = 519387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjvdWgIf+r8WDgmk+US0YAE/6GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηОΩжГωЗЦр():
    value = 404929
    text = __import__('base64').b64decode('Vk1jTmVXdm5PVmtDbkpEb185UDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _αюЯΤΜцφдψσЦΘ():
    if 43 * 10 < 0:
        519
        _dead_1508 = 801
    value = 855592
    text = __import__('base64').b64decode('c19hYmRCRmE2NTdmT29YS202VUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ХЮΗЖΗюΟθΕ():
    value = 108645
    text = __import__('base64').b64decode('RjVBV1lVM1dmZWhXMnl2QWNnZDU=').decode('utf-8')
    total = value + len(text)
    return total

def _щСρΤяГΝδΑψшιтЮ():
    if False and True:
        311
        pass
    value = 571035
    text = __import__('base64').b64decode('cDZMWFB4cDBlUnVuaEI4Z0NLSFY=').decode('utf-8')
    if False and True:
        490
    total = value + len(text)
    return total

def _гяφСνвΔНωΙШνλΨГ():
    value = 569039
    text = __import__('base64').b64decode('RG16eEk5N3pVbV9GNlhER190MmU=').decode('utf-8')
    total = value + len(text)
    return total

def _κЬГцΚдΨαоΧατЖ():
    value = 818891
    if False and True:
        703
        pass
        472
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxXVUQcexLoiMlikwnufZQ550j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДсИоЬΣХЖщчΩу():
    if 91 * 84 < 0:
        pass
        880
    value = 654240
    text = __import__('base64').b64decode('bkw5SDFXSFBrMFBLZ0huSWwxSl8=').decode('utf-8')
    total = value + len(text)
    if 12 * 28 < 0:
        881
    return total

def _иηυηψтπΓσКЪ():
    if 69 * 95 < 0:
        631
        _dead_9224 = 569
    value = 48145
    text = __import__('base64').b64decode('eFkyeEhrTGpXdzA0dm1LTF9tRUw=').decode('utf-8')
    total = value + len(text)
    return total

def _аЙΓπуΖфΓДЩ():
    value = 559728
    text = __import__('base64').b64decode('ZXY3YUQ5NVJ2ZFFKMGxieGVXNzY=').decode('utf-8')
    total = value + len(text)
    return total

def _мсОюЫΔΖιИυ():
    value = 818030
    if 64 * 43 < 0:
        _dead_4477 = 547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSH1Z3YY1KEgKT2N+ly4bAc+3Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9771 = 908
    total = value + len(text)
    return total

def _тΕΙЛЗСκφΔыζνНм():
    value = 567106
    if 89 * 80 < 0:
        pass
        _dead_9689 = 560
    text = __import__('base64').b64decode('TTk5bmFydktiRkRCaEh2T1lLUTk=').decode('utf-8')
    total = value + len(text)
    return total

def _кРЪюρоЦж():
    value = 568889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz3BTFAc8b9WIyfw32GEJCQH0UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΚσοζιрКυэБУНΒΑ():
    value = 970569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh3IQkJtxKJWLyGpwWWRARwA11k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΦИдЬШНβРΡЦδйν():
    if 21 * 46 < 0:
        _dead_6964 = 789
        728
    value = 209650
    text = __import__('base64').b64decode('TmRFRE9faXVZVG81aEJ5QUxCN2E=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        215
    return total

def _рчУдАмшфεыК():
    value = 282434
    if len('') > 0:
        _dead_6264 = 274
        pass
        _dead_3081 = 272
    text = __import__('base64').b64decode('UDVFUDE2MnVTR2p4V1Z2eWpDc1c=').decode('utf-8')
    if 48 * 93 < 0:
        386
    total = value + len(text)
    return total

def _ΟУΟтТУзДлΘ():
    value = 312983
    text = __import__('base64').b64decode('cVlnWnpZSEJUZjhhWVZNT25kTTU=').decode('utf-8')
    total = value + len(text)
    return total

def _фЪΝеыγХйгωыβТΗдС():
    value = 702775
    text = __import__('base64').b64decode('SGVUVmFzbUs1ZFlscU5XbDRPd3Q=').decode('utf-8')
    if len('') > 0:
        _dead_3366 = 105
        pass
    total = value + len(text)
    return total

def _ЕεСЙуΥбΩ():
    if 5 * 14 < 0:
        pass
    value = 113676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxzyOH0g9JAUDlu0ylW2Zn0Cslg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яъΝЦоυЛИωщНСδж():
    value = 980581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhzBXEk/0LgmPhiz/A6ZMQt+6Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςχжКЙмцХωККφЖыо():
    if False and True:
        _dead_8644 = 241
    value = 919630
    text = __import__('base64').b64decode('UWFQMm41RnV5eXBHSnFMVlRzb1o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6112 = 376
        303
        179
    return total

def _ΧπфΦПΕΜЙΑ():
    value = 323936
    text = __import__('base64').b64decode('SHJoeTg0Q2YybVF4ZlBJUDN5ZU4=').decode('utf-8')
    total = value + len(text)
    return total

def _яφШЕελκАи():
    value = 488993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAbIX18t16wnPweCzFCmZXc/9jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уγΖпеΤΙγΔХΞ():
    value = 897144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARbCTGY81JcIFz2gzH2CNSA36l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВАЬΕЦηБНΔΛΔпΟ():
    value = 955537
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Biq2UVBhqqQNDF/75VmJPxcMxng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΦΒτπΦδΖΧΤ():
    value = 837965
    text = __import__('base64').b64decode('TGl2dG5obXE2aDlhSmxrckVpbUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ъσэΦДЛСъαζδБΜусД():
    if 38 * 51 < 0:
        913
        _dead_4270 = 92
    value = 486080
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kimzf38b9IdWOFqCy1S+IHYg7GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пнТΕинΖбБΡ():
    value = 573125
    text = __import__('base64').b64decode('cEhOa0JZZTBsVlczcmZrMkJXbnE=').decode('utf-8')
    total = value + len(text)
    return total

def _οΖеΑΖгчУζПωΚ():
    if len('') > 0:
        _dead_4008 = 562
        288
    value = 420246
    if 57 * 55 < 0:
        _dead_8649 = 39
        353
    text = __import__('base64').b64decode('UEpLT0pwenJNNmFWOWtRa3FldDY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _жзиюυφβЖчЧВΩ():
    value = 271469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhfHQEM9qosTLQmN/XSfJ3EC8G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        369
        537
        374
    return total

def _ЗГХэРπдЫр():
    if 93 * 23 < 0:
        180
        767
    value = 497057
    text = __import__('base64').b64decode('cU11ZWJ4T1gwSnU0dFFKekRkck4=').decode('utf-8')
    if False and True:
        345
        _dead_9266 = 239
    total = value + len(text)
    return total

def _йβЯАΤΟΔП():
    value = 219332
    if 43 * 92 < 0:
        _dead_6427 = 185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhzAegc/7I5QDy2n+lm6PzUKsXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЮРыЯЭТШП():
    value = 972901
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXm1VEE8z64CDQubm3GVHBcg3lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        265
    total = value + len(text)
    return total

def _ъйΨЪδеπбθТцηц():
    value = 853299
    text = __import__('base64').b64decode('dFYzWU9nUUlsZU1vUDZCRTVtZGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕОλлκЮЗΨ():
    value = 790998
    text = __import__('base64').b64decode('dEJOb1Q4a2ZsM2piWHNRS3N1OUI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3426 = 750
    return total

def _бΜыЯцЪзсе():
    value = 850584
    if 57 * 100 < 0:
        _dead_8505 = 526
        _dead_2386 = 255
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nhn0dl8b+b4WAFqN3maeZwEFwmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οθψσЛαАЧνΧыαяβ():
    value = 683012
    text = __import__('base64').b64decode('ckllWEViN1BTN0QwZUNsY1Yya18=').decode('utf-8')
    total = value + len(text)
    return total

def _мυΕιъεБКΨЭ():
    value = 840010
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MD/NfQRsrYwVNDWsyUWAESMjvEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 44 < 0:
        _dead_6104 = 291
        _dead_8440 = 72
    total = value + len(text)
    return total

def _ЪΥзуьОмΠΞо():
    value = 374494
    text = __import__('base64').b64decode('a2pINUFmeXdSY2VtenZHZkw3U1o=').decode('utf-8')
    total = value + len(text)
    return total

def _мΚΕαλγσсяжЕухПют():
    value = 663001
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDrHeEQu2ZsVKCq3kQOIBzQY6Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΞΘХеПαЧип():
    value = 371682
    if False and True:
        _dead_7657 = 311
        509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRWwZkI+1qcwEjucxnGFEg4N0UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эЯУгΡΩοΞπмдпЪιο():
    value = 811005
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwnRPX0AzvooFlqBm27GAwYJ/GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЩцЖаПψУΘΛвСК():
    value = 348102
    text = __import__('base64').b64decode('ejJMMFNaRUk0dGYxN3hkYzVPaWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓτΡΜсЦСθθ():
    value = 21834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABCzTXISwYIbECTy6WKHZh956Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χχОГЩаΡξпξЖδлж():
    value = 539831
    if 86 * 41 < 0:
        _dead_6390 = 388
        _dead_8027 = 822
    text = __import__('base64').b64decode('S3dqSmRGZTMyZzNIS0RSRXoyeE4=').decode('utf-8')
    total = value + len(text)
    if 12 * 95 < 0:
        _dead_6820 = 665
        _dead_6909 = 45
        121
    return total

def _ζρΦΝжΦΕУΦΧΩхы():
    if len('') > 0:
        pass
        _dead_1752 = 827
    value = 687897
    if len('') > 0:
        _dead_9563 = 620
        711
        pass
    text = __import__('base64').b64decode('cXVIYUFfa1JwT0dsZmw0ekNIUUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΡΥомоЧЬν():
    value = 704006
    text = __import__('base64').b64decode('VUowQnR0bGF0RWlzY3NOa2xUNVM=').decode('utf-8')
    if len('') > 0:
        992
        928
    total = value + len(text)
    return total

def _дЦанΡЩзνХΙюещΗю():
    value = 352827
    if len('') > 0:
        569
        _dead_6422 = 604
    text = __import__('base64').b64decode('WXdrTGJCeUtRV1pVZVhtaXRfX0Y=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3169 = 152
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('bQ==').decode('utf-8'))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()