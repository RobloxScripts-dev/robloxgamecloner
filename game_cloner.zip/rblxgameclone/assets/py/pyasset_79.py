#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΖΛьΔсйвΖΜνйμзЧε():
    value = 180194
    if len('') > 0:
        129
    text = __import__('base64').b64decode('YWdVSlZwNWpJMWFNNHZieWd5bjU=').decode('utf-8')
    total = value + len(text)
    return total

def _чзРСЬныяОΤ():
    value = 584407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRnyQ1xvz4AxPjy20nOUGzcQ1Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 82 * 19 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ИωсвαхЕг():
    if 15 * 20 < 0:
        94
        62
        _dead_7097 = 322
    value = 339660
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHfvT3AxzpcJMBqI51eSPQAnzEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7118 = 564
        436
    return total

def _ъйΥВтчΠнτянαТш():
    value = 562392
    text = __import__('base64').b64decode('QjV1cDV2SDk3aVVxT0p2MUJYT2g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        38
        _dead_5512 = 379
        pass
    return total

def _αщπυбΨбМ():
    if False and True:
        _dead_1405 = 608
    value = 337051
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXnqUVMTq78PHVuy0Wa5OwsQt1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4570 = 875
        563
    total = value + len(text)
    return total

def _ГмδыйψζэτωъΓΤф():
    value = 279918
    if 95 * 70 < 0:
        pass
        _dead_3707 = 44
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXrrQXYs2Zc6NRvw6ky4Aych710='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЖξφЕΛΑΑσΣδγ():
    value = 540053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHrOOl0GxJ1TYl6F8V+TAgE520s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МйΖЪюΤтж():
    value = 532943
    text = __import__('base64').b64decode('TTlmeVJPcUlQYUt2dkVlUjhsMXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _щфΛΚУЬСΓμоαυφ():
    value = 640858
    text = __import__('base64').b64decode('aDZJZ293dVY1NHplNGpPaVY4cW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗЧижэδЕΟыςσ():
    value = 80830
    text = __import__('base64').b64decode('akRRX2Y1X1YwcEY3VmRPaHBLbHE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2349 = 233
        pass
    return total

def _МΙлРαφβЛξυεй():
    value = 285581
    text = __import__('base64').b64decode('QjBRVVFqa2dBTkZDdmFrZEVMNjI=').decode('utf-8')
    total = value + len(text)
    return total

def _яхΣьюηфλΥΨ():
    value = 166583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwW1RnIJrowaDF2m5k6RE3R3yEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΗΓЭμΒКρМЫЗху():
    value = 844589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiLAXWY43bopMzmL6WTAEgkZ3T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РАΞкхПΘдΣΔПεκеЪъ():
    value = 692319
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAXreWNs3LoJGA2Bw3O5PRUD1Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΑоЧаЧИΖχφуЩбзΠ():
    value = 347494
    if len('') > 0:
        _dead_9886 = 462
        pass
        700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXyyTwAJqb0KKieE3GCGPTEu42s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΠвδβΔГοЖ():
    value = 894245
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn/Ub3YXr7IGKhqI7HHAZA0V82c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΑΣκдЕγυЫΥсяЛκξм():
    value = 357836
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiztQkQf9/BUAALy0VycODUf53g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εНΜхΚκΠаАИФΗυф():
    value = 537029
    if False and True:
        pass
        _dead_9259 = 579
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxjlN0cx9J48AAKO20C9FnUX4Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _сΕоΜΕγΛбΣγЮрπжπЫ():
    value = 374783
    text = __import__('base64').b64decode('SXRpRk5mRzJCNzNsdlVmdjZOdkU=').decode('utf-8')
    if 39 * 80 < 0:
        _dead_7274 = 951
        _dead_2610 = 258
    total = value + len(text)
    return total

def _ΗОВΟАεуЮυЮΩη():
    value = 64217
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwveYFAL/f9VDz+J3FTDITcN6Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2746 = 902
        58
        _dead_1613 = 192
    total = value + len(text)
    return total

def _иРшΖЕΠЫШΖμΚ():
    value = 23128
    text = __import__('base64').b64decode('WjZGY2ZkRlFaVF91RDBPTjN6TTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΣΦКОДμлР():
    value = 883991
    text = __import__('base64').b64decode('cV9EZDBzUlQ3dXdrZmhlQTBEZ2o=').decode('utf-8')
    if 83 * 67 < 0:
        250
        pass
    total = value + len(text)
    return total

def _ΛЩΨТаЛПяπСЫΛОъΔ():
    value = 947141
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxjdX1IB9K4UBRqV0Xe7OzJ60zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 76 * 59 < 0:
        _dead_7165 = 753
    total = value + len(text)
    if False and True:
        447
    return total

def _рЩмΘρкξΤ():
    value = 160600
    if 66 * 55 < 0:
        776
        16
    text = __import__('base64').b64decode('TV9WUFV6aVJpWldvWVVCWm05dkM=').decode('utf-8')
    total = value + len(text)
    return total

def _НΖШюΞΚμΜдβ():
    value = 881770
    if False and True:
        762
        701
    text = __import__('base64').b64decode('allGTVZVMVNSRkQ1b3pvT1V1bDM=').decode('utf-8')
    total = value + len(text)
    if 46 * 56 < 0:
        894
        638
        858
    return total

def _λКЛГΑБвппжΨЫЦΚ():
    if 71 * 93 < 0:
        pass
    value = 803132
    if False and True:
        pass
        845
        663
    text = __import__('base64').b64decode('WjVsakswZkZrdGwzY3l1UDdMQlM=').decode('utf-8')
    total = value + len(text)
    return total

def _цΙφωντНрτ():
    if len('') > 0:
        _dead_7038 = 423
    value = 368979
    text = __import__('base64').b64decode('bG02TEVqbTNJMXJGaWliS19XQWo=').decode('utf-8')
    if False and True:
        _dead_1978 = 124
    total = value + len(text)
    return total

def _ЧΖЛΕΧφШяδЯΧеΥΟ():
    value = 982698
    text = __import__('base64').b64decode('azBDTkJ4bUFDVFdQbDRFVTdSdkg=').decode('utf-8')
    total = value + len(text)
    if 76 * 6 < 0:
        pass
    return total

def _ИУυζΖЧюрВΦΔмμду():
    value = 465640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An3oW0YM6742aCOC8X++BC4I1lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΝΘαДΣАгЩδЖЙхξЪю():
    value = 578347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxztWVI37ZAnIiCR4A7IAyYl13c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВζКΩпκАΤХнψ():
    value = 310528
    if False and True:
        _dead_5105 = 699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXz0PgZp8oQmYgmJ6lG9B3cr100='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 85 * 47 < 0:
        _dead_3921 = 533
        pass
    return total

def _υГΑЪчδНФλТλВШ():
    if 72 * 80 < 0:
        pass
        pass
        pass
    value = 900124
    text = __import__('base64').b64decode('VXNYVVprZEV5S21EWUFJMXZZUEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΜуζΦсκктΠθΑ():
    value = 945449
    text = __import__('base64').b64decode('YmJDWlNkdVVBbkJzdzI4ZmFhVjk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        279
    return total

def _ΘаХшσЦРΕ():
    value = 731864
    text = __import__('base64').b64decode('cUxXWHU0MmxUOU5CTVdvcktFeWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ВПВЧΙζГΨφУаΨаЬ():
    value = 332230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASyydHg326xVEyeynl23DTI4tXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωηЭνНΤщВνк():
    if False and True:
        _dead_9480 = 828
    value = 122455
    if False and True:
        _dead_3332 = 359
        277
        pass
    text = __import__('base64').b64decode('eUt4WmIybjJYcnJFRnpsaEpUdVk=').decode('utf-8')
    if 39 * 22 < 0:
        _dead_8028 = 138
        356
        379
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9960 = 541
        635
    return total

def _ТΠНΣΘАΒиρΓΜИь():
    value = 225210
    text = __import__('base64').b64decode('Y1RPMmY0QzhETzRUMGNpa1l0Vzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓεΘкΝЙΚΘΩφщНОЖΟν():
    value = 433102
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD3lPWEIrfwWLCOx/mKeAhUu7z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μωАРΣΗЬХ():
    value = 774467
    if False and True:
        _dead_7627 = 43
        _dead_3098 = 756
        618
    text = __import__('base64').b64decode('UmdET212UkJteHV0Y0FQM1hWNGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΓьЙщΗСριΣАЛигξ():
    if False and True:
        _dead_5415 = 363
        pass
        290
    value = 923163
    if False and True:
        391
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhniZgktroUgax6cz1mvFg143ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧρъΟΤАщχУф():
    value = 602783
    if len('') > 0:
        412
        _dead_7469 = 26
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX3OamAp/5hRKhWg+3GoCwM97lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 24 * 3 < 0:
        _dead_1394 = 744
    return total

def _ШНΘχзβНямпΜζмΠ():
    value = 646425
    text = __import__('base64').b64decode('dFpEZmt1M2JVV05DaFE0bnZKUTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩцμеЫзазЦЖ():
    value = 429435
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx3eSFMe97g8KSmT0WK8ZgYnyk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3077 = 964
        714
    return total

def _ΓΤЧаЛςΛвПАийщ():
    value = 884473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRDRbwg9yqkRHAWcw0aFABB4/Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΥυрбΧДююАБΗ():
    value = 25806
    text = __import__('base64').b64decode('UXcwd3ZuMGxfVHVyMVcyS3lsQnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _тαЕΣΤшρЬшСθЗ():
    value = 668541
    text = __import__('base64').b64decode('enpWdXpKMlU5U1NFNk5DcTc3WUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪыΑФΧΚВπеυМ():
    value = 490830
    text = __import__('base64').b64decode('SURtY0JfRm44REljSWJFVTN0MFM=').decode('utf-8')
    total = value + len(text)
    return total

def _АжЛψΒνχшПΛрμκуι():
    if 71 * 47 < 0:
        pass
        pass
        412
    value = 711687
    text = __import__('base64').b64decode('TkJIbTJvYXZvVjJYUFRTMVNaOW0=').decode('utf-8')
    total = value + len(text)
    return total

def _УъΨцНпшЫЭρТ():
    if 42 * 52 < 0:
        742
        _dead_5920 = 766
        _dead_5943 = 721
    value = 162010
    if False and True:
        _dead_4957 = 889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSS1QlYB3fsuEFi6212fOhojwFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лχцУръΘЩΧш():
    value = 386273
    if False and True:
        pass
        _dead_7189 = 543
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQmybARh9bEANi2u70C2PyM6x10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7599 = 317
        848
    total = value + len(text)
    return total

def _щЙПШρэαЙ():
    value = 911074
    text = __import__('base64').b64decode('ZHdjbENlZmxfa05Ka0VpeUZicGI=').decode('utf-8')
    total = value + len(text)
    return total

def _εЬАΟъΟωцФоЗС():
    value = 28638
    text = __import__('base64').b64decode('Z05xUUF3UXRabVdPVHRhQUlsMXQ=').decode('utf-8')
    if False and True:
        pass
        _dead_6139 = 873
    total = value + len(text)
    return total

def _εмγбςΑδЙ():
    if len('') > 0:
        pass
    value = 506483
    text = __import__('base64').b64decode('UU40blI0dmNPWXVKWThSS2lpSFI=').decode('utf-8')
    total = value + len(text)
    return total

def _γщщКΝБυуχз():
    value = 610170
    text = __import__('base64').b64decode('WVZ5SkpJUGx3MFljRk8yUjMzSFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖЖдАдΟαξΔты():
    value = 655870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CS7AW1sg8/grYiqQ4HKcGSkg/jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вβэΦГыДεΕц():
    value = 62164
    text = __import__('base64').b64decode('TlJuTkVXQ2RTX3p6SUZCYmg4MlU=').decode('utf-8')
    total = value + len(text)
    if 71 * 29 < 0:
        _dead_2419 = 689
        _dead_2637 = 678
        _dead_3294 = 427
    return total

def _ΥΙЫκΛцсэщзВЧсηФХ():
    value = 110844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzjCZmY99/taIyW67GDBIAp+6ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΒзЖδЙьщ():
    value = 26610
    text = __import__('base64').b64decode('bFdnTGx5ZndUQW16QXlqVU5iY2I=').decode('utf-8')
    total = value + len(text)
    if 62 * 69 < 0:
        _dead_5558 = 307
    return total

def _ΝюрЯБчνΒαξΠ():
    value = 119722
    text = __import__('base64').b64decode('SnlRNl9aMWdqNVJ0MncxSkNWRTA=').decode('utf-8')
    total = value + len(text)
    if 42 * 59 < 0:
        _dead_2480 = 584
    return total

def _οбнЦΙЮυйθ():
    value = 328034
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwP8f3UY8KYNIh+uzWmaYSQk82A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыВξΤλςΞΜгС():
    value = 520197
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgPhPFoB/K4mLQmB5l+5GRw66Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟφρШФеюΜεйыψХΑΨ():
    value = 531650
    text = __import__('base64').b64decode('TzR4QmRPQ255R2tsamtpUlBQMG8=').decode('utf-8')
    total = value + len(text)
    return total

def _νбЧπдΝΗуΡБЕгνЙΙ():
    value = 31298
    text = __import__('base64').b64decode('aTRlSzBidElmQnlEYm1kOXBGbWE=').decode('utf-8')
    total = value + len(text)
    return total

def _НшΨθξЧЩъснτф():
    value = 35220
    text = __import__('base64').b64decode('RjlNcDVpWjhhMVRnWU9fQXhWYnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЩЮФνМзΖлΠ():
    value = 22544
    text = __import__('base64').b64decode('QlhwRktod3RTRGdPNldESXJqMmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛΒХтЫΠНλду():
    if False and True:
        3
        pass
        pass
    value = 464304
    text = __import__('base64').b64decode('a0ZLWnNTN3NsZUhDZG9JUUFtcl8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        971
    return total

def _ΠηΑпΙЗεΡ():
    value = 211901
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgbwYQA2zIAiCDe63EyTERMYvXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝσвΑΜΔвЯολμηбзэ():
    value = 77071
    if len('') > 0:
        66
        _dead_7049 = 55
        _dead_7296 = 749
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ngj2R3Uh25lVMSiV8X6oGyMG4lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юΡтοΖμмгсЪбΔ():
    if 48 * 8 < 0:
        pass
        802
    value = 205064
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyL0YFYbr54yExaTzWWjYjEt43k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КОВцλΡяЬЗ():
    if 4 * 53 < 0:
        pass
        pass
    value = 262745
    if len('') > 0:
        _dead_1255 = 886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyDeYVM6x78SbQyC3VSaGxMQ8Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 20 * 47 < 0:
        _dead_3388 = 474
    total = value + len(text)
    if False and True:
        _dead_2523 = 22
    return total

def _ΔжзδΝхκδэвХζοИφЬ():
    value = 916001
    if 39 * 49 < 0:
        pass
    text = __import__('base64').b64decode('dVZ5WElQbURKUDFJZjhpaWdQbkg=').decode('utf-8')
    if len('') > 0:
        50
        30
        pass
    total = value + len(text)
    if 61 * 51 < 0:
        250
        pass
        55
    return total

def _ΩςΣОЮρΩθАд():
    value = 861808
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3vnRHYM77xbMgGI4nPCGDYaylk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОсΨюΗщηЧΒ():
    value = 392725
    text = __import__('base64').b64decode('dHluTzBCeUtwU1p3cGpFOGZzX2U=').decode('utf-8')
    total = value + len(text)
    return total

def _δΓцгЯОΕФφчθκлμςτ():
    if False and True:
        pass
    value = 919034
    if len('') > 0:
        112
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxW1XmMjz7gEPAegyWWhZQgttGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        61
    total = value + len(text)
    return total

def _дλыπγкинцι():
    value = 938340
    if False and True:
        77
        18
    text = __import__('base64').b64decode('R0p2QWNpU1hpR01zOTdQMngycFk=').decode('utf-8')
    total = value + len(text)
    return total

def _нщχΕΒУЕβκтοх():
    value = 108484
    if False and True:
        _dead_1250 = 372
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET3GUUcfrocHLB6ny0OpAyo83VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 60 * 42 < 0:
        615
        227
    total = value + len(text)
    return total

def _ΛьвЖεяпλЭρТ():
    if 96 * 32 < 0:
        961
        _dead_6230 = 552
    value = 711983
    text = __import__('base64').b64decode('Q3JGN1JHbms1ZUhVRGlpOUZfUzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΑΝΔэЗыΠΚθμ():
    value = 415889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ7eRV0Qz60RHy3y4FyiGgMdt1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΚΖμьЬЛΡШъУВ():
    value = 799174
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwbgWngtyJw5C16wwFeEIC0e0mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цлδуΧОΔυОμн():
    value = 394916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pzmyb1I62foqAgOG2luTHRMCsGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чεсэХюХКе():
    value = 986610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTnTTX1u25k1CzurnHeEHA0ns0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιΒЦΚεЪбАКц():
    if 96 * 60 < 0:
        634
        373
        852
    value = 538839
    text = __import__('base64').b64decode('aWVvWHFWcG5JVTh2V0Eyd09yMk4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        631
        _dead_4046 = 200
        356
    return total

def _ΒбΔйМШψχ():
    value = 195510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw7hVAEv+vsCLyr3nlK3EAoN4n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΑоΡνΡЫΣΕι():
    value = 21929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCfwfl877oEEYgqimWemHDN81Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΡψОЖрГйЙΘΒΣ():
    if len('') > 0:
        _dead_4726 = 823
        714
    value = 731838
    if False and True:
        _dead_5838 = 372
        588
        _dead_6760 = 473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyzwQ2YWppwwCzCE8U+iMHwk50I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 91 * 38 < 0:
        580
        157
        _dead_9519 = 91
    return total

def _ЬμШγэΖвΓИЩрфЖхяγ():
    value = 834677
    text = __import__('base64').b64decode('djg0VEtBWUtncWJuZnBocVFveHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΣШΛΟΘхЮмАз():
    value = 681752
    text = __import__('base64').b64decode('ZENXQXNaOW1VVjNQS3BIZ05xWXQ=').decode('utf-8')
    if 28 * 5 < 0:
        pass
        795
        _dead_2021 = 540
    total = value + len(text)
    return total

def _ЪСΨνПэФеψхРхдД():
    value = 508764
    if 19 * 91 < 0:
        _dead_1032 = 71
        _dead_5076 = 727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh/ia2sM17kGPiDz62+3IhB6szc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βжεввмПаЪзоЛкννо():
    value = 960798
    text = __import__('base64').b64decode('d0l1RDNKRUE1SVkycmNwUEhadVg=').decode('utf-8')
    total = value + len(text)
    return total

def _чИφδΠлЩΩΑпЦыоφΛΕ():
    value = 133643
    if len('') > 0:
        _dead_7446 = 955
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQbrWHto+IE3DT/27WWKI3IOyFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5175 = 914
        _dead_8677 = 411
    return total

def _щΥκКФπΜΓПν():
    value = 894703
    text = __import__('base64').b64decode('czljSWI4akNhOEh2OFQ2VUoyX2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘфюяФБΠШλэΕхΘиНΤ():
    value = 940468
    text = __import__('base64').b64decode('V1YwdGxzb3pjNmo1U3RWV2I4TFc=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        506
    return total

def _χΟΓЕяшдФЯЙЮХρΞΘ():
    value = 397380
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHbHRks/poQqLBn0mUW8ORcr0UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        157
        _dead_1335 = 603
        546
    return total

def _ЬΩДяШγσоΣюВьΛΓπ():
    value = 479993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzjHfFo8qa9QbgaT6m6TYgQo7zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωτφωлшΚХΑμπζулφ():
    value = 68813
    text = __import__('base64').b64decode('RVY3YmM4WmxveUZxeW5Zd3RaaEE=').decode('utf-8')
    total = value + len(text)
    return total

def _эЭΦьэΘΗΕΟьвωщЬ():
    value = 160658
    text = __import__('base64').b64decode('eHRFOVV2UmU3QzFnSXp4cVdHblQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЖСΞнаЧЦФаЫДкРΕЕ():
    value = 57770
    text = __import__('base64').b64decode('Skw3QzRuRnp5WnFOd2ZrbndkN0g=').decode('utf-8')
    total = value + len(text)
    return total

def _сσшξΨЧрΛоьтВΣЬк():
    if 8 * 60 < 0:
        417
        _dead_9350 = 621
    value = 657059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHfAQgAeqL0yKi2ZzgWVYS8FyGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 79 < 0:
        pass
        _dead_4536 = 113
    total = value + len(text)
    return total

def _РψУФΡαФЧл():
    if len('') > 0:
        pass
        _dead_5631 = 781
        pass
    value = 247928
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCzoVH8N3PgtIzeW8lGfEB8bsT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δБбБЦηαφюжЬЗт():
    value = 295530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQOxXXkKq/4taTeX2lXDYXwlsl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΥΓНЖεСйΖоЕλ():
    value = 187999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAm2P3QMx55bFCmUnlyYGQN99ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 43 < 0:
        191
        _dead_5975 = 481
        pass
    total = value + len(text)
    return total

def _ЬΠεЕКЭΦθιΨΠФЛсЯχ():
    value = 150816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgDPVHwRp4BQOQqxn3iGODJ7wlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮσАьДИξд():
    value = 380215
    text = __import__('base64').b64decode('dU1fdDByNlVlbnZUOFZpUHJlVFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔοЪθЬΕмгγΑΔозЧНЕ():
    value = 826651
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAzsZ2cv6oIJYjaH912hOQ4oxn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΑφΣΕъЮΘςШ():
    value = 519278
    text = __import__('base64').b64decode('TUpvNWFyMWd3N1hIOHo0RDNVMWw=').decode('utf-8')
    total = value + len(text)
    return total

def _σΑΙДАθюоЦκΒГм():
    value = 894417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxrLPVs9wbkCYiWk0lm3Gncj1GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ποиюζζюβμБ():
    value = 840947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy3oXnkayJ0AEwmAxWW6Pj0dyXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъЭыаЕνюЧΥΝЩдβΖ():
    value = 711602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwPhTWFuq5saIzq2mWOzJgd2sH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хЬрΧφφыγΚΧПσαВ():
    value = 600319
    text = __import__('base64').b64decode('bDNYVzlzcTl1TXlLWkx6WVphQ3c=').decode('utf-8')
    total = value + len(text)
    return total

def _вШаМψРвοцΞЭл():
    value = 962416
    if len('') > 0:
        pass
        21
    text = __import__('base64').b64decode('RTRLcG5VWDJnaTRzZVFLQnByTmk=').decode('utf-8')
    if 100 * 52 < 0:
        595
        478
        _dead_1783 = 89
    total = value + len(text)
    return total

def _олЕцЮуψС():
    value = 535659
    text = __import__('base64').b64decode('QXBZQU05TEsxREI4eERfUmNXbGE=').decode('utf-8')
    total = value + len(text)
    return total

def _λΡΗУζСЕЖЯΟΤεΝЦγИ():
    value = 997224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQLnW14B0K8kDBu7/3+mPS588E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПГακμΗбТΓΚЫΒζь():
    value = 693072
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQLef1w7yP8KN1uG3XGKECYc3Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 82 * 81 < 0:
        88
        867
        927
    return total

def _пΚХлТшРй():
    if False and True:
        pass
        _dead_2724 = 376
    value = 639555
    text = __import__('base64').b64decode('QTdoVnpIU04xOGVzTW52dnhFWGI=').decode('utf-8')
    total = value + len(text)
    if 88 * 13 < 0:
        pass
        565
    return total

def _δΝщгΚэААШ():
    value = 652665
    text = __import__('base64').b64decode('U2ZJWkNNZGdfSGo3MmM1dHBoRkk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4462 = 17
        pass
    return total

def _νчαШΔдχРρ():
    value = 697970
    text = __import__('base64').b64decode('VTk2QUhMczFrYUZGUWh3eGhTcHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ШΘψΗБбζеΖΦвδЫЛШХ():
    value = 810357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bxj8eGMTrrokLx/2mkC4GikuwmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4295 = 680
        pass
        pass
    total = value + len(text)
    return total

def _ΛцЬωΚйЪщΚМЫМ():
    value = 427456
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjXwOEAg3KA0FguZyV29Fwg87mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γоθΡТУМΦ():
    if 35 * 93 < 0:
        142
        pass
    value = 395707
    text = __import__('base64').b64decode('SVlyb0lPYmtDOEFpbWxidFp6ZmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔмТμшΛкл():
    value = 755331
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lgz8RAVqqf5WIhyo+1XEHwk27UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σУΡЖПЕΔΣΖ():
    value = 581844
    if 84 * 56 < 0:
        pass
    text = __import__('base64').b64decode('YjlGdzlqeEFURE1jNTZSYkNFU3Y=').decode('utf-8')
    total = value + len(text)
    if 28 * 40 < 0:
        _dead_9966 = 289
        _dead_4961 = 652
    return total

def _йЪяЯΣЩΣΓУμΛ():
    if len('') > 0:
        pass
    value = 382750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyHyeWI+84QhHlmk6n3IHysi5Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 38 * 84 < 0:
        711
    total = value + len(text)
    return total

def _ХΝΓЦЫξаσКЛчΟ():
    value = 32234
    text = __import__('base64').b64decode('RTlIRGpqT1NNdlVwOXlXZU12QjM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8190 = 468
        _dead_3760 = 85
    return total

def _ГΟСЗχИХΗфΕυп():
    value = 885514
    text = __import__('base64').b64decode('RzhsN0lvR1hnSVZOTnJ1c0JkeHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЗЫκЗνроΖЮλρОч():
    value = 942653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCTWOnYa+PolaSuv5kLDDTYsvG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6264 = 792
        _dead_6398 = 951
    total = value + len(text)
    if False and True:
        pass
        _dead_2703 = 323
        pass
    return total

def _шΠоСшερзщ():
    value = 542161
    text = __import__('base64').b64decode('Um1GRFFkaXM4MEdnYnFSMFFOdG0=').decode('utf-8')
    total = value + len(text)
    return total

def _жФпπчиθΟЫ():
    value = 724566
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KALCVm4frLgLKiy28mCILA4Yylo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хэλδцаγтМрΠфУ():
    value = 133980
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH3NX0U+qZkqAhyn+gaTNnA73UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟБνΜτЕЫζыуЗДЬ():
    value = 568103
    text = __import__('base64').b64decode('YklTakt0WXU4bmZVNlpXRkhESUg=').decode('utf-8')
    total = value + len(text)
    if 1 * 35 < 0:
        _dead_6808 = 614
        pass
    return total

def _φιΨΣфδЕХΠυШ():
    value = 973043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwW3PXNh7LsNCF3x4Aa8B3YC/D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚбыЩеτщэΞЛνхΕъ():
    value = 410114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHbgTVkDwfkKIxyFkHO8Ogx+/UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        29
        pass
        293
    return total

def _ωМЫЭХЕθωъьгэυн():
    value = 588586
    if 33 * 20 < 0:
        508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IB7PP0gO5IomPDf23FmSNip64Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κυЦаΧТμΡβΒΖβνх():
    value = 126405
    text = __import__('base64').b64decode('RUJjcHBfU29oSU5vZFJjQU1oak8=').decode('utf-8')
    total = value + len(text)
    return total

def _МДЧЛъΔΜαяУы():
    value = 726979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwHoRkYowbgXERmW4WSUFQYu6XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δЫΘяеХЦΡнΤ():
    value = 807511
    text = __import__('base64').b64decode('bmpiYnB5NExXRjEzOXg0dXRpOTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _сЦНАγКлЙЦнКм():
    value = 735144
    text = __import__('base64').b64decode('TWF0V2xiZUlVaVNTQzRqSVBaZ2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕμдΙФТΗКηжПвюυ():
    value = 850225
    if len('') > 0:
        _dead_3650 = 224
        _dead_1338 = 946
    text = __import__('base64').b64decode('YTZHR2lIYzJCZnpPUXZxd0lvTVg=').decode('utf-8')
    if len('') > 0:
        _dead_6252 = 686
        pass
        pass
    total = value + len(text)
    return total

def _ΑΨпРΙНДΟΥΘ():
    value = 234019
    text = __import__('base64').b64decode('cDFOZUFxR3pkYTBaUUpnQ2ZhU1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ζпΜбΓрВηΑзИΓМ():
    value = 919225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz/UfEsvp7AgbyC2mmzCAiAK6jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΠЭюеΥζЯЗУ():
    value = 271950
    if 19 * 29 < 0:
        _dead_2428 = 448
        _dead_5939 = 693
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA7OYGRu8ak3KiX2ywXDNjMu010='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θγγΠЩГФΝ():
    value = 683052
    text = __import__('base64').b64decode('RHBkXzA2VlJpWXpKbnlHbTBRR0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _πςπΞθГΚΨкμ():
    value = 935493
    text = __import__('base64').b64decode('bk5wQmVnd0VVWExQOHJqV05hSUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕТаФρеμθ():
    value = 472588
    text = __import__('base64').b64decode('S0JOUUJnWVF2aFlCM0VFbVpCNEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ьЦюЩЭГАΥзσТωθУк():
    value = 637837
    if len('') > 0:
        pass
        219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L37QQnsc9ZdVMAaLzW++AAwitlc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨШбΑЭГэЪЪГ():
    value = 610447
    if len('') > 0:
        pass
        pass
        841
    text = __import__('base64').b64decode('Vzl6ZjRqQ0pKelFHODV5THdveHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ζИχкΥчащ():
    value = 897192
    text = __import__('base64').b64decode('TTBYMVZkcHRIV2UyMkUzSWJfVk4=').decode('utf-8')
    total = value + len(text)
    return total

def _юЕιсВтъЦП():
    value = 562800
    text = __import__('base64').b64decode('eDN5c2dGeVZlWjhETGpUblg2b3k=').decode('utf-8')
    if False and True:
        _dead_5105 = 252
        45
        _dead_5780 = 937
    total = value + len(text)
    return total

def _ΣДщтяχνΘΔыа():
    value = 959254
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA39bXArxIkXAyX74n3BJjQ172U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦСЙмДεЯхΣΩЬΓуАΗ():
    value = 294617
    if len('') > 0:
        _dead_7118 = 455
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQqzP3MJq4BVaFumzgKELCMFsnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 97 * 91 < 0:
        _dead_8595 = 395
    return total

def _чΟςвΟοπεцкчуьχ():
    if 72 * 50 < 0:
        _dead_6793 = 769
    value = 308113
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhjhQ2JozK0kEViVwH6XEj93wGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αЛнлΜщКСздλλΘЛ():
    value = 658422
    text = __import__('base64').b64decode('RGtXRVZfZjZESnVzcGFoZHNZNUY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _йευΠеКчυЦФΨг():
    value = 404624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQ6zXVpu6ocNNRy29weEBDQ3yX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СпΖБЧΒчмГь():
    if False and True:
        _dead_9195 = 708
    value = 632057
    text = __import__('base64').b64decode('Tzc4QnBNVklrMWlYV1FhVTF4S1A=').decode('utf-8')
    total = value + len(text)
    if False and True:
        856
    return total

def _ИΚйΥУΝΧмх():
    if 9 * 13 < 0:
        977
        _dead_9521 = 306
        pass
    value = 75960
    if 68 * 72 < 0:
        820
        681
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjXgfwAA6pkyHxaM/GC/OCA81E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЛИСжαЪДΠдрБΟΣэГ():
    value = 935049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz69fGdg9LgBGCSC8nGyAnMut1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γЗнδвυШФγλюээНδΚ():
    value = 725033
    if len('') > 0:
        pass
        _dead_9810 = 844
    text = __import__('base64').b64decode('VlR2cExKek5RVlFBTDE1Nl9uUHg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7054 = 824
        190
    return total

def _φщцПΒΖЛυЪΨζАΖЛн():
    value = 66424
    text = __import__('base64').b64decode('d0dLalFpVUppNTZWSW91dDUxV3E=').decode('utf-8')
    total = value + len(text)
    return total

def _φдοΟШчεΥιлЧБсДшу():
    value = 556042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh3UbwAOrqoAax+ckHCYYjEJz3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΝΣОТДИжηь():
    value = 851421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JirGaAY+9qYZPCeywVCyZ3QY10U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΜςΒнΦОЛκвΨςйΗН():
    value = 551376
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JynTa1th+qM7DAqL0XXIMwo3738='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιчΩβθΦЪзΓτωАжЕлΡ():
    value = 423241
    text = __import__('base64').b64decode('TGtMcTBQSGhkajUzUktTM3hIQ1M=').decode('utf-8')
    total = value + len(text)
    return total

def _λΝЦыαΙбεГνжΞКИн():
    value = 16775
    text = __import__('base64').b64decode('cXNuOWgzMDRpdEtxTTN5RkMwSkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΧМΒβЦВΜΡ():
    value = 426586
    text = __import__('base64').b64decode('UEtCbHVic1pNdnI4R2lKRUtmSlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ИыπεмЪΘРнзΨ():
    value = 78709
    text = __import__('base64').b64decode('Ykk1dFJDRm42MG5udmhmd3pZYzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ωСЦπтπьΛ():
    value = 648244
    text = __import__('base64').b64decode('WVdac2Q1Y2JVU0lra3Q3Nk16RmU=').decode('utf-8')
    total = value + len(text)
    return total

def _υβбΨΙτπЩΣςП():
    value = 723558
    text = __import__('base64').b64decode('eFY4ems0X3hlYzR2UkpCNFJhZUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΦΨΛШуСςТХΑмЗ():
    value = 876398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ND6xWXkx+IcCAgSH4QWhAzN33V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 64 * 45 < 0:
        300
    return total

def _ЖКδοΑΥολΨюδР():
    if len('') > 0:
        pass
    value = 409233
    text = __import__('base64').b64decode('SHJzRFBDcXlXWjR5WGNqVUxib3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ιТΖмуΗФιпОκ():
    if False and True:
        pass
    value = 478548
    if 23 * 4 < 0:
        _dead_5730 = 887
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgbTVwUs3JgxIxy67EK8IxoexVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юΝкЕЪсмиАфвПρΒΔх():
    if 65 * 67 < 0:
        pass
        _dead_8269 = 14
    value = 36846
    if 52 * 28 < 0:
        pass
    text = __import__('base64').b64decode('YXNKYm5YQzR1Nlp6bE8wOEhzUnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _СΙΛπηςΨεтб():
    if len('') > 0:
        244
        609
        825
    value = 646845
    text = __import__('base64').b64decode('YXh5WlZFRzJxbWVMVlV0TzFyVmE=').decode('utf-8')
    total = value + len(text)
    return total

def _юБδΡζςищΚ():
    if 19 * 37 < 0:
        485
    value = 644274
    text = __import__('base64').b64decode('Rnl4TFp2X09yWG94TXgxQkR0UjU=').decode('utf-8')
    if False and True:
        _dead_2341 = 47
        2
        pass
    total = value + len(text)
    return total

def _ΥΚΝЧЮΔРΨυΒЫОΠ():
    value = 36737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSXCT3Yhz6QxGxWtw3SiZXcX4j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цеУьЭмИфγτ():
    value = 632646
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwXTWVM784clPxeCzVKcMjEg1GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъМаФиЦявΞΛыωι():
    value = 191173
    text = __import__('base64').b64decode('QTBnZmdpaHhENklQcHg3Z0hDeHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΤΧНΑΨЙпаλэΛюм():
    value = 56367
    text = __import__('base64').b64decode('ZHpXUGFkY1dRRGdZcDlDQVhadFc=').decode('utf-8')
    total = value + len(text)
    return total

def _иЦКΟСΘцζΖиЩσЕфξν():
    value = 972727
    text = __import__('base64').b64decode('SEhHdzN2Q0pKdFBuTEhCSWZLSWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if len('xx') > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    819
    pass