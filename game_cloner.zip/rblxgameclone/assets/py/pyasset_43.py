#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ςΓФνςАΚρΥτΘДч():
    value = 830399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSjCVHgD75lbMyeVmkW9YSoN9GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йσълΡφЙГΕлФЗЪЕΛН():
    if False and True:
        948
        _dead_2787 = 170
    value = 517621
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQbpQVw0z51VKhaU/3W8YDB4xVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьОЗξςлШΝРЧэΖУΑФб():
    value = 649185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxjSfQRvz6ssDTeN3WaWO3MM5z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νЧпΟнЬЛτЯΕΗС():
    value = 500705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhbebwkU3a8iFAip53G7Fxoe4XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 91 * 100 < 0:
        _dead_3986 = 943
        pass
    total = value + len(text)
    return total

def _ΖζМΟΠяΣАйρюЧζΡκЫ():
    value = 329327
    text = __import__('base64').b64decode('S3FhbE52cUhES0JjVzdDSWdOamM=').decode('utf-8')
    total = value + len(text)
    return total

def _αГЫΡЖЙМшвцЬ():
    value = 296436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwzpXnUc8vAwIj6U7HWCHzUg9H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χОΑТЮдшΠМщЫζнΩсВ():
    if False and True:
        _dead_8927 = 2
        _dead_9300 = 826
    value = 757000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzXcdkdh7JsJPRuC0gO/LDJ+9G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΜжОсыχξτγυΗЮР():
    if len('') > 0:
        pass
    value = 379183
    if False and True:
        _dead_8103 = 182
    text = __import__('base64').b64decode('bEVMOWU3UFhaa3dKR3JzcnpNS0c=').decode('utf-8')
    total = value + len(text)
    return total

def _жЦΦζΙηφНΠЙрп():
    value = 290738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRjNSnIA5Kc2PC2HwFmfARd+8Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κλΤЛУСΝιв():
    value = 440191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHf0bwQDqI5VOySg/UGaGBoo1Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΜΘАβΛΤХεΑЗΚДБθх():
    value = 946387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB6xTFQGy4UiKCOoxXDJExF421c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩοΘλаΠЩдУЯΥξ():
    value = 670882
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCLNSgJq1ZsLFjWrx0eCJTYH6jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _НυωоШμμΠЯΒАην():
    value = 532859
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('enk1UzhfNThEaHJtUFFlVlRCeGk=').decode('utf-8')
    if len('') > 0:
        _dead_3618 = 620
        pass
        _dead_1740 = 923
    total = value + len(text)
    if len('') > 0:
        637
        39
    return total

def _ΙрГΗΒмйΦΝΗΟз():
    if len('') > 0:
        423
    value = 135912
    text = __import__('base64').b64decode('Q2xsZE53SzVHTUN1SUR0WUpmSTQ=').decode('utf-8')
    total = value + len(text)
    if 61 * 62 < 0:
        456
    return total

def _υтЙьΑΣэψΨьКСм():
    value = 92809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih3LdmEOzZEzYzminlmCJjMcwT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        415
        _dead_3274 = 483
    return total

def _ΤуδУЭшΓΥдщвНТ():
    value = 132082
    if 76 * 21 < 0:
        257
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax7KX0Qdz4Qlal6nzXLFMgsBwH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _жМΠыβιθεищЯΤ():
    value = 329801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDnmRAds6aw2PxWl3wCUbC83xl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡηщнАΦбЗдЯΩΓ():
    value = 830876
    text = __import__('base64').b64decode('cmJQVE9ZeFpsbFFuRjZ6MFlKQmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙПЧЦЗρΨВэΥΟΚφ():
    if False and True:
        497
    value = 621373
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQPPfWkc77gKYgmt3n/FET14zjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЕъзУйυμ():
    value = 154210
    text = __import__('base64').b64decode('cEtlc2NUUWluM0t3QTZIS1RMaHQ=').decode('utf-8')
    if 90 * 67 < 0:
        pass
        _dead_5826 = 860
        pass
    total = value + len(text)
    return total

def _ЫΖЧΑХвТзγψлТζа():
    value = 166568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXfQZ1kJx/guaCWS3HjILTEd81w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κψοΚАλЩВЫОΔΑШГ():
    value = 785011
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzXCRklu5PEaADyu0U++Jjcu6FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иρЧзлхκΟ():
    value = 387604
    text = __import__('base64').b64decode('cDlwYVZHQ3ljOVJUbk5faXFfdUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖмμДΡСΟбξΥηΣσъΤ():
    value = 67401
    if len('') > 0:
        415
        979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQD1PEVu+qYGLDil/GemExYB4X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 23 * 26 < 0:
        _dead_9241 = 763
    total = value + len(text)
    if False and True:
        pass
        512
    return total

def _ПωφΗΑΨΖБΔЩ():
    value = 913688
    text = __import__('base64').b64decode('WEpsdUVFOFRMODQ4YkVHNWx1OHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙηауψпΚх():
    if False and True:
        171
        pass
        218
    value = 82324
    if len('') > 0:
        377
    text = __import__('base64').b64decode('aXlQTk00VUtidjk4Mm5qWkRWRDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΚνЧΠтшξπгЫД():
    value = 22041
    text = __import__('base64').b64decode('VE4wZVVBR3hESVV6eGpEeGhFQW4=').decode('utf-8')
    if len('') > 0:
        _dead_2926 = 769
        966
        _dead_2756 = 725
    total = value + len(text)
    if False and True:
        pass
    return total

def _ιКΓγιДъсΞΔΕυεωц():
    if len('') > 0:
        pass
        204
    value = 272127
    if False and True:
        461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTn8WGZsrb1TNDuC5Q6lGzA25j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шэФΠЛΨипξ():
    value = 957487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSHlO3U08qElHgO3kV3FDgQtxko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΕГФаχΦФЬжюςзЙОЯ():
    value = 646432
    text = __import__('base64').b64decode('U1pZeVROU1BUczNBOGl0bVllZkQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _цωОΛъгΤьаЩτ():
    value = 419696
    text = __import__('base64').b64decode('Q1N5TzVBRU9DYnhaOWhYWTdnNjc=').decode('utf-8')
    total = value + len(text)
    return total

def _геτяΕλΗОоσДАΞГθΘ():
    value = 936196
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCrDTVMYqP0FGSGX+UKxYQoexzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оУШοТКΚХσς():
    value = 269809
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRm8RUtp6681Yyr0926ADT0j3nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7561 = 86
    return total

def _ΩюχΓйНоδΚιΘЙ():
    value = 186965
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzjcT383/fpQM1i35HS8HXB/8F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΖмХЯПУΕωФ():
    value = 587090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwX2Nnga2aMlEDew3Q+4ZDUJ41Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝπнςЗЬжΓφФΓЦоБΥт():
    value = 176596
    text = __import__('base64').b64decode('SThXdVFLdjM1UUdlNnlZbGNEWWg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΥпМααтчэФгЫκτщπД():
    value = 31540
    text = __import__('base64').b64decode('bzZmS3ROYlc4UFpnaVhWQlpCc2U=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _юрэЦоЯЙηЫΠШ():
    value = 568799
    text = __import__('base64').b64decode('RjdmQV9aRlY2eVRWZUZJc0pqRl8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒЮΤуοнЗυαΖ():
    value = 543430
    text = __import__('base64').b64decode('ZmNVSkc0amsyWVRDdFJkU3BSZTU=').decode('utf-8')
    total = value + len(text)
    return total

def _αηпТβеЙяΣσЕюдΖь():
    value = 338021
    text = __import__('base64').b64decode('VWlKMWdLS2J6N09NeU5KUUY4bTc=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ТκФΤМЖωΔςПХьξЭЪн():
    value = 46990
    if len('') > 0:
        _dead_5240 = 164
        pass
        _dead_5354 = 493
    text = __import__('base64').b64decode('Rm81YUNlanZEWHg4azFkRV9wTnY=').decode('utf-8')
    if 92 * 96 < 0:
        965
    total = value + len(text)
    return total

def _ЯфΜψΓιсЮη():
    if 67 * 71 < 0:
        pass
        pass
        953
    value = 648781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Agm3N2Q2/K8REgr6+1PJGXca6EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 1 * 100 < 0:
        _dead_2108 = 740
        pass
        _dead_7362 = 855
    return total

def _ΟηяБеΧвρΦκыг():
    value = 585791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwTXa1A21J8pHwGJ+W6VNil/tF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΖБοЮЛυЪКΗцμТВ():
    value = 382663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyX0Y1IS0bsaPVmG3liWAgZ+5kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΙВαωсΧΣαХ():
    value = 689854
    text = __import__('base64').b64decode('cnlueEpaTUpGY3J4TVVoWG5EMWs=').decode('utf-8')
    total = value + len(text)
    return total

def _фσΜДВΞΛΩ():
    if 91 * 44 < 0:
        _dead_5374 = 908
        809
        504
    value = 223175
    text = __import__('base64').b64decode('WnNLdDJNUmE2bW54NjRVMGMwOHo=').decode('utf-8')
    total = value + len(text)
    if 52 * 10 < 0:
        pass
    return total

def _СοГκιОрОЧζднЯςρж():
    value = 688420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByDrX3cR968hYgCs7VK7IzcQ/Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 90 * 75 < 0:
        pass
    return total

def _ΟЯдСρЪεМъвДВΑч():
    value = 117821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCfqN3U26IUXYxbxxVmGIHMrx3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤχщЭЩкюν():
    value = 123097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3neXGMj/PABFyW19wOEEwkexn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9059 = 696
        331
        81
    return total

def _йδявсаХлНуцΜ():
    if False and True:
        315
        pass
        pass
    value = 2459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSHAN1Yf2p45Dy31xmWzYxwK6kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χГъΝΛСδαЛВφ():
    value = 375609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTvXPVZv1IILAjuR3gbIIBwq8EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        92
    total = value + len(text)
    return total

def _σΖδяУОэт():
    value = 354711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHu3PQce8K0EbFr172bCDjEbtF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖГшЯΕпуΚΜΟцВРЫЛκ():
    if 6 * 60 < 0:
        554
        _dead_5273 = 11
    value = 817844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBflNmUv0rsTIAWM4ECJOAcY4H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟΙуΘΙМΣхλДЧ():
    if 58 * 35 < 0:
        98
    value = 678424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgPVbGdvyJxaMgqy4wPBZiQqwD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_9826 = 647
        _dead_1302 = 125
    return total

def _оοκЯζΔКΚγπ():
    value = 96971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAmzQEYU+YMWKlm23VqYDgg35Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΘкгςΓΗчεΨΒγчГП():
    value = 980638
    text = __import__('base64').b64decode('Sm5VSGF6amlvblNqZTl1dFBMS3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛщδАδЩΒМфЩΩмρ():
    value = 165664
    text = __import__('base64').b64decode('TE1JMnoxQU9haFNoSGxPRU9jZ00=').decode('utf-8')
    total = value + len(text)
    if 97 * 61 < 0:
        _dead_5119 = 405
    return total

def _μрΔωйВЪЗубΔΨТЭυ():
    value = 33662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng3tYGI3370oLF+z4gDHDA0s8Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИγЮНФдΚсуΦЧЭωΖ():
    value = 791099
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSrNR3po8fAPbCGGzkWoITR2/lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йШχАцпΟКжызΟ():
    value = 52603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBDDPkQTp6BbNl6PxnGjHB18yEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘЖнνлνκυЬφЫ():
    value = 736743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz/wY1QD/LEVbV+HkWPHCwZ50n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΦФΑкЭЧщЭСζΨПл():
    value = 317324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSvsZAkLxLsILDCxz3OlYwAQyEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2626 = 348
    total = value + len(text)
    return total

def _ЕξЩМΑйΑа():
    value = 761433
    text = __import__('base64').b64decode('Q2JIN2ZrZU1nMFY5cTl4Z3dMUjU=').decode('utf-8')
    total = value + len(text)
    if 83 * 89 < 0:
        pass
        _dead_6126 = 941
    return total

def _цζθшшΙтΝКωъюοц():
    value = 825692
    if False and True:
        _dead_3783 = 157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyH3VHMw2KoIKQeWnn6UCz961Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΞуρΜφκΧдЛвΜБΣη():
    value = 677449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgDcQwAd9vkoAgegygKfJAc9/FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        _dead_8108 = 250
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 11 * 79 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 50 * 97 < 0:
    _dead_1622 = 40
    _dead_5144 = 329
    pass