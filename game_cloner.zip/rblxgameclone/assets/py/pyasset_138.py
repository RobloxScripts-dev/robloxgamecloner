#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _θΓрΙЪθΑжЧСΖχ():
    value = 337022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pwi1am5t+KkrHgGlx1GpCysC7EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 50 < 0:
        _dead_2124 = 728
    total = value + len(text)
    return total

def _тΓХΘΚыЕСКЪΑλЭ():
    value = 644003
    text = __import__('base64').b64decode('QnFUd3dwTk1JblJKWkZZcmZNdUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ξЪЧΜвΙςаПть():
    value = 321275
    if len('') > 0:
        54
    text = __import__('base64').b64decode('TXlYcERLS0RiWERhNjNHN3Nza2I=').decode('utf-8')
    total = value + len(text)
    return total

def _тПζУЫуΖπκΝ():
    value = 550307
    text = __import__('base64').b64decode('UUVmdlFzZUxNbkdTdGdheUdKVUI=').decode('utf-8')
    total = value + len(text)
    return total

def _βвпγСρхΙνμ():
    value = 961105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MALIOQNqxK4KLCb2yQazBDck4EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒαЗбφцγωΙ():
    value = 413868
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwvXfwAu2IAOEiP63XzGCzwjzUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6523 = 142
    return total

def _χЪΩъυψаФАУжрΗΦκ():
    value = 415488
    text = __import__('base64').b64decode('WTVNY0Z0R1BEcmV2RnNqNFhYVms=').decode('utf-8')
    if False and True:
        pass
        757
        pass
    total = value + len(text)
    return total

def _ΣгМКЦЛЗυεΩ():
    if 51 * 56 < 0:
        _dead_3831 = 0
        pass
        558
    value = 360154
    text = __import__('base64').b64decode('YW5QZkhHOU1ET2VqTWJzR3N0SmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ιшοΕΥдρяКες():
    if len('') > 0:
        872
    value = 895616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB/RVgY086NQNgyixECRARAcxmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        198
        93
    total = value + len(text)
    return total

def _ΡшъЕЖНвжΨМ():
    value = 790869
    text = __import__('base64').b64decode('bGV3RFUwZ2JMQ3ZXMVV5UDU0SW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛгεйΑчбщΑЖтφΠАΡΞ():
    value = 62957
    text = __import__('base64').b64decode('ektpdW0yNjlhcnRNRWVZZnFmR0g=').decode('utf-8')
    total = value + len(text)
    if 26 * 92 < 0:
        _dead_9026 = 353
        pass
        pass
    return total

def _яХΝъЕΡНзвИθНΥ():
    value = 938865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhfhRVwU/6AgPg2g7GGbZggkzWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΞьшΘРΥΑга():
    value = 165499
    text = __import__('base64').b64decode('WXVyT1U1bWtKM21peEhVQzI5YWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟачцΤУовсδωнθЙπ():
    value = 322622
    text = __import__('base64').b64decode('aGpXY3NWS3cxUElSa3RoOUlSbmw=').decode('utf-8')
    total = value + len(text)
    return total

def _уΣБХсТΦΞМТιТи():
    if 56 * 7 < 0:
        _dead_3658 = 739
        _dead_8833 = 580
        145
    value = 369306
    text = __import__('base64').b64decode('bFZMOE5DYkF3Q2ZCYnRwMEFEdG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ρГρΟΡщехйΡбчς():
    value = 530734
    if False and True:
        438
    text = __import__('base64').b64decode('RGVIWmxOVmc1SHBwVjhLQ0dPZ24=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        369
    return total

def _ьΗдΓЯЙнξθйХзбΕ():
    if 52 * 80 < 0:
        330
        pass
    value = 46262
    if len('') > 0:
        _dead_8105 = 105
    text = __import__('base64').b64decode('T1VRTzJ0cXJFRWRPTTJsN3U3VVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨрМзμЖщЯЗпфσОΘ():
    value = 212978
    text = __import__('base64').b64decode('bnd4eldjSVJBbTlUdlcwN1hlbGc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩυΚτζΨОΥЧ():
    value = 361297
    if 76 * 74 < 0:
        759
        707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHzLQAA8rqcZAz6J+AKxGjIcy0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 67 * 38 < 0:
        _dead_7847 = 486
        _dead_4645 = 153
    return total

def _οРΣдОΠРγкΓΓρяЙх():
    if len('') > 0:
        _dead_4444 = 586
        _dead_9512 = 386
    value = 363401
    text = __import__('base64').b64decode('U3RSanluTWtYTVVLNnVJV2h2Tms=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦьшбьЭΨΤЭФ():
    value = 837199
    if 78 * 91 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzvlVmBg2ZE1bSi793eeIBYYz14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        286
        pass
    return total

def _жАСχчΗыΡπКμжмэ():
    if len('') > 0:
        pass
    value = 672678
    if len('') > 0:
        351
    text = __import__('base64').b64decode('UGYxdVFrUlhkU09La1VUNjgxeUo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4677 = 241
        pass
        _dead_2700 = 306
    return total

def _μФθΠцЩжΠДЩΒХ():
    value = 82686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCjVe1ID6I86KiiBmWG4IhA820U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АτγτΜΗУЦШΧΝцОγЛΙ():
    if len('') > 0:
        284
    value = 783266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiPRYmsyp7glYl2a+2/FDQIL420='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8129 = 758
        211
    return total

def _κРеΘЯηЦωгΜ():
    value = 63626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxfhZwU764QMPViK/AGXPnUssVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        664
        _dead_2825 = 125
    return total

def _ΖЧμррΘРξв():
    if False and True:
        529
        357
        337
    value = 373376
    if len('') > 0:
        pass
        721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhXGOn8Xx6YEEQGR+mTEMnw2zmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 47 * 39 < 0:
        pass
    total = value + len(text)
    if False and True:
        _dead_1783 = 634
        _dead_5934 = 266
        767
    return total

def _чиХΧΠЙΦцСм():
    value = 899862
    text = __import__('base64').b64decode('TXMzSndfZHB5Y0h2SWVQZ3A2UDk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        167
    return total

def _ШΓΞБζΡлу():
    if False and True:
        _dead_3164 = 710
    value = 899134
    text = __import__('base64').b64decode('V1Jud21hRktQTDdpVWtoSE5zV2k=').decode('utf-8')
    if 32 * 1 < 0:
        _dead_6492 = 280
        pass
    total = value + len(text)
    return total

def _тюШкгψοΓρΡ():
    value = 184287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjbSNn4K2rohFDWyykWTFhMdzEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6296 = 807
    total = value + len(text)
    return total

def _κчσьΒБВчΔαЫлчΑ():
    value = 630509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AinWRl4SxJkxaQL2m3DCHBUt1jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΡλτиληΝьЬкп():
    value = 329411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzbMSGkj24UIEVry4AagZSwNslc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΦЯЕμπПψтТб():
    value = 901759
    if len('') > 0:
        _dead_7703 = 0
        _dead_1706 = 935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB7mTEkD64cvNS66wXjIH3R5xWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХТλХδиΚςΕΦтεψ():
    value = 168995
    text = __import__('base64').b64decode('SGlpSzFZdklLYWlaaUNKc2RNd2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙФФбдкЧλеЦпЧ():
    value = 696888
    if False and True:
        pass
        _dead_1816 = 282
        661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxDeYQAS9vANGTiHwFXCLiof0zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_5600 = 625
    total = value + len(text)
    return total

def _ΚδеЯεξчЯΕβΓΥΩ():
    value = 384805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwfISn4wyJgyNSSMnw+aETYExXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΝБΥΤδфΝяΔз():
    value = 354375
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxnBflMJrYI2IzeIkWeXJBMB6Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦОЫЗΚьжωррΗВКΞμ():
    value = 478197
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBvNVwQw9v0hPBqwm1qoHSMmzkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цυΜΗοэΙйМдλЙβ():
    if 42 * 90 < 0:
        _dead_2176 = 734
        pass
    value = 349171
    if len('') > 0:
        _dead_3355 = 483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bxz+XlsG1ItRGxf73WWfMgAO6Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АησγшчФУдΖХ():
    value = 296094
    text = __import__('base64').b64decode('bVpncUxWMHBNbkZFVmZfTzFiMnc=').decode('utf-8')
    if len('') > 0:
        _dead_3534 = 61
        pass
    total = value + len(text)
    if len('') > 0:
        324
        pass
    return total

def _λθΣвПояΙЦНΟЭΗянΔ():
    if False and True:
        697
        _dead_4684 = 424
        pass
    value = 338453
    if len('') > 0:
        _dead_3469 = 936
        780
    text = __import__('base64').b64decode('bzRYT2x2VDZWVUlKZ2VYXzVzaks=').decode('utf-8')
    if False and True:
        _dead_4162 = 369
        _dead_1249 = 420
        pass
    total = value + len(text)
    return total

def _ЪΓζЛЖЮкцх():
    if len('') > 0:
        403
        _dead_4589 = 945
        408
    value = 520134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBa3dkYcrZs8HAOB/ACTLhwJtmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΑΒΕЙырΛυΞгЖηМуЮ():
    value = 25737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnjRZAUq27wqIjj3xX2DGAAr8GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЖЯъцьЫεχднΡДΒ():
    value = 740779
    text = __import__('base64').b64decode('cDVtb0hoRjRpbnZjQWczblM4UGI=').decode('utf-8')
    total = value + len(text)
    return total

def _γТрΔЭфεΟПЛЙО():
    value = 939358
    text = __import__('base64').b64decode('cktyNzRlSnpYb0w2NzhnWXRSTU8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _рИУУΙυЦЫЭС():
    value = 492255
    if 52 * 84 < 0:
        782
        886
    text = __import__('base64').b64decode('Z1lZN3pOTzJrVnlDSzUwTG5ZQWE=').decode('utf-8')
    total = value + len(text)
    return total

def _лгТΑьτЛξξςΗπ():
    value = 741742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dhb+W0ts2Y0iNBWt4XvGAx0W/EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κχΟчыЭΗкДЩΧπΓьΩо():
    value = 52456
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnjxPH8tqZdbNw2F2EXBAzQqslo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞωυЕΨимжЩщЮшРП():
    value = 149487
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgTxYmkbqYUJEziNyWKIPz0N0lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦОΦзΤльнΗΧωЙ():
    value = 576526
    text = __import__('base64').b64decode('amFrVTlkQmxLbG8zNnZ1WEhSZWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝЫτιΧγрЯ():
    value = 97811
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3jHXWNuq64AL176+wSaBgosymU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГъκвБцеθЩЦΓβΟ():
    if len('') > 0:
        _dead_1119 = 180
        _dead_2884 = 705
    value = 454002
    if False and True:
        _dead_4635 = 34
        pass
    text = __import__('base64').b64decode('ZURXSUVMMnNsNDRRN01yaDBrUDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭСπΚЕГЬχОцоΤпΙ():
    value = 670731
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB33V1go7J0tEl2cwFiSbDYI0Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΤΜфТэчюυ():
    value = 324783
    if 9 * 91 < 0:
        pass
        761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAvpTAM8q5BXGQ21zwWjMCo7wz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЮгИСЮоΩςΟч():
    value = 399823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cz69XH8+7IlTawGcx1/IITU+xTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЯεАсΩΒΑИхΦР():
    if len('') > 0:
        795
        _dead_6775 = 429
    value = 26661
    text = __import__('base64').b64decode('SlZJanU1M1Vjd3JSVlZFUzgyX3A=').decode('utf-8')
    if False and True:
        423
        _dead_2967 = 205
        _dead_8909 = 735
    total = value + len(text)
    return total

def _АВсуаюΥБМΖΥГ():
    value = 376111
    text = __import__('base64').b64decode('RFg0ZU5rTVNmV0wxRFRlYkJRNXQ=').decode('utf-8')
    if len('') > 0:
        456
        pass
        pass
    total = value + len(text)
    return total

def _ξгЙКδφΤиХКхГΠ():
    value = 320182
    text = __import__('base64').b64decode('WDBzWHdJbVBXOG5ESEpGY3JQOVA=').decode('utf-8')
    total = value + len(text)
    return total

def _иλΗскфИбΙХζΛнω():
    value = 14242
    if len('') > 0:
        339
    text = __import__('base64').b64decode('cHkySUpFYUU2RVZpRkp6ZGVQN1I=').decode('utf-8')
    if 46 * 90 < 0:
        pass
        pass
        690
    total = value + len(text)
    return total

def _ьПμЫЭηяхщРΜρБβΡХ():
    value = 484184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ey3RO34wy5waK1+0/1GdLAEa1ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘЫθΓщЬыЗБ():
    if 78 * 52 < 0:
        pass
        287
        pass
    value = 687610
    text = __import__('base64').b64decode('R2RWZjNka0F5eGtjZTdZU1VPajQ=').decode('utf-8')
    if len('') > 0:
        301
        _dead_3249 = 58
        pass
    total = value + len(text)
    return total

def _νБΙΟИЪЧОШ():
    if 17 * 35 < 0:
        906
        483
    value = 411112
    if len('') > 0:
        791
        892
        pass
    text = __import__('base64').b64decode('YlZzenZqQnE3dkR0dnJoNDVodWY=').decode('utf-8')
    if 40 * 5 < 0:
        _dead_5517 = 490
    total = value + len(text)
    if False and True:
        300
        _dead_3184 = 747
    return total

def _ΟзгΖΥзПшАЖХυгγЭ():
    value = 816931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cia9b2QBzJAgaQj7mg+pLB0X7Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τВПМιЖмбоеΩа():
    if False and True:
        _dead_3806 = 32
        pass
    value = 314049
    if False and True:
        _dead_8606 = 986
        899
    text = __import__('base64').b64decode('anJmdk14NUkyRGVpVVRaY3RTS2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪрΕΦςΔФχф():
    value = 475980
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DA3HVnUXzKsyaiD6zW61DSIZwD0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ищθнЙΑλшЧψ():
    value = 113025
    if 45 * 12 < 0:
        5
        407
    text = __import__('base64').b64decode('em9hZDdsVThRclV4ak1OOTJmM3M=').decode('utf-8')
    total = value + len(text)
    if 12 * 86 < 0:
        81
        pass
        436
    return total

def _μΑΥонΚоКЗωοΥ():
    value = 134968
    text = __import__('base64').b64decode('amNFTlZHZ1NRbzhBbkVsb0dPbHo=').decode('utf-8')
    total = value + len(text)
    return total

def _οтЬνΒкВηαΗа():
    value = 226581
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjbHS2Yd7YonAy6O+l2jBAwhzG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5003 = 582
    return total

def _ΔΠБπΒмГоФЪТαД():
    value = 445933
    if len('') > 0:
        _dead_7209 = 975
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXjXd3Y+6JIQHQ6bmVnCFh0izmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лвбЩΩГΙКλб():
    value = 965888
    text = __import__('base64').b64decode('eWd6WWtwVEtxQ0VYSWxZdWpDV0o=').decode('utf-8')
    total = value + len(text)
    if 95 * 62 < 0:
        pass
        415
        _dead_6534 = 212
    return total

def _ЬхμкФЧыжЭΞπΤФжДЕ():
    value = 255195
    text = __import__('base64').b64decode('bVBTRGdLMk5kWlJSOEhRYUl3TDI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_5911 = 389
    return total

def _ΑРаιςВΦЯюЧξ():
    value = 962954
    text = __import__('base64').b64decode('VGdoMXZsX0hQWkZRWEwxRDJJZmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ШаГνΛшфκЖЫтΩζ():
    if len('') > 0:
        _dead_4852 = 740
        pass
        655
    value = 382281
    text = __import__('base64').b64decode('aU1NYnhVUjRKSmdLOG1GUXlUUEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΛπωβΞЦΩиξο():
    value = 445340
    text = __import__('base64').b64decode('eWZqWHQ0eGtEYWJCbnVoVjBxSTM=').decode('utf-8')
    total = value + len(text)
    if 88 * 26 < 0:
        146
        _dead_2427 = 793
    return total

def _гзγЕΜКωФкξхχ():
    value = 489439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy2wVl8XyrFRCyzz+3O6LgYM9D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 61 * 24 < 0:
        344
        _dead_7519 = 750
    return total

def _РμΩнкΑюο():
    value = 553123
    text = __import__('base64').b64decode('UXdHMkJOVjVTTGJMMVZ3bFZZcUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΕΩηыΓЙΩЯЛяΓю():
    value = 326184
    if 25 * 1 < 0:
        665
        616
        238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHfVaV5qrJsWLF6S0UeFPTN88Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΑΝКюЭОΝ():
    value = 960508
    text = __import__('base64').b64decode('UmdhNkxFYml1MVJEakR2bm5FZDk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _йЮнРЙΨУЛуλЮаО():
    value = 440677
    if 90 * 1 < 0:
        pass
    text = __import__('base64').b64decode('R0o1bjFhenVodHpjRWRCdEtEVmE=').decode('utf-8')
    if False and True:
        pass
        136
    total = value + len(text)
    return total

def _юИЕОΛπγДжЙЪшΚ():
    value = 153774
    if len('') > 0:
        713
        _dead_9494 = 70
    text = __import__('base64').b64decode('WDhOOVJNZVg2WVBRdWJMTXJEQWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗнИШзοПчχЗНοЛхЯЩ():
    value = 596353
    text = __import__('base64').b64decode('cXhzVThNS1dEZTNSNWJydFJPS0Q=').decode('utf-8')
    if False and True:
        _dead_9812 = 11
        _dead_4438 = 957
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3378 = 359
        737
    return total

def _κΝτΙмщθыΤσЪ():
    value = 257683
    if len('') > 0:
        pass
        162
    text = __import__('base64').b64decode('WEhYQ1NfYVI1eUhWRVd1RlJwYTA=').decode('utf-8')
    if False and True:
        _dead_2229 = 629
        745
        pass
    total = value + len(text)
    return total

def _йСγΑэОΣяфвнзу():
    value = 895183
    if len('') > 0:
        582
        pass
    text = __import__('base64').b64decode('dTl5eEtCZjdsQTIwbFFzeVBsTUw=').decode('utf-8')
    if 4 * 99 < 0:
        _dead_9511 = 473
        526
    total = value + len(text)
    return total

def _ееЯюιοτγΗЕи():
    if False and True:
        397
        pass
        _dead_1141 = 451
    value = 698675
    text = __import__('base64').b64decode('eEpXektZclpOdnN5SEl4OXhqZTI=').decode('utf-8')
    total = value + len(text)
    return total

def _оΙΟРЦΞγшТщъΤфΚ():
    value = 273305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxzNeVkPzY00Yj2cxXODICQj6m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лУГЩλрσэгΙщΒ():
    value = 626059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAz2aWs8zp0sKCqI3Q7CIQYm4D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮсСтΠΝНцψхЭбЙ():
    value = 419471
    text = __import__('base64').b64decode('eGZyWEd5Ull4Rzh2bzhuaFJjdVI=').decode('utf-8')
    total = value + len(text)
    return total

def _нρТЙвЭцΟшщγъб():
    value = 805473
    if False and True:
        773
        455
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwbGWkg28oIUPRu0xQ+nP3AWxlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 3 * 17 < 0:
        pass
    return total

def _рΟЮюΟοΨιтθиЭЖ():
    value = 720384
    text = __import__('base64').b64decode('cEhxRUxKZTVoWkRBV0FXZE9Vcm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΞэΒΣЕςμζбхСΔуВБ():
    value = 643013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCfUeksL0aRaGBu77XeaFTIb61s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        532
    return total

def _ыυЫΧΗнΑЯТкпΔΣэβ():
    value = 48206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSDqaHAh/IchPxep/Vi1EQZ421s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬρтνрОγТАо():
    value = 263967
    text = __import__('base64').b64decode('T1ROSE02TUJmY3lySVJTdzVLM3M=').decode('utf-8')
    if False and True:
        412
        872
        pass
    total = value + len(text)
    return total

def _оΖνЙйζыΨπАНξΙ():
    value = 262321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAWwalRu7bAgEAT72V+fNwp5wHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дАΚхнЭβхφΗΞΠ():
    value = 805948
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('SjJCS3VZM1dVUUdrS3VCR1VrSVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ГцЖΝнАхШпφιШС():
    value = 363357
    text = __import__('base64').b64decode('WWxJaGs4aW5iMUtfakluYWpNanA=').decode('utf-8')
    total = value + len(text)
    return total

def _ξГηюςШφЦб():
    value = 443386
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICHOW2UX0ao1CRylmQ+XOBoa8VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πУΗеΙρщьμ():
    value = 153317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jnf8RmA30JoBFV670Ue6BC8ptnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        82
    return total

def _ицООφЧХΧφюωχшгн():
    value = 957208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwPAQXgbppozPSib/WyBZSggvWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨξЛАсΟжЪуяθιυ():
    value = 596986
    text = __import__('base64').b64decode('UnFjaXR5QjJTYkJEc1ZjT3M2U0c=').decode('utf-8')
    total = value + len(text)
    return total

def _βиЮБсщфλΚΥк():
    value = 461433
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjbcY0U/04chDCyM7HCAHyAaw0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фγЧΤФОψС():
    value = 145234
    text = __import__('base64').b64decode('WmxpTnVQNEE5M28yYU94WWIyUEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗβюεъυМЪрΣεКθ():
    value = 980417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB7FRm490qAzFyL6xQ/AHxQj1Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡιмΙΓцхωφЗ():
    value = 604568
    text = __import__('base64').b64decode('WjljVXdqOFJhdEFrNWIxTUg2b0o=').decode('utf-8')
    if False and True:
        pass
        27
        pass
    total = value + len(text)
    return total

def _щαуяΧςοΤλы():
    value = 648690
    text = __import__('base64').b64decode('S3I2b2hzNTRHbWRTMUU0MUVfNkc=').decode('utf-8')
    total = value + len(text)
    return total

def _лεЖУΛΘΟАΡ():
    value = 988197
    text = __import__('base64').b64decode('dkdzUlpxU0s0NnRXMlZsVkV0UEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖъΞΙυωΜΦгЕψхχ():
    value = 636490
    text = __import__('base64').b64decode('bXJ2dVpHUW9KbGxUczk1bUdzU3k=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7624 = 46
        pass
    return total

def _йщаΗΨЪΩЭцвτЧВεе():
    value = 715971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyKzQAE1/7kqEx6Az1PEFXw/7Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΨΒрχφйθл():
    value = 536927
    if len('') > 0:
        255
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQnCQF0G2qQXNxu3+HzJOwce6Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5631 = 752
        _dead_4613 = 995
        84
    total = value + len(text)
    return total

def _ТΝΑТАЭΗчΜΞцΔο():
    if 37 * 55 < 0:
        _dead_4287 = 767
        pass
        pass
    value = 691927
    text = __import__('base64').b64decode('dGViSkY0X3Nfc0owelJPUnpBbnk=').decode('utf-8')
    total = value + len(text)
    return total

def _вβжЦΑΑΤνЧП():
    value = 94092
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgndRnoh1bBVER6LwlKvEycoyHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НАщДСΗθστИТиЛβιφ():
    value = 398689
    text = __import__('base64').b64decode('WkwzYU01NFk1TmEwQUtOOG9Sc0o=').decode('utf-8')
    total = value + len(text)
    return total

def _АΜАξЕйΦэ():
    value = 586397
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAH9WnUX9qsgbBeL3GKiPhI3/G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фζΒтШΨютюΕРчг():
    if len('') > 0:
        315
        _dead_5062 = 726
        840
    value = 279156
    if 41 * 82 < 0:
        _dead_6342 = 744
    text = __import__('base64').b64decode('bHRRMWRfTkZ6NXJEN0ZMcE81ZXA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1334 = 19
        _dead_6467 = 489
    return total

def _φкΑΑхЗЛЯ():
    value = 963574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSbMNmgvyoowMASQy26BIyF29UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яКηγхΒΝп():
    value = 91165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BArUbWVsqqIwEAOFynfIHR8M1n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛХпΧΟЮзΛγГ():
    value = 751781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCvzOlgTxIEMHjWT6USSbRwQ13c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧКΨВΙμЩЯ():
    value = 416664
    text = __import__('base64').b64decode('clFnMnhRcDRxaGNPNEdRNFlDYTA=').decode('utf-8')
    total = value + len(text)
    return total

def _иοбςЫЖΛЧОζΟОσ():
    value = 22309
    text = __import__('base64').b64decode('WVNJN0VOWjF3cXFMMUV1Y1REN28=').decode('utf-8')
    total = value + len(text)
    return total

def _жтЫЪΩΦυфЯμξщЪην():
    value = 60261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PX28eEAv0PE0HQK37VrFDj8svT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьрθопЙΙΒпΒЭэΟыΩΥ():
    if len('') > 0:
        376
        pass
    value = 99670
    text = __import__('base64').b64decode('TFROUDMxZ2JyZlVWVE9VOGZuZE0=').decode('utf-8')
    if len('') > 0:
        _dead_2974 = 545
        pass
    total = value + len(text)
    if False and True:
        293
    return total

def _ΣχжВψσфΨЗнКΖβσ():
    value = 866420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBazPGIc5KIyHhf1mWmGASADwUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        187
    total = value + len(text)
    return total

def _ЕЗсРЬΝΝξαпгΔηи():
    value = 144578
    text = __import__('base64').b64decode('SnNfd2lLNXFwdlJ6TWxTbzBFc2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ωйΘЧΒΞцΓычαмΘЛτ():
    if len('') > 0:
        186
    value = 908800
    text = __import__('base64').b64decode('ZHZDMkpxcnAyVXNaU2dlb3ZacWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ДТмюβкΩмκЭмЦφ():
    value = 494060
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kguwe2sA1rkRDCH1+nu2NgQAtU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фРЮΨπпψρκ():
    value = 548620
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAvDX0Qr07pTEzCT40W+PS571mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΙΙЩшЖυρмСуυгн():
    value = 10337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ay68XXcX6LwSOSG0mH6nHyB91GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΘЛоыΒΒλβкЮШ():
    value = 333012
    text = __import__('base64').b64decode('TDlURDZnZXhUejRlaDJ5eHBwbm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ПЯΩхθΒХнγΤ():
    value = 655266
    text = __import__('base64').b64decode('eXNSSWRobVo3V0V4MVdiWXFKa3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦπюцъКвсЪδΦ():
    value = 833195
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnrzR1kO+ZsxGzuowky9Jiwf10g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        370
        _dead_4990 = 234
    total = value + len(text)
    return total

def _фνφΣжοεПйΖуΟΖΩκЯ():
    value = 615017
    if 69 * 83 < 0:
        723
        _dead_2786 = 932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSzQSFo11vEbbTCE6gaZGwcc7mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦПΗеΩβΚбΔ():
    value = 41362
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDjhOEIT96YEFxmQ7kKXBDMG71g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨврδХνАψΘЧΑкс():
    value = 757364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxjNQWVv9ZchGSuG91OFGjYJyXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьпОРэЙБяπ():
    value = 975488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX6zfUcc24chLi30kV+zEhAM3Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 55 < 0:
        _dead_6176 = 842
        831
    total = value + len(text)
    return total

def _πнωжъХΝΜΞΜйНжΠζξ():
    value = 418191
    text = __import__('base64').b64decode('Skd4c0dvT1FSbUd0OXJyc29yU3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ийΝВЯΟфχ():
    value = 754509
    if False and True:
        58
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAbGdEU9q5xWAzm1/0GDInwg9j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЗЫЖκνдцж():
    value = 533822
    text = __import__('base64').b64decode('WTlEUlRkQmFQZWhvcnJTYU9xM1k=').decode('utf-8')
    if False and True:
        pass
        _dead_1409 = 171
        pass
    total = value + len(text)
    return total

def _ΔгКΨΞΚΓΔωΤΙЩη():
    if False and True:
        10
    value = 719461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDXrZFAd1I0vLFmX2QTAPCgWwVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_2786 = 7
        pass
    return total

def _ΙΔщΦГξξДкπ():
    value = 308587
    if len('') > 0:
        933
    text = __import__('base64').b64decode('c2tCQmFPM29rbmsybDNyOGpyVWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜХΟΓλΑНЫ():
    if 82 * 36 < 0:
        pass
        _dead_3075 = 614
    value = 858730
    if False and True:
        530
        pass
    text = __import__('base64').b64decode('eTFKU1Qybzk0SnVqTE5XZDJvbmM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        869
        pass
    return total

def _ΧЗкюпГΤΖюжΣрΦΠρ():
    value = 664054
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JznxakEz/f0KGSnxnl6yPQd2skg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОζςхВΙдП():
    value = 176654
    if False and True:
        307
        pass
        _dead_9777 = 154
    text = __import__('base64').b64decode('b2x4cFcwSnpyVnJOYzlsSmg0WHQ=').decode('utf-8')
    total = value + len(text)
    if 23 * 18 < 0:
        _dead_9065 = 186
        _dead_4434 = 405
        607
    return total

def _ФшхЬζΝгΕβχ():
    value = 350204
    text = __import__('base64').b64decode('Z2o2NzZ5WVBYQkVmbThsX2J6MFQ=').decode('utf-8')
    total = value + len(text)
    if 2 * 22 < 0:
        _dead_8427 = 878
        pass
        986
    return total

def _ΚяхЕγФтΨн():
    value = 94509
    text = __import__('base64').b64decode('aUxmY2tMekExVVVvbUNhQUJiR2o=').decode('utf-8')
    if len('') > 0:
        _dead_6036 = 59
        838
        36
    total = value + len(text)
    return total

def _ςψΚОЧμпΠЛшж():
    value = 75976
    text = __import__('base64').b64decode('ZkZuN25hT2dMMER5emdjNmZicFc=').decode('utf-8')
    total = value + len(text)
    return total

def _КζοΕлΛΨдрΜΙщ():
    value = 623248
    if len('') > 0:
        875
        815
    text = __import__('base64').b64decode('Qm9NeW9WTVVWdjg5dE96aHdpT00=').decode('utf-8')
    if len('') > 0:
        _dead_1440 = 525
        457
        _dead_9840 = 646
    total = value + len(text)
    return total

def _дρμЬЦΗμсЬэΕЛю():
    if 19 * 93 < 0:
        _dead_4227 = 496
        _dead_3610 = 842
    value = 812329
    if len('') > 0:
        _dead_5201 = 354
        285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fz/FbWsp8qwvDlmVz2WoDHU7w3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝЯλжЙтТιΧθАηοσ():
    value = 403251
    if 17 * 89 < 0:
        _dead_8424 = 238
        pass
    text = __import__('base64').b64decode('dTVVNUkydFMyOHltb1hXV2FLR1E=').decode('utf-8')
    total = value + len(text)
    if 16 * 61 < 0:
        pass
        829
    return total

def _τκТοаЙНΟцуяΩΡаφР():
    if 50 * 22 < 0:
        pass
        305
    value = 601566
    text = __import__('base64').b64decode('VW1sRVFWTXJfX1VUaFloa0t6ZFg=').decode('utf-8')
    total = value + len(text)
    return total

def _κыЩΨОАиахЫΚсьοЛа():
    value = 472810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3fMSWsu0K4SPRW26VueNyce1Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кИνРЭуиЬдсНУДА():
    value = 465544
    text = __import__('base64').b64decode('Y1JSdFJIdDBFN3BzZFBHWFlCRUc=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ΦбωΙТиВхаТ():
    value = 743369
    text = __import__('base64').b64decode('U1pQd0NMQjQ5YnFHUzA5RTVRSko=').decode('utf-8')
    total = value + len(text)
    return total

def _НчοГξΒΥоРЮйΖ():
    value = 966192
    text = __import__('base64').b64decode('U0dHSGNER2JvSVJfb1Fjek1GYTU=').decode('utf-8')
    if len('') > 0:
        pass
        777
    total = value + len(text)
    if False and True:
        982
        146
    return total

def _εйОιСБаЯфЖΣΒωχ():
    if 8 * 58 < 0:
        _dead_8354 = 21
        pass
    value = 754247
    text = __import__('base64').b64decode('YnVGRlRfV2I4S25RREFuMXY5Z1U=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6548 = 43
    return total

def _ЫκмцйωΗΩ():
    value = 566301
    text = __import__('base64').b64decode('ck05TDltVlBNM2s2VFQwT0FvejA=').decode('utf-8')
    total = value + len(text)
    return total

def _НХйΧЗЦжб():
    value = 185307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BifqRV8D8o4KAAmUyQ+2LnYA4no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_3115 = 811
    total = value + len(text)
    return total

def _ЕΚЙдΣПыω():
    value = 386396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCLzXEsQxIYnND6K7AazAnQCs3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хврвφΤцν():
    value = 435888
    text = __import__('base64').b64decode('U1N2X1FuV2hyMzJpZE1iYWt6WHA=').decode('utf-8')
    total = value + len(text)
    return total

def _РθЯχЬДТфбэςк():
    value = 667731
    text = __import__('base64').b64decode('VjFVb085T3RwaWRQSF8zNGw0VEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _СΛщΟцаЯοж():
    value = 876819
    text = __import__('base64').b64decode('b0RkNXRpczFDX1A5WTUwMkZZNng=').decode('utf-8')
    total = value + len(text)
    return total

def _цЕωБбΟРΓ():
    if 76 * 48 < 0:
        _dead_8743 = 557
    value = 900212
    if len('') > 0:
        _dead_7606 = 530
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bgv3N2gG+JkxKyrx+3CoYjIJ6n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 74 * 55 < 0:
        _dead_4439 = 127
        _dead_6333 = 823
    return total

def _црΡΨΟΝωПβуШ():
    value = 801107
    text = __import__('base64').b64decode('Y05Ya29pNWNGZUs2OEZpNWN3dnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤТξΛςΨοΣΜδмЛнοδъ():
    if len('') > 0:
        _dead_7259 = 794
    value = 451345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzXSVGUM/6ssNiGBxXSTGQgJ41k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΑνуХΨцТιБтυΟФγ():
    if len('') > 0:
        _dead_2834 = 469
    value = 763811
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MX2wOXBtr40Lbyvy3XPIFys67mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _φнξхтΙРкβУЙ():
    value = 314039
    text = __import__('base64').b64decode('ek1lZzBEVHExQ1VlRHZ5V1QzdFU=').decode('utf-8')
    total = value + len(text)
    return total

def _НЯΦзюοАЧЖζшΔфУи():
    value = 73925
    if False and True:
        _dead_7011 = 77
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH71SGUN9K0yMSyUkA7AMD19zzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 69 * 32 < 0:
        726
    total = value + len(text)
    return total

def _УΕуУЦсΝгэаецθχνы():
    value = 508243
    text = __import__('base64').b64decode('S0xoWWxaQlBJR2ZjUFRPZW9CODI=').decode('utf-8')
    total = value + len(text)
    return total

def _БΤΧрυПЕЛЕАΜΥτοзζ():
    value = 346194
    text = __import__('base64').b64decode('SjhFcEZGenJsbXZ1cFFSdGZjSGE=').decode('utf-8')
    if False and True:
        _dead_4754 = 592
    total = value + len(text)
    if len('') > 0:
        102
        160
    return total

def _НЧмΓуβΚыйζдкΠБ():
    if 59 * 31 < 0:
        pass
        _dead_7064 = 456
    value = 169716
    if 66 * 28 < 0:
        _dead_1358 = 517
        _dead_4565 = 685
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng7zW0gq0IUzLwSOyVWFNQR/4Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 45 * 31 < 0:
        93
        145
        564
    total = value + len(text)
    if False and True:
        _dead_9783 = 863
    return total

def _щдЛΕΥКΧΦуεξШдд():
    value = 290012
    if False and True:
        114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX/mXUQI15oBFQ6tmQ6HJ3x/3kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΔНЬьЩчΒρ():
    value = 702025
    text = __import__('base64').b64decode('S2QwUWNQOUdHUVJqS0dkNFVBRWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩФσЯΩКоλяцчΒ():
    value = 958704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgnyeFcu3aomNBilwXeeBQJ67Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 20 < 0:
        135
        _dead_1222 = 587
    total = value + len(text)
    if False and True:
        862
        _dead_3023 = 834
        _dead_2812 = 686
    return total

def _ыΕΗПγъζΛТψмМροΘо():
    value = 578688
    text = __import__('base64').b64decode('cHFkTGRnQU5XV1laWUpfandaUlY=').decode('utf-8')
    if False and True:
        _dead_3263 = 456
        pass
        pass
    total = value + len(text)
    return total

def _ΟФΒΠЯЫЦΞРЮЦсΕΕЬ():
    value = 288760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTvxOlQ3xJoKKF2IkHeALBUm6VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙмцχсЛАσКΞΓГСгζα():
    if 43 * 23 < 0:
        696
        _dead_5925 = 785
    value = 261092
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Din0amcM3ZE2NRyqmUGcAhwBsmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔДινχЩИцλтУΣ():
    value = 754982
    if 64 * 82 < 0:
        pass
    text = __import__('base64').b64decode('SFpKRVJ1RlZDV3d1T2JYYUZ3ekY=').decode('utf-8')
    total = value + len(text)
    return total

def _БыνχΕЗΠЙΤΞТ():
    if len('') > 0:
        360
        _dead_1727 = 236
    value = 331194
    text = __import__('base64').b64decode('ZWpLWEdTTTdxa214S01TbFM2RGo=').decode('utf-8')
    if 53 * 80 < 0:
        156
    total = value + len(text)
    if False and True:
        pass
    return total

def _ττНοЪзАЯΣ():
    value = 888132
    if len('') > 0:
        _dead_7717 = 105
        pass
        pass
    text = __import__('base64').b64decode('bjdhZjM1aTQwWElXOEhKcEo2Tk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧςЬАЗиΥΞвδСечΡΚ():
    value = 191702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CySwN0g4+6wFajiGmX2gJ3A46Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()