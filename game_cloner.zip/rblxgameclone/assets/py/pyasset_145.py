#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _КШвξςМКДШ():
    value = 54067
    text = __import__('base64').b64decode('SngxR2VjQUdreEJUYkxpaHZDbHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ФКтΟψюилЕ():
    value = 932904
    if len('') > 0:
        827
        784
        _dead_2549 = 645
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyTDdl5trJdXDF7y4wW1Hwst9ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗεЦрΤУрТХηэзВΔх():
    value = 898989
    if 24 * 9 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQnvO0MQ97EIADqT2Ge0LAY3sUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιωυУеξΧЙχцВ():
    value = 922475
    text = __import__('base64').b64decode('UTFfNTl6TUQzNkx3RFA2TjhwRUs=').decode('utf-8')
    if 80 * 44 < 0:
        pass
        _dead_1375 = 198
    total = value + len(text)
    if len('') > 0:
        _dead_8293 = 252
    return total

def _ЬоπЧυζλрΦΜ():
    value = 794126
    text = __import__('base64').b64decode('VEthU3hORTMzUDZ6ZklXSXpjTFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ФрТщμдлЬжЕΚ():
    if 64 * 2 < 0:
        _dead_2070 = 563
        643
        _dead_1911 = 779
    value = 180033
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CybdbWISr5oxACiQ5QezJBI1vHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КтχψРΔФХКЛвоЕ():
    value = 27749
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cg3VWwEzr4QQCFyknHPCIyoQwnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аσдЯЫςμΜг():
    value = 421733
    text = __import__('base64').b64decode('cnVEaFdCeHVJWDZScmZqdXBneGk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6520 = 54
    return total

def _фσΕЫιπыωо():
    value = 802216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQvlbH0B9fwwaFaZ2Ue9Liwr3Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨψλνЙΘγсЙ():
    if len('') > 0:
        191
    value = 800673
    if False and True:
        pass
    text = __import__('base64').b64decode('WVViSzcyTmlBZFl1YUxmRGRwWXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΡиеΩσЖаσΘσΛсОТω():
    value = 504678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fgy3XnMP5qRSHwWoxlC7Miw66mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6293 = 160
        _dead_6914 = 780
        _dead_5964 = 148
    total = value + len(text)
    return total

def _ЧΞςтуКβнΗοΒ():
    value = 450689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In3xVwgAxqApLASnm0PAHQgH9lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωΕгоωΕОΥТЩΒο():
    if 20 * 2 < 0:
        pass
        pass
    value = 115987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EH7jb0QDqJEHORWmzE+hGTF53j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        881
    return total

def _ЮζφΜξξчγЯьч():
    value = 608949
    text = __import__('base64').b64decode('b0cybkdVN08yWTNsek9VakNLVUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _цνπЭжφПыΒρΥ():
    value = 463796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX3CWgQN5P0pOAqP5l2dBQM+7jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΒηЬцАпкμ():
    value = 143290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnfjW2Ju2r1bF1uu/FnFIXAh9Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘШюΥΙμΠкΓ():
    if len('') > 0:
        288
    value = 389584
    text = __import__('base64').b64decode('cTc5cllJdWhtVEpBdXFlM0c5cTE=').decode('utf-8')
    total = value + len(text)
    return total

def _АΨЫΔуИкъΣ():
    value = 349775
    text = __import__('base64').b64decode('VnpIb2ZTam5weUY1a0hsdUtmZW8=').decode('utf-8')
    total = value + len(text)
    return total

def _НЩСчφщζΒБιхЬУ():
    value = 241726
    text = __import__('base64').b64decode('d1ZteHNkeTZoSFBKaXUwbWRBTkc=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_4221 = 994
    total = value + len(text)
    return total

def _θξωкНΝΜГΚοΑн():
    value = 872994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dwe9N3g30qoGEiSE/kLEEwAX20I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔιςПьыθεгхИεΣςИ():
    value = 498760
    if len('') > 0:
        pass
        pass
        _dead_4548 = 958
    text = __import__('base64').b64decode('d1hJN2QxOGpWVFZBM05VbFZHUHA=').decode('utf-8')
    if len('') > 0:
        _dead_6519 = 853
    total = value + len(text)
    return total

def _ΤπΥкΕκрФВΒ():
    value = 917290
    text = __import__('base64').b64decode('Rnl4aUgwR285NjJDMFhLMnlWd0U=').decode('utf-8')
    if 39 * 45 < 0:
        897
        _dead_3099 = 815
    total = value + len(text)
    if 51 * 72 < 0:
        539
        537
    return total

def _чъышфχφиΥсΗсЦτφβ():
    value = 522090
    text = __import__('base64').b64decode('SHd5MWJWSkdvZXpJeFF2Z0NLMXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΒжΧΗЮЭШΟЙ():
    value = 879593
    if len('') > 0:
        118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHj9WQEr+6ERPiv7mgHGFS4kx30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        195
        pass
    total = value + len(text)
    return total

def _ЙтчВΓЪишУΙЖцΣЛб():
    if len('') > 0:
        _dead_7310 = 97
    value = 902579
    if len('') > 0:
        pass
        pass
        428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgD8WHc6zo8QK1qK6weCEQQn6GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ншζΞрУΠвыщдΚΘСр():
    value = 635560
    text = __import__('base64').b64decode('TjliblZ2MmJTYno5ZV9mTWEwSUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ХйцвЕбζξΝΝβьЕ():
    value = 403801
    text = __import__('base64').b64decode('QTA3N3F6ODlwRVY5ODVkclBuVkc=').decode('utf-8')
    total = value + len(text)
    return total

def _δαщΡСЪзνмЦцφх():
    if 65 * 75 < 0:
        pass
        296
    value = 810494
    if 98 * 35 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDbmPmIL9YkMNwapn2ObJjYE3U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7207 = 962
        _dead_9389 = 299
        pass
    total = value + len(text)
    if 5 * 87 < 0:
        pass
        880
    return total

def _εВгЮЕШρТχчтЫ():
    value = 988953
    if len('') > 0:
        763
        _dead_6315 = 375
    text = __import__('base64').b64decode('UEpSaXl4dV9vY1Joem5zMUhIVEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ХэМИпζшΞγΑκχλχИ():
    if 57 * 70 < 0:
        309
        410
    value = 130147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx7TfWJsq78WawSp7mTJHSsXsz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иыКиФьΣΕеΣГАαμ():
    value = 549486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBW8PUVt7L4VDQSq4lzDOy8CwD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΓЙцΧζСπЛп():
    value = 808513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyTgYVkAz7szA1b60lGbBjw+wTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йοяτХΩрη():
    value = 785623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSTGPFIrrqY5HDWmnnyVLHUK7Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иРΧсΞΜуδΔкγм():
    value = 578639
    text = __import__('base64').b64decode('cEdNZHJjRHZkN2xKRjMwc2pVSWw=').decode('utf-8')
    total = value + len(text)
    return total

def _ыωεУЕΕβпχЙΝйοςТ():
    value = 392754
    text = __import__('base64').b64decode('Y2ZRZEJETlR2dWV5OXBHelFNb1U=').decode('utf-8')
    total = value + len(text)
    return total

def _νфиΒБтйγЖЖΗХб():
    value = 946453
    if len('') > 0:
        pass
        368
        877
    text = __import__('base64').b64decode('TTgxWWdjWVBaYmNxeVdaWVFvWGE=').decode('utf-8')
    if len('') > 0:
        _dead_2263 = 325
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_5272 = 110
    return total

def _ЬцΩеΠνюςΓ():
    value = 372889
    text = __import__('base64').b64decode('UDN0dTNZOTdFbGRrX1QwdzBlb0s=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ДэσфσжΔΟχΟЕд():
    value = 909161
    text = __import__('base64').b64decode('UHRQUHF0bzdhM3cxWjdIYU5MSDc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        193
        627
    return total

def _йωеγБуНзиГД():
    value = 302259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhXoS3Mh2q8LMVmR5k66NgEX80M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЩсροτΛг():
    value = 404996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nn7oW24e6aoEOzyHzH2SCz0H50M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 11 < 0:
        pass
        _dead_1891 = 283
    total = value + len(text)
    if 64 * 23 < 0:
        pass
        pass
    return total

def _кΛΙЮΒЩμМдеы():
    value = 480823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzXrYXAv1J4LMia5wXSoInwE6WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6771 = 362
    total = value + len(text)
    if len('') > 0:
        711
    return total

def _ιфεоΕΩγсхΜНΤ():
    if False and True:
        pass
    value = 918596
    text = __import__('base64').b64decode('b0djSHBNdmNMMmVJX256RlZnZFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩОεйЛгъяφ():
    value = 609584
    text = __import__('base64').b64decode('YXI3YmJ4QWVLZXVtSk9nVTdBSHY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        565
        _dead_9644 = 481
    return total

def _ШИλНχυβхзΘοιЛ():
    if False and True:
        943
        pass
        405
    value = 585012
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('QU5Xa3hxbkZIT1pwRG9KelhXTGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭТДЙЫιъЪΙΔТпχ():
    if 71 * 50 < 0:
        _dead_8653 = 954
        505
        868
    value = 644714
    text = __import__('base64').b64decode('UkphUTA3bENOTnpKX3FvMElpS18=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_5089 = 202
        918
        _dead_1450 = 331
    return total

def _νΡВεοДЧρЛκЭчκСππ():
    if False and True:
        303
    value = 224537
    text = __import__('base64').b64decode('Ymt3MzR3WHpVYWJVeTZsTk9oZ3U=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        580
    return total

def _ΤΑКξхкСςъмΦ():
    value = 765451
    text = __import__('base64').b64decode('aGpVMVFtRTYzVWJFb2U1TW1WeFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _йхιИΠыγφ():
    value = 817957
    text = __import__('base64').b64decode('SUlTZ0xuQ0tJa2o4MnZKZGl4S1g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9836 = 734
        _dead_6205 = 777
        _dead_9554 = 411
    return total

def _φΥΩΑуΖЫκбшдςЭфΜ():
    value = 583867
    text = __import__('base64').b64decode('ZnV2WG1nZlJnOGRsVTRrRDV0aEk=').decode('utf-8')
    total = value + len(text)
    return total

def _νсдБΞΜΦджΨд():
    value = 880505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT7laWIKyrstLgWryUGBHSYsykE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςБοйеЭЪρыΦйъЩСωН():
    value = 777801
    text = __import__('base64').b64decode('aFd0WnZYaWR3RFJ2SVFMTV8zS1I=').decode('utf-8')
    total = value + len(text)
    return total

def _щЪПΝгβςчωΨц():
    value = 640719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB/BPggq+YAGHyv3yl7JMR0a3lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥвжβкТΖΙйФψΠь():
    value = 25340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB/GVF1h9rAWFA2CxQSlLQc+s0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рωΠΙλαΠДΩ():
    if 92 * 15 < 0:
        pass
        pass
    value = 739674
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In/nYUUO9LAxYwiG3GCRFhYI9kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЧΙнаЫэюεΖхНроΑх():
    value = 193621
    if 33 * 12 < 0:
        62
        101
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CC7reH4Br5o7AiKL8W6CJwwAsmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υρσкφΑбΗи():
    value = 830138
    text = __import__('base64').b64decode('ZmhSRDB3OVY4OGpQa09KeEZFSmI=').decode('utf-8')
    if False and True:
        646
        _dead_5499 = 774
    total = value + len(text)
    return total

def _яЭУυνхоЬ():
    if False and True:
        _dead_6194 = 418
        pass
        127
    value = 56320
    if 86 * 41 < 0:
        557
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgTgPQRg+aVXDAv730apPiQMvHQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 52 * 19 < 0:
        _dead_2021 = 816
    total = value + len(text)
    return total

def _КΣянЯΨОРΝр():
    value = 965140
    text = __import__('base64').b64decode('ZWp6dzlrSVl5UEphRlFlOGx4Mmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦАПΧУкЮиψЪщξΣΘПй():
    if len('') > 0:
        pass
        _dead_4080 = 649
    value = 29363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXnvZQcu+oAXDR+q5GS0OCA88zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        821
    return total

def _ЫцйζδπΡΘτЬ():
    value = 598496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCfndAVr540sNTeq2WakAg4/0zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 93 * 94 < 0:
        986
    total = value + len(text)
    if False and True:
        _dead_7494 = 776
    return total

def _ДЙЙψОтаφψβО():
    value = 439604
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRDsZgI06qAiLAmQ+mK/FzIlvF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БпцАΚυΦЛТтγоΟ():
    value = 705344
    text = __import__('base64').b64decode('d2NFYXBycTBJZUd2UFF0aVd6a1g=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4808 = 628
        _dead_9129 = 28
    return total

def _ξЦΖλУфΦШТΘЙм():
    value = 305797
    text = __import__('base64').b64decode('Q2ZoUkpfZWQ5MllRTzVjeDZlTFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ъνσΟоЬеοΔΣаЯξΙоν():
    value = 649606
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQfuYEE22oVXLia65FnABxcX1Tc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЗЯЧхшНьЪяОΜУчХз():
    value = 83788
    if 20 * 23 < 0:
        _dead_1610 = 644
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDXCXAEV+rkoBSKAxHCaJwo/9Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        371
        pass
    return total

def _ΧдμДСЫеМиΑЭШξΩΗт():
    value = 253637
    if len('') > 0:
        pass
        822
    text = __import__('base64').b64decode('RjdPQzBXa3lQam42cUJORUlLVk8=').decode('utf-8')
    if 37 * 78 < 0:
        pass
        288
    total = value + len(text)
    if len('') > 0:
        pass
        147
        pass
    return total

def _ΞсΕЪΗХΝΥΩηЬδφу():
    value = 484666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyTiT1wv7KUWbyes0EOFMxMWyFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χλΜвωκБЙуρυФΕдβч():
    value = 242168
    text = __import__('base64').b64decode('a0RIQjBWY0RXUjVIaGFBTFIzaHA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        832
        _dead_7018 = 900
        pass
    return total

def _пφГЩςЫΠт():
    value = 902527
    text = __import__('base64').b64decode('QmloeDVIZGZsUkF1UnVoUWFQWnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫΚκΨΑляοРхΥ():
    value = 170839
    text = __import__('base64').b64decode('b2JqWjJDS0czOFdjNFVtVTZlZEM=').decode('utf-8')
    total = value + len(text)
    return total

def _цБΗφПЬΞыΔΑο():
    value = 618550
    text = __import__('base64').b64decode('UFVtTXF4ek9XSUJWblJ5MzhNeFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜсгΕΥαжРΟЫ():
    value = 674775
    text = __import__('base64').b64decode('VTJDSV90WUhfTHVtREVFV3lvYWg=').decode('utf-8')
    if len('') > 0:
        573
        182
    total = value + len(text)
    return total

def _вКбдηгзЖ():
    value = 199263
    text = __import__('base64').b64decode('aWk0REFSNG1BaHJlQmlSMGtVRnk=').decode('utf-8')
    total = value + len(text)
    return total

def _СΤьδτеОДρΤΠТм():
    value = 549048
    text = __import__('base64').b64decode('R1VxdjBpcHdpa2E4MUxxSnNGbTA=').decode('utf-8')
    if False and True:
        830
        776
    total = value + len(text)
    return total

def _ЫζκКбΦАιΦΥРЯ():
    if len('') > 0:
        pass
        _dead_7094 = 125
    value = 873762
    text = __import__('base64').b64decode('TmUzdG1WbnpxS2tjTjk2dE5vTUY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        442
    return total

def _ЩВγНΦХщΘЦ():
    value = 629928
    text = __import__('base64').b64decode('bkRFdFlQbV83X1dGUngzUUYxa24=').decode('utf-8')
    if len('') > 0:
        646
        58
        _dead_2713 = 906
    total = value + len(text)
    return total

def _οαьяХъΑλеΦ():
    value = 107260
    text = __import__('base64').b64decode('UlVTM2FOcXRxVDZ6cFkxTHd3a2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤНязАωаСЬПεж():
    value = 702864
    text = __import__('base64').b64decode('dHdaTk04bk01UkxsWk1LbTJUelA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΖοюΚкЮъωЧκЮЮζР():
    if len('') > 0:
        pass
        pass
    value = 286059
    text = __import__('base64').b64decode('RW9VWXU1WXBHbUtOYVVSNFcwQnc=').decode('utf-8')
    if False and True:
        _dead_3229 = 810
    total = value + len(text)
    if 78 * 94 < 0:
        784
    return total

def _оΠьЙМΗыΜ():
    if len('') > 0:
        _dead_5707 = 744
        pass
    value = 219825
    text = __import__('base64').b64decode('cG41M216R05BQjJ2dHFDN0Z5M2c=').decode('utf-8')
    total = value + len(text)
    return total

def _αрЭςыЬψρΡшгαΖγнφ():
    value = 20315
    text = __import__('base64').b64decode('T3haMXAyYXd1X0NqbEdJTml4T2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _шΒνβΑΔшикоο():
    value = 424790
    text = __import__('base64').b64decode('SzRFdTdkamlDN2FFTUlTbTkxS0w=').decode('utf-8')
    if False and True:
        997
    total = value + len(text)
    return total

def _ηδЕЕопμχР():
    value = 349260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQbFd1cO3PsZblagkUeJDRUitTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λеΤюφВξЙТα():
    value = 250701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnbDRnMD7qlQAFeJ4AWhZnIK6F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вшυДШйЙлΠСιЦΠψβЙ():
    if 61 * 28 < 0:
        _dead_6042 = 406
        pass
        80
    value = 539392
    if 57 * 50 < 0:
        819
    text = __import__('base64').b64decode('d1JBQWpXUHE5Qllaa3lnbWFsdUw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        340
    return total

def _ΡэЩаλΓъρГыид():
    value = 847933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByPUOEce7fwGajCN8mmcI3R902s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙεΡιπъьВТШΗκΙСЧν():
    value = 837097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxbUR241rLolaAb3kUG9EiQe10A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωуΠЫАюбφйχΧ():
    if 74 * 6 < 0:
        733
    value = 936012
    if False and True:
        pass
        _dead_3004 = 348
    text = __import__('base64').b64decode('Q2YyUHlGTUtsemM5aHp3WmpXVXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЧрχαξпшЩκ():
    value = 152434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQTJYEts0p02CCW0x2aoJw0M50w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оиЬΠЮВΨрУ():
    value = 914774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHy8aUQVyr0WNQP12U61AzU1t3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        109
        _dead_8434 = 754
    total = value + len(text)
    if len('') > 0:
        pass
        646
    return total

def _οЛерγЮΚЯφщωЙнецк():
    value = 710143
    if len('') > 0:
        274
        pass
        _dead_2460 = 428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjvqV1AU26sREViVwQamJnY23Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 77 * 53 < 0:
        855
        342
    total = value + len(text)
    return total

def _БоςδдΥπηъПЧπ():
    value = 90825
    text = __import__('base64').b64decode('Y1ZzM2VrUUZtSmN2bFdDcHpDTTY=').decode('utf-8')
    if False and True:
        _dead_7076 = 186
        867
        902
    total = value + len(text)
    return total

def _РХβзйБλМЗΚ():
    value = 816330
    if 88 * 57 < 0:
        pass
        191
    text = __import__('base64').b64decode('RU9jNWhKV1hmeU1qNlNNd0l0UGc=').decode('utf-8')
    if 13 * 45 < 0:
        824
        pass
    total = value + len(text)
    return total

def _бъβуЪЙψХЦЭΧμн():
    value = 958633
    if False and True:
        509
        _dead_9810 = 415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CT/idmko3J8bEz32mQehBT096Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _трмτйТАРыκγΖλγкΣ():
    value = 21025
    if False and True:
        pass
        390
    text = __import__('base64').b64decode('VEMzV0tQTDlRVUI2SGVRVE5HOHM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        612
    return total

def _НδΚЗщΟрΗмγОζςσΧ():
    value = 23668
    text = __import__('base64').b64decode('Vkx4MHZMX1RsS2l5QTNEbGQ3alI=').decode('utf-8')
    total = value + len(text)
    return total

def _эΥРςεΨпФы():
    if False and True:
        647
    value = 248453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bin0egQs36ozEgGFxlW8Bgwb9Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жψΑψΡыζзЬΘΦ():
    value = 969372
    text = __import__('base64').b64decode('cUdoNG9qY25IYXFwdzRoeWxaV2M=').decode('utf-8')
    total = value + len(text)
    return total

def _иЧвжБЬйяτ():
    if False and True:
        _dead_6908 = 284
    value = 593836
    text = __import__('base64').b64decode('aGlxWWxDbFFhWGdkTzJxRjd4SzU=').decode('utf-8')
    total = value + len(text)
    if 34 * 43 < 0:
        pass
        3
    return total

def _ЫДШΗφθАХ():
    if False and True:
        _dead_3105 = 163
    value = 394942
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTbGZVYJqL4VHSv6nVyUCzMezEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 1 * 32 < 0:
        633
        _dead_7776 = 650
        132
    return total

def _ΛЬШβРШπй():
    if False and True:
        154
        _dead_1020 = 534
        pass
    value = 172711
    text = __import__('base64').b64decode('UEVjWGJYSHJiQjE0eDM1OWszT0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΞДΚцρκЗ():
    value = 825283
    if len('') > 0:
        _dead_9887 = 216
    text = __import__('base64').b64decode('dHlRYmozdk1Icmk1ejFLZWh5NGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘЛйщΓωОаΦΟоρ():
    value = 92080
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bwnyb38pxpgMFiGs+kyoPB95tVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АаΧδЮШиΑψьα():
    value = 649053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRy9V2Q33/EtNByonHC6AwJ81GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪφВХысОλΨβ():
    value = 862611
    text = __import__('base64').b64decode('QnI1VllBZWF5Q0RzUWJsOG5EX2s=').decode('utf-8')
    total = value + len(text)
    return total

def _уΖаυρΘНν():
    if 65 * 97 < 0:
        _dead_2243 = 994
        pass
    value = 853323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExvVTXUs2YwHEjqHwEXGHQwLtXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кЬβоЯяΚψΣяЯкηо():
    value = 800575
    text = __import__('base64').b64decode('cjkwenA4MFkycHhlMmRaZXY1Ync=').decode('utf-8')
    total = value + len(text)
    return total

def _ζрυрПΝтЩАШБЪΕΓ():
    value = 350483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHnTYUUa66sUIF2a40yJGRV28kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4652 = 474
    return total

def _ЭρЩаωοφςщςэП():
    value = 296661
    if len('') > 0:
        _dead_2993 = 26
        _dead_7431 = 395
        665
    text = __import__('base64').b64decode('WEpuZl90NUpkazAyYjczbXNYRmo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        109
        490
    return total

def _аθΜшбΣюудпшΖМЮΟ():
    value = 888125
    if len('') > 0:
        _dead_2627 = 537
        _dead_5114 = 9
    text = __import__('base64').b64decode('VUt1VloyQ3FyMUxoR0g3RmpmNnA=').decode('utf-8')
    total = value + len(text)
    if 52 * 69 < 0:
        _dead_6795 = 184
    return total

def _σφъхАмыЙЙэΞТ():
    if False and True:
        8
        _dead_4935 = 563
        _dead_2537 = 164
    value = 901778
    if 44 * 49 < 0:
        880
        968
        366
    text = __import__('base64').b64decode('a1VRamtwcnF6UElWMjJYejhDU0s=').decode('utf-8')
    total = value + len(text)
    if 56 * 63 < 0:
        _dead_7896 = 965
        333
    return total

def _νзоЭκЗλχССξΗβ():
    if len('') > 0:
        _dead_5779 = 459
        _dead_8164 = 735
        483
    value = 586161
    if len('') > 0:
        pass
        pass
        804
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dja8TXU7q4YCFVe351uxNRUO9Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6381 = 989
        pass
    return total

def _ЮПЯυыΚзКζо():
    value = 219347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiDvPlw7p6QAKlqE+HjGZSgO0Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗАЫИГЫυлЛτΞμх():
    value = 410598
    text = __import__('base64').b64decode('QnRjeG5wM2JDM3NrY205MGdJVEI=').decode('utf-8')
    if 88 * 79 < 0:
        _dead_2727 = 759
        _dead_6717 = 995
    total = value + len(text)
    return total

def _кДжοΖφИς():
    value = 268602
    text = __import__('base64').b64decode('ZkVtcExPN205aWJoMUhGQmVJdVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ютЯЭбйΞκΠщжΨа():
    value = 276348
    text = __import__('base64').b64decode('dDVOcTB0eGVwU25MUnhRQk5xTHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _еΜΗзРζоНξОЧДм():
    value = 91545
    if 97 * 15 < 0:
        pass
        _dead_9434 = 992
        87
    text = __import__('base64').b64decode('aUR2MmZoMGRBZ21WckZqQVI0Sjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓμЛψэъαμЧпЩνΓхеу():
    value = 16402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jwnxb0Vv5/laHTW5y1/EBy06zW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 41 * 7 < 0:
        pass
        pass
    return total

def _йчРКυΠτн():
    value = 521494
    if len('') > 0:
        _dead_8460 = 406
    text = __import__('base64').b64decode('UnJtZWFBSzJvUTd2ZkZzdkFwWTA=').decode('utf-8')
    total = value + len(text)
    return total

def _иωΓСдδЯΔжΖШцΡЕюи():
    value = 412012
    text = __import__('base64').b64decode('eThSOURXbUJIc0xpcTVYcUNKRXc=').decode('utf-8')
    total = value + len(text)
    return total

def _юΓЯΩтζнΞκΑλ():
    value = 256795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSX8fXwc+7wWFjC60gWFYCY25ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΛγЫнφХμΗЧ():
    value = 860987
    if 29 * 53 < 0:
        574
        pass
        pass
    text = __import__('base64').b64decode('Q3VOSnA1Q3p1MnFpbHNuclhlbXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗуπуфθΦΖЫ():
    value = 441012
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQHxeW4AyqAWFhW5/UCDADcJzWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нΦдДЛЛОЗдуΧνΙАΩН():
    value = 707525
    text = __import__('base64').b64decode('aGZJVTljcU1wYzE2ZXJUZ3Y2NmM=').decode('utf-8')
    total = value + len(text)
    return total

def _αтσλшλуЩγΕυΥ():
    value = 792518
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgTxQnsIyfkyGw2g3VixAwYi8lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5502 = 617
        988
    total = value + len(text)
    return total

def _ЛΨΦΦΛΣΞТн():
    if False and True:
        pass
    value = 46461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQn0PAkPxIxbaCyNn0OnHXE3y2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        930
    total = value + len(text)
    return total

def _ъзъшцψЩЬθ():
    value = 496401
    text = __import__('base64').b64decode('ZDVWZDkzbU16ZElwWWJDVUNDT3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _мρκΥΥνаΛх():
    if False and True:
        pass
        _dead_3963 = 521
        _dead_9001 = 675
    value = 341825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LT3RZklsy6I0CSGO4UGcAQwp50A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯξикγζωШЦσггυ():
    value = 876180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PX+9TFUPyqEVNyCk4GaDJi4JwX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤГΝИΤюЦЕφпЫЗЛх():
    if False and True:
        pass
        871
        394
    value = 186229
    if False and True:
        936
        _dead_6229 = 356
        _dead_4308 = 559
    text = __import__('base64').b64decode('WjY5MmJXQnd6RzVta3lHNmlETGo=').decode('utf-8')
    total = value + len(text)
    return total

def _фθφлЗσΦβждτоП():
    value = 888244
    text = __import__('base64').b64decode('ZlQwREMzdDF6NU9VT00wbExSUlo=').decode('utf-8')
    total = value + len(text)
    return total

def _κφжзцΑоδнα():
    value = 639156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCHCSXUYzrABFh6u+waiNiwE72Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤыκοΡΟбζЧαΕμШΛО():
    value = 41750
    text = __import__('base64').b64decode('UmdfUWphRjlsdUswcDVrUmNWV2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ДУэпΨЕзшуНΘъЪу():
    value = 810230
    text = __import__('base64').b64decode('bDBjbDZwQVpQSWRlNnZ3cU4zU0g=').decode('utf-8')
    total = value + len(text)
    if 54 * 53 < 0:
        _dead_1088 = 168
        pass
    return total

def _иΕйΝΝΓФηΗαСЕβΖРЕ():
    value = 180053
    text = __import__('base64').b64decode('V1lqQXlRUzhCdXoyczFlSmw4WDg=').decode('utf-8')
    total = value + len(text)
    return total

def _φхЖЫУГΘΑ():
    value = 581730
    text = __import__('base64').b64decode('SDhnTXFLc21UZ3Y4czRxSlRsbHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _йЯйУнъКШο():
    if 92 * 74 < 0:
        pass
    value = 72323
    if False and True:
        _dead_9642 = 516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FST0dGEw8KEKNxrz0mGWCyEI7kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 52 < 0:
        _dead_6901 = 305
    total = value + len(text)
    if False and True:
        _dead_9831 = 394
    return total

def _еиъωθΣТнЖртΑНρиθ():
    value = 331978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgTbY25v5/sSaRyM3lPAFhAGsG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΩкЯьПφхτΣνЦ():
    value = 695252
    if 56 * 97 < 0:
        _dead_4179 = 713
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EA7vbwcu8r5SETmwn3yJMRQfyzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔйЩЮъΚνВЪΥЫУςλΑ():
    if False and True:
        73
        _dead_2425 = 373
        pass
    value = 772752
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSW3eWs0p/tVOTqK21KIMwEa73c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъЪΖΧБиμеЪαх():
    value = 185999
    text = __import__('base64').b64decode('VHZJZUlxM0xTWkxEcDlaaFhFX04=').decode('utf-8')
    if len('') > 0:
        _dead_5119 = 742
        pass
    total = value + len(text)
    return total

def _йυфЕνμπΘбрρРЗ():
    value = 688105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwfCRVIbrL8XEQui30yTGhwB8F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_2809 = 795
    total = value + len(text)
    return total

def _ЫτΕΙΒкαнСпДУ():
    if False and True:
        885
    value = 799947
    if 88 * 66 < 0:
        _dead_4890 = 335
        489
        843
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwDyPUga85k8byj3mka6EDELtH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _μΒсаειβВαр():
    value = 480069
    text = __import__('base64').b64decode('TlQ4aVVaUUd3eFNUUTc0MGVaY18=').decode('utf-8')
    if 6 * 3 < 0:
        966
    total = value + len(text)
    if 90 * 92 < 0:
        _dead_1671 = 469
    return total

def _БщБЛЮΣΖχеГО():
    value = 244758
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mxy0PXU+xI4IEzyb53uENSkm13w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΟξδЫВыА():
    value = 498749
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgrxV3Ar6KpaaTuE+163Fncu8mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρБοχэσξЩтх():
    value = 368620
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ki3ueVAtz4VSHSqc3FLJPXIEsns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧЪьЧпмКοуΜφ():
    value = 305164
    text = __import__('base64').b64decode('S3FQRDhPUVM4Y1hmdnFjUHVUREg=').decode('utf-8')
    if len('') > 0:
        _dead_3718 = 562
    total = value + len(text)
    return total

def _ΘщтьΖКЛпΚДщеΟξб():
    value = 401098
    text = __import__('base64').b64decode('b2hHSnM3THRhZ1hpVXMzN0NSSVU=').decode('utf-8')
    total = value + len(text)
    return total

def _нυчвЦАтЦдтΘ():
    if False and True:
        pass
        22
    value = 951722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBfga1IvqIsIKwe06VW6MwIo5l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 43 * 32 < 0:
        758
        143
        _dead_8822 = 502
    return total

def _γЪιнβψςЫдιΠуγЦΘο():
    value = 593868
    text = __import__('base64').b64decode('dDhkX2huWW1zNGlubVZERXFCcWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ибАωΑΔΔтφΜρ():
    value = 137674
    if 14 * 37 < 0:
        pass
        pass
    text = __import__('base64').b64decode('ZGxXaUVqekJBMzFRWlI4NGFfQkc=').decode('utf-8')
    total = value + len(text)
    return total

def _γЫМЮяΙΧчΛЦЬΝпΜс():
    if False and True:
        892
        _dead_4301 = 563
    value = 310734
    if 48 * 44 < 0:
        341
        652
        _dead_9749 = 562
    text = __import__('base64').b64decode('ZjF6RTZDWjg1aDY3alZncjZFamU=').decode('utf-8')
    total = value + len(text)
    return total

def _ФхπΝωТππγлРшИ():
    value = 390258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AC7vUWAw3IYuOBz64XKqESoj4z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΞκЭΒЛкОпρЫЮУφΕπ():
    value = 795088
    if len('') > 0:
        514
        pass
    text = __import__('base64').b64decode('VmdfeTVJTXBVaTV6N2JGak9yWEE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4125 = 630
        pass
        337
    return total

def _ЪфΩеВρψдυ():
    if False and True:
        _dead_7010 = 3
        872
        _dead_8110 = 792
    value = 44828
    text = __import__('base64').b64decode('aHdlSnFJd0VIRGNVU3p5ZlNkQWg=').decode('utf-8')
    if 68 * 25 < 0:
        433
        286
        968
    total = value + len(text)
    return total

def _МμЗΦδФчΡУνБюΔεδО():
    value = 873312
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARizf0I72PlVCTmr+ny7JyI77ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΕρшφΩУΥМ():
    value = 76358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH7Fdn0D954VKTCi0XqDOikD5nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        770
        622
        _dead_6423 = 415
    total = value + len(text)
    return total

def _ежμпЛυэτпЮЧχ():
    value = 548423
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3/tXUYJ1K8SCCj02kfJHA4Cszg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δзΤШпЮφγлБεЗΑ():
    value = 528957
    text = __import__('base64').b64decode('cFpDUFJaUWZXNGNTZzFabFBjcUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ДαιΤЗЭЦΘРμъ():
    value = 772762
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mw3RY3VtpoEgLRqowQKHBTIAwnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓνΜιзφъΠжСУηΠ():
    value = 716377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHvLZ24j3JIEPjCRnn3HLTYs5UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВωЦирЗсъΣΨКЫо():
    value = 123525
    if False and True:
        _dead_8245 = 920
    text = __import__('base64').b64decode('c2lzbHVKWGNwS1k5YWpZeGg5aTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ДЪадωшфпΑΤηΜЕ():
    if len('') > 0:
        _dead_8937 = 822
    value = 596498
    if len('') > 0:
        86
        310
        254
    text = __import__('base64').b64decode('a1IwMHQyVFRCbkxESEsyM3dmbmY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ПΣйуπΔσбιΝΑРεΝ():
    if 70 * 3 < 0:
        pass
        _dead_5067 = 797
        _dead_7019 = 448
    value = 3189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fyj8SWNpqqQpMRmW0nmdGjI+sE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        720
        pass
    total = value + len(text)
    return total

def _лРфχНцΗЬЧПу():
    value = 445866
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRzCeVhu1bEKMDz2xEHJO3d3xmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 33 * 40 < 0:
        _dead_3822 = 551
        _dead_1050 = 163
    return total

def _ТΘчРχшψιΠУφщ():
    value = 178707
    if 98 * 90 < 0:
        962
        693
    text = __import__('base64').b64decode('SVlCQWtSOWtFOWVlRWIzaDlYNU4=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        _dead_3816 = 14
    total = value + len(text)
    return total

def _зШΩΕВПΜЧξС():
    value = 819874
    text = __import__('base64').b64decode('WTNUTjJDT1R5MVR3NzAyR0R6WHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞαΧξΚцΓБьΑΠзлρΛм():
    value = 54043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwfgR1dh9KUxDSr13E68bSc+3UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        412
        844
    total = value + len(text)
    return total

def _ЦЗйэгДЖМΡЗЕф():
    value = 682523
    text = __import__('base64').b64decode('bWloUElXZmxaRGttRkM1YzFkVHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ηэθΒяΠЯщΙ():
    value = 573260
    if len('') > 0:
        pass
        pass
        317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTbQWGUL6KU6PTiR+XOEDnMisF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6272 = 737
        _dead_5244 = 571
        _dead_8735 = 486
    total = value + len(text)
    return total

def _ХЙΔЯπпВпеυοαУчοю():
    if 22 * 84 < 0:
        pass
        610
    value = 54235
    text = __import__('base64').b64decode('cmZXbGt6WVczZmVJUkI1dFJWR0c=').decode('utf-8')
    total = value + len(text)
    return total

def _θμлТΜыΦш():
    if False and True:
        922
    value = 314879
    text = __import__('base64').b64decode('RWJvQ3FraXhoVXJ5Y2FYN0JuRzQ=').decode('utf-8')
    if False and True:
        _dead_5889 = 532
        _dead_3061 = 470
        pass
    total = value + len(text)
    return total

def _εΞЕμФЗЧδдчМиьО():
    if False and True:
        _dead_6709 = 313
        _dead_1329 = 882
    value = 20796
    text = __import__('base64').b64decode('dDd5eDVROFl2SDkxdENUSmlzNTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ржьЧЭΙЪΙМсΙ():
    value = 725675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDjFfF8h870vKhy6y3mfAQsF9Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιзοпУЮШΝтБмуяН():
    value = 461105
    if len('') > 0:
        _dead_6950 = 93
        pass
    text = __import__('base64').b64decode('VkJBb1ZYcmRBNEQzZUkyc05ockk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟαΜЧγчΒΝо():
    value = 851532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTf0SF8o5I0hPFurxmC2HigYxmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖэБКωШгΛζХ():
    if len('') > 0:
        _dead_3262 = 107
        703
        pass
    value = 164418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NivMfUltyLkmOx2E2XqBNQQ/xV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫιФмЪΛπβЬЩ():
    value = 690169
    if 50 * 65 < 0:
        pass
    text = __import__('base64').b64decode('R0NNc2VjcVc4QWRrUUx5Rnhya2w=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6317 = 456
        _dead_2683 = 428
    return total

def _πмΞΥГΜζΦК():
    if False and True:
        190
    value = 391234
    if len('') > 0:
        _dead_9368 = 353
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXvXeQghy5gEKAKtkX2qYDcOvTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 7 < 0:
        pass
        _dead_7587 = 354
    total = value + len(text)
    return total

def _οΚΑлоΞйФ():
    if 69 * 43 < 0:
        _dead_7559 = 877
        pass
        890
    value = 800065
    text = __import__('base64').b64decode('a0pXekxsY3YwNm54YzdFdVB0dk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ωХνтЛсωμ():
    value = 846101
    text = __import__('base64').b64decode('V2NidTRSYWNNME1qdEswWWhsbzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _сΦεωсШЙцнЧчΑжΘι():
    value = 543232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3jFSgZp8r43IhiPzlfGZR0YxWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6280 = 152
        _dead_3465 = 263
        pass
    return total

def _ηιΣδεΧэШΦЩВΨЧДБ():
    value = 336942
    text = __import__('base64').b64decode('alo1TlRFTUpmaHRlQ0RqdUVjWXM=').decode('utf-8')
    total = value + len(text)
    return total

def _πЩΠμΒμπЪχШΣΦос():
    value = 564616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBfDNmQU564gKziG0UCkEisi/Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬλХГνΡξκЙΕЖЛωАφ():
    if 49 * 46 < 0:
        _dead_1437 = 315
        874
    value = 465867
    text = __import__('base64').b64decode('Q0hXSjFEZmlUUnY1eEpfTE5MRDA=').decode('utf-8')
    total = value + len(text)
    return total

def _эЕтгсΤлΦρΝςκΛ():
    value = 665734
    text = __import__('base64').b64decode('ak1KVnluN0Vya3VjZDhpVExTd00=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣЯΣΠπσЫЩтδС():
    value = 592968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRzbaEcx1royFQL68kaVIgII7G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жсΕПδρφЦтЖм():
    value = 924147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzzdaFUM3KkGaie75EGFOTc7618='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζΘрγВЦФΦЭ():
    value = 104417
    if 16 * 65 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NS3WWHk2xIAaNQ6wy0HBIQl2wzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΠпкзΘРааЩмЫυЩυτ():
    value = 552407
    text = __import__('base64').b64decode('a2hBTlFwTnFkYWVRdnJfNFZwTE0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5938 = 736
    return total

def _дωεΓрВΣм():
    value = 150264
    text = __import__('base64').b64decode('bnY0dzlnWkJvaHRGN1VZZzk3TWc=').decode('utf-8')
    total = value + len(text)
    return total

def _йкЩΥЪωДЯуаМас():
    value = 6964
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB7ISHY83akaORqsmkeXBgEC23g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЩЫгΝΖκЬЧъΑσ():
    if False and True:
        _dead_7534 = 500
        pass
    value = 888614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj7nQgYN2PgHLzuu2XqaFnIcwnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛμюτжьεСзΤЧ():
    value = 74572
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCjyfgM66qACNhagw1OvMncMvXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        111
        _dead_9452 = 659
        _dead_9514 = 366
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if (True or False) and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()