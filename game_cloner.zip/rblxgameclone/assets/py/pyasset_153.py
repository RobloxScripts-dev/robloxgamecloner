#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ИлιΝκДζζИБСμ():
    if 64 * 46 < 0:
        pass
        763
    value = 220783
    text = __import__('base64').b64decode('WnNVU0NRMm03b1N1cUo3RTJmRms=').decode('utf-8')
    total = value + len(text)
    return total

def _νΒζяΝΓлРСχψУε():
    value = 730560
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3a0Z1Vq6/koLDab5EbIOis84Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вЪНОΔтацΜчΞяЬшй():
    value = 686553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDb2TXopq/4uCjWVyQfFCzY603o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АξцξкхωШΡΠщАШχш():
    if len('') > 0:
        34
    value = 474568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3nrN0Ma7fgBOxWHyUOvYycM1nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧйаΔеИЦжыЬφВЖαМ():
    value = 250515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSX2SVgz2voGAx6R7He4BHwm9zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛвЛЫγΞλЩлηΧνГγВХ():
    value = 319843
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3zOfgI024MULx/2ykO1DSsOyDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΟвфвΦФητк():
    value = 941458
    if False and True:
        _dead_2140 = 631
        763
        925
    text = __import__('base64').b64decode('QlNnRzBlMkE2cFhyZ2xnUV94RkI=').decode('utf-8')
    total = value + len(text)
    if 73 * 74 < 0:
        320
        _dead_6188 = 173
    return total

def _аСφНщАхОΔкπаьο():
    value = 393462
    if False and True:
        _dead_5056 = 521
        _dead_1346 = 952
    text = __import__('base64').b64decode('SVRrbHN6V3lJb0FzdDIxeHhvQXA=').decode('utf-8')
    total = value + len(text)
    return total

def _υΥΘκΛггчετя():
    if False and True:
        pass
    value = 368802
    text = __import__('base64').b64decode('SzdsZndKRFVzOV9tcVhtM0pKdzA=').decode('utf-8')
    if False and True:
        _dead_1972 = 746
        pass
        pass
    total = value + len(text)
    return total

def _ьТАΘΗБАβАΤμδф():
    value = 246110
    text = __import__('base64').b64decode('aU5lRVhTNzd2SWRZYWVaRklZeno=').decode('utf-8')
    total = value + len(text)
    return total

def _БтуэγЧγФи():
    if 91 * 5 < 0:
        pass
        _dead_2886 = 282
        pass
    value = 768918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxftQUQX1oUmH1uQ2FPFFhN960g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 19 * 6 < 0:
        pass
    total = value + len(text)
    return total

def _ΛжβΩΖΙΙβющп():
    value = 740818
    text = __import__('base64').b64decode('Z2F1TmM5MmFXYlhmcjBSZ3NFdHM=').decode('utf-8')
    total = value + len(text)
    return total

def _θКΘΥвλоББЖыуθ():
    value = 955177
    if False and True:
        444
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzrsdgMzwb0bNQCV33OAFSMdt2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψцΘεεωяиПψΨР():
    value = 513505
    if 44 * 52 < 0:
        _dead_9820 = 397
        pass
    text = __import__('base64').b64decode('VldPdE1qUnBCSlp2S3c4dmdLVXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _χСΤςηаΠЮщЦУЬОЗ():
    value = 201295
    text = __import__('base64').b64decode('YllxWFp3dGw0bFNsTE9kbjJ2ZzU=').decode('utf-8')
    total = value + len(text)
    return total

def _аΨοσЬβΕΟγтэцФбЭ():
    value = 615849
    text = __import__('base64').b64decode('eWNEQW9FZmg4SGtPN3hwWVZYME8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΤΚΒзσУЛЭΟмσ():
    value = 340219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAfRZHUP5IEJLF2W7GWpMgY1wkg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        694
    total = value + len(text)
    return total

def _фСцюΧышдФвэΠ():
    value = 165756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQrAdAUVpqM3Ihew526JOXAjsUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΕηыμοцΚН():
    value = 309534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBXuPEg2yZ0MKQ2yzVyRGSYI7z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вЫъΩЪεЮλΠзκΛ():
    value = 980146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BD3HPnsGqYVSbjiBwF2cI3cY20Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МитητщАΛΗδΩПρ():
    value = 44309
    text = __import__('base64').b64decode('c3p2aHlkRTVZSFJKcXRGYzBxM1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕеДΜНЭмпΙюцКЮЭΘ():
    if 48 * 47 < 0:
        _dead_7042 = 212
    value = 778927
    text = __import__('base64').b64decode('R2xvUWdONU1DMFRwZF9nNXVQbWI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_4420 = 50
    return total

def _мФйχМгъΠμъп():
    value = 153927
    text = __import__('base64').b64decode('WnRhMGpBNGZsdWRoZGVqM0lob20=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪПΥΑнΕШЯ():
    value = 775015
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBW8VmYP8bhWD1qH60eGFjQu3kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if 42 * 44 < 0:
        _dead_5403 = 934
        976
        pass
    return total

def _юиΔйдγщШж():
    value = 758353
    text = __import__('base64').b64decode('cHpOS2hqWUd2YTZDVXJwc0NHbHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ξЬНζЮКвшэΠШςΝΣ():
    value = 652773
    text = __import__('base64').b64decode('VjNmc3MyS1FqcW9PYVhRMUNIM3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗμΕоЦЧэжйΟΨтзйκ():
    value = 226247
    text = __import__('base64').b64decode('YVB3VlBya2k3eGFjQ1RwaUJ6MV8=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΞСрТνУхсвТ():
    if len('') > 0:
        _dead_5314 = 829
        961
        _dead_6041 = 651
    value = 674877
    text = __import__('base64').b64decode('dmxFVkx3cWZva3dPWk00NE1KOFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟωЮЬγтΩДβ():
    value = 633411
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnbbPVQJ67EFEF6B/w6fLTJ91mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υЭвьξρΝРμкιс():
    value = 558574
    text = __import__('base64').b64decode('ZkZOejdqeFpZb3VYbU1mSmU2bFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ъλΣΣМΧχЧΔφ():
    if len('') > 0:
        206
    value = 824495
    if len('') > 0:
        pass
        163
        960
    text = __import__('base64').b64decode('b0lxalNhRVFBRVFDMDVnRjRpSkk=').decode('utf-8')
    if len('') > 0:
        231
        pass
    total = value + len(text)
    if 54 * 35 < 0:
        _dead_8234 = 318
        755
        pass
    return total

def _λΖΑЯШΚчтθлθΓКк():
    value = 735967
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTbCYkQOx/8uAwS62nPIYzN5/ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αΓΡкЭΘΓпιщ():
    value = 540769
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3fVaFQO0LggDyeE61e5PAMKvHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 39 < 0:
        pass
        _dead_5808 = 205
    total = value + len(text)
    return total

def _λψъюЪЙμΧчЛЖνф():
    value = 413998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjzlRlMb8/g8Aguy/3K6HzN5zEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 21 * 38 < 0:
        pass
    return total

def _ΟΘψбκΟеЪβθьыЯ():
    if False and True:
        243
    value = 510784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBzKPkdp16snFR2CmGOWAXQJ70k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИЦЩΜМЯЗЯиΨσ():
    value = 976738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDXtaWcJ1q85bSDz6VXHPzAIzzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γйчТеБЖЫ():
    value = 629021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A33BbGEWrLIBDiaC3maoMQJ39kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цιИονΞξюψЯξ():
    value = 431977
    text = __import__('base64').b64decode('S2pKT1RVcFlYMDFDcVZ4VHdHdWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖтМЛφЩЖюλβьψЛыζΣ():
    value = 223067
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQS8Rkg6pqJTDBqF5H6GIwM5zUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УяΩιоЧШфЪЮΗБ():
    if False and True:
        pass
        199
    value = 551916
    text = __import__('base64').b64decode('b005QVYyZ2NfN2pTUWNWQXJ2U00=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЖБΩЪфТРΖΓузωфКГ():
    value = 344507
    text = __import__('base64').b64decode('cmM4R1pLa25IUTNLNWI4cWJkQWI=').decode('utf-8')
    total = value + len(text)
    return total

def _цМφωεΖζЦεЛΛΡт():
    if len('') > 0:
        _dead_7133 = 308
    value = 171947
    if len('') > 0:
        _dead_5737 = 118
        _dead_7243 = 202
        189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgjgPkAs3PgMHAaG70CAJHZ27Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯЛЮбΚΕΗыγЮЩσнΖ():
    value = 997262
    text = __import__('base64').b64decode('ZDJBcWZmbTd3dHZRRW9YOWRTMEI=').decode('utf-8')
    if False and True:
        pass
        658
    total = value + len(text)
    if 64 * 35 < 0:
        197
    return total

def _ГГΥъцΗΧλшА():
    if 24 * 47 < 0:
        _dead_2499 = 123
        pass
    value = 263602
    if len('') > 0:
        276
        pass
        432
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiC8fHo/q4YWOAibm1mlMD0dtUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РρщйΥлΖτπηсшЧ():
    value = 125776
    if 69 * 40 < 0:
        661
        237
    text = __import__('base64').b64decode('dUk0dFpWRnE1dFEydjFINXd4clg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΛΠΤαвЛВФъ():
    value = 565981
    text = __import__('base64').b64decode('S05FYmwwTmVwUnFmSF9md1pacUo=').decode('utf-8')
    if False and True:
        883
    total = value + len(text)
    return total

def _джχηЫЪωεчХχΘц():
    value = 111000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgPAO3QqyoYPLiy562+CZAB70F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3097 = 251
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        869
    return total

def _жфΝэΥηЮАщР():
    value = 870946
    if False and True:
        220
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXzbd3Aj644sCzW6zQKzZS8IxXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕηЖЪКτФφνъьМ():
    value = 710552
    text = __import__('base64').b64decode('YzlydTBZNm5PWXcwcXNqT1Z0cWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞтКЕιΕΓΕ():
    value = 230164
    text = __import__('base64').b64decode('Y1BCWm5WMEFzaGNRNVFJZHVhb3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛωΣЛΟΔАΨфΖοМ():
    value = 254268
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAX8aVoP1KYKAwKH7FHIIgs84mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _киыΤЪЯβτиСΟюИаЯ():
    value = 850068
    if len('') > 0:
        _dead_2159 = 342
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQfvY0gJ6oQKDxWv7F65OB0Cw2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫγЕΛΘΦНθМφε():
    value = 42365
    text = __import__('base64').b64decode('WlpQd25Ed1RxZmFmZm1aQWxBM0w=').decode('utf-8')
    total = value + len(text)
    return total

def _лοВγйΛςОΦδΦБΜΓРυ():
    value = 379100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAz8OQQBrZA1PAmJ3FfCGzx8tFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗИпΙухΧΣΤЪ():
    value = 979546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiPiaF09q/wsMhfz73yiN3AI4X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥИΣрТРбφκ():
    value = 636249
    text = __import__('base64').b64decode('YmlRQU96VmVjV3RkWDZ2VDFfZkc=').decode('utf-8')
    total = value + len(text)
    return total

def _хДΓЖΞщςτΒψΩиπΓШ():
    value = 57145
    text = __import__('base64').b64decode('cHNhV1R4bjZsTmRjNWNHaVZrT2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ХωωУεТЦьΞφοΔδκЩц():
    value = 462817
    text = __import__('base64').b64decode('U1hVOXJFVWs5WmlVQXBVaVFvY0c=').decode('utf-8')
    total = value + len(text)
    if 81 * 33 < 0:
        230
        _dead_3372 = 542
    return total

def _ΡξСыοΛТЭνΧьαΣеНн():
    value = 870156
    text = __import__('base64').b64decode('aXJoYm1tZ3R4X0FRTzBJV0tuZWI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6351 = 97
    return total

def _ρГЛсΨнеъп():
    if 77 * 36 < 0:
        pass
    value = 59553
    text = __import__('base64').b64decode('T2p3MjRweFA4RkxoTHhTRzE2dlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦερΡЛμΝΗΛ():
    value = 708078
    text = __import__('base64').b64decode('aEVCZ1publhKRko4TUVMZ3Y1Xzg=').decode('utf-8')
    total = value + len(text)
    return total

def _μЮπΝЪгκЬςщ():
    value = 635120
    text = __import__('base64').b64decode('aEY1cHNmMTlOZ19ZZjZ5OXlwVGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΟγΤнΔусΠгЗΞ():
    value = 221741
    text = __import__('base64').b64decode('a1A4M1RRVUoyczNVM2NKb1dKTGw=').decode('utf-8')
    if len('') > 0:
        _dead_6026 = 625
    total = value + len(text)
    return total

def _СδβχхαЕΗЧΟ():
    if 78 * 62 < 0:
        685
        pass
    value = 681486
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy7sWHc97qAiHi2TxFeHDCcIs14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΠбεяцчфясуΖΙδК():
    value = 751823
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXfzOlw7044QMwr3mHqGOjIktW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τφΓюЛчΞиαьΑΛεΠО():
    if len('') > 0:
        163
        pass
    value = 280660
    if False and True:
        422
        _dead_6472 = 991
    text = __import__('base64').b64decode('WG5DaEszMkFCUUhVdnN6bDh6bVA=').decode('utf-8')
    total = value + len(text)
    return total

def _атΧΧЖРытςЗЭщΒυ():
    value = 640527
    text = __import__('base64').b64decode('aERhNENnN29tdGpHWEJiWHdsRHU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        649
        pass
    return total

def _υψσкьΔμя():
    value = 73944
    text = __import__('base64').b64decode('QV9FY2xYSzZLSEQ5VjJualpld0M=').decode('utf-8')
    total = value + len(text)
    return total

def _νΤΧаΠνФΝетνφя():
    value = 632812
    text = __import__('base64').b64decode('YXRUZDRGc1VUendoVlExNmtBemM=').decode('utf-8')
    total = value + len(text)
    return total

def _БΟκΥδНΑНυΑςδ():
    value = 238011
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhuxS3cKroAIMTiRkFe9ZAwN3Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЩОфвЩхТ():
    value = 149545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBrFel8N3IMCKTWi8gK8Bgp41lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъδΩНφТσУ():
    value = 505359
    text = __import__('base64').b64decode('emtaUEh2cWRkYnU5dmxjaHRxZ3I=').decode('utf-8')
    total = value + len(text)
    return total

def _АюφΞиβшγκ():
    value = 981622
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCriUXYL3YkhCCqKnnufOhwAx28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юβВХкфτΒ():
    value = 600109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgLnV1I+/b4uGADz4QeCPzJ/9ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АθαψΩДЮэПЧεЮэΞΚ():
    value = 356912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AibdZ0I75pE6MC61+Xy9PA8t8nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ацзθΤРΖЙΥΡпяФ():
    value = 653530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jwa2SV8L1r4vazyF8gS2IA0Q12U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕιЫШнτШρт():
    value = 124578
    text = __import__('base64').b64decode('QnVrdUpxUmNNS0NWVGxqMlk2aG8=').decode('utf-8')
    total = value + len(text)
    return total

def _εБшъоΨΖΧъГςЗДсцЭ():
    value = 843788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjrDRnc0+oRXCiOl+kOqHhAMzF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΘΠщΗΛπУоΙВωУН():
    if 12 * 32 < 0:
        259
    value = 446381
    text = __import__('base64').b64decode('eWhWS29wUGs0a2pvNDBBWE1mMGw=').decode('utf-8')
    if False and True:
        _dead_6614 = 720
        pass
        _dead_8488 = 879
    total = value + len(text)
    return total

def _τВЦΘуИρн():
    value = 90762
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX/XSEIP/6ktLBaxxgCWJiY+s34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΑфШцβКЪЙκнλρψиХ():
    value = 329430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxvvOH8a8osoPwGyz3WIG3w+6Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 82 * 2 < 0:
        344
    total = value + len(text)
    if len('') > 0:
        640
    return total

def _θКΚШбэьАεхЭ():
    value = 604312
    if False and True:
        _dead_5206 = 356
    text = __import__('base64').b64decode('TVkxQ0VlZzdPQmdVNGUxSTZ6THY=').decode('utf-8')
    if 78 * 50 < 0:
        _dead_9471 = 892
    total = value + len(text)
    return total

def _φзυЗЗьцАМψйчРΔЕη():
    value = 4168
    text = __import__('base64').b64decode('R01uR3BybmdJbU4wZzhEb0dsb0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ХУбχγΠаκ():
    value = 128446
    text = __import__('base64').b64decode('ZHFVRlB2dGZ5X3NOZlFHOWRTQ0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕυФЧдεчΝΠмΞ():
    value = 637207
    text = __import__('base64').b64decode('b1JpNXlsNUZ1TEZ5WDdVQlhBSjg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_5061 = 315
    return total

def _ΦΖтцΠςпτхиПЙЛдЮ():
    value = 656203
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBfFPHM//P0aCF2xmlGpZhIe91g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦЙЮшбъΦСε():
    value = 393151
    text = __import__('base64').b64decode('SG5XdFhIR205ZTR1ZERFZjZtMl8=').decode('utf-8')
    if 64 * 36 < 0:
        995
        _dead_8803 = 795
    total = value + len(text)
    return total

def _ςΞаοыъψθσФУεЭИХт():
    value = 224410
    text = __import__('base64').b64decode('WnNLTGd0TEZoTDRSMzFBeGV0b28=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧаΦЯдпЯтТВшщ():
    value = 249547
    text = __import__('base64').b64decode('UnBFZGtfQW9UNlpWQUpOR002Yk4=').decode('utf-8')
    total = value + len(text)
    return total

def _нъΕЦζвПШмωуЮоич():
    value = 305698
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwHQb2k7z4YlCQSb5FyCEw536j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΧИνРτРДΨ():
    value = 506229
    text = __import__('base64').b64decode('RVk2MUlKRlpvQjRCVE5xQmF6SUE=').decode('utf-8')
    if 76 * 16 < 0:
        pass
    total = value + len(text)
    return total

def _бΛюОςυЖВΛсЖξЮυА():
    value = 213361
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAbiXlIo7fpQEF6c8WbHMQN9/Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        43
    total = value + len(text)
    return total

def _γπψмΡλοΙбОьЯКшлщ():
    if False and True:
        370
    value = 728247
    text = __import__('base64').b64decode('SDN3NHFRUDVlVEZRTGUyRm96U1U=').decode('utf-8')
    if False and True:
        329
        387
        742
    total = value + len(text)
    if len('') > 0:
        220
        188
    return total

def _ъюрτρлΔμΖШνРμτΧ():
    value = 455011
    text = __import__('base64').b64decode('dXJ3cG1QS0gyNFZPcGxqMTZ4TjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΡνдчеγΣм():
    value = 119895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AibXXwMu3L8CEVat7nC7Zjws7Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зεЩΧΠТελΗΒ():
    value = 637768
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mi62bFxr0JEWI1mS+ACJJ30ss0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖшБκГЪΨтгшжεμпκ():
    value = 365556
    text = __import__('base64').b64decode('cnVTR0xCXzQ1c2JBQnI1UTNjUVU=').decode('utf-8')
    total = value + len(text)
    return total

def _яΑφЩφтмЦЪЗРвь():
    value = 407586
    text = __import__('base64').b64decode('WDFPUFRzcXMwcWlSN2puZUU1RUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯРшГДЛΖЯщЫэЮЮ():
    value = 498073
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgvQd2c7p5kmAAKW53LENTUJsXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТρΩΡЧЦсЖ():
    value = 214640
    text = __import__('base64').b64decode('cnBrcTA0a2F5WkJ0ODRLcEVUOHc=').decode('utf-8')
    if False and True:
        pass
        218
        937
    total = value + len(text)
    return total

def _ъεΜЕЬКΥΔΥ():
    if False and True:
        pass
        pass
    value = 368322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSbbPgkPx5oSbQ6h+EHFBgsrzkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κоννΩуБΔюхфΑыз():
    value = 955278
    text = __import__('base64').b64decode('bTB1d0luMUZXVkNoZWRoX0JpNGQ=').decode('utf-8')
    if 18 * 23 < 0:
        _dead_6376 = 154
        pass
    total = value + len(text)
    return total

def _бьРνβчйβЧΦжфЮ():
    value = 196006
    text = __import__('base64').b64decode('SFVYMkRkWno1d2d0VVNjanJNUjg=').decode('utf-8')
    total = value + len(text)
    return total

def _яαΗЖДиШΞφОσθту():
    value = 401121
    if len('') > 0:
        _dead_4191 = 530
        pass
    text = __import__('base64').b64decode('eVdtaUxCcHhnSzFUbEhEODljY28=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥЧσВεΩνвяИо():
    value = 843897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDzASFpr6rEiEQKO/VCbJgs6zDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЮξζξДбεжσΨъыКθЬ():
    if 15 * 71 < 0:
        pass
        pass
        638
    value = 190208
    if len('') > 0:
        857
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FynIRUEV2PwhKR736QefLSoD3Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВδтΖτΑЬτъ():
    value = 713084
    if False and True:
        pass
        _dead_5366 = 216
    text = __import__('base64').b64decode('TUlRU1lUQThDT0pxakV6VThHWTk=').decode('utf-8')
    total = value + len(text)
    return total

def _σЖэйЦаΤЙКБΖыΘΑоХ():
    if False and True:
        780
    value = 209620
    if 51 * 97 < 0:
        323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhbDY1kt84M1DQ6T0VHFOig44G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙыОТрпιИξΩΞеоЪΚ():
    value = 956213
    if 91 * 31 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgfURnc6zZgaIwK07neEMzYh5mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υЕτЬоιΧιже():
    value = 802355
    text = __import__('base64').b64decode('bGNDZFV5a3NveFhXUmNjS0JIcU8=').decode('utf-8')
    if 32 * 83 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ΗζΩΥχχЛΣΨμЗКчдШ():
    if 85 * 51 < 0:
        pass
        897
        pass
    value = 64825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjX8WmYJrIYLGCqX6QK6PDc84ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΩщιхΛιяεфмΓ():
    if 38 * 6 < 0:
        _dead_7763 = 511
        526
        pass
    value = 937942
    text = __import__('base64').b64decode('Y3dtbkk0NDhKemRQUnRJTUhxeFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЬγνЪНЕОьθИсщщ():
    value = 430999
    text = __import__('base64').b64decode('QmFmV0s3SmVneGJWeEFUb3lyTzU=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_9780 = 303
        pass
    total = value + len(text)
    return total

def _вΓτΤЖςΕΡЗчьηзбщк():
    if 94 * 79 < 0:
        _dead_7695 = 74
        630
    value = 277986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAjJZ0U77v8UOympmFC9MXwAyEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чшΞюθΜΞΖ():
    value = 649199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwnJZHw0qqk8Fy2r4nSvJnEa00Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9287 = 863
        _dead_7528 = 345
    total = value + len(text)
    return total

def _эПТδУмеΨдМЦΔч():
    value = 79593
    if 8 * 72 < 0:
        16
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR/tYnQb97IbPiOX8kLIF3Yr9jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8180 = 772
        _dead_1012 = 333
    return total

def _мБЩλЗЗуοеОДΠОЬ():
    value = 104371
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgLqbGQ75qRVPV6MzkyBHAwX7Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _тКιφГЯеρшΑΖЪΞ():
    value = 956473
    text = __import__('base64').b64decode('U2VQaHRaVzZ2bFA2ZkY5NHVrM2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΦΦЕψЭОК():
    value = 935851
    text = __import__('base64').b64decode('Zm1rSnRDeGZVaGxLcUdSS29hV2Q=').decode('utf-8')
    if False and True:
        pass
        _dead_1353 = 324
        pass
    total = value + len(text)
    return total

def _игΑАΤεΟς():
    value = 497094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCzrbEZp6KUoORv672KqGBcJwVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΒнλФВΛдσюхιΜчЮ():
    value = 879008
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EC38NkUu1roBECO53l+KCzAt13Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иξμΟαхΕяε():
    value = 566125
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwjNZ1sQrLAWGQOKmXvEHzIEzj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КεЖΩтЮДνЫπ():
    value = 48334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDjsUWE2qYYJbwO1x1KkF3R8y0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪДЭσжкЭЦμбιлрюο():
    value = 8244
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KH7oW24R8aJXLDr10Q+XIyIhzmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙеχУψАОΗкΝ():
    value = 173198
    text = __import__('base64').b64decode('WUNJYTVMWGRpY1A0WnFOaGFYNlE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЖчВθкАЮφэпыЕξΓ():
    value = 344558
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzzeZmMSyJAvBQD33U6yPwo/3Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗЦψΑЭςоЧιЛτЫΕγэ():
    if len('') > 0:
        _dead_7845 = 160
        _dead_6063 = 978
        840
    value = 583780
    text = __import__('base64').b64decode('bXJWMldoUFF3ZUJJbVU5eUx4Yng=').decode('utf-8')
    total = value + len(text)
    return total

def _ййΤЛлУУвИ():
    value = 28124
    text = __import__('base64').b64decode('TEFrNF9JSXcxWUhqbjA4NVRsYmo=').decode('utf-8')
    total = value + len(text)
    return total

def _шЖВΔΔψΦуГЯφ():
    value = 425361
    text = __import__('base64').b64decode('ck9ZRUhtNzBCX2RiRkhvaUNraXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ПοфХЮцβТБйδμ():
    value = 267127
    text = __import__('base64').b64decode('d0ZZc3pUSDlPbGtmQ3B6MDNHQUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙУньОγСюВЮЧξΝΖЭχ():
    value = 295381
    if len('') > 0:
        _dead_7382 = 124
        pass
        _dead_3381 = 997
    text = __import__('base64').b64decode('S1ZBVDliMWtCU1dfMUpDdDZkRnI=').decode('utf-8')
    if len('') > 0:
        990
    total = value + len(text)
    return total

def _σьΝΙΜΔюЭТСχзΥΚΞ():
    value = 628434
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSbBX2MW1IMzIA6g2meUHgojtGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        815
        pass
        pass
    total = value + len(text)
    if False and True:
        555
        598
        _dead_6185 = 890
    return total

def _бТцΗΟСΛΝτ():
    value = 578516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICe0SUs9+J5QHza5n0WBHBIGsmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 97 * 39 < 0:
        pass
        869
    return total

def _ΞΥπιΦтЬЦЕкЫξΡσΥЪ():
    value = 368363
    text = __import__('base64').b64decode('ZGtxQVBlbGlwMnJVdFRta2R3VGw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        107
        _dead_3550 = 586
    return total

def _νЗАПυмнΑσΔψ():
    value = 877569
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CX7xZEQq2/pQDyiw4QecBgs88kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖвеФΑΖцΛΕМωыцΕФ():
    if 86 * 13 < 0:
        620
        _dead_6798 = 767
    value = 100701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHjRRVdty6oQHi7xmFCpEx0a20Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πвеρхγπБΒжχЫθй():
    value = 793322
    text = __import__('base64').b64decode('dDBWUVJJcGhMQVh5eVVXTlB0dHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑξηδгзызΚΛξΛЧΝП():
    value = 468153
    if False and True:
        _dead_2693 = 809
        _dead_6572 = 147
        _dead_9230 = 889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Egj3T10o+J4pMCauwQS4EBQsyj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιРΥРРκδЗвяхОщДσР():
    if len('') > 0:
        pass
    value = 231147
    text = __import__('base64').b64decode('U0RGUzZaaHRERzNTSXBfYTM1clk=').decode('utf-8')
    if False and True:
        531
    total = value + len(text)
    return total

def _λμΞгψΤπφюаюΨ():
    value = 423910
    text = __import__('base64').b64decode('aDc1cjBmdkZPWEJyRXQ5SEhOTFE=').decode('utf-8')
    total = value + len(text)
    return total

def _лεаЖγρβπΠууΚ():
    value = 402916
    if 12 * 26 < 0:
        pass
        969
        _dead_4807 = 560
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQTQTAYX2YsoKSel/FfEPi0Hzn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        834
    return total

def _ЪыЖΒфэπтрΧυΘΕжωΟ():
    if len('') > 0:
        _dead_6976 = 949
        pass
        683
    value = 66944
    if False and True:
        _dead_1517 = 758
        682
    text = __import__('base64').b64decode('SUxqTFc4eVUzOG1LOXdkdlU3WGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ИщЯςсΙюλΑΖюяλφΤ():
    if False and True:
        _dead_2017 = 139
        639
    value = 105313
    if 86 * 21 < 0:
        _dead_6970 = 780
        1
    text = __import__('base64').b64decode('UHlKd3g1cGRkREpMV1gxTlJ3M2s=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2151 = 323
        _dead_4523 = 898
    return total

def _οφБωлЫЖΤΤюм():
    value = 734107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExfQQ25vzvkkFVaR5myWHT0B4D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йвБМлеχЬАэοЛσЬрξ():
    value = 360424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISfOWwYM8qwWMjym+UeBBTAs82w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еюПлиэεЯДζνя():
    value = 573471
    text = __import__('base64').b64decode('Y1FZVXRlQWtaX0dkXzczRG1lSTI=').decode('utf-8')
    total = value + len(text)
    return total

def _НχНζФтнрвνМбЭψп():
    value = 140156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRzcY0Fo/aQWaia771GSEHQ14Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иЛΤΞеψЯνм():
    value = 888517
    if False and True:
        145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCDHZmYG24pWKliF5GGBGj0Js1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        612
        pass
        pass
    total = value + len(text)
    return total

def _υцнΞКиδωыЦΤГπ():
    value = 297947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAvGXFcezJwmaSSo7FmYJRoMs34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙЖΙэκсМΦ():
    if False and True:
        _dead_6117 = 910
        626
        _dead_7215 = 216
    value = 324648
    text = __import__('base64').b64decode('WExucWlVRFhzcnFFUXo5eGs3YXo=').decode('utf-8')
    if False and True:
        330
    total = value + len(text)
    return total

def _ОшΙΖхРТрдρΞλεΥюк():
    if 91 * 7 < 0:
        862
    value = 863511
    text = __import__('base64').b64decode('RVhUaFBwcG5vWnl6VDZLT2lqNkg=').decode('utf-8')
    total = value + len(text)
    if 8 * 1 < 0:
        _dead_9535 = 233
        _dead_6706 = 133
        126
    return total

def _ΞλΛимгКЙЛΟνυюИκ():
    if 5 * 71 < 0:
        _dead_1733 = 194
        _dead_7849 = 574
    value = 210103
    text = __import__('base64').b64decode('RmllN3lRSkY4WmlDZUt6Z0k2MEo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9144 = 65
        882
        539
    return total

def _МкαнЧτйΩ():
    value = 162296
    text = __import__('base64').b64decode('ZzdTTkNXY05Lbl9DUGdudVk0aDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ксЩФΜшΝйσλчΟΕЧΕΞ():
    value = 666295
    text = __import__('base64').b64decode('TV9IcXBZYjk3Tmk1a1JvVHl3d0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕτпоΦΖяκκКвВΒЦ():
    if len('') > 0:
        _dead_9068 = 465
    value = 633719
    if len('') > 0:
        pass
        _dead_1100 = 209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS3+ewgrzZwALlmWwQ6GZx154X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        868
    return total

def _ФШЬΨζδτС():
    value = 640546
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('aWZTaU1NZDllUVlTaGhwZUU1cHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙχΘОΗεβуΡπдκэ():
    if len('') > 0:
        304
        _dead_1447 = 15
        pass
    value = 868526
    if len('') > 0:
        _dead_6881 = 261
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NALQUVk2zY8hIjycnUy1HxIc42c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΚсεядтЖэУГεΞПяъς():
    value = 677039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX7pXHgXrKE1aAaix3eWIxIszz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 100 * 38 < 0:
        pass
        289
        55
    return total

def _ΩαаДмЧЭτΚΚΓ():
    value = 218365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3z8awMIqoI1HR3yxl2aPggV8jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОωνВАйЩбΙтчλаζκ():
    value = 116430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwjdR3Qyzq0xMCuO6kGTPX064j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦννщΔΒДΦЛбБьАЪΞЮ():
    value = 305521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ch/mb3IMqpsaahi17nuZFiZ9/X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        530
        _dead_1990 = 866
    total = value + len(text)
    return total

def _ΒбАцЬξΥвΞИэГ():
    value = 142891
    if False and True:
        _dead_1798 = 928
        pass
    text = __import__('base64').b64decode('S255bHRLRjJpZGgwZmJhOFBKM24=').decode('utf-8')
    total = value + len(text)
    return total

def _ьξтАεшоΡτΙμчуЖψΝ():
    if 16 * 26 < 0:
        766
        _dead_7403 = 923
        _dead_5956 = 718
    value = 132669
    text = __import__('base64').b64decode('R013SFdzUzVZSV9pUGQyZ2tDU04=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮδНтОοΦιЕэХτζψ():
    value = 744445
    text = __import__('base64').b64decode('Vks2RUtXaGc5MVRDendRN0hZdm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕВьЩдДχτЮΥλΡΞе():
    value = 538901
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBrzXms65IcKaQqkmUPHFgx5y2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΩςтвρΨΣВΗиπАςδ():
    value = 617069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECH1Y1gS040EFgWI6XzDPS54wHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗЭΒщΗΦиοΒчЪ():
    value = 59543
    text = __import__('base64').b64decode('Sml0WmN3Tmh5Vm9YTXE5anZFYUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЪμΕоЙΧАФξа():
    value = 553470
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjjzSEcPq4tWaDez4kCoBiB4t0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2256 = 699
        pass
    return total

def _ΔШΦΩςΘυзψΜξЧξоЙγ():
    value = 712833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KivTN1ga0IUBbAGzmGmlLgwQtF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        456
        pass
    total = value + len(text)
    if 17 * 79 < 0:
        pass
    return total

def _яΡιъεВФιлЬБΨя():
    value = 974472
    text = __import__('base64').b64decode('aFFOU1hWcVQydG5XTF9lSkMwN3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝααΖшфмИοЪυ():
    value = 934575
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J37Hb2E+roc6CDCV/HGIETAItWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йЧΦΛНиЕВпς():
    value = 663968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAm3QFxqxIo3E126xwfCIzYl/VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        561
    total = value + len(text)
    return total

def _ΠΥИςζЧζЦ():
    value = 511490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQrjSQkq/50tNFuk+F++ZgsqtFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        403
        pass
    total = value + len(text)
    return total

def _ΡчфОΞаЙθ():
    value = 32930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSfJNgg68/lVPReB2AWaIAoA3H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        298
    total = value + len(text)
    return total

def _еΦфЩΛΦγлЦъИαц():
    value = 327896
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByX9UX84r5IzDAWq8U6BIAYZ1l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_3675 = 466
    total = value + len(text)
    if len('') > 0:
        348
        pass
        _dead_4431 = 778
    return total

def _ЖΞТнфλшσЖьΙМдΩ():
    value = 574044
    text = __import__('base64').b64decode('aWpiRjZ6d2R0dko4OWJJb1VVTEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ζфЩхЙдτьτκлΥψΩеЭ():
    if len('') > 0:
        960
        430
        pass
    value = 5816
    text = __import__('base64').b64decode('cHBqUUJLdDJ5U3BCd0NpeHJvRFk=').decode('utf-8')
    if len('') > 0:
        537
        _dead_2078 = 501
    total = value + len(text)
    if False and True:
        520
        pass
    return total

def _ςδДρЭςюИΚθΒΙШТ():
    value = 748148
    text = __import__('base64').b64decode('ZWNKV1JuclJtVkgxRGQyRlp6TUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭпτбсΞνκГЧσъ():
    if False and True:
        _dead_1711 = 369
    value = 640267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX7RYlsg6KMLLDCH0H2bPggd7Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_8872 = 165
    total = value + len(text)
    return total

def _лισиЫΩΑеμЬРΕЮ():
    value = 150778
    if 77 * 59 < 0:
        88
        pass
    text = __import__('base64').b64decode('djFfaXdpRFBDVFg2OUJad3N5ZHU=').decode('utf-8')
    if len('') > 0:
        _dead_9969 = 98
        440
        pass
    total = value + len(text)
    return total

def _МΔΝАΚмВνδλβТы():
    value = 743730
    if False and True:
        pass
        _dead_2287 = 152
        192
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCDGbWUppqxTHTmNnl+cYHMmzTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        742
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3967 = 244
    return total

def _эуΥВΓΧΝлαаХЬЧ():
    value = 689343
    text = __import__('base64').b64decode('Z18xMnVRRG1HUGhFWTV4bmlQVjI=').decode('utf-8')
    if 57 * 45 < 0:
        733
    total = value + len(text)
    return total

def _вτΑЫβВЖΗΦ():
    value = 347503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jg3+THQt/4MOL1ipxX/JAA42zUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цвИΚΛξЖЧМιсЧΦ():
    value = 968759
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ey7edmgP+bwNawqlzw+ZYCgc8l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΠощυУЯЬМИЙтΗΕΠ():
    value = 334323
    text = __import__('base64').b64decode('RWhKZDhPNGh2ekd6M3BzNFVuajI=').decode('utf-8')
    total = value + len(text)
    return total

def _λΘΛΦΙэΗφэσβу():
    value = 46089
    text = __import__('base64').b64decode('aGg4bk4xTHdmcUZ3WFlnX3hPQk4=').decode('utf-8')
    total = value + len(text)
    return total

def _κЯъЩАХЧьМφвρш():
    value = 162417
    if len('') > 0:
        473
        pass
    text = __import__('base64').b64decode('WDJ5QVk1YmRYWGtPZUNPQ3NadHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _МгъαГсΞбχΣЧТψ():
    value = 981960
    text = __import__('base64').b64decode('eTF1X3Njb202S2RhU1E1enk4Mnk=').decode('utf-8')
    total = value + len(text)
    if 70 * 11 < 0:
        pass
        pass
    return total

def _пΥбпςМсДψεлβъ():
    value = 951037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyLFaXMvqYcSGy6o0VHDGTIVtjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чηЕьПфΤρΑиΤτЫΝ():
    if len('') > 0:
        pass
        pass
        _dead_2260 = 473
    value = 629852
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HXbhTW49yrFaGQf2yn6VOj8+xmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨФΩеΖΘξИе():
    if len('') > 0:
        _dead_2463 = 896
        pass
    value = 13613
    text = __import__('base64').b64decode('UFJaU0dIMmVaUHhaQzhQM3NnNVI=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4948 = 233
    total = value + len(text)
    if 32 * 7 < 0:
        413
    return total

def _оВьΔψΓΜДς():
    value = 483836
    text = __import__('base64').b64decode('RHdva3ZBX1FoZDM2NEpmaTRHWlY=').decode('utf-8')
    if False and True:
        890
        _dead_6910 = 451
    total = value + len(text)
    return total

def _ρΘςльΦЭЖЪоσщΜТЛφ():
    if len('') > 0:
        52
        654
        _dead_1535 = 726
    value = 871486
    if False and True:
        3
        970
    text = __import__('base64').b64decode('ZVluaGY4dlZCRWV0SW5RTE9sbVE=').decode('utf-8')
    if False and True:
        pass
        _dead_5495 = 807
        _dead_3216 = 483
    total = value + len(text)
    return total

def _СМΠБлωπжлκТт():
    value = 899883
    if len('') > 0:
        _dead_6737 = 176
    text = __import__('base64').b64decode('T3JyUDRHdmNVbGNDc0xLdmQ2akE=').decode('utf-8')
    if 89 * 58 < 0:
        656
        pass
    total = value + len(text)
    return total

def _эαЖχгФςэФъιΨИЛы():
    value = 29556
    if 29 * 91 < 0:
        113
        259
        379
    text = __import__('base64').b64decode('Y3ZlelU4VVIyWWlUaXoyNGVldFI=').decode('utf-8')
    total = value + len(text)
    return total

def _аьХчΜψВПιчзбЧ():
    value = 958436
    if 22 * 47 < 0:
        _dead_3547 = 847
        500
        _dead_4511 = 39
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgnFWFADyK4RAzyixk7JN3Y670o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ркЮэφфСВη():
    value = 3369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHjuSmEA2oM5Ahf0xHu2DgMu0ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 44 < 0:
        pass
        pass
        pass
    return total

def _ЩкΘМТЮΡаΕсСεрС():
    value = 250172
    text = __import__('base64').b64decode('VzJBVG5aMW5sanViYkd2OFFieXE=').decode('utf-8')
    if False and True:
        _dead_5988 = 212
    total = value + len(text)
    return total

def _ΖЭΛλκΧΜωЪυΤ():
    value = 555791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACmzO3lr9v9QIzn3wE7FNi0nz2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХηюгдчгмМ():
    value = 595128
    if 9 * 49 < 0:
        215
    text = __import__('base64').b64decode('bFE2dWtPUHF5N3h5dEtBTVlETTA=').decode('utf-8')
    total = value + len(text)
    return total

def _иЬЩМοыэδзлфЧЫΝГХ():
    value = 490446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAayPgcX+pAxHTukxWKkJQY40kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        824
        pass
    total = value + len(text)
    return total

def _εХΩτΦыюσагδхХ():
    value = 792313
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dy3TOlIw3/0NMD+wy0aXNix29lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞЛЖЙПαъσьонΓы():
    value = 676341
    if 94 * 84 < 0:
        838
        981
    text = __import__('base64').b64decode('YUMzNk9BQkxSdmFLYTRFSWFPQVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ςбЛδшΓЪβΕκΓζд():
    value = 538128
    text = __import__('base64').b64decode('ZHVrcndLc2c2VUxKZFRVMHZkVWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧьНвЗΨζдмТПυЫφТ():
    if 78 * 23 < 0:
        822
        _dead_9261 = 918
    value = 17260
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCvzV24K0LgyFiT38kCKLRAB12s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2095 = 524
    return total

def _ζУγЫπΧΩШψгΚλЭ():
    value = 794896
    text = __import__('base64').b64decode('UFBuUWcza2dOUFBNT3FWREY0NzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭЖцХмЗПΛ():
    value = 784497
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzvDfnwS96waLleZxnWmPxUj1T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 28 < 0:
        _dead_7672 = 333
        pass
        pass
    total = value + len(text)
    return total

def _χШΤβьЩφжΤξβΓΑΚНА():
    value = 309526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA3pan0SqvgkLimP4XilG3E50EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('cg==').decode('utf-8'))
if 29 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 32 * 24 < 0:
    pass