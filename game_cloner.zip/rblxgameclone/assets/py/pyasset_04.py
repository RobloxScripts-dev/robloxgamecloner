#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΙΑΧΕЛйрИ():
    value = 960623
    text = __import__('base64').b64decode('WVg5bDl1Qkxlckh1T1l1MjZxVW4=').decode('utf-8')
    total = value + len(text)
    return total

def _υχбιαιμК():
    if 61 * 13 < 0:
        472
        _dead_7303 = 912
    value = 431600
    if False and True:
        _dead_2463 = 198
        533
        _dead_9792 = 332
    text = __import__('base64').b64decode('cEMwTjlVeVVtNnlBUUdlcnJnYnA=').decode('utf-8')
    if 76 * 99 < 0:
        _dead_9073 = 839
        _dead_1976 = 368
    total = value + len(text)
    return total

def _ъЪЗШΧБхфОΓεУхηуΛ():
    if len('') > 0:
        _dead_4520 = 987
        _dead_8661 = 62
    value = 117687
    text = __import__('base64').b64decode('cVFrRWh6VWRVbUliVlBXUTdBR0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ъΥДЩФТЪЙμъΣ():
    if False and True:
        pass
        _dead_8164 = 653
        442
    value = 544126
    if False and True:
        pass
    text = __import__('base64').b64decode('YnhpcXdlemJxWFdielRES1FpR3M=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        581
        916
    return total

def _АσЫАзΕПΘςк():
    value = 367089
    if 11 * 64 < 0:
        pass
        601
        963
    text = __import__('base64').b64decode('S2lQQm40ZDJYY1p4WlJ6Y2xzSUk=').decode('utf-8')
    total = value + len(text)
    return total

def _кυВэМкΜγВαижΚэ():
    if 11 * 71 < 0:
        576
        240
    value = 540102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HC7USEss+JIKKCyNmny3PnQMwGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 27 * 69 < 0:
        531
        _dead_9113 = 559
    return total

def _ЖοΗэΑλΠΤЗЮβпювΞ():
    value = 820760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fnm3OWEr7v5QYh6w7Fm5LSwpyjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бИзБΘЕОσΟН():
    value = 280444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSPXTVMezo0rYhqc6QOeHTF+4Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НИΓΜΦаΖъΝьБтПΧΛΘ():
    if False and True:
        pass
        811
        685
    value = 132894
    text = __import__('base64').b64decode('SVZSdXBQS19nZ01kUWlGZGxSSEg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_1470 = 836
        _dead_3881 = 37
        979
    return total

def _ЗιηνщЗτΞσδЫщС():
    value = 646332
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kg3LfwUL1PwGKjiy+nHBbQd5yzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨυЬИπБτЛη():
    value = 616917
    text = __import__('base64').b64decode('ZjVSUWRhVjlDdEk5ZWJncU85TUE=').decode('utf-8')
    total = value + len(text)
    return total

def _πфΝτΘИβΘубюЩ():
    value = 608916
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBe2QwEwzr1RCwiP2Qa5GxR67HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еσвωюΤюаΣζοБДς():
    value = 156542
    text = __import__('base64').b64decode('WlpUcXZSUUszc1NIRFV4dEREUkQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        138
        _dead_8757 = 974
    return total

def _κΚъΞщΡлβΤумδ():
    if len('') > 0:
        695
        917
        _dead_7338 = 838
    value = 357899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iw7yWV8R/ZAqb1eW52a7Pw0Mwko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1540 = 524
    total = value + len(text)
    return total

def _ζйρΦжЦяЖдгдЭ():
    value = 442804
    text = __import__('base64').b64decode('TjlTNTJ0WkFfZElWODhLT3ZhQjI=').decode('utf-8')
    total = value + len(text)
    return total

def _юφэШΠγΕнηβфЪ():
    value = 78040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwLeRgc2258sEQ2E5gK/Bxp4smg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЮФψФΦБфямюΥΣ():
    if 81 * 91 < 0:
        pass
        pass
    value = 665801
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjbpTFM4yLlbbBaI+XPEMTAF0UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 93 < 0:
        _dead_4726 = 24
    total = value + len(text)
    if 85 * 36 < 0:
        pass
        pass
    return total

def _ЕПФщИСΝЧлЯРтб():
    if False and True:
        pass
        780
        528
    value = 122454
    text = __import__('base64').b64decode('UXhKU0JGT3hRelpES19yNTBhMkw=').decode('utf-8')
    if 84 * 26 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_3570 = 342
    return total

def _ЯοΩΦπΚμΣΨ():
    value = 439572
    if 55 * 66 < 0:
        _dead_5951 = 507
        _dead_8891 = 242
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DibpVkUb2pAhEAqq6nKpOAwK608='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 75 * 90 < 0:
        151
        _dead_2215 = 750
    total = value + len(text)
    return total

def _чВЗτПЙΥя():
    value = 36312
    text = __import__('base64').b64decode('djlZbFJ3V0V6dTNzU3V6dHFZNlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑοМъΖΥуБяοздχδ():
    if False and True:
        pass
        _dead_4672 = 460
        _dead_8416 = 977
    value = 566663
    if 92 * 93 < 0:
        629
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3/qPFoL9aEEPjmPyXOfNz8uyGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 92 * 28 < 0:
        _dead_6353 = 292
        _dead_7438 = 647
        _dead_2034 = 671
    total = value + len(text)
    if False and True:
        _dead_7351 = 904
        pass
        424
    return total

def _ИΕБЖЪыЪНя():
    value = 122600
    if 10 * 46 < 0:
        41
        685
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXjDZHMgqb4PPg2Z3We0EDIuwkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 3 * 71 < 0:
        pass
    return total

def _ЬЭΥΦыΞвЛэΦОδГ():
    value = 83342
    text = __import__('base64').b64decode('eXVxbEJtTklWeU54WXZfYWlmNDM=').decode('utf-8')
    if 51 * 38 < 0:
        259
    total = value + len(text)
    return total

def _ΞшыψΘΕβпδЛξжσиаο():
    if 79 * 73 < 0:
        946
        _dead_1111 = 947
    value = 226160
    text = __import__('base64').b64decode('S1VNWDQxRFV0dkFWMjdpU1REaFM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6129 = 34
        pass
        _dead_6914 = 45
    return total

def _ИЧωЕΞΦφφ():
    value = 981053
    text = __import__('base64').b64decode('ck1BRzFSOEx3UlBweDRkN1BaZHo=').decode('utf-8')
    total = value + len(text)
    return total

def _АΘχиЯΨлйθмв():
    value = 177685
    if False and True:
        pass
    text = __import__('base64').b64decode('TzlPcEdNNFdfMjdUaTlhbTdWeXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΤγςΥэуΠхκΗΚμрм():
    value = 69144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnnWOWU1zYQLMjmUy1qWCxc7w2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        352
        668
    return total

def _ЬεсЦΜБΔсΓИ():
    value = 796261
    text = __import__('base64').b64decode('aEhhSkpxRWowNTVlQ0pzakFJMkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞΒснТХτβΣцΤηЫθΗ():
    if False and True:
        _dead_4109 = 968
        pass
        _dead_3509 = 972
    value = 871912
    text = __import__('base64').b64decode('dFBtNFVhWjEyNW9vMVpEbV9ISHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑОХПΡЙЗГГещ():
    value = 369219
    text = __import__('base64').b64decode('cURPd091MnpEUktldTFqclNTdFY=').decode('utf-8')
    total = value + len(text)
    return total

def _θυютвэρψС():
    value = 77734
    if len('') > 0:
        pass
        _dead_9531 = 562
    text = __import__('base64').b64decode('WUU5ZTA4UzcwX3liYzBVRnd6cjE=').decode('utf-8')
    total = value + len(text)
    return total

def _гЗъΚοжΜЛМшбΥδ():
    value = 565642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In3DPGM8yIoTHQKy+1OdMQt8tHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эЩΤрθРΠτςх():
    value = 408437
    text = __import__('base64').b64decode('RXBwNHNyUFhFUkpZdWVEdXFCUHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤχβΜΒχжнΗ():
    value = 910448
    text = __import__('base64').b64decode('VWdMdk1XbElQMHdzNVdVY3FQaEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬтτдσХЯχдΙв():
    value = 895242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACntUQQS+oYvYj+E+2WzCwZ2vWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3598 = 286
    total = value + len(text)
    return total

def _бчОΣБчрΗЦф():
    value = 765551
    if len('') > 0:
        _dead_3233 = 649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCLRQWkB7oAPN1usm1y/HAJ/s2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        829
    return total

def _ЬΑЧуαωэЗЭЦ():
    value = 988862
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTbDN2EB9qwIHCbx5lGyPQ8r1nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МγβΝΦГΕЦΕмιгΗΟ():
    value = 544341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FifpUWIO1v5QCgCSw3mZG3At4GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩχЩШКждТрττη():
    if False and True:
        34
        _dead_6702 = 65
        _dead_7058 = 506
    value = 377350
    text = __import__('base64').b64decode('QlZMemdBRnh5Wm9qSGVHZ0xua2E=').decode('utf-8')
    total = value + len(text)
    return total

def _νωчοΡДДу():
    value = 775620
    text = __import__('base64').b64decode('aG13V3c4NnpDeEhTUW9wX2UxMjk=').decode('utf-8')
    total = value + len(text)
    return total

def _мρπсΞЙΓΤьйνЯШЬ():
    if False and True:
        pass
        _dead_9128 = 716
    value = 966828
    text = __import__('base64').b64decode('eUJ5SWFHQXNoQ01yazNhR3NGWWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ξпζΒэЦдГ():
    value = 91968
    text = __import__('base64').b64decode('UjdJcHg1ampBTFE4eGNvZDdFQWQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        404
    return total

def _ιТρΞυИσφΛξ():
    value = 629163
    text = __import__('base64').b64decode('a1dwd3JJTmZJNU9aaEVhS0IxclA=').decode('utf-8')
    total = value + len(text)
    return total

def _γзΨдТУвКκψχюμμаЦ():
    value = 529813
    text = __import__('base64').b64decode('aHdYeE5EZTQ0UE96T25iMFhZMTc=').decode('utf-8')
    total = value + len(text)
    return total

def _γηςжяВΘТГЖ():
    value = 254330
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDeyPXAgp/02AyOJ2neiBBcc5Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 72 * 91 < 0:
        _dead_1948 = 538
    return total

def _ипνздщΙюжщα():
    value = 708079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JznlW3UUxqo2aTCnzmG2HSYL1mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωбЪΓψФΗαСЮΛЙ():
    value = 678213
    text = __import__('base64').b64decode('Y2NQaktwR2pJa0ZCN3pnbzRKSE8=').decode('utf-8')
    total = value + len(text)
    return total

def _еΘьγъСΖХηΔШΒЭЖΙ():
    value = 267625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ES3cS30uyIMFOQ2c90zCDA8j7nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΚЮΖЕУТЮЫ():
    value = 35464
    text = __import__('base64').b64decode('UEVtXzVLR3drOUExS0RiendMWnc=').decode('utf-8')
    total = value + len(text)
    return total

def _υНΧВцЬмЫоНΨψ():
    value = 420787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQviQlQwrocSPBz2/FeAZg0n1VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3045 = 657
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1597 = 818
        _dead_3153 = 786
    return total

def _ΠΣγΓКθωЦЦΧ():
    value = 890443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KD/BQl06+Ls5azeyywGHDnML6Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΥЭζйгфАΑШКБ():
    value = 645766
    text = __import__('base64').b64decode('V0RMM2Z5NXdwOGxTaHh1VV9ycWk=').decode('utf-8')
    total = value + len(text)
    return total

def _РсЯΟαЬΜφдδ():
    value = 392371
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASzLY0Ju0I0rN16N2UKGACw5/j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 89 * 71 < 0:
        601
        pass
    total = value + len(text)
    return total

def _κιυχΤжυΦмΗΗμРκМФ():
    if False and True:
        444
        pass
        444
    value = 708758
    text = __import__('base64').b64decode('VGEzemVXZ1VEMjdaY0lpTDBXWmU=').decode('utf-8')
    total = value + len(text)
    return total

def _щьдядиΜнпτΩнЩΘ():
    value = 906172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgngbUZt7bIJAze75GWJLRQ39jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эХеΣλοСъ():
    value = 324247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah69Z1MI+JlWNVeO4XCdFxw7wEI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кψΑбъЩηЪрΦΩΘοяПπ():
    value = 389346
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyfMN3oB7qoGBSmX0EWBAzwnxlE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вфТУмВТκΑНЪйηξθе():
    value = 631201
    text = __import__('base64').b64decode('cTlfaTRLNjJtbUdlNzRDNkR0R1o=').decode('utf-8')
    total = value + len(text)
    if 94 * 60 < 0:
        _dead_3363 = 192
        645
        985
    return total

def _ηπАΠвψΕтΓнΟЗΚλ():
    value = 222036
    text = __import__('base64').b64decode('RUkzbHNTRFpQVDhmVkM3bEhoMmw=').decode('utf-8')
    total = value + len(text)
    return total

def _тκЛЦТВΗвΞζλчЯЙД():
    value = 958971
    text = __import__('base64').b64decode('TklORFVUMlVhSjMxT2pibkl5c2I=').decode('utf-8')
    total = value + len(text)
    return total

def _κшЕΞЧЪЧгРΤЙ():
    value = 206956
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jjn9Z1cG86YIKDuG8FKVOXM32zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3829 = 705
    return total

def _ζфεЦЯΝЭцΦУеНълΜ():
    value = 91900
    text = __import__('base64').b64decode('dEJuejFXbHFVN1ZmSzRkRmJxYTY=').decode('utf-8')
    total = value + len(text)
    return total

def _мΜМЛηчПлΛЗн():
    if False and True:
        pass
        _dead_3351 = 478
    value = 479524
    text = __import__('base64').b64decode('aElBM01GbU8xRmlncWQzU3BSZDQ=').decode('utf-8')
    total = value + len(text)
    if 27 * 19 < 0:
        _dead_7720 = 532
    return total

def _ρσВЯςηЕВΙυиМ():
    value = 985130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzXsZkQV9LgwCif03w+VAAQp12M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        850
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _МнΦΨЭсфИзМσМ():
    value = 517462
    text = __import__('base64').b64decode('eTg0Nk5jSDBkZUlLRnd5VThZNEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ОοКДΔЬбУЭ():
    value = 852354
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTXOOXts84w3HSi540CXInQqz3c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΨНШΗнθэ():
    value = 658727
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQi3S1ch7KQwCVmynFPIEiZ5yEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λξΣσиαрЬσσШйωаΝЭ():
    value = 735200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HX22YWUQpq8IOxawzHu9bHQ3tVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝΦσζδΛΤΘ():
    value = 762217
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHm3P1Uw95c7HTai0nOBPCE59nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘнъΝрξЯФм():
    value = 164283
    if len('') > 0:
        534
        _dead_2629 = 992
        _dead_6394 = 190
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3q9akBq7Zs0ag2M2gbCN3x5vGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΜяαδпδχρдЖЪЙР():
    value = 953121
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDz2fGht064JLwigmmfBMSwr7Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _кМЦЩСμиΩζ():
    value = 208851
    text = __import__('base64').b64decode('bUhyTl84NTZsWHdWSDJkVDRzbng=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪсДΗΘНψРТ():
    if 89 * 79 < 0:
        431
    value = 965480
    if len('') > 0:
        _dead_2525 = 324
        908
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCyzP1ho570sYy6bm1eJZRwK8nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣτКоκнзЛЙч():
    value = 3535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AivcaWUV34JRCRaTwE6HDnwuskk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вхДχΩγнΑυΘςБΘηюβ():
    value = 972339
    text = __import__('base64').b64decode('VVdQaFVZaW11OEVHaXB6RGZCN1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЗЭλЫπПъэΜЭΙζ():
    value = 598705
    if len('') > 0:
        _dead_5676 = 187
        _dead_7039 = 801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pz/wel4655obLAWIx12hACQotWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6360 = 686
    total = value + len(text)
    if len('') > 0:
        _dead_5931 = 232
    return total

def _СьσχΗЯМξιъρЗхО():
    value = 88670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxXSSkUa+rIZHyiZ4VHJBHUEtkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘςρмЬвШЖβйΩσЯΛжΒ():
    if len('') > 0:
        pass
    value = 615078
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCayemEU0romGRWzwAWSOSM96Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛΩηхζФЧλΛΞΚ():
    value = 494876
    text = __import__('base64').b64decode('a3hYYmNWOEdwX2tRdU5pRVJ2bEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡИσШдΞщы():
    value = 9753
    text = __import__('base64').b64decode('T3lqZUYwcDBQQmU1ajBENHlfV0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЯрмкспгΣоь():
    value = 790622
    text = __import__('base64').b64decode('cUxUNE9rMGk4TU1KOVQ4a0ZGS3A=').decode('utf-8')
    if len('') > 0:
        227
        _dead_5469 = 90
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _шστΙЛСτд():
    value = 692714
    text = __import__('base64').b64decode('RFplOTNMaThxOXAxN1B6Ynp3TVU=').decode('utf-8')
    total = value + len(text)
    return total

def _πΝуЩюУαРЯΑ():
    value = 195926
    if False and True:
        pass
        _dead_5873 = 710
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FB+3d1ov3ZBRGQG5336gO3Et81o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΝЕΦКκΤаθСτΔρжэи():
    value = 20196
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jwz9OXkB7okIbivym0DEGSEKt18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΕдюηωЩИЦΛЙ():
    value = 12367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwrIS2Jg2fsLBQ6knUCnYSMk3jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΡмΑТзщЖ():
    value = 463218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQm8XVY19KcuHTew/06+ZycKwl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЮрΤвςУδΟψψРлр():
    value = 103293
    if len('') > 0:
        637
        163
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQTTfwdqx4E0Yzf7xXKFPwp/22U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьТуςΥмΛИИФ():
    value = 747436
    text = __import__('base64').b64decode('R1Z2X0NsNEtxT1hOam5vNEg3Y3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓРΑψьβгιУΠл():
    value = 136237
    text = __import__('base64').b64decode('dXZOcjZ1Q3lyVkJQTGpaR2c2T3o=').decode('utf-8')
    total = value + len(text)
    return total

def _аφЬтΙЧуξωςЪИ():
    if 61 * 83 < 0:
        _dead_8961 = 802
        _dead_9305 = 831
    value = 515511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjfDX1cj6aIsKQit4FLFYXM68Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аγЗтσОαΙΥв():
    value = 517104
    if False and True:
        pass
        723
    text = __import__('base64').b64decode('QmxZbHNuQUlBbjFFT3pjeHZKTnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ъΑιдТЛιЗмχΤиЖ():
    value = 376389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgbmXF1vy7EVPzfxylK2Ig5473g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШХλймκΛΞДИЕыюб():
    value = 549498
    if 78 * 2 < 0:
        pass
        168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnjTOGEs96RXDzD2wn+/DhcixUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        200
        429
        pass
    return total

def _СЗИσяλρΖэышЖρэК():
    value = 942657
    if len('') > 0:
        478
    text = __import__('base64').b64decode('eTJ3MXBQMmt1YVFQeHViUTNualg=').decode('utf-8')
    if len('') > 0:
        362
        pass
        109
    total = value + len(text)
    return total

def _ЭνΤΘпςЖбР():
    value = 572416
    text = __import__('base64').b64decode('d1FYQXdDVkY5X2xaZGlfbmQxOU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗНЩιггΦэΗОεΧМΔжρ():
    value = 655001
    text = __import__('base64').b64decode('R2Ffal82dTVVdVlYWkhhMEZWV3o=').decode('utf-8')
    total = value + len(text)
    return total

def _еηюЙΝΞςΜΒгЫσΗ():
    value = 750367
    text = __import__('base64').b64decode('Y0hMUVpIS0d6UDh3TmJpVTU3bmQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΔьЬΗμчгοφςэ():
    value = 555279
    if len('') > 0:
        _dead_1836 = 209
        447
    text = __import__('base64').b64decode('eGhGSUhQNU5vNlZVc1JxYXFmbDc=').decode('utf-8')
    if len('') > 0:
        77
        985
    total = value + len(text)
    return total

def _ΔхТБбΩΥκДΦв():
    value = 358043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiHUWgIs/5EhEDCJzHfFEyZ5138='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭДξηΙЩПΗбУνξНЭш():
    value = 648748
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fiu2Zl0/9p5WC1ik72a2EwQ18mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛнмхеΡщΩСыиφ():
    value = 811425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQb8Zkg05rorGBasyU++Ihx5zGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝИбъιΩΔЦнΞУΓ():
    if len('') > 0:
        _dead_6137 = 791
        pass
        pass
    value = 146704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Djrsb3g78vArGFeM6k+ALBIO/G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΘψцςσαх():
    value = 812986
    text = __import__('base64').b64decode('Snd0Q1JzaHhobWZQcnpYcE5jelQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡχБΗЩΓШэΔσУЕΧйщ():
    value = 780833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHbsWFQbzpEga1fwzXq8FSYqxV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КμРΨгыфЗУсХΒэДφХ():
    if 28 * 62 < 0:
        103
    value = 968272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cjb+O3IS+oswCzaO52efMC8ozTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 29 < 0:
        262
        _dead_7624 = 464
    total = value + len(text)
    return total

def _оρτлδВщсйλЭπАφк():
    if 74 * 47 < 0:
        pass
        pass
        240
    value = 778836
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAb1XwcVzZArDVaPynqjBgE7tVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 95 * 81 < 0:
        pass
        139
    return total

def _ΛλсГЖъΜφРпβΨκΤД():
    if False and True:
        pass
    value = 788736
    if False and True:
        986
        pass
        325
    text = __import__('base64').b64decode('cVNyU3NnMXREY3lPSnZoUkY5NnY=').decode('utf-8')
    if 16 * 22 < 0:
        _dead_8514 = 618
    total = value + len(text)
    if len('') > 0:
        _dead_6394 = 487
    return total

def _дΣЕЕюпωюΑИЙ():
    if False and True:
        pass
        786
        _dead_1419 = 245
    value = 368676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAXpVlkM+JoPEh2K0lKnH3Iasnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 18 * 31 < 0:
        807
    total = value + len(text)
    return total

def _ТωВЬБΞЦιΙА():
    value = 325204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAD2TQEt6KUvNj+I7Ue6EAl2tj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        413
        _dead_9102 = 851
    return total

def _ΩУиηαПКΒГГЦΔ():
    value = 936750
    if len('') > 0:
        _dead_4395 = 814
        577
        _dead_2863 = 53
    text = __import__('base64').b64decode('UVY5RmE2aW81Q3pfeEw1b0lQVzI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _аΖНΣФΦΘφЛЛσн():
    if len('') > 0:
        758
        _dead_8337 = 443
        _dead_1587 = 135
    value = 911390
    text = __import__('base64').b64decode('UnZlWGg3T3VPYWM5ZHVDZnR1WTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()