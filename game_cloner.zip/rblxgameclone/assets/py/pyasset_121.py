#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _бΒмгΕΟзΑи():
    value = 794325
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiHJd3Ao/4MIAxqr/WSVBikAyDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠъИΕλУцДρОЫΡЪьТ():
    if len('') > 0:
        _dead_7573 = 259
        361
    value = 169466
    text = __import__('base64').b64decode('aGNKd1BQZlhTaW1XeFVRbU5qc0s=').decode('utf-8')
    total = value + len(text)
    return total

def _еζЩρсπεΞЛщΗΔ():
    if 85 * 52 < 0:
        pass
    value = 298898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnniW2cA64QLBRyb22zAHygs8FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        928
    total = value + len(text)
    return total

def _βгИфχЦΓшКы():
    value = 455394
    text = __import__('base64').b64decode('S2RFNlVNenhIVG5iSFY4ejRxRFc=').decode('utf-8')
    total = value + len(text)
    return total

def _сюкΒΩΘλψОτ():
    value = 224286
    text = __import__('base64').b64decode('TE1IdlVDS3drS3dMdlZKTHNYdmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨтΛΠξЯЮуЦтρ():
    value = 49088
    text = __import__('base64').b64decode('Q3FLNXBxWkdyd3o5eHpHUVpOUnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _МмЪоЙεдтчΨ():
    if 64 * 58 < 0:
        _dead_7874 = 851
    value = 824275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTzWQGE6zLwaLD2ynUyaJgMB4Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4886 = 473
    total = value + len(text)
    return total

def _ΖΒЕйΓΔΚЮуЦщ():
    value = 412811
    text = __import__('base64').b64decode('c3ZGWDBDUEh2Q3pmNFF3V2hadlo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        903
    return total

def _ΧаΠΑΧαγЕж():
    value = 134350
    text = __import__('base64').b64decode('dmJaUkF5aFZTSmtqcHNyZHo3a2Q=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ЭйςΑдЦσμфЕξ():
    value = 364616
    text = __import__('base64').b64decode('VTJyeGZtMllSRWlaTGIwR1pXU04=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _АсΦтМΖчςγЭъмΤЖдΙ():
    value = 893507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fia8XGQb2KAWDzWO6VK6JzUCzn8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эоΒΕЛмшйЫБу():
    value = 736036
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DA7iOGUUy7AOHT61z2DCAyso/V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣТжФΖъЪюх():
    value = 249776
    text = __import__('base64').b64decode('dGthVXMyRV9qWkFCZXJ4azNWZ0Y=').decode('utf-8')
    if len('') > 0:
        981
        pass
    total = value + len(text)
    if False and True:
        186
    return total

def _ЭφοεΓγЫπщыΜмшпΝ():
    value = 947316
    text = __import__('base64').b64decode('UUxpcWpqSmIxWWVObG1vM3dPT3c=').decode('utf-8')
    total = value + len(text)
    return total

def _СцωОΡυсюБнэЧβοПТ():
    value = 389773
    text = __import__('base64').b64decode('Tkw4NGN0V3Y4b0FEelB5b3c5Mmk=').decode('utf-8')
    total = value + len(text)
    return total

def _δΡΨΝΦΘτщБслππχщЬ():
    value = 176529
    if False and True:
        _dead_9921 = 274
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxzdQEAL3KY5EQmZ5wXJAS4W0F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛТЯρрΧεйμФξеУЧ():
    value = 417033
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lyn9PXQvr/AZDleN3V7CAxEq72Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 10 * 50 < 0:
        934
    return total

def _эАелВЙΦΖЭйНЕη():
    value = 336570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICK2OFIB5IkzEwPz/mWdLB138lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БβδяЬΧυНъьПΒЛ():
    value = 513603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBe8TFoa7JFabA6F2HWWNRog3WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 45 * 46 < 0:
        _dead_4196 = 150
    total = value + len(text)
    return total

def _ΤхΛюχЭγμΣХяЯΜыΠ():
    value = 267711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHjPXEMexoYHKgqTxQ+4NTAg9Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νчσЙΛйУЯΡИΝБХ():
    value = 512814
    if 32 * 99 < 0:
        _dead_9614 = 962
        _dead_8648 = 143
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTXWPFdpxoswKVqH/3+6GioL7Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 85 * 36 < 0:
        _dead_9474 = 835
        _dead_1139 = 335
    return total

def _ψρНΑнЩЗξргвГвушς():
    if len('') > 0:
        407
        pass
    value = 487077
    text = __import__('base64').b64decode('dGNNbWZvX0hKakd1WTFWMVQ5X1M=').decode('utf-8')
    total = value + len(text)
    return total

def _тθωΡαουеΣсЬυ():
    value = 298234
    text = __import__('base64').b64decode('d2xLNEViZDhtSGMzSnRDOXZ2SHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΗУСЪΨрПΞΑЩΙλΘеα():
    value = 542864
    if 80 * 53 < 0:
        83
    text = __import__('base64').b64decode('WlJqYjZNZndYQndVZE1iSUFyTHQ=').decode('utf-8')
    if False and True:
        400
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _κЛНыβΠΖΔХΣΒсКΧй():
    value = 633032
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhbGekUo7aYNGFv76my2GA034lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΘфУншΔουЙ():
    value = 855702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQS8alAD2L8SDyCG+06iIRAZ9Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЩфγσуηй():
    value = 187504
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhjmOlpoqoQJIxiz+HmpPj0Z3W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιЪυχЭРфНЩцΚФФт():
    value = 189497
    text = __import__('base64').b64decode('cm1IaF9naU1LeVM5UmhBV2ZHS2w=').decode('utf-8')
    total = value + len(text)
    return total

def _εσВГθΤγлРбΕ():
    if 28 * 78 < 0:
        _dead_4840 = 762
    value = 345077
    text = __import__('base64').b64decode('aXdYQjlXYnRBS0NvV1JoVXNLYmo=').decode('utf-8')
    total = value + len(text)
    return total

def _μэρЦΗчеθμжΘεЙЖζЙ():
    value = 738991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDy8Z1cR3Ps5HR2k+nCpOg191EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑУЮΙΨιГπδλЯБ():
    value = 369729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyHdT2Axr/grEg2l/2K2Gi4A0Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓщбЗфъТΩΞ():
    value = 895118
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjbMfAkM/5s2LSCN2GK+PHMk1WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        611
        858
    total = value + len(text)
    if False and True:
        pass
    return total

def _оΦХΜФЖюйьΤ():
    value = 473819
    text = __import__('base64').b64decode('ek9qRTg5bXdBSFJIc2Vuc0ZZY3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ιОтΥдДΔь():
    value = 811888
    text = __import__('base64').b64decode('ekJWOXgxa19lT2tEU0NjX2luVF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ωηΓιφчНωЗΚхδЪβα():
    if False and True:
        _dead_5277 = 902
    value = 468556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASm1dAkrzbkZAjWk4ECnDRYjtmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жВКОТЬζΧрΞнχν():
    value = 727521
    text = __import__('base64').b64decode('cXhWcE9YOGpvQVJEdGk0YjR0QTg=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        809
        _dead_1056 = 776
    return total

def _зΠεπΓνцΨтЭЩιы():
    if False and True:
        pass
        pass
        pass
    value = 375675
    if 80 * 80 < 0:
        155
    text = __import__('base64').b64decode('SGZlVWVPVkJ4QTRHcVpRM21idFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ДгχρΜСфЦн():
    value = 137755
    text = __import__('base64').b64decode('SGZFOTVMSW1pTU1YRGFnTElxdTg=').decode('utf-8')
    total = value + len(text)
    if 2 * 59 < 0:
        _dead_2140 = 612
        _dead_3647 = 866
    return total

def _мεЕцΡУαЮяЛЫЭЭ():
    value = 665850
    text = __import__('base64').b64decode('cERxbUhqUXVYc2ZRMEVMZ0hOTW8=').decode('utf-8')
    total = value + len(text)
    return total

def _шжχωИщЙρДРΤЪ():
    value = 181581
    if len('') > 0:
        959
        _dead_7601 = 533
        _dead_5430 = 333
    text = __import__('base64').b64decode('d0lOMGh5M0w5TnlCQmtHR3VQMVM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        76
    return total

def _ΙΣдΝЕжсΗΥн():
    value = 309470
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAn3Y0Np5oUBKgaI7WyoHzF570Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уМθмсПχβΗшЪΖΗΨ():
    if False and True:
        pass
    value = 133221
    text = __import__('base64').b64decode('WlFhaVhKSnFldkhnaXFKNlZ2b0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΦυωΛФЬΤм():
    value = 330949
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBv1d1scxpBQDV6E2lu3bDYH60A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йотЫθεЛшБΨ():
    if False and True:
        pass
        pass
        614
    value = 504070
    text = __import__('base64').b64decode('RmFNaEFMRXBGVnBsckF4c0RMVEM=').decode('utf-8')
    if len('') > 0:
        pass
        918
        pass
    total = value + len(text)
    return total

def _кТЙуьЭΓτΤΝ():
    if 13 * 48 < 0:
        pass
    value = 450798
    if False and True:
        pass
        497
    text = __import__('base64').b64decode('UUhKT1hudG5PZUYyMUJVcTNOelE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _γОπΛΥЪΞΥΣюрРБβЧ():
    value = 83065
    text = __import__('base64').b64decode('VnNmTWFYZ201bnFRMXRxMjUyZWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔоцЪσФТЕΠΔЕδ():
    value = 19221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mwr0ZQcU07Ioal6BmQGSYxUnvVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μдαфνСеξДоαθЫгм():
    if len('') > 0:
        pass
        200
        _dead_6463 = 642
    value = 598346
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy72ZGUop4MhbDWC8HmhJgIZ9Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 77 < 0:
        84
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЖρьΗΟХЮУΠβГЯ():
    if False and True:
        pass
    value = 380731
    text = __import__('base64').b64decode('R1N4RHQ5M0ZsbUIyaFVvRzI5ek8=').decode('utf-8')
    if 16 * 17 < 0:
        pass
        874
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_6791 = 718
        pass
        595
    return total

def _ЪуЫйАζΧΖΤΗйв():
    value = 220551
    text = __import__('base64').b64decode('eDVMdXZrRjZ4U1pIZVFBUkQ5OFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΛцооρОЯζ():
    value = 26673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyjAeX1srbIMKVuP/2WdZx856z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΟΑΠΙэктцΔθТЛэ():
    value = 292135
    text = __import__('base64').b64decode('aXBsbmV2Y2t2SW1yOWR1djFrNVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ξπΚτοЦзΤЗυΦΘХФФΒ():
    value = 607025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCXBOnxq1IUwOzeo0EfILjI27kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧУъοΞψΠюЕΟ():
    if False and True:
        670
    value = 39026
    text = __import__('base64').b64decode('SnBPbzZNX1A5ZEFvbm9la0xLNDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗИЖЗψιΩυΜАωΑяэ():
    value = 861092
    text = __import__('base64').b64decode('U2tfR0ROUmpUNGVsT2pGZ2JueUg=').decode('utf-8')
    total = value + len(text)
    return total

def _оАЙлФξΜνΩγПκΥ():
    if False and True:
        pass
    value = 690936
    if False and True:
        pass
        60
        912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EirnYUcW+YJUKAqtnlXHBzMj6Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3580 = 632
        pass
    return total

def _жΝΒмюШορЭсυζълт():
    value = 462861
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgLLR0g49Y8rEw2y5QembTM6tUw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑцЯβπлХж():
    value = 42756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NimzVlIKp75QNVqzmEWAORI8ymY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωμкΙшАμКщфзАлπЭ():
    value = 56599
    text = __import__('base64').b64decode('Tm1jRVVMUE1rVkFBXzNmcGlHUm4=').decode('utf-8')
    if 10 * 36 < 0:
        310
        pass
    total = value + len(text)
    return total

def _ххσδЪψΒФФклтΗЯγΕ():
    value = 826555
    text = __import__('base64').b64decode('U0NYS1BvRlpLajl4b3NTZzJLbWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ψοфбплЛΖлйзΔр():
    value = 55463
    text = __import__('base64').b64decode('WFZIVnd0NE1MYmxaU0xDb2lVOUw=').decode('utf-8')
    total = value + len(text)
    return total

def _ηОσэшсмΝζЖЫпз():
    value = 847048
    text = __import__('base64').b64decode('WXdIbDZiMWtFdnB0MDRzX3RNdUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩЖяббδТВΓΧπЮвЕХν():
    value = 946867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHy1ZHgDzqQhCFipzFWnYhY67T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хТиΩсψχΤδК():
    value = 153194
    if len('') > 0:
        _dead_4969 = 693
    text = __import__('base64').b64decode('bGs2RDNmM0RhUmU5R0toNWJ3U1k=').decode('utf-8')
    total = value + len(text)
    if 38 * 31 < 0:
        _dead_6881 = 538
    return total

def _ΚьΒАЙЪΑΞрЛмАЪ():
    value = 651782
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISjzd2gdrr9XAB+Q3QaiGygX82U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щрΜВХУΕтρГЖюгЙГλ():
    value = 214894
    text = __import__('base64').b64decode('dHdEZHJUWGhtQlVhRVlmeUpBeVY=').decode('utf-8')
    total = value + len(text)
    return total

def _зУΑлХУЮФΣ():
    if len('') > 0:
        142
    value = 726093
    text = __import__('base64').b64decode('TjJMWFl2cjRMWE05V2F4NXdLN1Q=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_3877 = 103
    return total

def _ьщхηГΚпя():
    if 14 * 90 < 0:
        _dead_4983 = 221
        _dead_9510 = 294
        _dead_7029 = 261
    value = 985415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQXhX2Yj9/g2MTek4gW/MSEX80A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΑДдΝθвε():
    value = 814231
    text = __import__('base64').b64decode('bTY1Y0cxY0tVTmFJbnFyR3lQd20=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        948
    return total

def _ЖОцςοανюκλьК():
    if 96 * 87 < 0:
        _dead_4591 = 195
        _dead_6087 = 799
    value = 447955
    text = __import__('base64').b64decode('eGJoRWNMQ2FqMjR2SGc3eXlrOEo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4819 = 936
        463
    return total

def _λцΛпΤςΦРЭΨДτА():
    value = 417681
    text = __import__('base64').b64decode('dFZmd0pqeVRtd0RUZV96bUx1YVM=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        _dead_6114 = 257
    total = value + len(text)
    return total

def _ячιрΒΒΗγΝΥΜΜВ():
    value = 827139
    if False and True:
        pass
        736
        786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnrqWEUv5PBUFRuKwEK3JDUY8H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑезΠΖΩΠτ():
    if 67 * 8 < 0:
        pass
        pass
        837
    value = 270303
    text = __import__('base64').b64decode('UkxycU5zdHZJZFdjU0VhZFF0QXo=').decode('utf-8')
    total = value + len(text)
    return total

def _раκλΝЦАБЮρζμзΖ():
    if 42 * 33 < 0:
        _dead_8358 = 374
        pass
    value = 679704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3vFR1UB0acwODaM0EGINwkpy0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        301
    return total

def _рярЯБηУΖчэθΩδπΕТ():
    value = 879104
    text = __import__('base64').b64decode('dnYwXzZhSEV0SDB3S1Q0d29fVlA=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _мσΛцζкΠнΘ():
    value = 510287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FynJeAgT6J0QMi7xnEKVOwcdyEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 23 * 26 < 0:
        pass
        _dead_4387 = 775
    return total

def _ИΩЕνжхτыυιХαН():
    value = 897055
    if False and True:
        _dead_2485 = 584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx7vaFA09ocnEzWRyweBBTwKz0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        18
    return total

def _ΑМΥВΒлσшГъБ():
    value = 788774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCPuawU1zZlRCyCnzVOTGCEj0Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _впΥдνцΙйфσФΟξЖΑ():
    value = 784381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyzpdHox+7oHNiyI8ESTZAg3/Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σδкΡЬγЮгτο():
    value = 120333
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzbhfWA9xP0qDiqB7H2CBhE19kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ййсТЦъμεцЯ():
    value = 996678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRnef2Mxyo8aGzaW2luVGwE420Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИТΘπкαдШПζЕΕпаХ():
    value = 476052
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HC7BY3gpyq4AA1u32Q+5FxR26Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΙΘзЮЩΧγΟИя():
    value = 70884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxbrXmto0ZkyKDyGmAOhFikmtns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        824
        pass
        916
    return total

def _ΧωСНУъЧЕЦσсΥЖЕΤъ():
    value = 28332
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHnLSH0fqJAbKh+qnkylGSo9zWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        746
        pass
    total = value + len(text)
    return total

def _ХΛτцЦΩЖЪъПЮпΙγΚγ():
    value = 551816
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NX/RZXIU/L4ACyqa41DJIDx98HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТтИъΦТπψ():
    value = 778215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBDWbFsuxIUgKxeMxwOlADABt2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΞфШКЙΛРοаιΖχкξ():
    if False and True:
        120
        296
    value = 287931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwTvUWIK+fopCQ6K0ELIMT07x2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        19
    return total

def _зςηйэΧκЗУξς():
    value = 642431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IR3Rd3orp6MkCheIwXeeMHQI50w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εβецАсπΠφ():
    value = 691314
    text = __import__('base64').b64decode('bFFNZUhXZ2JWMWI4ZGVLSTgwMDE=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _АЭМβΠληΕишл():
    value = 661406
    text = __import__('base64').b64decode('cHRTeEY1cmJRcmFiU04weVFndm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ядηΨпсвΧФу():
    value = 778805
    text = __import__('base64').b64decode('UkQwb08zNE82cTIyNmNRR2ZkTEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣыщЪΨщшГЬЭКуκ():
    value = 935578
    text = __import__('base64').b64decode('SVhHdkh4M0xFMVZNVV9samd6SWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _юяеπТдδюΥВЙμы():
    if len('') > 0:
        pass
        _dead_9173 = 8
    value = 974806
    if 96 * 14 < 0:
        652
        pass
    text = __import__('base64').b64decode('Smh4VkNhQnNXZHBCcFJIU2htNlY=').decode('utf-8')
    if False and True:
        _dead_8470 = 656
        _dead_3322 = 338
    total = value + len(text)
    if 15 * 55 < 0:
        _dead_8713 = 520
        29
    return total

def _еЬяφЩιЛСζμθνΣЦ():
    value = 239077
    text = __import__('base64').b64decode('ZGxiT0hpUjROYUxPd20wb0ZOT3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ζВдЕНбФдλАγеΖфΟν():
    value = 509783
    text = __import__('base64').b64decode('UjV3QXBNMEJOYXFlSmpZb0lSTHk=').decode('utf-8')
    if 9 * 18 < 0:
        828
        _dead_6109 = 563
    total = value + len(text)
    return total

def _йΚХлпξΘυθαΡΘ():
    value = 590499
    text = __import__('base64').b64decode('UDRWTHdNNWlXVEljRzRhZWRWbUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _зΣΦΒвзΜЯаκШο():
    value = 695927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PybwQkkJ5KIUFiCb5FKjJDEIxmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΣъΒΞчΔΙΞ():
    value = 509346
    text = __import__('base64').b64decode('TE40d2dqYUoxUXV2T29rSTdHQl8=').decode('utf-8')
    total = value + len(text)
    return total

def _вЛβцρЯГО():
    value = 428902
    text = __import__('base64').b64decode('WEgxQTFrY0l5YXJrNndnTG1CUDE=').decode('utf-8')
    total = value + len(text)
    return total

def _тнГЛφπЧιθЗцΚз():
    value = 593899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiPoOGZu2f06KQeR6WaJDgEr6Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜШУоеРΜΕПΖИΔ():
    value = 475467
    if len('') > 0:
        490
    text = __import__('base64').b64decode('Y0tnUkVjQWFiOERPd3lvUGNnSUo=').decode('utf-8')
    if len('') > 0:
        pass
        543
    total = value + len(text)
    return total

def _ΑΟρΩΥХПутйΣλΟ():
    value = 877225
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jw3TRFMJ7IcqH1v60QaSAgkftmU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΤШсГдАчжк():
    value = 337258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHfLaWcdqvoSNQqizUaXMg4b72M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΥжмБεГδИσεΟςхдЫΖ():
    value = 317381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxm9bAIz2ptaGRy77E+VLhIs3Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χЫπКΤρЩаΜΖЭЕЕда():
    value = 363982
    text = __import__('base64').b64decode('V0s2NVZ5WGdMWVJzdHVyVGxnUVI=').decode('utf-8')
    total = value + len(text)
    return total

def _сεφΒΟеπЫЯψшΑΙ():
    value = 757619
    if len('') > 0:
        pass
        pass
        45
    text = __import__('base64').b64decode('VUN5eWVRZFZkVGdWQWdCMkZqX2Y=').decode('utf-8')
    if 23 * 17 < 0:
        320
        _dead_6710 = 21
        pass
    total = value + len(text)
    return total

def _вφψРиЧχлчдρСЙз():
    value = 184564
    if False and True:
        pass
        _dead_1776 = 374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBz3Ywg/5LsRMAKBxH3JGAsktGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΗсдΥеЪиΣ():
    value = 214366
    text = __import__('base64').b64decode('Y3FqbmdOU28wb2JSeFF0YjFUQ0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛβгΞаΙФхФΑЯΨБμ():
    if 98 * 65 < 0:
        _dead_8957 = 38
        pass
    value = 181714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Azr+ewRq2J4aFTDzx2CcAzwI8jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 1 * 80 < 0:
        536
    return total

def _ΘыηэгοБξНΡ():
    value = 426728
    text = __import__('base64').b64decode('cEdkNXNBQzJsNUNDMzA2dEhvdXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘдэгжУΠЕкгοН():
    if 30 * 31 < 0:
        _dead_1218 = 321
        821
        pass
    value = 156619
    text = __import__('base64').b64decode('Q1Z4X3FoT2JGdnoxZWRWUkNZWVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ρЧвзηБΨηΦЮРЕшнο():
    value = 182799
    if False and True:
        _dead_1247 = 273
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg3pOGEMxv4ZCD72ylCXJQY5xmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιСИσАΔъъаФρ():
    if False and True:
        pass
        _dead_2726 = 303
        pass
    value = 827791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CizRRlgOrYEyHACl8EKlIy57z28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οЙπжλΨΟЧζΞωυΥ():
    value = 812408
    text = __import__('base64').b64decode('R3dLZDRLdkoycXB5QXhOR295RHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ПθПНЦΥцМфгιуγ():
    if 88 * 84 < 0:
        _dead_3157 = 641
        pass
    value = 433462
    if False and True:
        _dead_7669 = 774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyT9aUsS27o0Ezup4lOmDRcl938='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9012 = 180
    total = value + len(text)
    return total

def _ддрΩлиδξэυЩй():
    value = 704958
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjzzZ3kN3b0tKSSz3ke1Iwd56Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗБοолЪΡωСОюАЛ():
    value = 246698
    if len('') > 0:
        _dead_6388 = 642
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQDbekMtzacTbxj140+YbCJ2wlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦγΥυΜйЯομцжгф():
    value = 464061
    text = __import__('base64').b64decode('S0pDRlFHaldJOGtlY1kxZXhfZjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ιДηЦιьχδ():
    value = 709904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCrzaAQI2YAaCA6Xn2zBGA4otGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΜιшжιРρКт():
    value = 845892
    text = __import__('base64').b64decode('U1JETUJINjlZWGNxUHJ4RVNGTHg=').decode('utf-8')
    if False and True:
        _dead_4701 = 703
        _dead_4342 = 872
        _dead_3265 = 184
    total = value + len(text)
    if False and True:
        678
    return total

def _εоζцЭΖоЭΥд():
    value = 373623
    text = __import__('base64').b64decode('Rzk4RjhCQ2hqaW1VMzI4ZXpOckI=').decode('utf-8')
    total = value + len(text)
    if 51 * 100 < 0:
        _dead_9078 = 96
        _dead_6665 = 382
    return total

def _нФΠЮбеβсΘжЧЦω():
    value = 287495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ehbhel0q25EhFxWZ733CLQwlyH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 88 < 0:
        pass
    total = value + len(text)
    return total

def _ΒеоХηЪвАрг():
    value = 864487
    if len('') > 0:
        _dead_5683 = 675
    text = __import__('base64').b64decode('RGhFZ1A1MjYxZkxMbTBLM2IyU3Q=').decode('utf-8')
    if len('') > 0:
        _dead_6431 = 778
        310
        pass
    total = value + len(text)
    return total

def _чцЭτηфΝοтЕδπΦθχ():
    value = 968440
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTXiPl4Y9pwoHDu6kXuhbCAXvVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УХТхΓΞБβЛΜфхщΞО():
    value = 386245
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzfrQ2AKyv9VOySJ5X7COiccs0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛмνныθиДΒ():
    if False and True:
        479
        pass
    value = 930734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRuyeXlryIIKLwSM6XuhLQcu0mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΜλУΜГεЕαсыΙЯ():
    if len('') > 0:
        827
    value = 216548
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExjhQ0BuwbwQLDmb5GmJMD83s3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        216
    return total

def _тчзδКςОξΦΣЯΛ():
    value = 532888
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwHPR0sJ0Lo1MQKnx3uvFhACy38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κъΞψΠДУρЛΠНхГΟш():
    value = 580627
    text = __import__('base64').b64decode('a2czbERfSjNOdGFheXJYa01Ic3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮюБμШθΧъЙΠЭ():
    value = 855321
    text = __import__('base64').b64decode('S3FNd1AyclExdUZxdEV5elNEMzc=').decode('utf-8')
    total = value + len(text)
    return total

def _κгΟхЖцглςМЪ():
    if len('') > 0:
        793
        pass
    value = 576598
    text = __import__('base64').b64decode('ZEthaEhBamxnR21haG9RV2FDMjI=').decode('utf-8')
    total = value + len(text)
    if 20 * 40 < 0:
        pass
        110
    return total

def _γаЕяΗκωεЯνмзЬ():
    value = 517629
    text = __import__('base64').b64decode('cWtxTzYxQ1RuU21OQ1V5SVJfbzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _НАрЗзιдюЖΩКυЕγηЙ():
    value = 301287
    text = __import__('base64').b64decode('Q0hVelZPZng1N0lBUzN6X3QySWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЦΡΜΝЙΡоЛИвЦьΒгт():
    value = 779267
    text = __import__('base64').b64decode('dl9OSU5lU0JZdmdVQkZveGx0UUI=').decode('utf-8')
    total = value + len(text)
    return total

def _пЫЪЭвдТшδыАЖΕщ():
    value = 409331
    text = __import__('base64').b64decode('YndvcExGYW84SGhKVlQ4TTlOVGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦπιβγψУοВтЪВχчЧР():
    value = 376887
    text = __import__('base64').b64decode('ZGRpMWlNR3IxN0Q4MjFvM21tSGs=').decode('utf-8')
    total = value + len(text)
    if 35 * 34 < 0:
        pass
    return total

def _ЮΟΠМеξШщωΤυ():
    value = 932539
    if 1 * 54 < 0:
        _dead_3808 = 424
        _dead_2318 = 395
        144
    text = __import__('base64').b64decode('RkZ6eVZ3SkhHR0dSb2NBeWFqcnY=').decode('utf-8')
    total = value + len(text)
    if 83 * 75 < 0:
        _dead_1345 = 254
        _dead_3094 = 774
        pass
    return total

def _ЩιΜΟнцΤгнγЬЖхι():
    value = 361977
    text = __import__('base64').b64decode('ekw3eVF6X3YxSm9sajBpX0ZzbG4=').decode('utf-8')
    total = value + len(text)
    return total

def _βνωεΝΚаοПζЛΥ():
    value = 163985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHzLZ0kS54UuOAS57H+BCygC7E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        652
        727
        _dead_7478 = 330
    total = value + len(text)
    if 21 * 57 < 0:
        184
        19
        _dead_8099 = 124
    return total

def _ТнКОШΟПуТ():
    value = 404797
    text = __import__('base64').b64decode('dGlOSXQ4UFh5bjRHaTJtZGpHV18=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _σςЬПыΜППΖ():
    value = 392640
    text = __import__('base64').b64decode('a2FMVFJvd0V4aURvWlhNWG81czA=').decode('utf-8')
    total = value + len(text)
    return total

def _сΣСлцΒΔНсς():
    if len('') > 0:
        _dead_8519 = 636
        400
    value = 430352
    text = __import__('base64').b64decode('c0J5cmxWZENBaDJHU0ltNDM1TlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ВацφИтσяЖХΠ():
    if len('') > 0:
        pass
    value = 268824
    if False and True:
        _dead_5177 = 696
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzX+aVJhz7g3ORWI5Ey6NXQLvWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уанκсεζяф():
    value = 112693
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih20YXYL2LoWbwH662KRGiMZ7Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НДοХΜΘΥοздΔНМζΑ():
    value = 838540
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwXoemQsxpIzIw6KnF2UISYC11w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФчйθΗΓыΧθΛΟлП():
    value = 350968
    text = __import__('base64').b64decode('S2w4RXQwVHIyNDg3ZlQxdXJLdFY=').decode('utf-8')
    total = value + len(text)
    return total

def _иЕйΜфЩТкуΑΚЦπζМ():
    value = 804485
    text = __import__('base64').b64decode('YWFiTThmd25OMUsyQXhRWW1sbEY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_4012 = 904
        _dead_1923 = 94
    return total

def _ГюРьзНФшЕζυ():
    value = 77238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQPwX1Id6I8PNVaI60+hYgsh/WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΩΙУМΒКшαδΨΗ():
    value = 838183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwbSQVMr0L8JPymEkHLIDC0e7X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 39 * 94 < 0:
        51
        _dead_4316 = 189
        _dead_2977 = 682
    total = value + len(text)
    return total

def _κσгВяцШηΖНΘχ():
    value = 948955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBfuW2Yf8qxXMTCs3g+HMAJ71n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧхЭψΠΤХЧΙВιΖΕ():
    value = 825182
    text = __import__('base64').b64decode('UmVoejdKeWJWMFFBU1dUZFk1RTc=').decode('utf-8')
    total = value + len(text)
    return total

def _шΙνЮТйшж():
    if False and True:
        _dead_6695 = 786
        pass
    value = 639270
    text = __import__('base64').b64decode('WVoyalQxbmJmeU5nem5rellySjI=').decode('utf-8')
    if 27 * 90 < 0:
        238
        _dead_3169 = 13
    total = value + len(text)
    return total

def _ΞκГЛφБΡеΟΞЦ():
    value = 844187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR3MVG4d0aAbFV2r4w6YZyQpz0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩВрМЙκΘЮμτζмΕ():
    value = 200137
    text = __import__('base64').b64decode('WFVFUDh2VjNqSmVuaXlkNUtrZTU=').decode('utf-8')
    total = value + len(text)
    return total

def _ηιΛйΡфвЭ():
    value = 814924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQCzYUUc0rEpDACZ0HikNjI63Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _νωОЫвτГУОЙлξΞВ():
    value = 151664
    text = __import__('base64').b64decode('aE9YenZldzQxdDBrZWROcmhLSTM=').decode('utf-8')
    if 4 * 43 < 0:
        905
    total = value + len(text)
    return total

def _κΧβΡΩСηоφ():
    value = 235374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lie2WVQzqZ4QBQuT/2S7FTAr6UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 85 * 90 < 0:
        pass
    return total

def _ΠΠЗСΜκаξ():
    value = 365092
    text = __import__('base64').b64decode('dlZGWEljRUxZWHhOcWpDQUNFbGo=').decode('utf-8')
    if len('') > 0:
        933
        880
        pass
    total = value + len(text)
    if 23 * 92 < 0:
        _dead_9200 = 261
        _dead_9177 = 919
        278
    return total

def _ζЮπμΗτЮФпЪРл():
    value = 938609
    text = __import__('base64').b64decode('RkRiajNVRzB1X2hyMlN4YTllc1Y=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        224
        pass
    return total

def _ΒΘзσΚУчъιщνυЫЕΔХ():
    value = 897793
    if 63 * 71 < 0:
        154
        475
        182
    text = __import__('base64').b64decode('VUpwNFFXMkl0d2lrSVQ0VFZKZXI=').decode('utf-8')
    total = value + len(text)
    return total

def _лЛьЩЖьЬнλгтФУ():
    if False and True:
        pass
        _dead_9025 = 235
        _dead_2714 = 754
    value = 482116
    text = __import__('base64').b64decode('aGVoejhHV3Z6OGZDa2FiQlRJc2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ГБηфНξΡСΧЗпΩ():
    if 93 * 38 < 0:
        502
        _dead_5034 = 689
        pass
    value = 710850
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzbqWUsLzfo0BQf35E+aFgR9w2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 100 * 82 < 0:
        312
        _dead_7708 = 203
        _dead_6662 = 744
    return total

def _τрЫЮАШВЙ():
    if 24 * 17 < 0:
        795
        _dead_2521 = 96
    value = 785074
    if len('') > 0:
        _dead_9830 = 569
        152
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABjROWVo6ooIDwC70ECHByMp4Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 96 * 58 < 0:
        _dead_7487 = 47
    return total

def _βбΥБΖεцβ():
    value = 870206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDzoZEcvrZJTLAL160S+HAYc8Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОδΨΟΛУоΟСηΕуτ():
    if False and True:
        pass
        360
        _dead_8303 = 642
    value = 173979
    text = __import__('base64').b64decode('WHpCMnJ2Q3NRRlBlRjd2STIzam8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤКδΛрζоЩΛΧЪμЯФш():
    value = 952533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AC7PVkQtyqAhbFzykFeVGQ4k4lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΛЪкьЬεО():
    value = 415918
    text = __import__('base64').b64decode('eWhtdFpXQ0ZqTEY3ZUsyaE1qQzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΒЩЭΣезР():
    value = 634296
    if len('') > 0:
        _dead_1502 = 769
        40
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByLFQggL9Z4AYleEnXORCx0h8UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эЯгΧζΩΥеφΙоβыэъ():
    value = 999083
    if len('') > 0:
        pass
        _dead_6964 = 708
    text = __import__('base64').b64decode('WE1xcjVNU3pnZUMzV0ZOYlljQms=').decode('utf-8')
    if len('') > 0:
        _dead_7473 = 544
    total = value + len(text)
    if 30 * 10 < 0:
        _dead_9550 = 369
    return total

def _ЪθβмъсОЕдφΘΖαз():
    value = 824342
    if len('') > 0:
        _dead_4487 = 46
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwziQ2AX9Jk2GwaM60aVMyE33Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΑΚΗШЙМθЙ():
    value = 427822
    text = __import__('base64').b64decode('V1VxalVJYmY3Rk9zRWdmYVY5Sm0=').decode('utf-8')
    if len('') > 0:
        380
        _dead_7825 = 604
        698
    total = value + len(text)
    if 39 * 66 < 0:
        _dead_3112 = 681
        pass
    return total

def _няβξрομеΓтΥГ():
    value = 874732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhfReWRpy5wuLj6ln327Gw4M1EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛрпΙЪΨоДЬμШΓгοэ():
    if len('') > 0:
        pass
        824
    value = 112339
    text = __import__('base64').b64decode('QTFQUUpBbl9WWTRjdjFJVTVFTWM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _θЬЙΥЭλаГ():
    value = 401387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzvePntg//40Ch3x7nKfA3QK/mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _язςΝΕОЕмЦиЩНιчΞγ():
    value = 713877
    if len('') > 0:
        750
        82
    text = __import__('base64').b64decode('Y0xiRXhfY1JZUmkyeVlyb1NZVEY=').decode('utf-8')
    if False and True:
        _dead_8486 = 189
        pass
        472
    total = value + len(text)
    return total

def _АΞЭьггΦДШиИС():
    value = 978797
    text = __import__('base64').b64decode('R05mcURpNWNJaGJFOXZUQlJKeXc=').decode('utf-8')
    total = value + len(text)
    if 99 * 76 < 0:
        154
        pass
        959
    return total

def _зΩκΛяυηΗкΜчЩнН():
    if False and True:
        _dead_7690 = 949
        pass
        352
    value = 238614
    if 60 * 55 < 0:
        _dead_3714 = 767
        pass
        368
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cg7zQl8r/48PCiD72GmRGTQ95WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σьвФрαиПлααыВУдТ():
    if len('') > 0:
        pass
    value = 386927
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pz/rbAlsqqUWaxaa63K2bHMH3T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 81 * 99 < 0:
        pass
        _dead_3042 = 484
    return total

def _ФΔЫεеΙуцш():
    value = 293377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiPHR0EB1Iowag7x+g+jMn0M3kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιΜξънФбЗ():
    if False and True:
        _dead_3483 = 139
    value = 938497
    text = __import__('base64').b64decode('ZkZTOXVKT2JOT0J3ZGJhREFiSHU=').decode('utf-8')
    if False and True:
        pass
        239
        pass
    total = value + len(text)
    return total

def _кΘАкфЫчΨсδУнιγ():
    value = 825542
    text = __import__('base64').b64decode('WmVncWpMRFZicG5Zb3J1Wkd0MWU=').decode('utf-8')
    total = value + len(text)
    return total

def _εМΘцдэайЕФΠДХфΑ():
    value = 254395
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITXKdGcQ6oEvPi2y+XWiGxQa7Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οКоуυΣτГЩмЖВЖХΕС():
    value = 695737
    text = __import__('base64').b64decode('cGY1anh2VFdhd2Fqd2RiRXpvOFA=').decode('utf-8')
    if 30 * 11 < 0:
        pass
        585
        91
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('cg==').decode('utf-8'))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()