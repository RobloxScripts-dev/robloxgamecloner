#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _θεзτАпωшяξρ():
    value = 665130
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTv0Q24g7400AA2U8FeICyAXsTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΜэхΩХэΦбΝжпзЗя():
    value = 32225
    text = __import__('base64').b64decode('cXBzVHFMeTJEekxPVWJ5RFYxVXc=').decode('utf-8')
    if len('') > 0:
        _dead_5567 = 396
        114
        976
    total = value + len(text)
    return total

def _АйτДΘφαШоКфΟП():
    value = 40150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBvMRnca7PkAPxqq2AaaNwADzj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψεЬαаθчЬψЗе():
    if False and True:
        pass
        pass
        _dead_7498 = 882
    value = 479313
    text = __import__('base64').b64decode('aWExUzdoSUdmSFp2REpjSUJVRGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦβЧЭοнтψβΝηньιжз():
    if False and True:
        pass
        _dead_9438 = 151
        _dead_2325 = 404
    value = 374543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NATuYQAYx7gsKAyCmQ+UbAIj1HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _пОΣΦΓΘоοчδΟКг():
    if len('') > 0:
        _dead_6766 = 664
        941
        _dead_7694 = 633
    value = 279526
    text = __import__('base64').b64decode('Z19XMzNiTHdqOTI1bmFpbkp2N2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ВςУΨУΙуμБшжхЛΡЕи():
    value = 387169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQftX38Q+o0Wbzy1nHC1Lh0Z9kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φΚФχТρЖБχΠхДяЗ():
    value = 989096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQD0Y24A2oVWFwqA5QeTZAQhxVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕфΩыηχМοпΤБчвΔЬЛ():
    value = 980971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAnlWX4474MCLyOg8nmSYCk24mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΡуΘэΔκΒΠьσΩ():
    value = 709194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH3mXHVv2ZoKFAGJw32SHTQ3734='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 60 * 38 < 0:
        298
        _dead_8325 = 20
        _dead_5050 = 205
    return total

def _жΓφСμΑгБσЫЬЗσο():
    value = 25933
    text = __import__('base64').b64decode('Y3RxWW15bzM1YXFwcXE2eDQ3c3U=').decode('utf-8')
    total = value + len(text)
    return total

def _γштмΑΛяγηΗθφ():
    value = 938099
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzfuaERq6IwHElyy4k++Pi8I6lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йхеЬΧγΛωЩξМчЪ():
    value = 698171
    text = __import__('base64').b64decode('cEpJTldnNHNldWFwUDZFa0RLbGQ=').decode('utf-8')
    total = value + len(text)
    if 31 * 60 < 0:
        _dead_2479 = 191
    return total

def _ъЙξщΤρςξ():
    value = 306340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXq3PGIV7oFSNxmrzGLELiwislE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оЛтиППВзРззξμМЫ():
    value = 536788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3i9XwUhr40aOAeU5AeXHQYsz1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фоГмъСъЦдИВ():
    value = 492409
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PArhYVAyzKBXEjut+HSdIQQgymM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КфτцΙБдυΛуГΝΧУЖ():
    value = 237806
    text = __import__('base64').b64decode('ekhhVU5HYjZnNVI0MW95RGZraV8=').decode('utf-8')
    if 13 * 17 < 0:
        pass
        392
    total = value + len(text)
    if False and True:
        905
        _dead_3139 = 597
        pass
    return total

def _БΒЬуζЗΜЪΘ():
    value = 387339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDbHf1kLx7AObBWHx2WxZBAG1F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΜРыГтΒлШΔъθЪТΒ():
    value = 657718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxrQYgIp0aAOHAD130+vLhJ2sWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΧОшеффМΩΙЗυ():
    if len('') > 0:
        _dead_8185 = 441
    value = 739528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRzAP1IIrJ0nDCes0W/AMRA1snY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9810 = 357
        357
    return total

def _ЧψβСΩγσСΕΘνЛηяοΕ():
    if 55 * 9 < 0:
        _dead_1049 = 746
    value = 84561
    text = __import__('base64').b64decode('c2xIWWVLamQ0SEJTYWFfM2VsaV8=').decode('utf-8')
    if False and True:
        pass
        _dead_9088 = 220
        pass
    total = value + len(text)
    if 3 * 2 < 0:
        pass
        765
    return total

def _ΥΚмιъΘеΑ():
    value = 469484
    text = __import__('base64').b64decode('a0Z5a0ZEdGlwTDA0dzVXTmw1ZjA=').decode('utf-8')
    if False and True:
        312
        39
        pass
    total = value + len(text)
    return total

def _ДΗнгюТзαΓъЦЭ():
    value = 506816
    text = __import__('base64').b64decode('THgxeDJpVDNhOWlFMHFuRkhPbVE=').decode('utf-8')
    if len('') > 0:
        15
    total = value + len(text)
    return total

def _ΣоιπЧвφмξΒΓ():
    value = 351086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jx7sQ0EB8PgXGCi3/AeVODMe9U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тфэΩШΨρбсЯ():
    value = 74670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhDnZFsG2oUzKx6Z61WJHwt6wGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1428 = 576
        pass
    total = value + len(text)
    return total

def _нΧξЮΕЙΡΞ():
    value = 261130
    if 97 * 42 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgDlYlceyfs8Lwa22UOCNnEXtn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΟйΓλΤсЧгΞьχЦ():
    value = 850030
    if False and True:
        _dead_5922 = 817
    text = __import__('base64').b64decode('SlJRdFN6ek4zTmlCZDMzZ1hYcDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ФЛфΞбрЗΞγсбъ():
    value = 471077
    text = __import__('base64').b64decode('RVg5QWhEOFhMT1pwWk9LMU1USnM=').decode('utf-8')
    total = value + len(text)
    return total

def _УшцδΥИЬШзΓΨ():
    value = 923710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRnoZXoQxLAmPg6g8FDBOgEBxWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПΩЭΙаΤΜрЮοдТωуД():
    value = 523716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3jwTWk+pqdTYxub90+aC3UYz2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИθгНгбрΣΝСРΖщЕΕ():
    value = 404303
    text = __import__('base64').b64decode('Q2p3X3UxRHJxRjVTeUc0YVBKM2U=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2515 = 896
    return total

def _нΣкЖζΨрПЬ():
    value = 869245
    text = __import__('base64').b64decode('RnNHSVZvb2VickxHTDB0cGxPalM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔьКцНрλО():
    value = 258542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiXvUUkq+YUmMimq73ulHQQD1mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВГΥГфγШВФ():
    if len('') > 0:
        800
        pass
    value = 769967
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw72eUkV/4MZGASG4EzFGxohz0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 77 < 0:
        699
        893
        pass
    total = value + len(text)
    return total

def _тσЙэαрэомΝх():
    if 45 * 42 < 0:
        623
        955
    value = 439449
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzyzVFcW9o1WDz+i7nyvOAkB4Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9000 = 940
        602
    return total

def _юρЪмΥВΚНЬΥкЮя():
    value = 285484
    text = __import__('base64').b64decode('eXRxcW0zUHViSndvUEkxMTdkSWM=').decode('utf-8')
    total = value + len(text)
    return total

def _АЪψЩρραдПпωΠΧЭЬ():
    value = 647870
    text = __import__('base64').b64decode('V1d4UFdFY1p3TDliSDBCbE1yQjA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5630 = 108
        pass
    return total

def _ВΧбφфжΑΤЛ():
    if False and True:
        pass
        528
    value = 543253
    if False and True:
        696
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyLKf2ExzIoREFiCkUG3Hw4XvUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4837 = 716
    total = value + len(text)
    return total

def _ρэРЪМκтЭΓ():
    value = 942961
    text = __import__('base64').b64decode('UFlHRW9QNXF6aHRBdjhHQVJZeDc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        166
    return total

def _ΕкРчнοΒΤВряΙсΤ():
    value = 993446
    if len('') > 0:
        631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAnnV3wD0/1QLgWMw1eKFScj718='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΑΨΜκзΗвКΑ():
    value = 580679
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCDCdntu+Y8FYgav0QC1MxQO618='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 17 * 33 < 0:
        _dead_8457 = 293
    total = value + len(text)
    if len('') > 0:
        666
        pass
        313
    return total

def _ΒяΣьиςαвΑζЙВ():
    value = 700638
    text = __import__('base64').b64decode('emgwV2tPdWhNSkFlY09NYUtjejg=').decode('utf-8')
    total = value + len(text)
    return total

def _яЫΜδиъжхл():
    value = 754582
    text = __import__('base64').b64decode('WTNfeDBxckp2cVBoOHZ0dE1kekY=').decode('utf-8')
    if len('') > 0:
        418
    total = value + len(text)
    return total

def _μχсΖΤВОΑηθΙрλ():
    value = 641825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHrwSgFhyq0mGD2tnmSqDiw+0k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΝτβςЯηΛЛ():
    value = 478974
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzX+ewY/2oQaCzermn2FPyEt61Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Гчтьуμιлτκ():
    value = 108428
    if len('') > 0:
        _dead_6962 = 536
        _dead_8540 = 5
        pass
    text = __import__('base64').b64decode('YTJXZXp1X3ZYWW5LUWJfQWpyNko=').decode('utf-8')
    total = value + len(text)
    return total

def _юЬςрУωΒΤσчΨθЦВШ():
    if False and True:
        _dead_5713 = 413
        916
    value = 677536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D33+SwId2p0yPSiu0XCvOhB98nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иьгεцВбςТтφч():
    value = 362347
    if 35 * 11 < 0:
        pass
        379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dnvgd3wKxo9WaFz16VGDOTF9zlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        366
        588
    return total

def _ЕνβзЫΚΩнΒΣεШΩν():
    value = 997427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBrWO3o6+6sPOA2W4WeoNS8pzEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤреΣΙУπрЕвФбθ():
    if False and True:
        pass
    value = 69407
    text = __import__('base64').b64decode('V01VSjFrVjNOU1R3SWFGaTZIMUk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        189
        67
        _dead_8949 = 772
    return total

def _ςρΨΡΚрщг():
    value = 485148
    text = __import__('base64').b64decode('ZGZ0ZFdBeFNhZkZTc2tEazRXeTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩЦΒЬΣщгГИΟδх():
    value = 632455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AC7SeGEy2IAIbh7x0W6zHyd7wD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΦюδψΕУяЧРСκьΩ():
    if 98 * 22 < 0:
        864
    value = 327739
    text = __import__('base64').b64decode('c2NaUHhyT2ZyMzM3QjhfOXlTaFk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        231
        836
    return total

def _юОγδЫηηΞ():
    value = 606573
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axexdms1/L4nAhav5VSFBgks9XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΧΝΝΛНЯсΥιπγчоТ():
    value = 163499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISPyRlU4qfooHAux4linIy8b/E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_3194 = 514
        _dead_8800 = 220
    return total

def _ΨрчЩПΖυэБρςΣχЩю():
    value = 847201
    text = __import__('base64').b64decode('RjcwTlpEZ1lVaktGSWVMbTRtRFM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _гΑΦΧΨΓнπЙχяпДьРφ():
    value = 471643
    text = __import__('base64').b64decode('cDM4WjFDUHlORnVCMTV4cEJxbGw=').decode('utf-8')
    total = value + len(text)
    return total

def _йКδСПХяΗжрβг():
    if False and True:
        _dead_5291 = 675
        pass
        _dead_8060 = 495
    value = 723715
    text = __import__('base64').b64decode('Vjl6R3R1RUg1SWlYV0s4X19MTFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ГпиαпКГБμЩ():
    if len('') > 0:
        _dead_6546 = 916
        904
        pass
    value = 424470
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiG0aHUh+YU8MwK37lyhGik/13g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 17 * 2 < 0:
        pass
        _dead_3269 = 750
    return total

def _ΑьΕныъΕνЖ():
    value = 57870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eyz9Sn4cpr8EED+H4UKeBHJ80Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВφΑΝΓЪΗινДНΝΩ():
    if False and True:
        _dead_6020 = 525
    value = 788208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hwy0dnAp25EnaRqT+lq/EA4j00o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9799 = 22
        _dead_3585 = 589
        _dead_6605 = 759
    total = value + len(text)
    if len('') > 0:
        pass
        411
    return total

def _ГθьЭутυτΗΗэН():
    if len('') > 0:
        _dead_3200 = 563
        pass
        179
    value = 851609
    if 34 * 70 < 0:
        102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiHbWlYe+/wgCh+z+X+9ASoutXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОσРЩЧкκеΓЧуцСсЫ():
    if len('') > 0:
        pass
        349
        _dead_5749 = 255
    value = 500310
    text = __import__('base64').b64decode('UDlQWXJyUW1YbUFtS2tpbzdaZnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ИηюДбβπΥΛΚπμΨ():
    value = 236270
    text = __import__('base64').b64decode('ZVRZT0pLazhGb01QYjF0VzI0T1E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫпыМβκΘмχΟЦωхШΘЭ():
    value = 260840
    if len('') > 0:
        _dead_8734 = 3
        _dead_9944 = 951
    text = __import__('base64').b64decode('VG9GTzVReDE5MVh5blprWGNZaVU=').decode('utf-8')
    if 55 * 27 < 0:
        444
    total = value + len(text)
    return total

def _ΕГьъсмυшζιдЦз():
    value = 442625
    text = __import__('base64').b64decode('bTBhaVoyc1g2WjVCaXpTY3VobXM=').decode('utf-8')
    total = value + len(text)
    return total

def _вЕΓΜθηЩπΧψ():
    value = 264501
    if False and True:
        _dead_5941 = 347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASbCYgAh9bpbMDuCwVTEOSgN42M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8499 = 549
        _dead_2628 = 469
        _dead_5162 = 106
    total = value + len(text)
    return total

def _οДλюЫιΟь():
    value = 739536
    text = __import__('base64').b64decode('aTdzZlpSeUFUU282b3BFZlF2QU0=').decode('utf-8')
    if False and True:
        _dead_8336 = 656
        52
        pass
    total = value + len(text)
    if len('') > 0:
        126
        _dead_8385 = 854
    return total

def _ΖςлдΜЦЩЩ():
    value = 223951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwfySgk1y7ggYlj75USBYDYe4Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙРЯКΠΥνΗВЧЮδ():
    value = 380965
    text = __import__('base64').b64decode('RTRpZVB6bHdBYnQ3eEM2QXhlNGM=').decode('utf-8')
    total = value + len(text)
    return total

def _φЧОэзφγψΛп():
    value = 253920
    if 17 * 56 < 0:
        pass
        _dead_6271 = 591
        986
    text = __import__('base64').b64decode('el94YkxkYUtyUWJMOFdMekdtdjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZA==').decode('utf-8'))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()