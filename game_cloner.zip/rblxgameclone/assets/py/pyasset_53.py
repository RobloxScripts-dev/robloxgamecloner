#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΛМΒФьДАαΚХΕΕУХΒВ():
    value = 225453
    if False and True:
        _dead_3698 = 978
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DADNZn8d0psuAA66+VGjJCImzmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΥξτωζЙπИвΛЮФ():
    value = 472734
    text = __import__('base64').b64decode('RndpMDZDMlk0S2FXM0JPUHhpTVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮαьцХгхκσХχЪсΝ():
    value = 799403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwDAOlU/1fEqDTW1y1yXYiYe4lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6876 = 570
        686
    return total

def _ЦпХЭυПδВЙ():
    value = 7379
    if 30 * 15 < 0:
        144
        901
    text = __import__('base64').b64decode('ak5vM0RyWkM0UW04NTNvcUxfV3k=').decode('utf-8')
    total = value + len(text)
    return total

def _чβμεσθεΤΠΖ():
    value = 577015
    text = __import__('base64').b64decode('TUZ4UEhaWllPdDVjOWc1QWhISUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЦΘΘξЪбхοнκγδь():
    value = 254394
    text = __import__('base64').b64decode('RHhpdUNjYUJ6WEJhSGR0VDY1N0E=').decode('utf-8')
    total = value + len(text)
    return total

def _шΑΣцαδБΕθ():
    value = 83232
    text = __import__('base64').b64decode('R1JzTUN0b1JlYXI2dTVWYnNhR2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡУаςΝνФζиιП():
    value = 704305
    if len('') > 0:
        128
        pass
        _dead_7679 = 204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSrCRnov0KtVG1iZnF7COSw6z1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΥцуьΑЯΜλΚЪ():
    value = 269894
    if False and True:
        pass
        pass
        _dead_6550 = 10
    text = __import__('base64').b64decode('dUNoM3JsdlJmMnJPUGRkMFhzUDM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1129 = 720
        601
    return total

def _хΖσОΝСΜΛцυЯЖКΓЮυ():
    if False and True:
        _dead_1106 = 89
        254
    value = 422149
    text = __import__('base64').b64decode('TlI1UGR3U0RldHVsZUF1b3NSNTY=').decode('utf-8')
    total = value + len(text)
    return total

def _δЭлЯδРсФπΞЖΝгюП():
    value = 225801
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECf8eEEU5qUraSyN91OgYwEtz3Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 14 * 54 < 0:
        266
        953
    return total

def _ΚГΥΩШВюωΚыχ():
    value = 242267
    text = __import__('base64').b64decode('dmFrc2N5V0ZJREJiWUtxWE5uTXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΧδςΟεюьδΓМΤБюаΞ():
    if False and True:
        921
    value = 365046
    text = __import__('base64').b64decode('QXJSY2hQbm1ObUxJNWY3dmR4NU4=').decode('utf-8')
    if 35 * 96 < 0:
        _dead_2038 = 927
    total = value + len(text)
    return total

def _АΑчуХвΓпГ():
    value = 173121
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Chi2Z2YazpALGR2C31mdGgkcwzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 40 * 13 < 0:
        606
    total = value + len(text)
    return total

def _αдΘΞбщеиРΘХ():
    value = 284292
    if 75 * 78 < 0:
        _dead_3588 = 332
        pass
    text = __import__('base64').b64decode('cWIxazVUV1V5a2hFdENLSV9OeXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔынНμЛкδΓШЫω():
    value = 856077
    text = __import__('base64').b64decode('STg1N2NHaldIU2hjMXY2NDdfRlA=').decode('utf-8')
    total = value + len(text)
    return total

def _яσθАщΩъЙуοУτΩдАь():
    if 7 * 20 < 0:
        _dead_6608 = 577
        568
    value = 471994
    text = __import__('base64').b64decode('YWFVMGRpTUZsMWg3UnZMX05fQmk=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ДАλΑΛζмΦьРγН():
    value = 395945
    text = __import__('base64').b64decode('QUVRSWVzZEZHY3hIcEY2NF9sUDk=').decode('utf-8')
    if len('') > 0:
        597
        _dead_5363 = 421
        740
    total = value + len(text)
    if 1 * 90 < 0:
        566
        522
    return total

def _ъшБтΞчΧыσУ():
    value = 190158
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxfRWGkp1f42EQLyzFyCJzUE8Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑλВлξεΤХπ():
    value = 474293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxbmSV0bprAPPTi790anPD0I9zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щΥФςηξЧЦсКχп():
    if len('') > 0:
        988
        pass
        _dead_2451 = 176
    value = 912465
    text = __import__('base64').b64decode('eE83TndQT1FKUmRuT3RBcHFzX2g=').decode('utf-8')
    if False and True:
        _dead_2217 = 831
        pass
    total = value + len(text)
    return total

def _ΤΘхςμуДΓ():
    value = 109807
    if 64 * 87 < 0:
        931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cnv8eEgt+ppTPx+O2Q6/Mx0r02Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εагГΧыЙεгναЧ():
    value = 129601
    text = __import__('base64').b64decode('ZGd2WWZXSWpDeTBwbmpWTlMyaWI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        932
        pass
        pass
    return total

def _δγπχцюνΖж():
    value = 819754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eiu8RHkPzJEnPgG57A+6OSwX4Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИтΣΝднΠδТΥкКφ():
    value = 346168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mn7QOnA37bEOGBqv+nenZio+8UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НЖΑрЗЮяНΤЖя():
    value = 433418
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRrTd2Rr2KAoGRmUwFueOTMaxkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΘΝМςЭщЪ():
    value = 591262
    if 34 * 97 < 0:
        _dead_9330 = 619
        467
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz3MWQcL6oJbaAGI8nLHYn0/w00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_7342 = 415
        _dead_8652 = 507
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЩδжπγЦЫыТцАνΘ():
    if len('') > 0:
        pass
    value = 623944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fn31OmVt+v8OEiy6/wWSMxEKvTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЬщζпβζдюШХ():
    value = 42671
    text = __import__('base64').b64decode('R3pTOXlHZkVhSktJMkY4TUxwbGM=').decode('utf-8')
    if len('') > 0:
        1
    total = value + len(text)
    if False and True:
        _dead_2134 = 618
        901
        773
    return total

def _АнαρлОъюΤΛΧ():
    if len('') > 0:
        pass
    value = 641337
    text = __import__('base64').b64decode('ZGNoTDBHbzdJZnpUalVvdjBzY04=').decode('utf-8')
    if False and True:
        441
    total = value + len(text)
    return total

def _ХδΨδΙβκЫхΨπлβБθ():
    value = 510750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3fseWI///oCHSr0kQaZJz0Vxmw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТКψγΜтΕЕшчЕсйьД():
    value = 652065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EnnJO3cIyJkHL1q0wXS9BQQ8s1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭГшМъΤριЩ():
    value = 426380
    text = __import__('base64').b64decode('akR5UjA2d0ZoeWZWQ3N2NFRXaHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΗГМςΣЫξΑ():
    if False and True:
        952
        _dead_7374 = 616
    value = 547231
    if len('') > 0:
        _dead_8508 = 393
        _dead_2403 = 756
        _dead_1687 = 192
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCDnQAQ4zq8oOQKQnXzJACgIt0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 85 * 21 < 0:
        pass
        21
    return total

def _ΤБΨМфσКВ():
    value = 245381
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCi8XkI/pqFVNgGSyQKXDjUq92E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΘκΒΒАΠΙрЖъд():
    value = 452554
    text = __import__('base64').b64decode('UjVObjNMYTBnOVhjVDVxczN1Y1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ωЮыτΟΨζАКж():
    if False and True:
        161
        548
        _dead_5759 = 912
    value = 223676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw7KOFsG7bAZHD+K0nfAEzUi4Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_6113 = 56
        _dead_3626 = 649
    total = value + len(text)
    return total

def _ΚЖпΙδШзΜЕΘпнЙ():
    value = 653552
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwnbREAP+ZgtLA2m6nrBNQwr5kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пфыюψДЖШΜλΓο():
    value = 316508
    if len('') > 0:
        _dead_6955 = 872
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ig7Ce0Fvp/EPLhaTnmnCOxY73mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _υТтβΠРхфЗ():
    value = 336186
    text = __import__('base64').b64decode('cTljRWxHcDVuM2NhX3ljemdCbmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ХпзфчΕαыЛΦц():
    value = 91846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxnVdGhs5JdXNVrzwVGdNxE2yFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηиЫДΑфВςιщйх():
    value = 976022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCazfmUg0p4ZYj2z8Fu8Lg4q6kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜЫΒδπтΒПувΥпβΔЕφ():
    value = 755053
    text = __import__('base64').b64decode('V284RjlXSXJQMmtjU3ZuMG9hYUU=').decode('utf-8')
    total = value + len(text)
    return total

def _цΧнЖпМΞΦΛ():
    value = 102664
    text = __import__('base64').b64decode('VTdfcFFhWGhoamdtUHJyc19Od0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ФъσΣЩЭНφ():
    value = 442816
    text = __import__('base64').b64decode('V3JKc1dpSmdVazhwRURoTGpoZ3M=').decode('utf-8')
    total = value + len(text)
    return total

def _БЫТЙФШОПм():
    if 57 * 56 < 0:
        611
        pass
    value = 349895
    text = __import__('base64').b64decode('eTB0NW1PRExsYkdJb21SMlRncTY=').decode('utf-8')
    total = value + len(text)
    if 25 * 15 < 0:
        pass
        pass
        pass
    return total

def _ыχЯъЬпСΡМζΞЖдβΜΣ():
    value = 554984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT/tfUg655kNGSDw7lKvGzIg3mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤΦЛьΕЯΣтъЕсЭ():
    value = 72189
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3rpbVAt8owobximmg6fBR8H83k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭзξυБСжШεРЦχЫ():
    if len('') > 0:
        175
        _dead_5642 = 862
    value = 17912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FybIXngb7ZotGw6b2GShF30K1D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9715 = 694
    return total

def _ΗиΡλΣΑчсъсΖπμ():
    if len('') > 0:
        pass
    value = 21349
    text = __import__('base64').b64decode('S21pQlEwYW9UaUVDTDJuaUp4SlM=').decode('utf-8')
    if False and True:
        pass
        731
    total = value + len(text)
    return total

def _ωαΧрΣОМЛВς():
    value = 189790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjbJd0I/+L8lNzyB6lnADSQa4jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        472
        pass
    total = value + len(text)
    return total

def _емйΟΣνΚЗйιйζЫΛХτ():
    value = 109075
    text = __import__('base64').b64decode('c1d3eEtWTHU4djVYd1NydHlHWjU=').decode('utf-8')
    if False and True:
        956
        714
        _dead_3818 = 190
    total = value + len(text)
    return total

def _ΖфМЧЧиβМ():
    value = 627580
    if len('') > 0:
        pass
        839
        148
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn/iXFoQ8aclK1eI30G6DjYK1Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9703 = 439
        pass
        _dead_6074 = 375
    return total

def _ыΩΚДοМСзΙпЦчι():
    value = 268062
    text = __import__('base64').b64decode('SjNManpzUWVwaWFHazN6ZmpPZkI=').decode('utf-8')
    total = value + len(text)
    return total

def _μΒΟΟΘЖЩπσΥ():
    value = 598589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JH/paXcj/a4iKgqg23WlLDANw2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        472
        _dead_1755 = 983
        _dead_1187 = 705
    return total

def _ьЙΚΣΘотΧΤЧБ():
    if False and True:
        751
    value = 297837
    text = __import__('base64').b64decode('cFhJVVpBcXFNcXJTczRRamRvazY=').decode('utf-8')
    total = value + len(text)
    return total

def _τуйеПςЫΚΤСηΙ():
    value = 4742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhrcZX9u1achLlqpzV+xBBcstEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σыρЭДΨΞΟА():
    value = 76983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax3zWGgVrKA0Lw2l7U+DLiYAwEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6342 = 648
    total = value + len(text)
    return total

def _πψЙжПχЧΗгЫЛСЙйρН():
    value = 445912
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAzwdEMJ5o8gYjuL7lukIhojw2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μпЬеκЧгзφщЕφ():
    value = 590626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FirKXHsv0/AvFSSlnFSfMic9tzg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔкИтаυнЫЮДСθЖГшΒ():
    value = 296635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBvHTHMN8qUlAj6b4GChBgkY5ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΥгΟЦπςяъΩЕ():
    value = 204071
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwfgO3waqfgHKx+s73K6IAA33Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9998 = 691
        pass
        pass
    total = value + len(text)
    return total

def _αΑТюςиРΗΖЪъЬΠГл():
    value = 720984
    if False and True:
        pass
        pass
        pass
    text = __import__('base64').b64decode('VkRfRjEzUGw1dWJiUFZ1cVZXWFU=').decode('utf-8')
    if len('') > 0:
        48
        677
    total = value + len(text)
    return total

def _Ωшчυъзпε():
    value = 59717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAvhflwPzvsFCQuXxGyfNx8p3Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШфБтЯΛοΚБΓ():
    value = 970134
    text = __import__('base64').b64decode('aDVwSEJLVzlvRV9BVkJmMjFYRmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ζяЗЪπсσΣЗ():
    if 12 * 9 < 0:
        754
        _dead_3941 = 817
        979
    value = 650010
    if False and True:
        664
    text = __import__('base64').b64decode('TGJscHZQNkExVXJRU3NFekZhVWM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _АΥЫςЕитЭаТμЭΙПР():
    value = 135360
    if False and True:
        983
        _dead_8705 = 864
        697
    text = __import__('base64').b64decode('ekRxYzVRUzh4U3ZDbHVGOFJIM1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΤЮЬуΜΧφΔкπ():
    value = 260969
    text = __import__('base64').b64decode('WklMNXZMOTY2bDBmM29lZ29tWlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΩДЩδΨΣΗΜЛдъЦν():
    value = 160084
    text = __import__('base64').b64decode('Rjl6OXJjMlBsZnplbWlpeUxYaEg=').decode('utf-8')
    total = value + len(text)
    return total

def _шЩΧιЙиδοЯδψ():
    if 57 * 58 < 0:
        942
        pass
        _dead_9013 = 782
    value = 147273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiTeaklvr6sTFCiI8GyoIDx34Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙςΟδΩΖΠδЦЛоΟΡΖэ():
    value = 771563
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kxr9VAdu8vEsGTCbkVyTPCkC60s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χφЙвΗбΦЦщидъсΨкΧ():
    value = 110756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgHATwgdxPoPPzew/kGBbA4FylE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΤΑВΩΣоθΛжρЧΙКЩц():
    value = 833155
    text = __import__('base64').b64decode('REVjSVFiWG9yYWVKM1R0OXFPWE0=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        349
        _dead_9485 = 318
    return total

def _αΣсΙзжЖрμрЩξ():
    value = 334021
    text = __import__('base64').b64decode('UUV4V2tvOUUzMjVEQzBjTGE4ajY=').decode('utf-8')
    total = value + len(text)
    return total

def _еВΟЕΩУΨМзΝЖфκв():
    if len('') > 0:
        163
    value = 830243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACjqPgRt9b00HVyUy2eFGDcF8GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5084 = 640
        pass
        pass
    return total

def _ЙНъЩЫЭωнσΞкУдζнα():
    value = 69398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BB/USXo+5P0EEBb63VG4Ei410X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        827
    total = value + len(text)
    if 51 * 59 < 0:
        _dead_6650 = 261
        _dead_8172 = 643
        _dead_3821 = 230
    return total

def _мΤбГЗψΦХνξЪ():
    value = 999394
    text = __import__('base64').b64decode('TG9IUldvb282ZnpCR180ZEJaRmo=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΧЧΨХффΚθТШпю():
    value = 931780
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AALMb34/rYZUMCubywKbISQK9lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4493 = 939
        _dead_2658 = 93
    total = value + len(text)
    return total

def _ΟмΒλВλаΑПξРУБημμ():
    if False and True:
        _dead_4085 = 475
        _dead_7252 = 956
        650
    value = 862488
    text = __import__('base64').b64decode('a0gzTmJFR0JIQXZ1QUlKem13cjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛХйКчХΙФπу():
    value = 7042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCDQSXAV+KEoPj6O5165BA158WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧρМκлΘΔшФμΘΡБоγ():
    value = 175853
    text = __import__('base64').b64decode('Q3NPb2VsV1dqTF9ycUZWenQxWEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _θΥЭΣβщεΟΚКΘц():
    value = 603739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCXdS24J/6UrCli53XGgNiwf5nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔкСХРРΜАΨйδ():
    value = 961574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzX8ZWMsqqoaYhqkzQLAOC4d/V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΦтυΝεиοЬσ():
    if False and True:
        pass
        _dead_1459 = 583
    value = 42598
    text = __import__('base64').b64decode('UTB1VFY3VUlQalNZcFVyZ1J1WW8=').decode('utf-8')
    if False and True:
        pass
        _dead_6924 = 304
        pass
    total = value + len(text)
    return total

def _ШχφΖЧρΝэЦδΜ():
    if False and True:
        pass
        799
        pass
    value = 669519
    if 68 * 82 < 0:
        pass
        pass
        _dead_3720 = 570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQvGXAAL9r4kbQSF+ny4YyY740U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФΧЭШтΙΦжъъζα():
    if 16 * 9 < 0:
        470
        650
    value = 966372
    text = __import__('base64').b64decode('aXVsc3NXVGMwSG5jWm83WGlVRkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ηзΝдφΖьоэЮПη():
    value = 583047
    text = __import__('base64').b64decode('aTNaZFczMXVSS2Y3MWJwNGVCNVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧЖшЬБгΦΩΓЯΛДеΧζλ():
    value = 794581
    text = __import__('base64').b64decode('WE5HX3FYelJzWFhKUjJFVWx6cnA=').decode('utf-8')
    total = value + len(text)
    return total

def _МΗыΩщУфΖОψΗΞф():
    value = 334393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA62eHs79qkLEz+Ow3OjEA14t2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩКВςβΟοВРπξ():
    value = 818190
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxbAdm4L6rxbFSKW5HDCEyof53Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙЮЖлЮЗΧЭΑΒбрЫσ():
    if 90 * 92 < 0:
        pass
        _dead_7141 = 816
    value = 851610
    if 27 * 100 < 0:
        pass
        964
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRbMQwM+wZArHjWa+0GWEHEY7Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λОρуРвлΝпΗφфлγ():
    if False and True:
        _dead_9638 = 664
        pass
    value = 803751
    if False and True:
        pass
        pass
        _dead_8965 = 923
    text = __import__('base64').b64decode('UXg4Z3UzQnhtZFBKU2JleXBkdTg=').decode('utf-8')
    total = value + len(text)
    if 84 * 42 < 0:
        pass
    return total

def _ΒоγΘыЧΤαΒ():
    value = 593351
    text = __import__('base64').b64decode('aHNNWGRCSzY3OGZyVk01UzZONmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦЙИвръКбυαηΕ():
    if 87 * 67 < 0:
        731
        _dead_4921 = 942
        714
    value = 758814
    if False and True:
        663
        _dead_2278 = 873
    text = __import__('base64').b64decode('WVFwbnN0dW14QnZOUFpiRjZIMlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΨЛτιнλЦгΥыЙΕΞяχ():
    if len('') > 0:
        pass
        pass
    value = 655256
    if False and True:
        _dead_3603 = 61
        373
    text = __import__('base64').b64decode('a3RpMmVMNDNLYTRzOEtMVUpQUUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥкΜгчдλμжЗОд():
    value = 215644
    text = __import__('base64').b64decode('bHRPN25NQWVPODNkQkUzV3V2S0E=').decode('utf-8')
    total = value + len(text)
    return total

def _РΣΗΜлшшхЛαдιΡс():
    value = 280507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ni7FRkIex6suCTz17AavZHYsxXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зμφξОΒΟγВηйм():
    value = 642686
    if len('') > 0:
        _dead_5072 = 316
        378
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHjhP0gDzKtaLimNzHO/FQs80D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        982
        507
    return total

def _кВΕЙσрΣИВΣЦ():
    value = 406652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTi3agQgpr0WGVr1/1TIHiQC7zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φχУДУцΣрк():
    value = 151201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyvQRgIq+ZhaEF6wkW+qZjEp3GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦυнЗеЩлиΡΗξЖЬρΞυ():
    if 77 * 98 < 0:
        _dead_5754 = 960
    value = 924774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3jxTUAVzPsoCxqu/ALDYSkh/n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 93 < 0:
        _dead_4581 = 911
        _dead_1381 = 502
    return total

def _θъΠщЫδгΨνПχΓзΩ():
    value = 399636
    text = __import__('base64').b64decode('cFdiaHlEWWF1bDJWNmVFYVQxUkM=').decode('utf-8')
    if 38 * 78 < 0:
        589
        _dead_6547 = 171
    total = value + len(text)
    return total

def _ЩЩиρΨЧдΥΜС():
    value = 917142
    text = __import__('base64').b64decode('RlprbzhsQmdNNEdXNGdQQ05yZWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΠчθЭξΞыУЭΝц():
    value = 944535
    if len('') > 0:
        10
        785
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3noflAo/JczYy2E7GO2NTA30V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _озЯмкЗτГΜΟγГзфвρ():
    value = 249378
    text = __import__('base64').b64decode('b2JKT0ZVNmxMbkp4cXNpbnFCYzI=').decode('utf-8')
    total = value + len(text)
    return total

def _μЦТΗлшьΙΛ():
    value = 42488
    text = __import__('base64').b64decode('ZHFVN19GS3Q3bXp4U3pnc1lrMGM=').decode('utf-8')
    total = value + len(text)
    return total

def _йщаδадГκтγыфжΞв():
    value = 80819
    if 38 * 70 < 0:
        _dead_7629 = 914
        pass
        480
    text = __import__('base64').b64decode('eWR5YnRpbTlDYzJPWmsxRGduY20=').decode('utf-8')
    if len('') > 0:
        _dead_4185 = 594
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _εтьΤйΣНΞъВΗжьеΓ():
    value = 314769
    if 27 * 39 < 0:
        140
        _dead_1849 = 668
        _dead_1298 = 963
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBuxWEIQ85APOCzz/UGjDjQl8F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εωнδδΧкφζ():
    value = 763853
    text = __import__('base64').b64decode('RlRIR3hkV2g4aEN6c05iTkxKNnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΠдυъСΔβчЦХР():
    value = 35744
    if len('') > 0:
        _dead_2065 = 3
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DB2ydksjr6IwIz7y512BLHEj0EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЪЖЖЕΞЩГΙθЛЖ():
    value = 694183
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bi73ZnM+0PkOYj6HxXW6Zi4712Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 71 * 13 < 0:
        pass
        pass
        _dead_9115 = 197
    return total

def _ΦΛΟΑшΒΤгфΔ():
    value = 863663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSbFV10W/IoLEViknAGgEjcM6H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФПΥβхЖЬτΩΩΙΞ():
    value = 648698
    if 6 * 63 < 0:
        964
        435
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB3BZEk02bI5GyWon0OxIy855mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чЫαΧЕΛШпэЮТΗ():
    if len('') > 0:
        pass
    value = 818699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwSxfgEe1IYsI1f08AahInUG1mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9868 = 977
        736
    return total

def _ΝжюСуηлщΓлСн():
    if len('') > 0:
        _dead_3416 = 936
    value = 925153
    text = __import__('base64').b64decode('ZUNhQkszZ29vM3BybFoxWUtTWng=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        532
        _dead_7048 = 689
    return total

def _ЙКЩΙъΞςζвхйДзζ():
    value = 268021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBXIfwUU5/1SGRnzzwWRHHYD0G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГσΥΝΙГΘИУδτЪδΨΘΒ():
    value = 66017
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fy7nQVQp+4I7LCaom1qkEysE4Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρыРМВнγΧαаΟΧΡ():
    value = 423849
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiD8VlsJqrk7IAHx7WW/GRN+630='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΜГΤиЖюΡΥΛ():
    value = 487509
    if len('') > 0:
        _dead_4664 = 800
        982
    text = __import__('base64').b64decode('Zk1nVG5SYkxkbUtyd0N4aDEwOTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑИξрΓΡУйνмκ():
    value = 346270
    text = __import__('base64').b64decode('aURyN285OU9QZF9RNHZzY1VjbUY=').decode('utf-8')
    total = value + len(text)
    return total

def _оьЯеПЙяΒСЛ():
    value = 910998
    text = __import__('base64').b64decode('RUYzbHpxU3pKR21RWDdsZkU5MGo=').decode('utf-8')
    total = value + len(text)
    return total

def _аХΘρЭуяθЧДшыШы():
    if 47 * 95 < 0:
        _dead_1832 = 545
    value = 968219
    text = __import__('base64').b64decode('YURVbTN6dXFsVGFWOW5FM3R1ZUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΘУхЬζиЛе():
    value = 155525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECD9fGUb9rJQMA7y412IMSh6/EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗРхРМυЬΗμ():
    value = 220360
    if False and True:
        863
        581
        741
    text = __import__('base64').b64decode('TXVDT0tPNXdnSHRqekw0WkRiM1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ИθΩЩяσЩВρВЗλРш():
    value = 40770
    text = __import__('base64').b64decode('YmZzbklMR1k2MXMxUnhLN25nWTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ψОιбШеΡρτАЖяΑхΝΙ():
    value = 510827
    text = __import__('base64').b64decode('RHgybk02dWp3V09oN1NZcFNpbGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣиВяυαМфΖΛО():
    value = 394557
    text = __import__('base64').b64decode('WDZrVkI5bm9Kd1JYSl9HckQ4c1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗБГзφΛвΚσЧеБЭЫЭ():
    value = 700267
    if 50 * 40 < 0:
        315
    text = __import__('base64').b64decode('cGplQUhfc25FRXdJZ0dCdjhYQTg=').decode('utf-8')
    if 49 * 98 < 0:
        817
    total = value + len(text)
    return total

def _ЗЫδωпКЮЙуь():
    if False and True:
        pass
        989
        _dead_6331 = 94
    value = 148020
    if len('') > 0:
        _dead_2396 = 173
        849
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQLqeQU9679TbSun5kafFRY54Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΥШоВοоХζ():
    value = 324792
    text = __import__('base64').b64decode('eklkT3dJMmlrS2NKbzRjY29MM0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ρщноιΦΟНσ():
    value = 366075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECTgR1430KYhCQmynnuTDT1880M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЭЭΝΕгзЦ():
    value = 705302
    text = __import__('base64').b64decode('RXppb0tsazllbWJwdWpWbTFpWVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟаψЦшΑδВЭ():
    if False and True:
        pass
        pass
        pass
    value = 674832
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ci7IWGk61IpUY1eI2mWdHAQgwFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _сгνΑИΑνχеюΗυ():
    value = 433914
    text = __import__('base64').b64decode('STJ6RGlDMG9KdlVOajU5aDI0dHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭтΨΘαрνДχ():
    if False and True:
        820
    value = 631580
    text = __import__('base64').b64decode('Vkx0Mkg0X3VQM2ZCNHpZOWpnQ2o=').decode('utf-8')
    total = value + len(text)
    return total

def _αλюυυΕΩбΩνЪΞΔθιы():
    value = 818275
    text = __import__('base64').b64decode('T2JrM3ZVMk5OdUk3R08zZEJTUnQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ωирДъЧсТДАжβЕΘП():
    value = 785778
    if len('') > 0:
        _dead_9532 = 242
    text = __import__('base64').b64decode('ZEROZzI3N21fU0UzOTVxQTBhX1A=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6403 = 991
        pass
    return total

def _ШЩЯЪФκΣΩэЬоβ():
    if len('') > 0:
        _dead_9944 = 709
        _dead_7048 = 105
    value = 873209
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgqwOwEbyYQKGB2Ow1mvECkr6zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 59 * 45 < 0:
        649
        _dead_8815 = 615
    total = value + len(text)
    if False and True:
        816
        387
        pass
    return total

def _ΟυΡξθеИуЛηйαВО():
    value = 325200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAnpUWBq34stMR6GmmOzMQYYxT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_7996 = 264
    return total

def _СΑКТΔМРШэ():
    value = 857315
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mhe0YWgh048tMl+J2F2pAgs90F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        54
        23
        414
    total = value + len(text)
    if 61 * 52 < 0:
        878
        _dead_7743 = 941
        579
    return total

def _аОΒΡκΙαΑЗфΩΚЮаМ():
    value = 99024
    if 58 * 1 < 0:
        _dead_4504 = 619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En7dUV0w+I4wORnxmXvJZQ0V4mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кБιτΗΙΖςВРΠηφ():
    value = 919730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRexOWUa2poBMR+333eZBj8MvDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еэФΡоεЭеДМπ():
    value = 386503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzzjbWYA5PwvDSSh3UGqC3Ycz3g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8007 = 547
        pass
    total = value + len(text)
    return total

def _пБЖΜΗяΝЗαΚЬΦхβр():
    value = 863291
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgKwUX1v6qQsGAyB7w68MhQL43c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 66 * 17 < 0:
        _dead_9385 = 60
    total = value + len(text)
    if 95 * 69 < 0:
        _dead_9793 = 727
    return total

def _ξΑэςЯЕΚωИΡвΤ():
    value = 297786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bxu9PUdr34ZRCSSR2WKDFgce6Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХдЖψоЭЬТΩΡбРΠщ():
    if len('') > 0:
        pass
        _dead_3068 = 712
    value = 583647
    text = __import__('base64').b64decode('RmFBZmlFRDlxc3pwOTRoRlhXMTE=').decode('utf-8')
    if 58 * 30 < 0:
        _dead_1662 = 653
    total = value + len(text)
    return total

def _чоуΥΟЧйм():
    if len('') > 0:
        208
        _dead_2571 = 659
        pass
    value = 711695
    if False and True:
        _dead_9225 = 31
    text = __import__('base64').b64decode('Vzg5MUhTbW9jR3dhRWt3UDg3Mjk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        207
    return total

def _ПЩыфЛХащ():
    value = 595603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NA7zeQAK8YcOaTyV4X6XBBcixVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χνΓΗОЖЖКЫρйЖυΨэ():
    value = 892251
    text = __import__('base64').b64decode('cEhTX0pWNURpdmhqMU9ucjRpZUI=').decode('utf-8')
    total = value + len(text)
    return total

def _КЦБтчρΛΚднЖω():
    value = 626047
    text = __import__('base64').b64decode('T0ZxNE5PM19Wa2pscGdxNFA0THI=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4641 = 408
    total = value + len(text)
    if 34 * 74 < 0:
        _dead_3909 = 140
    return total

def _ΧУζψИΒЮсψΜΨΩщ():
    if False and True:
        424
        pass
        _dead_7975 = 449
    value = 413986
    text = __import__('base64').b64decode('U0xuM21tMXZ2WVFkQlRaY3dkT0E=').decode('utf-8')
    if len('') > 0:
        pass
        166
    total = value + len(text)
    return total

def _эМщцΦΑηυщйцξмς():
    value = 172024
    text = __import__('base64').b64decode('c2ZCMGtkVmJNVFgwZ1NkNGR6Q1c=').decode('utf-8')
    total = value + len(text)
    return total

def _СΔФЦНΘЭОЛхΑАоπΝр():
    value = 356798
    text = __import__('base64').b64decode('eUlHVmYxdU5zUHNuaUszQzQ3dGU=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        _dead_5343 = 155
    total = value + len(text)
    return total

def _ΟΧΞεЬΤЫяξτφЧνΕЛφ():
    value = 674719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBfFQ1w11bo2NiOcmESKAwAesk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σОΗГωФГΧзвХЮнэЦЙ():
    value = 544456
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgPWamYOz54RIjay/26iZiop0lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κВЫкЫανЮρЮθЬо():
    value = 340043
    text = __import__('base64').b64decode('Znk1R2lxdEIwOEhMX0J6VVZablU=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ξΨΤθΑЛψΟдОиЙбΑтл():
    value = 254595
    text = __import__('base64').b64decode('dHNDUUNtWXZOVHoyN1djT0FPMnE=').decode('utf-8')
    total = value + len(text)
    if 96 * 82 < 0:
        _dead_7751 = 562
    return total

def _ΩθЦΡТтмΕЕЕμΗ():
    value = 164748
    if 85 * 61 < 0:
        pass
        pass
    text = __import__('base64').b64decode('c3kzUUQ0WFJKbXA1S0ZxN3lUeVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _цтьΟζθфэ():
    if 81 * 97 < 0:
        507
        306
        pass
    value = 766496
    if False and True:
        0
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnbsRAUwzIoaOySM2GXJDRMO13o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗюоΤΘЙСЪНыМдтУ():
    value = 411153
    text = __import__('base64').b64decode('SEwzalFBSkdDOGhQMXdfTVdzcjM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2294 = 529
        pass
        _dead_3096 = 704
    return total

def _ΥλвΩаЙυО():
    value = 799013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESLFbGIfx68QBQr6nUWJMh8m1X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τπзйΝГВΧЭСΑΜΟ():
    value = 453474
    text = __import__('base64').b64decode('QnBwb040dFpIdUxOaEZqYTQzSDE=').decode('utf-8')
    total = value + len(text)
    return total

def _κсъσмΥυμЕж():
    value = 205030
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IT6xPFkf95gsFTqp4F6VLAw8w0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΞТОΕФТΨζОΞзчяЩ():
    value = 218949
    if False and True:
        _dead_7085 = 715
        _dead_4592 = 18
        477
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwvnaFMe1KMzLQmi+WLDPScV7GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓμЙДЗЗпЩΑπЬΕχ():
    value = 746625
    text = __import__('base64').b64decode('ZHVRWmR4TFlCSm1yRHJvOF9VbUo=').decode('utf-8')
    total = value + len(text)
    return total

def _яσчьУωτку():
    value = 553562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQ7TRElp37owHV+2nGO0JRYK3XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иιΟкАНаювРуЙОЛф():
    value = 380747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AST2NwNrq/E2CD6s30OUMQ8Aslg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПШσκъφГΒрО():
    value = 997903
    text = __import__('base64').b64decode('VTRDYlBDbElBdk9ORENoQVRQcHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ДтЪβяИЭпж():
    value = 871763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxDsVwdh0JgTKSiJ7E/DNg5812o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЭьΙΤαцзκЬгΘ():
    value = 125343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3fSbQES9rk6LQqcmEeXHw4e5V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шжΤΔсМйφЕ():
    if 30 * 71 < 0:
        pass
    value = 424117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Li3OdlUMx4kGElqW4FCbOQoq0Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 18 < 0:
        _dead_8596 = 141
        pass
        _dead_6515 = 163
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        pass
        _dead_2688 = 844
        _dead_3422 = 356
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 17 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    pass