#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _МτηЧМΡγмΙΓΣ():
    value = 223442
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBbrOQYyyo8RLiGtnV+BNiIjyDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒдныЯАсЬу():
    value = 97236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiT+XUgd/bEBYwGJ/kKbJn0m/Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эЯОНПтЫГΦиλγнК():
    value = 790223
    text = __import__('base64').b64decode('cncwenBoeVNFUDg5ZkRNQkFfRng=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪлхφмυωУ():
    value = 745156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABzxeUUXq/8QBR6K8kS/BQkK7Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШТΖΦэρΛρС():
    value = 893184
    text = __import__('base64').b64decode('aWZSQl9WSHNaT2ZmQWo1eHo0ZXA=').decode('utf-8')
    if False and True:
        614
        pass
        pass
    total = value + len(text)
    return total

def _ΒЧυОΗиΙω():
    value = 435466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bi7gOAYg9IItazCOnUKSOH059EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        882
        pass
    total = value + len(text)
    if 100 * 69 < 0:
        pass
        _dead_7482 = 991
        pass
    return total

def _ΝΩэцфξΛΨСΖΠлΥΙΓφ():
    if len('') > 0:
        287
        _dead_5963 = 111
        pass
    value = 820212
    if False and True:
        _dead_9076 = 306
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HziyN2c925oLazmX6VnHJwAE21Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юτиЖЗтΦΨσЕΨмЬЖЛь():
    value = 886722
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('dnhKY29QdXltbV93NnBNVzBzSm0=').decode('utf-8')
    total = value + len(text)
    return total

def _уοЫчтοχΨэЛςАΖΜзю():
    value = 696807
    if 52 * 7 < 0:
        pass
        pass
        696
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiLSegcJ970sAiyt0WSEAiMCvEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лфуКРчΒЖΘΤЙΕВγз():
    value = 15878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTzpO3QG560UFDeQx1iBMDEQyDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηιθъЭβьМу():
    if 93 * 96 < 0:
        pass
        _dead_9575 = 569
        _dead_3482 = 660
    value = 256703
    if False and True:
        _dead_9626 = 306
        _dead_9947 = 788
        _dead_9574 = 507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyTdV2IT7q8xKzeIxQCHLQw150I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖσшΡБζЗωо():
    value = 301740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwXGXXou/Ys6bT+3mn7IAHU77GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чКΑФЧКΔπΕ():
    if len('') > 0:
        pass
        pass
        87
    value = 839810
    text = __import__('base64').b64decode('VlN4cWc0TVdFNnNOMEl0bnhaZVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _НΣλΑΙудЗΗШаЧюЧ():
    value = 742922
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhrveWgDrYxXLBj1+mHALnYNymo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φξΟΧхμкρ():
    if False and True:
        _dead_8602 = 915
    value = 99901
    text = __import__('base64').b64decode('RG44Qjh0U20xUEVDUk4zSk9PdUM=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _φΦтЯψπΦЩУюΚАψыκо():
    value = 925753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhaweWUtyLBbAiqr2nuXHh8J80Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пюςΝλЧЭΙфΑшΡ():
    value = 270610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHzqZGMv0rIPaQ6g7GW5MDwu1X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПςκкзБΥΤΨЪИΤВэЦЕ():
    value = 107451
    text = __import__('base64').b64decode('UHpOQk5aWXBXeUNGWVo4NzdxNE0=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _хяΒЮβТцмъχтДКо():
    value = 525135
    text = __import__('base64').b64decode('emdZVDBwdTJhT0J3bU9IcWZ1RHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕкшЭΖθγιуΔΠбπ():
    value = 934909
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSDxUUEX8J9aCT7w4nqeEnwmy1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уΗαΙνуπωσυГ():
    value = 658892
    text = __import__('base64').b64decode('SGh0b2gzN1NUUjZ5Mk1JenFWY24=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦВЮυМЭЛУτзНΕ():
    value = 617490
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISnMSHcUz/w2GCWF+nWYYjUo6jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 35 * 88 < 0:
        _dead_3687 = 295
        19
    return total

def _ΙДГпяОΙрγπΦ():
    value = 812732
    text = __import__('base64').b64decode('UHVZRXFlUGNxeTlkT0ptdkRhZVM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        576
        _dead_5485 = 8
    return total

def _ИъφАдйпηоч():
    value = 462971
    if False and True:
        _dead_1164 = 573
        59
        628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTfAN3Yp6ZwXMDCGmnC7ARcBwG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яНΑηсЧΩλъ():
    value = 454588
    text = __import__('base64').b64decode('RURxQTRJRTAzcXpGSTV5cUl2dnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _цыΑСеПνΟф():
    value = 829123
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXvuVHQhq5wpbR2knXevGQc7x0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шЖβьГПдюΚжγΜ():
    value = 801180
    if 10 * 54 < 0:
        237
        _dead_2629 = 352
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR3NQn0S37wBLRi07lGpJHM/s2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        565
        312
        866
    return total

def _РΤСαдКаΥΡγΑьгνжΑ():
    value = 987329
    text = __import__('base64').b64decode('b3IxMVZhd2tZNUFyMWQxWFVVTDM=').decode('utf-8')
    total = value + len(text)
    return total

def _мЮАлчΠЧΕΗ():
    value = 113262
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDz+f0ERq75XYweNmQWKEgAWtGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψЫргогδПΚΦэρ():
    value = 142429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnjKRkIGyK0LLASb707BbSh9sks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШЩУЩιыΘхΓСШЕЛ():
    value = 249362
    text = __import__('base64').b64decode('azkzdTVxNEVnMGwwOEU2Ql93ZHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨЙУуРРьщΞичΑφτЭζ():
    if 65 * 85 < 0:
        34
        _dead_9842 = 900
    value = 916598
    if 97 * 68 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jwj2RVZp9/EZMC2VxW+nGikF5j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        779
    total = value + len(text)
    return total

def _ъζиΛιΛРВюιфш():
    value = 4116
    text = __import__('base64').b64decode('c1Nlc0dTZWd0VW5Ia0FENnNQVjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫЦзΘΘфФΧЧΕορШβ():
    if len('') > 0:
        pass
        _dead_6393 = 701
    value = 310931
    text = __import__('base64').b64decode('QVJZcDVoTElEbjltTjIxTExfVE0=').decode('utf-8')
    if False and True:
        701
        _dead_4447 = 757
    total = value + len(text)
    if False and True:
        pass
        829
        _dead_1244 = 668
    return total

def _зАЮΕΚТЫμΞэηЙОгАΝ():
    value = 795914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgnvOmQ73fAtLCOQ3QS4OA5+x2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        609
        pass
    return total

def _ьОЧψσΧйΑкΣбδоΠτ():
    value = 616077
    text = __import__('base64').b64decode('SzVOSlI4NVhuem5yOTNxQWZXc1E=').decode('utf-8')
    total = value + len(text)
    return total

def _βρκхЫЧτбхΓгΩзХΠ():
    value = 344470
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('b0lwTDU4R3FKUXFVSl9qaU56YWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦεσΒςСЗЖρπΞмηС():
    value = 723028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DST9XUEv0fAHLyibnUWCbCYd10w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψшςθСοχξИ():
    value = 637190
    if len('') > 0:
        _dead_3339 = 585
        pass
        _dead_8505 = 255
    text = __import__('base64').b64decode('a05OYjJ6cDE5aDRNeEYwclJBZEE=').decode('utf-8')
    if len('') > 0:
        833
        _dead_2522 = 892
    total = value + len(text)
    return total

def _ДЪнπβравБмφΛТΣ():
    value = 782211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQOxV0IRwasSCg6t51SybQIc134='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8811 = 528
    return total

def _УюхпдвγιУЫρЫЬτО():
    value = 400507
    if len('') > 0:
        91
        pass
    text = __import__('base64').b64decode('U1ZQaTc3amZvZU5hMXpaNHNHU1Q=').decode('utf-8')
    if False and True:
        pass
        _dead_8651 = 331
        243
    total = value + len(text)
    if False and True:
        _dead_4363 = 369
        979
        146
    return total

def _ΘуΘЦδΑρяй():
    value = 125951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH7NeFQK9fsUMCWV/GSJHRMQw0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 99 * 100 < 0:
        940
        _dead_3218 = 649
        982
    return total

def _ΙэηЕИΨгЩοξЗΡΕЫ():
    value = 880987
    text = __import__('base64').b64decode('ekI0TktkdkpOSU1EcFhwaktPUlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ТκσЛсДшАθн():
    value = 638124
    text = __import__('base64').b64decode('ZlIyN1EzS3VWSjU5UDRHcDFQSmk=').decode('utf-8')
    if False and True:
        pass
        747
    total = value + len(text)
    if 96 * 7 < 0:
        _dead_2343 = 477
        432
        375
    return total

def _щЭΠΤяφЖкΕβъ():
    value = 755994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H321bHIUxIEJbivx2gO0JnMfwUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τиΥιςΒчпюςыΨЕΛУπ():
    if False and True:
        152
    value = 942077
    text = __import__('base64').b64decode('dEpTbElIakhTSmtNSWIyeUdJaEI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9725 = 413
        601
        186
    return total

def _ЬаΙШкΚИκΔРΙцεВъ():
    value = 751532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lg7zN2Nq76AXbSGi2n2eYR8lwXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ющеиаΑχχУУΞЭΜЙΘФ():
    value = 591522
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXbzf3Ys8p48BSSPnVWdFQAc5z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΩуфСрΚДΘφж():
    value = 154869
    text = __import__('base64').b64decode('dU15N1JTMnBQYmhaeUgyeWJ6Y1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡтОАДхЙδЧΦ():
    value = 372172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix7lWmIA2o0wYx+Xxw+2PgYY3H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        804
        255
        pass
    return total

def _жДΦВЛωΚΜΦЙΜγ():
    value = 491144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IC3vbEAQxKMwFiu14mzCAz92vH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыьΥφΨπив():
    value = 351732
    if False and True:
        pass
        _dead_9754 = 541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny3sZAAUrLAmAjy2w2avOiQG1kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φξθНΦλРεψ():
    value = 879015
    text = __import__('base64').b64decode('cWtENmFBdnhrRXdHdVJPaWVVczk=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΘэρхΡрмμΕуГЬ():
    value = 275722
    text = __import__('base64').b64decode('T29ZbVB1YWVBUUFQR2NCU25zN18=').decode('utf-8')
    if False and True:
        pass
        _dead_3805 = 177
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ХАхιζыэйΖТЦ():
    value = 370221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRDMYloc5KcRCVec4weTFyMk/Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ХАЕэχθжνрρρНтΖв():
    value = 228788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDbDbFM03PwwbluRwVOBOg423Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        572
        _dead_4510 = 6
    return total

def _фОаμзьТЪ():
    value = 783390
    text = __import__('base64').b64decode('czhQWXAxazZZRXFUYkl2d0xhaG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЙΜΗТεςαцмωπобдй():
    if len('') > 0:
        801
        _dead_2647 = 638
        _dead_2399 = 692
    value = 48486
    text = __import__('base64').b64decode('SjQyTTlZbG5VN1BHeVRENHFKUno=').decode('utf-8')
    total = value + len(text)
    if False and True:
        637
    return total

def _ΖиνЬУвΟοФлΟюЪоЙ():
    value = 861972
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHqyOnAyqoMRMQKZ6kfBPwws5ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оЗυωκдЫΝηφЪεЫβ():
    if 58 * 66 < 0:
        _dead_1574 = 707
        157
    value = 292916
    text = __import__('base64').b64decode('RXlEclp5VGJpcVRoR2NHcUhJbmE=').decode('utf-8')
    total = value + len(text)
    return total

def _вСГвξυфΔΝΔ():
    if False and True:
        pass
        _dead_1025 = 623
        120
    value = 426703
    text = __import__('base64').b64decode('eFFlMTNzSnVNY0lxbEtFZTZXbVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕАθМΒπуйυΑЬα():
    value = 377906
    text = __import__('base64').b64decode('aTBDX0tDS2pCMWthRXN1N21fTGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЛУτЬОЭГЯΗ():
    value = 467025
    if False and True:
        pass
        _dead_6441 = 817
        pass
    text = __import__('base64').b64decode('eW9RMnNzT2xoZVc3NUxxcXllOUo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        300
    return total

def _ЬЛМэцΧΛЬΦКсΛ():
    value = 575372
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECnUdlI3zYEROw220Ge8ETMD8nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НЖОянπνЩλиЫυЗш():
    if False and True:
        pass
        _dead_9178 = 940
        _dead_4994 = 418
    value = 965579
    text = __import__('base64').b64decode('czlxa1ZWS04xZDU1Wk9pVkxWZXo=').decode('utf-8')
    total = value + len(text)
    return total

def _ШьΤиФΝеΥοιοДΣяΗΠ():
    value = 969173
    if 43 * 39 < 0:
        _dead_9130 = 244
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyayOnNq3PwBYgezw2KeJzMaxkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕъВδТΞςСЗИ():
    value = 321169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CR71RQEJq/0KY1e37UKXLA8/tDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вξДХДЭφχАψΟСνэж():
    value = 802112
    if 48 * 29 < 0:
        _dead_1465 = 883
        _dead_4891 = 633
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cx7zfAEsp6cCHziPwX+RMwwn3VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΛΝоНВХбЯЭΜЛψЛр():
    value = 925506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExXReQZp9qU0KQ2xwAeAYTw4wEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лμΔхΑυьКΝαФβΜьбΗ():
    value = 280698
    if False and True:
        415
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAfmb1wL9KESPw2L+Vi/EQIItmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΙΧΖΑэРЕЙΗ():
    value = 697181
    text = __import__('base64').b64decode('S0VMVHN3ZjRzU0t4OFRQWFl5UDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ПУΑθижαΕ():
    if False and True:
        _dead_3030 = 788
        _dead_5623 = 703
        986
    value = 913055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICHTVmkqraIzMFmS/HO4DhM26mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΥισПцηЖрυАΜгд():
    value = 427942
    text = __import__('base64').b64decode('VEc3RmdhQ2NBNVQ5eVhUWFRnSW8=').decode('utf-8')
    if False and True:
        347
        585
        596
    total = value + len(text)
    if False and True:
        527
    return total

def _ψΕеНлЛуωНψΛъΑаΑ():
    value = 309580
    text = __import__('base64').b64decode('QTR1TXRYMktqcm5PRnNXU2ZZSDE=').decode('utf-8')
    total = value + len(text)
    return total

def _θвΔЩΜΖвι():
    value = 552043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AD70RGtv9JkvEjCOykaWbCAl/Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПщЖηηςΞи():
    value = 32453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiTHWHUp7qMHawHyxF2gMC98szc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИЙзчШУΞηΟХгε():
    value = 921210
    text = __import__('base64').b64decode('dDlnMWhSNXlEbGNoaXoxelVFMG8=').decode('utf-8')
    total = value + len(text)
    return total

def _зχоΙХМЬβρΛεΖρъГΤ():
    value = 252889
    text = __import__('base64').b64decode('WHltbTJpcVZCaWxicXpxZV9hdUI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΤνЪЙщЛкФ():
    value = 410280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXvCO0I7rIAVNTehngCxPC89sz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _лΛИΓευеΦ():
    value = 713847
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISjsQnIG07spbTCi4nCHODAkyW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        302
    return total

def _ЪβсЭОсНгКд():
    if 42 * 26 < 0:
        900
    value = 364741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxfXWXZr7rkBMQSE5QPJDncX01s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μΧΧрдьРΞЕыъβ():
    if False and True:
        352
    value = 654187
    if 46 * 1 < 0:
        _dead_8968 = 32
    text = __import__('base64').b64decode('aDN0b3VvMFZ1ZU5GM3hnZHRockw=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ηеаэЪЬЖοβэЭчмχιф():
    value = 695236
    text = __import__('base64').b64decode('Wk1hc0h6NW1XNkkxVWF1d29qSWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ηξЙσΞьνοе():
    if len('') > 0:
        pass
        _dead_6940 = 999
        pass
    value = 976693
    if 4 * 7 < 0:
        648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgPvOV4fxrxVFQ6G3l3IAwYK0FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιзфъΡεСыΖуΨЪΜт():
    value = 202555
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgXydn06/f0LFgW6z3qBHiAAz0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙвшΨКΣОЩΩΦΚτбяш():
    value = 912742
    text = __import__('base64').b64decode('TVFwWnlDT1dORTIzOE00UWlWS1I=').decode('utf-8')
    if 44 * 42 < 0:
        _dead_4567 = 240
        pass
        pass
    total = value + len(text)
    return total

def _ΩΨФУυεσρ():
    value = 767792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSvmSQgTyq4sFVaA/n67JykHy2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9172 = 157
        93
        pass
    return total

def _ΛЯрЯцзуЪπωюζ():
    if False and True:
        pass
    value = 64565
    text = __import__('base64').b64decode('V1hwY29oZzY3WGlWckpuQWVPMGw=').decode('utf-8')
    if 19 * 50 < 0:
        304
    total = value + len(text)
    return total

def _тκэΩЦьΗΩΔщζтъ():
    value = 11658
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IivdWnY3zJksOx+1yW6cABQk8jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΡНфКΞΦЛΙЮον():
    value = 17875
    text = __import__('base64').b64decode('SjVXNDFXaXdvZThkYzMyVWdjdkM=').decode('utf-8')
    total = value + len(text)
    return total

def _βШηρΖχРαμΞЬΔΥо():
    value = 689442
    text = __import__('base64').b64decode('R2J1QjJPWEZ3YTVRVktqTTlKX00=').decode('utf-8')
    total = value + len(text)
    return total

def _цАРъЮъΞЖи():
    value = 339393
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBzFO3Y79ZstEBi2mmOYFw0F/HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χтжΚхΒΑбΓьЧχ():
    value = 492908
    text = __import__('base64').b64decode('UE9XVlQ1SjFZWU0yb0FLR2kyUjY=').decode('utf-8')
    total = value + len(text)
    return total

def _βЭдΡнΠПч():
    value = 731281
    if False and True:
        pass
        _dead_9727 = 55
    text = __import__('base64').b64decode('a3NoNmxYMG52MXJFcTllZDRfTEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖЪγΛгрЧηэхлΟ():
    value = 444173
    if False and True:
        _dead_2183 = 841
    text = __import__('base64').b64decode('a3ZfVkRIUXN5WWRyNjhndEZPZzY=').decode('utf-8')
    if False and True:
        550
        _dead_6980 = 634
        922
    total = value + len(text)
    return total

def _ЦцΕζЫэΟυΡа():
    if len('') > 0:
        pass
    value = 852698
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCbuO1w60pwCKlm6w123OHYivWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΘΒΖлκΠОыεочы():
    value = 32582
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxjQV0AA1q8Hbx2ZwQamIQR/8XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λЩхρσΥСл():
    value = 508389
    if 11 * 28 < 0:
        222
        580
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSDnXGhr66svMS6w8lGkIykY82o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        866
        _dead_3217 = 285
        pass
    total = value + len(text)
    return total

def _λТчачхκбΦΩΙИ():
    value = 606659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAWxeEFszq1RKj32nnWbHTQmtWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        389
    total = value + len(text)
    if len('') > 0:
        pass
        733
    return total

def _θюКДютИэ():
    value = 666525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHnQXFof/7AsbiCF7HumHi0O5kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖдθεмвΕиПαЕλ():
    value = 142649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDm0ekIN8YIHAguS7EKAGQl7vDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юζΨνβшρяГбφЦиБ():
    if False and True:
        178
        _dead_1411 = 321
        pass
    value = 967060
    text = __import__('base64').b64decode('TFdfaFlGbEplS3ptb1lRZFpGeU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΕΓГБУΒяθВЫ():
    value = 300017
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyjjbGE3q6ENPjWx2UCFEHQHykk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖςκΣΠкЩмαεДΙь():
    value = 336431
    text = __import__('base64').b64decode('WmlITjl1dTUxS0FhYm5PQVJUUUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡπΑНУшЪΔкςП():
    value = 675928
    if 9 * 40 < 0:
        _dead_2595 = 47
        _dead_8327 = 35
        _dead_6524 = 375
    text = __import__('base64').b64decode('U0ZuWG10c1ROSkRQYjdqem05c1g=').decode('utf-8')
    if len('') > 0:
        787
        pass
        _dead_7331 = 668
    total = value + len(text)
    return total

def _ИΛΘЦПРЫΛξЪэуЗЭ():
    value = 481482
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICX1QlcNxv9RDhnxkEe4ZXQh8U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оЦλДρΗУиκψ():
    value = 79277
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwC8a2MDy5ALBRb2kXCSFwAL8Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΙΟθшχнΟХΡΠЮЫх():
    if 3 * 99 < 0:
        435
    value = 386379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nxj8YElh34pQFxeMwGSoPwses2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧψажьΟΘλρДφ():
    value = 642957
    if False and True:
        pass
        _dead_8527 = 305
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHvVXG4t2ZwlHymZ60WmMy4OzTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цЛъΜцгγЬΒι():
    value = 21626
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px3HaH1gzqciMVeozUK4FiI//mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΜФиыτвмΣτ():
    value = 945317
    text = __import__('base64').b64decode('SVRuNHJjVjhGNUFjRThEN0RRclA=').decode('utf-8')
    if 61 * 29 < 0:
        _dead_9531 = 784
    total = value + len(text)
    if len('') > 0:
        698
        129
    return total

def _РЫэЛΧχΗπΗСрнλ():
    value = 73156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCbGYgdpq60XPy6ykGeoDSoK3Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 29 * 36 < 0:
        pass
        _dead_5102 = 668
    return total

def _хΝχглΘΥψγΕ():
    if len('') > 0:
        pass
    value = 345244
    text = __import__('base64').b64decode('YlRRRXE2eERhR1I3MEdGM3FEVkg=').decode('utf-8')
    total = value + len(text)
    return total

def _йЭрЛьχΣπБфЬкнεЦΝ():
    if len('') > 0:
        _dead_9023 = 466
        _dead_8683 = 978
        pass
    value = 156117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnrqPQAU8qBUBQqJ2G6yLScH3jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4337 = 410
    return total

def _ЧηЗυЫκьδ():
    value = 558903
    text = __import__('base64').b64decode('UjZUaUJrOU1vU1RsdkowX0lNN2U=').decode('utf-8')
    total = value + len(text)
    return total

def _οΡςτοηγπМЫКυΘЮ():
    value = 483967
    text = __import__('base64').b64decode('cHROSGFrNzdQZXpjSEVDS3hmVFc=').decode('utf-8')
    total = value + len(text)
    return total

def _яτοΠпыΗы():
    value = 589439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz/eeAU40ZsxNQaz7FKKCwEbwHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТщΕΤΖΙкΔъη():
    if 61 * 40 < 0:
        _dead_6362 = 943
    value = 339693
    text = __import__('base64').b64decode('dW5JRGRTYUhxeHRHNXlPNjdmRFU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8284 = 849
        _dead_5649 = 666
    return total

def _юΤτмПσАюΒЪц():
    if len('') > 0:
        87
        459
        pass
    value = 718660
    if False and True:
        323
        _dead_9353 = 572
    text = __import__('base64').b64decode('U3MyYzRXMjh5NGFzQU9KZ3FOc28=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        65
        pass
    return total

def _ъдυБВςαГаС():
    value = 914971
    text = __import__('base64').b64decode('dEpTNk56aHN3QTBmZlpCdUY3R1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _σΣοтβзπпΘцα():
    value = 549592
    if len('') > 0:
        438
        pass
    text = __import__('base64').b64decode('eVM4STNsWG5BTzNmRWttTEp4Zzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫкФΘςСТшчΘФСЦ():
    value = 876897
    if 95 * 27 < 0:
        pass
        764
    text = __import__('base64').b64decode('alQyWXl3VFdqWjVFSFl6bTJDZ3M=').decode('utf-8')
    if False and True:
        832
        pass
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_7169 = 956
    return total

def _зйДчСЩσΑяΥю():
    value = 570985
    if False and True:
        311
    text = __import__('base64').b64decode('cGlJSEQ0UW9BRnZHWnBJWHVibmI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞцюνшгζвςΓΓΚξβ():
    value = 242075
    text = __import__('base64').b64decode('Rk5wSDVXZDdBaGVtblBXM3Y2a0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΡъЧеЭВΕм():
    if 7 * 56 < 0:
        _dead_1961 = 126
        126
    value = 300435
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHi9eGIy1aZabimQy3yiPyQp01Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 91 * 51 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΧωφφЫξΥб():
    value = 839707
    text = __import__('base64').b64decode('WWZoNXdWTnpfN2o0bG9tdkxETUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЩрΑδММτЗТΡЕдГιО():
    if len('') > 0:
        630
    value = 461045
    if 89 * 66 < 0:
        _dead_5952 = 189
        278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADezbFUvr74IExmT40+kGHQZyVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зьЧφШγлМлΨГ():
    if False and True:
        _dead_1956 = 120
    value = 707724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwzIfEUuzb4XLCSP0HWfOSEct2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6965 = 542
    return total

def _БΟщЗтЭцζψΧζ():
    value = 276286
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDjXOEUpy6YSIjuO4V27OQwB72M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        557
        580
    total = value + len(text)
    return total

def _ЖнχΔνςрοШЮоλθс():
    value = 702601
    if len('') > 0:
        3
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FivDN0Q38oY5KTWC4EbGIg0NyEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΓсΒΘфДНЖфВцэЫ():
    value = 33370
    if len('') > 0:
        _dead_2784 = 914
        pass
    text = __import__('base64').b64decode('UU55RUNjUEEyVElGWktfRjYzYVg=').decode('utf-8')
    total = value + len(text)
    return total

def _пЩΔιΗОюΘыοЦщ():
    value = 113297
    if len('') > 0:
        _dead_3997 = 70
    text = __import__('base64').b64decode('bkZ6d29Pc1JBN2M2dkVURFAxNmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖрτΧΒΕуьдиΛь():
    if len('') > 0:
        491
    value = 462683
    if 12 * 81 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgbQS1M3778vAiqm2m+0DBN3zWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςυКФКΒΓΒηΡвИμЙ():
    value = 576254
    if False and True:
        828
    text = __import__('base64').b64decode('aVQ2ZVVIcDgySmduaHZDajROcVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ыьСΡКзЫΨξΟьΕ():
    value = 900652
    if 90 * 82 < 0:
        _dead_3084 = 201
        _dead_2534 = 979
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx3oZQY2roJaIFec+XSmJXAZ5ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        616
        pass
        _dead_6013 = 794
    total = value + len(text)
    return total

def _сфЮΡГхЖРаθфπМЮΧ():
    value = 562919
    if False and True:
        845
        _dead_3764 = 265
        pass
    text = __import__('base64').b64decode('WDFQTzNYblVpbEdYendyT3k1aWc=').decode('utf-8')
    total = value + len(text)
    if 27 * 25 < 0:
        _dead_1024 = 633
        215
    return total

def _хтяΡчπЖοА():
    value = 955532
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzjDSkQ20roiLlmb8EWXGjcc4z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΝЙΜЖιΑБ():
    value = 826980
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXfnb3swqvEFDAuG5GaXOXIozHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑшςцπУвд():
    value = 979774
    if False and True:
        _dead_8230 = 877
    text = __import__('base64').b64decode('eUFNR0pmNXNzV2ZkeEdVd1hLQmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖтΓΜуиχЙ():
    if len('') > 0:
        pass
    value = 979306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHvVal0T07IODB2MkF64HgY+4Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κЯλГщпιЫπАφОшοΕм():
    value = 243693
    text = __import__('base64').b64decode('V3JkQ3pNdElWbVlLaDBjTGR4Slo=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΘпжΩэвΛΤΨа():
    if False and True:
        _dead_4515 = 122
        _dead_8632 = 339
    value = 17637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyLPNl48+IIPMS6azF+XPCg+zjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 91 * 83 < 0:
        _dead_7160 = 192
        _dead_7772 = 312
        274
    total = value + len(text)
    if len('') > 0:
        246
        118
        _dead_9865 = 775
    return total

def _аΜμлΟΠШЕУεЖεяσц():
    value = 438211
    text = __import__('base64').b64decode('UFZNeFlETXU2b3pSVlhBcHRUZ1c=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3157 = 996
    return total

def _еΤачΡΟжтηИοШРдΩБ():
    value = 696327
    text = __import__('base64').b64decode('dlZfajZsMXVTS1F6VmhraWFqX00=').decode('utf-8')
    total = value + len(text)
    return total

def _ПНЬчСσфυχС():
    if len('') > 0:
        _dead_5727 = 419
    value = 637405
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQOzYQUv2aM0KleCxmOqMiMC/Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _биγχΔхΧвГн():
    value = 251364
    text = __import__('base64').b64decode('TDVyVnFsN0xwRFF4Zmc5VjMwdlA=').decode('utf-8')
    total = value + len(text)
    return total

def _чΣΘηьοкεжОγыЦ():
    value = 374987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA3+Y1o9wYwbCD6yn3O4Bgt/4Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дцмμΧαеοэчοεΓ():
    if len('') > 0:
        283
        256
    value = 330466
    if False and True:
        _dead_8449 = 507
        421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBrQbGEG1q8KPSKF4WC9GXwl7kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыТЪψμΤθΘνςв():
    if 28 * 99 < 0:
        _dead_5682 = 715
        776
        _dead_6555 = 595
    value = 831075
    text = __import__('base64').b64decode('Qk5fMUVIWThiVF9ZZFB3NHBWODI=').decode('utf-8')
    total = value + len(text)
    return total

def _εБфΜХЯΨМг():
    value = 64362
    text = __import__('base64').b64decode('S0poVU9rQ2E3UVRFeUcxRDJUSWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ШωΕΑЕΓΤιβЭЮУνэΘи():
    value = 552424
    text = __import__('base64').b64decode('RkZ5V1RhQVB5QlJqNExVT0RwUGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ОуКΔΙχКБΩУΡΚΑΓ():
    value = 867874
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiDpV38gyIEtPAyw8VGZZBYZ4nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оНКΜПΣяСс():
    value = 324065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxD8eQMj0YkBOB+h0X2jHgsBz1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яκГвХчелΥθАρζ():
    value = 571675
    if False and True:
        _dead_9632 = 746
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyO9e1Mq2LgvLCuG5V+6Mj82x0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωдАΑюΜМлΖНЬΚм():
    value = 415955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px3iPlwqp5JUMziv33SzBy840DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФηΕγυОЮРΔΕчγцΑе():
    value = 969883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz/+QVg/q7ESClmm/l3DA3YH9WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚХпнεΔΞβΖΜψЗψ():
    value = 961066
    text = __import__('base64').b64decode('U0M1VXpVQ2wzRUpsXzk2cVRic3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦяХξГЖЦвЬ():
    if 29 * 67 < 0:
        pass
        492
    value = 883356
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQ7uS1wawY8bED6w8XyKZHYHz0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5914 = 216
        pass
    return total

def _ДыυшΣГΠКΕ():
    value = 880884
    text = __import__('base64').b64decode('QkZGOHNLdnVfX1Bfdl9aOUlkU1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ωηоъбαΒω():
    value = 206028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAvQeVob9IsMFVqt7H69MDMZsFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5872 = 129
        448
    return total

def _СοδλяюРξЮэ():
    value = 307003
    if 31 * 81 < 0:
        852
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzvsSwMY2PBRAAOJ23OmZDIZwUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 47 * 44 < 0:
        351
        _dead_5356 = 124
    return total

def _мЧΣΖуУΣКΩэυΩЦρτ():
    if False and True:
        _dead_3848 = 36
    value = 977837
    if False and True:
        pass
        283
        _dead_5796 = 284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETbtVGQo3ZwpbSn0mFycPQ1//EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5541 = 558
    total = value + len(text)
    if len('') > 0:
        _dead_7166 = 289
    return total

def _ΗФыЮгкΘδчЫοч():
    value = 774692
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBjQZAg/7ZIyaiCuwAPAN3MD1kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αсэΑЪюδФЗЮоΤОБхΠ():
    if 14 * 57 < 0:
        pass
    value = 743800
    text = __import__('base64').b64decode('R29JNDF3U0VCM2Z5OThYQ05sek4=').decode('utf-8')
    total = value + len(text)
    return total

def _βНΓззбΡυκУаюЪсРο():
    value = 665083
    if False and True:
        304
        410
        pass
    text = __import__('base64').b64decode('UEFjcnFJWk5sZldaNzZfcmFYdmk=').decode('utf-8')
    total = value + len(text)
    return total

def _МμПгГυкиБрνω():
    value = 328954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxXde0cLzb8qCzCRmlHBDCAf3Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РςЧзЗΧМΚ():
    value = 523117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgbBWVMw14E5Ih6wmVW/HBU73Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 22 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ςмιщмγΝкщΖгΕΜλζ():
    value = 375073
    text = __import__('base64').b64decode('eUxuek1oNTBZTVlNMXZ0Znoxa2o=').decode('utf-8')
    total = value + len(text)
    return total

def _аΞМъкΩжΤλυЕθ():
    value = 466026
    if False and True:
        272
        13
        _dead_5609 = 704
    text = __import__('base64').b64decode('aHFhQm9nUUpJYlVtYXdoMU00bDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ξзΟдδЛИвΤωТ():
    value = 126954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxDDR3Yry7ASCirw4F7CJDR/ync='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        786
    total = value + len(text)
    return total

def _ПЬοлσλяЬΖИιυ():
    value = 518903
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiK1X2g0p7lWNhym8kGFJAwY5Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩФФжФψьΔΕЧГΒΒЖ():
    if len('') > 0:
        _dead_9149 = 800
    value = 997782
    if False and True:
        pass
        429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jj3iS2A+/Z8INAeCm2aHE3UZ0VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1945 = 87
        335
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЕЖШяуφωΦθмуΩж():
    if False and True:
        588
        pass
        pass
    value = 783123
    if False and True:
        _dead_1148 = 865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDzUS2dh9JEKNhXw/WOqFwks9HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 100 * 11 < 0:
        55
    total = value + len(text)
    if 33 * 29 < 0:
        _dead_7706 = 932
        _dead_1370 = 781
        203
    return total

def _πкюΩΦЫΡφХаχРζ():
    value = 452550
    if 32 * 21 < 0:
        _dead_1024 = 520
        537
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBrcf0Q6zIAwFFaP4UaJLR0E0Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эθеηКφψЪзУψ():
    value = 113607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITvLZWgh55ovNAuzmFe2NQ8e9D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 83 * 21 < 0:
        452
    return total

def _χуΞчПΟждЬξΗΦΤβΤ():
    value = 469140
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhrMRFkMz58mDD+m/UXEER888UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓбтэгβтωрΦ():
    value = 141472
    text = __import__('base64').b64decode('YmhVakY4d2dlRVc0MGtISmJvZXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЕСХБжιСЖТШк():
    value = 812084
    text = __import__('base64').b64decode('YXRHeTlYM0kyX0Q5R200TGc5Y1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _δэΘμΡνРΨъαΞФΥφ():
    value = 777358
    text = __import__('base64').b64decode('aTk2MmJCOFpKcVJsZDh2MnhlcXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙМРШжυщωЕЦπуВб():
    value = 295177
    text = __import__('base64').b64decode('ZXRFN3FNRkZhYXlscW1SR3Bvczc=').decode('utf-8')
    if len('') > 0:
        889
    total = value + len(text)
    if len('') > 0:
        _dead_8470 = 99
    return total

def _δрЕΔΗξΑлГмΟЮЧЦЪм():
    value = 238365
    text = __import__('base64').b64decode('RnZYOUlsdmh4N2pVSXN5WjN6bDk=').decode('utf-8')
    total = value + len(text)
    return total

def _яΦΞΟτюФΙнШэθВК():
    value = 19561
    text = __import__('base64').b64decode('RThLZWNFTmxSUEdPMHhwcDU2V3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙφαηΟвΥюУωΤ():
    value = 282796
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAPsfwYh1psvazWlzEK5GiE7zXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΕΡΗЫβΖΤЬΒыЗЖОΩк():
    value = 981719
    text = __import__('base64').b64decode('azhTSkVkdno3OThOY0tVME5xZmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΕДΕЮθΓр():
    value = 310918
    if 62 * 62 < 0:
        pass
    text = __import__('base64').b64decode('VXNheU9YUThjdGhfbXpMb1JfWHI=').decode('utf-8')
    total = value + len(text)
    if 48 * 49 < 0:
        _dead_5659 = 789
        _dead_2752 = 601
        pass
    return total

def _ζиτфйеκЛЩκρνμксР():
    if False and True:
        _dead_7403 = 758
        561
        578
    value = 746336
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjXJfV0vz/EnYiCM3WbFJw0b1HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3267 = 296
        pass
        626
    return total

def _ШλКзАПЦЮкΧЩЫ():
    if 41 * 88 < 0:
        406
        pass
        _dead_2203 = 530
    value = 447274
    text = __import__('base64').b64decode('ZXZmT2VXeThBZ0FTeE8weVpaYzA=').decode('utf-8')
    if False and True:
        _dead_9903 = 583
        314
        _dead_6340 = 453
    total = value + len(text)
    return total

def _ТЖЫΧδЮΗΥ():
    value = 510853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cgjjfgk+zKQVG123kQaeAx8O8lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βαзрЯψΠьβ():
    value = 618702
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JinoeQch2v00L1yt9w7EbB191mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юфАуЕЮΜЧοζбФтШΧ():
    value = 254588
    if 37 * 42 < 0:
        _dead_5719 = 737
        _dead_7792 = 74
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AS3Ra1k9178PCiSznmWmPnMa4zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦξΓНлΣпыΠИг():
    if len('') > 0:
        _dead_5813 = 504
    value = 333907
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwewdEgyqrgRKjiKmmGREwcb3Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _ΞЩЮηчЪφΧЮФгΠΣъ():
    value = 705954
    text = __import__('base64').b64decode('Zk5jYlBxN1NTMkdoTGlSVkhkZUs=').decode('utf-8')
    if False and True:
        284
        pass
        pass
    total = value + len(text)
    if 56 * 99 < 0:
        _dead_5962 = 403
        _dead_7167 = 346
    return total

def _ЕНэЖηюΠτчя():
    value = 215279
    text = __import__('base64').b64decode('SG1pY1lJbXNiTm1vVlFmbDBxUEs=').decode('utf-8')
    total = value + len(text)
    return total

def _шΤЫΙЗΟМэТ():
    value = 321415
    text = __import__('base64').b64decode('czRoWDI0ZUJxTmdNbFhFeGF4WFI=').decode('utf-8')
    total = value + len(text)
    return total

def _нΡПкрЙзШх():
    if False and True:
        333
    value = 98848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Axi1Xm4axp0FIhuozHSxDQwOsFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пυζθЖОКЕЧΩе():
    value = 205595
    text = __import__('base64').b64decode('emtOdU4yZndCTDIxNmxPRnBJQ1c=').decode('utf-8')
    total = value + len(text)
    return total

def _πкΜВΓФэΗАзКаэ():
    if 79 * 91 < 0:
        pass
        pass
    value = 489533
    if False and True:
        _dead_9918 = 488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyzLT1gjpqoEEVqQnF2IYCAqwl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3184 = 978
        938
        356
    total = value + len(text)
    return total

def _чΜБψТюРБОМАП():
    if len('') > 0:
        _dead_4162 = 693
        795
        _dead_7635 = 367
    value = 973208
    text = __import__('base64').b64decode('RzQ4bGNMQVhxRHFZZ1duSnNvT0w=').decode('utf-8')
    total = value + len(text)
    if 16 * 74 < 0:
        538
        _dead_9432 = 482
        pass
    return total

def _схрΔгэЦЛ():
    if 27 * 81 < 0:
        _dead_9226 = 906
        pass
    value = 42090
    text = __import__('base64').b64decode('TDlwVXp4Nk9keG9tOElCeEhtT3o=').decode('utf-8')
    if len('') > 0:
        980
        pass
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()