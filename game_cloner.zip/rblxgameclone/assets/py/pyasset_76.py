#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _СΜεΗЩпДΓгУΘиςе():
    value = 360450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BijpaG4O9JsvGBi23FSiOwB703c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮухиΔЕШΣΒхφ():
    if 25 * 26 < 0:
        498
        pass
        pass
    value = 815336
    text = __import__('base64').b64decode('RG5QM1FsWjN6VkRJbElYaldZT1A=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8557 = 224
    return total

def _цΞМЖοВеγКΦΠΣξг():
    value = 163588
    if False and True:
        _dead_4205 = 19
        976
        pass
    text = __import__('base64').b64decode('VURKclhlSHROd2dDODZOR0xaRk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛкθΡδΔкаΠΟΗ():
    value = 409033
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzbdfnxgyYNULR+k3V6kOi4H7UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КγΗлКЯКΤδЦεбКъСВ():
    value = 166265
    text = __import__('base64').b64decode('Ql84ODZFenh5R2ZPdWdVU0tldHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯТΙхωΒТуΗωвцьΒΒ():
    value = 62982
    text = __import__('base64').b64decode('bjB5OEtHa3JDNmVxZVlRc1pRNkc=').decode('utf-8')
    total = value + len(text)
    return total

def _УΣдγψдΦЬгχ():
    if 42 * 81 < 0:
        319
        pass
        135
    value = 64458
    text = __import__('base64').b64decode('SFhxeUlGR3lMbDdGbDloRFlsZ24=').decode('utf-8')
    total = value + len(text)
    return total

def _тΖтЗюΒрΞИΝХξЬχч():
    value = 116525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSfFR2cqwYUNLFiLxGyjEQQOxWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 48 * 23 < 0:
        pass
        pass
    return total

def _ЙИфξРЖΛΘВ():
    value = 791359
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz3VWgcP8IEuPjf07WWRIT189Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦощρчРАБВзЙУ():
    value = 268993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHfmVkMo8IsCFia631CYJSoJ11k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑеиΨКνρЮж():
    value = 580365
    text = __import__('base64').b64decode('QkZnZ3B5WDFuc01oc3ZIX09fM1I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦЯΙиЪΜоУГРюΥυвΩ():
    if 51 * 28 < 0:
        _dead_7896 = 428
    value = 538766
    text = __import__('base64').b64decode('TE1yWWxvY2VTeHFCbnE4QWV5dkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥςΩωΟнλσ():
    value = 448932
    text = __import__('base64').b64decode('QVZJUmxkNHV6WU1SMEk3Skx2dVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΝπΗΞκЦоДθЯφ():
    value = 339597
    text = __import__('base64').b64decode('dngyTnZ1S2Y0VHhkZ1lBcGdVa3E=').decode('utf-8')
    total = value + len(text)
    return total

def _εθлъШςδхСхХЙЙМ():
    if len('') > 0:
        _dead_3866 = 68
        _dead_6851 = 622
        pass
    value = 563283
    if 54 * 29 < 0:
        682
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACHvWnoV/fAzIBeg2mOkMnI/5jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        208
        135
        _dead_6391 = 946
    total = value + len(text)
    return total

def _РγΒхφΑЙЯМьКй():
    value = 699366
    text = __import__('base64').b64decode('bUMxSDhONjM4RWM4NHZ1Q0NRWUU=').decode('utf-8')
    if False and True:
        pass
        _dead_3594 = 317
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7047 = 150
        pass
    return total

def _ΡчΡλΙβЫαсБЦцδйн():
    value = 716427
    text = __import__('base64').b64decode('Sm8xQjl5bzNqU2NGRnpjWjEyUlQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        598
        _dead_4234 = 896
    return total

def _ΓπμдητγБρη():
    if 19 * 59 < 0:
        pass
        567
    value = 234774
    if 35 * 80 < 0:
        pass
    text = __import__('base64').b64decode('Qm8xY0xVMGU5UlhkU1FaSDFYOHM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        289
        924
    return total

def _ηДΗдΔфлο():
    value = 622992
    if False and True:
        547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAbTa1Nu/J4XGQi17HO7LQ0A7Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ехгΠΠψЛяэЬвЩζвчΘ():
    value = 727278
    text = __import__('base64').b64decode('SGg4ZnBNUV9SZEU5dEhNZTBiUlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _λЪкГξδеωБ():
    value = 717255
    text = __import__('base64').b64decode('ZHYweWsyMnFTMHkwV2w2M1ZNMjM=').decode('utf-8')
    total = value + len(text)
    return total

def _фтВκфΦбπΦвφ():
    value = 603857
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBfKbX83p7pXPSj04U6FDDAJ53Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σБиПΒнЬκΕЖЧυв():
    value = 557400
    text = __import__('base64').b64decode('a1Nlcld1T2tmRXd1VU41dDNEa2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚδюЮНζЦξγεЯΕБ():
    if 90 * 88 < 0:
        pass
        pass
        _dead_4116 = 38
    value = 812428
    text = __import__('base64').b64decode('VU4ybTZneDd3WUpHTG9fa1RCdG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ξЩПΧаВΗФ():
    value = 571127
    text = __import__('base64').b64decode('d2lqUXNSZGFkbVpEQzlzc1V1MDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _чΞЛОΗЖШкд():
    value = 689995
    text = __import__('base64').b64decode('d0pPYndHWlUza3J2NkdodmRvVjg=').decode('utf-8')
    total = value + len(text)
    return total

def _КξойнФνУмΧцαα():
    value = 942717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhrDSAgM374LCz2K3nqIERoQ9UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХБΛτБΞяЩР():
    value = 798854
    text = __import__('base64').b64decode('QTFCSHczTGFDaW9KY0Z0dHZIRDg=').decode('utf-8')
    total = value + len(text)
    return total

def _НзНπЪюЖλΑτФλЯδ():
    value = 564712
    text = __import__('base64').b64decode('TDNWUFlDRktrV000MFdKbER4UDA=').decode('utf-8')
    total = value + len(text)
    return total

def _чЗъΣОчЮэοшгμЛΠΓ():
    value = 693472
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQjJP2Eb1fpbIC6pwkGkMBc88jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        798
        pass
        _dead_2599 = 523
    total = value + len(text)
    return total

def _ωΛФβшΞфВΘςΕΣςА():
    value = 102137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRnUXHYs+oRRN1m5nXrJZnwt00g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХэМΛωИυП():
    if 52 * 84 < 0:
        _dead_1824 = 270
        _dead_2738 = 331
    value = 579498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCrCbFIa7q0KMFep42K9EhcM/kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4129 = 116
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΛъψсЮΤНЪιмΘμκ():
    value = 826401
    if False and True:
        844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDnzTQBh+Ps0aBzywV6eGiIQwmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κψБζсΙσκ():
    if False and True:
        pass
    value = 212208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxX1W0s61ZgAaD6CkU+vZnR9x3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤθΠлЕσуνядьХΨ():
    value = 209741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3fvRl8zrrExHhil7FqbJQol0H0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СуΔΛβμσΗДμφΑ():
    value = 886902
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px28OFYO9a1SKTubkUekODAf9UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΠАЯйЩмдωΜъРЖεТΩ():
    value = 365575
    text = __import__('base64').b64decode('VmdFT0JCWnVDVExiT0hiR0VfNXE=').decode('utf-8')
    total = value + len(text)
    return total

def _иэлΙрξжУΞτ():
    if False and True:
        _dead_4175 = 267
    value = 264677
    text = __import__('base64').b64decode('bXk0Z1B4ZHJXSEdGQUg3RWtkWmE=').decode('utf-8')
    if 83 * 79 < 0:
        pass
        pass
        836
    total = value + len(text)
    return total

def _бйοЛσхИδΜ():
    if 57 * 82 < 0:
        237
        _dead_3706 = 210
    value = 57612
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCXDSl4o8r82FDyR+3mqYHI+yGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8212 = 584
    return total

def _ЬшαЬРΕωвкΛЗюЬЦ():
    value = 924607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSaya34J0PlbNCay3AXFDCF87WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЮЖдαЭыЫХФГξоτσн():
    value = 391114
    text = __import__('base64').b64decode('VXdBckdScWxwemNDZFRma1A4VWw=').decode('utf-8')
    if 53 * 45 < 0:
        pass
    total = value + len(text)
    return total

def _ιΗсЯмΩдψΚΜΧ():
    if len('') > 0:
        802
        pass
        436
    value = 103945
    text = __import__('base64').b64decode('WkxpQTA4ZTZKaGxPMFkwaFIwaW8=').decode('utf-8')
    total = value + len(text)
    return total

def _θИЫБЪωЫΘоηδΞΤβю():
    value = 695279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FADzO0kV2Y4nCD/w91vABCEb3m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДρΜпΥШΦΩШ():
    value = 471334
    if len('') > 0:
        529
        pass
    text = __import__('base64').b64decode('RkR6V2o4bnlaV2RVNm0ya0JzaXk=').decode('utf-8')
    if 63 * 96 < 0:
        _dead_7477 = 474
        509
        _dead_3488 = 770
    total = value + len(text)
    return total

def _τСΒΔлШΞχДаι():
    value = 518623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTjNfVUQ8Yo2FyK7y3uDBXMc8Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЮεрβΜБΨдЧНтΩЩ():
    value = 196478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiTPOlA1rZ0EDTWZywLBETwI7Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΥкмΩτρπкβлηΛοΕω():
    value = 844482
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDnNWkZt6KEsAzuU5mOSHBQXz2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        973
    total = value + len(text)
    return total

def _ΡνУМдрЬоБ():
    if len('') > 0:
        326
    value = 314668
    text = __import__('base64').b64decode('eThrY1pqMVpKRDdtaGFVdEkzQnU=').decode('utf-8')
    total = value + len(text)
    return total

def _НИινрЦηγЦΑμ():
    value = 212720
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3a0e3wv0aZbLj2Q61CJZSEl22k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        655
        _dead_5389 = 999
        _dead_9348 = 560
    total = value + len(text)
    if False and True:
        _dead_3285 = 560
        545
        pass
    return total

def _иноХιΖθоб():
    value = 13901
    text = __import__('base64').b64decode('V2Ywd0FxaTk2ZmJmVXBqdFo1SzM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _αΚΘβΨЬΟэΨ():
    if len('') > 0:
        pass
        _dead_9326 = 380
        117
    value = 403271
    text = __import__('base64').b64decode('bWNjSzZvV1BCRVZObkdLWjZoWE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ыωΓилεΑтьΜНЪСЛ():
    value = 757750
    text = __import__('base64').b64decode('Y0RObjROSHNaVjFBSXVJM3Z3QjU=').decode('utf-8')
    total = value + len(text)
    return total

def _σйΑΠЗΡОΝΦВтρТΔΝ():
    value = 490676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxjJQFpt2rs8Eh+7+AeZFy4p6jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 46 * 3 < 0:
        875
    total = value + len(text)
    return total

def _ЩгТаТдΑφΟЧбθу():
    value = 647167
    text = __import__('base64').b64decode('YzVhMkpxcTlOTEYwbDFmaFdOY0k=').decode('utf-8')
    total = value + len(text)
    return total

def _УξνГοΕЯπРЖщςаьй():
    value = 898980
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB7dOWA2558BNBy07gWgNRIi6mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣЦΥпШДмсΣΘΞ():
    value = 660120
    text = __import__('base64').b64decode('Rzc5encxelRwWkNQWjduc2ZGSVU=').decode('utf-8')
    total = value + len(text)
    return total

def _жЩηЖбυФЬсзΙЯРν():
    value = 875415
    text = __import__('base64').b64decode('aV9RY2h1NGFyT21QS3p1Y2ZDWF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΧИΗьХβсУ():
    if len('') > 0:
        _dead_6521 = 918
        _dead_3290 = 815
        _dead_4109 = 942
    value = 155808
    text = __import__('base64').b64decode('RzFocEtsYkU2NnRoQ3ZJaWtoaFU=').decode('utf-8')
    total = value + len(text)
    return total

def _лιпβΠэРМЗСьεωΦ():
    if 9 * 39 < 0:
        pass
        84
        308
    value = 310595
    if 92 * 39 < 0:
        _dead_3845 = 746
    text = __import__('base64').b64decode('WllEdlFORngyV0E4ODVBTGZDWXo=').decode('utf-8')
    total = value + len(text)
    return total

def _хСкκдΙβδθβοса():
    if 73 * 55 < 0:
        766
        _dead_9383 = 485
    value = 991530
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQfof0kGyr4oMRmb5malMyka60g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κσЯτшЦнχЮΛ():
    value = 243397
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CC3WQHMY+/0OMFmS0GW3bQEswUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГцχВВЫΒΩФσьΚиΦЫ():
    value = 668632
    text = __import__('base64').b64decode('bW9lVnpzYkE3UW5Xekl1VEwxSHU=').decode('utf-8')
    total = value + len(text)
    return total

def _пзкΡйσΓр():
    value = 583835
    text = __import__('base64').b64decode('c2szb0RYWlVwSnBwemVHc0RiMHk=').decode('utf-8')
    total = value + len(text)
    return total

def _яАаЮΥвιΙΤзТЫΖ():
    if 22 * 11 < 0:
        _dead_7190 = 878
        pass
    value = 127760
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxXFflU72blRHF/6ynGhIXcI12U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΝΤΥеЫапжΧΩМ():
    value = 663632
    if False and True:
        pass
        pass
        pass
    text = __import__('base64').b64decode('dU1ibE9ON2Q2anhIeU9Yd19VRXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡрЖгЪЯΩЮΓбΓ():
    if len('') > 0:
        _dead_7387 = 177
        _dead_5637 = 412
    value = 757918
    if 10 * 75 < 0:
        _dead_9172 = 882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyvOY3Bq87IObl66mnXJJw8G8Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΗбδНζπΗбκБ():
    if False and True:
        910
        _dead_1266 = 820
    value = 408822
    text = __import__('base64').b64decode('R0VOXzdkaFExcEpsOEk5U2VuaEU=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _шИγКСΖοШχΝχХЦ():
    if 29 * 23 < 0:
        959
    value = 105917
    if 88 * 7 < 0:
        932
        200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAvpSUYQ2oIOMDm0/kWKOSQa8kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        625
        pass
        818
    return total

def _ΣаΟАΡФΖАЮ():
    value = 442785
    if len('') > 0:
        601
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dw62ZUIYr60haTbx7mm6G3YgwTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        962
    return total

def _ЮдыЮюφυΛИ():
    value = 92672
    text = __import__('base64').b64decode('dUF5aDk1ajFyeWhFb2dpdnJTMzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬβΣΨλэмбЛК():
    if False and True:
        _dead_5164 = 883
        _dead_4682 = 88
    value = 559185
    if False and True:
        pass
        _dead_1740 = 769
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARzDe0U98PxbGwezw1y8Owt47WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        176
    return total

def _ιΘОоλβзμэъьжΣы():
    value = 637788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EirUPUFp6bs7OxyC6meJACMj9GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9879 = 435
        412
    return total

def _λΙКζрΚГЬсыфЕЩДηй():
    if False and True:
        _dead_9556 = 157
        pass
        94
    value = 968866
    text = __import__('base64').b64decode('SW9WYzRMREl5eUZISVhTS0RMaFE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕэФЗАкьθ():
    value = 915366
    if False and True:
        pass
        890
        pass
    text = __import__('base64').b64decode('UTBjX3hRcTdoaGVNOGs0aXRvTnc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜυωтнλЮЬΓшПКΩ():
    if 99 * 2 < 0:
        530
    value = 81269
    text = __import__('base64').b64decode('aUQ3V1lxYXIzdE9IQWJReFNjaWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ОжΚαЮВγγηрТ():
    if 5 * 41 < 0:
        _dead_2887 = 488
    value = 522300
    text = __import__('base64').b64decode('RU42d09NUkY2X0g1aFp1Z0FKQ1c=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_4415 = 369
    return total

def _АχгβΡЧчрΒεЕЖΦАω():
    value = 644731
    text = __import__('base64').b64decode('aG9FTVJxb084VW5KSHBPa1RRMnM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        849
        _dead_5066 = 697
        767
    return total

def _ЧГωмΜΡЕζлυВБρК():
    if 55 * 84 < 0:
        pass
    value = 68509
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDrMfwg7pvANDjyp43TEAAkmw30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗсЗΨцκйдςμчлβΟ():
    value = 22161
    if False and True:
        pass
        804
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCbgZXA+/L4LNhuTwUaFIh02/U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΕμαΝΩяБЛ():
    value = 845101
    text = __import__('base64').b64decode('empqdV9rSXZHZWhwWmZ3VGdOdGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝПΞйΨЛдП():
    value = 542967
    text = __import__('base64').b64decode('RGF2UFRvb2IxOEFMVjVuQTJWVzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨχаыΞЬγтκθБ():
    value = 601785
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JiHeSUY2/aEGY1aI8GKlHXwf/kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑηФЖБΗйДаАΟ():
    if len('') > 0:
        pass
        _dead_3527 = 458
        _dead_2847 = 407
    value = 468788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fn3zZEEp5oU0IBnxxHGdNyE96nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УШжзЭОΣφКСПυВаф():
    value = 456107
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyvlPmQ/5pABLQ6y5GzDbQEl6lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыШуюβЮуГοηΖ():
    value = 447747
    text = __import__('base64').b64decode('YTN5SzJpdDREc2NjaXhtNTZaTWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗδБКΥΙКψΞЦЭДФερи():
    value = 109648
    if False and True:
        pass
        489
        104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB/oTXspqKAIIx7w3nuZCyd462E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΔυρΕчРКЮУρσ():
    value = 50991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQHCdlU4+5c0FDyw2A6yMwd4yjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρчνЗцΞпМ():
    value = 972819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhzxW25q27gONBeL3FTDGgl5y2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 96 < 0:
        pass
    total = value + len(text)
    return total

def _ΑψБабЙтШ():
    value = 358317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzXUd2Zu84MOHBXx73qdMXYVwWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _нБУчЖеνЖЪашκ():
    if len('') > 0:
        138
    value = 183816
    if False and True:
        pass
    text = __import__('base64').b64decode('bEdHTzY3YVVMbERkdVh3R0VfV20=').decode('utf-8')
    total = value + len(text)
    return total

def _дцΑπΡЛηυαγΨНЦΡЪ():
    value = 650056
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQPIfFU+3JBTKy6Q+EyZEnR55mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_4626 = 655
        13
    return total

def _θоΤЕЪΤΔЛ():
    value = 275650
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACu0agILrbwkFwCw93CZYjwW/j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηЧмΨΞΕπιВЯβρ():
    value = 403668
    text = __import__('base64').b64decode('TDdyMUtRU3dmZ1E2VzBwcFh0OGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΥФТФрдгЩΖ():
    value = 746772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSPNOl4Ny5w7DxX7nAK+BSMoyl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 63 < 0:
        pass
        _dead_9279 = 768
    total = value + len(text)
    if False and True:
        768
        pass
    return total

def _φЙζπΓЛμΡКρчХ():
    value = 829777
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX3lbEg/yaIqEx7y41+vER1301Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПьдРχΘαΟΨдэΑнΤРΓ():
    value = 52669
    text = __import__('base64').b64decode('aURzdkdsek9Nclhnc09qaWt5Q3k=').decode('utf-8')
    total = value + len(text)
    return total

def _лбζЫуяχχΝ():
    value = 763376
    text = __import__('base64').b64decode('VjJGOEloSDZaR3ZuNW1qV1BpUHA=').decode('utf-8')
    total = value + len(text)
    return total

def _лПеФφωУμ():
    value = 200383
    text = __import__('base64').b64decode('TmN2UGV2Wk5FVG5aWVBoZUlvZWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜηМехБНΧЗγя():
    value = 827733
    if len('') > 0:
        _dead_3164 = 291
        _dead_4230 = 232
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQX3YnQ05IAHbiaq+QKiIzAKvDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        821
        _dead_4854 = 231
    return total

def _ьДЮΔЖкκΨΦЖдω():
    value = 382355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjfyOmQ7rrI5CFz62VqZJSgZ1Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫФΘНлΥρΘκτЧЙГфя():
    value = 423839
    text = __import__('base64').b64decode('ZTFZUHBQaksxUDlQRjBwM0M4RFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΤРыοΩмΜ():
    value = 583033
    if 8 * 36 < 0:
        _dead_2481 = 805
        _dead_2082 = 978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSvvaVVt9q4qOSmVmwWSHSwI9Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        958
        pass
    return total

def _ШБЖΓбηАγΕΥρнвЯοТ():
    value = 732212
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiLMZ0hp574mHSOawHy1Oy546U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΑψаяΛνΨΗуΟ():
    value = 273099
    if False and True:
        pass
        _dead_9569 = 826
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HA73b0UNxvAlMzeWznyBAwYtxns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        87
        _dead_1559 = 566
        467
    total = value + len(text)
    return total

def _УЦЙфЮΦκЬιυ():
    value = 560153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nij+f3k9xpsSagKX4QG2Cw4r6l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИΥтТЛπνясЮлЭпЕ():
    if 50 * 37 < 0:
        _dead_7872 = 757
    value = 222227
    text = __import__('base64').b64decode('d19xaE9iZTNxeUpRaEVIZkF2X0Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9799 = 339
        662
        734
    return total

def _ΝЩмЧΒиТдмЫАΑАΞзν():
    value = 90614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBn+TQcxzZAwIDus3mG5DnIp5j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 25 < 0:
        _dead_2111 = 209
        786
    total = value + len(text)
    return total

def _χгэПюлйа():
    if len('') > 0:
        849
        _dead_5712 = 478
        676
    value = 239802
    if 29 * 81 < 0:
        _dead_2744 = 242
    text = __import__('base64').b64decode('Q2NfajBwbjhvZlhGQWRPemxseG0=').decode('utf-8')
    total = value + len(text)
    if 81 * 54 < 0:
        _dead_8732 = 74
    return total

def _αΛψΕЫмεΙицщηглТц():
    value = 64404
    text = __import__('base64').b64decode('T2dPMVVhN3lXa2dyeXpVV1FxZXM=').decode('utf-8')
    total = value + len(text)
    return total

def _йЧысπχσΤΑОΝдΛ():
    if len('') > 0:
        pass
        pass
    value = 657969
    if False and True:
        215
        pass
    text = __import__('base64').b64decode('THlkbTkzS2lGUE1YN09QdERfMDE=').decode('utf-8')
    total = value + len(text)
    return total

def _реэчρЪцΦкΡоν():
    value = 330849
    text = __import__('base64').b64decode('Ym5FbjhsS3dLUGFNU2RTenA5Z3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔХИатωηЭнГзэ():
    if len('') > 0:
        922
        _dead_6199 = 696
    value = 524722
    if 82 * 96 < 0:
        42
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwGzZGU38qMkKS6UwH+EZy4G1EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΞАΠξлЕУ():
    value = 40710
    text = __import__('base64').b64decode('Qzl5V0hlS0JTX2ZHbWxGdWtJWEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙКΙушДЖφΒ():
    if len('') > 0:
        _dead_6429 = 358
        219
    value = 72085
    if False and True:
        499
        _dead_7571 = 109
        _dead_7734 = 146
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhrlWFoR+pkSPFiRnn+hYyl3vTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4142 = 368
        _dead_8192 = 886
    total = value + len(text)
    return total

def _ρωЫГπщЭоЫуэчфЪЦЫ():
    value = 187629
    text = __import__('base64').b64decode('azFGNGJyMU5hYXQwRm1yMXB4OXo=').decode('utf-8')
    if len('') > 0:
        _dead_9609 = 845
        pass
    total = value + len(text)
    return total

def _φЧАΠЮΖХТэяτ():
    value = 596885
    text = __import__('base64').b64decode('SHIxNF93VlNNdXRoeDdxUU82Tnk=').decode('utf-8')
    if 3 * 21 < 0:
        143
        pass
        _dead_1798 = 901
    total = value + len(text)
    return total

def _тгдδмюЖкΒεрΚ():
    value = 375281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwXWenYq2poOECX7kFCTADwM7Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        675
        pass
    total = value + len(text)
    return total

def _мВтχДэшр():
    if 82 * 69 < 0:
        _dead_9367 = 785
    value = 295365
    if 67 * 62 < 0:
        763
        pass
        843
    text = __import__('base64').b64decode('TXRUVzFrczlMWVE5dG9XRGw2REU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬякВψЛДΡαСκ():
    value = 957001
    text = __import__('base64').b64decode('dThEeTJVQzVVaU93QUN3QktYYTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΠшΕУЕсшΕλвпσο():
    value = 922079
    text = __import__('base64').b64decode('QTNjbFNlNVJCSXUwSWlMVGRQNXA=').decode('utf-8')
    total = value + len(text)
    return total

def _НсВΥЧΛбпΦΑΨРжящκ():
    value = 276836
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Di20SkEoz6ssKliA4VK2MSI8zl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 42 * 14 < 0:
        pass
    total = value + len(text)
    return total

def _ιхГЗяЬкОмЯΠφ():
    value = 227133
    if 99 * 51 < 0:
        _dead_3575 = 420
        pass
    text = __import__('base64').b64decode('TU5uak9MZnlPeWZMd01KdjBlNTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫНльпПЯыо():
    value = 252967
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCXnVH5p9I4LNAuJxWHGByR9sH0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъЛΟΠЩуλЧΠ():
    value = 655763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICHXNkAX5vsybR2R2VC4NRcktHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еΖМааςуЭАΑ():
    value = 661169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDf+dnBuzIIxGxWg22mSLTIet00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        554
    total = value + len(text)
    return total

def _ЬμнЪΤжΔущнσυм():
    value = 753590
    if False and True:
        556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT7uY1Zr7oFbKBnx4FioHCYZx20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫτБкЪцЬΘΛфΥ():
    value = 484129
    text = __import__('base64').b64decode('WWZIR2U0ZlN4djJQZGk1RGN2bXE=').decode('utf-8')
    total = value + len(text)
    return total

def _квъФφУгплЗъбдθηж():
    if False and True:
        _dead_6027 = 324
        453
    value = 934426
    text = __import__('base64').b64decode('Z1lPNFk3VGNOb3hxZFE1MEtDdWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΟТΠЕπηжМγжτНΚθΜ():
    value = 100589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyD3Y0ggpvsEPzWU212+GBcLyFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        678
    total = value + len(text)
    if len('') > 0:
        848
        655
    return total

def _ΘМКМΦφмφЪПκбиΓ():
    value = 277325
    text = __import__('base64').b64decode('T2F2WmU5QXM2VEZ6Q2w5UWJUWlE=').decode('utf-8')
    if False and True:
        pass
        _dead_7040 = 985
    total = value + len(text)
    if 51 * 80 < 0:
        _dead_3282 = 341
        _dead_3564 = 375
        579
    return total

def _ΝυзтφяΠШ():
    value = 776931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh7zPEI//4UaMDqpywOTGD0Xw2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иαхДμΜΠЪ():
    value = 809661
    text = __import__('base64').b64decode('Q1ZwZkg4a2RxOUpHRFFXXzgwMDc=').decode('utf-8')
    total = value + len(text)
    return total

def _НχьпΙθцЮэМΤхЗΥ():
    value = 188415
    if 30 * 74 < 0:
        pass
        _dead_5729 = 470
        pass
    text = __import__('base64').b64decode('SmZTeDBFYTFYQzExNUhtTmpFUTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ХъФαйμАТ():
    value = 551087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBbebEcY+Y0tIA6TnHqZYHUe42o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        69
    return total

def _ξΣтΡТРИТирсΑΥукр():
    value = 830508
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwDcSlcV9Jknayb0z1XAMQQoxUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВФΜνФуХκ():
    value = 276136
    text = __import__('base64').b64decode('SU9IcHZpM0JMa1puVTJGclpfcWY=').decode('utf-8')
    if len('') > 0:
        _dead_2479 = 805
        _dead_7062 = 49
    total = value + len(text)
    return total

def _αΛцЪηХря():
    value = 711214
    text = __import__('base64').b64decode('VFpYWmE1T1FZX2lOdXVuT1dvd0U=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 95 * 74 < 0:
        370
        681
        787
    return total

def _ТΚΦЛΙдеωηιцЭЫы():
    value = 933753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHuzZGge9oMGLV/75UGkIjc74WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        13
        689
    total = value + len(text)
    if len('') > 0:
        19
    return total

def _νоΣοыαЧκΥпΗ():
    value = 858316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Li7yO0kQz7wQP1ex2gGJDRUYzFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘВιшаЩбЮΛΓξРПд():
    value = 127912
    text = __import__('base64').b64decode('YXIzVHJ4NEp3clpMMXhNWHBlNmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧταЮχыяКм():
    value = 94387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Djr+XgQD/5gkPy22mFmmI30m7Xg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФЫкпЮЩΑтΨНνярДЪ():
    value = 320904
    text = __import__('base64').b64decode('U25HRjBRellwaHdldGU5ZVBVVUM=').decode('utf-8')
    total = value + len(text)
    return total

def _аΝъΨΡΞНпαΥνф():
    value = 740057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BD61VAk65IMqHD675GCYbR8W1VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        731
        _dead_1727 = 846
    total = value + len(text)
    return total

def _σχЮцУαΓЦγοн():
    if 57 * 47 < 0:
        pass
    value = 106494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjzjeGEg2L8XIliF7VeyESd46Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΚξΓΙГΚвКο():
    value = 771175
    text = __import__('base64').b64decode('TE9NMHcxaGJZaVZJVUZrR3R3eHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΦΓЗЬнГπΟΦаζ():
    if 63 * 95 < 0:
        pass
        _dead_6923 = 487
    value = 795876
    if len('') > 0:
        740
        _dead_7775 = 370
        _dead_5941 = 349
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChD1PHsX77kPLDWhwnS9Pi540Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЕТΨυяхδсИΑτмΦΑ():
    if 49 * 98 < 0:
        pass
        798
        809
    value = 575747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyDoOnIs6J9WCA6iynC7IjM20X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 43 < 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        710
        _dead_9634 = 733
    return total

def _НяΜьяхεΚ():
    value = 815694
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH/oZ3A9pr8RKziK50TJBg0X72g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιΞмΝΔЛНЧмθхкξСЧ():
    value = 135257
    if 59 * 75 < 0:
        774
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQDoPFQK9bAbMAiV5GDDNhQN3ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 49 * 17 < 0:
        pass
        _dead_1372 = 251
    total = value + len(text)
    return total

def _ФχыАβΨΥЫΡ():
    value = 80850
    text = __import__('base64').b64decode('dVFQMUFRdXk1bXBpMGlya2pMaUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΨξлчΖΚвαцПРΜй():
    value = 831229
    text = __import__('base64').b64decode('bHpLQ2ZPbDF5elJXMFB3WDV3YWc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2910 = 691
    return total

def _нЖлΜυЕбДуχ():
    value = 287841
    text = __import__('base64').b64decode('S1FybWtYZlJ0dEFlUGVuUjBTMF8=').decode('utf-8')
    total = value + len(text)
    return total

def _κхСФйдγυЩ():
    if len('') > 0:
        pass
        _dead_7347 = 410
        _dead_7510 = 467
    value = 987655
    if 63 * 26 < 0:
        695
    text = __import__('base64').b64decode('VVIxbHlkX1I0NVl6Wm43NWwzVno=').decode('utf-8')
    total = value + len(text)
    return total

def _ςОτσθπЕПαЖГΧΟ():
    if False and True:
        pass
    value = 798057
    if len('') > 0:
        pass
        799
    text = __import__('base64').b64decode('dkVFZDdKSWhUaXUwS2MzbU40djA=').decode('utf-8')
    total = value + len(text)
    return total

def _υЬЖκхРДЧкЭζКΖΙ():
    value = 240943
    text = __import__('base64').b64decode('WGoyZzlRSTY3d1E2M0hpZEwxSFA=').decode('utf-8')
    if 89 * 81 < 0:
        501
        _dead_3497 = 834
    total = value + len(text)
    return total

def _УСББКГΖгΦс():
    value = 78418
    text = __import__('base64').b64decode('cU9jT0pKWExnQ09FUFpFUGJ1UzE=').decode('utf-8')
    total = value + len(text)
    return total

def _πърΘсηехмжАГЦαе():
    value = 585595
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzjdXHcJqp0nHB6a4GCoABYZ5T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜчФΒνСЕЭоΕпцΟγΛη():
    if len('') > 0:
        348
        _dead_4650 = 472
    value = 501886
    text = __import__('base64').b64decode('bXE1VGwwMGpNVFB4NUo1OTltOW4=').decode('utf-8')
    total = value + len(text)
    if 12 * 82 < 0:
        pass
        pass
    return total

def _ΕζСуλФνΨΨАΠТπлωГ():
    if False and True:
        201
        pass
    value = 989447
    text = __import__('base64').b64decode('aW1QRnpKMTE2RkxiazlKMzFZenI=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    if 7 * 14 < 0:
        663
        pass
    return total

def _дΣооΤЛКγ():
    value = 282288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBv3RmUBz7glKzn33w6nLit+3U0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΤБιΜЮКΜζ():
    if len('') > 0:
        _dead_9866 = 55
        pass
        pass
    value = 274350
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3/jfVYb0JFSay7ywX21Pnc30To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξюТВАЪБЮηж():
    value = 985609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiLyXktu7YIlGQHx4F64Jis2zz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГПΨΦпфЦΨЮαБω():
    value = 913944
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXnyRkkV9aALGQWn7gSlJgE24Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        258
    return total

def _нυАνфΜуЪыКк():
    value = 842095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXn0VFoA6qEFAD+C5EGKBRA+zTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τЮХЗΥЩΜыσхΧ():
    if False and True:
        17
        528
    value = 601599
    if False and True:
        687
        pass
        81
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCnvQ1suzoovEVry4nGpOAkZzXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭюΩΥεΗцΑ():
    value = 417656
    text = __import__('base64').b64decode('QTNiZnd6MmxpcmcyVG1ZOEdZVlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ьςΥИЦтЛБΒγАΑΦУ():
    value = 145570
    text = __import__('base64').b64decode('U0VkR3d0aWdGVzRKVDBpYktfODM=').decode('utf-8')
    if len('') > 0:
        _dead_6153 = 312
        _dead_6418 = 96
    total = value + len(text)
    return total

def _уΣζфσρДχΗПτПВС():
    value = 522508
    text = __import__('base64').b64decode('Z2UxTnRKNkQ4cEJLdU0yWGRvX0w=').decode('utf-8')
    total = value + len(text)
    return total

def _эВιпсλыпψзш():
    value = 359143
    text = __import__('base64').b64decode('RzZLeXlpRGo0VmVMZER1SkY4X3I=').decode('utf-8')
    total = value + len(text)
    return total

def _πДιяξΧщφωюρρ():
    value = 377626
    text = __import__('base64').b64decode('RHM2MGdFdUJIQWZyemdWdENJS2U=').decode('utf-8')
    total = value + len(text)
    return total

def _τжБΡчΟΘтθ():
    value = 269997
    text = __import__('base64').b64decode('bFd2ZHd3eG5wbjdsUHc2QlR6UTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛяИэМЧЬЦж():
    value = 408264
    text = __import__('base64').b64decode('dWZGdDQybV9VMU9CWVNTNnlWOXU=').decode('utf-8')
    total = value + len(text)
    return total

def _тιКМψΣцΠСηΝеΞВαФ():
    value = 868453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiP+SWcI1rwqFQLw+HKeFgAWtzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хбгсηлΦОΧγνхаОΕ():
    value = 976154
    text = __import__('base64').b64decode('dm9rd3M0MFhEUmkxTWVmWGV0bDc=').decode('utf-8')
    total = value + len(text)
    return total

def _еζΕужοвЫЗ():
    value = 839870
    if False and True:
        520
        403
        3
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnvvewQtrqsFNgalmXvCNQo640Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧЖςОΨеνμΑ():
    value = 338670
    text = __import__('base64').b64decode('TjBSRHFaUG1YbktqdkIxR3p0b00=').decode('utf-8')
    total = value + len(text)
    return total

def _экВωнГΥΞЙΙΧз():
    value = 759405
    if False and True:
        _dead_5248 = 989
        _dead_2901 = 295
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3flbQA6pv4wHDyS3nq4DRAesFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рцНσΦдΖХКοМο():
    value = 671480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3vCNloRp641ODmamGCTGxIkvF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оνιλβΡΟσωлфтι():
    value = 829744
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCTxRFofpoEhFwSw2EWWMwocxUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фгжοрΗяΘАГΦψ():
    value = 751906
    text = __import__('base64').b64decode('b3dRMXdVZWtzMHQweTJ6S3Rsc3I=').decode('utf-8')
    total = value + len(text)
    return total

def _αУζккПτТ():
    value = 812395
    text = __import__('base64').b64decode('SjRMTFp4VTc0ZTNwYWlHQXlZYl8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        664
        383
        _dead_9991 = 421
    return total

def _ГкюΔчюΩьекшЕАαυЭ():
    if len('') > 0:
        486
        pass
        _dead_2982 = 781
    value = 453139
    text = __import__('base64').b64decode('RlE1aTk3U3VxVmV4RjdMbEdXZUM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        982
    return total

def _ΚрмΒΖжКΧьваφσΙ():
    value = 110620
    text = __import__('base64').b64decode('Z2htNFN2SkF4T05sRlN0OUd1UEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ФЮφμОЗΙЬТξΦδ():
    value = 850242
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX7CR0AQ77AHHR/0wgejYhMg10M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥωТΡημΩР():
    value = 918173
    text = __import__('base64').b64decode('QlBDdHMzQlJBRVlYRjVETGNvbGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙнДНφМШιэВωщЦ():
    value = 571846
    text = __import__('base64').b64decode('UGt5X1p3VVZoQ2lac1NTcE9MSWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟотбЪяЫΙг():
    value = 292120
    if 73 * 62 < 0:
        _dead_6237 = 248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACf+aUASyosFOQeoyV3IDDI502Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 87 * 32 < 0:
        pass
        pass
    return total

def _ЩΛУΔЬηλΞΡЧφхИ():
    value = 20509
    text = __import__('base64').b64decode('SlJJRk5HbGw3Q1RCRHR3N2daWUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΓЯШοяАЛοΙΜσΔΘςΩ():
    value = 46819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By3hYkZqr5wMLS2w/H2mMnN8sHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξИхΖυιЗЯσЯΘВКй():
    if len('') > 0:
        _dead_7671 = 37
    value = 947588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FB/HaHQJxPEEKSuG3HiZYhwK1H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ояъβλΚΧыθП():
    if len('') > 0:
        pass
        763
        13
    value = 542998
    text = __import__('base64').b64decode('bUk0ZHdaYmNJTTVBQ29meVJVOGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ιθκфЖФΧлТυτ():
    value = 548768
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACi3amhh95gEOAu00E6vHDcnsDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЛмбγΥЕя():
    value = 441809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBbmencM8PE2DhvwwkTEHxUL8l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 6 < 0:
        _dead_6561 = 227
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if 67 * 70 < 0:
        _dead_5831 = 779
        672
        861
    print(__import__('base64').b64decode('IA==').decode('utf-8'))
if 16 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()