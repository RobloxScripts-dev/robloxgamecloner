#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ытξфΤΜΔз():
    if False and True:
        _dead_5425 = 281
        _dead_3804 = 232
        _dead_2104 = 533
    value = 96267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CniyQkQQ3IU7bymbwwGcETQ38Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 42 * 8 < 0:
        158
        540
    total = value + len(text)
    return total

def _люмьтьЬνлφюзЖСτζ():
    value = 138981
    text = __import__('base64').b64decode('dGpCeTJuakVPOFFMeGdsVFhVZF8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ЦОτЗΙτβμ():
    value = 515844
    if False and True:
        _dead_1053 = 74
        _dead_7901 = 750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cz+xS1kSqK0GHx6c+UGpEjQW1Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λВγΙаΚσР():
    value = 837031
    text = __import__('base64').b64decode('a05ZQUpBUjNvbEdaSm15R1c4cnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑΜφфЮΧрЮртЩ():
    if 5 * 73 < 0:
        pass
    value = 523123
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA3QSHItr6pbMzWsxH+AHHI39l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БЖβκηаЯφρ():
    value = 991003
    text = __import__('base64').b64decode('SjBsc1d0aHlkdHRRSjUySTV0Q2U=').decode('utf-8')
    if 47 * 82 < 0:
        _dead_1534 = 941
        pass
        146
    total = value + len(text)
    return total

def _пКτФЭΒгЗгШМΩЬЗ():
    if False and True:
        481
        760
    value = 607899
    if False and True:
        492
    text = __import__('base64').b64decode('V2dkTWg1WGFOejZYakl4ODJobkk=').decode('utf-8')
    total = value + len(text)
    return total

def _еЬяρЖΜοзАχшЖΒρц():
    value = 532978
    if False and True:
        _dead_4009 = 762
        764
        pass
    text = __import__('base64').b64decode('endhUFJZaXRyMzY4RlJqUFlLc1U=').decode('utf-8')
    total = value + len(text)
    if 73 * 42 < 0:
        pass
        491
    return total

def _мъρΡаαшЖсΖωыΚ():
    value = 970319
    text = __import__('base64').b64decode('RHF3XzJrSHFxaU55eVBlUzlYWkM=').decode('utf-8')
    total = value + len(text)
    return total

def _БψЬχкπцΧкΩАΓ():
    if False and True:
        _dead_2387 = 554
        _dead_7533 = 472
        652
    value = 381646
    if len('') > 0:
        _dead_9039 = 801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwjwUUhg6YY5Yg7x7WGaERA5w0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δВЖрαЕКЭΩФ():
    if 41 * 3 < 0:
        _dead_8851 = 624
        pass
    value = 819413
    text = __import__('base64').b64decode('YVdJbzdvZ2o3WEMzSWJ6NjhPTFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠχκСкΛЯΗκдДИцχЕΓ():
    value = 530329
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwPOYgAw7IFWBRaixXuaOz0+5Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        775
        pass
        pass
    total = value + len(text)
    if False and True:
        496
    return total

def _хΟрΔΙбομΧαлλΘωЩМ():
    if False and True:
        935
        _dead_4794 = 652
        pass
    value = 816882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDbnVFI6prICahaonkaDPBo36Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 64 < 0:
        768
        538
        pass
    total = value + len(text)
    return total

def _ξюнЖΒоЙлУть():
    value = 846439
    text = __import__('base64').b64decode('Sno1SUlaVW9jUEt0OExXSFVIOXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦФТφцΨαычζΙα():
    value = 94412
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnziTWlu+YJXOBuE0lS2LiMVsFc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        485
    return total

def _ОΚβΔΡιЭΤβыΟкДΕ():
    if False and True:
        _dead_5086 = 414
        _dead_4808 = 788
        _dead_1898 = 811
    value = 84035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR/vfXsM9KsKOznynkzJIxwK6ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 9 * 11 < 0:
        _dead_7027 = 13
        pass
        _dead_6835 = 817
    return total

def _ЫРщрфаЪΘб():
    value = 951990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDzKZURt7IsEEh2ZwVC1BDQ8w2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρЮψЙТΔЫСσ():
    value = 413881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHbOe3Rp0LoiKiKZ30bGESoN0HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 17 * 77 < 0:
        pass
        pass
        pass
    return total

def _ΦмиЕτΘАРушЦΕубΞΨ():
    value = 303105
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHvWaVoT2I8VAzmFnE6/Fg4Xx3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        808
    total = value + len(text)
    return total

def _еАΡвыΓжπУдХΘΝ():
    value = 121184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H33BawVh5qUqHCGTxHeaYCsqz0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΟЫАжμГβСΙеК():
    value = 231268
    text = __import__('base64').b64decode('RXZBMDBEUG9fdGo1dlZBZUdpQzg=').decode('utf-8')
    total = value + len(text)
    return total

def _АΧитθψЯΦвβρΚρΜа():
    if 51 * 67 < 0:
        pass
        _dead_7573 = 860
    value = 509024
    text = __import__('base64').b64decode('dm5yQ3RYXzJlc0I2WWVUZFJNcjY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧτгНчΠйтфВθДд():
    value = 439852
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax3PZFsXy/kTPxj23ECKZDUd3ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЭΗЫουΝαГαш():
    value = 282588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAHwQVYe77sbFxeh2Q+FMRUg8zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТуЯаБдшкΥ():
    value = 560968
    text = __import__('base64').b64decode('dWRmZTVHbFVFRlNRbkdNMlVGMzk=').decode('utf-8')
    total = value + len(text)
    return total

def _θΨзΧγСφшΣЯμφуψмщ():
    value = 445147
    text = __import__('base64').b64decode('SVgzUlU0MWpOWEhTXzI4bE1IM0c=').decode('utf-8')
    if len('') > 0:
        _dead_4918 = 633
    total = value + len(text)
    if False and True:
        _dead_8342 = 720
        658
    return total

def _ЛшПТйКЭН():
    value = 698479
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCLiP2cbqbsQHy6C3gLHJQkt90Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΛвΑΝφτЬюΤμβтυ():
    value = 449738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FT78XGMSqfkxCSWq0XOiFis57WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕтЙаΔхцйη():
    value = 310281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PS7gQmEV0LoEMxiGx1HCIj0i6mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞЧХойκеΣΡχ():
    value = 382529
    text = __import__('base64').b64decode('RkNCSmo4XzQ3Yzh5QzRVTGlYVHE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЖβаΡΣσЩЦθАκк():
    value = 909194
    text = __import__('base64').b64decode('bk5VdVdwVmlWYlM3WF9QZDhyUUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ШдЛДΙРξдЙрφДΘ():
    value = 961953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTXsT0EQyr0FOAmN+gWoAw56sW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лъвΧпйυрψΣаΛΧ():
    value = 291648
    text = __import__('base64').b64decode('WDhRMEk2TzRkNGVnM3o5Q0ltMXY=').decode('utf-8')
    if False and True:
        620
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_7229 = 843
    return total

def _кΨиуΟΗОΤγΘЗйВж():
    value = 867831
    if len('') > 0:
        pass
        904
        pass
    text = __import__('base64').b64decode('QVpGc0xHOTB6R0J3ZVg5VHZ1ZmI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        283
        594
    return total

def _ыΕςΡмβгОθ():
    value = 144304
    text = __import__('base64').b64decode('THozaFlLZnhMVXRkT0NjUFp2TXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΨΔОбΓλΖΠΒωНΙΩ():
    value = 987606
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERzmQElqr5kZMFqE5UWvHRUoskw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΤφфГυыφψΤΙЮхΒЗ():
    value = 363266
    text = __import__('base64').b64decode('ZXUxaTZuMXBUOF9xT0dtOVd5UnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣΙРΚΣАЮшъмнЗΕ():
    value = 518491
    text = __import__('base64').b64decode('anJ1enRpTzM4ZFZ1NlFIV040bDA=').decode('utf-8')
    total = value + len(text)
    return total

def _мΓνΡΙΜΞΟеΑξТωφ():
    value = 29542
    text = __import__('base64').b64decode('cHgxYkRQRUFvMmxtNU1iME5QRlM=').decode('utf-8')
    if 42 * 83 < 0:
        pass
        pass
        _dead_3099 = 905
    total = value + len(text)
    if len('') > 0:
        _dead_6562 = 57
    return total

def _ΕνУνБςςβΠпмΔμ():
    value = 211993
    if False and True:
        811
        _dead_2378 = 849
    text = __import__('base64').b64decode('RWU0Z2xGTjN0d0k5akZZU0hzdUU=').decode('utf-8')
    if 8 * 60 < 0:
        pass
    total = value + len(text)
    return total

def _ЛЙюАоστηιЪΑЫМΠΥα():
    value = 415014
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBzdQ18z3fkXLj+n0gezPDB89WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЛИσВеπσωГБμΩΒ():
    value = 982579
    if 34 * 25 < 0:
        _dead_1354 = 186
        _dead_7034 = 822
    text = __import__('base64').b64decode('Z0Y0QnMxOFBsVG9Sa1BuZU1vWWc=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _яМЧΝрπΙЫыΥ():
    value = 805762
    if len('') > 0:
        432
        248
    text = __import__('base64').b64decode('bTBzVzBRV19tQ3BKa3BpTVVCWEY=').decode('utf-8')
    if 5 * 76 < 0:
        pass
    total = value + len(text)
    return total

def _ΩОрзΘΠФЛлЫ():
    value = 148927
    text = __import__('base64').b64decode('QmI0SVpvUDd1b3pQVDdNaHZYT2M=').decode('utf-8')
    total = value + len(text)
    return total

def _йΚЛтМρХΨδэΣбδ():
    if 93 * 86 < 0:
        _dead_3831 = 80
    value = 791222
    text = __import__('base64').b64decode('QWFRczR0YUtYdGhRWExBMmNTSkI=').decode('utf-8')
    if 37 * 18 < 0:
        _dead_4347 = 52
        938
    total = value + len(text)
    return total

def _ΙυδьщεХЫζыДОъ():
    if False and True:
        pass
    value = 520037
    if 85 * 22 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSPAWgU4qr8QIxyZw1mmIX19y3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠаФΔЮΗйкΣю():
    value = 399603
    text = __import__('base64').b64decode('VjhDaTBlcGtzMXhZbEUwNHBhbjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖшЬλφΔэг():
    value = 428697
    text = __import__('base64').b64decode('bmMwRmU2U19GdXd3RUdMdGhVNUg=').decode('utf-8')
    if len('') > 0:
        _dead_3801 = 9
        _dead_3499 = 262
    total = value + len(text)
    if 37 * 32 < 0:
        pass
    return total

def _хγτъФчщСыΛΚоыяκе():
    value = 592989
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDfCeUs9z4I0OAit2w+yNzYg000='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 96 * 56 < 0:
        _dead_7361 = 834
        905
    return total

def _ЭВХпβжΟν():
    value = 468351
    if len('') > 0:
        pass
        pass
        800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgrsSlAdrb8xFCOK3FvEHycrt0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        208
        _dead_7980 = 151
        _dead_1819 = 313
    return total

def _ΤΖгпωмэрзЬф():
    value = 204367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRz0VkIT+JkPClf3xVq4ITc822w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уоиΨψдеςηРЛΠΔδб():
    value = 141018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pz3yf2k3+IMiagea+1LEGDQJtGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РшΔΕиарΕ():
    value = 643316
    if len('') > 0:
        23
        _dead_2180 = 54
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCbXTAQGqY0OFSSE32+/Zzcj9EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гриЮРщχеэьπщгкχρ():
    value = 118872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSv0XnA+/LFRPxeU92a3OxUHwzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЮлθωζωдпΣχη():
    value = 289811
    if False and True:
        976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3fXSXIWr4kOBQy3mAG/HQwh0Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юπЖφСΚгθПεш():
    value = 630505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSjzZWgb1L0xbAuo+0GyC3YF7G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        618
        _dead_4374 = 270
    return total

def _гйъсЭкπИθьζο():
    value = 408651
    text = __import__('base64').b64decode('THBfN2M1UURJZnNTbVpoUjNvR2I=').decode('utf-8')
    total = value + len(text)
    return total

def _τхнйтФΟл():
    value = 351511
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxzbRXs9wZo5Kln7wk/GEwYIzl8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Лχьγщгъκу():
    value = 543012
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ES7WRgU2yKs2KwSp0F+CEAgIyT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _κПσкξγыЛНδνγДНρ():
    value = 272341
    if len('') > 0:
        pass
        _dead_4080 = 546
        _dead_4204 = 723
    text = __import__('base64').b64decode('UE1LYnhMMW1Mb0Y4MVI2Zl9UUk0=').decode('utf-8')
    total = value + len(text)
    return total

def _эκнκξΨто():
    value = 851061
    text = __import__('base64').b64decode('Q0tYeU9xSkY0QjZOR1k5YUF6SHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΒθзьΖεφοΔУψбδ():
    if len('') > 0:
        pass
        _dead_2040 = 991
        _dead_8350 = 90
    value = 292059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ljv8dl0A04NbAxiCnF6fMysgtDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧКΣψАыζЬδ():
    value = 818789
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRjTQFwSrqJSDDq3xQSXBzQuy2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        818
    return total

def _ΠцлЛкΦчβьχΦОЬ():
    value = 371977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR/FN30fqf45FF+J/GCTAAkttVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΤΓчтсΞЮнСэЩвΔСЖ():
    value = 496940
    text = __import__('base64').b64decode('dzZQZlVhOUhyeTJJVF82WU5YWnY=').decode('utf-8')
    total = value + len(text)
    if 42 * 78 < 0:
        pass
        927
    return total

def _ьГЕΧЫДγγχΞЮ():
    value = 922202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CinSRlUG1qQpFhaPxGWlETV78Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        774
        981
    return total

def _ТεκεршчДББεΙ():
    value = 462868
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LC7zR1IG2KowKwiTwETINSsbyEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йτЛиХβЩοοιэнΕс():
    value = 746364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ES3eRgIe6bkHaCq25lmkBgEmxTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПъγφкΖшπ():
    value = 382148
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lx7ne3lu/48VDlyh/gaEGCsst1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υсжιзаθюбθ():
    value = 413825
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT3caWs36f4nblqI+mfIHg06sGc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔэНгτЬаσЯшςΕЫГОЭ():
    value = 780767
    text = __import__('base64').b64decode('VGNsZkVrd29fYXBTRE5FaXpEdEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠшВωмσюο():
    value = 385898
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHn+QX5rxPsrHBaInmeVZhw73kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РνΒοРΦХΘю():
    value = 474168
    if len('') > 0:
        _dead_4063 = 683
        pass
    text = __import__('base64').b64decode('dUhWamVDY0lTQlZxdmlfa2liMTI=').decode('utf-8')
    total = value + len(text)
    return total

def _γэпЩΓΜПаφпη():
    value = 190563
    text = __import__('base64').b64decode('SjVFbXFhc2R2Z0tUR2RHdmNVNko=').decode('utf-8')
    total = value + len(text)
    if False and True:
        675
        882
        pass
    return total

def _жΚгαγЩκΓΘрΒШ():
    value = 695930
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D37LSXNg8vlVAi67zXi+bTMixVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓΘχвΤνчνПыБςЛ():
    value = 737274
    if len('') > 0:
        _dead_9818 = 699
        630
        pass
    text = __import__('base64').b64decode('VGk0cUY1YkhTc1NHSjdfZWpVc3A=').decode('utf-8')
    total = value + len(text)
    return total

def _зиЮΨΕИРфАΥ():
    value = 932108
    text = __import__('base64').b64decode('RW9hRExHOElpazRmOGdwd1hiUlE=').decode('utf-8')
    total = value + len(text)
    return total

def _СΖзνΛΖнλΜпИЮΒы():
    value = 718169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JALOeHc46qQqCwmAmlqHZxMWznk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λγρκηΔДψΔΑνееЩШψ():
    value = 883064
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSbWYlxo9/E6LFiH+VeICygd6k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΕΥхΗΕжωγμΒ():
    if len('') > 0:
        _dead_7037 = 624
        177
        _dead_5282 = 318
    value = 631230
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXb+YmJhpv8LIjq74V2GPnI/zlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 14 * 45 < 0:
        _dead_6551 = 528
        _dead_6968 = 638
        pass
    return total

def _щщρоЭюуоОК():
    value = 302574
    if 14 * 8 < 0:
        _dead_6959 = 255
        _dead_1231 = 696
    text = __import__('base64').b64decode('UDJXYXJNVlBTaHdWOTZPSENGZG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛτΠжипΙσΦ():
    value = 72358
    text = __import__('base64').b64decode('ZGpPd21ZdWp4Z3IxVkJoRUhPU0o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕяЗнЮЫЬщΓΡΨцОЬФ():
    value = 570748
    text = __import__('base64').b64decode('d0NKUEtaY2lkZ2hGcXJEZXh5ZGo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        205
        pass
        _dead_9396 = 397
    return total

def _цЭмΔеэЪшЗδСω():
    if False and True:
        _dead_4034 = 853
        _dead_4562 = 14
    value = 686303
    text = __import__('base64').b64decode('UW93aVJjeTE5N2Rvc3VOY3FQcnY=').decode('utf-8')
    if 95 * 74 < 0:
        864
        pass
    total = value + len(text)
    if len('') > 0:
        926
    return total

def _ψΠρЛξΠΙρДΚπΛ():
    if len('') > 0:
        _dead_9700 = 136
    value = 592741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fh7NWHwz7ZlWIgKt7GKTCw59xls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _зξζйэЪОсΥк():
    value = 162751
    text = __import__('base64').b64decode('YUl2WjJvRTgyZ0FLU3VpQ0tlYnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ςцНΝΖУЭВΚ():
    if False and True:
        pass
        865
    value = 788685
    text = __import__('base64').b64decode('c3RpQ1B4cVJRTTJ3TVA4NEo2Y2Q=').decode('utf-8')
    total = value + len(text)
    if 31 * 73 < 0:
        _dead_5252 = 385
    return total

def _ιеΕχЪдγΤяСηдΤШОΘ():
    value = 450499
    text = __import__('base64').b64decode('Q2puTWN0cml4WkthUUxsMEVGMGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕкдζЦыηЯξд():
    value = 769470
    text = __import__('base64').b64decode('b2YwUGVHTFpjbGRsQXd3ejBhWjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _μΟбΟοΠЩтςй():
    if 44 * 88 < 0:
        _dead_8309 = 712
        _dead_8805 = 992
        248
    value = 74693
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASvpXmsG6ZciazyAnHicEy8i4kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_7562 = 155
        pass
        284
    return total

def _ΣΧΑтЪщЭЩЬΓйδЩОоΥ():
    value = 663589
    text = __import__('base64').b64decode('aFBYVmQ3c1ExNUYxQ2Y4Y0sxblU=').decode('utf-8')
    total = value + len(text)
    return total

def _λριΕтοδЬΨВζτЮ():
    value = 907351
    text = __import__('base64').b64decode('YWRnY2FobnhfeXZTOU5OMUpra3k=').decode('utf-8')
    total = value + len(text)
    return total

def _йωЦхΒЭЬвΑΗ():
    value = 631452
    text = __import__('base64').b64decode('dUZaVndoZmtuaDBRWXdSRzNvemM=').decode('utf-8')
    if False and True:
        pass
        _dead_5560 = 632
    total = value + len(text)
    if 97 * 29 < 0:
        _dead_8814 = 418
        _dead_5981 = 546
        825
    return total

def _υςРΞщмφχ():
    if 59 * 27 < 0:
        306
        _dead_3927 = 273
    value = 639128
    if False and True:
        _dead_8079 = 60
        _dead_7642 = 388
    text = __import__('base64').b64decode('RzBTWW8wc3BMRHBzSjJRY3hfYWg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        15
        464
    return total

def _ГфλкВΧЩБчн():
    value = 339193
    text = __import__('base64').b64decode('cWtvZm1xYTJpSXhBM1dRNjNsclk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩΡηвЪцσρУΑφЮΘΘьэ():
    value = 444459
    text = __import__('base64').b64decode('UnBsRll6c0RDWjJnODZYOENBV1M=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5531 = 242
        669
        _dead_5475 = 102
    return total

def _РΝθБПΧХΟλКγК():
    value = 145219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj3MRl8tr44wIiqH4nSFYik1vVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τεоπЦΜΛЕΜШσ():
    value = 475458
    text = __import__('base64').b64decode('Tk5ZY3RuUXAzUGJlNzczQkRDcWg=').decode('utf-8')
    total = value + len(text)
    return total

def _рзρμρρОЕηΝЗ():
    value = 340739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mw7RSXo98b8xEBmZ/meeIw0Dy1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 9 * 85 < 0:
        pass
        _dead_7669 = 603
        _dead_2703 = 504
    return total

def _ςςγИΑнηФЙ():
    value = 17123
    text = __import__('base64').b64decode('cmZ2eFRWY0lwVnp2RlJRMUdiS28=').decode('utf-8')
    total = value + len(text)
    if 30 * 94 < 0:
        _dead_8252 = 718
        _dead_1888 = 659
    return total

def _яλяΣΣъИыШЪθжμДΡШ():
    if False and True:
        _dead_8692 = 322
        775
        _dead_6132 = 670
    value = 597687
    text = __import__('base64').b64decode('RU9RVkEzVW1BR0pDamlCNzZJWFk=').decode('utf-8')
    total = value + len(text)
    return total

def _йΞвшΦДкьЮβХΦ():
    value = 337847
    text = __import__('base64').b64decode('dkpCanJHNzd2b3RpM2hGVnpwWXY=').decode('utf-8')
    if 71 * 4 < 0:
        232
    total = value + len(text)
    return total

def _ηФкйБΦЮΜнνяУ():
    value = 222420
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAHiQlI4z60ZLxyy/FCoEhcHyG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕЬеЮθТΘΩυΑλТδΩСτ():
    value = 140066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR3pbHctrLkoNDCRmUS+MC4o9nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8466 = 443
    total = value + len(text)
    return total

def _мГЙξλЫУацγМъ():
    value = 89685
    text = __import__('base64').b64decode('c2prYnlhNkV1andVRm9YclNQdWk=').decode('utf-8')
    if 7 * 11 < 0:
        pass
        _dead_9976 = 772
    total = value + len(text)
    if 80 * 3 < 0:
        pass
        pass
        217
    return total

def _ΜЕйηηИЯтζз():
    if 8 * 53 < 0:
        _dead_7069 = 608
    value = 256869
    if len('') > 0:
        206
        _dead_2018 = 667
        290
    text = __import__('base64').b64decode('T1ZxWXhnMjBxUWFZZzhSOGdoODQ=').decode('utf-8')
    if 19 * 24 < 0:
        _dead_1204 = 657
        _dead_1201 = 847
        169
    total = value + len(text)
    return total

def _μΒсЮΧΟЧЙВря():
    value = 156859
    text = __import__('base64').b64decode('R3pDZnlZUW9WSFVhanh3RlJqNDM=').decode('utf-8')
    total = value + len(text)
    return total

def _λтοсьсфЯхпцХВ():
    if len('') > 0:
        pass
        664
        _dead_7940 = 133
    value = 471308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IX7XWlsf05oZMDiInUbIFQMY8Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 35 * 59 < 0:
        103
        781
        _dead_4664 = 611
    total = value + len(text)
    return total

def _ΣСНЮμрνКνптлЬпп():
    value = 260215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyfbSUgv8/1baVak3nK1bRAt7Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬΣςаЮσНФЪОАЩкλ():
    value = 750021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgnvRGU3/flbCDa5xGDEJCIK7Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йКкОΙфлоχκДΤа():
    value = 398019
    text = __import__('base64').b64decode('S3B5QmI3MkE0MXY2Rndoem5uV3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙгΙфαОοφФχКτГгрΒ():
    value = 395173
    text = __import__('base64').b64decode('amFXWGdSUlJUbjlMTFdCME5BaDY=').decode('utf-8')
    total = value + len(text)
    return total

def _зΙЬииχУСΥτΔбααΣ():
    value = 322842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATz1PUNpwYUFGT2q/U+7BQsK7Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        192
        pass
    total = value + len(text)
    return total

def _сΥΠЫΚΩλΑЫНаπ():
    value = 902180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHnHNwcv0PokMxuNx2m7OQZ2/X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дБΒφρЙψΦыОвγ():
    value = 421174
    if 84 * 19 < 0:
        643
        885
        656
    text = __import__('base64').b64decode('ajVBcGlGb21UcFIzNEV3OTRzREw=').decode('utf-8')
    total = value + len(text)
    return total

def _σΚθпΔΩΔΘч():
    value = 820271
    if 82 * 38 < 0:
        _dead_6327 = 42
        pass
        _dead_4905 = 935
    text = __import__('base64').b64decode('bWp3QTc2WVBMczVjb1dxYUhqZmc=').decode('utf-8')
    total = value + len(text)
    return total

def _КЯУΜΛзΛσоод():
    value = 782344
    text = __import__('base64').b64decode('RFh5RktVTW5ZTXJKX1JZaF9VWmo=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _σОχжъИРЛЖιиΠБл():
    value = 949313
    text = __import__('base64').b64decode('QWJKdklNaDZla2dfZ05LbkF3TjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤΙψНγНШαЕГ():
    value = 435208
    text = __import__('base64').b64decode('WmRqU1hiR2VBbzhXcEJvODVpQmo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΣеяΖьЮПΛΘгЬκΩ():
    if False and True:
        121
        656
    value = 550161
    if 9 * 12 < 0:
        pass
    text = __import__('base64').b64decode('aUM3WjJGUXROQ3BnazlhQXlraFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜмОтПчтйхνЯаυΩз():
    value = 812018
    text = __import__('base64').b64decode('Qkl5bEdVYzN5YnJqSzRTcU9BZkU=').decode('utf-8')
    total = value + len(text)
    return total

def _κΝЖЯГлЗтМΓпщыаψШ():
    value = 121901
    text = __import__('base64').b64decode('UUpYaDhxV2NJaTd4Y0xiQlc2Zjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΘΠΣнβψянχΔПΝМэк():
    value = 448272
    text = __import__('base64').b64decode('dWJvaUtMSHZON3V3ejVvVlRVNkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΑεХВΘуюθР():
    value = 776315
    text = __import__('base64').b64decode('TFpkWlRKTjVUams0bnhZbWVUY1E=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЪζυИΡлДАцЙΧп():
    if False and True:
        pass
        4
    value = 537264
    if len('') > 0:
        _dead_3110 = 730
        _dead_9309 = 285
    text = __import__('base64').b64decode('bHlRTjc5WkswRVAzaGUzZ2tnWDY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3004 = 572
    return total

def _ТУхΙУχШтЙЩβΗнκхф():
    value = 693001
    text = __import__('base64').b64decode('andJaTVjckdOc01wZGViMU10c2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ρВΘΓορΟηхЙТιЦΔК():
    value = 160414
    text = __import__('base64').b64decode('VFZGRXEwT08wQXprd1NWX0RmVV8=').decode('utf-8')
    if 63 * 23 < 0:
        pass
        _dead_9667 = 216
        pass
    total = value + len(text)
    return total

def _йГЖцдяыШΑцχиκΤΝ():
    if len('') > 0:
        _dead_1066 = 55
    value = 294347
    if 35 * 100 < 0:
        pass
        129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXzBWAA8rLwkNlap8GKiHSQD/ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тιφσаσуТ():
    if 15 * 97 < 0:
        pass
        712
        _dead_1453 = 813
    value = 531985
    text = __import__('base64').b64decode('c3VWMWYybFJnc1NMb0dCdTg0cTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘτщмчЖαΤΡф():
    value = 473834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXvONgIc/Z9XCT6BzACDBywc6mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        950
    total = value + len(text)
    return total

def _еЛьΘЧХΖаПΒЗΛыΛЫγ():
    value = 832780
    text = __import__('base64').b64decode('UnAxNkUycTREdl9jc3VGbkxodjY=').decode('utf-8')
    if 7 * 78 < 0:
        pass
    total = value + len(text)
    return total

def _ЫмφΛЪхΜΛЫΔΝь():
    value = 540767
    text = __import__('base64').b64decode('ZzRKbmVPZkd3WUJsczY0RHF5ekQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙνЩДЮыΞоγТОηΘ():
    value = 214987
    if len('') > 0:
        _dead_7650 = 877
    text = __import__('base64').b64decode('SEtRT290UnE3emdRb2lSelVKUU4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ОΥъоДΖрНΓ():
    value = 780124
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBn0eHMV8Yo7CCWC3USoAHYsxW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭиЦнэΠСьН():
    value = 801123
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATrHWVQh6PoVPSqG8mSTYTAqxls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΘЗζажζΓхЮУΤ():
    value = 191533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyT+d2EW0awtP1etmXCEJXwjsFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΦчрΡυНв():
    if False and True:
        572
        _dead_2703 = 231
        _dead_3416 = 968
    value = 278441
    text = __import__('base64').b64decode('TnBLMkFScnlSMFI2dFBTX0UzenQ=').decode('utf-8')
    total = value + len(text)
    return total

def _сΠуфИΡΡВ():
    value = 819426
    text = __import__('base64').b64decode('VzVkRFJFZnVoU3JuQlFmNlRvWVE=').decode('utf-8')
    total = value + len(text)
    return total

def _Лъьчззιш():
    value = 626302
    if 57 * 85 < 0:
        887
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En3GWGYoqbhVAjn760ORGnYC5X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _юбΧХюΖИξл():
    if False and True:
        _dead_9397 = 688
    value = 604585
    text = __import__('base64').b64decode('TXFlXzdabUsxZklocGxRUnNmSUY=').decode('utf-8')
    total = value + len(text)
    return total

def _δΞаΔσφκΧΑОПΗ():
    value = 350696
    text = __import__('base64').b64decode('RWlVeGdEU1RVQ3BWZ0EyTlBCYnk=').decode('utf-8')
    total = value + len(text)
    return total

def _РπэТρчηЛΘρЖΝШξг():
    value = 95460
    text = __import__('base64').b64decode('ekVKR1V0ZlFiT0haN1EwcW9saUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _εяэθУΩμляιюςЫЗΛ():
    if 41 * 21 < 0:
        pass
        _dead_9559 = 564
    value = 988406
    text = __import__('base64').b64decode('SEJCZDNPODIxYnZlazdrVE5FbnA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2470 = 189
        _dead_2168 = 783
    return total

def _ЧЮΘΕΓΟρфΝхНш():
    value = 231137
    text = __import__('base64').b64decode('bUxxek9BUThOZTJkUGhISTkzRWg=').decode('utf-8')
    total = value + len(text)
    return total

def _фΘаХЧАχЫζ():
    value = 297167
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3j2b2Ftwa47Lyam4g+9PnU9vE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΨΒЦμхВΥλъΨωв():
    value = 723955
    text = __import__('base64').b64decode('alFZUVAzQ1RGcVpfY3ZtN01XRkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯчфЗПΣчМдЩДЩСδю():
    value = 680967
    if False and True:
        _dead_6088 = 127
        511
        485
    text = __import__('base64').b64decode('dDVLNUdVaU04dlFVSk9WWGpzQlY=').decode('utf-8')
    total = value + len(text)
    return total

def _πΝпφЕΙΗтбь():
    value = 512983
    if 16 * 95 < 0:
        pass
    text = __import__('base64').b64decode('VGMyMURzdHlpOE5ZRHFKX1pTR3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ζЫТμняΓψΦЗ():
    if 66 * 11 < 0:
        pass
        729
        pass
    value = 663868
    text = __import__('base64').b64decode('QXdGVms5dGxYeEpMdFRDdmVTUFI=').decode('utf-8')
    if len('') > 0:
        _dead_8165 = 706
    total = value + len(text)
    return total

def _эчЦьХκΞМЩуИΣΖНτη():
    value = 200700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBrlR1MQyaNaIDyM+1uzJRMK4jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПμЧАзЛбψΗαЭЛф():
    value = 559299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRjWXFUN9KYxFhqiz1LHInx38mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 29 * 44 < 0:
        _dead_7209 = 50
    return total

def _ЗОςΥυΓЬэΗ():
    value = 149633
    text = __import__('base64').b64decode('TUVtTzNKQ0hYS1hpM2d0SkVjWDA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯъцюЙΨгЧКСκΡςК():
    value = 948754
    text = __import__('base64').b64decode('RTB2NXVMSXJicjl6Uk1GNnNfbHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙЕРκщеβгο():
    value = 48822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBrGVmk7560tPh+bkEy6PyJ/0G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еШρλеРФббωжΞТεχΞ():
    value = 585689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA3HfnYy6PABPAabzVilAgcI1Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хσΖΚъξΤΝЭКΠαщ():
    value = 325904
    text = __import__('base64').b64decode('TFFRZzdaU3V1Qm12WWRwb2FxSEM=').decode('utf-8')
    total = value + len(text)
    return total

def _φфΑнλЖνΖЮ():
    value = 772516
    text = __import__('base64').b64decode('WWtObWVFWlNXQmpoWjRNa29zQmI=').decode('utf-8')
    total = value + len(text)
    return total

def _жΡеЕвφаιπ():
    value = 808379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nx3KaFoT3PFbMySskQ6HAyA/3m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙЭшВщπРκΒΝзжηΦΖС():
    value = 623446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiHyQEcU0ZoKFF2o5QOoFTYW/Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪВФπΙЪКа():
    value = 444216
    text = __import__('base64').b64decode('Zm5GUFRNVVFVWEVGcXJIRk55c3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЕЭБΣξьθΣб():
    value = 144091
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('ZzlDQUlINk1vRGNCZzBIb1hYM2k=').decode('utf-8')
    if 71 * 86 < 0:
        486
    total = value + len(text)
    if len('') > 0:
        446
    return total

def _φбхαфТаЮа():
    value = 72757
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwDxVlAYqbhSECuZxg6WFQ159zc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5411 = 862
    total = value + len(text)
    return total

def _ВΗилηΛфцζЖγыΖ():
    value = 879162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Czr3ZEA7z5k1Nw6KyXTAODIMsX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гцхЛτБЪθ():
    value = 716083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhXXfkk0/64kbh37zFWbDiEJ5UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9215 = 952
    return total

def _ЦщтяδχρщΔ():
    value = 949726
    text = __import__('base64').b64decode('YVF2ZWt4NkFib01Xa0V6TV9vV3A=').decode('utf-8')
    total = value + len(text)
    return total

def _БИαταΓμΩэкΩН():
    value = 535319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQPUVmEt86wNFCOr8g7DMXci/FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΤиΛгюЭО():
    value = 636360
    text = __import__('base64').b64decode('aDVCMWxiNXU2SjQ2OXpnendhcks=').decode('utf-8')
    total = value + len(text)
    return total

def _зИζсηгыФ():
    value = 517307
    text = __import__('base64').b64decode('Ym5RYVJNOHFmQVJQbVp4RXk1U3c=').decode('utf-8')
    total = value + len(text)
    return total

def _АщшΕввμΤε():
    value = 419991
    if False and True:
        _dead_7783 = 628
        _dead_2302 = 701
        994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MT7QaWRp8qIzbS3y5WylOw4B/Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΦТоТЩЭБлδТδψΨ():
    value = 985787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiW0RH8M37oLbSWy4HSfFhUb7UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9784 = 830
    total = value + len(text)
    return total

def _йΑμЧεζφσлхοОщδε():
    value = 68674
    text = __import__('base64').b64decode('UEFhUnptczVwbXZCTzd5TmtUU2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΤжΓΒТОеЫΘ():
    value = 604629
    text = __import__('base64').b64decode('RjYya0RwdG16UmsyMWlFa3M2TEs=').decode('utf-8')
    if 7 * 5 < 0:
        _dead_3090 = 336
        _dead_7460 = 50
    total = value + len(text)
    return total

def _ЗΙΧΤмЪЪλω():
    value = 798603
    text = __import__('base64').b64decode('UnVGTzJWTzNyMGZjS1BpdGlPMHo=').decode('utf-8')
    if 22 * 1 < 0:
        pass
        832
    total = value + len(text)
    if len('') > 0:
        58
        925
        pass
    return total

def _κσΠГΓθΒЮЛпλЯδ():
    value = 477546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiHLfglqzYszEjua0kGEAhEK1Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εΑεПτΡλΜΓπмдδЯ():
    value = 771699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fh/OeEtpypFbNgiv2W6mHA84vVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωоΥоуωпшΨΓл():
    value = 589492
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KinLfGY2rIcEFyyZ+g+TPygk20M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χТυпИΨνМ():
    value = 872606
    text = __import__('base64').b64decode('T1Z4WGJJMVF2ZDBVVl9uQmdJMFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()