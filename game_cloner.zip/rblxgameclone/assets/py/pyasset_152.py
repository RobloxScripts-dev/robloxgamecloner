#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _πΒоΠЛΤоΝλΡъΤΨъΑ():
    if 91 * 95 < 0:
        245
    value = 162071
    if 61 * 14 < 0:
        _dead_5289 = 658
    text = __import__('base64').b64decode('QmxTc1VkNmJXdVV5TnpsN0s3VGE=').decode('utf-8')
    if False and True:
        840
        4
        997
    total = value + len(text)
    return total

def _ΣΧЮУмэΤνкΩ():
    if False and True:
        pass
        _dead_1078 = 678
        _dead_7605 = 524
    value = 103214
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nibrd2MJ2/sODyGk/1OpHX0K90Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 96 * 13 < 0:
        pass
        pass
    return total

def _пвΘРτКΔΙτ():
    value = 292116
    text = __import__('base64').b64decode('SlZoT2h3MktTbVZVb3h3emRIVlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ъЕеАЭδΟΟЖДЯтЗпИВ():
    value = 767483
    text = __import__('base64').b64decode('SlZxMzNnOWQ1SHBvUlJzSDZFQXA=').decode('utf-8')
    total = value + len(text)
    return total

def _δжхΛΗГифνσμ():
    if 14 * 81 < 0:
        pass
        _dead_1359 = 575
        560
    value = 5907
    text = __import__('base64').b64decode('eTFyeTdWZUw3RVR2UlphMWUyNlQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_6392 = 139
    return total

def _ОμΩΧыωψβЙмΞΘГл():
    if 16 * 96 < 0:
        pass
        _dead_8408 = 580
        pass
    value = 428408
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT/sSVM93YMbPjysmXSoESkAsFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5161 = 360
    return total

def _МсЕΣтЬЫюςΤδиηΨΣ():
    if len('') > 0:
        _dead_2124 = 332
        171
    value = 566128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ihq8Zn4Gyvo8LjW35EDGFw8dyjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьΥБвσςпυгбκτьΑΜ():
    value = 176469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA3qTV8+yaEwOQCRkVivHi4swVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТфШЕμЛСвофыΤβ():
    value = 970734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBDFTUY4wb1VGS305FWVGwMosz8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аъЙТαнΖΝШηβ():
    value = 770915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3jJYmNp+bFUIyD00UKfBDcQ4n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОжμфΛиαрΨεЛζΕΦ():
    value = 273249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADbgTXYT8IcxAFqF0kS9MjZ39F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8182 = 581
    total = value + len(text)
    if 85 * 72 < 0:
        467
        957
        pass
    return total

def _сфошнυξκδο():
    if False and True:
        377
    value = 498198
    text = __import__('base64').b64decode('UVVvamt2UWFIWVV6dXAwZHZJZF8=').decode('utf-8')
    total = value + len(text)
    if 77 * 2 < 0:
        _dead_9088 = 27
        551
    return total

def _цЦΛышΦΘДгΗьчу():
    value = 607618
    if False and True:
        pass
        808
        294
    text = __import__('base64').b64decode('RWJUOXl3dERCWUg3dmFBNlpkV0E=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        730
    return total

def _ζΟюТκζАэυяχФψ():
    if 62 * 93 < 0:
        pass
        _dead_6657 = 96
    value = 541409
    text = __import__('base64').b64decode('a2gxcjd5M3ppRzFyTEdGajhpTFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΝОΗЗΟМαэъ():
    value = 751423
    if len('') > 0:
        pass
        _dead_2704 = 169
        316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jn3ySVo7zr45PgK390y5Bhop0kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    if 80 * 33 < 0:
        _dead_3315 = 461
    return total

def _БωΨσМγЪкΙκКцГЙъЙ():
    if 99 * 79 < 0:
        _dead_9147 = 999
        pass
    value = 59388
    text = __import__('base64').b64decode('dF9WTW5UYUo1cGtRMjFCT0xtb0g=').decode('utf-8')
    if 26 * 15 < 0:
        702
    total = value + len(text)
    return total

def _ωΖЫЩбхТдδοφйΜ():
    value = 543441
    text = __import__('base64').b64decode('dHpQemdlc29vZXl6M1h2Y0c4MHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ζαφЭЮмΤΟλЕфЮяΜф():
    value = 622983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PX3UPH8x+q8sFzu6nXqoBnED8Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞЗχΙωΡАΤцСЯςΗцК():
    value = 745789
    text = __import__('base64').b64decode('Y2VwMFQ5c2duVGRWTUEwbEowOXE=').decode('utf-8')
    total = value + len(text)
    return total

def _УУαЦЙйэΧΚΖЩ():
    value = 720683
    text = __import__('base64').b64decode('U0tKWnAyOER5VmRzUEs4OFdaS3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ιЗΧСНιΜК():
    value = 229329
    if len('') > 0:
        pass
        797
        pass
    text = __import__('base64').b64decode('SVFqOEp5Qmt3SkJMaWlDY1M5YnU=').decode('utf-8')
    if False and True:
        694
    total = value + len(text)
    return total

def _ΜΣΕбшαАΔΑСρщ():
    if False and True:
        632
    value = 302705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgzCbWAsrY8RK1iA62OxMSwG8EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 3 < 0:
        _dead_5585 = 596
        pass
        _dead_5221 = 665
    total = value + len(text)
    return total

def _ЖБΖΓЫΕΥоΝι():
    if len('') > 0:
        594
        pass
    value = 274685
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET/sWgQa/JwqGy2L0HqROTwE8jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кбКдЦДьВΜσЦээю():
    if len('') > 0:
        pass
        106
    value = 967545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDj8Q3hq855QPT6F71qGIhor5VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_3083 = 729
        _dead_6727 = 522
    total = value + len(text)
    return total

def _ВюцИςЛχА():
    value = 39607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHvBTwEg840iICCX4A+eExQ9tmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εγшиЪχιξзδЙУЮ():
    value = 226724
    text = __import__('base64').b64decode('dXIyVWxSeDd5c2paQVE2NFMzMWE=').decode('utf-8')
    total = value + len(text)
    return total

def _ШζςΛккЧБςξξΧыЩЬК():
    value = 734997
    if len('') > 0:
        _dead_9949 = 704
        _dead_9978 = 439
        885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQXROwUw9KEwa1yl53iZYD06wUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4835 = 614
        _dead_6361 = 442
    total = value + len(text)
    return total

def _уΣςφωΒЧηβΕБΞΓжαυ():
    value = 539848
    text = __import__('base64').b64decode('RktzbDJCdXVMdWpocU13NUx5VV8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦжЗэΕуχΧ():
    value = 502851
    text = __import__('base64').b64decode('RDdSU1c0Ym91UWRTVm9Od0dOYVI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        258
        _dead_6937 = 164
    return total

def _пбολιЫχЛΖαъЗσ():
    if 40 * 74 < 0:
        _dead_2535 = 1
        pass
        _dead_5642 = 565
    value = 682756
    text = __import__('base64').b64decode('dHVjNDFQR2ZZVV9lNnJseUMxS2o=').decode('utf-8')
    if False and True:
        581
        pass
        _dead_5252 = 153
    total = value + len(text)
    if 69 * 37 < 0:
        _dead_5763 = 703
        213
        454
    return total

def _φШСΜЯчуΨυЩМсΠжУ():
    value = 372869
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhXAX11q6bA7Owqzxky5DD0f6jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑξыΘλξζΧйкΛΓЮТωψ():
    value = 30661
    text = __import__('base64').b64decode('cHRlZmNybkNYNU9SM0pOVDFVTjY=').decode('utf-8')
    total = value + len(text)
    return total

def _γΤПλЙγΒЧЫΟЖΕνξΒΙ():
    value = 52028
    text = __import__('base64').b64decode('U0lvNnhhZmdMeUFPc1kxNWtESDI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒвяжАЦМδΟ():
    value = 281032
    text = __import__('base64').b64decode('VXU2UlI1b0kwZDBqQnI1cm5WMF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ψВωφβВМЙиАфу():
    value = 558097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTvJeHIh04YrKhqM31y6HwB5x00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_1056 = 412
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        593
    return total

def _ΩβЧчΠθхΒ():
    value = 772164
    text = __import__('base64').b64decode('cktnU1VJWDhOa1VkekhiN2hKeUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЖχэЭδЬГΚ():
    value = 850436
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwjJYV4urI0ELj6r/EGIbCkswj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 3 * 65 < 0:
        _dead_8407 = 931
        _dead_2344 = 848
    total = value + len(text)
    return total

def _ΞΙΔΦεЭρΚсΞγΦ():
    if 86 * 92 < 0:
        900
        pass
    value = 838205
    if len('') > 0:
        173
    text = __import__('base64').b64decode('WXpsanBWMTV3RV92QUM1TEpINW0=').decode('utf-8')
    total = value + len(text)
    return total

def _μЬшΤРНжφΞ():
    value = 242754
    text = __import__('base64').b64decode('TUw0REVsU1pXNTM3T3pkS2VwNng=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЫШЛгΒАЩЛЩВΖББД():
    value = 437078
    text = __import__('base64').b64decode('UnlfOHpENFlyWUZTbWg2YXVIRno=').decode('utf-8')
    total = value + len(text)
    return total

def _учдΦΕδГΨηΝθοШτ():
    value = 560255
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAG1O1YMz4sREz2R+welPwIE0l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НрξΠγЙςаКΑЭЭЧТюΔ():
    value = 549212
    text = __import__('base64').b64decode('cUJMVGl2QTBlM1RLU0FYOENLZGg=').decode('utf-8')
    total = value + len(text)
    return total

def _лξΦΝшМωВΘΖΞгршεЬ():
    value = 66058
    text = __import__('base64').b64decode('VkJVMjM3d0NzbWFLeTZubGhTblc=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ЫβжСиΠСςтΥρэк():
    value = 579649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD3udF0r0pIBPzWq32mGLHwu91o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔьятГуПеωГπΕфт():
    value = 21612
    text = __import__('base64').b64decode('SEJReVIxUThmX2tQSWtyazlzSGU=').decode('utf-8')
    if 33 * 16 < 0:
        299
    total = value + len(text)
    if 54 * 22 < 0:
        331
        914
        pass
    return total

def _ΒтΕЕЕПπлБΛΩЗ():
    value = 837067
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Djn0ZGg08YJTCT25wVW/ECIA60c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьхφнΘВяьГкαДсЪΖ():
    value = 446307
    text = __import__('base64').b64decode('aHRWc0hPZzFkMVpiTm9mbTIxVU8=').decode('utf-8')
    total = value + len(text)
    return total

def _еСжΓцУφΣΒΟдЦΠξ():
    value = 699920
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwH3XXMB0IY3Dyua70ajHAYLsmE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΛюШсяпωΗМνкл():
    value = 81766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRDWagke9J8lAxqW7lW8Pgw79Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 16 * 80 < 0:
        _dead_8096 = 644
        950
        _dead_7119 = 257
    total = value + len(text)
    return total

def _ЮΕкΛζРШРСΠЩЫΨЩ():
    if len('') > 0:
        903
        _dead_2899 = 312
    value = 78868
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDu9XHQw0ZsoHiat/H+dHQwtyVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 86 * 80 < 0:
        637
    total = value + len(text)
    return total

def _ΘΖΤьΟиΚνΤ():
    value = 12337
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ly7uVwcY+6AAGCGz6l6jYDR4vWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 9 * 8 < 0:
        452
    total = value + len(text)
    return total

def _ΣТыфшδСξынъηвОК():
    value = 566958
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cjf9fAQ6y5ENEQ2q/WaCHCQ+1UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        _dead_3451 = 788
    return total

def _εфщЩχΡΙδωναпг():
    value = 619990
    if 86 * 87 < 0:
        pass
        629
        955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBz0eV0qzblRDV/05mzJNS02z38='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧЮπκψквУГтлαΛΨт():
    value = 226965
    text = __import__('base64').b64decode('SXhMRkFwdnFZR2NtUXRvSGJyRTg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9073 = 941
    return total

def _ξЪΚЕνДШεдаНЕуΒ():
    value = 74579
    text = __import__('base64').b64decode('c2J1b0FqMGVfVmVrZFZzUGRzX1c=').decode('utf-8')
    total = value + len(text)
    return total

def _еκΓВЪгΨЕс():
    if len('') > 0:
        _dead_4945 = 427
        pass
        pass
    value = 755075
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh7iOFA99I05GCaNwVq8DTYr4Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 14 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΕМДΝΧынΕθοкω():
    value = 996859
    if 75 * 19 < 0:
        _dead_5328 = 251
        _dead_3843 = 229
    text = __import__('base64').b64decode('Ung2MlNxUkJaNmdzQ2J0UlpwOG0=').decode('utf-8')
    total = value + len(text)
    return total

def _уцλжМхоΗ():
    value = 841077
    text = __import__('base64').b64decode('U1gzeUY5a1BFM2xCeWZGeGwyN3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΚАЕхΝνПж():
    value = 545469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyDWeQA85qI1Kxmg7nqAHnc9sHg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 29 * 31 < 0:
        pass
    total = value + len(text)
    return total

def _аОЬФΗкεпι():
    value = 916981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTjlXXA+0Kk0a1ahnF7DZSk14EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьНΔидψψщи():
    value = 793436
    text = __import__('base64').b64decode('R0NWNFo2UkprN1lWNjZsUlZHZEs=').decode('utf-8')
    total = value + len(text)
    return total

def _фΦΓγфρюМ():
    if False and True:
        pass
    value = 944107
    if False and True:
        _dead_6206 = 850
        _dead_4602 = 669
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cy79XEVq8vABIxWU40+bZzwL5nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жБьИΙΗρΗЦ():
    value = 354649
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj3zN1Ibx4wOCySR+WDEDnEs0HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бσАЮΜЧЧК():
    value = 895213
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgbcRGNh7rsZYwXy3GGaJRUnvUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧуΔΧыЭАγоФΒ():
    value = 957848
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ezv1Z0IeyoYOHAOv+maEGjcQyGw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЮЪΧЯПΤχεзГбΩМτ():
    value = 588906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MC7PNmc7/KQHFV2MzG6/NQYYzX8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪьαψИаΛЖлМκКЮ():
    value = 286170
    if len('') > 0:
        _dead_5955 = 792
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dne3V38D8qk5LQSb+w6DEXcEz2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩЯογКΘБρвнαиΘШг():
    value = 738215
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JjfPPnwX1PkQERa75Gm+PRclt0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 14 * 85 < 0:
        _dead_8413 = 237
    total = value + len(text)
    return total

def _кΖμζрДψΗ():
    value = 217775
    text = __import__('base64').b64decode('RFlQX0NpbnpCT0ZqQXpPUU9BVkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧгютЬοаШйцВИ():
    value = 690266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyS1W0Uf+aYtGCT12l3JLT8axWU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕюΜЪβΞυжц():
    value = 955326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADjpe3AV8Kw1MyTx+2e6AHwWxjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФБαщυзьШъэ():
    value = 4718
    if len('') > 0:
        _dead_8376 = 623
        _dead_5568 = 181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSPmUQYD7bABGQzx31yHFTMGxnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 43 * 82 < 0:
        792
    total = value + len(text)
    return total

def _ΝζзбБзУΦИжΠΓΑ():
    value = 376896
    text = __import__('base64').b64decode('dVY3RUptandLOHlRRlR3ZTVZRkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩηеηκщСЩχγХΤκκЦг():
    value = 532771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHfLO2QT26NVCDCC7AOeNnclzEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟНпΤАЫГЩИ():
    value = 80878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT7iRQhgr70qEDiW3161EQ083Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬτΣЕНΥΥΜмзфΜШ():
    value = 294295
    text = __import__('base64').b64decode('VUtlaHpBa0dicFE1ZzEwMkJ0MnU=').decode('utf-8')
    if False and True:
        _dead_7488 = 131
    total = value + len(text)
    return total

def _ΜωΒςτОШΣуЦцξзФρ():
    value = 886450
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCjwO1wb9bAyHyH1mHqYBiYj8ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        207
    total = value + len(text)
    if False and True:
        442
        634
    return total

def _ПЫлСбνδΚдΙкΦχг():
    value = 642567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kw3la1w41pkkMFaumg+kIi15wUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘХΝΗΡΝΥШйПΗυаχа():
    value = 409952
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('Vk04cng4TjZnaTlSaXN0Y2k4YVg=').decode('utf-8')
    total = value + len(text)
    return total

def _φΦлСбΥζМХςпτΦХμ():
    value = 707781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz3AXUQI6rEsHRr1kWG1J3UZyHo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        310
        _dead_1839 = 599
    return total

def _ТвхАтοыυγтρб():
    value = 28452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARvOQGc6/Y8OAgOL7EWaC3Ap83Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γζζЬЧЦΔεγРИεДΨ():
    value = 961637
    if len('') > 0:
        521
        _dead_4289 = 278
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgH8eXkRyqwpAwO63XO2YyM84mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚλдΤγБΟδδμΙηβэ():
    if False and True:
        377
        pass
    value = 556293
    if 69 * 14 < 0:
        _dead_7871 = 194
        766
        925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQTGWQAQ748qFz2okHWTMyke4UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_4613 = 53
    total = value + len(text)
    return total

def _χчςΩδЬΓаЦН():
    value = 509398
    if False and True:
        837
        _dead_4508 = 266
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bgv+YFwzrp0GHz6J7nO7Zz839ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΚπЖъΜзςХσЬыζдΡ():
    if len('') > 0:
        864
        _dead_2942 = 546
        29
    value = 972957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX+2VEITwb4vb1yE/HWJYQYezF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τяЦΟцаефиЖοδιΚъω():
    value = 779915
    text = __import__('base64').b64decode('bmJaYXdxU3doSHpZRDZkQ09scU8=').decode('utf-8')
    total = value + len(text)
    return total

def _ХξуΟЖцΧεΠ():
    value = 261296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwPCRkEsyKUNKgzwzXuWDXY50Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кухσдΖΡΤсΔΣΓИАуΙ():
    value = 671588
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyjhT0QG07w0bxWO3F+lHjIsyHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χπцΑΧЫυΔэωεοЭι():
    value = 558856
    text = __import__('base64').b64decode('T1VLQlZIck1reWJpT2ZOWkxpMUs=').decode('utf-8')
    total = value + len(text)
    return total

def _КпАЕДГДΚκе():
    value = 163377
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgbpQnAM2587CxWL5kypAh0ht1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лЪЦηЕАэСрΦαπ():
    if False and True:
        205
        275
        _dead_9093 = 395
    value = 798248
    text = __import__('base64').b64decode('bHVBOXAzZnpsbzB1aGE5TW5TM2o=').decode('utf-8')
    if 96 * 75 < 0:
        _dead_1892 = 146
        223
    total = value + len(text)
    return total

def _фэЮθБЮъνΨТнбαИ():
    value = 316111
    if False and True:
        398
        _dead_8145 = 220
        _dead_3902 = 223
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz+1RXIy9LwAIgav2gafMS0lxlQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 47 * 14 < 0:
        pass
    total = value + len(text)
    return total

def _ШхθбЕуΠАЛ():
    value = 379735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgHhbGQJ1JcNbj6n8V6iYiQL02I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨυγЦоВχΜжΗφыЮМο():
    value = 11252
    text = __import__('base64').b64decode('czRoT19QVGh4Z1Bpcl85d1hDR1M=').decode('utf-8')
    total = value + len(text)
    return total

def _κΑзΗДξыΟул():
    value = 675312
    text = __import__('base64').b64decode('Y0pPNXJUZFRpcDFUTUNtX3pIQ2k=').decode('utf-8')
    total = value + len(text)
    if 3 * 37 < 0:
        _dead_1242 = 623
        pass
        789
    return total

def _ΟΧχдЩВчиΠδа():
    value = 820427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCPyYXAr+aYqFT+vnQGkYzd58EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЦκТыХдФ():
    value = 881819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXjWa0cQr6QKIiuH7mLGbHYts0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        386
    total = value + len(text)
    return total

def _рЖГΩωСнГаΟφγ():
    value = 304427
    text = __import__('base64').b64decode('bnFhR05yQzZCbDlVWmlQUVB1QWg=').decode('utf-8')
    if len('') > 0:
        294
    total = value + len(text)
    return total

def _ХЕБвЕХхΨчΩ():
    value = 693974
    text = __import__('base64').b64decode('TTRDQVJUdTU1TXNDYVh6akxUSFA=').decode('utf-8')
    total = value + len(text)
    return total

def _гпГΠΔыΜШЙР():
    value = 710084
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRfGS0Af5K42BRb2mX2GA3d/0Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 100 < 0:
        pass
    total = value + len(text)
    return total

def _ЕФσηйиГκ():
    value = 378085
    if 11 * 99 < 0:
        801
        pass
    text = __import__('base64').b64decode('QzlrNVZLbHluQmw5OFY1Qk1TcmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡκΕΗГыяΕΛЗΩΨг():
    value = 273063
    text = __import__('base64').b64decode('SGFMWnVTbmQ4aXB4Mk5tbHZIeEM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        754
    return total

def _ЗνΗΝчиЪΩδеΔ():
    value = 123815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBbhTwUP8I0xaTexmEO5HBQiw1Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МщфсРЫωΑΡργωщхс():
    value = 811597
    text = __import__('base64').b64decode('WHZlNkZtc0g2OGJuUUp2cllJckU=').decode('utf-8')
    total = value + len(text)
    return total

def _АЮыФКΓПΛдс():
    if False and True:
        982
    value = 317047
    text = __import__('base64').b64decode('ZWVzSlFkUUluaGNxR2tqWENqSzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑΔюκбцνАοуХ():
    value = 940638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EybpWFop7IooIASQwEaJDCYrz1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        359
    total = value + len(text)
    return total

def _ИЬυшΔЮДЗρп():
    value = 764157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQPiW3M41rotIAWU/m+WZXwu2zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЙтλΓвΩшбоЦЬяЖηП():
    if 22 * 71 < 0:
        _dead_8348 = 190
        197
        pass
    value = 264854
    if len('') > 0:
        896
        _dead_2473 = 648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj7GQmlh0rsNCliqkQS/bHF94Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 1 < 0:
        _dead_2697 = 742
    total = value + len(text)
    return total

def _ΖБтФхΟВΩв():
    value = 565605
    text = __import__('base64').b64decode('a1hHV1BfUndSX3NTQWp4dm9ncW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ТЪυξλΑηеΘΠΘΘΙтζμ():
    if 99 * 29 < 0:
        pass
    value = 547615
    if 72 * 56 < 0:
        _dead_8659 = 159
        591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3rAWGcW2I0uOTiFkGOiJw038Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        143
        _dead_7747 = 462
    return total

def _τΖцЧЦътΕΖЛЕωнοэΒ():
    value = 217084
    text = __import__('base64').b64decode('UW5kY3FMeEdDWXZaX3dJbHRpSjI=').decode('utf-8')
    total = value + len(text)
    return total

def _СЩθΛдпхэыνЩ():
    value = 535198
    text = __import__('base64').b64decode('aWdqTDRZZzVCMTV2akxONlNBTVg=').decode('utf-8')
    total = value + len(text)
    return total

def _υчΕТηΝηЕ():
    if 4 * 41 < 0:
        _dead_6642 = 865
        pass
    value = 832689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXu0a1gT64pVbDis/nW6HXwh6G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        _dead_1884 = 76
    total = value + len(text)
    return total

def _ΩЕπφαмтСдθσГБ():
    value = 62511
    text = __import__('base64').b64decode('dFF5cUVDRWFkSm8xbWVzd3lodDg=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΝХюσвρχΒχξЛΖГ():
    value = 258078
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzvcUX0J8r4VaSu57m6DNXY/12E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δыеλФΤОыСЭ():
    value = 966733
    if 56 * 21 < 0:
        pass
    text = __import__('base64').b64decode('Q1FwVFdqZUVTdUFEZll0cUdKWmQ=').decode('utf-8')
    if 74 * 84 < 0:
        _dead_1264 = 811
        pass
    total = value + len(text)
    return total

def _асыΨΔрναЖДΛрж():
    value = 964503
    if 67 * 52 < 0:
        _dead_8680 = 410
        _dead_7917 = 703
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cx2xdgES0b0CHS6W+A+oDDYIxm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8869 = 261
    total = value + len(text)
    return total

def _ЛЯφгъΟβСχяυЭΦ():
    if 96 * 92 < 0:
        pass
        _dead_6873 = 207
    value = 739805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah69bHkI0oNRbxe2+UWTHiM79E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        439
    total = value + len(text)
    return total

def _яωηлΒηеλГкХΠЦελ():
    if False and True:
        pass
    value = 199235
    text = __import__('base64').b64decode('SU5YcWk2TjFWdHVGOEhGNXE1U2s=').decode('utf-8')
    total = value + len(text)
    return total

def _гηЛσАбыИйюΚφΞ():
    if False and True:
        _dead_3630 = 655
        _dead_6003 = 495
    value = 525457
    text = __import__('base64').b64decode('V1JSaVFxTkJ0MmszWDZHNUhoQnI=').decode('utf-8')
    if 84 * 12 < 0:
        _dead_7470 = 376
    total = value + len(text)
    if 11 * 19 < 0:
        _dead_6943 = 490
    return total

def _ΝЛЫΣЯЬзхΛηВр():
    if 6 * 44 < 0:
        718
        958
    value = 127514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxfXbUYG/IMzODyWwmmGECshtTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9706 = 18
        329
        _dead_2721 = 685
    return total

def _тΩκцρЦΜΖ():
    if False and True:
        _dead_6858 = 633
        pass
    value = 740549
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxfUZWIuxowJCQ617WSvbCIH/jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5764 = 6
    total = value + len(text)
    if False and True:
        198
        pass
        pass
    return total

def _АρНφжЯЧРБд():
    if len('') > 0:
        _dead_7241 = 437
        pass
        _dead_7302 = 750
    value = 619317
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICjXX2MKzowiGV6h+lSDYxJ311Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        82
    total = value + len(text)
    return total

def _ЬЖЛъДОΩЕσЛ():
    value = 513956
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSnOeWho27skDBag/V6abAYHyXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗυνБψХоΖ():
    value = 994209
    text = __import__('base64').b64decode('V3diaGxBa1oxVXJjVzNTVW5wX00=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5369 = 407
    return total

def _ξηЫηЛΖбΦ():
    value = 914516
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiDKSlQq6Zg5IgG58lW9AAM8yHY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖцΠдΞγΞЧ():
    value = 275515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3nzflIrq6IJHF2UzWWAIi4Nwkk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αыΦКφθюο():
    value = 862399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR7sekAS96IEPx36nUadIHAtzDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 49 * 24 < 0:
        pass
    return total

def _НлκшГЦαЦηзυΥ():
    value = 442774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnbyVFcWy/pVLFu58nqaMjUL8nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τШЕΞХθΘΡωЭВцФα():
    if 63 * 5 < 0:
        250
    value = 289043
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lnj8OgRo+o8iLQyQ3nOFNTc950A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _βдЭΖΧΜΑЙОУΣμλ():
    value = 527546
    if len('') > 0:
        pass
        63
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDWzSl0d66UZPw2nxg60C3wq4Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_4059 = 708
        _dead_4554 = 59
    total = value + len(text)
    return total

def _роψγЧгнПωь():
    value = 644579
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KS3nY2cuypkwbCy25kOzHAoA0mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σπЭξЦωυГ():
    value = 925100
    text = __import__('base64').b64decode('bEhhSWc1c21nSGpxNHBWWUFLNEk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5749 = 407
    return total

def _нбцΧТЧЭςЦηкΩ():
    value = 711723
    if 68 * 43 < 0:
        401
    text = __import__('base64').b64decode('VTNJN2poNktCYjdmVTV6UDBuSTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖςюшυЭΒΛηχкχЗ():
    value = 936162
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('WjZpYWdRV1V6SUZjWE9rbE45M0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡΝМθγБΑжηεα():
    if len('') > 0:
        _dead_6985 = 190
        46
    value = 740086
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgPjYV4Brb8IEDmc3F2IITAosHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞΧяβΘξгΣαъБΙ():
    value = 932538
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX3wN30j7ZwmaBWgylK9HjQJt0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οαРβхУΞбΡΝ():
    value = 291517
    text = __import__('base64').b64decode('R0ltOEdleXJrVDhEeUxVWXlTaXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΕρΚюθОвОЕъ():
    value = 627570
    text = __import__('base64').b64decode('ZHBYTjZTalNOUE1UUEdXQmJVNHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ТЪЧαΛΙмЗΥгε():
    value = 438843
    text = __import__('base64').b64decode('QUhCZTZ4ZFVYSG9XT1dud2JDMWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ιΠДЧТυщТЭΠлΝΦ():
    value = 835746
    text = __import__('base64').b64decode('WjB3TFl4VVpuTFI4WHY5N3VUaXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬυФъΝтαγКНРνТο():
    value = 448499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCW1PWQS3YMUaSKz4UaYNz0Nsnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 7 * 76 < 0:
        pass
        _dead_3458 = 463
    return total

def _μзЩΙРглΤΕвт():
    value = 962653
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwH3eGIt6ZA8LQeO5XTDFXwasUo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αбъщχΓΝψэΔОχсяф():
    value = 737804
    if len('') > 0:
        415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCX2PGQh/a8hKC2o/QHIJzAqtGk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 90 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _МγЬщЩнаΠЧΞ():
    if False and True:
        _dead_9185 = 939
    value = 222606
    if False and True:
        pass
    text = __import__('base64').b64decode('U3ZxamNPQjhTT1UwNHZ5cWZRQjE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        470
        177
    return total

def _ШψΤжΧЫрАΞΤδСγ():
    value = 265400
    if 93 * 40 < 0:
        _dead_4345 = 639
        _dead_8312 = 869
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag3nZQMz67AIFCyzmW+yZxB/x18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΧεΖФζαДСςП():
    value = 148730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3nAVEZr57g6aB+WxGyVJCcrz2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4769 = 980
        pass
        _dead_4524 = 423
    return total

def _мюκПΠЮυгБ():
    value = 736049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARuzeXgb/58mLyGO0E6YHDEl/ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖФνцΟБюηαл():
    value = 237455
    if len('') > 0:
        pass
        27
        _dead_6462 = 841
    text = __import__('base64').b64decode('aXNOVUpVdUN4UmlWSjZ6aTMxZHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _еΒΜΩυГψП():
    if len('') > 0:
        294
        pass
    value = 248161
    text = __import__('base64').b64decode('cjgxOFVsZmVuWGlWUGhBUlQyS0g=').decode('utf-8')
    if len('') > 0:
        781
        _dead_2255 = 88
        pass
    total = value + len(text)
    return total

def _νНΦРйΘρЯΑψШζКζ():
    value = 770959
    if len('') > 0:
        839
        915
    text = __import__('base64').b64decode('ZU1pZGJicFB5a1hOMG9qY2l0ZVM=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЪНдЬБγЖΑθзюЦгΝж():
    value = 241100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgTbP0Q2yLkzM1mz8HGUGQwfyzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 65 * 69 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        284
    return total

def _υОΣыъενηξπ():
    if False and True:
        309
        _dead_4440 = 399
    value = 349498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBfFfFkWxpgVPC6A3FybBhEc1Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΑчМΛΧΡюсζμамΧ():
    value = 952612
    if False and True:
        176
        _dead_8648 = 115
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyXBT3o1qbEbIlmN5VidJggm3Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬжпοπуΜЫΖКΗΦт():
    if 45 * 97 < 0:
        pass
        pass
    value = 870525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCzNfnIyz4YlCA6un0WgFRMW910='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1146 = 136
        61
        pass
    return total

def _γщМΔщλЮпΑАκ():
    value = 584276
    text = __import__('base64').b64decode('S2c2RUVCYVBEZ2EySXhzUlo1TVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЭЦΥХЙΒЯыьςψΕφсК():
    if False and True:
        815
    value = 315043
    if len('') > 0:
        999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NH3NaVsOqpxTI16n3m+TJgANsV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 57 * 60 < 0:
        145
    return total

def _НяρΕλчτοжМΟλИиЙ():
    value = 731472
    text = __import__('base64').b64decode('RmlRSEhMVnJocjhKTDU4UlIwdXU=').decode('utf-8')
    total = value + len(text)
    if 70 * 26 < 0:
        _dead_6093 = 713
        _dead_1426 = 276
        _dead_9738 = 156
    return total

def _ЧЙχАΩΔΗγχρ():
    value = 18244
    text = __import__('base64').b64decode('WEhKVUVfa2p0WDdudk1VUVNwenI=').decode('utf-8')
    total = value + len(text)
    return total

def _БюφδτЙШцΛкшпΖ():
    if 39 * 78 < 0:
        187
        pass
    value = 947550
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwaxTUQz0qc8KSeWnVOAFQ48yHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΝεЕХзΧλ():
    value = 587035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByT2aWsA+/ARCBzz3V+nCzA/z0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9645 = 611
    return total

def _хрЗГρξяФσнчκφЕβ():
    value = 146716
    if len('') > 0:
        _dead_7344 = 742
    text = __import__('base64').b64decode('a2ZGYUY4cmVfR0dXbW5xUlZCUkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΓυωΤДлпнΟ():
    value = 776838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBvlZXge56EPAyiTkAegJhN7wU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οξъСψыδЫωΚφμ():
    value = 992012
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxfydmhqzYoaBQ307VyvMj8g0WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΨΑχβЖгПЮиΒ():
    value = 767145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PATgVEUhzJIIFx6mxmS8MS0ZskQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        396
        _dead_5879 = 729
        892
    total = value + len(text)
    return total

def _ЫфβψюОбΣδ():
    value = 776138
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwzXUUMy37EzPAqT6Q+JBhZ35Vk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΦβΗГаΩЗΤΞЮбдмτ():
    value = 739699
    text = __import__('base64').b64decode('VHFPQ2xHNl9HSG5mRFpvQXNvS3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _νИψиЧлΑк():
    if False and True:
        _dead_2528 = 422
    value = 594812
    text = __import__('base64').b64decode('S1dPSkpCU0F4dkhuOEprTXVtdVo=').decode('utf-8')
    total = value + len(text)
    if 75 * 20 < 0:
        pass
        pass
    return total

def _υЕПλЫТбМφрυ():
    value = 460350
    text = __import__('base64').b64decode('VXZ4QW1OX3dQRDJ2bkJWdWRZd2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ШхбдУΝВΖЯΝΥΦЧ():
    value = 361216
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwDOOwEf9b8NCVbwyVu/P3Ql6Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬБзАΘЙКειμноξЙТη():
    if 14 * 32 < 0:
        78
    value = 253906
    text = __import__('base64').b64decode('SHBuTlFZd0hobjRubHNUZHdzVG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖТΜρЛαЯμα():
    value = 717224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSHQdAc38KUXNyir6li4OjED80o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οαткАЧЬЯ():
    if len('') > 0:
        _dead_7744 = 866
        pass
        _dead_1282 = 937
    value = 545922
    if len('') > 0:
        _dead_6036 = 334
        _dead_9226 = 404
    text = __import__('base64').b64decode('SE13QmxMTjM5aE16T3hJdmc0V1o=').decode('utf-8')
    if False and True:
        _dead_2238 = 410
    total = value + len(text)
    return total

def _νрБвяхдчлбМ():
    value = 834269
    text = __import__('base64').b64decode('blVJYURIbjlvWkc4UlFsc2ZPZno=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 40 * 54 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()