#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ЖΙжЧОδσЮΛΡшму():
    value = 617680
    text = __import__('base64').b64decode('anZHcGd1SEtQNGxGRWl1cU03dmE=').decode('utf-8')
    total = value + len(text)
    return total

def _τьφΦКдШλσэЭΣхΜ():
    if 64 * 56 < 0:
        _dead_2551 = 278
    value = 289700
    if False and True:
        _dead_9879 = 318
        pass
    text = __import__('base64').b64decode('ZnN0MUlkTUFmN0pUcmU5TzFJdVc=').decode('utf-8')
    if 32 * 36 < 0:
        pass
    total = value + len(text)
    if False and True:
        pass
        829
    return total

def _πыОΨΣбвхтСГω():
    value = 970357
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnrHQ1lg+/0wCxzy/AKREx8k4lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уифθΩΜΝыΜΖГХиМ():
    value = 165077
    text = __import__('base64').b64decode('cVJKY2FkQUE4Nm5ENE5mMzhSRXM=').decode('utf-8')
    total = value + len(text)
    return total

def _εцхбоасиэφоψЫοΙц():
    value = 312002
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hxn+QgY/xpsMKBew43maLHYb/Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞзРВюнΙлΝОΓΦУ():
    value = 390676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBbbelY+0/8qEibz7lKXJQ53zzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2985 = 759
        651
        pass
    return total

def _ξЖΗрРεΞяΕπβощΨ():
    value = 537894
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBjUN1A++rwSDRj0kFm2IwJ442k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жХшцшЦзФСБГШрξ():
    value = 559036
    text = __import__('base64').b64decode('WDc5emhaNGo5bXJZSGp1UW80VF8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΑмПЬγшμηУ():
    value = 951720
    text = __import__('base64').b64decode('UTlLSWF2dzBXWF90blRVUHA1aWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΕдфзθλыыфμВэК():
    value = 416348
    if False and True:
        _dead_5366 = 90
        pass
    text = __import__('base64').b64decode('YTFWNWFjNjlkdmJBVVlkd1BKdFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ωнΤэттэεухУНХυ():
    value = 603824
    text = __import__('base64').b64decode('eGduUktrcTQxUk9KTFFyYjNwa3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮβФгыЭмХь():
    value = 391979
    text = __import__('base64').b64decode('T3IyazZNal9xZ0N3RHBKVEtxR1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠхпΔΤаΩΑ():
    if 87 * 20 < 0:
        289
        _dead_4404 = 504
        _dead_7194 = 525
    value = 979655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhjqSFwpyfxQHCGW0X2yPCsO9lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οθвжЦяΜШФВЙлω():
    value = 480529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzvFbVsr5IA5LDik/GWYOQQp0lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λШеДτΒΙβΜпьΩ():
    if len('') > 0:
        pass
        pass
        pass
    value = 236243
    if len('') > 0:
        _dead_8008 = 897
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxyxbF4TrJ4TGF2X8mODMiYmxWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΑПδрОηΟΝРΤ():
    value = 663102
    text = __import__('base64').b64decode('ZEgzVlRTclZYcThlaHkyV0kxZ3U=').decode('utf-8')
    total = value + len(text)
    return total

def _СшЧΧΨыИуηДΒб():
    value = 360336
    text = __import__('base64').b64decode('TFNmbnJMZ3oydHJEdW5jdm1qMDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ИДЛлχыцхВЫ():
    value = 189079
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASLJZFYqyaJWFxqImUG9LAp/tE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗАπРъаУККΒ():
    value = 696583
    if False and True:
        pass
        593
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgjmeWIO+vErHjj0nWSXPRo35kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΕκУυЖςф():
    value = 474606
    if 53 * 69 < 0:
        _dead_8127 = 525
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQjXWgYt7pAaDgCi+kSHEwEK0EQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        350
    total = value + len(text)
    return total

def _εгταвшчэИЩзΗюΙτΡ():
    value = 529231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mza9UXMezP8mDxeM5lSCBHY57WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηςаПΚвЗх():
    value = 717570
    text = __import__('base64').b64decode('TzkyQTJiM3ZmSnYwUDZfRDR3Vmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔХрΓωноЧΧНвΖу():
    value = 874930
    text = __import__('base64').b64decode('ZDQ0VXV4UmY1SVFSd3BMc0R6Mk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦЖηСАΥχнШ():
    if False and True:
        569
        pass
    value = 781060
    if len('') > 0:
        pass
        _dead_5879 = 507
    text = __import__('base64').b64decode('QmpLZmhYMTdoTFhLa0pHVHhXdVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗРдДцΒγюА():
    if False and True:
        116
        _dead_2870 = 857
        858
    value = 117287
    text = __import__('base64').b64decode('Wjk1NU5uZGFHalIyNjBYX1p5S1M=').decode('utf-8')
    total = value + len(text)
    if False and True:
        16
        pass
    return total

def _ΞΨΚатΨΨеγЪшЙЮωьч():
    value = 994916
    text = __import__('base64').b64decode('Y0daTjVvQUZaN0d3YU9KMGRVY3o=').decode('utf-8')
    if 100 * 7 < 0:
        218
    total = value + len(text)
    return total

def _ТиΓαΕлЙжрΑЮЦчКЖъ():
    if len('') > 0:
        687
    value = 596006
    text = __import__('base64').b64decode('VHJORXJ3eEhNWXlhX0hlVHBtR3g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖυЪΜыτжЦηκ():
    value = 265843
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgbLRnkqwbkXEgCQ8GCjOHMH80A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уйРЭαЬЗΓΘкω():
    value = 261625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSLoX1k924YTLTWm7FKxOCEj034='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        204
    return total

def _νΓЯΛубδХ():
    if False and True:
        280
    value = 783178
    if False and True:
        _dead_1340 = 193
        pass
        _dead_1374 = 628
    text = __import__('base64').b64decode('QUZobFpkdEYxWnRudUFQNEZtMWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΓкιКШΠΞтπΤГ():
    value = 931334
    text = __import__('base64').b64decode('dElIR1FRMjJYdlN1TlloM2F1RlA=').decode('utf-8')
    if False and True:
        _dead_3284 = 378
    total = value + len(text)
    return total

def _жΖеΔпЧыЙгъΚугΧаЖ():
    if False and True:
        _dead_2085 = 771
        509
        pass
    value = 740845
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHu8RgEA37gPFx2XxgGlNxQoy0g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝψΣйΧΜмр():
    if False and True:
        _dead_8045 = 925
        539
    value = 167037
    if 25 * 34 < 0:
        400
    text = __import__('base64').b64decode('d244Y1FGZEgxN0dHUFJhRXVHMmo=').decode('utf-8')
    if 43 * 88 < 0:
        pass
        pass
        382
    total = value + len(text)
    return total

def _νэκΡИαΕοΖДτΛαΡХ():
    value = 67354
    text = __import__('base64').b64decode('dmx0NTM1Tmlqcm9qSVhtWUdYMmY=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_5638 = 559
        603
    total = value + len(text)
    return total

def _ΕΨвщуΠοΦΞчΩрШЛΒ():
    if len('') > 0:
        354
        253
    value = 196437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCrWS18qyJdSaF6g8AOJGz8B0lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΤφяεΠЙμδНжсЪЬг():
    value = 518421
    text = __import__('base64').b64decode('U25IbVVzRl9CVXlldERkT2xQUDY=').decode('utf-8')
    if len('') > 0:
        _dead_6590 = 582
        299
    total = value + len(text)
    if len('') > 0:
        875
    return total

def _еΤκφТнθθβΛςΜБЮΝУ():
    value = 568151
    if False and True:
        _dead_6900 = 183
    text = __import__('base64').b64decode('cjRDUjhQYjJOSUVTdWhnempKcUM=').decode('utf-8')
    if len('') > 0:
        pass
        83
        554
    total = value + len(text)
    return total

def _дцЧпеБКοξτшπ():
    value = 851539
    text = __import__('base64').b64decode('TEUyeW5XMllROHJ1MjZSN0g2TEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕъθΦйΜРφДεув():
    value = 629763
    text = __import__('base64').b64decode('QWdOSVpkUmdTeGhaZDlxQVl1amQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_8547 = 592
        _dead_9628 = 664
        419
    return total

def _ашΝΡПΗчЧщчУы():
    value = 402937
    text = __import__('base64').b64decode('SUozemxLVWNzVjIxQ1BfdzZXTEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ыКΥχЪБπλΦ():
    value = 108188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAz2Zn9q175SAz6w+GnDbCF53Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        17
        450
        695
    total = value + len(text)
    return total

def _РΨΣγЕйνцЯηц():
    value = 393734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AC2zTQE43JoyHV2E4wfJB30350Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πθмЪοгьпзуюТТИμу():
    value = 673770
    text = __import__('base64').b64decode('UDZLelpvUEdqSlNCbno3WlkwbTg=').decode('utf-8')
    total = value + len(text)
    if 38 * 18 < 0:
        258
    return total

def _ΜаυΜшΤυΨΠλцжεъз():
    if 100 * 26 < 0:
        pass
    value = 295972
    if False and True:
        _dead_8868 = 674
        pass
        406
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAi9YH9uzoxTMC6Wnn+KGyYFwlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сξΛАэфυЖωΙоΔιДЕ():
    value = 810499
    text = __import__('base64').b64decode('Y0NIZDVEd0lLekRzQU1POW1kTmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ζЩЛςΗζХΙОоσ():
    value = 82759
    text = __import__('base64').b64decode('ZkpmZ2s2RXJheURjTk9OS3BRRmI=').decode('utf-8')
    total = value + len(text)
    return total

def _λΓЦУαшΘαуΤ():
    value = 109224
    text = __import__('base64').b64decode('U1dkUXljSUNIbkdFckJPcHhCUzc=').decode('utf-8')
    total = value + len(text)
    return total

def _σμΤΦчΨσн():
    value = 278135
    text = __import__('base64').b64decode('aFAwNXNYNXdMV1Rsak5RV2Vzbks=').decode('utf-8')
    if False and True:
        pass
        pass
        905
    total = value + len(text)
    return total

def _αНУνкΞΚдЬЦЫп():
    if False and True:
        603
        pass
    value = 839931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Myn0WHkL6/A6Hl712nihFit26Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜМЛΔкХйфριп():
    value = 212612
    text = __import__('base64').b64decode('TkY5eGNPNnB5UUs3SFlfb2ZzV0c=').decode('utf-8')
    total = value + len(text)
    return total

def _λΚвΘЛΖЯКΙПсα():
    value = 946664
    text = __import__('base64').b64decode('VjNwajVrSFRNVUhQWTRMZENkazM=').decode('utf-8')
    if False and True:
        _dead_3499 = 793
        _dead_8658 = 107
    total = value + len(text)
    return total

def _кβШγΠЮμρфГςБΕВС():
    value = 552577
    text = __import__('base64').b64decode('ZFYwd004VVp1OUI2YW9vSXV1aHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ιрςηийΧοРζхИσ():
    value = 44238
    text = __import__('base64').b64decode('S3RBc0o0VTBuSFdzYmJxdzY0VXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ηβЬдΔТщυгμι():
    value = 872526
    text = __import__('base64').b64decode('SWFuaWJfTDVQb25JbHVHR3RDVk8=').decode('utf-8')
    total = value + len(text)
    return total

def _юзιΔЭηцЙфШЬыЩσΧχ():
    value = 118808
    if False and True:
        pass
    text = __import__('base64').b64decode('WmMwbUlrdU40NGhzaVB2NkY2cDQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΘаыЭЮλЦяψΟφΤиο():
    value = 124289
    text = __import__('base64').b64decode('ajFOVk9QWkUyWjZ4VWgyY1hiNGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ψБογсζяδΧэλрςпω():
    value = 886137
    text = __import__('base64').b64decode('R0Z0ZHBVMUp1X0pUMjVNNUlLcE4=').decode('utf-8')
    total = value + len(text)
    return total

def _σчΠΤβУωΓяЯ():
    if False and True:
        809
    value = 642094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAXtS0sp3b4naFqO90y9HHAG0n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧТцωЙнΕФвПТ():
    value = 151795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQqzUVg+6okRLhuan3/IYyAe/VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эΔнъρШЪφ():
    if len('') > 0:
        _dead_9253 = 637
        pass
    value = 236350
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mh70dwUtxq4oCQL35EyaAh0Lt1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7516 = 951
    total = value + len(text)
    return total

def _жΧКОЭМсИ():
    value = 95825
    if 49 * 37 < 0:
        pass
        295
        _dead_9070 = 597
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3bUawkb9o01GSO0nGCZEwI81Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςояЛκΦΓехрπΠ():
    value = 998740
    text = __import__('base64').b64decode('RTYzOXpHSU5OYlI2d3BHMVFNZHo=').decode('utf-8')
    total = value + len(text)
    if 22 * 64 < 0:
        _dead_8465 = 799
        478
    return total

def _БЙЛОιπцΜΙΓПΟыσ():
    value = 313389
    text = __import__('base64').b64decode('cU9zT2ljWlF5RGgzcE1xNmVHcFI=').decode('utf-8')
    total = value + len(text)
    return total

def _дΥмшΨΟαΚЖЦ():
    value = 687901
    text = __import__('base64').b64decode('Vm1MY1FiWV84M1A5cldZOUF0ZWs=').decode('utf-8')
    total = value + len(text)
    return total

def _щеζМНоημюЮΩЩυТК():
    value = 328855
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwbIYAEI6ok0awKM7G6eDAoGs2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДГΚГΟвωξтШκасщΓ():
    if len('') > 0:
        652
        876
        _dead_8379 = 896
    value = 218935
    text = __import__('base64').b64decode('SUY2Ykdtd1NMOGxXNUNXMkFBRTM=').decode('utf-8')
    total = value + len(text)
    return total

def _пюΟдэдЪИωофгΨа():
    if False and True:
        pass
        _dead_8173 = 349
        902
    value = 149627
    if 33 * 75 < 0:
        _dead_9411 = 668
    text = __import__('base64').b64decode('c0w5T2hqY0o3M21lbkFpVFVUZHI=').decode('utf-8')
    if False and True:
        _dead_1164 = 555
        _dead_4879 = 177
        _dead_9287 = 261
    total = value + len(text)
    return total

def _οОбБΛзΙйΒхвГθь():
    value = 453013
    text = __import__('base64').b64decode('VE40NEQ5NlBoYkJDbWhMQ3B1NXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ВφдЪΒκΕζуΥшЬΔЦ():
    value = 28259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cx/QO2sr9L0GYyuO0nmzGh8ew00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _убшЫαиθЕΜъЩмЖ():
    value = 254590
    text = __import__('base64').b64decode('YmVOV3pmaXN2eFV2VTF4dVZMVVY=').decode('utf-8')
    total = value + len(text)
    return total

def _вΜυТУбΡгмΦПВλ():
    if len('') > 0:
        581
    value = 528900
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MALJSV0t06cvIgyEm12GBCt/0ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        988
        pass
    return total

def _ЕЯэιЕΔзЗ():
    value = 919761
    if len('') > 0:
        pass
        _dead_9915 = 494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXflNkto//A6IASxzmmxIAEizEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 91 * 11 < 0:
        pass
        _dead_7529 = 277
    return total

def _ΝЛъΚΩβцγΨψΞγЧ():
    value = 988224
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgPjO0UW7vwFFy3y5mLDHDYlvTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_7794 = 477
        _dead_5230 = 467
    return total

def _уΟЬγιыΖа():
    value = 808799
    text = __import__('base64').b64decode('Rlp2a3pSVjRjclh1UV9XOVBrcVA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        530
    return total

def _ВΙΥΟΧθεβЖ():
    if 42 * 85 < 0:
        351
    value = 616070
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('TGRBSWZYTnppZjJmNHJibkxFRlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟщьταφΤΕГКξνΛЪΞΣ():
    value = 80382
    text = __import__('base64').b64decode('Y0I2dHNqQkZReEVDSnp6VVZqSkI=').decode('utf-8')
    if len('') > 0:
        427
        _dead_3258 = 502
        _dead_5067 = 151
    total = value + len(text)
    return total

def _цлΩЪжВφЖыфВ():
    value = 14043
    text = __import__('base64').b64decode('R1dMV05td2o2cGVVNDFrdkFqS2o=').decode('utf-8')
    total = value + len(text)
    return total

def _АюΒУΛЕЖжΣж():
    if 25 * 65 < 0:
        pass
        963
    value = 882184
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQbLfEMu1L0pDAz7ngCFHjwL82I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7116 = 949
        _dead_5213 = 419
    total = value + len(text)
    if len('') > 0:
        96
        _dead_9204 = 907
        pass
    return total

def _δГςψПγΜчззПУл():
    if False and True:
        pass
        851
    value = 212703
    if False and True:
        373
        132
        pass
    text = __import__('base64').b64decode('eGlSVno4MmpCMktjY2wzYlI2R18=').decode('utf-8')
    total = value + len(text)
    return total

def _νεэгэВΗФξΛр():
    value = 447269
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz/uOl1r/58wLSun7ECiBhY7/jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДωкьΦΣΧмВЧρΣΥ():
    value = 395445
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTvBPldrqpAqLxuL/H+bJAN6sl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        99
    return total

def _ΠδЭфПΦΦΑФЯТΖЬмшъ():
    value = 486039
    text = __import__('base64').b64decode('RnVCTVV5YVhoTVlycTMzNVhKT3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧхΛυαРмлйδΔВжх():
    value = 253152
    text = __import__('base64').b64decode('UjRwa3JmdXptSTFoRGxFcHV3Ung=').decode('utf-8')
    total = value + len(text)
    return total

def _ФяτуБТЫΖΟψа():
    value = 282172
    text = __import__('base64').b64decode('VVlLeWJfcUdTdnRFeEN3dHd5TG4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _кζΠзαυΨΝζ():
    value = 523546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCi3Vnwq6qEmAiOS3UWnESACyV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эгсУθТНЭЭ():
    value = 635293
    text = __import__('base64').b64decode('TnBXYWFzVFd4SE44M1BsWDhIWVY=').decode('utf-8')
    total = value + len(text)
    return total

def _πдИσХοΖΣιхρ():
    value = 332152
    if False and True:
        947
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICfJX0Ia0r42IFu7nHKpOnEJyW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛαшЗфτεΟ():
    value = 868797
    text = __import__('base64').b64decode('UTJscTFjbjNOSnZtNFdNcmZQcEk=').decode('utf-8')
    total = value + len(text)
    return total

def _δγюΧλΕБΔПΤΗБичшΜ():
    value = 625912
    text = __import__('base64').b64decode('aDRNZGs5RlM4b01xdHl2YVp2NHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞУηГхОσμΠо():
    if 19 * 26 < 0:
        pass
        564
        _dead_4572 = 252
    value = 164231
    if False and True:
        pass
    text = __import__('base64').b64decode('cmdxbHlIa0JTRE5nUzNwdXhaZlc=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_7617 = 424
    total = value + len(text)
    return total

def _эЗСчωΞЩιψηпτΘνβШ():
    value = 774914
    if False and True:
        _dead_7020 = 299
        893
        86
    text = __import__('base64').b64decode('Z1JfRF96NGJDRE13blZTTWJ2eno=').decode('utf-8')
    total = value + len(text)
    return total

def _νιεУЪЙξΦЫφχЬς():
    value = 314078
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAf2eAYyy51Uai27xVq2bQQQtE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4933 = 965
    total = value + len(text)
    if 93 * 6 < 0:
        pass
    return total

def _ΦгЪΝЬДΩЭζυ():
    value = 894503
    text = __import__('base64').b64decode('Tnh6VDFGX3N2MEYydDRWUUgwXzM=').decode('utf-8')
    if False and True:
        552
        pass
        pass
    total = value + len(text)
    return total

def _οпкИРиΛрφк():
    if len('') > 0:
        767
    value = 62842
    if len('') > 0:
        pass
        pass
        pass
    text = __import__('base64').b64decode('bTJZeV9tQlAxc0xXQWxfcE5XTnE=').decode('utf-8')
    total = value + len(text)
    return total

def _ИσюЕΔиεΑъО():
    value = 51813
    text = __import__('base64').b64decode('ZlJPMEVuZUJ6UGoybGtJb0FhZEw=').decode('utf-8')
    total = value + len(text)
    return total

def _αΦФΟσΗхΗвυψΡΛб():
    if len('') > 0:
        pass
        pass
    value = 499711
    text = __import__('base64').b64decode('blRVcF9ST2ZxWEVBamY3ZjVwdFg=').decode('utf-8')
    if False and True:
        548
    total = value + len(text)
    return total

def _ΔοЖΘΕшΝи():
    value = 10047
    text = __import__('base64').b64decode('ejF2MkNLVFNNSkJjRUN6TEh0V0M=').decode('utf-8')
    if False and True:
        pass
        _dead_5292 = 361
    total = value + len(text)
    return total

def _ηρжφУзЫΙо():
    value = 774180
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ixf0O1ouyPxVD1atnwXJGh8c50s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аОΒЮεМгэхзд():
    if len('') > 0:
        pass
        845
    value = 719135
    text = __import__('base64').b64decode('d2Zxd00xZElnOTZPWlZreW9mRFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧΩеνяψΥБΤαэηΘτ():
    if False and True:
        _dead_7451 = 561
        pass
        976
    value = 559724
    if len('') > 0:
        pass
        0
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny38Vwlu+KJUPDuG20e8JnIJ7ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φКЧΧЧιъЙΠкппсЛσδ():
    value = 256348
    text = __import__('base64').b64decode('Q00zdFF1Z2NmZkFWbk42bU5EZkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡгЮеРβпλΒе():
    value = 608909
    text = __import__('base64').b64decode('cnQxUEJIWWRhYno1ZmE2aV9lX2c=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _еЩЪξшГвЧ():
    value = 944376
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AA7IQ0YvyYFabgycnk6xHSQD3Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        314
    total = value + len(text)
    return total

def _ψЭЙаΚΙМΤР():
    if False and True:
        _dead_2458 = 712
        pass
        820
    value = 739826
    if False and True:
        922
        287
    text = __import__('base64').b64decode('VFZyNVZXUmJxemJkS2hSUzRCUUc=').decode('utf-8')
    if 1 * 67 < 0:
        pass
        637
    total = value + len(text)
    if 85 * 96 < 0:
        199
    return total

def _ΞяΧιцςΠчΚРУ():
    value = 135341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw7WPkUuqfxUEwWuw2yKYTMpsE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚзμДвηΖШЖбιπУΩ():
    if False and True:
        _dead_4934 = 625
        pass
        562
    value = 738466
    if len('') > 0:
        _dead_7433 = 452
    text = __import__('base64').b64decode('cWdQY1EzNzZveFJqa1hYZlFVUVo=').decode('utf-8')
    total = value + len(text)
    if 38 * 97 < 0:
        pass
    return total

def _РαΣφъγΥнΞωйОТ():
    if len('') > 0:
        pass
    value = 457187
    text = __import__('base64').b64decode('SUhmVFRKcWZIZjRXWW04V2xPTTE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΥЧЛУИκТПΕξΙфнФκ():
    value = 916195
    text = __import__('base64').b64decode('SU1KUjhQczFZdDQ2dzZjQ2JzcDY=').decode('utf-8')
    if 51 * 39 < 0:
        484
        619
        _dead_4156 = 951
    total = value + len(text)
    if 77 * 56 < 0:
        _dead_2047 = 955
        920
        pass
    return total

def _рШАЬЗΤЦиРяИ():
    value = 583024
    text = __import__('base64').b64decode('ZHZ5Snk3cU9HUmlZV09oV3Q5RFg=').decode('utf-8')
    total = value + len(text)
    return total

def _цνΟппЪЕМЬмζΒоΖΚγ():
    value = 51908
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhneYgQpq6EZb1aI43fEYggI0UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭьτΒΠρΓνΖτΙΝ():
    value = 789805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FR7jamQM7Y42CgSs6XS9YzYK5nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙлΚыЛФδрЖΒВο():
    value = 27956
    text = __import__('base64').b64decode('SnVPTVM0c1VrVlQ0Z3ZBak4yR1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΟτξзжсК():
    value = 508348
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSzMZ0kR360bOAL2/gOoLAwn40Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζΖэЫТωκΙ():
    value = 898627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AC62dwc6+JFSMByb/3uVDBw753s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шУмασщчΓΡδоЯаЙр():
    value = 936185
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQezREAN+4YXCBiT3Hm4bQAq6Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1818 = 600
    return total

def _ΘнГιбθГЙπ():
    value = 600335
    text = __import__('base64').b64decode('TjZkNXV6NDJoYTBvZG1nenNJV2E=').decode('utf-8')
    total = value + len(text)
    return total

def _гшαπΧЫзБЙΩ():
    value = 285428
    text = __import__('base64').b64decode('UFRlWjhPRWtIYmtld1JZNzFCSW8=').decode('utf-8')
    total = value + len(text)
    return total

def _УгιЧеδΕйШ():
    value = 644737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ch7MQQId6/oRLh2TnHu8PSIq7GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        518
        542
        14
    total = value + len(text)
    return total

def _пгЯГΑуЕЯΙЫшξЫЗ():
    value = 790261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQrtRAg92q9RLQONwXfDDiAQsDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗюγυεБСπЮяП():
    value = 9147
    text = __import__('base64').b64decode('aExwZklHel9HanlhY0Rta2liT3o=').decode('utf-8')
    total = value + len(text)
    return total

def _хοнцοВяМ():
    value = 385551
    text = __import__('base64').b64decode('T0I1dkFlSk41bjZYNmpMQ3NSeW4=').decode('utf-8')
    if False and True:
        pass
        295
        pass
    total = value + len(text)
    return total

def _мЗчКЯчΠЕрдΛюΘрИй():
    if 18 * 39 < 0:
        pass
        605
    value = 132515
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwTHZUc874QtMgeBwl/DbAsJ610='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щθяΖΓΙоΞχч():
    if False and True:
        pass
    value = 609827
    if 100 * 40 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwGxPkIY5KUqE12twnTIbRIIylQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 37 * 11 < 0:
        534
        _dead_3414 = 136
    return total

def _ПьАΚАтΘΚжιю():
    value = 217197
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AifPdmMY8LxTAFyA/FyWIzUZ13o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЛΛУΜеуиΚ():
    value = 415850
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cg3XOAIY8/tbETmnnUCIOgQt9Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        595
        187
        _dead_6054 = 983
    total = value + len(text)
    return total

def _ΛэΙΚШΥУСΤ():
    value = 606010
    text = __import__('base64').b64decode('SlNfY3NJbnZSdEFBNGV0dnZqT1E=').decode('utf-8')
    if 35 * 12 < 0:
        _dead_9950 = 652
    total = value + len(text)
    return total

def _μзμТтδьбγΖОΞχΦэ():
    value = 172011
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pz7jdH8awY9UNVuu2VieYS8BsF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠмθыФψЩоμΘЧω():
    value = 909707
    text = __import__('base64').b64decode('Z0xmZTBVRzZ4MmNWcDhhUUNscmM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯЮлπВрΟГΣΖΓД():
    value = 919144
    text = __import__('base64').b64decode('YmlHdzhpbjQzaUx6WHpuNFp1WGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧжЛпυдГλГАΜЙьь():
    value = 67838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyL8V1ctprwIYgugzkfAZyQNs00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πоЭЗЯВЩф():
    value = 424556
    text = __import__('base64').b64decode('bzg1aWdDcXF2TTVPRWNmbWoyUmo=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЪνβгΓуΩцοΒ():
    value = 865342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CT7IX3Q3zrwVb1aFn06kORcWyEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъДЮνΔΩЦЦЕэΓД():
    value = 709462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxvteH8I0P4AESKTzn7FCw4D/Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΘЧΖΙωВЖΡфЙσΦ():
    if len('') > 0:
        547
        _dead_4003 = 474
    value = 501186
    if 45 * 83 < 0:
        pass
        _dead_4937 = 136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgTuN3QxyJIPNhac51ilHiEltHw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _ДΔΡжхдфФ():
    value = 362742
    if 29 * 80 < 0:
        _dead_1397 = 489
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Diu0OFg3+Ps0Chal+Q6dMQYM0T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΟжЛΕиΒЧΘмνφρб():
    value = 296248
    if 51 * 11 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IwHzZWMhzKAgEF2cx1iBDQEtt20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 72 * 45 < 0:
        424
        856
        221
    return total

def _ЗΓЪМηιΩгεΒдЙвε():
    value = 109055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FB/XSGcq07AVOSKJ7gSFFik5034='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9457 = 9
        pass
    return total

def _ПъмбПБΕπΠβλКκшΚ():
    if False and True:
        pass
        449
    value = 369877
    text = __import__('base64').b64decode('UHFMd1RpQkNQV2NlcWhSWHlTNzU=').decode('utf-8')
    total = value + len(text)
    return total

def _λЭЬΘМΖоФвДΤ():
    value = 447266
    if 53 * 4 < 0:
        pass
        _dead_2765 = 57
    text = __import__('base64').b64decode('cjh3dFJrT0xhQlFIb21fcFRFQUo=').decode('utf-8')
    total = value + len(text)
    if 79 * 78 < 0:
        _dead_3435 = 386
    return total

def _РЬΡψТнφетфЫχ():
    value = 942809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXb3aAMLyJcQEj2Q23GiEi0bsV4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1914 = 928
        pass
    total = value + len(text)
    return total

def _хγКЗυмыАлεηαУμΜн():
    value = 354739
    if 54 * 75 < 0:
        728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXbCeGIN2JklEyiwnAC8Ez0Gz20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 16 < 0:
        pass
    total = value + len(text)
    return total

def _ΕеЛлδЮχκχκв():
    value = 947835
    if False and True:
        248
        pass
        622
    text = __import__('base64').b64decode('Q0lPYlZLcXdwaldYbXB5Qm90M2I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛωΚеνуυΔΛΟιΞΩ():
    value = 862765
    if False and True:
        670
        231
    text = __import__('base64').b64decode('azlYUDBKOEtvY0tQSGFTcGhJZkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ьλфцεЗοΞоθНЯшΓС():
    if 68 * 82 < 0:
        _dead_6951 = 195
        pass
    value = 186259
    text = __import__('base64').b64decode('c0FEdHd0Z2IweEZOX0NsN3BSRzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮιккПλΩчлψЮЛа():
    if 81 * 97 < 0:
        751
    value = 248353
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Civ0T3UoqqIbDDW3wFTFZxQs6D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФαΠюыΒΚзнНЩЫэ():
    if False and True:
        pass
        pass
        _dead_8517 = 611
    value = 467767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAvQTHU9zrwybSyZyVWcGzR71jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 75 * 52 < 0:
        pass
    total = value + len(text)
    return total

def _ЛБгδЮΛХИОΘн():
    if len('') > 0:
        89
        pass
    value = 739606
    text = __import__('base64').b64decode('WGltcVNVazYyYXFPaFBxYjgwVjk=').decode('utf-8')
    total = value + len(text)
    return total

def _οΙΕДΝγЙЗΩΧЯ():
    value = 181028
    text = __import__('base64').b64decode('cTJ5cTQySzNDQ2IxWXNrREZ4eDg=').decode('utf-8')
    if 72 * 17 < 0:
        _dead_9576 = 861
        pass
    total = value + len(text)
    return total

def _μтβσγнΜηСΞП():
    value = 447045
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3/La0MRyqoRHj+653yDI3wbw1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        50
        pass
    total = value + len(text)
    return total

def _аЗςΔИФΓιτ():
    if len('') > 0:
        170
        _dead_1112 = 681
        _dead_3626 = 241
    value = 51380
    text = __import__('base64').b64decode('T1V0bVR4YXFCMHRka0o0bW1RR3k=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8416 = 220
    return total

def _хΟΒΒЧθькοф():
    value = 486562
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pxi3T3kOp4wOF12v3WWIDgN50Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΤΣйЯΘυлΗЛЧχτΚ():
    value = 537735
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgruR3s91JwrIxaN+nCII3d5vWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΓωнХэаБ():
    value = 389521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDXOa1k2y5spYxWU/Vm8GRUd81c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДшАЕДСтυБιЮΖω():
    value = 22303
    if 7 * 28 < 0:
        _dead_9203 = 295
    text = __import__('base64').b64decode('bnVORThfalZRdTFCT3VwWE5janM=').decode('utf-8')
    if len('') > 0:
        755
    total = value + len(text)
    if len('') > 0:
        _dead_3636 = 122
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('YQ==').decode('utf-8'))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()