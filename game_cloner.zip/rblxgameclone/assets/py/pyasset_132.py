#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _еРΜтмΨδк():
    value = 813879
    text = __import__('base64').b64decode('TnpGN2t0UnZFX2hVWHp3MFV4Tm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΚеЮωχтμЦ():
    if False and True:
        pass
        _dead_8914 = 306
        _dead_3288 = 920
    value = 838151
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhu9QAg77rEuAhur/GOfLC580mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΟУЪЙКТεгЬЫΤ():
    value = 741285
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cyr+O0gQ+KoWLAi62lC+CyMh23g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        438
        pass
        pass
    return total

def _ΣΖЮΖφΘЪΟТρ():
    value = 901496
    if len('') > 0:
        _dead_6676 = 226
        206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB/FT14c7osNKiWH5QKjCx8ExVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5895 = 123
    total = value + len(text)
    return total

def _ΦτΕьЦнЩΥιθπЖИоζ():
    value = 597862
    if 4 * 51 < 0:
        379
        93
        _dead_9182 = 244
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx7KenAN6YsHBTqs/li4EAh21Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _жАςунΔВβД():
    value = 486768
    if False and True:
        pass
        541
    text = __import__('base64').b64decode('emo4bUZZY3FEQTdUbWJYUllLek0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭЛыωаЯйιЬтπςч():
    value = 187223
    text = __import__('base64').b64decode('RWdQZkYyd3JkcDkwYktnSjZtbDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _аΠЫζΨЖТБащΑЭΥ():
    value = 706104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwXLeUAaxL0RLliS0n3IY3QD7T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οСбННргεяΡφπл():
    value = 818065
    text = __import__('base64').b64decode('cDVpcW5tVm5OaUhEMjN5aktSYXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΖРηΣтшΩΒΝфσюΘ():
    value = 918370
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSawX14A96sVCRqzxkfEMn0ZxkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΙОΤδЯΞσ():
    value = 623412
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiXsSVk25KsGFCKBn3XGZB051G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠдЩаΣЬυюΥиθΖ():
    value = 630323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBW0RmkV2JopEyj68nyePh9/wFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        163
    total = value + len(text)
    return total

def _эΗШχΝУкΦИЙνуЖΨ():
    value = 385265
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX/oOgg01b4RMF6o5ELIJjwHtnY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        958
        pass
        _dead_5937 = 882
    total = value + len(text)
    return total

def _φцςξκΑΦЩЙхΙσэ():
    value = 6753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwrmTVUx77A0bR6BxGnIFiF5zkQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖρΟψσΖοε():
    value = 83439
    text = __import__('base64').b64decode('SWIzeWZqZFVGRzZvblh5V3FiOXk=').decode('utf-8')
    total = value + len(text)
    if 98 * 45 < 0:
        _dead_7654 = 408
    return total

def _ΥζШГυυΧПΙЖЗЦЩРуЯ():
    value = 54023
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAbCS2Bh0Lo6Dx6y8lGgOT8O00g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζζκЗШΠωΖцωТТ():
    value = 367233
    if False and True:
        pass
        _dead_6860 = 439
    text = __import__('base64').b64decode('RnBjM2ZqY0dnTUFraUN1TTROOHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ХΞΦЧьъМΞυЫ():
    value = 358234
    text = __import__('base64').b64decode('amowMTFlVVdmQzlXN3pyUkdkbWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ыФиμеЭΟο():
    value = 87652
    text = __import__('base64').b64decode('STdLbmE1UUlFNzhIaHpFa1YxSjc=').decode('utf-8')
    if 94 * 95 < 0:
        _dead_4477 = 743
    total = value + len(text)
    return total

def _ЬИΑмνъфЕРι():
    value = 358533
    text = __import__('base64').b64decode('R3h0bXlzZWpiZG1EcDlBYkptTjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _АΣΘшιяΡΖΜП():
    value = 67746
    text = __import__('base64').b64decode('YldFdF9nOUZWNGtjZ0xrR19RMnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔπжΑЗегц():
    value = 467231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhftXlZp1oIGIyuP8VSYHwt64UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бρХμпбγΠО():
    value = 265935
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESDWQ1081PwJGyKwz1OiNS8uzH4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 19 * 13 < 0:
        _dead_4052 = 500
        228
    return total

def _ЗχοΨΗχυΜ():
    value = 72070
    text = __import__('base64').b64decode('eGJjdl9VVFpuUVZzZnVjMmNfajk=').decode('utf-8')
    total = value + len(text)
    return total

def _еΡРъοΩмфςΜ():
    value = 175256
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3nga2kO5psiDV6c6nWIEgQL0V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤмτΛΤзЭεсλ():
    value = 488369
    text = __import__('base64').b64decode('WlJWVDRHc0l1M054RFp2clNZY08=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬРЙпыσЙгчωΖкь():
    value = 736058
    text = __import__('base64').b64decode('cHd2cEtwWGROUW5mQjdXak4xSG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣЧЧγЩΝΥΗΑΟννΞφδ():
    value = 153037
    if False and True:
        _dead_1259 = 665
    text = __import__('base64').b64decode('S01nQ3JsczFMSkFMOUdaSjhrUmo=').decode('utf-8')
    total = value + len(text)
    return total

def _цзΞψЫочυйшςих():
    value = 862423
    text = __import__('base64').b64decode('cm1ocEx3dmFUcUJZVmNyMUU2c1I=').decode('utf-8')
    total = value + len(text)
    return total

def _еΞΙΒЯЙфυПΗмεΣфа():
    value = 849293
    text = __import__('base64').b64decode('THpfRVVweDVEd1ZqN3hvQ2ZDelE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΕпкκЕЧоЮтГкτХ():
    if False and True:
        _dead_8794 = 560
    value = 460183
    text = __import__('base64').b64decode('U3JidzlSSmRZRGxNdW0zVUJOOWk=').decode('utf-8')
    total = value + len(text)
    if 29 * 97 < 0:
        _dead_7804 = 220
        57
    return total

def _ОЩΤмЫδбИ():
    if False and True:
        461
    value = 501432
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXnme3sM5KosERus5XGxGXJ96EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оигΞЗΞхШΝΙтнгГ():
    value = 615071
    text = __import__('base64').b64decode('S2JnWEFpc1ZCNkp5VTZ1WllZMUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ыМΗДнρаιλ():
    value = 595429
    text = __import__('base64').b64decode('Y1FtRFlFenlSTkNXWnVVVno4YnE=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _σΠЕΣψЧδΙСьοг():
    if len('') > 0:
        434
    value = 458092
    text = __import__('base64').b64decode('SUViVjVwQUlUVUxjdkNRcWtpSGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΖрРΟаЪΗУщΤэεзХΥ():
    value = 543643
    text = __import__('base64').b64decode('Rk90amlrbUtMbXZQX29JNUs2Slc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        420
    return total

def _ЙкσςΗяАыΥΩ():
    value = 476826
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiHTXlIWroEVDSeWx2e2BwoF9Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыЙйчΜЬλхлЕЛθ():
    if len('') > 0:
        157
    value = 48616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSfARUMw2awWaC6WxwPIDAsl1zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        435
    total = value + len(text)
    return total

def _αΙΣрЯкСьμк():
    value = 292377
    text = __import__('base64').b64decode('SmoyRlhTdWd5UFdTR1hXWmQwWks=').decode('utf-8')
    total = value + len(text)
    return total

def _ргблШЛБΞεДэлчК():
    value = 353846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAK1OVsY15gSLCOv+GyXbSod9Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_6914 = 250
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ХΗζΝЭчщξ():
    value = 718610
    if 62 * 71 < 0:
        983
        _dead_8748 = 234
    text = __import__('base64').b64decode('b3dTWWdESTR5UmJFaUtjYVhlSTY=').decode('utf-8')
    total = value + len(text)
    if 3 * 51 < 0:
        842
        532
    return total

def _ΖцАвμЫУй():
    value = 269658
    text = __import__('base64').b64decode('ejg1TkdtaGJBa0RoZEc4cFZsWHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ηЯЖοΜЛыαΖУХяΛТп():
    if 5 * 90 < 0:
        373
        482
        539
    value = 402413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JDnSeXAy8PkJMRuExAeCBRcdtWs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζЛχХυеиГδу():
    value = 905329
    if False and True:
        78
        _dead_8713 = 398
        _dead_1036 = 815
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyDhVFAG+pkpEiecnQGSFgx3/nY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦнСйΜоκК():
    value = 763223
    text = __import__('base64').b64decode('eHJieV9TYWo2NWZ4dTlrY2oxbGc=').decode('utf-8')
    if 92 * 45 < 0:
        pass
        _dead_6952 = 209
    total = value + len(text)
    return total

def _эΕΜТΥЬХЛоΖΔΛΦ():
    if 16 * 16 < 0:
        999
        pass
        pass
    value = 251467
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3vxR0UIzYowFV2PmVe0AD0Dw3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иςУАУЧαфЪφщам():
    value = 472572
    text = __import__('base64').b64decode('ZmJXYVZsOG5ibE9tSnNKSXRNUDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩжυОЧИΙфπΔуοхдщЩ():
    value = 643277
    text = __import__('base64').b64decode('UjFwak4wczM2cWNKaUlkVXppNWk=').decode('utf-8')
    total = value + len(text)
    return total

def _гΣρОтпΞХ():
    value = 86146
    text = __import__('base64').b64decode('RkR5WEFDRG56aFZEaUhpUEd1Zmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ωιХЭЫуОцЮΘΜЮЮЦй():
    value = 58945
    if len('') > 0:
        _dead_5331 = 873
        pass
    text = __import__('base64').b64decode('Q09nYWRiUTNvWWFxTWlqb29nNGw=').decode('utf-8')
    if len('') > 0:
        _dead_7796 = 969
        pass
    total = value + len(text)
    return total

def _мςОПцυаκΗΒΠΘυБы():
    value = 586951
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCTnPF9p8KkCIFyJ71CgYA821UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯхяЗαΙΛщчН():
    if False and True:
        153
    value = 613724
    if len('') > 0:
        _dead_9119 = 280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITvFa0kN0PASI1+77wWVNx88sEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 64 * 34 < 0:
        _dead_3748 = 543
        _dead_5820 = 741
    total = value + len(text)
    return total

def _ТξгыЖмЛдοΦ():
    value = 963125
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwXPVFoer4wGbgakwATDDg4IzT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡГьАΚйЙкРЯβкТ():
    value = 333529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lhb+VHwJ8P8lGzqkzwO+IxE980M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДβΤнФΓЭςΜΨ():
    value = 270814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDf+ZAAx2ZlUERf6ygG5YzZ2/ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 67 < 0:
        300
        _dead_3439 = 842
    total = value + len(text)
    return total

def _ζФυутнυλαΑМЗ():
    value = 330428
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LhzhUWI187obLlqtyVmjJHA4/Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γуζΧЩΗЖлН():
    value = 346740
    text = __import__('base64').b64decode('VXpWVkYyOXZsSjVEUFlUY0NZZ2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _сШыОУΥЕΛΑРпР():
    value = 803654
    text = __import__('base64').b64decode('d2VvRkRsWldxQnVPTXZIYmJXMWE=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΖоСμΡВшТизζΕ():
    if False and True:
        _dead_1019 = 714
    value = 140050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lyv0dmAtrYkJNCysx3qjLT0V03g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6438 = 191
    total = value + len(text)
    return total

def _ΝдЧΩйλЫλΕ():
    value = 28775
    if len('') > 0:
        _dead_9260 = 830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQTvQ19t8ZsMICiUwQ+8YC8rwFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 53 * 24 < 0:
        pass
        _dead_1159 = 534
        _dead_6855 = 457
    total = value + len(text)
    return total

def _ΞьΔΕфяΧΟαΘΞмРΦ():
    if 95 * 58 < 0:
        pass
    value = 484518
    if len('') > 0:
        317
        _dead_9332 = 863
    text = __import__('base64').b64decode('T2hBTndwY0JrTWJka1VSbmduYjc=').decode('utf-8')
    total = value + len(text)
    return total

def _μКνгрнφБфГвΕДα():
    value = 768485
    text = __import__('base64').b64decode('eUV3RTN6OHk0N1NhcHJJX3JLTzI=').decode('utf-8')
    total = value + len(text)
    return total

def _кκΧЩГΑпмЗвДδγλф():
    value = 883841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnbPagQf37knaQyt4wa8NiEIwm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δюλΟРψЖΠ():
    value = 500099
    text = __import__('base64').b64decode('WG5fakVZb25aN0pIQUo0UjlEUTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ζюЦθтЖΘТЪ():
    value = 564774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQ7HZ0Uh0/w3LgKA5l2pBxwc/lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ээΔЭφуУШΖΡ():
    value = 131455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyL0P1gyybJQChuR2kKzEgd2wV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΟЫβΤΕФΓςОΩ():
    value = 788219
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyLvO2sSp6ATGSf62WS2Ozwn7Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηЬЫВЕχΡρΨжЦΩМςνι():
    if len('') > 0:
        pass
    value = 438099
    if False and True:
        pass
        450
        243
    text = __import__('base64').b64decode('dTRoYWhCMWEya1drQWwzMldhNlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯфεяζыΕуΓ():
    value = 388053
    text = __import__('base64').b64decode('THRSOTc0WHpKUkw5b1ZhdGxvQWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ФΣЪκπБЫЯямСΝЯЫЙТ():
    value = 109638
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnixPUtv6KQrNAmo/0SFEzEj0Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 78 * 34 < 0:
        _dead_9160 = 132
    total = value + len(text)
    return total

def _ЫατΧΟΥΓМ():
    if False and True:
        882
        272
        pass
    value = 541810
    text = __import__('base64').b64decode('WmhtMGRzWE5DZ0hvbE84RDEzYW8=').decode('utf-8')
    total = value + len(text)
    if 37 * 78 < 0:
        pass
        35
    return total

def _ΖЗυωЫхΑЧφ():
    value = 796450
    if 98 * 21 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSCyXEU157gXAjulmlKBHRMV6DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        308
        474
        _dead_9175 = 479
    return total

def _ΑΙскΜтιоωчШРциЬС():
    value = 851463
    text = __import__('base64').b64decode('bWJDWkVWVUZIamhkRFhKYlpEWnM=').decode('utf-8')
    total = value + len(text)
    return total

def _уИΡРвШμΧφДТТ():
    value = 2416
    text = __import__('base64').b64decode('ZUhHUHY1c090Q3hCUmR4Y2tTaGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ъСЫΕЯХКСΓэΠΔйшΔ():
    value = 760132
    text = __import__('base64').b64decode('bWV3Sld2ZEliVVdsMVJWZlFVMVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑжщΔσОШΝЮ():
    value = 693069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FS7PZHYU9pkLMxqUx3OENTUOznc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βдбΞАюΚΨχ():
    value = 163432
    text = __import__('base64').b64decode('UFFSZjlQNE9FRG14V3d5aTI5V1M=').decode('utf-8')
    if 48 * 53 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ыΜЖξΨЛΛοЬΡзгтэ():
    if False and True:
        _dead_3906 = 971
        pass
        _dead_9170 = 137
    value = 738683
    text = __import__('base64').b64decode('WVE5eGlBMk40TUJpTXVBSjVHclI=').decode('utf-8')
    total = value + len(text)
    return total

def _нοΡαДЖζрυЖ():
    if len('') > 0:
        722
    value = 266772
    text = __import__('base64').b64decode('VW5JTEZpRjVEN1pjVzdPclZQZ0E=').decode('utf-8')
    total = value + len(text)
    if 4 * 9 < 0:
        pass
        _dead_2097 = 899
    return total

def _ΚρЖНАΚΠЭγζв():
    value = 789426
    text = __import__('base64').b64decode('R1ZqVVhzUnpUTzViNHU3ZzZyYjA=').decode('utf-8')
    if False and True:
        pass
        965
        188
    total = value + len(text)
    return total

def _мхΜсφЮγШΧΙъΨ():
    value = 449737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD3cT1ce56I2KyDykW+eYwoc/GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣλоΗБОΖя():
    value = 462570
    text = __import__('base64').b64decode('eHVic2h3N1dtUVl6YW03VmdPSUo=').decode('utf-8')
    total = value + len(text)
    return total

def _λΘβйДτЯσΨЦЪНχ():
    value = 773522
    if 13 * 39 < 0:
        _dead_2975 = 134
        pass
    text = __import__('base64').b64decode('RzYyMXoxdk53WWtKaFl6T3UycFE=').decode('utf-8')
    if 22 * 52 < 0:
        pass
        474
        423
    total = value + len(text)
    if 48 * 6 < 0:
        _dead_2639 = 564
    return total

def _ΥиΓьпоΩδТБθлШХо():
    value = 960892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz7pWkE+3LwEFgmAnlWYOik5xlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 71 * 36 < 0:
        _dead_4838 = 984
        _dead_1978 = 549
    total = value + len(text)
    return total

def _ИцσЬοβΟΓпπ():
    value = 326417
    if False and True:
        655
        547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MR/NeXcq5KkHGDyJ3k+cFjEssVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4729 = 899
    total = value + len(text)
    return total

def _ΕΩЬВςнθНВψΓр():
    value = 519283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERfnP3MSxrsTPQOUkXSxHzR51zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗоγдυЦΛфезΘ():
    value = 445289
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRixZQY00qVaCB+FmFSKLhoWt2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗКоΞΘψΖΓБπК():
    value = 585477
    text = __import__('base64').b64decode('c3p0cDRmMUR1ZFQwcUdjNWs2SG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝεЩωπюηимЭ():
    value = 645565
    text = __import__('base64').b64decode('YWlIUURCZGF4TUtkZEo0WTFxeFA=').decode('utf-8')
    if len('') > 0:
        _dead_2330 = 147
    total = value + len(text)
    return total

def _ЕοδШЖАЙкьξОмГβдΟ():
    value = 807814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E33oXV8P778tHTWc4X66FwIf/Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НаΣрРδιКЖαΑΤмΖΝ():
    if 36 * 48 < 0:
        646
        _dead_9187 = 780
        971
    value = 28722
    text = __import__('base64').b64decode('TUJwNFNpTE9Sa3V5Zk5wYTQ4VEk=').decode('utf-8')
    total = value + len(text)
    return total

def _βХЖдРЭнТ():
    value = 474838
    text = __import__('base64').b64decode('Tl83Y1BJS1pKNDJjazFkMkhWOFA=').decode('utf-8')
    total = value + len(text)
    return total

def _сγНЫψμгΖμσ():
    if 5 * 76 < 0:
        319
        pass
    value = 470619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ES78ZVoJxIUxOCSU+3mWGzR9wGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΚЪвΡιШЙпхΑХфС():
    if 39 * 85 < 0:
        _dead_5276 = 578
        299
    value = 997847
    if len('') > 0:
        _dead_7712 = 971
        _dead_1847 = 657
        pass
    text = __import__('base64').b64decode('blVJYjJSTWs2ZjNoS3FBaU16OWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧςΧЭАШвУю():
    if 3 * 51 < 0:
        pass
    value = 878829
    text = __import__('base64').b64decode('aEdSSkNldHh5YVR5UFBGRWJnQkw=').decode('utf-8')
    if 63 * 99 < 0:
        _dead_7902 = 210
        _dead_1172 = 240
    total = value + len(text)
    return total

def _ξΦялЮоΜυДК():
    value = 531607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyO8Nwks+fASPAjy8Fe4MTUDxlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        894
    total = value + len(text)
    return total

def _ЩыУОВΔωΒйХ():
    value = 955097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyHDY1cJ2b0zPiSZw0XFDSgQ818='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_5608 = 481
        _dead_8451 = 890
    total = value + len(text)
    return total

def _ΧюψιХюειЪχбэЗΤкШ():
    if len('') > 0:
        375
        _dead_6717 = 954
    value = 457646
    text = __import__('base64').b64decode('amV1OXNjU2RJRDY3VnR4MWEyY1U=').decode('utf-8')
    total = value + len(text)
    return total

def _яΨСρЕяЦцсШрιχвΓч():
    value = 75559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hxj9XAMq0flVNAuH+W69GCsuvWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡцΒςηУγНкэε():
    if False and True:
        pass
        _dead_2083 = 383
        _dead_3951 = 223
    value = 399197
    if False and True:
        pass
        652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARfhZ1YY/bsLHC67/GKkEAd91U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪаσВдДθΥΗт():
    value = 603534
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH/xN1U1qJxTYjek8kenMxMb4EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΖΝВΠЪηНΔΑЧурΩκю():
    value = 354462
    text = __import__('base64').b64decode('Y3pGMXUwN2FSUnlyZnVCbDNqOVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ИВпΚщωОАΘнсκ():
    if len('') > 0:
        pass
    value = 744741
    if False and True:
        _dead_9401 = 260
        201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTXBVG4K9o0sOFeL8mmVMgN54FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨЦжΗΥΩΡжεРΦπ():
    value = 961523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTfON1Jp+fA3HACs/GWbGCN4w3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сηУКβЖψяΕОВтτ():
    value = 853213
    text = __import__('base64').b64decode('SmcwMzd5TlkwOEdXNmlYQjZWd1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭжΕхξшΝΑнаФΒλ():
    value = 149756
    if 45 * 50 < 0:
        pass
        pass
        958
    text = __import__('base64').b64decode('TlRKdkk2NWFxTGVSZVU4b09KdEU=').decode('utf-8')
    total = value + len(text)
    return total

def _хюЯΞφцΜыζΙкхχ():
    value = 484223
    text = __import__('base64').b64decode('anhiS0lUNUEzbFVKOHd3c0kxQUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖФρшπΓΝθЗφπр():
    if False and True:
        _dead_1489 = 831
    value = 286064
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzvFVEEp2ronCASv51SmYQ011Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъдОЫЗπΜМμьЫШ():
    value = 888780
    text = __import__('base64').b64decode('d1lSbWtwWUluRHRmc2xQVmpsY2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ψГвтσκρпиΡГΣпρΦ():
    if len('') > 0:
        _dead_4756 = 919
        469
        63
    value = 798886
    text = __import__('base64').b64decode('YUxkYmpDUnVqaDhsbnZkTnNvYmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ФяρхЪУΩχ():
    value = 94802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Awj1RGAY86IkPF+7/3mqM3MB8T0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑζПκпмЬΦкЖσе():
    value = 623848
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwL8O1lq5K4LPgiI0nSEGAod4X8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 98 * 89 < 0:
        pass
    total = value + len(text)
    return total

def _хβУфΩынфΨд():
    value = 478827
    text = __import__('base64').b64decode('Ukw2Zm5xYXIyTmFkV20yTENfRFc=').decode('utf-8')
    total = value + len(text)
    return total

def _АΠγяχπоч():
    if False and True:
        _dead_1251 = 490
    value = 736505
    text = __import__('base64').b64decode('RXRoXzRnX05qNUNKcVlreFQ4eDY=').decode('utf-8')
    total = value + len(text)
    return total

def _νБΒзΝыПηКЯЗφЩС():
    value = 301062
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LA73PWIh268XNV+M2HOGYSof1Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΑЯбдЛчКσГψιΕ():
    value = 693744
    text = __import__('base64').b64decode('TnNJOHFMRG9vdGt2SllWU0RtZHM=').decode('utf-8')
    total = value + len(text)
    return total

def _АЦхЦγωΧВρЭуεψχЗε():
    value = 404193
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQPGfl4I8480CTWN0kC3FwEWvEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φЧΡЙγЮБпоψΧБяςγ():
    if False and True:
        715
        pass
        pass
    value = 782785
    if False and True:
        _dead_5964 = 341
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCTiZQYIzJsIDAitnW7CGSAovUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шяθЕЧЬпτΤΞ():
    value = 607608
    text = __import__('base64').b64decode('ekRFazBJY3NfN1F5UVExQVhiTHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΓχΙМоЗЧрАΙяκы():
    value = 706418
    text = __import__('base64').b64decode('eGR6QmdCdHVJWjgxTTY4WGsybFo=').decode('utf-8')
    total = value + len(text)
    return total

def _γРΞςцФъΠДΤΡаКΨΛ():
    value = 954154
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DXjeQUFg678aABmJ72KWJXcMyFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗυΖηψξΒυΘСЫнэ():
    value = 120147
    text = __import__('base64').b64decode('c1owU3Jwc1YwSEJodWp6TU51dEs=').decode('utf-8')
    total = value + len(text)
    return total

def _щвЮωБρЖтюХу():
    if False and True:
        _dead_5316 = 620
        pass
        _dead_8439 = 588
    value = 575081
    if 64 * 63 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDXLTEAczJATM1+NwwbBZyp9wG8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΞцЦяФθμжи():
    value = 954485
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzzmZkJh3P4vPFinmUGDAwwNvGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΖьВМЛМуεσмЧОЗфΡ():
    value = 223012
    text = __import__('base64').b64decode('Ul9BSENycVlBQnZHenhZZzJHR3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪрвνΚνеотИЫΠο():
    value = 300358
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KS3HOXkB7vkxDSWk7lq0EB0pyn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9560 = 297
        _dead_1439 = 956
        196
    total = value + len(text)
    return total

def _μКνтЮЗГυ():
    value = 494692
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cnn8XnAg04pVAx+onEDDHy0szUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςшλΤБюцЦτζхЯμМΩТ():
    value = 962929
    if 72 * 84 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzizOlQ4qrgTMFuQw2LGECgfzlo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гπνΙОгЮγραυ():
    value = 317427
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj7UXlUUqZc1PAGC3A+WJwEFtWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭςВйσчНθцΜчΓ():
    value = 313020
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXnNVn0h3L4wLgy6nkfAJHIE6l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        683
        _dead_2142 = 433
        pass
    total = value + len(text)
    return total

def _ФдмВθМΚйдАβεсФ():
    value = 463956
    text = __import__('base64').b64decode('dXhhU19vNFV2Wmd5WjloYUg4d0g=').decode('utf-8')
    total = value + len(text)
    return total

def _ФлΩТφаιΒΜ():
    value = 598428
    text = __import__('base64').b64decode('VDRMM2M2b192S3VHVVY2Zm8xa1k=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥΝςжЭдМЯещ():
    if False and True:
        949
    value = 226398
    if False and True:
        pass
        pass
        339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQXWO2Nu87kgKzCo4UeeCyAFvUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        529
        _dead_2433 = 540
        pass
    return total

def _щμλΩΕЯьыОдηШ():
    value = 897153
    if len('') > 0:
        87
        688
    text = __import__('base64').b64decode('dl9qRmtHZVhUdEk2UVBwTmZFbzg=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_9679 = 606
        pass
    total = value + len(text)
    return total

def _сυлъΧмΜΞΣДηфАτЙв():
    if False and True:
        pass
        797
    value = 458864
    if len('') > 0:
        _dead_9261 = 725
        _dead_5784 = 867
        pass
    text = __import__('base64').b64decode('c1NoUlFRNVZFMEdESDdQMWhzX3g=').decode('utf-8')
    if 85 * 63 < 0:
        _dead_9043 = 951
        pass
        367
    total = value + len(text)
    return total

def _ГлΥЩΗΞднΟω():
    value = 504531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSDlXFIh+vkTHArz8F2iOAoo834='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        749
    total = value + len(text)
    if 14 * 46 < 0:
        pass
        pass
        _dead_1981 = 162
    return total

def _ΨфтγиФЛΨчАΨΨ():
    value = 747880
    text = __import__('base64').b64decode('QnQyc0tfUXFaWG5QMjNjNnhlaDU=').decode('utf-8')
    total = value + len(text)
    return total

def _αΞΛγТзюНΧ():
    value = 422983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAz8YEkO94QoPxuR7U67YCJ+tFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟвτθжΖАд():
    value = 700742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQG3W1MMyaYTDAi7wA6IASg/xnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 34 * 9 < 0:
        pass
        _dead_7309 = 364
    return total

def _ЦхξКΡОЮбΝХХβ():
    value = 115185
    text = __import__('base64').b64decode('Umxrdm5qS041UGF2bzBIZjJOX3E=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_7048 = 374
    return total

def _ЩωТΓСокВ():
    value = 640993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3fQaXkO2ZsTMhyIwnXCJwR/1WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        677
    total = value + len(text)
    return total

def _ьΩтЧΞγЕжυπΗБтл():
    value = 598895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxfJZlsy7fEuPzCnmlK7OBwCzT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МЛοГсХиЫРФοЪчγз():
    value = 387465
    if len('') > 0:
        _dead_2698 = 303
        _dead_4675 = 627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXjLW39oq68nNzqz8nyUDHcW3Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΧυνΟθРеΥιГуЪΩΟΘ():
    value = 230751
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3bpQHgq3Yw2HAmmz1inIXEWwXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЛХОΘΚρΒЗξΙ():
    value = 642137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HC7sO24U34smYxiv0HeaOnY1wTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 82 * 85 < 0:
        718
        945
    return total

def _ΧАЖАЪλкЬΓЗ():
    value = 41410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ahj8en4X0oETGwiZ6w6RbDEfymc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        58
    total = value + len(text)
    if 95 * 48 < 0:
        pass
        _dead_1261 = 130
    return total

def _зσыζбжΜδэЩАΩРЕΓ():
    value = 927627
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnjRTVQN651VNgmz2WWfPjwM22Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гХκъЭдΩчвО():
    value = 672562
    text = __import__('base64').b64decode('V0tQeXI5eXBmY3FiYV9HN1JGNFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЦЬЛΨЕΒт():
    value = 533512
    if 43 * 92 < 0:
        511
    text = __import__('base64').b64decode('UUVpQVEyNE9hWnJsZVIwTXBlaHI=').decode('utf-8')
    if 60 * 52 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ψβхкГзЧΟДюΣγΒЛωп():
    value = 529790
    text = __import__('base64').b64decode('TlM4WTl3anRqMms5SkZyRDdFenc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΤжНσЧΖΔυ():
    value = 617574
    text = __import__('base64').b64decode('eWxsc0Y4RWxuOVllNDVDMjNwOF8=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _πКεεπикΔЩтМδ():
    value = 279433
    if 38 * 55 < 0:
        493
        _dead_1941 = 614
        _dead_3447 = 267
    text = __import__('base64').b64decode('dXE5RWpnelJGaWVjZGxBdkd0STM=').decode('utf-8')
    if 64 * 70 < 0:
        441
        _dead_6235 = 329
    total = value + len(text)
    return total

def _ТσАэяζΖидйэеД():
    value = 500683
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DifTfmU7yfwnbQSB2m+vOgEI0Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УχСНΨвςщφυЯ():
    value = 670014
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQS3YFVrzbgmPiiA0nOJDDd+y2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΞЪиΒιΦшα():
    value = 388424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA7JelA49vpWIwyr4nq1ODI7t2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΠΒπβιЮηΤ():
    value = 918809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESrPfWsW7IpUawKPzgOvMB8n7Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЮνмΦΓвкγε():
    value = 981458
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgHMYXMfqo0hMSCu8nyZOjEm5Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΖъΖВНβчξрлШуΗю():
    if 71 * 63 < 0:
        pass
        _dead_5319 = 614
        pass
    value = 701635
    if 46 * 79 < 0:
        _dead_5746 = 843
        _dead_1908 = 291
        _dead_1046 = 217
    text = __import__('base64').b64decode('VlRnUlN0UlpaX2VrVW9jU0E2Ylc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        30
        287
        369
    return total

def _ДуξЦΤЗыиαΓьνΘЧ():
    value = 802044
    text = __import__('base64').b64decode('ckxMRmtubXEzRW05YV9MRUt2aEM=').decode('utf-8')
    total = value + len(text)
    return total

def _еλРξψκТψО():
    value = 72846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH/9eQAt+YoMMViX0VChJDYL1Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΟνοфуδμσ():
    if 30 * 88 < 0:
        _dead_1286 = 951
        _dead_5397 = 626
    value = 689453
    text = __import__('base64').b64decode('bG5aVXpnQ2NUMjlGcGJPWXhadTM=').decode('utf-8')
    if len('') > 0:
        172
    total = value + len(text)
    if len('') > 0:
        _dead_2436 = 614
        _dead_2440 = 633
        _dead_8060 = 553
    return total

def _μΥЫьПгОгГвбΞ():
    value = 851959
    if False and True:
        691
        812
    text = __import__('base64').b64decode('WEY2RkJWRzdmZmJMdXhuZndPT24=').decode('utf-8')
    total = value + len(text)
    return total

def _шжΚШθδОяΡК():
    value = 395332
    text = __import__('base64').b64decode('ZnFiSXNONGpoYWlaalpuOFd1N1U=').decode('utf-8')
    total = value + len(text)
    if 84 * 35 < 0:
        _dead_7521 = 429
    return total

def _βΜцωхиьчΨ():
    value = 427041
    text = __import__('base64').b64decode('RHl3eGU1Y2R4ZzZYWlg2TjJhNWM=').decode('utf-8')
    total = value + len(text)
    return total

def _лВЫΠΒщЯхζхγьвκ():
    if len('') > 0:
        _dead_1915 = 449
        pass
        196
    value = 102085
    text = __import__('base64').b64decode('SXhyTXU2d1pqZlVuTUlDenVOZTY=').decode('utf-8')
    total = value + len(text)
    return total

def _мЗγΝΖъЖОфвкр():
    value = 115126
    if 25 * 71 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRDFTQY07aEwGz6OmwG4MQYC9Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вρиГδЫъИЙЮ():
    value = 418439
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyXLPkQMzr4SaSSLyU+qDTUY6Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПωТΚφижУиΓβЖΙцΦ():
    value = 25918
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXmxYmcK5Kw1OxiGymS9Hiop0Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        749
    total = value + len(text)
    return total

def _ЮοЙΓчδЯρ():
    value = 239217
    text = __import__('base64').b64decode('alZQY0hLU3djQTIxS0dyS2lDTG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑΔыΑΗжпГэγΧРρФНа():
    value = 372767
    if len('') > 0:
        _dead_3553 = 668
        472
    text = __import__('base64').b64decode('SkNtb3hrQ0NNalB4dWppQTVsVTM=').decode('utf-8')
    total = value + len(text)
    if 47 * 6 < 0:
        pass
    return total

def _ПЪпхΖзεΥ():
    value = 894886
    text = __import__('base64').b64decode('cnlmREJnbVA0WWV5NWhvcnlqMXU=').decode('utf-8')
    if 24 * 73 < 0:
        587
    total = value + len(text)
    return total

def _КΒСЕμЮЦтэЗΟШзΧΣ():
    value = 900320
    text = __import__('base64').b64decode('T0tva0pXTDBqRTBoSnEwRzF1QWk=').decode('utf-8')
    total = value + len(text)
    return total

def _моηξΒΠЪαЧчΗБЬхΣИ():
    value = 174095
    text = __import__('base64').b64decode('UkVjRkFPanhfN1R3R0VQenpRbHo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        536
        pass
        _dead_4741 = 797
    return total

def _ныΗβЙзьΩСТйΘПшх():
    value = 865754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRjrawUO571QC12B4F2bFR03w20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РИаτьТρБεЖνπнэηТ():
    value = 355588
    if 54 * 44 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lz3KT3sR774wbB6unkHDNQh99Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_2795 = 799
    return total

def _υαЦЮΩξΗν():
    value = 873523
    if 99 * 72 < 0:
        _dead_3540 = 787
        pass
    text = __import__('base64').b64decode('UExRUjFra0FFbUJwbDBiakxoNmk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥИРсΝТжЗΚЧДΙ():
    value = 619488
    text = __import__('base64').b64decode('SWdVa3MzM0FNWDJEV2RtQnFFQ0o=').decode('utf-8')
    if 93 * 9 < 0:
        565
    total = value + len(text)
    return total

def _ВΟΙСбОψчМВΗαц():
    value = 993064
    text = __import__('base64').b64decode('VXRtZlhDT1hOZGNiZGVjV1ZJOFU=').decode('utf-8')
    total = value + len(text)
    return total

def _УЪдыЯΧЗλНТцюΦъ():
    value = 684582
    text = __import__('base64').b64decode('RzZBZWRtQ25UUVpQR2lvUE1nb08=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΔьфεЧяΞΦКЦйΟΓΛ():
    value = 5742
    text = __import__('base64').b64decode('dmxOdjZSODBkTVZhdUoyWGpxWTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ФЬХΖЫтιДΠЙ():
    value = 216948
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDfnZkAT/4INEQf28WKhBQEt/GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бЬΡΧΖΖνых():
    value = 456994
    if 79 * 22 < 0:
        31
        _dead_1549 = 446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DH/TRXYNrv8OKVak3mSZECw293o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сГРξяоΕбтλИΟ():
    value = 770239
    text = __import__('base64').b64decode('bVl0TTFKamVWUkk5YXNTRHlKU3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ψБсУυΙСΦΛ():
    if 61 * 40 < 0:
        _dead_1317 = 514
        pass
    value = 505150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AD/yelJgrqsCKFq2y06kHA0owlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        559
        pass
    return total

def _кθφШрΥθщВκ():
    value = 788633
    text = __import__('base64').b64decode('Y0ZGbWM0UEd5YV9iQ1A5U0VmNVM=').decode('utf-8')
    total = value + len(text)
    return total

def _МыΩχПМοВζΠцωХΑще():
    value = 288431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCK2Xnk68qUyHSqi/W6ebT0O6FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΔТЩфОΗχнτыэФτ():
    value = 906957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACPjYkRhzaYNFCOu41LCHjwY7zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        _dead_5149 = 539
        307
        137
    print(__import__('base64').b64decode('IA==').decode('utf-8'))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    pass
    826
    617