#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _АωнΥυΑхοС():
    if False and True:
        939
        936
        _dead_6526 = 119
    value = 39614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRfldAJg/6coFCOmz1iAGwAE9zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤωςяΨΞιηкλлοГρΛ():
    value = 826407
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSvnXV4g958wExu34WXGLDQ+6D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4103 = 155
    return total

def _ΝχЫωΚΖДб():
    value = 883820
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgDLaUsqwYs7Hh6c63O7A3x80kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωЧΣφΝτГлξЯ():
    value = 890809
    text = __import__('base64').b64decode('cERxaGFDY2drWWJhR2pXVkhWek8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮЦξъфΒπЛπΔц():
    value = 361364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjvMRlwPzokXHxiCyw/IYTcBtGM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓещпΥУαфЩюпрδνэ():
    value = 45605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhfwZ30f+alWYyCH63yyLBAIvG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΤΘΛУмθμΧЭχ():
    value = 734918
    if False and True:
        778
        826
        _dead_1702 = 32
    text = __import__('base64').b64decode('cUIxd1k3Tkp5WjJPYnNGdUtCcjE=').decode('utf-8')
    total = value + len(text)
    return total

def _хВФαθΞΔяйδμΝΔ():
    if len('') > 0:
        _dead_2004 = 636
        653
        pass
    value = 784095
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3rqOEIhyLstOQmowmambRB582o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΚУрэπΙΔΜζкРΛкш():
    value = 887275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiTgQmU/7apQayfw/3ySIQ8XyGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νΧУΘΝзΜГφεΚяοКιξ():
    if False and True:
        5
    value = 6198
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxnsbEdu3flVaieE50/DPR074mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 29 < 0:
        493
        119
        pass
    total = value + len(text)
    return total

def _ΩдΩΚηχΔЬщБХИ():
    value = 756799
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnbhZH9swa0yMwCA5VGcBxAW5nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УПΟЙιΨАцΑΨ():
    value = 62072
    text = __import__('base64').b64decode('dXY3RHdhbXY5cU10SzBaRlJMZTc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗБдзэΗρТρВΚφΦТГ():
    value = 4267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HRDhWVkx968sKiChy0PEPSh9wF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1564 = 860
        _dead_7595 = 815
    total = value + len(text)
    if len('') > 0:
        _dead_8563 = 994
    return total

def _ШΚеМγЯΔπΨЪκ():
    if len('') > 0:
        102
        642
    value = 810656
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bx3xT2UTxKQtbjC5mEe3PhJ5zms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        704
        346
        pass
    return total

def _эΣЪИЩЗιгΟηρ():
    value = 516885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3+zVFU63IQyN1aA8lHEFgsu/HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        825
        _dead_7202 = 207
    return total

def _МΗΠидшФФш():
    value = 632203
    text = __import__('base64').b64decode('Vm9NbUpuMlVzeFltRktTdExXaE4=').decode('utf-8')
    total = value + len(text)
    return total

def _γβяШнΘρВπγЦ():
    value = 991495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P3eyPwZp8qMyYiSJxVq1Y3wJ4HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪЕОЮζπщВшЯЮЭбТ():
    value = 422624
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix2wO0lp0LkSKSP37VSnIAAf4Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕьφЬЭхдΦЗωε():
    value = 873889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTviWwkN8qtUAFiG0HKRJQR820w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РιγяΑрЖρХΤΕ():
    value = 308415
    if 2 * 22 < 0:
        pass
        _dead_8269 = 633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiCyelss6q8uGwKTzVyUGxYnzWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2369 = 784
    total = value + len(text)
    return total

def _υΡΘΡςИРШЩшΑЬ():
    value = 564675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwjybUgq5rsMPV+A43WcLDMjy18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 25 < 0:
        947
    total = value + len(text)
    return total

def _γΚСаΝεХячцеΟ():
    if 50 * 80 < 0:
        498
        869
    value = 840845
    text = __import__('base64').b64decode('RUpEanNEZWJvbXNNNk44Z3VlRXY=').decode('utf-8')
    total = value + len(text)
    if 65 * 89 < 0:
        _dead_9362 = 375
        785
    return total

def _зМψСфЯιυНсхΩδΓ():
    value = 773851
    text = __import__('base64').b64decode('Smo3bTFkYTNLRlpKcHVLcVJtSkI=').decode('utf-8')
    if 27 * 22 < 0:
        460
    total = value + len(text)
    return total

def _φγБьЕлλμ():
    value = 942941
    text = __import__('base64').b64decode('blJObUI1cHVRNkhIXzlWUW9ndEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒшγχΛФζΥА():
    value = 455915
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiPCWQEK964nCjea0AO4EHcG9D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΧЖщЭлΨφсΒТ():
    value = 438622
    if len('') > 0:
        pass
        pass
        _dead_6435 = 652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhC1dmcYr/pQKFiP+0WCHHwi6lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πχХЪтнваεжΟοВΓЮд():
    value = 608070
    if len('') > 0:
        _dead_3689 = 340
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDftYlMt1rwpCRuL5wC/GAo+wT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 18 < 0:
        344
        pass
    return total

def _цρθΛθΗОψ():
    value = 998588
    text = __import__('base64').b64decode('SjV0b2hCVUREd1AxSHJLRjZfcE0=').decode('utf-8')
    total = value + len(text)
    return total

def _фзБкЬЦΟγЬΥΞ():
    value = 400481
    text = __import__('base64').b64decode('VTV4dDRnM0k1YlgwUVR6OTBscmM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _аЕжцιШтΒγΠ():
    value = 442748
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhzcY24sz78UBQWcnUTBZyk9yEY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мПДΠΦЕгЫ():
    value = 581037
    text = __import__('base64').b64decode('eFIzbjU4UmxRaE1jSUtUX1RGTVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ъэδДЦΥлйЭхΔэΙьΞ():
    value = 943758
    if len('') > 0:
        441
        _dead_5221 = 844
    text = __import__('base64').b64decode('TDloRkFNcTNYOTl1Qk9oOFpCeng=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_7624 = 710
        774
    total = value + len(text)
    return total

def _шсςФдΡШдЫзГΥ():
    value = 799078
    if len('') > 0:
        610
        pass
    text = __import__('base64').b64decode('cjlHUUdObzhrMnRNWjhhdG9XNE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫемвХЬνфОεкяЩхΣ():
    value = 922366
    text = __import__('base64').b64decode('TVVkX0Z5Yk5lNUE2MWgzRVNvMG4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_2532 = 323
    return total

def _яСπсГЩιЪЮЖζφΞПΤ():
    value = 457268
    text = __import__('base64').b64decode('a2dvOTNEZGRteGNJQWRQZ05PNEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ТιрΕδПγχβ():
    value = 656273
    text = __import__('base64').b64decode('UVYwYm5ScUpHdzg0eG54SDFCYzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ефΥЙЪВсΘλτт():
    value = 25432
    text = __import__('base64').b64decode('b1JPTXlodDlPWWxNSTg3TFBGTDM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤЯзяφГΝвюΞΕυуфΒβ():
    value = 385178
    if len('') > 0:
        898
    text = __import__('base64').b64decode('cXFJdWtEY3RvR21ocFpxWjJrVm4=').decode('utf-8')
    if 93 * 46 < 0:
        _dead_9652 = 870
        pass
    total = value + len(text)
    return total

def _чΣГэΒΩΔИ():
    value = 93955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDb0QmEs7oMwYiSk7QfEbTQWyVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сσьГВиφйπφρβсеΓ():
    value = 361465
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NH3lR34szq4ENSWX/QCTAQsasjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΙлΖвфΡφΕЮЖДи():
    value = 947364
    text = __import__('base64').b64decode('Zjl5bXNfc2x6d1E0bERTdkZSV00=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3196 = 477
    return total

def _ΞФψплψφТъзн():
    value = 232255
    text = __import__('base64').b64decode('VENTdXZyZG5aZ3BUMjBObjg2WVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _γатьфΓκЭаβΩгсПωΜ():
    value = 314584
    text = __import__('base64').b64decode('VzdfRWJzaFdidmtRSkN3TVp6X2I=').decode('utf-8')
    total = value + len(text)
    return total

def _дΔИΤΡεМЕΦмΙКЙτ():
    value = 12822
    if 65 * 89 < 0:
        _dead_9892 = 928
        _dead_1286 = 318
    text = __import__('base64').b64decode('TURhMXpjR1hUSmIyMDQ3TGVwYU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚлпОΠрγθзσха():
    if 99 * 51 < 0:
        243
    value = 588882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDvzYHgs/LswHhvwmUKZOhd84Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠХΧΗΩЭАМБЩн():
    value = 727814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQXuRFsA1fk1HDuGwniqYHc47U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5836 = 254
        161
        pass
    total = value + len(text)
    if False and True:
        133
    return total

def _ЖσщъхШγΚюбΜЕку():
    value = 950988
    text = __import__('base64').b64decode('S3dtamVGWkcxN0E0NW5qTUdUWE0=').decode('utf-8')
    total = value + len(text)
    return total

def _βЯξчютЙцΣЪыΚв():
    value = 95780
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBXJXno88osLFCi66wGeEHwr6Tg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ЖΘБИСщЭЗШ():
    value = 270425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHnKe3Bvy58hFl6c4H2JEw869mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟкΛμнуЧΩΧΤИο():
    if False and True:
        pass
        _dead_6992 = 849
    value = 595640
    text = __import__('base64').b64decode('YURfOElaNUhieFVvQTBOT2dzS3I=').decode('utf-8')
    total = value + len(text)
    return total

def _гфнвдеφΤзиοΥуКΡ():
    value = 21119
    text = __import__('base64').b64decode('YTBOMElXQnNrclVoRWdjckY5WlE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1729 = 295
        624
    return total

def _лςРΟъИμηВоТχΥЗξ():
    value = 431893
    text = __import__('base64').b64decode('b2xOWkpySnRIX3liX2E4M0dEbWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΓуΖΝΦΗΧ():
    value = 702632
    text = __import__('base64').b64decode('UzY2UWM2NTVqU0VGdzVha0VUNVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤютУгρΓκΡьρК():
    value = 473520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PHvIVmRgx64bPh2nwgCBJxYD4k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1624 = 603
        _dead_1823 = 338
        808
    return total

def _ΧρОΖβОΧΩαевβΝθцσ():
    if False and True:
        89
        pass
    value = 432770
    if False and True:
        311
    text = __import__('base64').b64decode('bXNZUzlSY3hiT3Y0c29Xc1h0YzY=').decode('utf-8')
    if False and True:
        450
        155
    total = value + len(text)
    return total

def _ΩбБΡΥΑтЦУАу():
    value = 192760
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ch30W2Ms27gkNgaGw1mVAXc23Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_5140 = 937
        _dead_6669 = 896
    total = value + len(text)
    return total

def _ЫθъΖдΨсЯу():
    value = 391936
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyjQXkcv5pwpbweQ+ny+Zh0u7Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВφхΡΓλъЙюНΒΞй():
    value = 743464
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiXFPVxh2rxaLyGlwVKhNxAg8GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УрИτσωфяТ():
    value = 78033
    text = __import__('base64').b64decode('UUlZcGpLQTBGemFUaUhyeklUU0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑЯΧαΚиЩΧМе():
    value = 522179
    text = __import__('base64').b64decode('eEZocTByMks4bFJoTDhpbjBNdjU=').decode('utf-8')
    total = value + len(text)
    return total

def _шιπгΗΣгй():
    value = 533837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K3rGNlwN7P9bESmr91PCHhcm5Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тЛВΒΖЫшγ():
    value = 590489
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix6wW0ltyboKHRa0mlK6GCAdz3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эоΒЪπыλСмиΝжсВН():
    value = 20747
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRm2X18626QBHgeZ2gWvBQAE8n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8715 = 185
    total = value + len(text)
    return total

def _δИлσωЫβЫлπТτБТУη():
    value = 588198
    text = __import__('base64').b64decode('S1M1WnZvMUNVWlhzZElIbzJ5UHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥεПυлςψοЮиГс():
    value = 290101
    if len('') > 0:
        _dead_6952 = 170
        _dead_5836 = 89
        _dead_8156 = 26
    text = __import__('base64').b64decode('b0s0RkFtY1B4T1lIZDhocDlpUkg=').decode('utf-8')
    total = value + len(text)
    return total

def _οθΞшИкубжАφЗΤх():
    if 65 * 38 < 0:
        pass
        pass
        54
    value = 953914
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyG2fQY42poLOx+l0AaBFTYWzV0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6484 = 499
        _dead_2440 = 122
        pass
    total = value + len(text)
    return total

def _ЧΛΡηСЛКΦεЯ():
    value = 749547
    text = __import__('base64').b64decode('cWc5Y2RTdTVBcE9fN1NKeFNYUFo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        15
    return total

def _τмИмΜΧτРаτХςэОбФ():
    value = 212562
    if False and True:
        pass
        782
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzrtQAMGyPASGTqZy26pJR079XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нРζАΖЩКασПΗнδλйι():
    value = 695446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgvoSWUV0Y0HLFz7mmeFEjIC50s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гдΤъЫΜΜТпςЩσ():
    if len('') > 0:
        pass
        _dead_8308 = 722
        pass
    value = 285329
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiXXUUsJprAoHCeG53CxJXQttHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _сЦΠθωεЕЫτаΓ():
    value = 375734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mg3uQkUJ0Z5TL1+u2FiYPCge60E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КвνφσπГπΧтρ():
    value = 729859
    if 16 * 3 < 0:
        pass
        pass
        _dead_8791 = 442
    text = __import__('base64').b64decode('dG1vYTZsOWoxWTE5cEJOVTNkem0=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_7910 = 101
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _вςμфΨЗφγΩλΕДстХМ():
    value = 160180
    text = __import__('base64').b64decode('cXE5NHBGUGR6NkN2RDVmZjNsNkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗηОЭУНγтθ():
    value = 460862
    text = __import__('base64').b64decode('eElQVDZzQWtJWV92Sk1zM0NGNXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔδΖрвαАиЫпО():
    value = 721791
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAP+a3Qu6pwSAz/z4VKVHXUj838='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еαγβьΡъЗяК():
    value = 255177
    text = __import__('base64').b64decode('RERHNms0ODFveXdJZ0FBN0F2aHE=').decode('utf-8')
    total = value + len(text)
    return total

def _яΥФЯτРβчΦззψиз():
    value = 926731
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwbNXFIaxIIZH1uU+wWYOAs1sXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςτвсууεЫБνЗ():
    value = 269602
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQrNXFVg9aIEEzD18XCWJDcb0VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔбЪΙχьερθφЯηΗтΖ():
    value = 488384
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JB3CX3k+x64hYiew22GcJzE3s1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3910 = 886
        _dead_7917 = 208
        16
    return total

def _хΦцРЖоывβωпτКДВЧ():
    value = 141068
    text = __import__('base64').b64decode('dGIwUUtuUzd0cFp1OHNNSDlENU8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        588
        _dead_2280 = 140
        _dead_9908 = 165
    return total

def _ΠΦΨЕюΟгθцξЙ():
    value = 258197
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCz+bGk6r447BRaT6l2JPnB/tmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1191 = 454
        pass
        512
    total = value + len(text)
    return total

def _НОяςччνφц():
    value = 953283
    text = __import__('base64').b64decode('cjRtb3lwMVNMNm93MWRRc0ZfZ3o=').decode('utf-8')
    total = value + len(text)
    return total

def _ФББсΥаνΦЪМψлαβρ():
    value = 441270
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az70S1Mqy7sOah2r7ALFIycKymM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μωюγΜΔΛΔД():
    value = 291849
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRiyfmMW0f4GGFy03mG8MSoQwUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θОжцЧΚгууΙ():
    value = 819779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxnmVHkA84QQADeXmGW7Nw8kx3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        388
        564
        _dead_7660 = 896
    total = value + len(text)
    if False and True:
        pass
    return total

def _ъаБщοШЮЪкЧσтЦπдΑ():
    if False and True:
        pass
        _dead_2019 = 268
    value = 252342
    if len('') > 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DB/oXVQBr44tCBimyV+xYB8Oz2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_5143 = 514
    return total

def _ЮωЖБΔνъЫςο():
    value = 452226
    text = __import__('base64').b64decode('aTdxdXB6OEJnNVk1RDczY2EyRmE=').decode('utf-8')
    total = value + len(text)
    return total

def _уЮΦЬвпиЪεЧмΘиΥю():
    value = 467174
    text = __import__('base64').b64decode('Uk5Ca1UyNGpHWnZQS2ZMTXA5S04=').decode('utf-8')
    total = value + len(text)
    return total

def _МΩωιчΝШяωэβфжвΟЭ():
    if 34 * 38 < 0:
        pass
    value = 200721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxzsRFoBq7otHFeikUWaMyYbtEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηηΖΦЧтгрУюУΗнΙ():
    value = 743970
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx61YUAh1qZTEwCznWmGYjcn1Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪТуурπΩΔ():
    value = 83295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwnuUVwXzYsQIgmcxkylbS417Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 96 * 73 < 0:
        667
        pass
        pass
    return total

def _ГШΘцχмшζ():
    value = 845263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRrrakQhxqwkLhWlxHSnMhF9tTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жКανΘБΩζΩ():
    value = 612410
    text = __import__('base64').b64decode('SXBxbFZGZk0xOXIxX3hwVXc5aTE=').decode('utf-8')
    total = value + len(text)
    return total

def _зФфμΠΨоБЖЮ():
    value = 353431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBy3TUIe+6sMM1m2zlyWBHMY7EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φШΗдЩΟωΡΧйХИζь():
    if 19 * 32 < 0:
        pass
        pass
        947
    value = 78068
    text = __import__('base64').b64decode('R2hrbkRaVmVjemNxc0VCU09vbWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ИРПΑρиΩТюνйСНеЪА():
    value = 761936
    text = __import__('base64').b64decode('dzlBWWI3RDFZem45SmMxN083RzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣκрФεΧΙШлξΓζηбц():
    value = 758861
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRvNS0kP/JJXLgKs2FmJbRMqx18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪζФπЪйθτэррЫЬы():
    if 28 * 69 < 0:
        pass
        pass
        pass
    value = 964786
    text = __import__('base64').b64decode('TXVjTDI4YU5lM3Z5MTZKRzRMRV8=').decode('utf-8')
    total = value + len(text)
    return total

def _кфШЯπκЭβИΛαжΕЯ():
    value = 919157
    text = __import__('base64').b64decode('a2ZCYU11T09LR3BHZjlCX2g1azQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΥжьΚпλΑЖжΛоПШξО():
    value = 859395
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAfNQEkW9JdRPDea3l7BGC8C20g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑДЬΚШЬΒπяПΝυ():
    value = 102316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ci3WaFBs0aoXOTawmwWBNQIm6lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΑшΖπьйф():
    value = 959524
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTjOPWIW6YwuMRes+GCELAQg9js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧζАνΖνзΕυЗχΨЫщ():
    value = 819444
    text = __import__('base64').b64decode('T09pT096SzNpMlcwSkhIdmpGd3I=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_2239 = 432
        pass
    total = value + len(text)
    return total

def _аμΔΩΚχблыΨμ():
    value = 153244
    if len('') > 0:
        406
    text = __import__('base64').b64decode('bU5mNzBfZXUyQWVzcjJ3dXE0b24=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3722 = 462
        _dead_8930 = 399
        828
    return total

def _ПηΛΗксЦт():
    value = 846610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSDRNlIW24osOQCE8gCSMQB+00I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΟΗУΩεθΨАщΙσφэЙ():
    value = 339315
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PT61R0IazJ0mBVaN/UWjEioA1F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3048 = 101
        _dead_4597 = 244
    return total

def _ηφСδρρЧрмдцыρЛЭ():
    value = 314043
    text = __import__('base64').b64decode('Sm85bDZLQ0dqNnA4NTl5V0U1bWY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5197 = 55
        pass
        pass
    return total

def _гΧοЫΝЙСйЭьΡЧΟЗβ():
    value = 893260
    text = __import__('base64').b64decode('dUhhWjdyUDFZUkNaU2dqa2N1MHg=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        328
        977
        pass
    return total

def _ФНпΠΡαΤшΧУπ():
    value = 464693
    text = __import__('base64').b64decode('dFFNUl90VU5mdm9kd2lkRmZhTnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ГκσΓγΠΝЦχПηйΣ():
    value = 823654
    if 74 * 36 < 0:
        pass
        527
        987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnjdVwEfq6sGPgqCw3yXHTM9tj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 48 * 94 < 0:
        pass
        _dead_1678 = 537
        _dead_3100 = 715
    return total

def _ГЕκΧяХοκЙαкЫςЕ():
    if 29 * 56 < 0:
        7
    value = 876437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnfwfX4Dqo8GPz/yzQeYGxEDyFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъЪσπβΔΑвΕЫ():
    value = 885953
    text = __import__('base64').b64decode('bTNkSFVZTFJWbmZaWDVXdmRkd0c=').decode('utf-8')
    total = value + len(text)
    return total

def _ьΛηξΖъИуζЕЦрхй():
    if 86 * 18 < 0:
        pass
    value = 967721
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3zGSmhg5pICLwGlykyCNSkM6m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        725
    total = value + len(text)
    if len('') > 0:
        302
        223
        638
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()