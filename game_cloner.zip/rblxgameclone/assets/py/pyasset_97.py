#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ЛΜφΜЫδмшМφСО():
    if 17 * 15 < 0:
        pass
    value = 618921
    if False and True:
        938
    text = __import__('base64').b64decode('RXdwWktHcGxfb0MyaG50Ym1kS3I=').decode('utf-8')
    total = value + len(text)
    return total

def _лЕεЭбΜμфнФцΦ():
    if False and True:
        764
        833
    value = 71335
    text = __import__('base64').b64decode('cEZQSFB1SjdYYjRibzEyMG44VVk=').decode('utf-8')
    total = value + len(text)
    return total

def _ВηяЩβΧдцΩΕЩΥεζ():
    value = 312111
    text = __import__('base64').b64decode('QjBTZU4ydGZYNDljb1hZX3VzaTg=').decode('utf-8')
    total = value + len(text)
    return total

def _чΟрбзχВθЦΥъδ():
    value = 169756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiT8a3AXzLIvDQu1m2SFBAYe/GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уДοαгУьЫΛΦщРЗЧξΟ():
    value = 471078
    if len('') > 0:
        548
        _dead_7016 = 480
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgbndwZsp68maAmQkF+XBzB8x1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 63 * 31 < 0:
        _dead_2072 = 828
        pass
        _dead_5287 = 887
    total = value + len(text)
    return total

def _ФЧяΕγГрНдйПβΛΙут():
    value = 532850
    text = __import__('base64').b64decode('d2ZxV2Mwa3hDSVFqNVNqVlVzT3I=').decode('utf-8')
    total = value + len(text)
    if False and True:
        276
    return total

def _иθΞЙρгхяь():
    if False and True:
        pass
        626
    value = 973969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD/1ZHRs1YEFNSGN8Q7FGiE+3l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВειеаΘаΛ():
    value = 347247
    if 10 * 99 < 0:
        _dead_3125 = 223
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxbveVMj0LgtFQ2E0H7IHHB+xU8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГиЖΝюфсъэΗΞО():
    value = 765751
    if len('') > 0:
        44
    text = __import__('base64').b64decode('TzVnQ1M3NENXYk1lb2psNkNBd28=').decode('utf-8')
    total = value + len(text)
    return total

def _ρпФψΗΟΚπЬдΨΤ():
    value = 308851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex7rR2lv9K4VCRmh4UG3BiR6snw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оШиΗДсΗτΣнΝкφΞΡ():
    value = 169449
    text = __import__('base64').b64decode('bTJwbmFoZXJ0RkVlRE9XR3l3Y3A=').decode('utf-8')
    total = value + len(text)
    return total

def _юйςζюВεПυλ():
    value = 212275
    text = __import__('base64').b64decode('bGZSZUJBbUxpM0J1Z0xDYlo2OHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕъсхλТДα():
    if False and True:
        110
        _dead_6999 = 977
    value = 706366
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDjIWUgLxrosHQOQ0EC3AgQ+tVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ββΚετнШτсЧ():
    value = 237396
    text = __import__('base64').b64decode('dmFocThTdU52WnA1WVl4TjMyajY=').decode('utf-8')
    if 19 * 12 < 0:
        957
        _dead_2334 = 777
        pass
    total = value + len(text)
    return total

def _ТЭХιςΥΛчбЦКΚ():
    value = 270958
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fgj1NlAaqosqIj6UxX6GBjcD8WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λТφФΠщηЧι():
    if len('') > 0:
        342
        _dead_3410 = 886
        38
    value = 296396
    text = __import__('base64').b64decode('cUxmem9xYU84VEp0eXREVzMzY3Q=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3500 = 959
    return total

def _μΒΓχюΘΩαуМΣсЬСъ():
    value = 533005
    if False and True:
        941
        177
    text = __import__('base64').b64decode('WDdYMHpfdHNRQjVUdEh3Z0k3cFo=').decode('utf-8')
    total = value + len(text)
    return total

def _роДεмЦУРПυ():
    value = 151392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQDQb3wJ3K1UOzz0nX6oPXc+4j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕФЦξбΛеЩρφвα():
    value = 487666
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Inn+b0A/5IJWFj6v8QWlOD8nyU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 2 * 4 < 0:
        pass
    return total

def _ΨДψНчηЛкλяутЗгЙ():
    value = 55008
    text = __import__('base64').b64decode('S2x1aGl0ODZ4aVJtYkxld2VyVkc=').decode('utf-8')
    total = value + len(text)
    return total

def _вПЧυоδΖХ():
    value = 711550
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISvvPX0q9aMEHTWw8nGpFgMex2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯωппфниюνБΗРЩΤΜо():
    if False and True:
        _dead_7609 = 553
        _dead_4423 = 135
    value = 366104
    text = __import__('base64').b64decode('bzdFV01mT3RVSE82TzVaYkJpdFo=').decode('utf-8')
    total = value + len(text)
    return total

def _ъθхΛσэΟλΨМшΝйкХΒ():
    if 18 * 42 < 0:
        _dead_3705 = 842
    value = 595054
    text = __import__('base64').b64decode('cWZBOXRrMElXWHVob2Q2X1Zua3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠξςпψсΡΚЦ():
    if False and True:
        867
    value = 761570
    text = __import__('base64').b64decode('bUJua0tnN1AyOWxySkNBcUw3UDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝζВτТφгчша():
    value = 842396
    text = __import__('base64').b64decode('aFJWdXN1eGdWZF9Nb1UxdVk2SEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _дфΗоΠцгбз():
    value = 153853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwTxel4s6rAJNw2kkWKbYR8V23g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΗгГДτЯУφΕб():
    value = 684316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mx/1Q3YsroszAzqS7kOnEwA/w2k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тνБΥЭнЦйςРΛсвτΖε():
    if 54 * 93 < 0:
        pass
    value = 546498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR7KbHQh1IImLlut2V7HbAEezz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 26 * 17 < 0:
        _dead_6838 = 90
        _dead_4531 = 763
    return total

def _ΘъъπΕшъТΖοдСС():
    value = 314365
    text = __import__('base64').b64decode('bE9Cdk9aaHZWV1hQUFYwMlIxR18=').decode('utf-8')
    total = value + len(text)
    return total

def _шπηυрЙзωЦмξ():
    value = 764938
    if 4 * 82 < 0:
        288
        922
        pass
    text = __import__('base64').b64decode('ZTlUOXFtalFfNW9CU0pEczFOblA=').decode('utf-8')
    total = value + len(text)
    return total

def _οясηтгДъЮЬΚемΙσ():
    value = 191496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhrzP2UdxKlTFiuXmHqlHRAGzUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аυаμαыαωЗζы():
    value = 558609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fwb1V2Id9qJTAl37yXCTAwcF10o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒНемυΕςНζΖΡρ():
    if 99 * 17 < 0:
        310
        297
        194
    value = 116672
    if False and True:
        _dead_7042 = 380
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhf+WHw6548sazC731ORNXMsyXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥвςπЖЪΟСΙΠМ():
    value = 464588
    text = __import__('base64').b64decode('T3BxUWhIN1d1dFhrZ3NBVmQyM2w=').decode('utf-8')
    total = value + len(text)
    return total

def _αПμрτаьΙ():
    value = 903634
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzzlYkU/8f0EAyv6xQGZEQs+7E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝφНπΑтΝЯ():
    value = 108261
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AB23XnBhwYBXEjyr51+SbSYWykM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЧξРУΣΩуυ():
    value = 844892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ih7RSkM4x7wiDD6mzH7FYRE54Hw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τмКйΔκеτμЦαΠьпА():
    value = 429872
    if False and True:
        _dead_1012 = 332
        466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhvyRkQj+P0TaACV+mGoOXx9ykw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κДРΘЙуορйΛ():
    value = 616742
    text = __import__('base64').b64decode('YWdGRGpVWW9oV3E4dFd1WFBPRGk=').decode('utf-8')
    total = value + len(text)
    return total

def _λюеΡΨφηΦγΗΛДΩмжВ():
    value = 855072
    text = __import__('base64').b64decode('THVNejRIbzd5TE9VbnhkQnlrNmo=').decode('utf-8')
    total = value + len(text)
    return total

def _НξХмаЩСπЛοЫг():
    value = 14539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBzmZn0/1PwNHR2F5USKYHwY/GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6472 = 442
    return total

def _ДЕбЕΓТεЖмФазοиςВ():
    value = 232219
    if len('') > 0:
        537
        169
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXvyW35q8Jk6PT6k4W/HNSAB1Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МшηтΑτрМп():
    value = 478032
    text = __import__('base64').b64decode('UkgxUkhEVlVMd1VWNWpjakRJdGE=').decode('utf-8')
    if 4 * 5 < 0:
        _dead_7946 = 382
        _dead_6647 = 496
    total = value + len(text)
    if 47 * 68 < 0:
        609
    return total

def _ЫБπΩъΟωφЬхΝΤΤιЪи():
    value = 684360
    if False and True:
        _dead_4518 = 3
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzzRRUQbzoMqbDz18VTDbXQJ3kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 33 * 51 < 0:
        _dead_8276 = 795
        73
        pass
    total = value + len(text)
    return total

def _ЬζΡбμηΩκЧ():
    value = 38550
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExnwOGgO+74hAhWP2nWTFycXyko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜкΓβΠΥЙΡωЭγλтГЬ():
    value = 139840
    if False and True:
        pass
        719
    text = __import__('base64').b64decode('dFV2ZlVoT1Z4YllVdk9RYWQycFQ=').decode('utf-8')
    if False and True:
        _dead_2417 = 304
        _dead_3946 = 1000
        _dead_8863 = 435
    total = value + len(text)
    return total

def _ЙΩΥΗЛΡТбΦФБηШэЪ():
    value = 271537
    text = __import__('base64').b64decode('UlA1Zng4eGJrX1oybjM0VVRTZ2I=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        481
        pass
        _dead_7871 = 28
    return total

def _мШиЦъшхθФЫΑКλ():
    value = 519142
    text = __import__('base64').b64decode('V0pSY2dJc0IxVzNJZkRORFNKcjk=').decode('utf-8')
    total = value + len(text)
    return total

def _βκκЮзχмОΤ():
    value = 517509
    text = __import__('base64').b64decode('S2hqU3dlZ2hmdFpXaWxNRlB5bHY=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _сиумюяΨыθякΒΜσ():
    value = 425158
    text = __import__('base64').b64decode('TExYME50Mk1TWk1tWmtOSExkSHE=').decode('utf-8')
    total = value + len(text)
    return total

def _АКЖΧРΛизΧκнЬЯΣ():
    value = 576122
    text = __import__('base64').b64decode('QVZtU3A3MFBPSTNtZ1dQbWdQcVo=').decode('utf-8')
    total = value + len(text)
    if 9 * 52 < 0:
        _dead_4956 = 685
    return total

def _БцΦвЩпЪГΙЪуΞкΛ():
    value = 51706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhXHawExrpoWI1un8AO0Eh04tEk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_2175 = 198
    total = value + len(text)
    return total

def _юйθХΑяγτΒфлτΑΞЙΧ():
    value = 126011
    if 34 * 67 < 0:
        _dead_4817 = 697
        _dead_7318 = 391
        _dead_4185 = 470
    text = __import__('base64').b64decode('cVdkblBkeGNDUzdvMGx4WFBwUFI=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3326 = 306
        _dead_5160 = 941
    return total

def _иЮХЯΦТеΔКЕтл():
    value = 434508
    text = __import__('base64').b64decode('T1NCVnJfd2xGZ2U5cnJOX3AxQmg=').decode('utf-8')
    total = value + len(text)
    return total

def _πΓяИБΧΩλЙТχθЖ():
    if len('') > 0:
        _dead_1212 = 88
        392
        _dead_9294 = 427
    value = 64501
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCbjVFI01qwWbgOW+HibYzd/92s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эфсдъвΚбΚ():
    value = 233044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwaxdHgR8v82Hz/y90HHYA09vH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕЙιΨγОμτЫ():
    if False and True:
        623
    value = 722718
    text = __import__('base64').b64decode('aWZxS0N2ZV9RMURjSGhEWkhyRGQ=').decode('utf-8')
    if 97 * 84 < 0:
        226
    total = value + len(text)
    if False and True:
        481
    return total

def _ιоыйαДОГБъВ():
    value = 621855
    if False and True:
        _dead_5387 = 173
        pass
        _dead_3170 = 421
    text = __import__('base64').b64decode('bXpfTl9UdXFBeVIyMk9QYVVCOG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ψеАΘДσКпзд():
    value = 180731
    if 65 * 9 < 0:
        pass
    text = __import__('base64').b64decode('Vk1sUEVBMlA1V0F5SGRBWkdydGM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ЙмΨПЦммМХχ():
    value = 525715
    text = __import__('base64').b64decode('WDhuU1hQR3J5dXAxRTI3cU05UHI=').decode('utf-8')
    if len('') > 0:
        _dead_9480 = 576
        _dead_5421 = 347
    total = value + len(text)
    return total

def _вΘλγιοΡВЦВΔΟ():
    if 96 * 98 < 0:
        686
        pass
    value = 925700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACDbQwEerIsKFQCsnASTESI+0Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΡтΓрγΡΕЮИσсЛ():
    value = 803447
    text = __import__('base64').b64decode('Q2dnMFdzclVSa3JwS0w2bG90Mmg=').decode('utf-8')
    total = value + len(text)
    return total

def _СрФЫАбиμ():
    value = 81032
    if len('') > 0:
        234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQr3dwMs7LotaVqz/0+kOxIp3Xw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        196
        _dead_6172 = 232
        pass
    return total

def _θбМψпЗЦΘςυ():
    if False and True:
        _dead_5824 = 605
        _dead_9115 = 357
    value = 865302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng3GdAUM7v0nbDqLmg+qbB99tls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _НΜΨεРγζПияргжΡΥ():
    if 35 * 32 < 0:
        pass
    value = 974730
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhDpW0Nh6YMuNALwyVK6ETI76GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЕШηθЬТηоΜζЦοΣ():
    value = 143353
    text = __import__('base64').b64decode('SXQ2aXdMOUlwWTdUYkVibmF4UmE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        831
        411
    return total

def _ЛНτТДГηвЮдΓ():
    value = 860722
    text = __import__('base64').b64decode('d0xkclNxRnQwQ0dmWnk2a2NFZ3Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΤθσАзКПΘΥВМбйГΨ():
    value = 976560
    text = __import__('base64').b64decode('bkllV1FZT3ZmMjJHYjc0RDVvVTE=').decode('utf-8')
    if False and True:
        _dead_6304 = 820
        pass
    total = value + len(text)
    return total

def _ОψΛаΨПцΕυτЪЙ():
    value = 381039
    text = __import__('base64').b64decode('aGlDQURsNHF1Tk9vY2pHbUV0VEg=').decode('utf-8')
    total = value + len(text)
    return total

def _δКΘЫЮЙтЙ():
    value = 418374
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBi1VGIpya5UHwq0xmTGNSo35zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υэИγψΜΡиЮйОчιг():
    value = 916725
    text = __import__('base64').b64decode('SE5TMmNVYWV5OG03NGRzZDVUN2I=').decode('utf-8')
    if len('') > 0:
        122
        _dead_1696 = 370
        695
    total = value + len(text)
    return total

def _αωθНΜМρχΤуБУππп():
    if 79 * 58 < 0:
        pass
        _dead_1190 = 265
    value = 832144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATq0aGk8rKYRPiSv90S+LXM47mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_8798 = 598
    return total

def _ΗРΡЭΙΤйΓЛ():
    value = 327440
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSPNeFBvxLFRHRX6wl6JHikDz1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щτΑΛьКЭСκиοюьоφ():
    value = 631040
    text = __import__('base64').b64decode('Y1BpQlZiMzc5MGdGWkZEdTlFZGY=').decode('utf-8')
    total = value + len(text)
    return total

def _дЧΜМψЕРкХδяЮЕъгЭ():
    value = 456539
    text = __import__('base64').b64decode('VkJnOUxBeVpiaXE3Sjd0VTl0WlI=').decode('utf-8')
    if False and True:
        46
        _dead_2911 = 386
    total = value + len(text)
    return total

def _КΣЪЯжфяλ():
    value = 197441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQLTaQQbrpkoGw2EmlOGBA4J3Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жεΟΤЮνβАΔйЬ():
    value = 231703
    text = __import__('base64').b64decode('bTBxZ1luRmNsbWE0NmhyZFByVXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ψвщσкζбуνцδ():
    value = 959985
    text = __import__('base64').b64decode('WWd1MHpLUEZNeG1QUXJTU1FtbV8=').decode('utf-8')
    if len('') > 0:
        184
        pass
        483
    total = value + len(text)
    if len('') > 0:
        _dead_6507 = 983
        _dead_3797 = 161
        990
    return total

def _ПГΛХвжσμθеσΡИαОБ():
    value = 346917
    text = __import__('base64').b64decode('cU9nYlp2ZGdUMmg5OG9SaDZUZTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _яΦейгρΓчИЫГт():
    if False and True:
        pass
        443
    value = 660149
    text = __import__('base64').b64decode('d1V6RWs2U3RnOExwRUprcVNCY3c=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _υΤΡЯΡΔупд():
    value = 569845
    if False and True:
        _dead_5156 = 167
        _dead_2875 = 811
        856
    text = __import__('base64').b64decode('ZTVqYVQxMklCWlZqcjZrb1AxT1M=').decode('utf-8')
    if len('') > 0:
        _dead_5982 = 204
        _dead_9315 = 49
    total = value + len(text)
    return total

def _хεЫωερΕд():
    value = 27059
    text = __import__('base64').b64decode('YVZwd2JmN0ZTMWF1R3RjQWE3ZkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _κиμψаηмДрΞ():
    value = 983589
    text = __import__('base64').b64decode('Y3hkNG1sVk1VQUF1Qld5Zl9Qa0w=').decode('utf-8')
    if 8 * 63 < 0:
        pass
        232
        pass
    total = value + len(text)
    return total

def _ρЗЪСэкОΔΥгΠкГ():
    value = 706438
    text = __import__('base64').b64decode('QWtoeGJxZERaQlU3T280ekZUOW8=').decode('utf-8')
    total = value + len(text)
    return total

def _пοЩйΨИθβщμЮУ():
    value = 742670
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH3OZEAWyYsMLDX73nzIMBUQ3mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вйдляσрωνшΚ():
    value = 263075
    if 10 * 86 < 0:
        977
        _dead_2210 = 23
        _dead_9929 = 216
    text = __import__('base64').b64decode('UlRpVkpTQXY2SFBUSXF5RmpDTHo=').decode('utf-8')
    if len('') > 0:
        _dead_6180 = 134
        pass
    total = value + len(text)
    return total

def _АΑыΜУвяΑςΚДлдл():
    if False and True:
        930
    value = 143093
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('REtUUldKX0RZdGQ3U21uZ0k1anQ=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_7010 = 228
        pass
    total = value + len(text)
    return total

def _чпΛΨΔκцΠяАХζςК():
    value = 634684
    text = __import__('base64').b64decode('TWprX3VuMUEzUExZNGlkUEd0dks=').decode('utf-8')
    total = value + len(text)
    return total

def _АυιаСγАШЧΡнШΒ():
    value = 560777
    text = __import__('base64').b64decode('VFN6ZGZiQ0JaN3NLUEtYc3RmeUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _БοзйλθРЮγУы():
    if False and True:
        475
    value = 229867
    text = __import__('base64').b64decode('VWVQV3cyVXpBajlpc09QQVpFQlA=').decode('utf-8')
    total = value + len(text)
    return total

def _зηВРШяГиШΙщвз():
    value = 285103
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgHPaUYc7ZogICiNnHWfEDB3zkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        448
        _dead_2090 = 464
    total = value + len(text)
    if False and True:
        _dead_7452 = 852
    return total

def _чПъγΟΠБьΦЦк():
    if False and True:
        _dead_8914 = 577
        _dead_2216 = 27
    value = 994797
    text = __import__('base64').b64decode('Z2gyUTZnb25CTV9jQ1lCNk5SQXc=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        945
    total = value + len(text)
    return total

def _МХφΤεΓοδАмГεφ():
    value = 61747
    if False and True:
        _dead_7273 = 325
        671
        538
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aj7df1gt3ZgxNwn30Fe3LCYi6WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θпιЗЩЧлУЫθΑвΚмдБ():
    value = 941236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwrdaGsD9qYqCCGCn3HIHgx73ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЧЕνшнηΙΛНЧλкзш():
    value = 57886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCy9UWgAzoIVNln27E6UYh0W8WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВИФНξΨФΠпяκИΚρВ():
    value = 856021
    text = __import__('base64').b64decode('d0x0TG9NNFdnN19fMWdrSkpKMGM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3560 = 11
    return total

def _хщЯθθУмяэЦ():
    if len('') > 0:
        pass
    value = 984282
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('VEk3T0ZHT1FKWE5xVFdPYml1dlE=').decode('utf-8')
    total = value + len(text)
    if 78 * 81 < 0:
        430
    return total

def _юЪΣФΦтΗо():
    value = 798882
    text = __import__('base64').b64decode('RlZaRGZTNXUzdGJOYkJObGppM2Y=').decode('utf-8')
    total = value + len(text)
    if 73 * 91 < 0:
        pass
        932
        pass
    return total

def _шΧΧπννХхνлΨΦβχн():
    value = 466129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NT3hOkQ07oIsPgTy+1TAG3Q58Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘλшЩβДисфьΨх():
    value = 373470
    if False and True:
        _dead_1389 = 718
        pass
    text = __import__('base64').b64decode('UVpMNHoybXFWSnhGenJQTDJreHo=').decode('utf-8')
    if 37 * 93 < 0:
        pass
        458
    total = value + len(text)
    return total

def _ЙΩιщβяТΖМηγθ():
    value = 351268
    text = __import__('base64').b64decode('eDZvaTJVX0duZmNGZ1lpUVE5NHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ИΟьбΚιТЮсЦКЮнτд():
    value = 544844
    if len('') > 0:
        _dead_1468 = 369
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAuzWFwJ0/8kLj+G73SCPSs20z4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 18 * 93 < 0:
        pass
    total = value + len(text)
    return total

def _ΟЩζθозΥγΙ():
    if len('') > 0:
        _dead_2991 = 604
        _dead_7319 = 270
        _dead_5101 = 555
    value = 204317
    text = __import__('base64').b64decode('a2JwcHdiMEY0SGJUTDhTVnFDREc=').decode('utf-8')
    total = value + len(text)
    return total

def _тУΙИπιΚр():
    value = 3586
    text = __import__('base64').b64decode('TTVZS01EQnUwUmtVNTlfNDRBTTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _οББаазςθΘξпξλвВт():
    value = 438053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXvGd11u8aU6ayGlxESvHCAe5kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _σюПΚζроο():
    value = 141536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHb3Qkge+oosD1vx6nK1ADweyHs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΙуκλЯЙса():
    value = 285399
    if False and True:
        743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn/jbXAdqrg3aCWZ0ACVGXYF8Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 7 * 26 < 0:
        _dead_3626 = 594
    total = value + len(text)
    return total

def _ЛηΒЙПрτχМζτъ():
    value = 92163
    text = __import__('base64').b64decode('VUhqb0NxUFdoaFg2RFVfY1pNcWY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗэяыЧψσζЭΤλаψζΨ():
    value = 777495
    text = __import__('base64').b64decode('SVlmWFY3dnViWTMxa1NGeVBJcXY=').decode('utf-8')
    total = value + len(text)
    return total

def _αЮбΩΛΚЯΔνЛιС():
    if False and True:
        _dead_1719 = 340
        872
        _dead_2391 = 166
    value = 632345
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Aiy2eVcs7PAzIyv27128IigbsGg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        692
    return total

def _лвωθεЖСκИΩВΑπιПε():
    value = 81182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhXKZQEIxLEhPC6N+WHBFgEAwzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚξΒφΨяπЛ():
    value = 525555
    text = __import__('base64').b64decode('U1I4aXRaTjdodTE3eHdmbWJaVFc=').decode('utf-8')
    total = value + len(text)
    return total

def _УсЛлЙпУГЮь():
    value = 936753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCLOWEsu9f0hYzny636VGA4u1j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НДξФэΚεЫяОνБб():
    value = 610166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxrjPWdq56E1Mwn08l+EMBMG5ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦЕяφЩЖДЕμφν():
    value = 682376
    if 46 * 99 < 0:
        pass
        _dead_9328 = 639
        pass
    text = __import__('base64').b64decode('dHNmR1dCMDFCXzVhRjFUN21mSHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΧпИЮΚβγРпх():
    if len('') > 0:
        _dead_4470 = 437
        95
    value = 175051
    text = __import__('base64').b64decode('TmlqcmR1TVlTdlhJSVdzY3pPb0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ςζζУЦнАыρняб():
    value = 797567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTWxdlAOzIUiEDu5mWOnPgEE6ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔцсΨЫзВиδЖΔск():
    if False and True:
        _dead_1692 = 488
        _dead_8288 = 419
        pass
    value = 23352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjrJRVJp8L4WAC2z4wK2JycXzkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 71 < 0:
        pass
    return total

def _ΡΣΝтθоηУЭ():
    value = 326621
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyvbQWAL5JAuIh6Q/XS6FyYV7Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚβΙшИγзΕЦΝ():
    value = 484946
    text = __import__('base64').b64decode('aTN2aDM2WHM0ZkNnZXBWNUVIYUU=').decode('utf-8')
    total = value + len(text)
    return total

def _вЙΤфξТФцЪςмμнщ():
    value = 910456
    text = __import__('base64').b64decode('RjRPbU83Um80cFV6dWJNZkJ5MDU=').decode('utf-8')
    total = value + len(text)
    return total

def _МъчΘцΝПС():
    if len('') > 0:
        77
        _dead_4297 = 830
    value = 607616
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ3vNgRozpcWYymAw3WxOwkVtlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓοнυИΦчαКЫЮыФшΙ():
    value = 25647
    text = __import__('base64').b64decode('bEF2T1NwTFM4bU1YTE1kWUc3aVk=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ψСΚΗмнΣΘОшфто():
    value = 694838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDf+RENg6bsTPxiikH6VMAAm/jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 37 * 54 < 0:
        26
    total = value + len(text)
    return total

def _чγАκшеεэξьПΩГ():
    value = 285054
    text = __import__('base64').b64decode('UWZKVzJ1ajFEd0UwV09VSFFJUEw=').decode('utf-8')
    total = value + len(text)
    return total

def _шδюБςμΙΥΞμ():
    value = 348500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LC7UXEUrr6MCDB6t/wOyM3V+5lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωэΜрΟОθΥΑмТ():
    if len('') > 0:
        pass
        847
    value = 683608
    text = __import__('base64').b64decode('TWxiajhfT2FGRVRyUmhubmEwbXk=').decode('utf-8')
    total = value + len(text)
    return total

def _БьΦσмτАβюσΔΥ():
    value = 701355
    text = __import__('base64').b64decode('bGNCVnlHVTM1MVJxdV9KYjRqbTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑβъληυγεЫπΒКх():
    value = 628204
    text = __import__('base64').b64decode('eXVvYWZTY3ZtRks1OFZHcERma0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _οМГΥФΙδЗΠΙοжЩТЕ():
    value = 516459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjjba1gu7pIwA13z3nqiNRcK5Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΔΘΡКΖрьОю():
    if len('') > 0:
        pass
    value = 492326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix/yZkgSqZsxaVyR0FGAZxIb9kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΓΛЗГТДХΚεй():
    value = 177076
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxfXOGQ7yrFVMwiCmw65GnAr/WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъЖщгхоβЩУσХКμЭГ():
    value = 998068
    text = __import__('base64').b64decode('eDF3b0ppR0kydXJiUjcyQ2VxMjM=').decode('utf-8')
    total = value + len(text)
    return total

def _χοЖдаРвЛκяЮκ():
    value = 562838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LnrCZAUK55gTFSPx4ADAP3cX4Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗЮθДΝΦΜφыЬмΙгΞΡι():
    value = 84041
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx+xQns3+6Ezbyih4gPBMCQJ9E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юβфзΙфХЦъЖьξΙ():
    if len('') > 0:
        _dead_4668 = 724
        257
    value = 505840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXzjegED75gAMFuz3U6HLn0i0Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _αАΔэΡИаоЬχΛР():
    value = 62144
    text = __import__('base64').b64decode('WEhCaGJ3X2Nfc2c5WWFjSmFvQWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ηεζБΓпЯбηуυ():
    value = 270760
    if 41 * 100 < 0:
        _dead_9228 = 767
        pass
        pass
    text = __import__('base64').b64decode('a1FhNHpWV3U1MWdPVmRiZFJqUTE=').decode('utf-8')
    total = value + len(text)
    if 41 * 95 < 0:
        690
        919
    return total

def _ЛелШеяКζκξцο():
    value = 15738
    text = __import__('base64').b64decode('akp1cHZ5cG41V29fMktJbkpzSzg=').decode('utf-8')
    total = value + len(text)
    if 12 * 22 < 0:
        _dead_7326 = 711
        _dead_8288 = 218
        _dead_1073 = 584
    return total

def _ΔдАξεσКжЦш():
    value = 400941
    text = __import__('base64').b64decode('UHk5Q3IzZHBjMjlFajhFQnA3VmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟаψηкбУр():
    value = 899371
    if 83 * 17 < 0:
        pass
        _dead_6975 = 916
        _dead_5096 = 86
    text = __import__('base64').b64decode('TG4zZWhkZmk1SVBwMEtCRHBxU1I=').decode('utf-8')
    if False and True:
        _dead_8719 = 438
        pass
        pass
    total = value + len(text)
    return total

def _υτΥлФυуУн():
    value = 415192
    if False and True:
        _dead_9832 = 15
        976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HT/tQVgK7asHL1+mkXCpIAkfzFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъТΔьψψΞь():
    value = 666106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwjtQFYz8LwPYgiG+gW+GAsq3jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξπЭεΥМΠы():
    value = 552252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQnKbQE0qLFQICbxzWKpPDQOzEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΜθКπяаШНΗеζХΡ():
    value = 783268
    text = __import__('base64').b64decode('eFlQbVZYZVMzZ3BtdEVzQ0s5ZTE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙсΟΚξГеΜωыоТ():
    value = 887013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ITrUTH4R2LovIhannGW0PCIXxjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        88
        584
        pass
    total = value + len(text)
    return total

def _тιΜЯАИеβщΥНлΡм():
    value = 345058
    text = __import__('base64').b64decode('cnlhTmEwekVLU3Z0Qnp3YzNGc20=').decode('utf-8')
    total = value + len(text)
    return total

def _ФυΟъΩжτНφЭЭпвС():
    value = 693880
    text = __import__('base64').b64decode('cnNJRV9UTXRZU2Z4UjBsTHlXQ0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ФГнΠηюЭРлоБΔ():
    value = 663684
    text = __import__('base64').b64decode('ckt3c3RFaXh4SXkzelM3TFk4RV8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕАεΤоΡвПιιйрΝю():
    value = 576115
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiLAQ1BqzaoZGVeC4g7IJQZ7z0Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1121 = 713
        367
    return total

def _κΑμΘΓрακЪδВЦΛЭ():
    value = 425100
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MijPNm4f5/ATFT6G/AOjIC4YvV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥРФеκмχЕ():
    if len('') > 0:
        pass
        _dead_4076 = 890
        858
    value = 696184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCb2QlQh/b8LLCuL7WLABAQesF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΩΗΣζΠΟςдНιΘΚ():
    if False and True:
        pass
        715
        pass
    value = 680469
    if len('') > 0:
        _dead_9128 = 908
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTbXOmEY+f0kFCmM2n2TGzcgzlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чδΩтЛΒΩλУуГФ():
    value = 352882
    text = __import__('base64').b64decode('SUFtXzllMU1mUkhzOWtMUTFxa3c=').decode('utf-8')
    total = value + len(text)
    return total

def _фΑЯΗЙсσωΗξ():
    if 29 * 30 < 0:
        pass
    value = 113485
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxfGOEs4qJctG1eR6kPCAnV35jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζТζймчΑКъЯΣΨ():
    value = 376384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQ3ISl0uy5srDw2KzwSEGD0rsl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЦвΘЕМΞЙэАсзвιΦΜ():
    value = 796993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3uyOX0+36w1Cji6mkyIBBEc5Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕтρλΚγφπкьΚуρХ():
    value = 812880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDv8bXM66YYFAwmm7VHCPSwdskM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6746 = 708
    total = value + len(text)
    return total

def _ТΔИψхвлЙИσΠЯεЪ():
    value = 139210
    if len('') > 0:
        _dead_1978 = 193
        _dead_6599 = 983
    text = __import__('base64').b64decode('a3Y3bGVfOVZyWlBmMXp0SzNYSkM=').decode('utf-8')
    if 5 * 22 < 0:
        _dead_9926 = 480
        547
    total = value + len(text)
    return total

def _ЮюдρВцνГИχΛаЯ():
    value = 104171
    text = __import__('base64').b64decode('VFFBaG5CZjBkSXBsQ0tUTkJrMkk=').decode('utf-8')
    total = value + len(text)
    return total

def _υЧςДΤДΡЮюЫсю():
    value = 198274
    if 73 * 62 < 0:
        _dead_9359 = 996
        _dead_6201 = 414
        _dead_6074 = 913
    text = __import__('base64').b64decode('Rzd1ak9uRlRkcWVobUhtVkNKTkg=').decode('utf-8')
    if 66 * 92 < 0:
        _dead_5236 = 258
        _dead_9238 = 289
        pass
    total = value + len(text)
    return total

def _МиДΘНаορτеЗ():
    if 56 * 92 < 0:
        _dead_5065 = 954
        pass
        514
    value = 35730
    if 69 * 50 < 0:
        pass
        _dead_6556 = 387
        338
    text = __import__('base64').b64decode('aXBwVXdPMU9SZGNLOFhrTzdybzg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_7928 = 463
        _dead_4500 = 178
        _dead_6555 = 451
    return total

def _υφФЗпΦωΦТΤθЫθюзъ():
    value = 126714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDjQfFUYpvsTEljz2w/ELS0b/mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧπЮΕΤψΚЕ():
    value = 817581
    text = __import__('base64').b64decode('Rk9kc0NXV3BIUkl6dW4zMEYyUGk=').decode('utf-8')
    if False and True:
        _dead_1193 = 603
    total = value + len(text)
    return total

def _οуСΖЕχям():
    value = 986916
    text = __import__('base64').b64decode('aGMwVGhsMTBGQk43OGRQa0ZrQlM=').decode('utf-8')
    total = value + len(text)
    return total

def _хПΦαлΛЫγεАХПОЫΦ():
    value = 788074
    text = __import__('base64').b64decode('SnVSSERfaUpERmdtQ0tWUVJaWXE=').decode('utf-8')
    if len('') > 0:
        122
        _dead_2427 = 297
    total = value + len(text)
    if len('') > 0:
        730
        pass
        798
    return total

def _τλΔрχюЮщ():
    value = 741192
    text = __import__('base64').b64decode('V0lWY0tsZXhhOHVJM0UxOVF6Nm8=').decode('utf-8')
    if 3 * 83 < 0:
        _dead_7165 = 720
    total = value + len(text)
    return total

def _ГΗмθтεъЮяЗΤαΙхΒЯ():
    if False and True:
        pass
        _dead_3644 = 878
    value = 440430
    text = __import__('base64').b64decode('aWZ4U0lkc21HSks1SDEyNUlXakY=').decode('utf-8')
    total = value + len(text)
    return total

def _уζчΞЬУцПЪнΨзйЕПΛ():
    if len('') > 0:
        708
        202
        337
    value = 326252
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7RbFBg7LATKjaOwn6qFhx+xVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6608 = 593
        _dead_8698 = 933
    return total

def _χΜГЩАγжГΞχΠиАξξδ():
    value = 172155
    if len('') > 0:
        170
        pass
    text = __import__('base64').b64decode('VzdxR0ZhdmFlVWxZc3M1dHpDSVc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        181
        _dead_3565 = 7
        _dead_6663 = 907
    return total

def _κгЭΒΝοΨΠу():
    if len('') > 0:
        _dead_7426 = 775
        753
        885
    value = 900059
    if 31 * 8 < 0:
        871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQ7mPHwQqvA1CQ6r5GmpLCAdw0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        406
    return total

def _ЯошΜΗяаπыЗΩвωчΟι():
    if False and True:
        _dead_4976 = 6
        437
        178
    value = 146305
    if False and True:
        404
        pass
        _dead_5957 = 642
    text = __import__('base64').b64decode('ekpIcW5rNWttTmhKTXpKbmp1cVA=').decode('utf-8')
    if 29 * 26 < 0:
        pass
        _dead_5504 = 522
    total = value + len(text)
    return total

def _АγЧрβЯЫмω():
    value = 554901
    text = __import__('base64').b64decode('bWxyTVBZN2hSczlsZjNvQ2Z3cmI=').decode('utf-8')
    total = value + len(text)
    if 82 * 57 < 0:
        _dead_2273 = 221
        99
        _dead_5716 = 264
    return total

def _ΡπхАЯшζφΩΜηλкЪμ():
    value = 892224
    if 51 * 55 < 0:
        _dead_6246 = 341
        82
        656
    text = __import__('base64').b64decode('VXNBUmhNNGtzS2dYZ1dzb3ZVSVU=').decode('utf-8')
    total = value + len(text)
    return total

def _φчΓПчθРΓηАуεΙрοΤ():
    if len('') > 0:
        _dead_5587 = 890
        969
    value = 591737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERy2bXcTqqQ5NAuWxXSSJD8e22o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бэψВτлДуΥВΧ():
    value = 174544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRvhQGAP3/pbLgKV5WSgFnwOz0w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2199 = 88
        pass
    total = value + len(text)
    return total

def _лЮЛБΦσΘΕуπПρп():
    value = 892412
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KR/FYkg2wYcXIB7321eHESN51Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЭТθЪΤΩΥυχ():
    if len('') > 0:
        70
        354
        _dead_9883 = 562
    value = 648288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B37cWFwM06cqOCqBxAC+Ig455kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йФлнΛψюΡз():
    value = 257763
    text = __import__('base64').b64decode('WFBiU2xNRnBSSWVNbXBPQllwUmk=').decode('utf-8')
    if 42 * 46 < 0:
        68
        pass
        162
    total = value + len(text)
    return total

def _ЫΦтПуΠБпчοфн():
    value = 958403
    if 64 * 37 < 0:
        675
        _dead_1339 = 860
        pass
    text = __import__('base64').b64decode('VnFjT1Z6M0dQNklGcTZfT2JZVUE=').decode('utf-8')
    total = value + len(text)
    return total

def _βΕуыΨмдΖ():
    value = 517270
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACj8b3I/6Js1EA322lWbIScux10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭмθмкЪСажδΑФУ():
    value = 852413
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXbbfkk7+pomaiCg/GykMAgK3Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟОуцсЗδИηΜдЗυΕβε():
    value = 353271
    text = __import__('base64').b64decode('bVgybXRBTDd3VG1fVkFGT3dVSWo=').decode('utf-8')
    if False and True:
        _dead_1914 = 503
        _dead_1705 = 50
        _dead_1572 = 322
    total = value + len(text)
    return total

def _ξΝЪЛшХцφу():
    value = 172443
    if 97 * 60 < 0:
        pass
    text = __import__('base64').b64decode('RmJtWDJ1MkkxcEltY1dpY21qN3M=').decode('utf-8')
    total = value + len(text)
    return total

def _йρЗоδФыςВшΔйтлщф():
    value = 102359
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('d1ZwQm1VTzdDVkgwY0RrVWpaNEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ВζФЗзΝΟНΟ():
    value = 160884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dh6wQ3Jtp5IICSmF2EeAZB0rvDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГρχтθΨкξГрЭρι():
    value = 314671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyPAW3Mq+IkuPymBxWG2JwAF9mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΔЭхατσеΔБЛπУп():
    value = 894946
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kwfbd3wb/bEGLFqVylmCPzUC/Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _πбεнЮЮпπΤοыЖБ():
    if False and True:
        pass
        348
    value = 923130
    if 95 * 72 < 0:
        52
        pass
    text = __import__('base64').b64decode('VllYbkU3cUxyZVp6OHBJcVVpYkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()