#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ЛΤωжφАΟГп():
    value = 916168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Inb2WEk9p/k5IiqB3VPBOCgC0l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3178 = 550
        142
    return total

def _ΝΗешТенО():
    value = 201419
    text = __import__('base64').b64decode('dTdhaExSWnRtakppOHBmQlNvR3o=').decode('utf-8')
    if False and True:
        _dead_2738 = 334
        _dead_3271 = 316
        pass
    total = value + len(text)
    if 94 * 81 < 0:
        104
        pass
        834
    return total

def _ΩΓτлδΣЬζθЙзψβеφР():
    value = 223521
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzbgVwMa3YwxbwyVwA+2H3Y27WE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬьяЫΓΖшΞ():
    value = 3053
    text = __import__('base64').b64decode('b0xPY2hKNW9neHJDeERVNkROSjk=').decode('utf-8')
    if len('') > 0:
        493
        pass
        531
    total = value + len(text)
    if 27 * 8 < 0:
        pass
        _dead_8596 = 507
    return total

def _ПσπМЕЫЕРο():
    value = 234697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jw7xTFoz7PoREj+0m3ijM3M6/no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘλЛλСГЭφДоЯйγ():
    value = 246991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax/8aFJv54ErDyqi53WYLXEs0Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠиκχΚЯσбнЕИφч():
    value = 929528
    text = __import__('base64').b64decode('dXo1TlRjQWw3YkpROTd5MGMzYjI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬтυкψГυИτρΜΩуйЛХ():
    value = 120515
    text = __import__('base64').b64decode('YVk0ZHhrM1lyYl9VejVXWDVvWGU=').decode('utf-8')
    if False and True:
        109
        _dead_7166 = 140
        pass
    total = value + len(text)
    return total

def _ЫпΚТфоωκΝ():
    if 31 * 17 < 0:
        pass
    value = 305799
    if 61 * 16 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQOxfXIW0fAKNF3zwEKFGjwZ9kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 80 * 65 < 0:
        _dead_3621 = 982
    total = value + len(text)
    return total

def _θштКяьΚφЛΒЪлωчЛ():
    value = 392849
    if len('') > 0:
        395
    text = __import__('base64').b64decode('Y1NEeHRYZDBqZFAwcnRsY3FqMEM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        358
    return total

def _БгЧРЪруΩгщρмж():
    value = 294929
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXjsPHIcr54hEjmgmXXFJC8jwzk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГεΞЛωЮιβЗэ():
    if False and True:
        989
    value = 281581
    if False and True:
        pass
        _dead_3556 = 513
        _dead_7411 = 372
    text = __import__('base64').b64decode('dGRjdWM2dTBTMkNFTVBxZ3RfSHY=').decode('utf-8')
    total = value + len(text)
    return total

def _УθεдνеЯφяν():
    value = 130059
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCfVYWcX15E6Kzny/lSqOhoI3lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2371 = 900
        pass
        pass
    return total

def _ИРοцμΕΔζΤоаяоΧ():
    value = 904257
    text = __import__('base64').b64decode('R2Vwa1plc3Z3d2k5dzhHcDlPbnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦпΨПхωδρйвΟδОοФθ():
    value = 399665
    text = __import__('base64').b64decode('bFJjS3hJNGxuZFg0MUpDdG9MQ00=').decode('utf-8')
    total = value + len(text)
    if 21 * 67 < 0:
        _dead_1691 = 901
        _dead_1298 = 950
        pass
    return total

def _бηΡΥъмтбΩΕβ():
    value = 588149
    text = __import__('base64').b64decode('dmRsSTdMYWFUdzZpT3Q0UV82SDI=').decode('utf-8')
    if False and True:
        pass
        8
    total = value + len(text)
    return total

def _ЬртΧюΜςЬΗЛ():
    value = 464492
    if False and True:
        _dead_3299 = 270
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQOxQmUA6o43NAuZ0FTAEy13vEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4738 = 13
        _dead_7434 = 853
        pass
    return total

def _ЙьюаΑΞыбυΘААЩμъΞ():
    value = 475160
    text = __import__('base64').b64decode('RmltYnYwd3NBazdQV2RnVW16cmw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        992
    return total

def _тΒХτИмδйТъп():
    value = 507752
    text = __import__('base64').b64decode('Y2xZQ2pjeDdDX1FHUWdQRE1lWG8=').decode('utf-8')
    total = value + len(text)
    return total

def _νБοκЕЯИЭρФЕηΔΔшλ():
    value = 259667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CinXYlNt7IMZEhWnkAGmM3UG7j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тρгхΙΨκΝИΙТ():
    value = 561695
    text = __import__('base64').b64decode('U1NMcW1QSm9qWTF0RlVVZ1FlMG0=').decode('utf-8')
    if len('') > 0:
        854
        pass
    total = value + len(text)
    if False and True:
        _dead_2980 = 82
    return total

def _СкΦзνδΟА():
    value = 147198
    text = __import__('base64').b64decode('eURYZ0MxTGQ0T0hlWURHWlhNaEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _αΑЛцЙрФиφян():
    value = 464123
    if 41 * 14 < 0:
        pass
        _dead_3109 = 193
        175
    text = __import__('base64').b64decode('dGcyZ09fcmdmcl93bzl2c3VSSTA=').decode('utf-8')
    total = value + len(text)
    return total

def _ВМщкνчэцυμχеЩχ():
    value = 902199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH31P3kc+IUrHweGnHCAYSot7UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НтэтШΑШιуΒ():
    if False and True:
        667
    value = 910586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cwm9ZmNrxJ4kHxyHw0OSEjI+6DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        537
        193
    total = value + len(text)
    return total

def _ΤлшΖцПцефβ():
    value = 376463
    text = __import__('base64').b64decode('UG5hNHNUcng4WVBCRHJyV19CbFI=').decode('utf-8')
    total = value + len(text)
    return total

def _ФгРгзбεМиΣюРУац():
    value = 81201
    if 20 * 50 < 0:
        211
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECLeZQM614EULCeH/2m/JSk7wkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞыеЫθξΒйΜВХВщеβη():
    value = 737371
    text = __import__('base64').b64decode('TjF1U2x1dm1jb3V4T0lFVFpVNVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _НΑвψΧρΒБω():
    value = 418261
    text = __import__('base64').b64decode('UlhMMVRXb3ZJM0NvMTlycV9ocVI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        659
    return total

def _ΔσΖЮτψФднзДмοθый():
    value = 281605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnfCfEg137gOYgqzy3qFGQohzmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 66 * 47 < 0:
        pass
    return total

def _ΒЭрЮчΟтбΦЬ():
    if False and True:
        pass
        _dead_4335 = 91
        424
    value = 243819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyLbW3U49p8kaQGVxE6AByl39T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΧνшοлЩΚαΙщъα():
    value = 102215
    text = __import__('base64').b64decode('SURQZTJxMDF2RnRIbVFUQ3RqMk0=').decode('utf-8')
    total = value + len(text)
    return total

def _βЧтбклЩнЛζ():
    if 40 * 50 < 0:
        _dead_6451 = 922
    value = 379819
    if len('') > 0:
        923
        249
        pass
    text = __import__('base64').b64decode('VGl0WXhiczh5Slphd0ZKV3BTcXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ФхЭющРЙЩгηеΤ():
    value = 171496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAfhXwQapqdVYxeTnQ+qDQIs4Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дЕяχИшΡΥ():
    value = 560762
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw28agU9yqMEL1qU4XyjYBY/6k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1020 = 207
    return total

def _кγсμыΒъς():
    value = 238892
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSe8OGYN6ookaleR5QOJCwp3yj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УУАУмκΖβΖι():
    value = 178597
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQT2UVUd7apUMT+l3WnBYHU3xm8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣзъщвЫъНф():
    value = 971519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAvrYmYP+aMsEF2G60KaBRct3To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨωЮχфЭМВКТθКвΕβ():
    value = 629778
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ewm0SQEOzIICCR6iwFC5Yz0Q10U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        945
        956
        pass
    total = value + len(text)
    return total

def _щпπкνчоζςαΨΩЕДцд():
    value = 334662
    text = __import__('base64').b64decode('ZWxHbDZWbjNnVkZMbUZNb2ZkbkY=').decode('utf-8')
    if False and True:
        238
        pass
        pass
    total = value + len(text)
    return total

def _ΑПыХШмΑЩФγ():
    value = 875433
    text = __import__('base64').b64decode('ZWJTZVZPb1RraUVwb1NGM2o4WUI=').decode('utf-8')
    total = value + len(text)
    return total

def _рРбβЬξπуΒШЫΙЧЬ():
    value = 442998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBC2NnI836smLA7w0QeILQYr1nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4896 = 999
    return total

def _уΥπυΒеМκР():
    value = 474102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERDXaQFh6Z9UKTu7xX2xbDw+3kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_4063 = 502
        983
        545
    return total

def _уεвψНΠЪιμΣ():
    value = 736550
    text = __import__('base64').b64decode('UzV6ZXRPU3VkM0dmQnQ2ODJwNjQ=').decode('utf-8')
    if len('') > 0:
        798
        pass
        pass
    total = value + len(text)
    if False and True:
        590
    return total

def _ЕуΕьΙЪгψрЮ():
    value = 441941
    text = __import__('base64').b64decode('UnZZY0RMWkZqNVZXdTZjU3pNa1U=').decode('utf-8')
    total = value + len(text)
    return total

def _κаДъШэλΧиνΘян():
    value = 480409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnbIZ1IXwaEqaCm2kXyEYyB50k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иΘсφэАпγЦιΞΟ():
    value = 732555
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhnmfXIuya9SEziszmnDN3E9zE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _спЖΚКШΧщρΜАφАЦШ():
    if False and True:
        _dead_3165 = 811
    value = 498680
    text = __import__('base64').b64decode('QVhjVnJqdWRINlZrN0g3TFp3NWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΟΝцΚзыУ():
    value = 817893
    text = __import__('base64').b64decode('RHJYSnl4cDNPbzJ3cjE4dHdnMUE=').decode('utf-8')
    total = value + len(text)
    return total

def _фцΠζθФОΝ():
    value = 917484
    text = __import__('base64').b64decode('VXFTZzZhSFBCS2VCY0RLY2NQV3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΝλΙаэгΞυζШюа():
    value = 834971
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nw3ObAYMp6s8bi3wxWO0LQwK9jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΦчьιΠΘрδЧς():
    value = 817446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgDQfGcB8bFWOTqWkVKIMT9/6ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЩεΦоΤΔУм():
    value = 426190
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PX/yO3M114QUAAOiwH+jZiYM8Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цΕцΤφьБλГ():
    value = 717650
    text = __import__('base64').b64decode('dGo1Q09ONUdIU08xTFRJRFY2blU=').decode('utf-8')
    total = value + len(text)
    return total

def _ςтжχПψωЖиюερδ():
    value = 823927
    text = __import__('base64').b64decode('aFRwc24wRUVFTWtUVzRWTmt6bGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧΩпΒΖψЭЕλЦщςит():
    value = 395047
    text = __import__('base64').b64decode('emJlTGIxSG5RTExVWnJoSkdWWjM=').decode('utf-8')
    total = value + len(text)
    return total

def _εРхΓΥчψΛгЮκа():
    value = 964769
    if len('') > 0:
        174
        483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSDGeQggpvFQPgqg3VSSDgAiszY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΟНΜОчпЙΘкΒКσΡЕ():
    value = 113741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzflYVA4+6Q5FiKL+WWHY312tDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 80 < 0:
        978
    total = value + len(text)
    return total

def _КчПαΩЬжк():
    value = 1964
    if 56 * 50 < 0:
        _dead_3452 = 888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB7HaQMx6JsKNx2A+gDJHyp6z1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кнΠЩСпхШ():
    if len('') > 0:
        _dead_1869 = 426
        427
    value = 361007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDfld2g154MFFzWs2lmoDDYn20g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬиυΣΟечΠΙБАш():
    value = 744111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnnGOkIP1bszLR2Kyma9ZDx57Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_6532 = 336
        _dead_1694 = 835
    return total

def _юБЮжκтНШШл():
    value = 395554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnnWaQgX5oAUIieFmkaXMHYExWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        900
    total = value + len(text)
    if len('') > 0:
        _dead_8180 = 79
        _dead_3263 = 844
    return total

def _зИβйεδΜΖ():
    value = 813947
    if len('') > 0:
        pass
        576
    text = __import__('base64').b64decode('TzNzVmgyNlJFRjcxZEgzNllzUk4=').decode('utf-8')
    if False and True:
        _dead_2362 = 989
        387
    total = value + len(text)
    return total

def _ΠΨΑнγжЖьЦЫюЪ():
    value = 531945
    if False and True:
        _dead_2057 = 716
    text = __import__('base64').b64decode('cDMwS3VzUUE4RjRVNVhIV2VaYTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ρйηΔΣХοеΤы():
    value = 361286
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDvjdnwB9/gCKDrz8liUH3Ec0Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥЯΟεΘтΛμчΤК():
    value = 414674
    text = __import__('base64').b64decode('dXF6aXlKdXpLVnVSWllVQTRpOWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖеуЕьгоФΔмΡЭГ():
    value = 1834
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBrrenxtrpg0Air7mWXAHSE9wVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 23 * 61 < 0:
        162
    return total

def _нвщМΔЗмΠнп():
    value = 281468
    text = __import__('base64').b64decode('b01wMVlvNGRDaXFPNU0wNE1nWGI=').decode('utf-8')
    total = value + len(text)
    return total

def _ХАфЭНИοЫши():
    if False and True:
        582
        pass
        pass
    value = 970572
    if 35 * 40 < 0:
        _dead_5242 = 506
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjrKbFUg87gmAF6R7FivABAg82A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        369
        pass
        pass
    total = value + len(text)
    if False and True:
        969
    return total

def _λΥνСοΜРρ():
    value = 465484
    text = __import__('base64').b64decode('Y250RGhjR3NxTHR6eVBkbEtsQno=').decode('utf-8')
    total = value + len(text)
    return total

def _цπдлβыυове():
    value = 489144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgXFSEky9aEWLyH1736xJQ18/V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜГΒПΥΧеΘДΖЯ():
    if len('') > 0:
        240
    value = 449085
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyfhUXAd+7IpIl66xnWXFywtzGs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 38 < 0:
        258
        279
        135
    total = value + len(text)
    return total

def _ьЕЖкщφΥжΒψюш():
    if 18 * 32 < 0:
        _dead_2484 = 288
    value = 941255
    if False and True:
        625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyLFaWMI8vtQLj6x4EehHnEA9nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬиΛδΙΖΗцμυΥ():
    value = 225024
    text = __import__('base64').b64decode('WXd5RWxYVkhUVW1aTWJZZkdieUY=').decode('utf-8')
    total = value + len(text)
    return total

def _зΟМэΙОΦдмΤмА():
    value = 356699
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ET7RPkk+q4IoFiSGkWTGJhM20Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΚвΔСПйυюξ():
    if len('') > 0:
        881
        _dead_9321 = 628
    value = 451878
    if len('') > 0:
        631
    text = __import__('base64').b64decode('cHpIUEY0MGlIZHZybW1aYkw4eFg=').decode('utf-8')
    total = value + len(text)
    return total

def _эЩмУаОφиЭβН():
    value = 17750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxyzQX0/x6BQBVj7zHvJJHwI718='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕωЩдргПΔνιηκЬγ():
    value = 290928
    text = __import__('base64').b64decode('aERKSHZ6NzlITU1fT3dueTh4MjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯβИοдΞйωΦΙΩτ():
    value = 93733
    text = __import__('base64').b64decode('ZGpPNFdzelpndldaWFFQbEpaTkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮπηпΤьДΔпδΩМεΨФν():
    value = 481705
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwrTS34bqZEINgOZ40/EFwkX5Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΓΕΞыρΞΛΓΑЫΞд():
    value = 603851
    text = __import__('base64').b64decode('cVZDVmNSM3dfNkpodUVFam5zNGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ηпξΘΔКΔζжСω():
    value = 877904
    if 75 * 20 < 0:
        663
        pass
    text = __import__('base64').b64decode('enVaV01yR1pKTGVNazFNbmtqcUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _χαжЦαΛΒυΕδ():
    value = 361841
    text = __import__('base64').b64decode('a25VZ2VmckFWV0hzcUF3aGx4SFc=').decode('utf-8')
    total = value + len(text)
    return total

def _щЯтъАβФΑνХуэЫсθ():
    value = 702291
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxXRZXYv+60lNTeK3lqkLgcs118='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αлЬΔΝыςΞоΠΥзГγςΝ():
    value = 506809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DivWX0Fs8/ggaTb24XuzNXYK4lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜξОлζНЕοΥЕэЕχл():
    if len('') > 0:
        867
        _dead_6783 = 581
    value = 804628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzjUfGMa6vA5P12i332eIHd6s2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5350 = 970
        pass
        _dead_7338 = 180
    total = value + len(text)
    if 30 * 58 < 0:
        618
        pass
    return total

def _изΔшУщФεЕВ():
    value = 411085
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhD3f0Ao/ZcXMDr6+FDBIT03t1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЪεЕУьθоω():
    value = 72881
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgCzZnIQ0IQ6LVmTnVfIF3R9smw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гяΞЪμыΠζВν():
    value = 821189
    if False and True:
        _dead_5315 = 531
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HznVVFwdy54uDg6a0EHAIHI27ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΟξΣвгэЫυξθΨ():
    value = 897298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTvKbWcSzZAiAjWR/XWfYi4A/mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜχнеМвΤΤаυОΠΕτΔл():
    value = 456078
    text = __import__('base64').b64decode('RF9GejBVV3JiY3ZLRlpFNFJDSFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ШφоεЮжПαΗ():
    if False and True:
        pass
    value = 931969
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hyf2b3s0zpIgNQCww1iBGgM1tHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        428
        pass
    total = value + len(text)
    if 26 * 14 < 0:
        pass
    return total

def _ЦзФчΓΔсΞ():
    if 13 * 18 < 0:
        545
        _dead_9705 = 508
        820
    value = 261047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRrsYWUQ9PoAFRaB5H2hOxYY82o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _еЦРДээΨТМπΑэдΥг():
    value = 781840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHbUTUUj16cmMxqn0lCJYBYJ0WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щщνΜПзУσМ():
    value = 69106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRfXSEM60aUoNQOG7WWGJTB38VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        408
        _dead_1942 = 760
        pass
    return total

def _къкΛЮцΕТδΛΖх():
    if len('') > 0:
        _dead_3678 = 735
        pass
        _dead_1160 = 874
    value = 29589
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JirOWXw08rEHEQCFz2GCDgB75mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤυмψчУоуФαСΕζиБэ():
    value = 100631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyzjdwgByrBXGz+Ux3nCbHMG63w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ршΗЙδΕΖΒшшцΚΒ():
    value = 132278
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwvzbXlv26AQFQP1z17CZSM66HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΔΔПβκВΜБοПдΟψ():
    value = 36456
    text = __import__('base64').b64decode('dG1mR1R6U1RsNDhUcnN2ejhaSGI=').decode('utf-8')
    if 54 * 37 < 0:
        548
        pass
    total = value + len(text)
    return total

def _хμΛγωвъРψСδгГМн():
    value = 279073
    text = __import__('base64').b64decode('Vk9udXFvdWNiVV9aSDVxQ3dMSWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠсΑыЛΓΗοΙо():
    value = 267686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjzcRnUb7v8aOQK7/26/GwF8tXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДэЯюоαэЯХэаИπΕэ():
    value = 444728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EwP0OAM49IQPGz6n8g+zHw8E6Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧρΨαзшδрλΕαπкτ():
    value = 860431
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT32SFI825IxACmkzV7HARAG7nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 2 * 56 < 0:
        pass
    return total

def _РΧиςδΜαЬзαΚвАГ():
    value = 496832
    text = __import__('base64').b64decode('cWpET0t4d1Voa1VSV2VYWF9leXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΨΞЙζВзлощСЗЙСΥз():
    if 1 * 39 < 0:
        pass
        578
    value = 619844
    if 52 * 17 < 0:
        pass
    text = __import__('base64').b64decode('RzZSdG5CYjFlaWp1R2I4NDhVYjg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        498
        106
    return total

def _ΘщКζщщЮуТοэг():
    value = 91326
    text = __import__('base64').b64decode('WVhPZk5reU5nYW40a0xMTXpKNXg=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        276
    return total

def _ΟРξЕщΖЦзнЧηцΙαзЗ():
    value = 490714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IATVY0MR2IAUCRac/wehABMcyUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 69 * 26 < 0:
        _dead_1048 = 831
        pass
        439
    total = value + len(text)
    return total

def _зμκрЮΔуЮ():
    value = 109754
    text = __import__('base64').b64decode('bDlUZGU2dVB2c05LNXR1OGFkVFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠνэВРлЯАаЩышπΕθ():
    value = 17614
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('WGJVd05UczNmRmp1N0V6djF6aW8=').decode('utf-8')
    total = value + len(text)
    return total

def _йφωЪеЪΨЧγПЗСσя():
    value = 301569
    text = __import__('base64').b64decode('UXJFV3lPRFBNNERkNDBjX0o1VHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ФйГЛηЦβΞБФЗοΝχΖ():
    if False and True:
        _dead_3136 = 137
        _dead_3383 = 279
    value = 964053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jye8NmYu9P1aNieJ0FWaInAsyko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 63 * 66 < 0:
        _dead_4399 = 762
        710
        45
    return total

def _ψΦψюжьнψΔШ():
    value = 893032
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnfwaEYqz71VDCe52V+yICwrz1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _цЧΘεΕТмЕРЦτл():
    value = 254026
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXn0X0Fp0rgabBm3xHuTPwgD20k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВПЗσпσуΩγυΠχΙ():
    value = 45950
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LRnQSQc/7bhSKjWkwU+CYQkKvUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        894
    total = value + len(text)
    if 12 * 87 < 0:
        pass
        pass
    return total

def _ТΒЧеχΤλΗγЫρ():
    value = 119286
    text = __import__('base64').b64decode('Y1FpUHZaM3RhSXB5Z0xoRF9mMzU=').decode('utf-8')
    if len('') > 0:
        645
        pass
        pass
    total = value + len(text)
    return total

def _АΦкБΨЛВЛИΣжоиρ():
    if 79 * 27 < 0:
        _dead_9858 = 354
    value = 925765
    text = __import__('base64').b64decode('Vll3ZmlhbDUycllFUEt5VnVFVGM=').decode('utf-8')
    total = value + len(text)
    return total

def _гТэнΦΣЧεуШνξΡεδα():
    value = 25965
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExbyOkEz2Y0kKh2J7m+FDQh/xmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГышδЪΩУОкΑЯΖЦ():
    value = 63902
    text = __import__('base64').b64decode('RVNFTWF0OFZ1dWwxcjNjRjN4Wjg=').decode('utf-8')
    total = value + len(text)
    return total

def _скЙМБОяш():
    value = 638567
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('En/SWHUI0qwqHFm2x1KjLQZ2sX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΨφαмΘΛΗσ():
    if 51 * 7 < 0:
        pass
    value = 968271
    if 83 * 51 < 0:
        488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwPPeQcRy4skGByP/nfBGxV+wGY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        587
    return total

def _ΘβсδУХфαзЯИοШоуВ():
    value = 298163
    text = __import__('base64').b64decode('RGE3MDFTMktXZl9DcmJXSWQ5UVA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        952
        _dead_1310 = 740
        _dead_7540 = 649
    return total

def _ΥυΖσΓЕЖФЦΨωИввΡ():
    value = 441960
    text = __import__('base64').b64decode('RjY5YTBBV2pjbHFQV2J6VThXM00=').decode('utf-8')
    total = value + len(text)
    return total

def _тαШАΕЫнΛσпъφя():
    value = 420075
    if len('') > 0:
        pass
        109
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PATrQHM/8o4iNT+O52+1GgkVvWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λΥχГлЪηΙпδДФΛ():
    value = 77351
    if 92 * 92 < 0:
        244
    text = __import__('base64').b64decode('cFhqbkZ3SDI1Q21zMkw5clBPYU0=').decode('utf-8')
    if 27 * 53 < 0:
        599
        pass
    total = value + len(text)
    return total

def _ζНЧΔсεΜΔКа():
    value = 814714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX73W0UM/4k7MCqT+0CGYwAG8lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1714 = 876
        381
    total = value + len(text)
    return total

def _ψклΟшεсхηЩхΠ():
    if 9 * 12 < 0:
        995
    value = 660668
    text = __import__('base64').b64decode('Q3hFdm5YT1p6NERVejN0X1FPd2g=').decode('utf-8')
    if 64 * 67 < 0:
        _dead_2310 = 948
        416
        _dead_6527 = 466
    total = value + len(text)
    return total

def _нκμπψΔρΚииω():
    value = 726076
    if len('') > 0:
        224
        _dead_3449 = 486
    text = __import__('base64').b64decode('ZUFEQnpvMkdPVkIxTTRfSFpialo=').decode('utf-8')
    total = value + len(text)
    return total

def _δψΠъЗυΨНφ():
    value = 548260
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('cWEwSmtmb2ZsMmNLUjZ0dmlneTE=').decode('utf-8')
    if 43 * 93 < 0:
        640
        pass
    total = value + len(text)
    return total

def _ьκλтэЬнзнУγη():
    value = 415989
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgLvQEIc2bgkCAKLygOHYjI2sks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛюΓтΦθσГΡΓηчΤЫ():
    value = 367138
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQrOXAEazJ8SECqJxWmXJQE6sEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 98 * 86 < 0:
        _dead_4153 = 982
        pass
        37
    return total

def _ΠιЧБИЮιЙφй():
    value = 248387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BynKZlI01fBTNwn3wVqaMSknvH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жкЫлμДнг():
    if 98 * 5 < 0:
        pass
        596
        _dead_4146 = 782
    value = 640853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyH0PwYKrJkxHlaq2A+vFhQ/8kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩεχεΖΒΤМ():
    value = 368590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSn8dGk19fg7Kz+6nmOKAiAEyj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΖΣсЭΔжБфργы():
    value = 565686
    if 32 * 53 < 0:
        _dead_1658 = 734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiDWbVcxposTCVz1/n6nDiYLxk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5691 = 644
    total = value + len(text)
    if len('') > 0:
        _dead_3381 = 113
    return total

def _φАτΥκΗяльъЦнΑЙ():
    value = 75499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBXlWgUvzP8uHxrwyg6hEjcry0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρσДКСЫΩАЖйЧщΛЭ():
    value = 878849
    if False and True:
        pass
        400
    text = __import__('base64').b64decode('eDVpVGFySzBRWUdheDQ4cG5na28=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞνΝцγШωпΜηл():
    value = 656933
    if 82 * 42 < 0:
        _dead_6106 = 106
        354
        16
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EDnBeGgo87BWKzCg8XWoAXMu9Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Иуйзζаць():
    value = 216986
    text = __import__('base64').b64decode('VVZPdERXNllpcnZyUkRWT01BWm0=').decode('utf-8')
    total = value + len(text)
    return total

def _аМЖΑВГрАΔбрщХ():
    value = 278367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARvzRF8r+LsUCBjx4FGcFigf/lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛЙяРЯЮκыУмγ():
    value = 729026
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzXUXwgp5/wuNxezx0/COwQfzmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТьξΔПыΙщИУаΚΕЖς():
    if len('') > 0:
        pass
        315
        _dead_1193 = 267
    value = 508678
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSmySwMwqJwUDTm7+UCjDTN7zX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 66 < 0:
        pass
        _dead_6544 = 240
        _dead_4394 = 241
    return total

def _дςΝкνцМЙЬυθХψλ():
    value = 972891
    if len('') > 0:
        pass
        _dead_2502 = 85
        _dead_7193 = 882
    text = __import__('base64').b64decode('enBMRXNDTmw4ZExVOFdCaTJ4ejY=').decode('utf-8')
    total = value + len(text)
    return total

def _шрυΑУβνΟЧηхλ():
    if len('') > 0:
        462
    value = 650203
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyewamI3z/o5CgicnmWWHhIkyUU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥτγЮдЬΕЮΣΖКАΨуΠ():
    value = 243996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px3GYQU40YEBGyKInnOiPi4o4H4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АМψЗЬυжЛАΥЪΠ():
    value = 89413
    if False and True:
        _dead_9813 = 983
    text = __import__('base64').b64decode('ZjlfN25jNEJGS2tDc0hHcWxwX0k=').decode('utf-8')
    if 56 * 53 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _οъуеΑАеρκ():
    if len('') > 0:
        303
    value = 921225
    text = __import__('base64').b64decode('eFQ3cTVlM0xlcW5ad3Y2VHpiMzY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯθЬШЪΖΔΒΣυΚ():
    value = 542668
    text = __import__('base64').b64decode('TndjclZvcUVjQXp5SVJXdFJCTkI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕзΙΒКαАуοχСИБψι():
    if False and True:
        _dead_5179 = 925
    value = 674853
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRzyTHg7rolUCD+q7U+yNg0F8ns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮЮΞΘрΑΜβ():
    value = 52778
    text = __import__('base64').b64decode('dnBPZ3hfb2llcmFnOWFJbE83MXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΟАБцΕΚБΞΣН():
    value = 98637
    text = __import__('base64').b64decode('RHlPaG1XVDBiQjZGdWxEOExGZWw=').decode('utf-8')
    if False and True:
        _dead_3810 = 545
        888
    total = value + len(text)
    return total

def _СуπΩЬΛПΟхκ():
    if False and True:
        151
    value = 257737
    if False and True:
        _dead_4312 = 322
        _dead_8856 = 805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwHRXHMW6/5WMTrz20/JOXwW/H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 3 < 0:
        _dead_5679 = 510
        _dead_7595 = 249
        466
    total = value + len(text)
    return total

def _тιφβЗЬθΥлШωυИИТΩ():
    if 28 * 66 < 0:
        pass
        135
        415
    value = 54071
    text = __import__('base64').b64decode('YVZOcmJodzhYWDM1RFlHWnhsSDY=').decode('utf-8')
    total = value + len(text)
    return total

def _нΒЛЦΦφэγγъЪβ():
    value = 990951
    if 43 * 47 < 0:
        736
        320
        774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBC3YQYI0aQWOyGgnAWfZ3J80FQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 89 * 80 < 0:
        pass
    return total

def _ЦΒГΗΛΦΔБε():
    value = 494633
    if 77 * 64 < 0:
        pass
    text = __import__('base64').b64decode('QmJuVEZ2cWRWOWdhSXp0Vm1kUXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΞдЧΙοΛфпэИβ():
    if 46 * 78 < 0:
        _dead_6839 = 350
        357
    value = 658215
    text = __import__('base64').b64decode('WE85MHJFcVEzNDdTd3ozZ0o4TUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΠвЙщщΜНМйΧρΞБχ():
    value = 894336
    if False and True:
        _dead_5800 = 240
    text = __import__('base64').b64decode('b3JDMHdicHZtNFpoajkyTkZpQkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΡλΗκООιРΓ():
    value = 787660
    if False and True:
        _dead_4284 = 571
        830
        _dead_7326 = 766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bhr0YwkBz/tXOTiZ3VKHI3Y8vHc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΤΚЪυПυφΤΨΘЛι():
    value = 448415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCn9UVge9KEmGw6q3luGOQo/xzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_2740 = 835
    total = value + len(text)
    return total

def _μпΠπМеωяτ():
    value = 707498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyfDS0E1+v5aHQKvzW6gYXAdsnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρУΖшПТЦьжФИтВΒ():
    value = 926781
    if len('') > 0:
        _dead_9002 = 802
        _dead_1215 = 693
    text = __import__('base64').b64decode('WTRsTnRyb3FkMnUzNGFzeGlCczU=').decode('utf-8')
    total = value + len(text)
    return total

def _νХКνЛЭдмтκ():
    if False and True:
        pass
        813
    value = 407669
    if 33 * 50 < 0:
        353
        pass
        _dead_5338 = 162
    text = __import__('base64').b64decode('eDltdFBBTWNBcGFmaEJ3RzRiRjk=').decode('utf-8')
    if False and True:
        656
    total = value + len(text)
    return total

def _ΒиαкцТкΦτщζы():
    value = 308805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAbLTAVv6pIvHhyz51+INi0Qzzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪыσжгцμΝ():
    value = 62519
    text = __import__('base64').b64decode('cHF2TmRjT2F0Tm5vY3ZNaG9GTDA=').decode('utf-8')
    if len('') > 0:
        _dead_1379 = 124
        _dead_8182 = 606
        683
    total = value + len(text)
    return total

def _уΗФТеРΥτυ():
    value = 168125
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwXbRUEqqv4iayCT8H+iCyA2y14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щθβчΡяиΓΗюхτя():
    value = 409969
    if 19 * 17 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQnQRWM+qPxRbA3xwFKcbQ0c/XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лвЩσζюХδЖι():
    value = 701568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hy60YFsG5rEqN1yQnkKEAXciy3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩΜОΥгγδырγτю():
    value = 288666
    text = __import__('base64').b64decode('bEZ5YmpJUmp6R29RbmVlcTd5MlI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖУУΨЫτΨΖ():
    if False and True:
        _dead_3232 = 238
    value = 708797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyPHQUYWpo8ZYzqxyw6kABEI11o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 19 * 39 < 0:
        206
    return total

def _ΜБЮАяьλΦыυι():
    value = 158399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH7vQVQy8IY2Al2x/2S+JiQE4Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΚПδЕτδРЫЮИ():
    if 30 * 42 < 0:
        _dead_1982 = 276
    value = 931835
    if False and True:
        pass
        253
        806
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LR7MX1pr2p8MHCi7m1e2AC0c52s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КИКГΗτВйβщΛф():
    value = 905420
    text = __import__('base64').b64decode('RkVmVkRyQlNQTV9SQWM0V2l1RXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓсяЕчΓΛфξЛςдΥΒвв():
    value = 512248
    if False and True:
        pass
        _dead_8568 = 357
        pass
    text = __import__('base64').b64decode('UURwTDRjZUV4MDN5U3V2YkRsWUw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        941
    return total

def _ПΝоΙтГвτЬгЖЖΝтνЮ():
    value = 50682
    if 22 * 14 < 0:
        _dead_8642 = 575
        334
        _dead_9585 = 578
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhDAR2ZtqfsmCR+umne+OzF/6kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сУΑЯььчςМκЭοЖЖ():
    value = 879732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHj1OFgyy/sqEiic21y+YS157D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οшЯуΒΘЫλъБУφВю():
    value = 178903
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCDHdGgc6o4HNlqom0OCYwg1tXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТыВιЮΥθАωх():
    value = 58462
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwDVN18cxvBbEjeB5leWbDMj9lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨψЫЪΗιнσΗτι():
    value = 459439
    if len('') > 0:
        347
        pass
        _dead_5799 = 411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBjcXElg3Lo8AAbxwFOeZzEtzjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 5 * 83 < 0:
        364
        945
    total = value + len(text)
    if 52 * 95 < 0:
        pass
        _dead_8727 = 973
        pass
    return total

def _ОнχιеυгПт():
    value = 749484
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N33reVZr9rENEiT2mG63ZgMl62Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _λЦиκΝфΠΨΨЕдъфΑшУ():
    value = 778729
    text = __import__('base64').b64decode('Y09BSlQ1aGpHWkVBZ2F1U1hKc2s=').decode('utf-8')
    if len('') > 0:
        451
        _dead_1489 = 328
        pass
    total = value + len(text)
    if 30 * 75 < 0:
        pass
    return total

def _ИЫοЗТуГшψωτΗ():
    value = 633927
    text = __import__('base64').b64decode('azJ2ZTdsclVrdzgyeFJ5d05hbXE=').decode('utf-8')
    total = value + len(text)
    if 49 * 13 < 0:
        315
        983
    return total

def _дλЧΖмоΚψεахΑΙ():
    value = 193479
    text = __import__('base64').b64decode('c19CUlV1dllXRlhpVnNjZW1TR2c=').decode('utf-8')
    total = value + len(text)
    return total

def _еГЬОψЬСЮжря():
    value = 126381
    text = __import__('base64').b64decode('S081QmxDRDRtdEZUUTdycktadHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥяζнψЖΘлπΥ():
    value = 288365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IC7US0Is1rsBNAaX+wKlZhYVtmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘчαΞЫВЖЬοсωХЙΚЖ():
    value = 889014
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDzVdlAb5PAOHTmh2wOdJw4b9j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        572
        _dead_5624 = 720
        _dead_3195 = 24
    total = value + len(text)
    return total

def _ьрπМШγхрΖяΒΟОьеЖ():
    value = 949632
    text = __import__('base64').b64decode('bnNPc1ozWmVONWFDZ29ORk1Jb3U=').decode('utf-8')
    total = value + len(text)
    return total

def _нНιιПνЯЙμЩхр():
    value = 623050
    text = __import__('base64').b64decode('azFFc3RKNGliX3ptZk5jUGhfV0g=').decode('utf-8')
    total = value + len(text)
    if 65 * 88 < 0:
        3
        116
    return total

def _ΔйРЪыαгЧ():
    if False and True:
        pass
    value = 670446
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB3iSntux4I0Egqn8n+jPh0azWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 31 < 0:
        _dead_6158 = 341
        _dead_9776 = 901
        296
    total = value + len(text)
    if False and True:
        pass
        146
        pass
    return total

def _ΞЯλчьщБιРοΙ():
    value = 420066
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQa3RAYu/IwMKwaGzkWpZCkq1zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЪδкΨтκγмз():
    value = 974726
    text = __import__('base64').b64decode('Tng0XzBvRV9zR3VxNjhicFdpTkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΝμЙгΝгηлК():
    value = 373780
    if 85 * 35 < 0:
        _dead_8956 = 392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NATCZgcy9fBaayWNw1ukJwonxzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΜштθΖνЕчж():
    value = 337554
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DX7AV0YRqIMubgms4nnIDAo98Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛГшКΙпиПιЕΛаΡκ():
    value = 961697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxXMb2Yv1Z8NHiq6zAeAEnYFz3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КьωыυЮХлΙςц():
    if False and True:
        491
        _dead_5134 = 339
        292
    value = 316431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHzlPgU284NTIDCux2GjH3AM6lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 71 * 67 < 0:
        434
    return total

def _ГΩκНΓΔФфωнжαΒХ():
    if False and True:
        0
        _dead_2092 = 504
        _dead_3236 = 802
    value = 516011
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABjFNlsP5rhTCV+MwgevYg4X4k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αЦυУХθуЦνбУ():
    value = 434119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBzSOV9proMFPjau0WyaOnF3vVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 31 < 0:
        pass
        pass
    total = value + len(text)
    if 27 * 88 < 0:
        _dead_6255 = 395
    return total

def _γοΔИЮКγβπψ():
    value = 906772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBjdX0AD94UoFS6R4AXHEz8g8Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λпаыψфАΨТСПлρжπд():
    value = 304172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwDAa1kG8f0tLyGI40K5GzQ7130='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧшьΞηηЫскьΙю():
    value = 242352
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fxv8dkBs0qUaLAOymlG8PgwK72Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σзОεБЕЬфοЬОЗ():
    value = 301204
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRjcQloOq6waCV+y4k+bLRE6w0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        415
        _dead_7222 = 245
    return total

def _ΠтΡдΙΚшΙкфзИ():
    value = 373735
    if len('') > 0:
        824
        _dead_1717 = 774
    text = __import__('base64').b64decode('SmhJTG9rMElhZkJyNFN0bk5WQTE=').decode('utf-8')
    if 56 * 9 < 0:
        pass
        174
        pass
    total = value + len(text)
    return total

def _ΦαрЭАУИΜΠЩδς():
    value = 947601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FijzYQcq6v8qO1+qz3GDGjMgtkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГЦΞιюξФς():
    value = 158498
    text = __import__('base64').b64decode('UzlnS3FheUU0M3ljR0pKb1ExUDk=').decode('utf-8')
    total = value + len(text)
    return total

def _УσзШбмΜΘъБЦΝмΠΣ():
    value = 49392
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3z2X30+9YsVAyqG8Q+cAQ8mvF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФЭЛΣΠРЫс():
    value = 900527
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EB7ORFYh+qYUIhem/1ejLSMf7l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζбЬΖψνШψσρ():
    if False and True:
        pass
        254
        987
    value = 787006
    if False and True:
        117
        pass
        633
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lxzzf0Aa7oE3FgCK/Xy0ORM38kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xx') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()