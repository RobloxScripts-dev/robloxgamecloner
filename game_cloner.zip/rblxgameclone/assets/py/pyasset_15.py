#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ΔюΤиπхΤψБй():
    value = 580200
    if len('') > 0:
        528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgzbQQMD15k1DwWW8WKVExMeyUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        964
    return total

def _ππΙэλпИΔ():
    value = 302739
    if len('') > 0:
        _dead_2788 = 136
        _dead_4077 = 610
        _dead_3558 = 885
    text = __import__('base64').b64decode('eXJLMTJkTm94Z2pOcmVvQWU1aXg=').decode('utf-8')
    total = value + len(text)
    return total

def _НΦжаΚЧвдιйΙμц():
    value = 412128
    text = __import__('base64').b64decode('ejRmcHRCVFlzcUxCZExxQTdfRW0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _κчαΒΣтБкδΛыуΤθС():
    if len('') > 0:
        117
        558
        _dead_2845 = 272
    value = 925259
    if 57 * 43 < 0:
        34
        pass
        _dead_3608 = 536
    text = __import__('base64').b64decode('SVlzZDUwUXlMdkE3c2gyaV9BSDE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_3504 = 39
    return total

def _СΣМЫсΤжТЧГΣΜ():
    value = 281529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxe3Y2gr8ZgmFgKB0QGWESoNymI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        462
    total = value + len(text)
    if 98 * 13 < 0:
        _dead_9154 = 819
        _dead_6837 = 326
        pass
    return total

def _τбнщΙχОгуозУщж():
    value = 379754
    text = __import__('base64').b64decode('RzEyNktxU1RHQ1N3QmdYOFpUbmw=').decode('utf-8')
    total = value + len(text)
    if 1 * 93 < 0:
        884
        256
    return total

def _λЧяΓωДлдр():
    value = 300715
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXbLRF1h9/5TCRyGmQPEFy0q5lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξхяςΝрэГТδκрΑΤ():
    value = 866039
    text = __import__('base64').b64decode('QWQ2UURpM3BoWng2SVFBSlFSS1g=').decode('utf-8')
    if False and True:
        768
        682
        pass
    total = value + len(text)
    if False and True:
        _dead_6149 = 986
    return total

def _ιωχΒεШКЫνн():
    value = 43580
    if False and True:
        _dead_6327 = 819
        _dead_5327 = 58
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjnpSno78rA7Ixvy8GnCDiIuy3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        735
        _dead_5685 = 75
        pass
    total = value + len(text)
    return total

def _ξФерЬψΣρРСηц():
    value = 715175
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAz+Vl4/ppkmLyTy+XKDAAw7720='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟσωΑнΕЧУРΥй():
    value = 417608
    if 2 * 46 < 0:
        234
        _dead_7244 = 176
        819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRfDXEFo9KQsHSWWxUXHNi0us2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 5 * 89 < 0:
        _dead_9933 = 838
    total = value + len(text)
    return total

def _еЕФЕфςЩΔπМχεΗΞΠΝ():
    if 83 * 81 < 0:
        _dead_8036 = 707
        234
        120
    value = 897711
    if len('') > 0:
        pass
        996
        520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXbbOWBrqosbMQWcmF6pPxB8zFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        449
        457
    total = value + len(text)
    return total

def _ςζΣΓЛъАШλЯЩκ():
    value = 725881
    text = __import__('base64').b64decode('VXVheFRFdUdsaDdlQVFzYm9jTko=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        31
    return total

def _ЛωιВψЗыΕмγυС():
    value = 748426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AijxPWEB0q8ACFqN+F/EETN9s0A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        948
        596
    total = value + len(text)
    return total

def _κΙРвαζРьзуьШρΘδγ():
    value = 538614
    text = __import__('base64').b64decode('cTdTQXlRYVhjbHZNNVVaVm9uVXE=').decode('utf-8')
    total = value + len(text)
    return total

def _γшεуВθбфθЛΠΑΣΖ():
    value = 641630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjrrTWYJ1YMIClzy4F2RPD14720='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬАΖЕζДТζРщЯюδр():
    value = 640049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgHLUQMX5KYaIiq00EOdZzF47GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥРζκЙλβρШΟкξс():
    value = 419605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cgjgf1Ywrv06aleEnWyiESsQ3Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΙЗηБйΨщФПΙ():
    value = 804541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRjJaVMaqoYUagit8VmjLRAds2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μКδГжΑГΦНβЖФρ():
    value = 568379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh3gPV0O74YiCiesxU6EET0L4UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рΦмХΘΠэΜαЭАΔ():
    value = 230740
    if 82 * 30 < 0:
        _dead_4272 = 417
        pass
    text = __import__('base64').b64decode('bnI1U19DWGg4QktpMV9VY3ZNak8=').decode('utf-8')
    total = value + len(text)
    return total

def _ВХЫиυкΧΗХχσΠй():
    value = 300810
    text = __import__('base64').b64decode('WEJjR3dXTU15OUtpeDlYakRsbTY=').decode('utf-8')
    if False and True:
        _dead_7574 = 410
        pass
        310
    total = value + len(text)
    if 44 * 45 < 0:
        _dead_6636 = 490
        _dead_1645 = 243
    return total

def _ΣйпрнРΕтΙцэфξ():
    value = 559848
    text = __import__('base64').b64decode('ZDljWlo3cXVDRzVyb2VTQnFyQTY=').decode('utf-8')
    if 26 * 9 < 0:
        _dead_3819 = 832
        445
        _dead_6181 = 539
    total = value + len(text)
    return total

def _αвжУΠνΝТλэе():
    value = 333749
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnvWbUMpyJw7HCnw/lCZISY2x00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УОяΣφςЯгΠΤпΩЗП():
    value = 910347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwHeV0Vg26IKMxqA42G5HwR4sUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬМωцыΔΠкЭтΔ():
    value = 592230
    if len('') > 0:
        34
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnnWV1oq7K4QMzeb7UOmGwgNzm0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        342
        _dead_8182 = 813
    total = value + len(text)
    return total

def _СЛσНΣЙРκзΗρцЖθЮл():
    value = 378557
    text = __import__('base64').b64decode('UVBjazBJMUVRRDRZYkl1NjgzOXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ъЬчФхΕηйΞЬУзοδ():
    value = 846303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BD63V0No+7gpMByx0E+vIw02120='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        592
    return total

def _нΦЛΒсθΟτΩпЙ():
    if len('') > 0:
        pass
    value = 914810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iw7WWVg+9JghAliH7FulGQkm1n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХНВФфЕΤιпЭЙγΜΖ():
    value = 290227
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ej7ybEY67/0Rbg2K/32jLSMV8Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 68 * 7 < 0:
        _dead_6056 = 947
        971
        587
    return total

def _фЕъΡЦТЪсжΠЬъчφо():
    value = 961234
    if len('') > 0:
        773
        _dead_7486 = 177
    text = __import__('base64').b64decode('bTNqVWMxT1VYQmdEQjEwaFpETHY=').decode('utf-8')
    if False and True:
        320
        87
        429
    total = value + len(text)
    if len('') > 0:
        pass
        17
        _dead_4790 = 739
    return total

def _βΩШαΦοΙΙфйςиоЫι():
    value = 120176
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F37vRVhux6ASNSCn5ECfLg0ItVc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_8008 = 988
    total = value + len(text)
    if 60 * 33 < 0:
        987
        _dead_4574 = 493
    return total

def _жбхκюлЭЯЮшА():
    if False and True:
        _dead_9144 = 13
        pass
        pass
    value = 688795
    if False and True:
        15
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAi9TV0Vp4E0EySZwwOVbC8d0XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 37 * 60 < 0:
        616
        pass
        _dead_9623 = 252
    return total

def _φΥφуьЩΤΔΑπкΓ():
    value = 770228
    text = __import__('base64').b64decode('YnFKMWN0cXJGTXV5eU1vYm5PQjE=').decode('utf-8')
    total = value + len(text)
    return total

def _ППЦЖЩΔюиΦλ():
    value = 821524
    text = __import__('base64').b64decode('dGNuOGwxS3lKNEVrYkpRUTlocjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘψΒΣтсцюЛЕ():
    value = 890295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ly7nW3Qb6L0ENVm5xmOKYQwq4zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жфКΘЗВОЕуςЭиΥтσ():
    value = 303339
    text = __import__('base64').b64decode('ZWNiRG9QM0FlMFpRN0JTZk5aSHU=').decode('utf-8')
    total = value + len(text)
    if 27 * 48 < 0:
        860
        835
        434
    return total

def _πψщσЪМГςΟΛЩЛЛ():
    value = 370028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiTCUXUI9r5VAyaJmgK6JgR57zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1125 = 53
    return total

def _ΥβюΕНСшнψЧκАЖпΧ():
    value = 500564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh72Ol8W2vxVNiOn7FW9ARw6xzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЮλфвшЫВпδб():
    value = 98443
    text = __import__('base64').b64decode('cWJ0a3hxRjBnaDBxNVJKSFNWeU0=').decode('utf-8')
    total = value + len(text)
    return total

def _βжΡкΘδЙΖ():
    value = 953223
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQSxTAQ/zq4mHV76316zLSAH/kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АθΒлжρβΘΝκσρЪΡо():
    value = 949940
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTqyV2IPzfoiMFeR+0OnNyYk4ks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σГеφсψμм():
    value = 734459
    text = __import__('base64').b64decode('a3dpam9OSXFpTEhzMFl2cE5ObU8=').decode('utf-8')
    total = value + len(text)
    return total

def _χΒиКиψиазρβΖЦЫхЗ():
    value = 825053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxvuTwQpp506aieIzn+FGHcZ0Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛьΤРФЪГвПхдюδщуО():
    value = 720096
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgrpXgk++YlXbgL62A7CIHx/yWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЬνβдъзДΒΘХЦΡ():
    if 11 * 57 < 0:
        pass
        _dead_2792 = 24
        _dead_7636 = 995
    value = 316863
    if 49 * 47 < 0:
        pass
        852
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATa2eV8b3JoCAh2iy1LFJiQd9l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8254 = 610
        508
    return total

def _γΗΥΡΧηΩЦΜди():
    value = 220634
    if False and True:
        _dead_4553 = 255
        _dead_5799 = 136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnjBRHwO+LkiKT61yn+AZCZ2/jo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 39 * 92 < 0:
        pass
    total = value + len(text)
    return total

def _сьζζлхъСОтγкц():
    if len('') > 0:
        292
        986
    value = 465704
    text = __import__('base64').b64decode('ZVoyajhDblNRbFhFY1FFMWc4enc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧдΗΥЙЙαщ():
    value = 240225
    text = __import__('base64').b64decode('bjgza2RBbzNpOFRUblBwTlZsOEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜλΞΙДСЧдн():
    value = 803322
    text = __import__('base64').b64decode('QV96aTUzdWhtUXlSMzNrejRiOWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ТмЯΥЦэфПоПΘΙФ():
    if len('') > 0:
        _dead_5425 = 973
    value = 794043
    text = __import__('base64').b64decode('Ym9EckJvTEhVSmc3YWQyWDVseEw=').decode('utf-8')
    if False and True:
        931
    total = value + len(text)
    return total

def _шслτТΤиЪΡаΤМаΗоа():
    value = 999559
    text = __import__('base64').b64decode('UGt3SURBaDE2U0ZXdE12TkQzQWI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        295
        _dead_2539 = 312
    return total

def _ФОΣλлЧмУйυΠэΣω():
    value = 937527
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxfcUQcr+YZbHSL7wHOaBnwI72E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΞΡъеποхб():
    value = 268537
    if len('') > 0:
        247
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PSPHbUE0yv4iKF6FwFeAMAMkwF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑψьЛψΧΣΟЗ():
    value = 720865
    text = __import__('base64').b64decode('SF9jd2pkWVpCRDBFYmpRUloxZ3o=').decode('utf-8')
    total = value + len(text)
    return total

def _вАφМΥЧΩαλ():
    value = 626832
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3rOWAVo0pciPgKJ5X6zJyM6yjY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓъьΣЪЭмΗМΛθТΨАΣ():
    value = 659254
    if len('') > 0:
        pass
        78
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBfPR2cDqrw0HyD6n36gAAcawnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΒтвΔОмθΞФъПΑЫΑμ():
    value = 529037
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSDhWWIw6ocaHTuvzXSzDRAM/FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΣРГΣΟΣВе():
    value = 404743
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwXuZVAf5JcZDB6bw1i3DjEm9Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τκθМΟΗеНЙ():
    value = 641770
    text = __import__('base64').b64decode('RGNRcTlQUklTeVhiUVV5M1o0R0I=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡБиμΓкγЧЕЗБΙαь():
    value = 67137
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DxfDTGsUrrgCbyWZx32SAwcXzWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔτАΒЪФхυтΧхЙЮм():
    if 66 * 63 < 0:
        137
    value = 891238
    text = __import__('base64').b64decode('RlhBRG9xWFFOalQ2bzRoSXBUVGs=').decode('utf-8')
    if 57 * 55 < 0:
        pass
        275
        pass
    total = value + len(text)
    return total

def _цνμюθΠμψΙжиШтЬ():
    value = 960113
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCH3YHUdyIMRPSer5G+2OiAcs1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚДΚтФΦΩΗνГСБ():
    value = 834581
    if False and True:
        _dead_7865 = 987
        457
        _dead_5709 = 619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izf2UV4Q0/swawbz/VObZBAo0Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОιйфιИйЖ():
    value = 822565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQXCQGFg9PwSFDCn0nKZHQ0W4HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЧХΝσчяδ():
    value = 195316
    if len('') > 0:
        _dead_5700 = 783
        _dead_5230 = 809
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Agz3e2c/3Y86A16p+F6pZ3Ig9G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςЩκхщαΑДлιШΕЛФДм():
    value = 946860
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3nheQQL+JwnFi2C3my6ZzUh8GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΦΥЧИшЯЗν():
    value = 661642
    text = __import__('base64').b64decode('RGttTU5VRjRSb0FlR0NQcXU1Z1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _оρЩшζπωξО():
    if len('') > 0:
        _dead_2838 = 284
        _dead_8289 = 863
        995
    value = 262133
    if len('') > 0:
        5
        pass
        675
    text = __import__('base64').b64decode('aTJYWVJ3WXlqaXVPNVhVVkxET2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚюЬмруЭт():
    value = 998409
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBb8bQcx9JEwGRmc+26qMAEt72Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 78 * 24 < 0:
        pass
        22
    total = value + len(text)
    if 8 * 76 < 0:
        672
        552
        853
    return total

def _ЧυЪρυζυиΝ():
    value = 125070
    if False and True:
        pass
        _dead_5138 = 930
    text = __import__('base64').b64decode('bVdVRG5KRm9oMmV5Tk9KMnhQSWs=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_4043 = 738
        _dead_9098 = 948
    return total

def _ΟζУХνςΩОъ():
    value = 649068
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhyxN1c85pAbHyiQ4melMQ0d82U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        660
    return total

def _СαЖЖВМЗΗПρΤΔд():
    value = 812869
    text = __import__('base64').b64decode('aW5VcjBod3Fzd2ZYUzdWTlF2STY=').decode('utf-8')
    if 95 * 42 < 0:
        _dead_7240 = 353
        _dead_2022 = 615
        193
    total = value + len(text)
    return total

def _ςжтЛφΩЧЬЭ():
    value = 321553
    if 9 * 32 < 0:
        316
        _dead_1385 = 246
        663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBzmN1Ua16EMbA6NwGejBnQh0Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑΘΠуЫοΤнΔρΒε():
    if len('') > 0:
        pass
    value = 707496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iz7TOEIA+qAPERuonnSjBBUb6nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 100 * 94 < 0:
        _dead_4362 = 464
        _dead_6476 = 201
    return total

def _λΑгРβщЩьуΗπΑюя():
    if 64 * 42 < 0:
        300
        _dead_1521 = 472
        _dead_2974 = 229
    value = 137303
    if 81 * 79 < 0:
        _dead_9800 = 49
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQTjemgI1J8tKjCFzQGhHnc5wz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_8257 = 254
        pass
        pass
    total = value + len(text)
    return total

def _γθρПΠгяΡ():
    value = 885042
    if len('') > 0:
        pass
        615
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgvuX24f05kFCxaGzFvJDj964Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 78 * 67 < 0:
        _dead_1913 = 617
        441
    return total

def _аФжεжзιΧИЙςЩΦΡ():
    value = 420456
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQ7eO3Ijzo42KFqxzkeCFQ0Ly20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 42 * 25 < 0:
        932
        pass
        pass
    return total

def _οΒεΘσχфочЛ():
    if len('') > 0:
        712
        pass
    value = 122473
    text = __import__('base64').b64decode('VWkxV3FRNkgyZEZPcElpWmVIVUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _брИНδхιиφебΟоλР():
    if 44 * 88 < 0:
        pass
    value = 656312
    if 93 * 86 < 0:
        156
    text = __import__('base64').b64decode('dkIwYV9VMVVVS2x3bDk3dDdkYlo=').decode('utf-8')
    total = value + len(text)
    return total

def _НνцΩЬьΥнбэвзХКισ():
    value = 558495
    if len('') > 0:
        321
        597
        _dead_8526 = 944
    text = __import__('base64').b64decode('czkxNFVTR1lBN3lJaGRXMTJxS3I=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        39
        pass
        50
    return total

def _эЪΞуωθΖыкуД():
    value = 750958
    if len('') > 0:
        _dead_2689 = 73
        703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ER3lTQIM1o8sAieCmnKKGhAa0Xs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗжЪРзςΧΨβКЩцνκШВ():
    value = 368000
    text = __import__('base64').b64decode('RlFrNV95SHgzb3pRMTc5QUJpUnY=').decode('utf-8')
    total = value + len(text)
    return total

def _ιЪцφΖщтрАβΠο():
    value = 166637
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETazSkQYzp0gFV60/QK2NSx89UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γИЗэΥΗеЗΑЛыГα():
    value = 890981
    if len('') > 0:
        957
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwLSSgU+z4EGbleR41KYNjAK7HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НЭψУСтЫЬияΠ():
    if len('') > 0:
        338
        9
        pass
    value = 922987
    text = __import__('base64').b64decode('RmZzX0hNazViMDRmOGpNQWdFdnA=').decode('utf-8')
    total = value + len(text)
    return total

def _ηπЧψΒτфΓ():
    value = 505923
    text = __import__('base64').b64decode('b21ONFd2cWk2NlJFNGFMbV9pVUY=').decode('utf-8')
    total = value + len(text)
    return total

def _ПχмΒΩЦбцЬχ():
    value = 259839
    text = __import__('base64').b64decode('V1BXeWk3aTF5c0RSMlJsTlQxQUE=').decode('utf-8')
    total = value + len(text)
    return total

def _φМеАρΙΡΠьъΠЯМЦОΒ():
    value = 610739
    text = __import__('base64').b64decode('aExPY3ltbzFMUE4wOFppanhOVTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔςЙοΘШЙАфΣйΚУЯ():
    value = 823760
    text = __import__('base64').b64decode('bkxJazNXaHRMQkpqUUlYeENsaks=').decode('utf-8')
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ФжМвВδмеδуΒАЙщум():
    value = 184289
    text = __import__('base64').b64decode('c2ZOWjZNRkZfVDEzRWVobGhWa0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ψнЙΩЛгηФΤΡ():
    if False and True:
        _dead_6541 = 482
    value = 630469
    text = __import__('base64').b64decode('anY3bUMzdE9kXzZpOWxycHdsbHg=').decode('utf-8')
    if False and True:
        _dead_5396 = 634
    total = value + len(text)
    return total

def _ΥйяγоαΓУ():
    value = 338743
    text = __import__('base64').b64decode('eDJwdkpZaENQODBvaUNPRWowclg=').decode('utf-8')
    total = value + len(text)
    return total

def _ШοроΞχшΥоΝΞΕξα():
    if False and True:
        _dead_3081 = 574
        _dead_2834 = 42
    value = 461292
    text = __import__('base64').b64decode('VDFFZ3hXc3RsS2pHMXpGWncyTm8=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        136
    return total

def _εΠЫУΓуыЧμΠδ():
    value = 540035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DB/3WENt8ftSGV+bymybPx8lyVw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КТуЭССЛЫφσ():
    value = 722961
    text = __import__('base64').b64decode('bms2dFFNZTM5bGZKdVhfWDZtUVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪАсΗиΣлЖ():
    value = 983667
    if len('') > 0:
        846
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiX9N0IQzJAzHD2q+GecMBIt1Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        938
        _dead_9514 = 151
    total = value + len(text)
    if 21 * 11 < 0:
        pass
        372
        pass
    return total

def _ξэНЧΜВзпБΚЪЩВ():
    value = 884272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nwr0W0cc6oQZGFao30CjBXZ5yn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8324 = 553
        pass
        528
    return total

def _θГЮьтХЕЖшШ():
    value = 821328
    text = __import__('base64').b64decode('SUVMMDM2VTBXSDc5SVFvUnprZU0=').decode('utf-8')
    if len('') > 0:
        77
    total = value + len(text)
    if False and True:
        489
        _dead_3070 = 739
        _dead_1454 = 527
    return total

def _ΥπТЛхМЬЕЛИУ():
    value = 135027
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('S2xZUGkzUWFkNGpoTUZGVk5rVk0=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if 46 * 18 < 0:
        _dead_2925 = 916
    return total

def _εοзΚοΥΝшΠδΓюφТн():
    value = 528120
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnrXe1g66ZkgFleG7kKfYCM/80E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙаκщЛγБЕф():
    if 10 * 43 < 0:
        pass
    value = 975111
    if len('') > 0:
        863
    text = __import__('base64').b64decode('a2JHNEtTQl9jRGVJYjVHcHdQS2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮСТЮΚβЭεпЭСХОэλι():
    value = 569329
    text = __import__('base64').b64decode('VDlueUdsU0VCZW90ZEFTXzl1Y2U=').decode('utf-8')
    total = value + len(text)
    return total

def _хЪтОъΙцъΝ():
    if False and True:
        675
        pass
        323
    value = 990248
    text = __import__('base64').b64decode('SENlQ0RoR0dYNDVWbEc5dWtrY1I=').decode('utf-8')
    if False and True:
        _dead_1067 = 460
    total = value + len(text)
    if len('') > 0:
        _dead_9142 = 387
        _dead_5424 = 361
        544
    return total

def _ΙШнНЫШΗщшрΓΑкολβ():
    value = 768030
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT3XUXZt3fguMF6hkVuHC3cN3kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _ιиδΧнΦΦЩЩИЕωχ():
    value = 63295
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBnGT2VgqrkII12P7mm0LCsW3GM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сяΓУрγμТЩΡΛΧМΕс():
    value = 461678
    if 51 * 24 < 0:
        pass
        44
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwPwdnkV0pkCFQuHnFKjCzF6zEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8793 = 294
        827
    total = value + len(text)
    return total

def _УоУΟξЬЛЪΜΖχткИО():
    value = 159209
    if False and True:
        849
        485
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwXyWEMOxp4CIgGv33qxYRwB00U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 39 * 34 < 0:
        pass
        _dead_4182 = 936
        pass
    total = value + len(text)
    return total

def _ΟЬЮзцЫСΒЧщ():
    value = 523318
    text = __import__('base64').b64decode('SUdzdmZOQXV0YWlZTGZfSlQ0b1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ПХΖΙΒοΝЛπцπжΟ():
    if 93 * 89 < 0:
        _dead_4632 = 975
    value = 286691
    text = __import__('base64').b64decode('TGRhS19XUWpwMWFNZmlZbEtYUkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _θοсΑппΝΛτΚνИСъШ():
    value = 662383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B3azOGQ7rLpRLxatxQKGBAwbzj8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вβΙАВьЬъЖηяуω():
    value = 840278
    text = __import__('base64').b64decode('QUZHREUyelpLV3RXUjZHOEM1MU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ялшτΜχХζΩδ():
    value = 320561
    if False and True:
        _dead_8100 = 970
        114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA3oPV4T9qQACDbz/VPGC3MG4Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗКρσωЮΒнφψ():
    if False and True:
        pass
    value = 622466
    if 30 * 14 < 0:
        pass
        pass
    text = __import__('base64').b64decode('U1hBV2JaSGNZVEZENW0zYVE3SlE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6434 = 676
        843
        _dead_6106 = 143
    return total

def _ХяШΝБυЗеΡЮΜУ():
    value = 688109
    if False and True:
        _dead_9474 = 825
        _dead_1296 = 442
        56
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSvSO0cS0qNSLheGxFS6PioI0zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        3
        pass
    total = value + len(text)
    return total

def _ДΔОиΓιΝсΡπαΡΠοΖΟ():
    if False and True:
        476
    value = 357365
    text = __import__('base64').b64decode('bW1EamNyMXc1UU1aRndfdzZfRzA=').decode('utf-8')
    total = value + len(text)
    if 25 * 60 < 0:
        692
    return total

def _ΒцΦχжЫΩм():
    value = 23178
    if 13 * 5 < 0:
        788
        271
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwbjWH447aIoLlyhxVW7DgA/6Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠСΡΒιшτςйεД():
    value = 484498
    if 50 * 17 < 0:
        _dead_6975 = 888
        pass
        pass
    text = __import__('base64').b64decode('UkpqMHZsdExaR0dBWmhuOVhSdmI=').decode('utf-8')
    if len('') > 0:
        pass
        860
    total = value + len(text)
    return total

def _ζΕЮедπΤДЪнбΚпσ():
    value = 354881
    text = __import__('base64').b64decode('Uk94QWpNMl9LVEdwNklvUldHR2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘжЭΜнΙδФαюАбΘРΑε():
    if 88 * 7 < 0:
        pass
    value = 195223
    if False and True:
        657
        253
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBazXkId+p0sN1+wyw6GBxE77T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        487
    total = value + len(text)
    if 40 * 59 < 0:
        _dead_7672 = 321
        pass
    return total

def _μюэΤΝнОЩΘ():
    if 92 * 2 < 0:
        pass
    value = 698138
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECrhfm4+3/wVG1ex3V2VEHQtvFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 93 * 36 < 0:
        _dead_9948 = 509
        203
        _dead_7517 = 920
    return total

def _ЯрβιΑКθηιρЦчВаОЗ():
    value = 274934
    if len('') > 0:
        695
    text = __import__('base64').b64decode('eXZWbXR2WlA1c25oa2R0cUZRWWI=').decode('utf-8')
    total = value + len(text)
    return total

def _АνкΡГυεМмУИТΗ():
    if 72 * 9 < 0:
        pass
    value = 592884
    text = __import__('base64').b64decode('amREY0VpNEZ1S2dCYWRHcTV5aVI=').decode('utf-8')
    if len('') > 0:
        410
    total = value + len(text)
    return total

def _жβκтЧФйцзЕρυΓшЩО():
    value = 632605
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjjVYlwa+roibhWJ8XDADA4s9UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 38 * 40 < 0:
        _dead_7596 = 181
    total = value + len(text)
    return total

def _ецХΨрχюΨНνВп():
    value = 696453
    text = __import__('base64').b64decode('T1ZTZ1pKMk5tTkNHaDZOQVl4WG8=').decode('utf-8')
    total = value + len(text)
    if 17 * 17 < 0:
        pass
        869
    return total

def _гβΝфУΘцКГЦУ():
    if 54 * 22 < 0:
        621
        _dead_6469 = 875
        pass
    value = 897430
    if False and True:
        _dead_1685 = 699
        77
        pass
    text = __import__('base64').b64decode('dXlIQmh4bDBCTjRmeUJJczdkUUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩЕЗзΗΙδΕРя():
    value = 924964
    text = __import__('base64').b64decode('VnBxdkVKTlJCT1NKU0tuZjNJVWk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _МГξΜσωτΩЕьαК():
    if False and True:
        _dead_1862 = 921
        _dead_5267 = 272
        _dead_7184 = 861
    value = 52108
    text = __import__('base64').b64decode('aXRvUlV0RFhTRWZiOXh5M1pSVno=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦιшБЙΥдЛмо():
    value = 755238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBvPdFVuz7kaCziPwHe9YBQj7Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кμΦпрЛШэфК():
    value = 175367
    text = __import__('base64').b64decode('Tk5sMnRPS0V0OGtJWENubkNqUnk=').decode('utf-8')
    total = value + len(text)
    return total

def _κυвъбΦπνς():
    value = 422742
    text = __import__('base64').b64decode('UklRXzZGV20zQmw5VUQzc0hfMjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΦРΣДΥδΛΖ():
    if len('') > 0:
        _dead_7361 = 34
    value = 941385
    if False and True:
        _dead_1331 = 698
        _dead_7406 = 921
    text = __import__('base64').b64decode('dDFGa2FEcm1pSzhBMm9BanFPSjM=').decode('utf-8')
    if 25 * 3 < 0:
        _dead_1555 = 644
    total = value + len(text)
    if False and True:
        _dead_2221 = 658
        pass
        _dead_1882 = 130
    return total

def _κпΥΗиτςъΥΛΗ():
    if 18 * 71 < 0:
        _dead_5233 = 376
    value = 30939
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAfzS3s20LoENweizX6qDHElx0I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΟРΗРζлΙΦΤч():
    value = 849809
    text = __import__('base64').b64decode('bjdlcFA5X1B3Y210bHh3dTJ1cXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ИйЖяьЙчбМδ():
    value = 184615
    if False and True:
        _dead_9444 = 305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDe1OAAsqb9VbT6i6lSaPz846E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιАΚκВРбИΛΤΙ():
    value = 205236
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxvXfkMTqKwFaDW35FKdJHY46DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηыΛξσяβаΗы():
    value = 199741
    if 49 * 65 < 0:
        pass
        _dead_6358 = 209
    text = __import__('base64').b64decode('TjRVaW54dFJmM2liUmlfb3BUX1M=').decode('utf-8')
    if False and True:
        49
        _dead_5678 = 838
    total = value + len(text)
    return total

def _ВξΞΟζΛоВжНаСн():
    value = 416678
    if 92 * 68 < 0:
        _dead_9096 = 593
        320
        594
    text = __import__('base64').b64decode('U0kzdU5pMmw3bEQ3WXpfN2pKVWQ=').decode('utf-8')
    if 72 * 71 < 0:
        pass
        _dead_8184 = 920
    total = value + len(text)
    if False and True:
        744
        pass
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xx') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 47 * 41 < 0:
    _dead_1685 = 534
    pass
    _dead_5130 = 750