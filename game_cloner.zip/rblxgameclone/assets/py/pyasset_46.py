#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΗнψτгΙλнЕΙК():
    value = 612162
    text = __import__('base64').b64decode('d1l6UHFLYW9TdFpiWXBTRTBob2U=').decode('utf-8')
    if len('') > 0:
        62
        117
    total = value + len(text)
    if len('') > 0:
        _dead_7700 = 173
    return total

def _ΙΤуЩΕФЛэλЭЦΣΖц():
    value = 585701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyOyYWIRpqYHbTv22HqEIgkevFw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        792
    return total

def _мХТΟςрοζЛпщ():
    value = 10847
    text = __import__('base64').b64decode('R212TDVEQ1NHeHlUajJBaUpVRlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥψΒΛРзΑЖдΓ():
    if False and True:
        pass
        476
        944
    value = 109871
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzjyZGA6r5kHKCL1mWmaYnIKtD8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧΝΑжртДаЕ():
    value = 100069
    text = __import__('base64').b64decode('UzI5ZVZKaHU2RHdRVEZGUnpFVUg=').decode('utf-8')
    total = value + len(text)
    return total

def _УρθΦФФΚηδΖцЭ():
    value = 986317
    text = __import__('base64').b64decode('aWJ0R2FVMXFoNm1FeTliaVVsUUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ηфФэΚФМхΝΕциЙΖγ():
    value = 475758
    text = __import__('base64').b64decode('Tk9JMXBia0RtUmJ0Z2JKYnQ0TUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΖРεξΒΚЧβгГγГК():
    value = 585549
    text = __import__('base64').b64decode('b2NFMG85d3hPRnJDaVR4ZFByTzU=').decode('utf-8')
    total = value + len(text)
    return total

def _μψβыνТπωщбГЮοС():
    if len('') > 0:
        _dead_2867 = 726
    value = 830020
    text = __import__('base64').b64decode('bDdQZ01ReFhVQXBvNlVkNTZhaFE=').decode('utf-8')
    total = value + len(text)
    if 98 * 29 < 0:
        _dead_2831 = 610
        181
        pass
    return total

def _КλьХпМЙΝлтΝЪ():
    value = 338986
    text = __import__('base64').b64decode('TnJScHFuOTZTcnBRejhsY3lUWHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΜΣΟλтАΘЪяР():
    value = 799574
    text = __import__('base64').b64decode('RDd2TjVNWkh1ODlLejN2UWpZeU8=').decode('utf-8')
    if False and True:
        _dead_5870 = 773
        pass
        114
    total = value + len(text)
    if 75 * 82 < 0:
        829
    return total

def _СХеюΚзмжβιЩΙЛГ():
    value = 23258
    text = __import__('base64').b64decode('bUNTdldpRFR1X1FZZGJVb0hjUjU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖκуНΝЧЗΑб():
    if False and True:
        289
    value = 497396
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzrNY2hhxKArMlqnw1LIBg0eyDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φАφЫЫшяъУαеФ():
    if False and True:
        _dead_6056 = 84
        100
        _dead_6009 = 244
    value = 968014
    if 99 * 59 < 0:
        _dead_6184 = 155
        pass
    text = __import__('base64').b64decode('UkIzNVFDdF9Ud1JJb2lQMHpHck4=').decode('utf-8')
    if 83 * 99 < 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _φΗσΒЛЧеμ():
    if 23 * 43 < 0:
        678
    value = 391555
    text = __import__('base64').b64decode('V3lQcTBqSEFLVmlBVnkxTXpNeTY=').decode('utf-8')
    if 96 * 6 < 0:
        _dead_6527 = 197
    total = value + len(text)
    return total

def _лΒβκζЯШχъВοлΦΨο():
    value = 823921
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FATMRVweqINXPTCgzWSyBw4o1nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 35 * 73 < 0:
        _dead_4060 = 85
        _dead_5849 = 179
    return total

def _πчΦκИЛςΖЦΡмЦΠчя():
    value = 336196
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('ZVZ4eTlsZkdyblNHV1kwTGVyTDI=').decode('utf-8')
    if len('') > 0:
        407
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _тАыПЗθΙεд():
    value = 934844
    text = __import__('base64').b64decode('ZV9IaU42RDdSOWhrVWpaa081Yl8=').decode('utf-8')
    if 52 * 79 < 0:
        _dead_9157 = 59
        112
    total = value + len(text)
    return total

def _ΣΧоегюΝгΑОΝοΡЗЖλ():
    if len('') > 0:
        610
        976
    value = 266548
    if len('') > 0:
        651
        pass
    text = __import__('base64').b64decode('ZjBISE93X1c1b0lZN1RwckNLbWI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_9804 = 218
        890
    return total

def _ФΥуγиоЭтРηАΕ():
    value = 111239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH/JQkQj1aFTKiqN+FqxP3F81Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 8 * 97 < 0:
        pass
        966
        _dead_4193 = 640
    return total

def _ЙЪмаЫΦδоЕζ():
    if 24 * 66 < 0:
        pass
        8
        pass
    value = 275640
    if False and True:
        _dead_2441 = 284
        _dead_3418 = 732
        991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTq8S1M/zIEkHDy561K2MA8E1Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κψарΖЩмзчΧИцц():
    value = 654156
    text = __import__('base64').b64decode('dzFDYk96SkNGX1lFTmtUanBVVGo=').decode('utf-8')
    total = value + len(text)
    return total

def _мΚЭюΛΤγЩ():
    value = 633963
    if 70 * 59 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRzsZGEY/IAMOQqQxGa+GBYkyVE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤыασжгΗшЛымΔΛ():
    if 40 * 9 < 0:
        287
        pass
        446
    value = 685306
    text = __import__('base64').b64decode('U0JVMWcxUDRGYlc0d1JKWXNEYkw=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9453 = 613
        920
        _dead_8563 = 51
    return total

def _ωысбΕжτρУΠψ():
    value = 539909
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyXOfGsQ8boqal2B91OELi0B52E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪφηΞυαζНрКζ():
    value = 369476
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB/SZAUT3Zw1LViAwGCpGh8Jt3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИпЕΡΩюнйнфστдь():
    value = 646120
    text = __import__('base64').b64decode('cjFWVFk4ajc5V2FrZzlidTFuMzk=').decode('utf-8')
    if False and True:
        _dead_7318 = 454
        612
        _dead_3316 = 482
    total = value + len(text)
    if len('') > 0:
        _dead_9298 = 507
        _dead_6751 = 883
        _dead_2294 = 744
    return total

def _гЗпкПδСΚяπρгЯΛ():
    value = 968143
    text = __import__('base64').b64decode('aWtvNkZKWWp2UE9Qd3R0ZHhKUHk=').decode('utf-8')
    total = value + len(text)
    return total

def _РъйМΧрΟПАэлЫΦ():
    value = 42622
    text = __import__('base64').b64decode('UU96ektmRUh5TEc4Q2xoTHpmX04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚтκЩЯυщЯЖΦкΔ():
    value = 975976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXyxXwgRr6smDw6J60S2Bgwe50M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΛЯНΞПХХκαмιΕцЯΚ():
    value = 977806
    text = __import__('base64').b64decode('ZWRPSGlGY25mcDc5TDlRejIzVGU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭСΠзρГΩшδКЬКюбЫ():
    if False and True:
        _dead_5567 = 751
        _dead_5687 = 631
    value = 657163
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JizRV2cf3LJXAyih2ESjMh8i7zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВьΤкΠрληтυЧ():
    if False and True:
        _dead_8801 = 953
        pass
    value = 19065
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCzcfHoG8Ks8Mg6X5HqKLDwD4D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γюΧДУаЖЪΗΙαχхпаТ():
    value = 92087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KA60dGcz+vEvEQGb8XmSJil4/Gg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αγθаΩΓтчΩ():
    value = 672188
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBDRP1cTrJkBGwquw0WdETAW9kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2447 = 1000
        pass
    total = value + len(text)
    return total

def _агχЗнλΣθΚκΑща():
    value = 176065
    text = __import__('base64').b64decode('eW4wSWdSYWVaOFk4cEhpdmJMNms=').decode('utf-8')
    total = value + len(text)
    return total

def _аΩΜΥдαΣтхΧзмΔ():
    value = 611460
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax6wenQD+qkUEzqCwnKBInEe0zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙψЯαΟΨΗδΤ():
    value = 482293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQDyTX4Wx40XOCuH5XGyIRwh/kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪЙЩВξЛжλЩ():
    value = 967842
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXjCbGYW64cpDzevwFCDZCt/ylk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фцΜψρзГьп():
    value = 180290
    text = __import__('base64').b64decode('bjFzWkc2Z3ZTR0RJdktrNWlNUHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘмУΨΓλЮыΞΨΛутψκρ():
    value = 172821
    if len('') > 0:
        227
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CH/HTFkw+b0iYie662K4PCsnxWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3220 = 792
        pass
        pass
    total = value + len(text)
    return total

def _ЧхпΛмШЯΦΝГхλю():
    value = 8555
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ljb2eglsq5kAPza2zXDCZC4+sVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъΣМοΘЗξΦΙΓΞНмκшф():
    value = 120213
    text = __import__('base64').b64decode('bE9uNXJfQmlNMmwzWXlfVXFFSDg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_7962 = 645
        _dead_2816 = 562
    return total

def _ΨЮъΛЗψКЮт():
    value = 708533
    if len('') > 0:
        pass
        _dead_8805 = 403
    text = __import__('base64').b64decode('VEpJY1VUTDNORF91MlNDcHRJRmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠлиΝуΛωШькΘθΟИ():
    value = 823255
    text = __import__('base64').b64decode('SkcwdkxhOHh0ck1BUDZPQlNNR0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΝЙΘэПЕεθзЪнυωы():
    value = 797162
    if len('') > 0:
        _dead_6094 = 446
        pass
        _dead_3745 = 756
    text = __import__('base64').b64decode('b08wdnJlamdHb2cxSFBWT05sNmY=').decode('utf-8')
    total = value + len(text)
    return total

def _θΣππΡыЗяΨΣО():
    value = 117483
    text = __import__('base64').b64decode('WW5GNXBDXzRBVm5naXc5MXdnVEU=').decode('utf-8')
    total = value + len(text)
    return total

def _лКβωщπНцνуχ():
    if len('') > 0:
        564
        _dead_7102 = 190
    value = 183236
    text = __import__('base64').b64decode('aTVNR2habWo1S3piQW03ZEFUQ0Q=').decode('utf-8')
    if False and True:
        45
        6
    total = value + len(text)
    return total

def _ξАЙιЕЬθТЙчЮбσ():
    value = 375750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiXsYVoM3/AOAz2q93rDJB0753k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 28 < 0:
        pass
        772
        _dead_4512 = 210
    total = value + len(text)
    return total

def _ρОпΦгΩΛθξΠыгλ():
    value = 753696
    if False and True:
        _dead_3770 = 770
    text = __import__('base64').b64decode('aWNLMmtLVU5KTjR3aVhpaGc4Q1M=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_3690 = 526
    return total

def _ωоσУυΒΡΒυφйЪΔдЛД():
    if False and True:
        _dead_9661 = 243
        pass
    value = 929026
    if 86 * 34 < 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXf+XEMd5rsMKyWh4kK8Nn17sk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡθψνзουЯυ():
    if 100 * 7 < 0:
        _dead_5084 = 832
    value = 670312
    text = __import__('base64').b64decode('aG5yelNTU3cwNEJia01TR1FCZk4=').decode('utf-8')
    if 34 * 38 < 0:
        907
    total = value + len(text)
    return total

def _вςжэЯтьЧРЧΦ():
    if len('') > 0:
        816
    value = 6342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTXeV1U6wZkVESaxmVyTPiIe/Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 10 < 0:
        264
        779
        268
    total = value + len(text)
    return total

def _чπкЗραЮΟΗφА():
    value = 802044
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgXxVkBg2LgGBSeM2UC9C3UN/nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 82 * 54 < 0:
        pass
    total = value + len(text)
    return total

def _щщзκΣΘΒΡзь():
    value = 80505
    text = __import__('base64').b64decode('ZGNxVkxZSm90Qmk3MkE2UGdyRzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЧξΦγΧγΤΔκδяμГСН():
    value = 170466
    if False and True:
        pass
        _dead_9961 = 178
    text = __import__('base64').b64decode('ZVBxVXVGYmRRRW8ydUxDQVU0VEc=').decode('utf-8')
    if 8 * 24 < 0:
        958
    total = value + len(text)
    return total

def _рЧΥΞЪйдΒкβхЧЭ():
    value = 464976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgjmWwYozbAgPTChyweUBCsczXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΑПмлοсαОФРзμАκш():
    value = 480583
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwS1X1YW3KEiLRycmXKCO3Ypwmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_6473 = 137
        pass
    return total

def _αЛδщСкψЯ():
    value = 348367
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTWzWwQR6LsVPQiunQSnOQgD9jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫσΗЪητждВэΖббηщЕ():
    value = 793786
    if 15 * 43 < 0:
        pass
    text = __import__('base64').b64decode('Ump3aEp3OFV3WGZVYWJ1UWhhYUk=').decode('utf-8')
    if 86 * 52 < 0:
        878
        pass
    total = value + len(text)
    if 17 * 57 < 0:
        pass
        586
        pass
    return total

def _ΞЕρЮΗдФшЩΩк():
    value = 7482
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChzbP2Ea358iAja1kV+HIy8B0Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        276
        927
    return total

def _шрсγАиМШПЖЭю():
    value = 889985
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwHtZEQ3+KIIGyix7EexIycrym0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕΤкзАΩбМ():
    if False and True:
        pass
    value = 873693
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADvGXEAB3IcOayyo0lWJPi470n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬАЕОΣςΡНьгλ():
    value = 524182
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ez7RN3Mcyv5RDSCJ+HyZHHwlz0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лγхшΕσκкиΦΡΨАБ():
    if 55 * 3 < 0:
        pass
        326
    value = 439577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQXBQgQB8r5XPTyww2eiDBEX3kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6272 = 692
        964
    return total

def _ИйδЫокςаφΘосκχΖц():
    value = 815416
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxnvOnpoqYw1FwKF61SFZQka/UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жρΣΕαοиУθβΗ():
    value = 811507
    if False and True:
        pass
        _dead_1164 = 865
        130
    text = __import__('base64').b64decode('RG1hd2hWOHFibHlkN1BuQjJFQ3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΔαйНАΚКЕΧЖЪ():
    value = 869030
    if 56 * 58 < 0:
        _dead_5310 = 620
        _dead_3576 = 592
        _dead_3211 = 739
    text = __import__('base64').b64decode('VlpmT2dlRFBQWmF2N0JLTjdwM20=').decode('utf-8')
    if len('') > 0:
        644
        _dead_2423 = 469
    total = value + len(text)
    if 70 * 97 < 0:
        _dead_5787 = 390
        14
        622
    return total

def _ЗХЧΥЭДлтδЮρЩНлζ():
    value = 720977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRnyXF8hqYpaaS2g3XmIIR8uw1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΝιξβДьЯЧуХДФ():
    if 36 * 84 < 0:
        pass
    value = 159377
    text = __import__('base64').b64decode('TThONmVFa3IwQzJrZTdUenFoVXM=').decode('utf-8')
    total = value + len(text)
    return total

def _αПЙнеыРЭ():
    value = 679185
    if len('') > 0:
        397
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyPgRHUM7f4PCyvyzmGbZR0atF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_5391 = 733
    total = value + len(text)
    return total

def _этοΣνИαЬььЧМШЪЕ():
    value = 196130
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('TDR1OTFlb3l5MTRHQ2lESjFraVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧрΥΛυΖЖЮб():
    if False and True:
        _dead_1757 = 218
        _dead_9938 = 972
    value = 90084
    text = __import__('base64').b64decode('eEQzb1B6UUhBQUN4UWpfbFpkUVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ςЫΧηχФεЯйΡМецρТο():
    value = 486706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSbAbGY40bAvKB6CnlC8FS4H0Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭмжЦΜжθуδΤΟΠφщн():
    value = 269805
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwHiPnMh3f8kEQC7nXeRInx3w1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΨΚЫοΞΘсЭФσΡ():
    value = 175211
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IT62XVsR2rERKCyJ52KhEBE87kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьгРΚбπδЩςηКΨπβ():
    value = 385266
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDXxOEhq3588Hye5w0aaDh8Cxjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞμΝщЯμΗΚΦ():
    if len('') > 0:
        pass
        _dead_4732 = 85
        pass
    value = 614879
    if 91 * 10 < 0:
        682
        pass
        752
    text = __import__('base64').b64decode('T2M4T2l1X1l6N0F2NTlOaFVhenc=').decode('utf-8')
    if False and True:
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_8529 = 476
    return total

def _ξΓюΧчΜЦНжнΧ():
    value = 130011
    text = __import__('base64').b64decode('ZWFfd0NMYktiQ21HVDM3V1d3OVk=').decode('utf-8')
    total = value + len(text)
    return total

def _НиУПΜйΞΧаГяΤц():
    value = 590727
    text = __import__('base64').b64decode('ZWp3TWNsU1Y5QXhyMFRiWlo4cWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯΞИпЩΞожйβ():
    if False and True:
        385
    value = 130178
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXjTZHop35APEQuZ70C1EwQW1Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΔзСвИйγ():
    value = 347911
    text = __import__('base64').b64decode('ZzRld1BKQmJyYXMxdzk1SEd2QVA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘτМΦЭρΛζД():
    value = 732896
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSLJdlk6941QNT6pzGGiARQBxkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠνЦθδЖыЪβλωηЫКж():
    value = 287063
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fgu3P3oPq6YLDlm04nW7GykKzEU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 75 < 0:
        pass
        _dead_6445 = 192
    total = value + len(text)
    return total

def _ΠμжΞωдЫΡγдкα():
    if len('') > 0:
        278
    value = 557099
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('T3B5NkRTWEVWMFZTdm1FM3RaZ0I=').decode('utf-8')
    total = value + len(text)
    if 71 * 48 < 0:
        pass
        _dead_6457 = 282
        pass
    return total

def _еОρНυВΤΣшЫ():
    if False and True:
        _dead_3861 = 62
    value = 463680
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjjHdl84yZowGAeF2UaUHnY782s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λδюЕΖβцΦЪγΩ():
    value = 912060
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR/lPWJg7KEECyC6/w6SGnN68m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2588 = 588
    total = value + len(text)
    if 16 * 14 < 0:
        _dead_2914 = 586
        _dead_9056 = 608
        _dead_4731 = 711
    return total

def _ΦΜξтΥдСυхΩЪφζμЕ():
    value = 409628
    text = __import__('base64').b64decode('UFlFUmtENXVtMXM3VE1LYkY3MmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥьΩЪΘΛдюΑСΩ():
    value = 175110
    text = __import__('base64').b64decode('UHcxb3RvcGc5MFZ3d3hUZTRySHo=').decode('utf-8')
    total = value + len(text)
    return total

def _ФэйεΒЩαΧφΧКлНхО():
    value = 79757
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwjhQQAP9bovMj+XmlGEDnEk71Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 53 * 92 < 0:
        _dead_9197 = 752
        _dead_7346 = 627
    total = value + len(text)
    return total

def _ΘнТΚΒЧκЦΣййыуа():
    value = 482175
    text = __import__('base64').b64decode('UVFMSXQ2VXJWb3lHekRvTEs4VE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞЭЭРБωΒБ():
    value = 773193
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQfwO0cv+IcnM12Q8UGCZTM6/F8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОХШйгχδН():
    value = 642638
    text = __import__('base64').b64decode('cGNfTmMyeEVuVjVLYzl4MUc1WWU=').decode('utf-8')
    total = value + len(text)
    if 52 * 46 < 0:
        _dead_6927 = 461
        _dead_2897 = 663
    return total

def _ΥΥβяΟмςςп():
    if len('') > 0:
        pass
    value = 651841
    if False and True:
        466
        _dead_6055 = 477
        _dead_7230 = 38
    text = __import__('base64').b64decode('R0ZibU1rcllCTTZXX20yWkhVVGs=').decode('utf-8')
    total = value + len(text)
    return total

def _мЗбвτπΤΝчνδ():
    value = 135703
    if len('') > 0:
        pass
        _dead_1130 = 388
        986
    text = __import__('base64').b64decode('YXVDWG1IZzM5dkpOa1J3eVlncm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓζнΨЙΝπдэЛ():
    value = 645966
    text = __import__('base64').b64decode('c2R2ZUZhVnNkWF9BQzJjOWcwRnE=').decode('utf-8')
    total = value + len(text)
    return total

def _χДψеΑχТΙ():
    value = 752264
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTiyVHQ/36AnPi6c+QGHAiEX1mM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔщЭяыЮΗикμ():
    value = 904776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyTDVmQq14NaLhmu/lK+AnA2s3Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮроИбцΟовβΩωЪфФЮ():
    value = 688441
    text = __import__('base64').b64decode('T0RSUG45eDFWVXQ2ajJKbmdCNTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞφэΒΞΥψюΖΓшфс():
    if len('') > 0:
        120
        _dead_3420 = 928
        _dead_6228 = 449
    value = 217114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jh7OO34d/4ohNyOZ5lvGIzUV12w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 33 * 41 < 0:
        pass
        _dead_3521 = 725
    return total

def _ХγЙмΙεЮαυςιТс():
    if False and True:
        _dead_1275 = 475
    value = 498778
    text = __import__('base64').b64decode('bGZta0preTVtakVBU3BzN3pXUWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΣХФезомβЛ():
    value = 501842
    text = __import__('base64').b64decode('U2pFSXJrcnFHTFVqaDhYRTlxY3A=').decode('utf-8')
    if 33 * 10 < 0:
        pass
        66
    total = value + len(text)
    if 70 * 70 < 0:
        _dead_6978 = 731
        pass
    return total

def _юψΔενψэв():
    value = 124681
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAfeZ0AUxp0tClr2z2CDLRw5wDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯαвΡуПжщэΣ():
    value = 771933
    text = __import__('base64').b64decode('aGRaX2RkZXFFOGxLa2hobEZhdzI=').decode('utf-8')
    if False and True:
        _dead_2418 = 337
        pass
        _dead_3213 = 326
    total = value + len(text)
    return total

def _υяпζыЖпσΣФθтшΛΨ():
    value = 595260
    if len('') > 0:
        _dead_6064 = 644
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXvSOmtu6LA2Yh+k5U6EBCss6Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘπΥαэЩЕΔωΜФФВυ():
    value = 803195
    text = __import__('base64').b64decode('VEJTQkxPV0dpTWJZZ1lFZDltMGw=').decode('utf-8')
    total = value + len(text)
    return total

def _рчЦУтψрНзХдΔУуΧΒ():
    value = 676262
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDvAbHUU8J8WGQCn6USROy0C/kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αйΜЮΕЖΔρπЬΤ():
    value = 934510
    text = __import__('base64').b64decode('aG1EdlBVRXhJV0RfT1hFVU43ckY=').decode('utf-8')
    total = value + len(text)
    return total

def _схчЮΖΠлаДЙнΨыφНξ():
    value = 495507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CB29fAE49P9QL1in21C6AT8W9kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АДТσрцфφсΠ():
    value = 624995
    text = __import__('base64').b64decode('WWV3eldtMUs0andxa2FyNHpfNU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ρИЕуΟΕοσнкшхΧ():
    value = 894860
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQL2V2MJp7AZLzCwx2WGbAB6/kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥιЕявуЧЮЦΠЫ():
    value = 605266
    if len('') > 0:
        pass
        _dead_7419 = 292
        287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHn2Y2Vr8pBVDliZyUSZJRMLwjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эждбЕЕХΨΑχЦξΓπ():
    value = 246268
    if False and True:
        _dead_3216 = 102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgbUWWBt9Z83PjWN/n/FYAs+zk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 24 * 56 < 0:
        _dead_5929 = 703
    return total

def _νИΙψφΑκсαΠлοТσ():
    value = 238212
    text = __import__('base64').b64decode('dHBBSTNhSXp4M2xaRk05ekl0VzI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜьпΡΘΩЧНТуγХсгζ():
    value = 561386
    text = __import__('base64').b64decode('VlRHcDFXQjJoZHZoVXMxeFd4M20=').decode('utf-8')
    total = value + len(text)
    return total

def _λΟеρюЛЖчλфдАКС():
    value = 939553
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCW8V1Mu6pJSDR2L33WTCy0t/kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨΜДτЯпИθτлЮΞκΜр():
    value = 896782
    if len('') > 0:
        _dead_2201 = 410
        _dead_4307 = 140
        649
    text = __import__('base64').b64decode('S0w5T3hkNTkxUWZUQ2UzMkc0Q18=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫСοεΧэΦΥпмвιЯ():
    if len('') > 0:
        54
    value = 778948
    text = __import__('base64').b64decode('ZnozdVB4YktjRXZZRUw4bGRpQV8=').decode('utf-8')
    total = value + len(text)
    return total

def _юЩοΩαщβъК():
    if 28 * 100 < 0:
        pass
        _dead_2291 = 61
        13
    value = 518406
    if len('') > 0:
        532
        358
        429
    text = __import__('base64').b64decode('S2RnaFBaVFp4c1BCazdPRVl2X3Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        657
        _dead_4889 = 210
    return total

def _йРЧλюДσЩΞ():
    value = 222113
    if len('') > 0:
        pass
        34
    text = __import__('base64').b64decode('dGRwS3lISmp3c1FsbnNTakdYRmw=').decode('utf-8')
    total = value + len(text)
    return total

def _оъγвΠюυΩΨЕτыΝαЪ():
    value = 494108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnngSmIPra1SIwKizke3bDU/tXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЗПνУчηЗλγНΚΚΕд():
    if len('') > 0:
        _dead_1688 = 259
    value = 720965
    if 13 * 66 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kji9RH8305IxHD2q727BHH0GsEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОЗφЙΓΠЬτφЙ():
    value = 76816
    if False and True:
        pass
    text = __import__('base64').b64decode('UUp1MTNwMGtEWERxYjE0c3VqRmI=').decode('utf-8')
    total = value + len(text)
    return total

def _ДощΘΜοОξΑАбΕΨп():
    value = 572145
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LCjrYnc28486OyLywn2XDgcYtl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3177 = 955
    total = value + len(text)
    return total

def _врШкЛыΗЬβБΘдΒ():
    value = 773895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQi2ZmYL6vwWDz+I3gSzYnYb3Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8523 = 295
    return total

def _ХЩбЭωщΨΑΞГ():
    value = 143205
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EX3WQHIz16NaFSCznVCfLHx8szY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΓЮчΦоεОΤЦЖоеνΗΘ():
    value = 463365
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzzWSEM1rYELGz+xmmyYYi98w2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1214 = 766
    total = value + len(text)
    if False and True:
        _dead_7273 = 240
        131
        _dead_3912 = 998
    return total

def _ЩьζпГХялТ():
    value = 872113
    text = __import__('base64').b64decode('RzJ2dWxuZmg1bk51UXNhSmhPdHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _жЙФоЗρЦдΔуΗКΔΚЬ():
    value = 741183
    if 98 * 48 < 0:
        567
        _dead_8930 = 954
        _dead_3717 = 175
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ky30Wwc0qJIxFy2bxmKDEh0660o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 99 * 27 < 0:
        pass
    total = value + len(text)
    return total

def _ηмЬξΓЗрЗчΓςΜ():
    value = 298187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyG2Z0ks8ZwwEiz65gXEHBE870g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шйμΥАΙэЧ():
    value = 592206
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh/MR3Zhy/4BbFa7wFCREzQGzEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βвβчФПΡюεТВеθΖ():
    value = 402385
    text = __import__('base64').b64decode('Zjd2bkM5ZFNMbEQwQkQ2NlBzdEE=').decode('utf-8')
    total = value + len(text)
    return total

def _пζСηДОψЪаь():
    value = 900174
    if len('') > 0:
        _dead_9519 = 214
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiXbQGY41qUKCgKv+EycLQYd428='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 26 * 69 < 0:
        pass
    return total

def _ΝхтИщοΦСщШЛρω():
    value = 662069
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L37vTX5q/6RXCAC2mXK8PXQKsE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 34 * 46 < 0:
        211
        115
    return total

def _РЖΒкψωαΙξςΗвТожΣ():
    value = 412002
    if 56 * 3 < 0:
        pass
        _dead_2818 = 190
        pass
    text = __import__('base64').b64decode('bHRjNk9ldUZxRFdyZndlN1pGNk8=').decode('utf-8')
    total = value + len(text)
    return total

def _οаФΥθμьΝюυсΖχχΧЗ():
    value = 905328
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgPAeEkLyJ4GCVyg23iDFhZ+zWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜειΔρхБфЛΧχЭ():
    value = 210097
    text = __import__('base64').b64decode('cWpnanFfVnZQU1ZSMDZlSUlGNFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ТКдχοχΚΗΚУкΧ():
    if len('') > 0:
        _dead_2327 = 237
    value = 467391
    text = __import__('base64').b64decode('alJXZDEyeENRMDVXTTVpZE91OXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗγΓюζΨэЪЖΟцΒйс():
    value = 849682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mwz3WFYp97hUA1ebw3myEC4WvF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3381 = 88
        _dead_3258 = 384
        _dead_4949 = 865
    total = value + len(text)
    return total

def _ТιЖμВγБωΓР():
    value = 629603
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACa1Xlxu8qEKAzmQ7F6gMyh2620='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КγΦмΜΚκΝ():
    value = 571790
    text = __import__('base64').b64decode('ZUFPVnJsWHFqOThlaWdvVm9IWUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥшЛчιоТΖдъФνФ():
    value = 839466
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HR2ybG498IEVKB6H+nOmLQ8M7m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΡΚμΕнπΤНЧν():
    value = 253210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FD78NnYu+oYTFF2J5AKhHA0o0Es='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡзΛξψЮчМпОνгΙφΨγ():
    if len('') > 0:
        820
    value = 79642
    if False and True:
        _dead_8945 = 839
        709
    text = __import__('base64').b64decode('RWNTanNZdmpWM29RZFFpdGFUZEQ=').decode('utf-8')
    if 54 * 70 < 0:
        _dead_1440 = 400
        pass
    total = value + len(text)
    return total

def _ξΩοΩΒЕТЪЮ():
    value = 642438
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EC3mXEMJ/7sUCSu6wE6ZAyErx10='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1552 = 591
    return total

def _мΚθъΟΧРμЧотμιΗθ():
    if False and True:
        pass
        pass
    value = 758286
    if len('') > 0:
        _dead_4649 = 158
    text = __import__('base64').b64decode('b29MZ3RianVZdkhnbVVNc2JVN2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΧХκщЫδЫΖСΒνЛ():
    value = 4256
    text = __import__('base64').b64decode('dWtDZXBFQlUxZmZVTF9LQ1VabFY=').decode('utf-8')
    total = value + len(text)
    return total

def _ыЫΛлΧΓедτыаΕΖзαЦ():
    value = 654934
    text = __import__('base64').b64decode('VmFVOVlPclA0SEVzWTdYcXAxZG0=').decode('utf-8')
    if 41 * 29 < 0:
        _dead_6006 = 272
        pass
        364
    total = value + len(text)
    return total

def _ΘиδуγЛΛυцдΧС():
    if False and True:
        pass
    value = 526801
    if 22 * 66 < 0:
        180
        330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQnwZ3k9qZcGAAOM91WVHC185lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УЕНθлЮДλтΣкσ():
    value = 390306
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AD+xR0Yq0oM6PiGJnUXGEnYavTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9801 = 580
    total = value + len(text)
    return total

def _пγЬΚУсъДωжаΔИРκτ():
    value = 670503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSPld3oRrp8QIjmRmXeBGjwC3X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠЖЦМμИΖнЗтΓε():
    value = 53671
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHrPfQg1zKAxDQGG2k+iIj0azmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛкДЭгΟΖεъ():
    value = 251618
    text = __import__('base64').b64decode('bF92ajRQRmF5VW95RVRoTXhKWm8=').decode('utf-8')
    if False and True:
        477
        pass
        pass
    total = value + len(text)
    return total

def _ΜοΚιЫμГФΟακ():
    value = 777648
    text = __import__('base64').b64decode('ZEpZbnpBWVJVbF9rY01vUU9iM0U=').decode('utf-8')
    total = value + len(text)
    return total

def _πьΜчбвΗд():
    value = 626959
    text = __import__('base64').b64decode('ZzlHeEs5T2oyQ1pMU0pBc3MzQ3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨθЬΟВЬОΩι():
    value = 702272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDWzOEgp9pECPRWmngapACcJ/lQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΖЕщηΥβΥхтτΟ():
    if len('') > 0:
        627
        _dead_1165 = 877
        _dead_4056 = 86
    value = 785651
    text = __import__('base64').b64decode('ZGFvN3BUSUkxQzAyWkFTSjlHV2g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1450 = 177
    return total

def _δЖΟгΔХνкγΔςдОЩ():
    value = 739405
    text = __import__('base64').b64decode('ckJJZVFoVXlRcVRadEhfWEFreDM=').decode('utf-8')
    total = value + len(text)
    return total

def _чоδзζйяΘ():
    value = 748714
    text = __import__('base64').b64decode('TWRON2NQVTI0VXFtS21qQWVKN1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ψеЭυТВζяУКу():
    value = 277198
    text = __import__('base64').b64decode('TnhROE9panpZUldMUVVxMVZrbm8=').decode('utf-8')
    total = value + len(text)
    return total

def _ψωΖοБΕкЧГШ():
    value = 218684
    text = __import__('base64').b64decode('bjE3SWpla0VOVndlbG9faklwVDY=').decode('utf-8')
    total = value + len(text)
    return total

def _эαябБηГыЯВбε():
    value = 703938
    text = __import__('base64').b64decode('UFhsRHRDVmJGNm1keENvaDg4U04=').decode('utf-8')
    if False and True:
        730
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 64 * 83 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 90 * 85 < 0:
    pass
    _dead_9454 = 48