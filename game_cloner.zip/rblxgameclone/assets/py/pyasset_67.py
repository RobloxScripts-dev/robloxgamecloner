#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ьюφχЯнψЬтςλКξкЕь():
    value = 567662
    if 28 * 33 < 0:
        pass
        _dead_8743 = 616
    text = __import__('base64').b64decode('TzRIQjRJSnNidEV3dTZySVhOTTQ=').decode('utf-8')
    if False and True:
        pass
        pass
        495
    total = value + len(text)
    if 80 * 41 < 0:
        _dead_9730 = 331
        pass
        pass
    return total

def _ΘбзЪАχκδВЛ():
    value = 461404
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXbyXlYAyv0CEzqn337GHCMO814='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΠΜΠДИУΟВЕЯжЮп():
    value = 736417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NnfSO10JxKEWIh6L+1KFLTIG5Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜБСΒгМςΙП():
    value = 121786
    text = __import__('base64').b64decode('Skh6RU1KRlNnRnJ0cGNWOURUR1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛИПОШΧαγΚжКх():
    if False and True:
        pass
        pass
    value = 504318
    if False and True:
        pass
        _dead_6661 = 867
    text = __import__('base64').b64decode('S1ZhZXVTTHZvUFpSXzc3YndWd28=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΣΧαчΖΙφΨΧΖЮ():
    value = 946280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwnTQFoe74EULFu1kEWBZhAD3mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФЬεΦΠΟЩγлС():
    if len('') > 0:
        _dead_5814 = 660
    value = 26301
    if False and True:
        pass
        _dead_5798 = 659
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ihz1XH46r4sTGwyunmmgGg12zFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 22 < 0:
        _dead_1399 = 903
        _dead_5041 = 858
    total = value + len(text)
    return total

def _ΗхΧХяΣеΚаЙΑλςЫ():
    value = 58308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChXnaAQa06YJPhy6nw/BIHcGyUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЫΟтШξΣЕЛНДкΨΖΞ():
    if 50 * 28 < 0:
        pass
        905
    value = 865957
    if len('') > 0:
        228
    text = __import__('base64').b64decode('bkVZN0k5T3JMd09tazdqTGFwUkU=').decode('utf-8')
    total = value + len(text)
    if 90 * 100 < 0:
        _dead_6165 = 638
        pass
        pass
    return total

def _ζтЦηНΕЮиЙЫπ():
    value = 77753
    if 9 * 53 < 0:
        pass
        _dead_7752 = 657
    text = __import__('base64').b64decode('aG5zSnVLTjNHaU5OUEtOVUo0ZWo=').decode('utf-8')
    if False and True:
        668
        _dead_1623 = 781
        pass
    total = value + len(text)
    if False and True:
        _dead_5428 = 445
    return total

def _ΗΘзЦведЦЫυκ():
    value = 669286
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiToegMQ7oINDBe0zFK8OiIo4m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гΦБЪЩκхТЪΘνИξΛ():
    value = 399618
    text = __import__('base64').b64decode('bXZ0VW1lWUtPeHZ6aHJ6bUdSNzM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙхεлδФэδπΩη():
    value = 426253
    text = __import__('base64').b64decode('RUkzREM4WmFyVl9scjA1aTZ3TkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ДЛчгОХИΜкζ():
    value = 232748
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3aweEss6KMgDCyc5HKvJSs16Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пЭЗЖαПгΝСъΦфβ():
    value = 137375
    if len('') > 0:
        _dead_9069 = 639
        290
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDfjalw+0ZczCga57EGDLicq1mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иПСФЧГДΥλшβΕЖтεΙ():
    value = 263309
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgDQSno8x4YGGDeixEaZPSt9yWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юλТЫАιуλνШ():
    value = 672188
    text = __import__('base64').b64decode('ZkIxWG53R1hETXNxSm9kTDVsTEo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝпъςΙΣΞОΒ():
    value = 970839
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HD22b3w6qK03A1y1zlW3JyEZ0UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йςΚΕβРпΓΤЮΓфюйΔ():
    value = 292518
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('d1lKTF9TZUZHcmhBd2dMWWU5Y08=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        838
        199
    return total

def _ХΞСΧςщюΙЩв():
    value = 454293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAbQO2M78Jo5ORim2GChEQ4ZsWQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эОвΣδяхЗΒ():
    value = 145868
    if 7 * 19 < 0:
        _dead_9306 = 294
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnfCZ14xr7pUKSyJ2gaeFy8at1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _γяЙΩМπιбκΦ():
    value = 725729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCrDSwQN56MVbzqZxXCAJnYe8UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηγΟзБΑнΩΔчБиОаЖΕ():
    value = 797387
    text = __import__('base64').b64decode('ajNmS2F4cG14VFBjbGtsZEh3OXI=').decode('utf-8')
    total = value + len(text)
    return total

def _τКЖлУБιЭРЪщ():
    value = 845318
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAvPaVY1+75RYwyM5H+HYXcX9j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПмйЗΗнцτΤΠГтШЗ():
    value = 412867
    text = __import__('base64').b64decode('dnpIckp3bmRaQ05DcXQ3enJJSHI=').decode('utf-8')
    total = value + len(text)
    return total

def _хшΠИΒγΕЮοСο():
    value = 246315
    if 83 * 97 < 0:
        24
        _dead_4955 = 654
        850
    text = __import__('base64').b64decode('VjBMY203X0I1TWFwUF9pMHVVQWY=').decode('utf-8')
    total = value + len(text)
    return total

def _χнГΜραιЮΒω():
    value = 22023
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hz3pfQNgzf5TNRmLzVy9ZnAHtmY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φШТдъΛЗСΙцэΨБωЩ():
    value = 182527
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Khrje2sgy4FTPV2F8kSAMj0W0mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыεωεΘПХδРПΡиП():
    value = 318763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxC2XHlg+Y4wOQmr4AfABT8eyFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬЦйДεцωРΨζΘеεХЧΧ():
    if False and True:
        980
        pass
        _dead_7359 = 185
    value = 387789
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CA3zP2Ue3IMCET77/G+lGSYmvFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_5857 = 896
    total = value + len(text)
    return total

def _гΟмΚυΘМГχΝΛω():
    if len('') > 0:
        551
        _dead_4471 = 704
        959
    value = 560183
    text = __import__('base64').b64decode('c1BUZmhfcXVkN19iSFBkWGZNeGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ФЦεΣΩиΠРдьιδ():
    value = 628985
    text = __import__('base64').b64decode('RGQxUWIyVkN2VkRndVllMDdGVXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _λΩЯΝДЪТаЧψΖЦκΕЩ():
    value = 711163
    text = __import__('base64').b64decode('TkVUMmM3RUlRN2h2X00xMk9HdlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩАξΥΗΦβе():
    value = 493037
    text = __import__('base64').b64decode('eTc0NndfYm10cDlJQkN0QUV6a3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟшуцψыиэΧЬθΠΣЬе():
    value = 145627
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('WXBEWlF3QUU1UWdpX3FZUEM3aWY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        589
        pass
    return total

def _πΣНμМкΒйЗζ():
    value = 893202
    if False and True:
        _dead_2115 = 296
        _dead_4939 = 987
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bg3iTVkLz40GDV6B+kLIEA0b43Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ИбйμЖΦΔνеШΖΙφЭЯ():
    value = 11078
    text = __import__('base64').b64decode('akZacm13VmhCaGROR3VHZ3JtVG0=').decode('utf-8')
    total = value + len(text)
    return total

def _φЬГОаΔсьΡ():
    value = 626105
    if False and True:
        144
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FB3QXHMS7vhSLiDwym6xDBd/y0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПλМИепнЭξΙц():
    value = 180806
    if False and True:
        pass
    text = __import__('base64').b64decode('WENwb1FsNjVsN1h4Y2ZFXzNHaW8=').decode('utf-8')
    total = value + len(text)
    return total

def _θΘΧКяыдэλ():
    value = 625736
    text = __import__('base64').b64decode('Z0VkN05xYmg4UUFzUnNSRUhhZG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЕШяιθХз():
    value = 741123
    text = __import__('base64').b64decode('T2tqMzFWQnZ1NG02aTlMNFFEbzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ψСΔκΣМДЪОπΖ():
    value = 33868
    if False and True:
        306
    text = __import__('base64').b64decode('VzZoQkhQMVBQX0IxSWg4UUI3bk0=').decode('utf-8')
    total = value + len(text)
    return total

def _юγβЗЪγΞзοΠμ():
    if False and True:
        787
    value = 137408
    if 60 * 1 < 0:
        _dead_2373 = 171
    text = __import__('base64').b64decode('enFHbWMxU3Z6WmZsbkhyNFR5QXU=').decode('utf-8')
    if False and True:
        _dead_7643 = 434
        _dead_9388 = 933
        128
    total = value + len(text)
    if False and True:
        123
    return total

def _АяЭυΠЖΕАΝНрηЫпΟ():
    value = 257170
    text = __import__('base64').b64decode('T1lPSFhBTEs4bHRpaDNpV3ZtdUo=').decode('utf-8')
    total = value + len(text)
    return total

def _НгСΩщБΚйх():
    value = 544957
    if len('') > 0:
        pass
        pass
        524
    text = __import__('base64').b64decode('TEdnV1ZqOElIS2IzSzlteHR1RTk=').decode('utf-8')
    if len('') > 0:
        pass
        737
    total = value + len(text)
    return total

def _яΛрыЦЭоЯхφСЭдГ():
    value = 596046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LibOaEMw/YIvPRig0ECWZQEtyEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 22 * 76 < 0:
        _dead_8246 = 440
        _dead_2308 = 613
        pass
    total = value + len(text)
    return total

def _ΛбшмюξΝЕΧβΜлр():
    value = 143263
    text = __import__('base64').b64decode('azVHQ0JubFF0UVdfRmhJdXI0Z2o=').decode('utf-8')
    total = value + len(text)
    return total

def _гρчδиЯюΥΜΘНΓаБК():
    value = 780327
    text = __import__('base64').b64decode('ZVJmUEthZHF2eURWaTNJbTB1MUg=').decode('utf-8')
    total = value + len(text)
    return total

def _ымчΧρНγΠ():
    value = 606453
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx+3ZUEA9YYrFQaK52SiHz0p0HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1764 = 342
        _dead_1712 = 392
        638
    total = value + len(text)
    return total

def _ΠДгκЕβюσΚкцлφ():
    value = 889426
    text = __import__('base64').b64decode('Y0t0eE4yRHpzWnlBelhlamxqNkQ=').decode('utf-8')
    if False and True:
        106
    total = value + len(text)
    if 21 * 7 < 0:
        996
    return total

def _ЭΦηΜИбζλψ():
    value = 851724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTy0OXpt3/4hPBuv7HSXNnIG400='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 89 * 50 < 0:
        pass
    total = value + len(text)
    if len('') > 0:
        558
        354
        924
    return total

def _чГМΛцρφБ():
    value = 122716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSLoQgEtrqYmFBqSxgSEAXUo43c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΠЮФМЩΖΦОСΙЪνШяЩ():
    value = 914209
    if 92 * 91 < 0:
        pass
        930
        597
    text = __import__('base64').b64decode('WkY2XzJtVnBROFJGUVA1dHYyVEY=').decode('utf-8')
    if False and True:
        291
        _dead_8286 = 414
    total = value + len(text)
    return total

def _иЧььωΟЗΛφΧΤю():
    value = 256647
    text = __import__('base64').b64decode('RjdQRVM1c2lGejBVZ3BodUtENmE=').decode('utf-8')
    total = value + len(text)
    return total

def _РΗУгоХхφ():
    value = 170329
    text = __import__('base64').b64decode('TlhocTl2dTBxQVE5TnRjMVhOTDY=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        341
    total = value + len(text)
    return total

def _лснВσЯЬТнпνζωΩ():
    value = 169179
    if len('') > 0:
        _dead_5619 = 375
        0
        143
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiL2Z3I337I1HFi64leqICAmsUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бξΡпΛωЪм():
    if len('') > 0:
        999
    value = 233760
    text = __import__('base64').b64decode('ZTdJUm9SSzlNUDFjVURGOVgxWjY=').decode('utf-8')
    if 21 * 67 < 0:
        pass
        837
        _dead_2863 = 807
    total = value + len(text)
    return total

def _ΚψРΤςΒИρΨЦωΧлГ():
    value = 176915
    text = __import__('base64').b64decode('VmpZc0ZfMktrR29HMVN1eEJyZTM=').decode('utf-8')
    total = value + len(text)
    return total

def _вοЪεωΦЮμЕЮФДΕпβС():
    value = 400709
    text = __import__('base64').b64decode('dWcxZVh1WHhCVTFkTFlRSE96a0Q=').decode('utf-8')
    total = value + len(text)
    return total

def _δΙСΧПσнЗΧУ():
    if 44 * 56 < 0:
        _dead_6503 = 641
    value = 561027
    text = __import__('base64').b64decode('R0UwRzRqNlN2QnRzY2QyZmJsRDI=').decode('utf-8')
    if False and True:
        pass
        _dead_5099 = 84
    total = value + len(text)
    return total

def _ХΛωνсγЯОиМ():
    value = 359754
    text = __import__('base64').b64decode('SEE1aDY3SzhEODdBU0lmNEduU2M=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛШоΚΞЫрэсАПυΙκщ():
    value = 134364
    text = __import__('base64').b64decode('RWZLSmplaEN6SXFpdEo1MExXZkU=').decode('utf-8')
    if len('') > 0:
        pass
        311
    total = value + len(text)
    return total

def _ГγμХнνΒаχ():
    value = 360527
    text = __import__('base64').b64decode('enBZTThjZ2duVEYyeFU1ejRxMWk=').decode('utf-8')
    if False and True:
        674
        625
    total = value + len(text)
    if False and True:
        pass
        971
        900
    return total

def _ςδкЙИФзΗъЛΩθиΟВ():
    value = 212962
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiGxO3cczLwtGV2JnH+GBCMex0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςОЖСъΩШЗοщΡЙВж():
    value = 750422
    text = __import__('base64').b64decode('eXdVanJ0MGdIOXRUQ1NmdFU5Qnk=').decode('utf-8')
    total = value + len(text)
    return total

def _αжоЙρбζКΒ():
    if 61 * 15 < 0:
        pass
        pass
    value = 44404
    text = __import__('base64').b64decode('SFRUUnVySkhHWUhDRWc0ME0zNlM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЙωхзбπφφεΗΞДΩТζ():
    if 34 * 88 < 0:
        pass
        _dead_6945 = 566
        pass
    value = 108244
    if False and True:
        _dead_8284 = 736
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzjUQEgSrp1XHD2M8GC4E3IF7Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СЭζтПуσδμуαΠРЪ():
    value = 118035
    if False and True:
        pass
        713
        pass
    text = __import__('base64').b64decode('bmVDb0QyWklwSmZ3QmdWM2M4RW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗпкйΠрΤΟΦΑяя():
    value = 949821
    if len('') > 0:
        _dead_4860 = 72
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxb8WXxgq5knNDiT5WbIIC57234='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦαВЪπςвΞ():
    if len('') > 0:
        pass
        814
    value = 29456
    text = __import__('base64').b64decode('V25DUWJNUEFrbWtVdHBoSnBtZTc=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if 1 * 54 < 0:
        _dead_6758 = 650
        688
        _dead_9676 = 53
    return total

def _ЖОКНмЦМΦςΙΗΦξфъК():
    if len('') > 0:
        pass
        _dead_6900 = 487
    value = 908184
    text = __import__('base64').b64decode('dmZtOHZHSnhyeWVhcmIzVERFc1Y=').decode('utf-8')
    if 21 * 5 < 0:
        643
    total = value + len(text)
    return total

def _ХрГуηΠйФчΥл():
    value = 95292
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQDCdGAN9KRXCDiT+GLBPBIgxT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓШΕсΠдΣκзσД():
    value = 752652
    text = __import__('base64').b64decode('Q05sS2x2MmNMbTM4RlFUV2E0djk=').decode('utf-8')
    total = value + len(text)
    return total

def _вЬаΘьЗьалпЭ():
    value = 335042
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSvDO0US2vgqKxqTzHSbN3130EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мψρЗЛЙфеΡΜХΧУΠ():
    value = 521097
    text = __import__('base64').b64decode('dVljUEZlZEVQZXRMclZlYm9UYXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩяЕσθтЖпςΦΡлУ():
    value = 597222
    if False and True:
        _dead_2830 = 33
    text = __import__('base64').b64decode('RjBncUxSUVdwcFljX3ZENllCUDI=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΦЦЪωПыМβФйΚыКю():
    value = 495550
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jzj+R3sBy44TKz2w6XiaMgYi7GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρΗΠЮΚЖШκΛЫщυ():
    if 31 * 19 < 0:
        pass
        _dead_2949 = 615
    value = 554761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyP8anIc35IpBS6gzlqzOXQa7Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8390 = 884
        _dead_1971 = 59
        444
    return total

def _ΠωαΩДΝξСАΡος():
    value = 115469
    text = __import__('base64').b64decode('ekVLUFZVWWFENHJ3VFpUcWpaYWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ятμθγцеоакηπчιь():
    if len('') > 0:
        _dead_9797 = 526
        _dead_2101 = 256
    value = 884465
    text = __import__('base64').b64decode('ZWVXbVVyQ19mZ2p4TkpJWXVvNks=').decode('utf-8')
    total = value + len(text)
    if 9 * 69 < 0:
        123
    return total

def _ьξΖМкΟχцζΠтЬΓΩ():
    value = 847271
    if len('') > 0:
        315
        pass
    text = __import__('base64').b64decode('SXJfNnoyZEsxSjR5dDN2cDlCOWQ=').decode('utf-8')
    if False and True:
        207
        989
    total = value + len(text)
    return total

def _пьиШχмΧΥωχбρεΩχε():
    value = 800305
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQztSwAx3ZsnKAutylOvYwJ250w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        594
    total = value + len(text)
    return total

def _ΗАοЙυМδξΡ():
    value = 222517
    if False and True:
        pass
    text = __import__('base64').b64decode('QmtoekczVlhLaHdIVUczRnBmVXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _якЬЪзАшеьЗжлЙ():
    value = 92014
    text = __import__('base64').b64decode('VDFLdVluYm1sZE5hc1kwYkI2MDE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8589 = 710
        pass
    return total

def _ΠηфσАθΥβО():
    if False and True:
        _dead_5974 = 920
        _dead_3992 = 389
    value = 500460
    if False and True:
        941
        pass
    text = __import__('base64').b64decode('cl9sMTRXRkFwQW5qMU9VeXlqRHA=').decode('utf-8')
    total = value + len(text)
    return total

def _НаρгτПЩЖфРοηвΩρ():
    if len('') > 0:
        pass
    value = 999163
    if False and True:
        514
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiO2WEk9xKRUHVf1yX+gYRwF82Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΜрΚΠГιХяЗγД():
    if False and True:
        pass
        pass
        _dead_6947 = 352
    value = 402341
    if 16 * 64 < 0:
        _dead_6006 = 764
        _dead_5365 = 74
    text = __import__('base64').b64decode('WDF6MTdacXNBbF9iUUZOWjJVeFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠвΘЭπΓЯВΩоΖΠΩΡχ():
    value = 328095
    text = __import__('base64').b64decode('UzZxbkI2cW9ReGxTRm9KWWRUanM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣнаΞΚΛУτемЫ():
    value = 584777
    text = __import__('base64').b64decode('aTBkclJHQlZiNFVLNHpUeFl0Sjk=').decode('utf-8')
    total = value + len(text)
    return total

def _УοЖРЖлΒςтгΖΦΗщυ():
    if len('') > 0:
        _dead_2216 = 423
        pass
    value = 644650
    text = __import__('base64').b64decode('eGtlTHdraHNBSHVhOXRITlY5b1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _вХπΠξпЧп():
    value = 464380
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDvPS19s7vEsHAmJ70yFPAsdvXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςсσШφΝъχвΡЦ():
    value = 943199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NzrWfgM0ro0tMR+kyVCFJxQB8XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТзНцыΙЛΠΘЭαиεЛΘΦ():
    value = 993106
    text = __import__('base64').b64decode('VHZtR0RSRUtsOG9oaTZOMGVYdVI=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _εРΣнΠζσСΛМпωι():
    value = 58172
    text = __import__('base64').b64decode('bUduZ0dPZjc3TDJoVXlRMk9NTGE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘгЧЭЫωКЪΙαУρε():
    value = 58862
    if False and True:
        557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyHKYFUP1aQWayCt73+5FykGzk0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        417
    total = value + len(text)
    return total

def _ΓΘЙеΡФчρ():
    if 45 * 34 < 0:
        _dead_2712 = 56
        _dead_9534 = 294
        _dead_9150 = 636
    value = 427238
    text = __import__('base64').b64decode('VEJsRGV4RmpmS2tGTFNOd25UVFA=').decode('utf-8')
    if len('') > 0:
        894
        _dead_3291 = 546
    total = value + len(text)
    return total

def _ξαшшΓΑзЧθцг():
    value = 230619
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAL3QFspqaEsHFm2ylyUYXd/71Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οξхсσеВωЫθпΥж():
    value = 406945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwbeO1c7pqtWLyOHxGCzbAs7/Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_9277 = 392
        85
    return total

def _РΛηуΗБβξж():
    value = 480504
    text = __import__('base64').b64decode('WktrT3lmRDg4ZlJMbTRUVXZWNXI=').decode('utf-8')
    total = value + len(text)
    return total

def _эМЬиЖπвйЕШЮЬ():
    value = 614564
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BiLRXn5q7owGEzCm6l+dNyg58kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1554 = 155
        944
    return total

def _ΝЕБπθЖδπТτыХΡО():
    value = 230646
    text = __import__('base64').b64decode('emRsdUJJMF9TbkxVVkpQMmhuX1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΖгσυξΩЪфОмлΖ():
    value = 738193
    text = __import__('base64').b64decode('blFLaUoza3FIUlFCT3FCcTg5dVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡКкЫпφюпвОΣΞБυ():
    value = 315393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AxzQOElq6PorCimGkVuHHzMg1zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        465
    total = value + len(text)
    if len('') > 0:
        pass
        955
    return total

def _вοаΜΖтжΠюАιΤф():
    value = 187606
    if 17 * 35 < 0:
        165
    text = __import__('base64').b64decode('UWxFbnVsd1pycHJFTjdNanNrM3Q=').decode('utf-8')
    if False and True:
        217
        143
        _dead_9352 = 223
    total = value + len(text)
    if False and True:
        pass
    return total

def _ДНТжнΞДъъБιфΣЖ():
    value = 519688
    if 44 * 9 < 0:
        pass
        _dead_2360 = 433
        323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FB/cOHceyqNSMiWumH3BORQByUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СбКучρΘνячуφθΠ():
    value = 147507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ah3zdFMyrZIqbTi0/3ejDBc63Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3675 = 878
        pass
    total = value + len(text)
    return total

def _ρТδвРΥГнδΖζЪмηрμ():
    if len('') > 0:
        276
    value = 318339
    text = __import__('base64').b64decode('TzJoWVZwTFplX0pKZnRQRTE2RWw=').decode('utf-8')
    total = value + len(text)
    return total

def _δуХЩΗβБΘΝπОВ():
    value = 917928
    if len('') > 0:
        _dead_7224 = 951
        pass
        496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSXORlg61aMJGSyWmAOZA3IQ70c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        88
        641
        pass
    total = value + len(text)
    if 80 * 25 < 0:
        pass
        pass
    return total

def _ГНуωжΓЧΡφηЖ():
    value = 144406
    text = __import__('base64').b64decode('elFQd3Q0NXF6V25wZFFQMWdIXzk=').decode('utf-8')
    total = value + len(text)
    return total

def _ζйыТΩкяЭ():
    value = 445249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAXIRVMr0qUFaSSS4WeCJwMH5W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗβΚЕΡρςνИКМвΜКсЭ():
    value = 3249
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAiyewQS6osoOQqHmQaGLhALxks='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ббЭεМθоδΛщηшД():
    value = 403621
    text = __import__('base64').b64decode('RVl6UEhuMHhWOFRqQzBFRjFUdUc=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _слпЫρηζφυБв():
    if len('') > 0:
        312
    value = 372263
    text = __import__('base64').b64decode('TndaYlRzQWZaNm4xYmVvM2pQQ0M=').decode('utf-8')
    if 100 * 84 < 0:
        71
        _dead_7358 = 349
    total = value + len(text)
    return total

def _бχРФюωТЛС():
    if len('') > 0:
        534
    value = 579783
    text = __import__('base64').b64decode('eXBxbXVGakU0RXlBNnBwUnByV0U=').decode('utf-8')
    if False and True:
        pass
        167
    total = value + len(text)
    return total

def _ЦчлРψбнтΓпΕсωищ():
    value = 821398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCvJTVA0wZkaMjm10neJPiEBvWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_8310 = 156
        243
    return total

def _νΥΗΚЯАΚοРοΑЙ():
    value = 632290
    if False and True:
        pass
        601
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3nbOgZpzvosLwH27H6zHTIG9nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 54 < 0:
        _dead_1985 = 907
        _dead_6584 = 551
        658
    total = value + len(text)
    return total

def _яθΟθΘЕΗяΝςШвυςχе():
    if 64 * 83 < 0:
        _dead_9376 = 98
        _dead_3116 = 235
    value = 413117
    text = __import__('base64').b64decode('WDBQZGI0M0RzcVM2T3RldkdOX3c=').decode('utf-8')
    total = value + len(text)
    return total

def _νууящφихηДА():
    value = 176519
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTj9bURp6oE7Ml2X73uSBBUf1kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РАъуЛΡΧяφΩΒШΟφ():
    value = 323889
    text = __import__('base64').b64decode('eWZtMW9NWDlGN2dYTGdBYVRzd3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _иОΩаЦвΤвΜэщρ():
    value = 199865
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Li7cS3Ut9YkmAze0kFGTPiAj0k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яВΜЫΩεΑВуф():
    value = 37162
    text = __import__('base64').b64decode('SjV4Zm9YSENCQzZsdDZTTzMweUs=').decode('utf-8')
    total = value + len(text)
    return total

def _дШиЗюоπΔЙЙ():
    value = 170488
    text = __import__('base64').b64decode('b20ybHVmYmdBb3NSSk5WUFFBcEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙжбΨЫмΥΝΟФ():
    value = 591094
    if 65 * 55 < 0:
        194
        164
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C33APAkg9oxaGQu0+2CCBx148Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кΦΠΟΜдυДлΩΘΙЩн():
    value = 286600
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRrXP1sr54orChzw+2afZAZ+0Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘπнЫχбχФκΣУт():
    value = 72378
    text = __import__('base64').b64decode('S0NaOWcyMXZKME9TMmZRRlBEQmE=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _йЮбкгνЧШΜФмΩУкЛΓ():
    value = 316928
    text = __import__('base64').b64decode('akdfRmNXVGlXZUpQWV9SbFFuTmg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΟШьоοоцΙРОΡΖч():
    value = 501714
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDrxW0dg+LkXIyXx8FnGPAN35kA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лΔУЗюцПЫΔДΣΔΡ():
    value = 437919
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjX+Pglq0qQ5ESGQ4gC+MyQ50Xk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γжгηйΒΙΑПйЯэμЕР():
    if False and True:
        pass
        _dead_4085 = 678
    value = 389908
    if len('') > 0:
        _dead_7792 = 633
        445
    text = __import__('base64').b64decode('RVdBOHlxNW1DdTZKcWR2N2VfTFA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8031 = 351
        413
        141
    return total

def _χλшРβВθΝσрАъ():
    value = 435811
    text = __import__('base64').b64decode('TnNqZjNITWVUMWVWWUdxX3J2dmk=').decode('utf-8')
    if len('') > 0:
        975
        pass
        pass
    total = value + len(text)
    return total

def _ΜηБвеОΥΜξбγж():
    value = 343499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDe8fUcPp5saHh7z4Xq7JygovGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΡЕξΩСЯΤмιΡе():
    value = 458454
    text = __import__('base64').b64decode('eEVIVldNYjl1b3VFVF9BRmM2cHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕЭгЗОууρΙωΗΒωш():
    if False and True:
        pass
        735
        pass
    value = 828229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyrCV1Uqrf8sKjmk2VLGOSEr3Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 100 * 48 < 0:
        pass
        _dead_1361 = 508
    total = value + len(text)
    return total

def _ΥуψΙςЦХжЬΔЫΑьщ():
    if len('') > 0:
        pass
        537
    value = 919688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAPgeV4s1PEhEhu2mFOHJzEY1T4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψΨОΜжΡьυР():
    value = 220860
    if len('') > 0:
        469
    text = __import__('base64').b64decode('QmV6QzRQdnVwQlFxa3BLcDNFUlc=').decode('utf-8')
    total = value + len(text)
    return total

def _оγκΗщьСПΘин():
    value = 113505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgbcfWkw8P0MCl60m2mqDgA2tmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘηФοАюПа():
    value = 410341
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDvFV3o16ZEHFleImX7IZSJ50m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κгбЩζКиυΓΘМтНΑДх():
    value = 145981
    text = __import__('base64').b64decode('QU9CUjZvVHZnSjM0Q2dubHFfRjc=').decode('utf-8')
    total = value + len(text)
    return total

def _иОΓΠзΕΣγъΣыδжиιΡ():
    if 60 * 13 < 0:
        _dead_9101 = 387
        _dead_9901 = 413
    value = 535159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECTQakk1+opXMBqZ8U/BDjM24GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΑζΙΛδДоЮьцъ():
    value = 799040
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzvnbVYD8YIPER6v7kC+Nj8Awn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДεАΙβвэВВ():
    value = 581819
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzXDPnwj6vEVYgmr93zFHjMNvF0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        583
    total = value + len(text)
    return total

def _яъνвΖОΘδμЬδШЧ():
    if len('') > 0:
        789
        417
    value = 772242
    text = __import__('base64').b64decode('YXhna042ZXBteWtkN2xLb1Q2RVI=').decode('utf-8')
    if 89 * 97 < 0:
        pass
    total = value + len(text)
    return total

def _юьЕПэГСΔ():
    value = 775117
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PAbtbGRo2KkaLxicylTHHyQ6s1g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тгрьЫгЙΠГ():
    value = 837882
    text = __import__('base64').b64decode('RzZnZDZhYW5GQ0Q2YWdrV0JwNDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ОьДΡΡкΚρйμοΧΦКΤ():
    value = 718545
    text = __import__('base64').b64decode('dmJpRDE0MjRRRWI2YWc3bkxGZU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙыυПЖдеТсРНΜζфк():
    value = 752977
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgnNZ0gc9LFTNxym0GOSZwQs7Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 71 * 91 < 0:
        _dead_7256 = 28
        pass
    return total

def _ζЛжЗкΣузшΣΚΟаГΝе():
    if 66 * 42 < 0:
        pass
        145
    value = 112863
    text = __import__('base64').b64decode('Vl9WbGJEaGlkY0tiZlJyZmVkNks=').decode('utf-8')
    total = value + len(text)
    return total

def _САЪцЖβΘТ():
    if len('') > 0:
        pass
    value = 403379
    if False and True:
        pass
        833
        406
    text = __import__('base64').b64decode('d3QwZUJHZXRnVW1ZbWx0ZldFdTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜзЖЩυВψιδ():
    value = 628729
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DC6yYF8Q5/1RAj6L+EeGJA0C5kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мсιρξΖОχβηγβйςσх():
    if False and True:
        _dead_8153 = 656
    value = 128404
    if False and True:
        790
    text = __import__('base64').b64decode('bHkzbk5neU4xYlhuOU5USkhfbEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдΕЧπдΘЕθУ():
    if 55 * 53 < 0:
        822
        _dead_1882 = 749
    value = 521075
    if 70 * 67 < 0:
        892
        pass
    text = __import__('base64').b64decode('RDFXVFA1bWdYc1dRaGJ1TnBBZ3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦфΖМτетε():
    value = 687962
    if len('') > 0:
        pass
        _dead_6556 = 87
    text = __import__('base64').b64decode('ZkIxXzRrTzNKTXY2T3NYdl81Ylk=').decode('utf-8')
    total = value + len(text)
    return total

def _ТаАбЕУθχξπ():
    value = 738612
    text = __import__('base64').b64decode('b2RtSzZwZGZGN012QkpuWHFBWkc=').decode('utf-8')
    total = value + len(text)
    return total

def _ФωψдуаψσξγюЖЪΗο():
    if False and True:
        _dead_6601 = 129
        _dead_6231 = 411
    value = 733786
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Py7Ka2Uf17FXAzyJyXyCFRN5zz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рйδжπτζΒТΣΣчγБ():
    if 41 * 80 < 0:
        423
        172
        609
    value = 951599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhvLO244/b4oMQuV3nuKOCAH/Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3115 = 854
        pass
    total = value + len(text)
    return total

def _ГαζΩΗЧδъΟιγθωС():
    if len('') > 0:
        _dead_3265 = 148
    value = 496081
    if 67 * 4 < 0:
        _dead_7258 = 152
        53
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CifsagFsq5oJYluFmWCkDQs93VE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ονΘеψταйЛДэн():
    value = 88791
    text = __import__('base64').b64decode('R2poa2RKdVdXeWpzOFFucjdaREE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝηмπθПςоУ():
    value = 560820
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHyzQGc22oImCQ7x0UGEYw8Y6Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 21 * 36 < 0:
        512
    total = value + len(text)
    return total

def _ψщΜδсΧэбэψУφο():
    value = 746828
    if False and True:
        pass
        pass
        pass
    text = __import__('base64').b64decode('TjZ5MERNUVliMDBrd2ZRVkdpVTQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8704 = 217
        pass
    return total

def _прозЕЖτюЮΡЕИмΞшΗ():
    value = 809954
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyjIbQQxx4YQMgi08Q+WMjYQzFQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΧХЭыИфΣЮЛеς():
    value = 394597
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FhztPXcX7YIHaTeqmVGDLQk/03s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σВЫъΞΘОμКНФяцεΩ():
    value = 831754
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DR69WFg9qoMSFB+xykSUJyQ7520='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ιθТпгΥйβеа():
    value = 937584
    text = __import__('base64').b64decode('dlJLMWtiSXFyajJYNGZUNHdEenA=').decode('utf-8')
    if False and True:
        382
    total = value + len(text)
    return total

def _ЪюьΘэθμΖБСэβγΒЭβ():
    value = 817237
    text = __import__('base64').b64decode('RGpQWXczZGlrQ3NBNlhsT1BVOVE=').decode('utf-8')
    if 2 * 29 < 0:
        pass
        _dead_3422 = 207
        _dead_2429 = 562
    total = value + len(text)
    if False and True:
        793
        _dead_8844 = 374
        109
    return total

def _ОмНΛοЧпροв():
    value = 588013
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQC0Zkst27ASbAiWm0HCZig401s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςЪσΨДАμчοΙвщЖ():
    value = 400621
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pw3Gfwcxqq0yESOo2A+yIBcG7Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫζψςΝыСд():
    value = 400457
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyHNeWk01blRMAaIwXGdNw8etFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _лЩЦкшТΝεΓьШънИМ():
    value = 267657
    text = __import__('base64').b64decode('aXJxQ3ZmSmNYVjJfeDBsMlR3dE4=').decode('utf-8')
    total = value + len(text)
    if 34 * 87 < 0:
        pass
        463
        pass
    return total

def _ПЫσΚеЪеυνσηч():
    value = 1867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSvSXFQP2YUMOD3ykXyzIwwi61E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νФλэξУοж():
    value = 542199
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHvXP2du0Y4CMjChkAO0ICQ9tGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 1 * 2 < 0:
        _dead_4038 = 3
        pass
    total = value + len(text)
    if False and True:
        _dead_5510 = 335
        pass
    return total

def _κδьВПΤШцΝмωСθΙФ():
    value = 252748
    text = __import__('base64').b64decode('SHlLRnZPbFNnVWQyTXlCSTJ5UUY=').decode('utf-8')
    total = value + len(text)
    return total

def _СцЧЖΖΖωονΠκЫд():
    value = 280767
    text = __import__('base64').b64decode('ZW41aFRTdUpkbm16VjF2QW9vMkw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣσΙεбРςΑЩШПаЧΚМλ():
    value = 780367
    text = __import__('base64').b64decode('VGtHaXRsQ04wUW4yR2tjaW9DYkM=').decode('utf-8')
    total = value + len(text)
    return total

def _рЬдΠЛмШΘυΗφма():
    value = 109536
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ax3cfnowx4UkPxavn3eIIRE3w1o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6294 = 793
    total = value + len(text)
    return total

def _мЛθΘИζΝъω():
    value = 397901
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDq2d2hpy4MKbgW1/WyvYBIlsEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        640
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()